require "vagrant"

module VagrantPlugins
  module GuestCygwin
    class Guest < Vagrant.plugin("2", :guest)
      def detect?(machine)
        machine.communicate.test("/usr/bin/uname -s | grep 'CYGWIN'")
      end
    end
  end
end
