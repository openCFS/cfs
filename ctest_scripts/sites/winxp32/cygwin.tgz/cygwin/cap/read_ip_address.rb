module VagrantPlugins
  module GuestCygwin
    module Cap
      class ReadIPAddress
        def self.read_ip_address(machine)
          command = "ipconfig | grep 'IP Address' | cut -d':' -f2 | sed 's/ //g'"
          result  = ""
          machine.communicate.execute(command) do |type, data|
            result << data if type == :stdout
          end

          result.chomp
        end
      end
    end
  end
end
