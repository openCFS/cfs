require 'set'
require 'tempfile'

require "vagrant/util/template_renderer"

module VagrantPlugins
  module GuestCygwin
    module Cap
      class ConfigureNetworks
        include Vagrant::Util

        def self.configure_networks(machine, networks)
        end
      end
    end
  end
end
