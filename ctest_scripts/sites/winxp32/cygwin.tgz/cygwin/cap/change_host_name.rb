module VagrantPlugins
  module GuestCygwin
    module Cap
      class ChangeHostName
        def self.change_host_name(machine, name)
        end
      end
    end
  end
end
