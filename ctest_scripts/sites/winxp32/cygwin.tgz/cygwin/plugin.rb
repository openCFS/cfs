require "vagrant"

module VagrantPlugins
  module GuestCygwin
    class Plugin < Vagrant.plugin("2")
      name "Cygwin guest."
      description "Cygwin guest support."

      guest("cygwin")  do
        require File.expand_path("../guest", __FILE__)
        Guest
      end

      guest_capability("cygwin", "halt") do
        require_relative "cap/halt"
        Cap::Halt
      end

      guest_capability("cygwin", "shell_expand_guest_path") do
        require_relative "cap/shell_expand_guest_path"
        Cap::ShellExpandGuestPath
      end

      guest_capability("cygwin", "mount_nfs_folder") do
        require_relative "cap/mount_nfs"
        Cap::MountNFS
      end

      guest_capability("cygwin", "mount_virtualbox_shared_folder") do
        require_relative "cap/mount_virtualbox_shared_folder"
        Cap::MountVirtualBoxSharedFolder
      end

      guest_capability("cygwin", "read_ip_address") do
        require_relative "cap/read_ip_address"
        Cap::ReadIPAddress
      end

      guest_capability("cygwin", "configure_networks") do
        require_relative "cap/configure_networks"
        Cap::ConfigureNetworks
      end

      guest_capability("cygwin", "change_host_name") do
        require_relative "cap/change_host_name"
        Cap::ChangeHostName
      end

    end
  end
end
