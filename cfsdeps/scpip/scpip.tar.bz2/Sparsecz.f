      SUBROUTINE BLOCKDEC (ROWS,COLS,SUPN_SPLIT,LCOLPNT,LVAL)

	IMPLICIT NONE

	INTEGER          ROWS,COLS,SUPN_SPLIT(*),LCOLPNT(*),COL1,
     +                 BLOCK,PNTR,M,N,COL2,COL3
	DOUBLE PRECISION LVAL(*)


      BLOCK = 0
      COL1 = 1
      M = ROWS
      PNTR = LCOLPNT(COL1)

100   CONTINUE
      IF (COL1 .LE. COLS) THEN
         BLOCK = BLOCK + 1
         N = SUPN_SPLIT(BLOCK)
         CALL DENSDEC (M,N,LCOLPNT(COL1),LVAL)

         COL2 = COL1 + N
         COL3 = COLS - COL2 + 1
         M = M - N
         PNTR = LCOLPNT(COL2)
         IF (COL3 .GT. 0) CALL MATMAT3 (M,N,COL3,LCOLPNT(COL1),LVAL,
     +                                  LVAL(PNTR),M)
         COL1 = COL2
         GOTO 100
      ENDIF

      RETURN
      END
C
C-----------------------------------------------------------------------------
C
      SUBROUTINE DENSDEC (ROWS,COLS,LCOLPNT,LVAL)

	IMPLICIT NONE

	INTEGER          ROWS,COLS,LCOLPNT(*),PNTR,COL,M
	DOUBLE PRECISION LVAL(*),DIAG,MAXEL

      MAXEL=1.D0
      M     = ROWS
      PNTR = LCOLPNT(1)

      DO COL = 1,COLS
         IF (COL .GT. 1) THEN
            CALL MATVEC (M,COL-1,LVAL(PNTR),LCOLPNT,LVAL)
         ENDIF

C COMPUTE DIAGONAL:
         DIAG = LVAL(PNTR)


C
	   IF (DIAG .LT.1.D-14) THEN !EMACH EIGENTLICH
	      DIAG=1.D-14
	   ENDIF
C

	   DIAG = DSQRT (DIAG)
         LVAL(PNTR) = DIAG
         DIAG = 1.D0/DIAG
         M = M - 1
         PNTR = PNTR + 1
         CALL SCPDSCAL (M,DIAG,LVAL(PNTR),1)
         PNTR = PNTR + M
      ENDDO

      RETURN
      END

C
C-----------------------------------------------------------------------------
C
      SUBROUTINE ELTREE1 (DIM,ADJPOINT,ADJLIST,MDORDER,MDORDER2,
     +                    LEVELUP,LEVELDOWN1,LEVELEQ,MDORDER3)

      IMPLICIT NONE

	INTEGER DIM,ADJPOINT(*),ADJLIST(*),MDORDER(*),MDORDER2(*),
     +        LEVELUP(*),LEVELDOWN1(*),LEVELEQ(*),MDORDER3(*)


      CALL ELTREE2 (DIM,ADJPOINT,ADJLIST,MDORDER,MDORDER2,LEVELUP,
     +              MDORDER3)

      CALL ELTREE3 (DIM,LEVELUP,LEVELDOWN1,LEVELEQ)

      CALL ELTREE4 (DIM,LEVELDOWN1,LEVELEQ,MDORDER3,LEVELUP,MDORDER)

      CALL INVORDER (DIM,MDORDER2,MDORDER3,MDORDER)

      RETURN
      END

C
C-----------------------------------------------------------------------------
C
      SUBROUTINE ELTREE2 (DIM,ADJPOINT,ADJLIST,MDORDER,MDORDER2,
     +                    LEVELUP,MDORDER3)

      IMPLICIT NONE

	INTEGER DIM,ADJPOINT(*),ADJLIST(*),MDORDER(*),MDORDER2(*),
     +        MDORDER3(*),LEVELUP(*),I,J,NODE,J1,J2,NEXT,NEXT2


      DO I = 1,DIM
         LEVELUP(I) = 0
         MDORDER3(I) = 0
         NODE = MDORDER(I)
C
         J1 = ADJPOINT(NODE)
         J2 = ADJPOINT(NODE+1) - 1
         IF  ( J1 .LE. J2 )  THEN
            DO J = J1,J2
               NEXT = ADJLIST(J)
               NEXT = MDORDER2(NEXT)
               IF  ( NEXT .LT. I )  THEN
100                CONTINUE
                   IF  ( MDORDER3(NEXT) .EQ. I )  GOTO 110
                   IF  ( MDORDER3(NEXT) .GT. 0 )  THEN
                      NEXT2 = MDORDER3(NEXT)
                      MDORDER3(NEXT) = I
                      NEXT = NEXT2
                      GOTO 100
                   ENDIF
                   LEVELUP(NEXT) = I
                   MDORDER3(NEXT) = I
               ENDIF
110            CONTINUE
            ENDDO
         ENDIF
      ENDDO

      RETURN
      END

C
C-----------------------------------------------------------------------------
C
      SUBROUTINE ELTREE3 (DIM,LEVELUP,LEVELDOWN1,LEVELEQ)

      IMPLICIT NONE

	INTEGER DIM,LEVELUP(*),LEVELDOWN1(*),LEVELEQ(*),NODE,ROOT,NODE2

      DO NODE = 1,DIM
         LEVELDOWN1(NODE) = 0
         LEVELEQ(NODE) = 0
      ENDDO

      ROOT = DIM

      IF (DIM .LE. 1) RETURN
      DO NODE = DIM-1,1,-1
         NODE2 = LEVELUP(NODE)
         IF ((NODE2 .LE. 0) .OR. (NODE2 .EQ. NODE)) THEN
            LEVELEQ(ROOT) = NODE
            ROOT = NODE
         ELSE
            LEVELEQ(NODE) = LEVELDOWN1(NODE2)
            LEVELDOWN1(NODE2) = NODE
         ENDIF
      ENDDO

      LEVELEQ(ROOT) = 0

      RETURN
      END

C
C-----------------------------------------------------------------------------
C
      SUBROUTINE ELTREE4 (DIM,LEVELDOWN1,LEVELEQ,MDORDER3,LEVELUP,
     +                    MDORDER)

      IMPLICIT NONE

	INTEGER DIM,LEVELDOWN1(*),LEVELEQ(*),MDORDER3(*),LEVELUP(*),
     +        MDORDER(*),NODE,NODE2,NODE3,NODE4,II

      NODE4 = 0
      II = 0
      NODE = DIM

100   CONTINUE
      II = II + 1
      MDORDER(II) = NODE
      NODE = LEVELDOWN1(NODE)
      IF (NODE .GT. 0) GOTO 100

110   CONTINUE
      IF (II .LE. 0) GOTO 120
      NODE = MDORDER(II)
      II = II - 1
      NODE4 = NODE4 + 1
      MDORDER3(NODE) = NODE4

      NODE = LEVELEQ(NODE)
      IF (NODE .LE. 0) GOTO 110
      GOTO 100
C
120   CONTINUE

      DO NODE = 1,NODE4
         NODE3 = MDORDER3(NODE)
         NODE2 = LEVELUP(NODE)
         IF (NODE2 .GT. 0) NODE2 = MDORDER3(NODE2)
         LEVELEQ(NODE3) = NODE2
      ENDDO

      DO NODE3 = 1,NODE4
         LEVELUP(NODE3) = LEVELEQ(NODE3)
      ENDDO

      RETURN
      END

C
C-----------------------------------------------------------------------------
C
      SUBROUTINE ELTREE5 (DIM,LEVELUP,COLNNZ,LEVELDOWN1,LEVELEQ,
     +                    MDORDER3)

      IMPLICIT NONE

	INTEGER DIM,LEVELUP(*),LEVELEQ(*),COLNNZ(*),LEVELDOWN1(*),
     +        MDORDER3(*),NODE,NODE2,NODE3,NODE4


      DO NODE = 1,DIM
         LEVELDOWN1(NODE) = 0
         LEVELEQ(NODE) = 0
         MDORDER3(NODE) = 0
      ENDDO

      NODE4 = DIM

      DO NODE = DIM-1,1,-1
         NODE3 = LEVELUP(NODE)
         IF ((NODE3 .LE. 0) .OR. (NODE3 .EQ. NODE)) THEN
            LEVELEQ(NODE4) = NODE
            NODE4 = NODE
         ELSE
            NODE2 = MDORDER3(NODE3)
            IF (NODE2 .NE. 0) THEN
               IF (COLNNZ(NODE) .GE. COLNNZ(NODE2)) THEN
                  LEVELEQ(NODE) = LEVELDOWN1(NODE3)
                  LEVELDOWN1(NODE3) = NODE
               ELSE
                  LEVELEQ(NODE2) = NODE
                  MDORDER3(NODE3) = NODE
               ENDIF
            ELSE
               LEVELDOWN1(NODE3) = NODE
                MDORDER3(NODE3) = NODE
            ENDIF
         ENDIF
      ENDDO

      LEVELEQ(NODE4) = 0

      RETURN
      END

C
C-----------------------------------------------------------------------------
C
      SUBROUTINE ELTREE6 (DIM,LEVELDOWN1,LEVELEQ,MDORDER3,LEVELUP,
     +                    COLNNZ,MDORDER)

      IMPLICIT NONE

	INTEGER DIM,LEVELDOWN1(*),LEVELEQ(*),MDORDER3(*),LEVELUP(*),
     +        COLNNZ(*),MDORDER(*),NODE,NODE2,NODE3,NODE4,NODE5


      NODE4 = 0
      NODE5 = 0
      NODE = DIM
100   CONTINUE
      NODE5 = NODE5 + 1
      MDORDER(NODE5) = NODE
      NODE = LEVELDOWN1(NODE)
      IF (NODE .GT. 0) GOTO 100
110   CONTINUE
      IF (NODE5 .LE. 0) GOTO 120
      NODE = MDORDER(NODE5)
      NODE5 = NODE5 - 1
      NODE4 = NODE4 + 1
      MDORDER3(NODE) = NODE4
      NODE = LEVELEQ(NODE)
      IF (NODE .LE. 0) GOTO 110
      GOTO 100

120   CONTINUE

      DO NODE = 1,NODE4
         NODE3 = MDORDER3(NODE)
         NODE2 = LEVELUP(NODE)
         IF (NODE2 .GT. 0) NODE2 = MDORDER3(NODE2)
         LEVELEQ(NODE3) = NODE2
      ENDDO

      DO NODE3 = 1,NODE4
         LEVELUP(NODE3) = LEVELEQ(NODE3)
      ENDDO

      DO NODE = 1,NODE4
         NODE3 = MDORDER3(NODE)
         MDORDER(NODE3) = COLNNZ(NODE)
      ENDDO

      DO NODE = 1,NODE4
         COLNNZ(NODE) = MDORDER(NODE)
      ENDDO

      RETURN
      END

C
C-----------------------------------------------------------------------------
C
      SUBROUTINE FACTOR_NUM (DIM,ADJPOINT,ADJLIST,
     +                       RHS,MDORDER,MDORDER2,SUPN_NUM,SUPN_PART,
     +                       LADJPOINT,LADJLIST,LCOLPNT,SUPN_MEM,
     +                       SUPN_SPLIT,WSLENG,ADJFPOINT,ADJFLIST,IWS,
     +                       LVAL,RHSTEMP,FULLVAL,DWS,IERR)


C
C     INPUT:  DIM        (I;1) DIMENSION OF SYSTEM
C             ADJPOINT   (I;DIM+1) ==> FACTOR_SYMB
C             ADJLIST    (I;NNZ) ==> FACTOR_SYMB (NNZ=ADJPOINT(DIM+1)-1)
C             RHS        (D;DIM) RIGHT HAND SIDE OF LINEAR SYSTEM
C             MDORDER    |
C             MDORDER2   |
C             SUPN_NUM   |
C             SUPN_PART  |
C             LADJPOINT  |  OUTPUT FROM FACTOR_SYMB
C             LADJILST   |
C             LCOLPNT    |
C             SUPN_MEM   |
C             SUPN_SPLIT |
C             WSLENG     |
C
C     OUTPUT: RHS         SOLUTION. RHS IS OVERWRITTEN!
C             IERR
C     DUMMY:  FULLVAL

C AUFTEILUNG IWS: 1...DIM+1           ADJFPOINT
C                    +NNZ+DIM         ADJFLIST
C                    +2DIM+2SUPN_NUM  IWS
C                -------------------
C                 NNZ+4*DIM+2SUPN_NUM+1

C AUFTEILUNG DWS: 1...INDLENG           LVAL
C                    +DIM            RHSTEMP
C                    +NNZ+DIM        FULLVAL
C                    +WSLENG         DWS
C                -------------------
C                 NNZL+NNZ+2*DIM+WSLENG

	IMPLICIT NONE

	INTEGER          DIM,ADJPOINT(*),ADJLIST(*),MDORDER(*),
     +                 MDORDER2(*),SUPN_NUM,SUPN_PART(*),LADJPOINT(*),
     +                 LADJLIST(*),LCOLPNT(*),SUPN_MEM(*),SUPN_SPLIT(*),
     +                 WSLENG,ADJFPOINT(*),ADJFLIST(*),IWS(*),IERR,I
      DOUBLE PRECISION FULLVAL(*),LVAL(*),
     +                 RHSTEMP(*),DWS(*),RHS(*)




      CALL FILLVAL (ADJFPOINT,ADJFLIST,FULLVAL,MDORDER,MDORDER2,
     +              SUPN_NUM,SUPN_PART,LADJPOINT,LADJLIST,LCOLPNT,LVAL,
     +              IWS)


C IWS BRAUCHT 2*DIM+2*SUPN_NUM
C DWS BRAUCHT WSLENG; WSLENG EVTL. AUS PARAMETERLISTE RAUS!
      CALL NUMFCT2 (SUPN_NUM,SUPN_PART,SUPN_MEM,SUPN_SPLIT,LADJPOINT,
     +              LADJLIST,LCOLPNT,LVAL,IWS(1),IWS(SUPN_NUM+1),
     +              IWS(2*SUPN_NUM+1),IWS(2*SUPN_NUM+DIM+1),WSLENG,
     +              DWS,IERR)

	IF (IERR .NE. 0) RETURN

	DO I=1,DIM
	   RHSTEMP(I)=RHS(MDORDER(I))
	ENDDO

      CALL NUMSOLV (SUPN_NUM,SUPN_PART,LADJPOINT,LADJLIST,LCOLPNT,LVAL,
     +              RHSTEMP)
C RHS IS MODIFIED!!

	DO I=1,DIM
	   RHS(MDORDER(I))=RHSTEMP(I)
	ENDDO



	RETURN
	END

C
C-----------------------------------------------------------------------------
C
      SUBROUTINE FACTOR_SYMB (DIM,ADJPOINT,ADJLIST,MDORDER,MDORDER2,
     +                        SUPN_NUM,SUPN_MEM,SUPN_PART,LADJPOINT,
     +                        LADJLIST,LCOLPNT,IERR,WSLENG,SUPN_SPLIT,
     +                        ADJWORK,DEGKOPF,SUPNODSZ,TEMPLIST,
     +                        TEMPMARK,COLNNZ,IWS,NNZ,NNZSPACE,INDLENG,
     +                        NNZL)

C ROUTINE TO COMPUTE THE SYMBOLIC (CHOLESKY-)FACTORIZATION OF A POSITIVE
C DEFINITE MATRIX. A MINIMUM DEGREE PREORDERING ALGORITHM IS USED
C
C INPUT:  DIM         (I;1) DIMENSION OF LINEAR SYSTEM
C         ADJPOINT    (I;DIM+1) ADJPOINT(I) POINTS TO THE START OF THE
C                     ADJACENCY LIST OF NODE/VARIABLE I IN ADJLIST.
C                     ADJPOINT(DIM+1)-1 DENOTES THE END IN ADJLIST.
C         ADJLIST     (I;NNZ) ADJACENCY LISTS OF ALL NODES. LIST OF NODE I STARTS
C                     AT ADJPOINT(I) AND ENDS AT ADJPOINT(I+1)-1. ALL NEIGHBORS
C                     ALL LISTED IN THE NUMERICAL ORDER, I.E. SYMMETRY IS NOT
C                     USED HERE.
C         NNZ         (I;1) NUMBER OF NONZEROS (ADJACENCIES) IN THE MATRIX
C                     WITHOUT (!) DIAGONAL, BUT WITH (!) LOWER AND UPPER
C                     TRIANGLE.
C         NNZSPACE    RESERVED STORAGE FOR LADJLIST
C
C OUTPUT: (FOR USE IN NUMERICAL FACTORIZATION)
C         MDORDER     (I;DIM)
C         MDORDER2    (I;DIM)
C         SUPN_NUM    (I;1)
C         SUPN_MEM    (I;DIM)
C         SUPN_PART   (I;DIM+1)
C         LADJPOINT   (I;DIM+1)
C         LADJLIST    (I;NNZSPACE)
C         LCOLPNT     (I;DIM+1)
C         IERR        (I;1)
C         WSLENG      (I;1)
C         SUPN_SPLIT: (I;DIM)
C         NNZL        (I;1)         NUMBER OF NONZEROS INCL. DIAGONAL
C
C DUMMY:  ADJWORK     (I;NNZ)
C         DEGKOPF     (I;DIM)
C         SUPNODSZ    (I;DIM)
C         TEMPLIST    (I;DIM)
C         TEMPMARK    (I;DIM)
C         COLNNZ      (I;DIM)
C         IWS         (I;7*DIM+12)
C
C         TOGETHER ALL DUMMIES: NNZ+12*DIM+12
C

	IMPLICIT NONE

	INTEGER DIM,ADJPOINT(*),ADJLIST(*),MDORDER2(*),MDORDER(*),
     +        SUPN_NUM,SUPN_MEM(*),SUPN_PART(*),LADJPOINT(*),
     +        LADJLIST(*),LCOLPNT(*),IERR,WSLENG,SUPN_SPLIT(*),
     +        ADJWORK(*),DEGKOPF(*),SUPNODSZ(*),TEMPLIST(*),TEMPMARK(*),
     +        COLNNZ(*),IWS(*),NNZL,INDLENG,NNZ,I,NNZSPACE

      DO I=1,NNZ                    ! MINDEG DESTROYS ADJLIST
	   ADJWORK(I)=ADJLIST(I)
	ENDDO


C     IWS BRAUCHT 4*DIM
	CALL MINDEG (DIM,ADJPOINT,ADJWORK,MDORDER2,MDORDER,DEGKOPF,
     +             SUPNODSZ,TEMPLIST,TEMPMARK)

C      7*DIM+12 = NOETIGE LAENGE VON IWS!!!!
      CALL SYMBFCT1 (DIM,ADJPOINT,ADJLIST,MDORDER,MDORDER2,COLNNZ,
     +               NNZL,INDLENG,SUPN_NUM,SUPN_MEM,SUPN_PART,IWS)

C INDLENG IST DIE NOETIGE L�NGE VON LADJLIST. CHECKE HIER!!!!!!
C NNZL IST DIE NOETIGE LAENGE VON LVAL.


	IF (INDLENG .GT. NNZSPACE) THEN
C	   PRINT*,'NNZSPACE TOO SMALL (INDLENG)'
	   IERR= 3
	   RETURN
	ENDIF

      CALL SYMBFCT2 (DIM,ADJPOINT,ADJLIST,MDORDER,MDORDER2,COLNNZ,
     +               SUPN_NUM,SUPN_PART,SUPN_MEM,LADJPOINT,LADJLIST,
     +               LCOLPNT,
     +               IWS(1),IWS(SUPN_NUM+1),IWS(SUPN_NUM+DIM+2),IERR)


      IF (IERR .EQ. 4) RETURN

      CALL NUMFCT1 (DIM,SUPN_NUM,SUPN_PART,SUPN_MEM,LADJPOINT,LADJLIST,
     +              WSLENG,SUPN_SPLIT)

C WSLENG GIBT DIE LAENGE DES WORKING STORAGE IN NUMFCT2 AN

	RETURN
	END

C
C-----------------------------------------------------------------------------
C
      SUBROUTINE FCTSPLIT (DIM,SUPN_NUM,SUPN_PART,LADJPOINT,SUPN_SPLIT)

	IMPLICIT NONE

	INTEGER DIM,SUPN_NUM,SUPN_PART(*),SUPN_SPLIT(*),LADJPOINT(*),COL,
     +        COL2,SIZE,I,NODE,COL3,COLNUM,NEXT,DONE


      DO I = 1,DIM
         SUPN_SPLIT(I) = 0
      ENDDO

      DO NODE = 1,SUPN_NUM

         SIZE = LADJPOINT(NODE+1) - LADJPOINT(NODE)
         COL2 = SUPN_PART(NODE)
         COL3 = SUPN_PART(NODE+1) - 1
         NEXT = COL2
         COL = COL2 - 1
100      CONTINUE

         COL = COL+1
         IF (COL .LT. COL3) THEN
            COL = COL + 1
            COLNUM = 2
            DONE = 3*SIZE - 1
            SIZE = SIZE - 2
         ELSE
            COLNUM = 1
            DONE = 2 * SIZE
            SIZE = SIZE - 1
         ENDIF

110      CONTINUE
         IF ((DONE+SIZE .LE. 1999999999) .AND. (COL .LT. COL3)) THEN
            COL = COL + 1
            COLNUM = COLNUM + 1
            DONE = DONE + SIZE
            SIZE = SIZE - 1
            GOTO 110
         ENDIF

         SUPN_SPLIT(NEXT) = COLNUM
         NEXT = NEXT + 1
         IF (COL .LT. COL3) GOTO 100

      ENDDO

      RETURN
      END

C
C-----------------------------------------------------------------------------
C
      SUBROUTINE FCTSTOR (SUPN_NUM,SUPN_PART,SUPN_MEM,LADJPOINT,
     +                    LADJLIST,WSLENG)

	IMPLICIT NONE

	INTEGER SUPN_NUM,SUPN_PART(*),SUPN_MEM(*),LADJPOINT(*),
     +        LADJLIST(*),WSLENG,I,I1,I2,NODE,COLNUM,LENG,NODE2,NODE3,
     +        LENG2,BORDER,SIZE,WIDE


      WSLENG = 0
      DO NODE = SUPN_NUM,1,-1
         COLNUM = SUPN_PART(NODE+1) - SUPN_PART(NODE)
         I1 = LADJPOINT(NODE) + COLNUM
         I2 = LADJPOINT(NODE+1) - 1
         LENG = I2 - I1 + 1
         BORDER = LENG*(LENG+1)/2
         IF (BORDER .GT. WSLENG) THEN
            NODE2 = SUPN_MEM(LADJLIST(I1))
            LENG2 = LADJPOINT(NODE2+1) - LADJPOINT(NODE2)
            WIDE = 0
            DO I = I1,I2
               NODE3 = SUPN_MEM(LADJLIST(I))
               IF (NODE3 .EQ. NODE2) THEN
                  WIDE = WIDE + 1
                  IF (I .EQ. I2) THEN
                     IF (LENG2 .GT. LENG) THEN
                        SIZE = (LENG*WIDE) - ((WIDE-1)*WIDE/2)
                        WSLENG = MAX(SIZE,WSLENG)
                     ENDIF
                  ENDIF
               ELSE
                  IF (LENG2 .GT. LENG) THEN
                     SIZE = (LENG*WIDE) - ((WIDE-1)*WIDE/2)
                     WSLENG = MAX(SIZE,WSLENG)
                   ENDIF
                   LENG = LENG - WIDE
                   BORDER = LENG * (LENG + 1) / 2
                   IF (BORDER .LE. WSLENG) GOTO 100
                   WIDE = 1
                   NODE2 = NODE3
                   LENG2 = LADJPOINT(NODE2+1) - LADJPOINT(NODE2)
                ENDIF
            ENDDO
         ENDIF
100      CONTINUE
      ENDDO

      RETURN
      END

C
C-----------------------------------------------------------------------------
C
      SUBROUTINE FILLCNT (DIM,ADJPOINT,ADJLIST,MDORDER,MDORDER2,LEVELUP,
     +                    SUPN_MEM,COLNNZ,NNZL,SUBTREE,PRSUBTREE,
     +                    SUPN_PART,COLWEIGHT,LOWDES,SONCOUNT,NBRLOW)


      IMPLICIT NONE

	INTEGER DIM,ADJPOINT(*),ADJLIST(*),MDORDER(*),MDORDER2(*),
     +        LEVELUP(*),SUPN_MEM(*),COLNNZ(*),NNZL,SUBTREE(*),
     +        PRSUBTREE(*),SUPN_PART(0:*),COLWEIGHT(0:*),LOWDES(0:*),
     +        SONCOUNT(0:*),NBRLOW(*),ILOWDES,K,J,J1,J2,PAPA,NBR1,NBR2,
     +        NBR3,LEAF1,LL1,LL2,LL3,TEMP,NODE,LF


C     INITIALIZATION

      SUPN_PART(0) = 0
      DO K = DIM,1,-1
         SUPN_MEM(K) = 1
         COLNNZ(K) = 0
         SUBTREE(K) = K
         PRSUBTREE(K) = 0
         SUPN_PART(K) = SUPN_PART(LEVELUP(K)) + 1
         COLWEIGHT(K) = 1
         LOWDES(K) = K
         SONCOUNT(K) = 0
         NBRLOW(K) = 0
      ENDDO

      SONCOUNT(0) = 0
      LOWDES(0) = 0
      DO K = 1,DIM
         PAPA = LEVELUP(K)
         COLWEIGHT(PAPA) = 0
         SONCOUNT(PAPA) = SONCOUNT(PAPA) + 1
         ILOWDES = LOWDES(K)
         IF (ILOWDES .LT. LOWDES(PAPA)) THEN
            LOWDES(PAPA) = ILOWDES
         ENDIF
      ENDDO

C FUER JEDEN LOWER NACHBAR NBR1:
      DO NBR1 = 1, DIM
         LF = 0
         ILOWDES = LOWDES(NBR1)
         NBR2 = MDORDER(NBR1)
         J1 = ADJPOINT(NBR2)
         J2 = ADJPOINT(NBR2+1) - 1

C        FUER JEDEN HOEHEREN NACHBARN NBR3 VON NBR1:
         DO J = J1,J2
            NBR3 = MDORDER2(ADJLIST(J))
            IF (NBR3 .GT. NBR1) THEN
               IF (ILOWDES .GT. NBRLOW(NBR3)) THEN
                  COLWEIGHT(NBR1) = COLWEIGHT(NBR1) + 1
                  LEAF1 = PRSUBTREE(NBR3)
                     IF (LEAF1 .EQ. 0) THEN
                        SUPN_MEM(NBR3) = SUPN_MEM(NBR3) +
     +                               SUPN_PART(NBR1) - SUPN_PART(NBR3)
                     ELSE
                        LL1 = LEAF1
                        LL2 = SUBTREE(LL1)
                        LL3 = SUBTREE(LL2)
100                     CONTINUE
                        IF (LL3 .NE. LL2) THEN
                           SUBTREE(LL1) = LL3
                           LL1 = LL3
                           LL2 = SUBTREE(LL1)
                           LL3 = SUBTREE(LL2)
                           GOTO 100
                        ENDIF
                        SUPN_MEM(NBR3) = SUPN_MEM(NBR3)
     +                            + SUPN_PART(NBR1) - SUPN_PART(LL3)
                        COLWEIGHT(LL3) = COLWEIGHT(LL3) - 1
                    ENDIF
                    PRSUBTREE(NBR3) = NBR1
                    LF = 1
                ENDIF
                NBRLOW(NBR3) = NBR1
            ENDIF
         ENDDO
         PAPA = LEVELUP(NBR1)
         COLWEIGHT(PAPA) = COLWEIGHT(PAPA) - 1
         IF ((LF .EQ. 1) .OR. (SONCOUNT(NBR1) .GE. 2)) THEN
            NODE = NBR1
         ENDIF
         SUBTREE(NODE) = PAPA
      ENDDO

      NNZL = 0
      DO K = 1,DIM
         TEMP = COLNNZ(K) + COLWEIGHT(K)
         COLNNZ(K) = TEMP
         NNZL = NNZL + TEMP
         PAPA = LEVELUP(K)
         IF (PAPA .NE. 0) THEN
            COLNNZ(PAPA) = COLNNZ(PAPA) + TEMP
         ENDIF
      ENDDO

      RETURN
      END

C
C-----------------------------------------------------------------------------
C
      SUBROUTINE FILLVAL (ADJFPOINT,ADJFLIST,FULLVAL,MDORDER,MDORDER2,
     +                    SUPN_NUM,SUPN_PART,LADJPOINT,LADJLIST,LCOLPNT,
     +                    LVAL,IWS)

	IMPLICIT NONE

	INTEGER          ADJFPOINT(*),ADJFLIST(*),MDORDER(*),MDORDER2(*),
     +                 SUPN_NUM,SUPN_PART(*),LADJPOINT(*),LADJLIST(*),
     +                 LCOLPNT(*),IWS(*),I,J,LENG,I2,J2,I3,J3
	DOUBLE PRECISION FULLVAL(*),LVAL(*)


      DO J2 = 1,SUPN_NUM
         LENG = LADJPOINT(J2+1) - LADJPOINT(J2)
         DO I2 = LADJPOINT(J2),LADJPOINT(J2+1)-1
            I = LADJLIST(I2)
            LENG = LENG-1
            IWS(I) = LENG
         ENDDO

         DO  J = SUPN_PART(J2),SUPN_PART(J2+1)-1
            DO I2 = LCOLPNT(J),LCOLPNT(J+1)-1
               LVAL(I2) = 0.0
            ENDDO

            J3 = MDORDER(J)
            I3 = LCOLPNT(J+1)-1
            DO I2 = ADJFPOINT(J3),ADJFPOINT(J3+1)-1
               I = MDORDER2(ADJFLIST(I2))
               IF (I .GE. J) THEN
                  LVAL(I3-IWS(I)) = FULLVAL(I2)
               ENDIF
            ENDDO
         ENDDO
      ENDDO

      RETURN
      END

C
C-----------------------------------------------------------------------------
C
      SUBROUTINE INDJOIN (ROWS,COLS,BUPD,SUPN_DIST2,LCOLPNT,LVAL,
     +                    COLLENG)

	IMPLICIT NONE

	INTEGER          ROWS,COLS,COLLENG,LCOLPNT(*),SUPN_DIST2(*),COL,
     +                 COMP1,I,COMP2,GAMMA,COL2,DELTA
	DOUBLE PRECISION LVAL(*),BUPD(*)


      DELTA = 0
      DO COL = 1,COLS
         COL2 = COLLENG - SUPN_DIST2(COL)
         GAMMA = LCOLPNT(COL2+1) - 1
         DO I = COL,ROWS
            COMP1 = GAMMA - SUPN_DIST2(I)
            COMP2 = DELTA + I
            LVAL(COMP1) = LVAL(COMP1) + BUPD(COMP2)
            BUPD(COMP2) = 0.D0
         ENDDO
         DELTA = COMP2 - COL
      ENDDO

      RETURN
      END

C
C-----------------------------------------------------------------------------
C
      SUBROUTINE INVORDER (DIM,MDORDER2,MDORDER3,MDORDER)

      IMPLICIT NONE

	INTEGER DIM,MDORDER2(*),MDORDER3(*),MDORDER(*),I,NODE,ITEMP

      DO I = 1,DIM
         ITEMP = MDORDER2(I)
         MDORDER2(I) = MDORDER3(ITEMP)
      ENDDO

      DO I = 1,DIM
         NODE = MDORDER2(I)
         MDORDER(NODE) = I
      ENDDO

      RETURN
      END

C
C-----------------------------------------------------------------------------
C
      SUBROUTINE LOADVEC (LENG,LADJLIST,SUPN_DIST)

	IMPLICIT NONE

	INTEGER LENG,LADJLIST(*),SUPN_DIST(*),LENGTH,I,NODE

      LENGTH = LENG
      DO I = 1,LENG
          NODE = LADJLIST(I)
          LENGTH = LENGTH - 1
          SUPN_DIST(NODE) = LENGTH
      ENDDO

      RETURN
      END

C
C-----------------------------------------------------------------------------
C
      SUBROUTINE MATMAT1 (ROWS,COLS,COLS2,SUPN_SPLIT,LCOLPNT,X,Y,LENGTH)

C MATRIX-MATRIX-MULTIPLY WITH SPECIAL DATA STRUCTURES

      IMPLICIT NONE

	INTEGER          ROWS,COLS,COLS2,SUPN_SPLIT(*),LCOLPNT(*),LENGTH,
     +                 INEXT,COL3,NEXT
	DOUBLE PRECISION X(*),Y(*)

      INEXT = 1
      COL3 = 1
100   CONTINUE
      IF (COL3 .LE. COLS) THEN
         NEXT = SUPN_SPLIT(INEXT)
         CALL MATMAT3 (ROWS,NEXT,COLS2,LCOLPNT(COL3),X,Y,LENGTH)
         COL3 = COL3 + NEXT
         INEXT = INEXT + 1
         GOTO 100
      ENDIF

      RETURN
      END

C
C-----------------------------------------------------------------------------
C
      SUBROUTINE MATMAT2 (ROWS,COLS,NEXTPTR,X,COLPTR,Y,INDIC)

C SPECIAL MATRIX-MATRIX-MULTIPLY, USING SPECIAL DATA STRUCTURES

      IMPLICIT NONE

	INTEGER          ROWS,COLS,NEXTPTR(*),COLPTR(*),INDIC(*),I,K,
     +                 NEXTCOL,LAST,NODE
	DOUBLE PRECISION X(*),Y(*),DUM


      DO K = 1,COLS
         NEXTCOL = NEXTPTR(K)
         LAST = COLPTR(NEXTCOL+1) - 1
         DUM = - X(K)
         DO I = K,ROWS
            NODE = NEXTPTR(I)
            NODE = LAST - INDIC(NODE)
            Y(NODE) = Y(NODE) + DUM*X(I)
         ENDDO
      ENDDO

      RETURN
      END

C
C-----------------------------------------------------------------------------
C
      SUBROUTINE MATMAT3 (ROWS,COLS,COLS2,LCOLPNT,X,Y,LENGTH)

C MATRIX-MATRIX-MULTIPLY FOR SPECIAL DATA STRUCTURES

      IMPLICIT NONE

	INTEGER          ROWS,COLS,COLS2,LCOLPNT(*),LENGTH,II,IJ,LAST,BEG,
     +                 FIN,LENG,ROWS2,COL,COL2
	DOUBLE PRECISION X(*),Y(*),DUM


      ROWS2 = ROWS
      LAST = 0
      LENG = LENGTH

      DO COL2 = 1,COLS2
         BEG = LAST + 1
         FIN = BEG + ROWS2 - 1
         LAST = LAST + LENG
         DO COL = 1,COLS
            II = LCOLPNT(COL+1) - ROWS2
            DUM  = - X(II)
            DO IJ = BEG,FIN
               Y(IJ) = Y(IJ) + DUM * X(II)
               II = II + 1
            ENDDO
         ENDDO
         ROWS2 = ROWS2 - 1
         LENG = LENG - 1
      ENDDO

      RETURN
      END

C
C-----------------------------------------------------------------------------
C
      SUBROUTINE MATVEC (ROWS,COLS,LVAL2,LCOLPNT,LVAL)

C MATRIX-VECTOR-MULTIPLY WITH SPECIAL DATA STRUCTURES

      IMPLICIT NONE

	INTEGER          ROWS,COLS,LCOLPNT(*),I,J,J2
	DOUBLE PRECISION LVAL2(*),LVAL(*),DUM


      DO J = 1, COLS
         J2 = LCOLPNT(J+1) - ROWS
         DUM  = - LVAL(J2)
         DO I = 1,ROWS
            LVAL2(I) = LVAL2(I) + DUM*LVAL(J2)
            J2 = J2 + 1
         ENDDO
      ENDDO

      RETURN
      END

C
C-----------------------------------------------------------------------------
C
      SUBROUTINE MINDEG (DIM,ADJPOINT,ADJLIST,MDORDER2,MDORDER,
     +                   DEGKOPF,SUPNODSZ,TEMPLIST,TEMPMARK)

C
C     MINIMUM DEGREE ORDERING
C
C     INPUT:  DIM:           DIMENSION OF LINEAR SYSTEM
C             ADJPOINT:      POINTER FOR BEGIN OF NODE IN LIST ADJLIST
C             ADJLIST:       LIST OF NEIGHBORS. ADJPOINT POINTS TO THE
C                            BEGINNING OF THE CURRENT NODE. SYMMETRY IS
C                            NOT USED!
C     OUTPUT: MDORDER(DIM):  CONTAINS NODE PERMUTATION SUBJECT TO MINIMUM DEGREE
C                 TAKE CARE: ADJLIST IS OVERWRITTEN!!!
C             MDORDER2(DIM): INVERSE OF MDORDER
C
C     DEGKOPF: KOPF DER DEGREE-LISTEN
C     SUPNODSZ: GROESSE DER SUPERNODES
C     TEMPLIST: TEMP. VERKETTETE LISTE
C     TEMPMARK: TEMP. MARKIERENDER VEKTOR
C     ALLE GROESSE DIM
C


      IMPLICIT NONE

      INTEGER DIM,ADJPOINT(*),ADJLIST(*),MDORDER(*),MDORDER2(*),
     +        DEGKOPF(*),SUPNODSZ(*),TEMPLIST(*),TEMPMARK(*),INTSUP,
     +        ORDNOD,MDFOLLOW,ACTNOD,XXT,DEGMIN,ELNODSTART,DEGLIM,I

      INTSUP = 32767

      CALL MINDEG_INT (DIM,ADJPOINT,DEGKOPF,MDORDER2,MDORDER,
     +                  SUPNODSZ,TEMPLIST,TEMPMARK)

      ORDNOD = 1

C     STREICHE ISOLIERTE KNOTEN

      MDFOLLOW = DEGKOPF(1)
100   CONTINUE
      IF (MDFOLLOW .LE. 0) GOTO 110
         ACTNOD = MDFOLLOW
         MDFOLLOW = MDORDER2(ACTNOD)
         TEMPMARK(ACTNOD) = INTSUP
         MDORDER2(ACTNOD) = - ORDNOD
         ORDNOD = ORDNOD + 1
         GOTO 100
C
110   CONTINUE

C     SUCHE KNOTEN MIT MINIMUM DEGREE (DEGMIN); XXT FACILITATES
C     MARKIERENDE KNOTEN

      IF (ORDNOD .GT. DIM) GOTO 180
      XXT = 1
      DEGKOPF(1) = 0
      DEGMIN = 2
120   CONTINUE
      IF (DEGKOPF(DEGMIN) .GT. 0) GOTO 130
      DEGMIN = DEGMIN + 1
      GOTO 120
130   CONTINUE
      DEGLIM = DEGMIN
      ELNODSTART = 0

140   CONTINUE
      ACTNOD = DEGKOPF(DEGMIN)
      IF (ACTNOD .GT. 0) GOTO 150
      DEGMIN = DEGMIN + 1
      IF (DEGMIN .GT. DEGLIM) GOTO 170
      GOTO 140
150   CONTINUE

      MDFOLLOW = MDORDER2(ACTNOD)
      DEGKOPF(DEGMIN) = MDFOLLOW
      IF (MDFOLLOW .GT. 0) MDORDER(MDFOLLOW) = - DEGMIN
      MDORDER2(ACTNOD) = - ORDNOD
      IF (ORDNOD+SUPNODSZ(ACTNOD) .GT. DIM) GOTO 180

      XXT = XXT + 1
      IF (XXT .LT. INTSUP) GOTO 160
      XXT = 1
      DO I=1,DIM
         IF (TEMPMARK(I) .LT. INTSUP) TEMPMARK(I) = 0
      ENDDO

160   CONTINUE

      CALL MINDEG_ELIM (ACTNOD,ADJPOINT,ADJLIST,DEGKOPF,MDORDER2,
     +                  MDORDER,SUPNODSZ,TEMPLIST,TEMPMARK,INTSUP,
     +                  XXT)

      ORDNOD = ORDNOD + SUPNODSZ(ACTNOD)
      TEMPLIST(ACTNOD) = ELNODSTART
      ELNODSTART = ACTNOD
      GOTO 140
170   CONTINUE

      IF (ORDNOD .GT. DIM) GOTO 180
      CALL MINDEG_UPD (ELNODSTART,DIM,ADJPOINT,ADJLIST,DEGMIN,DEGKOPF,
     +                 MDORDER2,MDORDER,SUPNODSZ,TEMPLIST,TEMPMARK,
     +                 INTSUP, XXT )

      GOTO 120

180   CONTINUE

      CALL MINDEG_ORD (DIM,MDORDER,MDORDER2,SUPNODSZ)

      RETURN
      END

C
C-----------------------------------------------------------------------------
C
      SUBROUTINE MINDEG_ELIM (ACTNOD,ADJPOINT,ADJLIST,DEGKOPF,MDORDER2,
     +                        MDORDER,SUPNODSZ,TEMPLIST,TEMPMARK,INTSUP,
     +                        XXT)

      IMPLICIT NONE

      INTEGER ADJPOINT(*),ADJLIST(*),MDORDER(*),MDORDER2(*),
     +        DEGKOPF(*),SUPNODSZ(*),TEMPLIST(*),TEMPMARK(*),INTSUP,
     +        ACTNOD,XXT,I1,I2,J1,J2,NODE,I,J,ELNEXT,NODNEXT,NODLAST,
     +        NEIGHBOR,LINK,REACH,NEXT,PREV,QNEIGHB,NQNEIGHB,MINPREV


      TEMPMARK(ACTNOD) = XXT
      I1 = ADJPOINT(ACTNOD)
      I2 = ADJPOINT(ACTNOD+1) - 1

      ELNEXT = 0
      NODNEXT = I1
      NODLAST = I2
      DO I = I1,I2
         NEIGHBOR = ADJLIST(I)
         IF (NEIGHBOR .EQ. 0) GOTO 120
         IF (TEMPMARK(NEIGHBOR) .GE. XXT) GOTO 110
         TEMPMARK(NEIGHBOR) = XXT
         IF (MDORDER2(NEIGHBOR) .LT. 0) GOTO 100
         ADJLIST(NODNEXT) = NEIGHBOR
         NODNEXT = NODNEXT + 1
         GOTO 110
100      CONTINUE
         TEMPLIST(NEIGHBOR) = ELNEXT
         ELNEXT = NEIGHBOR
110      CONTINUE
      ENDDO

120   CONTINUE

      IF (ELNEXT .LE. 0) GOTO 190
      ADJLIST(NODLAST) = - ELNEXT
      LINK = ELNEXT
130   CONTINUE
      J1 = ADJPOINT(LINK)
      J2 = ADJPOINT(LINK+1) - 1
      DO J = J1,J2
         NODE = ADJLIST(J)
         LINK = - NODE
         IF (NODE) 130,180,140
140      CONTINUE
         IF ((TEMPMARK(NODE) .GE. XXT) .OR. (MDORDER2(NODE) .LT. 0))
     +      GOTO 170
         TEMPMARK(NODE) = XXT

150      CONTINUE
         IF (NODNEXT .LT. NODLAST) GOTO 160
         LINK = - ADJLIST(NODLAST)
         NODNEXT = ADJPOINT(LINK)
         NODLAST = ADJPOINT(LINK+1) - 1
         GOTO 150
160      CONTINUE
         ADJLIST(NODNEXT) = NODE
         NODNEXT = NODNEXT + 1
170      CONTINUE
      ENDDO

180   CONTINUE
      ELNEXT = TEMPLIST(ELNEXT)
      GOTO 120
190   CONTINUE
      IF (NODNEXT .LE. NODLAST) ADJLIST(NODNEXT) = 0

      LINK = ACTNOD
200   CONTINUE
      I1 = ADJPOINT(LINK)
      I2 = ADJPOINT(LINK+1) - 1

      DO I = I1,I2
         REACH = ADJLIST(I)
         LINK = - REACH
         IF (REACH) 200,270,210
210      CONTINUE

         PREV = MDORDER(REACH)
         IF  ((PREV .EQ. 0) .OR. (PREV .EQ. (-INTSUP))) GOTO 220

         NEXT = MDORDER2(REACH)
         IF (NEXT .GT. 0) MDORDER(NEXT) = PREV
         IF (PREV .GT. 0) MDORDER2(PREV) = NEXT
         MINPREV = - PREV
         IF (PREV .LT. 0) DEGKOPF(MINPREV) = NEXT
220      CONTINUE

         J1 = ADJPOINT(REACH)
         J2 = ADJPOINT(REACH+1) - 1
         QNEIGHB = J1
         DO J = J1,J2
            NEIGHBOR = ADJLIST(J)
            IF (NEIGHBOR .EQ. 0) GOTO 240
            IF (TEMPMARK(NEIGHBOR) .GE. XXT) GOTO 230
            ADJLIST(QNEIGHB) = NEIGHBOR
            QNEIGHB = QNEIGHB + 1
230         CONTINUE
         ENDDO
240      CONTINUE

         NQNEIGHB = QNEIGHB - J1
         IF (NQNEIGHB .GT. 0) GOTO 250

         SUPNODSZ(ACTNOD) = SUPNODSZ(ACTNOD) + SUPNODSZ(REACH)
         SUPNODSZ(REACH) = 0
         TEMPMARK(REACH) = INTSUP
         MDORDER2(REACH) = - ACTNOD
         MDORDER(REACH) = - INTSUP
         GOTO 260
250      CONTINUE

         MDORDER2(REACH) = NQNEIGHB + 1
         MDORDER(REACH) = 0
         ADJLIST(QNEIGHB) = ACTNOD
         QNEIGHB = QNEIGHB + 1
         IF (QNEIGHB .LE. J2) ADJLIST(QNEIGHB) = 0
C
260      CONTINUE
      ENDDO

270   CONTINUE

      RETURN
      END

C
C-----------------------------------------------------------------------------
C
      SUBROUTINE MINDEG_INT (DIM,ADJPOINT,DEGKOPF,MDORDER2,
     +                       MDORDER,SUPNODSZ,TEMPLIST,TEMPMARK)

C     PREPARES MINIMUM DEGREE ROUTINE

      IMPLICIT NONE

      INTEGER DIM,ADJPOINT(*),MDORDER(*),MDORDER2(*),
     +        DEGKOPF(*),SUPNODSZ(*),TEMPLIST(*),TEMPMARK(*),NODE,
     +        NODE2,DEGREE

      DO NODE = 1,DIM
         DEGKOPF(NODE) = 0
         SUPNODSZ(NODE) = 1
         TEMPMARK(NODE) = 0
         TEMPLIST(NODE) = 0
      ENDDO

C     PREPARE TWICE LINKED LISTS
      DO NODE = 1,DIM
         DEGREE = ADJPOINT(NODE+1) - ADJPOINT(NODE) + 1
         NODE2 = DEGKOPF(DEGREE)
         MDORDER2(NODE) = NODE2
         DEGKOPF(DEGREE) = NODE
         IF (NODE2 .GT. 0) MDORDER(NODE2) = NODE
         MDORDER(NODE) = - DEGREE
      ENDDO

      RETURN
      END

C
C-----------------------------------------------------------------------------
C
      SUBROUTINE MINDEG_ORD (DIM,MDORDER,MDORDER2,SUPNODSZ)

      IMPLICIT NONE

      INTEGER DIM,MDORDER(*),MDORDER2(*),SUPNODSZ(*),NODE,ABOVE,ROOT,
     +        SIZE,ROOT2,ABOVE2

      DO NODE = 1, DIM
         SIZE = SUPNODSZ(NODE)
         IF (SIZE .LE. 0) MDORDER(NODE) = MDORDER2(NODE)
         IF (SIZE .GT. 0) MDORDER(NODE) = - MDORDER2(NODE)
      ENDDO

      DO NODE = 1, DIM
         IF (MDORDER(NODE) .GT. 0)  GOTO 130

         ABOVE = NODE
100      CONTINUE
         IF (MDORDER(ABOVE) .GT. 0) GOTO 110
         ABOVE = - MDORDER(ABOVE)
         GOTO 100
110      CONTINUE

         ROOT = ABOVE
         ROOT2 = MDORDER(ROOT) + 1
         MDORDER2(NODE) = - ROOT2
         MDORDER(ROOT) = ROOT2

         ABOVE = NODE
120      CONTINUE
         ABOVE2 = - MDORDER(ABOVE)
         IF (ABOVE2 .LE. 0) GOTO 130
         MDORDER(ABOVE) = - ROOT
         ABOVE = ABOVE2
         GOTO 120
130      CONTINUE
      ENDDO

      DO NODE = 1, DIM
         ROOT2 = - MDORDER2(NODE)
         MDORDER2(NODE) = ROOT2
         MDORDER(ROOT2) = NODE
      ENDDO

      RETURN
      END

C
C-----------------------------------------------------------------------------
C
      SUBROUTINE MINDEG_UPD (ELNODSTART,DIM,ADJPOINT,ADJLIST,
     +                       DEGMIN,DEGKOPF,MDORDER2,MDORDER,SUPNODSZ,
     +                       TEMPLIST,TEMPMARK,INTSUP,XXT)

      IMPLICIT NONE

      INTEGER DIM,ADJPOINT(*),ADJLIST(*),MDORDER(*),MDORDER2(*),
     +        DEGKOPF(*),SUPNODSZ(*),TEMPLIST(*),TEMPMARK(*),INTSUP,
     +        XXT,DEGMIN,ELNODSTART,NODE2,I1,I2,J1,J2,ELNEXT,I,J,
     +        NEIGHBOR,DEGREE,DEGREE0,MINDEG,NODE,LINK,NODE3,II2,
     +        XXT2,TOP2,TOP3


      MINDEG = DEGMIN
      ELNEXT = ELNODSTART
100   CONTINUE

      IF (ELNEXT .LE. 0) RETURN
      XXT2 = XXT + MINDEG
      IF (XXT2 .LT. INTSUP) GOTO 110
      XXT = 1
      DO I = 1,DIM
         IF (TEMPMARK(I) .LT. INTSUP) TEMPMARK(I) = 0
      ENDDO

      XXT2 = XXT + MINDEG
110   CONTINUE

      TOP2 = 0
      TOP3 = 0
      DEGREE0 = 0
      LINK = ELNEXT
120   CONTINUE
      I1 = ADJPOINT(LINK)
      I2 = ADJPOINT(LINK+1) - 1
      DO I = I1,I2
         NODE3 = ADJLIST(I)
         LINK = - NODE3
         IF (NODE3) 120,160,130

130      CONTINUE
         IF (SUPNODSZ(NODE3) .EQ. 0) GOTO 150
         DEGREE0 = DEGREE0 + SUPNODSZ(NODE3)
         TEMPMARK(NODE3) = XXT2

         IF (MDORDER(NODE3) .NE. 0) GOTO 150

         IF (MDORDER2(NODE3) .EQ. 2) GOTO 140
         TEMPLIST(NODE3) = TOP3
         TOP3 = NODE3
         GOTO 150
140      CONTINUE
         TEMPLIST(NODE3) = TOP2
         TOP2 = NODE3
150      CONTINUE
      ENDDO

160   CONTINUE

      NODE3 = TOP2
      II2 = 1
170   CONTINUE
      IF (NODE3 .LE. 0) GOTO 230
      IF (MDORDER(NODE3) .NE. 0) GOTO 300
      XXT = XXT + 1
      DEGREE = DEGREE0

      I1 = ADJPOINT(NODE3)
      NEIGHBOR = ADJLIST(I1)
      IF (NEIGHBOR .EQ. ELNEXT) NEIGHBOR = ADJLIST(I1+1)

      LINK = NEIGHBOR
      IF (MDORDER2(NEIGHBOR) .LT. 0) GOTO 180
      DEGREE = DEGREE + SUPNODSZ(NEIGHBOR)
      GOTO 290
180   CONTINUE

      I1 = ADJPOINT(LINK)
      I2 = ADJPOINT(LINK+1) - 1
      DO I = I1,I2
         NODE = ADJLIST(I)
         LINK = - NODE
         IF (NODE .EQ. NODE3) GOTO 220
         IF (NODE) 180,290,190

190      CONTINUE
         IF (SUPNODSZ(NODE) .EQ. 0) GOTO 220
         IF (TEMPMARK(NODE) .GE. XXT) GOTO 200

         TEMPMARK(NODE) = XXT
         DEGREE = DEGREE + SUPNODSZ(NODE)
         GOTO 220
200      CONTINUE

         IF (MDORDER(NODE) .NE. 0) GOTO 220
         IF (MDORDER2(NODE) .NE. 2) GOTO 210
         SUPNODSZ(NODE3) = SUPNODSZ(NODE3) + SUPNODSZ(NODE)
         SUPNODSZ(NODE) = 0
         TEMPMARK(NODE) = INTSUP
         MDORDER2(NODE) = - NODE3
         MDORDER(NODE) = - INTSUP
         GOTO 220
210      CONTINUE

         IF (MDORDER(NODE) .EQ. 0) MDORDER(NODE) = - INTSUP
220      CONTINUE
      ENDDO

      GOTO 290
230   CONTINUE

      NODE3 = TOP3
      II2 = 0
240   CONTINUE
      IF (NODE3 .LE. 0) GOTO 310
      IF (MDORDER(NODE3) .NE. 0) GOTO 300
      XXT = XXT + 1
      DEGREE = DEGREE0

      I1 = ADJPOINT(NODE3)
      I2 = ADJPOINT(NODE3+1) - 1
      DO I = I1, I2
         NEIGHBOR = ADJLIST(I)
         IF (NEIGHBOR .EQ. 0) GOTO 290
         IF (TEMPMARK(NEIGHBOR) .GE. XXT) GOTO 280
         TEMPMARK(NEIGHBOR) = XXT
         LINK = NEIGHBOR

         IF (MDORDER2(NEIGHBOR) .LT. 0) GOTO 250
         DEGREE = DEGREE + SUPNODSZ(NEIGHBOR)
         GOTO 280
250      CONTINUE

         J1 = ADJPOINT(LINK)
         J2 = ADJPOINT(LINK+1) - 1
         DO J = J1, J2
            NODE = ADJLIST(J)
            LINK = - NODE
            IF (NODE) 250,280,260

260         CONTINUE
            IF (TEMPMARK(NODE) .GE. XXT) GOTO 270
            TEMPMARK(NODE) = XXT
            DEGREE = DEGREE + SUPNODSZ(NODE)
270         CONTINUE
         ENDDO
280      CONTINUE
      ENDDO

290   CONTINUE

      DEGREE = DEGREE - SUPNODSZ(NODE3) + 1
      NODE2 = DEGKOPF(DEGREE)
      MDORDER2(NODE3) = NODE2
      MDORDER(NODE3) = - DEGREE
      IF (NODE2 .GT. 0) MDORDER(NODE2) = NODE3
      DEGKOPF(DEGREE) = NODE3
      IF (DEGREE .LT. DEGMIN) DEGMIN = DEGREE
300   CONTINUE

      NODE3 = TEMPLIST(NODE3)
      IF (II2 .EQ. 1) GOTO 170
      GOTO 240
310   CONTINUE

      XXT = XXT2
      ELNEXT = TEMPLIST(ELNEXT)
      GOTO 100

      RETURN
      END

C
C-----------------------------------------------------------------------------
C
      SUBROUTINE NUMFCT1 (DIM,SUPN_NUM,SUPN_PART,SUPN_MEM,LADJPOINT,
     +                    LADJLIST,WSLENG,SUPN_SPLIT)

	IMPLICIT NONE

	INTEGER DIM,SUPN_NUM,SUPN_PART(*),SUPN_MEM(*),LADJPOINT(*),
     +        LADJLIST(*),WSLENG,SUPN_SPLIT(*)


      CALL FCTSTOR (SUPN_NUM,SUPN_PART,SUPN_MEM,LADJPOINT,LADJLIST,
     +              WSLENG)

      CALL FCTSPLIT (DIM,SUPN_NUM,SUPN_PART,LADJPOINT,SUPN_SPLIT)

      RETURN
      END

C
C-----------------------------------------------------------------------------
C
      SUBROUTINE NUMFCT2 (SUPN_NUM,SUPN_PART,SUPN_MEM,SUPN_SPLIT,
     +                    LADJPOINT,LADJLIST,LCOLPNT,LVAL,SUPN_LINK,
     +                    SUPN_LENG,SUPN_DIST,SUPN_DIST2,WSLENG,DWS,
     +                    IERR)

C NUMERICAL FACTORIZATION
C
C IERR: 0: O.K.
C      -2: WSLENG TOO SMALL
C

	IMPLICIT NONE

	INTEGER          SUPN_NUM,SUPN_PART(*),SUPN_MEM(*),SUPN_SPLIT(*),
     +                 LADJPOINT(*),LADJLIST(*),LCOLPNT(*),SUPN_LINK(*),
     +                 SUPN_LENG(*),SUPN_DIST(*),SUPN_DIST2(*),WSLENG,
     +                 IERR,I,COLBEG,COLBEG2,COLLENG3,COLPTR3,COLLENG4,
     +                 COLLENG,COLPTR2,NODE,NNZPTR,COLBEG3,COLEND3,J,
     +                 COLLENG2,COLPTR,NODE2,NNZPTR2,COLEND,COLNUMUPD,
     +                 COLNUM,COLNUM2,NODE3,COLUMN,NODE4,MEMORY
	DOUBLE PRECISION LVAL(*),DWS(*)

      IERR = 0

      DO I = 1,SUPN_NUM
         SUPN_LINK(I) = 0
      ENDDO
      DO I = 1,WSLENG
         DWS(I) = 0.D0
      ENDDO

      DO NODE = 1,SUPN_NUM

         COLBEG  = SUPN_PART(NODE)
         COLNUM = SUPN_PART(NODE+1) - COLBEG
         COLEND  = COLBEG + COLNUM - 1
         COLLENG   = LCOLPNT(COLBEG+1) - LCOLPNT(COLBEG)
         NNZPTR  = LADJPOINT(NODE)

         CALL LOADVEC (COLLENG,LADJLIST(NNZPTR),SUPN_DIST)
         NODE2 = SUPN_LINK(NODE)
100      IF (NODE2 .GT. 0) THEN
            NODE3 = SUPN_LINK(NODE2)
            COLBEG2 = SUPN_PART(NODE2)
            COLNUM2 = SUPN_PART(NODE2+1) - COLBEG2
            COLLENG2 = SUPN_LENG(NODE2)
            NNZPTR2 = LADJPOINT(NODE2+1) - COLLENG2
            IF (COLLENG2 .NE. COLLENG) THEN
               DO I = 0,COLLENG2-1
                  COLUMN = LADJLIST(NNZPTR2+I)
                  IF (COLUMN .GT. COLEND) GOTO 110
               ENDDO
               I = COLLENG2
110            CONTINUE
               COLNUMUPD = I

               IF (COLNUM2 .EQ. 1) THEN
                  COLPTR = LCOLPNT(COLBEG2+1) - COLLENG2
                  CALL MATMAT2 (COLLENG2,COLNUMUPD,LADJLIST(NNZPTR2),
     +                          LVAL(COLPTR),LCOLPNT,LVAL,SUPN_DIST)
               ELSE
                  COLBEG3 = LADJLIST(NNZPTR2)
                  COLEND3  = LADJLIST(NNZPTR2+COLLENG2-1)
                  COLLENG4 = SUPN_DIST(COLBEG3) - SUPN_DIST(COLEND3)

                  IF (COLLENG4 .LT. COLLENG2) THEN
                     COLPTR3 = LCOLPNT(COLBEG3)
                     COLLENG3 = LCOLPNT(COLBEG3+1) - COLPTR3
                     CALL MATMAT1 (COLLENG2,COLNUM2,COLNUMUPD,
     +                          SUPN_SPLIT(COLBEG2),LCOLPNT(COLBEG2),
     +                          LVAL,LVAL(COLPTR3),COLLENG3)
                  ELSE
                     MEMORY = (COLLENG2*COLNUMUPD) - (COLNUMUPD*
     +                                               (COLNUMUPD-1)/2)
                     IF (MEMORY .GT. WSLENG) THEN
                        IERR = -2
                        RETURN
                     ENDIF
                     CALL MATMAT1 (COLLENG2,COLNUM2,COLNUMUPD,
     +                          SUPN_SPLIT(COLBEG2),LCOLPNT(COLBEG2),
     +                          LVAL,DWS,COLLENG2)
                     DO J=1,COLLENG2
	                  SUPN_DIST2(J) = SUPN_DIST(LADJLIST(NNZPTR2-1+J))
	               ENDDO
                     CALL INDJOIN (COLLENG2,COLNUMUPD,DWS,SUPN_DIST2,
     +                             LCOLPNT(COLBEG),LVAL,COLLENG)
                  ENDIF
               ENDIF
            ELSE
               COLPTR2 = LCOLPNT(COLBEG)
               CALL MATMAT1 (COLLENG2,COLNUM2,COLNUM,
     +                       SUPN_SPLIT(COLBEG2),LCOLPNT(COLBEG2),LVAL,
     +                       LVAL(COLPTR2),COLLENG)
               COLNUMUPD = COLNUM
               IF (COLLENG2 .GT. COLNUM) THEN
                  COLUMN = LADJLIST(NNZPTR+COLNUM)
               ENDIF
            ENDIF
            IF (COLLENG2 .GT. COLNUMUPD) THEN
               NODE4 = SUPN_MEM(COLUMN)
               SUPN_LINK(NODE2) = SUPN_LINK(NODE4)
               SUPN_LINK(NODE4) = NODE2
               SUPN_LENG(NODE2) = COLLENG2 - COLNUMUPD
            ELSE
               SUPN_LENG(NODE2) = 0
            ENDIF
            NODE2 = NODE3
            GOTO 100
         ENDIF

	   CALL BLOCKDEC (COLLENG,COLNUM,SUPN_SPLIT(COLBEG),
     +                  LCOLPNT(COLBEG),LVAL)

         IF (COLLENG .GT. COLNUM) THEN
            COLUMN = LADJLIST(NNZPTR+COLNUM)
            NODE4 = SUPN_MEM(COLUMN)
            SUPN_LINK(NODE) = SUPN_LINK(NODE4)
            SUPN_LINK(NODE4) = NODE
            SUPN_LENG(NODE) = COLLENG - COLNUM
         ELSE
            SUPN_LENG(NODE) = 0
         ENDIF
      ENDDO

      RETURN
      END

C
C-----------------------------------------------------------------------------
C
      SUBROUTINE NUMSOLV (SUPN_NUM,SUPN_PART,LADJPOINT,LADJLIST,LCOLPNT,
     +                    LVAL,RHS)

C     TRIANGULAR SOLUTION

      IMPLICIT NONE

	INTEGER          SUPN_NUM,SUPN_PART(*),LADJLIST(*),LADJPOINT(*),
     +                 LCOLPNT(*),COLBEG,I,PNTR2,J,JEND,JBEG,COL,PNTR,
     +                 NODE,COLEND
	DOUBLE PRECISION LVAL(*),RHS(*),DUM


C FORWARD PART:
      COLBEG = SUPN_PART(1)
      DO NODE = 1,SUPN_NUM
         COLEND = SUPN_PART(NODE+1) - 1
         JBEG = LCOLPNT(COLBEG)
         PNTR = LADJPOINT(NODE)
         DO COL = COLBEG,COLEND
            JEND = LCOLPNT(COL+1) - 1
            DUM = RHS(COL)/LVAL(JBEG)
            RHS(COL) = DUM
            PNTR2 = PNTR + 1
            DO J = JBEG+1,JEND
               I = LADJLIST(PNTR2)
               RHS(I) = RHS(I) - DUM*LVAL(J)
               PNTR2 = PNTR2 + 1
            ENDDO
            JBEG = JEND + 1
            PNTR = PNTR + 1
         ENDDO
         COLBEG = COLEND + 1
      ENDDO

C BACKWARD PART:
      COLEND = SUPN_PART(SUPN_NUM+1) - 1
      DO NODE = SUPN_NUM,1,-1
         COLBEG = SUPN_PART(NODE)
         JEND = LCOLPNT(COLEND+1) - 1
         PNTR = LADJPOINT(NODE) + (COLEND - COLBEG)
         DO COL = COLEND,COLBEG,-1
            JBEG = LCOLPNT(COL)
            PNTR2 = PNTR + 1
            DUM = RHS(COL)
            DO J = JBEG+1,JEND
               I = LADJLIST(PNTR2)
               DUM = DUM - LVAL(J)*RHS(I)
               PNTR2 = PNTR2 + 1
            ENDDO
            RHS(COL) = DUM/LVAL(JBEG)
            JEND = JBEG - 1
            PNTR = PNTR - 1
         ENDDO
         COLEND = COLBEG - 1
      ENDDO

      RETURN
	END

C
C-----------------------------------------------------------------------------
C
      SUBROUTINE REORDER (DIM,MDORDER,MDORDER2,COLNNZ,LEVELUP,
     +                    LEVELDOWN1,LEVELEQ,MDORDER3)

      IMPLICIT NONE

	INTEGER DIM,MDORDER(*),MDORDER2(*),COLNNZ(*),LEVELUP(*),
     +        LEVELDOWN1(*),LEVELEQ(*),MDORDER3(*)

      CALL ELTREE5 (DIM,LEVELUP,COLNNZ,LEVELDOWN1,LEVELEQ,MDORDER3)

      CALL ELTREE6 (DIM,LEVELDOWN1,LEVELEQ,MDORDER3,LEVELUP,COLNNZ,
     +              MDORDER)

      CALL INVORDER (DIM,MDORDER2,MDORDER3,MDORDER)

      RETURN
      END

C
C-----------------------------------------------------------------------------
C
      SUBROUTINE SUPNODES (DIM,LEVELUP,COLNNZ,INDLENG,SUPN_NUM,SUPN_MEM)

	IMPLICIT NONE

	INTEGER DIM,LEVELUP(*),COLNNZ(*),INDLENG,SUPN_NUM,SUPN_MEM(*),COL

      SUPN_NUM = 1
      SUPN_MEM(1) = 1
      INDLENG = COLNNZ(1)
      DO COL = 2,DIM
         IF (LEVELUP(COL-1) .EQ. COL) THEN
            IF (COLNNZ(COL-1) .EQ. (COLNNZ(COL)+1)) THEN
               SUPN_MEM(COL) = SUPN_NUM
               GOTO 100
            ENDIF
         ENDIF
         SUPN_NUM = SUPN_NUM + 1
         SUPN_MEM(COL) = SUPN_NUM
         INDLENG = INDLENG + COLNNZ(COL)
100      CONTINUE
      ENDDO

      RETURN
      END

C
C-----------------------------------------------------------------------------
C
      SUBROUTINE SUPPART (DIM,SUPN_NUM,SUPN_MEM,SUPN_PART)

	IMPLICIT NONE

	INTEGER DIM,SUPN_NUM,SUPN_MEM(*),SUPN_PART(*),COL,SNODE,SNODE2


      SNODE2 = SUPN_NUM + 1
      DO COL = DIM,1,-1
         SNODE = SUPN_MEM(COL)
         IF (SNODE .NE. SNODE2) THEN
            SUPN_PART(SNODE2) = COL + 1
         ENDIF
         SNODE2 = SNODE
      ENDDO
      SUPN_PART(1) = 1

      RETURN
      END

C
C-----------------------------------------------------------------------------
C
      SUBROUTINE SYMBFCT1 (DIM,ADJPOINT,ADJLIST,MDORDER,MDORDER2,
     +                     COLNNZ,NNZL,INDLENG,SUPN_NUM,SUPN_MEM,
     +                     SUPN_PART,IWS)

C
C     FIRST PART OF SYMBOLIC FACTORIZATION: STORAGE REQUIREMENTS AND DATA
C     STRUCTURES
C
C     INPUT:   DIM:      DIMENSION OF LINEAR SYSTEM
C                        SYMMETRY IS NOT CONSIDERED!
C              ADJPOINT: POINTER FOR BEGIN OF NODE IN LIST ADJLIST
C              ADJLIST:  LIST OF NEIGHBORS. ADJPOINT POINTS TO THE
C                        BEGINNING OF THE CURRENT NODE. SYMMETRY IS
C                        NOT USED!
C              MDORDER:  CONTAINS NODE PERMUTATION SUBJECT TO MINIMUM DEGREE
C              MDORDER2: INVERSE OF MDORDER
C     OUTPUT:  COLNNZ(DIM):   NUMBER OF NONZEROS FOR EACH COLUMN (INCL. DIAGONAL)
C              NNZL:     NUMBER OF NONZEROS OF L (INCL. DIAGONAL)
C              INDLENG   NECESSARY LENGTH OF ARRAY DEC_IND (SYMBFCT2)
C              SUPN_NUM  NUMBER OF SUPERNODES
C              SUPN_MEM(DIM): DENOTES TO WHICH SUPERNODE THE CORRESPONDING NODE BELONGS
C              SUPN_PART(DIM+1)  SUPERNODE PARTITIONING
C     DUMMY:   IWS(7*DIM+12)
C

      IMPLICIT NONE

	INTEGER DIM,ADJPOINT(*),ADJLIST(*),MDORDER(*),MDORDER2(*),
     +        COLNNZ(*),INDLENG,SUPN_NUM,SUPN_MEM(*),SUPN_PART(*),NNZL,
     +        IWS(*)



      CALL ELTREE1 (DIM,ADJPOINT,ADJLIST,MDORDER,MDORDER2,IWS(1),
     +              IWS(DIM+1),IWS(2*DIM+1),IWS(3*DIM+1))

      CALL FILLCNT (DIM,ADJPOINT,ADJLIST,MDORDER,MDORDER2,IWS(1),
     +              SUPN_MEM,COLNNZ,NNZL,IWS(DIM+1),IWS(2*DIM+1),
     +              SUPN_PART,IWS(3*DIM+1),IWS(4*DIM+2),IWS(5*DIM+3),
     +              IWS(6*DIM+4))

      CALL REORDER (DIM,MDORDER,MDORDER2,COLNNZ,IWS(1),
     +              IWS(DIM+1),IWS(2*DIM+1),IWS(3*DIM+1))

      CALL SUPNODES (DIM,IWS(1),COLNNZ,INDLENG,SUPN_NUM,SUPN_MEM)

      CALL SUPPART (DIM,SUPN_NUM,SUPN_MEM,SUPN_PART)
C

	RETURN
      END

C
C-----------------------------------------------------------------------------
C
      SUBROUTINE SYMBFCT2 (DIM,ADJPOINT,ADJLIST,MDORDER,MDORDER2,COLNNZ,
     +                     SUPN_NUM,SUPN_PART,SUPN_MEM,LADJPOINT,
     +                     LADJLIST,LCOLPNT,SNODCHILD,SETLIST,INDMARK,
     +                     IERR)


C     SYMBOLIC FACTORIZATION OF REORDERED SYSTEM SUBJECT TO SUPERNODES

	IMPLICIT NONE

	INTEGER DIM,ADJPOINT(*),ADJLIST(*),MDORDER(*),MDORDER2(*),
     +        COLNNZ(*),SUPN_NUM,SUPN_PART(*),SUPN_MEM(*),LADJPOINT(*),
     +        LADJLIST(*),LCOLPNT(*),IERR,INDMARK(*),SNODCHILD(*),
     +        SETLIST(0:*),I,NODE, LISTBEG2,LISTEND2,LISTBEG3,LISTEND3,
     +        LISTBEG,LISTEND,SETEND,COL1,HEAD,J1,NODE3,JWIDE,NNZCNT,
     +        J2,NODE2,LENG, COL2,INDINS,INDFOLL,COL3,SUPNO,PNTR,WIDE

      IERR = 0

      LISTEND = 0
      HEAD = 0
      SETEND = DIM + 1
      PNTR = 1
      DO I = 1,DIM
         INDMARK(I) = 0
         LCOLPNT(I) = PNTR
         PNTR = PNTR + COLNNZ(I)
      ENDDO

      LCOLPNT(DIM+1) = PNTR
      PNTR = 1
      DO NODE2 = 1,SUPN_NUM
         SNODCHILD(NODE2) = 0
         COL1 = SUPN_PART(NODE2)
         LADJPOINT(NODE2) = PNTR
         PNTR = PNTR + COLNNZ(COL1)
      ENDDO

      LADJPOINT(SUPN_NUM+1) = PNTR

      DO NODE2 = 1,SUPN_NUM

         COL1 = SUPN_PART(NODE2)
         COL2 = SUPN_PART(NODE2+1) - 1
         WIDE  = COL2 - COL1 + 1
         LENG = COLNNZ(COL1)
         NNZCNT = 0
         SETLIST(HEAD) = SETEND
         NODE3 = SNODCHILD(NODE2)

         IF (NODE3 .GT. 0) THEN

            JWIDE = SUPN_PART(NODE3+1) - SUPN_PART(NODE3)
            LISTBEG2 = LADJPOINT(NODE3) + JWIDE
            LISTEND2 = LADJPOINT(NODE3+1) - 1
            DO J1 = LISTEND2,LISTBEG2,-1
               INDINS = LADJLIST(J1)
               NNZCNT = NNZCNT+1
               INDMARK(INDINS) = NODE2
               SETLIST(INDINS) = SETLIST(HEAD)
               SETLIST(HEAD) = INDINS
            ENDDO

            NODE3 = SNODCHILD(NODE3)
100         CONTINUE
            IF ((NODE3 .NE. 0) .AND. (NNZCNT .LT. LENG)) THEN

               JWIDE = SUPN_PART(NODE3+1) - SUPN_PART(NODE3)
               LISTBEG2 = LADJPOINT(NODE3) + JWIDE
               LISTEND2 = LADJPOINT(NODE3+1) - 1
               INDFOLL = HEAD
               DO J1 = LISTBEG2,LISTEND2
                  INDINS = LADJLIST(J1)
110               CONTINUE
                  I = INDFOLL
                  INDFOLL = SETLIST(I)
                  IF (INDINS .GT. INDFOLL) GOTO 110
                  IF (INDINS .LT. INDFOLL) THEN
                     NNZCNT = NNZCNT+1
                     SETLIST(I) = INDINS
                     SETLIST(INDINS) = INDFOLL
                     INDMARK(INDINS) = NODE2
                     INDFOLL = INDINS
                  ENDIF
               ENDDO
               NODE3 = SNODCHILD(NODE3)
               GOTO 100
            ENDIF
         ENDIF

         IF (NNZCNT .LT. LENG) THEN
            NODE = MDORDER(COL1)
            LISTBEG3 = ADJPOINT(NODE)
            LISTEND3 = ADJPOINT(NODE+1) - 1
            DO J2 = LISTBEG3,LISTEND3
               INDINS = ADJLIST(J2)
               INDINS = MDORDER2(INDINS)
               IF ((INDINS .GT. COL1) .AND.
     +     		 (INDMARK(INDINS) .NE. NODE2)) THEN

                  INDFOLL = HEAD
120               CONTINUE
                  I = INDFOLL
                  INDFOLL = SETLIST(I)
                  IF (INDINS .GT. INDFOLL)  GOTO 120
                  NNZCNT = NNZCNT + 1
                  SETLIST(I) = INDINS
                  SETLIST(INDINS) = INDFOLL
                  INDMARK(INDINS) = NODE2
               ENDIF
            ENDDO
         ENDIF

         IF (SETLIST(HEAD) .NE. COL1) THEN
            SETLIST(COL1) = SETLIST(HEAD)
            SETLIST(HEAD) = COL1
            NNZCNT = NNZCNT + 1
         ENDIF

         LISTBEG = LISTEND + 1
         LISTEND = LISTEND + NNZCNT
         IF (LISTEND+1 .NE. LADJPOINT(NODE2+1)) GOTO 130
         I = HEAD
         DO J2 = LISTBEG,LISTEND
            I = SETLIST(I)
            LADJLIST(J2) = I
         ENDDO

         IF (LENG .GT. WIDE) THEN
            COL3 = LADJLIST(LADJPOINT(NODE2)+WIDE)
            SUPNO = SUPN_MEM(COL3)
            SNODCHILD(NODE2) = SNODCHILD(SUPNO)
            SNODCHILD(SUPNO) = NODE2
         ENDIF

      ENDDO

	RETURN

130   CONTINUE

      IERR = 4

      RETURN
      END
