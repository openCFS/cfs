      subroutine scpfct(i1,i2,i3,d1,d2,d3,d4)
      return
      end

      subroutine scpgrd(i1,i2,i3,d1,d2,d3,d4,i4,d5,i5,i6,d6,i7,i8,i9,
     +                  d7,i10)
      return
      end

