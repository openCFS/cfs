#include <iostream>
#include <math.h>

/** Declare a C header for the SCPIP fortran implementation by Ch. Zillober */ 

extern "C" 
{
  /** SCPIP is a FORTRAN77 subroutine. It contains all necessary subroutines besides some linear algebra which
      will be mentioned below. To execute SCPIP, the corresponding file has to be compiled and linked with the
      object codes for function and gradient evaluations provided by the user. All calculations within the subrou-
      tines of this file are performed in double precision arithmetic.
   * @param n Number of variables, at least ¸ 1; not altered (NA) (IN) 
   * @param mie Number of inequality constraints (NA) (IN)
   * @param meq Number of equality constraints (NA) (IN)
   * @param iemax Dimension of inequality dependent arrays H ORG, Y IE, ACTIVE. Must be at least MIE and ¸ 1 (NA) (IN) 
   * @param eqmax Dimension of equality dependent arrays G ORG, Y EQ. Must be at least MEQ and ¸ 1 (NA) (IN)
   * @param x0 (N) X0 has to contain an initial guess of the solution. (IN)
   *        On return: X0 is replaced by the last computed iterate *
   * @param x_l (N) Lower bounds on the variables (NA) (IN)
   * @param x_u (N) Upper bounds on the variables (NA) (IN)
   * @param f_org Contains the objective function value of the last computed iterate
   * @param h_org (IEMAX) contains the values of the inequality constraints at the last computed iterate
   * @param g_org (EQMAX) contains the values of the equality constraints at the last computed iterate
   * @param df (N)contains the gradient of the objective function at X0
   * @param y_ie (IEMAX) contains the Lagrange multipliers for the inequality constraints at the last computed iterate (OUT)
   * @param y_eq (EQMAX) contains the Lagrange multipliers for the equality constraints at the last computed iterate (OUT)
   * @param y_l (N) contains the Lagrange multipliers for the lower bounds on the variables at the last computed iterate (OUT)
   * @param y_u (N) contains the Lagrange multipliers for the upper bounds on the variables at the last computed iterate (OUT)
   * @param icntl (13) Integer array of dimension 13 to be set by the user, but all components have reasonable defaults (NA). 
   *        A value 0 indicates that the defaults should be chosen (IN)
   * @param rcntl (6) double precision array of dimension 6 to be set by the user, 
   *        but all components have reasonable defaults (NA). 
   *        A value 0 indicates that the defaults should be chosen (IN)
   * @param info (23) Integer array of dimension 7[sic!] containing some problem information (OUT)
   * @param rinfo (5) Double precision array of dimension 5 containing some problem information (OUT)  
   * 
   * */
  void scpip30_(const int* n,            // ON INPUT (INTEGER = I): NUMBER OF VARIABLES, AT LEAST >=1. NOT ALTERED (NA)
                const int* mie,          // ON INPUT (I): NUMBER OF INEQUALITY CONSTRAINTS (NA)
                const int* meq,          // ON INPUT (I): NUMBER OF EQUALITY CONSTRAINTS (NA)
                const int* iemax,        // ON INPUT (I): DIMENSION OF INEQUALITY DEPENDENT ARRAYS H_ORG, Y_IE,ACTIVE. MUST BE AT LEAST MIE AND >=1. (NA)
                const int* eqmax,        // ON INPUT (I): DIMENSION OF EQUALITY DEPENDENT ARRAYS G_ORG, Y_EQ. MUST BE AT LEAST MEQ AND >=1. (NA) 
                double* x0,                   // ON INPUT (DOUBLE PRECISION = D): X0 HAS TO CONTAIN AN INITIAL GUESS OF THE SOLUTION 
                                               // ON RETURN: X0 IS REPLACED BY THE LAST COMPUTED ITERATE
                const double* x_l,      // ON INPUT (D): LOWER BOUNDS ON THE VARIABLES (NA)  
                const double* x_u,      // ON INPUT (D): UPPER BOUNDS ON THE VARIABLES (NA)
                double* f_org,                // ON RETURN (D), F_ORG CONTAINS THE OBJECTIVE FUNCTION VALUE OF THE LAST COMPUTED ITERATE
                double* h_org,                // ON RETURN (D), H_ORG CONTAINS THE VALUES OF THE INEQUALITY CONSTRAINTS AT THE LAST COMPUTED ITERATE
                double* g_org,                // ON RETURN (D), G_ORG CONTAINS THE VALUES OF THE EQUALITY CONSTRAINTS AT THE LAST COMPUTED ITERATE
                double* df,                   // ON RETURN (D), DF CONTAINS THE GRADIENT OF THE OBJECTIVE FUNCTION AT X0
                double* y_ie,                 // ON RETURN (D), Y_IE CONTAINS THE LAGRANGE MULTIPLIERS FOR THE INEQUALITY CONSTRAINTS AT THE LAST COMPUTED ITERATE  
                double* y_eq,                 // ON RETURN (D), Y_EQ CONTAINS THE LAGRANGE MULTIPLIERS FOR THE EQUALITY CONSTRAINTS AT THE LAST COMPUTED ITERATE
                double* y_l,                  // ON RETURN (D), Y_L CONTAINS THE LAGRANGE MULTIPLIERS FOR THE LOWER BOUNDS ON THE VARIABLES AT THE LAST COMPUTED ITERATE
                double* y_u,                  // ON RETURN (D), Y_U CONTAINS THE LAGRANGE MULTIPLIERS FOR THE UPPER BOUNDS ON THE VARIABLES AT THE LAST COMPUTED ITERATE
                const int* icntl,       // ON INPUT (I): INTEGER ARRAY OF DIMENSION .. TO BE SET BY THE USER, BUT ALL COMPONENTS HAVE REASONABLE DEFAULTS (NA).
                const double* rcntl,    // ON INPUT (D): DOUBLE PRECISION ARRAY OF DIMENSION 6 TO BE SET BY THE USER, BUT ALL COMPONENTS HAVE REASONABLE DEFAULTS (NA). 
                int* info,                    // ON RETURN (I): INTEGER ARRAY CONTAINING SOME PROBLEM INFORMATION.
                double* rinfo,                // ON RETURN (D): DOUBLE PRECISION ARRAY OF DIMENSION 5. CONTAINS INFORMATION ON SOME DATA
                const int* nout,         // ON INPUT (I), INTEGER, INDICATING OUTPUT UNIT NUMBER (NA)
                double* r_scp,                // (D) REAL WORKING ARRAY OF DIMENSION AT LEAST RDIM
                const int* rdim,         // ON INPUT (I): MUST BE AT LEAST 30*N+11*IEMAX+8+10*EQMAX (NA)
                double* r_sub,                // (D) REAL WORKING ARRAY OF DIMENSION AT LEAST RSUBDIM
                const int* rsubdim,      // ON INPUT (I): MUST BE AT LEAST 22*N+41*IEMAX+27*EQMAX+2*IELPAR+EQLPAR (NA)
                int* i_scp,                   // (I) INTEGER WORKING ARRAY OF DIMENSION AT LEAST IDIM
                const int* idim,         // ON INPUT (I): MUST BE AT LEAST 5*N+5*IEMAX+2*EQMAX+3 (NA)
                int* i_sub,                   // (I) INTEGER WORKING ARRAY OF DIMENSION AT LEAST ISUBDIM
                const int* isubdim,      // ON INPUT (I): MUST BE AT LEAST 2*N+3*IEMAX+2*EQMAX+IELPAR (NA)
                int* active,                  // ON RETURN (I): INTEGER ARRAY INDICATING THE INEQUALITY CONSTRAINTS ...
                                               // ON INPUT (I): A USER IS ALLOWED TO CHANGE ACTIVE BEFORE COMPUTING ...
                const int* mode,         // ON INPUT (I): (NA)
                                               // 1: USUAL SUBROUTINE CALL FOR FUNCTION VALUES AND GRADIENTS
                                               // 2: REVERSE COMMUNICATION
                int* ierr,                    // ON (VERY FIRST) INPUT (I): HAS INITIALLY TO BE 0. DO NOT ALTER IERR OUTSIDE THE ROUTINE!
                                               // ON RETURN:
                                               // <0 : REVERSE COMMUNICATION:
                                               // -1: FUNCTION VALUES ARE REQUESTED
                                               // -2: GRADIENTS ARE REQUESTED
                                               // -3: INFO(6) AND INFO(7) ARE COMPUTED. THE USER CAN NOW DIMENSION SPIW AND SPDW DYNAMICALLY. 
                                               //     IF THIS IS NOT DESIRED, JUST REJUMP INTO SCPIP AFTER IERR = -3.
                                               // 0: SUCCESSFUL COMPUTATION ...
                int* iern,                    // ON INPUT (I): IERN CONTAINS THE ROW NUMBERS, I.E. THE INDEX OF THE COMPONENT OF THE ENTRIES 
                                               // OF THE JACOBIAN OF THE INEQUALITY CONSTRAINTS (NA)
                int* iecn,                    // ON INPUT (I): IECN CONTAINS THE COLUMN NUMBERS, I.E. THE NUMBER OF THE
                                               // INEQUALITY OF THE ENTRIES OF THE JACOBIAN OF THE INEQUALITY CONSTRAINTS (NA)
                double* iederv,                  // ON INPUT (D): IEDERV CONTAINS THE VALUES OF THE ENTRIES OF THE JACOBIAN OF THE INEQUALITY CONSTRAINTS. ...
                const int* ielpar,       // ON INPUT (I): DIMENSION OF ARRAYS IERN, IECN AND IEDERV. MUST BE AT LEAST IELENG AND >=1. (NA)
                const int* ieleng,       // ON INPUT (I): ACTUAL NUMBER OF ENTRIES IN IEDERV (NA)
                int* eqrn,                    // ON INPUT (I): EQRN CONTAINS THE ROW NUMBERS, I.E. THE INDEX OF THE COMPONENT OF THE ENTRIES OF 
                                               // THE JACOBIAN OF THE EQUALITYCONSTRAINTS (NA)
                int* eqcn,                    // ON INPUT (I): EQCN CONTAINS THE COLUMN NUMBERS, I.E. THE NUMBER OF THE 
                                               // EQUALITY OF THE ENTRIES OF THE JACOBIAN OF THE EQUALITY CONSTRAINTS (NA)
                double* eqcoef,               // ON INPUT (D): EQCOEF CONTAINS THE VALUES OF THE ENTRIES OF THE JACOBIAN OF THE EQUALITY CONSTRAINTS.
                const int* eqlpar,       // ON INPUT (I): DIMENSION OF ARRAYS EQRN, EQCN AND EQCOEF. MUST BE AT LEAST EQLENG AND >=1. (NA)
                const int* eqleng,       // ON INPUT (I): ACTUAL NUMBER OF ENTRIES IN EQCOEF (NA)
                int* mactiv,                   // ON RETURN (I): NUMBER OF CONSTRAINTS (EQUALITIES AND INEQUALITIES)... 
                                               // THIS AFFECTS THE REQUIRED WORKING SPACE, SEE SPDWDIM BELOW, AND THUS THE SUBPROBLEM SOLUTION METHOD
                int* spiw,                    // (I) INTEGER WORKING ARRAY OF DIMENSION AT LEAST SPIWDIM. 
                                               // AFTER IERR = -3 ONE CAN DIMENSION SPIW AND SPDW DYNAMICALLY WITH THE VALUES OF INFO(6) AND INFO(7).
                const int* spiwdim,      // ON INPUT (I): HAS TO BE AT LEAST:
                                               // SPSTRAT=1: LINSYS=1,3:  1
                                               //            LINSYS=2  :  136*(IELENG+EQLENG)+32*(MIE+MEQ)+3*N+22
                                               //            IF YOU USE DYNAMIC ALLOCATION (ICNTL(13)=1) THEN YOU CAN USE LOWER INITIAL VALUES FOR SPIWDIM 
                                               //            AND LET YOUR CALLING ROUTINE DO THE REST.
                                               // SPSTRAT=2: LINSYS=1,3:  1
                                               //            LINSYS=2  : (IELENG)*5+2*MACTIV+1 (ESTIMATION)
                double* spdw,                 // (D) DOUBLE PRECISION WORKING ARRAY OF DIMENSION AT LEAST SPDWDIM. FOR
                const int* spdwdim,      // ON INPUT (I): HAS TO BE AT LEAST:
                                               // SPSTRAT=1, LINSYS=1:  (MACTIV+MEQ)**2
                                               //            LINSYS=2:  7*PRODLENG+2*(MIE+MEQ)   (ESTIMATION)
                                               //            LINSYS=3:  1
                                               //            IF YOU USE DYNAMIC ALLOCATION (ICNTL(13)=1) THEN YOU CAN USE ...
                                               // SPSTRAT=2, LINSYS=1:  N**2
                                               //            LINSYS=3:  1
                const int* spstrat,      // ON INPUT (I): SUBPROBLEM SOLUTION STATEGY:
                                               // 0: AUTOMATIC CHOICE BY THE PROGRAM
                                               // 1: APPROACH (S3) OF THE REFERENCE 4, ABOVE
                                               // 2: APPROACH (S4) OF THE REFERENCE 4,
                const int* linsys);       // ON INPUT (I): LINEAR SYSTEMS SOLVER THAT SHOULD BE APPLIED.
                                               // 1: DENSE CHOLESKY SOLVER
                                               // 2: SPARSE CHOLESKY SOLVER.
                                               // 3: CG SOLVER
}


void scpfct (int n, int mie, int meq, const double* x,
             double f_org, double* g_org, double* h_org)
{
  f_org = -1.0 * x[0];
  h_org[0] = exp(x[0]) - x[1];
  h_org[1] = exp(x[1]) - x[2];
}

void scpgrd (int n, int mie, int meq,const double* x, double f_org, const double* g_org, const double* h_org,
             const int* active, double* df, int* iern, int* iecn, double* iederv, int& ieleng,
             int* eqrn, int* eqcn, double* eqcoef, int& eqleng)
{             

  df[0] = -1.0; // gradient of objective fully stored!
  df[1] = 0.0;  
  df[2] = 0.0;

  ieleng = 0;
  int numbercon = 0;

  if(active[0] == 1)
  {
    numbercon = numbercon+1;    // one more active constraint
    // constraint 0, component 0
    ieleng = ieleng + 1;        // derivative always > 0
    iecn[ieleng] = numbercon;   // function number
    iern[ieleng] = 0;           // component number
    iederv[ieleng] = exp(x[0]); // value

    // constraint 0, component 1
    ieleng = ieleng + 1;
    iecn[ieleng] = numbercon;
    iern[ieleng] = 1;
    iederv[ieleng] = -1.0;
  }

  if(active[1] == 1) 
  {
    numbercon=numbercon+1;
    // constraint 1, component 1
    ieleng = ieleng + 1;
    iecn[ieleng] = numbercon;
    iern[ieleng] = 1;
    iederv[ieleng] = exp(x[1]);

    // constraint 1, component 2
    ieleng = ieleng + 1;
    iecn[ieleng] = numbercon;
    iern[ieleng] = 2;     
    iederv[ieleng] = -1.0;
  }
}


void test()
{
  // this is a plain fortan -> c translation of v30main.f written by Ch. Zillober
  // Sample driving program for problem #34 in Hock/Schittkowski

  int nn,mi,me,ielpar,eqlpar,rd,rd2,rd3,id,id2,id3;
  
  nn = 100; // maximum number of variables,
  mi = 10;  // inequality constraints
  me = 10;  // equality constraints

  ielpar=mi*10; // maximum number of entries in Jacobian of inequalities  
  eqlpar=me*10; // same for equalities

  rd = rd2 = rd3 = id = id2 = id3 = 1000; // maximum for working arrays

  int n,mie,meq,iemax,eqmax,nout,rdim,rsubdim,idim,isubdim,
      mode,ierr,ieleng,eqleng,mactiv,spiwdim,spdwdim,spstrat,linsys,i;
      
  int icntl[13];
  int info[23];    
  int* i_scp = new int[id];
  int* i_sub = new int[id2];
  int* active = new int[mi];
  int* iern = new int[ielpar];
  int* iecn = new int[ielpar];
  int* eqrn = new int[eqlpar];
  int* eqcn = new int[eqlpar];
  int* spiw = new int[id3];
      
  double f_org;

  double rcntl[6];
  double rinfo[5];       
         
  double* x0 = new double[nn];
  double* x_l = new double[nn];
  double* x_u = new double[nn];
  double* h_org = new double[mi];
  double* g_org = new double[me];
  double* df = new double[nn];  
  double* y_ie = new double[mi];  
  double* y_eq = new double[me];
  double* y_l = new double[nn];
  double* y_u = new double[nn];      
  double* r_scp = new double[rd];
  double* r_sub = new double[rd2];
  double* iederv = new double[ielpar];
  double* eqcoef = new double[eqlpar];
  double* spdw = new double[rd3];      
      
  n = 3;
  mie = 2;
  meq = 0;

  iemax = mie > 1 ? mie : 1;
  eqmax = meq > 1 ? meq : 1;

  x0[0] = 0.0;
  x0[1] = 1.05;
  x0[2] = 2.9;

  x_l[0] = 0.0;
  x_l[1] = 0.0;
  x_l[2] = 0.0;

  x_u[0] = 100;
  x_u[1] = 100;
  x_u[1] = 10;

  icntl[0] = 1;
  icntl[1] = 1;
  icntl[2] = 100;
  icntl[3] = 1;
  icntl[4] = 10;
  icntl[5] = 0;
  icntl[10] = 0;
  icntl[11] = 0;
  icntl[12] = 0;

  rcntl[0] = 1.e-7;
  rcntl[1] = 1.e30;
  rcntl[2] = 1.e30;
  rcntl[3] = 0.0;
  rcntl[4] = 0.0;
  rcntl[5] = 0.0;

  ierr = 0;
  nout = 7;
  rdim = rd;
  rsubdim = rd2;
  idim = id;
  isubdim = id2;
  spiwdim = id3;
  spdwdim = rd3;

  mode = 2;

  spstrat = 1;
  linsys = 1;
/*
  int n,mie,meq,iemax,eqmax,nout,rdim,rsubdim,idim,isubdim,
      mode,ierr,ieleng,eqleng,mactiv,spiwdim,spdwdim,spstrat,linsys,i;
 int nn,mi,me,ielpar,eqlpar,rd,rd2,rd3,id,id2,id3;*/

  bool loop = true;
  while(loop)
  {
    scpip30_(&n,&mie,&meq,&iemax,&eqmax,x0,x_l,x_u,&f_org,h_org,
            g_org,df,y_ie,y_eq,y_l,y_u,icntl,rcntl,info,
            rinfo,&nout,r_scp,&rdim,r_sub,&rsubdim,i_scp,&idim,
            i_sub,&isubdim,active,&mode,&ierr,iern,iecn,iederv,
            &ielpar,&ieleng,eqrn,eqcn,eqcoef,&eqlpar,&eqleng,&mactiv,
            spiw,&spiwdim,spdw,&spdwdim,&spstrat,&linsys);

    if(ierr == 0) 
    {
      std::cout << "solution obtained" << std::endl;
      loop = false;
    }
    if(ierr == -1) 
    {
      scpfct(n,mie,meq,x0,f_org,g_org,h_org);
    }
    if(ierr == -2) 
    {
       scpgrd (n,mie,meq,x0,f_org,g_org,h_org,active,df,iern,
               iecn,iederv,ieleng,eqrn,eqcn,eqcoef,eqleng);
    }
    if(ierr == -3)
    {
       // now you have the chance to adopt spiwdim and spdwdim with the information
       // of info(6) and info(7). we just jump back here.
    }
    if(ierr < -3 || ierr > 0)
    {
      std::cout << "scpip finished with an error! ierr = " << ierr << std::endl;
      loop = false;
    }
  }  
}

int main(int argc, char* argv[])
{
  test();
}
