      program main

c     Sample driving program for problem #34 in Hock/Schittkowski

      implicit none

      integer nn,mi,me,ielpar,eqlpar,rd,rd2,rd3,id,id2,id3

      parameter(nn=100,mi=10,me=10)         !nn maximum number of variables,
                                            !mi inequality constraints
                                            !me equality constraints

      parameter(ielpar=mi*10,eqlpar=me*10)  !ielpar maximum number of entries in
                                            !Jacobian of inequalities. eqlpar same
                                            !for equalities

      parameter(rd=1000,rd2=1000,rd3=1000,id=1000,id2=1000,id3=1000)
                                            !maximum for working arrays

      integer          n,mie,meq,iemax,eqmax,icntl(13),info(23),nout,
     +                 rdim,rsubdim,i_scp(id),idim,i_sub(id2),isubdim,
     +                 active(mi),mode,ierr,iern(ielpar),iecn(ielpar),
     +                 ieleng,eqrn(eqlpar),eqcn(eqlpar),eqleng,mactiv,
     +                 spiw(id3),spiwdim,spdwdim,spstrat,linsys,i
      double precision x0(nn),x_l(nn),x_u(nn),f_org,h_org(mi),g_org(me),
     +                 df(nn),y_ie(mi),y_eq(me),y_l(nn),y_u(nn),
     +                 rcntl(6),rinfo(5),r_scp(rd),r_sub(rd2),
     +                 iederv(ielpar),eqcoef(eqlpar),spdw(rd3)

      n = 3
      mie = 2
      meq = 0

      iemax = max(mie,1)
      eqmax = max(meq,1)

      x0(1) = 0.d0
      x0(2) = 1.05d0
      x0(3) = 2.9d0

      x_l(1) = 0.d0
      x_l(2) = 0.d0
      x_l(3) = 0.d0

      x_u(1) = 1.d2
      x_u(2) = 1.d2
      x_u(3) = 1.d1

      icntl(1) = 1
      icntl(2) = 1
      icntl(3) = 100
      icntl(4) = 1
      icntl(5) = 10
      icntl(6) = 0
      icntl(11) = 0
      icntl(12) = 0
      icntl(13) = 0

      rcntl(1) = 1.d-7
      rcntl(2) = 1.d30
      rcntl(3) = 1.d30
      rcntl(4) = 0.d0
      rcntl(5) = 0.d0
      rcntl(6) = 0.d0

      ierr = 0
      nout = 7
      rdim = rd
      rsubdim = rd2
      idim = id
      isubdim = id2
      spiwdim = id3
      spdwdim = rd3

      mode = 2

      spstrat = 1
      linsys = 1

100   call scpip30 (n,mie,meq,iemax,eqmax,x0,x_l,x_u,f_org,h_org,
     +              g_org,df,y_ie,y_eq,y_l,y_u,icntl,rcntl,info,
     +              rinfo,nout,r_scp,rdim,r_sub,rsubdim,i_scp,idim,
     +              i_sub,isubdim,active,mode,ierr,iern,iecn,iederv,
     +              ielpar,ieleng,eqrn,eqcn,eqcoef,eqlpar,eqleng,mactiv,
     +              spiw,spiwdim,spdw,spdwdim,spstrat,linsys)

      if (ierr .eq. 0) then
         print*,'solution obtained'
      else if (ierr .eq. -1) then
         call scpfct (n,mie,meq,x0,f_org,g_org,h_org)
         goto 100
      else if (ierr .eq. -2) then
         call scpgrd (n,mie,meq,x0,f_org,g_org,h_org,active,df,iern,
     +                 iecn,iederv,ieleng,eqrn,eqcn,eqcoef,eqleng)
         goto 100
      else if (ierr .eq. -3) then
c now you have the chance to adopt spiwdim and spdwdim with the information
c of info(6) and info(7). we just jump back here.
         goto 100
      else
         print*,'scpip finished with an error! ierr = ',ierr
      end if

      stop
      end

**********************************************************************************
      subroutine scpfct (n,mie,meq,x,f_org,g_org,h_org)

c     input:  n,mie,meq,x
c     output: f_org,g_org,h_org

      implicit none

      integer          n,mie,meq
      double precision f_org,g_org(*),h_org(*),x(*)

      f_org = -x(1)

      h_org(1) =  dexp(x(1)) - x(2)
      h_org(2) =  dexp(x(2)) - x(3)

      return
      end

**********************************************************************************
      subroutine scpgrd (n,mie,meq,x,f_org,g_org,h_org,active,df,iern,
     +                   iecn,iederv,ieleng,eqrn,eqcn,eqcoef,eqleng)

c     input:  n,mie,meq,x,f_org,g_org,h_org,active
c     output: df,iern,iecn,iederv,ieleng,eqrn,eqcn,eqcoef,eqleng

      implicit none

      integer          n,mie,meq,active(*),iern(*),iecn(*),ieleng,
     +                 eqrn(*),eqcn(*),eqleng,numbercon
      double precision f_org,g_org(*),h_org(*),x(*),df(*),iederv(*),
     +                 eqcoef(*)

      df(1) = -1.d0
      df(2) = 0.d0                          !gradient of objective fully stored!
      df(3) = 0.d0

      ieleng = 0
	numbercon = 0

      if (active(1) .eq. 1) then
	   numbercon=numbercon+1              !one more active constraint
c constraint 1, component 1:
         ieleng = ieleng + 1                !derivative always > 0
         iecn(ieleng) = numbercon           !function number
         iern(ieleng) = 1                   !component number
         iederv(ieleng) = dexp(x(1))        !value

c constraint 1, component 2:
         ieleng = ieleng + 1                !derivative always > 0
         iecn(ieleng) = numbercon           !function number
         iern(ieleng) = 2                   !component number
         iederv(ieleng) = -1.d0             !value
      endif

      if (active(2) .eq. 1) then
	   numbercon=numbercon+1              !one more active constraint
c constraint 2, component 2:
         ieleng = ieleng + 1                !derivative always > 0
         iecn(ieleng) = numbercon                   !function number
         iern(ieleng) = 2                   !component number
         iederv(ieleng) = dexp(x(2))        !value

c constraint 2, component 3:
         ieleng = ieleng + 1                !derivative always > 0
         iecn(ieleng) = numbercon                   !function number
         iern(ieleng) = 3                   !component number
         iederv(ieleng) = -1.d0             !value
      endif

      return
      end



      subroutine timer2(ttime)

      double precision ttime

c     *********
c
c     Subroutine timer
c
c     The subroutine statement is
c
c       subroutine timer(ttime)
c
c     where
c
c       ttime is an output variable which specifies the user time.
c
c     Argonne National Laboratory and University of Minnesota.
c     MINPACK-2 Project.
c
c     Modified October 1990 by Brett M. Averick.
c
c     **********

      real temp
      real tarray(2)
      real etime                                       

c     The first element of the array tarray specifies user time
      temp = etime(tarray)

      ttime = dble(tarray(1))

      return
      end          

