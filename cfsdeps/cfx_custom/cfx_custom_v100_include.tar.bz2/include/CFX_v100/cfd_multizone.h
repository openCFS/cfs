C/**********************************************************
C * 
C * Defines parameters used for multizone mapping arrays
C *
C *
C **********************************************************/
       INTEGER zone_number, zpl_number
       INTEGER parent_zone,parent_zpl_number
       INTEGER child_zone,child_zpl_number
       PARAMETER(zone_number = 1, zpl_number = 2)
       PARAMETER(parent_zone = 1, parent_zpl_number = 2,
     &           child_zone = 3, child_zpl_number = 4)
