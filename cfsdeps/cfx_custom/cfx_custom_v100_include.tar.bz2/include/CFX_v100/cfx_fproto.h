/*
  cfx_fproto.h

  This file declares the following symbols, for use mainly in porting
  to Windows NT but hopefully more generally useful:

  STDCALL     A C declaration for a Fortran-callable function. Use as
              void STDCALL FUNC(void).

  FortranSubPtr
              A pointer to a subroutine.

  PROTOTYPE   Preprocessor symbol, defined if we want function 
              prototypes.

  UNDERSCORE  Preprocessor symbol, defined if fortran functions should
              have underscores appended.

  UNDERSCORE_DBL
              Preprocessor symbol, defined if Fortran functions
              containing an underscore already should have two
              underscores appended, in the Linux g77 style.  Functions
              not containing an underscore still have just a single
              underscore appended, and UNDERSCORE will always be
              defined whenever UNDERSCORE_DBL is.

  NT_DECL     Preprocessor symbol, defined if the NT style of
              declaring Fortran-callable functions from C is
	      needed. Ie, the name should be in uppercase, and the
	      arguments giving the lengths of strings follow the
	      string they reference, rather than being collected at
	      the end.

  F_LENGTH_T  This is a C type, to be used for the hidden length
              argument for strings.

  It relies on the preprocessor symbol WINDOWS_NT being defined on NT
  by the caller.

  Example usage is as follows, if the function in question doesn't
  take any difficult (ie, string) parameters:

    #if defined NT_DECL
    #  define USER_ABORT	USER_ABORT
    #elif defined UNDERSCORE_DBL
    #  define USER_ABORT	user_abort__
    #elif defined UNDERSCORE
    #  define USER_ABORT	user_abort_
    #else
    #  define USER_ABORT   user_abort
    #endif

  Note that the UNDERSCORE_DBL test comes before that for UNDERSCORE.
  If it does take string parameters, the need to reorder them is also
  signalled by the NT_DECL define.
*/

#ifndef _CFX_FPROTO_H
#define _CFX_FPROTO_H

#ifdef _WIN32 
#ifndef WINDOWS_NT
#error _WIN32 defined without WINDOWS_NT. Fix cfx_proto.h.
#endif
#endif

#if defined __STDC__ || defined WINDOWS_NT
#define PROTOTYPE
#endif

#if defined WINDOWS_NT
#  define STDCALL __stdcall
#  define NT_DECL
#elif defined _AIX
#  define STDCALL
#elif defined __APPLE__
#  define STDCALL
#elif defined(linux) && defined(__powerpc__)
#  define STDCALL
#elif defined __hpux
#  define STDCALL
#  if defined __ia64 || defined _LP64
/* the IA64 (or 64-bit HP-UX builds, when we get there) uses underscores too */
#    ifndef UNDERSCORE
#      define UNDERSCORE
#    endif
#  endif
#elif defined __linux
#  ifndef UNDERSCORE
#    define UNDERSCORE
#  endif
#  define STDCALL
#  ifndef __ia64
#    if !defined (LINUXIA32_SYS) && !defined (LINUXIA64_SYS)  /* Not Ansys LINUX 32 and not LINUX 64*/
#      define UNDERSCORE_DBL
#    endif
#  endif
#else
#  ifndef UNDERSCORE
#    define UNDERSCORE
#  endif
#  define STDCALL
#endif

typedef void STDCALL FortranSub(void);
typedef FortranSub *FortranSubPtr;

#if defined(__hpux)
   /* HP 64-bit uses 64-bit length args */
#  if defined __ia64 || defined _LP64
#    define F_LENGTH_T long
#  else
#    define F_LENGTH_T int
#  endif
#else
#  define F_LENGTH_T int
#endif

#endif /* _CFX_FPROTO_H */
