C /**********************************************************
C   * 
C   *      Memory management system parameters.
C   *      ************************************
C   *
C   *   MXDNAM - Maximum number characters in a data area name
C   *   MXDIR  - Maximum number of directories in a path.
C   *   MXPNAM - Recommended number of characters for a full
C   *            path name variable.
C   *   CSEP   - Name separation character, used in lists and
C   *            for data area names passed to gcntrl.
C   * 
C   **********************************************************/
      INTEGER MXDNAM,MXPNAM,MXDIR
      PARAMETER (MXDNAM=20,MXPNAM=240,MXDIR=64)
      CHARACTER CSEP*(1)
      PARAMETER (CSEP='|')
