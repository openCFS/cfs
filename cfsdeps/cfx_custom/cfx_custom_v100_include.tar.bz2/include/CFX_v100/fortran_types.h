/**********************************************************
 *
 *   fortran_types.h 
 *
 **********************************************************/

/* Declare typedef's for C data types corresponding to Fortran data types */

#ifndef _fortran_types_h
#define _fortran_types_h

#ifdef NEC
  typedef long int Fint;
  typedef long int Flogical;
  typedef long int FLen;
#else
#  if defined(__hpux)
   /* HP 64-bit uses 64-bit length args */
#    if defined __ia64 || defined _LP64
       typedef long FLen;
#    else
       typedef int FLen;
#    endif
#  else
     typedef int FLen;
#  endif
  typedef int Fint;
  typedef int Flogical;
#endif

#ifdef CFX5_ATTR_DOUBLE
  typedef double Freal;
#else
  typedef float  Freal;
#endif

  typedef double Fdouble;
  typedef char   Fchar;

#endif /* !_fortran_types_h*/
