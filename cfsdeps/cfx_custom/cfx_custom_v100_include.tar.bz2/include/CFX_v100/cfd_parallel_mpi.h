C/**********************************************
C *  Parameter definitions and common blocks
C **********************************************/

C
C---- RCVSEC = time interval for timed receive
C
      INTEGER         RCVSEC
      PARAMETER      (RCVSEC=10)
C
C---- Declare buffers for MPI
C
      INTEGER         MPISBF(10000),MPIRBF(10000),MPIBBF(10000)
      COMMON /PARMPI/ MPISBF, MPIRBF, MPIBBF

      INTEGER         DATPOS, DATMAX
      PARAMETER      (DATMAX=5000)
      COMMON /DATMPI/ DATPOS

#ifdef _WIN32
      INTERFACE

      SUBROUTINE MPI_ABORT (I1,I2,I3)
!DEC$ ATTRIBUTES ALIAS:'_MPI_ABORT'::MPI_ABORT
!DEC$ ATTRIBUTES C, REFERENCE, NO_ARG_CHECK::MPI_ABORT
      END SUBROUTINE MPI_ABORT

      SUBROUTINE MPI_BCAST (I1,I2,I3,I4,I5,I6)
!DEC$ ATTRIBUTES ALIAS:'_MPI_BCAST'::MPI_BCAST
!DEC$ ATTRIBUTES C, REFERENCE, VARYING::MPI_BCAST
      END SUBROUTINE MPI_BCAST

      SUBROUTINE MPI_COMM_RANK (I1,I2,I3)
!DEC$ ATTRIBUTES ALIAS:'_MPI_COMM_RANK'::MPI_COMM_RANK
!DEC$ ATTRIBUTES C, REFERENCE, VARYING::MPI_COMM_RANK
      END SUBROUTINE MPI_COMM_RANK

      SUBROUTINE MPI_IPROBE (I1,I2,I3,I4,I5,I6)
!DEC$ ATTRIBUTES ALIAS:'_MPI_IPROBE'::MPI_IPROBE
!DEC$ ATTRIBUTES C, REFERENCE, VARYING::MPI_IPROBE
      END SUBROUTINE MPI_IPROBE

      SUBROUTINE MPI_FINALIZE (I)
!DEC$ ATTRIBUTES ALIAS:'_MPI_FINALIZE'::MPI_FINALIZE
!DEC$ ATTRIBUTES C, REFERENCE, NO_ARG_CHECK::MPI_FINALIZE
      END SUBROUTINE MPI_FINALIZE

      SUBROUTINE MPI_GET_COUNT (I1,I2,I3,I4)
!DEC$ ATTRIBUTES ALIAS:'_MPI_GET_COUNT'::MPI_GET_COUNT
!DEC$ ATTRIBUTES C, REFERENCE, NO_ARG_CHECK::MPI_GET_COUNT
      END SUBROUTINE MPI_GET_COUNT

      SUBROUTINE MPI_PACK (I1,I2,I3,I4,I5,I6,I7,I8)
!DEC$ ATTRIBUTES ALIAS:'_MPI_PACK'::MPI_PACK
!DEC$ ATTRIBUTES C, REFERENCE, VARYING::MPI_PACK
      END SUBROUTINE MPI_PACK

      SUBROUTINE MPI_RECV (I1,I2,I3,I4,I5,I6,I7,I8)
!DEC$ ATTRIBUTES ALIAS:'_MPI_RECV'::MPI_RECV
!DEC$ ATTRIBUTES C, REFERENCE, VARYING::MPI_RECV
      END SUBROUTINE MPI_RECV

      SUBROUTINE MPI_SEND (I1,I2,I3,I4,I5,I6,I7)
!DEC$ ATTRIBUTES ALIAS:'_MPI_SEND'::MPI_SEND
!DEC$ ATTRIBUTES C, REFERENCE, VARYING::MPI_SEND
      END SUBROUTINE MPI_SEND

      SUBROUTINE MPI_UNPACK (I1,I2,I3,I4,I5,I6,I7,I8)
!DEC$ ATTRIBUTES ALIAS:'_MPI_UNPACK'::MPI_UNPACK
!DEC$ ATTRIBUTES C, REFERENCE, VARYING::MPI_UNPACK
      END SUBROUTINE MPI_UNPACK

      END INTERFACE
#endif

C/*********************************
C *  Include MPI common block
C *********************************/

#if defined CFX_F90
      include 'mpif.h'
#else
#include "mpif.h"
#endif

C/*********************************
C *  Word length for buffer
C *********************************/

#if defined CRAY

#define   __character_word_length__ 1
#define     __logical_word_length__ 8
#define     __integer_word_length__ 8
#define        __real_word_length__ 8
#define      __double_word_length__ 8

#else

#define   __character_word_length__ 1
#define     __logical_word_length__ 4
#define     __integer_word_length__ 4
#ifdef DOUBLE_PRECISION
#define        __real_word_length__ 8
#else
#define        __real_word_length__ 4
#endif
#define      __double_word_length__ 8

#endif

#define             __mpi_integer__ MPI_INTEGER
#ifdef DOUBLE_PRECISION
#define                __mpi_real__ MPI_DOUBLE_PRECISION
#else
#define                __mpi_real__ MPI_REAL
#endif
#define              __mpi_double__ MPI_DOUBLE_PRECISION
#define             __mpi_logical__ MPI_LOGICAL
#define              __mpi_string__ MPI_CHARACTER
