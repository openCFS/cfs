/*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Copyright (c) CFX International 2002.
 
Module:           CFX Volume Mesh Import
File Description: Volume Mesh Import Utility API.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
*/

#ifndef _GETARGS_H_
#define _GETARGS_H_

#define usage cfxUsage

#ifdef __cplusplus
extern "C" {
#endif

  extern int argind;
  extern char *argarg;

#ifdef PROTOTYPE
  void 
  cfxUsage
  (char **usgmsg,      /* usage message */
   char *errmsg);      /* error message */

  int 
  getargs
  (int argc,               /* number of arguments */
   char **argv,            /* argument list */
   char *ostr);            /* option list */

#else
  void 
  cfxUsage();

  int 
  getargs();

#endif

#ifdef __cplusplus
}
#endif

#endif  /* _GETARGS_H_ */

/*
================================================================================
*/
