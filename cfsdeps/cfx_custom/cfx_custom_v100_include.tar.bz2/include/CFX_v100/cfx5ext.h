C=======================================================================
C Version: $Id: cfx5ext.h,v 1.2 2004/11/30 16:51:17 jcmorale Exp $
C-----------------------------------------------------------------------
C
C File: cfx5ext.h
C
C Purpose: macros for user fortran routines
C
C-----------------------------------------------------------------------
C
C --- dllexport(f) ---
C
C directive needed to declare external name on NT without upsetting osf.
C macro should be called from first column, ahead of user routine.
C argument f is user routine calling name in lower case.
C
#ifdef _WIN32
#define dllexport(f) cDEC$ ATTRIBUTES DLLEXPORT:: ## f
#else
#define dllexport(f)
#endif
                                            
#define cfd_version 5.8

#define __jbox_memory_stacks__ CZ,DZ,IZ,LZ,RZ
#define __jbox_arg_list__ CZ,DZ,IZ,LZ,RZ

#define __usercel_memory_stacks__ CZ,DZ,IZ,LZ,RZ
#define __usercel_arg_list__ \
     &                       NLOC,NRET,NARG,RET,ARGS,CRESLT \
     &                       __usercel_memory_stacks__ 
