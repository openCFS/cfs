C=======================================================================
C @(#) $Id: cfd_sysdep.h,v 1.21 2005/03/21 14:18:01 pjzwart Exp $
C-----------------------------------------------------------------------
C 
C---- Very small and very large numbers (REAL and DOUBLE PRECISION)
C
      REAL SSM,SM,SN,BN,LOGBN,MACH_EPS
      PARAMETER(SSM=1.0D-10, SM=1.0D-20, SN=1.0D-30, BN=1.0D+30)
C
      DOUBLE PRECISION DSSM,DSM,DSN,DBN,DLOGBN,DMACH_EPS
      PARAMETER(DSSM=1.0D-10, DSM=1.0D-20, DSN=1.0D-30, DBN=1.0D+30)
C
C---- Biggest signed 32 bit integers are is +/- (2^31 - 1)
C
      INTEGER IBIG,IMAXINT,IMININT
      PARAMETER(IBIG=2**30-1,IMAXINT=2147483646,IMININT=-2147483646)
C
      INTEGER REAL_SIZE,INTEGER_SIZE,LOGICAL_SIZE,CHAR_SIZE,DBLE_SIZE
      INTEGER WORD_SIZE
C
C---- Integer and real size depend on whether were doing a double
C     precision build or not.  Some platforms also make integers
C     8 bytes in addition to reals.
C
C---- MACH_EPS is the smallest number which, when added to 1, gives
C     something other than 1.  These values are rounded to the
C     nearest decade.
C
C---- LOGBN is the largest number when exponentiated, i.e exp(LOGBN), 
C     gives a big number (BN) without overflowing.
C     These values have been made consistent with BN, LOGBN = LOG(BN)
C
C     Actual values (IEEE compliant) are:
C        QUANTITY            SINGLE PRECISION       DOUBLE PRECISION
C     ------------------------------------------------------------------
C        SMALLEST               1.18E-038             2.23E-308
C        LARGEST                3.40E+038             1.79E+308
C        LOGBN                  8.87E+001             7.09E+002
C        MACH EPS               1.19E-007             2.22E-016
C
#ifdef DOUBLE_PRECISION
      PARAMETER(REAL_SIZE=8)
      PARAMETER(MACH_EPS=1.D-15)
      PARAMETER(LOGBN = 69.0D0)
C
      PARAMETER(DMACH_EPS=1.D-15)
      PARAMETER(DLOGBN = 69.0D0)
#else
      PARAMETER(REAL_SIZE=4)
      PARAMETER(MACH_EPS=1.D-7)
      PARAMETER(LOGBN = 69.0D0)
C
      PARAMETER(DMACH_EPS=1.D-15)
      PARAMETER(DLOGBN = 69.0D0)
#endif

#ifdef CRAY
      PARAMETER(INTEGER_SIZE=8)
#else
      PARAMETER(INTEGER_SIZE=4)
#endif

#if defined(ASC_SPARC_SOLARIS) && defined(DOUBLE_PRECISION)
      PARAMETER(DBLE_SIZE=16)
#else
      PARAMETER(DBLE_SIZE=8)
#endif
      PARAMETER(LOGICAL_SIZE=4, CHAR_SIZE=1)
      PARAMETER(WORD_SIZE=INTEGER_SIZE)
C
      REAL ONEKB,ONEK
      PARAMETER(ONEKB=1024.0D0, ONEK=1000.0D0)
C
      DOUBLE PRECISION DONEKB,DONEK
      PARAMETER(DONEKB=1024.0D0, DONEK=1000.0D0)
