C /**********************************************************
C   * 
C   *   Stack pointer type declaration.
C   * 
C   **********************************************************/

#if defined(CFX5_POINTER_64)
#define __stack_point__ INTEGER*8
#else
#define __stack_point__ INTEGER
#endif
#define __dummy_stack_point__ 1
#define __invalid_stack_point__ -999 999 999
