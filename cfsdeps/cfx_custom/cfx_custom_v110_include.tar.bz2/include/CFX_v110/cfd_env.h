C=======================================================================
C @(#) $Id: cfd_env.h,v 1.5 2006/05/29 13:55:08 jcmorale Exp $
C-----------------------------------------------------------------------
      INTEGER MXENVIRO
      PARAMETER (MXENVIRO = 10)
C
      INTEGER MXLEN_ENVNAM
      PARAMETER (MXLEN_ENVNAM = 256)
C
      CHARACTER*(MXLEN_ENVNAM) CFX_ENVNAM(MXENVIRO),CFX_ENVVAL(MXENVIRO)
C
      COMMON /CFX_ENVIRO/ CFX_ENVNAM, CFX_ENVVAL
C
#define           __data_dir__ 1
#define          __units_dir__ 2
#define      __materials_dir__ 3
#define      __reactions_dir__ 4
#define    __solver_root_dir__ 5
#define __solver_output_file__ 6
#define __solver_test_reread__ 7
#define            __par_out__ 8
#define        __standard_io__ 9
#define __interp_nocrdvx_check__  10
C
#define    __env_string_type__ CHARACTER*(MXLEN_ENVNAM)
C
