C/* $Revision: 1.10 $ */
C/**********************************************************
C *
C * NODIM  - Number of pointers in LNOD,
C * LODIM  - Number of pointers in LCON,
C * MAXMGL - Maximum number of MG levels 
C * MAXPHI - Maximum number of scalar equations assembled together
C *
C **********************************************************/

      INTEGER NODIM,LODIM,NKZifVxDIM,MAXMGL,MAXPHI
      PARAMETER (NODIM=3, LODIM=4, MAXMGL=100, MAXPHI=13)
      PARAMETER (NKZifVxDIM = 3)

      INTEGER NODIM_PART,LODIM_PART
      PARAMETER (NODIM_PART=1,LODIM_PART=2)
 
      INTEGER IHUGE,OVERLAP
      PARAMETER(IHUGE=1000000000, OVERLAP=999999)

C/**********************************************************
C *
C * Defines the first array index of the topology containing arrays
C * LNOD and LCON .
C *
C * This helps the code developer to understand the meaning of the 
C * different entities of this arrays.  For single zone problems
C * __connected_node_number__ is right, but for multizone problems
C * this is really __connected_col_number__.  This should supercede
C * usage of __connected_node_number__.
C *
C * Note that index 4 is overloaded.  __prev_connection__ is used
C * during symbolic assembly, while __pointer_to_A__ is used
C * during actual assembly/solve.
C *
C **********************************************************/

C/**********************************************************
C *  Indices for LNOD
C **********************************************************/
#define           __pointer_to_LCON__       1
#define           __number_of_connections__ 2
#define           __mg_block_number__       3

C/**********************************************************
C *  Indices for LCON
C **********************************************************/
#define           __connected_node_number__ 1
#define           __connected_col_number__ 1
#define           __next_connection__ 2
#define           __connection_type__ 3
#define           __prev_connection__ 4
#define           __pointer_to_A__ 4

C/**********************************************************
C *  Connection types: LCON(__connection_type__)
C **********************************************************/
#define           __full__ 1
#define           __sparse__ 2
