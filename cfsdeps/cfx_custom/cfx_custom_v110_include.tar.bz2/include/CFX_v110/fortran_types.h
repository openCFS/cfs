/**********************************************************
 *
 *   fortran_types.h 
 *
 **********************************************************/

/* Declare C typedef's for each Fortran data type */

#ifndef _fortran_types_h

#define _fortran_types_h

/* Character */

  typedef char   Fchar;

/* Double Precision */

  typedef double Fdouble;

/* Integer */

#if defined(CFX5_ATTR_INT64)
#  if defined(CFX5_OS_WINNT) || defined(CFX5_OS_WINNT_AMD64)
     typedef __int64 Fint;
#  else
     typedef long long Fint;
#  endif
#else
  typedef int Fint;
#endif

#if defined(CFX5_OS_WINNT) || defined(CFX5_OS_WINNT_AMD64)
  typedef __int64 Fint8;
#else
  typedef long long Fint8;
#endif

/* Logical */
#if defined(CFX5_ATTR_INT64) 
#  if defined(CFX5_OS_WINNT) || defined(CFX5_OS_WINNT_AMD64)
     typedef __int64 Flogical;
#  else
     typedef long long Flogical;
#  endif
#else
  typedef int Flogical;
#endif

/* Real */

#if defined(CFX5_ATTR_DOUBLE)
  typedef double Freal;
#else
  typedef float  Freal;
#endif

/* Hidden lengths for character strings are 8 bytes on some platforms, 4 on others */
#if defined(CFX5_OS_HPUX) || defined(CFX5_OS_HPUX_IA64)
#  if defined(__ia64) || defined(_LP64)
  typedef long FLen;
#  else
  typedef int FLen;
#  endif
#elif defined(CFX5_OS_SOLARIS_AMD64) || defined(CFX5_OS_SOLARIS) || defined(CFX5_OS_LINUX_IA64)
  typedef long FLen;
#elif defined(CFX5_OS_WINNT_AMD64)
  typedef __int64 FLen;
#else
  typedef int FLen;
#endif

#endif /* !_fortran_types_h*/
