C/* $Revision: 1.22 $ */
C
C
#include "cfx_fortran_io.h"
#include "cfd_env.h"
C
C-----------------------------------------------------------------
C Common block for I/O.
C  
C   UNITS(1) -- ITRM     -- terminal output or TRO file.
C   UNITS(2) -- IOUT     -- OUT file.
C   UNITS(3) -- IERR     -- ERR file.
C   UNITS(4) -- INTRM    -- terminal input or TRI file.
C-----------------------------------------------------------------
C  
#if defined(CFX5_OS_WINNT) || defined(CFX5_OS_WINNT_AMD64)
#  ifdef DLL_EXPORT_SOLVER
cDEC$ ATTRIBUTES DLLEXPORT:: /IOMAN/
#  else
cDEC$ ATTRIBUTES DLLIMPORT:: /IOMAN/
#  endif
#endif
C
      INTEGER         UNITS(4)
      CHARACTER*(4)   IODEFFMT
C
      COMMON /IOMAN/  UNITS
      COMMON /IOFMT/  IODEFFMT
C
C-----------------------------------------------------------------
C Common block for output option 
C-----------------------------------------------------------------
C
      INTEGER        OUTOPT
      LOGICAL        WRTJOB,WRTCCL
C
      COMMON /OUTOP/  OUTOPT, WRTJOB, WRTCCL
C
C-----------------------------------------------------------------
C Common block for temporary solver lock file
C-----------------------------------------------------------------
C
      CHARACTER*(256)   FILE_1
C
      COMMON /IOLCKFILE/ FILE_1
C
C----------------------------------------------------------------- 
C  
C------ file units
C
C-----------------------------------------------------------------
C
#define   __unit_trm__ 1
#define   __unit_out__ 2
#define   __unit_err__ 3
#define   __unit_inp__ 4
C----------------------------------------------------------------- 
C  
C------ file names
C
C-----------------------------------------------------------------
C
#define   __def_file_name__ 'def'
#define   __res_file_name__ 'res'

#define   __out_file_name__ 'out'
#define   __out_file_number__ 50

#define   __job_file_name__ 'job'

#define   __hst_file_name__ 'hst'
#define   __phst_file_name__ 'phst'

#define   __stp_file_name__ 'stp'

#define   __msg_file_name__ 'english_msg.txt'

#define   __trn_file_name__ 'trn'

#define   __cgns_file_name__ 'cgns'

#define   __bnd_file_name__ 'bnd'

#define   __csv_file_name__ 'csv'

#define   __par_file_name__ 'par'

#define   __bak_file_name__ 'bak'

#define   __crash_file_name__ 'crash'

#define   __reread_file_name__ 'reread'

#define   __setup_file_name__ 'solver.setup'

C-----------------------------------------------------------------
C
C------ file types
C
C-----------------------------------------------------------------

#define   __res_file_type__  0
#define   __trn_file_type__  1
#define   __bak_file_type__  2
#define   __cgns_file_type__ 3
#define   __bnd_file_type__  4
#define   __csv_file_type__  5

C-----------------------------------------------------------------
C
C------ outfile control level 
C
C-----------------------------------------------------------------

#define __brief__             0
#define __residual_only__     1
#define __verbose__           2
