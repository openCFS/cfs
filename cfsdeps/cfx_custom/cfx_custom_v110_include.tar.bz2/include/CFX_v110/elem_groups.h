C/**********************************************************
C * 
C *  LOGT_MOD      : Modulus for unpacking FLOGTYPE,
C *                  FLOGTYPE = LOGT_MOD*ELOGTYPE + FACETYPE
C *  LOGT_MOD_GGI  : Modulus for unpacking FLOGTYPE of facesets
C *                  for ggi interfaces.
C *                  FLOGTYPE = LOGT_MOD_GGI*ZIFTYPE +
C *                             LOGT_MOD*ELOGTYPE + FACETYPE
C *                  For belgs at GGI interface, however,
C *                  LOGT_MOD_GGI is not packed in FLOGTYPE.
C *                  FLOGTYPE = LOGT_MOD*ELOGTYPE + FACETYPE
C *  LOGT_MOD_FC   : Moduli for unpacking boundary element 
C *  & LOGT_MOD_EL : group pair logical types
C *                  PAIRTYPE = LOGT_MOD_FC*FACETYPE +
C *                           LOGT_MOD_EL*ELOGTYPE_PARENT +
C *                           ELOGTYPE_CHILD
C * 
C **********************************************************/
      INTEGER LOGT_MOD, LOGT_MOD_FC, LOGT_MOD_EL, LOGT_MOD_GGI
      PARAMETER (LOGT_MOD=100, LOGT_MOD_FC=100, LOGT_MOD_EL=10)
      PARAMETER (LOGT_MOD_GGI=1000)
C
#define __empty_face__ 1
#define  __full_face__ 2
#define __mixed_face__ 3
