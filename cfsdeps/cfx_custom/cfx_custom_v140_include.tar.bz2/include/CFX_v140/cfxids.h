/*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
$RCSfile: cfxids.h,v $: ID definition
<FIG>
Copyright (c)     ANSYS CFX 2003.
Module:           Mesh Import
File Description: ID definition
Author:           Richard Hann 05 Mar 2003.
</FIG>
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
$Id: cfxids.h,v 1.2 2005/02/07 11:51:03 cfxrh Exp $
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
*/

#ifndef _cfxIMPORT_CFX_IDS_H_
#define _cfxIMPORT_CFX_IDS_H_

#include <limits.h>

#if defined(__cplusplus)
extern "C" {
#endif

  typedef unsigned int  ShortID_t;

#define SID_MAX UINT_MAX

#ifdef CFX_LONG_IDS
  
  typedef unsigned long ID_t;

#define ID_MAX ULONG_MAX

#else

  typedef unsigned int  ID_t;

#define ID_MAX UINT_MAX

#endif

#if defined(__cplusplus)
}
#endif

#endif

/*
================================================================================
================================================================================
*/


