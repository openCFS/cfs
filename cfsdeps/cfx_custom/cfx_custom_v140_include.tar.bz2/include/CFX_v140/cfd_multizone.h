C/**********************************************************
C * 
C * Defines parameters used for multizone mapping arrays
C *
C *
C **********************************************************/
       INTEGER zone_number, zpl_number
       INTEGER parent_zone,parent_zpl_number
       INTEGER child_zone,child_zpl_number
       PARAMETER(zone_number = 1, zpl_number = 2)
       PARAMETER(parent_zone = 1, parent_zpl_number = 2,
     &           child_zone = 3, child_zpl_number = 4)
C
       INTEGER ZONE_P, FACE_P, PVX_S, PVX_F
       INTEGER ZONE_C, FACE_C, CVX_S, CVX_F
       PARAMETER (ZONE_P = 1, FACE_P = 3,
     &            PVX_S = 5, PVX_F = 8)
       PARAMETER (ZONE_C = 2, FACE_C = 4,
     &            CVX_S = 9, CVX_F = 12)
