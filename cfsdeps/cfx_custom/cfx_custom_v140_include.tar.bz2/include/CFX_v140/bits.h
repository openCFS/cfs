C=======================================================================
C @(#) $Id: bits.h,v 1.1 2000/03/31 07:22:43 cfdspl Exp $
C-----------------------------------------------------------------------
CC
CD Bits type declaration and values.
CC
CC --------------------
CC        History
CC --------------------
CC
CC  29 Mar 2000  BAS  Created.
CC
C-----------------------------------------------------------------------
C
#define __bits__ INTEGER
C
#define __bit0__ 1
#define __bit1__ 2
#define __bit2__ 4
#define __bit3__ 8
#define __bit4__ 16
#define __bit5__ 32
#define __bit6__ 64
#define __bit7__ 128
#define __bit8__ 256
#define __bit9__ 512
#define __bit10__ 1024
#define __bit11__ 2048
#define __bit12__ 4096
#define __bit13__ 8192
#define __bit14__ 16384
#define __bit15__ 32768
#define __bit16__ 65536
#define __bit17__ 131072
#define __bit18__ 262144
#define __bit19__ 524288
#define __bit20__ 1048576
#define __bit21__ 2097152
#define __bit22__ 4194304
#define __bit23__ 8388608
#define __bit24__ 16777216
#define __bit25__ 33554432
#define __bit26__ 67108864
#define __bit27__ 134217728
#define __bit28__ 268435456
#define __bit29__ 536870912
#define __bit30__ 1073741824
C
C-----------------------------------------------------------------------
