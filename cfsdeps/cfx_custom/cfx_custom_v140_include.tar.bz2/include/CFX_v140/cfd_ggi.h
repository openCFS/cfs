C
C---- GGI_OUT: output channel for GGI debug information
C     GGI_DEB: flag to control GGI debug information
C
      INTEGER GGI_OUT, GGI_DEB
C
      COMMON /GGIGGI/ GGI_DEB, GGI_OUT
