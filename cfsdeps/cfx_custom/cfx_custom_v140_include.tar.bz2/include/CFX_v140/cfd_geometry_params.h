C /**********************************************************
C   *   Parameters used for accessing NTOTALS in /FLOW/GEOMETRY
C   *   All parameters begin MNT_.
C   *   E.g. /FLOW/GEOMETRY/NTOTALS(MNT_NVL) equals NVL the number
C   *   of volumes in the model. Similarly for the zone
C   *   specific values, e.g. /FLOW/GEOMETRY/Zone/NTOTALS(MNT_NVL)
C   *   equals the number of volumes in zone Zone.
C   * 
C   * MNT_NVL      - Number of volumes.
C   * MNT_NVP      - Number of volume patches.
C   * MNT_NSF      - Number of surface sides.
C   * MNT_NBCP     - Number of boundary conditon patches.
C   * MNT_NPBC     - Number of periodic boundary conditions.
C   * MNT_NSVP     - Number of super volume patches
C   * MNT_NSBP     - Number of super boundary patches
C   * 
C   **********************************************************/
      INTEGER MNT_NVL,MNT_NVP,MNT_NSF,MNT_NBCP,MNT_NPBC,
     &        MNT_NSVP,MNT_NSBP
      PARAMETER (MNT_NVL    = 1 , MNT_NSF  = 3 , MNT_NBCP  = 5 ,
     &           MNT_NVP    = 2 , MNT_NPBC = 6,
     &           MNT_NSVP   = 7 , MNT_NSBP = 8 )
