C=======================================================================
C @(#) $Id: common_sizes.h,v 1.4 2005/01/21 18:44:22 gawang Exp $
C-----------------------------------------------------------------------
CC
CD Common sizes.
CC
CC --------------------
CC        History
CC --------------------
CC
CC  28 Jan 2000  BAS  Created.
CC
C-----------------------------------------------------------------------
C
C---- Size limit for aliases that are used internally.
C
      INTEGER MXLEN_ALIAS
      PARAMETER (MXLEN_ALIAS = 48)
C
C---- Size limit for passing external aliases through the solver.
C
C     *NB* This is only a declaration size for matching PEEKCS/POKECS
C     which exceeds but does not represent the actual constraint
C     on the length of names.
C
      INTEGER MXLEN_XALIAS
      PARAMETER (MXLEN_XALIAS = 120)
C
C---- Size limit for CGNS names.
C
      INTEGER  MXCGNAM
      PARAMETER (MXCGNAM = 32)
C
C
C---- Size limit for number of fluids
C
      INTEGER MFLUID
      PARAMETER (MFLUID=100)
C
C-----------------------------------------------------------------------
