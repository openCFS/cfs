C/**********************************************
C *  Parameter definitions and common blocks
C **********************************************/

C
C---- RCVSEC = time interval for PVM_TRECV
C
      INTEGER         RCVSEC
      PARAMETER      (RCVSEC=10)

C/*********************************
C *  Include PVM common block
C *********************************/

#include "fpvm3.h"

C/*********************************
C *  Word length for buffer
C *********************************/

#define   __character_word_length__ 1
#define     __logical_word_length__ 4
#define     __integer_word_length__ 4
#ifdef DOUBLE_PRECISION
#define        __real_word_length__ 8
#else
#define        __real_word_length__ 4
#endif
#define      __double_word_length__ 8
