C /**********************************************************
C   * 
C   *      Memory management system parameters.
C   *      ************************************
C   *
C   *   MXDNAM - Maximum number characters in a data area name
C   *   MXDIR  - Maximum number of directories in a path.
C   *   MXPNAM - Recommended number of characters for a full
C   *            path name variable.
C   *   CSEP   - Name separation character, used in lists and
C   *            for data area names passed to gcntrl.
C   * 
C   **********************************************************/
      INTEGER MXDNAM,MXPNAM,MXDIR
      PARAMETER (MXDNAM=20,MXPNAM=240,MXDIR=64)
      CHARACTER CSEP*(1)
      PARAMETER (CSEP='|')
C
C---- Vulnerability levels
C
#define  __levvul_0__   0
#define  __levvul_1__  10 
#define  __levvul_2__  20
#define  __levvul_3__  30
#define  __levvul_4__  40
#define  __levvul_5__  50
#define  __levvul_6__  60
#define  __levvul_7__  70
#define  __levvul_8__  80
#define  __levvul_9__  90
#define __levvul_10__ 100
