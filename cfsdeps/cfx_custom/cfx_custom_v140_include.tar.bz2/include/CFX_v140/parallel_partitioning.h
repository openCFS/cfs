C/**********************************************
C *  Parameter definitions and common blocks
C **********************************************/

C
C---- General parallel/partitioning stuff
C
C     NHSTDD   maximum number of hosts
C     NPARDD   maximum number of partitions
C
C     PARMOD   parallel run mode (master or slave)
C     RUNMOD   run mode (serial, partitioning or parallel)
C     OWNPAR   own partition number
C     NPARD    actual number of partitions
C     TBUFID   actual buffer ID
C     BUFPOS   actual buffer position
C     BUFMAX   maximum buffer size
C     TPRCID   process IDs
C     SYNCOM   logical flag for synchronization
C     PARTYP   parallel library type ('PVM', 'MPI', ...)
C
      INTEGER         NHSTDD, NPARDD
      PARAMETER      ( NHSTDD=2048, NPARDD=2048 )
C
#if defined(_WIN32) || defined(_WIN64)
#  ifdef DLL_EXPORT_SOLVER
cDEC$ ATTRIBUTES DLLEXPORT:: /PARMOD/, /PARPAR/
#  else
cDEC$ ATTRIBUTES DLLIMPORT:: /PARMOD/, /PARPAR/
#  endif
#endif
C
      INTEGER         PARMOD, RUNMOD, EXEMOD, OWNPAR, NPARD,
     &                TBUFID, BUFPOS, BUFMAX, TPRCID(NPARDD),
     &                CFX5_MPI_COMM, BUFTAG
  
      LOGICAL         SYNCOM
      CHARACTER*(3)   PARTYP
C
      COMMON /PARPAR/ OWNPAR, NPARD
      COMMON /PARMOD/ PARMOD, RUNMOD, EXEMOD
      COMMON /PARTOP/ TPRCID
      COMMON /PARBUF/ TBUFID, BUFPOS, BUFMAX, BUFTAG
      COMMON /PARCTL/ SYNCOM, PARTYP
      COMMON /PARCOM/ CFX5_MPI_COMM
C
C---- Stuff to measure the communication effort
C
C     DIAGCOMM logical flag to switch on cpmmunication effort monitoring
C     MSGBLK   number of blocks sent between processes
C     MSGBYT   number of bytes sent between processes
C
      INTEGER         DIAGCOMM, MSGBLK(0:NPARDD), MSGBYT(0:NPARDD)
      COMMON /PARMEM/ DIAGCOMM, MSGBLK, MSGBYT
C
C---- Description of parallel hosts
C
C     NHSTD    actual number of hosts
C     HSTSPD   relative host speed
C     HSTSPD   static load distribution
C     HSTPRC   number of processors avaialbe in a host
C     HSTPAR   number of partitions assigned to a host
C     HTSDEF   host name and name of corresponding solver binary
C
      REAL            HSTSPD(NHSTDD), HSTSTL(NHSTDD)
      INTEGER         NHSTD, HSTPRC(NHSTDD), HSTPAR(NHSTDD)
      CHARACTER*10    HSTTYP
      CHARACTER*256   HSTDEF(3,NHSTDD)
      COMMON /PARHST/ NHSTD, HSTPRC, HSTPAR, HSTDEF, HSTTYP
      COMMON /PRHST2/ HSTSPD, HSTSTL

C/*********************************
C *  Default I/O blocking size
C *********************************/

#define  __default_blocking_size__ 10000

C/*********************************
C *  Specific buffer ids
C *********************************/

#define  __initial_buffer_id__  -1
#define  __buffer_id_initialized__  -99

C/*********************************
C *  Run mode
C *********************************/

#define  __sequential_run__ 0
#define  __parallel_run__ 1
#define  __partitioning_run__ 2

#define  __sequential__ 0
#define  __parallel__ 1
#define  __partitioning__ 2

C/*********************************
C *  Execution mode
C *********************************/

#define  __flow__ 0
#define  __partitioner__ 1
#define  __radiation__ 2
#define  __interpolator__ 3

C/*********************************
C *  Parallel mode
C *********************************/

#define  __master_in_parallel_run__ 1
#define  __slave_in_parallel_run__ 2

#define  __master__ 1
#define  __slave__ 2

C/*********************************
C *  Lookup for host array
C *********************************/

#define  __par_host__ 1
#define  __par_command__ 2
#define  __par_solver_binary__ 3

C/*********************************
C *  Message communication mode
C *********************************/

#define  __no_communication__ 0
#define  __cm_to_all_partitions__ 1
#define  __cm_to_one_partition__ 2
#define  __ds_to_partitions__ 3
#define  __broadcast__ 4
#define  __gather_from_slaves__ 5

C/*********************************
C *  Continuation flags
C *********************************/

#define  __stop__ 0
#define  __continue__ 1
#define  __return__ 2

C/*********************************
C *  Message Numbers
C *********************************/

#define                     __test_message__ 1000
#define         __process_topology_message__ 1001
#define             __error_report_message__ 1002
#define           __message_report_message__ 1003
#define             __stop_process_message__ 1004
#define           __dataset_header_message__ 1005

#define                __stop_flag_message__ 1007



#define               __cnl_cmicnl_message__ 1011
#define               __cnl_cmrcnl_message__ 1012
#define               __cnl_sizcnl_message__ 1013
#define               __cnl_bldcnl_message__ 1014

#define               __cnl_comres_message__ 1016
#define          __update_priority_message__ 1017
#define                   __sclchk_message__ 1018
#define                   __avepar_message__ 1019
#define                   __sumpar_message__ 1020
#define                   __minpar_message__ 1021
#define                   __maxpar_message__ 1022
#define                   __runf3d_message__ 1023
#define                   __solver_message__ 1025
#define                   __jobsum_message__ 1026
#define                   __disdat_message__ 1027
#define                  __compare_message__ 1028
#define                   __cheslv_message__ 1029
#define                   __mempar_message__ 1030
#define                   __parcgb_message__ 1031
#define                   __logpar_message__ 1032
#define                   __resout_message__ 1033
#define                   __finmes_message__ 1034
#define              __Set_NarvSym_message__ 1037
#define                   __symnor_message__ 1038
#define                   __jobchk_message__ 1039
#define                   __wrtjb2_message__ 1040
#define                   __wrtpar_message__ 1041
#define                   __gnofst_message__ 1042
#define                   __coltop_message__ 1043
#define                   __colmat_message__ 1044
#define                   __colrhs_message__ 1045
#define                   __discor_message__ 1046
#define                   __maxloc_message__ 1047
#define                   __wrtme1_message__ 1048
#define                    __premg_message__ 1049
#define                   __prshft_message__ 1050
#define                   __redsht_message__ 1051
#define                  __wrtlong_message__ 1052
#define                  __redlong_message__ 1053
#define                  __redatrb_message__ 1054
#define               __PutFacInfo_message__ 1055
#define                   __dishdr_message__ 1056
#define                  __crmper1_message__ 1057
#define                   __allerr_message__ 1058
#define                 __Read_MMS_message__ 1059
#define             __store_totals_message__ 1060
#define               __get_varlst_message__ 1061
#define            __write_soln_vx_message__ 1062
#define           __diag_cpu_times_message__ 1063
#define                __su_hybarr_message__ 1064
#define            __cfxmsg_report_message__ 1065
#define                   __minpai_message__ 1066
#define         __extract_real_l2g_message__ 1067
#define                   __ilufac_message__ 1068
#define            __upd_dvar_zone_message__ 1069
#define    __copy_struct_to_slaves_message__ 1070
#define             __wrtlong_cgns_message__ 1071
#define              __wrtlong_csv_message__ 1072
#define         __write_soln_bcpvx_message__ 1073
#define           __get_varlst_fcs_message__ 1074
#define           __write_mesh_zif_message__ 1075
#define              __update_cbck_message__ 1076
#define                   __getmem_message__ 1077
#define             __chk_wallarea_message__ 1078
#define          __parallel_offset_message__ 1079
#define               __su_radflow_message__ 1080
#define                   __sumpai_message__ 1081
#define                   __maxpai_message__ 1082
#define            __out_cpu_times_message__ 1083
#define                 __userfort_message__ 1084
#define             __init_prefeqn_message__ 1085
#define             __circ_bnd_avg_message__ 1086
#define               __prompt_mol_message__ 1087
#define                __write_mol_message__ 1088
#define                __inject_pt_message__ 1089
#define        __cal_source_points_message__ 1090
#define          __upd_parflag_ims_message__ 1091
#define                  __partset_message__ 1092
#define          __create_hostlist_message__ 1093

#define                   __prntop_message__ 1201
#define                   __prncnl_message__ 1202
#define                   __prncgb_message__ 1203
#define                 __trn_flag_message__ 1204
#define           __fnd_nearest_vx_message__ 1205
#define            __fnd_global_vx_message__ 1206
#define            __ctrl_mon_user_message__ 1207
#define          __fnd_nearest_elm_message__ 1208
#define             __calc_rot_mat_message__ 1209
#define           __theta_cont_fin_message__ 1210
#define              __reread_flag_message__ 1211
#define                    __rdrgp_message__ 1212
#define             __su_props_rgp_message__ 1213
#define             __sum_par_real_message__ 1214
#define             __sum_par_intr_message__ 1215
#define             __write_pt_src_message__ 1216
#define      __su_radiation_points_message__ 1217
#define           __upd_rad_points_message__ 1218
#define                __ckpartrvx_message__ 1219
#define            __get_pvar_monp_message__ 1220
#define              __get_pvar_sp_message__ 1221
#define      __cplg_getnextrequest_message__ 1222
#define  __cplg_acknowledgerequest_message__ 1223
#define            __cplg_puterror_message__ 1224
#define             __synp_connect_message__ 1225
#define             __srv_code_val_message__ 1226
#define              __srv_sim_val_message__ 1227
#define             __srv_cplg_val_message__ 1228
#define             __srv_mesh_val_message__ 1229
#define             __srv_soln_val_message__ 1230
#define            __ckgvxbcpvxbcp_message__ 1231
#define            __ckgfcbcpfcbcp_message__ 1232
#define             __cplg_putdata_message__ 1233
#define             __cplg_getdata_message__ 1234
#define         __cplg_sendcommand_message__ 1235
#define               __clnt_solve_message__ 1236
#define             __clnt_chkconv_message__ 1237
#define                  __clnt_dt_message__ 1238
#define                 __clnt_prc_message__ 1239
#define                __clnt_synp_message__ 1240
#define             __clnt_slvinit_message__ 1241
#define             __clnt_siminit_message__ 1242
#define           __cplg_gunitconv_message__ 1243
#define     __inject_pt_pos_predef_message__ 1250
#define          __pario_dist_info_message__ 1251
#define         __pario_dist_table_message__ 1252
#define          __pario_dist_intr_message__ 1253
#define          __pario_dist_real_message__ 1254
#define          __pario_dist_dble_message__ 1255
#define          __pario_coll_info_message__ 1256
#define         __pario_coll_table_message__ 1257
#define          __pario_coll_intr_message__ 1258
#define          __pario_coll_real_message__ 1259
#define          __pario_coll_dble_message__ 1260
#define            __collect_array_message__ 1261
#define                   __sumpad_message__ 1262
#define                 __init_cel_message__ 1263
#define           __su_mesh_region_message__ 1264
#define               __init_id_pt_message__ 1265
#define              __get_kgcscsg_message__ 1266
#define               __get_global_message__ 1267
#define                __lpnq_init_message__ 1268
#define                 __coll_blk_message__ 1269
#define              __sync_kvalvx_message__ 1270
#define          __srf_delta_theta_message__ 1271
#define            __mon_check_par_message__ 1272
#define           __comparedistpar_message__ 1273
#define             __fnd_elmtopol_message__ 1274
#define        __pt_adj_mfloip_par_message__ 1275
#define             __min_par_intr_message__ 1276
#define             __max_par_intr_message__ 1277
#define             __min_par_real_message__ 1278
#define             __max_par_real_message__ 1279
#define          __upd_rad_iatrib2_message__ 1280
#define           __rbs_distribute_message__ 1281
#define                __srf_nedge_message__ 1282

#define            __comm_part_dir_message__ 2001
#define        __transfer_part_dir_message__ 2002
#define               __track_file_message__ 2003
#define             __unique_id_pt_message__ 2004
#define               __pt_db_save_message__ 2005
#define               __pt_db_load_message__ 2006
#define           __pt_db_setpatch_message__ 2007
#define                      __prb_message__ 2008
#define           __pt_db_fnd_part_message__ 2009
#define        __par_coll_arr_intr_message__ 2010
#define        __par_dist_arr_intr_message__ 2011
#define             __pt_reloc_wpt_message__ 2012
#define        __par_coll_arr_real_message__ 2013
#define       __get_greinit_ffront_message__ 2014
#define               __distribute_message__ 6666
#define                  __default_message__ 7777
#define             __notification_message__ 8888
#define          __synchronisation_message__ 9999
