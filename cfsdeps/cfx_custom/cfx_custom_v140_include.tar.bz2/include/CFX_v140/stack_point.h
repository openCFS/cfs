C /**********************************************************
C   *
C   *   Stack pointer type declaration.
C   *
C   **********************************************************/

#if defined(CFX_MMSPTR64)
#define __stack_point__ INTEGER*8
#else
#define __stack_point__ INTEGER
#endif

#define __dummy_stack_point_cz__ DUM_STK_PT_CZ
#define __dummy_stack_point_dz__ DUM_STK_PT_DZ
#define __dummy_stack_point_iz__ DUM_STK_PT_IZ
#define __dummy_stack_point_lz__ DUM_STK_PT_LZ
#define __dummy_stack_point_rz__ DUM_STK_PT_RZ

#define __invalid_stack_point__ -999 999 999

      __stack_point__     DUM_STK_PT_CZ,
     &                    DUM_STK_PT_DZ,
     &                    DUM_STK_PT_IZ,
     &                    DUM_STK_PT_LZ,
     &                    DUM_STK_PT_RZ
      COMMON /DUM_STK_PT/ DUM_STK_PT_CZ,
     &                    DUM_STK_PT_DZ,
     &                    DUM_STK_PT_IZ,
     &                    DUM_STK_PT_LZ,
     &                    DUM_STK_PT_RZ
