C/**********************************************************
C *   Parameters used for accessing NTOTALS in /FLOW/MESH
C *   All parameters begin MNT_.
C *   E.g. /FLOW/MESH/NTOTALS(MNT_NVX) equals NVX the number
C *   of vertices in the model. Similarly for the zone
C *   specific values, e.g. /FLOW/MESH/Zone/NTOTALS(MNT_NEL)
C *   equals the number of elements in zone Zone.
C * 
C * MNT_NVX      - Number of vertices on a zone or zif.
C * MNT_NEL      - Number of elements.
C * MNT_NELS     - Number of element sets.
C * MNT_NIELG    - Number of interior element groups.
C * MNT_NFCS     - Number of face sets.
C * MNT_NBELG    - Number of boundary element groups.
C * MNT_NFC      - Number of mesh faces.
C * MNT_NTFC     - Number of triangular faces on a zif
C * MNT_NQFC     - Number of quad faces on a zif
C * MNT_NBELGP   - Number of boundary element group pairs on a zif.
C * MNT_NCS      - Number of control surfaces on a zif
C * MNT_NCSC     - Number of ip to control surface connections on
C *                a zif
C * MNT_NBELGS   - Number of static boundary element groups. 
C *                The "static" here termed as any belg that is not 
C *                GGI. 
C * 
C **********************************************************/
      INTEGER NMESHOBJ
      PARAMETER (NMESHOBJ = 10)
C
      INTEGER MNT_NVX,MNT_NEL,MNT_NELS,MNT_NIELG,MNT_NFCS,MNT_NBELG
      INTEGER MNT_NFC, MNT_NBELGP, MNT_NFCSP, MNT_NQFC, MNT_NTFC
      INTEGER MNT_NCS, MNT_NCSC, MNT_NCSG, MNT_NBELGS, MNT_NVXO

      PARAMETER (MNT_NVX    = 1, 
     &           MNT_NEL    = 2,
     &           MNT_NELS   = 3,
     &           MNT_NTFC   = 3,
     &           MNT_NIELG  = 4,
     &           MNT_NQFC   = 4,
     &           MNT_NFCS   = 5,
     &           MNT_NFCSP  = 5,
     &           MNT_NCS    = 5,
     &           MNT_NBELG  = 6,
     &           MNT_NCSG   = 6,
     &           MNT_NFC    = 7,
     &           MNT_NBELGP = 8,
     &           MNT_NCSC   = 8,
     &           MNT_NBELGS = 9,
     &           MNT_NVXO   = 9)
C/**********************************************************
C *   Parameters used for accessing the ELEM_LOC_INFO data
C *   structure. All parameters begin 'ELI_'. Except for
C *   ELI_NINFO all parameters are pointers into INFO for the
C *   value of the associated parameter, e.g. INFO(ELI_IP1)
C *   equals IP1.
C * 
C * ELI_NINFO    - Maximum number entries, dimension of INFO
C * ELI_IELS     - The element set number.
C * ELI_IELG     - The element group number.
C * ELI_IFCS     - The face set number.
C * ELI_IBCP     - The boundary condition patch number.
C * ELI_BELG     - The boundary element group number.
C * ELI_ELOGTYPE - The element set logical type.
C * ELI_FLOGTYPE - The face set logical type.
C * ELI_ISEL_S   - The first set element on the locale.
C * ELI_ISEL_F   - The final set element on the locale.
C * ELI_ISFC_S   - The first set face on the locale.
C * ELI_ISFC_F   - The final set face on the locale.
C * ELI_IP1      - The first integration point.
C * ELI_IP2      - The last integration point.
C * ELI_IPC      - The centre point.
C * ELI_NVxEl    - The number of vertices on an element.
C * ELI_NDIM     - The number of spatial dimensions.
C * ELI_IFCSP    - Faceset pair number
C * ELI_BELGP    - Boundary element group pair number
C * ELI_BELG_P   - Parent boundary element group number
C * ELI_BELG_C   - Child boundary element group number
C * ELI_IZN_P    - Parent zone number
C * ELI_IZN_C    - Child zone number
C * 
C **********************************************************/
      INTEGER ELI_NINFO
      PARAMETER (ELI_NINFO=30)
      INTEGER ELI_IELS,ELI_IELG,ELI_ELOGTYPE,ELI_ISEL_S,ELI_ISEL_F,
     &        ELI_IP1,ELI_IP2,ELI_IPC,ELI_NVxEl,ELI_NDIM,
     &        ELI_IFCS,ELI_BELG,ELI_FLOGTYPE,ELI_ISFC_S,ELI_ISFC_F,
     &        ELI_IBCP,ELI_IFCSP,ELI_BELGP,ELI_BELG_P,ELI_BELG_C,
     &        ELI_IZN_P, ELI_IZN_C,ELI_IIP1,ELI_IIP2,ELI_BFACE,
     &        ELI_FACETYPE,
     &        ELI_IP1_2D,ELI_IP2_2D,ELI_IIP1_2D,ELI_IIP2_2D
      PARAMETER (ELI_IELS   = 1 , ELI_IELG   = 2 , ELI_ELOGTYPE = 3 ,
     &           ELI_ISEL_S = 4 , ELI_ISEL_F = 5 , ELI_IP1      = 6 ,
     &           ELI_IP2    = 7 , ELI_IPC    = 8 , ELI_NVxEl    = 9 ,
     &           ELI_NDIM   = 10, ELI_IFCS   = 11, ELI_BELG     = 12,
     &         ELI_FLOGTYPE = 13, ELI_ISFC_S = 14, ELI_ISFC_F   = 15,
     &           ELI_IBCP   = 16, ELI_BELG_P = 17, ELI_BELG_C   = 18,
     &           ELI_IFCSP  = 19, ELI_BELGP  = 20, ELI_IZN_P    = 21,
     &           ELI_IZN_C  = 22, ELI_IIP1   = 23, ELI_IIP2     = 24,
     &           ELI_BFACE  = 25, ELI_FACETYPE = 26,ELI_IP1_2D  = 27,
     &           ELI_IP2_2D = 28, ELI_IIP1_2D = 29,ELI_IIP2_2D  = 30)
C/**********************************************************
C *   Parameters used for accessing the FC_INFO data
C *   structure from KSfcEl. All parameters begin 'FCI_'.
C *   Except for FCI_NINFO all parameters are pointers into FC_INFO
C *   for the value of the associated parameter,
C *   e.g. INFO(FCI_IFCS) equals IFCS.
C * 
C * FCI_NINFO    - Maximum number entries, dimension of INFO
C * FCI_FACE     - The local face set number.
C * FCI_IFCS     - The face set number.
C * FCI_ISFC     - The set face number.
C * FCI_ZIFTYPE  - The overlap face type: empty, mixed, or full
C * 
C **********************************************************/
      INTEGER FCI_NINFO
      PARAMETER (FCI_NINFO=4)
      INTEGER FCI_FACE,FCI_IFCS,FCI_ISFC,FCI_ZIFTYPE
      PARAMETER (FCI_FACE    = 1 , FCI_IFCS   = 2 , FCI_ISFC = 3 ,
     &           FCI_ZIFTYPE = 4)
C/**********************************************************
C *   Macros to facilitate MMS MMS navigation
C * 
C **********************************************************/
#define      __mesh_zone_to_topol__ '../../../TOPOL'
#define  __initmesh_zone_to_topol__ '../../TOPOL'
#define      __mesh_locl_to_topol__ '../../../../TOPOL'
#define  __initmesh_locl_to_topol__ '../../../TOPOL'
#define      __mesh_intp_to_topol__ '../../../../../TOPOL'
#define  __initmesh_intp_to_topol__ '../../../../TOPOL'
#define      __mesh_enty_to_topol__ '../../../../../TOPOL'
#define  __initmesh_enty_to_topol__ '../../../../TOPOL'
#define     __mesh_eintp_to_topol__ '../../../../../../TOPOL'
#define __initmesh_eintp_to_topol__ '../../../../../TOPOL'
#define      __mesh_face_to_topol__ '../../../../../TOPOL'

