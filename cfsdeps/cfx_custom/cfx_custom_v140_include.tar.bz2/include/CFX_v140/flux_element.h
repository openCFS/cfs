C /**********************************************************
C   * 
C   *   NNODED - Maximum number of nodes per element.
C   *   NNODEF - Maximum number of nodes per element face.
C   *   NIPD   - Maximum number of integration points.
C   *   MXELOG - Maximum element logical type.
C   *   NVXIP  - Maximum number of corner vertices per ip face.
C   * 
C   **********************************************************/
      INTEGER NIPD,NNODED,NNODEF,MXELOG, NVXIP
      PARAMETER (NIPD=43, NNODED=8, NNODEF=4, MXELOG=7, NVXIP=4)

C /**********************************************************
C   * Element Logical types
C   **********************************************************/

#define             __bar_element__ 1
#define        __triangle_element__ 2
#define   __quadrilateral_element__ 3
#define     __tetrahedral_element__ 4
#define           __wedge_element__ 5
#define      __hexahedral_element__ 6
#define         __pyramid_element__ 7

C /**********************************************************
C   * Element facetypes
C   **********************************************************/

#define                __tri_face__ 0
#define               __quad_face__ 1
#define           __internal_face__ 2

C /***********************************************************
C   *
C   *  Element Routine Error Codes
C   *
C   ***********************************************************/

#define            __no_element_errors__ 0
#define __invalid_element_logical_type__ 1

