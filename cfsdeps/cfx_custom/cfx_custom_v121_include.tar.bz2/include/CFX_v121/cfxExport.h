/*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Copyright (c)     ANSYS Inc 2003.
Module:           CFX5 Export API.
File Description: Export API Header File.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
*/
#ifndef _cfxEXPORT_H_
#define _cfxEXPORT_H_

/*--- element types ---*/

#define cfxELEM_TET     4   /* tet element (4 nodes ) */
#define cfxELEM_PYR     5   /* pyramid element (5 nodes ) */
#define cfxELEM_WDG     6   /* wedge element (6 nodes) */
#define cfxELEM_HEX     8   /* hex element (8 nodes) */

/*--- count entries ---*/

enum cfxCounts {
    cfxCNT_NODE = 0,    /* number of nodes */
    cfxCNT_ELEMENT,     /* number of elements */
    cfxCNT_VOLUME,      /* number of volumes */
    cfxCNT_REGION,      /* number of regions */
    cfxCNT_VARIABLE,    /* number of variables */
    cfxCNT_BOUNDARY,    /* number of boundaries */
    cfxCNT_TET,         /* number of tetrahedral elements */
    cfxCNT_PYR,         /* number of ptramid elements */
    cfxCNT_WDG,         /* number of wedge elements */
    cfxCNT_HEX,         /* number of hexhedral elements */
    cfxCNT_SIZE         /* size of count array */
};

/*--- zone motion flags ---*/

#define cfxMOTION_USE    0 
#define cfxMOTION_IGNORE 1 

/*--- element ID and face number ---*/

#define cfxREG_NODES    0
#define cfxREG_FACES    1

#define cfxFACENUM(face)    ((face) & 7)
#define cfxELEMNUM(face)    ((face) >> 3)

/*--- volume flags ---*/

#define cfxVOL_NODES    0
#define cfxVOL_ELEMS    1

/*--- data value flags ---*/

enum cfxValues {
    cfxPRESSURE_OFFSET = 1, /* pressure offset */
    cfxMOLECULAR_WEIGHT,    /* molecular weight (ideal gas only) */
    cfxGAS_CONSTANT,        /* gas constant (ideal gas only) */
    cfxDENSITY,             /* fluid density */
    cfxDYNAMIC_VISCOSITY,   /* dynamic viscosity */
    cfxSPECIFIC_HEAT_P,     /* specific heat at constant pressure */
    cfxCONDUCTIVITY,        /* fluid thermal conductivity */
    cfxTHERMAL_EXPANSION    /* fluid thermal expansion */
};

/*--- node data ---*/

typedef struct cfxNode {
  double x, y, z;
} cfxNode;

/*--- element data ---*/

typedef struct cfxElement {
    int type;
    int *nodeid;
} cfxElement;

/*--- function prototypes ---*/

#ifdef __cplusplus
extern "C" {
#endif

void cfxExportError (       /* define callback for errors */

    void (*callback)(       /* user-supplied call back routine */
        char *errmsg        /* error message */
    )

);

void cfxExportFatal (       /* terminate with error message */

    char *errmsg            /* error message */

);

  /* Called when a fatal error is encountered when opening a CFX5 file
     We don't close the input file, because closing it will try to write
     an index to the file (which might corrupt it).
  */
void cfxExportNoClose (  

    char *errmsg            /* error message */

);

int cfxExportInit (         /* initialize for export */
            /* returns number of zones */
    char *resfile,          /* results file name */
    int counts[cfxCNT_SIZE] /* counts (may be NULL) */

);

void cfxExportDone (        /* finish export */

    void

);

/*========== Zones ======================================*/

int cfxExportZoneCount (    /* return number of zones */

    void

);

const char *cfxExportZoneName (   /* return zone name */

    const int zone                /* zone number */

);

int cfxExportZoneSet (      /* sets the current zone */

    const int zone,         /* zone number */
    int counts[cfxCNT_SIZE] /* zone counts (may be NULL) */

);

int cfxExportZoneGet (      /* gets the current zone number */

    void

);

void cfxExportZoneFree (    /* free current zone data */

    void

);

int cfxExportZoneIsRotating( /* return whether the current zone is rotating */

    double  rotationAxis[2][3],/* rotation axis of the zone */
    double *angularVelocity    /* angular velocity of the zone */

);

int cfxExportZoneMotionAction(  /* Use or ignore the grid motion */

    const int zone,             /* zone number */
    const int flag              /* cfxMOTION_USE or cfxMOTION_IGNORE */

);

/*========== Nodes ======================================*/

int cfxExportNodeCount (    /* return number of nodes */

    void

);

cfxNode *cfxExportNodeList (/* return node list */

    void

);

int cfxExportNodeGet (      /* return a single node */

    const int nodeid,       /* node number */
    double *x,              /* x coordinate */
    double *y,              /* y coordinate */
    double *z               /* z coordinate */

);

void cfxExportNodeFree (    /* free node data storage */

    void

);

int cfxExportGridChanged ( 

    const int tsIndex1, /* The base timestep at which to compare the grid. */
    const int tsIndex2  /* The second timestep at which to compare the grid. */

);

/*========== Elements ===================================*/

int cfxExportElementCount ( /* return number of elements */

    void

);

cfxElement *cfxExportElementList (/* return element list */

    void

);

int cfxExportElementGet (   /* get a single element */

    const int elemid,       /* element number */
    int *elemtype,          /* element type - tet,pyr,wdg or hex */
    int *nodelist           /* node numbers defining element */

);

void cfxExportElementFree ( /* free element data storage */

    void

);

/*========== Volumes ====================================*/

int cfxExportVolumeCount (  /* return number of volumes */

    void

);

int cfxExportVolumeSize (   /* return number of nodes or elements in a volume */

    const int volnum,       /* volume number */
    const int type          /* nodes(cfxVOL_NODES) or elements(cfxVOL_ELEMS) */

); 

const char *cfxExportVolumeName ( /* return volume name */

    const int volnum              /* volume number */

);

int *cfxExportVolumeList (  /* return nodes or elements for a volume */

    const int volnum,       /* volume number */
    const int type          /* nodes(cfxVOL_NODES) or elements(cfxVOL_ELEMS) */

);

int cfxExportVolumeGet (    /* get a single node or element for a volume */

    const int volnum,       /* volume number */
    const int type,         /* node(cfxVOL_NODES) or element(cfxVOL_ELEMS) */
    const int index,        /* index in volume */
    int *id                 /* node or element id */

);

void cfxExportVolumeFree (  /* free volume data storage */

    const int volnum        /* volume number */

);

/*========== Regions ====================================*/

int cfxExportRegionCount (  /* return number of regions */

    void

);

int cfxExportRegionSize (   /* return number of nodes or faces in a region */

    const int regnum,       /* region number */
    const int type          /* nodes(cfxREG_NODES) or faces(cfxREG_FACES) */

); 

const char *cfxExportRegionName ( /* return region name */

    const int regnum              /* region number */

);

int *cfxExportRegionList (  /* return nodes or faces for a region */

    const int regnum,       /* region number */
    const int type          /* nodes(cfxREG_NODES) or faces(cfxREG_FACES) */

);

int cfxExportRegionGet (    /* get a single node or face for a region */

    const int regnum,       /* region number */
    const int type,         /* nodes(cfxREG_NODES) or faces(cfxREG_FACES) */
    const int index,        /* index in region */
    int      *id            /* node or face id */

);

void cfxExportRegionFree (  /* free region data storage */

    const int regnum        /* region number */

);

int cfxExportFaceNodes (    /* get nodes for a given face */

    const int faceid,       /* face number */
    int *nodes              /* node ID's for face */

);

/*========== Variables ====================================*/

void cfxExportSetVarParams (/* set global var params for combined zone */

    const int correct,      /* use corrected boundary node values */
    const int level         /* level of interest */

);

int cfxExportVariableCount (/* return number of variables */

    const int usr_level     /* level of interest */

);

int cfxExportVariableSize ( /* return dimension and length of variable */

    const int varnum,       /* variable number */
    int *dimension,         /* dimension of variable */
    int *length,            /* number of values */
    int *bdnflag            /* flag for corrected boundary node values */

); 

const char *cfxExportVariableName (/* return variable name */

    const int varnum,              /* variable number */
    const int alias                /* if non-zero, use alias */

);

float *cfxExportVariableList (/* return variable values */

    const int varnum,         /* variable number */
    const int correct         /* use corrected boundary node values */

);

int cfxExportVariableGet (  /* get a single value for a variable */

    const int varnum,       /* variable number */
    const int correct,      /* use corrected boundary node values */
    const int index,        /* index in variable */
    float *var              /* value */

);

void cfxExportVariableFree (/* free region data storage */

    const int varnum        /* variable number */

);

/*========== Boundaries ====================================*/

int cfxExportBoundaryCount (/* return number of boundarys */

    void

);

int cfxExportBoundarySize ( /* return number of nodes or faces in a boundary */

    const int bndnum,       /* boundary number */
    const int type          /* nodes(cfxREG_NODES) or faces(cfxREG_FACES) */

); 

const char *cfxExportBoundaryName ( /* return boundary name */

    const int bndnum                /* boundary number */

);

const char *
cfxExportBoundaryType(      /* return boundary type */
		      
    const int bndnum        /* boundary number */
);

int *cfxExportBoundaryList (  /* return face sets for a boundary */
			    
    const int bndnum,      /* boundary number */
    const int type         /* nodes(cfxREG_NODES) or faces(cfxREG_FACES) */

);

int cfxExportBoundaryGet ( /* get a single node or face for a boundary */

    const int bndnum,      /* boundary number */
    const int type,        /* nodes(cfxREG_NODES) or faces(cfxREG_FACES) */
    const int index,       /* index in boundary */
    int *id                /* node or face id */

);

void cfxExportBoundaryFree (  /* free boundary data storage */

    const int bndnum       /* boundary number */

);


/*========== Data Values ==================================*/

int cfxExportValueGet (    /* retrieve data value */

    const int type,        /* data type */
    float *value           /* returned value */

);


/*========== Timesteps ======================================*/

int cfxExportTimestepCount (    /* return number of timesteps */

    void

);

int cfxExportTimestepSet (      /* sets the current timestep */

    const int ts                /* timestep number */

);

int cfxExportTimestepNumGet (   /* return actual timestep of a timestep */

    const int tsIndex           /* timestep index */

);

float cfxExportTimestepTimeGet (/* return time value of a timestep */

    const int tsIndex           /* timestep index */

);

int
cfxExportGetNumberOfParticleTypes();

const char *
cfxExportGetParticleName(const int index);

int
cfxExportGetNumberOfTracks(const int index);


int 
cfxExportGetNumberOfPointsOnParticleTrack(const int typeIndex,
                                          const int trackIndex);

float *
cfxExportGetParticleTrackCoordinatesByTrack(const int typeIndex, 
                                            const int trackIndex, 
                                            int *numTrackPoints);

float *
cfxExportGetParticleTrackTimeByTrack(const int typeIndex, 
                                     const int trackIndex, 
                                     int      *numTrackPoints);
int
cfxExportGetParticleTypeVarCount(const int typeIndex);


const char *       
cfxExportGetParticleTypeVarName(const int typeIndex, 
				const int varIndex,
				const int alias);
       
int
cfxExportGetParticleTypeVarDimension(const int typeIndex, const int varIndex);


float *
cfxExportGetParticleTypeVar(const int typeIndex, 
			    const int varIndex,
			    const int trackIndex);

/* 
 * Warning
 * -------
 * This macro is for backwards compatability - it should NOT be used. 
 */

#define cfxExportGetParticleTrackCoordinatresByTrack(A, B, C) \
          cfxExportGetParticleTrackCoordinatesByTrack(A, B, C)

#ifdef __cplusplus
}
#endif

#endif  /* _cfxEXPORT_H_ */

/*
================================================================================
================================================================================
*/
