#include <stdio.h>
#include <pardiso.h>
#include <ilupack.h>

#include <ilupackmacros.h>

#ifdef __PARDISO_2__
integer mps_pardiso(integer n, integer * ia, integer *ja, double *a, 
		    integer *p, double *rowscal, double *colscal, 
		    integer j)
#else
integer mps_pardiso(integer contraint1, integer contraint2, 
		    integer n, integer * ia, integer *ja, double *a, 
		    integer *p, double *rowscal, double *colscal, 
		    integer j)
#endif
{
  integer i;

  printf("*** Warning: PARDISO maximum weight matching is disabled! ***\n");fflush(stdout);
  for (i=0; i<n; i++) {
      // mps_pardiso uses C-style
      p[i]=i;
      // scalings are the dual vectors
      rowscal[i]=colscal[i]=0.0;
      // the exponential has to be applied afterwards
  }
  return (0);
}
