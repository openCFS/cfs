c              push node k and its information onto the top of 
c              the stack
               if (usestack) then
                  pressurelist(topstack)=k
c                 stack is below its capacity
                  if (nstack.lt.npressurelist) then
                     nstack=nstack+1
                  else
c                    remove oldest pressure node to create space for k
                     startA=pressuretopA(bottomstack)+1
                     if (startA.gt.npressurestackA) startA=1
                     bottomstack=bottomstack+1
                     if (bottomstack.gt.npressurelist)
     +                  bottomstack=1
                  end if
                  topstack=topstack+1
                  if (topstack.gt.npressurelist) topstack=1
                  

c                 insert list of nonzero columns of A

c                 get beginning of the data stack for A
                  if (nstack.eq.1) then
                     ii=startA
                  else
                     ii=topstack-2
                     if (ii.le.0) ii=ii+npressurelist
                     ii=pressuretopA(ii)+1
                     if (ii.gt.npressurestackA) ii=1
                  end if
c                 get end of the data stack for A
                  if (nstack.eq.1) then
                     jj=npressurestackA+1
                  else
                     jj=startA
                  end if
c                 number of entries available 
                  kk=jj-ii
                  if (kk.lt.0) kk=kk+npressurestackA
c                    head of the linked list
                  i=jw(n2+k)
c                 while i>0         
 3010             if (i.le.0) goto 3020
c                    push row i onto the stack
                     if (kk.gt.0) then
c                       write (6,'(A,I6,A,I6)')'insert node ',i,
c     +                              ' at ',ii
                        pressurestackA(ii)=i
                        ii=ii+1
                        if (ii.gt.npressurestackA) ii=1
                        kk=kk-1
                     else
c                       remove further nodes from the stack
c                       while kk=0 
 3030                   if (kk.gt.0) goto 3040
                           startA=pressuretopA(bottomstack)+1
                           if (startA.gt.npressurestackA) startA=1
                           bottomstack=bottomstack+1
                           if (bottomstack.gt.npressurelist)
     +                        bottomstack=1
                           nstack=nstack-1
                           if (nstack.le.1) then
                              jj=npressurestackA+1
                           else
                              jj=startA
                           end if
                           kk=jj-ii
                           if (kk.lt.0) kk=kk+npressurestackA
                           if (nstack.le.1.and.kk.eq.0) goto 3060
                        goto 3030
c                       end while
 3040                   pressurestackA(ii)=i
c                       write (6,'(A,I6,A,I6)')'insert node ',i,
c     +                              ' at ',ii
                        ii=ii+1
                        if (ii.gt.npressurestackA) ii=1
                        kk=kk-1
                     end if
                     i=jw(n3+i)
                  goto 3010
c                 end while

 3060             nstack=0
                  topstack=2
c                 where does the data for row k end
 3020             if (ii.eq.1) ii=npressurestackA+1
                  if (topstack.gt.1) then
                     pressuretopA(topstack-1)=ii-1
                  else
                     pressuretopA(npressurelist)=ii-1
                  end if

#ifdef PRINT_SADDLE
                  ii=bottomstack
                  jj=startA
                  do i=1,nstack
                     kk=pressurelist(ii)
                     write (6,'(A,I5,A)') 'pressure node ',kk,
     +                    ', list:'
                     kk=pressuretopA(ii)
                     write (6,'(20I8)')(pressurestackA(j),
     +                    j=jj,kk)
                     if (kk.lt.jj) then
                        write (6,'(20I8)')(pressurestackA(j),
     +                       j=jj,npressurestackA)
                        write (6,'(20I8)')(pressurestackA(j),
     +                       j=1,kk)
                     end if
                     jj=pressuretopA(ii)+1
                     if (jj.gt.npressurestackA) jj=1
                     ii=ii+1
                     if (ii.gt.npressurelist) ii=1
                  end do
#endif

               end if
            end if
