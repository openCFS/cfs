#include <stdio.h>
#include <stdlib.h>

#include <blas.h>
#include <lapack.h>

#include <ilupack.h>

#include <ilupackmacros.h>

#define MAX_LINE        255
#define STDERR          stderr
#define STDOUT          stdout
// #define PRINT_INFO
#define MAX(A,B)        (((A)>(B))?(A):(B))
#define MIN(A,B)        (((A)<(B))?(A):(B))


/*
   Given a multilevel ILU decomposition, AMGsol performs a simple
   forward backward substitution
*/ 
void AMGSOL(AMGLEVELMAT *PRE, ILUPACKPARAM *IPparam,
	    FLOAT *rhs, FLOAT *sol, FLOAT *buff)
{

/*
   PRE       linked list of multilevel ILU preconditioners
   nlev      number of levels (blocks)
   rhs       given right hand side
   sol       solution obtained by AMGsol
   buff      work array of length 3n, where n is the size of the original 
             matrix
  
   Code written by Matthias Bollhoefer, May/November 2003
                                            November 2004
*/

   AMGLEVELMAT *next, *prev;

   integer i,j, n=PRE->n, nB, *p, *invq, sumn=0, lev, param, ierr,nbf,
     PILUCparam,nlev=PRE->nlev;

   FLOAT *rowscal, *colscal;
   REALS val;
   character uplo, trans, diag;
   static int info_message=1;

#ifdef PRINT_INFO
   static int check=1;

   if (check) {
     check=0;
#ifdef _SINGLE_REAL_ 
     printf("SGNL solve\n");
#else
#ifdef _DOUBLE_REAL_
     printf("DGNL solve\n");
#else
#ifdef _SINGLE_COMPLEX_
     printf("CGNL solve\n");
#else
     printf("ZGNL solve\n");
#endif
#endif
#endif
   }
#endif

   // buffer to store 'true' ipar[6] from the time of the factorization
   PILUCparam=IPparam->ipar[16];
   if (IPparam->ipar[10]!=0 && !(PILUCparam&DISCARD_MATRIX)) {
      sumn=0;
      next=PRE;
      nbf=0;
      if (IPparam->ipar[10]==2) 
	 nbf=n;
      for (i=1; i<=nlev; i++) {
	  sumn+=next->nB;
	  nbf+=n-sumn;
	  next=next->next;
      } // end for i

      for (i=0; i<n; i++)
	  sol[i]=rhs[i];
      if (IPparam->ipar[10]==1) 
	 AMGSOL1(PRE, 1, n, nbf, 0,0, IPparam, sol, buff);
      else if (IPparam->ipar[10]==2) {
 	 AMGSOL2(PRE, 1, n, nbf, 0,0, IPparam, sol, buff);
      }
      return ;
   }
   else if (IPparam->ipar[10]!=0 && info_message) {
      printf("ILUPACK WARNING!\n");
      printf("AMLI-like AMG or classical multigrid need to selected prior to\n");
      printf("factorization in order to maintain coarse grid systems.\n");
      printf("Will use multilevel ILU instead.\n");
      info_message=0;
   }

   param=IPparam->ipar[6];
   buff+=n;
   for (i=0; i<n; i++)
       buff[i]=rhs[i];
   buff-=n;

   /* block forward substitution */
   next=PRE;
   prev=NULL;
   lev=1;
   while (lev<nlev) {
	 nB=next->nB;
	 p=next->p;

	 if (lev>1) {
	    rowscal=next->rowscal-sumn;
	    buff+=n;
	    for (i=sumn; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	        buff[i]*=rowscal[i];
#else
		val=buff[i].r;
	        buff[i].r=val*rowscal[i].r-buff[i].i*rowscal[i].i;
	        buff[i].i=val*rowscal[i].i+buff[i].i*rowscal[i].r;
#endif
	    }
	    buff-=n;
	 } /* end if */

	 /* reorder the whole system */
	 p-=sumn;
	 for (i=sumn; i<n; i++)
	     buff[i]=buff[n+sumn+p[i]-1];
	 p+=sumn;

	 /* first block */
	 if (param&COARSE_REDUCE) {
	    j=next->LU.ja[nB];
	    next->LU.ja[nB]=next->LU.nnz+1;
	    ILUCSOL(&nB, buff+sumn,buff+n+sumn, next->LU.a,next->LU.ja,next->LU.ia);
	    next->LU.ja[nB]=j;

	    /* second block */
	    CSRMATVEC(next->E,buff+n+sumn,sol+sumn+nB);

	    sumn+=nB;

	    /* coarse grid projection */
	    for (i=sumn; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	        buff[n+i]=buff[i]-sol[i];
#else
		buff[n+i].r=buff[i].r-sol[i].r;
		buff[n+i].i=buff[i].i-sol[i].i;
#endif
	    } // end for i
	 } // end if
	 else {
	    i=n-sumn;
	    j=next->LU.ja[nB];
	    next->LU.ja[nB]=next->LU.nnz+1;
	    PILUCLSOL (&i,&nB, buff+sumn,buff+n+sumn, next->LU.a,next->LU.ja,next->LU.ia);
	    next->LU.ja[nB]=j;
	    sumn+=nB;

	    /* coarse grid projection */
	    for (i=sumn; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	        buff[n+i]=buff[i]+buff[n+i];
#else
		buff[n+i].r=buff[i].r+buff[n+i].r;
		buff[n+i].i=buff[i].i+buff[n+i].i;
#endif
	    } // end for i
	 } // end else

	 prev=next;
	 next=next->next;
	 lev++;
   } /* end while */

   /* last level */
   nB=next->nB;
   p=next->p;
   invq=next->invq;
   

   /* -----   last block   ----- */

   /* did we finally switch to full matrix processing? */
   if (lev>1 && next->LU.ja==NULL) {
#ifdef USE_LAPACK_DRIVER
     i=1;
     COPY(&nB, buff+n+sumn,&i, sol+sumn,&i);
     GETRS("T",&nB,&i,next->LU.a,&nB,next->LU.ia, sol+sumn,&nB,&ierr,1); 
#else
     LUPQTSOL(&nB, next->LU.a,next->LUperm,next->LU.ia, buff+n+sumn,sol+sumn, buff); 
#endif
   }
   else {
      if (lev>1) {
	 rowscal=next->rowscal-sumn;
	 buff+=n;
	 for (i=sumn; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	   buff[i]*=rowscal[i];
#else
	   val=buff[i].r;
	   buff[i].r=val*rowscal[i].r-buff[i].i*rowscal[i].i;
	   buff[i].i=val*rowscal[i].i+buff[i].i*rowscal[i].r;
#endif
	 } // end for i
	 buff-=n;
      } /* end if */
      if (next->LUperm==NULL) {

	/* reorder the whole system */
	p-=sumn;
	for (i=sumn; i<n; i++)
	    buff[i]=buff[n+sumn+p[i]-1];
	p+=sumn;
     
	j=next->LU.ja[nB];
	next->LU.ja[nB]=next->LU.nnz+1;
	ILUCSOL(&nB, buff+sumn,buff+n+sumn, next->LU.a,next->LU.ja,next->LU.ia); 
	next->LU.ja[nB]=j;

	/* reorder the whole system back */
	buff+=n+sumn-1;
	invq-=sumn;
	for (i=sumn; i<n; i++) 
	    sol[i]=buff[invq[i]];
	invq+=sumn;
	buff-=n+sumn-1;
	
      }
      else {
	LUSOL(&nB, buff+n+sumn,buff+sumn, next->LU.a,next->LU.ja,next->LU.ia);
	/* reorder the whole system back */
	sol+=sumn-1;
	buff+=sumn;
	for (i=0; i<nB; i++) 
	    sol[next->LUperm[i]]=buff[i];
	buff-=sumn;
	sol-=sumn-1;
	
      }
      if (lev>1) {
	 colscal=next->colscal-sumn;
	 for (i=sumn; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	     sol[i]*=colscal[i];
#else
	     val=sol[i].r;
	     sol[i].r=val*colscal[i].r-sol[i].i*colscal[i].i;
	     sol[i].i=val*colscal[i].i+sol[i].i*colscal[i].r;
#endif
	 } // end for i
      } /* end if */
      
   } /* end if-else (next->LU.ja==NULL) */



   /* block backward substitution */
   lev=nlev-1;
   while (lev>0) {
	 nB=prev->nB;
	 invq=prev->invq;
	 
	 if (param&COARSE_REDUCE) {
	    /* copy r.h.s */
	    for (i=sumn; i<n; i++)
	        buff[i]=sol[i];

	    /* second block */
	    CSRMATVEC(prev->F,sol+sumn,buff+sumn-nB);

	    /* first block */
	    sumn-=nB;
	    j=prev->LU.ja[nB];
	    prev->LU.ja[nB]=prev->LU.nnz+1;
	    ILUCSOL(&nB, buff+sumn,sol+sumn, prev->LU.a,prev->LU.ja,prev->LU.ia);
	    prev->LU.ja[nB]=j;

	    /* update solution */ 
	    buff+=sumn;
	    sol+=sumn;
	    for (i=0; i<nB; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	        buff[i]=buff[n+i]-sol[i];
#else
		buff[i].r=buff[n+i].r-sol[i].r;
		buff[i].i=buff[n+i].i-sol[i].i;
#endif
	    } // end for i
	    sol-=sumn;
	    buff-=sumn;

	    /* reorder the whole system */
	    buff+=sumn-1;
	    invq-=sumn;
	    for (i=sumn; i<n; i++)
	        sol[i]=buff[invq[i]];
	    invq+=sumn;
	    buff-=sumn-1;
	 }
	 else {
	    /* copy r.h.s */
	    buff+=n;
	    for (i=sumn; i<n; i++)
	        buff[i]=sol[i];
	    buff-=n;

	    sumn-=nB;

	    i=n-sumn;
	    j=prev->LU.ja[nB];
	    prev->LU.ja[nB]=prev->LU.nnz+1;
	    PILUCDUSOL(&i,&nB, buff+n+sumn,buff+n+sumn, prev->LU.a,prev->LU.ja,prev->LU.ia);
	    prev->LU.ja[nB]=j;

	    /* reorder the whole system */
	    buff+=n+sumn-1;
	    invq-=sumn;
	    for (i=sumn; i<n; i++)
	        sol[i]=buff[invq[i]];
	    invq+=sumn;
	    buff-=n+sumn-1;
	 } // end else


	 if (lev>1) {
	    colscal=prev->colscal-sumn;
	    for (i=sumn; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	        sol[i]*=colscal[i];
#else
		val=sol[i].r;
		sol[i].r=val*colscal[i].r-sol[i].i*colscal[i].i;
		sol[i].i=val*colscal[i].i+sol[i].i*colscal[i].r;
#endif
	    } // end for i
	 } /* end if */

	 next=prev;
	 prev=prev->prev;
	 lev--;
   } /* end while */

} /* end AMGsol */


