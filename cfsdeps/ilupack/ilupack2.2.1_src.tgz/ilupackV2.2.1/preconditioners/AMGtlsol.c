#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>


#include <ilupack.h>

#include <ilupackmacros.h>

#define MAX_LINE        255
#define STDERR          stderr
#define STDOUT          stdout
#define PRINT_INFO
#define MAX(A,B)        (((A)>(B))?(A):(B))
#define MIN(A,B)        (((A)<(B))?(A):(B))








/*
   Given a multilevel ILU decomposition, AMGsol performs a simple
   TRANSPOSED forward substitution
*/ 
void AMGTLSOL(AMGLEVELMAT *PRE, ILUPACKPARAM *IPparam,
	     FLOAT *rhs, FLOAT *sol, FLOAT *buff)
{
/*
   PRE       linked list of multilevel ILU preconditioners
   nlev      number of levels (blocks)
   rhs       given right hand side
   sol       solution obtained by AMGtsol
   buff      work array of length 3n, where n is the size of the original 
             matrix
  
   Code written by Matthias Bollhoefer, May/November 2003, November 2004
*/

   AMGLEVELMAT *next, *prev;

   integer i, n=PRE->n, nB, *p, *invq, sumn=0, lev, param, ierr, nlev=PRE->nlev;

   FLOAT *rowscal, *colscal;
   REALS val;
   character uplo, trans, diag;

   param=IPparam->ipar[6];

   buff+=n;
   for (i=0; i<n; i++)
       buff[i]=rhs[i];
   buff-=n;

   /* block forward substitution */
   next=PRE;
   prev=NULL;
   lev=1;
   while (lev<nlev) {
	 nB=next->nB;
	 p=next->p;
 
	 sumn+=nB;

	 prev=next;
	 next=next->next;
	 lev++;
   } /* end while */

   /* last level */
   nB=next->nB;
   p=next->p;
   

   /* -----   last block   ----- */

   /* did we finally switch to full matrix processing? */
   if (lev>1 && next->LU.ja==NULL) {
      LUPQUSOL(&nB, next->LU.a,next->LUperm,next->LU.ia, buff+n+sumn,sol+sumn, buff); 
   }
   else {
      if (next->LUperm==NULL) {
	 ILUCTLSOL(&nB, buff+n+sumn,buff+sumn, next->LU.a,next->LU.ja,next->LU.ia); 
	 
	 /* reorder the whole system back */
	 sol+=sumn-1;
	 p-=sumn;
	 for (i=sumn; i<n; i++) 
	     sol[p[i]]=buff[i];
	 p+=sumn;
	 sol-=sumn-1;
	 
      }
      else {
	 LUTLSOL(&nB, buff+n+sumn,sol+sumn, next->LU.a,next->LU.ja,next->LU.ia);
      }
      if (lev>1) {
	 rowscal=next->rowscal-sumn;
	 for (i=sumn; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	     sol[i]*=rowscal[i];
#else
	     val=sol[i].r;
	     sol[i].r=val*rowscal[i].r-sol[i].i*rowscal[i].i;
	     sol[i].i=val*rowscal[i].i+sol[i].i*rowscal[i].r;
#endif
	 } // end for i
      } /* end if */
      
   } /* end if-else (next->LU.ja==NULL) */



   /* block backward substitution */
   lev=nlev-1;
   while (lev>0) {
	 nB=prev->nB;
	 p=prev->p;
	 
	 if (param&COARSE_REDUCE) {
	    /* copy r.h.s */
	    for (i=sumn; i<n; i++)
	        buff[i]=sol[i];

	    /* second block */
	    CSRMATTVEC(prev->E,sol+sumn,buff+sumn-nB);

	    /* first block */
	    sumn-=nB;
	    ILUCTDUSOL(&nB, buff+sumn,sol+sumn, prev->LU.a,prev->LU.ja,prev->LU.ia);

	    /* update solution */ 
	    buff+=n+sumn;
	    sol+=sumn;
	    for (i=0; i<nB; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	        buff[i]=buff[i]-sol[i];
#else
		buff[i].r=buff[i].r-sol[i].r;
		buff[i].i=buff[i].i-sol[i].i;
#endif
	    } // end for i
	    sol-=sumn;
	    buff-=n+sumn;

	    // transposed forward solve
	    ILUCTLSOL(&nB, buff+n+sumn,buff+sumn, prev->LU.a,prev->LU.ja,prev->LU.ia);

	    /* reorder the whole system */
	    sol+=sumn-1;
	    p-=sumn;
	    for (i=sumn; i<n; i++)
	        sol[p[i]]=buff[i];
	    p+=sumn;
	    sol-=sumn-1;
	 } // end if
	 else {
	    /* copy r.h.s */
	    buff+=n;
	    for (i=sumn; i<n; i++)
	        buff[i]=sol[i];
	    buff-=n;

	    sumn-=nB;

	    i=n-sumn;
	    PILUCTLSOL(&i,&nB, buff+n+sumn,buff+n+sumn, prev->LU.a,prev->LU.ja,prev->LU.ia);

	    /* reorder the whole system */
	    buff+=n;
	    sol+=sumn-1;
	    p-=sumn;
	    for (i=sumn; i<n; i++)
	        sol[p[i]]=buff[i];
	    p+=sumn;
	    sol-=sumn-1;
	    buff-=n;
	 } // end if-else COARSE_REDUCE


	 if (lev>1) {
	    rowscal=prev->rowscal-sumn;
	    for (i=sumn; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	        sol[i]*=rowscal[i];
#else
		val=sol[i].r;
		sol[i].r=val*rowscal[i].r-sol[i].i*rowscal[i].i;
		sol[i].i=val*rowscal[i].i+sol[i].i*rowscal[i].r;
#endif
	    } // end for i
	 } /* end if */

	 next=prev;
	 prev=prev->prev;
	 lev--;
   } /* end while */

} /* end AMGtlsol */
