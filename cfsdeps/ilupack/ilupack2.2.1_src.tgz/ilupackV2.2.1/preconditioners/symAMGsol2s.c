#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
#define _COMPLEX_SYMMETRIC_
#include "symAMGsol2.c"
#else
void myilupackdummy105()
{
  // nothing     
}
#endif
