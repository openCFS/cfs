#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
#define _COMPLEX_SYMMETRIC_
#include "symAMGextract.c"
#else
void myilupackdummy41()
{
}
#endif
