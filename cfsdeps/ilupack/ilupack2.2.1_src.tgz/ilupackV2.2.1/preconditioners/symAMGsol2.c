#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include <blas.h>
#include <lapack.h>
#include <ilupack.h>
#include <ilupackmacros.h>

#define MAX_LINE        255
#define STDERR          stderr
#define STDOUT          stdout
// #define PRINT_INFO

#define IABS(A)         (((A)>=0)?(A):-(A))
#define MAX(A,B)        (((A)>(B))?(A):(B))
#define MIN(A,B)        (((A)<(B))?(A):(B))

#ifdef _SKEW_MATRIX_
#define SKEW(A)      (-(A))
#else
#define SKEW(A)      (A)
#endif

#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
#define CONJG(A)      (A)
#define MYCSRMATVEC          CSRMATVEC 
#define MYCSRMATTVEC         CSRMATTVEC 

#ifdef _DOUBLE_REAL_
#define MYSYMAMGSOL          DSYMAMGsol
#define MYSYMAMGSOL1         DSYMAMGsol1
#define MYSYMAMGSOL2         DSYMAMGsol2
#define MYSYMPILUCSOL        DSYMpilucsol
#define MYSYMPILUCLSOL       DSYMpiluclsol
#define MYSYMPILUCUSOL       DSYMpilucusol
#define MYPSYMPILUCLSOL      DSYMppiluclsol
#define MYPSYMPILUCUSOL      DSYMppilucusol
#define MYSPTRS              dsptrs
#define MYSMATVEC            DSYMmatvec
#define MYSYMBUILDBLOCK      DSYMbuildblock
#else			   
#define MYSYMAMGSOL          SSYMAMGsol
#define MYSYMAMGSOL1         SSYMAMGsol1
#define MYSYMAMGSOL2         SSYMAMGsol2
#define MYSYMPILUCSOL        SSYMpilucsol
#define MYSYMPILUCLSOL       SSYMpiluclsol
#define MYSYMPILUCUSOL       SSYMpilucusol
#define MYPSYMPILUCLSOL      SSYMppiluclsol
#define MYPSYMPILUCUSOL      SSYMppilucusol
#define MYSPTRS              ssptrs
#define MYSMATVEC            SSYMmatvec
#define MYSYMBUILDBLOCK      SSYMbuildblock
#endif



#else



#ifdef _COMPLEX_SYMMETRIC_
#define CONJG(A)     (A)
#define MYCSRMATVEC          CSRMATVEC 
#define MYCSRMATTVEC         CSRMATTVEC 

#ifdef _SINGLE_COMPLEX_
#define MYSYMAMGSOL          CSYMAMGsol
#define MYSYMAMGSOL1         CSYMAMGsol1
#define MYSYMAMGSOL2         CSYMAMGsol1
#define MYSYMPILUCSOL        CSYMpilucsol
#define MYSYMPILUCLSOL       CSYMpiluclsol
#define MYSYMPILUCUSOL       CSYMpilucusol
#define MYPSYMPILUCLSOL      CSYMppiluclsol
#define MYPSYMPILUCUSOL      CSYMppilucusol
#define MYSPTRS              csptrs
#define MYSMATVEC            CSYMmatvec
#define MYSYMBUILDBLOCK      CSYMbuildblock
#else
#define MYSYMAMGSOL          ZSYMAMGsol
#define MYSYMAMGSOL1         ZSYMAMGsol1
#define MYSYMAMGSOL2         ZSYMAMGsol2
#define MYSYMPILUCSOL        ZSYMpilucsol
#define MYSYMPILUCLSOL       ZSYMpiluclsol
#define MYSYMPILUCUSOL       ZSYMpilucusol
#define MYPSYMPILUCLSOL      ZSYMppiluclsol
#define MYPSYMPILUCUSOL      ZSYMppilucusol
#define MYSPTRS              zsptrs
#define MYSMATVEC            ZSYMmatvec
#define MYSYMBUILDBLOCK      ZSYMbuildblock
#endif

#else
#define MYCSRMATVEC          CSRMATVEC 
#define MYCSRMATTVEC         CSRMATHVEC 

#ifdef _SINGLE_COMPLEX_
#define CONJG(A)             (-(A))
#define MYSYMAMGSOL          CHERAMGsol
#define MYSYMAMGSOL1         CHERAMGsol1
#define MYSYMAMGSOL2         CHERAMGsol2
#define MYSYMPILUCSOL        CHERpilucsol
#define MYSYMPILUCLSOL       CHERpiluclsol
#define MYSYMPILUCUSOL       CHERpilucusol
#define MYPSYMPILUCLSOL      CHERppiluclsol
#define MYPSYMPILUCUSOL      CHERppilucusol
#define MYSPTRS              chptrs
#define MYSMATVEC            CHERmatvec
#define MYSYMBUILDBLOCK      CHERbuildblock
#else
#define CONJG(A)             (-(A))
#define MYSYMAMGSOL          ZHERAMGsol
#define MYSYMAMGSOL1         ZHERAMGsol1
#define MYSYMAMGSOL2         ZHERAMGsol2
#define MYSYMPILUCSOL        ZHERpilucsol
#define MYSYMPILUCLSOL       ZHERpiluclsol
#define MYSYMPILUCUSOL       ZHERpilucusol
#define MYPSYMPILUCLSOL      ZHERppiluclsol
#define MYPSYMPILUCUSOL      ZHERppilucusol
#define MYSMATVEC            ZHERmatvec
#define MYSYMBUILDBLOCK      ZHERbuildblock
#define MYSPTRS              zhptrs
#endif

#endif



#endif


/*
   Given a multilevel ILU decomposition, AMGsol2 performs a recursive
   full multigrid solve with several pre- and post-smoothing options
*/ 
void MYSYMAMGSOL2(AMGLEVELMAT *PRE, integer lev, 
		  integer n, integer nbf, integer sumn, integer sumlev,
		  ILUPACKPARAM *IPparam, FLOAT *sol, FLOAT *buff)
{

/*
   PRE       linked list of multilevel ILU preconditioners
   nlev      number of levels (blocks)
   lev       current level (block)
   n         total size
   sumn      sum over all previous leading blocks so far
   sumlev    sum over all previous remaining blocks so far
   IPparam   ILUPACK parameters
   sol       on input: given right hand side, on output: solution
   buff      work array of length max(3n, sum_{lev=2}^{nlev} nB), where n 
             is the size of the original matrix
  
   Code written by Matthias Bollhoefer,   November 2005,   February, March 2006
*/

   AMGLEVELMAT *next, *prev;
   CSRMAT A;

   integer i,i2,j,k,l,nnzU,m=IPparam->ipar[11],r, nB, *p, *invq, param, ierr, flagspd,
     flag, PILUCparam, nlev=PRE->nlev;

   FLOAT *scal, buff_rhs, *a, aii, aiip1,aip1ip1, det, buff1,buff2,ve;
   REALS val,  vali,  vb,  vc,  vd,  buffr,  buffi;
   character uplo, trans, diag;
#ifdef PRINT_INFO
   static int check=1;

   if (check) {
     check=0;
#ifdef _SINGLE_REAL_ 
     printf("SSYM2 solve\n");
#else
#ifdef _DOUBLE_REAL_
     printf("DSYM2 solve\n");
#else
#ifdef _SINGLE_COMPLEX_
#ifdef _COMPLEX_SYMMETRIC_
     printf("CSYM2 solve\n");
#else
     printf("CHER2 solve\n");
#endif
#else
#ifdef _COMPLEX_SYMMETRIC_
     printf("ZSYM2 solve\n");
#else
     printf("ZHER2 solve\n");
#endif
#endif
#endif
#endif
   }
#endif

   param=IPparam->ipar[6];
   PILUCparam=IPparam->ipar[16];

   if ((IPparam->ipar[14]==4) && !(PILUCparam&COARSE_REDUCE)) {
     printf("Error! Multigrid AMG solver. For ILU smoother option the switch `COARSE_REDUCE' must be set before factorizing the matrix\n");
     fflush(stdout);
     return ;
   }

   
   // size of the leading block
   nB=PRE->nB;
   // row permutation
   p   =PRE->p;
   // inverse column permutation
   invq=PRE->invq;

   /* last but first level */
   if (lev==nlev-1) {
      /* if the last level uses direct solve, then only one recursive call
	 is useful, since the system is exactly solved.
         Moreover, the exact coarse grid system is not stored. In this case
	 the matrix-vector multiplication (in case m>1) would lead to an error
      */
      if (PRE->next->LU.ja==NULL)
         m=MIN(m,1);
   }

   if (lev<nlev) {


      // **********************************************************************
      // pre smoothing

      for (j=0; j<IPparam->ipar[12]; j++) {

  	  // sol = sol - A *sol
	  if (j>0) {
	     MYSMATVEC(PRE->A,sol+sumn,buff+sumn);
#ifdef PRINT_INFO	     
	     val=0;
#endif
	     for (i=sumn; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	         sol[i]=buff[n+i]-buff[i];
#ifdef PRINT_INFO	     
		 val+=sol[i]*sol[i];
#endif
#else
		 sol[i].r=buff[n+i].r-buff[i].r;
		 sol[i].i=buff[n+i].i-buff[i].i;
#ifdef PRINT_INFO	     
		 val+=sol[i].r*sol[i].r+sol[i].i*sol[i].i;
#endif
#endif
	     } // end for i
#ifdef PRINT_INFO	     
	     printf("level %d, pre-smoothing step %d, res=%8.1le\n",lev,j,sqrt(val));fflush(stdout);
#endif
	  } // end if (j>0)


	  // make a copy of the initial right hand side before applying the smoother
#ifdef PRINT_INFO	     
	  val=0;
#endif
	  for (i=sumn; i<n; i++) {
	      buff[n+i]=sol[i];
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
#ifdef PRINT_INFO	     
	      val+=buff[n+i]*buff[n+i];
#endif
#else
#ifdef PRINT_INFO	     
	      val+=buff[n+i].r*buff[n+i].r+buff[n+i].i*buff[n+i].i;
#endif
#endif
	  }
#ifdef PRINT_INFO	     
	  if (j==0) printf("level %d, pre-smoothing step %d, res=%8.1le\n",lev,j,sqrt(val));fflush(stdout);
#endif



#ifdef PRINT_INFO	     
	  val=0;
#endif
	  /* reorder the whole system */
	  p-=sumn;
	  for (i=sumn; i<n; i++) {
	      buff[i]=sol[sumn+p[i]-1];
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
#ifdef PRINT_INFO	     
	      val+=buff[i]*buff[i];
#endif
#else
#ifdef PRINT_INFO	     
	      val+=buff[i].r*buff[i].r+buff[i].i*buff[i].i;
#endif
#endif
	  }
	  p+=sumn;
#ifdef PRINT_INFO2	     
	  printf("level %d, pre-smoothing step %d, res=%8.1le after permutation\n",lev,j,sqrt(val));fflush(stdout);
#endif




	  /*
	     ipar[14]    type of pre-smoother
	     default: 1  (block) Gauss-Seidel forward
	              2  (block) Gauss-Seidel backward
		      3  (damped block) Jacobi
		      4  ILU
		      5  custom
	  */
	  // Gauss-Seidel forward
	  if (IPparam->ipar[14]==1) {
#ifdef PRINT_INFO	     
	     printf("level %d, Gauss-Seidel forward\n",lev);fflush(stdout);
#endif
	     // remember that the system is already scaled and reordered as
	     // part of the multilevel process

	     for (i=sumn; i<n; i++) {
	         i2=PRE->nextblock[i-sumn];
		 if (i2<0) {
		    val=1;
		    vb=0;
		    buffr=0;
		    buffi=0;
		    r=p[i-sumn];
		    for (k=PRE->A.ia[r-1]; k<PRE->A.ia[r]; k++) {
		        l=PRE->A.ja[k-1]-1;
			l=sumn+invq[l]-1;
			// A(p(i),q(i))?
			if (l==i) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			   val=PRE->A.a[k-1];
#else
			   val=PRE->A.a[k-1].r;
			   vb =PRE->A.a[k-1].i;
#endif
			}
			/* Gauss-Seidel forward substitution
			   Remember that except for the diagonal part, only half of
			   the matrix is stored. This has to be compensated by a 
			   simple row-wise forward substitution for the effective
			   lower triangular part and by a rank-1 update for the 
			   remaining upper triangular part
			*/
			else if (l<i) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			   buffr+=PRE->A.a[k-1]*buff[l];
#else
			   buffr+=PRE->A.a[k-1].r*buff[l].r-PRE->A.a[k-1].i*buff[l].i;
			   buffi+=PRE->A.a[k-1].r*buff[l].i+PRE->A.a[k-1].i*buff[l].r;
#endif
			}
		    } // end for k
		    // final division by the diagonal entry
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		    buff[i]=(buff[i]-buffr)/val;
#else
		    vc=1.0/(val*val+vb*vb);
		    buff[i].r-=buffr;
		    buff[i].i-=buffi;
		    vd=buff[i].r;
		    buff[i].r=( vd*val+buff[i].i*vb) *vc;
		    buff[i].i=(-vd*vb +buff[i].i*val)*vc;
#endif		 

		    // store current rhs on entry
		    buff_rhs=buff[i];
		    for (k=PRE->A.ia[r-1]; k<PRE->A.ia[r]; k++) {
		        l=PRE->A.ja[k-1]-1;
			l=sumn+invq[l]-1;
			if (l>i) { 
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			   buff[l]-=PRE->A.a[k-1]*buff_rhs;
#else
			   buff[l].r-=SKEW(PRE->A.a[k-1].r)*buff_rhs.r
			             -SKEW(CONJG(PRE->A.a[k-1].i))*buff_rhs.i;
			   buff[l].i-=SKEW(PRE->A.a[k-1].r)*buff_rhs.i
			             +SKEW(CONJG(PRE->A.a[k-1].i))*buff_rhs.r;
#endif
			}
		    } // end for k
		 } // end if i2<0
		 // i2>=0
		 else {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		    aii=1.0;  
		    aiip1=0.0;
		    aip1ip1=1.0;
		    buff1=0.0;
		    buff2=0.0;
#else
		    aii.r=1.0;     aii.i=0.0;     
		    aiip1.r=0.0;   aiip1.i=0.0;   
		    aip1ip1.r=1.0; aip1ip1.i=0.0; 
		    buff1.r=0.0;   buff1.i=0.0;   
		    buff2.r=0.0;   buff2.i=0.0;   
#endif
		    r=p[i-sumn];
		    for (k=PRE->A.ia[r-1]-1; k<PRE->A.ia[r]-1; k++) {
		        l=PRE->A.ja[k]-1;
			l=sumn+invq[l]-1;
			// A(p(i),q(i))?
			if (l==i) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			   aii=PRE->A.a[k];
#else
			   aii.r=PRE->A.a[k].r;
			   aii.i=PRE->A.a[k].i;
#endif
			}
			else if (l==i+1) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			   aiip1=PRE->A.a[k];
#else
			   aiip1.r=PRE->A.a[k].r;
			   aiip1.i=PRE->A.a[k].i;
#endif
			}
			/* Gauss-Seidel forward substitution
			   Remember that except for the diagonal part, only half of
			   the matrix is stored. This has to be compensated by a 
			   simple row-wise forward substitution for the effective
			   lower triangular part and by a rank-1 update for the 
			   remaining upper triangular part
			*/
			else if (l<i) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			   buff1+=PRE->A.a[k]*buff[l];
#else
			   buff1.r+=PRE->A.a[k].r*buff[l].r-PRE->A.a[k].i*buff[l].i;
			   buff1.i+=PRE->A.a[k].r*buff[l].i+PRE->A.a[k].i*buff[l].r;
#endif
			}
		    } // end for k
		    r=p[i+1-sumn];
		    for (k=PRE->A.ia[r-1]-1; k<PRE->A.ia[r]-1; k++) {
		        l=PRE->A.ja[k]-1;
			l=sumn+invq[l]-1;
			// A(p(i),q(i))?
			if (l==i) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			   aiip1=PRE->A.a[k];
#else
			   aiip1.r=SKEW(PRE->A.a[k].r);
			   aiip1.i=SKEW(CONJG(PRE->A.a[k].i));
#endif
			}
			else if (l==i+1) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			   aip1ip1=PRE->A.a[k];
#else
			   aip1ip1.r=PRE->A.a[k].r;
			   aip1ip1.i=PRE->A.a[k].i;
#endif
			}
			/* Gauss-Seidel forward substitution
			   Remember that except for the diagonal part, only half of
			   the matrix is stored. This has to be compensated by a 
			   simple row-wise forward substitution for the effective
			   lower triangular part and by a rank-1 update for the 
			   remaining upper triangular part
			*/
			else if (l<i) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			   buff2+=PRE->A.a[k]*buff[l];
#else
			   buff2.r+=PRE->A.a[k].r*buff[l].r-PRE->A.a[k].i*buff[l].i;
			   buff2.i+=PRE->A.a[k].r*buff[l].i+PRE->A.a[k].i*buff[l].r;
#endif
			}
		    } // end for k
		    // final division by the diagonal entry
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		    buff[i]  -=buff1;
		    buff[i+1]-=buff2;
		    det=1.0/(aii*aip1ip1-aiip1*aiip1);
		    ve=buff[i];
		    buff[i]  =(aip1ip1*ve-aiip1*buff[i+1])*det;
		    buff[i+1]=(-aiip1 *ve+aii  *buff[i+1])*det;
#else
		    buff[i].r  -=buff1.r;
		    buff[i].i  -=buff1.i;
		    buff[i+1].r-=buff2.r;
		    buff[i+1].i-=buff2.i;
		    det.r=(aii.r  *aip1ip1.r           -aii.i  *aip1ip1.i)
		         -(aiip1.r*SKEW(aiip1.r)       -aiip1.i*SKEW(CONJG(aiip1.i)));
		    det.i=(aii.r  *aip1ip1.i           +aii.i  *aip1ip1.r)
		         -(aiip1.r*SKEW(CONJG(aiip1.i))+aiip1.i*SKEW(aiip1.r));
		    vd=1.0/(det.r*det.r+det.i*det.i);
		    det.r*= vd;
		    det.i*=-vd;
		    ve=buff[i];
		    buff[i].r  =(aip1ip1.r*ve.r-aip1ip1.i*ve.i)
		               -(aiip1.r*buff[i+1].r-aiip1.i*buff[i+1].i);
		    buff[i].i  =(aip1ip1.r*ve.i+aip1ip1.i*ve.r)
		               -(aiip1.r*buff[i+1].i+aiip1.i*buff[i+1].r);
		    vc=buff[i].r;
		    buff[i].r  =buff[i].r*det.r-buff[i].i*det.i;
		    buff[i].i  =vc       *det.i+buff[i].i*det.r;

		    vc=buff[i+1].r;
		    buff[i+1].r=-(SKEW(aiip1.r) *ve.r-SKEW(CONJG(aiip1.i)) *ve.i)
                                +(aii.r  *buff[i+1].r-aii.i  *buff[i+1].i);
		    buff[i+1].i=-(SKEW(aiip1.r) *ve.i+SKEW(CONJG(aiip1.i)) *ve.r)
                                +(aii.r  *buff[i+1].i+aii.i  *vc);
		    vc=buff[i+1].r;
		    buff[i+1].r=buff[i+1].r*det.r-buff[i+1].i*det.i;
		    buff[i+1].i=vc         *det.i+buff[i+1].i*det.r;
#endif		 

		    // store current rhs on entry
		    buff_rhs=buff[i];
		    r=p[i-sumn];
		    for (k=PRE->A.ia[r-1]-1; k<PRE->A.ia[r]-1; k++) {
		        l=PRE->A.ja[k]-1;
			l=sumn+invq[l]-1;
			if (l>i+1) { 
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			   buff[l]-=PRE->A.a[k]*buff_rhs;
#else
			   buff[l].r-=PRE->A.a[k].r*buff_rhs.r-CONJG(PRE->A.a[k].i)*buff_rhs.i;
			   buff[l].i-=PRE->A.a[k].r*buff_rhs.i+CONJG(PRE->A.a[k].i)*buff_rhs.r;
#endif
			}
		    } // end for k
		    // store current rhs on entry
		    buff_rhs=buff[i+1];
		    r=p[i+1-sumn];
		    for (k=PRE->A.ia[r-1]-1; k<PRE->A.ia[r]-1; k++) {
		        l=PRE->A.ja[k]-1;
			l=sumn+invq[l]-1;
			if (l>i+1) { 
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			   buff[l]-=PRE->A.a[k]*buff_rhs;
#else
			   buff[l].r-=PRE->A.a[k].r*buff_rhs.r-CONJG(PRE->A.a[k].i)*buff_rhs.i;
			   buff[l].i-=PRE->A.a[k].r*buff_rhs.i+CONJG(PRE->A.a[k].i)*buff_rhs.r;
#endif
			}
		    } // end for k

		    i++;
		 } // end if-else i2<0
	     } // end for i
	  }
	  // Gauss-Seidel backward
	  else if (IPparam->ipar[14]==2) {
#ifdef PRINT_INFO	     
	     printf("level %d, Gauss-Seidel backward\n",lev);fflush(stdout);
#endif
	     // remember that the system is already scaled and reordered as
	     // part of the multilevel process

	     for (i=n-1; i>=sumn; i--) {
	         i2=PRE->nextblock[i-sumn];
		 if (i2<0) {
		    val=1;
		    vb=0;
		    buffr=0;
		    buffi=0;
		    r=p[i-sumn];
		    for (k=PRE->A.ia[r-1]; k<PRE->A.ia[r]; k++) {
		        l=PRE->A.ja[k-1]-1;
			l=sumn+invq[l]-1;
			// A(p(i),q(i))?
			if (l==i) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			   val=PRE->A.a[k-1];
#else
			   val=PRE->A.a[k-1].r;
			   vb =PRE->A.a[k-1].i;
#endif
			}
			/* Gauss-Seidel backward substitution
			   Remember that except for the diagonal part, only half of
			   the matrix is stored. This has to be compensated by a 
			   simple row-wise backward substitution for the effective
			   upper triangular part and by a rank-1 update for the 
			   remaining lower triangular part
			*/
			else if (l>i) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			  buffr+=PRE->A.a[k-1]*buff[l];
#else
			  buffr+=PRE->A.a[k-1].r*buff[l].r-PRE->A.a[k-1].i*buff[l].i;
			  buffi+=PRE->A.a[k-1].r*buff[l].i+PRE->A.a[k-1].i*buff[l].r;
#endif
			}
		    } // end for k
		    // final division by the diagonal entry
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		    buff[i]=(buff[i]-buffr)/val;
#else
		    vc=1.0/(val*val+vb*vb);
		    buff[i].r-=buffr;
		    buff[i].i-=buffi;
		    vd=buff[i].r;
		    buff[i].r=( vd*val+buff[i].i*vb) *vc;
		    buff[i].i=(-vd*vb +buff[i].i*val)*vc;
#endif		 

		    // store current rhs on entry
		    buff_rhs=buff[i];
		    for (k=PRE->A.ia[r-1]; k<PRE->A.ia[r]; k++) {
		        l=PRE->A.ja[k-1]-1;
			l=sumn+invq[l]-1;
			if (l<i) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			   buff[l]-=PRE->A.a[k-1]*buff_rhs;
#else
			   buff[l].r-=PRE->A.a[k-1].r*buff_rhs.r-CONJG(PRE->A.a[k-1].i)*buff_rhs.i;
			   buff[l].i-=PRE->A.a[k-1].r*buff_rhs.i+CONJG(PRE->A.a[k-1].i)*buff_rhs.r;
#endif
			}
		    } // end for k
		 } // end if i2<0
		 // i2>=0
		 else {
		    i--;
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		    aii=1.0;  
		    aiip1=0.0;
		    aip1ip1=1.0;
		    buff1=0.0;
		    buff2=0.0;
#else
		    aii.r=1.0;     aii.i=0.0;     
		    aiip1.r=0.0;   aiip1.i=0.0;   
		    aip1ip1.r=1.0; aip1ip1.i=0.0; 
		    buff1.r=0.0;   buff1.i=0.0;   
		    buff2.r=0.0;   buff2.i=0.0;   
#endif
		    r=p[i-sumn];
		    for (k=PRE->A.ia[r-1]-1; k<PRE->A.ia[r]-1; k++) {
		        l=PRE->A.ja[k]-1;
			l=sumn+invq[l]-1;
			// A(p(i),q(i))?
			if (l==i) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			   aii=PRE->A.a[k];
#else
			   aii.r=PRE->A.a[k].r;
			   aii.i=PRE->A.a[k].i;
#endif
			}
			else if (l==i+1) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			   aiip1=PRE->A.a[k];
#else
			   aiip1.r=PRE->A.a[k].r;
			   aiip1.i=PRE->A.a[k].i;
#endif
			}
			/* Gauss-Seidel backward substitution
			   Remember that except for the diagonal part, only half of
			   the matrix is stored. This has to be compensated by a 
			   simple row-wise forward substitution for the effective
			   lower triangular part and by a rank-1 update for the 
			   remaining upper triangular part
			*/
			else if (l>i+1) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			   buff1+=PRE->A.a[k]*buff[l];
#else
			   buff1.r+=PRE->A.a[k].r*buff[l].r-PRE->A.a[k].i*buff[l].i;
			   buff1.i+=PRE->A.a[k].r*buff[l].i+PRE->A.a[k].i*buff[l].r;
#endif
			}
		    } // end for k
		    r=p[i+1-sumn];
		    for (k=PRE->A.ia[r-1]-1; k<PRE->A.ia[r]-1; k++) {
		        l=PRE->A.ja[k]-1;
			l=sumn+invq[l]-1;
			// A(p(i),q(i))?
			if (l==i) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			   aiip1=PRE->A.a[k];
#else
			   aiip1.r=SKEW(PRE->A.a[k].r);
			   aiip1.i=SKEW(CONJG(PRE->A.a[k].i));
#endif
			}
			else if (l==i+1) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			   aip1ip1=PRE->A.a[k];
#else
			   aip1ip1.r=PRE->A.a[k].r;
			   aip1ip1.i=PRE->A.a[k].i;
#endif
			}
			/* Gauss-Seidel backward substitution
			   Remember that except for the diagonal part, only half of
			   the matrix is stored. This has to be compensated by a 
			   simple row-wise forward substitution for the effective
			   lower triangular part and by a rank-1 update for the 
			   remaining upper triangular part
			*/
			else if (l>i+1) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			   buff2+=PRE->A.a[k]*buff[l];
#else
			   buff2.r+=PRE->A.a[k].r*buff[l].r-PRE->A.a[k].i*buff[l].i;
			   buff2.i+=PRE->A.a[k].r*buff[l].i+PRE->A.a[k].i*buff[l].r;
#endif
			}
		    } // end for k
		    // final division by the diagonal entry
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		    buff[i]  -=buff1;
		    buff[i+1]-=buff2;
		    det=1.0/(aii*aip1ip1-aiip1*aiip1);
		    ve=buff[i];
		    buff[i]  =(aip1ip1*ve-aiip1*buff[i+1])*det;
		    buff[i+1]=(-aiip1 *ve+aii  *buff[i+1])*det;
#else
		    buff[i].r  -=buff1.r;
		    buff[i].i  -=buff1.i;
		    buff[i+1].r-=buff2.r;
		    buff[i+1].i-=buff2.i;
		    det.r=(aii.r  *aip1ip1.r           -aii.i  *aip1ip1.i)
		         -(aiip1.r*SKEW(aiip1.r)       -aiip1.i*SKEW(CONJG(aiip1.i)));
		    det.i=(aii.r  *aip1ip1.i           +aii.i  *aip1ip1.r)
		         -(aiip1.r*SKEW(CONJG(aiip1.i))+aiip1.i*SKEW(aiip1.r));
		    vd=1.0/(det.r*det.r+det.i*det.i);
		    det.r*= vd;
		    det.i*=-vd;
		    ve=buff[i];
		    buff[i].r  =(aip1ip1.r*ve.r-aip1ip1.i*ve.i)
		               -(aiip1.r*buff[i+1].r-aiip1.i*buff[i+1].i);
		    buff[i].i  =(aip1ip1.r*ve.i+aip1ip1.i*ve.r)
		               -(aiip1.r*buff[i+1].i+aiip1.i*buff[i+1].r);
		    vc=buff[i].r;
		    buff[i].r  =buff[i].r*det.r-buff[i].i*det.i;
		    buff[i].i  =vc       *det.i+buff[i].i*det.r;

		    vc=buff[i+1].r;
		    buff[i+1].r=-(SKEW(aiip1.r) *ve.r-SKEW(CONJG(aiip1.i)) *ve.i)
                                +(aii.r  *buff[i+1].r-aii.i  *buff[i+1].i);
		    buff[i+1].i=-(SKEW(aiip1.r) *ve.i+SKEW(CONJG(aiip1.i)) *ve.r)
                                +(aii.r  *buff[i+1].i+aii.i  *vc);
		    vc=buff[i+1].r;
		    buff[i+1].r=buff[i+1].r*det.r-buff[i+1].i*det.i;
		    buff[i+1].i=vc         *det.i+buff[i+1].i*det.r;
#endif		 

		    // store current rhs on entry
		    buff_rhs=buff[i];
		    r=p[i-sumn];
		    for (k=PRE->A.ia[r-1]-1; k<PRE->A.ia[r]-1; k++) {
		        l=PRE->A.ja[k]-1;
			l=sumn+invq[l]-1;
			if (l<i) { 
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			   buff[l]-=PRE->A.a[k]*buff_rhs;
#else
			   buff[l].r-=PRE->A.a[k].r*buff_rhs.r-CONJG(PRE->A.a[k].i)*buff_rhs.i;
			   buff[l].i-=PRE->A.a[k].r*buff_rhs.i+CONJG(PRE->A.a[k].i)*buff_rhs.r;
#endif
			}
		    } // end for k
		    // store current rhs on entry
		    buff_rhs=buff[i+1];
		    r=p[i+1-sumn];
		    for (k=PRE->A.ia[r-1]-1; k<PRE->A.ia[r]-1; k++) {
		        l=PRE->A.ja[k]-1;
			l=sumn+invq[l]-1;
			if (l<i) { 
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			   buff[l]-=PRE->A.a[k]*buff_rhs;
#else
			   buff[l].r-=PRE->A.a[k].r*buff_rhs.r-CONJG(PRE->A.a[k].i)*buff_rhs.i;
			   buff[l].i-=PRE->A.a[k].r*buff_rhs.i+CONJG(PRE->A.a[k].i)*buff_rhs.r;
#endif
			}
		    } // end for k
		 } // end if-else i2<0
	     } // end for i
	  }
	  // Jacobi
	  else if (IPparam->ipar[14]==3) {
#ifdef PRINT_INFO	     
	     printf("level %d, Jacobi\n",lev);fflush(stdout);
#endif
	     // remember that the system is already scaled and reordered as 
	     // part of the multilevel process

	     for (i=sumn; i<n; i++) {
	         i2=PRE->nextblock[i-sumn];
		 if (i2<0) {
		    val=1;
		    vb=0;
		    r=p[i-sumn];
		    for (k=PRE->A.ia[r-1]; k<PRE->A.ia[r]; k++) {
		        l=PRE->A.ja[k-1]-1;
			l=sumn+invq[l]-1;
			// A(p(i),q(i))?
			if (l==i) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			   val=PRE->A.a[k-1];
#else
			   val=PRE->A.a[k-1].r;
			   vb =PRE->A.a[k-1].i;
#endif
			   k=PRE->A.ia[r];
			}
		    } // end for k
		    // final division by the diagonal entry
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		    buff[i]/=val;
#else
		    vc=1.0/(val*val+vb*vb);
		    vd=buff[i].r;
		    buff[i].r=( vd*val+buff[i].i*vb) *vc;
		    buff[i].i=(-vd*vb +buff[i].i*val)*vc;
#endif 
		 } // end if i2<0
		 // i2>=0
		 else {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		    aii=1.0;  
		    aiip1=0.0;
		    aip1ip1=1.0;
		    buff1=0.0;
		    buff2=0.0;
#else
		    aii.r=1.0;     aii.i=0.0;     
		    aiip1.r=0.0;   aiip1.i=0.0;   
		    aip1ip1.r=1.0; aip1ip1.i=0.0; 
		    buff1.r=0.0;   buff1.i=0.0;   
		    buff2.r=0.0;   buff2.i=0.0;   
#endif
		    r=p[i-sumn];
		    for (k=PRE->A.ia[r-1]-1; k<PRE->A.ia[r]-1; k++) {
		        l=PRE->A.ja[k]-1;
			l=sumn+invq[l]-1;
			// A(p(i),q(i))?
			if (l==i) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			   aii=PRE->A.a[k];
#else
			   aii.r=PRE->A.a[k].r;
			   aii.i=PRE->A.a[k].i;
#endif
			}
			else if (l==i+1) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			   aiip1=PRE->A.a[k];
#else
			   aiip1.r=PRE->A.a[k].r;
			   aiip1.i=PRE->A.a[k].i;
#endif
			}
		    } // end for k
		    r=p[i+1-sumn];
		    for (k=PRE->A.ia[r-1]-1; k<PRE->A.ia[r]-1; k++) {
		        l=PRE->A.ja[k]-1;
			l=sumn+invq[l]-1;
			// A(p(i),q(i))?
			if (l==i) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			   aiip1=PRE->A.a[k];
#else
			   aiip1.r=SKEW(PRE->A.a[k].r);
			   aiip1.i=SKEW(CONJG(PRE->A.a[k].i));
#endif
			}
			else if (l==i+1) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			   aip1ip1=PRE->A.a[k];
#else
			   aip1ip1.r=PRE->A.a[k].r;
			   aip1ip1.i=PRE->A.a[k].i;
#endif
			}
		    } // end for k
		    // final division by the diagonal entry
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		    det=1.0/(aii*aip1ip1-aiip1*aiip1);
		    ve=buff[i];
		    buff[i]  =(aip1ip1*ve-aiip1*buff[i+1])*det*IPparam->damping;
		    buff[i+1]=(-aiip1 *ve+aii  *buff[i+1])*det*IPparam->damping;
#else
		    det.r=(aii.r  *aip1ip1.r           -aii.i  *aip1ip1.i)
		         -(aiip1.r*SKEW(aiip1.r)       -aiip1.i*SKEW(CONJG(aiip1.i)));
		    det.i=(aii.r  *aip1ip1.i           +aii.i  *aip1ip1.r)
		         -(aiip1.r*SKEW(CONJG(aiip1.i))+aiip1.i*SKEW(aiip1.r));
		    vd=1.0/(det.r*det.r+det.i*det.i);
		    det.r*= vd;
		    det.i*=-vd;
		    ve=buff[i];
		    buff[i].r  =(aip1ip1.r*ve.r-aip1ip1.i*ve.i)
		               -(aiip1.r*buff[i+1].r-aiip1.i*buff[i+1].i);
		    buff[i].i  =(aip1ip1.r*ve.i+aip1ip1.i*ve.r)
		               -(aiip1.r*buff[i+1].i+aiip1.i*buff[i+1].r);
		    vc=buff[i].r;
		    buff[i].r  =buff[i].r*det.r-buff[i].i*det.i;
		    buff[i].i  =vc       *det.i+buff[i].i*det.r;

		    vc=buff[i+1].r;
		    buff[i+1].r=-(SKEW(aiip1.r) *ve.r-SKEW(CONJG(aiip1.i)) *ve.i)
                                +(aii.r  *buff[i+1].r-aii.i  *buff[i+1].i);
		    buff[i+1].i=-(SKEW(aiip1.r) *ve.i+SKEW(CONJG(aiip1.i)) *ve.r)
                                +(aii.r  *buff[i+1].i+aii.i  *vc);
		    vc=buff[i+1].r;
		    buff[i+1].r=buff[i+1].r*det.r-buff[i+1].i*det.i;
		    buff[i+1].i=vc         *det.i+buff[i+1].i*det.r;
		    // damping factor
		    val=IPparam->damping.r;
		    vb =IPparam->damping.i;
		    vd=buff[i].r;		 
		    buff[i].r=vd*val-buff[i].i*vb;
		    buff[i].i=vd*vb +buff[i].i*val;
		    vd=buff[i+1].r;		 
		    buff[i+1].r=vd*val-buff[i+1].i*vb;
		    buff[i+1].i=vd*vb +buff[i+1].i*val;
#endif		 

		    i++;
		 } // i2<0
	     } // end for i
	  }
	  // associated partial ILU
	  else if (IPparam->ipar[14]==4) {
#ifdef PRINT_INFO	     
	     printf("level %d, ILU\n",lev);fflush(stdout);
#endif
	     nnzU=PRE->LU.ja[nB];
	     PRE->LU.ja[nB]=PRE->LU.nnz+1;
	     MYSYMPILUCSOL(&nB, buff+sumn,buff+sumn, PRE->LU.a,PRE->LU.ja);
	     PRE->LU.ja[nB]=nnzU;
	     for (i=sumn+nB; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		 buff[i]=0;
#else
		 buff[i].r=0;
		 buff[i].i=0;
#endif		 
	     } // end for i
	  }

#ifdef PRINT_INFO2
	  val=0;
	  for (i=sumn; i<n; i++)
	      val+=buff[i]*buff[i];
	  printf("level %d, pre-smoothing step %d, res=%8.1le after Gau�-Seidel\n",lev,j,sqrt(val));fflush(stdout);
#endif

	  /* reorder the whole system */
#ifdef PRINT_INFO
	  val=0;
#endif
	  buff+=sumn-1;
	  invq-=sumn;
	  for (i=sumn; i<n; i++) {
	      sol[i]=buff[invq[i]];
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
#ifdef PRINT_INFO
	      val+=sol[i]*sol[i];
#endif
#else
#ifdef PRINT_INFO	     
	      val+=sol[i].r*sol[i].r+sol[i].i*sol[i].i;
#endif
#endif
	  }
	  invq+=sumn;
	  buff-=sumn-1;
#ifdef PRINT_INFO2
	  printf("level %d, pre-smoothing step %d, res=%8.1le after permutation\n",lev,j,sqrt(val));fflush(stdout);
#endif



#ifdef PRINT_INFO	     
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	  if (j==IPparam->ipar[12]-1) {
	     MYSMATVEC(PRE->A,sol+sumn,buff+sumn);
	     
	     val=0;
	     for (i=sumn; i<n; i++) {
	         buff[i]=buff[n+i]-buff[i];
		 val+=buff[i]*buff[i];
	     } // end for i
	     printf("level %d, pre-smoothing step %d, res=%8.1le\n",lev,j+1,sqrt(val));fflush(stdout);
	  }
#else
	  if (j==IPparam->ipar[12]-1) {
	     MYSMATVEC(PRE->A,sol+sumn,buff+sumn);
	     
	     val=0;
	     for (i=sumn; i<n; i++) {
	         buff[i].r=buff[n+i].r-buff[i].r;
	         buff[i].i=buff[n+i].i-buff[i].i;
		 val+=buff[i].r*buff[i].r+buff[i].i*buff[i].i;
	     } // end for i
	     printf("level %d, pre-smoothing step %d, res=%8.1le\n",lev,j+1,sqrt(val));fflush(stdout);
	  }
#endif
#endif

	  if (j>0) {
	     for (i=sumn,k=sumlev; i<n; i++,k++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	         buff[2*n+nbf+k]+=sol[i];
#else
		 buff[2*n+nbf+k].r+=sol[i].r;
		 buff[2*n+nbf+k].i+=sol[i].i;
#endif
	     }
	  }
	  else { // j==0
	     for (i=sumn,k=sumlev; i<n; i++,k++) {
	         buff[2*n+nbf+k]=sol[i];
	     }
	  }

      } // end for j

      // end pre-smoothing
      // **********************************************************************





      // **********************************************************************
      // coarse grid correction

      // make a copy of the previous sol
      if (IPparam->ipar[12]>0) {
	 for (k=sumlev,i=sumn; i<n; i++,k++) 
	     buff[2*n+k]=buff[n+i];
      }

      for (j=0; j<m; j++) {

  	  // sol = sol_old - A *sol_new
	  if (j>0 || IPparam->ipar[12]>0) {
	     MYSMATVEC(PRE->A,sol+sumn,buff+sumn);
#ifdef PRINT_INFO	     
	     val=0;
#endif
	     for (i=sumn,k=sumlev; i<n; i++,k++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	         sol[i]=buff[2*n+k]-buff[i];
#ifdef PRINT_INFO	     
		 val+=sol[i]*sol[i];
#endif
#else
		 sol[i].r=buff[2*n+k].r-buff[i].r;
		 sol[i].i=buff[2*n+k].i-buff[i].i;
#ifdef PRINT_INFO	     
		 val+=sol[i].r*sol[i].r+sol[i].i*sol[i].i;
#endif
#endif
	     } // end for i
#ifdef PRINT_INFO	     
	     printf("level %d, coarse grid correction step %d, res=%8.1le\n",lev,j,sqrt(val));fflush(stdout);
#endif
	  } // end if (j>0 || IPparam->ipar[12]>0)


	  // make a copy of the initial right hand side before applying the smoother
#ifdef PRINT_INFO
	  val=0;
#endif
	  for (i=sumn,k=sumlev; i<n; i++,k++) {
	      buff[2*n+k]=sol[i];
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
#ifdef PRINT_INFO	     
	      val+=buff[2*n+k]*buff[2*n+k];
#endif
#else
#ifdef PRINT_INFO	     
	      val+=buff[2*n+k].r*buff[2*n+k].r+buff[2*n+k].i*buff[2*n+k].i;
#endif
#endif
	  }
#ifdef PRINT_INFO	     
	  if (j==0 && IPparam->ipar[12]==0) 
	     printf("level %d, coarse grid correction step %d, res=%8.1le\n",lev,j,sqrt(val));fflush(stdout);
#endif



	  /* block forward substitution */
     
	  /* reorder the whole system */
	  p-=sumn;
	  for (i=sumn; i<n; i++)
	      buff[i]=sol[sumn+p[i]-1];
	  p+=sumn;

	  /* first block */
	  if (param&COARSE_REDUCE) {
	     if (PRE->LU.ja[0]<0)
	        flagspd=-1;
	     else
	        flagspd=0;
	     PRE->LU.ja[0]=IABS(PRE->LU.ja[0]);

	     nnzU=PRE->LU.ja[nB];
	     PRE->LU.ja[nB]=PRE->LU.nnz+1;
	     if (flagspd) {
	        // printf("1.\n");fflush(stdout);
	        // solve system with [(L+D)D^{-1}]
	        MYSYMPILUCLSOL(&nB, buff+sumn,sol+sumn, PRE->LU.a,PRE->LU.ja);
		// printf("2.\n");fflush(stdout);
	     }
	     else
	        MYSYMPILUCSOL(&nB, buff+sumn,sol+sumn, PRE->LU.a,PRE->LU.ja);
	     PRE->LU.ja[nB]=nnzU;

	     if (flagspd) {
	        sol +=sumn;
		buff+=sumn;
		// multiply by D^{-1}
		i=0;
		a=PRE->LU.a;
		// printf("3.\n");fflush(stdout);
		while (i<nB) {
	              if (PRE->LU.ja[nB+1+i]==0) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			 buff[i]=sol[i]*a[i];
#else
			 buff[i].r=sol[i].r*a[i].r-sol[i].i*a[i].i;
			 buff[i].i=sol[i].r*a[i].i+sol[i].i*a[i].r;
#endif
			 i++;
		      }
		      else {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			 buff[i]  =a[i]            *sol[i]+a[nB+1+i]*sol[i+1];
			 buff[i+1]=a[nB+1+i]       *sol[i]+a[i+1]   *sol[i+1];
#else
			 buff[i].r  =a[i].r     *sol[i].r  -a[i].i     *sol[i].i
			            +a[nB+1+i].r*sol[i+1].r-a[nB+1+i].i*sol[i+1].i;
			 buff[i].i  =a[i].r     *sol[i].i  +a[i].i     *sol[i].r
		                    +a[nB+1+i].r*sol[i+1].i+a[nB+1+i].i*sol[i+1].r;
#ifdef _COMPLEX_SYMMETRIC_		     
			 buff[i+1].r=a[nB+1+i].r*sol[i].r  -a[nB+1+i].i*sol[i].i
		                    +a[i+1].r   *sol[i+1].r-a[i+1].i   *sol[i+1].i;
			 buff[i+1].i=a[nB+1+i].r*sol[i].i  +a[nB+1+i].i*sol[i].r
		                    +a[i+1].r   *sol[i+1].i+a[i+1].i   *sol[i+1].r;
#else
			 buff[i+1].r=a[nB+1+i].r*sol[i].r  +a[nB+1+i].i*sol[i].i
		                    +a[i+1].r   *sol[i+1].r-a[i+1].i   *sol[i+1].i;
			 buff[i+1].i=a[nB+1+i].r*sol[i].i  -a[nB+1+i].i*sol[i].r
		                    +a[i+1].r   *sol[i+1].i+a[i+1].i   *sol[i+1].r;
#endif
#endif
			 i+=2;
		      }
		} // end while
		// multiply by |D|^{-1}
		i=0;
		a=PRE->absdiag;
		// printf("4.\n");fflush(stdout);
		while (i<nB) {
	              if (PRE->LU.ja[nB+1+i]==0) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			 sol[i]*=a[i];
#else
			 val     =sol[i].r*a[i].r-sol[i].i*a[i].i;
			 sol[i].i=sol[i].r*a[i].i+sol[i].i*a[i].r;
			 sol[i].r=val;
#endif
			 i++;
		      }
		      else {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			 val     =a[i]            *sol[i]+a[nB+1+i]*sol[i+1];
			 sol[i+1]=a[nB+1+i]       *sol[i]+a[i+1]   *sol[i+1];
			 sol[i]  =val;
#else
			 val       =a[i].r     *sol[i].r  -a[i].i     *sol[i].i
		                   +a[nB+1+i].r*sol[i+1].r-a[nB+1+i].i*sol[i+1].i;
			 sol[i].i  =a[i].r     *sol[i].i  +a[i].i     *sol[i].r
		                   +a[nB+1+i].r*sol[i+1].i+a[nB+1+i].i*sol[i+1].r;
#ifdef _COMPLEX_SYMMETRIC_		     
			 vali      =a[nB+1+i].r*sol[i].r  -a[nB+1+i].i*sol[i].i
		                   +a[i+1].r   *sol[i+1].r-a[i+1].i   *sol[i+1].i;
			 sol[i+1].i=a[nB+1+i].r*sol[i].i  +a[nB+1+i].i*sol[i].r
		                   +a[i+1].r   *sol[i+1].i+a[i+1].i   *sol[i+1].r;
#else
			 vali      =a[nB+1+i].r*sol[i].r  +a[nB+1+i].i*sol[i].i
		                   +a[i+1].r   *sol[i+1].r-a[i+1].i   *sol[i+1].i;
			 sol[i+1].i=a[nB+1+i].r*sol[i].i  -a[nB+1+i].i*sol[i].r
		                   +a[i+1].r   *sol[i+1].i+a[i+1].i   *sol[i+1].r;
#endif
			 sol[i+1].r=vali;
			 sol[i].r  =val;
#endif
			 i+=2;
		      }
		} // end while
		// printf("5.\n");fflush(stdout);
		// solve system with [D^{-1}(D+U)]
		nnzU=PRE->LU.ja[nB];
		PRE->LU.ja[nB]=PRE->LU.nnz+1;
		MYSYMPILUCUSOL(&nB, buff,buff, PRE->LU.a,PRE->LU.ja);
		PRE->LU.ja[nB]=nnzU;
		// printf("6.\n");fflush(stdout);
		/* second block, multiply by E=F^H  */
		MYCSRMATTVEC(PRE->F,buff,sol+nB);
		// printf("7.\n");fflush(stdout);
		PRE->LU.ja[0]=-IABS(PRE->LU.ja[0]);
		sol -=sumn;
		buff-=sumn;
	     }
	     else
	        /* second block, multiply by E=F^* */
	        MYCSRMATTVEC(PRE->F,sol+sumn,sol+sumn+nB);

	     sumn+=nB;
	 
	     /* coarse grid projection */
	     for (i=sumn; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	         sol[i]=buff[i]-sol[i];
#else
		 sol[i].r=buff[i].r-sol[i].r;
		 sol[i].i=buff[i].i-sol[i].i;
#endif
	     } // end for i
	  } // end if
	  else { // U12 is kept and F is not accessed
	     i=n-sumn;
	     nnzU=PRE->LU.ja[nB];
	     PRE->LU.ja[nB]=PRE->LU.nnz+1;
	     MYPSYMPILUCLSOL(&i,&nB, buff+sumn,sol+sumn, PRE->LU.a,PRE->LU.ja);
	     PRE->LU.ja[nB]=nnzU;

	     sumn+=nB;
	     
	     /* coarse grid projection */
	     for (i=sumn; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	         sol[i]+=buff[i];
#else
		 sol[i].r+=buff[i].r;
		 sol[i].i+=buff[i].i;
#endif
	     } // end for i
	  } // end else


	  flag=-1;
	  // if the last level uses direct solve, then no scaling is required
	  if (lev==nlev-1) 
	     if (PRE->next->LU.ja==NULL) 
	        flag=0;

	  if (flag) {
	     // conjugate-transpose of the right scaling
	     scal=PRE->next->colscal;
	     for (i=sumn; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	         sol[i]*=scal[i-sumn];
#ifdef PRINT_INFO	     
		 val+=sol[i]*sol[i];
#endif
#else
		 val=sol[i].r;
		 sol[i].r=      val*scal[i-sumn].r
		          -sol[i].i*CONJG(scal[i-sumn].i);
		 sol[i].i=      val*CONJG(scal[i-sumn].i)
		          +sol[i].i*scal[i-sumn].r;
#ifdef PRINT_INFO	     
		 val+=sol[i].r*sol[i].r+sol[i].i*sol[i].i;
#endif
#endif
	     } // end for i
	  }

	  // coarse grid solve
	  MYSYMAMGSOL2(PRE->next,  lev+1,  n, nbf, sumn,  sumlev+nB+n-sumn, 
		       IPparam, sol, buff);

	  if (flag) {
	     // diagonal scaling from the right
	     scal=PRE->next->colscal;
	     for (i=sumn; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	         sol[i]*=scal[i-sumn];
#ifdef PRINT_INFO	     
		 val+=sol[i]*sol[i];
#endif
#else
		 val=sol[i].r;
		 sol[i].r=     val*scal[i-sumn].r
		         -sol[i].i*scal[i-sumn].i;
		 sol[i].i=     val*scal[i-sumn].i
		         +sol[i].i*scal[i-sumn].r;
#ifdef PRINT_INFO	     
		 val+=sol[i].r*sol[i].r+sol[i].i*sol[i].i;
#endif
#endif
	     } // end for i
	  }


	  // move approximate solution to buff
	  for (i=sumn; i<n; i++) 
	      buff[i]=sol[i];


	  // backward substitution
	  if (param&COARSE_REDUCE) {
	     /* second block, multiply by F */
	     MYCSRMATVEC(PRE->F,buff+sumn,buff+sumn-nB);

	     /* first block */
	     sumn-=nB;
	     // nnzU=PRE->LU.ja[nB];
	     // PRE->LU.ja[nB]=PRE->LU.nnz+1;
	     // ILDLCSOL(&nB, buff+sumn,buff+sumn, PRE->LU.a,PRE->LU.ja);
             // PRE->LU.ja[nB]=nnzU;

	     if (PRE->LU.ja[0]<0)
	        flagspd=-1;
	     else
	        flagspd=0;
	     PRE->LU.ja[0]=IABS(PRE->LU.ja[0]);

	     nnzU=PRE->LU.ja[nB];
	     PRE->LU.ja[nB]=PRE->LU.nnz+1;
	     if (flagspd) {
	        buff+=sumn;
		// printf("12.\n");fflush(stdout);
		MYSYMPILUCLSOL(&nB, buff,buff, PRE->LU.a,PRE->LU.ja);
		// printf("13.\n");fflush(stdout);
		i=0;
		a=PRE->LU.a;
		while (i<nB) {
	              if (PRE->LU.ja[nB+1+i]==0) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			 buff[i]*=a[i];
#else
			 val      =buff[i].r*a[i].r-buff[i].i*a[i].i;
			 buff[i].i=buff[i].r*a[i].i+buff[i].i*a[i].r;
			 buff[i].r=val;
#endif
			 i++;
		      }
		      else {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			val      =a[i]            *buff[i]+a[nB+1+i]*buff[i+1];
			buff[i+1]=a[nB+1+i]       *buff[i]+a[i+1]   *buff[i+1];
			buff[i]  =val;
#else
			val        =a[i].r     *buff[i].r  -a[i].i     *buff[i].i
		                   +a[nB+1+i].r*buff[i+1].r-a[nB+1+i].i*buff[i+1].i;
			buff[i].i  =a[i].r     *buff[i].i  +a[i].i     *buff[i].r
		                   +a[nB+1+i].r*buff[i+1].i+a[nB+1+i].i*buff[i+1].r;
#ifdef _COMPLEX_SYMMETRIC_		     
			vali       =a[nB+1+i].r*buff[i].r  -a[nB+1+i].i*buff[i].i
		                   +a[i+1].r   *buff[i+1].r-a[i+1].i   *buff[i+1].i;
			buff[i+1].i=a[nB+1+i].r*buff[i].i  +a[nB+1+i].i*buff[i].r
		                   +a[i+1].r   *buff[i+1].i+a[i+1].i   *buff[i+1].r;
#else
			vali       =a[nB+1+i].r*buff[i].r  +a[nB+1+i].i*buff[i].i
		                   +a[i+1].r   *buff[i+1].r-a[i+1].i   *buff[i+1].i;
			buff[i+1].i=a[nB+1+i].r*buff[i].i  -a[nB+1+i].i*buff[i].r
		                   +a[i+1].r   *buff[i+1].i+a[i+1].i   *buff[i+1].r;
#endif
			buff[i].r  =val;
			buff[i+1].r=vali;
#endif
			i+=2;
		      }
		} // end while
		// printf("14.\n");fflush(stdout);
		buff-=sumn;
	     }
	     else
	        MYSYMPILUCSOL(&nB, buff+sumn,buff+sumn, PRE->LU.a,PRE->LU.ja);
	     PRE->LU.ja[nB]=nnzU;



	     /* update solution */ 
	     buff+=sumn;
	     sol+=sumn;
	     // to be precise, we should keep '-buff' and not
	     // use 'sol-buff' in order to have correct multigrid
	     for (i=0; i<nB; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	         buff[i]=sol[i]-buff[i];
#else
		 buff[i].r=sol[i].r-buff[i].r;
		 buff[i].i=sol[i].i-buff[i].i;
#endif
	     } // end for i
	     if (flagspd) {
	        // printf("15.\n");fflush(stdout);
	        nnzU=PRE->LU.ja[nB];
	        PRE->LU.ja[nB]=PRE->LU.nnz+1;
		MYSYMPILUCUSOL(&nB, buff,buff, PRE->LU.a,PRE->LU.ja);
		PRE->LU.ja[nB]=nnzU;
		// printf("16.\n");fflush(stdout);
		PRE->LU.ja[0]=-IABS(PRE->LU.ja[0]);
	     }
	     sol-=sumn;
	     buff-=sumn;
	 
	     /* reorder the whole system */
	     buff+=sumn-1;
	     invq-=sumn;
	     for (i=sumn; i<n; i++)
	         sol[i]=buff[invq[i]];
	     invq+=sumn;
	     buff-=sumn-1;
	  }
	  else { // U12 is kept and F is not referenced
	     /* copy r.h.s */
	     sumn-=nB;
	     buff+=sumn;
	     sol +=sumn;
	     // note that in the sense of classical multigrid
	     // we should set buff:=0
	     // By restoring the old solution, the coarse grid
	     // correction behaves similar to AMLI
	     for (i=0; i<nB; i++)
	         buff[i]=sol[i];
	     buff-=sumn;
	     sol -=sumn;
	    

	     // block diagonal scaling using D^{-1}
	     i=0;
	     buff+=sumn;
	     a=PRE->LU.a;
	     while (i<nB) {
	           if (PRE->LU.ja[nB+1+i]==0) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		      buff[i]*=a[i];
#else
		      val      =buff[i].r*a[i].r-buff[i].i*a[i].i;
		      buff[i].i=buff[i].r*a[i].i+buff[i].i*a[i].r;
		      buff[i].r=val;
#endif
		      i++;
		   }
		   else {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		     val      =a[i]            *buff[i]+a[nB+1+i]*buff[i+1];
		     buff[i+1]=a[nB+1+i]       *buff[i]+a[i+1]   *buff[i+1];
		     buff[i]  =val;
#else
		     val        =a[i].r     *buff[i].r  -a[i].i     *buff[i].i
		                +a[nB+1+i].r*buff[i+1].r-a[nB+1+i].i*buff[i+1].i;
		     buff[i].i  =a[i].r     *buff[i].i  +a[i].i     *buff[i].r
		                +a[nB+1+i].r*buff[i+1].i+a[nB+1+i].i*buff[i+1].r;
#ifdef _COMPLEX_SYMMETRIC_		     
		     vali       =a[nB+1+i].r*buff[i].r  -a[nB+1+i].i*buff[i].i
		                +a[i+1].r   *buff[i+1].r-a[i+1].i   *buff[i+1].i;
		     buff[i+1].i=a[nB+1+i].r*buff[i].i  +a[nB+1+i].i*buff[i].r
		                +a[i+1].r   *buff[i+1].i+a[i+1].i   *buff[i+1].r;
#else
		     vali       =a[nB+1+i].r*buff[i].r  +a[nB+1+i].i*buff[i].i
		                +a[i+1].r   *buff[i+1].r-a[i+1].i   *buff[i+1].i;
		     buff[i+1].i=a[nB+1+i].r*buff[i].i  -a[nB+1+i].i*buff[i].r
		                +a[i+1].r   *buff[i+1].i+a[i+1].i   *buff[i+1].r;
#endif
		     buff[i].r  =val;
		     buff[i+1].r=vali;
#endif
		     i+=2;
		   }
	     } // end while
	     buff-=sumn;
	 
	     i=n-sumn;
	     nnzU=PRE->LU.ja[nB];
	     PRE->LU.ja[nB]=PRE->LU.nnz+1;
	     MYPSYMPILUCUSOL(&i,&nB, buff+sumn,buff+sumn, PRE->LU.a,PRE->LU.ja);
	     PRE->LU.ja[nB]=nnzU;

	     /* reorder the whole system */
	     buff+=sumn-1;
	     invq-=sumn;
	     for (i=sumn; i<n; i++)
	         sol[i]=buff[invq[i]];
	     invq+=sumn;
	     buff-=sumn-1;
	  } // end else




#ifdef PRINT_INFO	     
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	  if (j==m-1) {
	     MYSMATVEC(PRE->A,sol+sumn,buff+sumn);
	     
	     val=0;
	     for (i=sumn,k=sumlev; i<n; i++,k++) {
	         buff[i]=buff[2*n+k]-buff[i];
		 val+=buff[i]*buff[i];
	     } // end for i
	     printf("level %d, coarse grid correction step %d, res=%8.1le\n",lev,j+1,sqrt(val));fflush(stdout);
	  }
#else
	  if (j==m-1) {
	     MYSMATVEC(PRE->A,sol+sumn,buff+sumn);
	     
	     val=0;
	     for (i=sumn,k=sumlev; i<n; i++,k++) {
	         buff[i].r=buff[2*n+k].r-buff[i].r;
	         buff[i].i=buff[2*n+k].i-buff[i].i;
		 val+=buff[i].r*buff[i].r+buff[i].i*buff[i].i;
	     } // end for i
	     printf("level %d, coarse grid correction step %d, res=%8.1le\n",lev,j+1,sqrt(val));fflush(stdout);
	  }
#endif
#endif



	  if (j>0 || IPparam->ipar[12]>0) {
	     for (k=sumlev,i=sumn; i<n; i++,k++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	         buff[2*n+nbf+k]+=sol[i];
#else
		 buff[2*n+nbf+k].r+=sol[i].r;
		 buff[2*n+nbf+k].i+=sol[i].i;
#endif
	     }
	  }
	  else {
	     for (k=sumlev,i=sumn; i<n; i++,k++) {
	         buff[2*n+nbf+k]=sol[i];
	     }
	  }
      } // end for j

      // end coarse grid correction
      // **********************************************************************





      // **********************************************************************
      // post smoothing

      // make a copy of the previous sol
      if (m>0) {
	 for (k=sumlev,i=sumn; i<n; i++,k++) 
	     buff[n+i]=buff[2*n+k];
      }

      for (j=0; j<IPparam->ipar[12]; j++) {

  	  // sol = sol - A *sol
	  if (j>0 || IPparam->ipar[12]>0 || m>0) {
	     MYSMATVEC(PRE->A,sol+sumn,buff+sumn);
#ifdef PRINT_INFO	     
	     val=0;
#endif
	     for (i=sumn; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	         sol[i]=buff[n+i]-buff[i];
#ifdef PRINT_INFO	     
		 val+=sol[i]*sol[i];
#endif
#else
		 sol[i].r=buff[n+i].r-buff[i].r;
		 sol[i].i=buff[n+i].i-buff[i].i;
#ifdef PRINT_INFO	     
		 val+=sol[i].r*sol[i].r+sol[i].i*sol[i].i;
#endif
#endif
	     } // end for i
#ifdef PRINT_INFO	     
	     printf("level %d, post-smoothing step %d, res=%8.1le\n",lev,j,sqrt(val));fflush(stdout);
#endif
	  } // end if (j>0 || IPparam->ipar[12]>0 || m>0)


	  // make a copy of the initial right hand side before applying the smoother
#ifdef PRINT_INFO	     
	  val=0;
#endif
	  for (i=sumn; i<n; i++) {
	      buff[n+i]=sol[i];
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
#ifdef PRINT_INFO	     
	      val+=buff[n+i]*buff[n+i];
#endif
#else
#ifdef PRINT_INFO	     
	      val+=buff[n+i].r*buff[n+i].r+buff[n+i].i*buff[n+i].i;
#endif
#endif
	  }
#ifdef PRINT_INFO	     
	  if (j==0 && IPparam->ipar[12]==0 && m==0) printf("level %d, post-smoothing step %d, res=%8.1le\n",lev,j,sqrt(val));fflush(stdout);
#endif




	  /* reorder the whole system */
	  p-=sumn;
	  for (i=sumn; i<n; i++)
	      buff[i]=sol[sumn+p[i]-1];
	  p+=sumn;




	  /*
	     ipar[14]    type of post-smoother (adjoint operation w.r.t. pre-smoothing)
	     default: 2  (block) Gauss-Seidel forward
	              1  (block) Gauss-Seidel backward
		      3  (damped block) Jacobi
		      4  ILU
	  */
	  // Gauss-Seidel forward
	  if (IPparam->ipar[14]==2) {
#ifdef PRINT_INFO	     
	     printf("level %d, Gauss-Seidel forward\n",lev);fflush(stdout);
#endif
	     // remember that the system is already scaled and reordered as 
	     // part of the multilevel process

	     for (i=sumn; i<n; i++) {
	         i2=PRE->nextblock[i-sumn];
		 if (i2<0) {
		    val=1;
		    vb=0;
		    buffr=0;
		    buffi=0;
		    r=p[i-sumn];
		    for (k=PRE->A.ia[r-1]; k<PRE->A.ia[r]; k++) {
		        l=PRE->A.ja[k-1]-1;
			l=sumn+invq[l]-1;
			// A(p(i),q(i))?
			if (l==i) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			   val=PRE->A.a[k-1];
#else
			   val=PRE->A.a[k-1].r;
			   vb =PRE->A.a[k-1].i;
#endif
			}
			/* Gauss-Seidel forward substitution
			   Remember that except for the diagonal part, only half of
			   the matrix is stored. This has to be compensated by a 
			   simple row-wise forward substitution for the effective
			   lower triangular part and by a rank-1 update for the 
			   remaining upper triangular part
			*/
			else if (l<i) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			   buffr+=PRE->A.a[k-1]*buff[l];
#else
			   buffr+=PRE->A.a[k-1].r*buff[l].r-PRE->A.a[k-1].i*buff[l].i;
			   buffi+=PRE->A.a[k-1].r*buff[l].i+PRE->A.a[k-1].i*buff[l].r;
#endif
			}
		    } // end for k
		    // final division by the diagonal entry
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		    buff[i]=(buff[i]-buffr)/val;
#else
		    vc=1.0/(val*val+vb*vb);
		    buff[i].r-=buffr;
		    buff[i].i-=buffi;
		    vd=buff[i].r;
		    buff[i].r=( vd*val+buff[i].i*vb) *vc;
		    buff[i].i=(-vd*vb +buff[i].i*val)*vc;
#endif		 

		    // store current rhs on entry
		    buff_rhs=buff[i];
		    for (k=PRE->A.ia[r-1]; k<PRE->A.ia[r]; k++) {
		        l=PRE->A.ja[k-1]-1;
			l=sumn+invq[l]-1;
			if (l>i) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			   buff[l]-=PRE->A.a[k-1]*buff_rhs;
#else
			   buff[l].r-=PRE->A.a[k-1].r*buff_rhs.r-CONJG(PRE->A.a[k-1].i)*buff_rhs.i;
			   buff[l].i-=PRE->A.a[k-1].r*buff_rhs.i+CONJG(PRE->A.a[k-1].i)*buff_rhs.r;
#endif
			}
		    } // end for k
		 } // end if i2<0
		 // i2>=0
		 else {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		    aii=1.0;  
		    aiip1=0.0;
		    aip1ip1=1.0;
		    buff1=0.0;
		    buff2=0.0;
#else
		    aii.r=1.0;     aii.i=0.0;     
		    aiip1.r=0.0;   aiip1.i=0.0;   
		    aip1ip1.r=1.0; aip1ip1.i=0.0; 
		    buff1.r=0.0;   buff1.i=0.0;   
		    buff2.r=0.0;   buff2.i=0.0;   
#endif
		    r=p[i-sumn];
		    for (k=PRE->A.ia[r-1]-1; k<PRE->A.ia[r]-1; k++) {
		        l=PRE->A.ja[k]-1;
			l=sumn+invq[l]-1;
			// A(p(i),q(i))?
			if (l==i) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			   aii=PRE->A.a[k];
#else
			   aii.r=PRE->A.a[k].r;
			   aii.i=PRE->A.a[k].i;
#endif
			}
			else if (l==i+1) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			   aiip1=PRE->A.a[k];
#else
			   aiip1.r=PRE->A.a[k].r;
			   aiip1.i=PRE->A.a[k].i;
#endif
			}
			/* Gauss-Seidel forward substitution
			   Remember that except for the diagonal part, only half of
			   the matrix is stored. This has to be compensated by a 
			   simple row-wise forward substitution for the effective
			   lower triangular part and by a rank-1 update for the 
			   remaining upper triangular part
			*/
			else if (l<i) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			   buff1+=PRE->A.a[k]*buff[l];
#else
			   buff1.r+=PRE->A.a[k].r*buff[l].r-PRE->A.a[k].i*buff[l].i;
			   buff1.i+=PRE->A.a[k].r*buff[l].i+PRE->A.a[k].i*buff[l].r;
#endif
			}
		    } // end for k
		    r=p[i+1-sumn];
		    for (k=PRE->A.ia[r-1]-1; k<PRE->A.ia[r]-1; k++) {
		        l=PRE->A.ja[k]-1;
			l=sumn+invq[l]-1;
			// A(p(i),q(i))?
			if (l==i) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			   aiip1=PRE->A.a[k];
#else
			   aiip1.r=SKEW(PRE->A.a[k].r);
			   aiip1.i=SKEW(CONJG(PRE->A.a[k].i));
#endif
			}
			else if (l==i+1) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			   aip1ip1=PRE->A.a[k];
#else
			   aip1ip1.r=PRE->A.a[k].r;
			   aip1ip1.i=PRE->A.a[k].i;
#endif
			}
			/* Gauss-Seidel forward substitution
			   Remember that except for the diagonal part, only half of
			   the matrix is stored. This has to be compensated by a 
			   simple row-wise forward substitution for the effective
			   lower triangular part and by a rank-1 update for the 
			   remaining upper triangular part
			*/
			else if (l<i) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			   buff2+=PRE->A.a[k]*buff[l];
#else
			   buff2.r+=PRE->A.a[k].r*buff[l].r-PRE->A.a[k].i*buff[l].i;
			   buff2.i+=PRE->A.a[k].r*buff[l].i+PRE->A.a[k].i*buff[l].r;
#endif
			}
		    } // end for k
		    // final division by the diagonal entry
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		    buff[i]  -=buff1;
		    buff[i+1]-=buff2;
		    det=1.0/(aii*aip1ip1-aiip1*aiip1);
		    ve=buff[i];
		    buff[i]  =(aip1ip1*ve-aiip1*buff[i+1])*det;
		    buff[i+1]=(-aiip1 *ve+aii  *buff[i+1])*det;
#else
		    buff[i].r  -=buff1.r;
		    buff[i].i  -=buff1.i;
		    buff[i+1].r-=buff2.r;
		    buff[i+1].i-=buff2.i;
		    det.r=(aii.r  *aip1ip1.r           -aii.i  *aip1ip1.i)
		         -(aiip1.r*SKEW(aiip1.r)       -aiip1.i*SKEW(CONJG(aiip1.i)));
		    det.i=(aii.r  *aip1ip1.i           +aii.i  *aip1ip1.r)
		         -(aiip1.r*SKEW(CONJG(aiip1.i))+aiip1.i*SKEW(aiip1.r));
		    vd=1.0/(det.r*det.r+det.i*det.i);
		    det.r*= vd;
		    det.i*=-vd;
		    ve=buff[i];
		    buff[i].r  =(aip1ip1.r*ve.r-aip1ip1.i*ve.i)
		               -(aiip1.r*buff[i+1].r-aiip1.i*buff[i+1].i);
		    buff[i].i  =(aip1ip1.r*ve.i+aip1ip1.i*ve.r)
		               -(aiip1.r*buff[i+1].i+aiip1.i*buff[i+1].r);
		    vc=buff[i].r;
		    buff[i].r  =buff[i].r*det.r-buff[i].i*det.i;
		    buff[i].i  =vc       *det.i+buff[i].i*det.r;

		    vc=buff[i+1].r;
		    buff[i+1].r=-(SKEW(aiip1.r) *ve.r-SKEW(CONJG(aiip1.i)) *ve.i)
                                +(aii.r  *buff[i+1].r-aii.i  *buff[i+1].i);
		    buff[i+1].i=-(SKEW(aiip1.r) *ve.i+SKEW(CONJG(aiip1.i)) *ve.r)
                                +(aii.r  *buff[i+1].i+aii.i  *vc);
		    vc=buff[i+1].r;
		    buff[i+1].r=buff[i+1].r*det.r-buff[i+1].i*det.i;
		    buff[i+1].i=vc         *det.i+buff[i+1].i*det.r;
#endif		 

		    // store current rhs on entry
		    buff_rhs=buff[i];
		    r=p[i-sumn];
		    for (k=PRE->A.ia[r-1]-1; k<PRE->A.ia[r]-1; k++) {
		        l=PRE->A.ja[k]-1;
			l=sumn+invq[l]-1;
			if (l>i+1) { 
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			   buff[l]-=PRE->A.a[k]*buff_rhs;
#else
			   buff[l].r-=PRE->A.a[k].r*buff_rhs.r-CONJG(PRE->A.a[k].i)*buff_rhs.i;
			   buff[l].i-=PRE->A.a[k].r*buff_rhs.i+CONJG(PRE->A.a[k].i)*buff_rhs.r;
#endif
			}
		    } // end for k
		    // store current rhs on entry
		    buff_rhs=buff[i+1];
		    r=p[i+1-sumn];
		    for (k=PRE->A.ia[r-1]-1; k<PRE->A.ia[r]-1; k++) {
		        l=PRE->A.ja[k]-1;
			l=sumn+invq[l]-1;
			if (l>i+1) { 
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			   buff[l]-=PRE->A.a[k]*buff_rhs;
#else
			   buff[l].r-=PRE->A.a[k].r*buff_rhs.r-CONJG(PRE->A.a[k].i)*buff_rhs.i;
			   buff[l].i-=PRE->A.a[k].r*buff_rhs.i+CONJG(PRE->A.a[k].i)*buff_rhs.r;
#endif
			}
		    } // end for k

		    i++;
		 } // end if-else i2<0
	     } // end for i
	  }
	  // Gauss-Seidel backward
	  else if (IPparam->ipar[14]==1) {
#ifdef PRINT_INFO	     
	     printf("level %d, Gauss-Seidel backward\n",lev);fflush(stdout);
#endif
	     // remember that the system is already scaled and reordered as
	     // part of the multilevel process

	     for (i=n-1; i>=sumn; i--) {
	         i2=PRE->nextblock[i-sumn];
		 if (i2<0) {
		    val=1;
		    vb=0;
		    buffr=0;
		    buffi=0;
		    r=p[i-sumn];
		    for (k=PRE->A.ia[r-1]; k<PRE->A.ia[r]; k++) {
		        l=PRE->A.ja[k-1]-1;
			l=sumn+invq[l]-1;
			// A(p(i),q(i))?
			if (l==i) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		           val=PRE->A.a[k-1];
#else
			   val=PRE->A.a[k-1].r;
			   vb =PRE->A.a[k-1].i;
#endif
			}
			/* Gauss-Seidel backward substitution
			   Remember that except for the diagonal part, only half of
			   the matrix is stored. This has to be compensated by a 
			   simple row-wise backward substitution for the effective
			   upper triangular part and by a rank-1 update for the 
			   remaining lower triangular part
			*/
			else if (l>i) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			   buffr+=PRE->A.a[k-1]*buff[l];
#else
			   buffr+=PRE->A.a[k-1].r*buff[l].r-PRE->A.a[k-1].i*buff[l].i;
			   buffi+=PRE->A.a[k-1].r*buff[l].i+PRE->A.a[k-1].i*buff[l].r;
#endif
			}
		    } // end for k
		    // final division by the diagonal entry
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		    buff[i]=(buff[i]-buffr)/val;
#else
		    vc=1.0/(val*val+vb*vb);
		    buff[i].r-=buffr;
		    buff[i].i-=buffi;
		    vd=buff[i].r;
		    buff[i].r=( vd*val+buff[i].i*vb) *vc;
		    buff[i].i=(-vd*vb +buff[i].i*val)*vc;
#endif		 
		    
		    // store current rhs on entry
		    buff_rhs=buff[i];
		    for (k=PRE->A.ia[r-1]; k<PRE->A.ia[r]; k++) {
		        l=PRE->A.ja[k-1]-1;
			l=sumn+invq[l]-1;
			if (l<i) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		           buff[l]-=PRE->A.a[k-1]*buff_rhs;
#else
			   buff[l].r-=PRE->A.a[k-1].r*buff_rhs.r-CONJG(PRE->A.a[k-1].i)*buff_rhs.i;
			   buff[l].i-=PRE->A.a[k-1].r*buff_rhs.i+CONJG(PRE->A.a[k-1].i)*buff_rhs.r;
#endif
			}
		    } // end for k
		 } // end if i2<0
		 // i2>=0
		 else {
		    i--;
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		    aii=1.0;  
		    aiip1=0.0;
		    aip1ip1=1.0;
		    buff1=0.0;
		    buff2=0.0;
#else
		    aii.r=1.0;     aii.i=0.0;     
		    aiip1.r=0.0;   aiip1.i=0.0;   
		    aip1ip1.r=1.0; aip1ip1.i=0.0; 
		    buff1.r=0.0;   buff1.i=0.0;   
		    buff2.r=0.0;   buff2.i=0.0;   
#endif
		    r=p[i-sumn];
		    for (k=PRE->A.ia[r-1]-1; k<PRE->A.ia[r]-1; k++) {
		        l=PRE->A.ja[k]-1;
			l=sumn+invq[l]-1;
			// A(p(i),q(i))?
			if (l==i) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			   aii=PRE->A.a[k];
#else
			   aii.r=PRE->A.a[k].r;
			   aii.i=PRE->A.a[k].i;
#endif
			}
			else if (l==i+1) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			   aiip1=PRE->A.a[k];
#else
			   aiip1.r=PRE->A.a[k].r;
			   aiip1.i=PRE->A.a[k].i;
#endif
			}
			/* Gauss-Seidel backward substitution
			   Remember that except for the diagonal part, only half of
			   the matrix is stored. This has to be compensated by a 
			   simple row-wise forward substitution for the effective
			   lower triangular part and by a rank-1 update for the 
			   remaining upper triangular part
			*/
			else if (l>i+1) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			   buff1+=PRE->A.a[k]*buff[l];
#else
			   buff1.r+=PRE->A.a[k].r*buff[l].r-PRE->A.a[k].i*buff[l].i;
			   buff1.i+=PRE->A.a[k].r*buff[l].i+PRE->A.a[k].i*buff[l].r;
#endif
			}
		    } // end for k
		    r=p[i+1-sumn];
		    for (k=PRE->A.ia[r-1]-1; k<PRE->A.ia[r]-1; k++) {
		        l=PRE->A.ja[k]-1;
			l=sumn+invq[l]-1;
			// A(p(i),q(i))?
			if (l==i) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			   aiip1=PRE->A.a[k];
#else
			   aiip1.r=SKEW(PRE->A.a[k].r);
			   aiip1.i=SKEW(CONJG(PRE->A.a[k].i));
#endif
			}
			else if (l==i+1) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			   aip1ip1=PRE->A.a[k];
#else
			   aip1ip1.r=PRE->A.a[k].r;
			   aip1ip1.i=PRE->A.a[k].i;
#endif
			}
			/* Gauss-Seidel backward substitution
			   Remember that except for the diagonal part, only half of
			   the matrix is stored. This has to be compensated by a 
			   simple row-wise forward substitution for the effective
			   lower triangular part and by a rank-1 update for the 
			   remaining upper triangular part
			*/
			else if (l>i+1) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			   buff2+=PRE->A.a[k]*buff[l];
#else
			   buff2.r+=PRE->A.a[k].r*buff[l].r-PRE->A.a[k].i*buff[l].i;
			   buff2.i+=PRE->A.a[k].r*buff[l].i+PRE->A.a[k].i*buff[l].r;
#endif
			}
		    } // end for k
		    // final division by the diagonal entry
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		    buff[i]  -=buff1;
		    buff[i+1]-=buff2;
		    det=1.0/(aii*aip1ip1-aiip1*aiip1);
		    ve=buff[i];
		    buff[i]  =(aip1ip1*ve-aiip1*buff[i+1])*det;
		    buff[i+1]=(-aiip1 *ve+aii  *buff[i+1])*det;
#else
		    buff[i].r  -=buff1.r;
		    buff[i].i  -=buff1.i;
		    buff[i+1].r-=buff2.r;
		    buff[i+1].i-=buff2.i;
		    det.r=(aii.r  *aip1ip1.r           -aii.i  *aip1ip1.i)
		         -(aiip1.r*SKEW(aiip1.r)       -aiip1.i*SKEW(CONJG(aiip1.i)));
		    det.i=(aii.r  *aip1ip1.i           +aii.i  *aip1ip1.r)
		         -(aiip1.r*SKEW(CONJG(aiip1.i))+aiip1.i*SKEW(aiip1.r));
		    vd=1.0/(det.r*det.r+det.i*det.i);
		    det.r*= vd;
		    det.i*=-vd;
		    ve=buff[i];
		    buff[i].r  =(aip1ip1.r*ve.r-aip1ip1.i*ve.i)
		               -(aiip1.r*buff[i+1].r-aiip1.i*buff[i+1].i);
		    buff[i].i  =(aip1ip1.r*ve.i+aip1ip1.i*ve.r)
		               -(aiip1.r*buff[i+1].i+aiip1.i*buff[i+1].r);
		    vc=buff[i].r;
		    buff[i].r  =buff[i].r*det.r-buff[i].i*det.i;
		    buff[i].i  =vc       *det.i+buff[i].i*det.r;

		    vc=buff[i+1].r;
		    buff[i+1].r=-(SKEW(aiip1.r) *ve.r-SKEW(CONJG(aiip1.i)) *ve.i)
                                +(aii.r  *buff[i+1].r-aii.i  *buff[i+1].i);
		    buff[i+1].i=-(SKEW(aiip1.r) *ve.i+SKEW(CONJG(aiip1.i)) *ve.r)
                                +(aii.r  *buff[i+1].i+aii.i  *vc);
		    vc=buff[i+1].r;
		    buff[i+1].r=buff[i+1].r*det.r-buff[i+1].i*det.i;
		    buff[i+1].i=vc         *det.i+buff[i+1].i*det.r;
#endif		 

		    // store current rhs on entry
		    buff_rhs=buff[i];
		    r=p[i-sumn];
		    for (k=PRE->A.ia[r-1]-1; k<PRE->A.ia[r]-1; k++) {
		        l=PRE->A.ja[k]-1;
			l=sumn+invq[l]-1;
			if (l<i) { 
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			   buff[l]-=PRE->A.a[k]*buff_rhs;
#else
			   buff[l].r-=PRE->A.a[k].r*buff_rhs.r-CONJG(PRE->A.a[k].i)*buff_rhs.i;
			   buff[l].i-=PRE->A.a[k].r*buff_rhs.i+CONJG(PRE->A.a[k].i)*buff_rhs.r;
#endif
			}
		    } // end for k
		    // store current rhs on entry
		    buff_rhs=buff[i+1];
		    r=p[i+1-sumn];
		    for (k=PRE->A.ia[r-1]-1; k<PRE->A.ia[r]-1; k++) {
		        l=PRE->A.ja[k]-1;
			l=sumn+invq[l]-1;
			if (l<i) { 
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			   buff[l]-=PRE->A.a[k]*buff_rhs;
#else
			   buff[l].r-=PRE->A.a[k].r*buff_rhs.r-CONJG(PRE->A.a[k].i)*buff_rhs.i;
			   buff[l].i-=PRE->A.a[k].r*buff_rhs.i+CONJG(PRE->A.a[k].i)*buff_rhs.r;
#endif
			}
		    } // end for k
		 } // end if-else i2<0
	     } // end for i
	  }
	  // Jacobi
	  else if (IPparam->ipar[14]==3) {
#ifdef PRINT_INFO	     
	     printf("level %d, Jacobi\n",lev);fflush(stdout);
#endif
	     // remember that the system is already scaled and reordered as
	     // part of the multilevel process

	     for (i=sumn; i<n; i++) {
	         i2=PRE->nextblock[i-sumn];
		 if (i2<0) {
		    val=1;
		    vb=0;
		    r=p[i-sumn];
		    for (k=PRE->A.ia[r-1]; k<PRE->A.ia[r]; k++) {
		        l=PRE->A.ja[k-1]-1;
			l=sumn+invq[l]-1;
			// A(p(i),q(i))?
			if (l==i) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			   val=PRE->A.a[k-1];
#else
			   val=PRE->A.a[k-1].r;
			   vb =PRE->A.a[k-1].i;
#endif
			   k=PRE->A.ia[r];
			}
		    } // end for k
		    // final division by the diagonal entry
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		    buff[i]/=val;
#else
		    vc=1.0/(val*val+vb*vb);
		    vd=buff[i].r;
		    buff[i].r=( vd*val+buff[i].i*vb) *vc;
		    buff[i].i=(-vd*vb +buff[i].i*val)*vc;
#endif		 
		 } // end if i2<0
		 // i2>=0
		 else {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		    aii=1.0;  
		    aiip1=0.0;
		    aip1ip1=1.0;
		    buff1=0.0;
		    buff2=0.0;
#else
		    aii.r=1.0;     aii.i=0.0;     
		    aiip1.r=0.0;   aiip1.i=0.0;   
		    aip1ip1.r=1.0; aip1ip1.i=0.0; 
		    buff1.r=0.0;   buff1.i=0.0;   
		    buff2.r=0.0;   buff2.i=0.0;   
#endif
		    r=p[i-sumn];
		    for (k=PRE->A.ia[r-1]-1; k<PRE->A.ia[r]-1; k++) {
		        l=PRE->A.ja[k]-1;
			l=sumn+invq[l]-1;
			// A(p(i),q(i))?
			if (l==i) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			   aii=PRE->A.a[k];
#else
			   aii.r=PRE->A.a[k].r;
			   aii.i=PRE->A.a[k].i;
#endif
			}
			else if (l==i+1) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			   aiip1=PRE->A.a[k];
#else
			   aiip1.r=PRE->A.a[k].r;
			   aiip1.i=PRE->A.a[k].i;
#endif
			}
		    } // end for k
		    r=p[i+1-sumn];
		    for (k=PRE->A.ia[r-1]-1; k<PRE->A.ia[r]-1; k++) {
		        l=PRE->A.ja[k]-1;
			l=sumn+invq[l]-1;
			// A(p(i),q(i))?
			if (l==i) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			   aiip1=PRE->A.a[k];
#else
			   aiip1.r=SKEW(PRE->A.a[k].r);
			   aiip1.i=SKEW(CONJG(PRE->A.a[k].i));
#endif
			}
			else if (l==i+1) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			   aip1ip1=PRE->A.a[k];
#else
			   aip1ip1.r=PRE->A.a[k].r;
			   aip1ip1.i=PRE->A.a[k].i;
#endif
			}
		    } // end for k
		    // final division by the diagonal entry
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		    det=1.0/(aii*aip1ip1-aiip1*aiip1);
		    ve=buff[i];
		    buff[i]  =(aip1ip1*ve-aiip1*buff[i+1])*det*IPparam->damping;
		    buff[i+1]=(-aiip1 *ve+aii  *buff[i+1])*det*IPparam->damping;
#else
		    det.r=(aii.r  *aip1ip1.r           -aii.i  *aip1ip1.i)
		         -(aiip1.r*SKEW(aiip1.r)       -aiip1.i*SKEW(CONJG(aiip1.i)));
		    det.i=(aii.r  *aip1ip1.i           +aii.i  *aip1ip1.r)
		         -(aiip1.r*SKEW(CONJG(aiip1.i))+aiip1.i*SKEW(aiip1.r));
		    vd=1.0/(det.r*det.r+det.i*det.i);
		    det.r*= vd;
		    det.i*=-vd;
		    ve=buff[i];
		    buff[i].r  =(aip1ip1.r*ve.r-aip1ip1.i*ve.i)
		               -(aiip1.r*buff[i+1].r-aiip1.i*buff[i+1].i);
		    buff[i].i  =(aip1ip1.r*ve.i+aip1ip1.i*ve.r)
		               -(aiip1.r*buff[i+1].i+aiip1.i*buff[i+1].r);
		    vc=buff[i].r;
		    buff[i].r  =buff[i].r*det.r-buff[i].i*det.i;
		    buff[i].i  =vc       *det.i+buff[i].i*det.r;

		    vc=buff[i+1].r;
		    buff[i+1].r=-(SKEW(aiip1.r) *ve.r-SKEW(CONJG(aiip1.i)) *ve.i)
                                +(aii.r  *buff[i+1].r-aii.i  *buff[i+1].i);
		    buff[i+1].i=-(SKEW(aiip1.r) *ve.i+SKEW(CONJG(aiip1.i)) *ve.r)
                                +(aii.r  *buff[i+1].i+aii.i  *vc);
		    vc=buff[i+1].r;
		    buff[i+1].r=buff[i+1].r*det.r-buff[i+1].i*det.i;
		    buff[i+1].i=vc         *det.i+buff[i+1].i*det.r;
		    // damping factor
		    val=IPparam->damping.r;
		    vb =IPparam->damping.i;
		    vd=buff[i].r;		 
		    buff[i].r=vd*val-buff[i].i*vb;
		    buff[i].i=vd*vb +buff[i].i*val;
		    vd=buff[i+1].r;		 
		    buff[i+1].r=vd*val-buff[i+1].i*vb;
		    buff[i+1].i=vd*vb +buff[i+1].i*val;
#endif		 

		    i++;
		 } // i2<0
	     } // end for i
	  }
	  // associated partial ILU
	  else if (IPparam->ipar[14]==4) {
#ifdef PRINT_INFO	     
	     printf("level %d, ILU\n",lev);fflush(stdout);
#endif
	     nnzU=PRE->LU.ja[nB];
	     PRE->LU.ja[nB]=PRE->LU.nnz+1;
	     ILDLCSOL(&nB, buff+sumn,buff+sumn, PRE->LU.a,PRE->LU.ja);
	     PRE->LU.ja[nB]=nnzU;
	     for (i=sumn+nB; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		 buff[i]=0;
#else
		 buff[i].r=0;
		 buff[i].i=0;
#endif		 
	     } // end for i
	  }

	 

	  /* reorder the whole system */
	  buff+=sumn-1;
	  invq-=sumn;
	  for (i=sumn; i<n; i++)
	      sol[i]=buff[invq[i]];
	  invq+=sumn;
	  buff-=sumn-1;


#ifdef PRINT_INFO	     
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	  if (j==IPparam->ipar[12]-1) {
	     MYSMATVEC(PRE->A,sol+sumn,buff+sumn);
	     val=0;
	     for (i=sumn; i<n; i++) {
	         buff[i]=buff[n+i]-buff[i];
		 val+=buff[i]*buff[i];
	     } // end for i
	     printf("level %d, post-smoothing step %d, res=%8.1le\n",lev,j+1,sqrt(val));fflush(stdout);
	  }
#else
	  if (j==IPparam->ipar[12]-1) {
	     MYSMATVEC(PRE->A,sol+sumn,buff+sumn);
	     val=0;
	     for (i=sumn; i<n; i++) {
	         buff[i].r=buff[n+i].r-buff[i].r;
	         buff[i].i=buff[n+i].i-buff[i].i;
		 val+=buff[i].r*buff[i].r+buff[i].i*buff[i].i;
	     } // end for i
	     printf("level %d, post-smoothing step %d, res=%8.1le\n",lev,j+1,sqrt(val));fflush(stdout);
	  }
#endif
#endif

	  if (j>0 || IPparam->ipar[12]>0 || m>0) {
	     for (i=sumn,k=sumlev; i<n; i++,k++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	         buff[2*n+nbf+k]+=sol[i];
#else
		 buff[2*n+nbf+k].r+=sol[i].r;
		 buff[2*n+nbf+k].i+=sol[i].i;
#endif
	     }
	  }
	  else {
	     for (i=sumn,k=sumlev; i<n; i++,k++) {
	         buff[2*n+nbf+k]=sol[i];
	     }
	  }

      } // end for j

      // end post-smoothing
      // **********************************************************************




      // finally move accumulated approximate solutions back to sol
      for (i=sumn,k=sumlev; i<n; i++,k++)
	  sol[i]=buff[2*n+nbf+k];

      
   } /* end if */
   else { // lev==nlev
     
      /* last level */

      /* did we finally switch to full matrix processing? */
      if (lev>1 && PRE->LU.ja==NULL) {
	 for (i=sumn; i<n; i++)
	     buff[i]=sol[i];
 	 i=1;
	 MYSPTRS("L", &nB, &i, PRE->LU.a,PRE->LU.ia,
		 sol+sumn, &nB, &ierr,1);     
      }
      else {
	 /* reorder the whole system */
	 p-=sumn;
	 for (i=sumn; i<n; i++)
	     buff[i]=sol[sumn+p[i]-1];
	 p+=sumn;
     
	 if (PRE->LU.ja[0]<0)
	    flagspd=-1;
	 else
	    flagspd=0;
	 PRE->LU.ja[0]=IABS(PRE->LU.ja[0]);
	 nnzU=PRE->LU.ja[nB];
	 PRE->LU.ja[nB]=PRE->LU.nnz+1;
	 if (flagspd) {
	    buff+=sumn;
	    sol+=sumn;
	    // printf("8.\n");fflush(stdout);
	    MYSYMPILUCLSOL(&nB, buff,sol, PRE->LU.a,PRE->LU.ja); 
	    i=0;
	    a=PRE->absdiag;
	    // printf("9.\n");fflush(stdout);
	    while (i<nB) {
	          // printf("%3d\n",i);fflush(stdout);
	          if (PRE->LU.ja[nB+1+i]==0) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		     // printf("%12.4le\n",sol[i]);fflush(stdout);
		     // printf("%12.4le\n",a[i]);fflush(stdout);
		     sol[i]*=a[i];
#else
		     val     =sol[i].r*a[i].r-sol[i].i*a[i].i;
		     sol[i].i=sol[i].r*a[i].i+sol[i].i*a[i].r;
		     sol[i].r=val;
#endif
		     i++;
		  }
		  else {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		     val     =a[i]            *sol[i]+a[nB+1+i]*sol[i+1];
		     sol[i+1]=a[nB+1+i]       *sol[i]+a[i+1]   *sol[i+1];
		     sol[i]  =val;
#else
		     val       =a[i].r     *sol[i].r  -a[i].i     *sol[i].i
		               +a[nB+1+i].r*sol[i+1].r-a[nB+1+i].i*sol[i+1].i;
		     sol[i].i  =a[i].r     *sol[i].i  +a[i].i     *sol[i].r
		               +a[nB+1+i].r*sol[i+1].i+a[nB+1+i].i*sol[i+1].r;
#ifdef _COMPLEX_SYMMETRIC_		     
		     vali      =a[nB+1+i].r*sol[i].r  -a[nB+1+i].i*sol[i].i
		               +a[i+1].r   *sol[i+1].r-a[i+1].i   *sol[i+1].i;
		     sol[i+1].i=a[nB+1+i].r*sol[i].i  +a[nB+1+i].i*sol[i].r
		               +a[i+1].r   *sol[i+1].i+a[i+1].i   *sol[i+1].r;
#else
		     vali      =a[nB+1+i].r*sol[i].r  +a[nB+1+i].i*sol[i].i
		               +a[i+1].r   *sol[i+1].r-a[i+1].i   *sol[i+1].i;
		     sol[i+1].i=a[nB+1+i].r*sol[i].i  -a[nB+1+i].i*sol[i].r
		               +a[i+1].r   *sol[i+1].i+a[i+1].i   *sol[i+1].r;
#endif
		     sol[i+1].r=vali;
		     sol[i].r  =val;
#endif
		     i+=2;
		  }
	    } // end while
	    // printf("10.\n");fflush(stdout);
	    MYSYMPILUCUSOL(&nB, sol,sol, PRE->LU.a,PRE->LU.ja); 
	    // printf("11.\n");fflush(stdout);
	    buff-=sumn;
	    sol-=sumn;
	 }
	 else
	    MYSYMPILUCSOL(&nB, buff+sumn,sol+sumn, PRE->LU.a,PRE->LU.ja); 
	 PRE->LU.ja[nB]=nnzU;
	 if (flagspd)
	    PRE->LU.ja[0]=-IABS(PRE->LU.ja[0]);


	 // nnzU=PRE->LU.ja[nB];
	 // PRE->LU.ja[nB]=PRE->LU.nnz+1;
	 // ILDLCSOL(&nB, buff+sumn,sol+sumn, PRE->LU.a,PRE->LU.ja); 
	 // PRE->LU.ja[nB]=nnzU;

	 for (i=sumn; i<n; i++)
	     buff[i]=sol[i];

	 /* reorder the whole system back */
	 buff+=sumn-1;
	 invq-=sumn;
	 for (i=sumn; i<n; i++) 
	     sol[i]=buff[invq[i]];
	 invq+=sumn;
	 buff-=sumn-1;
      } /* end if-else (PRE->LU.ja==NULL) */
   } /* end if-else */
} /* end AMGsol2 */
