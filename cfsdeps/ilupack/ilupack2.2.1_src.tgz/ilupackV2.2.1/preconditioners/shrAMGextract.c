#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
#define _SKEW_MATRIX_
#include "symAMGextract.c"
#else
void myilupackdummy40()
{
}
#endif
