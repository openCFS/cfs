#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
#define _COMPLEX_SYMMETRIC_
#include "symAMGsetup.c"
#else
void myilupackdummy11()
{
}
#endif
