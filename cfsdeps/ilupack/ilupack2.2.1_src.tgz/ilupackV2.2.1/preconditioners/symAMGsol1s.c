#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
#define _COMPLEX_SYMMETRIC_
#include "symAMGsol1.c"
#else
void myilupackdummy104()
{
  // nothing     
}
#endif
