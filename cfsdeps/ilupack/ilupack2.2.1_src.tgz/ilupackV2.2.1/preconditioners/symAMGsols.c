#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
#define _COMPLEX_SYMMETRIC_
#include "symAMGsol.c"
#else
void myilupackdummy103()
{
  // nothing     
}
#endif
