#include <stdio.h>
#include <stdlib.h>

#include <blas.h>
#include <lapack.h>

#include <ilupack.h>

#include <ilupackmacros.h>

#define MAX_LINE        255
#define STDERR          stderr
#define STDOUT          stdout
//#define PRINT_INFO
#define MAX(A,B)        (((A)>(B))?(A):(B))
#define MIN(A,B)        (((A)<(B))?(A):(B))


/*
   Given a multilevel ILU decomposition, AMGsol1 performs a recursive
   AMLI-like AMG solve
*/ 
void AMGSOL1(AMGLEVELMAT *PRE, integer lev, 
	     integer n, integer nbf, integer sumn, integer sumlev,
	     ILUPACKPARAM *IPparam, FLOAT *sol, FLOAT *buff)
{

/*
   PRE       linked list of multilevel ILU preconditioners
   nlev      number of levels (blocks)
   lev       current level (block)
   n         total size
   sumn      sum over all previous leading blocks so far
   sumlev    sum over all previous remaining blocks so far
   IPparam   ILUPACK parameters
   sol       on input: given right hand side, on output: solution
   buff      work array of length max(3n, sum_{lev=2}^{nlev} nB), where n 
             is the size of the original matrix
  
   Code written by Matthias Bollhoefer,     November 2005
*/

   AMGLEVELMAT *next, *prev;

   integer i,j,k,nnzU,m=IPparam->ipar[11], nB, *p, *invq, param, flag, ierr, nlev=PRE->nlev;

   FLOAT *rowscal, *colscal;
   REALS val, vb;
   character uplo, trans, diag;
#ifdef PRINT_INFO
   static int check=1;

   if (check) {
     check=0;
#ifdef _SINGLE_REAL_ 
     printf("SGNL1 solve\n");
#else
#ifdef _DOUBLE_REAL_
     printf("DGNL1 solve\n");
#else
#ifdef _SINGLE_COMPLEX_
     printf("CGNL1 solve\n");
#else
     printf("ZGNL1 solve\n");
#endif
#endif
#endif
   }
#endif

   param=IPparam->ipar[6];

   
   // size of the leading block
   nB=PRE->nB;
   // row permutation
   p   =PRE->p;
   // inverse column permutation
   invq=PRE->invq;

   /* last but first level */
   if (lev==nlev-1) {
      /* if the last level uses direct solve, then only one recursive call
	 is useful, since the system is exactly solved.
         Moreover, the exact coarse grid system is not stored. In this case
	 the matrix-vector multiplication (in case m>1) would lead to an error
      */
      if (PRE->next->LU.ja==NULL)
         m=MIN(m,1);
   }

   /* block forward substitution */
   if (lev<nlev) {
     
      /* reorder the whole system */
      p-=sumn;
      for (i=sumn; i<n; i++)
	  buff[i]=sol[sumn+p[i]-1];
      p+=sumn;

      /* first block */
      if (param&COARSE_REDUCE) {
	 nnzU=PRE->LU.ja[nB];
	 PRE->LU.ja[nB]=PRE->LU.nnz+1;
	 ILUCSOL(&nB, buff+sumn,sol+sumn, PRE->LU.a,PRE->LU.ja,PRE->LU.ia);
	 PRE->LU.ja[nB]=nnzU;

	 /* second block */
	 CSRMATVEC(PRE->E,sol+sumn,sol+sumn+nB);

	 sumn+=nB;
	 
	 /* coarse grid projection */
	 for (i=sumn; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	     sol[i]=buff[i]-sol[i];
#else
	     sol[i].r=buff[i].r-sol[i].r;
	     sol[i].i=buff[i].i-sol[i].i;
#endif
	 } // end for i
      } // end if
      else { 
	 i=n-sumn;
	 nnzU=PRE->LU.ja[nB];
	 PRE->LU.ja[nB]=PRE->LU.nnz+1;
	 PILUCLSOL (&i,&nB, buff+sumn,sol+sumn, PRE->LU.a,PRE->LU.ja,PRE->LU.ia);
	 PRE->LU.ja[nB]=nnzU;
	 sumn+=nB;
	 
	 /* coarse grid projection */
	 for (i=sumn; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	     sol[i]+=buff[i];
#else
	     sol[i].r+=buff[i].r;
	     sol[i].i+=buff[i].i;
#endif
	 } // end for i
      } // end else


      flag=-1;
      // if the last level uses direct solve, then no scaling is required
      if (lev==nlev-1) 
	 if (PRE->next->LU.ja==NULL) 
	    flag=0;

      if (flag) {
	 rowscal=PRE->next->rowscal;
	 for (i=sumn; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	     sol[i]*=rowscal[i-sumn];
#ifdef PRINT_INFO	     
	     val+=sol[i]*sol[i];
#endif
#else
	     val=sol[i].r;
	     sol[i].r=     val*rowscal[i-sumn].r
	             -sol[i].i*rowscal[i-sumn].i;
	     sol[i].i=     val*rowscal[i-sumn].i
	             +sol[i].i*rowscal[i-sumn].r;
#endif
	 } // end for i
      }


      for (i=0; i<m; i++) {
  	  // sol = sol - AH *sol
	  if (i>0) {
	     CSRMATVEC(PRE->next->A,sol+sumn,buff+sumn);
	     val=0;
	     for (k=sumlev, j=sumn; j<n; j++,k++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	         sol[j]=buff[n+nbf+k]-buff[j];
		 val+=sol[j]*sol[j];
#else
		 sol[j].r=buff[n+nbf+k].r-buff[j].r;
		 sol[j].i=buff[n+nbf+k].i-buff[j].i;
#endif
	     } // end for i
#ifdef PRINT_INFO	     
	     printf("level %d, step %d, res=%8.1le\n",lev,i,sqrt(val));fflush(stdout);
#endif
	  }
	  // make a copy of the initial right hand side before coarsening
	  val=0;
	  for (k=sumlev, j=sumn; j<n; j++,k++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	      buff[n+nbf+k]=sol[j];
	      val+=buff[n+nbf+k]*buff[n+nbf+k];
#else
	      buff[n+nbf+k].r=sol[j].r;
	      buff[n+nbf+k].i=sol[j].i;
#endif
	  }
#ifdef PRINT_INFO	     
	  if (i==0) printf("level %d, step %d, res=%8.1le\n",lev,i,sqrt(val));fflush(stdout);
#endif
	  AMGSOL1(PRE->next, lev+1,  n, nbf, sumn,  sumlev+n-sumn, 
		  IPparam, sol, buff);


#ifdef PRINT_INFO	     
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	  if ((lev<nlev-1 || (lev==nlev-1 && PRE->next->LU.ja!=NULL)) && i==m-1) {
	     CSRMATVEC(PRE->next->A,sol+sumn,buff+sumn);     
	     val=0;
	     for (k=sumlev, j=sumn; j<n; j++,k++) {
	         buff[j]=buff[n+nbf+k]-buff[j];
		 val+=buff[j]*buff[j];
	     } // end for i
	     printf("level %d, step %d, res=%8.1le\n",lev,i+1,sqrt(val));fflush(stdout);
	  }
#endif
#endif




	  if (i>0) {
	     for (k=sumlev, j=sumn; j<n; j++,k++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	         buff[n+k]+=sol[j];
#else
		 buff[n+k].r+=sol[j].r;
		 buff[n+k].i+=sol[j].i;
#endif
	     }
	  }
	  else {
	     for (k=sumlev,j=sumn; j<n; j++,k++) {
	         buff[n+k]=sol[j];
	     }
	  }
      } // end for i


      // move approximate solutions to buff
      for (k=sumlev,i=sumn; i<n; i++,k++) 
	  buff[i]=buff[n+k];


      if (flag) {
	 colscal=PRE->next->colscal;
	 for (i=sumn; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	     buff[i]*=colscal[i-sumn];
#ifdef PRINT_INFO	     
	     val+=buff[i]*buff[i];
#endif
#else
	     val=buff[i].r;
	     buff[i].r=     val*colscal[i-sumn].r
	             -buff[i].i*colscal[i-sumn].i;
	     buff[i].i=     val*colscal[i-sumn].i
	             +buff[i].i*colscal[i-sumn].r;
#endif
	 } // end for i
      }





      if (param&COARSE_REDUCE) {
	 /* second block */
	 CSRMATVEC(PRE->F,buff+sumn,buff+sumn-nB);

	 /* first block */
	 sumn-=nB;
	 nnzU=PRE->LU.ja[nB];
	 PRE->LU.ja[nB]=PRE->LU.nnz+1;
	 ILUCSOL(&nB, buff+sumn,buff+sumn, PRE->LU.a,PRE->LU.ja,PRE->LU.ia);
	 PRE->LU.ja[nB]=nnzU;
	 
	 /* update solution */ 
	 buff+=sumn;
	 sol+=sumn;
	 for (i=0; i<nB; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	     buff[i]=sol[i]-buff[i];
#else
	     buff[i].r=sol[i].r-buff[i].r;
	     buff[i].i=sol[i].i-buff[i].i;
#endif
	 } // end for i
	 sol-=sumn;
	 buff-=sumn;
	 
	 /* reorder the whole system */
	 buff+=sumn-1;
	 invq-=sumn;
	 for (i=sumn; i<n; i++)
	     sol[i]=buff[invq[i]];
	 invq+=sumn;
	 buff-=sumn-1;
      }
      else { 
         /* copy r.h.s */
	 sumn-=nB;
	 buff+=sumn;
	 sol +=sumn;
	 for (i=0; i<nB; i++)
	     buff[i]=sol[i];
	 buff-=sumn;
	 sol -=sumn;
	 
	 i=n-sumn;
	 nnzU=PRE->LU.ja[nB];
	 PRE->LU.ja[nB]=PRE->LU.nnz+1;
	 PILUCDUSOL(&i,&nB, buff+sumn,buff+sumn, PRE->LU.a,PRE->LU.ja,PRE->LU.ia);
	 PRE->LU.ja[nB]=nnzU;
	 
	 /* reorder the whole system */
	 buff+=sumn-1;
	 invq-=sumn;
	 for (i=sumn; i<n; i++)
	     sol[i]=buff[invq[i]];
	 invq+=sumn;
	 buff-=sumn-1;
      } // end else

   } /* end if */
   else { // lev==nlev
     
      /* last level */

      /* did we finally switch to full matrix processing? */
      if (lev>1 && PRE->LU.ja==NULL) {
	 for (i=sumn; i<n; i++)
	     buff[i]=sol[i];
#ifdef USE_LAPACK_DRIVER
	 i=1;
	 COPY(&nB, buff+sumn,&i, sol+sumn,&i);
	 GETRS("T",&nB,&i,PRE->LU.a,&nB,PRE->LU.ia, sol+sumn,&nB,&ierr,1); 
#else
         LUPQTSOL(&nB, PRE->LU.a,PRE->LUperm,PRE->LU.ia, buff+sumn,sol+sumn, buff); 
#endif
      }
      else {
	 if (PRE->LUperm==NULL) {

	    /* reorder the whole system */
	    p-=sumn;
	    for (i=sumn; i<n; i++)
	        buff[i]=sol[sumn+p[i]-1];
	    p+=sumn;
     
	    nnzU=PRE->LU.ja[nB];
	    PRE->LU.ja[nB]=PRE->LU.nnz+1;
	    ILUCSOL(&nB, buff+sumn,sol+sumn, PRE->LU.a,PRE->LU.ja,PRE->LU.ia); 
	    PRE->LU.ja[nB]=nnzU;
	    for (i=sumn; i<n; i++)
	        buff[i]=sol[i];

	    /* reorder the whole system back */
	    buff+=sumn-1;
	    invq-=sumn;
	    for (i=sumn; i<n; i++) 
	        sol[i]=buff[invq[i]];
	    invq+=sumn;
	    buff-=sumn-1;
	
	 }
	 else {
	    LUSOL(&nB, sol+sumn,buff+sumn, PRE->LU.a,PRE->LU.ja,PRE->LU.ia);
	    /* reorder the whole system back */
	    sol+=sumn-1;
	    buff+=sumn;
	    for (i=0; i<nB; i++) 
	        sol[PRE->LUperm[i]]=buff[i];
	    buff-=sumn;
	    sol-=sumn-1;
	    
	 }
      } /* end if-else (PRE->LU.ja==NULL) */
   } /* end if-else */
} /* end AMGsol1 */


