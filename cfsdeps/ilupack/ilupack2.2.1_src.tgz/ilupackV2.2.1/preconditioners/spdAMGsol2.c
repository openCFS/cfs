#include <stdio.h>
#include <stdlib.h>
#include <blas.h>
#include <lapack.h>

#include <ilupack.h>

#include <ilupackmacros.h>

#define MAX_LINE        255
#define STDERR          stderr
#define STDOUT          stdout
//#define PRINT_INFO
#define IABS(A)         (((A)>=0)?(A):-(A))
#define MAX(A,B)        (((A)>(B))?(A):(B))
#define MIN(A,B)        (((A)<(B))?(A):(B))


/*
   Given a multilevel ILU decomposition, AMGsol2 performs a recursive
   full multigrid solve with several pre- and post-smoothing options
*/ 
void SPDAMGSOL2(AMGLEVELMAT *PRE, integer lev, 
		integer n, integer nbf, integer sumn, integer sumlev,
		ILUPACKPARAM *IPparam, FLOAT *sol, FLOAT *buff)
{

/*
   PRE       linked list of multilevel ILU preconditioners
   nlev      number of levels (blocks)
   lev       current level (block)
   n         total size
   sumn      sum over all previous leading blocks so far
   sumlev    sum over all previous remaining blocks so far
   IPparam   ILUPACK parameters
   sol       on input: given right hand side, on output: solution
   buff      work array of length max(3n, sum_{lev=2}^{nlev} nB), where n 
             is the size of the original matrix
  
   Code written by Matthias Bollhoefer,     November 2005, February 2006
*/

   AMGLEVELMAT *next, *prev;

   integer i,j,k,l,nnzU,m=IPparam->ipar[11],r, nB, *p, *invq, param, ierr, 
     flag, PILUCparam, nlev=PRE->nlev;

   FLOAT *scal, buff_rhs;
   REALS val, vb, vc, vd, buffr, buffi;
   character uplo, trans, diag;
#ifdef PRINT_INFO
   static int check=1;

   if (check) {
     check=0;
#ifdef _SINGLE_REAL_ 
     printf("SSPD2 solve\n");
#else
#ifdef _DOUBLE_REAL_
     printf("DSPD2 solve\n");
#else
#ifdef _SINGLE_COMPLEX_
     printf("CHPD2 solve\n");
#else
     printf("ZHPD2 solve\n");
#endif
#endif
#endif
   }
#endif

   param=IPparam->ipar[6];
   PILUCparam=IPparam->ipar[16];

   if ((IPparam->ipar[14]==4) && !(PILUCparam&COARSE_REDUCE)) {
     printf("Error! Multigrid AMG solver. For ILU smoother option the switch `COARSE_REDUCE' must be set before factorizing the matrix\n");
     fflush(stdout);
     return ;
   }

   
   // size of the leading block
   nB=PRE->nB;
   // row permutation
   p   =PRE->p;
   // inverse column permutation
   invq=PRE->invq;

   /* last but first level */
   if (lev==nlev-1) {
      /* if the last level uses direct solve, then only one recursive call
	 is useful, since the system is exactly solved.
         Moreover, the exact coarse grid system is not stored. In this case
	 the matrix-vector multiplication (in case m>1) would lead to an error
      */
      if (PRE->next->LU.ja==NULL)
         m=MIN(m,1);
   }

   if (lev<nlev) {


      // **********************************************************************
      // pre smoothing

      for (j=0; j<IPparam->ipar[12]; j++) {

  	  // sol = sol - A *sol
	  if (j>0) {
	     HERMATVEC(PRE->A,sol+sumn,buff+sumn);
#ifdef PRINT_INFO	     
	     val=0;
#endif
	     for (i=sumn; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	         sol[i]=buff[n+i]-buff[i];
#ifdef PRINT_INFO	     
		 val+=sol[i]*sol[i];
#endif
#else
		 sol[i].r=buff[n+i].r-buff[i].r;
		 sol[i].i=buff[n+i].i-buff[i].i;
#endif
	     } // end for i
#ifdef PRINT_INFO	     
	     printf("level %d, pre-smoothing step %d, res=%8.1le\n",lev,j,sqrt(val));fflush(stdout);
#endif
	  } // end if (j>0)


	  // make a copy of the initial right hand side before applying the smoother
#ifdef PRINT_INFO	     
	  val=0;
#endif
	  for (i=sumn; i<n; i++) {
	      buff[n+i]=sol[i];
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
#ifdef PRINT_INFO	     
	      val+=buff[n+i]*buff[n+i];
#endif
#endif
	  }
#ifdef PRINT_INFO	     
	  if (j==0) printf("level %d, pre-smoothing step %d, res=%8.1le\n",lev,j,sqrt(val));fflush(stdout);
#endif



#ifdef PRINT_INFO	     
	  val=0;
#endif
	  /* reorder the whole system */
	  p-=sumn;
	  for (i=sumn; i<n; i++) {
	      buff[i]=sol[sumn+p[i]-1];
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
#ifdef PRINT_INFO	     
	      val+=buff[i]*buff[i];
#endif
#endif
	  }
	  p+=sumn;
#ifdef PRINT_INFO2	     
	  printf("level %d, pre-smoothing step %d, res=%8.1le after permutation\n",lev,j,sqrt(val));fflush(stdout);
#endif




	  /*
	     ipar[14]    type of pre-smoother
	     default: 1  (block) Gauss-Seidel forward
	              2  (block) Gauss-Seidel backward
		      3  (damped block) Jacobi
		      4  ILU
		      5  custom
	  */
	  // Gauss-Seidel forward
	  if (IPparam->ipar[14]==1) {
#ifdef PRINT_INFO	     
	    printf("level %d, Gauss-Seidel forward\n",lev);fflush(stdout);
#endif
	     // remember that the system is already scaled and reordered as part
	     // of the multilevel process
	     for (i=sumn; i<n; i++) {
	         val=1;
		 vb=0;
		 buffr=0;
		 buffi=0;
		 r=p[i-sumn];
		 flag=-1;
	         for (k=PRE->A.ia[r-1]; k<PRE->A.ia[r]; k++) {
		     l=PRE->A.ja[k-1]-1;
		     l=sumn+invq[l]-1;
		     // A(p(i),q(i))?
		     if (l==i) {
		        flag=0;
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		        val=PRE->A.a[k-1];
#else
		        val=PRE->A.a[k-1].r;
		        vb =PRE->A.a[k-1].i;
#endif
		     }
		     /* Gauss-Seidel forward substitution
		        Remember that except for the diagonal part, only half of
		        the matrix is stored. This has to be compensated by a 
		        simple row-wise forward substitution for the effective
			lower triangular part and by a rank-1 update for the 
			remaining upper triangular part
		     */
		     else if (l<i) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		        buffr+=PRE->A.a[k-1]*buff[l];
#else
			buffr+=PRE->A.a[k-1].r*buff[l].r-PRE->A.a[k-1].i*buff[l].i;
			buffi+=PRE->A.a[k-1].r*buff[l].i+PRE->A.a[k-1].i*buff[l].r;
#endif
		     }
		 } // end for k
		 // final division by the diagonal entry
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		 buff[i]=(buff[i]-buffr)/val;
#else
		 vc=1.0/(val*val+vb*vb);
		 buff[i].r-=buffr;
		 buff[i].i-=buffi;
		 vd=buff[i].r;
		 buff[i].r=( vd*val+buff[i].i*vb) *vc;
		 buff[i].i=(-vd*vb +buff[i].i*val)*vc;
#endif		 

		 // store current rhs on entry
		 buff_rhs=buff[i];
	         for (k=PRE->A.ia[r-1]; k<PRE->A.ia[r]; k++) {
		     l=PRE->A.ja[k-1]-1;
		     l=sumn+invq[l]-1;
		     if (l>i) { 
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		        buff[l]-=PRE->A.a[k-1]*buff_rhs;
#else
			buff[l].r-= PRE->A.a[k-1].r*buff_rhs.r+PRE->A.a[k-1].i*buff_rhs.i;
			buff[l].i-=-PRE->A.a[k-1].r*buff_rhs.i+PRE->A.a[k-1].i*buff_rhs.r;
#endif
		     }
		 } // end for k

	     } // end for i
	  }
	  // Gauss-Seidel backward
	  else if (IPparam->ipar[14]==2) {
#ifdef PRINT_INFO	     
	     printf("level %d, Gauss-Seidel backward\n",lev);fflush(stdout);
#endif
	     // remember that the system is already scaled and reordered as part
	     // of the multilevel process
	     for (i=n-1; i>=sumn; i--) {
	         val=1;
		 vb=0;
		 buffr=0;
		 buffi=0;
		 r=p[i-sumn];
	         for (k=PRE->A.ia[r-1]; k<PRE->A.ia[r]; k++) {
		     l=PRE->A.ja[k-1]-1;
		     l=sumn+invq[l]-1;
		     // A(p(i),q(i))?
		     if (l==i) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		        val=PRE->A.a[k-1];
#else
		        val=PRE->A.a[k-1].r;
		        vb =PRE->A.a[k-1].i;
#endif
		     }
		     /* Gauss-Seidel backward substitution
		        Remember that except for the diagonal part, only half of
		        the matrix is stored. This has to be compensated by a 
		        simple row-wise backward substitution for the effective
			upper triangular part and by a rank-1 update for the 
			remaining lower triangular part
		     */
		     else if (l>i) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		        buffr+=PRE->A.a[k-1]*buff[l];
#else
			buffr+=PRE->A.a[k-1].r*buff[l].r-PRE->A.a[k-1].i*buff[l].i;
			buffi+=PRE->A.a[k-1].r*buff[l].i+PRE->A.a[k-1].i*buff[l].r;
#endif
		     }
		 } // end for k
		 // final division by the diagonal entry
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		 buff[i]=(buff[i]-buffr)/val;
#else
		 vc=1.0/(val*val+vb*vb);
		 buff[i].r-=buffr;
		 buff[i].i-=buffi;
		 vd=buff[i].r;
		 buff[i].r=( vd*val+buff[i].i*vb) *vc;
		 buff[i].i=(-vd*vb +buff[i].i*val)*vc;
#endif		 

		 // store current rhs on entry
		 buff_rhs=buff[i];
	         for (k=PRE->A.ia[r-1]; k<PRE->A.ia[r]; k++) {
		     l=PRE->A.ja[k-1]-1;
		     l=sumn+invq[l]-1;
		     if (l<i) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		        buff[l]-=PRE->A.a[k-1]*buff_rhs;
#else
			buff[l].r-= PRE->A.a[k-1].r*buff_rhs.r+PRE->A.a[k-1].i*buff_rhs.i;
			buff[l].i-=-PRE->A.a[k-1].r*buff_rhs.i+PRE->A.a[k-1].i*buff_rhs.r;
#endif
		     }
		 } // end for k

	     } // end for i
	  }
	  // Jacobi
	  else if (IPparam->ipar[14]==3) {
#ifdef PRINT_INFO	     
	     printf("level %d, Jacobi\n",lev);fflush(stdout);
#endif
	     // remember that the system is already scaled and reordered as part
	     // of the multilevel process
	     for (i=sumn; i<n; i++) {
	         val=1;
		 vb=0;
		 r=p[i-sumn];
	         for (k=PRE->A.ia[r-1]; k<PRE->A.ia[r]; k++) {
		     l=PRE->A.ja[k-1]-1;
		     l=sumn+invq[l]-1;
		     // A(p(i),q(i))?
		     if (l==i) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		        val=PRE->A.a[k-1];
#else
		        val=PRE->A.a[k-1].r;
		        vb =PRE->A.a[k-1].i;
#endif
			k=PRE->A.ia[r];
		     }
		 } // end for k
		 // final division by the diagonal entry
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		 buff[i]/=val;
		 buff[i]*=IPparam->damping;
#else
		 vc=1.0/(val*val+vb*vb);
		 vd=buff[i].r;
		 buff[i].r=( vd*val+buff[i].i*vb) *vc;
		 buff[i].i=(-vd*vb +buff[i].i*val)*vc;
		 // damping factor
		 val=IPparam->damping.r;
		 vb =IPparam->damping.i;
		 vd=buff[i].r;		 
		 buff[i].r=vd*val-buff[i].i*vb;
		 buff[i].i=vd*vb +buff[i].i*val;
#endif		 
	     } // end for i
	  }
	  // associated partial ILU
	  else if (IPparam->ipar[14]==4) {
#ifdef PRINT_INFO	     
	     printf("level %d, ILU\n",lev);fflush(stdout);
#endif
	     nnzU=PRE->LU.ja[nB];
	     PRE->LU.ja[nB]=PRE->LU.nnz+1;
	     ILDLCSOL(&nB, buff+sumn,buff+sumn, PRE->LU.a,PRE->LU.ja);
	     PRE->LU.ja[nB]=nnzU;
	     for (i=sumn+nB; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		 buff[i]=0;
#else
		 buff[i].r=0;
		 buff[i].i=0;
#endif		 
	     } // end for i
	  }

#ifdef PRINT_INFO2
	  val=0;
	  for (i=sumn; i<n; i++)
	      val+=buff[i]*buff[i];
	  printf("level %d, pre-smoothing step %d, res=%8.1le after Gau�-Seidel\n",lev,j,sqrt(val));fflush(stdout);
#endif

	  /* reorder the whole system */
#ifdef PRINT_INFO
	  val=0;
#endif
	  buff+=sumn-1;
	  invq-=sumn;
	  for (i=sumn; i<n; i++) {
	      sol[i]=buff[invq[i]];
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
#ifdef PRINT_INFO
	      val+=sol[i]*sol[i];
#endif
#endif
	  }
	  invq+=sumn;
	  buff-=sumn-1;
#ifdef PRINT_INFO2
	  printf("level %d, pre-smoothing step %d, res=%8.1le after permutation\n",lev,j,sqrt(val));fflush(stdout);
#endif



#ifdef PRINT_INFO	     
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	  if (j==IPparam->ipar[12]-1) {
	     HERMATVEC(PRE->A,sol+sumn,buff+sumn);
	     
	     val=0;
	     for (i=sumn; i<n; i++) {
	         buff[i]=buff[n+i]-buff[i];
		 val+=buff[i]*buff[i];
	     } // end for i
	     printf("level %d, pre-smoothing step %d, res=%8.1le\n",lev,j+1,sqrt(val));fflush(stdout);
	  }
#endif
#endif

	  if (j>0) {
	     for (i=sumn,k=sumlev; i<n; i++,k++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	         buff[2*n+nbf+k]+=sol[i];
#else
		 buff[2*n+nbf+k].r+=sol[i].r;
		 buff[2*n+nbf+k].i+=sol[i].i;
#endif
	     }
	  }
	  else { // j==0
	     for (i=sumn,k=sumlev; i<n; i++,k++) {
	         buff[2*n+nbf+k]=sol[i];
	     }
	  }

      } // end for j

      // end pre-smoothing
      // **********************************************************************





      // **********************************************************************
      // coarse grid correction

      // make a copy of the previous sol
      if (IPparam->ipar[12]>0) {
	 for (k=sumlev,i=sumn; i<n; i++,k++) 
	     buff[2*n+k]=buff[n+i];
      }

      for (j=0; j<m; j++) {

  	  // sol = sol_old - A *sol_new
	  if (j>0 || IPparam->ipar[12]>0) {
	     HERMATVEC(PRE->A,sol+sumn,buff+sumn);
#ifdef PRINT_INFO	     
	     val=0;
#endif
	     for (i=sumn,k=sumlev; i<n; i++,k++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	         sol[i]=buff[2*n+k]-buff[i];
#ifdef PRINT_INFO	     
		 val+=sol[i]*sol[i];
#endif
#else
		 sol[i].r=buff[2*n+k].r-buff[i].r;
		 sol[i].i=buff[2*n+k].i-buff[i].i;
#endif
	     } // end for i
#ifdef PRINT_INFO	     
	     printf("level %d, coarse grid correction step %d, res=%8.1le\n",lev,j,sqrt(val));fflush(stdout);
#endif
	  } // end if (j>0 || IPparam->ipar[12]>0)


	  // make a copy of the initial right hand side before applying the smoother
#ifdef PRINT_INFO
	  val=0;
#endif
	  for (i=sumn,k=sumlev; i<n; i++,k++) {
	      buff[2*n+k]=sol[i];
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
#ifdef PRINT_INFO	     
	      val+=buff[2*n+k]*buff[2*n+k];
#endif
#endif
	  }
#ifdef PRINT_INFO	     
	  if (j==0 && IPparam->ipar[12]==0) 
	     printf("level %d, coarse grid correction step %d, res=%8.1le\n",lev,j,sqrt(val));fflush(stdout);
#endif



	  /* block forward substitution */
     
	  /* reorder the whole system */
	  p-=sumn;
	  for (i=sumn; i<n; i++)
	      buff[i]=sol[sumn+p[i]-1];
	  p+=sumn;

	  /* first block */
	  if (param&COARSE_REDUCE) {
	     nnzU=PRE->LU.ja[nB];
	     PRE->LU.ja[nB]=PRE->LU.nnz+1;
	     ILDLCSOL(&nB, buff+sumn,sol+sumn, PRE->LU.a,PRE->LU.ja);
	     PRE->LU.ja[nB]=nnzU;

	     /* second block, multiply by E=F^H  */
	     CSRMATHVEC(PRE->F,sol+sumn,sol+sumn+nB);
	     
	     sumn+=nB;
	 
	     /* coarse grid projection */
	     for (i=sumn; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	         sol[i]=buff[i]-sol[i];
#else
		 sol[i].r=buff[i].r-sol[i].r;
		 sol[i].i=buff[i].i-sol[i].i;
#endif
	     } // end for i
	  } // end if
	  else { 
	     i=n-sumn;
	     nnzU=PRE->LU.ja[nB];
	     PRE->LU.ja[nB]=PRE->LU.nnz+1;
	     PILDLCLSOL (&i,&nB, buff+sumn,sol+sumn, PRE->LU.a,PRE->LU.ja);
	     PRE->LU.ja[nB]=nnzU;
	     sumn+=nB;
	     
	     /* coarse grid projection */
	     for (i=sumn; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	         sol[i]+=buff[i];
#else
		 sol[i].r+=buff[i].r;
		 sol[i].i+=buff[i].i;
#endif
	     } // end for i
	  } // end else


	  flag=-1;
	  // if the last level uses direct solve, then no scaling is required
	  if (lev==nlev-1) 
	     if (PRE->next->LU.ja==NULL) 
	        flag=0;

	  if (flag) {
	     // conjugate-transpose of the right scaling
	     scal=PRE->next->colscal;
	     for (i=sumn; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	         sol[i]*=scal[i-sumn];
#ifdef PRINT_INFO	     
		 val+=sol[i]*sol[i];
#endif
#else
		 val=sol[i].r;
		 sol[i].r=      val*scal[i-sumn].r
		          +sol[i].i*scal[i-sumn].i;
		 sol[i].i=-     val*scal[i-sumn].i
		          +sol[i].i*scal[i-sumn].r;
#endif
	     } // end for i
	  }

	  // coarse grid solve
	  SPDAMGSOL2(PRE->next, lev+1,  n, nbf, sumn,  sumlev+nB+n-sumn, 
		     IPparam, sol, buff);

	  if (flag) {
	     // diagonal scaling from the right
	     scal=PRE->next->colscal;
	     for (i=sumn; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	         sol[i]*=scal[i-sumn];
#ifdef PRINT_INFO	     
		 val+=sol[i]*sol[i];
#endif
#else
		 val=sol[i].r;
		 sol[i].r=     val*scal[i-sumn].r
		         -sol[i].i*scal[i-sumn].i;
		 sol[i].i=     val*scal[i-sumn].i
		         +sol[i].i*scal[i-sumn].r;
#endif
	     } // end for i
	  }


	  // move approximate solution to buff
	  for (i=sumn; i<n; i++) 
	      buff[i]=sol[i];


	  // backward substitution
	  if (param&COARSE_REDUCE) {
	     /* second block, multiply by F */
	     CSRMATVEC(PRE->F,buff+sumn,buff+sumn-nB);

	     /* first block */
	     sumn-=nB;
	     nnzU=PRE->LU.ja[nB];
	     PRE->LU.ja[nB]=PRE->LU.nnz+1;
	     ILDLCSOL(&nB, buff+sumn,buff+sumn, PRE->LU.a,PRE->LU.ja);
	     PRE->LU.ja[nB]=nnzU;

	     /* update solution */ 
	     buff+=sumn;
	     sol+=sumn;
	     // to be precise, we should keep '-buff' and not
	     // use 'sol-buff' in order to have correct multigrid
	     for (i=0; i<nB; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	         buff[i]=sol[i]-buff[i];
#else
		 buff[i].r=sol[i].r-buff[i].r;
		 buff[i].i=sol[i].i-buff[i].i;
#endif
	     } // end for i
	     sol-=sumn;
	     buff-=sumn;
	 
	     /* reorder the whole system */
	     buff+=sumn-1;
	     invq-=sumn;
	     for (i=sumn; i<n; i++)
	         sol[i]=buff[invq[i]];
	     invq+=sumn;
	     buff-=sumn-1;
	  }
	  else { // U12 is kept and F is not referenced
	     /* copy r.h.s */
	     sumn-=nB;
	     buff+=sumn;
	     sol +=sumn;
	     // note that in the sense of classical multigrid
	     // we should set buff:=0
	     // By restoring the old solution, the coarse grid
	     // correction behaves similar to AMLI
	     for (i=0; i<nB; i++)
	       buff[i]=sol[i];
	     buff-=sumn;
	     sol -=sumn;
	    
	     i=n-sumn;
	     nnzU=PRE->LU.ja[nB];
	     PRE->LU.ja[nB]=PRE->LU.nnz+1;
	     PILDLCDUSOL(&i,&nB, buff+sumn,buff+sumn, PRE->LU.a,PRE->LU.ja);
	     PRE->LU.ja[nB]=nnzU;
	     
	     /* reorder the whole system */
	     buff+=sumn-1;
	     invq-=sumn;
	     for (i=sumn; i<n; i++)
	         sol[i]=buff[invq[i]];
	     invq+=sumn;
	     buff-=sumn-1;
	  } // end else




#ifdef PRINT_INFO	     
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	  if (j==m-1) {
	     HERMATVEC(PRE->A,sol+sumn,buff+sumn);
	     
	     val=0;
	     for (i=sumn,k=sumlev; i<n; i++,k++) {
	         buff[i]=buff[2*n+k]-buff[i];
		 val+=buff[i]*buff[i];
	     } // end for i
	     printf("level %d, coarse grid correction step %d, res=%8.1le\n",lev,j+1,sqrt(val));fflush(stdout);
	  }
#endif
#endif



	  if (j>0 || IPparam->ipar[12]>0) {
	     for (k=sumlev,i=sumn; i<n; i++,k++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	         buff[2*n+nbf+k]+=sol[i];
#else
		 buff[2*n+nbf+k].r+=sol[i].r;
		 buff[2*n+nbf+k].i+=sol[i].i;
#endif
	     }
	  }
	  else {
	     for (k=sumlev,i=sumn; i<n; i++,k++) {
	         buff[2*n+nbf+k]=sol[i];
	     }
	  }
      } // end for j

      // end coarse grid correction
      // **********************************************************************





      // **********************************************************************
      // post smoothing

      // make a copy of the previous sol
      if (m>0) {
	 for (k=sumlev,i=sumn; i<n; i++,k++) 
	     buff[n+i]=buff[2*n+k];
      }

      for (j=0; j<IPparam->ipar[12]; j++) {

  	  // sol = sol - A *sol
	  if (j>0 || IPparam->ipar[12]>0 || m>0) {
	     HERMATVEC(PRE->A,sol+sumn,buff+sumn);
#ifdef PRINT_INFO	     
	     val=0;
#endif
	     for (i=sumn; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	         sol[i]=buff[n+i]-buff[i];
#ifdef PRINT_INFO	     
		 val+=sol[i]*sol[i];
#endif
#else
		 sol[i].r=buff[n+i].r-buff[i].r;
		 sol[i].i=buff[n+i].i-buff[i].i;
#endif
	     } // end for i
#ifdef PRINT_INFO	     
	     printf("level %d, post-smoothing step %d, res=%8.1le\n",lev,j,sqrt(val));fflush(stdout);
#endif
	  } // end if (j>0 || IPparam->ipar[12]>0 || m>0)


	  // make a copy of the initial right hand side before applying the smoother
#ifdef PRINT_INFO	     
	  val=0;
#endif
	  for (i=sumn; i<n; i++) {
	      buff[n+i]=sol[i];
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
#ifdef PRINT_INFO	     
	      val+=buff[n+i]*buff[n+i];
#endif
#endif
	  }
#ifdef PRINT_INFO	     
	  if (j==0 && IPparam->ipar[12]==0 && m==0) printf("level %d, post-smoothing step %d, res=%8.1le\n",lev,j,sqrt(val));fflush(stdout);
#endif




	  /* reorder the whole system */
	  p-=sumn;
	  for (i=sumn; i<n; i++)
	      buff[i]=sol[sumn+p[i]-1];
	  p+=sumn;




	  /*
	     ipar[14]    type of post-smoother (adjoint operation w.r.t. pre-smoothing)
	     default: 2  (block) Gauss-Seidel forward
	              1  (block) Gauss-Seidel backward
		      3  (damped block) Jacobi
		      4  ILU
	  */
	  // Gauss-Seidel forward
	  if (IPparam->ipar[14]==2) {
#ifdef PRINT_INFO	     
	     printf("level %d, Gauss-Seidel forward\n",lev);fflush(stdout);
#endif
	     // remember that the system is already scaled and reordered as part
	     // of the multilevel process
	     for (i=sumn; i<n; i++) {
	         val=1;
		 vb=0;
		 buffr=0;
		 buffi=0;
		 r=p[i-sumn];
	         for (k=PRE->A.ia[r-1]; k<PRE->A.ia[r]; k++) {
		     l=PRE->A.ja[k-1]-1;
		     l=sumn+invq[l]-1;
		     // A(p(i),q(i))?
		     if (l==i) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		        val=PRE->A.a[k-1];
#else
		        val=PRE->A.a[k-1].r;
		        vb =PRE->A.a[k-1].i;
#endif
		     }
		     /* Gauss-Seidel forward substitution
		        Remember that except for the diagonal part, only half of
		        the matrix is stored. This has to be compensated by a 
		        simple row-wise forward substitution for the effective
			lower triangular part and by a rank-1 update for the 
			remaining upper triangular part
		     */
		     else if (l<i) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		        buffr+=PRE->A.a[k-1]*buff[l];
#else
			buffr+=PRE->A.a[k-1].r*buff[l].r-PRE->A.a[k-1].i*buff[l].i;
			buffi+=PRE->A.a[k-1].r*buff[l].i+PRE->A.a[k-1].i*buff[l].r;
#endif
		     }
		 } // end for k
		 // final division by the diagonal entry
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		 buff[i]=(buff[i]-buffr)/val;
#else
		 vc=1.0/(val*val+vb*vb);
		 buff[i].r-=buffr;
		 buff[i].i-=buffi;
		 vd=buff[i].r;
		 buff[i].r=( vd*val+buff[i].i*vb) *vc;
		 buff[i].i=(-vd*vb +buff[i].i*val)*vc;
#endif		 

		 // store current rhs on entry
		 buff_rhs=buff[i];
	         for (k=PRE->A.ia[r-1]; k<PRE->A.ia[r]; k++) {
		     l=PRE->A.ja[k-1]-1;
		     l=sumn+invq[l]-1;
		     if (l>i) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		        buff[l]-=PRE->A.a[k-1]*buff_rhs;
#else
			buff[l].r-= PRE->A.a[k-1].r*buff_rhs.r+PRE->A.a[k-1].i*buff_rhs.i;
			buff[l].i-=-PRE->A.a[k-1].r*buff_rhs.i+PRE->A.a[k-1].i*buff_rhs.r;
#endif
		     }
		 } // end for k

	     } // end for i
	  }
	  // Gauss-Seidel backward
	  else if (IPparam->ipar[14]==1) {
#ifdef PRINT_INFO	     
	     printf("level %d, Gauss-Seidel backward\n",lev);fflush(stdout);
#endif
	     // remember that the system is already scaled and reordered as part
	     // of the multilevel process
	     for (i=n-1; i>=sumn; i--) {
	         val=1;
		 vb=0;
		 buffr=0;
		 buffi=0;
		 r=p[i-sumn];
	         for (k=PRE->A.ia[r-1]; k<PRE->A.ia[r]; k++) {
		     l=PRE->A.ja[k-1]-1;
		     l=sumn+invq[l]-1;
		     // A(p(i),q(i))?
		     if (l==i) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		        val=PRE->A.a[k-1];
#else
		        val=PRE->A.a[k-1].r;
		        vb =PRE->A.a[k-1].i;
#endif
		     }
		     /* Gauss-Seidel backward substitution
		        Remember that except for the diagonal part, only half of
		        the matrix is stored. This has to be compensated by a 
		        simple row-wise backward substitution for the effective
			upper triangular part and by a rank-1 update for the 
			remaining lower triangular part
		     */
		     else if (l>i) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		        buffr+=PRE->A.a[k-1]*buff[l];
#else
			buffr+=PRE->A.a[k-1].r*buff[l].r-PRE->A.a[k-1].i*buff[l].i;
			buffi+=PRE->A.a[k-1].r*buff[l].i+PRE->A.a[k-1].i*buff[l].r;
#endif
		     }
		 } // end for k
		 // final division by the diagonal entry
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		 buff[i]=(buff[i]-buffr)/val;
#else
		 vc=1.0/(val*val+vb*vb);
		 buff[i].r-=buffr;
		 buff[i].i-=buffi;
		 vd=buff[i].r;
		 buff[i].r=( vd*val+buff[i].i*vb) *vc;
		 buff[i].i=(-vd*vb +buff[i].i*val)*vc;
#endif		 

		 // store current rhs on entry
		 buff_rhs=buff[i];
	         for (k=PRE->A.ia[r-1]; k<PRE->A.ia[r]; k++) {
		     l=PRE->A.ja[k-1]-1;
		     l=sumn+invq[l]-1;
		     if (l<i) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		        buff[l]-=PRE->A.a[k-1]*buff_rhs;
#else
			buff[l].r-= PRE->A.a[k-1].r*buff_rhs.r+PRE->A.a[k-1].i*buff_rhs.i;
			buff[l].i-=-PRE->A.a[k-1].r*buff_rhs.i+PRE->A.a[k-1].i*buff_rhs.r;
#endif
		     }
		 } // end for k

	     } // end for i
	  }
	  // Jacobi
	  else if (IPparam->ipar[14]==3) {
#ifdef PRINT_INFO	     
	     printf("level %d, Jacobi\n",lev);fflush(stdout);
#endif
	     // remember that the system is already scaled and reordered as part
	     // of the multilevel process
	     for (i=sumn; i<n; i++) {
	         val=1;
		 vb=0;
		 r=p[i-sumn];
	         for (k=PRE->A.ia[r-1]; k<PRE->A.ia[r]; k++) {
		     l=PRE->A.ja[k-1]-1;
		     l=sumn+invq[l]-1;
		     // A(p(i),q(i))?
		     if (l==i) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		        val=PRE->A.a[k-1];
#else
		        val=PRE->A.a[k-1].r;
		        vb =PRE->A.a[k-1].i;
#endif
			k=PRE->A.ia[r];
		     }
		 } // end for k
		 // final division by the diagonal entry
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		 buff[i]/=val;
		 buff[i]*=IPparam->damping;
#else
		 vc=1.0/(val*val+vb*vb);
		 vd=buff[i].r;
		 buff[i].r=( vd*val+buff[i].i*vb) *vc;
		 buff[i].i=(-vd*vb +buff[i].i*val)*vc;
		 // damping factor
		 val=IPparam->damping.r;
		 vb =IPparam->damping.i;
		 vd=buff[i].r;		 
		 buff[i].r=vd*val-buff[i].i*vb;
		 buff[i].i=vd*vb +buff[i].i*val;
#endif		 
	     } // end for i
	  }
	  // associated partial ILU
	  else if (IPparam->ipar[14]==4) {
#ifdef PRINT_INFO	     
	     printf("level %d, ILU\n",lev);fflush(stdout);
#endif
	     nnzU=PRE->LU.ja[nB];
	     PRE->LU.ja[nB]=PRE->LU.nnz+1;
	     ILDLCSOL(&nB, buff+sumn,buff+sumn, PRE->LU.a,PRE->LU.ja);
	     PRE->LU.ja[nB]=nnzU;
	     for (i=sumn+nB; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		 buff[i]=0;
#else
		 buff[i].r=0;
		 buff[i].i=0;
#endif		 
	     } // end for i
	  }

	 

	  /* reorder the whole system */
	  buff+=sumn-1;
	  invq-=sumn;
	  for (i=sumn; i<n; i++)
	      sol[i]=buff[invq[i]];
	  invq+=sumn;
	  buff-=sumn-1;


#ifdef PRINT_INFO	     
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	  if (j==IPparam->ipar[12]-1) {
	     HERMATVEC(PRE->A,sol+sumn,buff+sumn);
	     val=0;
	     for (i=sumn; i<n; i++) {
	         buff[i]=buff[n+i]-buff[i];
		 val+=buff[i]*buff[i];
	     } // end for i
	     printf("level %d, post-smoothing step %d, res=%8.1le\n",lev,j+1,sqrt(val));fflush(stdout);
	  }
#endif
#endif

	  if (j>0 || IPparam->ipar[12]>0 || m>0) {
	     for (i=sumn,k=sumlev; i<n; i++,k++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	         buff[2*n+nbf+k]+=sol[i];
#else
		 buff[2*n+nbf+k].r+=sol[i].r;
		 buff[2*n+nbf+k].i+=sol[i].i;
#endif
	     }
	  }
	  else {
	     for (i=sumn,k=sumlev; i<n; i++,k++) {
	         buff[2*n+nbf+k]=sol[i];
	     }
	  }

      } // end for j

      // end post-smoothing
      // **********************************************************************




      // finally move accumulated approximate solutions back to sol
      for (i=sumn,k=sumlev; i<n; i++,k++)
	  sol[i]=buff[2*n+nbf+k];

      
   } /* end if */
   else { // lev==nlev
     
      /* last level */

      /* did we finally switch to full matrix processing? */
      if (lev>1 && PRE->LU.ja==NULL) {
	 for (i=sumn; i<n; i++)
	     buff[i]=sol[i];
#ifdef USE_LAPACK_DRIVER
	 i=1;
	 COPY(&nB, buff+sumn,&i, sol+sumn,&i);
         PPTRS("L", &nB, &i, PRE->LU.a,sol+sumn, &nB, &ierr,1); 
#else
         LDLPSOL(&nB, PRE->LU.a,PRE->LU.ia, buff+sumn,sol+sumn, (integer *)buff); 
#endif
      }
      else {
	 /* reorder the whole system */
	 p-=sumn;
	 for (i=sumn; i<n; i++)
	     buff[i]=sol[sumn+p[i]-1];
	 p+=sumn;
     
	 nnzU=PRE->LU.ja[nB];
	 PRE->LU.ja[nB]=PRE->LU.nnz+1;
	 ILDLCSOL(&nB, buff+sumn,sol+sumn, PRE->LU.a,PRE->LU.ja); 
	 PRE->LU.ja[nB]=nnzU;

	 for (i=sumn; i<n; i++)
	     buff[i]=sol[i];

	 /* reorder the whole system back */
	 buff+=sumn-1;
	 invq-=sumn;
	 for (i=sumn; i<n; i++) 
	     sol[i]=buff[invq[i]];
	 invq+=sumn;
	 buff-=sumn-1;
      } /* end if-else (PRE->LU.ja==NULL) */
   } /* end if-else */
} /* end AMGsol2 */
