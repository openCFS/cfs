#include <stdio.h>
#include <stdlib.h>
#include <ilupack.h>

#include <ilupackmacros.h>

#define MAX_LINE        255
#define STDERR          stderr
#define STDOUT          stdout
#define PRINT_INFO
#define MAX(A,B)        (((A)>(B))?(A):(B))
#define MIN(A,B)        (((A)<(B))?(A):(B))


/*
   Given a multilevel ILU decomposition, AMGlsol performs a simple
   forward substitution
*/ 
void AMGLSOL(AMGLEVELMAT *PRE, ILUPACKPARAM *IPparam,
	     FLOAT *rhs, FLOAT *sol, FLOAT *buff)
{

/*
   PRE       linked list of multilevel ILU preconditioners
   nlev      number of levels (blocks)
   rhs       given right hand side
   sol       solution obtained by AMGsol
   buff      work array of length 3n, where n is the size of the original 
             matrix
  
   Code written by Matthias Bollhoefer, May/November 2003, November 2004
*/

   AMGLEVELMAT *next, *prev;

   integer i, n=PRE->n, nB, *p, *invq, sumn=0, lev, param, ierr, nlev=PRE->nlev;

   FLOAT *rowscal, *colscal;
   REALS val;
   character uplo, trans, diag;

   param=IPparam->ipar[6];

   buff+=n;
   for (i=0; i<n; i++)
       buff[i]=rhs[i];
   buff-=n;

   /* block forward substitution */
   next=PRE;
   prev=NULL;
   lev=1;
   while (lev<nlev) {
	 nB=next->nB;
	 p=next->p;

	 if (lev>1) {
	    rowscal=next->rowscal-sumn;
	    buff+=n;
	    for (i=sumn; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	        buff[i]*=rowscal[i];
#else
		val=buff[i].r;
	        buff[i].r=val*rowscal[i].r-buff[i].i*rowscal[i].i;
	        buff[i].i=val*rowscal[i].i+buff[i].i*rowscal[i].r;
#endif
	    }
	    buff-=n;
	 } /* end if */

	 /* reorder the whole system */
	 p-=sumn;
	 for (i=sumn; i<n; i++)
	     buff[i]=buff[n+sumn+p[i]-1];
	 p+=sumn;

	 /* first block */
	 if (param&COARSE_REDUCE) {
	    ILUCLSOL (&nB, buff+sumn,  buff+n+sumn, next->LU.a,next->LU.ja,next->LU.ia);
	    ILUCDUSOL(&nB, buff+n+sumn,buff+sumn,   next->LU.a,next->LU.ja,next->LU.ia);

	    /* second block */
	    CSRMATVEC(next->E,buff+sumn,sol+sumn+nB);

	    sumn+=nB;

	    /* coarse grid projection */
	    for (i=sumn; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	        buff[n+i]=buff[i]-sol[i];
#else
		buff[n+i].r=buff[i].r-sol[i].r;
		buff[n+i].i=buff[i].i-sol[i].i;
#endif
	    } // end for i
	 } // end if
	 else {
	    i=n-sumn;
	    PILUCLSOL (&i,&nB, buff+sumn,buff+n+sumn, next->LU.a,next->LU.ja,next->LU.ia);

	    sumn+=nB;

	    /* coarse grid projection */
	    for (i=sumn; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	        buff[n+i]=buff[i]+buff[n+i];
#else
		buff[n+i].r=buff[i].r+buff[n+i].r;
		buff[n+i].i=buff[i].i+buff[n+i].i;
#endif
	    } // end for i
	 } // end else

	 prev=next;
	 next=next->next;
	 lev++;
   } /* end while */

   /* last level */
   nB=next->nB;
   p=next->p;
   

   /* -----   last block   ----- */

   /* did we finally switch to full matrix processing? */
   if (lev>1 && next->LU.ja==NULL) {
       LUPQTUSOL(&nB, next->LU.a,next->LUperm,next->LU.ia, buff+n+sumn,sol+sumn, buff); 
   }
   else {
      if (lev>1) {
	 rowscal=next->rowscal-sumn;
	 buff+=n;
	 for (i=sumn; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	   buff[i]*=rowscal[i];
#else
	   val=buff[i].r;
	   buff[i].r=val*rowscal[i].r-buff[i].i*rowscal[i].i;
	   buff[i].i=val*rowscal[i].i+buff[i].i*rowscal[i].r;
#endif
	 } // end for i
	 buff-=n;
      } /* end if */
      if (next->LUperm==NULL) {

	/* reorder the whole system */
	p-=sumn;
	for (i=sumn; i<n; i++)
	    buff[i]=buff[n+sumn+p[i]-1];
	p+=sumn;
     
	ILUCLSOL(&nB, buff+sumn,buff+n+sumn, next->LU.a,next->LU.ja,next->LU.ia); 

	/* rewrite the system back to the solution vector */
	buff+=n;
	for (i=sumn; i<n; i++) 
	    sol[i]=buff[i];
	buff-=n;
	
      }
      else {
	LULSOL(&nB, buff+n+sumn,buff+sumn, next->LU.a,next->LU.ja,next->LU.ia);
	/* reorder the whole system back */
	sol+=sumn;
	buff+=sumn;
	for (i=0; i<nB; i++) 
	    sol[i]=buff[i];
	buff-=sumn;
	sol-=sumn;
	
      }
   } /* end if-else (next->LU.ja==NULL) */


   // copy computed solution to the solution vector
   buff+=n;
   for (i=0; i<sumn; i++) 
       sol[i]=buff[i];
   buff-=n;

} /* end AMGlsol */


