#include <stdlib.h>
#include <stdio.h>

#include <blas.h>
#include <lapack.h>
#include <ilupack.h>
#include <ilupackmacros.h>

#define MAX_LINE        255
#define STDERR          stderr
#define STDOUT          stdout
// #define PRINT_INFO

#define IABS(A)         (((A)>=0)?(A):-(A))
#define MAX(A,B)        (((A)>(B))?(A):(B))
#define MIN(A,B)        (((A)<(B))?(A):(B))


#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
#define CONJG(A)      (A)
#define MYCSRMATVEC          CSRMATVEC 
#define MYCSRMATTVEC         CSRMATTVEC 

#ifdef _DOUBLE_REAL_
#define MYSYMAMGSOL          DSYMAMGsol
#define MYSYMAMGSOL1         DSYMAMGsol1
#define MYSYMAMGSOL2         DSYMAMGsol2
#define MYSYMPILUCSOL        DSYMpilucsol
#define MYSYMPILUCLSOL       DSYMpiluclsol
#define MYSYMPILUCUSOL       DSYMpilucusol
#define MYPSYMPILUCLSOL      DSYMppiluclsol
#define MYPSYMPILUCUSOL      DSYMppilucusol
#define MYPRIVATESPTRS       dprivatesptrs
#define MYSPTRS              dsptrs
#else			   
#define MYSYMAMGSOL          SSYMAMGsol
#define MYSYMAMGSOL1         SSYMAMGsol1
#define MYSYMAMGSOL2         SSYMAMGsol2
#define MYSYMPILUCSOL        SSYMpilucsol
#define MYSYMPILUCLSOL       SSYMpiluclsol
#define MYSYMPILUCUSOL       SSYMpilucusol
#define MYPSYMPILUCLSOL      SSYMppiluclsol
#define MYPSYMPILUCUSOL      SSYMppilucusol
#define MYPRIVATESPTRS       sprivatesptrs
#define MYSPTRS              ssptrs
#endif



#else



#ifdef _COMPLEX_SYMMETRIC_
#define CONJG(A)     (A)
#define MYCSRMATVEC          CSRMATVEC 
#define MYCSRMATTVEC         CSRMATTVEC 

#ifdef _SINGLE_COMPLEX_
#define MYSYMAMGSOL          CSYMAMGsol
#define MYSYMAMGSOL1         CSYMAMGsol1
#define MYSYMAMGSOL2         CSYMAMGsol1
#define MYSYMPILUCSOL        CSYMpilucsol
#define MYSYMPILUCLSOL       CSYMpiluclsol
#define MYSYMPILUCUSOL       CSYMpilucusol
#define MYPSYMPILUCLSOL      CSYMppiluclsol
#define MYPSYMPILUCUSOL      CSYMppilucusol
#define MYPRIVATESPTRS       csptrs
#define MYSPTRS              csptrs
#else
#define MYSYMAMGSOL          ZSYMAMGsol
#define MYSYMAMGSOL1         ZSYMAMGsol1
#define MYSYMAMGSOL2         ZSYMAMGsol2
#define MYSYMPILUCSOL        ZSYMpilucsol
#define MYSYMPILUCLSOL       ZSYMpiluclsol
#define MYSYMPILUCUSOL       ZSYMpilucusol
#define MYPSYMPILUCLSOL      ZSYMppiluclsol
#define MYPSYMPILUCUSOL      ZSYMppilucusol
#define MYPRIVATESPTRS       zsptrs
#define MYSPTRS              zsptrs
#endif

#else
#define MYCSRMATVEC          CSRMATVEC 
#define MYCSRMATTVEC         CSRMATHVEC 

#ifdef _SINGLE_COMPLEX_
#define CONJG(A)     (-(A))
#define MYSYMAMGSOL          CHERAMGsol
#define MYSYMAMGSOL1         CHERAMGsol1
#define MYSYMAMGSOL2         CHERAMGsol2
#define MYSYMPILUCSOL        CHERpilucsol
#define MYSYMPILUCLSOL       CHERpiluclsol
#define MYSYMPILUCUSOL       CHERpilucusol
#define MYPSYMPILUCLSOL      CHERppiluclsol
#define MYPSYMPILUCUSOL      CHERppilucusol
#define MYPRIVATESPTRS       cprivatehptrs
#define MYSPTRS              chptrs
#else
#define CONJG(A)     (-(A))
#define MYSYMAMGSOL          ZHERAMGsol
#define MYSYMAMGSOL1         ZHERAMGsol1
#define MYSYMAMGSOL2         ZHERAMGsol2
#define MYSYMPILUCSOL        ZHERpilucsol
#define MYSYMPILUCLSOL       ZHERpiluclsol
#define MYSYMPILUCUSOL       ZHERpilucusol
#define MYPSYMPILUCLSOL      ZHERppiluclsol
#define MYPSYMPILUCUSOL      ZHERppilucusol
#define MYPRIVATESPTRS       zprivatehptrs
#define MYSPTRS              zhptrs
#endif

#endif



#endif



#define MAX_LINE        255
#define STDERR          stderr
#define STDOUT          stdout
#define MAX(A,B)        (((A)>(B))?(A):(B))
#define MIN(A,B)        (((A)<(B))?(A):(B))






/*
   Given a multilevel ILU decomposition performed by SYMAMGsetup, 
   SYMAMGsol performs a simple forward backward substitution
*/ 
void MYSYMAMGSOL(AMGLEVELMAT *PRE, ILUPACKPARAM *IPparam,
		 FLOAT *rhs, FLOAT *sol, FLOAT *buff)

{

/*
   PRE       linked list of multilevel ILU preconditioners
   nlev      number of levels (blocks)
   rhs       given right hand side
   sol       solution obtained by SYMAMGsol
   buff      work array of length 2n, where n is the size of the original 
             matrix
  
   Code written by Matthias Bollhoefer, February 2005, March 2006
*/

   AMGLEVELMAT *next, *prev;

   integer i, j, k,n=PRE->n, nB, *p, *invq, sumn=0, lev, param, nnzU, 
           ierr, flag, nbf, PILUCparam,globalflag=0, nlev=PRE->nlev;
   

   FLOAT *scal, *a;
   REALS val, vali,vb,vc;
   static int info_message=1;
#ifdef PRINT_INFO
   static int check=1;

   if (check) {
#ifdef _SINGLE_REAL_ 
     printf("SSYM solve\n");
#else
#ifdef _DOUBLE_REAL_
     printf("DSYM solve\n");
#else
#ifdef _SINGLE_COMPLEX_
#ifdef _COMPLEX_SYMMETRIC_
     printf("CSYM solve\n");
#else
     printf("CHER solve\n");
#endif
#else
#ifdef _COMPLEX_SYMMETRIC_
     printf("ZSYM solve\n");
#else
     printf("ZHER solve\n");
#endif
#endif
#endif
#endif
   }
#endif

   // buffer to store 'true' ipar[6] from the time of the factorization
   PILUCparam=IPparam->ipar[16];
   if (IPparam->ipar[10]!=0 && !(PILUCparam&DISCARD_MATRIX)) {
      sumn=0;
      next=PRE;
      nbf=0;
      if (IPparam->ipar[10]==2) 
	 nbf=n;
      for (i=1; i<=nlev; i++) {
	  sumn+=next->nB;
	  nbf+=n-sumn;
	  next=next->next;
      } // end for i

      for (i=0; i<n; i++)
	  sol[i]=rhs[i];
      if (IPparam->ipar[10]==1) {
#ifdef PRINT_INFO
	 if (check)
	    printf("AMLI-like solve\n");
#endif
	 MYSYMAMGSOL1(PRE, 1, n, nbf, 0,0, IPparam, sol, buff);
      }
      else if (IPparam->ipar[10]==2) {
#ifdef PRINT_INFO
	 if (check)
	    printf("classical multigrid-like solve\n");
#endif
 	 MYSYMAMGSOL2(PRE, 1, n, nbf, 0,0, IPparam, sol, buff);
      }
#ifdef PRINT_INFO
      check=0;
#endif
      return ;
   }
   else if (IPparam->ipar[10]!=0 && info_message) {
      printf("ILUPACK WARNING!\n");
      printf("AMLI-like AMG or classical multigrid need to selected prior to\n");
      printf("factorization in order to maintain coarse grid systems.\n");
      printf("Will use multilevel ILU instead.\n");
      info_message=0;
   }


#ifdef PRINT_INFO
   check=0;
#endif

   param=IPparam->ipar[6];
   buff+=n;
   for (i=0; i<n; i++)
       buff[i]=rhs[i];
   buff-=n;
   /* block forward substitution */
   next=PRE;
   prev=NULL;
   lev=1;
   
   while (lev<nlev) {
	 nB=next->nB;
	 p=next->p;

#ifdef PRINT_INFO
	 printf("level %3d\n",lev);fflush(stdout);
#endif
	 if (lev>1) {
	    scal=next->colscal-sumn;
	    buff+=n;
	    for (i=sumn; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	        buff[i]*=scal[i];
#else
		val=buff[i].r;
	        buff[i].r= val*scal[i].r+buff[i].i*scal[i].i;
	        buff[i].i=-val*scal[i].i+buff[i].i*scal[i].r;
#endif
	    }
	    buff-=n;
	 } /* end if */

	 /* reorder the whole system */
	 p-=sumn;
	 for (i=sumn; i<n; i++)
	     buff[i]=buff[n+sumn+p[i]-1];
	 p+=sumn;
	 
	 /* first block */
	 if (param&COARSE_REDUCE) {
	    if (next->LU.ja[0]<0) {
	       flag=-1;
	       globalflag=-1;
	    }
	    else
	       flag=0;
	    next->LU.ja[0]=IABS(next->LU.ja[0]);

	    nnzU=next->LU.ja[nB];
	    next->LU.ja[nB]=next->LU.nnz+1;
	    if (flag) {
	       // printf("1.\n");fflush(stdout);
	       // solve system with [(L+D)D^{-1}]
	       MYSYMPILUCLSOL(&nB, buff+sumn,buff+n+sumn, next->LU.a,next->LU.ja);
	       // printf("2.\n");fflush(stdout);
	    }
	    else
	       MYSYMPILUCSOL(&nB, buff+sumn,buff+n+sumn, next->LU.a,next->LU.ja);
	    next->LU.ja[nB]=nnzU;

	    if (flag) {
	       sol +=sumn;
	       buff+=n+sumn;
	       // multiply by |D|^{-1}
	       i=0;
	       a=next->LU.a;
	       // printf("3.\n");fflush(stdout);
	       while (i<nB) {
	             if (next->LU.ja[nB+1+i]==0) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		        sol[i]=buff[i]*a[i];
#else
			sol[i].r=buff[i].r*a[i].r-buff[i].i*a[i].i;
			sol[i].i=buff[i].r*a[i].i+buff[i].i*a[i].r;
#endif
			i++;
		     }
		     else {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		        sol[i]  =a[i]            *buff[i]+a[nB+1+i]*buff[i+1];
			sol[i+1]=a[nB+1+i]       *buff[i]+a[i+1]   *buff[i+1];
#else
			sol[i].r  =a[i].r     *buff[i].r  -a[i].i     *buff[i].i
		                  +a[nB+1+i].r*buff[i+1].r-a[nB+1+i].i*buff[i+1].i;
			sol[i].i  =a[i].r     *buff[i].i  +a[i].i     *buff[i].r
		                  +a[nB+1+i].r*buff[i+1].i+a[nB+1+i].i*buff[i+1].r;
#ifdef _COMPLEX_SYMMETRIC_		     
			sol[i+1].r=a[nB+1+i].r*buff[i].r  -a[nB+1+i].i*buff[i].i
		                  +a[i+1].r   *buff[i+1].r-a[i+1].i   *buff[i+1].i;
			sol[i+1].i=a[nB+1+i].r*buff[i].i  +a[nB+1+i].i*buff[i].r
		                  +a[i+1].r   *buff[i+1].i+a[i+1].i   *buff[i+1].r;
#else
			sol[i+1].r=a[nB+1+i].r*buff[i].r  +a[nB+1+i].i*buff[i].i
		                  +a[i+1].r   *buff[i+1].r-a[i+1].i   *buff[i+1].i;
			sol[i+1].i=a[nB+1+i].r*buff[i].i  -a[nB+1+i].i*buff[i].r
		                  +a[i+1].r   *buff[i+1].i+a[i+1].i   *buff[i+1].r;
#endif
#endif
			i+=2;
		     }
	       } // end while
	       // multiply by |D|^{-1}
	       i=0;
	       a=next->absdiag;
	       // printf("4.\n");fflush(stdout);
	       while (i<nB) {
		     if (next->LU.ja[nB+1+i]==0) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		        buff[i]*=a[i];
#else
			val      =buff[i].r*a[i].r-buff[i].i*a[i].i;
			buff[i].i=buff[i].r*a[i].i+buff[i].i*a[i].r;
			buff[i].r=val;
#endif
			i++;
		     }
		     else {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		       val      =a[i]            *buff[i]+a[nB+1+i]*buff[i+1];
		       buff[i+1]=a[nB+1+i]       *buff[i]+a[i+1]   *buff[i+1];
		       buff[i]  =val;
#else
		       val        =a[i].r     *buff[i].r  -a[i].i     *buff[i].i
		                  +a[nB+1+i].r*buff[i+1].r-a[nB+1+i].i*buff[i+1].i;
		       buff[i].i  =a[i].r     *buff[i].i  +a[i].i     *buff[i].r
		                  +a[nB+1+i].r*buff[i+1].i+a[nB+1+i].i*buff[i+1].r;
#ifdef _COMPLEX_SYMMETRIC_		     
		       vali       =a[nB+1+i].r*buff[i].r  -a[nB+1+i].i*buff[i].i
		                  +a[i+1].r   *buff[i+1].r-a[i+1].i   *buff[i+1].i;
		       buff[i+1].i=a[nB+1+i].r*buff[i].i  +a[nB+1+i].i*buff[i].r
		                  +a[i+1].r   *buff[i+1].i+a[i+1].i   *buff[i+1].r;
#else
		       vali       =a[nB+1+i].r*buff[i].r  +a[nB+1+i].i*buff[i].i
		                  +a[i+1].r   *buff[i+1].r-a[i+1].i   *buff[i+1].i;
		       buff[i+1].i=a[nB+1+i].r*buff[i].i  -a[nB+1+i].i*buff[i].r
		                  +a[i+1].r   *buff[i+1].i+a[i+1].i   *buff[i+1].r;
#endif
		       buff[i+1].r=vali;
		       buff[i].r  =val;
#endif
		       i+=2;
		     }
	       } // end while
	       // printf("5.\n");fflush(stdout);
	       // solve system with [D^{-1}(D+U)]
	       nnzU=next->LU.ja[nB];
	       next->LU.ja[nB]=next->LU.nnz+1;
	       MYSYMPILUCUSOL(&nB, sol,sol, next->LU.a,next->LU.ja);
	       next->LU.ja[nB]=nnzU;
	       // printf("6.\n");fflush(stdout);
	       MYCSRMATTVEC(next->F,sol,sol+nB);
	       // printf("7.\n");fflush(stdout);
	       next->LU.ja[0]=-IABS(next->LU.ja[0]);
	       sol -=sumn;
	       buff-=n+sumn;
	    }
	    else
	       /* second block, multiply by F^H */
	       MYCSRMATTVEC(next->F,buff+n+sumn,sol+sumn+nB);

	    sumn+=nB;

	    /* coarse grid projection */
	    for (i=sumn; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	        buff[n+i]=buff[i]-sol[i];
#else
		buff[n+i].r=buff[i].r-sol[i].r;
		buff[n+i].i=buff[i].i-sol[i].i;
#endif
	    } // end for i
	 }
	 else { // !(param&COARSE_REDUCE)
	    if (next->LU.ja[0]<0) {
	      printf("ILUPACK error: _SYMSPDAMGconvert requires that COARSE_REDUCE is set\n");
	      fflush(stdout);
	      exit(-1);
	    }

	    i=n-sumn;
	    nnzU=next->LU.ja[nB];
	    next->LU.ja[nB]=next->LU.nnz+1;
	    MYPSYMPILUCLSOL(&i, &nB, buff+sumn,buff+n+sumn, next->LU.a,next->LU.ja);
	    next->LU.ja[nB]=nnzU;

	    sumn+=nB;

	    /* coarse grid projection */
	    for (i=sumn; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	        buff[n+i]=buff[i]+buff[n+i];
#else
		buff[n+i].r=buff[i].r+buff[n+i].r;
		buff[n+i].i=buff[i].i+buff[n+i].i;
#endif
	    } // end for i
	 } // end if-else (param&COARSE_REDUCE)

	 prev=next;
	 next=next->next;
	 lev++;
   } // end while




   // last level
   nB=next->nB;
   p=next->p;
   invq=next->invq;

#ifdef PRINT_INFO
   printf("level %3d\n",lev);fflush(stdout);
#endif




   /* -----   last block   ----- */

   /* did we finally switch to full matrix processing? */
   if (lev>1 && next->LU.ja==NULL) {
#ifdef PRINT_INFO
      printf("dense U-factor\n");fflush(STDOUT);
      for (i=0; i<nB; i++)
	  printf("%12d",next->LU.ia[i]);
      printf("\n");fflush(stdout);
      j=0;
      for (k=0; k<nB; k++) {
	  for (i=k; i<nB; i++) {
	      printf("%12.4le",next->LU.a[j++]);
	  }
	  printf("\n");fflush(stdout);
      }
      printf("\n");fflush(stdout);
#endif

      i=1;
      COPY(&nB, buff+n+sumn,&i, sol+sumn,&i);
#ifdef PRINT_INFO
      printf("rhs\n");fflush(STDOUT);
      for (i=0; i<nB; i++)
	  printf("%12.4le",sol[sumn+i]);
      printf("\n");fflush(stdout);
      i=1;
#endif
      if (globalflag)
	 MYPRIVATESPTRS("L", &nB, &i, next->LU.a,next->LU.ia,
			sol+sumn, &nB, &ierr,1);     
      else
	 MYSPTRS("L", &nB, &i, next->LU.a,next->LU.ia,
		 sol+sumn, &nB, &ierr,1);     
#ifdef PRINT_INFO
      printf("sol\n");fflush(STDOUT);
      for (i=0; i<nB; i++)
	  printf("%12.4le",sol[sumn+i]);
      printf("\n");fflush(stdout);
      i=1;
#endif
   }
   else {
      if (lev>1) {
	 scal=next->colscal-sumn;
	 buff+=n;
	 for (i=sumn; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	   buff[i]*=scal[i];
#else
	   val=buff[i].r;
	   buff[i].r= val*scal[i].r+buff[i].i*scal[i].i;
	   buff[i].i=-val*scal[i].i+buff[i].i*scal[i].r;
#endif
	 } // end for i
	 buff-=n;
      } /* end if */

      /* reorder the whole system */
      p-=sumn;
      for (i=sumn; i<n; i++)
	  buff[i]=buff[n+sumn+p[i]-1];
      p+=sumn;
     

      if (next->LU.ja[0]<0) {
	 flag=-1;
	 globalflag=-1;
      }
      else
	 flag=0;
      next->LU.ja[0]=IABS(next->LU.ja[0]);
      
      nnzU=next->LU.ja[nB];
      next->LU.ja[nB]=next->LU.nnz+1;
      if (flag) {
	 buff+=sumn;
	 // printf("8.\n");fflush(stdout);
	 MYSYMPILUCLSOL(&nB, buff,buff+n, next->LU.a,next->LU.ja); 
	 i=0;
	 // multiply by |D|^{-1}
	 a=next->absdiag;
	 buff+=n;
	 //printf("9.\n");fflush(stdout);
	 while (i<nB) {
	       // printf("%3d\n",i);fflush(stdout);
	       if (next->LU.ja[nB+1+i]==0) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		  // printf("%12.4le\n",buff[i]);fflush(stdout);
		  // printf("%12.4le\n",a[i]);fflush(stdout);
		  buff[i]*=a[i];
#else
		  val      =buff[i].r*a[i].r-buff[i].i*a[i].i;
		  buff[i].i=buff[i].r*a[i].i+buff[i].i*a[i].r;
		  buff[i].r=val;
#endif
		  i++;
	       }
	       else {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		  val      =a[i]            *buff[i]+a[nB+1+i]*buff[i+1];
		  buff[i+1]=a[nB+1+i]       *buff[i]+a[i+1]   *buff[i+1];
		  buff[i]  =val;
#else
		  val        =a[i].r     *buff[i].r  -a[i].i     *buff[i].i
		             +a[nB+1+i].r*buff[i+1].r-a[nB+1+i].i*buff[i+1].i;
		  buff[i].i  =a[i].r     *buff[i].i  +a[i].i     *buff[i].r
		             +a[nB+1+i].r*buff[i+1].i+a[nB+1+i].i*buff[i+1].r;
#ifdef _COMPLEX_SYMMETRIC_		     
		  vali       =a[nB+1+i].r*buff[i].r  -a[nB+1+i].i*buff[i].i
		             +a[i+1].r   *buff[i+1].r-a[i+1].i   *buff[i+1].i;
		  buff[i+1].i=a[nB+1+i].r*buff[i].i  +a[nB+1+i].i*buff[i].r
		             +a[i+1].r   *buff[i+1].i+a[i+1].i   *buff[i+1].r;
#else
		  vali       =a[nB+1+i].r*buff[i].r  +a[nB+1+i].i*buff[i].i
		             +a[i+1].r   *buff[i+1].r-a[i+1].i   *buff[i+1].i;
		  buff[i+1].i=a[nB+1+i].r*buff[i].i  -a[nB+1+i].i*buff[i].r
		             +a[i+1].r   *buff[i+1].i+a[i+1].i   *buff[i+1].r;
#endif
		  buff[i+1].r=vali;
		  buff[i].r  =val;
#endif
		  i+=2;
	       }
	 } // end while
	 // printf("10.\n");fflush(stdout);
	 MYSYMPILUCUSOL(&nB, buff,buff, next->LU.a,next->LU.ja); 
	 // printf("11.\n");fflush(stdout);
	 buff-=n+sumn;
      }
      else
	 MYSYMPILUCSOL(&nB, buff+sumn,buff+n+sumn, next->LU.a,next->LU.ja); 
      next->LU.ja[nB]=nnzU;
      if (flag)
	 next->LU.ja[0]=-IABS(next->LU.ja[0]);


      /* reorder the whole system back */
      buff+=n+sumn-1;
      invq-=sumn;
      for (i=sumn; i<n; i++) 
	sol[i]=buff[invq[i]];
      invq+=sumn;
      buff-=n+sumn-1;
	
      if (lev>1) {
	 scal=next->colscal-sumn;
	 for (i=sumn; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	     sol[i]*=scal[i];
#else
	     val=sol[i].r;
	     sol[i].r=val*scal[i].r-sol[i].i*scal[i].i;
	     sol[i].i=val*scal[i].i+sol[i].i*scal[i].r;
#endif
	 } // end for i
      } /* end if */
      
   } // end if-else (next->LU.ja==NULL)

      


   /* block backward substitution */
   lev=nlev-1;
   while (lev>0) {
	 nB=prev->nB;
	 invq=prev->invq;

#ifdef PRINT_INFO
	 printf("level %3d\n",lev);fflush(stdout);
#endif
	 
	 if (param&COARSE_REDUCE) {
	    /* copy r.h.s */
	    for (i=sumn; i<n; i++)
	        buff[i]=sol[i];

	    /* second block */
	    MYCSRMATVEC(prev->F,sol+sumn,buff+sumn-nB);

	    /* first block */
	    sumn-=nB;


	    if (prev->LU.ja[0]<0) {
	       flag=-1;
	       globalflag=-1;
	    }
	    else
	       flag=0;
	    prev->LU.ja[0]=IABS(prev->LU.ja[0]);
	    nnzU=prev->LU.ja[nB];
	    prev->LU.ja[nB]=prev->LU.nnz+1;
	    if (flag) {
	       sol +=sumn;
	       buff+=sumn;
	       // printf("12.\n");fflush(stdout);
	       MYSYMPILUCLSOL(&nB, buff,buff, prev->LU.a,prev->LU.ja);
	       // printf("13.\n");fflush(stdout);
	       // multiply by D^{-1}
	       i=0;
	       a=prev->LU.a;
	       while (i<nB) {
	             if (prev->LU.ja[nB+1+i]==0) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		        sol[i]=buff[i]*a[i];
#else
			sol[i].r=buff[i].r*a[i].r-buff[i].i*a[i].i;
			sol[i].i=buff[i].r*a[i].i+buff[i].i*a[i].r;
#endif
			i++;
		     }
		     else {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		       sol[i]  =a[i]            *buff[i]+a[nB+1+i]*buff[i+1];
		       sol[i+1]=a[nB+1+i]       *buff[i]+a[i+1]   *buff[i+1];
#else
		       sol[i].r  =a[i].r     *buff[i].r  -a[i].i     *buff[i].i
		                 +a[nB+1+i].r*buff[i+1].r-a[nB+1+i].i*buff[i+1].i;
		       sol[i].i  =a[i].r     *buff[i].i  +a[i].i     *buff[i].r
		                 +a[nB+1+i].r*buff[i+1].i+a[nB+1+i].i*buff[i+1].r;
#ifdef _COMPLEX_SYMMETRIC_		     
		       sol[i+1].r=a[nB+1+i].r*buff[i].r  -a[nB+1+i].i*buff[i].i
		                 +a[i+1].r   *buff[i+1].r-a[i+1].i   *buff[i+1].i;
		       sol[i+1].i=a[nB+1+i].r*buff[i].i  +a[nB+1+i].i*buff[i].r
		                 +a[i+1].r   *buff[i+1].i+a[i+1].i   *buff[i+1].r;
#else
		       sol[i+1].r=a[nB+1+i].r*buff[i].r  +a[nB+1+i].i*buff[i].i
		                 +a[i+1].r   *buff[i+1].r-a[i+1].i   *buff[i+1].i;
		       sol[i+1].i=a[nB+1+i].r*buff[i].i  -a[nB+1+i].i*buff[i].r
		                 +a[i+1].r   *buff[i+1].i+a[i+1].i   *buff[i+1].r;
#endif
#endif
		       i+=2;
		     }
	       } // end while
	       // printf("14.\n");fflush(stdout);
	       sol -=sumn;
	       buff-=sumn;
	    }
	    else
	       MYSYMPILUCSOL(&nB, buff+sumn,sol+sumn, prev->LU.a,prev->LU.ja);
	    prev->LU.ja[nB]=nnzU;
	       
	    /* update solution */ 
	    buff+=sumn;
	    sol+=sumn;
	    for (i=0; i<nB; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	        buff[i]=buff[n+i]-sol[i];
#else
		buff[i].r=buff[n+i].r-sol[i].r;
		buff[i].i=buff[n+i].i-sol[i].i;
#endif
	    } // end for i
	    if (flag) {
	       // printf("15.\n");fflush(stdout);
	       nnzU=prev->LU.ja[nB];
	       prev->LU.ja[nB]=prev->LU.nnz+1;
	       MYSYMPILUCUSOL(&nB, buff,buff, prev->LU.a,prev->LU.ja);
	       prev->LU.ja[nB]=nnzU;
	       // printf("16.\n");fflush(stdout);
	       prev->LU.ja[0]=-IABS(prev->LU.ja[0]);
	    }
	    sol-=sumn;
	    buff-=sumn;

	    /* reorder the whole system */
	    buff+=sumn-1;
	    invq-=sumn;
	    for (i=sumn; i<n; i++)
	        sol[i]=buff[invq[i]];
	    invq+=sumn;
	    buff-=sumn-1;
	 }
	 else { // !(param&COARSE_REDUCE)
	    /* copy r.h.s */
	    // printf("17.\n");fflush(stdout);
	    buff+=n;
	    // this is NECESSARY to make MYPSYMPILUCUSOL correctly work
	    for (i=sumn; i<n; i++)
	        buff[i]=sol[i];
	    buff-=n;

	    sumn-=nB;

	    // printf("18.\n");fflush(stdout);
	    // block diagonal scaling using D^{-1}
	    i=0;
	    buff+=n+sumn;
	    a=prev->LU.a;
	    while (i<nB) {
	          if (prev->LU.ja[nB+1+i]==0) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		     buff[i]*=a[i];
#else
		     val      =buff[i].r*a[i].r-buff[i].i*a[i].i;
		     vb       =buff[i].r*a[i].i+buff[i].i*a[i].r;
		     buff[i].r=val;
		     buff[i].i=vb;
#endif
		     i++;
		  }
		  else {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		     val      =a[i]            *buff[i]+a[nB+1+i]*buff[i+1];
		     vb       =a[nB+1+i]       *buff[i]+a[i+1]   *buff[i+1];
		     buff[i]  =val;
		     buff[i+1]=vb;
#else
		     val        =a[i].r     *buff[i].r  -a[i].i     *buff[i].i
		                +a[nB+1+i].r*buff[i+1].r-a[nB+1+i].i*buff[i+1].i;
		     vb         =a[i].r     *buff[i].i  +a[i].i     *buff[i].r
		                +a[nB+1+i].r*buff[i+1].i+a[nB+1+i].i*buff[i+1].r;
#ifdef _COMPLEX_SYMMETRIC_		     
		     vali       =a[nB+1+i].r*buff[i].r  -a[nB+1+i].i*buff[i].i
		                +a[i+1].r   *buff[i+1].r-a[i+1].i   *buff[i+1].i;
		     vc         =a[nB+1+i].r*buff[i].i  +a[nB+1+i].i*buff[i].r
		                +a[i+1].r   *buff[i+1].i+a[i+1].i   *buff[i+1].r;
#else
		     vali       =a[nB+1+i].r*buff[i].r  +a[nB+1+i].i*buff[i].i
		                +a[i+1].r   *buff[i+1].r-a[i+1].i   *buff[i+1].i;
		     vc         =a[nB+1+i].r*buff[i].i  -a[nB+1+i].i*buff[i].r
		                +a[i+1].r   *buff[i+1].i+a[i+1].i   *buff[i+1].r;
#endif
		     buff[i].r  =val;
		     buff[i].i  =vb;
		     buff[i+1].r=vali;
		     buff[i+1].i=vc;
#endif
		     i+=2;
		  }
	    } // end while
	    buff-=n+sumn;
	    // printf("19.\n");fflush(stdout);

	    i=n-sumn;
	    nnzU=prev->LU.ja[nB];
	    prev->LU.ja[nB]=prev->LU.nnz+1;
	    MYPSYMPILUCUSOL(&i,&nB, buff+n+sumn,buff+n+sumn, prev->LU.a,prev->LU.ja);
	    prev->LU.ja[nB]=nnzU;
	    // printf("20.\n");fflush(stdout);

	    /* reorder the whole system */
	    buff+=n+sumn-1;
	    invq-=sumn;
	    for (i=sumn; i<n; i++)
	        sol[i]=buff[invq[i]];
	    invq+=sumn;
	    buff-=n+sumn-1;
	 } // end if-else (param&COARSE_REDUCE)


	 if (lev>1) {
	    scal=prev->colscal-sumn;
	    for (i=sumn; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	        sol[i]*=scal[i];
#else
		val=sol[i].r;
		sol[i].r=val*scal[i].r-sol[i].i*scal[i].i;
		sol[i].i=val*scal[i].i+sol[i].i*scal[i].r;
#endif
	    } // end for i
	 } /* end if */

	 
	 next=prev;
	 prev=prev->prev;
	 lev--;
   } // end while

} /* end SYMAMGsol */


