#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>


#include <lapack.h>
#include <ilupack.h>
#include <ilupackmacros.h>


//#define printf mexPrintf

//#define PRINT_RC
//#define PRINT_INLINE
//#define PRINT_INFO2

//#define PRINT_MEM
#define MEGA      1048576.0
#define IMEGA      262144.0
#define DMEGA      131072.0

#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
#define CONJG(A)      (A)

#ifdef _DOUBLE_REAL_
#define MYSYMAMGSETUPPARAMETERS             DSYMAMGsetupparameters
#define SYMPILUC             DSYMpiluc
#define SYMILUC              DSYMiluc
#define MYSMATVEC            DSYMmatvec
#define MYSYMAMGFACTOR       DSYMAMGfactor
#define MYSYMAMGDELETE       DSYMAMGdelete
#define MYSYMAMGEXTRACT      DSYMAMGextract
#define MYSPTRF              dsptrf
#define MYSYMBUILDBLOCK      DSYMbuildblock

#else
#define MYSYMAMGSETUPPARAMETERS             SSYMAMGsetupparameters
#define SYMPILUC             SSYMpiluc
#define SYMILUC              SSYMiluc
#define MYSMATVEC            SSYMmatvec
#define MYSYMAMGFACTOR       SSYMAMGfactor
#define MYSYMAMGDELETE       SSYMAMGdelete
#define MYSYMAMGEXTRACT      SSYMAMGextract
#define MYSPTRF              ssptrf
#define MYSYMBUILDBLOCK      SSYMbuildblock
#endif



#else



#ifdef _COMPLEX_SYMMETRIC_
#define CONJG(A)     (A)

#ifdef _SINGLE_COMPLEX_
#define MYSYMAMGSETUPPARAMETERS             CSYMAMGsetupparameters
#define SYMPILUC             CSYMpiluc
#define SYMILUC              CSYMiluc
#define MYSMATVEC            CSYMmatvec
#define MYSYMAMGFACTOR       CSYMAMGfactor
#define MYSYMAMGDELETE       CSYMAMGdelete
#define MYSYMAMGEXTRACT      CSYMAMGextract
#define MYSPTRF              csptrf
#define MYSYMBUILDBLOCK      CSYMbuildblock
#else
#define MYSYMAMGSETUPPARAMETERS             ZSYMAMGsetupparameters
#define SYMPILUC             ZSYMpiluc
#define SYMILUC              ZSYMiluc
#define MYSMATVEC            ZSYMmatvec
#define MYSYMAMGFACTOR       ZSYMAMGfactor
#define MYSYMAMGDELETE       ZSYMAMGdelete
#define MYSYMAMGEXTRACT      ZSYMAMGextract
#define MYSPTRF              zsptrf
#define MYSYMBUILDBLOCK      ZSYMbuildblock
#endif

#else
#define CONJG(A)             (-(A))

#ifdef _SINGLE_COMPLEX_
#define MYSYMAMGSETUPPARAMETERS             CHERAMGsetupparameters
#define SYMPILUC             CHERpiluc
#define SYMILUC              CHERiluc
#define MYSMATVEC            CHERmatvec
#define MYSYMAMGFACTOR       CHERAMGfactor
#define MYSYMAMGDELETE       CHERAMGdelete
#define MYSYMAMGEXTRACT      CHERAMGextract
#define MYSPTRF              chptrf
#define MYSYMBUILDBLOCK      CHERbuildblock
#else
#define MYSYMAMGSETUPPARAMETERS             ZHERAMGsetupparameters
#define SYMPILUC             ZHERpiluc
#define SYMILUC              ZHERiluc
#define MYSMATVEC            ZHERmatvec
#define MYSYMAMGFACTOR       ZHERAMGfactor
#define MYSYMAMGDELETE       ZHERAMGdelete
#define MYSYMAMGEXTRACT      ZHERAMGextract
#define MYSPTRF              zhptrf
#define MYSYMBUILDBLOCK      ZHERbuildblock
#endif

#endif



#endif



#define MAX_LINE        255
#define STDERR          stderr
#define STDOUT          stdout
#define MAX(A,B)        (((A)>(B))?(A):(B))
#define MIN(A,B)        (((A)<(B))?(A):(B))






/*
  main driver for the multilevel ILU

  given a symmetrically structured A, a sequence of permutations and 
  incomplete LU factorizations is performed. Partially we obtain an
  approximate partial factorization
          /  B  F \   /U^T   0\ /D  0\ /U UF\
  P^TAP = |       | ~ |       | |    | |    |
          \ F^T C /   \UF^T  I/ \0  S/ \0 I /
  The D,U as well as p,p^{-1} and F are kept and the multilevel strategy
  is repeated for S
*/
integer MYSYMAMGFACTOR(CSRMAT *A, AMGLEVELMAT *PRE, ILUPACKPARAM *IPparam)
{
/*
  A        input matrix, matrix is altered by the function
           diagonal scaling is directly applied to A
           only the diagonal part of A and its upper triangular part
           are stored
  PRE      Linked list of partial preconditioners
  nlev     number of levels(blocks)
  IPparam  ILUPACK parameter list
  perm0    function for initial scaling and preprocessing, applied to
           the initial system only
  perm     regular reordering/scaling applied to all subsequent levels
  permf    final scaling/pivoting strategy, applied when perm has failed
    
           perm...(A,rowscale,colscale,p,invq,nB,IPparam)
           - rescales A, returns the results in rowscale and colscale
           - permutes the rows of A and returns the permutation vector in p
           - permutes similarly the columns of A and returns the inverse 
           - permutation vector of p in invq
           - return the size nB of the leading block B
                     /  B  F \
             P^TAP = |       |
                     \ F^T C /
             that hopefully can be safely factored

  Code written by Matthias Bollhoefer November 2003
*/


  integer i,j,k,l,n, PILUCparam, nnz, nB, posiwk;
  integer  *jlu, ierr, regular_pivoting, *ia, *ja;
  integer lfil[2], param, discardA, shiftA;
  REALS droptols[3], condest, condest0, condest1, amgcancel, ilucancel,
    condest_increase; 
  REALS seps, ptol, val,vb, elbow;
  CSRMAT S;
  AMGLEVELMAT *current, *curr;
  FLOAT *alu, *a, *r, *c;
  float  systime, time_start, time_stop, secnds, 
         ILUP_sec[ILUPACK_secnds_length];
  LONG_INT imem, myimem, mymaximem;
  size_t   nibuff, ndbuff,  mem, *delta, delta_ia,
           delta_ja, delta_a;
  integer (*perm0)(),(*perm)(),(*permf)(), nlev;
  integer npressurelist,  *pressurelist, 
          npressurestackA,*pressurestackA, *pressuretopA,
          npressurestackL,*pressurestackL, *pressuretopL,
          *invheadA, *invlistA, 
          *invheadL, *invlistL,
          *invheadLe,*invlistLe;


  if (IPparam->returnlabel!=0) {
#ifdef PRINT_RC
     printf("continue at label 1\n");fflush(stdout);
#endif
     if (IPparam->returnlabel==1) goto label1;
  }

  n=A->nr;
  PILUCparam=0;
  ierr=0;
  // init time counters
  evaluate_time(&time_start,&systime);
  // counter for the total setup time
  for (i=0; i<ILUPACK_secnds_length; i++)
      ILUP_sec[i]=0;
  ILUP_sec[7]=time_start;

  // init memory counters
  for (i=0; i<ILUPACK_mem_length; i++)
      ILUPACK_mem[i]=0;

  // ILUPACK_mem[ 0]:  maximum size of the integer buffer
  // ILUPACK_mem[ 1]:  maximum size of the floating point buffer
  // ILUPACK_mem[ 2]:  size of array jlu (on exit, integer)
  // ILUPACK_mem[ 3]:  size of array alu (on exit, FLOAT)
  // ILUPACK_mem[ 4]:  peek size of array jlu (integer)
  // ILUPACK_mem[ 5]:  peek size of array alu (FLOAT)
  // ILUPACK_mem[ 6]:  memory for E,F (integer)
  // ILUPACK_mem[ 7]:  memory for E,F (FLOAT)
  // ILUPACK_mem[ 8]:  memory for permutations p/invq (integer)
  // ILUPACK_mem[ 9]:  memory for scaling rowscal/colscal (FLOAT)
  // ILUPACK_mem[10]:  memory for storing coarse grid systems (integer)
  // ILUPACK_mem[11]:  memory for storing coarse grid systems (FLOAT)

  // for pildlc the integer buffer is required to have at least
  //    11*n for the simple Schur complement (S version)
  //    14*n for the Tismenetsky-like Schur complement (T version)
  // for mpiluc the integer buffer is required to have at least
  //    12*n for the simple Schur complement (S version)
  //    15*n for the Tismenetsky-like Schur complement (T version)

  // analogous settings for the floating point buffer
  //    2*n  (not improved version)
  //    3*n  (improved version or medium Schur complement version)


  // ***  new parameter selection scheme *** 
  // transfer the user request to the internal parameter list
  MYSYMAMGSETUPPARAMETERS(A, IPparam,0);
  // overwrite the permutation drivers by those that have been selected via the
  // setup. If param->FCpart, param->ordering do not match any of the 
  // preselected items (e.g. NULL pointer, empty string, fancy strings like 
  // "mydriver",...), then perm0,perm,permf effectively do not change
  perm0=IPparam->perm0;
  perm =IPparam->perm;
  permf=IPparam->permf;

  /* old version
  elbow  =IPparam->ipar[0];
  nibuff =IPparam->nibuff;
  ndbuff =IPparam->ndbuff;
  lfil[0]=IPparam->ipar[3];
  lfil[1]=IPparam->ipar[9];
  param  =IPparam->ipar[6];

  droptols[0]=IPparam->fpar[0];
  droptols[1]=IPparam->fpar[1];
  droptols[2]=IPparam->fpar[8];
  condest    =IPparam->fpar[2];
  ilucancel  =IPparam->fpar[3];
  amgcancel  =IPparam->fpar[4]; 
  condest_increase=IPparam->fpar[9]; 
  */
  // new version
  elbow  =IPparam->elbow; // now floating point
  nibuff =IPparam->nibuff;
  ndbuff =IPparam->ndbuff;
  lfil[0]=IPparam->lfil;
  lfil[1]=IPparam->lfilS;
  param  =IPparam->flags;

  droptols[0]=IPparam->fpar[0];
  droptols[1]=IPparam->droptol;
  droptols[2]=IPparam->droptolS;
  condest    =IPparam->condest;
  condest0=condest;
  ilucancel  =IPparam->fpar[3];
  amgcancel  =IPparam->fpar[4]; 
  condest_increase=IPparam->fpar[9]; 


  // analyze how the size of the buffer has to be chosen
  if (param&TISMENETSKY_SC) {
     if (param&MULTI_PILUC)
        nibuff=MAX(nibuff,17*(size_t)n);
     nibuff=MAX(nibuff,16*(size_t)n);
  }
  else {
     if (param&MULTI_PILUC)
        nibuff=MAX(nibuff,14*(size_t)n);
     nibuff=MAX(nibuff,13*(size_t)n); // recommended version!
  }

  if (param&DROP_INVERSE) {
     // if a more reliable estimate for the inverse is required
     if (param&IMPROVED_ESTIMATE || !(param&(SIMPLE_SC|TISMENETSKY_SC)))
        ndbuff=MAX(ndbuff,4*(size_t)n); // recommended version!
     else 
        ndbuff=MAX(ndbuff,3*(size_t)n);
  }
  else {
     // currently the norm of the inverse factors are computed
     // even if classical dropping is desired
     // The comments in (m)piluc still refer to their predecessor
     // iluc, which allows classical dropping in a strict sense

     // if a more reliable estimate for the inverse is required
     if (param&IMPROVED_ESTIMATE || !(param&(SIMPLE_SC|TISMENETSKY_SC)))
        ndbuff=MAX(ndbuff,4*(size_t)n);
     else 
        ndbuff=MAX(ndbuff,3*(size_t)n);
  }

  /* integer and floating point buffer */
#ifdef PRINT_MEM
  printf("ibuffmem=%8.2fMB, dbuffmem=%8.2fMB\n",IPparam->nibuff/IMEGA,IPparam->ndbuff/DMEGA);fflush(stdout);
#endif
  if (IPparam->nibuff==0) {
     IPparam->nibuff=nibuff;
     IPparam->ibuff=(integer *)  MALLOC(IPparam->nibuff*sizeof(integer),
				    "symAMGfactor:ibuff");
#ifdef PRINT_MEM
     printf("ibuff(%8.2fMB) allocated\n",nibuff/IMEGA);fflush(stdout);
#endif
  }     
  else if (nibuff>IPparam->nibuff) {
     IPparam->nibuff=nibuff;
     IPparam->ibuff=(integer *)  REALLOC(IPparam->ibuff,
				     IPparam->nibuff*sizeof(integer),
				     "symAMGfactor:ibuff");
#ifdef PRINT_MEM
     printf("ibuff(%8.2fMB) re-allocated\n",nibuff/IMEGA);fflush(stdout);
#endif
  }
  if (IPparam->ndbuff==0) {
     IPparam->ndbuff=ndbuff;
     IPparam->dbuff=(FLOAT *)MALLOC(IPparam->ndbuff*sizeof(FLOAT),
				    "symAMGfactor:dbuff");
#ifdef PRINT_MEM
     printf("dbuff(%8.2fMB) allocated\n",ndbuff/DMEGA);fflush(stdout);
#endif
  } 
  else if (ndbuff>IPparam->ndbuff) {
     IPparam->ndbuff=ndbuff;
     IPparam->dbuff=(FLOAT *)REALLOC(IPparam->dbuff,
				     IPparam->ndbuff*sizeof(FLOAT),
				     "symAMGfactor:dbuff");
#ifdef PRINT_MEM
     printf("dbuff(%8.2fMB) re-allocated\n",ndbuff/DMEGA);fflush(stdout);
#endif
  }

  // keep track on the amount of memory consumed by the buffers
  ILUPACK_mem[0]=nibuff;
  ILUPACK_mem[1]=ndbuff;



  // total amount of memory requested by the parameters
  mem=elbow*(size_t)A->ia[A->nr];
  if (mem<2*A->nr+1) {
     mem=2*A->nr+1;
     IPparam->elbow=(2.0*A->nr+1.0)/((size_t)A->ia[A->nr])+1.0e-4;
     elbow=IPparam->elbow;
  }
    
#ifdef PRINT_MEM
  printf("jlumem=%8.2fMB, alumem=%8.2fMB\n",IPparam->njlu/IMEGA,IPparam->nalu/DMEGA);fflush(stdout);
#endif
  if (IPparam->njlu==0) {
     IPparam->njlu=mem;
     IPparam->jlu=(integer *)  MALLOC(IPparam->njlu*sizeof(integer),
				  "symAMGfactor:jlu");
#ifdef PRINT_MEM
     printf("jlu(%8.2lfMB) allocated\n",mem/IMEGA);fflush(stdout);
#endif
  }
  else if (mem>IPparam->njlu) {
     IPparam->njlu=mem;
     IPparam->jlu=(integer *) REALLOC(IPparam->jlu,
				  IPparam->njlu*sizeof(integer),
				  "symAMGfactor:jlu");
#ifdef PRINT_MEM
     printf("jlu(%8.2fMB) re-allocated\n",mem/IMEGA);fflush(stdout);
#endif
  }
  jlu=IPparam->jlu;
  if (IPparam->nalu==0) {
     IPparam->nalu=mem;
     IPparam->alu=(FLOAT *) MALLOC(IPparam->nalu*sizeof(FLOAT),
				   "symAMGfactor:alu");
#ifdef PRINT_MEM
     printf("alu(%8.2fMB) allocated\n",mem/DMEGA);fflush(stdout);
#endif
  }
  else if (mem>IPparam->nalu) {
     IPparam->nalu=mem;
     IPparam->alu=(FLOAT *)REALLOC(IPparam->alu,
				   IPparam->nalu*sizeof(FLOAT),
				   "symAMGfactor:alu");
#ifdef PRINT_MEM
     printf("alu(%8.2fMB) re-allocated\n",mem/DMEGA);fflush(stdout);
#endif
  }
  alu=IPparam->alu;



  if (param&FINAL_PIVOTING)
     regular_pivoting=-1;
  else 
     regular_pivoting=0;
  // default settings for PILUC within ILUPACK
  if (param&COARSE_REDUCE)
     PILUCparam|=COARSE_REDUCE; 
  if (param&IMPROVED_ESTIMATE)
     PILUCparam|=IMPROVED_ESTIMATE;
  if (param&DROP_INVERSE)
     PILUCparam|=DROP_INVERSE;
  // additional legal options
  if (param&TISMENETSKY_SC)
     PILUCparam|=TISMENETSKY_SC;
  else if (param&SIMPLE_SC)
    PILUCparam|=SIMPLE_SC;
  if (param&DIAGONAL_COMPENSATION)
     PILUCparam|=DIAGONAL_COMPENSATION;

  if (param&AGGRESSIVE_DROPPING)
     PILUCparam|=AGGRESSIVE_DROPPING;

  if (param&STATIC_TESTVECTOR)
     PILUCparam|=STATIC_TESTVECTOR;
  if (param&DYNAMIC_TESTVECTOR)
     PILUCparam|=DYNAMIC_TESTVECTOR;

  if (param&SADDLE_POINT) {
     PILUCparam|=SADDLE_POINT;
     //printf("saddle point structure!\n");
     // build a stack of up to five pressure node
     npressurelist=5;
     pressurelist=(integer *)MALLOC(npressurelist*sizeof(integer),"symAMGfactor:pressurelist");
     pressuretopA=(integer *)MALLOC(npressurelist*sizeof(integer),"symAMGfactor:pressuretopA");
     pressuretopL=(integer *)MALLOC(npressurelist*sizeof(integer),"symAMGfactor:pressuretopL");
     npressurestackA=npressurelist*3;
     npressurestackL=2*npressurestackA;
     pressurestackA=(integer *)MALLOC(npressurestackA*sizeof(integer),"symAMGfactor:pressurestackA");
     pressurestackL=(integer *)MALLOC(npressurestackL*sizeof(integer),"symAMGfactor:pressurestackL");
     invheadA=(integer *)MALLOC(A->nr*sizeof(integer),"symAMGfactor:invheadA");
     invlistA=(integer *)MALLOC(A->nr*sizeof(integer),"symAMGfactor:invlistA");
     invheadL=(integer *)MALLOC(A->nr*sizeof(integer),"symAMGfactor:invheadL");
     invlistL=(integer *)MALLOC(A->nr*sizeof(integer),"symAMGfactor:invlistL");
     if (PILUCparam&TISMENETSKY_SC) {
        invheadLe=(integer *)MALLOC(A->nr*sizeof(integer),"symAMGfactor:invheadL");
	invlistLe=(integer *)MALLOC(A->nr*sizeof(integer),"symAMGfactor:invlistL");
     }
  }
  

  /* old version. This should have been managed by the parameter setup
  if (PILUCparam&(DIAGONAL_COMPENSATION|STATIC_TESTVECTOR|DYNAMIC_TESTVECTOR)) {
     if (PILUCparam&(STATIC_TESTVECTOR|DYNAMIC_TESTVECTOR)) {
        // test vector is given
        IPparam->ntestvector=MAX(2*n,IPparam->ntestvector);
        IPparam->testvector=(FLOAT *)REALLOC(IPparam->testvector,(size_t)IPparam->ntestvector*sizeof(FLOAT),"symAMGfactor:IPparam->testvector");
     }
     else {
        IPparam->ntestvector=2*n;
        IPparam->testvector=(FLOAT *)MALLOC((size_t)IPparam->ntestvector*sizeof(FLOAT),"symAMGfactor:IPparam->testvector");
	for (i=0; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	    IPparam->testvector[i]=1.0;
#else
	    IPparam->testvector[i].r=1.0;
	    IPparam->testvector[i].i=0.0;
#endif
	} // end for
     }
  }
  */

  // do we like to use some real multigrid method?
  if (IPparam->ipar[10]>0) {
     // remove possibly inconsistency in setup
     IPparam->ipar[6]&=~DISCARD_MATRIX;
     param           &=~DISCARD_MATRIX;
     if (IPparam->ipar[14]==4) {
        IPparam->ipar[6]|=COARSE_REDUCE;
        param           |=COARSE_REDUCE;
        PILUCparam      |=COARSE_REDUCE;
     }
  }



  discardA=0;
  if (param&DISCARD_MATRIX) {
     discardA=DISCARD_MATRIX;
  }
  // buffer to store 'true' ipar[6] from the time of the factorization
  IPparam->ipar[16]=PILUCparam|discardA;


  // store the logical gap between the allocated memory areas alu,jlu
  // and the pointers to the subsystems
  delta=(size_t *)MALLOC(A->nr*sizeof(size_t),"symAMGfactor:delta");
  for (i=0; i<A->nr; i++)
    delta[i]=0;
  /* block LU decomposition */
  S=*A; 

  n=(1+1.0/amgcancel)*S.nr;
  current=PRE;
  current->prev=NULL;
  current->A.ia=A->ia;
  current->A.ja=A->ja;
  current->A.a =A->a;
  current->A.nr=current->A.nc=A->nr;
  current->nextblock=NULL;
  
  nlev=0;
  PRE->nlev=nlev;

  // while (0<S.nr & S.nr<=amgcancel*n) {
  while (0<S.nr) {
	nlev++;
	PRE->nlev=nlev;
	
	// printf("lev %d\n",nlev);fflush(stdout);

        n=S.nr;
	if (nlev>1)
	{
	   current->next=(AMGLEVELMAT *)MALLOC((size_t)1*sizeof(AMGLEVELMAT),
					       "symAMGfactor:current->next");
#ifdef PRINT_INFO2
	   printf("lev %d, next level allocated\n",nlev);fflush(stdout);
#endif
	   current->next->prev=current;
	   current=current->next;
	}
	current->n=n;
	current->next=NULL;
	current->absdiag=NULL;
	current->nextblock=NULL;
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_ || defined _COMPLEX_SYMMETRIC_
	current->issymmetric=1;
#else
	current->issymmetric=0;
#endif
	current->isdefinite =0;
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	current->ishermitian=1;
#else
	current->ishermitian=0;
#endif
	current->isskew     =0;
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	current->isreal     =1;
#else
	current->isreal     =0;
#endif
#if defined _SINGLE_COMPLEX_ || defined _SINGLE_REAL_
	current->issingle   =1;
#else
	current->issingle   =0;
#endif
	

	// start counter for preprocessing/reordering/pivoting  and  scaling
	evaluate_time(&time_start,&systime);
	/* row and column scaling if desired */
	current->colscal=(FLOAT *)MALLOC((size_t)n*sizeof(FLOAT),
					 "symAMGfactor:current->colscal");
	current->rowscal=current->colscal;
	ILUPACK_mem[9]+=n;
#ifdef PRINT_INFO2
	printf("lev %d, colscal allocated\n",nlev);fflush(stdout);
#endif

	for (i=0; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	    current->colscal[i]=1;
#else
	    current->colscal[i].r=1;
	    current->colscal[i].i=0;
#endif
	}

	current->p   =(integer *)MALLOC((size_t)n*sizeof(integer),"symAMGfactor:current->p");
	current->invq=(integer *)MALLOC((size_t)n*sizeof(integer),"symAMGfactor:current->invq");
	ILUPACK_mem[8]+=2*n;
	for (i=0; i<n; i++)
	  current->p[i]=current->invq[i]=i+1;
	current->nB=current->n;
#ifdef PRINT_INFO2
	printf("lev %d, p,invq allocated\n",nlev);fflush(stdout);
#endif


	// auxilliary memory that is currently left over
	IPparam->niaux=IPparam->ndaux=mem;
	IPparam->iaux=jlu;
	IPparam->daux=alu;

	/* check whether the matrix is almost dense */
	/* We define a matrix to be dense if nnz(S)>1/3 n(n+1)/2 */
	nnz=S.ia[n]-1;

#ifdef PRINT_INLINE
	printf("n=%7d, nnz=%9d, %6.1fav",n,nnz,((double)nnz)/n);
#endif

	if (nlev>1 && ilucancel*nnz>((REALS)n)*(n+1)/2.0) {

#ifdef PRINT_INLINE
	   printf("\nswitched to full matrix processing\n");fflush(STDOUT);
#endif

	   
	   // start counter for SPTRF
	   evaluate_time(&time_start,&systime);
	   /* uncompress S if possible */

	   if (mem<(n*(size_t)(n+1))/2-nnz) {
	      if (nlev>1) {
	         delta_ia=jlu-S.ia;
		 delta_ja=jlu-S.ja;
		 delta_a =alu-S.a;
	      }
	      myimem=(n*(size_t)(n+1))/2-nnz-mem;
	      mem+=myimem;
	      IPparam->elbow+=((double)myimem)/A->ia[A->nr]+1.0e-4;
#ifdef PRINT_MEM
	      printf("jlumem=%8.2fMB, alumem=%8.2fMB, elbow=%8.2f\n",
		     IPparam->njlu/IMEGA,IPparam->nalu/DMEGA,IPparam->elbow);fflush(stdout);
#endif
	      IPparam->njlu+=myimem;
	      // printf("jlu_old=%lu,%lu,%lu\n",IPparam->jlu,jlu,jlu-IPparam->jlu);
	      // printf("alu_old=%lu,%lu,%lu\n",IPparam->alu,alu,alu-IPparam->alu);
	      IPparam->jlu=(integer *) REALLOC(IPparam->jlu,
					       IPparam->njlu*sizeof(integer),
					       "symAMGfactor:jlu");
#ifdef PRINT_MEM
	      printf("level %2d, jlu(%8.2fMB) re-allocated\n",nlev,IPparam->njlu/IMEGA);fflush(stdout);
#endif
	      IPparam->nalu+=myimem;
	      IPparam->alu=(FLOAT *)REALLOC(IPparam->alu,
					    IPparam->nalu*sizeof(FLOAT),
					    "symAMGfactor:alu");
#ifdef PRINT_MEM
	      printf("level %2d, alu(%8.2fMB) re-allocated\n",nlev,IPparam->nalu/DMEGA);fflush(stdout);
#endif
	      // remap pointers
	      curr=PRE;
	      for (i=0; i<nlev; i++) {
		  // so far sparse case only
		  curr->LU.ja=IPparam->jlu+delta[i];
		  curr->LU.a =IPparam->alu+delta[i];
		  curr=curr->next;
	      }
	      jlu=IPparam->jlu+delta[nlev-1];
	      alu=IPparam->alu+delta[nlev-1];
	      if (nlev>1) {
		 S.ia=jlu-delta_ia;
		 S.ja=jlu-delta_ja;
		 S.a =alu-delta_a;
	      }
	      // printf("jlu_new=%lu,%lu,%lu\n",IPparam->jlu,jlu,jlu-IPparam->jlu);
	      //printf("alu_new=%lu,%lu,%lu\n",IPparam->alu,alu,alu-IPparam->alu);
#ifdef PRINT_MEM
	      printf("level %2d, delta=%d, pointers remapped\n",nlev,delta[nlev-1]);fflush(stdout);
#endif
	   } // end if


	   if (mem<(n*(size_t)(n+1))/2-nnz) {
	      evaluate_time(&time_stop,&systime);
	      // compute total setup time
	      ILUP_sec[7]=time_stop-ILUP_sec[7];
	      // compute TOTAL time
	      ILUP_sec[8]=time_stop-ILUP_sec[8];
	      for (i=0; i<ILUPACK_secnds_length; i++)
		  ILUPACK_secnds[i]=ILUP_sec[i];
	      ierr=-2;
	      current->E.ia=current->F.ia=NULL;
	      current->E.ja=current->F.ja=NULL;
	      current->E.a =current->F.a =NULL;
	      current->LU.ja=jlu;
	      current->absdiag=NULL;

	      // undo scaling
	      r=PRE->rowscal;
	      c=PRE->colscal;
	      // adjust arrays
	      ia=A->ia;
	      ja=A->ja;
	      a =A->a;
	      ja--;
	      a--;
	      c--;
	      for (i=0; i<A->nr; i++) {
		for (j=ia[i]; j<ia[i+1]; j++) {
		    k=ja[j];
#if defined _SINGLE_REAL_ || defined _DOUBLE_REAL_
		    a[j]/=r[i]*c[k];
#else
		    a[j].r/=r[i].r*c[k].r;
		    a[j].i/=r[i].r*c[k].r;
#endif	  
		}
	      }

	      MYSYMAMGDELETE(A, PRE, IPparam);

	      if (param&SADDLE_POINT) {
		free(pressurelist);
		free(pressuretopA);
		free(pressuretopL);
		free(pressurestackA);
		free(pressurestackL);
		free(invheadA);
		free(invlistA);
		free(invheadL);
		free(invlistL);
		if (PILUCparam&TISMENETSKY_SC) {
		  free(invheadLe);
		  free(invlistLe);
		}
	      }

	      return (ierr);
	   }
	   

	   /* position in alu behind the uncompressed matrix */
	   alu+=(n*(size_t)(n+1))/2-nnz;
	   delta[nlev-1]-=nnz;
	   // additional memory needed
	   ILUPACK_mem[2]+=0;
	   ILUPACK_mem[3]+=(n*(size_t)(n+1))/2-nnz;
	   ILUPACK_mem[5]=MAX(ILUPACK_mem[5],ILUPACK_mem[3]);
	   S.ja--;
	   S.a--;
	   for (i=n-1; i>=0; i--) {
	       for (j=i; j<n; j++) 
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		   IPparam->dbuff[j]=0;
#else
	           IPparam->dbuff[j].r=IPparam->dbuff[j].i=0;
#endif
	       IPparam->dbuff--;
	       for (j=S.ia[i]; j<S.ia[i+1]; j++)
		   IPparam->dbuff[S.ja[j]]=S.a[j];
	       IPparam->dbuff++;
	       alu-=(n-i);
	       for (j=i; j<n; j++)
		   alu[j-i]=IPparam->dbuff[j];
	   }
	   S.ja++;
	   S.a++;
	   current->LUperm=NULL;


#ifdef PRINT_INFO
	   printf("dense A\n");fflush(STDOUT);
	   for (i=0; i<n; i++)
	     printf("%12d",S.ia[i]);
	   printf("\n");fflush(stdout);
	   j=0;
	   for (k=0; k<n; k++) {
	     for (i=k; i<n; i++) {
	       printf("%12.4le",S.a[j++]);
	     }
	     printf("\n");fflush(stdout);
	   }
	   printf("\n");fflush(stdout);
#endif
	   MYSPTRF("L",&n,S.a,S.ia,&ierr,1); 
#ifdef PRINT_INFO
	   printf("dense U\n");fflush(STDOUT);
	   for (i=0; i<n; i++)
	     printf("%12d",S.ia[i]);
	   printf("\n");fflush(stdout);
	   j=0;
	   for (k=0; k<n; k++) {
	     for (i=k; i<n; i++) {
	       printf("%12.4le",S.a[j++]);
	     }
	     printf("\n");fflush(stdout);
	   }
	   printf("\n");fflush(stdout);
#endif
	   // store SPTRF computation time
	   evaluate_time(&time_stop,&systime);
	   ILUP_sec[4]=time_stop-time_start;

	   if (ierr) { 
	      // compute total setup time
	      ILUP_sec[7]=time_stop-ILUP_sec[7];
	      // compute TOTAL time
	      ILUP_sec[8]=time_stop-ILUP_sec[8];
	      for (i=0; i<ILUPACK_secnds_length; i++)
	          ILUPACK_secnds[i]=ILUP_sec[i];
	      current->E.ia=current->F.ia=NULL;
	      current->E.ja=current->F.ja=NULL;
	      current->E.a =current->F.a =NULL;
	      current->LU.ja=jlu;
	      current->absdiag=NULL;

	      // undo scaling
	      r=PRE->rowscal;
	      c=PRE->colscal;
	      // adjust arrays
	      ia=A->ia;
	      ja=A->ja;
	      a=A->a;
	      ja--;
	      a--;
	      c--;
	      for (i=0; i<A->nr; i++) {
		for (j=ia[i]; j<ia[i+1]; j++) {
		    k=ja[j];
#if defined _SINGLE_REAL_ || defined _DOUBLE_REAL_
		    a[j]/=r[i]*c[k];
#else
		    a[j].r/=r[i].r*c[k].r;
		    a[j].i/=r[i].r*c[k].r;
#endif	  
		}
	      }

	      MYSYMAMGDELETE(A, PRE, IPparam);

	      if (param&SADDLE_POINT) {
		free(pressurelist);
		free(pressuretopA);
		free(pressuretopL);
		free(pressurestackA);
		free(pressurestackL);
		free(invheadA);
		free(invlistA);
		free(invheadL);
		free(invlistL);
		if (PILUCparam&TISMENETSKY_SC) {
		  free(invheadLe);
		  free(invlistLe);
		}
	      }

	      return (ierr);
	   }
	   current->nB=n;
	     
	   current->E.nr=current->F.nc=0;
	   current->E.nc=current->F.nr=0;
	   
	   current->LU.nr=current->nB;
	   current->LU.nc=current->LU.nr;
	   current->LU.a =alu;
	   current->LU.ja=NULL;
	   current->LU.ia=S.ia;

	   n=-1;
	   S.nr=0;
	}
	else { /* the matrix is still sparse */

	  // use reverse communication to generate a dynamic test vector
	  if (PILUCparam&DIAGONAL_COMPENSATION && PILUCparam&DYNAMIC_TESTVECTOR) {
#ifdef PRINT_RC
	     printf("prepare for reverse communication and return from SYMAMGFACTOR before label 1\n");fflush(stdout);
#endif
	     IPparam->rcomflag=-1;
	     IPparam->returnlabel=1;
	     IPparam->tv=IPparam->testvector;
	     IPparam->A =S;

	     // save local variables
	     IPparam->istack[ 0]=i;
	     IPparam->istack[ 1]=j;
	     IPparam->istack[ 2]=k;
	     IPparam->istack[ 3]=l;
	     IPparam->istack[ 4]=n;
	     IPparam->istack[ 5]=PILUCparam;
	     IPparam->istack[ 6]=nnz;
	     IPparam->istack[ 7]=nB;
	     IPparam->istack[ 8]=ierr;
	     IPparam->istack[ 9]=regular_pivoting;
	     IPparam->istack[10]=lfil[0];
	     IPparam->istack[11]=lfil[1];
	     IPparam->istack[12]=elbow;
	     IPparam->istack[13]=param;
	     IPparam->istack[14]=discardA;
	     IPparam->istack[15]=shiftA;
	     IPparam->istack[16]=imem;
	     IPparam->istack[17]=nlev;

	     IPparam->istack[18]=npressurelist;
	     IPparam->istack[19]=npressurestackA;
	     IPparam->istack[20]=npressurestackL;

	     IPparam->pistack[ 0]=jlu;
	     IPparam->pistack[ 1]=ia;
 	     IPparam->pistack[ 2]=ja;

 	     IPparam->pistack[ 3]=pressurelist;
 	     IPparam->pistack[ 4]=pressuretopA;
 	     IPparam->pistack[ 5]=pressuretopL;
 	     IPparam->pistack[ 6]=pressurestackA;
 	     IPparam->pistack[ 7]=pressurestackL;
 	     IPparam->pistack[ 8]=invheadA;
 	     IPparam->pistack[ 9]=invlistA;
 	     IPparam->pistack[10]=invheadL;
 	     IPparam->pistack[11]=invlistL;
 	     IPparam->pistack[12]=invheadLe;
 	     IPparam->pistack[13]=invlistLe;


 	     IPparam->rstack[ 0]=droptols[0];
 	     IPparam->rstack[ 1]=droptols[1];
 	     IPparam->rstack[ 2]=droptols[2];
 	     IPparam->rstack[ 3]=condest;
 	     IPparam->rstack[ 4]=amgcancel;
 	     IPparam->rstack[ 5]=ilucancel;
 	     IPparam->rstack[ 6]=seps;
 	     IPparam->rstack[ 7]=ptol;
 	     IPparam->rstack[ 8]=val;
 	     IPparam->rstack[ 9]=vb;
 	     IPparam->rstack[10]=systime;
 	     IPparam->rstack[11]=time_start;
 	     IPparam->rstack[12]=time_stop;
 	     IPparam->rstack[13]=secnds;
 	     IPparam->rstack[14]=ILUP_sec[ 0];
 	     IPparam->rstack[15]=ILUP_sec[ 1];
 	     IPparam->rstack[16]=ILUP_sec[ 2];
 	     IPparam->rstack[17]=ILUP_sec[ 3];
 	     IPparam->rstack[18]=ILUP_sec[ 4];
 	     IPparam->rstack[19]=ILUP_sec[ 5];
 	     IPparam->rstack[20]=ILUP_sec[ 6];
 	     IPparam->rstack[21]=ILUP_sec[ 7];
 	     IPparam->rstack[22]=ILUP_sec[ 8];
 	     IPparam->rstack[23]=ILUP_sec[ 9];
 	     IPparam->rstack[24]=condest0;
	     IPparam->rstack[25]=condest_increase; 

 	     IPparam->pfstack[0]=alu;
 	     IPparam->pfstack[1]=a;
 	     IPparam->pfstack[2]=r;
 	     IPparam->pfstack[3]=c;
  
 	     IPparam->ststack[0]=nibuff;
 	     IPparam->ststack[1]=ndbuff;
 	     IPparam->ststack[2]=mem;

 	     IPparam->pststack[0]=delta;

 	     IPparam->mstack[0]=S;

 	     IPparam->amglmstack[0]=current;

 	     IPparam->intfctstack[0]=perm0;
 	     IPparam->intfctstack[1]=perm;
 	     IPparam->intfctstack[2]=permf;

	     // printf("stack completed\n");fflush(stdout);
	     return (0);
	  }

label1:
	  if (IPparam->returnlabel==1) {
#ifdef PRINT_RC
	     printf("re-enter SYMAMGFACTOR from reverse communication at label 1\n");fflush(stdout);
#endif
	     // load local variables
	     i               =IPparam->istack[ 0];
	     j               =IPparam->istack[ 1];
             k               =IPparam->istack[ 2];
             l               =IPparam->istack[ 3];
             n               =IPparam->istack[ 4];
             PILUCparam      =IPparam->istack[ 5];
             nnz             =IPparam->istack[ 6];
             nB              =IPparam->istack[ 7];
             ierr            =IPparam->istack[ 8];
             regular_pivoting=IPparam->istack[ 9];
             lfil[0]         =IPparam->istack[10];
             lfil[1]         =IPparam->istack[11];
             elbow           =IPparam->istack[12];
             param           =IPparam->istack[13];
             discardA        =IPparam->istack[14];
             shiftA          =IPparam->istack[15];
             imem            =IPparam->istack[16];
             nlev            =IPparam->istack[17];

	     npressurelist   =IPparam->istack[18];
	     npressurestackA =IPparam->istack[19];
	     npressurestackL =IPparam->istack[20];


	     jlu           =IPparam->pistack[ 0];
	     ia            =IPparam->pistack[ 1];
 	     ja            =IPparam->pistack[ 2];

 	     pressurelist  =IPparam->pistack[ 3];
 	     pressuretopA  =IPparam->pistack[ 4];
 	     pressuretopL  =IPparam->pistack[ 5];
 	     pressurestackA=IPparam->pistack[ 6];
 	     pressurestackL=IPparam->pistack[ 7];
 	     invheadA      =IPparam->pistack[ 8];
 	     invlistA      =IPparam->pistack[ 9];
 	     invheadL      =IPparam->pistack[10];
 	     invlistL      =IPparam->pistack[11];
 	     invheadLe     =IPparam->pistack[12];
 	     invlistLe     =IPparam->pistack[13];


 	     droptols[0] =IPparam->rstack[ 0];
 	     droptols[1] =IPparam->rstack[ 1];
 	     droptols[2] =IPparam->rstack[ 2];
 	     condest     =IPparam->rstack[ 3];
 	     amgcancel   =IPparam->rstack[ 4];
 	     ilucancel   =IPparam->rstack[ 5];
 	     seps	 =IPparam->rstack[ 6];
 	     ptol	 =IPparam->rstack[ 7];
 	     val	 =IPparam->rstack[ 8];
 	     vb	         =IPparam->rstack[ 9];
 	     systime     =IPparam->rstack[10];
 	     time_start  =IPparam->rstack[11];
 	     time_stop   =IPparam->rstack[12];
 	     secnds      =IPparam->rstack[13];
 	     ILUP_sec[ 0]=IPparam->rstack[14];
 	     ILUP_sec[ 1]=IPparam->rstack[15];
 	     ILUP_sec[ 2]=IPparam->rstack[16];
 	     ILUP_sec[ 3]=IPparam->rstack[17];
 	     ILUP_sec[ 4]=IPparam->rstack[18];
 	     ILUP_sec[ 5]=IPparam->rstack[19];
 	     ILUP_sec[ 6]=IPparam->rstack[20];
 	     ILUP_sec[ 7]=IPparam->rstack[21];
 	     ILUP_sec[ 8]=IPparam->rstack[22];
 	     ILUP_sec[ 9]=IPparam->rstack[23];
 	     condest0    =IPparam->rstack[24];
	     condest_increase=IPparam->rstack[25]; 

 	     alu=IPparam->pfstack[0];
 	     a  =IPparam->pfstack[1]; 
 	     r  =IPparam->pfstack[2]; 
 	     c  =IPparam->pfstack[3];
  
 	     nibuff=IPparam->ststack[0];
             ndbuff=IPparam->ststack[1];
	     mem   =IPparam->ststack[2];

 	     delta=IPparam->pststack[0];

 	     S=IPparam->mstack[0];
 	     current=IPparam->amglmstack[0];

 	     perm0=IPparam->intfctstack[0];
 	     perm =IPparam->intfctstack[1];
 	     permf=IPparam->intfctstack[2];
	     // if necessary manipulate testvector
	  }
	  IPparam->rcomflag=0;
	  IPparam->returnlabel=0;

	  // printf("1.\n",current->nB);fflush(STDOUT);
	  /*
	  for (i=0; i<S.nc; i++) {
	      for (j=S.ia[i]-1; j<S.ia[i+1]-1; j++) {
		  printf("%6ld%6ld%16.8le\n",i+1,S.ja[j],S.a[j]);
	      }
	  }
	  printf("\n");
	  fflush(stdout);
	  */

	  // apply reordering techniques 
	  current->absdiag=NULL;
	  // initial reordering
	  if (nlev==1 && (param&PREPROCESS_INITIAL_SYSTEM)) {
	     IPparam->ipar[7]&=~1024;
	     IPparam->ipar[7]|=512;
	     ierr=(*perm0)(S, current->rowscal, current->colscal,current->p,
			   current->invq, &current->nB, IPparam);
	     IPparam->ipar[7]&=~(512+1024);
	  }
	  else 
	    // final pivoting
	    if (nlev>1 && (param&FINAL_PIVOTING) && !regular_pivoting) { 
	       IPparam->ipar[7]|=512+1024;
	       ierr=(*permf)(S, current->rowscal, current->colscal, current->p,
			     current->invq, &current->nB, IPparam);
	       IPparam->ipar[7]&=~(512+1024);
	    } // end if-elseif-if
	    else
	       // regular pivoting
	       if (nlev>1 && (param&PREPROCESS_SUBSYSTEMS)) { 
		  IPparam->ipar[7]&=~512;
		  IPparam->ipar[7]|=1024;
		  ierr=(*perm)(S, current->rowscal, current->colscal, current->p,
			       current->invq, &current->nB, IPparam);
		  IPparam->ipar[7]&=~(512+1024);
	       } // end if-elseif-elseif


	  evaluate_time(&time_stop,&systime);
	  if (nlev==1)
	     // time for initial preprocessing + scaling
	     ILUP_sec[0] =time_stop-time_start;
	  else
	     // accumulated time for reordering/pivoting and scaling 
	     // the remaining systems
	     ILUP_sec[1]+=time_stop-time_start;

	  if (ierr) {
	     // compute total setup time
	     ILUP_sec[7]=time_stop-ILUP_sec[7];
	     // compute TOTAL time
	     ILUP_sec[8]=time_stop-ILUP_sec[8];
	     for (i=0; i<ILUPACK_secnds_length; i++)
		 ILUPACK_secnds[i]=ILUP_sec[i];
	     current->E.ia=current->F.ia=NULL;
	     current->E.ja=current->F.ja=NULL;
	     current->E.a =current->F.a =NULL;
	     current->LU.ja=jlu;
	     current->absdiag=NULL;

	     // undo scaling
	     r=PRE->rowscal;
	     c=PRE->colscal;
	     // adjust arrays
	     ia=A->ia;
	     ja=A->ja;
	     a=A->a;
	     ja--;
	     a--;
	     c--;
	     for (i=0; i<A->nr; i++) {
	         for (j=ia[i]; j<ia[i+1]; j++) {
		     k=ja[j];
#if defined _SINGLE_REAL_ || defined _DOUBLE_REAL_
		     a[j]/=r[i]*c[k];
#else
		     a[j].r/=r[i].r*c[k].r;
		     a[j].i/=r[i].r*c[k].r;
#endif	  
		 }
	     }

	     MYSYMAMGDELETE(A, PRE, IPparam);

	     if (param&SADDLE_POINT) {
	       free(pressurelist);
	       free(pressuretopA);
	       free(pressuretopL);
	       free(pressurestackA);
	       free(pressurestackL);
	       free(invheadA);
	       free(invlistA);
	       free(invheadL);
	       free(invlistL);
	       if (PILUCparam&TISMENETSKY_SC) {
		 free(invheadLe);
		 free(invlistLe);
	       }
	     }

	     return (ierr);
	  }

	  // printf("2.\n",current->nB);fflush(STDOUT);

	  if ((n-current->nB > amgcancel*n || current->nB==0) && 
	      (param&FINAL_PIVOTING) && regular_pivoting) {
	     // switch to final pivoting
#ifdef PRINT_INLINE
  	     printf("\nswitched to final pivoting\n");fflush(STDOUT);
#endif
	     regular_pivoting=0;
	     amgcancel  =IPparam->fpar[5]; 
	     current->nB=n;
	     evaluate_time(&time_start,&systime);
	     IPparam->ipar[7]|=512+1024;
	     ierr=(*permf)(S, current->rowscal, current->colscal, current->p,
			   current->invq, &current->nB, IPparam);
	     IPparam->ipar[7]&=~(512+1024);

	     evaluate_time(&time_stop,&systime);
	     if (nlev==1)
	        // time for initial preprocessing + scaling
	        ILUP_sec[0] =time_stop-time_start;
	     else
	        // accumulated time for reordering/pivoting and scaling 
	        // the remaining systems
	        ILUP_sec[1]+=time_stop-time_start;

	     if (ierr) {
	        // compute total setup time
	        ILUP_sec[7]=time_stop-ILUP_sec[7];
		// compute TOTAL time
		ILUP_sec[8]=time_stop-ILUP_sec[8];
		for (i=0; i<ILUPACK_secnds_length; i++)
		    ILUPACK_secnds[i]=ILUP_sec[i];
		current->E.ia=current->F.ia=NULL;
		current->E.ja=current->F.ja=NULL;
		current->E.a =current->F.a =NULL;
		current->LU.ja=jlu;
		current->absdiag=NULL;

		// undo scaling
		r=PRE->rowscal;
		c=PRE->colscal;
		// adjust arrays
		ia=A->ia;
		ja=A->ja;
		a=A->a;
		ja--;
		a--;
		c--;
		for (i=0; i<A->nr; i++) {
		    for (j=ia[i]; j<ia[i+1]; j++) {
		        k=ja[j];
#if defined _SINGLE_REAL_ || defined _DOUBLE_REAL_
			a[j]/=r[i]*c[k];
#else
			a[j].r/=r[i].r*c[k].r;
			a[j].i/=r[i].r*c[k].r;
#endif	  
		    }
		}

		MYSYMAMGDELETE(A, PRE, IPparam);

		if (param&SADDLE_POINT) {
		  free(pressurelist);
		  free(pressuretopA);
		  free(pressuretopL);
		  free(pressurestackA);
		  free(pressurestackL);
		  free(invheadA);
		  free(invlistA);
		  free(invheadL);
		  free(invlistL);
		  if (PILUCparam&TISMENETSKY_SC) {
		    free(invheadLe);
		    free(invlistLe);
		  }
		}

		return (ierr);
	     }
	  } // end if

	  // printf("3.\n",current->nB);fflush(STDOUT);

	  nB=current->nB;
	  /* perform PILUC decomposition */

	  current->LUperm=NULL;

#ifdef PRINT_INLINE
	  printf(", nB=%7d->",current->nB);fflush(STDOUT);
#endif
	  /*
	  if (nlev==1) {
	    FILE *fp;
	    fp=fopen("ptot","r");
	    for (i=0; i<n; i++)
	      fscanf(fp,"%d",current->p+i);
	      
	    for (i=0; i<n; i++)
	      current->invq[current->p[i]-1]=i+1;
	    fclose(fp);
	    //for (i=0; i<n; i++)
	    //  printf("%6d",current->p[i]);
	    //printf("\n");fflush(stdout);
	  }
	  */

	  if (current->nB>0) {
	     // start counter for sympiluc
	     evaluate_time(&time_start,&systime);
	     condest1=condest;
	     condest/=2.0;
	     mymaximem=0;
	     do {
	        current->nB=nB;
		ierr=0;
	        condest*=2.0;
		// printf("level %2d, condest=%8.1le\n",nlev,condest);fflush(stdout);
		if (nlev>1)
		   PILUCparam|=discardA;
		shiftA=0;

		if (PILUCparam&(DIAGONAL_COMPENSATION|STATIC_TESTVECTOR|DYNAMIC_TESTVECTOR)) {
		   // rescale test vector
		   for (i=0; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		       IPparam->testvector[i]/=current->colscal[i];
#else
		       val=1.0/(current->colscal[i].r*current->colscal[i].r +
				current->colscal[i].i*current->colscal[i].i);
		       vb=IPparam->testvector[i].r;
		       IPparam->testvector[i].r=( vb*current->colscal[i].r
						  +IPparam->testvector[i].i*current->colscal[i].i)*val;
		       IPparam->testvector[i].i=(-vb*current->colscal[i].i
						 +IPparam->testvector[i].i*current->colscal[i].r)*val;
#endif
		   } // end for i
		   // compute a permuted copy
		   for (i=0; i<n; i++) {
		       IPparam->testvector[n+current->invq[i]-1]=IPparam->testvector[i];
		   } // end for i
		} // end if
		if (PILUCparam&SADDLE_POINT) {
		   // compute a permuted copy
		   for (i=0; i<n; i++) 
		       IPparam->indicator[n+current->invq[i]-1]=IPparam->indicator[i];
		} // end if

		posiwk=0;
		if (nlev>1) {
		   delta_ia=jlu-S.ia;
		   delta_ja=jlu-S.ja;
		   delta_a =alu-S.a;
		}
		do {
		   imem=(LONG_INT)mem;
		   if (param&MULTI_PILUC){
		      SYMPILUC(&n,S.a,S.ja,S.ia,lfil,droptols,&condest,
			       // IPparam->fpar+6,
			       &current->nB,&PILUCparam,current->p,current->invq,alu,
			       jlu,&imem,IPparam->dbuff,IPparam->ibuff,&shiftA,
			       &amgcancel,IPparam->testvector,IPparam->indicator, &posiwk, &ierr,
			       &npressurelist,  pressurelist,
			       &npressurestackA,pressurestackA,pressuretopA,
			       &npressurestackL,pressurestackL,pressuretopL,
			       invheadA, invlistA, 
			       invheadL, invlistL,
			       invheadLe,invlistLe);
		   }
		   else {
		     SYMPILUC(&n,S.a,S.ja,S.ia,lfil,droptols,&condest,
			      &current->nB,&PILUCparam,current->p,current->invq,alu,
			      jlu,&imem,IPparam->dbuff,IPparam->ibuff,&shiftA,
			      &amgcancel,IPparam->testvector,IPparam->indicator, &posiwk, &ierr,
			      &npressurelist,  pressurelist,
			      &npressurestackA,pressurestackA,pressuretopA,
			      &npressurestackL,pressurestackL,pressuretopL,
			      invheadA, invlistA, 
			      invheadL, invlistL,
			      invheadLe,invlistLe);
		   }
		   mymaximem=MAX(mymaximem,imem);
		   
		   if (posiwk>0) {
		      // total amount of memory requested by the parameters
		      myimem=elbow*(size_t)A->ia[A->nr];
		      mem+=myimem;
		      IPparam->elbow+=elbow;
#ifdef PRINT_MEM
		      printf("posiwk=%d,jlumem=%8.2fMB, alumem=%8.2fMB, elbow=%8.2f\n",
			     posiwk,IPparam->njlu/IMEGA,IPparam->nalu/DMEGA,IPparam->elbow);
		      fflush(stdout);
#endif
		      IPparam->njlu+=myimem;
		      // printf("jlu_old=%lu,%lu,%lu\n",IPparam->jlu,jlu,jlu-IPparam->jlu);
		      // printf("alu_old=%lu,%lu,%lu\n",IPparam->alu,alu,alu-IPparam->alu);
		      IPparam->jlu=(integer *) REALLOC(IPparam->jlu,
						       IPparam->njlu*sizeof(integer),
						       "symAMGfactor:jlu");
#ifdef PRINT_MEM
		      printf("level %2d, jlu(%8.2fMB) re-allocated\n",nlev,IPparam->njlu/IMEGA);fflush(stdout);
#endif
		      IPparam->nalu+=myimem;
		      IPparam->alu=(FLOAT *)REALLOC(IPparam->alu,
						    IPparam->nalu*sizeof(FLOAT),
						    "symAMGfactor:alu");
#ifdef PRINT_MEM
		      printf("level %2d, alu(%8.2fMB) re-allocated\n",nlev,IPparam->nalu/DMEGA);fflush(stdout);
#endif
		      // remap pointers
		      curr=PRE;
		      for (i=0; i<nlev; i++) {
			
			  // only sparse case
			  curr->LU.ja=IPparam->jlu+delta[i];
			  curr->LU.a =IPparam->alu+delta[i];
			  curr=curr->next;
		      }
		      jlu=IPparam->jlu+delta[nlev-1];
		      alu=IPparam->alu+delta[nlev-1];
		      if (nlev>1) {
			 S.ia=jlu-delta_ia;
			 S.ja=jlu-delta_ja;
			 S.a =alu-delta_a;
		      }
		      // printf("jlu_new=%lu,%lu,%lu\n",IPparam->jlu,jlu,jlu-IPparam->jlu);
		      // printf("alu_new=%lu,%lu,%lu\n",IPparam->alu,alu,alu-IPparam->alu);
#ifdef PRINT_MEM
		      printf("level %2d, delta=%d, pointers remapped\n",nlev,delta[nlev-1]);fflush(stdout);
#endif
		   } // end if posiwk>0
		}
		while (posiwk>0);
		// printf("level %2d, nB=%6ld\n",nlev,current->nB);fflush(stdout);

	     }
	     while (nB-current->nB>amgcancel*nB && 
		    condest<1024*condest0 && condest<16*condest1);
	     
	     
	     // printf("%d,%f,%f\n",nB-current->nB,amgcancel*nB, condest_increase*nB);fflush(stdout);

	     // if PILUC successfully reduced the matrix, but if the
	     // reduction was not great, then we increase condest
	     // hoping to be more successful on the next level
	     if (n-current->nB>condest_increase*nB && 
		 condest<1024*condest0 && condest<16*condest1) {
	        condest*=2.0;
	        // printf("condest doubled, lev=%d\n",nlev);fflush(stdout);
	     }

	     // printf("sympiluc completed, nlev=%d\n",nlev);fflush(stdout);

	     // transfer condest back to the parameter array, if we had to increment condest
	     // already on the initial level
	     if (nlev==1 && condest>IPparam->condest)
	        IPparam->condest=condest;

	     alu-=shiftA;
	     jlu-=shiftA;
	     delta[nlev-1]-=shiftA;
	     // stop counter for (m)piluc
	     evaluate_time(&time_stop,&systime);
	     // accumulate collective time for (m)piluc
	     ILUP_sec[2]+=time_stop-time_start;
	     if (ierr) {
	        // compute total setup time
	        ILUP_sec[7]=time_stop-ILUP_sec[7];
		// compute TOTAL time
		ILUP_sec[8]=time_stop-ILUP_sec[8];
	        for (i=0; i<ILUPACK_secnds_length; i++)
		    ILUPACK_secnds[i]=ILUP_sec[i];
		current->E.ia=current->F.ia=NULL;
		current->E.ja=current->F.ja=NULL;
		current->E.a =current->F.a =NULL;
		current->LU.ja=jlu;
		current->absdiag=NULL;

		// undo scaling
		r=PRE->rowscal;
		c=PRE->colscal;
		// adjust arrays
		ia=A->ia;
		ja=A->ja;
		a=A->a;
		ja--;
		a--;
		c--;
		for (i=0; i<A->nr; i++) {
		    for (j=ia[i]; j<ia[i+1]; j++) {
		        k=ja[j];
#if defined _SINGLE_REAL_ || defined _DOUBLE_REAL_
			a[j]/=r[i]*c[k];
#else
			a[j].r/=r[i].r*c[k].r;
			a[j].i/=r[i].r*c[k].r;
#endif	  
		    }
		}

		MYSYMAMGDELETE(A, PRE, IPparam);

		if (param&SADDLE_POINT) {
		  free(pressurelist);
		  free(pressuretopA);
		  free(pressuretopL);
		  free(pressurestackA);
		  free(pressurestackL);
		  free(invheadA);
		  free(invlistA);
		  free(invheadL);
		  free(invlistL);
		  if (PILUCparam&TISMENETSKY_SC) {
		    free(invheadLe);
		    free(invlistLe);
		  }
		}

		return (ierr);
	     }
	  }

#ifdef PRINT_INLINE
	  printf("%7d\n",current->nB);fflush(STDOUT);
#endif
	  // printf("no error occured\n");fflush(stdout);


#ifdef PRINT_INFO
	  printf("1.computed U-factor\n");fflush(STDOUT);
	  for (i=0; i<current->nB; ) {
	    if (jlu[n+1+i]==0){
	      for (k=jlu[i];k<jlu[i+1]; k++) 
		printf("%8d",jlu[k-1]);
	      printf("\n");fflush(STDOUT);
	      for (k=jlu[i];k<jlu[i+1]; k++) 
		printf("%8.1le",alu[k-1]);
	      printf("\n");fflush(STDOUT);
	      i++;
	    }
	    else {
	      for (k=jlu[i];k<jlu[i+1]; k++) 
		printf("%8d",jlu[k-1]);
	      printf("\n");fflush(STDOUT);
	      for (k=jlu[i];k<jlu[i+1]; k++) 
		printf("%8.1le",alu[jlu[i]+2*(k-jlu[i])-1]);
	      printf("\n");fflush(STDOUT);
	      for (k=jlu[i];k<jlu[i+1]; k++) 
		printf("%8.1le",alu[jlu[i]+2*(k-jlu[i])]);
	      printf("\n");fflush(STDOUT);
	      i+=2;
	    }
	  }
	  printf("\n");fflush(STDOUT);
	  printf("Block diagonal factor\n");
	  for (k=0; k<current->nB;) {
	    if (jlu[n+1+k]==0){
	      printf("%8.1le",alu[k]);
	      k++;
	    }
	    else {
	      printf("%8.1le%8.1le",alu[k],alu[n+1+k]);
	      k+=2;
	    }
	  }
	  printf("\n");fflush(stdout);
	  for (k=0; k<current->nB; ) {
	    if (jlu[n+1+k]==0) {
	      printf("        ");
	      k++;
	    }
	    else {
	      printf("%8.1le%8.1le",alu[n+1+k],alu[k+1]);
	      k+=2;
	    }
	  }
	  printf("\n");fflush(stdout);
	  printf("computed Schur complement\n");fflush(STDOUT);
	  for (i=current->nB; i<n; i++) {
	    for (k=jlu[i];k<jlu[i+1]; k++) 
	      printf("%8d",jlu[k-1]);
	    printf("\n");fflush(STDOUT);
	    for (k=jlu[i];k<jlu[i+1]; k++) 
	      printf("%8.1le",alu[k-1]);
	    printf("\n");fflush(STDOUT);
	  }

	  for (i=0; i<=current->nB; i++)
	    printf("%8d",i+1);
	  printf("\n");fflush(stdout);
	  for (i=0; i<=current->nB; i++)
	    printf("%8d",jlu[i]);
	  printf("\n");fflush(stdout);
	  for (i=0; i<current->nB; i++)
	    printf("%8d",jlu[n+1+i]);
	  printf("\n");fflush(stdout);
#endif


	  
	  // COMMENT: Maybe in a later version the extraction of E and F and discarding the old
	  //          S should be done in one shot. This is reasonable, since (for nlev>1) the old
	  //          matrix S is not needed any longer and to create some new space to store E and
	  //          F is not really necessary. But this is very technical, since the rows of S
	  //          have to be reordered in order to construct E and F :(


	  // appearently piluc failed
	  // BUT we set the final pivoting flag
	  // AND we haven't switched to final pivoting yet
	  if ((nB-current->nB > amgcancel*nB || nB==0) && 
	      (param&FINAL_PIVOTING) && regular_pivoting) {
	     // switch to final pivoting
#ifdef PRINT_INLINE
  	     printf("\nswitched to final pivoting\n");fflush(STDOUT);
#endif


	     if (PILUCparam&(DIAGONAL_COMPENSATION|STATIC_TESTVECTOR|DYNAMIC_TESTVECTOR)) {
	        // undo rescale test vector
	        for (i=0; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		    IPparam->testvector[i]*=current->colscal[i];
#else
		    vb=IPparam->testvector[i].r;
		    IPparam->testvector[i].r= vb*current->colscal[i].r
					     -IPparam->testvector[i].i*current->colscal[i].i;
		    IPparam->testvector[i].i= vb*current->colscal[i].i
					     +IPparam->testvector[i].i*current->colscal[i].r;
#endif
		} // end for i
	     } // end if
	     // undo scaling for S
	     for (i=0; i<n; i++) {
		 for (j=S.ia[i]-1; j<S.ia[i+1]-1; j++) {
		     l=S.ja[j]-1;
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		     S.a[j]=S.a[j]/(current->rowscal[i]*current->colscal[l]);
#else
		     val=1.0/(current->rowscal[i].r*current->rowscal[i].r +
			      current->rowscal[i].i*current->rowscal[i].i);
		     vb=S.a[j].r;
		     S.a[j].r=(     vb*current->rowscal[i].r
			     +S.a[j].i*current->rowscal[i].i)*val;
		     S.a[i].i=(    -vb*current->rowscal[i].i
			     +S.a[j].i*current->rowscal[i].r)*val;

		     val=1.0/(current->colscal[l].r*current->colscal[l].r +
			      current->colscal[l].i*current->colscal[l].i);
		     vb=S.a[j].r;
		     S.a[j].r=(     vb*current->colscal[l].r
			     +S.a[j].i*current->colscal[l].i)*val;
		     S.a[i].i=(    -vb*current->colscal[l].i
			     +S.a[j].i*current->colscal[l].r)*val;
#endif
		 }
	     } // end for i


	     regular_pivoting=0;
	     amgcancel  =IPparam->fpar[5]; 
	     current->nB=n;
	     evaluate_time(&time_start,&systime);
	     IPparam->ipar[7]|=512+1024;
	     ierr=(*permf)(S, current->rowscal, current->colscal, current->p,
			   current->invq, &current->nB, IPparam);
	     IPparam->ipar[7]&=~(512+1024);

	     evaluate_time(&time_stop,&systime);
	     if (nlev==1)
	        // time for initial preprocessing + scaling
	        ILUP_sec[0] =time_stop-time_start;
	     else
	        // accumulated time for reordering/pivoting and scaling 
	        // the remaining systems
	        ILUP_sec[1]+=time_stop-time_start;

	     if (ierr) {
	        // compute total setup time
	        ILUP_sec[7]=time_stop-ILUP_sec[7];
		// compute TOTAL time
		ILUP_sec[8]=time_stop-ILUP_sec[8];
		for (i=0; i<ILUPACK_secnds_length; i++)
		    ILUPACK_secnds[i]=ILUP_sec[i];
		current->E.ia=current->F.ia=NULL;
		current->E.ja=current->F.ja=NULL;
		current->E.a =current->F.a =NULL;
		current->LU.ja=jlu;
		current->absdiag=NULL;

		// undo scaling
		r=PRE->rowscal;
		c=PRE->colscal;
		// adjust arrays
		ia=A->ia;
		ja=A->ja;
		a=A->a;
		ja--;
		a--;
		c--;
		for (i=0; i<A->nr; i++) {
		    for (j=ia[i]; j<ia[i+1]; j++) {
		        k=ja[j];
#if defined _SINGLE_REAL_ || defined _DOUBLE_REAL_
			a[j]/=r[i]*c[k];
#else
			a[j].r/=r[i].r*c[k].r;
			a[j].i/=r[i].r*c[k].r;
#endif	  
		    }
		}

		MYSYMAMGDELETE(A, PRE, IPparam);

		if (param&SADDLE_POINT) {
		  free(pressurelist);
		  free(pressuretopA);
		  free(pressuretopL);
		  free(pressurestackA);
		  free(pressurestackL);
		  free(invheadA);
		  free(invlistA);
		  free(invheadL);
		  free(invlistL);
		  if (PILUCparam&TISMENETSKY_SC) {
		    free(invheadLe);
		    free(invlistLe);
		  }
		}

		return (ierr);
	     }

	     nB=current->nB;
	     current->LUperm=NULL;

#ifdef PRINT_INLINE
	     printf(", nB=%7d->",current->nB);fflush(STDOUT);
#endif

	     if (current->nB>0) {
	        // start counter for (m)piluc
	        evaluate_time(&time_start,&systime);
		condest1=condest;
		condest/=2.0;
		mymaximem=0;
		do {
		   current->nB=nB;
		   ierr=0;
		   condest*=2.0;
		   // printf("level %2d, condest=%8.1le\n",nlev,condest);fflush(stdout);
		   // if DISCARD_MATRIX is set, then at any level>1 the system
		   // matrix is discarded as soon as possible to save memory
		   if (nlev>1)
		      PILUCparam|=discardA;
		   shiftA=0;

		   if (PILUCparam&(DIAGONAL_COMPENSATION|STATIC_TESTVECTOR|DYNAMIC_TESTVECTOR)) {
		      // rescale test vector
		      for (i=0; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			  IPparam->testvector[i]/=current->colscal[i];
#else
			  val=1.0/(current->colscal[i].r*current->colscal[i].r +
				   current->colscal[i].i*current->colscal[i].i);
			  vb=IPparam->testvector[i].r;
			  IPparam->testvector[i].r=( vb*current->colscal[i].r
						    +IPparam->testvector[i].i*current->colscal[i].i)*val;
			  IPparam->testvector[i].i=(-vb*current->colscal[i].i
						    +IPparam->testvector[i].i*current->colscal[i].r)*val;
#endif
		      } // end for i
		      // compute a permuted copy
		      for (i=0; i<n; i++) {
			  IPparam->testvector[n+current->invq[i]-1]=IPparam->testvector[i];
		      } // end for i
		   } // end if
		   if (PILUCparam&SADDLE_POINT) {
		      // compute a permuted copy
		      for (i=0; i<n; i++) 
			  IPparam->indicator[n+current->invq[i]-1]=IPparam->indicator[i];
		   } // end if

		   posiwk=0;
		   if (nlev>1) {
		      delta_ia=jlu-S.ia;
		      delta_ja=jlu-S.ja;
		      delta_a =alu-S.a;
		   }
		   do {
		      imem=(LONG_INT)mem;
		      if (param&MULTI_PILUC) {
			 SYMPILUC(&n,S.a,S.ja,S.ia,lfil,droptols,&condest,
				  //IPparam->fpar+6,
				  &current->nB,&PILUCparam,current->p,current->invq,
				  alu,jlu,&imem,IPparam->dbuff,IPparam->ibuff,
				  &shiftA,&amgcancel,IPparam->testvector,IPparam->indicator, &posiwk, &ierr,
				  &npressurelist,  pressurelist,
				  &npressurestackA,pressurestackA,pressuretopA,
				  &npressurestackL,pressurestackL,pressuretopL,
				  invheadA, invlistA, 
				  invheadL, invlistL,
				  invheadLe,invlistLe);
		      }
		      else
			 SYMPILUC(&n,S.a,S.ja,S.ia,lfil,droptols,&condest,
				  &current->nB,&PILUCparam,current->p,current->invq,
				  alu,jlu,&imem,IPparam->dbuff,IPparam->ibuff,
				  &shiftA,&amgcancel,IPparam->testvector, IPparam->indicator, &posiwk, &ierr,
				  &npressurelist,  pressurelist,
				  &npressurestackA,pressurestackA,pressuretopA,
				  &npressurestackL,pressurestackL,pressuretopL,
				  invheadA, invlistA, 
				  invheadL, invlistL,
				  invheadLe,invlistLe);
		      mymaximem=MAX(mymaximem,imem);

		      if (posiwk>0) {
			 // total amount of memory requested by the parameters
			 myimem=elbow*(size_t)A->ia[A->nr];
			 mem+=myimem;
			 IPparam->elbow+=elbow;
#ifdef PRINT_MEM
			 printf("!posiwk=%d,jlumem=%8.2fMB, alumem=%8.2fMB, elbow=%8.2f\n",
				posiwk,IPparam->njlu/IMEGA,IPparam->nalu/DMEGA,IPparam->elbow);
			 fflush(stdout);
#endif
			 IPparam->njlu+=myimem;
			 // printf("!jlu_old=%lu,%lu,%lu\n",IPparam->jlu,jlu,jlu-IPparam->jlu);
			 // printf("!alu_old=%lu,%lu,%lu\n",IPparam->alu,alu,alu-IPparam->alu);
			 IPparam->jlu=(integer *) REALLOC(IPparam->jlu,
							  IPparam->njlu*sizeof(integer),
							  "symAMGfactor:jlu");
#ifdef PRINT_MEM
			 printf("!level %2d, jlu(%8.2fMB) re-allocated\n",nlev,IPparam->njlu/IMEGA);fflush(stdout);
#endif
			 IPparam->nalu+=myimem;
			 IPparam->alu=(FLOAT *)REALLOC(IPparam->alu,
						       IPparam->nalu*sizeof(FLOAT),
						       "symAMGfactor:alu");
#ifdef PRINT_MEM
			 printf("!level %2d, alu(%8.2fMB) re-allocated\n",nlev,IPparam->nalu/DMEGA);fflush(stdout);
#endif
			 // remap pointers
			 curr=PRE;
			 for (i=0; i<nlev; i++) {
			
			     // sparse case only
			     curr->LU.ja=IPparam->jlu+delta[i];
			     curr->LU.a =IPparam->alu+delta[i];
			     curr=curr->next;
			 }
			 jlu=IPparam->jlu+delta[nlev-1];
			 alu=IPparam->alu+delta[nlev-1];
			 if (nlev>1) {
			    S.ia=jlu-delta_ia;
			    S.ja=jlu-delta_ja;
			    S.a =alu-delta_a;
			 }
			 // printf("!jlu_new=%lu,%lu,%lu\n",IPparam->jlu,jlu,jlu-IPparam->jlu);
			 // printf("!alu_new=%lu,%lu,%lu\n",IPparam->alu,alu,alu-IPparam->alu);
#ifdef PRINT_MEM
			 printf("!level %2d, delta=%d, pointers remapped\n",nlev,delta[nlev-1]);fflush(stdout);
#endif
		      } // end if posiwk>0
		   }
		   while (posiwk>0);
		}
		while (nB-current->nB>amgcancel*nB && 
		       condest<1024*condest0 && condest<16*condest1);
		


		// printf("%d,%f,%f\n",nB-current->nB,amgcancel*nB, condest_increase*nB);fflush(stdout);

		// if PILUC successfully reduced the matrix, but if the
		// reduction was not great, then we increase condest
		// hoping to be more successful on the next level
		if (n-current->nB>condest_increase*nB && 
		    condest<1024*condest0 && condest<16*condest1) {
		   condest*=2.0;
		   // printf("condest doubled, lev=%d\n",nlev);fflush(stdout);
		}

		// printf("sympiluc completed, nlev=%d\n",nlev);fflush(stdout);
		
		// transfer condest back to the parameter array, if we had to increment condest
		// already on the initial level
		if (nlev==1 && condest>IPparam->condest)
		   IPparam->condest=condest;

		alu-=shiftA;
		jlu-=shiftA;
		delta[nlev-1]-=shiftA;
		// stop counter for (m)piluc
		evaluate_time(&time_stop,&systime);
		// accumulate collective time for (m)piluc
		ILUP_sec[2]+=time_stop-time_start;
		if (ierr) {
		   // compute total setup time
		   ILUP_sec[7]=time_stop-ILUP_sec[7];
		   // compute TOTAL time
		   ILUP_sec[8]=time_stop-ILUP_sec[8];
		   for (i=0; i<ILUPACK_secnds_length; i++)
		       ILUPACK_secnds[i]=ILUP_sec[i];
		   current->E.ia=current->F.ia=NULL;
		   current->E.ja=current->F.ja=NULL;
		   current->E.a =current->F.a =NULL;
		   current->LU.ja=jlu;
		   current->absdiag=NULL;

		   // undo scaling
		   r=PRE->rowscal;
		   c=PRE->colscal;
		   // adjust arrays
		   ia=A->ia;
		   ja=A->ja;
		   a=A->a;
		   ja--;
		   a--;
		   c--;
		   for (i=0; i<A->nr; i++) {
		       for (j=ia[i]; j<ia[i+1]; j++) {
			   k=ja[j];
#if defined _SINGLE_REAL_ || defined _DOUBLE_REAL_
			   a[j]/=r[i]*c[k];
#else
			   a[j].r/=r[i].r*c[k].r;
			   a[j].i/=r[i].r*c[k].r;
#endif	  
		       }
		   }

		   MYSYMAMGDELETE(A, PRE, IPparam);
		   
		   if (param&SADDLE_POINT) {
		     free(pressurelist);
		     free(pressuretopA);
		     free(pressuretopL);
		     free(pressurestackA);
		     free(pressurestackL);
		     free(invheadA);
		     free(invlistA);
		     free(invheadL);
		     free(invlistL);
		     if (PILUCparam&TISMENETSKY_SC) {
		       free(invheadLe);
		       free(invlistLe);
		     }
		   }

		   return (ierr);
		}
	     }

#ifdef PRINT_INLINE
	     printf("%7d\n",current->nB);fflush(STDOUT);
#endif



#ifdef PRINT_INFO
	     printf("2.computed U-factor\n");fflush(STDOUT);
	     for (i=0; i<current->nB; ) {
	       if (jlu[n+1+i]==0){
		 for (k=jlu[i];k<jlu[i+1]; k++) 
		   printf("%8d",jlu[k-1]);
		 printf("\n");fflush(STDOUT);
		 for (k=jlu[i];k<jlu[i+1]; k++) 
		   printf("%8.1le",alu[k-1]);
		 printf("\n");fflush(STDOUT);
		 i++;
	       }
	       else {
		 for (k=jlu[i];k<jlu[i+1]; k++) 
		   printf("%8d",jlu[k-1]);
		 printf("\n");fflush(STDOUT);
		 for (k=jlu[i];k<jlu[i+1]; k++) 
		   printf("%8.1le",alu[jlu[i]+2*(k-jlu[i])-1]);
		 printf("\n");fflush(STDOUT);
		 for (k=jlu[i];k<jlu[i+1]; k++) 
		   printf("%8.1le",alu[jlu[i]+2*(k-jlu[i])]);
		 printf("\n");fflush(STDOUT);
		 i+=2;
	       }
	     }
	     printf("\n");fflush(stdout);
	     printf("Block diagonal factor\n");
	     for (k=0; k<current->nB;) {
	       if (jlu[n+1+k]==0){
		 printf("%8.1le",alu[k]);
		 k++;
	       }
	       else {
		 printf("%8.1le%8.1le",alu[k],alu[n+1+k]);
		 k+=2;
	       }
	     }
	     printf("\n");fflush(stdout);
	     for (k=0; k<current->nB; ) {
	       if (jlu[n+1+k]==0) {
		 printf("        ");
		 k++;
	       }
	       else {
		 printf("%8.1le%8.1le",alu[n+1+k],alu[k+1]);
		 k+=2;
	       }
	     }
	     printf("\n");fflush(stdout);
	     printf("computed Schur complement\n");fflush(STDOUT);
	     for (i=current->nB; i<n; i++) {
	       for (k=jlu[i];k<jlu[i+1]; k++) 
		 printf("%8d",jlu[k-1]);
	       printf("\n");fflush(STDOUT);
	       for (k=jlu[i];k<jlu[i+1]; k++) 
		 printf("%8.1le",alu[k-1]);
	       printf("\n");fflush(STDOUT);
	     }
	     for (i=0; i<=current->nB; i++)
	       printf("%8d",i+1);
	     for (i=0; i<=current->nB; i++)
	       printf("%8d",jlu[i]);
	     printf("\n");fflush(stdout);
	     printf("\n");fflush(stdout);
	     for (i=0; i<current->nB; i++)
	       printf("%8d",jlu[n+1+i]);
	     printf("\n");fflush(stdout);
#endif



	  } // end if

	  // maximum (peek) memory observed during sympiluc
	  ILUPACK_mem[4]=MAX(ILUPACK_mem[4],ILUPACK_mem[2]+mymaximem);
	  ILUPACK_mem[5]=MAX(ILUPACK_mem[5],ILUPACK_mem[3]+mymaximem);
	  
	  /* if sympiluc reduction was successful */
	  if (nB-current->nB<=amgcancel*nB && nB>0) {
	     if (n-current->nB) {
	        if (PILUCparam&COARSE_REDUCE) {
		   // printf("sympiluc was successful,n=%d,nz=%d\n",S.nr,S.ia[S.nr]-1);fflush(stdout);
		   MYSYMAMGEXTRACT(&current->F,S, current->p,current->invq,
				   current->nB);
		   ILUPACK_mem[6]+=current->F.nr+1
		                 +current->F.ia[current->F.nr]-1;
		   ILUPACK_mem[7]+=current->F.ia[current->F.nr]-1;
		   // printf("F extracted\n");fflush(stdout);
		   current->E=current->F;
#ifdef PRINT_INFO2
		   printf("lev %d, F allocated\n",nlev);fflush(stdout);
#endif
		}
		else { 
		   // if no coarse reduction is done then L11 and L21 
		   // (resp. U11, U12) are kept in one common array
		   current->E.nr=current->F.nc=n-current->nB;
		   current->E.nc=current->F.nr=current->nB;
		   current->E.ia=current->F.ia=NULL;
		   current->E.ja=current->F.ja=NULL;
		   current->E.a =current->F.a =NULL;
		}
	     }
	     else {
	        current->E.nr=current->F.nc=0;
		current->E.nc=current->F.nr=0;
	     }

	     /* discard old S by simply shifting the new S and the L and U factors,
		because they immediately follow S in the memory */

	     if (nlev>1) {
	        /* number of nonzeros in the old S */
	        k=S.ia[n]-1;
		if (!discardA) {
		   current->A.ia=(integer *)MALLOC((size_t)(n+1)*sizeof(integer),"symAMGfactor:current->A.ia");
		   memcpy(current->A.ia,S.ia,(size_t)(n+1)*sizeof(integer));

		   current->A.ja=(integer *)MALLOC((size_t)k*sizeof(integer),    "symAMGfactor:current->A.ja");
		   memcpy(current->A.ja,S.ja,(size_t)k*sizeof(integer));
		   
		   current->A.a =(FLOAT *)MALLOC((size_t)k*sizeof(FLOAT),        "symAMGfactor:current->A.a");
		   memcpy(current->A.a, S.a, (size_t)k*sizeof(FLOAT));
		   current->A.nr=current->A.nc=n;
		   ILUPACK_mem[10]+=n+1+k;
		   ILUPACK_mem[11]+=k;
		}
		/* number of nonzeros in U and the new S */
		nnz=jlu[n]-1;
		alu-=k;
		jlu-=k;
		delta[nlev-1]-=k;
		for (i=0; i<nnz; i++) {
		    alu[i]=alu[i+k];
		    jlu[i]=jlu[i+k];
		} /* end for */
		mem+=k;
		ILUPACK_mem[2]-=k;
		ILUPACK_mem[3]-=k;
	     }
	     else { // store copy to pointers of the initial matrix
	        current->A.ia=S.ia;
		current->A.ja=S.ja;
		current->A.a =S.a;
		current->A.nr=current->A.nc=S.nr;
	     }


	     // did we already predefine the block structure on this level?
	     if (!discardA) {
	        current->nextblock=(integer *)MALLOC((size_t)current->A.nc*sizeof(integer),
						     "symAMGfactor:nextblock");
		IPparam->ndbuff=MAX(IPparam->ndbuff,(size_t)current->A.nc);
		IPparam->dbuff=(FLOAT *) REALLOC(IPparam->dbuff,
						 IPparam->ndbuff*sizeof(FLOAT),
						 "symAMGfactor:dbuff");
		MYSYMBUILDBLOCK(current->A,current->p,current->invq,current->nextblock,
				(REALS *)IPparam->dbuff);
	     } // end if


	     current->LU.nr=current->nB;
	     current->LU.nc=current->LU.nr;
	     current->LU.a =alu;
	     current->LU.ja=jlu;
	     current->LU.ia=NULL;
	     
	     // number of nonzeros in LU
	     nnz=jlu[current->nB]-1;
	     current->LU.nnz=nnz;
	     
	     // printf("nnz(LU)=%d\n",nnz);fflush(stdout);
	     S.nr=n-current->nB; 
	     S.nc=S.nr;
	     S.a =alu+nnz;
	     S.ja=jlu+nnz;
	     S.ia=jlu+current->nB;
	     
	     for (i=0; i<=S.nr; i++) {
#ifdef PRINT_INFO
	         printf("!%4d,%4d,%4d\n",i+1,S.ia[i],S.ia[i]-nnz);
#endif
		 S.ia[i]-=nnz;
	     }
	     
	     nnz+=jlu[n]-1;
	     alu+=nnz;
	     jlu+=nnz;
	     delta[nlev]=delta[nlev-1]+nnz;
	     mem-=(size_t)nnz;
	     ILUPACK_mem[2]+=(size_t)nnz;
	     ILUPACK_mem[3]+=(size_t)nnz;
	     // maximum (peek) memory observed during sympiluc
	     ILUPACK_mem[4]=MAX(ILUPACK_mem[4],ILUPACK_mem[2]);
	     ILUPACK_mem[5]=MAX(ILUPACK_mem[5],ILUPACK_mem[3]);
	     
	     
	     // adapt test vector to the coarse grid
	     // reorder the test vector
	     if (PILUCparam&(DIAGONAL_COMPENSATION|STATIC_TESTVECTOR|DYNAMIC_TESTVECTOR)) {
	        for (i=0; i<n; i++)
		    IPparam->dbuff[current->invq[i]-1]=IPparam->testvector[i];
	        for (i=current->nB; i<n; i++)
		    IPparam->testvector[i-current->nB]=IPparam->dbuff[i];
	     }
	     if (PILUCparam&SADDLE_POINT) {
	        for (i=0; i<n; i++)
		    IPparam->ibuff[current->invq[i]-1]=IPparam->indicator[i];
	        for (i=current->nB; i<n; i++)
		    IPparam->indicator[i-current->nB]=IPparam->ibuff[i];
	     }

#ifdef PRINT_INFO
	     printf("3.computed U-factor\n");fflush(STDOUT);
	     for (i=0; i<current->nB; ) {
	       if (current->LU.ja[n+1+i]==0){
		 for (k=current->LU.ja[i];k<current->LU.ja[i+1]; k++) 
		   printf("%8d",current->LU.ja[k-1]);
		 printf("\n");fflush(STDOUT);
		 for (k=current->LU.ja[i];k<current->LU.ja[i+1]; k++) 
		  printf("%8.1le",current->LU.a[k-1]);
		 printf("\n");fflush(STDOUT);
		 i++;
	       }
	       else {
		 for (k=current->LU.ja[i];k<current->LU.ja[i+1]; k++) 
		   printf("%8d",current->LU.ja[k-1]);
		 printf("\n");fflush(STDOUT);
		 for (k=current->LU.ja[i];k<current->LU.ja[i+1]; k++) 
		   printf("%8.1le",current->LU.a[current->LU.ja[i]+2*(k-current->LU.ja[i])-1]);
		 printf("\n");fflush(STDOUT);
		 for (k=current->LU.ja[i];k<current->LU.ja[i+1]; k++) 
		   printf("%8.1le",current->LU.a[current->LU.ja[i]+2*(k-current->LU.ja[i])]);
		 printf("\n");fflush(STDOUT);
		 i+=2;
	       }
	     }
	     printf("\n");fflush(stdout);
	     printf("Block diagonal factor\n");
	     for (k=0; k<current->nB;) {
	       if (current->LU.ja[n+1+k]==0){
		 printf("%8.1le",current->LU.a[k]);
		 k++;
	       }
	       else {
		 printf("%8.1le%8.1le",current->LU.a[k],current->LU.a[n+1+k]);
		 k+=2;
	       }
	     }
	     printf("\n");fflush(stdout);
	     for (k=0; k<current->nB; ) {
	       if (current->LU.ja[n+1+k]==0) {
		 printf("        ");
		 k++;
	       }
	       else {
		 printf("%8.1le%8.1le",current->LU.a[n+1+k],current->LU.a[k+1]);
		 k+=2;
	       }
	     }
	     printf("\n");fflush(stdout);
	     printf("computed Schur complement\n");fflush(STDOUT);
	     for (i=0; i<S.nr; i++) {
	       for (k=S.ia[i];k<S.ia[i+1]; k++) 
		 printf("%8d",S.ja[k-1]);
	       printf("\n");fflush(STDOUT);
	       for (k=S.ia[i];k<S.ia[i+1]; k++) 
		 printf("%8.1le",S.a[k-1]);
	       printf("\n");fflush(STDOUT);
	     }
	     for (i=0; i<=current->nB; i++)
	       printf("%8d",i+1);
	     printf("\n");fflush(stdout);
	     for (i=0; i<=current->nB; i++)
	       printf("%8d",current->LU.ja[i]);
	     printf("\n");fflush(stdout);
	     for (i=0; i<current->nB; i++)
	       printf("%8d",current->LU.ja[n+1+i]);
	     printf("\n");fflush(stdout);
#endif
	     
	     
	  } /* end if (nB-current->nB<=amgcancel*nB) */
	  else { /* sympiluc failed to produce a sensible reduction */

#ifdef PRINT_INLINE
	     printf("level %d,  piluc failed (nB=%d), switch to SYMILUC\n",nlev,current->nB);fflush(STDOUT);
#endif

	     /* switch to ILDLC */

	     // start counter for ILDLC
	     evaluate_time(&time_start,&systime);
	     current->LUperm=NULL;
	     for (i=0; i<n; i++)
	         current->p[i]=current->invq[i]=i+1;
	     
	     imem=(LONG_INT)mem;
	     myimem=imem;
	     SYMILUC(&n,S.a,S.ja,S.ia,&n,IPparam->fpar+7,&PILUCparam,
		     current->p,current->invq,alu,jlu,&myimem,
		     IPparam->dbuff,IPparam->ibuff,&ierr);
	     ILUPACK_mem[4]=MAX(ILUPACK_mem[4],ILUPACK_mem[2]+myimem);
	     ILUPACK_mem[5]=MAX(ILUPACK_mem[5],ILUPACK_mem[3]+myimem);

	     /*
	     for (i=0; i<n; i++) 
	       printf("%8.1le\n",alu[i]);
	     printf("\n");fflush(stdout);
	     for (i=0; i<n; i++) {
	       printf("%8d:\n",i+1);fflush(stdout);
	       for (k=jlu[i]; k<jlu[i+1];k++)
		 printf("%8d",jlu[k-1]);
	       printf("\n");fflush(stdout);
	       for (k=jlu[i]; k<jlu[i+1];k++)
		 printf("%8.1le",alu[k-1]);
	       printf("\n");fflush(stdout);
	     }
	     */

	     // computation time for ILDLC
	     evaluate_time(&time_stop,&systime);
	     ILUP_sec[3]=time_stop-time_start;
	     if (ierr) {
	        // compute total setup time
	        ILUP_sec[7]=time_stop-ILUP_sec[7];
		// compute TOTAL time
		ILUP_sec[8]=time_stop-ILUP_sec[8];
	        for (i=0; i<ILUPACK_secnds_length; i++)
		    ILUPACK_secnds[i]=ILUP_sec[i];
		current->E.ia=current->F.ia=NULL;
		current->E.ja=current->F.ja=NULL;
		current->E.a =current->F.a =NULL;
		current->LU.ja=jlu;
		current->absdiag=NULL;

		// undo scaling
		r=PRE->rowscal;
		c=PRE->colscal;
		// adjust arrays
		ia=A->ia;
		ja=A->ja;
		a=A->a;
		ja--;
		a--;
		c--;
		for (i=0; i<A->nr; i++) {
		    for (j=ia[i]; j<ia[i+1]; j++) {
		        k=ja[j];
#if defined _SINGLE_REAL_ || defined _DOUBLE_REAL_
			a[j]/=r[i]*c[k];
#else
			a[j].r/=r[i].r*c[k].r;
			a[j].i/=r[i].r*c[k].r;
#endif	  
		    }
		}

		MYSYMAMGDELETE(A, PRE, IPparam);

		if (param&SADDLE_POINT) {
		  free(pressurelist);
		  free(pressuretopA);
		  free(pressuretopL);
		  free(pressurestackA);
		  free(pressurestackL);
		  free(invheadA);
		  free(invlistA);
		  free(invheadL);
		  free(invlistL);
		  if (PILUCparam&TISMENETSKY_SC) {
		    free(invheadLe);
		    free(invlistLe);
		  }
		}

		return (ierr);
	     }
	     	     
	     current->nB=n;
	     
	     current->E.nr=current->F.nc=0;
	     current->E.nc=current->F.nr=0;
	     
	     /* discard old S by simply shifting the new U factor, because
		it immediately follows the old S in the memory */
	     if (nlev>1) {
	        /* number of nonzeros in the old S */
	        k=S.ia[n]-1;
	        if (!discardA) {
		  current->A.ia=(integer *)MALLOC((size_t)(n+1)*sizeof(integer),"symAMGfactor:current->A.ia");
		  memcpy(current->A.ia,S.ia,(size_t)(n+1)*sizeof(integer));

		  current->A.ja=(integer *)MALLOC((size_t)k*sizeof(integer),    "symAMGfactor:current->A.ja");
		  memcpy(current->A.ja,S.ja,(size_t)k*sizeof(integer));

		  current->A.a =(FLOAT *)MALLOC((size_t)k*sizeof(FLOAT),        "symAMGfactor:current->A.a");
		  memcpy(current->A.a, S.a, (size_t)k*sizeof(FLOAT));
		  current->A.nr=current->A.nc=n;
		  ILUPACK_mem[10]+=n+1+k;
		  ILUPACK_mem[11]+=k;
		}
		/* number of nonzeros in U */
		nnz=jlu[n]-1;
		alu-=k;
		jlu-=k;
		delta[nlev-1]-=k;
		for (i=0; i<nnz; i++) {
		    alu[i]=alu[i+k];
		    jlu[i]=jlu[i+k];
		} /* end for */
		mem+=k;
		ILUPACK_mem[2]-=k;
		ILUPACK_mem[3]-=k;
	     }
	     else { // store copy to pointers of the initial matrix
	        current->A.ia=S.ia;
	        current->A.ja=S.ja;
	        current->A.a =S.a;
		current->A.nr=current->A.nc=S.nr;
	     }


	     // did we already predefine the block structure on this level?
	     if (!discardA) {
	         current->nextblock=(integer *)MALLOC((size_t)current->A.nc*sizeof(integer),
						      "symAMGfactor:nextblock");
		 IPparam->ndbuff=MAX(IPparam->ndbuff,(size_t)current->A.nc);
		 IPparam->dbuff=(FLOAT *) REALLOC(IPparam->dbuff,
						  IPparam->ndbuff*sizeof(FLOAT),
						  "symAMGfactor:dbuff");
		 MYSYMBUILDBLOCK(current->A,current->p,current->invq,current->nextblock,
				 (REALS *)IPparam->dbuff);
	     } // end if

	   
	     current->LU.nr=current->nB;
	     current->LU.nc=current->LU.nr;
	     current->LU.a =alu;
	     current->LU.ja=jlu;
	     current->LU.ia=NULL;
	     // number of nonzeros in LU
	     current->LU.nnz=jlu[current->nB]-1;
	     
	     nnz=(size_t)jlu[n]-1;

	     ILUPACK_mem[2]+=(size_t)nnz;
	     ILUPACK_mem[3]+=(size_t)nnz;
	     ILUPACK_mem[4]=MAX(ILUPACK_mem[4],ILUPACK_mem[2]);
	     ILUPACK_mem[5]=MAX(ILUPACK_mem[5],ILUPACK_mem[3]);

	     n=-1;
	     S.nr=0;
	  } /* end if-else */
	} /* end if-else (nlev>1 && 3*(S.ia[n]-1)>S.nr*S.nc) */
  } /* end while */


  
  // reduce memory to the size that was really needed
  if (!(param&RE_FACTOR)) {
     IPparam->njlu=ILUPACK_mem[2];
     IPparam->jlu=(integer *)  REALLOC(IPparam->jlu,
				       IPparam->njlu*sizeof(integer),  
				       "symAMGfactor:jlu");
     IPparam->nalu=ILUPACK_mem[3];
     IPparam->alu=(FLOAT *)REALLOC(IPparam->alu,
				   IPparam->nalu*sizeof(FLOAT),
				   "symAMGfactor:alu");
     IPparam->elbow=((double)(MAX(ILUPACK_mem[4],ILUPACK_mem[5])))/A->ia[A->nr]+1.0e-4;
     
     /*
     current=PRE;
     j=0;
     for (i=0; i<nlev; i++) {
       if (i==0)
	 printf("%8d,%8ld\n", delta[i],(long)0);
       else {
	 j+=(integer)(((unsigned long)(current->LU.a)-(unsigned long)(current->prev->LU.a))/sizeof(FLOAT));
	 printf("%8d,%8ld\n", delta[i],j);
       }
       current=current->next;
     }
     if ((unsigned long)IPparam->alu!=(unsigned long)PRE->LU.a)
       printf("pointers will be remapped\n");
     */

     // remap pointers
     current=PRE;
     for (i=0; i<nlev; i++) {

       // sparse case
       if (current->LU.ja!=NULL)
	  current->LU.ja=IPparam->jlu+delta[i];
       else // dense case
	  current->LU.ia=current->prev->LU.ja+current->prev->LU.nr;

       current->LU.a =IPparam->alu+delta[i];
       
       current=current->next;
     }


     /*
     current=PRE;
     for (i=1; i<nlev; i++) {
       current=current->next;
     }
     for (i=0; i<current->LU.nr; i++) 
       printf("%8.1le\n",current->LU.a[i]);
     printf("\n");fflush(stdout);
     for (i=0; i<current->LU.nr; i++) {
       printf("%8d:\n",i+1);fflush(stdout);
       for (k=current->LU.ja[i]; k<current->LU.ja[i+1];k++)
	 printf("%8d",current->LU.ja[k-1]);
       printf("\n");fflush(stdout);
       for (k=current->LU.ja[i]; k<current->LU.ja[i+1];k++)
	 printf("%8.1le",current->LU.a[k-1]);
       printf("\n");fflush(stdout);
     }
     */

#ifdef PRINT_MEM
     printf("jlu(%8.2lfMB), alu(%8.2lfMB), elbow=%8.2f finally re-allocated\n",
	    ILUPACK_mem[2]/IMEGA,ILUPACK_mem[3]/DMEGA,IPparam->elbow);fflush(stdout);
#endif
  }
  // release delta
  free(delta);

  current=PRE;
  n=A->nr;
  for (j=1; j<=nlev; j++) {
      // level i
    
      // case of a sparse inverse-based block ILU
      if (j<nlev || current->LU.ja!=NULL) {
	 // shift block diagonal parts properly
	 if (j==nlev-1 && current->next->LU.ja==NULL) {
	    /* exceptional case, if the next level is the final level
	       and the final level uses a dense factorization 
	       In this case move the space in ja at nB+1,...,n to 
               n+1+nB+1,...n+1+n
	    */
	    for (i=0; i<n-current->nB; i++) {
		current->LU.ja[n+1+current->nB+i]=current->LU.ja[current->nB+i];
	    }
	    // re-adjust pointer
	    current->next->LU.ia=current->LU.ja+n+1+current->nB;
	 }
	 for (i=0; i<current->nB; i++) {
	     current->LU.ja[current->nB+1+i]=current->LU.ja[n+1+i];
	     current->LU.a[current->nB+1+i] =current->LU.a[n+1+i];
	 } // end for i
	 // now we do not need to refer to the dense Schur complement anymore
	 current->LU.ja[current->nB]=current->LU.ja[current->nB-1];

#ifdef PRINT_INFO
	    printf("4.computed U-factor\n");fflush(STDOUT);
	    for (i=0; i<current->nB; ) {
	      if (current->LU.ja[current->nB+1+i]==0){
		for (k=current->LU.ja[i];k<current->LU.ja[i+1]; k++) 
		  printf("%8d",current->LU.ja[k-1]);
		printf("\n");fflush(STDOUT);
		for (k=current->LU.ja[i];k<current->LU.ja[i+1]; k++) 
		  printf("%8.1le",current->LU.a[k-1]);
		printf("\n");fflush(STDOUT);
		i++;
	      }
	      else {
		for (k=current->LU.ja[i];k<current->LU.ja[i+1]; k++) 
		  printf("%8d",current->LU.ja[k-1]);
		printf("\n");fflush(STDOUT);
		for (k=current->LU.ja[i];k<current->LU.ja[i+1]; k++) 
		  printf("%8.1le",current->LU.a[current->LU.ja[i]+2*(k-current->LU.ja[i])-1]);
		printf("\n");fflush(STDOUT);
		for (k=current->LU.ja[i];k<current->LU.ja[i+1]; k++) 
		  printf("%8.1le",current->LU.a[current->LU.ja[i]+2*(k-current->LU.ja[i])]);
		printf("\n");fflush(STDOUT);
		i+=2;
	      }
	    }
	    printf("\n");fflush(stdout);
	    printf("Block diagonal factor\n");
	    for (k=0; k<current->nB;) {
	      if (current->LU.ja[current->nB+1+k]==0){
		printf("%8.1le",current->LU.a[k]);
		k++;
	      }
	      else {
		printf("%8.1le%8.1le",current->LU.a[k],current->LU.a[current->nB+1+k]);
		k+=2;
	      }
	    }
	    printf("\n");fflush(stdout);
	    for (k=0; k<current->nB; ) {
	      if (current->LU.ja[current->nB+1+k]==0) {
		printf("        ");
		k++;
	      }
	      else {
		printf("%8.1le%8.1le",current->LU.a[current->nB+1+k],current->LU.a[k+1]);
		k+=2;
	      }
	    }
	    printf("\n");fflush(stdout);
	    for (i=0; i<=current->nB; i++)
	      printf("%8d",i+1);
	    printf("\n");fflush(stdout);
	    for (i=0; i<=current->nB; i++)
	      printf("%8d",current->LU.ja[i]);
	    printf("\n");fflush(stdout);
	    for (i=0; i<current->nB; i++)
	      printf("%8d",current->LU.ja[current->nB+1+i]);
	    printf("\n");fflush(stdout);
#endif


      }
      else {
	  // full matrix processing in the final step
#ifdef PRINT_INFO
	    printf("dense U-factor\n");fflush(STDOUT);
	    for (i=0; i<current->nB; i++)
	      printf("%8d",current->LU.ia[i]);
	    printf("\n");fflush(stdout);
	    j=0;
	    for (k=0; k<current->nB; k++) {
	        for (i=k; i<current->nB; i++) {
		    printf("%8.1le",current->LU.a[j++]);
		}
		printf("\n");fflush(stdout);
	    }
	    printf("\n");fflush(stdout);
#endif

      }
      n-=current->nB;
      current=current->next;
  } // end for j


  evaluate_time(&time_stop,&systime);
  // compute total setup time
  ILUP_sec[7]=time_stop-ILUP_sec[7];
  for (i=0; i<ILUPACK_secnds_length; i++)
      ILUPACK_secnds[i]=ILUP_sec[i];

  ILUPACK_mem[0]=IPparam->nibuff;
  ILUPACK_mem[1]=IPparam->ndbuff;

  // make sure that nlev in consistent on all levels
  current=PRE;
  for (i=0; i<nlev; i++) {
      current->nlev=nlev;
      current=current->next;
  }

  // undo scaling
  r=PRE->rowscal;
  c=PRE->colscal;
  // adjust arrays
  ia=A->ia;
  ja=A->ja;
  a =A->a;
  ja--;
  a--;
  c--;
  for (i=0; i<A->nr; i++) {
      for (j=ia[i]; j<ia[i+1]; j++) {
	  k=ja[j];
#if defined _SINGLE_REAL_ || defined _DOUBLE_REAL_
	  a[j]/=r[i]*c[k];
#else
	  a[j].r/=r[i].r*c[k].r;
	  a[j].i/=r[i].r*c[k].r;
#endif	  
      }
  }

  if (param&SADDLE_POINT) {
     free(pressurelist);
     free(pressuretopA);
     free(pressuretopL);
     free(pressurestackA);
     free(pressurestackL);
     free(invheadA);
     free(invlistA);
     free(invheadL);
     free(invlistL);
     if (PILUCparam&TISMENETSKY_SC) {
        free(invheadLe);
	free(invlistLe);
     }
  }

  return (ierr);
} /* end symAMGfactor */

