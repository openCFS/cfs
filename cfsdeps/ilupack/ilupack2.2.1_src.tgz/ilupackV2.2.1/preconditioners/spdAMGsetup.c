#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include <lapack.h>

#include <ilupack.h>

#include <ilupackmacros.h>

#define STDERR          stderr
#define STDOUT          stdout
#define MAX(A,B)        (((A)>(B))?(A):(B))
#define MIN(A,B)        (((A)<(B))?(A):(B))

// #define printf mexPrintf

// #define PRINT_RC
// #define PRINT_INLINE


// #define PRINT_MEM
#define MEGA      1048576.0
#define IMEGA      262144.0
#define DMEGA      131072.0



/*
  main driver for the multilevel ILU

  given an SPD A, a sequence of permutations and incomplete LU factorizations
  is performed. Partially we obtain a approximate partial factorization
          /  B  F \   /U^T   0\ /D  0\ /U UF\
  P^TAP = |       | ~ |       | |    | |    |
          \ F^T C /   \UF^T  I/ \0  S/ \0 I /
  The D,U as well as p,p^{-1} and F are kept and the multilevel strategy
  is repeated for S
*/
integer SPDAMGSETUP(CSRMAT *A, AMGLEVELMAT *PRE, ILUPACKPARAM *IPparam)
{
/*
  A        input matrix, matrix is altered by the function
           diagonal scaling is directly applied to A
           only the diagonal part of A and its upper triangular part
           are stored
  PRE      Linked list of partial preconditioners
  nlev     number of levels(blocks)
  IPparam  ILUPACK parameter list
  perm0    function for initial scaling and preprocessing, applied to
           the initial system only
  perm     regular reordering/scaling applied to all subsequent levels
  permf    final scaling/pivoting strategy, applied when perm has failed
    
           perm...(A,rowscale,colscale,p,invq,nB,IPparam)
           - rescales A, returns the results in rowscale and colscale
           - permutes the rows of A and returns the permutation vector in p
           - permutes similarly the columns of A and returns the inverse 
           - permutation vector of p in invq
           - return the size nB of the leading block B
                     /  B  F \
             P^TAP = |       |
                     \ F^T C /
             that hopefully can be safely factored

  Code written by Matthias Bollhoefer November 2003
*/


  integer i,j,k,l,n, PILUCparam, nnz, nB, posiwk;
  integer  *jlu, ierr, regular_pivoting, *ia, *ja;
  integer lfil[2], param, discardA, shiftA;
  LONG_INT imem, myimem, mymaximem;
  REALS droptols[3], condest, condest0, condest1, amgcancel, ilucancel,
  condest_increase, 
        mycondest; 
  REALS seps, ptol,val,vb, elbow;
  CSRMAT S;
  AMGLEVELMAT *current, *curr;
  FLOAT *alu, *a, *r, *c;
  float  systime, time_start, time_stop, secnds, 
         ILUP_sec[ILUPACK_secnds_length];
  size_t mem, nibuff, ndbuff, *delta, delta_ia,
           delta_ja, delta_a;
  integer (*perm0)(),(*perm)(),(*permf)(), nlev;

  if (IPparam->returnlabel!=0) {
#ifdef PRINT_RC
     printf("continue at label 1\n");fflush(stdout);
#endif
     if (IPparam->returnlabel==1) goto label1;
  }

  n=A->nr;
  PILUCparam=0;
  ierr=0;

  // init time counters
  evaluate_time(&time_start,&systime);
  // counter for the total setup time
  for (i=0; i<ILUPACK_secnds_length; i++)
      ILUP_sec[i]=0;
  ILUP_sec[7]=time_start;

  // init memory counters
  for (i=0; i<ILUPACK_mem_length; i++)
      ILUPACK_mem[i]=0;


  // for pildlc the integer buffer is required to have at least
  //    11*n for the simple Schur complement (S version)
  //    14*n for the Tismenetsky-like Schur complement (T version)
  // for mpiluc the integer buffer is required to have at least
  //    12*n for the simple Schur complement (S version)
  //    15*n for the Tismenetsky-like Schur complement (T version)

  // analogous settings for the floating point buffer
  //    2*n  (not improved version)
  //    3*n  (improved version or medium Schur complement version)

  // ***  new parameter selection scheme *** 
  // transfer the user request to the internal parameter list
  SPDAMGSETUPPARAMETERS(A, IPparam, 0);
  // overwrite the permutation drivers by those that have been selected via the
  // setup. If param->FCpart, param->ordering do not match any of the 
  // preselected items (e.g. NULL pointer, empty string, fancy strings like 
  // "mydriver",...), then perm0,perm,permf effectively do not change
  perm0=IPparam->perm0;
  perm =IPparam->perm;
  permf=IPparam->permf;

  /* old version
  elbow  =IPparam->ipar[0];
  nibuff =IPparam->nibuff;
  ndbuff =IPparam->ndbuff;
  lfil[0]=IPparam->ipar[3];
  lfil[1]=IPparam->ipar[9];
  param  =IPparam->ipar[6];

  droptols[0]=IPparam->fpar[0];
  droptols[1]=IPparam->fpar[1];
  droptols[2]=IPparam->fpar[8];
  condest    =IPparam->fpar[2];
  ilucancel  =IPparam->fpar[3];
  amgcancel  =IPparam->fpar[4]; 
  */
  // new version
  elbow  =IPparam->elbow; // now floating point
  nibuff =IPparam->nibuff;
  ndbuff =IPparam->ndbuff;
  lfil[0]=IPparam->lfil;
  lfil[1]=IPparam->lfilS;
  param  =IPparam->flags;

  droptols[0]=IPparam->fpar[0];
  droptols[1]=IPparam->droptol;
  droptols[2]=IPparam->droptolS;
  condest    =IPparam->condest;
  condest0=condest;
  ilucancel  =IPparam->fpar[3];
  amgcancel  =IPparam->fpar[4]; 
  condest_increase=IPparam->fpar[9];

  // analyze how the size of the buffer has to be chosen
  if (param&TISMENETSKY_SC) {
     if (param&MULTI_PILUC)
        nibuff=MAX(nibuff,15*(size_t)n);
     nibuff=MAX(nibuff,14*(size_t)n);
  }
  else {
     if (param&MULTI_PILUC)
        nibuff=MAX(nibuff,12*(size_t)n);
     nibuff=MAX(nibuff,11*(size_t)n); // recommended version!
  }

  if (param&DROP_INVERSE) {
     // if a more reliable estimate for the inverse is required
     if (param&IMPROVED_ESTIMATE || !(param&(SIMPLE_SC|TISMENETSKY_SC)))
        ndbuff=MAX(ndbuff,3*(size_t)n); // recommended version!
     else 
        ndbuff=MAX(ndbuff,2*(size_t)n);
  }
  else {
     // currently the norm of the inverse factors are computed
     // even if classical dropping is desired
     // The comments in (m)piluc still refer to their predecessor
     // iluc, which allows classical dropping in a strict sense

     // if a more reliable estimate for the inverse is required
     if (param&IMPROVED_ESTIMATE || !(param&(SIMPLE_SC|TISMENETSKY_SC)))
        ndbuff=MAX(ndbuff,3*(size_t)n);
     else 
        ndbuff=MAX(ndbuff,2*(size_t)n);
  }


  /* integer and floating point buffer */
  if (IPparam->nibuff==0) {
     IPparam->nibuff=nibuff;
     IPparam->ibuff=(integer *)  MALLOC(IPparam->nibuff*sizeof(integer),
				    "spdAMGfactor:ibuff");
  }     
  else if (nibuff>IPparam->nibuff) {
     IPparam->nibuff=nibuff;
     IPparam->ibuff=(integer *)  REALLOC(IPparam->ibuff,
				     IPparam->nibuff*sizeof(integer),
				     "spdAMGfactor:ibuff");
  }
  if (IPparam->ndbuff==0) {
     IPparam->ndbuff=ndbuff;
     IPparam->dbuff=(FLOAT *)MALLOC(IPparam->ndbuff*sizeof(FLOAT),
				    "spdAMGfactor:dbuff");
  } 
  else if (ndbuff>IPparam->ndbuff) {
     IPparam->ndbuff=ndbuff;
     IPparam->dbuff=(FLOAT *)REALLOC(IPparam->dbuff,
				     IPparam->ndbuff*sizeof(FLOAT),
				     "spdAMGfactor:dbuff");
  }

  // keep track on the amount of memory consumed by the buffers
  ILUPACK_mem[0]=nibuff;
  ILUPACK_mem[1]=ndbuff;


  // total amount of memory requested by the parameters
  mem=elbow*(size_t)A->ia[A->nr];
  if (mem<A->nr+1) {
     mem=A->nr+1;
     IPparam->elbow=(A->nr+1.0)/((size_t)A->ia[A->nr])+1.0e-4;
     elbow=IPparam->elbow;
  }

  if (IPparam->njlu==0) {
     IPparam->njlu=mem;
     IPparam->jlu=(integer *)  MALLOC(IPparam->njlu*sizeof(integer),
				  "spdAMGfactor:jlu");
  }
  else if (mem>IPparam->njlu) {
     IPparam->njlu=mem;
     IPparam->jlu=(integer *) REALLOC(IPparam->jlu,
				  IPparam->njlu*sizeof(integer),
				  "spdAMGfactor:jlu");
  }
  jlu=IPparam->jlu;
  if (IPparam->nalu==0) {
     IPparam->nalu=mem;
     IPparam->alu=(FLOAT *) MALLOC(IPparam->nalu*sizeof(FLOAT),
				   "spdAMGfactor:alu");
  }
  else if (mem>IPparam->nalu) {
     IPparam->nalu=mem;
     IPparam->alu=(FLOAT *)REALLOC(IPparam->alu,
				   IPparam->nalu*sizeof(FLOAT),
				   "spdAMGfactor:alu");
  }
  alu=IPparam->alu;



  if (param&FINAL_PIVOTING)
     regular_pivoting=-1;
  else 
     regular_pivoting=0;
  // default settings for PILUC within ILUPACK
  if (param&COARSE_REDUCE)
     PILUCparam|=COARSE_REDUCE; 
  if (param&IMPROVED_ESTIMATE)
     PILUCparam|=IMPROVED_ESTIMATE;
  if (param&DROP_INVERSE)
     PILUCparam|=DROP_INVERSE;
  // additional legal options
  if (param&TISMENETSKY_SC)
     PILUCparam|=TISMENETSKY_SC;
  else if (param&SIMPLE_SC)
    PILUCparam|=SIMPLE_SC;
  if (param&ENSURE_SPD)
     PILUCparam|=ENSURE_SPD;
  if (param&DIAGONAL_COMPENSATION) {
     PILUCparam|=DIAGONAL_COMPENSATION;
     PILUCparam&=~ENSURE_SPD;
  }
  if (param&AGGRESSIVE_DROPPING)
     PILUCparam|=AGGRESSIVE_DROPPING;

  if (param&STATIC_TESTVECTOR)
     PILUCparam|=STATIC_TESTVECTOR;
  if (param&DYNAMIC_TESTVECTOR)
     PILUCparam|=DYNAMIC_TESTVECTOR;

  /* old version. This should have been managed by the parameter setup
  if (PILUCparam&(DIAGONAL_COMPENSATION|STATIC_TESTVECTOR|DYNAMIC_TESTVECTOR)) {
     IPparam->ntestvector=2*n;
     if (PILUCparam&(STATIC_TESTVECTOR|DYNAMIC_TESTVECTOR)) {
        // test vector is given
        IPparam->testvector=(FLOAT *)REALLOC(IPparam->testvector,2*(size_t)n*sizeof(FLOAT),"spdAMGfactor:IPparam->testvector");
     }
     else {
        IPparam->testvector=(FLOAT *)MALLOC(2*(size_t)n*sizeof(FLOAT),"spdAMGfactor:IPparam->testvector");
	for (i=0; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	    IPparam->testvector[i]=1.0;
#else
	    IPparam->testvector[i].r=1.0;
	    IPparam->testvector[i].i=0.0;
#endif
	} // end for
     }
  }
  */

  // do we like to use some real multigrid method?
  if (IPparam->ipar[10]>0) {
     // remove possibly inconsistency in setup
     IPparam->ipar[6]&=~DISCARD_MATRIX;
     param           &=~DISCARD_MATRIX;
     if (IPparam->ipar[14]==4) {
        IPparam->ipar[6]|=COARSE_REDUCE;
        param           |=COARSE_REDUCE;
        PILUCparam      |=COARSE_REDUCE;
     }
  }


  discardA=0;
  if (param&DISCARD_MATRIX) {
     discardA=DISCARD_MATRIX;
  }
  // buffer to store 'true' ipar[6] from the time of the factorization
  IPparam->ipar[16]=PILUCparam|discardA;


  // store the logical gap between the allocated memory areas alu,jlu
  // and the pointers to the subsystems
  delta=(size_t *)MALLOC(A->nr*sizeof(size_t),"spdAMGfactor:delta");
  for (i=0; i<A->nr; i++)
    delta[i]=0;
  /* block LU decomposition */
  S=*A; 

  n=(1+1/amgcancel)*S.nr;
  current=PRE;
  current->prev=NULL;
  current->A.ia=A->ia;
  current->A.ja=A->ja;
  current->A.a =A->a;
  current->A.nr=current->A.nc=A->nr;

  nlev=0;
  PRE->nlev=nlev;

  // while (0<S.nr & S.nr<=amgcancel*n) {
  while (0<S.nr) {
	nlev++;
	PRE->nlev=nlev;

        n=S.nr;	
	if (nlev>1)
	{
	   current->next=(AMGLEVELMAT *)MALLOC((size_t)1*sizeof(AMGLEVELMAT),
					       "spdAMGfactor:current->next");
	   current->next->prev=current;
	   current=current->next;
	}
	current->n=n;
	current->next=NULL;
	

	// start counter for preprocessing/reordering/pivoting  and  scaling
	evaluate_time(&time_start,&systime);
	/* row and column scaling if desired */
	current->colscal=(FLOAT *)MALLOC((size_t)n*sizeof(FLOAT),
					 "spdAMGfactor:current->colscal");
	current->rowscal=current->colscal;
	ILUPACK_mem[9]+=n;

	for (i=0; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	    current->colscal[i]=1;
#else
	    current->colscal[i].r=1;
	    current->colscal[i].i=0;
#endif
	}

	current->p   =(integer *)MALLOC((size_t)n*sizeof(integer),"spdAMGfactor:current->p");
	current->invq=(integer *)MALLOC((size_t)n*sizeof(integer),"spdAMGfactor:current->invq");
	ILUPACK_mem[8]+=2*n;
	for (i=0; i<n; i++)
	  current->p[i]=current->invq[i]=i+1;
	current->nB=current->n;


	// auxilliary memory that is currently left over
	IPparam->niaux=IPparam->ndaux=mem;
	IPparam->iaux=jlu;
	IPparam->daux=alu;

	/* check whether the matrix is almost dense */
	/* We define a matrix to be dense if nnz(S)>1/3 n(n+1)/2 */
	nnz=S.ia[n]-1;

#ifdef PRINT_INLINE
	printf("n=%7d, nnz=%9d, %6.1fav",n,nnz,((double)nnz)/n);
#endif

	if (nlev>1 && ilucancel*nnz>((REALS)n)*(n+1)/2.0) {

#ifdef PRINT_INLINE
	   printf("\nswitched to full matrix processing\n");fflush(STDOUT);
#endif

	   // start counter for LDLP
	   evaluate_time(&time_start,&systime);
	   /* uncompress S if possible */

	   if (mem<(n*(size_t)(n+1))/2-nnz) {
	      if (nlev>1) {
	         delta_ia=jlu-S.ia;
		 delta_ja=jlu-S.ja;
		 delta_a =alu-S.a;
	      }
	      myimem=(n*(size_t)(n+1))/2-nnz-mem;
	      mem+=myimem;
	      IPparam->elbow+=((double)myimem)/A->ia[A->nr]+1.0e-4;
#ifdef PRINT_MEM
	      printf("jlumem=%8.2fMB, alumem=%8.2fMB, elbow=%8.2f\n",
		     IPparam->njlu/IMEGA,IPparam->nalu/DMEGA,IPparam->elbow);fflush(stdout);
#endif
	      IPparam->njlu+=myimem;
	      // printf("jlu_old=%lu,%lu,%lu\n",IPparam->jlu,jlu,jlu-IPparam->jlu);
	      // printf("alu_old=%lu,%lu,%lu\n",IPparam->alu,alu,alu-IPparam->alu);
	      IPparam->jlu=(integer *) REALLOC(IPparam->jlu,
					       IPparam->njlu*sizeof(integer),
					       "spdAMGfactor:jlu");
#ifdef PRINT_MEM
	      printf("level %2d, jlu(%8.2fMB) re-allocated\n",nlev,IPparam->njlu/IMEGA);fflush(stdout);
#endif
	      IPparam->nalu+=myimem;
	      IPparam->alu=(FLOAT *)REALLOC(IPparam->alu,
					    IPparam->nalu*sizeof(FLOAT),
					    "spdAMGfactor:alu");
#ifdef PRINT_MEM
	      printf("level %2d, alu(%8.2fMB) re-allocated\n",nlev,IPparam->nalu/DMEGA);fflush(stdout);
#endif
	      // remap pointers
	      curr=PRE;
	      for (i=0; i<nlev; i++) {
		  // so far sparse case only
		  curr->LU.ja=IPparam->jlu+delta[i];
		  curr->LU.a =IPparam->alu+delta[i];
		  curr=curr->next;
	      }
	      jlu=IPparam->jlu+delta[nlev-1];
	      alu=IPparam->alu+delta[nlev-1];
	      if (nlev>1) {
		 S.ia=jlu-delta_ia;
		 S.ja=jlu-delta_ja;
		 S.a =alu-delta_a;
	      }
	      // printf("jlu_new=%lu,%lu,%lu\n",IPparam->jlu,jlu,jlu-IPparam->jlu);
	      //printf("alu_new=%lu,%lu,%lu\n",IPparam->alu,alu,alu-IPparam->alu);
#ifdef PRINT_MEM
	      printf("level %2d, delta=%d, pointers remapped\n",nlev,delta[nlev-1]);fflush(stdout);
#endif
	   } // end if


	   if (mem<(n*(size_t)(n+1))/2-nnz) {
	      evaluate_time(&time_stop,&systime);
	      // compute total setup time
	      ILUP_sec[7]=time_stop-ILUP_sec[7];
	      // compute TOTAL time
	      ILUP_sec[8]=time_stop-ILUP_sec[8];
	      for (i=0; i<ILUPACK_secnds_length; i++)
		  ILUPACK_secnds[i]=ILUP_sec[i];
	      ierr=-2;
	      current->E.ia=current->F.ia=NULL;
	      current->E.ja=current->F.ja=NULL;
	      current->E.a =current->F.a =NULL;
	      current->LU.ja=jlu;

	      // undo scaling
	      r=PRE->rowscal;
	      c=PRE->colscal;
	      // adjust arrays
	      ia=A->ia;
	      ja=A->ja;
	      a =A->a;
	      ja--;
	      a--;
	      c--;
	      for (i=0; i<A->nr; i++) {
		  for (j=ia[i]; j<ia[i+1]; j++) {
		      k=ja[j];
#if defined _SINGLE_REAL_ || defined _DOUBLE_REAL_
		      a[j]/=r[i]*c[k];
#else
		      a[j].r/=r[i].r*c[k].r;
		      a[j].i/=r[i].r*c[k].r;
#endif	  
		  }
	      }

	      SPDAMGDELETE(A, PRE, IPparam);
	      return (ierr);
	   }
	   
	   /* position in alu behind the uncompressed matrix */
	   alu+=(n*(size_t)(n+1))/2-nnz;
	   delta[nlev-1]-=nnz;
	   // additional memory needed
	   ILUPACK_mem[2]+=0;
	   ILUPACK_mem[3]+=(n*(size_t)(n+1))/2-nnz;
	   ILUPACK_mem[5]=MAX(ILUPACK_mem[5],ILUPACK_mem[3]);
	   S.ja--;
	   S.a--;
	   for (i=n-1; i>=0; i--) {
	       for (j=i; j<n; j++) 
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		   IPparam->dbuff[j]=0;
#else
	           IPparam->dbuff[j].r=IPparam->dbuff[j].i=0;
#endif
	       IPparam->dbuff--;
	       for (j=S.ia[i]; j<S.ia[i+1]; j++)
		   IPparam->dbuff[S.ja[j]]=S.a[j];
	       IPparam->dbuff++;
	       alu-=(n-i);
	       for (j=i; j<n; j++)
		   alu[j-i]=IPparam->dbuff[j];
	   }
	   S.ja++;
	   S.a++;
	   current->LUperm=NULL;
	   
#ifdef USE_LAPACK_DRIVER
	   PPTRF("L",&n,S.a,&ierr,1); 
#else
	   LDLP(&n,S.a,S.ia,IPparam->ibuff,&ierr); 
#endif
	   // store LDLP computation time
	   evaluate_time(&time_stop,&systime);
	   ILUP_sec[4]=time_stop-time_start;

	   if (ierr) { 
	      // compute total setup time
	      ILUP_sec[7]=time_stop-ILUP_sec[7];
	      // compute TOTAL time
	      ILUP_sec[8]=time_stop-ILUP_sec[8];
	      for (i=0; i<ILUPACK_secnds_length; i++)
	          ILUPACK_secnds[i]=ILUP_sec[i];
	      current->E.ia=current->F.ia=NULL;
	      current->E.ja=current->F.ja=NULL;
	      current->E.a =current->F.a =NULL;
	      current->LU.ja=jlu;

	      // undo scaling
	      r=PRE->rowscal;
	      c=PRE->colscal;
	      // adjust arrays
	      ia=A->ia;
	      ja=A->ja;
	      a =A->a;
	      ja--;
	      a--;
	      c--;
	      for (i=0; i<A->nr; i++) {
		for (j=ia[i]; j<ia[i+1]; j++) {
		    k=ja[j];
#if defined _SINGLE_REAL_ || defined _DOUBLE_REAL_
		    a[j]/=r[i]*c[k];
#else
		    a[j].r/=r[i].r*c[k].r;
		    a[j].i/=r[i].r*c[k].r;
#endif	  
		}
	      }

	      SPDAMGDELETE(A, PRE, IPparam);
	      return (ierr);
	   }
	   current->nB=n;
	     
	   current->E.nr=current->F.nc=0;
	   current->E.nc=current->F.nr=0;
	   
	   current->LU.nr=current->nB;
	   current->LU.nc=current->LU.nr;
	   current->LU.a =alu;
	   current->LU.ja=NULL;
	   current->LU.ia=S.ia;

	   n=-1;
	   S.nr=0;
	}
	else { /* the matrix is still sparse */

	   // use reverse communication to generate a dynamic test vector
	   if (PILUCparam&DIAGONAL_COMPENSATION && PILUCparam&DYNAMIC_TESTVECTOR) {
#ifdef PRINT_RC
	      printf("prepare for reverse communication and return from SPDAMGFACTOR before label 1\n");fflush(stdout);
#endif
	      IPparam->rcomflag=-1;
	      IPparam->returnlabel=1;
	      IPparam->tv=IPparam->testvector;
	      IPparam->A =S;

	      // save local variables
	      IPparam->istack[ 0]=i;
	      IPparam->istack[ 1]=j;
	      IPparam->istack[ 2]=k;
	      IPparam->istack[ 3]=l;
	      IPparam->istack[ 4]=n;
	      IPparam->istack[ 5]=PILUCparam;
	      IPparam->istack[ 6]=nnz;
	      IPparam->istack[ 7]=nB;
	      IPparam->istack[ 8]=ierr;
	      IPparam->istack[ 9]=regular_pivoting;
	      IPparam->istack[10]=lfil[0];
	      IPparam->istack[11]=lfil[1];
	      IPparam->istack[12]=elbow;
	      IPparam->istack[13]=param;
	      IPparam->istack[14]=discardA;
	      IPparam->istack[15]=shiftA;
	      IPparam->istack[16]=imem;
	      IPparam->istack[17]=nlev;
	      
	      IPparam->pistack[0]=jlu;
	      IPparam->pistack[1]=ia;
	      IPparam->pistack[2]=ja;
	      
	      IPparam->rstack[ 0]=droptols[0];
	      IPparam->rstack[ 1]=droptols[1];
	      IPparam->rstack[ 2]=droptols[2];
	      IPparam->rstack[ 3]=condest;
	      IPparam->rstack[ 4]=amgcancel;
	      IPparam->rstack[ 5]=ilucancel;
	      IPparam->rstack[ 6]=seps;
	      IPparam->rstack[ 7]=ptol;
	      IPparam->rstack[ 8]=val;
	      IPparam->rstack[ 9]=vb;
	      IPparam->rstack[10]=systime;
	      IPparam->rstack[11]=time_start;
	      IPparam->rstack[12]=time_stop;
	      IPparam->rstack[13]=secnds;
	      IPparam->rstack[14]=ILUP_sec[ 0];
	      IPparam->rstack[15]=ILUP_sec[ 1];
	      IPparam->rstack[16]=ILUP_sec[ 2];
	      IPparam->rstack[17]=ILUP_sec[ 3];
	      IPparam->rstack[18]=ILUP_sec[ 4];
	      IPparam->rstack[19]=ILUP_sec[ 5];
	      IPparam->rstack[20]=ILUP_sec[ 6];
	      IPparam->rstack[21]=ILUP_sec[ 7];
	      IPparam->rstack[22]=ILUP_sec[ 8];
	      IPparam->rstack[23]=ILUP_sec[ 9];
	      IPparam->rstack[24]=mycondest;
	      IPparam->rstack[25]=elbow;
	      IPparam->rstack[26]=condest0;
	      IPparam->rstack[27]=condest_increase;

	      IPparam->pfstack[0]=alu;
	      IPparam->pfstack[1]=a;
	      IPparam->pfstack[2]=r;
	      IPparam->pfstack[3]=c;
	      
	      IPparam->ststack[0]=nibuff;
	      IPparam->ststack[1]=ndbuff;
	      IPparam->ststack[2]=mem;

	      IPparam->pststack[0]=delta;
	      
	      IPparam->mstack[0]=S;
	      
	      IPparam->amglmstack[0]=current;
	      
	      IPparam->intfctstack[0]=perm0;
	      IPparam->intfctstack[1]=perm;
	      IPparam->intfctstack[2]=permf;
	      
	      // printf("stack completed\n");fflush(stdout);
	      return (0);
	   } // end if

label1:
	   if (IPparam->returnlabel==1) {
#ifdef PRINT_RC
	      printf("re-enter SPDAMGFACTOR from reverse communication at label 1\n");fflush(stdout);
#endif
	      // load local variables
	      i               =IPparam->istack[ 0];
	      j               =IPparam->istack[ 1];
	      k               =IPparam->istack[ 2];
	      l               =IPparam->istack[ 3];
	      n               =IPparam->istack[ 4];
	      PILUCparam      =IPparam->istack[ 5];
	      nnz             =IPparam->istack[ 6];
	      nB              =IPparam->istack[ 7];
	      ierr            =IPparam->istack[ 8];
	      regular_pivoting=IPparam->istack[ 9];
	      lfil[0]         =IPparam->istack[10];
	      lfil[1]         =IPparam->istack[11];
	      elbow           =IPparam->istack[12];
	      param           =IPparam->istack[13];
	      discardA        =IPparam->istack[14];
	      shiftA          =IPparam->istack[15];
	      imem            =IPparam->istack[16];
	      nlev            =IPparam->istack[17];
	      
	      jlu=IPparam->pistack[0];
	      ia =IPparam->pistack[1];
	      ja =IPparam->pistack[2];
	      
	      droptols[0] =IPparam->rstack[ 0];
	      droptols[1] =IPparam->rstack[ 1];
	      droptols[2] =IPparam->rstack[ 2];
	      condest     =IPparam->rstack[ 3];
	      amgcancel   =IPparam->rstack[ 4];
	      ilucancel   =IPparam->rstack[ 5];
	      seps	  =IPparam->rstack[ 6];
	      ptol	  =IPparam->rstack[ 7];
	      val	  =IPparam->rstack[ 8];
	      vb          =IPparam->rstack[ 9];
	      systime     =IPparam->rstack[10];
	      time_start  =IPparam->rstack[11];
	      time_stop   =IPparam->rstack[12];
	      secnds      =IPparam->rstack[13];
	      ILUP_sec[ 0]=IPparam->rstack[14];
	      ILUP_sec[ 1]=IPparam->rstack[15];
	      ILUP_sec[ 2]=IPparam->rstack[16];
	      ILUP_sec[ 3]=IPparam->rstack[17];
	      ILUP_sec[ 4]=IPparam->rstack[18];
	      ILUP_sec[ 5]=IPparam->rstack[19];
	      ILUP_sec[ 6]=IPparam->rstack[20];
	      ILUP_sec[ 7]=IPparam->rstack[21];
	      ILUP_sec[ 8]=IPparam->rstack[22];
	      ILUP_sec[ 9]=IPparam->rstack[23];
	      mycondest   =IPparam->rstack[24];
	      elbow       =IPparam->rstack[25];
	      condest0    =IPparam->rstack[26];
	      condest_increase=IPparam->rstack[27];
	      
	      alu=IPparam->pfstack[0];
	      a  =IPparam->pfstack[1]; 
	      r  =IPparam->pfstack[2]; 
	      c  =IPparam->pfstack[3];
	      
	      nibuff=IPparam->ststack[0];
	      ndbuff=IPparam->ststack[1];
	      mem   =IPparam->ststack[2];
	      
	      delta=IPparam->pststack[0];
	      
	      S=IPparam->mstack[0];
	      current=IPparam->amglmstack[0];

	      perm0=IPparam->intfctstack[0];
	      perm =IPparam->intfctstack[1];
	      permf=IPparam->intfctstack[2];
	      // if necessary manipulate testvector
	   }
	   IPparam->rcomflag=0;
	   IPparam->returnlabel=0;


	   // apply reordering techniques 
	  
	   // initial reordering
	   if (nlev==1 && (param&PREPROCESS_INITIAL_SYSTEM)) {
	      IPparam->ipar[7]&=~1024;
	      IPparam->ipar[7]|=512;
	      ierr=(*perm0)(S, current->rowscal, current->colscal,current->p,
			    current->invq, &current->nB, IPparam);
	      IPparam->ipar[7]&=~(512+1024);
	   }
	   else 
	      // final pivoting
	      if (nlev>1 && (param&FINAL_PIVOTING) && !regular_pivoting) { 
		 IPparam->ipar[7]|=512+1024;
		 ierr=(*permf)(S, current->rowscal, current->colscal, current->p,
			       current->invq, &current->nB, IPparam);
		 IPparam->ipar[7]&=~(512+1024);
	      } // end if-elseif-if
	      else
		 // regular pivoting
		 if (nlev>1 && (param&PREPROCESS_SUBSYSTEMS)) { 
		    IPparam->ipar[7]&=~512;
		    IPparam->ipar[7]|=1024;
		    ierr=(*perm)(S, current->rowscal, current->colscal, current->p,
				 current->invq, &current->nB, IPparam);
		    IPparam->ipar[7]&=~(512+1024);
		 } // end if-elseif-elseif

	   evaluate_time(&time_stop,&systime);
	   if (nlev==1)
	      // time for initial preprocessing + scaling
	      ILUP_sec[0] =time_stop-time_start;
	   else
	      // accumulated time for reordering/pivoting and scaling 
	      // the remaining systems
	      ILUP_sec[1]+=time_stop-time_start;

	   if (ierr) {
	      // compute total setup time
	      ILUP_sec[7]=time_stop-ILUP_sec[7];
	      // compute TOTAL time
	      ILUP_sec[8]=time_stop-ILUP_sec[8];
	      for (i=0; i<ILUPACK_secnds_length; i++)
		  ILUPACK_secnds[i]=ILUP_sec[i];
	      current->E.ia=current->F.ia=NULL;
	      current->E.ja=current->F.ja=NULL;
	      current->E.a =current->F.a =NULL;
	      current->LU.ja=jlu;
	      
	      // undo scaling
	      r=PRE->rowscal;
	      c=PRE->colscal;
	      // adjust arrays
	      ia=A->ia;
	      ja=A->ja;
	      a =A->a;
	      ja--;
	      a--;
	      c--;
	      for (i=0; i<A->nr; i++) {
		  for (j=ia[i]; j<ia[i+1]; j++) {
		      k=ja[j];
#if defined _SINGLE_REAL_ || defined _DOUBLE_REAL_
		      a[j]/=r[i]*c[k];
#else
		      a[j].r/=r[i].r*c[k].r;
		      a[j].i/=r[i].r*c[k].r;
#endif	  
		  }
	      }

	      SPDAMGDELETE(A, PRE, IPparam);
	      return (ierr);
	   }

	   if ((n-current->nB > amgcancel*n || current->nB==0) && 
	       (param&FINAL_PIVOTING) && regular_pivoting) {
	      // switch to final pivoting
	      regular_pivoting=0;
	      amgcancel  =IPparam->fpar[5]; 
	      current->nB=n;
	      evaluate_time(&time_start,&systime);
	      IPparam->ipar[7]|=512+1024;
	      ierr=(*permf)(S, current->rowscal, current->colscal, current->p,
			    current->invq, &current->nB, IPparam);
	      IPparam->ipar[7]&=~(512+1024);
	      
	      evaluate_time(&time_stop,&systime);
	      if (nlev==1)
	         // time for initial preprocessing + scaling
	         ILUP_sec[0] =time_stop-time_start;
	      else
	         // accumulated time for reordering/pivoting and scaling 
	         // the remaining systems
	         ILUP_sec[1]+=time_stop-time_start;

	      if (ierr) {
	         // compute total setup time
	         ILUP_sec[7]=time_stop-ILUP_sec[7];
		 // compute TOTAL time
		 ILUP_sec[8]=time_stop-ILUP_sec[8];
		 for (i=0; i<ILUPACK_secnds_length; i++)
		     ILUPACK_secnds[i]=ILUP_sec[i];
		 current->E.ia=current->F.ia=NULL;
		 current->E.ja=current->F.ja=NULL;
		 current->E.a =current->F.a =NULL;
		 current->LU.ja=jlu;
		 
		 // undo scaling
		 r=PRE->rowscal;
		 c=PRE->colscal;
		 // adjust arrays
		 ia=A->ia;
		 ja=A->ja;
		 a =A->a;
		 ja--;
		 a--;
		 c--;
		 for (i=0; i<A->nr; i++) {
		     for (j=ia[i]; j<ia[i+1]; j++) {
		         k=ja[j];
#if defined _SINGLE_REAL_ || defined _DOUBLE_REAL_
			 a[j]/=r[i]*c[k];
#else
			 a[j].r/=r[i].r*c[k].r;
			 a[j].i/=r[i].r*c[k].r;
#endif	  
		     }
		 }
		 
		 SPDAMGDELETE(A, PRE, IPparam);
		 return (ierr);
	      }
	   } // end if


	   nB=current->nB;
	   // perform PILDLC decomposition
	   
	   current->LUperm=NULL;
	   
#ifdef PRINT_INLINE
	   printf(", nB=%7d->",current->nB);fflush(STDOUT);
#endif
	  
	   if (current->nB>0) {
	      // start counter for (m)pildlc
	      evaluate_time(&time_start,&systime);
	      condest1=condest;
	      condest/=2.0;
	      mymaximem=0;
	      do {
	         current->nB=nB;
		 ierr=0;
		 condest*=2.0;
		 // printf("level %2d, condest=%8.1le\n",nlev,condest);fflush(stdout);
		 if (nlev>1)
		    PILUCparam|=discardA;
		 shiftA=0;

		 if (PILUCparam&(DIAGONAL_COMPENSATION|STATIC_TESTVECTOR|DYNAMIC_TESTVECTOR)) {
		    // rescale test vector
		    for (i=0; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		        IPparam->testvector[i]/=current->colscal[i];
#else
			val=1.0/(current->colscal[i].r*current->colscal[i].r +
				 current->colscal[i].i*current->colscal[i].i);
			vb=IPparam->testvector[i].r;
			IPparam->testvector[i].r=( vb*current->colscal[i].r
						   +IPparam->testvector[i].i*current->colscal[i].i)*val;
			IPparam->testvector[i].i=(-vb*current->colscal[i].i
						  +IPparam->testvector[i].i*current->colscal[i].r)*val;
#endif
		    } // end for i
		    // compute a permuted copy
		    for (i=0; i<n; i++) {
		        IPparam->testvector[n+current->invq[i]-1]=IPparam->testvector[i];
		    } // end for i
		 } // end if
		 
		 posiwk=0;
		 if (nlev>1) {
		    delta_ia=jlu-S.ia;
		    delta_ja=jlu-S.ja;
		    delta_a =alu-S.a;
		 }
		 do {
		    /*
		    if (posiwk>0) {
		       printf("Re-enter pildlc at label %d\n",posiwk);
		       fflush(stdout);
		    }
		    */
   
		    imem=(LONG_INT)mem;
		    if (param&MULTI_PILUC){
		       // MPILDLC(&n,S.a,S.ja,S.ia,lfil,droptols,&condest,
		       //         IPparam->fpar+6,
		       PILDLC(&n,S.a,S.ja,S.ia,lfil,droptols,&condest,
			      &current->nB,&PILUCparam,current->p,current->invq,alu,
			      jlu,&imem,IPparam->dbuff,IPparam->ibuff,&shiftA,
			      &amgcancel,IPparam->testvector, &posiwk, &ierr);
		    }
		    else {
		       PILDLC (&n,S.a,S.ja,S.ia,lfil,droptols,&condest,
			       &current->nB,&PILUCparam,current->p,current->invq,alu,
			       jlu,&imem,IPparam->dbuff,IPparam->ibuff,&shiftA,
			       &amgcancel,IPparam->testvector, &posiwk, &ierr);
		    }
		    mymaximem=MAX(mymaximem,imem);
		   
		    if (posiwk>0) {
		       // total amount of memory requested by the parameters
		       myimem=elbow*(size_t)A->ia[A->nr];
		       mem+=myimem;
		       IPparam->elbow+=elbow;
#ifdef PRINT_MEM
		       printf("posiwk=%d,jlumem=%8.2fMB, alumem=%8.2fMB, elbow=%8.2f\n",
			      posiwk,IPparam->njlu/IMEGA,IPparam->nalu/DMEGA,IPparam->elbow);
		       fflush(stdout);
#endif
		       IPparam->njlu+=myimem;
		       // printf("jlu_old=%lu,%lu,%lu\n",IPparam->jlu,jlu,jlu-IPparam->jlu);
		       // printf("alu_old=%lu,%lu,%lu\n",IPparam->alu,alu,alu-IPparam->alu);
		       IPparam->jlu=(integer *) REALLOC(IPparam->jlu,
							IPparam->njlu*sizeof(integer),
							"spdAMGfactor:jlu");
#ifdef PRINT_MEM
		       printf("level %2d, jlu(%8.2fMB) re-allocated\n",nlev,IPparam->njlu/IMEGA);fflush(stdout);
#endif
		       IPparam->nalu+=myimem;
		       IPparam->alu=(FLOAT *)REALLOC(IPparam->alu,
						     IPparam->nalu*sizeof(FLOAT),
						     "spdAMGfactor:alu");
#ifdef PRINT_MEM
		       printf("level %2d, alu(%8.2fMB) re-allocated\n",nlev,IPparam->nalu/DMEGA);fflush(stdout);
#endif
		       // remap pointers
		       curr=PRE;
		       for (i=0; i<nlev; i++) {
			 
			   // only sparse case
			   curr->LU.ja=IPparam->jlu+delta[i];
			   curr->LU.a =IPparam->alu+delta[i];
			   curr=curr->next;
		       }
		       jlu=IPparam->jlu+delta[nlev-1];
		       alu=IPparam->alu+delta[nlev-1];
		       if (nlev>1) {
			  S.ia=jlu-delta_ia;
			  S.ja=jlu-delta_ja;
			  S.a =alu-delta_a;
		       }
		       // printf("jlu_new=%lu,%lu,%lu\n",IPparam->jlu,jlu,jlu-IPparam->jlu);
		       // printf("alu_new=%lu,%lu,%lu\n",IPparam->alu,alu,alu-IPparam->alu);
#ifdef PRINT_MEM
		       printf("level %2d, delta=%d, pointers remapped\n",nlev,delta[nlev-1]);fflush(stdout);
#endif
		    } // end if posiwk>0
		 }
		 while (posiwk>0);
	      }
	      while (nB-current->nB>amgcancel*nB && 
		     condest<1024*condest0 && condest<16*condest1);

	      // if PILUC successfully reduced the matrix, but if the
	      // reduction was not great, then we increase condest
	      // hoping to be more successful on the next level
	      if (n-current->nB>condest_increase*nB && 
		  condest<1024*condest0 && condest<16*condest1) {
		 condest*=2.0;
	      }

	      // printf("pildlc completed, nlev=%d\n",nlev);fflush(stdout);

	      // transfer condest back to the parameter array, if we had to increment condest
	      // already on the initial level
	      if (nlev==1 && condest>IPparam->condest)
	         IPparam->condest=condest;

	      alu-=shiftA;
	      jlu-=shiftA;
	      delta[nlev-1]-=shiftA;
	      // stop counter for (m)piluc
	      evaluate_time(&time_stop,&systime);
	      // accumulate collective time for (m)piluc
	      ILUP_sec[2]+=time_stop-time_start;
	      if (ierr) {
	         // compute total setup time
	         ILUP_sec[7]=time_stop-ILUP_sec[7];
		 // compute TOTAL time
		 ILUP_sec[8]=time_stop-ILUP_sec[8];
		 for (i=0; i<ILUPACK_secnds_length; i++)
		     ILUPACK_secnds[i]=ILUP_sec[i];
		 current->E.ia=current->F.ia=NULL;
		 current->E.ja=current->F.ja=NULL;
		 current->E.a =current->F.a =NULL;
		 current->LU.ja=jlu;
		 
		 // undo scaling
		 r=PRE->rowscal;
		 c=PRE->colscal;
		 // adjust arrays
		 ia=A->ia;
		 ja=A->ja;
		 a =A->a;
		 ja--;
		 a--;
		 c--;
		 for (i=0; i<A->nr; i++) {
		     for (j=ia[i]; j<ia[i+1]; j++) {
		         k=ja[j];
#if defined _SINGLE_REAL_ || defined _DOUBLE_REAL_
			 a[j]/=r[i]*c[k];
#else
			 a[j].r/=r[i].r*c[k].r;
			 a[j].i/=r[i].r*c[k].r;
#endif	  
		     }
		 }
		 
		 SPDAMGDELETE(A, PRE, IPparam);
		 return (ierr);
	      }
	   }

#ifdef PRINT_INLINE
	   printf("%7d\n",current->nB);fflush(STDOUT);
#endif

	  
	   // COMMENT: Maybe in a later version the extraction of E and F and discarding the old
	   //          S should be done in one shot. This is reasonable, since (for nlev>1) the old
	   //          matrix S is not needed any longer and to create some new space to store E and
	   //          F is not really necessary. But this is very technical, since the rows of S
	   //          have to be reordered in order to construct E and F :(
	   
	   
	   // appearently piluc failed
	   // BUT we set the final pivoting flag
	   // AND we haven't switched to final pivoting yet
	   if ((nB-current->nB > amgcancel*nB || nB==0) && 
	       (param&FINAL_PIVOTING) && regular_pivoting) {
	      // switch to final pivoting
#ifdef PRINT_INLINE
	      printf("level %d,  piluc failed (nB=%d), switch to final pivoting\n",nlev,current->nB);fflush(STDOUT);
#endif

	      if (PILUCparam&(DIAGONAL_COMPENSATION|STATIC_TESTVECTOR|DYNAMIC_TESTVECTOR)) {
	         // undo rescale test vector
	         for (i=0; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		     IPparam->testvector[i]*=current->colscal[i];
#else
		     vb=IPparam->testvector[i].r;
		     IPparam->testvector[i].r= vb*current->colscal[i].r
		                              -IPparam->testvector[i].i*current->colscal[i].i;
		     IPparam->testvector[i].i= vb*current->colscal[i].i
					      +IPparam->testvector[i].i*current->colscal[i].r;
#endif
		 } // end for i
	      } // end if
	      // undo scaling for S
	      for (i=0; i<n; i++) {
		  for (j=S.ia[i]-1; j<S.ia[i+1]-1; j++) {
		      l=S.ja[j]-1;
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		      S.a[j]=S.a[j]/(current->rowscal[i]*current->colscal[l]);
#else
		      val=1.0/(current->rowscal[i].r*current->rowscal[i].r +
			       current->rowscal[i].i*current->rowscal[i].i);
		      vb=S.a[j].r;
		      S.a[j].r=(     vb*current->rowscal[i].r
			      +S.a[j].i*current->rowscal[i].i)*val;
		      S.a[i].i=(    -vb*current->rowscal[i].i
			      +S.a[j].i*current->rowscal[i].r)*val;

		      val=1.0/(current->colscal[l].r*current->colscal[l].r +
			       current->colscal[l].i*current->colscal[l].i);
		      vb=S.a[j].r;
		      S.a[j].r=(     vb*current->colscal[l].r
			      +S.a[j].i*current->colscal[l].i)*val;
		      S.a[i].i=(    -vb*current->colscal[l].i
			      +S.a[j].i*current->colscal[l].r)*val;
#endif
		  }
	      } // end for i

	      regular_pivoting=0;
	      amgcancel  =IPparam->fpar[5]; 
	      current->nB=n;
	      evaluate_time(&time_start,&systime);
	      IPparam->ipar[7]|=512+1024;
	      ierr=(*permf)(S, current->rowscal, current->colscal, current->p,
			    current->invq, &current->nB, IPparam);
	      IPparam->ipar[7]&=~(512+1024);

	      evaluate_time(&time_stop,&systime);
	      if (nlev==1)
	         // time for initial preprocessing + scaling
	         ILUP_sec[0] =time_stop-time_start;
	      else
	         // accumulated time for reordering/pivoting and scaling 
	         // the remaining systems
	         ILUP_sec[1]+=time_stop-time_start;
	      
	      if (ierr) {
	         // compute total setup time
	         ILUP_sec[7]=time_stop-ILUP_sec[7];
		 // compute TOTAL time
		 ILUP_sec[8]=time_stop-ILUP_sec[8];
		 for (i=0; i<ILUPACK_secnds_length; i++)
		     ILUPACK_secnds[i]=ILUP_sec[i];
		 current->E.ia=current->F.ia=NULL;
		 current->E.ja=current->F.ja=NULL;
		 current->E.a =current->F.a =NULL;
		 current->LU.ja=jlu;
		 
		 // undo scaling
		 r=PRE->rowscal;
		 c=PRE->colscal;
		 // adjust arrays
		 ia=A->ia;
		 ja=A->ja;
		 a =A->a;
		 ja--;
		 a--;
		 c--;
		 for (i=0; i<A->nr; i++) {
		     for (j=ia[i]; j<ia[i+1]; j++) {
		         k=ja[j];
#if defined _SINGLE_REAL_ || defined _DOUBLE_REAL_
			 a[j]/=r[i]*c[k];
#else
			 a[j].r/=r[i].r*c[k].r;
			 a[j].i/=r[i].r*c[k].r;
#endif	  
		     }
		 }
		
		 SPDAMGDELETE(A, PRE, IPparam);
		 return (ierr);
	      }
	      
	      nB=current->nB;
	      current->LUperm=NULL;

#ifdef PRINT_INLINE
	      printf(", nB=%7d->",current->nB);fflush(STDOUT);
#endif

	      if (current->nB>0) {
	         // start counter for (m)piluc
	         evaluate_time(&time_start,&systime);
		 condest1=condest;
		 condest/=2.0;
		 mymaximem=0;
		 do {
		    current->nB=nB;
		    ierr=0;
		    condest*=2.0;
		    // printf("level %2d, condest=%8.1le\n",nlev,condest);fflush(stdout);
		    // if DISCARD_MATRIX is set, then at any level>1 the system
		    // matrix is discarded as soon as possible to save memory
		    if (nlev>1)
		       PILUCparam|=discardA;
		    shiftA=0;

		    if (PILUCparam&(DIAGONAL_COMPENSATION|STATIC_TESTVECTOR|DYNAMIC_TESTVECTOR)) {
		       // rescale test vector
		       for (i=0; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
			   IPparam->testvector[i]/=current->colscal[i];
#else
			   val=1.0/(current->colscal[i].r*current->colscal[i].r +
				    current->colscal[i].i*current->colscal[i].i);
			   vb=IPparam->testvector[i].r;
			   IPparam->testvector[i].r=( vb*current->colscal[i].r
						     +IPparam->testvector[i].i*current->colscal[i].i)*val;
			   IPparam->testvector[i].i=(-vb*current->colscal[i].i
				   		     +IPparam->testvector[i].i*current->colscal[i].r)*val;
#endif
		       } // end for i
		       // compute a permuted copy
		       for (i=0; i<n; i++) {
			   IPparam->testvector[n+current->invq[i]-1]=IPparam->testvector[i];
		       } // end for i
		    } // end if
		    
		    posiwk=0;
		    if (nlev>1) {
		       delta_ia=jlu-S.ia;
		       delta_ja=jlu-S.ja;
		       delta_a =alu-S.a;
		    }
		    do {
		       imem=(LONG_INT)mem;
		       if (param&MULTI_PILUC) {
			  //MPILDLC(&n,S.a,S.ja,S.ia,lfil,droptols,&condest,
			  //       IPparam->fpar+6,
			  PILDLC(&n,S.a,S.ja,S.ia,lfil,droptols,&condest,
				 &current->nB,&PILUCparam,current->p,current->invq,
				 alu,jlu,&imem,IPparam->dbuff,IPparam->ibuff,
				 &shiftA,&amgcancel,IPparam->testvector, &posiwk, &ierr);
		       }
		       else
			  PILDLC (&n,S.a,S.ja,S.ia,lfil,droptols,&condest,
				  &current->nB,&PILUCparam,current->p,current->invq,
				  alu,jlu,&imem,IPparam->dbuff,IPparam->ibuff,
				  &shiftA,&amgcancel,IPparam->testvector, &posiwk, &ierr);
		       mymaximem=MAX(mymaximem,imem);
		       
		       if (posiwk>0) {
			  // total amount of memory requested by the parameters
			  myimem=elbow*(size_t)A->ia[A->nr];
			  mem+=myimem;
			  IPparam->elbow+=elbow;
#ifdef PRINT_MEM
			  printf("!posiwk=%d,jlumem=%8.2fMB, alumem=%8.2fMB, elbow=%8.2f\n",
				 posiwk,IPparam->njlu/IMEGA,IPparam->nalu/DMEGA,IPparam->elbow);
			  fflush(stdout);
#endif
			  IPparam->njlu+=myimem;
			  // printf("!jlu_old=%lu,%lu,%lu\n",IPparam->jlu,jlu,jlu-IPparam->jlu);
			  // printf("!alu_old=%lu,%lu,%lu\n",IPparam->alu,alu,alu-IPparam->alu);
			  IPparam->jlu=(integer *) REALLOC(IPparam->jlu,
							   IPparam->njlu*sizeof(integer),
							   "spdAMGfactor:jlu");
#ifdef PRINT_MEM
			  printf("!level %2d, jlu(%8.2fMB) re-allocated\n",nlev,IPparam->njlu/IMEGA);fflush(stdout);
#endif
			  IPparam->nalu+=myimem;
			  IPparam->alu=(FLOAT *)REALLOC(IPparam->alu,
							IPparam->nalu*sizeof(FLOAT),
						       "spdAMGfactor:alu");
#ifdef PRINT_MEM
			  printf("!level %2d, alu(%8.2fMB) re-allocated\n",nlev,IPparam->nalu/DMEGA);fflush(stdout);
#endif
			  // remap pointers
			  curr=PRE;
			  for (i=0; i<nlev; i++) {
			    
			      // sparse case only
			      curr->LU.ja=IPparam->jlu+delta[i];
			      curr->LU.a =IPparam->alu+delta[i];
			      curr=curr->next;
			  }
			  jlu=IPparam->jlu+delta[nlev-1];
			  alu=IPparam->alu+delta[nlev-1];
			  if (nlev>1) {
			     S.ia=jlu-delta_ia;
			     S.ja=jlu-delta_ja;
			     S.a =alu-delta_a;
			  }
			  // printf("!jlu_new=%lu,%lu,%lu\n",IPparam->jlu,jlu,jlu-IPparam->jlu);
			  // printf("!alu_new=%lu,%lu,%lu\n",IPparam->alu,alu,alu-IPparam->alu);
#ifdef PRINT_MEM
			  printf("!level %2d, delta=%d, pointers remapped\n",nlev,delta[nlev-1]);fflush(stdout);
#endif
		       } // end if posiwk>0
		    }
		    while (posiwk>0);
		 }
		 while (nB-current->nB>amgcancel*nB && 
			condest<1024*condest0 && condest<16*condest1);

		 // if PILUC successfully reduced the matrix, but if the
		 // reduction was not great, then we increase condest
		 // hoping to be more successful on the next level
		 if (n-current->nB>condest_increase*nB && 
		     condest<1024*condest0 && condest<16*condest1) {
		    condest*=2.0;
		 }

		 printf("pildlc completed, nlev=%d\n",nlev);fflush(stdout);
		
		 // transfer condest back to the parameter array, if we had to increment condest
		 // already on the initial level
		 if (nlev==1 && condest>IPparam->condest)
		    IPparam->condest=condest;

		 alu-=shiftA;
		 jlu-=shiftA;
		 delta[nlev-1]-=shiftA;
		 // stop counter for (m)piluc
		 evaluate_time(&time_stop,&systime);
		 // accumulate collective time for (m)piluc
		 ILUP_sec[2]+=time_stop-time_start;
		 if (ierr) {
		    // compute total setup time
		    ILUP_sec[7]=time_stop-ILUP_sec[7];
		    // compute TOTAL time
		    ILUP_sec[8]=time_stop-ILUP_sec[8];
		    for (i=0; i<ILUPACK_secnds_length; i++)
		        ILUPACK_secnds[i]=ILUP_sec[i];
		    current->E.ia=current->F.ia=NULL;
		    current->E.ja=current->F.ja=NULL;
		    current->E.a =current->F.a =NULL;
		    current->LU.ja=jlu;
		    
		    // undo scaling
		    r=PRE->rowscal;
		    c=PRE->colscal;
		    // adjust arrays
		    ia=A->ia;
		    ja=A->ja;
		    a =A->a;
		    ja--;
		    a--;
		    c--;
		    for (i=0; i<A->nr; i++) {
		        for (j=ia[i]; j<ia[i+1]; j++) {
			    k=ja[j];
#if defined _SINGLE_REAL_ || defined _DOUBLE_REAL_
			    a[j]/=r[i]*c[k];
#else
			    a[j].r/=r[i].r*c[k].r;
			    a[j].i/=r[i].r*c[k].r;
#endif	  
			}
		    }
		    
		    SPDAMGDELETE(A, PRE, IPparam);
		    return (ierr);
		 }
	      }

#ifdef PRINT_INLINE
	      printf("%7d\n",current->nB);fflush(STDOUT);
#endif
	      
	   } // end if

	   // maximum (peek) memory observed during pildlc
	   ILUPACK_mem[4]=MAX(ILUPACK_mem[4],ILUPACK_mem[2]+mymaximem);
	   ILUPACK_mem[5]=MAX(ILUPACK_mem[5],ILUPACK_mem[3]+mymaximem);
	   
	   /* if pildlc reduction was successful */
	   if (nB-current->nB<=amgcancel*nB && nB>0) {
	      if (n-current->nB) {
	         if (PILUCparam&COARSE_REDUCE) {
		    SYMAMGEXTRACT(&current->F,S, current->p,current->invq,
				  current->nB);
		    ILUPACK_mem[6]+=current->F.nr+1
		                   +current->F.ia[current->F.nr]-1;
		    ILUPACK_mem[7]+=current->F.ia[current->F.nr]-1;
		    current->E=current->F;
		 }
		 else { 
		    // if no coarse reduction is done then L11 and L21 
		    // (resp. U11, U12) are kept in one common array
		    current->E.nr=current->F.nc=n-current->nB;
		    current->E.nc=current->F.nr=current->nB;
		    current->E.ia=current->F.ia=NULL;
		    current->E.ja=current->F.ja=NULL;
		    current->E.a =current->F.a =NULL;
		 }
	      }
	      else {
	         current->E.nr=current->F.nc=0;
		 current->E.nc=current->F.nr=0;
	      }

	      /* discard old S by simply shifting the new S and the L and U factors,
		 because they immediately follow S in the memory */
	      
	      /*
		printf("p%d=[",nlev);
		for (i=0;i<n;i++) 
		printf(" %d",current->p[i]);
		printf("]\n");fflush(stdout);
	      */

	      if (nlev>1) {
		 // number of nonzeros in the old S
	         k=S.ia[n]-1;
		 if (!discardA) {
		    current->A.ia=(integer *)MALLOC((size_t)(n+1)*sizeof(integer),"spdAMGfactor:current->A.ia");
		    memcpy(current->A.ia,S.ia,(size_t)(n+1)*sizeof(integer));
		    
		    current->A.ja=(integer *)MALLOC((size_t)k*sizeof(integer),    "spdAMGfactor:current->A.ja");
		    memcpy(current->A.ja,S.ja,(size_t)k*sizeof(integer));
		    
		    current->A.a =(FLOAT *)MALLOC((size_t)k*sizeof(FLOAT),        "spdAMGfactor:current->A.a");
		    memcpy(current->A.a, S.a, (size_t)k*sizeof(FLOAT));
		    current->A.nr=current->A.nc=n;
		    ILUPACK_mem[10]+=n+1+k;
		    ILUPACK_mem[11]+=k;
		    // printf("%ld, av. nnz=%8.1lf\n",nlev,(current->A.ia[n]-1)/((double)n));fflush(stdout);
		    // printf("lev %2d, system size=%6d, fill-in=%8.1f(av.)\n",nlev,
		    //	  n,(current->A.ia[n]-1)/((double)n));fflush(stdout);
		    
		    /*
		    printf("A%d=[",nlev);
		    for (i=0;i<n;i++) 
		        for (j=current->A.ia[i]-1;j<current->A.ia[i+1]-1;j++) 
			  printf(" %d %d %8.1e;...\n",i+1,current->A.ja[j],current->A.a[j]);
		    printf("];\n");fflush(stdout);
		    */
		 }
		 // number of nonzeros in U and the new S
		 nnz=jlu[n]-1;
		 alu-=k;
		 jlu-=k;
		 delta[nlev-1]-=k;
		 for (i=0; i<nnz; i++) {
		     alu[i]=alu[i+k];
		     jlu[i]=jlu[i+k];
		 } /* end for */
		 mem+=k;
		 ILUPACK_mem[2]-=k;
		 ILUPACK_mem[3]-=k;
	      }
	      else { // store copy to pointers of the initial matrix
	         current->A.ia=S.ia;
		 current->A.ja=S.ja;
		 current->A.a =S.a;
		 current->A.nr=current->A.nc=S.nr;
	      }
	     
	      current->LU.nr=current->nB;
	      current->LU.nc=current->LU.nr;
	      current->LU.a =alu;
	      current->LU.ja=jlu;
	      current->LU.ia=NULL;
	      
	      // number of nonzeros in LU
	      nnz=jlu[current->nB]-1;
	      current->LU.nnz=nnz;
	      
	      S.nr=n-current->nB; 
	      S.nc=S.nr;
	      S.a=alu+nnz;
	      S.ja=jlu+nnz;
	      S.ia=jlu+current->nB;
	      for (i=0; i<=S.nr; i++)
	          S.ia[i]-=nnz;
	      
	      
	      nnz+=jlu[n]-1;
	      alu+=nnz;
	      jlu+=nnz;
	      delta[nlev]=delta[nlev-1]+nnz;
	      mem-=(size_t)nnz;
	      ILUPACK_mem[2]+=(size_t)nnz;
	      ILUPACK_mem[3]+=(size_t)nnz;
	      // maximum (peek) memory observed during pildlc
	      ILUPACK_mem[4]=MAX(ILUPACK_mem[4],ILUPACK_mem[2]);
	      ILUPACK_mem[5]=MAX(ILUPACK_mem[5],ILUPACK_mem[3]);
	      

	      // adapt test vector to the coarse grid
	      // reorder the test vector
	      if (PILUCparam&(DIAGONAL_COMPENSATION|STATIC_TESTVECTOR|DYNAMIC_TESTVECTOR)) {
	         for (i=0; i<n; i++)
		     IPparam->dbuff[current->invq[i]-1]=IPparam->testvector[i];
		 for (i=current->nB; i<n; i++)
		     IPparam->testvector[i-current->nB]=IPparam->dbuff[i];
	      }
	      
	   } /* end if (nB-current->nB<=amgcancel*nB) */
	   else { /* pildlc failed to produce a sensible reduction */

#ifdef PRINT_INLINE
	        printf("level %d,  piluc failed (nB=%d), switch to ILDLC\n",nlev,current->nB);fflush(STDOUT);
#endif

		/* switch to ILDLC */
		
		// start counter for ILDLC
		evaluate_time(&time_start,&systime);
		current->LUperm=NULL;
		for (i=0; i<n; i++)
	            current->p[i]=current->invq[i]=i+1;
		
		imem=(LONG_INT)mem;
		myimem=imem;
		ILDLC(&n,S.a,S.ja,S.ia,&n,IPparam->fpar+7,&PILUCparam,alu,jlu,&myimem,
		      IPparam->dbuff,IPparam->ibuff,&ierr);
		ILUPACK_mem[4]=MAX(ILUPACK_mem[4],ILUPACK_mem[2]+myimem);
		ILUPACK_mem[5]=MAX(ILUPACK_mem[5],ILUPACK_mem[3]+myimem);
		// computation time for ILDLC
		evaluate_time(&time_stop,&systime);
		ILUP_sec[3]=time_stop-time_start;
		if (ierr) {
		   // compute total setup time
		   ILUP_sec[7]=time_stop-ILUP_sec[7];
		   // compute TOTAL time
		   ILUP_sec[8]=time_stop-ILUP_sec[8];
		   for (i=0; i<ILUPACK_secnds_length; i++)
		       ILUPACK_secnds[i]=ILUP_sec[i];
		   current->E.ia=current->F.ia=NULL;
		   current->E.ja=current->F.ja=NULL;
		   current->E.a =current->F.a =NULL;
		   current->LU.ja=jlu;
		   
		   // undo scaling
		   r=PRE->rowscal;
		   c=PRE->colscal;
		   // adjust arrays
		   ia=A->ia;
		   ja=A->ja;
		   a =A->a;
		   ja--;
		   a--;
		   c--;
		   for (i=0; i<A->nr; i++) {
		       for (j=ia[i]; j<ia[i+1]; j++) {
		           k=ja[j];
#if defined _SINGLE_REAL_ || defined _DOUBLE_REAL_
			   a[j]/=r[i]*c[k];
#else
			   a[j].r/=r[i].r*c[k].r;
			   a[j].i/=r[i].r*c[k].r;
#endif	  
		       }
		   }
		
		   SPDAMGDELETE(A, PRE, IPparam);
		   return (ierr);
		}
		
		current->nB=n;
		
		current->E.nr=current->F.nc=0;
		current->E.nc=current->F.nr=0;
		
		
		/*
	        printf("p%d=[",nlev);
	        for (i=0;i<n;i++) 
	            printf(" %d",current->p[i]);
	        printf("]\n");fflush(stdout);
		*/


		/* discard old S by simply shifting the new U factor, because
		   it immediately follows the old S in the memory */
		if (nlev>1) {
		   // number of nonzeros in the old S
		   k=S.ia[n]-1;
		   if (!discardA) {
		      current->A.ia=(integer *)MALLOC((size_t)(n+1)*sizeof(integer),"spdAMGfactor:current->A.ia");
		      memcpy(current->A.ia,S.ia,(size_t)(n+1)*sizeof(integer));

		      current->A.ja=(integer *)MALLOC((size_t)k*sizeof(integer),    "spdAMGfactor:current->A.ja");
		      memcpy(current->A.ja,S.ja,(size_t)k*sizeof(integer));
		      
		      current->A.a =(FLOAT *)MALLOC((size_t)k*sizeof(FLOAT),        "spdAMGfactor:current->A.a");
		      memcpy(current->A.a, S.a, (size_t)k*sizeof(FLOAT));
		      current->A.nr=current->A.nc=n;
		      ILUPACK_mem[10]+=n+1+k;
		      ILUPACK_mem[11]+=k;
		      // printf("%ld, av. nnz=%8.1lf\n",nlev,(current->A.ia[n]-1)/((double)n));fflush(stdout);
		      // printf("lev %2d, system size=%6d, fill-in=%8.1f(av.)\n",nlev,
		      //	  n,(current->A.ia[n]-1)/((double)n));fflush(stdout);
		      
		      /*
		      printf("A%d=[",nlev);
		      for (i=0;i<n;i++) 
		          for (j=current->A.ia[i]-1;j<current->A.ia[i+1]-1;j++) 
			    printf(" %d %d %8.1e;...\n",i+1,current->A.ja[j],current->A.a[j]);
		      printf("];\n");fflush(stdout);
		      */
		   }
		   // number of nonzeros in U
		   nnz=jlu[n]-1;
		   alu-=k;
		   jlu-=k;
		   delta[nlev-1]-=k;
		   for (i=0; i<nnz; i++) {
		       alu[i]=alu[i+k];
		       jlu[i]=jlu[i+k];
		   } // end for
		   mem+=k;
		   ILUPACK_mem[2]-=k;
		   ILUPACK_mem[3]-=k;
		}
		else { // store copy to pointers of the initial matrix
		   current->A.ia=S.ia;
		   current->A.ja=S.ja;
		   current->A.a =S.a;
		   current->A.nr=current->A.nc=S.nr;
		}
		
		current->LU.nr=current->nB;
		current->LU.nc=current->LU.nr;
		current->LU.a =alu;
		current->LU.ja=jlu;
		current->LU.ia=NULL;
		// number of nonzeros in LU
		current->LU.nnz=jlu[current->nB]-1;
		
		nnz=(size_t)jlu[n]-1;
		
		ILUPACK_mem[2]+=(size_t)nnz;
		ILUPACK_mem[3]+=(size_t)nnz;
		ILUPACK_mem[4]=MAX(ILUPACK_mem[4],ILUPACK_mem[2]);
		ILUPACK_mem[5]=MAX(ILUPACK_mem[5],ILUPACK_mem[3]);
		
		n=-1;
		S.nr=0;
	   } // end if-else
	} // end if-else (nlev>1 && 3*(S.ia[n]-1)>S.nr*S.nc)
  } // end while

  // reduce memory to the size that was really needed
  if (!(param&RE_FACTOR)) {
     IPparam->njlu=ILUPACK_mem[2];
     IPparam->jlu=(integer *)  REALLOC(IPparam->jlu,
				       IPparam->njlu*sizeof(integer),  
				       "spdAMGfactor:jlu");
     IPparam->nalu=ILUPACK_mem[3];
     IPparam->alu=(FLOAT *)REALLOC(IPparam->alu,
				   IPparam->nalu*sizeof(FLOAT),
				   "spdAMGfactor:alu");

     IPparam->elbow=((double)(MAX(ILUPACK_mem[4],ILUPACK_mem[5])))/A->ia[A->nr]+1.0e-4;

     /*
     current=PRE;
     j=0;
     for (i=0; i<nlev; i++) {
       if (i==0)
	 printf("%8d,%8ld\n", delta[i],(long)0);
       else {
	 j+=(integer)(((unsigned long)(current->LU.a)-(unsigned long)(current->prev->LU.a))/sizeof(FLOAT));
	 printf("%8d,%8ld\n", delta[i],j);
       }
       current=current->next;
     }
     if ((unsigned long)IPparam->alu!=(unsigned long)PRE->LU.a)
       printf("pointers will be remapped\n");
     */

     // remap pointers
     current=PRE;
     for (i=0; i<nlev; i++) {

         // sparse case
         if (current->LU.ja!=NULL)
	    current->LU.ja=IPparam->jlu+delta[i];
	 else // dense case
	    current->LU.ia=current->prev->LU.ja+current->prev->LU.nr;

	 current->LU.a =IPparam->alu+delta[i];
	 
	 current=current->next;
     } // end for i

  }
  // release delta
  free(delta);

  evaluate_time(&time_stop,&systime);
  // compute total setup time
  ILUP_sec[7]=time_stop-ILUP_sec[7];
  for (i=0; i<ILUPACK_secnds_length; i++)
      ILUPACK_secnds[i]=ILUP_sec[i];

  ILUPACK_mem[0]=IPparam->nibuff;
  ILUPACK_mem[1]=IPparam->ndbuff;

  // make sure that nlev in consistent on all levels
  current=PRE;
  for (i=0; i<nlev; i++) {
      current->nlev=nlev;
      current=current->next;
  }


  // finally undo scaling
  r=PRE->rowscal;
  c=PRE->colscal;
  // adjust arrays
  ia=A->ia;
  ja=A->ja;
  a =A->a;
  ja--;
  a--;
  c--;
  for (i=0; i<A->nr; i++) {
      for (j=ia[i]; j<ia[i+1]; j++) {
	  k=ja[j];
#if defined _SINGLE_REAL_ || defined _DOUBLE_REAL_
	  a[j]/=r[i]*c[k];
#else
	  a[j].r/=r[i].r*c[k].r;
	  a[j].i/=r[i].r*c[k].r;
#endif	  
      }
  }

  return (ierr);
} /* end spdAMGfactor */


