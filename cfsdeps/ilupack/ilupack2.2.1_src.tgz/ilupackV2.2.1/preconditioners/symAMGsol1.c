#include <stdio.h>
#include <stdlib.h>

#include <blas.h>
#include <lapack.h>
#include <ilupack.h>
#include <ilupackmacros.h>

#define MAX_LINE        255
#define STDERR          stderr
#define STDOUT          stdout
//#define PRINT_INFO
#define IABS(A)         (((A)>=0)?(A):-(A))
#define MAX(A,B)        (((A)>(B))?(A):(B))
#define MIN(A,B)        (((A)<(B))?(A):(B))


#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
#define CONJG(A)      (A)
#define MYCSRMATVEC          CSRMATVEC 
#define MYCSRMATTVEC         CSRMATTVEC 

#ifdef _DOUBLE_REAL_
#define MYSYMAMGSOL          DSYMAMGsol
#define MYSYMAMGSOL1         DSYMAMGsol1
#define MYSYMAMGSOL2         DSYMAMGsol2
#define MYSYMPILUCSOL        DSYMpilucsol
#define MYSYMPILUCLSOL       DSYMpiluclsol
#define MYSYMPILUCUSOL       DSYMpilucusol
#define MYPSYMPILUCLSOL      DSYMppiluclsol
#define MYPSYMPILUCUSOL      DSYMppilucusol
#define MYSPTRS              dsptrs
#define MYSMATVEC            DSYMmatvec
#else			   
#define MYSYMAMGSOL          SSYMAMGsol
#define MYSYMAMGSOL1         SSYMAMGsol1
#define MYSYMAMGSOL2         SSYMAMGsol2
#define MYSYMPILUCSOL        SSYMpilucsol
#define MYSYMPILUCLSOL       SSYMpiluclsol
#define MYSYMPILUCUSOL       SSYMpilucusol
#define MYPSYMPILUCLSOL      SSYMppiluclsol
#define MYPSYMPILUCUSOL      SSYMppilucusol
#define MYSPTRS              ssptrs
#define MYSMATVEC            SSYMmatvec
#endif



#else



#ifdef _COMPLEX_SYMMETRIC_
#define CONJG(A)     (A)
#define MYCSRMATVEC          CSRMATVEC 
#define MYCSRMATTVEC         CSRMATTVEC 

#ifdef _SINGLE_COMPLEX_
#define MYSYMAMGSOL          CSYMAMGsol
#define MYSYMAMGSOL1         CSYMAMGsol1
#define MYSYMAMGSOL2         CSYMAMGsol1
#define MYSYMPILUCSOL        CSYMpilucsol
#define MYSYMPILUCLSOL       CSYMpiluclsol
#define MYSYMPILUCUSOL       CSYMpilucusol
#define MYPSYMPILUCLSOL      CSYMppiluclsol
#define MYPSYMPILUCUSOL      CSYMppilucusol
#define MYSPTRS              csptrs
#define MYSMATVEC            CSYMmatvec
#else
#define MYSYMAMGSOL          ZSYMAMGsol
#define MYSYMAMGSOL1         ZSYMAMGsol1
#define MYSYMAMGSOL2         ZSYMAMGsol2
#define MYSYMPILUCSOL        ZSYMpilucsol
#define MYSYMPILUCLSOL       ZSYMpiluclsol
#define MYSYMPILUCUSOL       ZSYMpilucusol
#define MYPSYMPILUCLSOL      ZSYMppiluclsol
#define MYPSYMPILUCUSOL      ZSYMppilucusol
#define MYSPTRS              zsptrs
#define MYSMATVEC            ZSYMmatvec
#endif

#else
#define MYCSRMATVEC          CSRMATVEC 
#define MYCSRMATTVEC         CSRMATHVEC 

#ifdef _SINGLE_COMPLEX_
#define CONJG(A)     (conjg(A))
#define MYSYMAMGSOL          CHERAMGsol
#define MYSYMAMGSOL1         CHERAMGsol1
#define MYSYMAMGSOL2         CHERAMGsol2
#define MYSYMPILUCSOL        CHERpilucsol
#define MYSYMPILUCLSOL       CHERpiluclsol
#define MYSYMPILUCUSOL       CHERpilucusol
#define MYPSYMPILUCLSOL      CHERppiluclsol
#define MYPSYMPILUCUSOL      CHERppilucusol
#define MYSPTRS              chptrs
#define MYSMATVEC            CHERmatvec
#else
#define CONJG(A)     (dconjg(A))
#define MYSYMAMGSOL          ZHERAMGsol
#define MYSYMAMGSOL1         ZHERAMGsol1
#define MYSYMAMGSOL2         ZHERAMGsol2
#define MYSYMPILUCSOL        ZHERpilucsol
#define MYSYMPILUCLSOL       ZHERpiluclsol
#define MYSYMPILUCUSOL       ZHERpilucusol
#define MYPSYMPILUCLSOL      ZHERppiluclsol
#define MYPSYMPILUCUSOL      ZHERppilucusol
#define MYSMATVEC            ZHERmatvec
#define MYSPTRS              zhptrs
#endif

#endif



#endif


/*
   Given a multilevel ILU decomposition, AMGsol1 performs a recursive
   AMLI-like AMG solve
*/ 
void MYSYMAMGSOL1(AMGLEVELMAT *PRE, integer lev, 
		  integer n, integer nbf, integer sumn, integer sumlev,
		  ILUPACKPARAM *IPparam, FLOAT *sol, FLOAT *buff)
{

/*
   PRE       linked list of multilevel ILU preconditioners
   nlev      number of levels (blocks)
   lev       current level (block)
   n         total size
   sumn      sum over all previous leading blocks so far
   sumlev    sum over all previous remaining blocks so far
   IPparam   ILUPACK parameters
   sol       on input: given right hand side, on output: solution
   buff      work array of length max(3n, sum_{lev=2}^{nlev} nB), where n 
             is the size of the original matrix
  
   Code written by Matthias Bollhoefer,     November 2005
*/

   //AMGLEVELMAT *next, *prev;

  integer i,j,k,nnzU,m=IPparam->ipar[11], nB, *p, *invq, param, flag, flagspd,ierr, nlev=PRE->nlev;

   FLOAT *scal, *a;
   REALS val, vb, vali;
   character uplo, trans, diag;
#ifdef PRINT_INFO
   static int check=1;

   if (check) {
     check=0;
#ifdef _SINGLE_REAL_ 
     printf("SSYM1 solve\n");
#else
#ifdef _DOUBLE_REAL_
     printf("DSYM1 solve\n");
#else
#ifdef _SINGLE_COMPLEX_
#ifdef _COMPLEX_SYMMETRIC_
     printf("CSYM1 solve\n");
#else
     printf("CHER1 solve\n");
#endif
#else
#ifdef _COMPLEX_SYMMETRIC_
     printf("ZSYM1 solve\n");
#else
     printf("ZHER1 solve\n");
#endif
#endif
#endif
#endif
   }
#endif

   param=IPparam->ipar[6];

   
   // size of the leading block
   nB=PRE->nB;
   // row permutation
   p   =PRE->p;
   // inverse column permutation
   invq=PRE->invq;

   /* last but first level */
   if (lev==nlev-1) {
      /* if the last level uses direct solve, then only one recursive call
	 is useful, since the system is exactly solved.
         Moreover, the exact coarse grid system is not stored. In this case
	 the matrix-vector multiplication (in case m>1) would lead to an error
      */
      if (PRE->next->LU.ja==NULL)
         m=MIN(m,1);
   }

   /* block forward substitution */
   if (lev<nlev) {
     
      /* reorder the whole system */
      p-=sumn;
      for (i=sumn; i<n; i++)
	  buff[i]=sol[sumn+p[i]-1];
      p+=sumn;

      /* first block */
      if (param&COARSE_REDUCE) {
	 if (PRE->LU.ja[0]<0)
	    flagspd=-1;
	 else
	    flagspd=0;
	 PRE->LU.ja[0]=IABS(PRE->LU.ja[0]);

	 nnzU=PRE->LU.ja[nB];
	 PRE->LU.ja[nB]=PRE->LU.nnz+1;
	 if (flagspd) {
	    // printf("1.\n");fflush(stdout);
	    // solve system with [(L+D)D^{-1}]
	    MYSYMPILUCLSOL(&nB, buff+sumn,sol+sumn, PRE->LU.a,PRE->LU.ja);
	    // printf("2.\n");fflush(stdout);
	 }
	 else
	    MYSYMPILUCSOL(&nB, buff+sumn,sol+sumn, PRE->LU.a,PRE->LU.ja);
	 PRE->LU.ja[nB]=nnzU;

	 if (flagspd) {
	    sol +=sumn;
	    buff+=sumn;
	    // multiply by D^{-1}
	    i=0;
	    a=PRE->LU.a;
	    // printf("3.\n");fflush(stdout);
	    while (i<nB) {
	          if (PRE->LU.ja[nB+1+i]==0) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		     buff[i]=sol[i]*a[i];
#else
		     buff[i].r=sol[i].r*a[i].r-sol[i].i*a[i].i;
		     buff[i].i=sol[i].r*a[i].i+sol[i].i*a[i].r;
#endif
		     i++;
		  }
		  else {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		     buff[i]  =a[i]            *sol[i]+a[nB+1+i]*sol[i+1];
		     buff[i+1]=a[nB+1+i]       *sol[i]+a[i+1]   *sol[i+1];
#else
		     buff[i].r  =a[i].r     *sol[i].r  -a[i].i     *sol[i].i
		                +a[nB+1+i].r*sol[i+1].r-a[nB+1+i].i*sol[i+1].i;
		     buff[i].i  =a[i].r     *sol[i].i  +a[i].i     *sol[i].r
		                +a[nB+1+i].r*sol[i+1].i+a[nB+1+i].i*sol[i+1].r;
#ifdef _COMPLEX_SYMMETRIC_		     
		     buff[i+1].r=a[nB+1+i].r*sol[i].r  -a[nB+1+i].i*sol[i].i
		                +a[i+1].r   *sol[i+1].r-a[i+1].i   *sol[i+1].i;
		     buff[i+1].i=a[nB+1+i].r*sol[i].i  +a[nB+1+i].i*sol[i].r
		                +a[i+1].r   *sol[i+1].i+a[i+1].i   *sol[i+1].r;
#else
		     buff[i+1].r=a[nB+1+i].r*sol[i].r  +a[nB+1+i].i*sol[i].i
		                +a[i+1].r   *sol[i+1].r-a[i+1].i   *sol[i+1].i;
		     buff[i+1].i=a[nB+1+i].r*sol[i].i  -a[nB+1+i].i*sol[i].r
		                +a[i+1].r   *sol[i+1].i+a[i+1].i   *sol[i+1].r;
#endif
#endif
		     i+=2;
		  }
	    } // end while
	    // multiply by |D|^{-1}
	    i=0;
	    a=PRE->absdiag;
	    // printf("4.\n");fflush(stdout);
	    while (i<nB) {
	          if (PRE->LU.ja[nB+1+i]==0) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		     sol[i]*=a[i];
#else
		     val     =sol[i].r*a[i].r-sol[i].i*a[i].i;
		     sol[i].i=sol[i].r*a[i].i+sol[i].i*a[i].r;
		     sol[i].r=val;
#endif
		     i++;
		  }
		  else {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		     val     =a[i]            *sol[i]+a[nB+1+i]*sol[i+1];
		     sol[i+1]=a[nB+1+i]       *sol[i]+a[i+1]   *sol[i+1];
		     sol[i]  =val;
#else
		     val       =a[i].r     *sol[i].r  -a[i].i     *sol[i].i
		               +a[nB+1+i].r*sol[i+1].r-a[nB+1+i].i*sol[i+1].i;
		     sol[i].i  =a[i].r     *sol[i].i  +a[i].i     *sol[i].r
		               +a[nB+1+i].r*sol[i+1].i+a[nB+1+i].i*sol[i+1].r;
#ifdef _COMPLEX_SYMMETRIC_		     
		     vali      =a[nB+1+i].r*sol[i].r  -a[nB+1+i].i*sol[i].i
		               +a[i+1].r   *sol[i+1].r-a[i+1].i   *sol[i+1].i;
		     sol[i+1].i=a[nB+1+i].r*sol[i].i  +a[nB+1+i].i*sol[i].r
		               +a[i+1].r   *sol[i+1].i+a[i+1].i   *sol[i+1].r;
#else
		     vali      =a[nB+1+i].r*sol[i].r  +a[nB+1+i].i*sol[i].i
		               +a[i+1].r   *sol[i+1].r-a[i+1].i   *sol[i+1].i;
		     sol[i+1].i=a[nB+1+i].r*sol[i].i  -a[nB+1+i].i*sol[i].r
		               +a[i+1].r   *sol[i+1].i+a[i+1].i   *sol[i+1].r;
#endif
		     sol[i+1].r=vali;
		     sol[i].r  =val;
#endif
		     i+=2;
		  }
	    } // end while
	    // printf("5.\n");fflush(stdout);
	    // solve system with [D^{-1}(D+U)]
	    nnzU=PRE->LU.ja[nB];
	    PRE->LU.ja[nB]=PRE->LU.nnz+1;
	    MYSYMPILUCUSOL(&nB, buff,buff, PRE->LU.a,PRE->LU.ja);
	    PRE->LU.ja[nB]=nnzU;
	    // printf("6.\n");fflush(stdout);
	    MYCSRMATTVEC(PRE->F,buff,sol+nB);
	    // printf("7.\n");fflush(stdout);
	    PRE->LU.ja[0]=-IABS(PRE->LU.ja[0]);
	    sol -=sumn;
	    buff-=sumn;
	 }
	 else
	    /* second block, multiply by E=F^* */
	    MYCSRMATTVEC(PRE->F,sol+sumn,sol+sumn+nB);

	 sumn+=nB;
	 
	 /* coarse grid projection */
	 for (i=sumn; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	     sol[i]=buff[i]-sol[i];
#else
	     sol[i].r=buff[i].r-sol[i].r;
	     sol[i].i=buff[i].i-sol[i].i;
#endif
	 } // end for i
      } // end if
      else { // U12 is kept and F is not accessed
	 i=n-sumn;
	 nnzU=PRE->LU.ja[nB];
	 PRE->LU.ja[nB]=PRE->LU.nnz+1;
	 MYPSYMPILUCLSOL(&i,&nB, buff+sumn,sol+sumn, PRE->LU.a,PRE->LU.ja);
	 PRE->LU.ja[nB]=nnzU;

	 sumn+=nB;
	 
	 /* coarse grid projection */
	 for (i=sumn; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	     sol[i]+=buff[i];
#else
	     sol[i].r+=buff[i].r;
	     sol[i].i+=buff[i].i;
#endif
	 } // end for i
      } // end else


      flag=-1;
      // if the last level uses direct solve, then no scaling is required
      if (lev==nlev-1) 
	 if (PRE->next->LU.ja==NULL) 
	    flag=0;

      if (flag) {
	 // conjugate-transpose of the right scaling
	 scal=PRE->next->colscal;
#ifdef PRINT_INFO	     
	 val=0;
#endif
	 for (i=sumn; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	     sol[i]*=scal[i-sumn];
#ifdef PRINT_INFO	     
	     val+=sol[i]*sol[i];
#endif
#else
	     val=sol[i].r;
	     sol[i].r=      val*scal[i-sumn].r
	              +sol[i].i*scal[i-sumn].i;
	     sol[i].i=-     val*scal[i-sumn].i
	              +sol[i].i*scal[i-sumn].r;
#endif
	 } // end for i
      }


      for (i=0; i<m; i++) {
  	  // sol = sol_old - AH *sol_new
	  if (i>0) {
	     MYSMATVEC(PRE->next->A,sol+sumn,buff+sumn);
#ifdef PRINT_INFO
	     val=0;
	     for (k=sumlev, j=sumn; j<n; j++,k++) 
		 val+=buff[n+nbf+k]*buff[n+nbf+k];
	     printf("level %d, step %d, res=%8.1le\n",lev,i-1,sqrt(val));fflush(stdout);
	     val=0;
#endif
	     for (k=sumlev, j=sumn; j<n; j++,k++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	         sol[j]=buff[n+nbf+k]-buff[j];
#ifdef PRINT_INFO	     
		 val+=sol[j]*sol[j];
#endif
#else
		 sol[j].r=buff[n+nbf+k].r-buff[j].r;
		 sol[j].i=buff[n+nbf+k].i-buff[j].i;
#endif
	     } // end for i
#ifdef PRINT_INFO	     
	     printf("level %d, step %d, res=%8.1le\n",lev,i,sqrt(val));fflush(stdout);
#endif
	  }
#ifdef PRINT_INFO	     
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	  else {
	     val=0;
	     for (k=sumlev, j=sumn; j<n; j++,k++) {
		 val+=sol[j]*sol[j];
	     } // end for i
	     printf("level %d, step %d, res=%8.1le\n",lev,i,sqrt(val));fflush(stdout);
	  }
#endif
#endif

	  // make a copy of the initial right hand side before coarsening
#ifdef PRINT_INFO	     
	  val=0;
#endif
	  for (k=sumlev, j=sumn; j<n; j++,k++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	      buff[n+nbf+k]=sol[j];
#ifdef PRINT_INFO	     
	      val+=buff[n+nbf+k]*buff[n+nbf+k];
#endif
#else
	      buff[n+nbf+k].r=sol[j].r;
	      buff[n+nbf+k].i=sol[j].i;
#endif
	  }
#ifdef PRINT_INFO	     
	  if (i==0) printf("level %d, step %d, res=%8.1le\n",lev,i,sqrt(val));fflush(stdout);
#endif
	  MYSYMAMGSOL1(PRE->next, lev+1,  n, nbf, sumn,  sumlev+n-sumn, 
		       IPparam, sol, buff);

#ifdef PRINT_INFO	     
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	  if ((lev<nlev-1 || (lev==nlev-1 && PRE->next->LU.ja!=NULL)) && i==m-1) 
          {
	     MYSMATVEC(PRE->next->A,sol+sumn,buff+sumn);     
	     val=0;
	     for (k=sumlev, j=sumn; j<n; j++,k++) {
	         buff[j]=buff[n+nbf+k]-buff[j];
		 val+=buff[j]*buff[j];
	     } // end for i
	     printf("Level %d, step %d, res=%8.1le\n",lev,i+1,sqrt(val));fflush(stdout);
	  }
#endif
#endif


	  if (i>0) {
	     for (k=sumlev, j=sumn; j<n; j++,k++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	         buff[n+k]+=sol[j];
#else
		 buff[n+k].r+=sol[j].r;
		 buff[n+k].i+=sol[j].i;
#endif
	     }
	  }
	  else {
	     for (k=sumlev,j=sumn; j<n; j++,k++) {
	         buff[n+k]=sol[j];
	     }
	  }
      } // end for i


      // move approximate solutions to buff
      for (k=sumlev,i=sumn; i<n; i++,k++) 
	  buff[i]=buff[n+k];


      if (flag) {
	 // diagonal scaling from the right
	 scal=PRE->next->colscal;
	 for (i=sumn; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	     buff[i]*=scal[i-sumn];
#ifdef PRINT_INFO	     
	     val+=buff[i]*buff[i];
#endif
#else
	     val=buff[i].r;
	     buff[i].r=     val*scal[i-sumn].r
	             -buff[i].i*scal[i-sumn].i;
	     buff[i].i=     val*scal[i-sumn].i
	             +buff[i].i*scal[i-sumn].r;
#endif
	 } // end for i
      }





      if (param&COARSE_REDUCE) {
	 /* second block */
	 MYCSRMATVEC(PRE->F,buff+sumn,buff+sumn-nB);

	 /* first block */
	 sumn-=nB;
	 if (PRE->LU.ja[0]<0)
	    flagspd=-1;
	 else
	    flagspd=0;
	 PRE->LU.ja[0]=IABS(PRE->LU.ja[0]);
	 nnzU=PRE->LU.ja[nB];
	 PRE->LU.ja[nB]=PRE->LU.nnz+1;
	 if (flagspd) {
	    buff+=sumn;
	    // printf("12.\n");fflush(stdout);
	    MYSYMPILUCLSOL(&nB, buff,buff, PRE->LU.a,PRE->LU.ja);
	    // printf("13.\n");fflush(stdout);
	    i=0;
	    a=PRE->LU.a;
	    while (i<nB) {
	          if (PRE->LU.ja[nB+1+i]==0) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		     buff[i]*=a[i];
#else
		     val      =buff[i].r*a[i].r-buff[i].i*a[i].i;
		     buff[i].i=buff[i].r*a[i].i+buff[i].i*a[i].r;
		     buff[i].r=val;
#endif
		     i++;
		  }
		  else {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		     val      =a[i]            *buff[i]+a[nB+1+i]*buff[i+1];
		     buff[i+1]=a[nB+1+i]       *buff[i]+a[i+1]   *buff[i+1];
		     buff[i]  =val;
#else
		     val        =a[i].r     *buff[i].r  -a[i].i     *buff[i].i
		                +a[nB+1+i].r*buff[i+1].r-a[nB+1+i].i*buff[i+1].i;
		     buff[i].i  =a[i].r     *buff[i].i  +a[i].i     *buff[i].r
		                +a[nB+1+i].r*buff[i+1].i+a[nB+1+i].i*buff[i+1].r;
#ifdef _COMPLEX_SYMMETRIC_		     
		     vali       =a[nB+1+i].r*buff[i].r  -a[nB+1+i].i*buff[i].i
		                +a[i+1].r   *buff[i+1].r-a[i+1].i   *buff[i+1].i;
		     buff[i+1].i=a[nB+1+i].r*buff[i].i  +a[nB+1+i].i*buff[i].r
		                +a[i+1].r   *buff[i+1].i+a[i+1].i   *buff[i+1].r;
#else
		     vali       =a[nB+1+i].r*buff[i].r  +a[nB+1+i].i*buff[i].i
		                +a[i+1].r   *buff[i+1].r-a[i+1].i   *buff[i+1].i;
		     buff[i+1].i=a[nB+1+i].r*buff[i].i  -a[nB+1+i].i*buff[i].r
		                +a[i+1].r   *buff[i+1].i+a[i+1].i   *buff[i+1].r;
#endif
		     buff[i].r  =val;
		     buff[i+1].r=vali;
#endif
		     i+=2;
		  }
	    } // end while
	    // printf("14.\n");fflush(stdout);
	    buff-=sumn;
	 }
	 else
	    MYSYMPILUCSOL(&nB, buff+sumn,buff+sumn, PRE->LU.a,PRE->LU.ja);
	 PRE->LU.ja[nB]=nnzU;

	 /* update solution */ 
	 buff+=sumn;
	 sol+=sumn;
	 for (i=0; i<nB; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	     buff[i]=sol[i]-buff[i];
#else
	     buff[i].r=sol[i].r-buff[i].r;
	     buff[i].i=sol[i].i-buff[i].i;
#endif
	 } // end for i
	 if (flagspd) {
	    // printf("15.\n");fflush(stdout);
	    nnzU=PRE->LU.ja[nB];
	    PRE->LU.ja[nB]=PRE->LU.nnz+1;
	    MYSYMPILUCUSOL(&nB, buff,buff, PRE->LU.a,PRE->LU.ja);
	    PRE->LU.ja[nB]=nnzU;
	    // printf("16.\n");fflush(stdout);
	    PRE->LU.ja[0]=-IABS(PRE->LU.ja[0]);
	 }
	 sol-=sumn;
	 buff-=sumn;
	 
	 /* reorder the whole system */
	 buff+=sumn-1;
	 invq-=sumn;
	 for (i=sumn; i<n; i++)
	     sol[i]=buff[invq[i]];
	 invq+=sumn;
	 buff-=sumn-1;
      }
      else { // U12 is kept and F is not referenced
         /* copy r.h.s */
	 sumn-=nB;
	 buff+=sumn;
	 sol +=sumn;
	 for (i=0; i<nB; i++)
	     buff[i]=sol[i];
	 buff-=sumn;
	 sol -=sumn;

	 // block diagonal scaling using D^{-1}
	 i=0;
	 buff+=sumn;
	 a=PRE->LU.a;
	 while (i<nB) {
	       if (PRE->LU.ja[nB+1+i]==0) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		  buff[i]*=a[i];
#else
		  val      =buff[i].r*a[i].r-buff[i].i*a[i].i;
		  buff[i].i=buff[i].r*a[i].i+buff[i].i*a[i].r;
		  buff[i].r=val;
#endif
		  i++;
	       }
	       else {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		  val      =a[i]            *buff[i]+a[nB+1+i]*buff[i+1];
		  buff[i+1]=a[nB+1+i]       *buff[i]+a[i+1]   *buff[i+1];
		  buff[i]  =val;
#else
		  val        =a[i].r     *buff[i].r  -a[i].i     *buff[i].i
		             +a[nB+1+i].r*buff[i+1].r-a[nB+1+i].i*buff[i+1].i;
		  buff[i].i  =a[i].r     *buff[i].i  +a[i].i     *buff[i].r
		             +a[nB+1+i].r*buff[i+1].i+a[nB+1+i].i*buff[i+1].r;
#ifdef _COMPLEX_SYMMETRIC_		     
		  vali       =a[nB+1+i].r*buff[i].r  -a[nB+1+i].i*buff[i].i
		             +a[i+1].r   *buff[i+1].r-a[i+1].i   *buff[i+1].i;
		  buff[i+1].i=a[nB+1+i].r*buff[i].i  +a[nB+1+i].i*buff[i].r
		             +a[i+1].r   *buff[i+1].i+a[i+1].i   *buff[i+1].r;
#else
		  vali       =a[nB+1+i].r*buff[i].r  +a[nB+1+i].i*buff[i].i
		             +a[i+1].r   *buff[i+1].r-a[i+1].i   *buff[i+1].i;
		  buff[i+1].i=a[nB+1+i].r*buff[i].i  -a[nB+1+i].i*buff[i].r
		             +a[i+1].r   *buff[i+1].i+a[i+1].i   *buff[i+1].r;
#endif
		  buff[i].r  =val;
		  buff[i+1].r=vali;
#endif
		  i+=2;
	       }
	 } // end while
	 buff-=sumn;
	 
	 i=n-sumn;
	 nnzU=PRE->LU.ja[nB];
	 PRE->LU.ja[nB]=PRE->LU.nnz+1;
	 MYPSYMPILUCUSOL(&i,&nB, buff+sumn,buff+sumn, PRE->LU.a,PRE->LU.ja);
	 PRE->LU.ja[nB]=nnzU;
	 
	 /* reorder the whole system */
	 buff+=sumn-1;
	 invq-=sumn;
	 for (i=sumn; i<n; i++)
	     sol[i]=buff[invq[i]];
	 invq+=sumn;
	 buff-=sumn-1;
      } // end else

   } /* end if */
   else { // lev==nlev
     
      /* last level */

      /* did we finally switch to full matrix processing? */
      if (lev>1 && PRE->LU.ja==NULL) {
	 for (i=sumn; i<n; i++)
	     buff[i]=sol[i];
 	 i=1;
	 MYSPTRS("L", &nB, &i, PRE->LU.a,PRE->LU.ia,
		 sol+sumn, &nB, &ierr,1);     
      }
      else {
	 /* reorder the whole system */
	 p-=sumn;
	 for (i=sumn; i<n; i++)
	     buff[i]=sol[sumn+p[i]-1];
	 p+=sumn;
     
	 if (PRE->LU.ja[0]<0)
	    flagspd=-1;
	 else
	    flagspd=0;
	 PRE->LU.ja[0]=IABS(PRE->LU.ja[0]);
	 nnzU=PRE->LU.ja[nB];
	 PRE->LU.ja[nB]=PRE->LU.nnz+1;
	 if (flagspd) {
	    buff+=sumn;
	    sol+=sumn;
	    // printf("8.\n");fflush(stdout);
	    MYSYMPILUCLSOL(&nB, buff,sol, PRE->LU.a,PRE->LU.ja); 
	    i=0;
	    a=PRE->absdiag;
	    // printf("9.\n");fflush(stdout);
	    while (i<nB) {
	          // printf("%3d\n",i);fflush(stdout);
	          if (PRE->LU.ja[nB+1+i]==0) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		     // printf("%12.4le\n",sol[i]);fflush(stdout);
		     // printf("%12.4le\n",a[i]);fflush(stdout);
		     sol[i]*=a[i];
#else
		     val     =sol[i].r*a[i].r-sol[i].i*a[i].i;
		     sol[i].i=sol[i].r*a[i].i+sol[i].i*a[i].r;
		     sol[i].r=val;
#endif
		     i++;
		  }
		  else {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		     val     =a[i]            *sol[i]+a[nB+1+i]*sol[i+1];
		     sol[i+1]=a[nB+1+i]       *sol[i]+a[i+1]   *sol[i+1];
		     sol[i]  =val;
#else
		     val       =a[i].r     *sol[i].r  -a[i].i     *sol[i].i
		               +a[nB+1+i].r*sol[i+1].r-a[nB+1+i].i*sol[i+1].i;
		     sol[i].i  =a[i].r     *sol[i].i  +a[i].i     *sol[i].r
		               +a[nB+1+i].r*sol[i+1].i+a[nB+1+i].i*sol[i+1].r;
#ifdef _COMPLEX_SYMMETRIC_		     
		     vali      =a[nB+1+i].r*sol[i].r  -a[nB+1+i].i*sol[i].i
		               +a[i+1].r   *sol[i+1].r-a[i+1].i   *sol[i+1].i;
		     sol[i+1].i=a[nB+1+i].r*sol[i].i  +a[nB+1+i].i*sol[i].r
		               +a[i+1].r   *sol[i+1].i+a[i+1].i   *sol[i+1].r;
#else
		     vali      =a[nB+1+i].r*sol[i].r  +a[nB+1+i].i*sol[i].i
		               +a[i+1].r   *sol[i+1].r-a[i+1].i   *sol[i+1].i;
		     sol[i+1].i=a[nB+1+i].r*sol[i].i  -a[nB+1+i].i*sol[i].r
		               +a[i+1].r   *sol[i+1].i+a[i+1].i   *sol[i+1].r;
#endif
		     sol[i+1].r=vali;
		     sol[i].r  =val;
#endif
		     i+=2;
		  }
	    } // end while
	    // printf("10.\n");fflush(stdout);
	    MYSYMPILUCUSOL(&nB, sol,sol, PRE->LU.a,PRE->LU.ja); 
	    // printf("11.\n");fflush(stdout);
	    buff-=sumn;
	    sol-=sumn;
	 }
	 else
	    MYSYMPILUCSOL(&nB, buff+sumn,sol+sumn, PRE->LU.a,PRE->LU.ja); 
	 PRE->LU.ja[nB]=nnzU;
	 if (flagspd)
	    PRE->LU.ja[0]=-IABS(PRE->LU.ja[0]);


	 for (i=sumn; i<n; i++)
	     buff[i]=sol[i];

	 /* reorder the whole system back */
	 buff+=sumn-1;
	 invq-=sumn;
	 for (i=sumn; i<n; i++) 
	     sol[i]=buff[invq[i]];
	 invq+=sumn;
	 buff-=sumn-1;
      } /* end if-else (PRE->LU.ja==NULL) */
   } /* end if-else */
} /* end symAMGsol1 */


