#include <stdlib.h>
#include <stdio.h>
#include <blas.h>
#include <lapack.h>

#include <ilupack.h>

#include <ilupackmacros.h>

#define MAX_LINE        255
#define STDERR          stderr
#define STDOUT          stdout
//#define PRINT_INFO
#define MAX(A,B)        (((A)>(B))?(A):(B))
#define MIN(A,B)        (((A)<(B))?(A):(B))






/*
   Given a multilevel ILU decomposition performed by spdAMGsetup, AMGsol 
   performs a simple forward backward substitution
*/ 
void SPDAMGSOL(AMGLEVELMAT *PRE, ILUPACKPARAM *IPparam,
	       FLOAT *rhs, FLOAT *sol, FLOAT *buff)

{

/*
   PRE       linked list of multilevel ILU preconditioners
   nlev      number of levels (blocks)
   rhs       given right hand side
   sol       solution obtained by AMGsol
   buff      work array of length 2n, where n is the size of the original 
             matrix
  
   Code written by Matthias Bollhoefer, November 2003, January, March 2006
*/

   AMGLEVELMAT *next, *prev;

   integer i, j, n=PRE->n, nB, *p, *invq, sumn=0, lev, param, buffldl, ierr,nbf,
     PILUCparam, nlev=PRE->nlev;  

   FLOAT *scal;
   REALS val;
   static int info_message=1;

#ifdef PRINT_INFO
   static int check=1;

   if (check) {
#ifdef _SINGLE_REAL_ 
     printf("SSPD solve\n");
#else
#ifdef _DOUBLE_REAL_
     printf("DSPD solve\n");
#else
#ifdef _SINGLE_COMPLEX_
     printf("CHPD solve\n");
#else
     printf("ZHPD solve\n");
#endif
#endif
#endif
   }
#endif

   // buffer to store 'true' ipar[6] from the time of the factorization
   PILUCparam=IPparam->ipar[16];
   if (IPparam->ipar[10]!=0 && !(PILUCparam&DISCARD_MATRIX)) {
      sumn=0;
      next=PRE;
      nbf=0;
      if (IPparam->ipar[10]==2) 
	 nbf=n;
      for (i=1; i<=nlev; i++) {
	  sumn+=next->nB;
	  nbf+=n-sumn;
	  next=next->next;
      } // end for i

      for (i=0; i<n; i++)
	  sol[i]=rhs[i];
      if (IPparam->ipar[10]==1) {
#ifdef PRINT_INFO
	 if (check)
	    printf("AMLI-like solve\n");
#endif
	 SPDAMGSOL1(PRE, 1, n, nbf, 0,0, IPparam, sol, buff);
      }
      else if (IPparam->ipar[10]==2) {
#ifdef PRINT_INFO
	 if (check)
	    printf("classical multigrid-like solve\n");
#endif
 	 SPDAMGSOL2(PRE, 1, n, nbf, 0,0, IPparam, sol, buff);
      }
#ifdef PRINT_INFO
      check=0;
#endif
      return ;
   }
   else if (IPparam->ipar[10]!=0 && info_message) {
      printf("ILUPACK WARNING!\n");
      printf("AMLI-like AMG or classical multigrid need to selected prior to\n");
      printf("factorization in order to maintain coarse grid systems.\n");
      printf("Will use multilevel ILU instead.\n");
      info_message=0;
   }

#ifdef PRINT_INFO
   check=0;
#endif

   param=IPparam->ipar[6];
   buff+=n;
   for (i=0; i<n; i++)
       buff[i]=rhs[i];
   buff-=n;

   /* block forward substitution */
   next=PRE;
   prev=NULL;
   lev=1;
   while (lev<nlev) {
	 nB=next->nB;
	 p=next->p;

	 if (lev>1) {
	    scal=next->colscal-sumn;
	    buff+=n;
	    for (i=sumn; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	        buff[i]*=scal[i];
#else
		val=buff[i].r;
	        buff[i].r= val*scal[i].r+buff[i].i*scal[i].i;
	        buff[i].i=-val*scal[i].i+buff[i].i*scal[i].r;
#endif
	    }
	    buff-=n;
	 } /* end if */

	 /* reorder the whole system */
	 p-=sumn;
	 for (i=sumn; i<n; i++)
	     buff[i]=buff[n+sumn+p[i]-1];
	 p+=sumn;
	 
	 /* first block */
	 if (param&COARSE_REDUCE) {
	    buffldl=next->LU.ja[nB];
	    next->LU.ja[nB]=next->LU.nnz+1;
	    ILDLCSOL(&nB, buff+sumn,buff+n+sumn, next->LU.a,next->LU.ja);
	    next->LU.ja[nB]=buffldl;

	    /* second block, multiply by F^H */
	    CSRMATHVEC(next->F,buff+n+sumn,sol+sumn+nB);

	    sumn+=nB;

	    /* coarse grid projection */
	    for (i=sumn; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	        buff[n+i]=buff[i]-sol[i];
#else
		buff[n+i].r=buff[i].r-sol[i].r;
		buff[n+i].i=buff[i].i-sol[i].i;
#endif
	    } // end for i
	 }
	 else { // !(param&COARSE_REDUCE)
	    i=n-sumn;
	    buffldl=next->LU.ja[nB];
	    next->LU.ja[nB]=next->LU.nnz+1;
	    PILDLCLSOL(&i, &nB, buff+sumn,buff+n+sumn, next->LU.a,next->LU.ja);
	    next->LU.ja[nB]=buffldl;

	    sumn+=nB;

	    /* coarse grid projection */
	    for (i=sumn; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	        buff[n+i]=buff[i]+buff[n+i];
#else
		buff[n+i].r=buff[i].r+buff[n+i].r;
		buff[n+i].i=buff[i].i+buff[n+i].i;
#endif
	    } // end for i
	 } // end else (param&COARSE_REDUCE)

	 prev=next;
	 next=next->next;
	 lev++;
   } // end while


   // last level
   nB=next->nB;
   p=next->p;
   invq=next->invq;

   /* -----   last block   ----- */

   /* did we finally switch to full matrix processing? */
   if (lev>1 && next->LU.ja==NULL) {
     
      // LDLP requires an integer buffer of size nB
#ifdef USE_LAPACK_DRIVER
      i=1;
      COPY(&nB, buff+n+sumn,&i, sol+sumn,&i);
      PPTRS("L", &nB, &i, next->LU.a,sol+sumn, &nB, &ierr,1); 
#else
      LDLPSOL(&nB, next->LU.a,next->LU.ia, buff+n+sumn,sol+sumn, (integer *)buff); 
#endif
   }
   else {
      if (lev>1) {
	 scal=next->colscal-sumn;
	 buff+=n;
	 for (i=sumn; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	   buff[i]*=scal[i];
#else
	   val=buff[i].r;
	   buff[i].r= val*scal[i].r+buff[i].i*scal[i].i;
	   buff[i].i=-val*scal[i].i+buff[i].i*scal[i].r;
#endif
	 } // end for i
	 buff-=n;
      } /* end if */

      /* reorder the whole system */
      p-=sumn;
      for (i=sumn; i<n; i++)
	  buff[i]=buff[n+sumn+p[i]-1];
      p+=sumn;
     
      buffldl=next->LU.ja[nB];
      next->LU.ja[nB]=next->LU.nnz+1;
      ILDLCSOL(&nB, buff+sumn,buff+n+sumn, next->LU.a,next->LU.ja); 
      next->LU.ja[nB]=buffldl;
      
      /* reorder the whole system back */
      buff+=n+sumn-1;
      invq-=sumn;
      for (i=sumn; i<n; i++) 
	sol[i]=buff[invq[i]];
      invq+=sumn;
      buff-=n+sumn-1;
	
      if (lev>1) {
	 scal=next->colscal-sumn;
	 for (i=sumn; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	     sol[i]*=scal[i];
#else
	     val=sol[i].r;
	     sol[i].r=val*scal[i].r-sol[i].i*scal[i].i;
	     sol[i].i=val*scal[i].i+sol[i].i*scal[i].r;
#endif
	 } // end for i
      } /* end if */
      
   } // end if-else (next->LU.ja==NULL)



   /* block backward substitution */
   lev=nlev-1;
   while (lev>0) {
	 nB=prev->nB;
	 invq=prev->invq;
	 
	 if (param&COARSE_REDUCE) {
	    /* copy r.h.s */
	    for (i=sumn; i<n; i++)
	        buff[i]=sol[i];

	    /* second block */
	    CSRMATVEC(prev->F,sol+sumn,buff+sumn-nB);

	    /* first block */
	    sumn-=nB;
	    buffldl=prev->LU.ja[nB];
	    prev->LU.ja[nB]=prev->LU.nnz+1;
	    ILDLCSOL(&nB, buff+sumn,sol+sumn, prev->LU.a,prev->LU.ja);
	    prev->LU.ja[nB]=buffldl;

	    /* update solution */ 
	    buff+=sumn;
	    sol+=sumn;
	    for (i=0; i<nB; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	        buff[i]=buff[n+i]-sol[i];
#else
		buff[i].r=buff[n+i].r-sol[i].r;
		buff[i].i=buff[n+i].i-sol[i].i;
#endif
	    } // end for i

	    sol-=sumn;
	    buff-=sumn;

	    /* reorder the whole system */
	    buff+=sumn-1;
	    invq-=sumn;
	    for (i=sumn; i<n; i++)
	        sol[i]=buff[invq[i]];
	    invq+=sumn;
	    buff-=sumn-1;
	 }
	 else { // !(param&COARSE_REDUCE)
	    /* copy r.h.s */
	    // this is NECESSARY to make PILDLCDUSOL correctly work
	    buff+=n;
	    for (i=sumn; i<n; i++)
	        buff[i]=sol[i];
	    buff-=n;

	    sumn-=nB;

	    i=n-sumn;
	    buffldl=prev->LU.ja[nB];
	    prev->LU.ja[nB]=prev->LU.nnz+1;
	    PILDLCDUSOL(&i,&nB, buff+n+sumn,buff+n+sumn, prev->LU.a,prev->LU.ja);
	    prev->LU.ja[nB]=buffldl;

	    /* reorder the whole system */
	    buff+=n+sumn-1;
	    invq-=sumn;
	    for (i=sumn; i<n; i++)
	        sol[i]=buff[invq[i]];
	    invq+=sumn;
	    buff-=n+sumn-1;
	 } // end else


	 if (lev>1) {
	    scal=prev->colscal-sumn;
	    for (i=sumn; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	        sol[i]*=scal[i];
#else
		val=sol[i].r;
		sol[i].r=val*scal[i].r-sol[i].i*scal[i].i;
		sol[i].i=val*scal[i].i+sol[i].i*scal[i].r;
#endif
	    } // end for i
	 } /* end if */
	 
	 next=prev;
	 prev=prev->prev;
	 lev--;
   } // end while

} /* end spdAMGsol */


