#include <ilupack.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

#include <ilupackmacros.h>

#define MAX_LINE        255
#define STDERR          stderr
#define STDOUT          stdout
#define MAX(A,B)        (((A)>(B))?(A):(B))
#define MIN(A,B)        (((A)<(B))?(A):(B))







/* Given an nxn matrix A, extract from
           / B  F \
   P^TAQ = |      |
           \ E  C /
   the matrices E and F, where B is of size nBxnB
*/
void AMGEXTRACT(CSRMAT *E,CSRMAT *F, CSRMAT A, integer *p,integer *invq,  integer nB)
{
/*
   A        given matrix
   p,q      permutation vectors associated with the permutation matrices P
            and Q
   nB       size of B
   E,F      on output, matrices E and F are extracted from P^TAQ

   written by Matthias Bollhoefer, May 2003
*/

   integer i,ii,j,jj,cnt, n, *ia, *ja;
   FLOAT *a;

   n=A.nr;
   ia=A.ia;
   ja=A.ja;
   a=A.a;
   
   /* Block F */
   /* 1. pass, detect  length of any row and total number of nonzeros */
   F->nr=nB;
   F->nc=n-nB;
   F->ia=(integer *)MALLOC((size_t)(nB+1)*sizeof(integer),"AMGextract:F->ia");
   F->ia[0]=1;
   for (ii=0; ii<nB; ii++) {
       /* extract row p[i] */
       i=p[ii]-1;
       cnt=0;
       for (jj=ia[i]-1; jj<ia[i+1]-1;jj++) {
	   j=ja[jj]-1;
	   if (invq[j]>nB) cnt++;
       } /* end for */
       F->ia[ii+1]=F->ia[ii]+cnt;
   } /* end for */
   /* number of nonzeros */
   cnt=F->ia[nB]-1;
   F->ja=(integer *)  MALLOC((size_t)cnt*sizeof(integer),  "AMGextract:F->ja");
   F->a =(FLOAT *)MALLOC((size_t)cnt*sizeof(FLOAT),"AMGextract:F->a");
   /* 2. pass, extract values and indices */
   cnt=0;
   for (ii=0; ii<nB; ii++) {
       /* extract row p[i] */
       i=p[ii]-1;
       for (jj=ia[i]-1; jj<ia[i+1]-1;jj++) {
	   j=ja[jj]-1;
	   if (invq[j]>nB) {
	      F->ja[cnt]=invq[j]-nB;
	      F->a[cnt]=a[jj];
	      cnt++;
	   }
       } /* end for */
   } /* end for */


   /* Block E */
   /* 1. pass, detect  length of any row and total number of nonzeros */
   E->nr=n-nB;
   E->nc=nB;
   E->ia=(integer *)MALLOC((size_t)(n-nB+1)*sizeof(integer),"AMGextract:E->ia");
   E->ia[0]=1;
   for (ii=nB; ii<n; ii++) {
       /* extract row p[i] */
       i=p[ii]-1;
       cnt=0;
       for (jj=ia[i]-1; jj<ia[i+1]-1;jj++) {
	   j=ja[jj]-1;
	   if (invq[j]<=nB) cnt++;
       } /* end for */
       E->ia[ii-nB+1]=E->ia[ii-nB]+cnt;
   } /* end for */
   /* number of nonzeros */
   cnt=E->ia[n-nB]-1;
   E->ja=(integer *)  MALLOC((size_t)cnt*sizeof(integer),  "AMGextract:E->ja");
   E->a =(FLOAT *)MALLOC((size_t)cnt*sizeof(FLOAT),"AMGextract:E->a");

   /* 2. pass, extract values and indices */
   cnt=0;
   for (ii=nB; ii<n; ii++) {
       /* extract row p[i] */
       i=p[ii]-1;
       for (jj=ia[i]-1; jj<ia[i+1]-1;jj++) {
	   j=ja[jj]-1;
	   if (invq[j]<=nB) {
	      E->ja[cnt]=invq[j];
	      E->a[cnt]=a[jj];
	      cnt++;
	   }
       } /* end for */
   } /* end for */

} /* end AMGextract */


