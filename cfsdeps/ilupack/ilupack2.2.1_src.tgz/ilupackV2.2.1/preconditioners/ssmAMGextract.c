#define _SKEW_MATRIX_
#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
#define _COMPLEX_SYMMETRIC_
#endif
#include "symAMGextract.c"
