#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
#define _COMPLEX_SYMMETRIC_
#include "GNLSYM.c"
#else
void myilupackdummy406()
{
}
#endif


