#include <stdio.h>
#include <ilupack.h>

#include <ilupackmacros.h>


void CPERM(CSRMAT *A, integer *invperm)
/*
  Interchange columns of A according to the permutation vector invperm
  1,...,n -> invperm(1),...,invperm(n)
  This leads to A_new = A(:,perm)

  code taken from ARMS of Yousef Saad.
  adapted by Matthias Bollhoefer to fit with the data structures
  of ILUPACK including the complex case
*/
{
   integer i, *p, nz;

   nz=A->ia[A->nr]-1;

   p=A->ja;
   invperm--;
   for (i=0; i<nz; i++,p++)
       *p=invperm[*p];
} // end CPERM
