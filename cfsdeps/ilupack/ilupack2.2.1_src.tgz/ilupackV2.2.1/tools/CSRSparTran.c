#include <ilupack.h>
#include <stdlib.h>
#include <malloc.h>
#include <stdio.h>

#include <ilupackmacros.h>





integer SPARTRAN(CSRMAT A, CSRMAT *B, integer job, integer flag)
{
/*----------------------------------------------------------------------
| Finds the transpose of a matrix stored in CSR format.
|
|-----------------------------------------------------------------------
| on entry:
|----------
| (A) = a matrix stored in CSR format.
|
| job    = integer to indicate whether to fill the values (job.eq.1)
|          of the matrix (B) or only the pattern.
|
| flag   = integer to indicate whether the target matrix has been filled
|          previously
|          0 - no filled
|          1 - filled
|
| ind    = integer buff of size at least nc
| on return:
| ----------
| (B) = the transpose of (A) stored in CSR format.
|
| integer value returned:
|             0   --> successful return.
|             1   --> memory allocation error.
|
|     code taken from ARMS of Yousef Saad.
|     adapted by Matthias Bollhoefer to fit with the data structures
|     of ILUPACK including the complex case
|---------------------------------------------------------------------*/
  integer i, j, k, n, nnz, *ind;

  n=A.nc;
  if (!flag) {
    B->nr=A.nc;
    B->nc=A.nr;
  }
  nnz=A.ia[A.nr]-1;

  /* compute the length of each column of A */
  if (!flag) {
     B->ia=(integer *)MALLOC((size_t)(n+1)*sizeof(integer),"CSRSparTran:B->ia");
     B->ja=(integer *)MALLOC((size_t)nnz  *sizeof(integer),"CSRSparTran:B->ja");
     if (job==1) 
        B->a=(FLOAT *)MALLOC((size_t)nnz*sizeof(FLOAT),"CSRSparTran:B->a");
     else
        B->a=NULL;
     
     // counter for the number of nonzeros for every row of B
     ind=B->ia;
     for (i=0; i<=n; i++)
         ind[i] = 0;

     // run through A in order to find the nnz for each column of A
     // do not adjust ind to fit with FORTRAN indexing!
     for (j=0; j<nnz; j++) 
         ind[A.ja[j]]++;
     // change ind such that ind[i] holds the start of column i
     // ind[0] has not been used due to different indexing in FORTRAN
     ind[0]=1;
     for (i=0; i<n; i++) 
         ind[i+1]+=ind[i];
  } // end if
  else
     ind=B->ia;


  /*--------------------  now do the actual copying  */
  for (i=0; i<n; i++) {
    // copy indices
    for (j=A.ia[i]; j<A.ia[i+1]; j++) {
        // current column index of row i in FORTRAN style
        k=A.ja[j-1]-1;
	B->ja[ind[k]-1]=i+1;
	if (job==1)
	   B->a[ind[k]-1]=A.a[j-1];
	// advance pointer
	ind[k]++;
    } // end for j
  } // end for i

  // shift ind back
  for (i=n; i>0; i--) 
      ind[i]=ind[i-1];
  ind[0]=1;


  return 0;
}
/*-------------- end of CSRSparTran ---------------------------------------
|---------------------------------------------------------------------*/



