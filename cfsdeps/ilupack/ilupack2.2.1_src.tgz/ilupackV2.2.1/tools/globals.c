#define _DECLARE_ILUPACK_GLOBALS_
#include <ilupack.h>

void ilupack_dummy_000()
{
}
