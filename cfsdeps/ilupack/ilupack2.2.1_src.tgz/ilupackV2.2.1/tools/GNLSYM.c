#include <stdio.h>
#include <ilupack.h>

#include <ilupackmacros.h>

#define STDERR   stderr
#define STDOUT   stdout
#define IABS(A)         (((A)>=0)?(A):(-(A)))
#define MAX(A,B)        (((A)>=(B))?(A):(B))


#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
#define CONJG(A)      (A)

#ifdef _SKEW_MATRIX_

#ifdef _DOUBLE_REAL_
#define GNLSYM       DGNLSSM
#else
#define GNLSYM       SGNLSSM
#endif

#define SKEW(A)      (-(A))

#else

#ifdef _DOUBLE_REAL_
#define GNLSYM       DGNLSYM
#else
#define GNLSYM       SGNLSYM
#endif

#define SKEW(A)      (A)
#endif
// end _SKEW_MATRIX_


#else

#ifdef _COMPLEX_SYMMETRIC_
#define CONJG(A)     (A)

#ifdef _SKEW_MATRIX_
#define SKEW(A)      (-(A))

#ifdef _SINGLE_COMPLEX_
#define GNLSYM       CGNLSSM
#else
#define GNLSYM       ZGNLSSM
#endif

#else
#define SKEW(A)      (A)

#ifdef _SINGLE_COMPLEX_
#define GNLSYM       CGNLSYM
#else
#define GNLSYM       ZGNLSYM
#endif

#endif
// end _SKEW_MATRIX_


#else
#define CONJG(A)     (-(A))

#ifdef _SKEW_MATRIX_
#define SKEW(A)      (-(A))

#ifdef _SINGLE_COMPLEX_
#define GNLSYM       CGNLSHR
#else
#define GNLSYM       ZGNLSHR
#endif

#else
#define SKEW(A)      (A)

#ifdef _SINGLE_COMPLEX_
#define GNLSYM       CGNLHER
#else
#define GNLSYM       ZGNLHER
#endif

#endif
// end _SKEW_MATRIX_

#endif
// end _COMPLEX_SYMMETRIC_

#endif
// end _DOUBLE_REAL_





void GNLSYM(CSRMAT A, CSRMAT *AS, integer *ibuff)
{
/*---------------------------------------------------------------------
|
| This routine compute AS=(A+A^T)/2
|
|----------------------------------------------------------------------
| on entry:
| A  = general unsymmetric matrix (in SparRow form)
| ibuff = buffer of size A.nr
|
| on return
| AS   = (A+A^T)/2 or (A+A^H)/2
|--------------------------------------------------------------------*/
/*   local variables    */
  
   integer *ia, *ja, n,nnz, i,j,k, shift,oldshift;
   FLOAT *a, val;

   n=A.nr;
   nnz=A.ia[n]-1;
   AS->nr=AS->nc=n;
   AS->ia=(integer *)  MALLOC((size_t)(n+1)*sizeof(integer),"GNLSYM:AS->ia");
   ia=AS->ia;
   AS->ja=(integer *)  MALLOC((size_t)nnz*sizeof(integer),  "GNLSYM:AS->ja");
   ja=AS->ja;
   AS->a =(FLOAT *)MALLOC((size_t)nnz*sizeof(FLOAT),"GNLSYM:AS->ja");
   a=AS->a;
  
   // counter for the number of nonzeros for every row of B
   for (i=0; i<=A.nr; i++)
       ia[i]=0;


   // run through A in order to find the nnz for each column of the
   // strict lower triangular part of A
   // also increment by the number of nonzeros in every row of the 
   // upper triangular part of A
   // do not adjust ia to fit with FORTRAN indexing!
   for (i=0; i<n; i++) 
       for (j=A.ia[i]; j<A.ia[i+1]; j++) {
	   // current column index k of row i in FORTRAN style
	   k=A.ja[j-1];
	   // strict lower triangular part?
	   if (k<i+1)
	      ia[k]++;
	   else // upper triangular part
	      ia[i+1]++;
       } // end for j

   
   // change ia such that ia[i] holds the start of column i
   // ia[0] has not been used due to different indexing in FORTRAN
   ia[0]=1;
   for (i=0; i<n; i++) 
       ia[i+1]+=ia[i];

   /*--------------------  now do the actual copying  */
   for (i=0; i<n; i++) {
       // copy indices
       for (j=A.ia[i]; j<A.ia[i+1]; j++) {
	   // current column index of row i in C style
	   k=A.ja[j-1]-1;
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	   val=A.a[j-1]/2;
#else
	   val.r=A.a[j-1].r/2;
	   val.i=A.a[j-1].i/2;
#endif
	   // contribution from strict lower triangular part?
	   if (k<i) {
	      ja[ia[k]-1]=i+1;
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	      a [ia[k]-1]=SKEW(val);
#else
	      // use conjugate transpose
	      a [ia[k]-1].r=SKEW(      val.r);
	      a [ia[k]-1].i=SKEW(CONJG(val.i));
#endif
	      // advance pointer
	      ia[k]++;
	   }
	   else {
	      ja[ia[i]-1]=k+1;
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	      if (k==i)
		 val+=SKEW(val);
	      a [ia[i]-1]=val;
#else
	      if (k==i) {
		val.r+=SKEW(      val.r);
		val.i+=SKEW(CONJG(val.i));
	      }
	      a [ia[i]-1].r=val.r;
	      a [ia[i]-1].i=val.i;
#endif
	      // advance pointer
	      ia[i]++;
	   }
       } // end for j
   } // end for i
   
   
   // shift ia back
   for (i=n; i>0; i--) 
       ia[i]=ia[i-1];
   ia[0]=1;

   // Now every row may have duplicate entries, merge these!
   for (i=0; i<n; i++) 
       ibuff[i]=0;
   shift=0;
   for (i=0; i<n; i++) {
       for (j=ia[i]; j<ia[i+1]; j++) {
	   // current column index of row i in C style
	   k=ja[j-1]-1;
	   // did column index k already show up in this row?
	   // no!
	   if (ibuff[k]==0)
	      ibuff[k]=j;
	   else if (ibuff[k]>0) { // yes, merge values
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	      a[j-1]+=a[ibuff[k]-1];
#else		 	         
	      a[j-1].r+=a[ibuff[k]-1].r;
	      a[j-1].i+=a[ibuff[k]-1].i;
#endif
	      // flag this column as duplicate index
	      ibuff[k]=-1;
	   }
       }
       oldshift=shift;
       for (j=ia[i]; j<ia[i+1]; j++) {
	   // current column index of row i in C style
	   k=ja[j-1]-1;
	   ja[j-1-shift]=ja[j-1];
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	   a [j-1-shift]=a[j-1];
#else
	   a [j-1-shift].r=a[j-1].r;
	   a [j-1-shift].i=a[j-1].i;
#endif
	   // this entry already exists in the current row
	   if (ibuff[k]<0)
	      shift++;
	   // clear flag
	   ibuff[k]=0;
       } // end for j
       ia[i]-=oldshift;
   } // end for i
   ia[n]-=shift;

   nnz=ia[n]-1;
   AS->ja=(integer *)  REALLOC(AS->ja,(size_t)nnz*sizeof(integer),  "GNLSYM:AS->ja");
   AS->a =(FLOAT *)REALLOC(AS->a, (size_t)nnz*sizeof(FLOAT),"GNLSYM:AS->a");

}
/*--------------- end of GNLSYM --------------------------------------
----------------------------------------------------------------------*/


