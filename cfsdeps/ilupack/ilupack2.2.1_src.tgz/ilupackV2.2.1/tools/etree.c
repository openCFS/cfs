#include <ilupack.h>
#include <ilupackmacros.h>
#include <stdio.h>

/* compute the etree of A(p,p), adapted from Tim Davis' book

   Aia,Aja  matrix in sparse row format holding the undirected
            graph of A (no matter whether A is originally
	    symmetric or not. FORTRAN-style indexing

   p	    permutation, FORTRAN-style indexing
   invq     inverse permutation with respect to p, 
            FORTRAN-style indexing

   parent   array of parents in the elimination tree of A(p,p)

   iw       work space of length n used to store ancestors
            which leads to path compression and thus more
	    efficiency

   Remark. To compute the elimination tree, the graph of the
           matrix need not be connected
 */
void IP_etree(integer *Aia, integer *Aja, integer n,
	      integer *p, integer *invq, integer *parent,
	      integer *iw)
{
    integer i,k,j, inext, *ancestor=iw;

    for (k=0; k<n; k++) {
        // node k has no parent yet
	parent[k]=-1;		    
	// nor does k have an ancestor
	ancestor[k]=-1;		    
	for (j=Aia[p[k]-1]-1; j<Aia[p[k]]-1; j++) {
	    i=invq[Aja[j]-1]-1;
	    // traverse from i to k
	    while (i!=-1 && i<k) {
	          // next node = ancestor of i
	          inext=ancestor[i];		    
		  // path compression
		  ancestor[i]=k;		    
		  // no ancestor, then parent is k
		  if (inext==-1) 
		     parent[i]=k;   
		  i=inext;
	    } // end while
	} // end for j
    } // end for k
} // end IP_etree

