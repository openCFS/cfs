#include <stdio.h>
#include <stdlib.h>
#include <ilupack.h>

#include <ilupackmacros.h>


void RPERM(CSRMAT *A, integer *perm)
/*
  Interchange rows of A according to the permutation vector perm
  This leads to A_new = A(perm,:)

  code taken from ARMS of Yousef Saad.
  adapted by Matthias Bollhoefer to fit with the data structures
  of ILUPACK including the complex case
*/
{
   integer i, j, n=A->nr, nz, *ia, *ja, *pj;
   FLOAT *a, *pa;

   nz=A->ia[n]-1;

   ia=(integer *)  MALLOC((size_t)(n+1)*sizeof(integer),"RPERM:ia");
   ja=(integer *)  MALLOC((size_t)nz*sizeof(integer),   "RPERM:ja");
   a =(FLOAT *)MALLOC((size_t)nz*sizeof(FLOAT), "RPERM:a");

   ia[0]=1;
   for (i=0; i<n; i++) {
       nz=A->ia[perm[i]]-A->ia[perm[i]-1];
       ia[i+1]=ia[i]+nz;
       pj=A->ja+A->ia[perm[i]-1]-1;
       pa=A->a +A->ia[perm[i]-1]-1;
       for (j=0; j<nz; j++) {
	 *ja++=*pj++;
	 *a++ =*pa++;
       } // end for j           
   } // end for i
   nz=A->ia[n]-1;
   ja-=nz;
   a -=nz;

   // release old values
   free(A->ia);
   free(A->ja);
   free(A->a);

   // change pointers
   A->ia=ia;
   A->ja=ja;
   A->a = a;
} // end RPERM
