#define _SKEW_MATRIX_
#include "symmatvec.c"
