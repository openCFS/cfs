#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <ilupack.h>
#include <ilupackmacros.h>

#define  SMALL   1.0e-08
#define  LARGE   1.0e+08
#define  MYABS(A)      (((A)>=0)?(A):(-(A)))
#define MAX(A,B)        (((A)>(B))?(A):(B))
#define MIN(A,B)        (((A)<(B))?(A):(B))



integer MPSARMS(CSRMAT oldmat, integer *f, REALS *uvec, REALS *vvec,
		integer *ibuff, REALS *dbuff)
{
/*----------------------------------------------------------------------
| C version of Mixed Primal-Dual Algorithm for Assignment Problem
| Giorgio Carpaneto and Paolo Toth
| Discrete Applied Math 18 (1987)
| This algorithm also includes the conversion between a maximum
| product and minimum sum problem.
|-----------------------------------------------------------------------
| coded by  Brian Suchomel
|-----------------------------------------------------------------------
| some changes made by Matthias Bollhoefer in order to fit with ILUPACK
|-----------------------------------------------------------------------
| on entry:
| =========
|   oldmat = source matrix in S/D/C/Zmat format
| on return:
| ==========
|    f     = row permutation array in the range from from 1,...,n
|    uvec  = left diagonal scaling factor
|    vvec  = right diagonal scaling factor
|            finally newmat=uvec*oldmat*vvec will be a matrix such that
|            newmat(f,:) has unit diagonal in absolute values and all
|            other entries are at most 1 in modulus
| work space:
| ===========
|    ibuff = integer buffer of size 8*n+nnz+1
|    dbuff = real    buffer of size 2*n+nnz
|
|
|
|  work arrays:
|==============
|  C[j]    = row preceding column j in the alternating path
|  fbar[j] = row i currently assigned to column j  (f_i = j)
|  IC[q]   = index in vector (UC) of the q-th column labeled in current
|					iteration  ( q=1,...,s; s<=n )
|  m       = number of currently assigned rows (columns)
|  UC[k]   = (k+1)^{st} unlabelled column, if 0<=k<w, 
|		as the (k-w+1)^{st} labelled column if w<=k<nz[] 
|  Pi[j]   = cost of the alternating path arriving at column j
|
| integer value returned:
|             0   --> successful return.
|             i   --> row i is zero.
|	     -2   --> trouble converting matrix
|---------------------------------------------------------------------*/
   integer b, g, h, i, j, jj, k, l, n=oldmat.nc, m, mj, q, r, s, w, 
           flag; 
   integer *jwrev, *jrev2, *C, *fbar, *UC, *IC, *RC, *pia, *pja;
   REALS   d, mm, *Pi, *pa, val, *maxr, *maxc;
   RCSRMAT  mat;
   integer PRO2SUM(CSRMAT, RCSRMAT *, REALS *, REALS *);
   integer INITARMS(RCSRMAT, integer *, REALS *, REALS *, 
		    integer *, integer *, REALS *);

   fbar =ibuff;
   C    =ibuff+n;
   UC   =ibuff+2*n;
   RC   =ibuff+3*n;
   IC   =ibuff+4*n;
   jwrev=ibuff+5*n;
   jrev2=ibuff+6*n;
   Pi=dbuff;

   // map memory, matrix of same size as oldmat
   mat.nc=oldmat.nc;
   mat.nr=oldmat.nr;
   mat.ia=ibuff+7*n;
   mat.ja=ibuff+8*n+1;
   mat.a =dbuff+2*n;
   pia=mat.ia;
   // use shift to compensate FORTRAN-style indexing
   pja=mat.ja-1;
   pa =mat.a-1;
   // compute logarithms, require real buffer of size n
   maxc=dbuff;
   maxr=dbuff+n;
   if (PRO2SUM(oldmat, &mat, maxr,maxc)) return -2;

/*------------------------------------------------------------
|  search for the initial dual and partial primal solutions
|-----------------------------------------------------------*/

   // this routine requires an auxilliary integer buffer of size 3n
   // and an auxilliary real buffer of size n
   m=INITARMS(mat, f, uvec, vvec, fbar, ibuff+n, dbuff);

   for (i=0; i<n; i++)
       IC[i]=-1;
   memcpy(jwrev, IC, n*sizeof(integer));
   memcpy(jrev2, IC, n*sizeof(integer));

   r=0;
   while (m<n) {

         if (f[r]==-1) {
/*-------------------------------------------------------
| search for augmenting path starting from row r
|------------------------------------------------------*/

	    for (j=pia[r]; j<pia[r+1]; j++) {
	        l=pja[j]-1;
		jrev2[l]=j;
	    } // end for j

	    for (j=0; j<n; j++) {
	        C[j] =r;
		UC[j]=j;
	    } // end for j

	    for (k=0; k<n; k++) {
	        if (jrev2[k]!=-1)
		   Pi[k]=pa[jrev2[k]]-uvec[r]-vvec[k];
		else
		   Pi[k]=LARGE       -uvec[r]-vvec[k];
	    }

	    w=n-1;
	    do {
/*-------------------------------------------------------
| computation of d = min {Pi[j]: column j is unlabelled}
|------------------------------------------------------*/

	       d=2*LARGE;
	       g=-1;
	       k=0;
	       flag=0;

	       do {
		  j=UC[k];

		  if (Pi[j]<= d) {

		     if (Pi[j]<d) {
		        g=-1;
			s=-1;
			d=Pi[j];
		     }

		     if (fbar[j]==-1) {
		        g=j;
			if (MYABS(d)<SMALL) flag=1;
		     }

		     s++;
		     IC[s]=k;
		  } // end if

		  k++;

	       }  while (k<=w && flag==0);

	       if (g==-1) {
/*----------------------------------------
| updating of Pi and C
|---------------------------------------*/
		  for (q=s; q>=0; q--) {
		    
		      k=IC[q];
		      b=UC[k];
		      UC[k]=UC[w];
		      UC[w]=b;
		      w--;
		      i=fbar[b];

		      for (jj=pia[i]; jj<pia[i+1]; jj++) {
			  l=pja[jj]-1;
			  jwrev[l]=jj;
		      } // end for jj

		      for (k=0; k<=w; k++) {
			  j=UC[k];
			  jj=jwrev[j];
			  if (jj!=-1) {
			     if (Pi[j]>d+pa[jj]-uvec[i]-vvec[j]) {
			        Pi[j]=d+pa[jj]-uvec[i]-vvec[j];
				C[j] = i;
			     } // end if 
			  } // end if
		      } // end for k

		      for (jj=pia[i]; jj<pia[i+1]; jj++) {
			  l=pja[jj]-1;
			  jwrev[l]=-1;
		      } // end for jj
		  } // end for q
	       } // end if

	    }  while (g<0);

/*--------------------------------------------------
| updating of the dual variables uvec and vvec
|-------------------------------------------------*/

	    for (k=w+1; k<n; k++) {
	        j=UC[k];
		vvec[j]+=Pi[j]-d;
		i=fbar[j];
		uvec[i]+=d-Pi[j];
	    } // end for k
	    uvec[r] += d;


/*--------------------------------------------------
| assignment of a new row
|-------------------------------------------------*/
	    do {
	       i=C[g];
	       fbar[g]=i;
	       b=f[i];
	       f[i]=g;
	       g=b;
	    }  while (i!=r);

	    m++;

	    for (j=pia[r]; j<pia[r+1]; j++) {
	        l=pja[j]-1;
		jrev2[l]=-1;
	    } // end for r

	 } // if (f[r]==-1)

	 r++;
   } // end while


   // compute inverse permutation
   for (i=0; i<n; i++) 
       ibuff[f[i]]=i;
   // right permutation back and increment values by 1
   for (i=0; i<n; i++) 
       f[i]=ibuff[i]+1;

   
   // finally compute scaling
   for (i=0; i<n; i++) {
       uvec[i]=exp(uvec[i]-maxr[i]);
       vvec[i]=exp(vvec[i]);
   }

   return 0;
}



integer INITARMS(RCSRMAT A, integer *f, REALS *uvec, REALS *vvec, 
		 integer *fbar, integer *ibuff, REALS *dbuff)
{
/*----------------------------------------------------------------------
| search for the initial dual and partial primal solutions
| 
| p[i] defines the index of the first unscanned column of row i
|-----------------------------------------------------------------------
|
|  f[i]    = column j currently assigned to row i  (f_i = j)
|  fbar[j] = row i currently assigned to column j  (f_i = j)
|  m       = number of currently assigned rows (columns)
|
|  (uvec), (vvec) = dual vectors
|  ibuff, dbuff = integer/real vectors of size 3n/n
|
| integer value returned:
|             0   --> successful return.
|             i   --> row i is zero.
|-----------------------------------------------------------------------
| coded by  Brian Suchomel
|-----------------------------------------------------------------------
| some changes made by Matthias Bollhoefer in order to fit with ILUPACK
|---------------------------------------------------------------------*/
   integer i, j, k, l, m, r, flag, n=A.nc, *minj, mj, *jwrev, *p, *jp;
   integer *pia, *pja;
   REALS  *pa, *minm, mm, val;

   p   =ibuff;
   jp  =ibuff+n;
   minj=ibuff+2*n;
   minm=dbuff;

   pia=A.ia;
   // additional shift to compensate FORTRAN indexing
   pja=A.ja-1;
   pa =A.a-1;
/*------------------------------------------------------------
|  initialization
|-----------------------------------------------------------*/
   for (k=0; k<n; k++) {
       f[k]   =-1;
       fbar[k]=-1;
       uvec[k]=0.0;
       p[k]   =pia[k];
   } // end for k
/*------------------------------------------------------------
|  initialization of the dual variables  (vvec)
|-----------------------------------------------------------*/
   for (i=0; i<n; i++) {
       minm[i]=LARGE;
       minj[i]=-1;
   } // end for i
   for (i=0; i<n; i++) {
       for (k=pia[i]; k<pia[i+1]; k++) {
	   j  =pja[k]-1;
	   val=pa[k];
	   if (val<minm[j]) {
	      minm[j]=val;
	      minj[j]=i;
	      jp[i]  =k;
	   }
	   else if (val==minm[j]) {
	      if (f[i]==-1) {
		 minm[j]=val;
		 minj[j]=i;
		 jp[i]  =k;
	      }
	   }
       } // end for k
   }

   m=0;
   for (j=0; j<n; j++) {
       r=minj[j];
       vvec[j]=minm[j];

       if (f[r]==-1) {
/*-----------------------------------
|  assignment of column j to row r
|----------------------------------*/
	  m++;
	  fbar[j]=r;
	  f[r]   =j;
	  p[r]   =jp[r] + 1;
       }
       else
	  p[r]   =pia[r];
   } // end for j

/*-----------------------------------------------------------------------
|  scanning of the unassigned rows and updating of dual variables  (uvec)
|----------------------------------------------------------------------*/
   for (i=0; i<n; i++) {

       if (f[i]==-1) {

	  mm=LARGE;
	  mj=-1;
	  j =pia[i];
	  for (k=pia[i]; k<pia[i+1]; k++) {
	      l  =pja[k]-1;
	      val=pa[k]-vvec[l];
	      if (val<mm) {
	         mm=val;
		 mj=l;
		 j=k;
	      }
	      else if (val==mm) {
	         if (fbar[mj]!=-1) {
		    mm=val;
		    mj=l;
		    j=k;
		 }
	      }
	  } // end for k

	  uvec[i]=mm-vvec[mj];
	  flag=0;

/*----------------------------------------------
|  search for an unassigned column j in row i
|---------------------------------------------*/
	  while (f[i]!=-1 && j<pia[i+1]) {
	        l  =pja[j]-1;
		val=pa[j];

		if (MYABS(val-uvec[i]-vvec[l])<SMALL) {
		   r=fbar[l];
		   k=p[r];

/*----------------------------------------------
|  search for an unassigned column k in row r
|---------------------------------------------*/
		   while (flag==0 && k<pia[r+1]) {
		         l  =pja[k]-1;
			 val=pa[k];

			 if (fbar[l]==-1 && val-uvec[r]-vvec[l]<SMALL)
			    flag=1;
			 else
			    p[r]=++k;
		   } // end while
		} // end if

		if (flag) {
/*------------------------------------
| reassignment of row r to column k
|-----------------------------------*/
		   fbar[pja[j]-1]=-1;
		   f[r]   =l;
		   fbar[l]=r;
		}
		else
		   j++;
	  } // end while

	  if (j<pia[i+1]) {
	     l=pja[j]-1;
	     if (fbar[l]==-1) {
/*------------------------------------
| assignment of column j to row i
|-----------------------------------*/
	        m++;
		f[i] = l;
		fbar[l] = i;
		p[i] = j + 1;
	     } // end if
	  } // end if
       } // end if
   } // end for i
   
   return m;
}



integer PRO2SUM(CSRMAT Pmat, RCSRMAT *Smat, REALS *ai, REALS *aj)
{
/*----------------------------------------------------------------------
| This routine does the following transformation
|
|             a_i = max_j | P_{i,j} |
|             a_j = max_i | P_{i,j} |
|
|             S_{i,j} = log(a_i) - log | P_{i,j} | 
|
|-----------------------------------------------------------------------
| coded by  Brian Suchomel
|-----------------------------------------------------------------------
| some changes made by Matthias Bollhoefer in order to fit with ILUPACK
|-----------------------------------------------------------------------
|
| on entry:
|==========
|
| Pmat - S/D/C/Zmat             (matrix exists)
| Smat - pointer to S/D/C/Zmat  (no matrix, but structures and memory exist)
| ai   - auxilliary buffer of size Pmat.nc
| aj   - auxilliary buffer of size Pmat.nr
|
| on return:
|===========
| Smat - pointer to SparRow struct  (matrix exists)
|
|
| integer value returned:
|             0   --> successful return
|             i   --> row i+1 is zero
|            -1   --> memory error
|---------------------------------------------------------------------*/
   integer i, j, *iw, *jw, k, len, n=Pmat.nc, *pia, *pja;
   REALS val, *w;
   FLOAT *pa;

   // number of nonzeros in Pmat
   for (i=0; i<n; i++)
       ai[i]=aj[i]=0.0;

   iw=Smat->ia;
   jw=Smat->ja;
   w =Smat->a;

   pia=Pmat.ia;
   // include shift to adjust FORTRAN indexing
   pja=Pmat.ja-1;
   pa =Pmat.a-1;

   for (i=0; i<n; i++) { 
      for (k=pia[i]; k<pia[i+1]; k++) {
	  j=pja[k]-1;
	  val=FABS(pa[k]);
	  if (val>ai[i])  
             ai[i]=val;
	  if (val>aj[j])  
             aj[j]=val;
      }
   }
   for (i=0; i<n; i++) {
      if (ai[i]>0.0) 
	 ai[i]=log((double)ai[i]);
      else
         return i+1;
   }
   for (j=0; j<n; j++) {
      if (aj[j]>0.0) 
	 aj[j]=log((double)aj[j]);
      else
         return j+1;
   }

   iw[0]=1;
   for (i=0; i<n; i++) { 
       len=iw[i]-1;
       for (k=pia[i]; k<pia[i+1]; k++) {
	   j=pja[k];
	   val=FABS(pa[k]);
	   // only store logarithm of nonzero entries
	   if (val>0.0) {
	      val=log((double)val);
	      if (val>MIN(ai[i],aj[j-1])-5) {
		 w[len]   =ai[i]-val;
		 jw[len++]=j;
	      }
	   }
       }
       iw[i+1]=len+1;
   }

   // printf("MWA: %ld, %ld\n",pia[n]-1,iw[n]-1);fflush(stdout);
   return 0;
}
