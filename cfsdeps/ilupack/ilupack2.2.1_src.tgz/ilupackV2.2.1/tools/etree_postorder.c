#include <ilupack.h>
#include <ilupackmacros.h>

/*
  post order the elimination tree

  parent   array describing the tree by storing the parent
           information
   
  n        size of the tree

  post     post ordering of the tree to be computed

  iw       work space of length at least 3n

*/
void IP_post_order(integer *parent, integer n, integer *post,
		   integer *iw)
{
    integer j, k=0, *head, *next, *stack ;

    head=iw; next=iw+n; stack=iw+2*n;
    // empty linked lists
    for (j=0; j<n; j++) 
        head[j]=-1;

    // traverse nodes in reverse order
    for (j=n-1; j>=0; j--) {
        // j is a root
	if (parent[j]==-1) continue;    

	// add j to list of its parent
	next[j]=head[parent[j]];	    
	head[parent[j]]=j;
    } // end for j
    for (j=0; j<n; j++) {
        // skip j if it is not a root
	if (parent[j]!=-1) continue;    
	k=IP_tdfs(j, k, head, next, post, stack);
    } // end for j
} // end IP_post_order


integer IP_tdfs(integer j, integer k, integer *head, 
		integer *next, integer *post, integer *stack)
{
    integer i, p, top=0;

    // place j on the stack
    stack[0]=j;		    
    // while (stack is not empty)
    while (top>=0) {
          // p = top of stack
          p=stack[top];	    
	  // i = youngest child of p
	  i=head[p];		    
	  if (i==-1) {
	     // p has no unordered children left
	     top--;
	     // node p is the kth postordered node
	     post[k++]=p;
	  } // end if 
	  else {
	     // remove i from children of p
	     head[p]=next[i];   
	     // start dfs on child node i
	     stack[++top]=i;	    
	  } // end else
    } // end while

    return (k);
} // end IP_tdfs
