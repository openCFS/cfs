#ifndef _ILU_PACK_HH
#define _ILU_PACK_HH

#include <ilupack.h>

void AMGinit(Smat *, SILUPACKparam *);
void AMGinit(Dmat *, DILUPACKparam *);
void AMGinit(Cmat *, CILUPACKparam *);
void AMGinit(Zmat *, ZILUPACKparam *);

void AMGinit(Dmat *, SILUPACKparam *);
void AMGinit(Zmat *, CILUPACKparam *);


void AMGdelete(Smat *, SAMGlevelmat *, SILUPACKparam *);
void AMGdelete(Dmat *, DAMGlevelmat *, DILUPACKparam *);
void AMGdelete(Cmat *, CAMGlevelmat *, CILUPACKparam *);
void AMGdelete(Zmat *, ZAMGlevelmat *, ZILUPACKparam *);

void AMGdelete(Dmat *, SAMGlevelmat *, SILUPACKparam *);
void AMGdelete(Zmat *, CAMGlevelmat *, CILUPACKparam *);


integer AMGfactor(Smat *, SAMGlevelmat *, SILUPACKparam *);
integer AMGfactor(Dmat *, DAMGlevelmat *, DILUPACKparam *);
integer AMGfactor(Cmat *, CAMGlevelmat *, CILUPACKparam *);
integer AMGfactor(Zmat *, ZAMGlevelmat *, ZILUPACKparam *);

integer AMGfactor(Dmat *, SAMGlevelmat *, SILUPACKparam *);
integer AMGfactor(Zmat *, CAMGlevelmat *, CILUPACKparam *);


integer AMGsolver(Smat *, SAMGlevelmat *, SILUPACKparam *, 
		  real *, real *);
integer AMGsolver(Dmat *, DAMGlevelmat *, DILUPACKparam *, 
		  doubleprecision *, doubleprecision *);
integer AMGsolver(Cmat *, CAMGlevelmat *, CILUPACKparam *, 
		  complex *, complex *);
integer AMGsolver(Zmat *, ZAMGlevelmat *, ZILUPACKparam *, 
		  doublecomplex *, doublecomplex *);

integer AMGsolver(Dmat *, SAMGlevelmat *, SILUPACKparam *, 
		  doubleprecision *, doubleprecision *);
integer AMGsolver(Zmat *, CAMGlevelmat *, CILUPACKparam *, 
		  doublecomplex *, doublecomplex *);

integer AMGsolver(Cmat *, SAMGlevelmat *, SILUPACKparam *, 
		  complex *, complex *);
integer AMGsolver(Zmat *, DAMGlevelmat *, DILUPACKparam *, 
		  doublecomplex *, doublecomplex *);
integer AMGsolver(Zmat *, SAMGlevelmat *, SILUPACKparam *, 
		  doublecomplex *, doublecomplex *);

#endif
