#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include <blas.h>
#include <hsl.h>
#include <metisord.h>
#include <ilupack.h>

#include <ilupackmacros.h>

#define MAX(A,B)        (((A)>(B))?(A):(B))
#define MIN(A,B)        (((A)<(B))?(A):(B))
#define IABS(A)         (((A)>=0)?(A):(-(A)))
#define STDERR          stderr
#define STDOUT          stdout


// #define PRINT_INFO


#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
#define CONJG(A)      (A)

#ifdef _SKEW_MATRIX_

#ifdef _DOUBLE_REAL_
#define MYSYMMWM             DSSMsmwm
#define MYSYMPERMMC64METIS_n_sp     DSSMperm_mc64_metis_n_sp

#else
#define MYSYMMWM             SSSMsmwm
#define MYSYMPERMMC64METIS_n_sp     SSSMperm_mc64_metis_n_sp
#endif

#define SKEW(A)      (-(A))

#else

#ifdef _DOUBLE_REAL_
#define MYSYMMWM             DSYMsmwm
#define MYSYMPERMMC64METIS_n_sp     DSYMperm_mc64_metis_n_sp
#else
#define MYSYMMWM             SSYMsmwm
#define MYSYMPERMMC64METIS_n_sp      SSYMperm_mc64_metis_n_sp
#endif

#define SKEW(A)      (A)
#endif
// end _SKEW_MATRIX_


#else

#ifdef _COMPLEX_SYMMETRIC_
#define CONJG(A)     (A)

#ifdef _SKEW_MATRIX_
#define SKEW(A)      (-(A))

#ifdef _SINGLE_COMPLEX_
#define MYSYMMWM             CSSMsmwm
#define MYSYMPERMMC64METIS_n_sp     CSSMperm_mc64_metis_n_sp
#else
#define MYSYMMWM             ZSSMsmwm
#define MYSYMPERMMC64METIS_n_sp     ZSSMperm_mc64_metis_n_sp
#endif

#else
#define SKEW(A)      (A)

#ifdef _SINGLE_COMPLEX_
#define MYSYMMWM            CSYMsmwm
#define MYSYMPERMMC64METIS_n_sp    CSYMperm_mc64_metis_n_sp
#else
#define MYSYMMWM            ZSYMsmwm
#define MYSYMPERMMC64METIS_n_sp    ZSYMperm_mc64_metis_n_sp
#endif

#endif
// end _SKEW_MATRIX_


#else
#define CONJG(A)     (-(A))

#ifdef _SKEW_MATRIX_
#define SKEW(A)      (-(A))

#ifdef _SINGLE_COMPLEX_
#define MYSYMMWM            CSHRsmwm
#define MYSYMPERMMC64METIS_n_sp    CSHRperm_mc64_metis_n_sp
#else
#define MYSYMMWM            ZSHRsmwm
#define MYSYMPERMMC64METIS_n_sp    ZSHRperm_mc64_metis_n_sp
#endif

#else
#define SKEW(A)      (A)

#ifdef _SINGLE_COMPLEX_
#define MYSYMMWM            CHERsmwm
#define MYSYMPERMMC64METIS_n_sp    CHERperm_mc64_metis_n_sp
#else
#define MYSYMMWM            ZHERsmwm
#define MYSYMPERMMC64METIS_n_sp    ZHERperm_mc64_metis_n_sp
#endif

#endif
// end _SKEW_MATRIX_

#endif
// end _COMPLEX_SYMMETRIC_

#endif
// end _DOUBLE_REAL_


/*
 scaling and permutation driver, followed by a symmetric reordering.

 here 1) maximum weight matching (MC64)
      3) associated symmetric block partitioning and block reordering by
         I.S. Duff and S. Pralet
      2) MeTis multilevel nested dissection by nodes


 Given an n x n matrix A in compressed sparse row format this routine computes
 row and column scalings as well as row and column permutations such that

 A -> Dr * A * Dc,
 
 where Dr and Dc are diagonal matrices stored in the vectors proscal and 
 pcolscale. The scaling is explicitly applied to A.

 The permutation p,invq refer to permutation matrices P and Q^{-1} such  that

  P^T*(Dr * A * Dc)*Q 

 is hopefully better suited for the ILU.

 The routine returns a leading block size nB<=n
                        /B F\ 
  P^T*(Dr * A * Dc)*Q = |   | 
                        \E C/
 In this case the permutation recommends that the ILU is only applied to the
 leading block B of size nB x nB
*/
integer MYSYMPERMMC64METIS_n_sp(CSRMAT A, FLOAT *prowscale, FLOAT *pcolscale, 
				    integer *p, integer *invq, integer *nB, 
				    ILUPACKPARAM *param)
{
/*
    A          n x n matrix in compressed sparse row format
               A is altered by the routine since the scalings are directly
               applied to A. Hopefully the scaling are only powers of 2,
               which is the case for all scaling routines from ILUPACK.

    prowscale,   vectors of length n that store the row and column scalings Dr
    pcolscale    and Dc
               A -> Dr*A*Dc

    p,invq     permutation vectors p and q^{-1} of length n which refer to
               row / column permutation matrices P and Q^{-1}.
               P^T*(Dr * A * Dc)*Q hopefully better suited for ILU

    nB         leading blocksize nB
                                     /B F\ 
               P^T*(Dr * A * Dc)*Q = |   |,  B matrix of size nB x nB
                                     \E C/
               nB is the recommended block size for the application of an ILU

    param      ILUPACK parameters


    interface driver written by Matthias Bollhoefer, November 2004, May 2005,
                                                     May 2008
 
*/
    integer  i,ii,j,jj,k,l,m,imx,n=A.nr,liw,*iw,ldw,info[10],icntl[10],
             iflag,*ind,*list,*ncolumn,*pid,niaux,useiaux[4],
             num,nz,ierr=0,options[10], numflag, scale, pow,nrm,qi,
      *ia, *ja,bnd,bndt,*cperm,job,nr,nlist,gr,mingr,mingr2,minfill;
    REALS mxr, lg2=1.0/log((double)2.0), fpow, *dw, *b, a,
          sm,sm2, sigma, sigmat, x;
    FLOAT  *w,mx;
    size_t mem;
    CSRMAT B, Br, Bc, C, D;
    // FILE *fp;

    ierr=0;
    // --------------------   END set up parameters   --------------------

#ifdef PRINT_INFO
    printf("start symperm_mc64_metis_n_sp\n");fflush(stdout);
#endif
    param->ndbuff=MAX(param->ndbuff,(2*(size_t)A.nc*MAX(sizeof(FLOAT),sizeof(double)))/sizeof(double));
    param->dbuff=(FLOAT *) REALLOC(param->dbuff,param->ndbuff*sizeof(FLOAT),
				   "symperm_mc64_metis_n_sp:dbuff");

#include "scaleprefix.c"

    // use unsymmetric version of A for maximum weight matching
    // build B=|A|+|A^T|
    param->nibuff=MAX(param->nibuff,6*(size_t)A.nc+5);
    param->ibuff=(integer *) REALLOC(param->ibuff,param->nibuff*sizeof(integer),
				     "symperm_mc64_metis_n_sp:ibuff");
    // param->ibuff (2n+1) will be used indicate the pruned parts of A, but 
    // also be used for B.ia!
    // the leading 5n entries of param->iaux will be used for MC64, if possible
    // dbuff (n) will be used to compute the maximum absolute entry per row.
    mem=(param->niaux>=5*n) ? param->niaux-5*n : 0;
    SETUPGRAPH_EPSILON(A,&B,(REALS)MC64THRESHOLD,
		       (REALS *)param->dbuff, param->ibuff, 
		       param->iaux+5*n, mem);

    // check if MALLOC was needed to set up B.ja
    if (B.ia[B.nc]<0) {
       iflag=0;
       B.ia[B.nc]=-(B.ia[B.nc]);
    }
    else // nz entries from iaux+5n are already in use 
       iflag=B.ia[B.nc]-1; 

    // number of nonzeros
    nz=B.ia[B.nc]-1;

    // memory for the unsymmetric version of A
    ldw=3*B.nc+nz;
    if (param->ndaux>=ldw)
       dw=(REALS *)param->daux;
    else {
       dw=(REALS *) MALLOC((size_t)ldw*sizeof(REALS),"symperm_mc64_metis_n_sp:dw");
       // printf("alloc dw\n");fflush(stdout);
    }
    b=dw+3*B.nc;

    //--------------------  actual copying 
    iw=B.ia;
    for (i=0; i<A.nc; i++) {
        // copy indices
        for (j=A.ia[i]-1; j<param->ibuff[i]-1; j++) {
	    // current column index of row i in FORTRAN style
	    k=A.ja[j]-1;
	    a=FABS(A.a[j]);
	    b[iw[i]-1]=a;
	    // advance pointer
	    iw[i]++;
	    // avoid duplicate entries
	    if (k!=i) {
	       b[iw[k]-1]=a;
	       // advance pointer
	       iw[k]++;
	    } // end if
	} // end for j
    } // end for i
    // shift iw back
    for (i=A.nc; i>0; i--) 
        iw[i]=iw[i-1];
    iw[0]=1;


    // MC64 maximum weight matching interface
    liw=5*B.nc;
    if (param->niaux>=liw)
       iw=param->iaux;
    else {
       iw=(integer *) MALLOC((size_t)liw*sizeof(integer),"sympermMC64_metis_n:iw");
       // printf("alloc iw\n");fflush(stdout);
    }


    // -------------   construct permutation  ------------
    MC64IR(icntl);
    job=5;
    MC64AR(&job,&(B.nc),&nz,B.ia,B.ja,b,&num,p,
	   &liw,iw,&ldw,dw,icntl,info);
#ifdef PRINT_INFO
    printf("call MC64 matching routine\n");fflush(stdout);
#endif
    if (param->niaux<liw) {
       free(iw);
       //printf("release iw\n"); fflush(stdout);
    }
    nz=A.ia[A.nc]-1;
    // values of the unsymmetric version are not longer needed
    if (!iflag)
       free(B.ja);

    /*
    for (i=0; i<n; i++)
      printf("%16.8le ",dw[i]);
    printf("\n");fflush(stdout);
      
    for (i=0; i<n; i++)
      printf("%16.8le ",dw[n+i]);
    printf("\n");fflush(stdout);
    for (i=0; i<n; i++)
      printf("%8i ",p[i]);
    printf("\n");fflush(stdout);
    */
  
    // build left and right diagonal scaling derived from the matching
    for (i=0; i<n; i++) {

        mxr=sqrt(exp(dw[i]+dw[n+i]));
	// compute nearest power of 2
	fpow=log(mxr)*lg2;
	if (fpow<0.0) {
	   pow=fpow-0.5;
	   fpow=1;
	   for (l=1; l<=-pow; l++)
	       fpow*=2.0;
	   mxr=1.0/fpow;
	}
	else {
	   pow=fpow+0.5;
	   fpow=1;
	   for (l=1; l<=pow; l++)
	       fpow*=2;
	   mxr=fpow;
	}
	dw[i]=mxr;
    } // end for i

    // transfer scaling to the official interface vectors
    for (i=0; i<A.nr; i++){
#if defined _DOUBLE_REAL_ || defined  _SINGLE_REAL_
	pcolscale[i]*=dw[i];
#else
	pcolscale[i].r*=dw[i];
	pcolscale[i].i=0;
#endif
    } // end for i


    // rescale matrix explicitly
    for (i=0; i<n; i++){
        for (j=A.ia[i]-1; j<A.ia[i+1]-1; j++){
#if defined _DOUBLE_REAL_ || defined  _SINGLE_REAL_
	    A.a[j]=dw[i]*A.a[j]*dw[A.ja[j]-1];
#else
	    A.a[j].r=dw[i]*A.a[j].r*dw[A.ja[j]-1];
	    A.a[j].i=dw[i]*A.a[j].i*dw[A.ja[j]-1];
#endif
	} // end for j
    } // end for i
    if (param->ndaux<ldw) {
       free(dw);
       // printf("free dw\n");fflush(stdout);
    }

#ifdef PRINT_INFO2
    // fp=fopen("test","w");
    for (i=0; i<n; i++)
        for (j=A.ia[i];j<A.ia[i+1];j++)
	  printf("%8d%8d%16.8le\n",i+1, A.ja[j-1],A.a[j-1]);
    printf("\n");
    fflush(stdout);
    for (i=0; i<A.nc; i++) 
        printf("%8d",p[i]);
    printf("\n");
    fflush(stdout);
    // fclose(fp);
#endif


 
    // extract from the saddle point matrix 
    //    [ C   B]
    // A= [      ]
    //    [B^T  0]
    // the pattern of |C|+|B|*|B|^T
    
    // first pass, determine the fill-in of C
    // C will store the full undirected graph of C
    C.ia=param->ibuff;
    // clear C.ia
    j=0;
    for (i=0; i<=A.nc; i++) {
        C.ia[i]=0;
	// on the fly, also determine the size of the C-block
        if (param->indicator[i]>=0)
	   j++;
    }
    C.nr=C.nc=j;
    nz=0;
    for (i=0; i<A.nc; i++) {       
        if (param->indicator[i]>=0) {
	   for (k=A.ia[i]-1; k<A.ia[i+1]-1; k++) {
	       j=A.ja[k]-1;
	       // examine a_ij
	       if (param->indicator[j]>=0) {
		  C.ia[i+1]++;
		  nz++;
		  // we need to incorporate symmetry but exclude the diagonal entries
		  if (i!=j) {
		     C.ia[j+1]++;
		     nz++;
		  }
	       }
	   }
	}
    }
    C.a=NULL;
    // change to cumulative sum
    C.ia[0]=1;
    for (i=0; i<A.nc; i++)        
        C.ia[i+1]+=C.ia[i];
    // second pass, insert graph of A
    niaux=param->niaux;
    useiaux[0]=0;
    if (niaux>=nz+1) {
       C.ja=param->iaux;
       useiaux[0]=nz+1;
       niaux-=nz+1;
    }
    else
       C.ja=(integer *)MALLOC((size_t)nz*sizeof(integer), "symperm_mc64_metis_n_sp:C.ja");
    for (i=0; i<A.nc; i++) {       
        if (param->indicator[i]>=0) {
	   for (k=A.ia[i]-1; k<A.ia[i+1]-1; k++) {
	       j=A.ja[k]-1;
	       // examine a_ij
	       if (param->indicator[j]>=0) {
		  C.ja[C.ia[i]-1]=j+1;
		  C.ia[i]++;
		  if (i!=j) {
		     C.ja[C.ia[j]-1]=i+1;
		     C.ia[j]++;
		  }
	       }
	   }
	}
    }
    // shift C.ia back
    for (i=A.nc-1; i>=0; i--)        
        C.ia[i+1]=C.ia[i];
    C.ia[0]=1;

#ifdef PRINT_INFO2
    // fp=fopen("test","w");
    for (i=0; i<A.nc; i++)
        for (j=C.ia[i];j<C.ia[i+1];j++)
	  printf("%8d%8d%16.8le\n",i+1, C.ja[j-1],1.0);
    printf("\n");
    fflush(stdout);
#endif


    // next step consists of computing the pattern of B by columns
    // first pass, determine the fill-in of B by columns (B^T by rows)
    Bc.nc=C.nc;
    Bc.nr=A.nr-C.nr;
    Bc.ia=param->ibuff+A.nc+1;
    for (i=0; i<=A.nc; i++)
        Bc.ia[i]=0;
    nz=0;
    for (i=0; i<A.nc; i++) {       
        // significant row i, since B might be disassembled in the
        // lower triangular part as well as in the upper triangular part.
        // in the lower triangular part this refers to parts of B^T
        if (param->indicator[i]<0) {
	   for (k=A.ia[i]-1; k<A.ia[i+1]-1; k++) {
	       j=A.ja[k]-1;
	       // examine a_ij
	       if (param->indicator[j]>=0) {
		  Bc.ia[i+1]++;
		  nz++;
	       }
	   }
	}
        // significant column i, B might be disassembled
        else { // (param->indicator[i]>=0) 
	   for (k=A.ia[i]-1; k<A.ia[i+1]-1; k++) {
	       j=A.ja[k]-1;
	       // examine a_ij
	       if (param->indicator[j]<0) {
		  Bc.ia[j+1]++;
		  nz++;
	       }
	   }
	}
    }
    Bc.a=NULL;
    // change to cumulative sum
    Bc.ia[0]=1;
    for (i=0; i<A.nc; i++)        
        Bc.ia[i+1]+=Bc.ia[i];
    // second pass, insert graph of A
    if (niaux>=nz+1) {
       Bc.ja=param->iaux+useiaux[0];
       useiaux[1]=useiaux[0]+nz+1;
       niaux-=nz+1;
    }
    else {
       useiaux[1]=useiaux[0];
       Bc.ja=(integer *)MALLOC((size_t)nz*sizeof(integer), "symperm_mc64_metis_n_sp:Bc.ja");
    }
    for (i=0; i<A.nc; i++) {       
        if (param->indicator[i]<0) {
	   for (k=A.ia[i]-1; k<A.ia[i+1]-1; k++) {
	       j=A.ja[k]-1;
	       if (param->indicator[j]>=0) {
		  Bc.ja[Bc.ia[i]-1]=j+1;
		  Bc.ia[i]++;
	       }
	   }
	}
        // significant column i, B might be disassembled
        else { // (param->indicator[i]>=0)
	   for (k=A.ia[i]-1; k<A.ia[i+1]-1; k++) {
	       j=A.ja[k]-1;
	       if (param->indicator[j]<0) {
		  Bc.ja[Bc.ia[j]-1]=i+1;
		  Bc.ia[j]++;
	       }
	   }
	}
    }
    // shift Bc.ia back
    for (i=A.nc-1; i>=0; i--)        
        Bc.ia[i+1]=Bc.ia[i];
    Bc.ia[0]=1;
#ifdef PRINT_INFO2
    // fp=fopen("test","w");
    for (i=0; i<A.nc; i++)
        for (j=Bc.ia[i];j<Bc.ia[i+1];j++)
	  printf("%8d%8d%16.8le\n",i+1, Bc.ja[j-1],1.0);
    printf("\n");
    fflush(stdout);
#endif


    // next step consists of computing the pattern of B by rows
    // first pass, determine the fill-in of B
    Br.nr=C.nr;
    Br.nc=A.nc-C.nc;
    Br.ia=param->ibuff+2*(A.nc+1);
    for (i=0; i<=A.nc; i++)
        Br.ia[i]=0;
    nz=0;
    for (i=0; i<A.nc; i++) {       
        // significant row i, since B might be disassembled in the
        // lower triangular part as well as in the upper triangular part.
        // in the lower triangular part this refers to parts of B^T
        if (param->indicator[i]<0) {
	   for (k=A.ia[i]-1; k<A.ia[i+1]-1; k++) {
	       j=A.ja[k]-1;
	       // examine a_ij
	       if (param->indicator[j]>=0) {
		  Br.ia[j+1]++;
		  nz++;
	       }
	   }
	}
        // significant column i, B might be disassembled
        else { // (param->indicator[i]>=0) 
	   for (k=A.ia[i]-1; k<A.ia[i+1]-1; k++) {
	       j=A.ja[k]-1;
	       if (param->indicator[j]<0) {
		  Br.ia[i+1]++;
		  nz++;
	       }
	   }
	}
    }
    Br.a=NULL;
    // change to cumulative sum
    Br.ia[0]=1;
    for (i=0; i<A.nc; i++)        
        Br.ia[i+1]+=Br.ia[i];
    // second pass, insert graph
    if (niaux>=nz+1) {
       Br.ja=param->iaux+useiaux[1];
       useiaux[2]=useiaux[1]+nz+1;
       niaux-=nz+1;
    }
    else {
       useiaux[2]=useiaux[1];
       Br.ja=(integer *)MALLOC((size_t)nz*sizeof(integer), "symperm_mc64_metis_n_sp:Br.ja");
    }
    for (i=0; i<A.nc; i++) {       
        if (param->indicator[i]<0) {
	   for (k=A.ia[i]-1; k<A.ia[i+1]-1; k++) {
	       j=A.ja[k]-1;
	       if (param->indicator[j]>=0) {
		  Br.ja[Br.ia[j]-1]=i+1;
		  Br.ia[j]++;
	       }
	   }
	}
        // significant column i, Br might be disassembled
        else { // (param->indicator[i]>=0)
	   for (k=A.ia[i]-1; k<A.ia[i+1]-1; k++) {
	       j=A.ja[k]-1;
	       if (param->indicator[j]<0) {
		  Br.ja[Br.ia[i]-1]=j+1;
		  Br.ia[i]++;
	       }
	   }
	}
    }
    // shift Br.ia back
    for (i=A.nc-1; i>=0; i--)        
        Br.ia[i+1]=Br.ia[i];
    Br.ia[0]=1;
#ifdef PRINT_INFO2
    // fp=fopen("test","w");
    for (i=0; i<A.nc; i++)
        for (j=Br.ia[i];j<Br.ia[i+1];j++)
	  printf("%8d%8d%16.8le\n",i+1, Br.ja[j-1],1.0);
    printf("\n");
    fflush(stdout);
#endif
    


    // next step, compute D=C+BB^T, row by row
    D.ia=param->ibuff+3*(A.nc+1);
    D.nr=D.nc=A.nc;
    nz=0;
    ind=param->ibuff+4*A.nc+4;
    for (i=0; i<A.nc; i++)
        ind[i]=D.ia[i]=0;
    D.ia[A.nc]=0;
    list=param->ibuff+5*A.nc+4;
    for (i=0; i<A.nc; i++) {   
        // first step, scatter entries of C
        nlist=0;
	for (k=C.ia[i]-1; k<C.ia[i+1]-1; k++) {
	    j=C.ja[k]-1;
	    if (j!=i) {
	       list[nlist]=j;
	       ind[j]=++nlist;
	       nz++;
	    }
	} // end for k
        // second step, scatter entries of B(:,j)^T for all b_ij!=0
	for (k=Br.ia[i]-1; k<Br.ia[i+1]-1; k++) {
	    j=Br.ja[k]-1;
	    for (l=Bc.ia[j]-1; l<Bc.ia[j+1]-1; l++) {
	        jj=Bc.ja[l]-1;
		if (ind[jj]==0 && jj!=i) {
		   list[nlist]=jj;
		   ind[jj]=++nlist;
		   nz++;
		}
	    } // end for l
	} // end for k
	D.ia[i+1]=nlist;
	
	// clear auxilliary list
	for (k=0; k<nlist; k++) {
	    ind[list[k]]=0;
	}
    }
    // change to cumulative sum
    D.ia[0]=1;
    for (i=0; i<A.nc; i++) {
        D.ia[i+1]+=D.ia[i];
    }
    // second pass, insert graph of A
    if (niaux>=nz+1) {
       D.ja=param->iaux+useiaux[2];
       useiaux[3]=useiaux[2]+nz+1;
       niaux-=nz+1;
    }
    else {
       useiaux[3]=useiaux[2];
       D.ja=(integer *)MALLOC((size_t)nz*sizeof(integer), "symperm_mc64_metis_n_sp:D.ja");
    }
    for (i=0; i<A.nc; i++) {       
        // first step, scatter entries of C
        m=0;
	for (k=C.ia[i]-1; k<C.ia[i+1]-1; k++) {
	    j=C.ja[k]-1;
	    if (j!=i) {
	       D.ja[D.ia[i]-1]=j+1;
	       D.ia[i]++;
	       ind[j]=++m;
	    }
	} // end for k
        // second step, scatter entries of B(:,j)^T for all b_ij!=0
	for (k=Br.ia[i]-1; k<Br.ia[i+1]-1; k++) {
	    j=Br.ja[k]-1;
	    for (l=Bc.ia[j]-1; l<Bc.ia[j+1]-1; l++) {
	        jj=Bc.ja[l]-1;
		if (ind[jj]==0 && jj!=i) {
		   D.ja[D.ia[i]-1]=jj+1;
		   D.ia[i]++;
		   ind[jj]=++m;
		}
	    } // end for l
	} // end for k
	
	// clear auxilliary list
	for (k=D.ia[i]-m-1; k<D.ia[i]-1; k++) {
	    j=D.ja[k]-1;
	    ind[j]=0;
	} // end for k
    } // end for i
    // shift D.ia back
    for (i=A.nc-1; i>=0; i--)        
        D.ia[i+1]=D.ia[i];
    D.ia[0]=1;
#ifdef PRINT_INFO
    // fp=fopen("test","w");
    for (i=0; i<A.nc; i++)
        for (j=D.ia[i];j<D.ia[i+1];j++)
	  printf("%8d%8d%16.8le\n",i+1, D.ja[j-1],1.0);
    printf("\n");
    fflush(stdout);
#endif
#ifdef PRINT_INFO2   
    for (i=0; i<=A.nc; i++)
      printf("%8d",D.ia[i]);
    printf("\n");
    fflush(stdout);
    for (i=0; i<D.ia[A.nc]; i++)
      printf("%8d",D.ja[i]);
    printf("\n");
    fflush(stdout);
#endif


    // Already get rid of Bc,C
    if (useiaux[0]==0) 
       free(C.ja);
    else 
       niaux+=C.ia[A.nc];
    if (useiaux[1]==useiaux[0]) 
       free(Bc.ja);
    else 
       niaux+=Bc.ia[A.nc];

    // reorder the system using multilevel nested dissection & minimum degree
    // FORTRAN style
    i=1;
    // default options
    //options[0]=0;
    options[0]=1;
    options[1]=3;
    options[2]=1;
    options[3]=2;
    options[4]=0;
    options[5]=1;
    options[6]=200; 
    options[7]=1; 
    numflag=1;
    cperm=param->ibuff;
    if (D.ia[D.nc]>1)
       METIS_NodeND(&D.nc,D.ia,D.ja, &numflag,options,cperm,invq);
    else
       for (i=0; i<B.nc; i++) 
	   cperm[i]=invq[i]=i+1;
    if (useiaux[3]==useiaux[2]) 
       free(D.ja);
    else 
       niaux+=D.ia[A.nc];



#ifdef PRINT_INFO2
    for (i=0; i<D.nc; i++)
	   printf("%8d",cperm[i]);
    printf("\n\n");
    fflush(stdout);
#endif



    // now insert pressure nodes properly

    // number of nonzero elements per columns can easily be 
    // derived from Bc.ia
    ncolumn=Bc.ia;
    // reuse the pointer space of D.ia for pid
    pid=D.ia;
    for (i=0; i<A.nc; i++) {
        ncolumn[i]=ncolumn[i+1]-ncolumn[i];
	pid[i]=i;
    } // end for i
    ncolumn[A.nc]=A.nc+1;
    pid[A.nc]=A.nc;
    
    j=0;
    for (i=0; i<A.nc; i++) {
        // permutation in FORTRAN style
        qi=cperm[i];
	// consider the next entry from the (1,1) block
	if (param->indicator[qi-1]>=0) {
	   p[j]=qi;

	   // number of neighbours in the (1,2) block
	   nr=Br.ia[qi]-Br.ia[qi-1];

	   // init list
	   nlist=0;

	   // check for entries with same ancestor
	   for (k=Br.ia[qi-1]-1; k<Br.ia[qi]-1; k++) {
	       gr=Br.ja[k]-1;

	       // iterate until a fix point is found
	       while (pid[gr]!=gr) 
		     gr=pid[gr]; 

	       // is there already one node with the same ancestor?
	       if (gr<A.nc) {
		  l=IABS(ind[gr]);
		  if (l)
		     // flag entry gr negative to indicate that the entry
	             // is duplicate
		     list[l-1]=-(gr+1);
		  else { // gr has been discovered for the first time
		     list[nlist++]=gr+1;
		     if (gr==Br.ja[k]-1) 
		        // indicate that Br{qi}(k) is already a fix point
		        ind[gr]=-nlist;
		     else
		        ind[gr]=nlist;
		  } // end if (l)
	       } // end if
	   } // end for k

	   // clear inds and remove negative gr entries
	   k=0;
	   while (k<nlist) {
	         gr=list[k];
		 if (gr>0) {
		    // indicate that Br.ja[k]==gr
		    if (ind[gr-1]<0) {
		       // transfer the negative sign from ind to list
		       // to indicate that Br.ja[k] is already a fix point
		       // since we do not visit this entry anymore during
		       // this while-loop there will be no confusion with 
		       // the former meaning of negative entries in 'list'
		       list[k]=-gr;
		    } // end if
		    // clear ind and advance to the next element
		    ind[gr-1]=0;
		    k++;
		 } // end if
		 else {
		    // this entry occurs at least twice and cannot be used anymore
		    // clear ind and overwrite element by the last element
		    // from the list
		    ind[-gr-1]=0;
		    list[k]=list[--nlist];
		 } // end else
	   } // end while

	   // is there any entry left over that is not a fill?
	   iflag=0;
	   k=0;
	   while (k<nlist) {
	         gr=list[k];
		 if (gr<0) {
		    iflag=-1;
		    k=nr+1;
		 } // end if
		 k++;
	   } // end while
	   // turn off original pressure nodes
	   // iflag=0;
	   
	   minfill=A.nc+1;
	   mingr=A.nc+1;
	   for (k=0; k<nlist; k++) {
	       gr=list[k];
	       // consider non-fill nodes only
	       if (iflag) {
		  if (gr<0) {
		     gr=-gr;
		     if (ncolumn[gr-1]<minfill) {
		        mingr=gr;
			minfill=ncolumn[gr-1];
		     } // end if
		  } // end if
	       }
	       // only fill nodes left over
	       else {
		  gr=IABS(gr);
		  if (ncolumn[gr-1]<minfill) {
		     mingr=gr;
		     minfill=ncolumn[gr-1];
		  } // end if
	       } // end if
	   } // end for k
     

	   // we were not successful in finding a suitable pressure node
	   if (mingr==A.nc+1)
	      j++;
	   else {
	      // insert pressure behind a velocity node
	      p[j+1] = mingr;
	   
	      minfill=A.nc+1;
	      mingr2=A.nc+1;
	      for (k=0; k<nlist; k++) {
		  gr=IABS(list[k]);
		  if (gr!=mingr) {
		     if (ncolumn[gr-1]<minfill) {
		        mingr2=gr;
			minfill=ncolumn[gr-1];
		     } // end if
		     if (gr<A.nc+1) {
		        ncolumn[gr-1]+=ncolumn[mingr-1]-2;
			ncolumn[gr-1]=MIN(ncolumn[gr-1],A.nc);
		     } // end if
		  } // end if
	      } // end for k

	      pid[mingr-1] = pid[mingr2-1];
	      //  perm(j) = j+1; perm(j+1) = j;
	      j +=2;
	   } // end if

	} // end if
    } // end for i




    if (j<A.nc) {
       printf("%d nodes are missing\n",A.nc-j);
       for (i=0; i<j; i++) {
	   ind[p[i]-1]=1;
       }
       i=0;
       for (; j<A.nc; j++) {
	   while (ind[i]!=0)
	         i++;
	   p[j]=++i;
	   // printf("inserting node %d\n",i);
       } // end for j
    } // end if
    /*
function [p,test] = addindefnodes4(B,q)
% function [p,perm,test] = addindefnodes4(B,q)
% insert indefnodes into defnodes-ordering q

[n,m] = size(B);
N = n+m;
% perm = 1:N;
p = ones(1,N);

% count how many nonzeros we have in every row/column
nrow=zeros(n,1);
ncolumn=zeros(m+1,1);
for j=1:m
    I=find(B(:,j));
    nrow(I)=nrow(I)+1;
    ncolumn(j)=length(I);
end % for
ncolumn(m+1)=n+1;
% set up list of pressure nodes
Br=cell(n,1);
nBr=zeros(n,1);
for i=1:n
    Br{i}=zeros(1,nrow(i));
end % for i
for j=1:m
    I=find(B(:,j));
    nBr(I)=nBr(I)+1;
    for i=I'
        Br{i}(nBr(i))=j;
    end
end % for

% for i=1:n
%    norm(Br{i}+find(B(i,:)),1)
% end
% return

ind=zeros(1,m);
list=zeros(1,m);
pid = 1:m+1;
j = 1;
for qi = q
    p(j) = qi;

    % number of neighbours
    nr=nrow(qi);

    % init list
    nlist=0;

    % check for entries with same ancestor
    for k=1:nr
        gr=Br{qi}(k);
	while pid(gr)~=gr
	      gr=pid(gr); 
	end % while
	% is there already one node with the same ancestor?
	if gr<m+1
	   l=abs(ind(gr));
	   if l
	      % flag entry gr negative to indicate that the entry
	      % is duplicate
	      list(l)=-gr;
	   else % gr has been dicsovered for the first time
	      nlist=nlist+1;
	      list(nlist)=gr;
	      if gr==Br{qi}(k)
		 % indicate that Br{qi}(k) is already a fix point
		 ind(gr)=-nlist;
	      else
		 ind(gr)=nlist;
	      end % if-else
	   end % if l
	end % if
    end % for k

    % clear inds and remove negative gr entries
    k=1;
    while k<=nlist
         gr=list(k);
	 if gr>0
	    % indicate that Br{qi}(k)==gr
	    if ind(gr)<0
	       % transfer the negative sign from ind to list
	       % to indicate that Br{qi}(k) is already a fix point
	       % since we do not visit this entry anymore during
	       % this while-loop there will be no confusion with the
	       % former meaning of negative entries in 'list'
	       list(k)=-gr;
	    end % if
	    % clear ind and advance to the next element
	    ind(gr)=0;
	    k=k+1;
	 else
	    % this entry occurs at least twice and cannot be used anymore
	    % clear ind and overwrite element by the last element
	    % from the list
	    ind(-gr)=0;
	    list(k)=list(nlist);
	    nlist=nlist-1;
	 end % if-else
    end % while k
    
    % is there any entry left over that is not a fill?
    flag=0;
    k=1;
    while k<=nlist
          gr=list(k);
	  if gr<0
	     flag=-1;
	     k=nr+1;
	  end % if
	  k=k+1;
    end % while
    % turn off original pressure nodes
    % flag=0;
  
    minfill=n+1;
    mingr=m+1;
    for k=1:nlist
        gr=list(k);
	% consider non-fill nodes only
	if flag 
	   if gr<0 
	      gr=-gr;
	      if ncolumn(gr)<minfill 
		 mingr=gr;
		 minfill=ncolumn(gr);
	      end
	   end
	   % only fill nodes left over
	else 
	   gr=abs(gr);
	   if ncolumn(gr)<minfill
	      mingr=gr;
	      minfill=ncolumn(gr);
	   end
	end % if
    end % for k
     

    % we were not successful in finding a suitable pressure node
    if mingr==m+1
       j=j+1;
    else
       p(j+1) = n + mingr;
	   
       minfill=n+1;
       mingr2=m+1;
       for k=1:nlist
	   gr=abs(list(k));
	   if gr~=mingr
	      if ncolumn(gr)<minfill
		 mingr2=gr;
		 minfill=ncolumn(gr);
	      end
	      if gr<m+1
		 ncolumn(gr)=ncolumn(gr)+ncolumn(mingr)-2;
		 ncolumn(gr)=min(ncolumn(gr),n);
	      end
	   end % if
       end % for k

       pid(mingr) = pid(mingr2);
       % perm(j) = j+1; perm(j+1) = j;
       j = j+2;
    end % if
end % for qi


test=ones(1,m+n); 
test(p)=0; 
p(j:n+m)=find(test);

     */

    
    // inverse permutation
    for (i=0; i<A.nc; i++) {
	invq[p[i]-1]=i+1;
    }



#ifdef PRINT_INFO2
    printf("final permutation\n");fflush(stdout);
    for (i=0; i<A.nc; i++)
        printf("%8d",p[i]);
    printf("\n\n");
    fflush(stdout);
#endif

    *nB=A.nc; 

    return (ierr);
} /* end perm_mc64_metis_n_sp */
