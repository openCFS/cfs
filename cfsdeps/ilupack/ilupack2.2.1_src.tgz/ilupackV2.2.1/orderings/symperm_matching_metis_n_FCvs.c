#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
#define _COMPLEX_SYMMETRIC_
#include "symperm_matching_metis_n_FCv.c"
#else
void myilupackdummy75()
{
}
#endif
