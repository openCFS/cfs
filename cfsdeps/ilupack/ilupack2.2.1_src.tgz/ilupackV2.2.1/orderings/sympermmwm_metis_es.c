#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
#define _COMPLEX_SYMMETRIC_
#include "sympermmwm_metis_e.c"
#else
void myilupackdummy22()
{
}
#endif
