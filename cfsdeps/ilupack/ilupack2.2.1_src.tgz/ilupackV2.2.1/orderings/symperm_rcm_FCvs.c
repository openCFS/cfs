#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
#define _COMPLEX_SYMMETRIC_
#include "symperm_rcm_FCv.c"
#else
void myilupackdummy46()
{
}
#endif
