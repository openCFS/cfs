#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
#define _COMPLEX_SYMMETRIC_
#include "symperm_amd_FCv.c"
#else
void myilupackdummy20()
{
}
#endif
