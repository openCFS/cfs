#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
#define _COMPLEX_SYMMETRIC_
#include "sympermMC64mmd.c"
#else
void myilupackdummy32()
{
}
#endif
