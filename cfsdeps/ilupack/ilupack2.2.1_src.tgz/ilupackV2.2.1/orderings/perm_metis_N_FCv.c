#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

#include <metisord.h>
#include <ilupack.h>

#include <ilupackmacros.h>

#define MAX_LINE        255
#define STDERR          stderr
#define STDOUT          stdout
#define MAX(A,B)        (((A)>(B))?(A):(B))
#define MIN(A,B)        (((A)<(B))?(A):(B))




/*
 scaling and permutation driver, here for multilevel (edge) nested dissection
 with minimum degree from METIS (Karypis & Kumar)

 Given an n x n matrix A in compressed sparse row format this routine computes
 row and column scalings as well as row and column permutations such that

 A -> Dr * A * Dc,
 
 where Dr and Dc are diagonal matrices stored in the vectors proscal and 
 pcoscal. The scaling is explicitly applied to A.

 The permutation p,invq refer to permutation matrices P and Q^{-1} such  that

  P^T*(Dr * A * Dc)*Q  

 is hopefully better suited for the ILU.

 The routine returns a leading block size nB<=n
                        /B F\ 
  P^T*(Dr * A * Dc)*Q = |   | 
                        \E C/
 In this case the permutation recommends that the ILU is only applied to the
 leading block B of size nB x nB


 In particular MMD uses a symmetric reordering that reorders the system
 such that nodes from the elimination graph with lowest degree precede
 those with higher degree which may be advantageous for direct solvers. nB=n
 */
integer PERMMETISNFCV(CSRMAT A, FLOAT *prowscale, FLOAT *pcolscale,
		      integer *p, integer *invq, integer *nB, ILUPACKPARAM *param)

{
/*
    A          n x n matrix in compressed sparse row format
               A is altered by the routine since the scalings are directly
               applied to A. Hopefully the scaling are only powers of 2,
               which is the case for all scaling routines from ILUPACK.

    proscal,   vectors of length n that store the row and column scalings Dr
    pcoscal    and Dc
               A -> Dr*A*Dc

    p,invq     permutation vectors p and q^{-1} of length n which refer to
               row / column permutation matrices P and Q^{-1}.
               P^T*(Dr * A * Dc)*Q hopefully better suited for ILU

    nB         leading blocksize nB
                                     /B F\ 
               P^T*(Dr * A * Dc)*Q = |   |,  B matrix of size nB x nB
                                     \E C/
               nB is the recommended block size for the application of an ILU

    param      ILUPACK parameters
               param->ipar[7] gives information about the requested scaling

               param->ipar[7] &  512       indicates initial preprocessing,
                                           initial permutation routine in
                                           the main ILU driver called AMGFACTOR

               param->ipar[7] & 1024       indicates regular reordering,
                                           the second permutation routine in
                                           the main ILU driver called AMGFACTOR

               param->ipar[7] &  512+1024  indicates final pivoting,
                                           the third permutation routine in
                                           the main ILU driver called AMGFACTOR


               depending on the circumstances (initial preprocessing, regular
               reordering, final pivoting)

               param->ipar[7] & ( 1+  2+  4)   initial preprocessing

               param->ipar[7] & ( 8+ 16+ 32)   regular reordering

               param->ipar[7] & (64+128+256)   final pivoting

               give information on whether row scaling (lowest bit 1,8,64), 
               column scaling (medium bit 2,16,128) should be applied.
               The highest bit (4,32,256) defines the order in which the 
               scalings should be perfomed. If the highest bit is cleared, then
               we start with row scaling.

    
               param->ipar[8] defines the norm that should be used

               param->ipar[8] & (   1+   2+   4+   8+   16)  initial preprocessing

               param->ipar[8] & (  32+  64+ 128+ 256+  512)  regular reordering

               param->ipar[8] & (1024+2048+4096+8192+16384)  final pivoting

               The five bits (values [0,...,31] up to shifts) are used for
               0,1,2          infinity norm, 1-norm, 2-norm
               3              spd scaling using the square root of the diagonal
                              entries

               The scaling routines that are defined with ILUPACK only use
               the nearest powers of 2 for scaling


   interface driver written by Matthias Bollhoefer, July/November 2003
 */

   integer i,j,k,l,scale,nrm,ierr=0, numflag, options[10], iflag;
   size_t mem;
   CSRMAT B;
   REALS val,vb;
   

   // start by rescaling the system, param defines the norms
#include "scaleprefix.c"


   // allocate memory with respect to the specific permutation routine
   param->nibuff=MAX(param->nibuff,(size_t)A.nc+1);
   param->ibuff=(integer *)   REALLOC(param->ibuff,param->nibuff*sizeof(integer),
				  "perm_metis_N:ibuff");


   // build B=|A|+|A^T|
   // param->ibuff will also be used for B.ia!
   // remember that the leading 2n are already in use for symrcm
   // param->iaux will be used for B.ja if possible
   SETUPGRAPH(A,&B, param->ibuff, param->iaux,param->niaux);

   // check if MALLOC was needed to set up B.ja
   if (B.ia[B.nc]<0) {
      iflag=0;
      B.ia[B.nc]=-(B.ia[B.nc]);
   }
   else  {// nz+B.ia[B.nc]-1 entries from iaux were already in use 
      iflag=B.ia[B.nc]-1; 
   }

   // reorder the system using multilevel nested dissection & minimum degree
   /*
   for (i=0; i<=A.nc; i++)
       printf("%4d",B.ia[i]);
   printf("\n");
   for (i=0; i<B.ia[A.nc]-1; i++)
     printf("%4d",B.ja[i]);
   printf("\n");
   */
   // get rid of the diagonal entries
   k=0;
   for (i=0; i<A.nc; i++) {
       l=k;
       for (j=B.ia[i]-1; j<B.ia[i+1]-1;j++) {
	   // diagonal entry
	   if (B.ja[j]==i+1) {
	      // skip diagonal entry
	      k++;
	   }
	   else {
	      // shift diagonal entry
	      B.ja[j-k]=B.ja[j];
	   } // end if
       } // end for j
       B.ia[i]-=l;
   } // end for i
   B.ia[i]-=k;

   /*
   for (i=0; i<=A.nc; i++)
       printf("%4d",B.ia[i]);
   printf("\n");
   for (i=0; i<B.ia[A.nc]-1; i++)
     printf("%4d",B.ja[i]);
   printf("\n");
   printf("Call Metis\n"); fflush(stdout);
   */


   // default options
   //options[0]=0;
   options[0]=1;
   options[1]=3;
   options[2]=1;
   options[3]=2;
   options[4]=0;
   options[5]=1;
   options[6]=200;
   options[7]=1;
   numflag=1;
   // matrix is non-diagonal
   if (B.ia[A.nc]>1)
      METIS_NodeND(&A.nc,B.ia,B.ja, &numflag,options,p,invq);
   else
      for (i=0; i<A.nc; i++) 
	  p[i]=invq[i]=i+1;

   /*
   printf("Metis, done\n"); fflush(stdout);
   for (i=0; i<A.nc; i++)
     printf("%8d",p[i]);
   printf("\n");
   fflush(stdout);
   for (i=0; i<A.nc; i++)
     printf("%8d",invq[i]);
   printf("\n");
   fflush(stdout);
   */

   if (!iflag)
      free(B.ja);

   *nB=A.nc;


   // allocate memory with respect to the specific permutation routine
   param->nibuff=MAX(param->nibuff,9*(size_t)A.nc+3);
   param->ibuff=(integer *)   REALLOC(param->ibuff,param->nibuff*sizeof(integer),
				  "permFC:ibuff");

   param->ndbuff=MAX(param->ndbuff,2*(size_t)A.nc);
   param->dbuff=(FLOAT *) REALLOC(param->dbuff,param->ndbuff*sizeof(FLOAT),
				  "permFC:dbuff");

   for (i=0; i<A.nc; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
       param->testvector[i]/=pcolscale[i];
#else
       val=1.0/(pcolscale[i].r*pcolscale[i].r +
		pcolscale[i].i*pcolscale[i].i);
       vb=param->testvector[i].r;
       param->testvector[i].r=(                     vb*pcolscale[i].r
	                       +param->testvector[i].i*pcolscale[i].i)*val;
       param->testvector[i].i=(                    -vb*pcolscale[i].i
		 	       +param->testvector[i].i*pcolscale[i].r)*val;
#endif
   }

   // call indFCv
   INDFCV(A, param->ibuff+A.nc,param->ibuff,nB,  1.0/param->fpar[2],
	  param->testvector,1,
	  (REALS *)param->dbuff,param->ibuff+2*A.nc);

   for (i=0; i<A.nc; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
       param->testvector[i]*=pcolscale[i];
#else
       vb=param->testvector[i].r;
       param->testvector[i].r=                     vb*pcolscale[i].r
	                      -param->testvector[i].i*pcolscale[i].i;
       param->testvector[i].i=                     vb*pcolscale[i].i
		 	      +param->testvector[i].i*pcolscale[i].r;
#endif
   }

   k=0;
   l=0;
   for (i=0; i<A.nc; i++) {
       j=p[i];
       if (param->ibuff[j-1]<=*nB) {
	  param->ibuff[A.nc+k]=j;
	  k++;
       }
       else {
	  param->ibuff[2*A.nc+l]=j;
	  l++;
       }
   }
   for (i=0; i<*nB; i++)
       p[i]=param->ibuff[A.nc+i];
   for (l=0; i<A.nc; i++,l++)
       p[i]=param->ibuff[2*A.nc+l];

   for (i=0; i<A.nc; i++)
       invq[p[i]-1]=i+1;

   return (ierr);
}
