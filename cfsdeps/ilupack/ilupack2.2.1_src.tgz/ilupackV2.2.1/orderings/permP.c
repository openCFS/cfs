#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>

#include <ilupack.h>

#include <ilupackmacros.h>

#define MAX_LINE        255
#define STDERR          stdout
#define STDOUT          stdout
#define PRINT_INFO
#define MAX(A,B)        (((A)>(B))?(A):(B))
#define MIN(A,B)        (((A)<(B))?(A):(B))





integer PERMP(CSRMAT A, FLOAT *prowscale, FLOAT *pcolscale, 
	  integer *p, integer *invq, integer *nB, ILUPACKPARAM *param)
{
   integer i,j,k,scale,nrm,ierr=0;


#include "scaleprefix.c"


    param->nibuff=MAX(param->nibuff,8*(size_t)A.nc);
    param->ibuff=(integer *)   REALLOC(param->ibuff,param->nibuff*sizeof(integer),
				   "permP:ibuff");

#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
    param->ndbuff=MAX(param->ndbuff,5*(size_t)A.nc);
    param->dbuff=(FLOAT *)  REALLOC(param->dbuff,param->ndbuff*sizeof(FLOAT),
				    "permP:dbuff");
#else
    // 5*n REALS <= 3*n COMPLEX spaces required 
    param->ndbuff=MAX(param->ndbuff,MAX(3,(5*sizeof(REAL))/sizeof(FLOAT))*(size_t)A.nc);
    param->dbuff=(FLOAT *)  REALLOC(param->dbuff,param->ndbuff*sizeof(FLOAT),
				    "permP:dbuff");
#endif


   PPERM(A, 50, param->ibuff, invq, nB, 0.5,param->dbuff,param->ibuff+2*A.nc);
   for (i=0; i<A.nc; i++) {
       p[param->ibuff[i]]=i;
   }
   for (i=0; i<A.nc; i++) {
       invq[i]++;
       p[i]++;
   }

   return (ierr);
}
