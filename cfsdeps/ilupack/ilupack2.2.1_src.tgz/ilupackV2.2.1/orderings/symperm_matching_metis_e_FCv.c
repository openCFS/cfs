#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include <blas.h>
#include <mumps_matching.h>
#include <metisord.h>
#include <ilupack.h>

#include <ilupackmacros.h>

#define MAX(A,B)        (((A)>(B))?(A):(B))
#define MIN(A,B)        (((A)<(B))?(A):(B))
#define STDERR          stderr
#define STDOUT          stdout
#define _PIND_FC_

// #define PRINT_INFO


#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
#define CONJG(A)      (A)

#ifdef _SKEW_MATRIX_

#ifdef _DOUBLE_REAL_
#define MYSYMINDFCV                 DSSMindfcv
#define MYSYMPINDFCV                DSSMpindfcv
#define MYSYMMWM                    DSSMsmwm
#define MYSYMPERMMATCHINGMETISEFCV  DSSMperm_matching_metis_e_fcv

#else
#define MYSYMINDFCV            SSSMindfcv
#define MYSYMPINDFCV           SSSMpindfcv
#define MYSYMMWM              SSSMsmwm
#define MYSYMPERMMATCHINGMETISEFCV  SSSMperm_matching_metis_e_fcv
#endif

#define SKEW(A)      (-(A))

#else

#ifdef _DOUBLE_REAL_
#define MYSYMINDFCV            DSYMindfcv
#define MYSYMPINDFCV           DSYMpindfcv
#define MYSYMMWM              DSYMsmwm
#define MYSYMPERMMATCHINGMETISEFCV  DSYMperm_matching_metis_e_fcv
#else
#define MYSYMINDFCV            SSYMindfcv
#define MYSYMPINDFCV           SSYMpindfcv
#define MYSYMMWM              SSYMsmwm
#define MYSYMPERMMATCHINGMETISEFCV  SSYMperm_matching_metis_e_fcv
#endif

#define SKEW(A)      (A)
#endif
// end _SKEW_MATRIX_


#else

#ifdef _COMPLEX_SYMMETRIC_
#define CONJG(A)     (A)

#ifdef _SKEW_MATRIX_
#define SKEW(A)      (-(A))

#ifdef _SINGLE_COMPLEX_
#define MYSYMINDFCV            CSSMindfcv
#define MYSYMPINDFCV           CSSMpindfcv
#define MYSYMMWM              CSSMsmwm
#define MYSYMPERMMATCHINGMETISEFCV  CSSMperm_matching_metis_e_fcv
#else
#define MYSYMINDFCV            ZSSMindfcv
#define MYSYMPINDFCV           ZSSMpindfcv
#define MYSYMMWM              ZSSMsmwm
#define MYSYMPERMMATCHINGMETISEFCV  ZSSMperm_matching_metis_e_fcv
#endif

#else
#define SKEW(A)      (A)

#ifdef _SINGLE_COMPLEX_
#define MYSYMINDFCV            CSYMindfcv
#define MYSYMPINDFCV           CSYMpindfcv
#define MYSYMMWM              CSYMsmwm
#define MYSYMPERMMATCHINGMETISEFCV  CSYMperm_matching_metis_e_fcv
#else
#define MYSYMINDFCV            ZSYMindfcv
#define MYSYMPINDFCV           ZSYMpindfcv
#define MYSYMMWM              ZSYMsmwm
#define MYSYMPERMMATCHINGMETISEFCV  ZSYMperm_matching_metis_e_fcv
#endif

#endif
// end _SKEW_MATRIX_


#else
#define CONJG(A)     (-(A))

#ifdef _SKEW_MATRIX_
#define SKEW(A)      (-(A))

#ifdef _SINGLE_COMPLEX_
#define MYSYMPINDFCV           CSHRpindfcv
#define MYSYMMWM              CSHRsmwm
#define MYSYMPERMMATCHINGMETISEFCV  CSHRperm_matching_metis_e_fcv
#else
#define MYSYMPINDFCV           ZSHRpindfcv
#define MYSYMMWM              ZSHRsmwm
#define MYSYMPERMMATCHINGMETISEFCV  ZSHRperm_matching_metis_e_fcv
#endif

#else
#define SKEW(A)      (A)

#ifdef _SINGLE_COMPLEX_
#define MYSYMPINDFCV           CHERpindfcv
#define MYSYMMWM              CHERsmwm
#define MYSYMPERMMATCHINGMETISEFCV  CHERperm_matching_metis_e_fcv
#else
#define MYSYMPINDFCV           ZHERpindfcv
#define MYSYMMWM              ZHERsmwm
#define MYSYMPERMMATCHINGMETISEFCV  ZHERperm_matching_metis_e_fcv
#endif

#endif
// end _SKEW_MATRIX_

#endif
// end _COMPLEX_SYMMETRIC_

#endif
// end _DOUBLE_REAL_


/*
 scaling and permutation driver, followed by a symmetric reordering.

 here 1) maximum weight matching (MUMPS)
      3) associated symmetric block partitioning and block reordering by
         I.S. Duff and S. Pralet
      2) MeTis multilevel nested dissection by nodes


 Given an n x n matrix A in compressed sparse row format this routine computes
 row and column scalings as well as row and column permutations such that

 A -> Dr * A * Dc,
 
 where Dr and Dc are diagonal matrices stored in the vectors proscal and 
 pcolscale. The scaling is explicitly applied to A.

 The permutation p,invq refer to permutation matrices P and Q^{-1} such  that

  P^T*(Dr * A * Dc)*Q 

 is hopefully better suited for the ILU.

 The routine returns a leading block size nB<=n
                        /B F\ 
  P^T*(Dr * A * Dc)*Q = |   | 
                        \E C/
 In this case the permutation recommends that the ILU is only applied to the
 leading block B of size nB x nB
 */
integer MYSYMPERMMATCHINGMETISEFCV(CSRMAT A, FLOAT *prowscale, FLOAT *pcolscale, 
		     integer *p, integer *invq, integer *nB, ILUPACKPARAM *param)
{
/*
    A          n x n matrix in compressed sparse row format
               A is altered by the routine since the scalings are directly
               applied to A. Hopefully the scaling are only powers of 2,
               which is the case for all scaling routines from ILUPACK.

    prowscale,   vectors of length n that store the row and column scalings Dr
    pcolscale    and Dc
               A -> Dr*A*Dc

    p,invq     permutation vectors p and q^{-1} of length n which refer to
               row / column permutation matrices P and Q^{-1}.
               P^T*(Dr * A * Dc)*Q hopefully better suited for ILU

    nB         leading blocksize nB
                                     /B F\ 
               P^T*(Dr * A * Dc)*Q = |   |,  B matrix of size nB x nB
                                     \E C/
               nB is the recommended block size for the application of an ILU

    param      ILUPACK parameters


    interface driver written by Matthias Bollhoefer, April 2008
 */ 

    integer  i,ii,j,k,l,m,imx,n=A.nr,liw,*iw,ldw,info[10],icntl[10],*cperm,job,
         iflag, num,nz,ierr=0,options[10], numflag, scale, pow,nrm;
    REALS mxr, lg2=1.0/log((double)2.0), fpow, val, vb;
    REALS *scal, a, *b=NULL;
    FLOAT  *w,*dw,mx;
    size_t mem;
    CSRMAT B, C;

    ierr=0;
    /* --------------------   END set up parameters   -------------------- */

    // PARDISO maximum weight matching interface
    param->ndbuff=MAX(param->ndbuff,(2*(size_t)A.nc*MAX(sizeof(FLOAT),sizeof(double))/sizeof(double)));
    param->dbuff=(FLOAT *) REALLOC(param->dbuff,param->ndbuff*sizeof(FLOAT),
				  "symperm_matching_metis_e_FCv:dbuff");

#include "scaleprefix.c"

    // use unsymmetric version of A for maximum weight matching
    // build B=|A|+|A^T|
    param->nibuff=MAX(param->nibuff,3*(size_t)A.nc+2);
    param->ibuff=(integer *) REALLOC(param->ibuff,param->nibuff*sizeof(integer),
				 "symperm_matching_metis_e_FCv:ibuff");
    // param->ibuff (2n+1) will be used indicate the pruned parts of A, but 
    // also be used for B.ia!
    // param->iaux will be used for B.ja, if possible
    // dbuff (n) will be used to compute the maximum absolute entry per row.
    SETUPGRAPH_EPSILON(A,&B,(REALS)MC64THRESHOLD,
		       (REALS *)param->dbuff, param->ibuff, 
		       param->iaux, param->niaux);

    // check if MALLOC was needed to set up B.ja
    if (B.ia[B.nc]<0) {
       iflag=0;
       B.ia[B.nc]=-(B.ia[B.nc]);
    }
    else // nz entries from iaux are already in use 
       iflag=B.ia[B.nc]-1; 
    nz=A.ia[A.nc]-1;


    // memory for the unsymmetric version of A
    if ((param->ndaux*sizeof(REALS))/sizeof(FLOAT)>=B.ia[n]-1) 
       b=(REALS *)param->daux;
    else
       b=(REALS *)MALLOC((size_t)(B.ia[n]-1)*sizeof(REALS),"symperm_matching_metis_e_FCv:b");

    /*--------------------  actual copying  */
    iw=B.ia;
    for (i=0; i<A.nc; i++) {
        // copy indices
        for (j=A.ia[i]-1; j<param->ibuff[i]-1; j++) {
	    // current column index of row i in FORTRAN style
	    k=A.ja[j]-1;
	    // for minimum weight matching the PARDISO interface requires a 
	    // real-valued matrix in REALS precision 
	    a=FABS(A.a[j]);
	    b[iw[i]-1]=a;
	    // advance pointer
	    iw[i]++;
	    // avoid duplicate entries
	    if (k!=i) {
	       b[iw[k]-1]=a;
	       // advance pointer
	       iw[k]++;
	    } // end if
	} // end for j
    } // end for i
    // shift iw back
    for (i=A.nc; i>0; i--) 
        iw[i]=iw[i-1];
    iw[0]=1;


    // maximum weight matching
    scal=(REALS *)param->dbuff;
#ifdef PRINT_INFO
    printf("call MUMPS matching routine\n");fflush(stdout);
#endif
    /*
    ierr = mps_pardiso(     A.nr, B.ia,B.ja,b, p, scal+n,scal, 0);
    */
    nz=B.ia[B.nc]-1;
    MUMPS_MATCHR(&(B.nc), &nz, p,B.ia,B.ja,b, scal, scal+n);
    nz=A.ia[A.nc]-1;

    // values of the unsymmetric version are not longer needed
    if ((param->ndaux*sizeof(REALS))/sizeof(FLOAT)<B.ia[n]-1) 
       free(b);
    if (!iflag)
       free(B.ja);


    // build left and right diagonal scaling derived from the matching
    for (i=0; i<n; i++) {
	mxr=sqrt(scal[i]*scal[n+i]);
	// compute nearest power of 2
	fpow=log(mxr)*lg2;
	if (fpow<0.0) {
	   pow=fpow-0.5;
	   fpow=1;
	   for (l=1; l<=-pow; l++)
	       fpow*=2.0;
	   mxr=1.0/fpow;
	}
	else {
	   pow=fpow+0.5;
	   fpow=1;
	   for (l=1; l<=pow; l++)
	       fpow*=2;
	   mxr=fpow;
	}
	scal[i]=mxr;
    } // end for i

    // transfer scaling to the official interface vectors
    for (i=0; i<A.nr; i++){
#if defined _DOUBLE_REAL_ || defined  _SINGLE_REAL_
	pcolscale[i]*=scal[i];
#else
	pcolscale[i].r*=scal[i];
	pcolscale[i].i=0;
#endif
    } // end for i


    // rescale matrix explicitly
    for (i=0; i<n; i++){
        for (j=A.ia[i]-1;j<A.ia[i+1]-1;j++){
#if defined _DOUBLE_REAL_ || defined  _SINGLE_REAL_
	    A.a[j]=scal[i]*A.a[j]*scal[A.ja[j]-1];
#else
	    A.a[j].r=scal[i]*A.a[j].r*scal[A.ja[j]-1];
	    A.a[j].i=scal[i]*A.a[j].i*scal[A.ja[j]-1];
#endif
	} // end for j
    } // end for i


#ifdef PRINT_INFO
    for (i=0; i<n; i++)
        for (j=A.ia[i];j<A.ia[i+1];j++)
	    printf("%8d%8d%16.8le\n",i+1, A.ja[j-1],A.a[j-1]);
    printf("\n");
    fflush(stdout);
    for (i=0; i<A.nc; i++) 
        printf("%8d",p[i]);
    printf("\n");
    fflush(stdout);
#endif



    // compute symmetric weighted matching, i.e. break cycles into
    // 1x1 and 2x2 cycles
    // PARDISO maximum weight matching interface
    l=MYSYMMWM(A, p, param->ibuff, param->dbuff);
    


#ifdef PRINT_INFO
    for (i=0; i<A.nr; i++)
      printf("%8d",p[i]);
    printf("\n");
    fflush(stdout);
#endif


    // reorder the pattern of A by rows in order to apply a symbolic reordering
    // allocate memory with respect to the specific permutation routine
    // param->nibuff=MAX(param->nibuff,2*(size_t)A.nc+1);
    // param->ibuff=(integer *) REALLOC(param->ibuff,param->nibuff*sizeof(integer),
    //			 "symperm_matching_metis_e_FCv:ibuff");
    

    // reorder the rows and columns of A, at least the pattern of it
    // inverse permutation
    cperm=param->ibuff+A.nc+1;
    for (i=0; i<A.nc; i++)
        cperm[p[i]-1]=i+1;
    C.nc=C.nr=A.nr;
    C.a=NULL;
    C.ia=param->ibuff;
    if (param->niaux>=nz)
       C.ja=param->iaux;
    else
       C.ja=(integer *)MALLOC((size_t)nz*sizeof(integer), "symperm_matching_metis_e_FCv:C.ja");
    C.ia[0]=1;


    for (i=0; i<A.nc; i++) {
        ii=p[i]-1;
	k=C.ia[i]-1;
	for (j=A.ia[ii]; j<A.ia[ii+1]; j++) {
	    C.ja[k++]=cperm[A.ja[j-1]-1];
	}
	C.ia[i+1]=C.ia[i]+ (A.ia[ii+1]-A.ia[ii]);
    }


    // compress matrix
    // the leading l rows correspond to 1x1 pivots
    for (i=0; i<l; i++)
        cperm[i]=i+1;
    j=l;
    for (; i<A.nc; i+=2)
        cperm[i]=cperm[i+1]=++j;


    // shift column indices
    for (i=0; i<nz; i++)
        C.ja[i]=cperm[C.ja[i]-1];


    // buffer for flags
    for (i=0; i<A.nc; i++)
        cperm[i]=0;
    // skip duplicate entries in the leading l rows
    k=0;
    for (i=0; i<l; i++) {
        // old start of row i
        j=C.ia[i]-1;
	// new start of row i
	C.ia[i]=k+1;
        for (; j<C.ia[i+1]-1; j++) {
	    ii=C.ja[j]-1;
	    // entry is not duplicate yet
	    if (!cperm[ii]) {
	       // check mark
	       cperm[ii]=-1;
	       // shift entry
	       C.ja[k++]=ii+1;
	    }
	}
	// clear check mark array
        for (j=C.ia[i]-1; j<k; j++) {
	    ii=C.ja[j]-1;
	    cperm[ii]=0;
	}
    }
    // merge duplicate entries and rows in the remaining  n-l rows
    m=l;
    for (; i<A.nc; i+=2,m++) {
        // old start of row i
        j=C.ia[i]-1;
	// new start of row i
	C.ia[m]=k+1;
        for (; j<C.ia[i+2]-1; j++) {
	    ii=C.ja[j]-1;
	    // entry is not duplicate yet
	    if (!cperm[ii]) {
	       // check mark
	       cperm[ii]=-1;
	       // shift entry
	       C.ja[k++]=ii+1;
	    }
	}
	// clear check mark array
        for (j=C.ia[m]-1; j<k; j++) {
	    ii=C.ja[j]-1;
	    cperm[ii]=0;
	}
    }
    C.ia[m]=k+1;
    C.nc=C.nr=m;



#ifdef PRINT_INFO
    for (i=0; i<C.nc; i++)
        for (j=C.ia[i];j<C.ia[i+1];j++)
	    printf("%8d%8d%16.8le\n",i+1, C.ja[j-1],-1.0);
    printf("\n");
    fflush(stdout);
#endif



    // build symmetric undirected graph
    B.nc=B.nr=C.nc;
    // param->ibuff+2n+1 will also be used for B.ia!
    // remember that the leading 2n+1 are already in use for C.ia and cperm
    // the leading C.ia[C.nc]-1 entries of param->iaux will be used for C.ja,
    // if possible
    mem=(param->niaux>=C.ia[C.nc]-1) ? param->niaux-(C.ia[C.nc]-1) : 0;
    SETUPGRAPH(C,&B, param->ibuff+2*A.nc+1, 
	       param->iaux +(C.ia[C.nc]-1),mem);

    // release memory for reordered pattern
    if (param->niaux<nz)
       free(C.ja);

    // check if MALLOC was needed to set up B.ja
    if (B.ia[B.nc]<0) {
       iflag=0;
       B.ia[B.nc]=-(B.ia[B.nc]);
    }
    else  {// nz+B.ia[B.nc]-1 entries from iaux were already in use 
       iflag=B.ia[B.nc]-1; 
    }


#ifdef PRINT_INFO
    for (i=0; i<B.nc; i++)
        for (j=B.ia[i];j<B.ia[i+1];j++)
	    printf("%8d%8d%16.8le\n",i+1, B.ja[j-1],-1.0);
    printf("\n");
    fflush(stdout);
#endif



    // get rid of the diagonal entries
    k=0;
    for (i=0; i<B.nc; i++) {
        ii=k;
	for (j=B.ia[i]-1; j<B.ia[i+1]-1;j++) {
	    // diagonal entry
	    if (B.ja[j]==i+1) {
	       // skip diagonal entry
	       k++;
	    }
	    else {
	       // shift diagonal entry
	       B.ja[j-k]=B.ja[j];
	    } // end if
	} // end for j
	B.ia[i]-=ii;
    } // end for i
    B.ia[i]-=k;
	

    // reorder the system using multilevel nested dissection & minimum degree
    // FORTRAN style
    i=1;
    // default options
    options[0]=0;
    numflag=1;
    cperm=param->ibuff+A.nc+1;
    if (B.ia[B.nc]>1)
       METIS_EdgeND(&B.nc,B.ia,B.ja, &numflag,options,cperm,invq);
    else
       for (i=0; i<B.nc; i++) 
	   cperm[i]=invq[i]=i+1;
    if (!iflag)
       free(B.ja);



#ifdef PRINT_INFO
    for (i=0; i<B.nc; i++)
        printf("%8d",cperm[i]);
    printf("\n\n");
    fflush(stdout);
#endif



    // prolongate permutation to its original size
    j=0;
    for (i=0;i<B.nc; i++)
        // 1x1 block
        if (cperm[i]<=l)
	   param->ibuff[j++]=cperm[i];
        else { // 2x2 block
	   param->ibuff[j]=2*cperm[i]-l-1;
	   param->ibuff[j+1]=param->ibuff[j]+1;
	   j+=2;
	}



#ifdef PRINT_INFO
    printf("block permutation\n");fflush(stdout);
    for (i=0; i<A.nc; i++)
        printf("%8d",param->ibuff[i]);
    printf("\n\n");
    fflush(stdout);
#endif


    
    // build product permutation for the rows (minimum weighted matching followed 
    //                                         symmetric reordering)
    for (i=0; i<n; i++) {
        cperm[i]=p[param->ibuff[i]-1];
    }
    // rewrite permutation
    for (i=0; i<n; i++) {
	p[i]=cperm[i];
    }
    // inverse permutation
    for (i=0; i<n; i++) {
	invq[p[i]-1]=i+1;
    }



#ifdef PRINT_INFO
    printf("final permutation\n");fflush(stdout);
    for (i=0; i<A.nc; i++)
        printf("%8d",p[i]);
    printf("\n\n");
    fflush(stdout);
#endif

    *nB=A.nc; 

   // allocate memory with respect to the specific permutation routine
   param->nibuff=MAX(param->nibuff,10*(size_t)A.nc+3);
   param->ibuff=(integer *)   REALLOC(param->ibuff,param->nibuff*sizeof(integer),
				  "symperm_matching_metis_e_FCv:ibuff");

   param->ndbuff=MAX(param->ndbuff,8*(size_t)A.nc);
   param->dbuff=(FLOAT *) REALLOC(param->dbuff,param->ndbuff*sizeof(FLOAT),
				  "symperm_matching_metis_e_FCv:dbuff");


   for (i=0; i<A.nc; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
       param->testvector[i]/=pcolscale[i];
#else
       val=1.0/(pcolscale[i].r*pcolscale[i].r +
		pcolscale[i].i*pcolscale[i].i);
       vb=param->testvector[i].r;
       param->testvector[i].r=(                     vb*pcolscale[i].r
	                       +param->testvector[i].i*pcolscale[i].i)*val;
       param->testvector[i].i=(                    -vb*pcolscale[i].i
		 	       +param->testvector[i].i*pcolscale[i].r)*val;
#endif
   }



#ifdef _PIND_FC_
   // call sympindFCv
   MYSYMPINDFCV(A, p,invq, param->ibuff+A.nc,param->ibuff,nB,  1.0/param->fpar[2],
		param->testvector,1,
		(REALS *)param->dbuff,param->ibuff+2*A.nc,param->dbuff+4*A.nc);

   // compose both permutations.
   k=0;
   for (i=0; i<A.nc; i++) 
       if (param->ibuff[i]<=*nB) 
	  param->ibuff[A.nc+k++]=p[i];
   for (i=0; i<A.nc; i++) 
       if (param->ibuff[i]>*nB) 
	  param->ibuff[A.nc+k++]=p[i];
   for (i=0; i<A.nc; i++)
       p[i]=param->ibuff[A.nc+i];

#else
   // call symindFCv
   MYSYMINDFCV(A, param->ibuff+A.nc,param->ibuff,nB,  1.0/param->fpar[2],
	       param->testvector,1,
	      (REALS *)param->dbuff,param->ibuff+2*A.nc);

   k=0;
   l=0;
   for (i=0; i<A.nc; i++) {
       j=p[i];
       if (param->ibuff[j-1]<=*nB) {
	  param->ibuff[A.nc+k]=j;
	  k++;
       }
       else {
	  param->ibuff[2*A.nc+l]=j;
	  l++;
       }
   }
   for (i=0; i<*nB; i++)
       p[i]=param->ibuff[A.nc+i];
   for (l=0; i<A.nc; i++,l++)
       p[i]=param->ibuff[2*A.nc+l];
#endif

   for (i=0; i<A.nc; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
       param->testvector[i]*=pcolscale[i];
#else
       vb=param->testvector[i].r;
       param->testvector[i].r=                     vb*pcolscale[i].r
	                      -param->testvector[i].i*pcolscale[i].i;
       param->testvector[i].i=                     vb*pcolscale[i].i
		 	      +param->testvector[i].i*pcolscale[i].r;
#endif
   }


   for (i=0; i<A.nc; i++)
       invq[p[i]-1]=i+1;

    return (ierr);
} /* end symperm_matching_metis_e_FCv */
