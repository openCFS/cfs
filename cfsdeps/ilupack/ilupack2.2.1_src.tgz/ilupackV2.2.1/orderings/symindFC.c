#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>

#include <sparspak.h>
#include <ilupack.h>

#include <ilupackmacros.h>

#define MAX_LINE        255
#define STDERR          stderr
#define STDOUT          stdout
#define MAX(A,B)        (((A)>(B))?(A):(B))
#define MIN(A,B)        (((A)<(B))?(A):(B))
//#define PRINT_INFO




/*
 scaling and permutation driver, here for partial reordering that divides
 the total set of nodes into fine grid nodes (F-points) and coarse grid
 nodes (C-points). The F-points precede the C-points. Strategy is similar
 to the Ruge-Stueben coarsening strategy.

 Given an n x n matrix A in compressed sparse row format this routine computes
 row and column scalings as well as row and column permutations such that

 A -> Dr * A * Dc,
 
 where Dr and Dc are diagonal matrices stored in the vectors proscal and 
 pcoscal. The scaling is explicitly applied to A.

 The permutation p,invq refer to permutation matrices P and Q^{-1} such  that

  P^T*(Dr * A * Dc)*Q 

 is hopefully better suited for the ILU.

 The routine returns a leading block size nB<=n
                        / B  F\ 
  P^T*(Dr * A * Dc)*Q = |     | 
                        \F^T C/
 In this case the permutation recommends that the ILU is only applied to the
 leading block B of size nB x nB

 We typically have nB<<n
 */
void SYMINDFC(CSRMAT A, integer *p,integer *invq, integer *nB, REALS tol, REALS *dbuff,integer *ibuff)
{
/*
    A          n x n matrix in compressed sparse row format
               A is altered by the routine since the scalings are directly
               applied to A. Hopefully the scaling are only powers of 2,
               which is the case for all scaling routines from ILUPACK.

    p,invq     permutation vectors p and q^{-1} of length n which refer to
               row / column permutation matrices P and Q^{-1}.
               P^T*(Dr * A * Dc)*Q hopefully better suited for ILU

    nB         leading blocksize nB
                                     /B F\ 
               P^T*(Dr * A * Dc)*Q = |   |,  B matrix of size nB x nB
                                     \E C/
               nB is the recommended block size for the application of an ILU

    dbuff      real buffer of size 3*n
    ibuff      integer buffer of size 7*n+3
 */

  integer  i,j,jj,k,kk,l,m, bnd,bndt,scale,nrm, ierr=0,
       nC=0, nF=0, nU=A.nr, lm, maxlm, *S, *ST,
       // weights(n) for coarsening
       *lambda=ibuff, 
       // double linked list(n), successor
       *next  =ibuff+A.nr, 
       // double linked list(n), predecessor
       *prev  =ibuff+2*A.nr, 
       // entry points (n+1) for the linked lists
       *first =ibuff+3*A.nr,
       // pointer(n+1) to the strong connections
       *nS    =ibuff+4*A.nr+1,
       // pointer(n+1) to the adjoint strong connections
       *nST   =ibuff+5*A.nr+2,
       // check mark array(n)
       *mark  =ibuff+6*A.nr+3;

   REALS sm,sm2, sigma, x, 
         // largest off-diagonal entry(n) in modulus, row-wise
         *mx   =dbuff, 
         // absolute value of the diagonal entry(n)
         *adiag=dbuff+A.nc,
         // row sums in absolute value
         *sum  =dbuff+2*A.nc;

   //  variables needed for the second part of the Ruge/Stueben AMG
   integer  nCi,nDsi,tCi,nCiCj, cnt,cntj,
        // strong connections of node i located in the coarse grid
        *Ci  =ibuff, 
        // strong F-F connections
        *Dsi =ibuff+A.nr,
        // intersection of strong coarse grid connections of i and j
        *CiCj=ibuff+2*A.nr;



   for (i=0; i<A.nc; i++) {
       invq[i]=ibuff[i]=0;
       mx[i]=0.0;
       adiag[i]=0.0;
   }

   // determine rows and columns that have extremely many nonzeros
   for (i=0; i<A.nc; i++) {
       for (j=A.ia[i]; j<A.ia[i+1]; j++) {
	   // column index A(i,k), C-style
	   k=A.ja[j-1]-1;

	   // compute maximum off-diagonal entry
	   x=FABS(A.a[j-1]);
	   if (k!=i) {
	      // increment number of nonzeros
	      ibuff[k]++;
	      if (x>mx[i])
		 mx[i]=x;
	      // remember that only the upper triangular part is stored
	      if (x>mx[k])
		 mx[k]=x;
	   } // end if
	   else
	      adiag[i]=x;
       } // end for j
   } // end for i
   // remember that only the upper triangular part is stored
   for (i=0; i<A.nc; i++) 
       ibuff[i]+=A.ia[i+1]-A.ia[i];

   // arithmetic mean: nnz/n */
   x=2*(A.ia[A.nc]-1)/((REALS)A.nc);
   // compute standard deviation
   sm=0; sm2=0;
   j=0;
   for (i=0; i<A.nc; i++) {
       k=ibuff[i];
       sm+=k;
       sm2+=k*k;
   } // end for i
   // standard deviation by row/column
   sigma=sqrt((sm2+A.nc*x*x-2.0*x*sm)/A.nc); 

   /* now put those rows/columns to the coarse grid that have too many
      nonzeros or which have diagonal entries that are too small 
   */
   bnd =MAX(3*x,x+3*(sigma +1));
   for (i=0; i<A.nc; i++) {
       if (ibuff[i]>bnd || adiag[i]<tol*mx[i]) {
	  // coarse grid nodes are put to the end
	  invq[i]=A.nc-nC++;
	  p[A.nc-nC]=i+1;
	  nU--;
       } // end if
   } // end for i

   // next move those nodes to the fine grid that are strongly diagonal
   // dominant
   for (i=0; i<A.nc; i++)
       sum[i]=0.0;
   // first compute the column sums
   for (i=0; i<A.nc; i++) {
       if (!invq[i]) {
	  for (j=A.ia[i]; j<A.ia[i+1]; j++) {
	      // associated column index
	      k=A.ja[j-1]-1;
	      // exclude diagonal entry
	      if (i!=k)
		 sum[k]+=FABS(A.a[j-1]);
	  } // end for j
       } // end if
   } // end for i

   for (i=0; i<A.nc; i++) {
       if (!invq[i]) {
	  x=0.0;
	  for (j=A.ia[i]; j<A.ia[i+1]; j++)
	      x+=FABS(A.a[j-1]);
	  // add column sums
	  x+=sum[i];
	  // diagonal entry strongly dominates the off-diagonal sum
	  if ((1.0-tol)*adiag[i]>(x-adiag[i])) {
	     // fine grid nodes are put to the front
	     p[nF++]=i+1;
	     invq[i]=nF;
	     nU--;
	  } // end if
       } // end if
   } // end for i

#ifdef PRINT_INFO
   printf("nC=%5d,nF=%d,nU=%5d, nC+nF+nU=%5d\n",nC,nF,nU,nC+nF+nU);

   printf("%5d current fine grid nodes\n",nF);
   for (i=0; i<nF; i++)
     printf("%8d",p[i]);
   printf("\n\n");
   printf("%5d current coarse grid nodes\n",nC);
   for (i=A.nc-1; i>=A.nc-nC; i--)
     printf("%8d",p[i]);
   printf("\n\n");
#endif

   // FIRST PART of the Rugen-Stueben fine/coarse grid selection

   /* ---------------------   Set up strong connection   ---------------------
      Now, after all poor entries are moved to the coarse grid and all
      strong entries are put to the fine grid, set up strong and adjoint
      strong connections
  
      We need two passes.
      1. the first pass essentially counts how many strong connections
         and adjoint connections do exist for any node
      Then the memory is allocated
      2. the second pass repeats the process and generates the sets
   */

   nS++; nST++;
   for (i=0; i<A.nc; i++)
       lambda[i]=nS[i]=nST[i]=0;

   // first pass
   for (i=0; i<A.nc; i++) {
       // strong connections of node i
       x=tol*mx[i];
       for (j=A.ia[i]; j<A.ia[i+1]; j++) {
	   // column index A(i,k), FORTRAN-style
	   k=A.ja[j-1];
	   // make sure that the diagonal entry is excluded
	   if (k-1!=i) {
	      // strong connection found, row-wise
	      /* in contrast to the original Ruge-Stueben AMG we do not
		 compare -A(i,j) >=max_j |A(i,j)|, but here we use 
		         |A(i,j)|>=max_j |A(i,j)|.
		 We are not seeking really for a good interpolation, but for
		 a reasonable partitioning into fine/coarse grid nodes 
		 suitable for our multilevel ILU
	      */ 
	      if (FABS(A.a[j-1])>=x) { 
		 // only those strong neighbors count as 'strong', that do not
	         // belong to the coarse grid yet
 		 if (invq[k-1]<=A.nc-nC)
		    nS[i]++;
		 
		 // adjoint strong connections
		 nST[k-1]++;
	      } // end if

	      // strong connection found, column-wise
	      if (FABS(A.a[j-1])>=tol*mx[k-1]) { 
		 // only those strong neighbors count as 'strong', that do not
	         // belong to the coarse grid yet
 		 if (invq[i]<=A.nc-nC)
		    nS[k-1]++;
		 
		 // adjoint strong connections
		 nST[i]++;
	      } // end if
	   } // end if 
       } // end for j
   } // end for i

   
   // change nS, nST to a reference array
   nS--;
   nST--;
   nS[0]=nST[0]=0;
   // accumulate number of nonzeros
   for (i=0; i<A.nc; i++) {
       nS[i+1] +=nS[i];
       nST[i+1]+=nST[i];
   } // end for i


   // total number of strong connections
   sm =nS[A.nc];
   // total number of adjoint strong connections
   sm2=nST[A.nc];

   // strong connections (neighbours) for any node i
   S =(integer *) MALLOC((size_t)sm *sizeof(integer),"indFC:S");
   // nodes (neighbours) for which node i is a strong connection (neighbour)
   ST=(integer *) MALLOC((size_t)sm2*sizeof(integer),"indFC:ST");

   // second pass
   for (i=0; i<A.nc; i++) {
       // strong connections of node i
       x=tol*mx[i];
       for (j=A.ia[i]; j<A.ia[i+1]; j++) {
	   // column index A(i,k), FORTRAN-style
	   k=A.ja[j-1];
	   // make sure that the diagonal entry is excluded
	   if (k!=i+1) {
	      // strong connection found, row-wise
	      if (FABS(A.a[j-1])>=x) { 
		 // only those strong neighbors count as 'strong', that do not
	         // belong to the coarse grid yet
		 if (invq[k-1]<=A.nc-nC)
		    S[nS[i]++]=k;

		 // adjoint strong connections
		 ST[nST[k-1]++]=i+1;
		 lambda[k-1]++;
	      } // end if

	      // strong connection found, column-wise
	      if (FABS(A.a[j-1])>=tol*mx[k-1]) { 
		 // only those strong neighbors count as 'strong', that do not
	         // belong to the coarse grid yet
 		 if (invq[i]<=A.nc-nC)
		    S[nS[k-1]++]=i+1;
		 
		 // adjoint strong connections
		 ST[nST[i]++]=k;
		 lambda[i]++;
	      } // end if
	   } // end if 
       } // end for j
   } // end for i

   // shift references forward by one
   for (i=A.nc; i>0; i--) {
       nS[i] =nS[i-1];
       nST[i]=nST[i-1];
   } // end for i
   nS[0]=nST[0]=0;




   // ----   do a bucket sort to store nodes with the same lambda   ----

   // init arrays
   // first, next, prev will be accessed in C-style [0,1,...] but have
   // integer values in FORTRAN-style [1,2,3,...]
   for (i=0; i<A.nc; i++)
       mark[i]=next[i]=prev[i]=first[i]=0;
   first[A.nc]=0;

   // maximum value for lambda
   maxlm=0;
   for (i=0; i<A.nc; i++) {
       if (!invq[i]) {
	  lm=lambda[i];
	  // make sure that the weight does not exceed n (unlikely)
	  if (lm>A.nc) {
	     lm=A.nc;
	     lambda[i]=lm;
	  } // end if 
	  // store the largest existing value of lambda
	  if (lm>maxlm)
  	     maxlm=lm;
    
	  // zero values form an exception
	  if (lm==0)
	     lm=A.nc+1;
       
	  // current first entry of the bucket having weight lambda[i]
	  j=first[lm-1];
	  // put i to the front, its successor will be the former leader
	  next[i]=j;
	  // new first entry is i
	  first[lm-1]=i+1;
	  // link backward to i
	  if (j>0)
	     prev[j-1]=i+1;
       } // end if
   } // end for i

   // END bucket sort

#ifdef PRINT_INFO
   printf("maxlm=%8d\n",maxlm);
   for (i=A.nc-1; i>=0; i--) {
     j=first[i];
     if (j>0) {
       printf("weight %8d\n",i+1);
       while (j>0){
	 printf("%8d",j);
	 j=next[j-1];
       }
       printf("\n");
     }
   }
   j=first[A.nc];
   if (j>0) {
     printf("weight %8d\n",0);
     while (j>0){
       printf("%8d",j);
       j=next[j-1];
     }
     printf("\n");
   }
#endif

   // main loop
   while (nU>0) {

         // as coarse grid node we choose one that has maximal lambda
         i=first[maxlm-1];
	 while (i==0 && maxlm>0) 
	       i=first[--maxlm-1];

	 if (maxlm==0)
	    lm=A.nc+1;
	 else
	    lm=maxlm;
	 i=first[lm-1];
      
	 // remove i from the list
	 j=next[i-1];
	 first[lm-1]=j;
	 next[i-1]=0;
	 if (j>0)
	    prev[j-1]=0;
	 
	 // add new coarse grid node i
	 invq[i-1]=A.nc-nC++;
	 p[A.nc-nC]=i;
	 nU--;
      
	 // each node j will be moved to the set of fine grid nodes
	 // if i is a strong connection for j
	 for (jj=nST[i-1]; jj<nST[i]; jj++) {
	     // adjoint strong connection of i
	     j=ST[jj];
	     // set check mark, needed to compute set difference S[i] \ ST[j]
	     mark[j-1]=-1;
	     if (!invq[j-1]) {
	        // remove j from the list
	        lm=lambda[j-1];
		if (lm==0)
		   lm=A.nc+1;
		k=next[j-1];
		l=prev[j-1];
		if (k>0)
		   prev[k-1]=l;
		if (l>0)
		   next[l-1]=k;
		else
		   first[lm-1]=k;
		next[j-1]=0;
		prev[j-1]=0;
	 
		// add new fine grid node j
		p[nF++]=j;
		invq[j-1]=nF;
		nU--;

		// for all remaining neighbours increase the weight
		for (kk=nS[j-1]; kk<nS[j]; kk++) {
		    k=S[kk];
		    if (!invq[k-1]) {
		       // remove k from the list
		       lm=lambda[k-1];
		       if (lm==0) 
			  lm=A.nc+1;
		       l=next[k-1];
		       m=prev[k-1];
		       if (l>0)
			  prev[l-1]=m;
		       if (m>0)
			  next[m-1]=l;
		       else
			  first[lm-1]=l;
		       prev[k-1]=0;
		       next[k-1]=0;
		       
		       // increase the weight
		       lambda[k-1]=MIN(A.nc,lambda[k-1]+1);
		       lm=lambda[k-1];
		    
		       // keep track on the maximum weight
		       if (lm>maxlm)
			  maxlm=lm;
		    
		       // re-insert k to the list
		       l=first[lm-1];
		       first[lm-1]=k;
		       next[k-1]=l;
		       if (l>0)
			  prev[l-1]=k;
		    } // end if
		} // end for k
	     } // end if  
	 } // end for j

	 // for the remaining nodes decrease the weight
	 for (jj=nS[i-1]; jj<nS[i]; jj++) {
	     // strong connection of i
	     j=S[jj];
	     if (!invq[j-1] && !mark[j-1]) {
	        // remove j from the list
	        lm=lambda[j-1];
		if (lm==0)
		   lm=A.nc+1;
		k=next[j-1];
		l=prev[j-1];
		if (k>0)
		   prev[k-1]=l;
		if (l>0)
		   next[l-1]=k;
		else
		   first[lm-1]=k;
		next[j-1]=0;
		prev[j-1]=0;
		    
		// decrease the weight
		lambda[j-1]=MAX(0,lambda[j-1]-1);
		lm=lambda[j-1];
		if (lm==0)
		   lm=A.nc+1;
		    
		// re-insert j to the list
		k=first[lm-1];
		first[lm-1]=j;
		next[j-1]=k;
		if (k>0)
	 	   prev[k-1]=j;

	     } // end if 
	 } // end for j

	 for (jj=nST[i-1]; jj<nST[i]; jj++) {
	     // adjoint strong connection of i
	     j=ST[jj];
	     // clear check mark
	     mark[j-1]=0;
	 } // end for jj


#ifdef PRINT_INFO
	 printf("new C point:%5d. nC=%5d,nF=%d,nU=%5d, nC+nF+nU=%5d\n",i,nC,nF,nU,nC+nF+nU);

	 printf("maxlm=%8d\n",maxlm);
	 for (i=A.nc-1; i>=0; i--) {
	   j=first[i];
	   if (j>0) {
	     printf("weight %8d\n",i+1);
	     while (j>0){
	       printf("%8d",j);
	       j=next[j-1];
	     }
	     printf("\n");
	   }
	 }
	 j=first[A.nc];
	 if (j>0) {
	   printf("weight %8d\n",0);
	   while (j>0){
	     printf("%8d",j);
	     j=next[j-1];
	   }
	   printf("\n");
	 }
#endif

   } // end while



   // adjoint strong connections are no longer required
   free(ST);



   // SECOND AMG PASS: add further nodes to the coarse grid if necessary
   cnt=0;
   while (cnt<nF) {
         i=p[cnt];

	 // -- determine strong neighbours of i that are in the coarse grid --

	 // set of strong neighbours of i lying in the coarse grid,
	 // set its number to 0
	 nCi=0;
	 /* test node for a strong F-F connection, if different from zero then
	    this node might be moved to the coarse grid, except if there are
	    more than 1 strong F-F connections. In this case i is moved to
	    the coarse grid
	 */
	 tCi=0;
	 // set of strong neighbours of i in belonging to the fine grid (strong
	 // F-F connections), set its number to 0
	 nDsi=0;
	 // check the strong neighbours of i, whether there are and if, how
	 // many coarse grid neighbours exist
	 for (kk=nS[i-1]; kk<nS[i]; kk++) {
	     k=S[kk];
	     // is this a coarse grid node?
	     if (invq[k-1]>A.nc-nC)
	        // yes
	        Ci[nCi++]=k;
	     else // no, this is a strong F-F connection. This should be avoided!
	        Dsi[nDsi++]=k;
	 } // end for k

	 // we are lucky, no strong F-F connections
	 if (nDsi==0)
	    cnt++;
	 else { // we are unlucky, there are strong F-F connections

	    // set check marks to indicate the entries of Ci and possibly
	    // later also the value tCi
	    for (j=0; j<nCi; j++)
	        mark[Ci[j]-1]=-1;

	    /* check if these F-F connection are at least connected to Ci 
	       i.e. the strong F-F connection share a common coarse grid node 
	       with i
	    */
	    cntj=0;
	    while (cntj<nDsi) {
	          j=Dsi[cntj];
		  // do i and j share common coarse grid points

		  // compute intersection of Ci and Cj
		  nCiCj=0;
		  for (jj=nS[j-1]; jj<nS[j]; jj++) {
		      l=S[jj];
		      if (mark[l-1])
			 CiCj[nCiCj++]=l;
		  } // end for jj

		  if (nCiCj>0) 
		     // yes, they share a common coarse grid node
		     // keep j in Dsi and advance to the next strong connection
		     cntj++;
		  else { // no, then j will be temporarily moved to the coarse
		         // grid is this already the second node?
		     if (tCi!=0 || invq[j-1]<cnt) {
		       /* In this case it is cheaper to move i to the coarse
		          grid than to include two of i's neighbours to the 
			  coarse grid no strong neighbours anymore
		       */
		       nDsi=0;;
		       // remove i from the set of F-points by interchanging it
		       // with the last element in the list
		       l=p[cnt];
		       p[cnt]=p[--nF];
		       p[nF] =l;
		       invq[p[cnt]-1]=cnt+1;
		       invq[p[nF]-1] =nF+1;
		       nC++;
		       // remember to clear the check mark
		       mark[tCi-1]=0;
		       tCi=0;
		     } // end if
		     else { // j becomes a coarse grid node, temporarily
		        tCi=j;
			// set check mark
			mark[tCi-1]=-1;
			/* It might be that there a no serious strong
			   connections anymore. But clearly j is the first
			   serious strong connection, because otherwise tCi=0. 
			   j has to be removed from the list strong connections
			*/
			Dsi[cntj]=Dsi[--nDsi];
		     } // end if-else
		  } // end if-else
	    } // end while cntj
         
	    /* The problem of serious F-F connection has been solved by moving
	       one strong connection temporarily to the coarse grid. In this 
	       case the node now becomes a permanent member of the coarse grid
	       i stays in the fine grid but tCi moves to the coarse grid
	    */
	    if (tCi!=0) {
	       /* remove tCi from the list of F-points
		  if this F-point occured before i in the list, then we first
		  interchange it with i
	       */
 	       cntj=invq[tCi-1]-1;
	       if (cntj<=cnt) {
		  l=p[cnt];
		  p[cnt]=p[cntj];
		  p[cntj]=l;
		  invq[p[cnt]-1] =cnt+1;
		  invq[p[cntj]-1]=cntj+1;
		  // now at position cnt we have tCi
		  l=p[cnt];
		  p[cnt]=p[--nF];
		  p[nF] =l;
		  invq[p[cnt]-1]=cnt+1;
		  invq[p[nF]-1] =nF+1;
		  nC++;
		  // don't increment cnt, since a new F-node is moved to this
		  // position
	       } // end if
	       else {
		 l=p[cntj];
		 p[cntj]=p[--nF];
		 p[nF]  =l;
		 invq[p[cntj]-1]=cntj+1;
		 invq[p[nF]-1]  =nF+1;
		 nC++;
		 // increment cnt, since a new F-node is moved to a higher
		 // position and i is left in the fine grid
		 cnt++;
	       } // end if-else
	       // Finally move the node at position cnt (whatever it is) to the
	       // coarse grid
	    } // end if
	    else {
	       // i is not moved to the coarse grid, check next fine grid node
	      if (invq[i-1]<=A.nc-nC)
		 cnt++;
	    } // end if-else

	    // remember to clear the check marks 
	    for (j=0; j<nCi; j++)
	        mark[Ci[j]-1]=0;
	    if (tCi>0)
	       mark[tCi-1]=0;
	 } // end % if-else nDsi==0
   } //end while (cnt<=...)


   // now the strong connections are also not needed anymore
   free(S);
   
   *nB=nF;

#ifdef PRINT_INFO
   printf("%5d fine grid nodes\n",*nB);
   for (i=0; i<nF; i++)
     printf("%8d",p[i]);
   printf("\n\n");
   printf("%5d coarse grid nodes\n",A.nc-*nB);
   for (i=nF; i<A.nc; i++)
     printf("%8d",p[i]);
   printf("\n\n");
#endif
} // end indFC 
