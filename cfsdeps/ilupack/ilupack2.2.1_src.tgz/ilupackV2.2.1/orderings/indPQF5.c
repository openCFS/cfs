#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ilupack.h>


#include <ilupackmacros.h>

#define  ALPHA  0.00001



void WDIAG(CSRMAT, integer *, integer *, REALS, integer *, REALS *, REALS *, REALS *, integer *);

integer PQPERM(CSRMAT mat, integer bsize, integer *Pord, integer *Qord, integer *nnod, 
	   REALS tol, FLOAT *dbuff, integer *ibuff) {
/*--------------------------------------------------------------------- 
| algorithm for nonsymmetric  block selection - 
|----------------------------------------------------------------------
|     Input parameters:
|     -----------------
|     (mat)  =  matrix in SparRow format
|     
|     tol    =  a tolerance for excluding a row from B block 
|
|     bsize not used here - it is used in arms2.. 
|
|     Output parameters:
|     ------------------ 
|     Pord   = row permutation array.  Row number i will become row number 
|		Pord[i] in permuted matrix. (Old to new labels) 
|     Qord   = column permutation array.  Column number j will become 
|		row number Qord[j] in permuted matrix.
|             [destination lists] - i.e., old to new arrays= 
|     
|     nnod   = number of elements in the B-block 
|
|     ibuff  = integer buffer of size 2*n
|
|     dbuff  = double buffer of size 2*n
|
| original unsymmetric version written by Yousef Saad, 2003
| changes to better fit with ILUPACK by Matthias Bollhoefer, August 2003
|---------------------------------------------------------------------*/ 
/*--------------------   local variables   */
  integer *icor, *jcor, *row;
  REALS *rownorm, *colnorm, toli, t, aii; 
  FLOAT *mrow;
  integer i, j, ii, jj, k, nzi, n=mat.nr, count, numnode;
  CSRMAT matT;

/*-------------------- prototypes */
  integer check_perm(integer, integer *) ;   /* debug only */
/*-----------------------------------------------------------------------*/  

  /*
    printf("\nA\n");
    for (i=0; i<n; i++) {
      printf("%4d:",i+1);
      for (j=mat.ia[i]; j<mat.ia[i+1]; j++)
	printf("%8d",mat.ja[j-1]);
      printf("\n");
      printf("     ");
      for (j=mat.ia[i]; j<mat.ia[i+1]; j++)
	printf("%8.1le",mat.a[j-1]);
      printf("\n");
    }
    fflush(stdout);
  */
  SPARTRAN(mat, &matT, 1, 0) ; 
  /* 
    printf("A^T\n");
    for (i=0; i<n; i++) {
        printf("%4d:",i+1);
        for (j=matT.ia[i]; j<matT.ia[i+1]; j++)
            printf("%8d",matT.ja[j-1]);
        printf("\n");
	printf("     ");
	for (j=matT.ia[i]; j<matT.ia[i+1]; j++)
            printf("%8.1le",matT.a[j-1]);
	printf("\n");
    }
    fflush(stdout);
  */
  


  for (j=0; j<n; j++) {
    Pord[j] = -1;
    Qord[j] = -1; 
  }
  icor = ibuff;     // n   spaces required   totally 2*n integer spaces required
  jcor = ibuff+n;   // n   spaces required  

  rownorm=(REALS *)dbuff;     // n   spaces required  
  colnorm=rownorm+n;          // n   spaces required   totally 2*n REALS spaces
  /*-------------------- end allocs - */
  numnode = 0;
  count = 0;
/*-------------------- wDiag selects candidate entries in a sorted oder */
  WDIAG(mat, icor, jcor, tol, &count, rownorm, colnorm, (REALS *)dbuff, ibuff) ;

  /* change row/col norms to scaled max norms */ 
  for (i = 0; i<n; i++){
    mrow=mat.a+mat.ia[i]-1; 
    rownorm[i]=FABS(mrow[0]);
  }
/*-------------------- add entries one by one to diagnl */
  for (i = 0; i<count; i++){ 
    ii = icor[i];
    jj = jcor[i]; 
    if (Pord[ii] != -1 || Qord[jj] != -1) continue;
    Pord[ii] = numnode;
    Qord[jj] = numnode;
    numnode++; 
/*-------------------- A */
    row =mat.ja+mat.ia[ii]-1; 
    mrow=mat.a +mat.ia[ii]-1; 
    nzi = mat.ia[ii+1]-mat.ia[ii];
    for (k=0; k < nzi; k++) {
      j = row[k]-1;
      if (Qord[j] >= 0) 
	continue;
      t = FABS(mrow[k]) ; 
      if(rownorm[ii] < t) 
	Qord[j] = -2;
      else
	rownorm[ii] -= t;
    }
/*-------------------- A^T */
    row =matT.ja+matT.ia[jj]-1; 
    mrow=matT.a +matT.ia[jj]-1; 
    nzi = matT.ia[jj+1]-matT.ia[jj];
    for (k=0; k < nzi; k++) {
      j = row[k]-1;
      if (Pord[j] >=0) 
	continue;
      t = FABS(mrow[k]) ; 
      if (rownorm[j] < 0) 
/*-------------------- exclude this row */ 
	Pord[j] = -2;
      else
	rownorm[j] -=t;
    }
  }
  /*-------------------- number of B nodes */
  *nnod = numnode; 
/*-------------------- printf(" nnod found = %d \n",*nnod);  */ 
/*--------------------------------------------------
 |    end-main-loop - complete permutation arrays
 |-------------------------------------------------*/
  for (i=0; i<n; i++)
    if (Pord[i] < 0) 
      Pord[i] = numnode++;
  
  if (numnode != n) {
    printf("  ** counting error - type 1 \n"); return 1; }   
  numnode = *nnod;
  for (j=0; j<n; j++)
    if (Qord[j] < 0)
      Qord[j] = numnode++;
/*--------------------              */ 
  if (numnode != n) {
    printf(" **  counting error type 2 \n"); return 1; }
  
/*-------------------- debugging - check permutations */
  /* 
     printf(" checking P  and Q  :    -->  \n") ;
     check_perm(n, Pord) ;
     check_perm(n, Qord) ;
  */
/*--------------------------------------------------
|  clean up before returning
|-------------------------------------------------*/
  // free(icor);
  // free(jcor);
  // free(rownorm);
  // free(colnorm);
  free(matT.ia);
  free(matT.ja);
  free(matT.a);
  return 0;
}
/*---------------------------------------------------------------------
|-----end-of-indsetPQ--------------------------------------------------
|--------------------------------------------------------------------*/

void WDIAG(CSRMAT mat, integer *icor, integer *jcor, REALS tol, integer *count, 
	   REALS* rownorm, REALS *colnorm, REALS *dbuff, integer *ibuff) 
{
/*---------------------------------------------------------------------
|     defines goodness weights based on diagonal dominance relative to 
|     excluded rows and columns. The code will return a list of "count"
|     bi-indices representing the best entries to be selected as 
|     diagonal elements -- the order is important (from best to
|       to worst). The list is in the form (icor(ii), jcor(ii)) 
|
|      ON ENTRY: 
|       mat   = matrix in csptr format 
|       tol   = tolerance used for selecting best rows -|
|
|      ON RETURN: 
|       icor  = list of row indices of entries selected 
|       jcor  = list of column indices of entries selected 
|       count = number of entries selected (size of B block) 
|     
|     ibuff  = integer buffer of size ?*n, in this version UNUSED
|
|     dbuff  = double buffer of size ?*n,  in this version UNUSED
|
|--------------------------------------------------------------------*/
  integer i, k, kmax, n=mat.nr, len, col, jmax, countL;
  integer nzi, *jcol; 
  REALS t, t1, t2, tmax, wmaxR, wmaxC;
  FLOAT *mrow, ft;
/*--------------------begin */
/*-----------------------------------------------------------------------*/
  // nz =mat->nnzrow;
  len = 0; 
/*-------------------- initialize */
  for (i=0; i<n; i++) {
    rownorm[i] = 0.0;
    colnorm[i] = 0.0;
  }
/*-------------------- get norms and max entries  (their locations) */
  for (i=0; i<n; i++) {
    jcol = mat.ja+mat.ia[i]-1;
    mrow = mat.a +mat.ia[i]-1;
    tmax = 0.0; 
    kmax = 0; 
    nzi = mat.ia[i+1]-mat.ia[i];
    for (k = 0; k<nzi; k++) {
      col = jcol[k]-1; 
      t   = FABS(mrow[k]); 
      if (t != 0.0) {
	colnorm[col] +=t; 
	rownorm[i]  += t; 
	if (tmax < t) {
	  tmax = t;
	  kmax = k; 
	}
      }
    }
    jmax = jcol[kmax]-1;
    jcor[i] = jmax; 
/*-------------------- swap largest element to first position ! */
    if (kmax != 0) {
      ft = mrow[kmax];
      mrow[kmax] = mrow[0];
      mrow[0] = ft;
      jcol[kmax] = jcol[0];
      jcol[0] = jmax+1;
    }
/*-------------------- save max diag. dominance ratios ------  */
  }
  wmaxR = 0.0;
  wmaxC = 0.0; 
  for (i=0; i<n; i++) {
    mrow = mat.a +mat.ia[i]-1;
    tmax = FABS(mrow[0]) ;
    col  = jcor[i];
    t1   = tmax / rownorm[i];
    t2   = tmax / colnorm[col] ;
    wmaxR += t1;
    wmaxC += t2;
  }
/*-------------------- now select according to tol */
/*-------------------- eliminate by relative diag. dominance */
  countL = 0;
  wmaxR /= n;
  wmaxC /= n;

  for (i=0; i<n; i++) {
    jcol = mat.ja+mat.ia[i]-1;
    mrow = mat.a +mat.ia[i]-1;
    tmax = FABS(mrow[0]);
    col = jcol[0]-1;
    t1 = tmax / rownorm[i];
    t2 = tmax / colnorm[col];
    if (t2 < tol*wmaxC || t1 < tol*wmaxR)  
      continue;
    /*-------------------- riskless backward copy */
    nzi = mat.ia[i+1]-mat.ia[i];
    rownorm[countL] = t1/((REALS) nzi);
    icor[countL] = i; 
    jcor[countL] = col;
    countL++;
  }
/*-------------------- sort them  */
  QSORTR2I(rownorm, icor, jcor, 0, countL-1);
  *count = countL;
}
/*---------------------------------------------------------------------
|---- end of wDiag ----------------------------------------------------
|--------------------------------------------------------------------*/



