#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
#define _COMPLEX_SYMMETRIC_
#include "symperm_amf_FC.c"
#else
void myilupackdummy28()
{
}
#endif
