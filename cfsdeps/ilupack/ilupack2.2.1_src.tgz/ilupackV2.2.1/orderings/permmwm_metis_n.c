#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include <blas.h>
#include <pardiso.h>
#include <metisord.h>
#include <ilupack.h>

#include <ilupackmacros.h>

//#define PRINT_MEM
//#define PRINT_INFO
#define MEGA      1048576.0
#define IMEGA      262144.0
#define DMEGA      131072.0

#define MAX(A,B)        (((A)>(B))?(A):(B))
#define MIN(A,B)        (((A)<(B))?(A):(B))


/*
 scaling and permutation driver, followed by a symmetric reordering.

 here 1) maximum weight matching (PARDISO)
      2) MeTis multilevel nested dissection by nodes


 Given an n x n matrix A in compressed sparse row format this routine computes
 row and column scalings as well as row and column permutations such that

 A -> Dr * A * Dc,
 
 where Dr and Dc are diagonal matrices stored in the vectors proscal and 
 pcoscal. The scaling is explicitly applied to A.

 The permutation p,invq refer to permutation matrices P and Q^{-1} such  that

  P^T*(Dr * A * Dc)*Q 

 is hopefully better suited for the ILU.

 The routine returns a leading block size nB<=n
                        /B F\ 
  P^T*(Dr * A * Dc)*Q = |   | 
                        \E C/
 In this case the permutation recommends that the ILU is only applied to the
 leading block B of size nB x nB


 In particular MC64 rescales the system and tries to improve the diagonal
 dominance by column permutations, nB=n
 */
integer PERMMWMMETISN(CSRMAT A, FLOAT *proscal, FLOAT *pcoscal, integer *p, integer *invq, integer *nB, 
	     ILUPACKPARAM *param)
{
/*
    A          n x n matrix in compressed sparse row format
               A is altered by the routine since the scalings are directly
               applied to A. Hopefully the scaling are only powers of 2,
               which is the case for all scaling routines from ILUPACK.

    proscal,   vectors of length n that store the row and column scalings Dr
    pcoscal    and Dc
               A -> Dr*A*Dc

    p,invq     permutation vectors p and q^{-1} of length n which refer to
               row / column permutation matrices P and Q^{-1}.
               P^T*(Dr * A * Dc)*Q hopefully better suited for ILU

    nB         leading blocksize nB
                                     /B F\ 
               P^T*(Dr * A * Dc)*Q = |   |,  B matrix of size nB x nB
                                     \E C/
               nB is the recommended block size for the application of an ILU

    param      ILUPACK parameters


    interface driver written by Matthias Bollhoefer, November 2004, July 2005
 */ 

    integer  i,ii,j,k,l,m,imx,n=A.nr,liw,*iw,ldw,info[10],icntl[10],*cperm,job,
      num,nz,ierr=0,options[10], numflag, scale, pow, iflag, flags, *ptr;
    REALS mxr, lg2=1.0/log((double)2.0), fpow;
    double *scal, *a=NULL, *b=NULL, val;
    FLOAT  *w,*dw,mx;
    size_t mem;
    CSRMAT B, C;
    int *Bia, *Bja, *p32;

    ierr=0;
    /* --------------------   END set up parameters   -------------------- */
    flags=param->ipar[6];


    // initial preprocessing
    if ((param->ipar[7]&(512+1024))==512) {
       scale=param->ipar[7]&(1+2+4);
    }
    // regular reordering
    else if ((param->ipar[7]&(512+1024))==1024) {
       scale=(param->ipar[7]&(8+16+32))>>3;
    }
    // final pivoting
    else if ((param->ipar[7]&(512+1024))==512+1024) {
       scale=(param->ipar[7]&(64+128+256))>>6;
    }
    else {
       scale=param->ipar[7]&(1+2+4);
    }
    /* if ((scale&4)==0)   => row scaling first
       else                   column scaling first
       
       if (scale&1)        => apply row scaling     \   ignored for 
       if (scale&2)        => apply column scaling  /   matching
    */


    // rescale the matrix a priori
    CLEAR(A.nc, pcoscal,1);
    // if desired apply row scaling and compute parameters for column scaling
    m=1;
    for (i=0; i<A.nc; i++)
    {
        j=A.ia[i]-1;
        k=A.ia[i+1]-1;
	// if row scaling should be applied before column scaling
	if ((scale&4)==0) {
	   l=k-j;
	   imx=I_AMAX(&l,A.a+j,&m);
	   mxr=FABS(A.a[j+imx-1]);

	   // compute nearest power of 2
	   fpow=log(mxr)*lg2;
	   if (fpow<0.0) {
	      pow=fpow-0.5;
	      fpow=1;
	      for (l=1; l<=-pow; l++)
		  fpow*=2.0;
	      mxr=fpow;
	   }
	   else {
	      pow=fpow+0.5;
	      fpow=1;
	      for (l=1; l<=pow; l++)
		  fpow*=2;
	      mxr=1.0/fpow;
	   }

#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	   proscal[i]=mx=mxr;
#else
	   mx.r=mxr;
	   mx.i=0.0;
	   proscal[i]=mx;
#endif
	   l=k-j;
	   SCAL(&l,&mx,A.a+j,&m);
	} // end if ((scale&4)==0)
        for (; j<k; j++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	    if (pcoscal[A.ja[j]-1]<FABS(A.a[j])) {
	        pcoscal[A.ja[j]-1]=FABS(A.a[j]);
	    } // end if
#else
	    if (pcoscal[A.ja[j]-1].r<FABS(A.a[j])) {
	        pcoscal[A.ja[j]-1].r=FABS(A.a[j]);
	        pcoscal[A.ja[j]-1].i=0.0;
	    } // end if
#endif
	} // end for j
    } // end for i

    // invert column scaling parameters
    for (i=0; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
        mxr=pcoscal[i];
#else
        mxr=pcoscal[i].r;
#endif
	// compute nearest power of 2
	fpow=log(mxr)*lg2;
	if (fpow<0.0) {
	   pow=fpow-0.5;
	   fpow=1;
	   for (l=1; l<=-pow; l++)
	       fpow*=2.0;
	   mxr=fpow;
	}
	else {
	   pow=fpow+0.5;
	   fpow=1;
	   for (l=1; l<=pow; l++)
	       fpow*=2;
	   mxr=1.0/fpow;
	}

#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
        pcoscal[i]=mxr;
#else
        pcoscal[i].r=mxr;
        pcoscal[i].i=0.0;
#endif
    } // end for i

    // apply column scaling
    for (i=0; i<n; i++)
    {
        j=A.ia[i]-1;
        k=A.ia[i+1]-1;
        for (; j<k; j++){
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	    A.a[j]*=pcoscal[A.ja[j]-1];
#else
	    A.a[j].r*=pcoscal[A.ja[j]-1].r;
	    A.a[j].i*=pcoscal[A.ja[j]-1].r;
#endif
	} // end for j

	// if row scaling should be applied after column scaling
	if ((scale&4)!=0) {
	   j=A.ia[i]-1;
	   l=k-j;
	   imx=I_AMAX(&l,A.a+j,&m);
	   mxr=FABS(A.a[j+imx-1]);

	   // compute nearest power of 2
	   fpow=log(mxr)*lg2;
	   if (fpow<0.0) {
	      pow=fpow-0.5;
	      fpow=1;
	      for (l=1; l<=-pow; l++)
		  fpow*=2.0;
	      mxr=fpow;
	   }
	   else {
	      pow=fpow+0.5;
	      fpow=1;
	      for (l=1; l<=pow; l++)
		  fpow*=2;
	      mxr=1.0/fpow;
	   }

#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	   proscal[i]=mx=mxr;
#else
	   mx.r=mxr;
	   mx.i=0.0;
	   proscal[i]=mx;
#endif
	   l=k-j;
	   SCAL(&l,&mx,A.a+j,&m);
	} // end if ((scale&4)!=0) {
    }



    if (flags&SYMMETRIC_STRUCTURE) {

       // PARDISO maximum weight matching interface
       param->ndbuff=MAX(param->ndbuff,(2*(size_t)A.nc*MAX(sizeof(FLOAT),sizeof(double))/sizeof(double)));
       param->dbuff=(FLOAT *) REALLOC(param->dbuff,param->ndbuff*sizeof(FLOAT),
				      "permmwm_metis_n:dbuff");

       // use unsymmetric but symmetrized version of A for maximum weight matching
       // build B=|A|.*|A^T|
       param->nibuff=MAX(param->nibuff,4*(size_t)A.nc+2);
       param->ibuff=(integer *) REALLOC(param->ibuff,param->nibuff*sizeof(integer),
					"permmwm_metis_n:ibuff");
       // param->ibuff (1,...,2n+1) will be used indicate the pruned parts of A, but 
       // also be used for B.ia!
       // param->iaux will be used for B.ja, if possible
       // dbuff (n) will be used to compute the maximum absolute entry per row.
       SETUPGRAPH_EPSILON(A,&B,(REALS)MC64THRESHOLD,
			  (REALS *)param->dbuff, param->ibuff, 
			  param->iaux, param->niaux);
       
       // check if MALLOC was needed to set up B.ja
       if (B.ia[B.nc]<0) {
	  iflag=0;
	  B.ia[B.nc]=-(B.ia[B.nc]);
       }
       else // nz entries from iaux are already in use 
	  iflag=B.ia[B.nc]-1; 

    
       // convert ia from FORTRAN-style to C-style
       for (i=0; i<=A.nr; i++)
           A.ia[i]--;
       // number of nonzeros
       nz=A.ia[n];
       
       // convert ja from FORTRAN-style to C-style
       for (i=0; i<nz; i++)
	   A.ja[i]--;
    
       
       // memory for the unsymmetric but symmetrized version of A
       nz=B.ia[n]-1;
       if ((param->ndaux*sizeof(double))/sizeof(FLOAT)>=nz) 
	  b=(double *)param->daux;
       else
	  b=(double *)MALLOC((size_t)nz*sizeof(double),"permmwm_metis_n:b");
       
       /*--------------------  actual copying  */
       // first 2n+1 components of ibuff are already in use for B.ia and the
       // pruned part of A
       iw=param->ibuff+2*A.nc+1;
       // copy pointers to the start of every row in B
       for (i=0; i<=A.nc; i++)
	   iw[i]=B.ia[i];
       // printf("copy matrix nz=%d\n",nz);fflush(stdout);
       // step 1. column-based copy
       //printf("step 1: A^T\n");fflush(stdout);
       for (i=0; i<A.nc; i++) {
	   // copy indices and values
	   for (j=A.ia[i]; j<param->ibuff[i]-1; j++) {
	       // current column index of row i in C style
	       k=A.ja[j];
	       val=FABS(A.a[j]);
	       // current position in row k, FORTRAN style
	       l=iw[k]-1;
	       // set index (FORTRAN style) and value
	       B.ja[l]=i+1;
	       b[l]=val;
	       // advance pointer
	       iw[k]++;
	   } // end for j
       } // end for i

       //printf("step 2: A\n");fflush(stdout);
       // pointer array to indicate whether an entry has already been set
       ptr=iw+A.nc+1;
       for (i=0; i<A.nc; i++)
	   ptr[i]=-1;
       for (i=0; i<A.nc; i++) {
	   // set check marks. Indicate which nonzeros already exist in row i 
	   for (j=B.ia[i]-1; j<iw[i]-1; j++) {
	       // index B(i,k), Fortran style -> C style
	       k=B.ja[j]-1;
	       // store pointer
	       ptr[k]=j;
	   } // end for j
	   // copy indices and values
	   for (j=A.ia[i]; j<param->ibuff[i]-1; j++) {
	       // current column index of row i in C style
	       k=A.ja[j];
	       
	       // B(i,k) already exists => this entry has been set during step k<i
	       l=ptr[k];
	       if (l>=0) {
		  val=FABS(A.a[j]);
		  // |A(k,i)|*|A(i,k)|
		  b[l]*=val;
		  ptr[k]=-1;
	       }
	       // else A(k,i)==0
	   } // end for j
	   l=iw[i]-1;
	   for (j=B.ia[i]-1; j<l; ) {
	       // index B(i,k), Fortran style -> C style
	       k=B.ja[j]-1;
	       // check pointer  
	       if (ptr[k]!=-1) {
		  // A(i,k)==0
		  l--;
		  b[j]=b[l];
		  B.ja[j]=B.ja[l];
		  ptr[k]=-1;
	       }
	       else
		  j++;
	   } // end for j
	   iw[i]=l+1;
       } // end for i

       // finally compress B       
       l=0;
       for (i=0; i<B.nr; i++) {
	   for (j=B.ia[i]-1; j<iw[i]-1; j++) {
	       B.ja[j-l]=B.ja[j];
	       b[j-l]=b[j];
	   } // end for j
	   B.ia[i]-=l;
	   l+=B.ia[i+1]-iw[i];
       } // end for i
       B.ia[B.nr]-=l;
       //printf("matrix copied nz=%d\n",B.ia[B.nc]-1);fflush(stdout);
	   

#ifdef PRINT_INFO
       for (i=0; i<B.nr; i++) {
	 for (j=B.ia[i]-1; j<B.ia[i+1]-1; j++) {
	   printf("%d %d %12.4le;...\n",i+1,B.ja[j],b[j]); fflush(stdout);
	 }
       }
#endif

       // PARDISO maximum weight matching
       scal=(double *)param->dbuff;
       // convert B.ia,B.ja from FORTRAN-style to C-style
       for (i=0; i<=B.nr; i++)
	   B.ia[i]--;
       for (i=0; i<B.ia[B.nr]; i++)
	   B.ja[i]--;
#ifdef __PARDISO_2__
       ierr = mps_pardiso(     A.nr, B.ia,B.ja,b, p, scal+n,scal, 0);
#else
#ifdef _LONG_INTEGER_
       Bia=(int *)MALLOC((B.nr+1)*sizeof(int),"sympermmwm_metisn:Bia");
       Bja=(int *)MALLOC(B.ia[B.nr]*sizeof(int),"sympermmwm_metisn:Bja");
       p32=(int *)MALLOC(B.nr*sizeof(int),"sympermmwm_metisn:p32");
       for (i=0; i<=B.nr; i++)
	   Bia[i]=B.ia[i];
       for (i=0; i<B.ia[B.nr]; i++)
	   Bja[i]=B.ja[i];
       ierr = mps_pardiso(0,0, (int)A.nr, Bia,Bja,b, p32, scal+n,scal, 0);
       for (i=0; i<B.nr; i++) 
	   p[i]=p32[i];
       free(p32);
       free(Bia);
       free(Bja);
#else
       ierr = mps_pardiso(0,0, A.nr, B.ia,B.ja,b, p, scal+n,scal, 0);
#endif /* _LONG_INTEGER_ */
#endif
       // values of the unsymmetric version are not longer needed
       if ((param->ndaux*sizeof(double))/sizeof(FLOAT)<nz) 
	  free(b);
       if (!iflag)
	  free(B.ja);
       if (ierr)
	  return (ierr);

    
       // build left and right diagonal scaling derived from the matching
       for (i=0; i<n; i++) {
	   // convert permutation from C style back to Fortran style
           p[i]++;

	   // remember that B~|A|.*|A|^T was input for mps_pardiso
	   mxr=sqrt(sqrt(exp(scal[i]+scal[n+i])));
	   // compute nearest power of 2
	   fpow=log(mxr)*lg2;
	   if (fpow<0.0) {
	      pow=fpow-0.5;
	      fpow=1;
	      for (l=1; l<=-pow; l++)
		  fpow*=2.0;
	      mxr=1.0/fpow;
	   }
	   else {
	      pow=fpow+0.5;
	      fpow=1;
	      for (l=1; l<=pow; l++)
	          fpow*=2;
	      mxr=fpow;
	   }
	   scal[i]=mxr;
       } // end for i
	   


       // transfer scaling to the official interface vectors
       for (i=0; i<A.nr; i++){
#if defined _DOUBLE_REAL_ || defined  _SINGLE_REAL_
	   proscal[i]*=scal[i];
	   pcoscal[i]*=scal[i];
#else
	   proscal[i].r*=scal[i];
	   pcoscal[i].r*=scal[i];
	   proscal[i].i=0;
	   pcoscal[i].i=0;
#endif
       } // end for i


       /*
#if defined _DOUBLE_REAL_ || defined  _SINGLE_REAL_
       for (i=0; i<n; i++)
	 printf("%16.8le",proscal[i]);
       printf("\n");
       for (i=0; i<n; i++)
	 printf("%16.8le",pcoscal[i]);
       printf("\n");
#else
       for (i=0; i<n; i++)
	 printf("%16.8le",proscal[i].r);
       printf("\n");
       for (i=0; i<n; i++)
	 printf("%16.8le",pcoscal[i].r);
       printf("\n");
#endif
       for (i=0; i<A.nc; i++) {
	 printf("%8ld",p[i]);
       }
       printf("\n");
       fflush(stdout);
       */




       // rescale matrix explicitly
       for (i=0; i<n; i++){
           for (j=A.ia[i];j<A.ia[i+1];j++){
#if defined _DOUBLE_REAL_ || defined  _SINGLE_REAL_
	       A.a[j]=scal[i]*A.a[j]*scal[A.ja[j]];
#else
	       A.a[j].r=scal[i]*A.a[j].r*scal[A.ja[j]];
	       A.a[j].i=scal[i]*A.a[j].i*scal[A.ja[j]];
#endif
	   } // end for j
       } // end for i

       
       
       // convert ia,ja back from C-style to FORTRAN-style 
       nz=A.ia[A.nr];
       for (i=0; i<=A.nr; i++)
	   A.ia[i]++;
       for (i=0; i<nz; i++)
	   A.ja[i]++;     


#ifdef PRINT_INFO
       fflush(stdout);
       for (i=0; i<A.nr; i++) {
	   printf("%8d",p[i]);
       }
       printf("\n");
       fflush(stdout);
       for (i=0; i<A.nr; i++) {
	   for (j=A.ia[i];j<A.ia[i+1];j++) {
	       printf("%d %d %e;...\n",i+1,A.ja[j-1],A.a[j-1]);
	   }
	   fflush(stdout);
       }
       printf("\n");
       fflush(stdout);
#endif

       // compute symmetric weighted matching, i.e. break cycles into
       // 1x1 and 2x2 cycles
       // SYMMETRIC maximum weight matching interface
       l=GNLSYMMWM(A, p, param->ibuff, param->dbuff);


#ifdef PRINT_INFO
       printf("1x1: 1,...,%d\n",l);
       fflush(stdout);
       for (i=0; i<A.nr; i++) {
	   printf("%8d",p[i]);
       }
       printf("\n");
       fflush(stdout);
#endif


       // reorder the pattern of A by rows in order to apply a symbolic reordering

       // inverse permutation
       cperm=param->ibuff+2*A.nc+2;
       for (i=0; i<A.nc; i++)
	   cperm[p[i]-1]=i+1;
       C.nc=C.nr=A.nr;
       C.a=NULL;
       C.ia=param->ibuff+A.nc+1;
       if (param->niaux>=nz)
	  C.ja=param->iaux;
       else
	  C.ja=(integer *)MALLOC((size_t)nz*sizeof(integer), "permmwm_metis_n:C.ja");
       C.ia[0]=1;
       for (i=0; i<A.nc; i++) {
	   ii=p[i]-1;
	   k=C.ia[i]-1;
	   for (j=A.ia[ii]; j<A.ia[ii+1]; j++) {
	       C.ja[k++]=cperm[A.ja[j-1]-1];
	   }
	   C.ia[i+1]=C.ia[i]+ (A.ia[ii+1]-A.ia[ii]);
       }

       
       // compress matrix
       // the leading l rows correspond to 1x1 pivots
       for (i=0; i<l; i++)
	   cperm[i]=i+1;
       j=l;
       for (; i<A.nc; i+=2)
	   cperm[i]=cperm[i+1]=++j;


       // shift column indices
       for (i=0; i<nz; i++)
	   C.ja[i]=cperm[C.ja[i]-1];

       // buffer for flags
       for (i=0; i<A.nc; i++)
	   cperm[i]=0;
       // skip duplicate entries in the leading l rows
       k=0;
       for (i=0; i<l; i++) {
	   // old start of row i
           j=C.ia[i]-1;
	   // new start of row i
	   C.ia[i]=k+1;
	   for (; j<C.ia[i+1]-1; j++) {
	       ii=C.ja[j]-1;
	       // entry is not duplicate yet
	       if (!cperm[ii]) {
	          // check mark
		  cperm[ii]=-1;
		  // shift entry
		  C.ja[k++]=ii+1;
	       }
	   }
	   // clear check mark array
	   for (j=C.ia[i]-1; j<k; j++) {
	       ii=C.ja[j]-1;
	       cperm[ii]=0;
	   }
       }
       // merge duplicate entries and rows in the remaining  n-l rows
       m=l;
       for (; i<A.nc; i+=2,m++) {
	   // old start of row i
	   j=C.ia[i]-1;
	   // new start of row i
	   C.ia[m]=k+1;
	   for (; j<C.ia[i+2]-1; j++) {
	       ii=C.ja[j]-1;
	       // entry is not duplicate yet
	       if (!cperm[ii]) {
		  // check mark
		  cperm[ii]=-1;
		  // shift entry
		  C.ja[k++]=ii+1;
	       }
	   }
	   // clear check mark array
	   for (j=C.ia[m]-1; j<k; j++) {
	       ii=C.ja[j]-1;
	       cperm[ii]=0;
	   }
       }
       C.ia[m]=k+1;
       C.nc=C.nr=m;



#ifdef PRINT_INFO
       for (i=0; i<C.nc; i++)
	   for (j=C.ia[i];j<C.ia[i+1];j++)
	       printf("%8d %8d %16.8le;...\n",i+1, C.ja[j-1],-1.0);
       printf("\n");
       fflush(stdout);
#endif


       // build symmetric undirected graph
       mem=(param->niaux>=k) ? param->niaux-k : 0;
       SETUPGRAPH(C,&B, param->ibuff, 
		  param->iaux+k,mem);
       // release memory for reordered pattern
       if (nz>param->niaux)
	  free(C.ja);

       // check if MALLOC was needed to set up B.ja
       if (B.ia[B.nc]<0) {
	  iflag=0;
	  B.ia[B.nc]=-(B.ia[B.nc]);
       }
       else  {// nz+B.ia[B.nc]-1 entries from iaux were already in use 
	  iflag=B.ia[B.nc]-1; 
	  B.ja-=k;
	  // shift entries back by nz
	  for (i=0; i<iflag; i++) {
	      B.ja[i]=B.ja[i+k];
	  } // end for i
       }

       // get rid of the diagonal entries
       k=0;
       for (i=0; i<B.nc; i++) {
           m=k;
	   for (j=B.ia[i]-1; j<B.ia[i+1]-1;j++) {
	       // diagonal entry
	       if (B.ja[j]==i+1) {
		  // skip diagonal entry
		  k++;
	       }
	       else {
	          // shift diagonal entry
		  B.ja[j-k]=B.ja[j];
	       } // end if
	   } // end for j
	   B.ia[i]-=m;
       } // end for i
       B.ia[i]-=k;
	
       // reorder the system using multilevel nested dissection & minimum degree
       // FORTRAN style
       numflag=1;
       i=1;
       // default options
       //options[0]=0;
       options[0]=1;
       options[1]=3;
       options[2]=1;
       options[3]=2;
       options[4]=0;
       options[5]=1;
       options[6]=200; 
       options[7]=1; 

       cperm=param->ibuff+A.nc+1;
       if (B.ia[B.nc]>1)
	  METIS_NodeND(&B.nc,B.ia,B.ja, &numflag,options,cperm,invq);
       else
	  for (i=0; i<B.nc; i++) 
	      cperm[i]=invq[i]=i+1;
       if (!iflag)
	  free(B.ja);


#ifdef PRINT_INFO
       for (i=0; i<C.nc; i++)
	   printf("%8d",cperm[i]);
       printf("\n\n");
       fflush(stdout);
#endif



       // prolongate permutation to its original size
       j=0;
       for (i=0;i<C.nc; i++)
	   // 1x1 block
	   if (cperm[i]<=l)
	      param->ibuff[j++]=cperm[i];
	   else { // 2x2 block
	      param->ibuff[j]=2*cperm[i]-l-1;
	      param->ibuff[j+1]=param->ibuff[j]+1;
	      j+=2;
	   }
      

#ifdef PRINT_INFO
       printf("block permutation\n");fflush(stdout);
       for (i=0; i<A.nc; i++)
	   printf("%8d",param->ibuff[i]);
       printf("\n\n");
       fflush(stdout);
#endif


    
       // build product permutation for the rows (maximum weighted matching 
       //                                         followed by
       //                                         symmetric reordering)
       for (i=0; i<n; i++) {
	   cperm[i]=p[param->ibuff[i]-1];
       }
       // rewrite permutation
       for (i=0; i<n; i++) {
	   p[i]=cperm[i];
       }
       // inverse permutation
       for (i=0; i<n; i++) {
	   invq[p[i]-1]=i+1;
       }


#ifdef PRINT_INFO
       printf("final permutation\n");fflush(stdout);
       for (i=0; i<A.nc; i++)
	   printf("%8d",p[i]);
       printf("\n\n");
       fflush(stdout);
#endif

    }
    else { // generally structured matrix

       // convert ia from FORTRAN-style to C-style
       for (i=0; i<=A.nr; i++)
	   A.ia[i]--;
       // number of nonzeros
       nz=A.ia[n];

       // convert ja from FORTRAN-style to C-style
       for (i=0; i<nz; i++)
	   A.ja[i]--;


       // for minimum weight matching the PARDISO interface requires a 
       // real-valued matrix in double precision 
#ifdef _DOUBLE_REAL_
       a=A.a;
#elif defined _SINGLE_REAL_
       // conversion single to double
       if (nz<=MAX(2,sizeof(double)/sizeof(float))*param->ndaux)
	  a=(double*)param->daux;
       else
	  a=(double *)MALLOC((size_t)nz*sizeof(double),"permmwm_metis_n:a");
       for (i=0; i<nz; i++)
	   a[i]=A.a[i];   
#else
       // conversion single/double complex to real double
       if (nz<=param->ndaux)
	  a=(double*)param->daux;
       else
	  a=(double *)MALLOC((size_t)nz*sizeof(double),"permmwm_metis_n:a");
       for (i=0; i<nz; i++) {
	   a[i]=FABS(A.a[i]);
       }
#endif

      
       // PARDISO minimum weight matching interface
#ifdef PRINT_MEM
       printf("dbuffmem=%8.2lfMB\n",param->ndbuff/DMEGA);fflush(stdout);
#endif
       if (param->ndbuff==0) {
	  param->ndbuff=2*(size_t)A.nc*MAX(sizeof(FLOAT),sizeof(double))/sizeof(double);
	  param->dbuff=(FLOAT *) MALLOC(param->ndbuff*sizeof(FLOAT),
					"permmwm_metis_n:dbuff");
#ifdef PRINT_MEM
	  printf("dbuff(%8.2lfMB) allocated\n",param->ndbuff/DMEGA);fflush(stdout);
#endif
       }
       else if (2*(size_t)A.nc*MAX(sizeof(FLOAT),sizeof(double))/sizeof(double)>param->ndbuff) {
	  param->ndbuff=2*(size_t)A.nc*MAX(sizeof(FLOAT),sizeof(double))/sizeof(double);
	  param->dbuff=(FLOAT *) REALLOC(param->dbuff,
					 param->ndbuff*sizeof(FLOAT),
					 "permmwm_metis_n:dbuff");
#ifdef PRINT_MEM
	  printf("dbuff(%8.2lfMB) re-allocated\n",param->ndbuff/DMEGA);fflush(stdout);
#endif
       }
       scal=(double *)param->dbuff;
#ifdef __PARDISO_2__
       ierr = mps_pardiso(     A.nr, A.ia,A.ja,a, p, scal+n,scal, 0);
#else
#ifdef _LONG_INTEGER_
       Bia=(int *)MALLOC((A.nr+1)*sizeof(int),"sympermmwm_metisn:Bia");
       Bja=(int *)MALLOC(A.ia[A.nr]*sizeof(int),"sympermmwm_metisn:Bja");
       p32=(int *)MALLOC(A.nr*sizeof(int),"sympermmwm_metisn:p32");
       for (i=0; i<=A.nr; i++)
	   Bia[i]=A.ia[i];
       for (i=0; i<A.ia[A.nr]; i++)
	   Bja[i]=A.ja[i];
       ierr = mps_pardiso(0,0, (int)A.nr, Bia,Bja,a, p32, scal+n,scal, 0);
       for (i=0; i<A.nr; i++) 
	   p[i]=p32[i];
       free(p32);
       free(Bia);
       free(Bja);
#else
       ierr = mps_pardiso(0,0, A.nr, A.ia,A.ja,a, p, scal+n,scal, 0);
#endif /* _LONG_INTEGER_ */
#endif
       if (ierr)
	  return (ierr);

#if defined _SINGLE_REAL_
       if (nz>MAX(2,sizeof(double)/sizeof(float))*param->ndaux)
	  free(a);
#elif defined _SINGLE_COMPLEX_ || defined _DOUBLE_COMPLEX_
       if (nz>param->ndaux)
	  free(a);
#endif
    
       // build left and right diagonal scaling derived from the matching
       for (i=0; i<n; i++) {
	   p[i]++;

	   mxr=exp(scal[i]);
	   // compute nearest power of 2
	   fpow=log(mxr)*lg2;
	   if (fpow<0.0) {
	      pow=fpow-0.5;
	      fpow=1;
	      for (l=1; l<=-pow; l++)
	          fpow*=2.0;
	      mxr=1.0/fpow;
	   }
	   else {
	      pow=fpow+0.5;
	      fpow=1;
	      for (l=1; l<=pow; l++)
	          fpow*=2;
	      mxr=fpow;
	   }
	   scal[i]=mxr;
	  
	   mxr=exp(scal[n+i]);
	   // compute nearest power of 2
	   fpow=log(mxr)*lg2;
	   if (fpow<0.0) {
	      pow=fpow-0.5;
	      fpow=1;
	      for (l=1; l<=-pow; l++)
	          fpow*=2.0;
	      mxr=1.0/fpow;
	   }
	   else {
	      pow=fpow+0.5;
	      fpow=1;
	      for (l=1; l<=pow; l++)
	          fpow*=2;
	      mxr=fpow;
	   }
	   scal[n+i]=mxr;
       } // end for i

       // transfer scaling to the official interface vectors
       for (i=0; i<A.nr; i++){
#if defined _DOUBLE_REAL_ || defined  _SINGLE_REAL_
	   proscal[i]*=scal[n+i];
	   pcoscal[i]*=scal[i];
#else
	   proscal[i].r*=scal[n+i];
	   pcoscal[i].r*=scal[i];
	   proscal[i].i=0;
	   pcoscal[i].i=0;
#endif
       } // end for i



       // rescale matrix explicitly
       for (i=0; i<n; i++){
	   for (j=A.ia[i];j<A.ia[i+1];j++){
#if defined _DOUBLE_REAL_ || defined  _SINGLE_REAL_
	       A.a[j]=scal[n+i]*A.a[j]*scal[A.ja[j]];
#else
	       A.a[j].r=scal[n+i]*A.a[j].r*scal[A.ja[j]];
	       A.a[j].i=scal[n+i]*A.a[j].i*scal[A.ja[j]];
#endif
	   } // end for j
       } // end for i
	 



       // convert ia,ja back from C-style to FORTRAN-style 
       for (i=0; i<=A.nr; i++)
	   A.ia[i]++;
       for (i=0; i<nz; i++)
           A.ja[i]++;

       // reorder the pattern of A by rows in order to apply a symbolic reordering
       // allocate memory with respect to the specific permutation routine
#ifdef PRINT_MEM
       printf("ibuffmem=%8.2lfMB\n",param->nibuff/IMEGA);fflush(stdout);
#endif
       if (param->nibuff==0) {
	  param->nibuff=3*(size_t)A.nc+2;
	  param->ibuff=(integer *)  MALLOC(param->nibuff*sizeof(integer),
					   "permmwm_metis_n:ibuff");
#ifdef PRINT_MEM
	  printf("ibuff(%8.2lfMB) allocated\n",param->nibuff/IMEGA);fflush(stdout);
#endif
       }
       else if (3*(size_t)A.nc+2>param->nibuff) {
	    param->nibuff=3*(size_t)A.nc+2;
	    param->ibuff=(integer *) REALLOC(param->ibuff,
					     param->nibuff*sizeof(integer),
					     "permmwm_metis_n:ibuff");
#ifdef PRINT_MEM
	    printf("ibuff(%8.2lfMB) re-allocated\n",param->nibuff/IMEGA);fflush(stdout);
#endif
       }

       // reorder the rows of A, at least the pattern of A
       C.nc=C.nr=A.nr;
       C.a=NULL;
       C.ia=param->ibuff;
       if (nz<=param->niaux)
	  C.ja=param->iaux;
       else
	  C.ja=(integer *)MALLOC((size_t)nz*sizeof(integer), "permmwm_metis_n:C.ja");
       C.ia[0]=1;
       for (i=0; i<A.nc; i++) {
	   ii=p[i]-1;
	   k=C.ia[i]-1;
	   for (j=A.ia[ii]; j<A.ia[ii+1]; j++) {
	       C.ja[k++]=A.ja[j-1];
	   }
	   C.ia[i+1]=C.ia[i]+ (A.ia[ii+1]-A.ia[ii]);
       }
       // build symmetric undirected graph
       mem=(param->niaux>=C.ia[C.nc]-1) ? param->niaux-(C.ia[C.nc]-1) : 0;
       SETUPGRAPH(C,&B, param->ibuff+2*n+1, 
		  param->iaux+(C.ia[C.nc]-1),mem);
       // release memory for reordered pattern
       if (nz>param->niaux)
	  free(C.ja);

       // check if MALLOC was needed to set up B.ja
       if (B.ia[B.nc]<0) {
	  iflag=0;
	  B.ia[B.nc]=-(B.ia[B.nc]);
       }
       else  {// nz+B.ia[B.nc]-1 entries from iaux were already in use 
	  iflag=B.ia[B.nc]-1; 
	  B.ja-=(C.ia[C.nc]-1);
	  // shift entries back by nz
	  for (i=0; i<iflag; i++) {
	      B.ja[i]=B.ja[i+(C.ia[C.nc]-1)];
	  } // end for i
       }

       // get rid of the diagonal entries
       k=0;
       for (i=0; i<A.nc; i++) {
           l=k;
	   for (j=B.ia[i]-1; j<B.ia[i+1]-1;j++) {
	       // diagonal entry
	       if (B.ja[j]==i+1) {
		  // skip diagonal entry
		  k++;
	       }
	       else {
	          // shift diagonal entry
		  B.ja[j-k]=B.ja[j];
	       } // end if
	   } // end for j
	   B.ia[i]-=l;
       } // end for i
       B.ia[i]-=k;
	
       // reorder the system using multilevel nested dissection & minimum degree
       // FORTRAN style
       i=1;
       // default options
       //options[0]=0;
       options[0]=1;
       options[1]=3;
       options[2]=1;
       options[3]=2;
       options[4]=0;
       options[5]=1;
       options[6]=200; 
       options[7]=1; 
       numflag=1;

       if (B.ia[A.nc]>1)
	  METIS_NodeND(&A.nc,B.ia,B.ja, &numflag,options,param->ibuff+A.nc,invq);
       else
	  for (i=0; i<A.nc; i++) 
	      param->ibuff[A.nc+i]=invq[i]=i+1;
       if (!iflag)
	  free(B.ja);

       // build product permutation for the rows (minimum weighted matching followed 
       //                                         symmetric reordering)
       for (i=0; i<n; i++) {
	   param->ibuff[i]=p[param->ibuff[A.nc+i]-1];
       }
       // rewrite permutation
       for (i=0; i<n; i++) {
	  p[i]=param->ibuff[i];
       }
    }


    *nB=A.nc; 

    return (ierr);
} /* end permmwm_metis_n */
