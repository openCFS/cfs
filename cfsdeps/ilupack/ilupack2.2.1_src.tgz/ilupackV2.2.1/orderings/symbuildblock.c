#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>

#include <sparspak.h>
#include <ilupack.h>

#include <ilupackmacros.h>

#define MAX_LINE        255
#define STDERR          stderr
#define STDOUT          stdout
#define MAX(A,B)        (((A)>(B))?(A):(B))
#define MIN(A,B)        (((A)<(B))?(A):(B))
// #define PRINT_INFO



#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
#define CONJG(A)      (A)

#ifdef _SKEW_MATRIX_

#ifdef _DOUBLE_REAL_
#define MYSYMBUILDBLOCK           DSSMbuildblock

#else
#define MYSYMBUILDBLOCK           SSSMbuildblock
#endif

#define SKEW(A)      (-(A))

#else

#ifdef _DOUBLE_REAL_
#define MYSYMBUILDBLOCK           DSYMbuildblock
#else
#define MYSYMBUILDBLOCK           SSYMbuildblock
#endif

#define SKEW(A)      (A)
#endif
// end _SKEW_MATRIX_


#else

#ifdef _COMPLEX_SYMMETRIC_
#define CONJG(A)     (A)

#ifdef _SKEW_MATRIX_
#define SKEW(A)      (-(A))

#ifdef _SINGLE_COMPLEX_
#define MYSYMBUILDBLOCK           CSSMbuildblock
#else
#define MYSYMBUILDBLOCK           ZSSMbuildblock
#endif

#else
#define SKEW(A)      (A)

#ifdef _SINGLE_COMPLEX_
#define MYSYMBUILDBLOCK           CSYMbuildblock
#else
#define MYSYMBUILDBLOCK           ZSYMbuildblock
#endif

#endif
// end _SKEW_MATRIX_


#else
#define CONJG(A)     (-(A))

#ifdef _SKEW_MATRIX_
#define SKEW(A)      (-(A))

#ifdef _SINGLE_COMPLEX_
#define MYSYMBUILDBLOCK           CSHRbuildblock
#else
#define MYSYMBUILDBLOCK           ZSHRbuildblock
#endif

#else
#define SKEW(A)      (A)

#ifdef _SINGLE_COMPLEX_
#define MYSYMBUILDBLOCK           CHERbuildblock
#else
#define MYSYMBUILDBLOCK           ZHERbuildblock
#endif

#endif
// end _SKEW_MATRIX_

#endif
// end _COMPLEX_SYMMETRIC_

#endif
// end _DOUBLE_REAL_




// we predefine a block structure
void MYSYMBUILDBLOCK(CSRMAT A, integer *pi,integer *invqi, integer *nextblock, 
		     REALS *rbuff)
{
/*
    A          n x n matrix in compressed sparse row format
               A is altered by the routine since the scalings are directly
               applied to A. Hopefully the scaling are only powers of 2,
               which is the case for all scaling routines from ILUPACK.

    pi,invqi   permutation vectors p and q^{-1} of length n which refer to
               row / column permutation matrices P and Q^{-1}.
               P^T*A*Q hopefully better suited for ILU
    nextblock
	       

    rbuff      real buffer of size n
 */

   integer  i,i2,j,k,l,m;
   REALS    sm, x, x2, adiag,
            // row sums in absolute value
            *sum  =rbuff;
   
   FLOAT aii,aiip1,aip1ip1,det;

   for (i=0; i<A.nc; i++) {
       nextblock[i]=-1;
       sum[i]=0.0;
   } // end for i
   for (i=0; i<A.nc; i++) {
       l=-1;
       for (j=A.ia[pi[i]-1]-1; j<A.ia[pi[i]]-1; j++) {
	   k=invqi[A.ja[j]-1]-1;
	   if (i!=k) {
	      x=FABS(A.a[j]);
	      sum[i]+=x;
	      // remember that only half of the matrix is stored
	      sum[k]+=x;
	   } // end if i!=k
	   else
	      l=j; // store position of the diagonal entry
       } // end for j
       // make sure that the diagonal entry is leading
       if (l>=0) {
	  j=A.ia[pi[i]-1]-1;

	  k=A.ja[j];
	  A.ja[j]=A.ja[l];
	  A.ja[l]=k;

	  aii=A.a[j];
	  A.a[j]=A.a[l];
	  A.a[l]=aii;
       } // end if l>=0
   } // end for i

   for (i=0; i<A.nc; i++) {
       // check whether a scalar row or a block row is preferred
       i2=i+1;
       if (i2<A.nc) {
	  // search for a_ii, a_{i,i+1}, a_{i+1,i+1}
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	  aii=0;
	  aiip1=0;
	  aip1ip1=0;
#else
	  aii.r=0;
	  aii.i=0;
	  aiip1.r=0;
	  aiip1.i=0;
	  aip1ip1.r=0;
	  aip1ip1.i=0;
#endif
	  l=-1;
	  // scan row i of A(pi,qi)
	  for (j=A.ia[pi[i]-1]-1; j<A.ia[pi[i]]-1; j++) {
	      k=invqi[A.ja[j]-1]-1;
	      // a_{i,i+1}
	      if (k==i2) {
		 aiip1=A.a[j];
		 l=j;
	      }
	      // a_ii
	      else if (k==i)
		 aii=A.a[j];
	  } // end for j
	  // make sure that the super-diagonal is close to the front
	  if (l>=0) {
	     j=A.ia[pi[i]-1]-1;
	     k=invqi[A.ja[j]-1]-1;
	     // if the diagonal entry is in front, then leave it there
	     if (k==i)
	        j++;

	     k=A.ja[j];
	     A.ja[j]=A.ja[l];
	     A.ja[l]=k;

	     aii=A.a[j];
	     A.a[j]=A.a[l];
	     A.a[l]=aii;
	  } // end if l>=0
	  l=-1;
	  // scan row i+1 of A(pi,qi)
	  for (j=A.ia[pi[i2]-1]-1; j<A.ia[pi[i2]]-1; j++) {
	      k=invqi[A.ja[j]-1]-1;
	      // a_{i+1,i}
	      if (k==i) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
		 aiip1=A.a[j];
#else
		 aiip1.r=SKEW(A.a[j].r);
		 aiip1.i=SKEW(CONJG(A.a[j].i));
#endif
		 l=j;
	      } // end if
	      // a_{i+1,i+1}
	      else if (k==i2) 
	         aip1ip1=A.a[j];
	  } // end for j
	  // make sure that the sub-diagonal is close to the front
	  if (l>=0) {
	     j=A.ia[pi[i2]-1]-1;
	     k=invqi[A.ja[j]-1]-1;
	     // if the diagonal entry is in front, then leave it there
	     if (k==i2)
	        j++;

	     k=A.ja[j];
	     A.ja[j]=A.ja[l];
	     A.ja[l]=k;

	     aii=A.a[j];
	     A.a[j]=A.a[l];
	     A.a[l]=aii;
	  } // end if l>=0

	  // inverse of a 2x2 block
	  //     [a_{ii}    a_{i,i+1}  ] 
	  // A = [a_{i+1,i} a_{i+1,i+1}]
	  // is
	  //  -1   1/det * [ a_{i+1,i+1} -a_{i,i+1}] 
	  // A   =         [-a_{i+1,i}    a_{ii}   ]
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	  det=aii*aip1ip1-aiip1*aiip1;
#else
	  det.r=(aii.r*aip1ip1.r-aii.i*aip1ip1.i)
	       -(aiip1.r*SKEW(aiip1.r)-aiip1.i*SKEW(CONJG(aiip1.i)));
	  det.i=(aii.r*aip1ip1.i+aii.i*aip1ip1.r)
	       -(aiip1.r*SKEW(CONJG(aiip1.i))+aiip1.i*SKEW(aiip1.r));
#endif
	  // compare MAX(|a_ii|\sum[i],|a_{i+1,i+1}|\sum[i+1]) 
	  //        =MAX(|a_{i+1,i+1}|sum[i],|a_ii|sum[i+1])/(|a_iia_{i+1,i+1}|)
	  //
	  //                   and
	  //
	  //                      [sum[i]  -|a_{i,i+1}|]
	  //         MAX(|A^{-1}|*[                    ])
	  //                      [sum[i+1]-|a_{i,i+1}|]
	  //             [|a{i+1,i+1}| |a_{i,i+1}|] [ sum[i]-|a_{i,i+1}| ]
	  //        =MAX([                        ]*[                    ])/det
	  //             [ |a{i+1,i}|     |a_ii|  ] [sum[i+1]-|a_{i,i+1}|]
	  // if the latter is smaller, then we prefer a 2x2 block
	  x=FABS(aii);
	  x2=FABS(aip1ip1);
	  sm=FABS(aiip1);
	  adiag=FABS(det);
	  // avoid 2x2 block rows if the off-diagonal entry is not sufficiently
	  // large
	  if (sm>1e-1*MIN(x,x2)) {
	     if ((x==0.0 && adiag!=0) ||
		 adiag*MAX(x2*sum[i],x*sum[i2])>
	         x*x2*MAX(x2*MAX(sum[i]-sm,0.0)+sm*MAX(sum[i2]-sm,0.0),
			  sm*MAX(sum[i]-sm,0.0)+x *MAX(sum[i2]-sm,0.0))) {
	        nextblock[i]=i2;
		nextblock[i2]=i;
		i++;
	     }
	  }
       } // end if i2<A.nc
   } // end for i

#ifdef PRINT_INFO
   for (j=0,i=0; i<A.nc; i++)
       if (nextblock[i]>=0) {
	 j+=2;i++;
       }
   printf("n=%7ld, 2x2 pivots %5.1lf%%\n",A.nc, (100.0*j)/A.nc);
   fflush(stdout);
#endif
} // end symbuildblock 
 
