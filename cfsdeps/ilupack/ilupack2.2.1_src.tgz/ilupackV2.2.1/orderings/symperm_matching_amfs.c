#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
#define _COMPLEX_SYMMETRIC_
#include "symperm_matching_amf.c"
#else
void myilupackdummy98()
{
}
#endif
