#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
#define _COMPLEX_SYMMETRIC_
#include "symperm_matching_amf_sp.c"
#else
void myilupackdummy203()
{
}
#endif
