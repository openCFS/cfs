#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
#define _COMPLEX_SYMMETRIC_
#include "symperm_mwm_metis_e_FCv.c"
#else
void myilupackdummy78()
{
}
#endif
