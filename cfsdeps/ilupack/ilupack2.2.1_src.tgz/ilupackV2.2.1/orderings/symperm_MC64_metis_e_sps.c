#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
#define _COMPLEX_SYMMETRIC_
#include "symperm_MC64_metis_e_sp.c"
#else
void myilupackdummy107()
{
}
#endif
