#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
#define _COMPLEX_SYMMETRIC_
#include "symperm_MC64_amd_FC.c"
#else
void myilupackdummy50()
{
}
#endif
