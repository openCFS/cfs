#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
#define _COMPLEX_SYMMETRIC_
#include "symperm_matching_metis_e_FC.c"
#else
void myilupackdummy89()
{
}
#endif
