#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
#define _COMPLEX_SYMMETRIC_
#include "symperm_nd_FCv.c"
#else
void myilupackdummy48()
{
}
#endif
