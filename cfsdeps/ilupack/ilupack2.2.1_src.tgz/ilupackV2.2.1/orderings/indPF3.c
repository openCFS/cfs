#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ilupack.h>


#include <ilupackmacros.h>

#define  ALPHA  0.00001





void WPDIAG(CSRMAT, integer *, integer *, REAL, integer *, REALS *, REALS *, REALS *, integer *);


integer PPERM(CSRMAT mat, integer bsize, integer *Pord, integer *Qord, integer *nnod, 
	   REALS tol, FLOAT *dbuff, integer *ibuff) {
/*--------------------------------------------------------------------- 
| algorithm for nonsymmetric  block selection - 
|----------------------------------------------------------------------
|     Input parameters:
|     -----------------
|     (mat)  =  matrix in SparRow format
|     
|     tol    =  a tolerance for excluding a row from B block 
|
|     bsize not used here - it is used in arms2.. 
|
|     Output parameters:
|     ------------------ 
|     Pord   = row permutation array.  Row number i will become row number 
|		Pord[i] in permuted matrix. (Old to new labels) 
|     Qord   = column permutation array.  Column number j will become 
|		row number Qord[j] in permuted matrix.
|             [destination lists] - i.e., old to new arrays= 
|     Here symmetric reordering
|     
|     nnod   = number of elements in the B-block 
|     
|---------------------------------------------------------------------*/ 
/*--------------------   local variables   */
  integer *icor, *jcor;
  integer i, j,  n=mat.nr, nnzrow, count, numnode;
  integer ii, jj, k, exclu, *row; 
  REALS wmax,wsum,s,t, mx;
  FLOAT *mrow;

/*-------------------- prototypes */
  integer check_perm(integer, integer *) ;   /* debug only */
/*-----------------------------------------------------------------------*/  
  
   for (j=0; j<n; j++) {
     Pord[j] = -1;
     Qord[j] = -1; 
   } // end for j

   icor = ibuff;     // 2*n   spaces required   totally 4*n integer spaces required
   jcor = ibuff+2*n; // 2*n   spaces required  

/*--------------------------------------------------
|  get coordinate format
|-------------------------------------------------*/
  numnode = 0;
  count = 0;
/*-------------------- wDiag selects candidate entries in sorted oder */
  /* use a weaker drop tolerance when preselecting rows/cols with a certain
     'diagonal dominance' weight */
  WPDIAG(mat, icor, jcor, tol, &count, &wmax,&wsum, (REALS *)dbuff, ibuff+4*n); 
/*-------------------- add entries one by one to diagnl */
  for (i = 0; i<count; i++){ 
    ii = icor[i];
    jj = jcor[i]; 
    if (Pord[ii] != -1 || Qord[jj] != -1) continue;
    row =mat.ja+mat.ia[ii]-1; 
    mrow=mat.a +mat.ia[ii]-1; 
    t =0.0;
    mx=0.0;
    for (k=0; k<mat.ia[ii+1]-mat.ia[ii]; k++) {
      j=row[k]-1;
      s=FABS(mrow[k]);
      /* fetch maximum value for row/column diagonal dominance */
      if (j==jj) 
	 mx=s; 
      /* check for row diagonal dominance with respect to previously chosen
         columns */
      if (Qord[j]>=0)  
	 t+=s;
    }
    t+=mx;

    /* check whether the diagonal dominance measures are already exceeded */
    if (mx<tol*wmax*t && mx<wsum*t) continue;

    for (k=0; k<mat.ia[ii+1]-mat.ia[ii]; k++) {
      j=row[k]-1;
      s=FABS(mrow[k]);
      /* do not include column j again */
      if (j!=jj && Qord[j]==-1) { 
	/* will row i loose its diagonal dominance? */
	if (mx<tol*wmax*(t+s) && mx<wsum*(t+s)) { 
	   /* exclude column j */
	   Qord[j]=-2;
	}
	else
	  /* another column is admissible without loosing diagonal dom. */
	  t+=s; 
      }
    }

    Pord[ii] = numnode;
    Qord[jj] = numnode;
    numnode++; 
  }
  /*-------------------- number of B nodes */
  *nnod = numnode; 
  /* printf(" nnod found = %d \n",*nnod);  */ 
/*--------------------------------------------------
|    end-main-loop - complete permutation arrays
|-------------------------------------------------*/
  for (i=0; i<n; i++)
    if (Pord[i] < 0) 
      Pord[i] = numnode++;

  if (numnode != n) {
    printf("  ** counting error - type 1 \n"); return 1; }   
  numnode = *nnod;
  for (j=0; j<n; j++)
    if (Qord[j] < 0)
      Qord[j] = numnode++;
/*--------------------              */ 
  if (numnode != n) {
    printf(" **  counting error type 2 (%d!=%d)\n",numnode,n); return 1; }

/*-------------------- debugging - check permutations */
  /*      printf(" checking P  and Q  :    -->  \n") ;
	  check_perm(n, Pord) ;
	  check_perm(n, Qord) ;
  */
/*--------------------------------------------------
|  clean up before returning
|-------------------------------------------------*/
  // free(icor);
  // free(jcor);
  return 0;
}
/*---------------------------------------------------------------------
|-----end-of-indsetP--------------------------------------------------
|--------------------------------------------------------------------*/

void WPDIAG(CSRMAT mat, integer *icor, integer *jcor, REALS tol, integer *count, 
	   REALS *wmax, REALS *wsum, REALS *dbuff, integer *ibuff) 
{
/*---------------------------------------------------------------------
|     defines weights based on diagonal dominance relative to 
|     excluded rows and columns
|    
|     fir indPO2.. [upper triangular reduction] 
|--------------------------------------------------------------------*/
  integer i, k, n=mat.nr, len, col, jmax, countL;
  integer *nz, *nzT, *jcol, *imax; 
  REALS *rownorm, *colnorm, *weight, s,t, tmax, *smax, diag;
  FLOAT *mrow;

/*--------------------begin */
  // rownorm = (REALS *)Malloc(n*sizeof(REAL),"wDiagRF:rownorm");
  // colnorm = (REALS *)Malloc(n*sizeof(REAL),"wDiagRF:colnorm");
  // smax =    (REALS *)Malloc(n*sizeof(REAL),"wDiagRF:smax");
  // weight  = (REALS *)Malloc(2*n*sizeof(REAL),"wDiagRF:smax");
  // nzT =     (integer *)   Malloc(n*sizeof(integer),"wDiagRF:nzT");
  // imax =    (integer *)   Malloc(n*sizeof(integer),"wDiagRF:imax");

  rownorm=dbuff;     // n   spaces required  
  colnorm=dbuff+n;   // n   spaces required   totally 5*n REALS spaces
  smax   =dbuff+2*n; // n   spaces required   
  weight =dbuff+3*n; // 2*n spaces required 
 
  nzT    =ibuff;     // n   spaces required    totally 2*n integer    spaces
  imax   =ibuff+n;   // n   spaces required 

  // nz =mat->nnzrow;
  len = 0; 
  for (i=0; i<n; i++) {
    rownorm[i] = 0.0;
    colnorm[i] = 0.0;
    smax[i] = 0.0;
    nzT[i] = 0; 
  }
/*-------------------- compute row + column norms and nzT */
  *wmax = 0.0; 
  *wsum = 0.0; 
  for (i=0; i<n; i++) {
    jcol = mat.ja+mat.ia[i]-1;
    mrow = mat.a +mat.ia[i]-1;
    tmax = 0.0; 
    jmax = 0; 
    diag=0.0;
    for (k =0; k<mat.ia[i+1]-mat.ia[i]; k++) {
      col = jcol[k]-1; 
      t = FABS(mrow[k]); 
      // store diagonal element
      if (col==i)
	 diag=t;
      if (t != 0.0) {
	colnorm[col] += t;
	rownorm[i] += t; 
	if ((tmax<t && jmax!=col) || (tmax<0.99*t && jmax==col) || (t>=0.99*tmax && col==i)) {
	  tmax = t;
	  jmax = col;
	}
	if ((smax[col]<t && imax[col]!=i) || (smax[col]<0.99*t && imax[col]==i) || (t>=0.99*smax[col] && col==i)) {
	  smax[col] = t;
	  imax[col] = i;
	}
	nzT[col]++; 
      }
    }
/*-------------------- save max diag. dominance ratio  */
    t = tmax / rownorm[i]; 
    if (*wmax < t)  *wmax = t; 
    *wsum += t; 
    t = diag / rownorm[i]; 
    weight[i]=t;
    jcor[i]  =i;
  }
  for (col=0; col<n; col++) {
      t = smax[col] / colnorm[col]; 
      if (*wmax < t)  *wmax = t; 
      *wsum += t; 

      // search in row 'col' for the diagonal entry 
      jcol = mat.ja+mat.ia[col]-1;
      mrow = mat.a +mat.ia[col]-1;
      diag=0.0;
      for (k =0; k<mat.ia[col+1]-mat.ia[col]; k++) {
	  i = jcol[k]-1; 
	  t = FABS(mrow[k]); 
	  // store diagonal element
	  if (col==i)
	     diag=t;
      } // end for k
      t = diag / colnorm[col]; 
      weight[n+col]=t;
      // i=imax[col];
      icor[n+col]  =col;
  }
  *wsum/=(2.0*n);
  //*wsum=*wmax;
/*-------------------- now select according to tol */
  countL = 0; 
  for (i=0; i<n; i++) {
    t =weight[i] ;
    col=jcor[i];
    s =weight[n+col];
    /* allow weaker diagonal dominance w.r.t the row */
    if (4.0*t<tol**wmax && t<*wsum && t<=0.51) continue ; 
    if (4.0*s<tol**wmax && s<*wsum && s<=0.51) continue ; 
    //weight[countL] = t /((REAL) (nzT[col]));
    weight[countL] = t*s/((REAL)(nzT[col]-1)*(REAL)(mat.ia[i+1]-mat.ia[i]-1)+1 );
    icor[countL] = i; 
    jcor[countL] = col; 
    countL++;
  }
  for (col=0; col<n; col++) {
      t  =weight[n+col] ;
      i=icor[n+col];
      s  =weight[i];
      if (2.0*t<tol**wmax && t<*wsum && t<=0.51) continue ;
      if (4.0*s<tol**wmax && s<*wsum && s<=0.51) continue ;
      //weight[countL] = t /((REAL) (mat.ia[i+1]-mat.ia[i]));
      weight[countL] = s*t / ((REAL)(nzT[col]-1)*(REAL)(mat.ia[i+1]-mat.ia[i]-1)+1 );
      icor[countL] = i; 
      jcor[countL] = col; 
      countL++;
  }
/*-------------------- sort them  */
  QSORTR2I(weight, icor, jcor, 0, countL-1);
  *count = countL;
  // printf(" nnod preselected = %d \n",countL);   
  // free(rownorm);
  // free(colnorm);
  // free(weight);
  // free(imax);
  // free(smax);
  // free(nzT);
}
/*---------------------------------------------------------------------
|---- end of wDiag ----------------------------------------------------
|--------------------------------------------------------------------*/



