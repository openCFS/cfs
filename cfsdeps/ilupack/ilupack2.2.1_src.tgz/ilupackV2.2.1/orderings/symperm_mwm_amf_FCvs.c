#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
#define _COMPLEX_SYMMETRIC_
#include "symperm_mwm_amf_FCv.c"
#else
void myilupackdummy83()
{
}
#endif
