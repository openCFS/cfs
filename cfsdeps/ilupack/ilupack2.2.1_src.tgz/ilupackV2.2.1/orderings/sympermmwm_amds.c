#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
#define _COMPLEX_SYMMETRIC_
#include "sympermmwm_amd.c"
#else
void myilupackdummy23()
{
}
#endif
