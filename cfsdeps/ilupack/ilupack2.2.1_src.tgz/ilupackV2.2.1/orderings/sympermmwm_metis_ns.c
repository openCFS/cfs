#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
#define _COMPLEX_SYMMETRIC_
#include "sympermmwm_metis_n.c"
#else
void myilupackdummy21()
{
}
#endif
