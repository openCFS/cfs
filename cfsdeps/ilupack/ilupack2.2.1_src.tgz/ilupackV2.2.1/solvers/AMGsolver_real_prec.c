#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
#define _REAL_PREC_
#include "AMGsolver.c"
#else
void myilupackdummy12()
{
}
#endif
