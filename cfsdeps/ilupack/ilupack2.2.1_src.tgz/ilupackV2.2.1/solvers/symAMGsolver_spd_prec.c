#define _SPD_PREC_
#include "symAMGsolver.c"
