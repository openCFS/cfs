#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include <blas.h>
#include <ilupack.h>

#include <ilupackmacros.h>

#define STDERR          stdout
#define STDOUT          stdout
//#define PRINT_INFO
#define MAX(A,B)        (((A)>(B))?(A):(B))
#define MIN(A,B)        (((A)<(B))?(A):(B))






void SPDAMGSETUPPARAMETERS(CSRMAT *A, ILUPACKPARAM *param, integer env)
/*
  written by Matthias Bollhoefer, October 2006
*/
{
   integer i;

   // ******************************************************************
   // new parameter selection scheme
   // ******************************************************************
   
   // first part: paramaters to be set up prior to building the 
   // preconditioner
   if (env==0) {
      // do FCpart and typetv have legal values? maybe not
      if (strncmp("yes",param->FCpart,3) && strncmp("none",param->FCpart,4)) {
	 param->FCpart="none";
      }
      // do we want to pre-select coarse grid nodes? yes
      if (param->FCpart!=NULL && strlen(param->FCpart)>0) {
	 if (!strncmp("yes",param->FCpart,3)) {
	    // do we want to use test vectors for filtering? yes
	    if (param->typetv!=NULL && strlen(param->typetv)>0) {
	       if (strncmp("none",param->typetv,4)) {
		  // 1. fine/coarse grid partitioning
		  // 2. ... based on static or dynamic test vector
		  if (param->ordering==NULL || strlen(param->ordering)==0) {
		     // custom settings from the user
		  }
		  else if (!strncmp("amd",param->ordering,3)) {
		     param->perm0         =SPDPERMAMDFCV;
		     param->perm          =SPDPERMAMDFCV;
		     param->permf         =SPDPERMPP;
		     param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		     param->flags  |=PREPROCESS_SUBSYSTEMS;
		     param->flags  |=FINAL_PIVOTING;
	          }
		  else if (!strncmp("metisn",param->ordering,6)) {
	             param->perm0         =SPDPERMMETISNFCV;
		     param->perm          =SPDPERMMETISNFCV;
		     param->permf         =SPDPERMPP;
		     param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		     param->flags  |=PREPROCESS_SUBSYSTEMS;
		     param->flags  |=FINAL_PIVOTING;
	          }
		  else if (!strncmp("metise",param->ordering,6)) {
	             param->perm0         =SPDPERMMETISEFCV;
		     param->perm          =SPDPERMMETISEFCV;
		     param->permf         =SPDPERMPP;
		     param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		     param->flags  |=PREPROCESS_SUBSYSTEMS;
		     param->flags  |=FINAL_PIVOTING;
	          }
		  else if (!strncmp("rcm",param->ordering,3)) {
	             param->perm0         =SPDPERMRCMFCV;
		     param->perm          =SPDPERMRCMFCV;
		     param->permf         =SPDPERMPP;
		     param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		     param->flags  |=PREPROCESS_SUBSYSTEMS;
		     param->flags  |=FINAL_PIVOTING;
	          }
		  else if (!strncmp("amf",param->ordering,3)) {
	             param->perm0         =SPDPERMAMFFCV;
		     param->perm          =SPDPERMAMFFCV;
		     param->permf         =SPDPERMPP;
		     param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		     param->flags  |=PREPROCESS_SUBSYSTEMS;
		     param->flags  |=FINAL_PIVOTING;
	          }
		  else if (!strncmp("mmd",param->ordering,3)) {
	             param->perm0         =SPDPERMMMDFCV;
		     param->perm          =SPDPERMMMDFCV;
		     param->permf         =SPDPERMPP;
		     param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		     param->flags  |=PREPROCESS_SUBSYSTEMS;
		     param->flags  |=FINAL_PIVOTING;
	          }
		  /*
		  else if (!strncmp("indset",param->ordering,6)) {
	             param->perm0         =SPDPERMINDSETFCV;
		     param->perm          =SPDPERMINDSETFCV;
		     param->permf         =SPDPERMPP;
		     param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		     param->flags  |=PREPROCESS_SUBSYSTEMS;
		     param->flags  |=FINAL_PIVOTING;
	          }
                  */
		  else if (!strncmp("none",param->ordering,4)) {
	             param->perm0         =SYMPERMFCV;
		     param->perm          =SYMPERMFCV;
		     param->permf         =SPDPERMPP;
		     param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		     param->flags  |=PREPROCESS_SUBSYSTEMS;
		     param->flags  |=FINAL_PIVOTING;
	          }
		  else if (!strncmp("pp",param->ordering,2)) {
		     param->perm0         =SPDPERMPP;
		     param->perm          =SPDPERMPP;
		     param->permf         =SPDPERMPP;
		     // ignore permf
		     param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		     param->flags  |=PREPROCESS_SUBSYSTEMS;
		     param->flags  &=~FINAL_PIVOTING;
		  }
		  // no sensible string
		  else {
		     // custom settings from the user
		  }
	       }
	       // 2. no test vector
	       else {
	          // 1. fine/coarse grid partitioning
		  // 1. no test vector
		  if (param->ordering==NULL || strlen(param->ordering)==0) {
		     // custom settings from the user
		  }
		  else if (!strncmp("amd",param->ordering,3)) {
	             param->perm0         =SPDPERMAMDFC;
		     param->perm          =SPDPERMAMDFC;
		     param->permf         =SPDPERMPP;
		     param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		     param->flags  |=PREPROCESS_SUBSYSTEMS;
		     param->flags  |=FINAL_PIVOTING;
	          }
		  else if (!strncmp("metisn",param->ordering,6)) {
	             param->perm0         =SPDPERMMETISNFC;
		     param->perm          =SPDPERMMETISNFC;
		     param->permf         =SPDPERMPP;
		     param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		     param->flags  |=PREPROCESS_SUBSYSTEMS;
		     param->flags  |=FINAL_PIVOTING;
	          }
		  else if (!strncmp("metise",param->ordering,6)) {
	             param->perm0         =SPDPERMMETISEFC;
		     param->perm          =SPDPERMMETISEFC;
		     param->permf         =SPDPERMPP;
		     param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		     param->flags  |=PREPROCESS_SUBSYSTEMS;
		     param->flags  |=FINAL_PIVOTING;
	          }
		  else if (!strncmp("rcm",param->ordering,3)) {
	             param->perm0         =SPDPERMRCMFC;
		     param->perm          =SPDPERMRCMFC;
		     param->permf         =SPDPERMPP;
		     param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		     param->flags  |=PREPROCESS_SUBSYSTEMS;
		     param->flags  |=FINAL_PIVOTING;
	          }
		  else if (!strncmp("amf",param->ordering,3)) {
	             param->perm0         =SPDPERMAMFFC;
		     param->perm          =SPDPERMAMFFC;
		     param->permf         =SPDPERMPP;
		     param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		     param->flags  |=PREPROCESS_SUBSYSTEMS;
		     param->flags  |=FINAL_PIVOTING;
	          }
		  else if (!strncmp("mmd",param->ordering,3)) {
	             param->perm0         =SPDPERMMMDFC;
		     param->perm          =SPDPERMMMDFC;
		     param->permf         =SPDPERMPP;
		     param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		     param->flags  |=PREPROCESS_SUBSYSTEMS;
		     param->flags  |=FINAL_PIVOTING;
	          }
		  /*
		  else if (!strncmp("indset",param->ordering,6)) {
	             param->perm0         =SPDPERMINDSETFC;
		     param->perm          =SPDPERMINDSETFC;
		     param->permf         =SPDPERMPP;
		     param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		     param->flags  |=PREPROCESS_SUBSYSTEMS;
		     param->flags  |=FINAL_PIVOTING;
	          }
		  */
		  else if (!strncmp("none",param->ordering,4)) {
	             param->perm0         =SYMPERMFC;
		     param->perm          =SYMPERMFC;
		     param->permf         =SPDPERMPP;
		     param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		     param->flags  |=PREPROCESS_SUBSYSTEMS;
		     param->flags  |=FINAL_PIVOTING;
	          }
		  else if (!strncmp("pp",param->ordering,2)) {
		     param->perm0         =SPDPERMPP;
		     param->perm          =SPDPERMPP;
		     param->permf         =SPDPERMPP;
		     // ignore permf
		     param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		     param->flags  |=PREPROCESS_SUBSYSTEMS;
		     param->flags  &=~FINAL_PIVOTING;
		  }
		  // no sensible string
		  else  {
		     // custom settings from the user
		  }
	       }
	    }
	    // no sensible string
	    else {
	       // custom settings from the user
	    }
	 }
	 // do we want to pre-select coarse grid nodes? no
	 else {
	    // 1. no fine/coarse grid partitioning
	    // 2. ... whatever the test vector will be
	    // no sensible string
	    if (param->ordering==NULL || strlen(param->ordering)==0) {
	       // custom settings from the user
	    }
	    else if (!strncmp("amd",param->ordering,3)) {
	       param->perm0         =SPDPERMAMD;
	       param->perm          =SPDPERMAMD;
	       param->permf         =SPDPERMPP;
	       param->flags  |=PREPROCESS_INITIAL_SYSTEM;
	       param->flags  |=PREPROCESS_SUBSYSTEMS;
	       param->flags  |=FINAL_PIVOTING;
	    }
	    else if (!strncmp("metisn",param->ordering,6)) {
	       param->perm0         =SPDPERMMETISN;
	       param->perm          =SPDPERMMETISN;
	       param->permf         =SPDPERMPP;
	       param->flags  |=PREPROCESS_INITIAL_SYSTEM;
	       param->flags  |=PREPROCESS_SUBSYSTEMS;
	       param->flags  |=FINAL_PIVOTING;
	    }
	    else if (!strncmp("metise",param->ordering,6)) {
	       param->perm0         =SPDPERMMETISE;
	       param->perm          =SPDPERMMETISE;
	       param->permf         =SPDPERMPP;
	       param->flags  |=PREPROCESS_INITIAL_SYSTEM;
	       param->flags  |=PREPROCESS_SUBSYSTEMS;
	       param->flags  |=FINAL_PIVOTING;
	    }
	    else if (!strncmp("rcm",param->ordering,3)) {
	       param->perm0         =SPDPERMRCM;
	       param->perm          =SPDPERMRCM;
	       param->permf         =SPDPERMPP;
	       param->flags  |=PREPROCESS_INITIAL_SYSTEM;
	       param->flags  |=PREPROCESS_SUBSYSTEMS;
	       param->flags  |=FINAL_PIVOTING;
	    }
	    else if (!strncmp("amf",param->ordering,3)) {
	       param->perm0         =SPDPERMAMF;
	       param->perm          =SPDPERMAMF;
	       param->permf         =SPDPERMPP;
	       param->flags  |=PREPROCESS_INITIAL_SYSTEM;
	       param->flags  |=PREPROCESS_SUBSYSTEMS;
	       param->flags  |=FINAL_PIVOTING;
	    }
	    else if (!strncmp("mmd",param->ordering,3)) {
	       param->perm0         =SPDPERMMMD;
	       param->perm          =SPDPERMMMD;
	       param->permf         =SPDPERMPP;
	       param->flags  |=PREPROCESS_INITIAL_SYSTEM;
	       param->flags  |=PREPROCESS_SUBSYSTEMS;
	       param->flags  |=FINAL_PIVOTING;
	    }
	    /*
	    else if (!strncmp("indset",param->ordering,6)) {
	       param->perm0         =SPDPERMINDSET;
	       param->perm          =SPDPERMINDSET;
	       param->permf         =SPDPERMPP;
	       param->flags  |=PREPROCESS_INITIAL_SYSTEM;
	       param->flags  |=PREPROCESS_SUBSYSTEMS;
	       param->flags  |=FINAL_PIVOTING;
	    } 
	    */
	    else if (!strncmp("none",param->ordering,4)) {
	       param->perm0         =SPDPERMNULL;
	       param->perm          =SPDPERMNULL;
	       param->permf         =SPDPERMPP;
	       param->flags  |=PREPROCESS_INITIAL_SYSTEM;
	       param->flags  |=PREPROCESS_SUBSYSTEMS;
	       param->flags  |=FINAL_PIVOTING;
	    }
	    else if (!strncmp("pp",param->ordering,2)) {
	       param->perm0         =SPDPERMPP;
	       param->perm          =SPDPERMPP;
	       param->permf         =SPDPERMPP;
	       // ignore permf
	       param->flags  |=PREPROCESS_INITIAL_SYSTEM;
	       param->flags  |=PREPROCESS_SUBSYSTEMS;
	       param->flags  &=~FINAL_PIVOTING;
	    }
	    // no sensible string
	    else {
	       // custom settings from the user
	    }
	 }
      }
      // no sensible string
      else {
	 // custom settings from the user
      }

      param->fpar[ 1]=param->droptol;
      param->fpar[ 8]=param->droptolS;
      param->fpar[ 2]=param->condest;
      param->ipar[ 0]=ceil(param->elbow);
      param->ipar[ 3]=param->lfil;
      param->ipar[ 9]=param->lfilS;

      // test vector
      if (param->typetv!=NULL && strlen(param->typetv)>0) {
	 if (!strncmp("static",param->typetv,6)) {
	    param->flags|=DIAGONAL_COMPENSATION|STATIC_TESTVECTOR; 
	    param->flags&=~ENSURE_SPD;
	 }
	 else if (strncmp("none",param->typetv,4)) {
	    param->flags|=DIAGONAL_COMPENSATION|DYNAMIC_TESTVECTOR;
	    param->flags&=~ENSURE_SPD;
	 }
	 if (strncmp("none",param->typetv,4)) {
	    if (param->ntestvector==0) {
	       param->ntestvector=2*A->nc;
	       param->testvector=(FLOAT *)MALLOC((size_t)param->ntestvector*sizeof(FLOAT),
						 "AMGsetupparameters:param->testvector");
	    }
	    else {
	       param->ntestvector=MAX(2*A->nc,param->ntestvector);
	       param->testvector=(FLOAT *)REALLOC(param->testvector,
						  (size_t)param->ntestvector*sizeof(FLOAT),
						  "AMGsetupparameters:param->testvector");
	    }
	    memcpy(param->testvector, param->tv, A->nc*sizeof(FLOAT));
	 }
      }

      // capture the old style
      if (param->flags&DIAGONAL_COMPENSATION) {
	 if (param->ntestvector==0)
	    param->ntestvector=2*A->nc;
	 else
	    param->ntestvector=MAX(2*A->nc,param->ntestvector);
	 
	 if (param->testvector==NULL)
	    param->testvector=(FLOAT *)MALLOC((size_t)param->ntestvector*sizeof(FLOAT),
					      "AMGsetupparameters:param->testvector");
	 else
	    param->testvector=(FLOAT *)REALLOC(param->testvector,
					       (size_t)param->ntestvector*sizeof(FLOAT),
					       "AMGsetupparameters:param->testvector");
	 // diagonal compensation in the classical sense using the 1-vector 
	 if (!(param->flags&STATIC_TESTVECTOR) && 
	     !(param->flags&DYNAMIC_TESTVECTOR)) {
	    for (i=0; i<A->nc; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	        param->testvector[i]=1.0;
#else
		param->testvector[i].r=1.0;
		param->testvector[i].i=0.0;
#endif
	    } // end for
	 }
      }

      // type of coarse grid system
      if (param->typecoarse!=NULL && strlen(param->typecoarse)>0) {
	 if (!strncmp("ilu",param->typecoarse,3)) {
	    param->flags&=~TISMENETSKY_SC;
	    param->flags|=SIMPLE_SC;
	 }
	 else if (!strncmp("amg",param->typecoarse,3)) {
	    param->flags&=~TISMENETSKY_SC;
	    param->flags&=~SIMPLE_SC;
	 }
      }

      // type of multigrid
      if (strncmp("ilu",param->amg,3) && strncmp("amli",param->amg,4) && 
	  strncmp("mg",param->amg,2)) {
	 param->amg="ilu";
      }

      if (param->amg!=NULL && strlen(param->amg)>0) {
	 if (!strncmp("ilu",param->amg,3))
	    param->ipar[10]=0;
	 else if (!strncmp("amli",param->amg,4))
	    param->ipar[10]=1;
	 else if (!strncmp("mg",param->amg,2))
	    param->ipar[10]=2;
	 else {
	    param->amg="ilu";
	    param->ipar[10]=0;
	 }
      }
      
      // flags only used to set up the preconditioner
      param->ipar[6] =param->flags;
   }
   // env!=0
   // setup parameters that only affect the iterative part
   else {
      param->npresmoothing=MAX(param->npresmoothing,param->npostsmoothing);
      param->npostsmoothing=param->npresmoothing;
      param->ipar[12]=param->ipar[13]=param->npresmoothing;
      param->ipar[11]=param->ncoarse;
      param->fpar[20]=param->restol;
      param->ipar[24]=param->nrestart;
      param->ipar[25]=param->maxit;


      // pre- and post smoother (if used with "mg")
      if (param->presmoother!=NULL && strlen(param->presmoother)>0) {
	 if (!strncmp("gsf",param->presmoother,3)) {
	    param->ipar[14]=1;
	    param->ipar[15]=2;
	 }
	 else if (!strncmp("gsb",param->presmoother,3)) {
	    param->ipar[14]=2;
	    param->ipar[15]=1;
	 }
	 else if (!strncmp("j",param->presmoother,1)) {
	    param->ipar[14]=3;
	    param->ipar[15]=3;
	 }
	 else if (!strncmp("ilu",param->presmoother,3)) {
	    param->ipar[14]=4;
	    param->ipar[15]=4;
	 }
	 else { // custom
	    param->ipar[14]=5;
	    param->ipar[15]=5;
	 }
      }

      // set up solver and prepare memory allocation for the 
      // iterative solver 
      i=param->ipar[24];
      if (!strncmp("sbcg",param->solver,4)) {
	 param->ipar[5]=2;
	 i=5*A->nr;
      }
      else if (!strncmp("bcg",param->solver,3)) {
	 param->ipar[5]=3;
	 i=7*A->nr;
      }
      else if (!strncmp("sqmr",param->solver,4)) {
	 param->ipar[5]=4;
	 i=6*A->nr;
      }
      else if (!strncmp("gmres",param->solver,5)) {
	 param->ipar[5]=8;
	 i=(A->nr+3)*(i+2)+(i+1)*i/2;
      }
      else if (!strncmp("fgmres",param->solver,6)) {
	 param->ipar[5]=9;
	 i=2*A->nr*(i+1)+((i+1)*i)/2 + 3*i + 2;
      }
      else if (!strncmp("fcg",param->solver,3)) {
	 param->ipar[5]=21;
	 i=(5+2*i)*A->nr+i+1;
      }
      else {
	 param->solver="cg";
	 param->ipar[5]=1;
	 i=5*A->nr;
      } // end switch
      // memory required by the iterative method
      param->ipar[23]=i;

      // type of multigrid
      if (strncmp("ilu",param->amg,3) && strncmp("amli",param->amg,4) && 
	  strncmp("mg",param->amg,2)) {
	 param->amg="ilu";
      }
      if (param->amg!=NULL && strlen(param->amg)>0) {
         if (!strncmp("ilu",param->amg,3))
	    param->ipar[10]=0;
	 // note that in order to apply amli or mg the coarse grid
	 // systems had to be kept during the computation of the preconditioner
	 else if (!(param->ipar[16]&DISCARD_MATRIX)) {
	    if (!strncmp("amli",param->amg,4))
	       param->ipar[10]=1;
	    else if (!strncmp("mg",param->amg,2))
	       param->ipar[10]=2;
	    else {
	       param->amg="ilu";
	       param->ipar[10]=0;
	    }
	 }
	 else {
	    param->amg="ilu";
	    param->ipar[10]=0;
	 }
      }

   } // end if-else env=0

} // end spdAMGsetupparameters

