#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include <blas.h>
#include <ilupack.h>

#include <ilupackmacros.h>

#define STDERR          stdout
#define STDOUT          stdout
// #define PRINT_INFO
#define MAX(A,B)        (((A)>(B))?(A):(B))
#define MIN(A,B)        (((A)<(B))?(A):(B))





void AMGSETUPPARAMETERS(CSRMAT *A, ILUPACKPARAM *param, integer env)
/*
  written by Matthias Bollhoefer, October 2006
*/
{
   integer i;
   
   // ******************************************************************
   // new parameter selection scheme
   // ******************************************************************

   // first part: paramaters to be set up prior to building the 
   // preconditioner
   if (env==0) {
      // do FCpart and typetv have legal values? maybe not
      if (strncmp("yes",param->FCpart,3) && strncmp("none",param->FCpart,4)) {
	 param->FCpart="none";
      }
      // first step: carefully select the drivers
      // is matching turned on? yes
      if (param->matching) {
	 // do we want to pre-select coarse grid nodes? yes
	 if (param->FCpart!=NULL && strlen(param->FCpart)>0) {
	    if (!strncmp("yes",param->FCpart,3)) {
	       // do we want to use test vectors for filtering? yes
	       if (param->typetv!=NULL && strlen(param->typetv)>0) {
		  if (strncmp("none",param->typetv,4)) {
		     // 1. maximum weight matching
		     // 2. fine/coarse grid partitioning
		     // 3. ... based on static or dynamic test vector
		     if (param->ordering==NULL || strlen(param->ordering)==0) {
		        // custom settings from the user
		     }
		     /*
		     else if (!strncmp("amd",param->ordering,3)) {
#ifdef _MC64_MATCHING_
  		        param->perm0         =PERMMC64AMDFCV;
#elif defined _PARDISO_MATCHING_
		        param->perm0         =PERMMWMAMDFCV;
#else // _MUMPS_MATCHING_ assumed by default
		        param->perm0         =PERMMATCHINGAMDFCV;
#endif
			param->perm          =PERMAMDFCV;
			param->permf         =PERMPQ;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  |=FINAL_PIVOTING;
		     }
		     else if (!strncmp("metisn",param->ordering,6)) {
#ifdef _MC64_MATCHING_
  		        param->perm0         =PERMMC64METISNFCV;
#elif defined _PARDISO_MATCHING_
		        param->perm0         =PERMMWMMETISNFCV;
#else // _MUMPS_MATCHING_ assumed by default
		        param->perm0         =PERMMATCHINGMETISNFCV;
#endif
			param->perm          =PERMMETISNFCV;
			param->permf         =PERMPQ;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  |=FINAL_PIVOTING;
		     }
		     else if (!strncmp("metise",param->ordering,6)) {
#ifdef _MC64_MATCHING_
  		        param->perm0         =PERMMC64METISEFCV;
#elif defined _PARDISO_MATCHING_
		        param->perm0         =PERMMWMMETISEFCV;
#else // _MUMPS_MATCHING_ assumed by default
		        param->perm0         =PERMMATCHINGMETISEFCV;
#endif
			param->perm          =PERMMETISEFCV;
			param->permf         =PERMPQ;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  |=FINAL_PIVOTING;
		     }
		     else if (!strncmp("rcm",param->ordering,3)) {
#ifdef _MC64_MATCHING_
  		        param->perm0         =PERMMC64RCMFCV;
#elif defined _PARDISO_MATCHING_
		        param->perm0         =PERMMWMRCMFCV;
#else // _MUMPS_MATCHING_ assumed by default
		        param->perm0         =PERMMATCHINGRCMFCV;
#endif
			param->perm          =PERMRCMFCV;
			param->permf         =PERMPQ;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  |=FINAL_PIVOTING;
		     }
		     else if (!strncmp("amf",param->ordering,3)) {
#ifdef _MC64_MATCHING_
  		        param->perm0         =PERMMC64AMFFCV;
#elif defined _PARDISO_MATCHING_
		        param->perm0         =PERMMWMAMFFCV;
#else // _MUMPS_MATCHING_ assumed by default
		        param->perm0         =PERMMATCHINGAMFFCV;
#endif
			param->perm          =PERMAMFFCV;
			param->permf         =PERMPQ;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  |=FINAL_PIVOTING;
		     }
		     else if (!strncmp("mmd",param->ordering,3)) {
#ifdef _MC64_MATCHING_
  		        param->perm0         =PERMMC64MMDFCV;
#elif defined _PARDISO_MATCHING_
		        param->perm0         =PERMMWMMMDFCV;
#else // _MUMPS_MATCHING_ assumed by default
		        param->perm0         =PERMMATCHINGMMDFCV;
#endif
			param->perm          =PERMMMDFCV;
			param->permf         =PERMPQ;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  |=FINAL_PIVOTING;
		     }
		     else if (!strncmp("indset",param->ordering,6)) {
#ifdef _MC64_MATCHING_
  		        param->perm0         =PERMMC64INDSETFCV;
#elif defined _PARDISO_MATCHING_
		        param->perm0         =PERMMWMINDSETFCV;
#else // _MUMPS_MATCHING_ assumed by default
		        param->perm0         =PERMMATCHINGINDSETFCV;
#endif
			param->perm          =PERMINDSETFCV;
			param->permf         =PERMPQ;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  |=FINAL_PIVOTING;
		     }
		     else if (!strncmp("none",param->ordering,4)) {
#ifdef _MC64_MATCHING_
  		        param->perm0         =PERMMC64FCV;
#elif defined _PARDISO_MATCHING_
		        param->perm0         =PERMMWMFCV;
#else // _MUMPS_MATCHING_ assumed by default
		        param->perm0         =PERMMATCHINGFCV;
#endif
		        param->perm          =PERMFCV;
			param->permf         =PERMPQ;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  |=FINAL_PIVOTING;
		     }
		     */
		     else if (!strncmp("pq",param->ordering,2)) {
		        param->perm0         =PERMPQ;
			param->perm          =PERMPQ;
			param->permf         =PERMPQ;
			// ignore permf
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  &=~FINAL_PIVOTING;
		     }
		     // no sensible string
		     else {
		        // custom settings from the user
		     }
		  }
		  // 3. no test vector
		  else {
	             // 1. maximum weight matching
		     // 2. fine/coarse grid partitioning
		     // 3. no test vector
		     if (param->ordering==NULL || strlen(param->ordering)==0) {
		        // custom settings from the user
		     }
		     /*
		     else if (!strncmp("amd",param->ordering,3)) {
#ifdef _MC64_MATCHING_
  		        param->perm0         =PERMMC64AMDFC;
#elif defined _PARDISO_MATCHING_
		        param->perm0         =PERMMWMAMDFC;
#else // _MUMPS_MATCHING_ assumed by default
		        param->perm0         =PERMMATCHINGAMDFC;
#endif
			param->perm          =PERMAMDFC;
			param->permf         =PERMPQ;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  |=FINAL_PIVOTING;
		     }
		     else if (!strncmp("metisn",param->ordering,6)) {
#ifdef _MC64_MATCHING_
  		        param->perm0         =PERMMC64METISNFC;
#elif defined _PARDISO_MATCHING_
		        param->perm0         =PERMMWMMETISNFC;
#else // _MUMPS_MATCHING_ assumed by default
		        param->perm0         =PERMMATCHINGMETISNFC;
#endif
			param->perm          =PERMMETISNFC;
			param->permf         =PERMPQ;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  |=FINAL_PIVOTING;
		     }
		     else if (!strncmp("metise",param->ordering,6)) {
#ifdef _MC64_MATCHING_
  		        param->perm0         =PERMMC64METISEFC;
#elif defined _PARDISO_MATCHING_
		        param->perm0         =PERMMWMMETISEFC;
#else // _MUMPS_MATCHING_ assumed by default
		        param->perm0         =PERMMATCHINGMETISEFC;
#endif
			param->perm          =PERMMETISEFC;
			param->permf         =PERMPQ;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  |=FINAL_PIVOTING;
		     }
		     else if (!strncmp("rcm",param->ordering,3)) {
#ifdef _MC64_MATCHING_
  		        param->perm0         =PERMMC64RCMFC;
#elif defined _PARDISO_MATCHING_
		        param->perm0         =PERMMWMRCMFC;
#else // _MUMPS_MATCHING_ assumed by default
		        param->perm0         =PERMMATCHINGRCMFC;
#endif
			param->perm          =PERMRCMFC;
			param->permf         =PERMPQ;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  |=FINAL_PIVOTING;
		     }
		     else if (!strncmp("amf",param->ordering,3)) {
#ifdef _MC64_MATCHING_
  		        param->perm0         =PERMMC64AMFFC;
#elif defined _PARDISO_MATCHING_
		        param->perm0         =PERMMWMAMFFC;
#else // _MUMPS_MATCHING_ assumed by default
		        param->perm0         =PERMMATCHINGAMFFC;
#endif
			param->perm          =PERMAMFFC;
			param->permf         =PERMPQ;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  |=FINAL_PIVOTING;
		     }
		     else if (!strncmp("mmd",param->ordering,3)) {
#ifdef _MC64_MATCHING_
  		        param->perm0         =PERMMC64MMDFC;
#elif defined _PARDISO_MATCHING_
		        param->perm0         =PERMMWMMMDFC;
#else // _MUMPS_MATCHING_ assumed by default
		        param->perm0         =PERMMATCHINGMMDFC;
#endif
			param->perm          =PERMMMDFC;
			param->permf         =PERMPQ;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  |=FINAL_PIVOTING;
		     }
		     else if (!strncmp("indset",param->ordering,6)) {
#ifdef _MC64_MATCHING_
  		        param->perm0         =PERMMC64INDSETFC;
#elif defined _PARDISO_MATCHING_
		        param->perm0         =PERMMWMINDSETFC;
#else // _MUMPS_MATCHING_ assumed by default
		        param->perm0         =PERMMATCHINGINDSETFC;
#endif
			param->perm          =PERMINDSETFC;
			param->permf         =PERMPQ;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  |=FINAL_PIVOTING;
		     }
		     else if (!strncmp("none",param->ordering,4)) {
#ifdef _MC64_MATCHING_
  		        param->perm0         =PERMMC64FC;
#elif defined _PARDISO_MATCHING_
		        param->perm0         =PERMMWMFC;
#else // _MUMPS_MATCHING_ assumed by default
		        param->perm0         =PERMMATCHINGFC;
#endif
			param->perm          =PERMFC;
			param->permf         =PERMPQ;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  |=FINAL_PIVOTING;
		     }
		     */
		     else if (!strncmp("pq",param->ordering,2)) {
		        param->perm0         =PERMPQ;
			param->perm          =PERMPQ;
			param->permf         =PERMPQ;
			// ignore permf
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  &=~FINAL_PIVOTING;
		     }
		     // no sensible string
		     else  {
		        // custom settings from the user
		     }
		  }
	       }
	       // no sensible string
	       else {
		  // custom settings from the user
	       }
	    }
	    // do we want to pre-select coarse grid nodes? no
	    else {
	       // 1. maximum weight matching
	       // 2. no fine/coarse grid partitioning
	       // 3. ... whatever the test vector will be
	       // no sensible string
	       if (param->ordering==NULL || strlen(param->ordering)==0) {
		  // custom settings from the user
	       }
	       else if (!strncmp("amd",param->ordering,3)) {
#ifdef _MC64_MATCHING_
		  param->perm0         =PERMMC64AMD;
#elif defined _PARDISO_MATCHING_
		  param->perm0         =PERMMWMAMD;
#else /* _MUMPS_MATCHING_ assumed by default */
		  param->perm0         =PERMMATCHINGAMD;
#endif
		  param->perm          =PERMAMD;
		  param->permf         =PERMPQ;
		  param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		  param->flags  |=PREPROCESS_SUBSYSTEMS;
		  param->flags  |=FINAL_PIVOTING;
	       }
	       else if (!strncmp("metisn",param->ordering,6)) {
#ifdef _MC64_MATCHING_
		  param->perm0         =PERMMC64METISN;
#elif defined _PARDISO_MATCHING_
		  param->perm0         =PERMMWMMETISN;
#else /* _MUMPS_MATCHING_ assumed by default */
		  param->perm0         =PERMMATCHINGMETISN;
#endif
		  param->perm          =PERMMETISN;
		  param->permf         =PERMPQ;
		  param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		  param->flags  |=PREPROCESS_SUBSYSTEMS;
		  param->flags  |=FINAL_PIVOTING;
	       }
	       else if (!strncmp("metise",param->ordering,6)) {
#ifdef _MC64_MATCHING_
		  param->perm0         =PERMMC64METISE;
#elif defined _PARDISO_MATCHING_
		  param->perm0         =PERMMWMMETISE;
#else /* _MUMPS_MATCHING_ assumed by default */
		  param->perm0         =PERMMATCHINGMETISE;
#endif
		  param->perm          =PERMMETISE;
		  param->permf         =PERMPQ;
		  param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		  param->flags  |=PREPROCESS_SUBSYSTEMS;
		  param->flags  |=FINAL_PIVOTING;
	       }
	       else if (!strncmp("rcm",param->ordering,3)) {
#ifdef _MC64_MATCHING_
		  param->perm0         =PERMMC64RCM;
#elif defined _PARDISO_MATCHING_
		  param->perm0         =PERMMWMRCM;
#else /* _MUMPS_MATCHING_ assumed by default */
		  param->perm0         =PERMMATCHINGRCM;
#endif
		  param->perm          =PERMRCM;
		  param->permf         =PERMPQ;
		  param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		  param->flags  |=PREPROCESS_SUBSYSTEMS;
		  param->flags  |=FINAL_PIVOTING;
	       }
	       else if (!strncmp("amf",param->ordering,3)) {
#ifdef _MC64_MATCHING_
		  param->perm0         =PERMMC64AMF;
#elif defined _PARDISO_MATCHING_
		  param->perm0         =PERMMWMAMF;
#else /* _MUMPS_MATCHING_ assumed by default */
		  param->perm0         =PERMMATCHINGAMF;
#endif
		  param->perm          =PERMAMF;
		  param->permf         =PERMPQ;
		  param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		  param->flags  |=PREPROCESS_SUBSYSTEMS;
		  param->flags  |=FINAL_PIVOTING;
	       }
	       else if (!strncmp("mmd",param->ordering,3)) {
#ifdef _MC64_MATCHING_
		  param->perm0         =PERMMC64MMD;
#elif defined _PARDISO_MATCHING_
		  param->perm0         =PERMMWMMMD;
#else /* _MUMPS_MATCHING_ assumed by default */
		  param->perm0         =PERMMATCHINGMMD;
#endif
		  param->perm          =PERMMMD;
		  param->permf         =PERMPQ;
		  param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		  param->flags  |=PREPROCESS_SUBSYSTEMS;
		  param->flags  |=FINAL_PIVOTING;
	       }
	       /*
	       else if (!strncmp("indset",param->ordering,6)) {
#ifdef _MC64_MATCHING_
	          param->perm0         =PERMMC64INDSET;
#elif defined _PARDISO_MATCHING_
		  param->perm0         =PERMMWMINDSET;
#else // _MUMPS_MATCHING_ assumed by default
		  param->perm0         =PERMMATCHINGINDSET;
#endif
		  param->perm          =PERMINDSET;
		  param->permf         =PERMPQ;
		  param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		  param->flags  |=PREPROCESS_SUBSYSTEMS;
		  param->flags  |=FINAL_PIVOTING;
	       } 
	       else if (!strncmp("none",param->ordering,4)) {
#ifdef _MC64_MATCHING_
	          param->perm0         =PERMMC64;
#elif defined _PARDISO_MATCHING_
		  param->perm0         =PERMMWM;
#else // _MUMPS_MATCHING_ assumed by default
		  param->perm0         =PERMMATCHING;
#endif
		  param->perm          =PERMNULL;
		  param->permf         =PERMPQ;
		  param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		  param->flags  |=PREPROCESS_SUBSYSTEMS;
		  param->flags  |=FINAL_PIVOTING;
	       }
	       */
	       else if (!strncmp("pq",param->ordering,2)) {
		  param->perm0         =PERMPQ;
		  param->perm          =PERMPQ;
		  param->permf         =PERMPQ;
		  // ignore permf
		  param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		  param->flags  |=PREPROCESS_SUBSYSTEMS;
		  param->flags  &=~FINAL_PIVOTING;
	       }
	       // no sensible string
	       else {
		  // custom settings from the user
	       }
	    }
	 }
	 // no sensible string
	 else {
	    // custom settings from the user
	 }
      }
      // no matching
      else {
	 // do we want to pre-select coarse grid nodes? yes
	 if (param->FCpart!=NULL && strlen(param->FCpart)>0) {
	    if (!strncmp("yes",param->FCpart,3)) {
	       // do we want to use test vectors for filtering? yes
	       if (param->typetv!=NULL && strlen(param->typetv)>0) {
		  if (strncmp("none",param->typetv,4)) {
		     // 1. no matching
		     // 2. fine/coarse grid partitioning
		     // 3. ... based on static or dynamic test vector
		     // no sensible string
		     if (param->ordering==NULL || strlen(param->ordering)==0) {
		        // custom settings from the user
		     }
		     /*
		     else if (!strncmp("amd",param->ordering,3)) {
		        param->perm0         =PERMAMDFCV;
			param->perm          =PERMAMDFCV;
			param->permf         =PERMPQ;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  |=FINAL_PIVOTING;
		     }
		     else if (!strncmp("metisn",param->ordering,6)) {
		        param->perm0         =PERMMETISNFCV;
			param->perm          =PERMMETISNFCV;
			param->permf         =PERMPQ;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  |=FINAL_PIVOTING;
		     }
		     else if (!strncmp("metise",param->ordering,6)) {
	                param->perm0         =PERMMETISEFCV;
			param->perm          =PERMMETISEFCV;
			param->permf         =PERMPQ;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  |=FINAL_PIVOTING;
		     }
		     else if (!strncmp("rcm",param->ordering,3)) {
	                param->perm0         =PERMRCMFCV;
			param->perm          =PERMRCMFCV;
			param->permf         =PERMPQ;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  |=FINAL_PIVOTING;
		     }
		     else if (!strncmp("amf",param->ordering,3)) {
		        param->perm0         =PERMAMFFCV;
			param->perm          =PERMAMFFCV;
			param->permf         =PERMPQ;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  |=FINAL_PIVOTING;
		     }
		     else if (!strncmp("mmd",param->ordering,3)) {
		        param->perm0         =PERMMMDFCV;
			param->perm          =PERMMMDFCV;
			param->permf         =PERMPQ;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  |=FINAL_PIVOTING;
		     }
		     else if (!strncmp("indset",param->ordering,6)) {
		        param->perm0         =PERMINDSETFCV;
			param->perm          =PERMINDSETFCV;
			param->permf         =PERMPQ;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  |=FINAL_PIVOTING;
		     }
		     */
		     else if (!strncmp("none",param->ordering,4)) {
		        param->perm0         =PERMFCV;
			param->perm          =PERMFCV;
			param->permf         =PERMPQ;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  |=FINAL_PIVOTING;
		     }
		     else if (!strncmp("pq",param->ordering,2)) {
		        param->perm0         =PERMPQ;
			param->perm          =PERMPQ;
			param->permf         =PERMPQ;
			// ignore permf
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  &=~FINAL_PIVOTING;
		     }
		     // no sensible string
		     else  {
		        // custom settings from the user
		     }
		  }
		  // 3. no test vector
		  else {
		     // 1. no matching
		     // 2. fine/coarse grid partitioning
		     // 3. no test vector
		     // no sensible string
		     if (param->ordering==NULL || strlen(param->ordering)==0) {
		        // custom settings from the user
		     }
		     /*
		     else if (!strncmp("amd",param->ordering,3)) {
		        param->perm0         =PERMAMDFC;
			param->perm          =PERMAMDFC;
			param->permf         =PERMPQ;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  |=FINAL_PIVOTING;
		     }
		     else if (!strncmp("metisn",param->ordering,6)) {
	                param->perm0         =PERMMETISNFC;
			param->perm          =PERMMETISNFC;
			param->permf         =PERMPQ;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  |=FINAL_PIVOTING;
		     }
		     else if (!strncmp("metise",param->ordering,6)) {
		        param->perm0         =PERMMETISEFC;
			param->perm          =PERMMETISEFC;
			param->permf         =PERMPQ;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  |=FINAL_PIVOTING;
		     }
		     else if (!strncmp("rcm",param->ordering,3)) {
		        param->perm0         =PERMRCMFC;
			param->perm          =PERMRCMFC;
			param->permf         =PERMPQ;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  |=FINAL_PIVOTING;
		     }
		     else if (!strncmp("amf",param->ordering,3)) {
	                param->perm0         =PERMAMFFC;
			param->perm          =PERMAMFFC;
			param->permf         =PERMPQ;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  |=FINAL_PIVOTING;
		     }
		     else if (!strncmp("mmd",param->ordering,3)) {
		        param->perm0         =PERMMMDFC;
			param->perm          =PERMMMDFC;
			param->permf         =PERMPQ;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  |=FINAL_PIVOTING;
		     }
		     else if (!strncmp("indset",param->ordering,6)) {
		        param->perm0         =PERMINDSETFC;
			param->perm          =PERMINDSETFC;
			param->permf         =PERMPQ;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  |=FINAL_PIVOTING;
		     }
		     */
		     else if (!strncmp("none",param->ordering,4)) {
		        param->perm0         =PERMFC;
			param->perm          =PERMFC;
			param->permf         =PERMPQ;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  |=FINAL_PIVOTING;
		     }
		     else if (!strncmp("pq",param->ordering,2)) {
	                param->perm0         =PERMPQ;
			param->perm          =PERMPQ;
			param->permf         =PERMPQ;
			// ignore permf
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  &=~FINAL_PIVOTING;
		     }
		     // no sensible string
		     else  {
		        // custom settings from the user
		     }
		  }
	       }
	       // no sensible string
	       else {
		  // custom settings from the user
	       }
	    }
	    // do we want to pre-select coarse grid nodes? no
	    else {
	       // 1. no matching
	       // 2. no fine/coarse grid partitioning
	       // 3. do not care about the test vector
	       // no sensible string
	       if (param->ordering==NULL || strlen(param->ordering)==0) {
		  // custom settings from the user
	       }
	       else if (!strncmp("amd",param->ordering,3)) {
		  param->perm0         =PERMAMD;
		  param->perm          =PERMAMD;
		  param->permf         =PERMPQ;
		  param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		  param->flags  |=PREPROCESS_SUBSYSTEMS;
		  param->flags  |=FINAL_PIVOTING;
	       }
	       else if (!strncmp("metisn",param->ordering,6)) {
		  param->perm0         =PERMMETISN;
		  param->perm          =PERMMETISN;
		  param->permf         =PERMPQ;
		  param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		  param->flags  |=PREPROCESS_SUBSYSTEMS;
		  param->flags  |=FINAL_PIVOTING;
	       }
	       else if (!strncmp("metise",param->ordering,6)) {
		  param->perm0         =PERMMETISE;
		  param->perm          =PERMMETISE;
		  param->permf         =PERMPQ;
		  param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		  param->flags  |=PREPROCESS_SUBSYSTEMS;
		  param->flags  |=FINAL_PIVOTING;
	       }
	       else if (!strncmp("rcm",param->ordering,3)) {
		  param->perm0         =PERMRCM;
		  param->perm          =PERMRCM;
		  param->permf         =PERMPQ;
		  param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		  param->flags  |=PREPROCESS_SUBSYSTEMS;
		  param->flags  |=FINAL_PIVOTING;
	       }
	       else if (!strncmp("amf",param->ordering,3)) {
		  param->perm0         =PERMAMF;
		  param->perm          =PERMAMF;
		  param->permf         =PERMPQ;
		  param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		  param->flags  |=PREPROCESS_SUBSYSTEMS;
		  param->flags  |=FINAL_PIVOTING;
	       }
	       else if (!strncmp("mmd",param->ordering,3)) {
		  param->perm0         =PERMMMD;
		  param->perm          =PERMMMD;
		  param->permf         =PERMPQ;
		  param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		  param->flags  |=PREPROCESS_SUBSYSTEMS;
		  param->flags  |=FINAL_PIVOTING;
	       }
	       /*
	       else if (!strncmp("indset",param->ordering,6)) {
	          param->perm0         =PERMINDSET;
		  param->perm          =PERMINDSET;
		  param->permf         =PERMPQ;
		  param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		  param->flags  |=PREPROCESS_SUBSYSTEMS;
		  param->flags  |=FINAL_PIVOTING;
	       } 
	       */
	       else if (!strncmp("none",param->ordering,4)) {
		  param->perm0         =PERMNULL;
		  param->perm          =PERMNULL;
		  param->permf         =PERMPQ;
		  param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		  param->flags  |=PREPROCESS_SUBSYSTEMS;
		  param->flags  |=FINAL_PIVOTING;
	       }
	       else if (!strncmp("pq",param->ordering,2)) {
		  param->perm0         =PERMPQ;
		  param->perm          =PERMPQ;
		  param->permf         =PERMPQ;
		  // ignore permf
		  param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		  param->flags  |=PREPROCESS_SUBSYSTEMS;
		  param->flags  &=~FINAL_PIVOTING;
	       }
	       // no sensible string
	       else {
		  // custom settings from the user
	       }
	    }
	 }
	 // no sensible string
	 else {
	    // custom settings from the user
	 }
      }


      param->fpar[1] =param->droptol;
      param->fpar[8] =param->droptolS;
      param->fpar[2] =param->condest;
      param->ipar[0] =ceil(param->elbow);
      param->ipar[3] =param->lfil;
      param->ipar[9] =param->lfilS;

      // test vector
      if (param->typetv!=NULL && strlen(param->typetv)>0) {
         if (!strncmp("static",param->typetv,6)) {
	    param->flags|=DIAGONAL_COMPENSATION|STATIC_TESTVECTOR; 
	 }
	 else if (strncmp("none",param->typetv,4)) {
	    param->flags|=DIAGONAL_COMPENSATION|DYNAMIC_TESTVECTOR;
	 }
	 if (strncmp("none",param->typetv,4)) {
	    if (param->ntestvector==0) {
	       param->ntestvector=2*A->nc;
	       param->testvector=(FLOAT *)MALLOC((size_t)param->ntestvector*sizeof(FLOAT),
						 "AMGsetupparameters:param->testvector");
	    }
	    else {
	       param->ntestvector=MAX(2*A->nc,param->ntestvector);
	       param->testvector=(FLOAT *)REALLOC(param->testvector,
					       (size_t)param->ntestvector*sizeof(FLOAT),
					       "AMGsetupparameters:param->testvector");
	    }
	    memcpy(param->testvector, param->tv, A->nc*sizeof(FLOAT));
	 }
      }

      // capture the old style
      if (param->flags&DIAGONAL_COMPENSATION) {
	 if (param->ntestvector==0)
	    param->ntestvector=2*A->nc;
	 else
	    param->ntestvector=MAX(2*A->nc,param->ntestvector);

	 if (param->testvector==NULL)
	    param->testvector=(FLOAT *)MALLOC((size_t)param->ntestvector*sizeof(FLOAT),
					      "AMGsetupparameters:param->testvector");
	 else
	    param->testvector=(FLOAT *)REALLOC(param->testvector,
					       (size_t)param->ntestvector*sizeof(FLOAT),
					       "AMGsetupparameters:param->testvector");
	 // diagonal compensation in the classical sense using the 1-vector 
	 if (!(param->flags&STATIC_TESTVECTOR) && 
	     !(param->flags&DYNAMIC_TESTVECTOR)) {
	    for (i=0; i<A->nc; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	        param->testvector[i]=1.0;
#else
		param->testvector[i].r=1.0;
		param->testvector[i].i=0.0;
#endif
	    } // end for
	 }
      }

      // type of coarse grid system
      if (param->typecoarse!=NULL && strlen(param->typecoarse)>0) {
	 if (!strncmp("ilu",param->typecoarse,3)) {
	    param->flags&=~TISMENETSKY_SC;
	    param->flags|=SIMPLE_SC;
	 }
	 else if (!strncmp("amg",param->typecoarse,3)) {
	    param->flags&=~TISMENETSKY_SC;
	    param->flags&=~SIMPLE_SC;
	 }
      }

      // type of multigrid
      if (strncmp("ilu",param->amg,3) && strncmp("amli",param->amg,4) && 
	  strncmp("mg",param->amg,2)) {
	 param->amg="ilu";
      }
      if (param->amg!=NULL && strlen(param->amg)>0) {
	 if (!strncmp("ilu",param->amg,3))
	    param->ipar[10]=0;
	 else if (!strncmp("amli",param->amg,4))
	    param->ipar[10]=1;
	 else if (!strncmp("mg",param->amg,2))
	    param->ipar[10]=2;
	 else {
	    param->amg="ilu";
	    param->ipar[10]=0;
	 }
      }

      // flags only used to set up the preconditioner
      param->ipar[6] =param->flags;
   }
   // env!=0
   // setup parameters that only affect the iterative part
   else {

      param->ipar[12]=param->npresmoothing;
      param->ipar[13]=param->npostsmoothing;
      param->ipar[11]=param->ncoarse;
      param->fpar[20]=param->restol;
      param->ipar[24]=param->nrestart;
      param->ipar[25]=param->maxit;


      // pre- and post smoother (if used with "mg")
      if (param->presmoother!=NULL && strlen(param->presmoother)>0) {
	 if (!strncmp("gsf",param->presmoother,3))
	    param->ipar[14]=1;
	 else if (!strncmp("gsb",param->presmoother,3))
	    param->ipar[14]=2;
	 else if (!strncmp("j",param->presmoother,1))
	    param->ipar[14]=3;
	 else if (!strncmp("ilu",param->presmoother,3))
	    param->ipar[14]=4;
	 else // custom
	    param->ipar[14]=5;
      }

      if (param->postsmoother!=NULL && strlen(param->postsmoother)>0) {
	 if (!strncmp("gsf",param->postsmoother,3))
	    param->ipar[15]=1;
	 else if (!strncmp("gsb",param->postsmoother,3))
	    param->ipar[15]=2;
	 else if (!strncmp("j",param->postsmoother,1))
	    param->ipar[15]=3;
	 else if (!strncmp("ilu",param->postsmoother,3))
	    param->ipar[15]=4;
	 else // custom
	    param->ipar[15]=5;
      }


      // set up solver and prepare memory allocation for the 
      // iterative solver 
      i=param->ipar[24];
      if (!strncmp("bcg",param->solver,3)) {
	 param->ipar[5]=3;
	 i=7*A->nr;
      }
      else if (!strncmp("gmres",param->solver,5)) {
	 param->ipar[5]=8;
	 i=(A->nr+3)*(i+2)+(i+1)*i/2;
      }
      else if (!strncmp("fgmres",param->solver,6)) {
	 param->ipar[5]=9;
	 i=2*A->nr*(i+1)+((i+1)*i)/2 + 3*i + 2;
      }
      else {
	 param->solver="gmres";
	 param->ipar[5]=8;
	 i=(A->nr+3)*(i+2)+(i+1)*i/2;
      } // end switch
      // memory required by the iterative method
      param->ipar[23]=i;

      // type of multigrid
      if (strncmp("ilu",param->amg,3) && strncmp("amli",param->amg,4) && 
	  strncmp("mg",param->amg,2)) {
	 param->amg="ilu";
      }
      if (param->amg!=NULL && strlen(param->amg)>0) {
         if (!strncmp("ilu",param->amg,3))
	    param->ipar[10]=0;
	 // note that in order to apply amli or mg the coarse grid
	 // systems had to be kept during the computation of the preconditioner
	 else if (!(param->ipar[16]&DISCARD_MATRIX)) {
	    if (!strncmp("amli",param->amg,4))
	       param->ipar[10]=1;
	    else if (!strncmp("mg",param->amg,2))
	       param->ipar[10]=2;
	    else {
	       param->amg="ilu";
	       param->ipar[10]=0;
	    }
	 }
	 else {
	    param->amg="ilu";
	    param->ipar[10]=0;
	 }
      }

   } // end if-else env==0

} // end AMGsetupparameters

