#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include <blas.h>
#include <ilupack.h>

#include <ilupackmacros.h>

#define STDERR          stdout
#define STDOUT          stdout
// #define PRINT_INFO
#define MAX(A,B)        (((A)>(B))?(A):(B))
#define MIN(A,B)        (((A)<(B))?(A):(B))




#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
#define CONJG(A)      (A)

#ifdef _DOUBLE_REAL_
#define MYSYMAMGSETUPPARAMETERS             DSYMAMGsetupparameters
#define MYSYMAMGINIT                        DSYMAMGinit

#define PERMSMWMAMF          DSYMperm_mwm_amf
#define PERMSMWMAMD          DSYMperm_mwm_amd
#define PERMSMWMMMD          DSYMperm_mwm_mmd
#define PERMSMWMRCM          DSYMperm_mwm_rcm
#define PERMSMWMMETISE       DSYMperm_mwm_metis_e
#define PERMSMWMMETISN       DSYMperm_mwm_metis_n

#define PERMSMC64AMF          DSYMperm_mc64_amf
#define PERMSMC64AMD          DSYMperm_mc64_amd
#define PERMSMC64MMD          DSYMperm_mc64_mmd
#define PERMSMC64RCM          DSYMperm_mc64_rcm
#define PERMSMC64METISE       DSYMperm_mc64_metis_e
#define PERMSMC64METISN       DSYMperm_mc64_metis_n

#define PERMSMC64AMF_SP          DSYMperm_mc64_amf_sp
#define PERMSMC64AMD_SP          DSYMperm_mc64_amd_sp
#define PERMSMC64MMD_SP          DSYMperm_mc64_mmd_sp
#define PERMSMC64RCM_SP          DSYMperm_mc64_rcm_sp
#define PERMSMC64METISE_SP       DSYMperm_mc64_metis_e_sp
#define PERMSMC64METISN_SP       DSYMperm_mc64_metis_n_sp

#define PERMSMWMAMF_SP          DSYMperm_mwm_amf_sp
#define PERMSMWMAMD_SP          DSYMperm_mwm_amd_sp
#define PERMSMWMMMD_SP          DSYMperm_mwm_mmd_sp
#define PERMSMWMRCM_SP          DSYMperm_mwm_rcm_sp
#define PERMSMWMMETISE_SP       DSYMperm_mwm_metis_e_sp
#define PERMSMWMMETISN_SP       DSYMperm_mwm_metis_n_sp

#define PERMSMATCHINGAMF_SP          DSYMperm_matching_amf_sp
#define PERMSMATCHINGAMD_SP          DSYMperm_matching_amd_sp
#define PERMSMATCHINGMMD_SP          DSYMperm_matching_mmd_sp
#define PERMSMATCHINGRCM_SP          DSYMperm_matching_rcm_sp
#define PERMSMATCHINGMETISE_SP       DSYMperm_matching_metis_e_sp
#define PERMSMATCHINGMETISN_SP       DSYMperm_matching_metis_n_sp

#define PERMSMATCHINGAMF          DSYMperm_matching_amf
#define PERMSMATCHINGAMD          DSYMperm_matching_amd
#define PERMSMATCHINGMMD          DSYMperm_matching_mmd
#define PERMSMATCHINGRCM          DSYMperm_matching_rcm
#define PERMSMATCHINGMETISE       DSYMperm_matching_metis_e
#define PERMSMATCHINGMETISN       DSYMperm_matching_metis_n

#define PERMSMWMAMFFCV        DSYMperm_mwm_amf_fcv
#define PERMSMWMAMDFCV        DSYMperm_mwm_amd_fcv
#define PERMSMWMMMDFCV        DSYMperm_mwm_mmd_fcv
#define PERMSMWMRCMFCV        DSYMperm_mwm_rcm_fcv
#define PERMSMWMMETISEFCV     DSYMperm_mwm_metis_e_fcv
#define PERMSMWMMETISNFCV     DSYMperm_mwm_metis_n_fcv

#define PERMSMC64AMFFCV       DSYMperm_mc64_amf_fcv
#define PERMSMC64AMDFCV       DSYMperm_mc64_amd_fcv
#define PERMSMC64MMDFCV       DSYMperm_mc64_mmd_fcv
#define PERMSMC64RCMFCV       DSYMperm_mc64_rcm_fcv
#define PERMSMC64METISEFCV    DSYMperm_mc64_metis_e_fcv
#define PERMSMC64METISNFCV    DSYMperm_mc64_metis_n_fcv

#define PERMSMATCHINGAMFFCV       DSYMperm_matching_amf_fcv
#define PERMSMATCHINGAMDFCV       DSYMperm_matching_amd_fcv
#define PERMSMATCHINGMMDFCV       DSYMperm_matching_mmd_fcv
#define PERMSMATCHINGRCMFCV       DSYMperm_matching_rcm_fcv
#define PERMSMATCHINGMETISEFCV    DSYMperm_matching_metis_e_fcv
#define PERMSMATCHINGMETISNFCV    DSYMperm_matching_metis_n_fcv

#define PERMSMWMAMFFC        DSYMperm_mwm_amf_fc
#define PERMSMWMAMDFC        DSYMperm_mwm_amd_fc
#define PERMSMWMMMDFC        DSYMperm_mwm_mmd_fc
#define PERMSMWMRCMFC        DSYMperm_mwm_rcm_fc
#define PERMSMWMMETISEFC     DSYMperm_mwm_metis_e_fc
#define PERMSMWMMETISNFC     DSYMperm_mwm_metis_n_fc

#define PERMSMC64AMFFC       DSYMperm_mc64_amf_fc
#define PERMSMC64AMDFC       DSYMperm_mc64_amd_fc
#define PERMSMC64MMDFC       DSYMperm_mc64_mmd_fc
#define PERMSMC64RCMFC       DSYMperm_mc64_rcm_fc
#define PERMSMC64METISEFC    DSYMperm_mc64_metis_e_fc
#define PERMSMC64METISNFC    DSYMperm_mc64_metis_n_fc

#define PERMSMATCHINGAMFFC       DSYMperm_matching_amf_fc
#define PERMSMATCHINGAMDFC       DSYMperm_matching_amd_fc
#define PERMSMATCHINGMMDFC       DSYMperm_matching_mmd_fc
#define PERMSMATCHINGRCMFC       DSYMperm_matching_rcm_fc
#define PERMSMATCHINGMETISEFC    DSYMperm_matching_metis_e_fc
#define PERMSMATCHINGMETISNFC    DSYMperm_matching_metis_n_fc

#else

#define MYSYMAMGSETUPPARAMETERS             SSYMAMGsetupparameters
#define MYSYMAMGINIT                        SSYMAMGinit

#define PERMSMWMAMF          SSYMperm_mwm_amf
#define PERMSMWMAMD          SSYMperm_mwm_amd
#define PERMSMWMMMD          SSYMperm_mwm_mmd
#define PERMSMWMRCM          SSYMperm_mwm_rcm
#define PERMSMWMMETISE       SSYMperm_mwm_metis_e
#define PERMSMWMMETISN       SSYMperm_mwm_metis_n

#define PERMSMC64AMF          SSYMperm_mc64_amf
#define PERMSMC64AMD          SSYMperm_mc64_amd
#define PERMSMC64MMD          SSYMperm_mc64_mmd
#define PERMSMC64RCM          SSYMperm_mc64_rcm
#define PERMSMC64METISE       SSYMperm_mc64_metis_e
#define PERMSMC64METISN       SSYMperm_mc64_metis_n

#define PERMSMC64AMF_SP          SSYMperm_mc64_amf_sp
#define PERMSMC64AMD_SP          SSYMperm_mc64_amd_sp
#define PERMSMC64MMD_SP          SSYMperm_mc64_mmd_sp
#define PERMSMC64RCM_SP          SSYMperm_mc64_rcm_sp
#define PERMSMC64METISE_SP       SSYMperm_mc64_metis_e_sp
#define PERMSMC64METISN_SP       SSYMperm_mc64_metis_n_sp

#define PERMSMWMAMF_SP          SSYMperm_mwm_amf_sp
#define PERMSMWMAMD_SP          SSYMperm_mwm_amd_sp
#define PERMSMWMMMD_SP          SSYMperm_mwm_mmd_sp
#define PERMSMWMRCM_SP          SSYMperm_mwm_rcm_sp
#define PERMSMWMMETISE_SP       SSYMperm_mwm_metis_e_sp
#define PERMSMWMMETISN_SP       SSYMperm_mwm_metis_n_sp

#define PERMSMATCHINGAMF_SP          SSYMperm_matching_amf_sp
#define PERMSMATCHINGAMD_SP          SSYMperm_matching_amd_sp
#define PERMSMATCHINGMMD_SP          SSYMperm_matching_mmd_sp
#define PERMSMATCHINGRCM_SP          SSYMperm_matching_rcm_sp
#define PERMSMATCHINGMETISE_SP       SSYMperm_matching_metis_e_sp
#define PERMSMATCHINGMETISN_SP       SSYMperm_matching_metis_n_sp

#define PERMSMATCHINGAMF          SSYMperm_matching_amf
#define PERMSMATCHINGAMD          SSYMperm_matching_amd
#define PERMSMATCHINGMMD          SSYMperm_matching_mmd
#define PERMSMATCHINGRCM          SSYMperm_matching_rcm
#define PERMSMATCHINGMETISE       SSYMperm_matching_metis_e
#define PERMSMATCHINGMETISN       SSYMperm_matching_metis_n

#define PERMSMWMAMFFCV        SSYMperm_mwm_amf_fcv
#define PERMSMWMAMDFCV        SSYMperm_mwm_amd_fcv
#define PERMSMWMMMDFCV        SSYMperm_mwm_mmd_fcv
#define PERMSMWMRCMFCV        SSYMperm_mwm_rcm_fcv
#define PERMSMWMMETISEFCV     SSYMperm_mwm_metis_e_fcv
#define PERMSMWMMETISNFCV     SSYMperm_mwm_metis_n_fcv

#define PERMSMC64AMFFCV       SSYMperm_mc64_amf_fcv
#define PERMSMC64AMDFCV       SSYMperm_mc64_amd_fcv
#define PERMSMC64MMDFCV       SSYMperm_mc64_mmd_fcv
#define PERMSMC64RCMFCV       SSYMperm_mc64_rcm_fcv
#define PERMSMC64METISEFCV    SSYMperm_mc64_metis_e_fcv
#define PERMSMC64METISNFCV    SSYMperm_mc64_metis_n_fcv

#define PERMSMATCHINGAMFFCV       SSYMperm_matching_amf_fcv
#define PERMSMATCHINGAMDFCV       SSYMperm_matching_amd_fcv
#define PERMSMATCHINGMMDFCV       SSYMperm_matching_mmd_fcv
#define PERMSMATCHINGRCMFCV       SSYMperm_matching_rcm_fcv
#define PERMSMATCHINGMETISEFCV    SSYMperm_matching_metis_e_fcv
#define PERMSMATCHINGMETISNFCV    SSYMperm_matching_metis_n_fcv

#define PERMSMWMAMFFC        SSYMperm_mwm_amf_fc
#define PERMSMWMAMDFC        SSYMperm_mwm_amd_fc
#define PERMSMWMMMDFC        SSYMperm_mwm_mmd_fc
#define PERMSMWMRCMFC        SSYMperm_mwm_rcm_fc
#define PERMSMWMMETISEFC     SSYMperm_mwm_metis_e_fc
#define PERMSMWMMETISNFC     SSYMperm_mwm_metis_n_fc

#define PERMSMC64AMFFC       SSYMperm_mc64_amf_fc
#define PERMSMC64AMDFC       SSYMperm_mc64_amd_fc
#define PERMSMC64MMDFC       SSYMperm_mc64_mmd_fc
#define PERMSMC64RCMFC       SSYMperm_mc64_rcm_fc
#define PERMSMC64METISEFC    SSYMperm_mc64_metis_e_fc
#define PERMSMC64METISNFC    SSYMperm_mc64_metis_n_fc

#define PERMSMATCHINGAMFFC       SSYMperm_matching_amf_fc
#define PERMSMATCHINGAMDFC       SSYMperm_matching_amd_fc
#define PERMSMATCHINGMMDFC       SSYMperm_matching_mmd_fc
#define PERMSMATCHINGRCMFC       SSYMperm_matching_rcm_fc
#define PERMSMATCHINGMETISEFC    SSYMperm_matching_metis_e_fc
#define PERMSMATCHINGMETISNFC    SSYMperm_matching_metis_n_fc

#endif




#else



#ifdef _COMPLEX_SYMMETRIC_
#define CONJG(A)     (A)

#ifdef _SINGLE_COMPLEX_
#define MYSYMAMGSETUPPARAMETERS             CSYMAMGsetupparameters
#define MYSYMAMGINIT                        CSYMAMGinit

#define PERMSMWMAMF          CSYMperm_mwm_amf
#define PERMSMWMAMD          CSYMperm_mwm_amd
#define PERMSMWMMMD          CSYMperm_mwm_mmd
#define PERMSMWMRCM          CSYMperm_mwm_rcm
#define PERMSMWMMETISE       CSYMperm_mwm_metis_e
#define PERMSMWMMETISN       CSYMperm_mwm_metis_n

#define PERMSMC64AMF          CSYMperm_mc64_amf
#define PERMSMC64AMD          CSYMperm_mc64_amd
#define PERMSMC64MMD          CSYMperm_mc64_mmd
#define PERMSMC64RCM          CSYMperm_mc64_rcm
#define PERMSMC64METISE       CSYMperm_mc64_metis_e
#define PERMSMC64METISN       CSYMperm_mc64_metis_n

#define PERMSMC64AMF_SP          CSYMperm_mc64_amf_sp
#define PERMSMC64AMD_SP          CSYMperm_mc64_amd_sp
#define PERMSMC64MMD_SP          CSYMperm_mc64_mmd_sp
#define PERMSMC64RCM_SP          CSYMperm_mc64_rcm_sp
#define PERMSMC64METISE_SP       CSYMperm_mc64_metis_e_sp
#define PERMSMC64METISN_SP       CSYMperm_mc64_metis_n_sp

#define PERMSMWMAMF_SP          CSYMperm_mwm_amf_sp
#define PERMSMWMAMD_SP          CSYMperm_mwm_amd_sp
#define PERMSMWMMMD_SP          CSYMperm_mwm_mmd_sp
#define PERMSMWMRCM_SP          CSYMperm_mwm_rcm_sp
#define PERMSMWMMETISE_SP       CSYMperm_mwm_metis_e_sp
#define PERMSMWMMETISN_SP       CSYMperm_mwm_metis_n_sp

#define PERMSMATCHINGAMF_SP          CSYMperm_matching_amf_sp
#define PERMSMATCHINGAMD_SP          CSYMperm_matching_amd_sp
#define PERMSMATCHINGMMD_SP          CSYMperm_matching_mmd_sp
#define PERMSMATCHINGRCM_SP          CSYMperm_matching_rcm_sp
#define PERMSMATCHINGMETISE_SP       CSYMperm_matching_metis_e_sp
#define PERMSMATCHINGMETISN_SP       CSYMperm_matching_metis_n_sp

#define PERMSMATCHINGAMF          CSYMperm_matching_amf
#define PERMSMATCHINGAMD          CSYMperm_matching_amd
#define PERMSMATCHINGMMD          CSYMperm_matching_mmd
#define PERMSMATCHINGRCM          CSYMperm_matching_rcm
#define PERMSMATCHINGMETISE       CSYMperm_matching_metis_e
#define PERMSMATCHINGMETISN       CSYMperm_matching_metis_n

#define PERMSMWMAMFFCV        CSYMperm_mwm_amf_fcv
#define PERMSMWMAMDFCV        CSYMperm_mwm_amd_fcv
#define PERMSMWMMMDFCV        CSYMperm_mwm_mmd_fcv
#define PERMSMWMRCMFCV        CSYMperm_mwm_rcm_fcv
#define PERMSMWMMETISEFCV     CSYMperm_mwm_metis_e_fcv
#define PERMSMWMMETISNFCV     CSYMperm_mwm_metis_n_fcv

#define PERMSMC64AMFFCV       CSYMperm_mc64_amf_fcv
#define PERMSMC64AMDFCV       CSYMperm_mc64_amd_fcv
#define PERMSMC64MMDFCV       CSYMperm_mc64_mmd_fcv
#define PERMSMC64RCMFCV       CSYMperm_mc64_rcm_fcv
#define PERMSMC64METISEFCV    CSYMperm_mc64_metis_e_fcv
#define PERMSMC64METISNFCV    CSYMperm_mc64_metis_n_fcv

#define PERMSMATCHINGAMFFCV       CSYMperm_matching_amf_fcv
#define PERMSMATCHINGAMDFCV       CSYMperm_matching_amd_fcv
#define PERMSMATCHINGMMDFCV       CSYMperm_matching_mmd_fcv
#define PERMSMATCHINGRCMFCV       CSYMperm_matching_rcm_fcv
#define PERMSMATCHINGMETISEFCV    CSYMperm_matching_metis_e_fcv
#define PERMSMATCHINGMETISNFCV    CSYMperm_matching_metis_n_fcv

#define PERMSMWMAMFFC        CSYMperm_mwm_amf_fc
#define PERMSMWMAMDFC        CSYMperm_mwm_amd_fc
#define PERMSMWMMMDFC        CSYMperm_mwm_mmd_fc
#define PERMSMWMRCMFC        CSYMperm_mwm_rcm_fc
#define PERMSMWMMETISEFC     CSYMperm_mwm_metis_e_fc
#define PERMSMWMMETISNFC     CSYMperm_mwm_metis_n_fc

#define PERMSMC64AMFFC       CSYMperm_mc64_amf_fc
#define PERMSMC64AMDFC       CSYMperm_mc64_amd_fc
#define PERMSMC64MMDFC       CSYMperm_mc64_mmd_fc
#define PERMSMC64RCMFC       CSYMperm_mc64_rcm_fc
#define PERMSMC64METISEFC    CSYMperm_mc64_metis_e_fc
#define PERMSMC64METISNFC    CSYMperm_mc64_metis_n_fc

#define PERMSMATCHINGAMFFC       CSYMperm_matching_amf_fc
#define PERMSMATCHINGAMDFC       CSYMperm_matching_amd_fc
#define PERMSMATCHINGMMDFC       CSYMperm_matching_mmd_fc
#define PERMSMATCHINGRCMFC       CSYMperm_matching_rcm_fc
#define PERMSMATCHINGMETISEFC    CSYMperm_matching_metis_e_fc
#define PERMSMATCHINGMETISNFC    CSYMperm_matching_metis_n_fc


#else
#define MYSYMAMGSETUPPARAMETERS             ZSYMAMGsetupparameters
#define MYSYMAMGINIT                        ZSYMAMGinit

#define PERMSMWMAMF          ZSYMperm_mwm_amf
#define PERMSMWMAMD          ZSYMperm_mwm_amd
#define PERMSMWMMMD          ZSYMperm_mwm_mmd
#define PERMSMWMRCM          ZSYMperm_mwm_rcm
#define PERMSMWMMETISE       ZSYMperm_mwm_metis_e
#define PERMSMWMMETISN       ZSYMperm_mwm_metis_n

#define PERMSMC64AMF          ZSYMperm_mc64_amf
#define PERMSMC64AMD          ZSYMperm_mc64_amd
#define PERMSMC64MMD          ZSYMperm_mc64_mmd
#define PERMSMC64RCM          ZSYMperm_mc64_rcm
#define PERMSMC64METISE       ZSYMperm_mc64_metis_e
#define PERMSMC64METISN       ZSYMperm_mc64_metis_n

#define PERMSMC64AMF_SP          ZSYMperm_mc64_amf_sp
#define PERMSMC64AMD_SP          ZSYMperm_mc64_amd_sp
#define PERMSMC64MMD_SP          ZSYMperm_mc64_mmd_sp
#define PERMSMC64RCM_SP          ZSYMperm_mc64_rcm_sp
#define PERMSMC64METISE_SP       ZSYMperm_mc64_metis_e_sp
#define PERMSMC64METISN_SP       ZSYMperm_mc64_metis_n_sp

#define PERMSMWMAMF_SP          ZSYMperm_mwm_amf_sp
#define PERMSMWMAMD_SP          ZSYMperm_mwm_amd_sp
#define PERMSMWMMMD_SP          ZSYMperm_mwm_mmd_sp
#define PERMSMWMRCM_SP          ZSYMperm_mwm_rcm_sp
#define PERMSMWMMETISE_SP       ZSYMperm_mwm_metis_e_sp
#define PERMSMWMMETISN_SP       ZSYMperm_mwm_metis_n_sp

#define PERMSMATCHINGAMF_SP          ZSYMperm_matching_amf_sp
#define PERMSMATCHINGAMD_SP          ZSYMperm_matching_amd_sp
#define PERMSMATCHINGMMD_SP          ZSYMperm_matching_mmd_sp
#define PERMSMATCHINGRCM_SP          ZSYMperm_matching_rcm_sp
#define PERMSMATCHINGMETISE_SP       ZSYMperm_matching_metis_e_sp
#define PERMSMATCHINGMETISN_SP       ZSYMperm_matching_metis_n_sp

#define PERMSMATCHINGAMF          ZSYMperm_matching_amf
#define PERMSMATCHINGAMD          ZSYMperm_matching_amd
#define PERMSMATCHINGMMD          ZSYMperm_matching_mmd
#define PERMSMATCHINGRCM          ZSYMperm_matching_rcm
#define PERMSMATCHINGMETISE       ZSYMperm_matching_metis_e
#define PERMSMATCHINGMETISN       ZSYMperm_matching_metis_n

#define PERMSMWMAMFFCV        ZSYMperm_mwm_amf_fcv
#define PERMSMWMAMDFCV        ZSYMperm_mwm_amd_fcv
#define PERMSMWMMMDFCV        ZSYMperm_mwm_mmd_fcv
#define PERMSMWMRCMFCV        ZSYMperm_mwm_rcm_fcv
#define PERMSMWMMETISEFCV     ZSYMperm_mwm_metis_e_fcv
#define PERMSMWMMETISNFCV     ZSYMperm_mwm_metis_n_fcv

#define PERMSMC64AMFFCV       ZSYMperm_mc64_amf_fcv
#define PERMSMC64AMDFCV       ZSYMperm_mc64_amd_fcv
#define PERMSMC64MMDFCV       ZSYMperm_mc64_mmd_fcv
#define PERMSMC64RCMFCV       ZSYMperm_mc64_rcm_fcv
#define PERMSMC64METISEFCV    ZSYMperm_mc64_metis_e_fcv
#define PERMSMC64METISNFCV    ZSYMperm_mc64_metis_n_fcv

#define PERMSMWMAMFFCV       ZSYMperm_mwm_amf_fcv
#define PERMSMWMAMDFCV       ZSYMperm_mwm_amd_fcv
#define PERMSMWMMMDFCV       ZSYMperm_mwm_mmd_fcv
#define PERMSMWMRCMFCV       ZSYMperm_mwm_rcm_fcv
#define PERMSMWMMETISEFCV    ZSYMperm_mwm_metis_e_fcv
#define PERMSMWMMETISNFCV    ZSYMperm_mwm_metis_n_fcv

#define PERMSMATCHINGAMFFCV       ZSYMperm_matching_amf_fcv
#define PERMSMATCHINGAMDFCV       ZSYMperm_matching_amd_fcv
#define PERMSMATCHINGMMDFCV       ZSYMperm_matching_mmd_fcv
#define PERMSMATCHINGRCMFCV       ZSYMperm_matching_rcm_fcv
#define PERMSMATCHINGMETISEFCV    ZSYMperm_matching_metis_e_fcv
#define PERMSMATCHINGMETISNFCV    ZSYMperm_matching_metis_n_fcv

#define PERMSMWMAMFFC        ZSYMperm_mwm_amf_fc
#define PERMSMWMAMDFC        ZSYMperm_mwm_amd_fc
#define PERMSMWMMMDFC        ZSYMperm_mwm_mmd_fc
#define PERMSMWMRCMFC        ZSYMperm_mwm_rcm_fc
#define PERMSMWMMETISEFC     ZSYMperm_mwm_metis_e_fc
#define PERMSMWMMETISNFC     ZSYMperm_mwm_metis_n_fc

#define PERMSMC64AMFFC       ZSYMperm_mc64_amf_fc
#define PERMSMC64AMDFC       ZSYMperm_mc64_amd_fc
#define PERMSMC64MMDFC       ZSYMperm_mc64_mmd_fc
#define PERMSMC64RCMFC       ZSYMperm_mc64_rcm_fc
#define PERMSMC64METISEFC    ZSYMperm_mc64_metis_e_fc
#define PERMSMC64METISNFC    ZSYMperm_mc64_metis_n_fc

#define PERMSMATCHINGAMFFC       ZSYMperm_matching_amf_fc
#define PERMSMATCHINGAMDFC       ZSYMperm_matching_amd_fc
#define PERMSMATCHINGMMDFC       ZSYMperm_matching_mmd_fc
#define PERMSMATCHINGRCMFC       ZSYMperm_matching_rcm_fc
#define PERMSMATCHINGMETISEFC    ZSYMperm_matching_metis_e_fc
#define PERMSMATCHINGMETISNFC    ZSYMperm_matching_metis_n_fc

#endif

#else
#define CONJG(A)             (-(A))

#ifdef _SINGLE_COMPLEX_
#define MYSYMAMGSETUPPARAMETERS             CHERAMGsetupparameters
#define MYSYMAMGINIT                        CHERAMGinit

#define PERMSMWMAMF          CHERperm_mwm_amf
#define PERMSMWMAMD          CHERperm_mwm_amd
#define PERMSMWMMMD          CHERperm_mwm_mmd
#define PERMSMWMRCM          CHERperm_mwm_rcm
#define PERMSMWMMETISE       CHERperm_mwm_metis_e
#define PERMSMWMMETISN       CHERperm_mwm_metis_n

#define PERMSMC64AMF          CHERperm_mc64_amf
#define PERMSMC64AMD          CHERperm_mc64_amd
#define PERMSMC64MMD          CHERperm_mc64_mmd
#define PERMSMC64RCM          CHERperm_mc64_rcm
#define PERMSMC64METISE       CHERperm_mc64_metis_e
#define PERMSMC64METISN       CHERperm_mc64_metis_n

#define PERMSMC64AMF_SP          CHERperm_mc64_amf_sp
#define PERMSMC64AMD_SP          CHERperm_mc64_amd_sp
#define PERMSMC64MMD_SP          CHERperm_mc64_mmd_sp
#define PERMSMC64RCM_SP          CHERperm_mc64_rcm_sp
#define PERMSMC64METISE_SP       CHERperm_mc64_metis_e_sp
#define PERMSMC64METISN_SP       CHERperm_mc64_metis_n_sp

#define PERMSMWMAMF_SP          CHERperm_mwm_amf_sp
#define PERMSMWMAMD_SP          CHERperm_mwm_amd_sp
#define PERMSMWMMMD_SP          CHERperm_mwm_mmd_sp
#define PERMSMWMRCM_SP          CHERperm_mwm_rcm_sp
#define PERMSMWMMETISE_SP       CHERperm_mwm_metis_e_sp
#define PERMSMWMMETISN_SP       CHERperm_mwm_metis_n_sp

#define PERMSMATCHINGAMF_SP          CHERperm_matching_amf_sp
#define PERMSMATCHINGAMD_SP          CHERperm_matching_amd_sp
#define PERMSMATCHINGMMD_SP          CHERperm_matching_mmd_sp
#define PERMSMATCHINGRCM_SP          CHERperm_matching_rcm_sp
#define PERMSMATCHINGMETISE_SP       CHERperm_matching_metis_e_sp
#define PERMSMATCHINGMETISN_SP       CHERperm_matching_metis_n_sp

#define PERMSMATCHINGAMF          CHERperm_matching_amf
#define PERMSMATCHINGAMD          CHERperm_matching_amd
#define PERMSMATCHINGMMD          CHERperm_matching_mmd
#define PERMSMATCHINGRCM          CHERperm_matching_rcm
#define PERMSMATCHINGMETISE       CHERperm_matching_metis_e
#define PERMSMATCHINGMETISN       CHERperm_matching_metis_n

#define PERMSMWMAMFFCV        CHERperm_mwm_amf_fcv
#define PERMSMWMAMDFCV        CHERperm_mwm_amd_fcv
#define PERMSMWMMMDFCV        CHERperm_mwm_mmd_fcv
#define PERMSMWMRCMFCV        CHERperm_mwm_rcm_fcv
#define PERMSMWMMETISEFCV     CHERperm_mwm_metis_e_fcv
#define PERMSMWMMETISNFCV     CHERperm_mwm_metis_n_fcv

#define PERMSMC64AMFFCV       CHERperm_mc64_amf_fcv
#define PERMSMC64AMDFCV       CHERperm_mc64_amd_fcv
#define PERMSMC64MMDFCV       CHERperm_mc64_mmd_fcv
#define PERMSMC64RCMFCV       CHERperm_mc64_rcm_fcv
#define PERMSMC64METISEFCV    CHERperm_mc64_metis_e_fcv
#define PERMSMC64METISNFCV    CHERperm_mc64_metis_n_fcv

#define PERMSMATCHINGAMFFCV       CHERperm_matching_amf_fcv
#define PERMSMATCHINGAMDFCV       CHERperm_matching_amd_fcv
#define PERMSMATCHINGMMDFCV       CHERperm_matching_mmd_fcv
#define PERMSMATCHINGRCMFCV       CHERperm_matching_rcm_fcv
#define PERMSMATCHINGMETISEFCV    CHERperm_matching_metis_e_fcv
#define PERMSMATCHINGMETISNFCV    CHERperm_matching_metis_n_fcv

#define PERMSMWMAMFFC        CHERperm_mwm_amf_fc
#define PERMSMWMAMDFC        CHERperm_mwm_amd_fc
#define PERMSMWMMMDFC        CHERperm_mwm_mmd_fc
#define PERMSMWMRCMFC        CHERperm_mwm_rcm_fc
#define PERMSMWMMETISEFC     CHERperm_mwm_metis_e_fc
#define PERMSMWMMETISNFC     CHERperm_mwm_metis_n_fc

#define PERMSMC64AMFFC       CHERperm_mc64_amf_fc
#define PERMSMC64AMDFC       CHERperm_mc64_amd_fc
#define PERMSMC64MMDFC       CHERperm_mc64_mmd_fc
#define PERMSMC64RCMFC       CHERperm_mc64_rcm_fc
#define PERMSMC64METISEFC    CHERperm_mc64_metis_e_fc
#define PERMSMC64METISNFC    CHERperm_mc64_metis_n_fc

#define PERMSMATCHINGAMFFC       CHERperm_matching_amf_fc
#define PERMSMATCHINGAMDFC       CHERperm_matching_amd_fc
#define PERMSMATCHINGMMDFC       CHERperm_matching_mmd_fc
#define PERMSMATCHINGRCMFC       CHERperm_matching_rcm_fc
#define PERMSMATCHINGMETISEFC    CHERperm_matching_metis_e_fc
#define PERMSMATCHINGMETISNFC    CHERperm_matching_metis_n_fc


#else
#define MYSYMAMGSETUPPARAMETERS             ZHERAMGsetupparameters
#define MYSYMAMGINIT                        ZHERAMGinit

#define PERMSMWMAMF          ZHERperm_mwm_amf
#define PERMSMWMAMD          ZHERperm_mwm_amd
#define PERMSMWMMMD          ZHERperm_mwm_mmd
#define PERMSMWMRCM          ZHERperm_mwm_rcm
#define PERMSMWMMETISE       ZHERperm_mwm_metis_e
#define PERMSMWMMETISN       ZHERperm_mwm_metis_n

#define PERMSMC64AMF          ZHERperm_mc64_amf
#define PERMSMC64AMD          ZHERperm_mc64_amd
#define PERMSMC64MMD          ZHERperm_mc64_mmd
#define PERMSMC64RCM          ZHERperm_mc64_rcm
#define PERMSMC64METISE       ZHERperm_mc64_metis_e
#define PERMSMC64METISN       ZHERperm_mc64_metis_n

#define PERMSMC64AMF_SP          ZHERperm_mc64_amf_sp
#define PERMSMC64AMD_SP          ZHERperm_mc64_amd_sp
#define PERMSMC64MMD_SP          ZHERperm_mc64_mmd_sp
#define PERMSMC64RCM_SP          ZHERperm_mc64_rcm_sp
#define PERMSMC64METISE_SP       ZHERperm_mc64_metis_e_sp
#define PERMSMC64METISN_SP       ZHERperm_mc64_metis_n_sp

#define PERMSMWMAMF_SP          ZHERperm_mwm_amf_sp
#define PERMSMWMAMD_SP          ZHERperm_mwm_amd_sp
#define PERMSMWMMMD_SP          ZHERperm_mwm_mmd_sp
#define PERMSMWMRCM_SP          ZHERperm_mwm_rcm_sp
#define PERMSMWMMETISE_SP       ZHERperm_mwm_metis_e_sp
#define PERMSMWMMETISN_SP       ZHERperm_mwm_metis_n_sp

#define PERMSMATCHINGAMF_SP          ZHERperm_matching_amf_sp
#define PERMSMATCHINGAMD_SP          ZHERperm_matching_amd_sp
#define PERMSMATCHINGMMD_SP          ZHERperm_matching_mmd_sp
#define PERMSMATCHINGRCM_SP          ZHERperm_matching_rcm_sp
#define PERMSMATCHINGMETISE_SP       ZHERperm_matching_metis_e_sp
#define PERMSMATCHINGMETISN_SP       ZHERperm_matching_metis_n_sp

#define PERMSMATCHINGAMF          ZHERperm_matching_amf
#define PERMSMATCHINGAMD          ZHERperm_matching_amd
#define PERMSMATCHINGMMD          ZHERperm_matching_mmd
#define PERMSMATCHINGRCM          ZHERperm_matching_rcm
#define PERMSMATCHINGMETISE       ZHERperm_matching_metis_e
#define PERMSMATCHINGMETISN       ZHERperm_matching_metis_n

#define PERMSMWMAMFFCV        ZHERperm_mwm_amf_fcv
#define PERMSMWMAMDFCV        ZHERperm_mwm_amd_fcv
#define PERMSMWMMMDFCV        ZHERperm_mwm_mmd_fcv
#define PERMSMWMRCMFCV        ZHERperm_mwm_rcm_fcv
#define PERMSMWMMETISEFCV     ZHERperm_mwm_metis_e_fcv
#define PERMSMWMMETISNFCV     ZHERperm_mwm_metis_n_fcv

#define PERMSMC64AMFFCV       ZHERperm_mc64_amf_fcv
#define PERMSMC64AMDFCV       ZHERperm_mc64_amd_fcv
#define PERMSMC64MMDFCV       ZHERperm_mc64_mmd_fcv
#define PERMSMC64RCMFCV       ZHERperm_mc64_rcm_fcv
#define PERMSMC64METISEFCV    ZHERperm_mc64_metis_e_fcv
#define PERMSMC64METISNFCV    ZHERperm_mc64_metis_n_fcv

#define PERMSMATCHINGAMFFCV       ZHERperm_matching_amf_fcv
#define PERMSMATCHINGAMDFCV       ZHERperm_matching_amd_fcv
#define PERMSMATCHINGMMDFCV       ZHERperm_matching_mmd_fcv
#define PERMSMATCHINGRCMFCV       ZHERperm_matching_rcm_fcv
#define PERMSMATCHINGMETISEFCV    ZHERperm_matching_metis_e_fcv
#define PERMSMATCHINGMETISNFCV    ZHERperm_matching_metis_n_fcv

#define PERMSMWMAMFFC        ZHERperm_mwm_amf_fc
#define PERMSMWMAMDFC        ZHERperm_mwm_amd_fc
#define PERMSMWMMMDFC        ZHERperm_mwm_mmd_fc
#define PERMSMWMRCMFC        ZHERperm_mwm_rcm_fc
#define PERMSMWMMETISEFC     ZHERperm_mwm_metis_e_fc
#define PERMSMWMMETISNFC     ZHERperm_mwm_metis_n_fc

#define PERMSMC64AMFFC       ZHERperm_mc64_amf_fc
#define PERMSMC64AMDFC       ZHERperm_mc64_amd_fc
#define PERMSMC64MMDFC       ZHERperm_mc64_mmd_fc
#define PERMSMC64RCMFC       ZHERperm_mc64_rcm_fc
#define PERMSMC64METISEFC    ZHERperm_mc64_metis_e_fc
#define PERMSMC64METISNFC    ZHERperm_mc64_metis_n_fc

#define PERMSMATCHINGAMFFC       ZHERperm_matching_amf_fc
#define PERMSMATCHINGAMDFC       ZHERperm_matching_amd_fc
#define PERMSMATCHINGMMDFC       ZHERperm_matching_mmd_fc
#define PERMSMATCHINGRCMFC       ZHERperm_matching_rcm_fc
#define PERMSMATCHINGMETISEFC    ZHERperm_matching_metis_e_fc
#define PERMSMATCHINGMETISNFC    ZHERperm_matching_metis_n_fc

#endif

#endif



#endif




void MYSYMAMGSETUPPARAMETERS(CSRMAT *A, ILUPACKPARAM *param, integer env)
/*
  written by Matthias Bollhoefer, October 2006
*/
{
  integer i,j;
       
   // ******************************************************************
   // new parameter selection scheme
   // ******************************************************************

   // first part: paramaters to be set up prior to building the 
   // preconditioner
   if (env==0) {
      // do FCpart and typetv have legal values? maybe not
      if (strncmp("yes",param->FCpart,3) && strncmp("none",param->FCpart,4)) {
	 param->FCpart="none";
      }

      // index indicator
      if (param->ind!=NULL) {
	 if (param->nindicator==0) {
	    param->nindicator=2*A->nc;
	    param->indicator=(integer *)MALLOC((size_t)param->nindicator*sizeof(integer),
					       "AMGsetupparameters:param->indicator");
	 }
	 else {
	    param->nindicator=MAX(param->nindicator,2*A->nc);
2*A->nc;
	    param->indicator=(integer *)REALLOC(param->indicator,
					       (size_t)param->nindicator*sizeof(integer),
					       "AMGsetupparameters:param->indicator");
	 }
	 j=0;
	 for (i=0; i<A->nc; i++) {
	     param->indicator[i]=param->ind[i];
	     if (param->indicator[i]<0)
	        j=-1;
	 }
	 if (j) {
	    param->flags|=SADDLE_POINT;
	 }
      }

      // first step: carefully select the drivers
      // is matching turned on? yes
      if (param->matching) {
	 // do we want to pre-select coarse grid nodes? yes
	 if (param->FCpart!=NULL && strlen(param->FCpart)>0) {
	    if (!strncmp("yes",param->FCpart,3)) {
	       // do we want to use test vectors for filtering? yes
	       if (param->typetv!=NULL && strlen(param->typetv)>0) {
		  if (strncmp("none",param->typetv,4)) {
		     // 1. maximum weight matching
		     // 2. fine/coarse grid partitioning
		     // 3. ... based on static or dynamic test vector
		     // 4. saddle point
		     if (param->ordering==NULL || strlen(param->ordering)==0) {
		        // custom settings from the user
		     }
		     else if (!strncmp("amd",param->ordering,3)) {
#ifdef _MC64_MATCHING_
		        param->perm0         =PERMSMC64AMDFCV;
			param->perm          =PERMSMC64AMDFCV;
#elif defined _PARDISO_MATCHING_
		        param->perm0         =PERMSMWMAMDFCV;
			param->perm          =PERMSMWMAMDFCV;
#else // _MUMPS_MATCHING_ assumed by default
		        param->perm0         =PERMSMATCHINGAMDFCV;
			param->perm          =PERMSMATCHINGAMDFCV;
#endif

			param->permf         =SPDPERMPP;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  &=~FINAL_PIVOTING;
		     }
		     else if (!strncmp("metisn",param->ordering,6)) {
#ifdef _MC64_MATCHING_
		        param->perm0         =PERMSMC64METISNFCV;
			param->perm          =PERMSMC64METISNFCV;
#elif defined _PARDISO_MATCHING_
		        param->perm0         =PERMSMWMMETISNFCV;
			param->perm          =PERMSMWMMETISNFCV;
#else // _MUMPS_MATCHING_ assumed by default
		        param->perm0         =PERMSMATCHINGMETISNFCV;
			param->perm          =PERMSMATCHINGMETISNFCV;
#endif
			param->permf         =SPDPERMPP;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  &=~FINAL_PIVOTING;
		     }
		     else if (!strncmp("metise",param->ordering,6)) {
#ifdef _MC64_MATCHING_
		        param->perm0         =PERMSMC64METISEFCV;
			param->perm          =PERMSMC64METISEFCV;
#elif defined _PARDISO_MATCHING_
		        param->perm0         =PERMSMWMMETISEFCV;
			param->perm          =PERMSMWMMETISEFCV;
#else // _MUMPS_MATCHING_ assumed by default
		        param->perm0         =PERMSMATCHINGMETISEFCV;
			param->perm          =PERMSMATCHINGMETISEFCV;
#endif
			param->permf         =SPDPERMPP;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  &=~FINAL_PIVOTING;
		     }
		     else if (!strncmp("rcm",param->ordering,3)) {
#ifdef _MC64_MATCHING_
		        param->perm0         =PERMSMC64RCMFCV;
			param->perm          =PERMSMC64RCMFCV;
#elif defined _PARDISO_MATCHING_
		        param->perm0         =PERMSMWMRCMFCV;
			param->perm          =PERMSMWMRCMFCV;
#else // _MUMPS_MATCHING_ assumed by default
		        param->perm0         =PERMSMATCHINGRCMFCV;
			param->perm          =PERMSMATCHINGRCMFCV;
#endif
			param->permf         =SPDPERMPP;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  &=~FINAL_PIVOTING;
		     }
		     else if (!strncmp("amf",param->ordering,3)) {
#ifdef _MC64_MATCHING_
		        param->perm0         =PERMSMC64AMFFCV;
			param->perm          =PERMSMC64AMFFCV;
#elif defined _PARDISO_MATCHING_
		        param->perm0         =PERMSMWMAMFFCV;
			param->perm          =PERMSMWMAMFFCV;
#else // _MUMPS_MATCHING_ assumed by default
		        param->perm0         =PERMSMATCHINGAMFFCV;
			param->perm          =PERMSMATCHINGAMFFCV;
#endif
			param->permf         =SPDPERMPP;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  &=~FINAL_PIVOTING;
		     }
		     else if (!strncmp("mmd",param->ordering,3)) {
#ifdef _MC64_MATCHING_
		        param->perm0         =PERMSMC64MMDFCV;
			param->perm          =PERMSMC64MMDFCV;
#elif defined _PARDISO_MATCHING_
		        param->perm0         =PERMSMWMMMDFCV;
			param->perm          =PERMSMWMMMDFCV;
#else // _MUMPS_MATCHING_ assumed by default
		        param->perm0         =PERMSMATCHINGMMDFCV;
			param->perm          =PERMSMATCHINGMMDFCV;
#endif
			param->permf         =SPDPERMPP;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  &=~FINAL_PIVOTING;
		     }
		     /*
		     else if (!strncmp("indset",param->ordering,6)) {
#ifdef _MC64_MATCHING_
		        param->perm0         =PERMSMC64INDSETFCV;
			param->perm          =PERMSMC64INDSETFCV;
#elif defined _PARDISO_MATCHING_
		        param->perm0         =PERMSMWMINDSETFCV;
			param->perm          =PERMSMWMINDSETFCV;
#else // _MUMPS_MATCHING_ assumed by default
		        param->perm0         =PERMSMATCHINGINDSETFCV;
			param->perm          =PERMSMATCHINGINDSETFCV;
#endif
			param->permf         =SPDPERMPP;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  &=~FINAL_PIVOTING;
		     }
		     else if (!strncmp("none",param->ordering,4)) {
#ifdef _MC64_MATCHING_
		        param->perm0         =PERMSMC64FCV;
			param->perm          =PERMSMC64FCV;
#elif defined _PARDISO_MATCHING_
		        param->perm0         =PERMSMWMFCV;
			param->perm          =PERMSMWMFCV;
#else // _MUMPS_MATCHING_ assumed by default
		        param->perm0         =PERMSMATCHINGFCV;
			param->perm          =PERMSMATCHINGFCV;
#endif
			param->permf         =SPDPERMPP;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  |=FINAL_PIVOTING;
	             }
		     */
		     else if (!strncmp("pp",param->ordering,2)) {
		        param->perm0         =SPDPERMPP;
			param->perm          =SPDPERMPP;
			param->permf         =SPDPERMPP;
			// ignore permf
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  &=~FINAL_PIVOTING;
		     }
		     // no sensible string
		     else {
		        // custom settings from the user
		     }
		  }
		  // 3. no test vector
		  else {
		     // 1. maximum weight matching
		     // 2. fine/coarse grid partitioning
		     // 3. no test vector
		     if (param->ordering==NULL || strlen(param->ordering)==0) {
		        // custom settings from the user
		     }
		     else if (!strncmp("amd",param->ordering,3)) {
#ifdef _MC64_MATCHING_
		        param->perm0         =PERMSMC64AMDFC;
			param->perm          =PERMSMC64AMDFC;
#elif defined _PARDISO_MATCHING_
		        param->perm0         =PERMSMWMAMDFC;
			param->perm          =PERMSMWMAMDFC;
#else // _MUMPS_MATCHING_ assumed by default
		        param->perm0         =PERMSMATCHINGAMDFC;
			param->perm          =PERMSMATCHINGAMDFC;
#endif
			param->permf         =SPDPERMPP;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  &=~FINAL_PIVOTING;
		     }
		     else if (!strncmp("metisn",param->ordering,6)) {
#ifdef _MC64_MATCHING_
		        param->perm0         =PERMSMC64METISNFC;
			param->perm          =PERMSMC64METISNFC;
#elif defined _PARDISO_MATCHING_
		        param->perm0         =PERMSMWMMETISNFC;
			param->perm          =PERMSMWMMETISNFC;
#else // _MUMPS_MATCHING_ assumed by default
		        param->perm0         =PERMSMATCHINGMETISNFC;
			param->perm          =PERMSMATCHINGMETISNFC;
#endif
			param->permf         =SPDPERMPP;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  &=~FINAL_PIVOTING;
		     }
		     else if (!strncmp("metise",param->ordering,6)) {
#ifdef _MC64_MATCHING_
		        param->perm0         =PERMSMC64METISEFC;
			param->perm          =PERMSMC64METISEFC;
#elif defined _PARDISO_MATCHING_
		        param->perm0         =PERMSMWMMETISEFC;
			param->perm          =PERMSMWMMETISEFC;
#else // _MUMPS_MATCHING_ assumed by default
		        param->perm0         =PERMSMATCHINGMETISEFC;
			param->perm          =PERMSMATCHINGMETISEFC;
#endif
			param->permf         =SPDPERMPP;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  &=~FINAL_PIVOTING;
		     }
		     else if (!strncmp("rcm",param->ordering,3)) {
#ifdef _MC64_MATCHING_
		        param->perm0         =PERMSMC64RCMFC;
			param->perm          =PERMSMC64RCMFC;
#elif defined _PARDISO_MATCHING_
		        param->perm0         =PERMSMWMRCMFC;
			param->perm          =PERMSMWMRCMFC;
#else // _MUMPS_MATCHING_ assumed by default
		        param->perm0         =PERMSMATCHINGRCMFC;
			param->perm          =PERMSMATCHINGRCMFC;
#endif
			param->permf         =SPDPERMPP;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  &=~FINAL_PIVOTING;
		     }
		     else if (!strncmp("amf",param->ordering,3)) {
#ifdef _MC64_MATCHING_
		        param->perm0         =PERMSMC64AMFFC;
			param->perm          =PERMSMC64AMFFC;
#elif defined _PARDISO_MATCHING_
		        param->perm0         =PERMSMWMAMFFC;
			param->perm          =PERMSMWMAMFFC;
#else // _MUMPS_MATCHING_ assumed by default
		        param->perm0         =PERMSMATCHINGAMFFC;
			param->perm          =PERMSMATCHINGAMFFC;
#endif
			param->permf         =SPDPERMPP;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  &=~FINAL_PIVOTING;
		     }
		     else if (!strncmp("mmd",param->ordering,3)) {
#ifdef _MC64_MATCHING_
		        param->perm0         =PERMSMC64MMDFC;
			param->perm          =PERMSMC64MMDFC;
#elif defined _PARDISO_MATCHING_
		        param->perm0         =PERMSMWMMMDFC;
			param->perm          =PERMSMWMMMDFC;
#else // _MUMPS_MATCHING_ assumed by default
		        param->perm0         =PERMSMATCHINGMMDFC;
			param->perm          =PERMSMATCHINGMMDFC;
#endif
			param->permf         =SPDPERMPP;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  &=~FINAL_PIVOTING;
		     }
		     /*
		     else if (!strncmp("indset",param->ordering,6)) {
#ifdef _MC64_MATCHING_
		        param->perm0         =PERMSMC64INDSETFC;
			param->perm          =PERMSMC64INDSETFC;
#elif defined _PARDISO_MATCHING_
		        param->perm0         =PERMSMWMINDSETFC;
			param->perm          =PERMSMWMINDSETFC;
#else // _MUMPS_MATCHING_ assumed by default
		        param->perm0         =PERMSMATCHINGINDSETFC;
			param->perm          =PERMSMATCHINGINDSETFC;
#endif
			param->permf         =SPDPERMPP;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  &=~FINAL_PIVOTING;
		     }
		     else if (!strncmp("none",param->ordering,4)) {
#ifdef _MC64_MATCHING_
		        param->perm0         =PERMSMC64FC;
			param->perm          =PERMSMC64FC;
#elif defined _PARDISO_MATCHING_
		        param->perm0         =PERMSMWMFC;
			param->perm          =PERMSMWMFC;
#else // _MUMPS_MATCHING_ assumed by default
		        param->perm0         =PERMSMATCHINGFC;
			param->perm          =PERMSMATCHINGFC;
#endif
			param->permf         =SPDPERMPP;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  |=FINAL_PIVOTING;
	             }
		     */
		     else if (!strncmp("pp",param->ordering,2)) {
		        param->perm0         =SPDPERMPP;
			param->perm          =SPDPERMPP;
			param->permf         =SPDPERMPP;
			// ignore permf
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  &=~FINAL_PIVOTING;
		     }
		     // no sensible string
		     else  {
		        // custom settings from the user
		     }
		  }
	       }
	       // no sensible string
	       else {
		  // custom settings from the user
	       }
	    }
	    // do we want to pre-select coarse grid nodes? no
	    else {
	       // 1. maximum weight matching
	       // 2. no fine/coarse grid partitioning
	       // 3. ... whatever the test vector will be
	       // no sensible string
	       if (param->ordering==NULL || strlen(param->ordering)==0) {
		  // custom settings from the user
	       }
	       else if (!strncmp("amd",param->ordering,3)) {
		  if (param->flags&SADDLE_POINT) {
#ifdef _MC64_MATCHING_
		     param->perm0         =PERMSMC64AMD_SP;
		     param->perm          =PERMSMC64AMD_SP;
#elif defined _PARDISO_MATCHING_
		     param->perm0         =PERMSMWMAMD_SP;
		     param->perm          =PERMSMWMAMD_SP;
#else // _MUMPS_MATCHING_ assumed by default
		     param->perm0         =PERMSMATCHINGAMD_SP;
		     param->perm          =PERMSMATCHINGAMD_SP;
#endif
		     param->permf         =SPDPERMPP;
		  }
		  else {
#ifdef _MC64_MATCHING_
		     param->perm0         =PERMSMC64AMD;
		     param->perm          =PERMSMC64AMD;
#elif defined _PARDISO_MATCHING_
		     param->perm0         =PERMSMWMAMD;
		     param->perm          =PERMSMWMAMD;
#else // _MUMPS_MATCHING_ assumed by default
		     param->perm0         =PERMSMATCHINGAMD;
		     param->perm          =PERMSMATCHINGAMD;
#endif
		     param->permf         =SPDPERMPP;
		  }
		  param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		  param->flags  |=PREPROCESS_SUBSYSTEMS;
		  param->flags  &=~FINAL_PIVOTING;
	       }
	       else if (!strncmp("metisn",param->ordering,6)) {
		  if (param->flags&SADDLE_POINT) {
#ifdef _MC64_MATCHING_
		     param->perm0         =PERMSMC64METISN_SP;
		     param->perm          =PERMSMC64METISN_SP;
#elif defined _PARDISO_MATCHING_
		     param->perm0         =PERMSMWMMETISN_SP;
		     param->perm          =PERMSMWMMETISN_SP;
#else // _MUMPS_MATCHING_ assumed by default
		     param->perm0         =PERMSMATCHINGMETISN_SP;
		     param->perm          =PERMSMATCHINGMETISN_SP;
#endif
		     param->permf         =SPDPERMPP;
		  }
		  else {
#ifdef _MC64_MATCHING_
		     param->perm0         =PERMSMC64METISN;
		     param->perm          =PERMSMC64METISN;
#elif defined _PARDISO_MATCHING_
		     param->perm0         =PERMSMWMMETISN;
		     param->perm          =PERMSMWMMETISN;
#else // _MUMPS_MATCHING_ assumed by default
		     param->perm0         =PERMSMATCHINGMETISN;
		     param->perm          =PERMSMATCHINGMETISN;
#endif
		     param->permf         =SPDPERMPP;
		  }
		  param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		  param->flags  |=PREPROCESS_SUBSYSTEMS;
		  param->flags  &=~FINAL_PIVOTING;
	       }
	       else if (!strncmp("metise",param->ordering,6)) {
		  if (param->flags&SADDLE_POINT) {
#ifdef _MC64_MATCHING_
		     param->perm0         =PERMSMC64METISE_SP;
		     param->perm          =PERMSMC64METISE_SP;
#elif defined _PARDISO_MATCHING_
		     param->perm0         =PERMSMWMMETISE_SP;
		     param->perm          =PERMSMWMMETISE_SP;
#else // _MUMPS_MATCHING_ assumed by default
		     param->perm0         =PERMSMATCHINGMETISE_SP;
		     param->perm          =PERMSMATCHINGMETISE_SP;
#endif
		     param->permf         =SPDPERMPP;
		  }
		  else {
#ifdef _MC64_MATCHING_
		     param->perm0         =PERMSMC64METISE;
		     param->perm          =PERMSMC64METISE;
#elif defined _PARDISO_MATCHING_
		     param->perm0         =PERMSMWMMETISE;
		     param->perm          =PERMSMWMMETISE;
#else // _MUMPS_MATCHING_ assumed by default
		     param->perm0         =PERMSMATCHINGMETISE;
		     param->perm          =PERMSMATCHINGMETISE;
#endif
		     param->permf         =SPDPERMPP;
		  }
		  param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		  param->flags  |=PREPROCESS_SUBSYSTEMS;
		  param->flags  &=~FINAL_PIVOTING;
	       }
	       else if (!strncmp("rcm",param->ordering,3)) {
		  if (param->flags&SADDLE_POINT) {
#ifdef _MC64_MATCHING_
		     param->perm0         =PERMSMC64RCM_SP;
		     param->perm          =PERMSMC64RCM_SP;
#elif defined _PARDISO_MATCHING_
		     param->perm0         =PERMSMWMRCM_SP;
		     param->perm          =PERMSMWMRCM_SP;
#else // _MUMPS_MATCHING_ assumed by default
		     param->perm0         =PERMSMATCHINGRCM_SP;
		     param->perm          =PERMSMATCHINGRCM_SP;
#endif
		     param->permf         =SPDPERMPP;
		  }
		  else {
#ifdef _MC64_MATCHING_
		    param->perm0         =PERMSMC64RCM;
		    param->perm          =PERMSMC64RCM;
#elif defined _PARDISO_MATCHING_
		    param->perm0         =PERMSMWMRCM;
		    param->perm          =PERMSMWMRCM;
#else // _MUMPS_MATCHING_ assumed by default
		    param->perm0         =PERMSMATCHINGRCM;
		    param->perm          =PERMSMATCHINGRCM;
#endif
		    param->permf         =SPDPERMPP;
		  }
		  param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		  param->flags  |=PREPROCESS_SUBSYSTEMS;
		  param->flags  &=~FINAL_PIVOTING;
	       }
	       else if (!strncmp("amf",param->ordering,3)) {
		  if (param->flags&SADDLE_POINT) {
#ifdef _MC64_MATCHING_
		     param->perm0         =PERMSMC64AMF_SP;
		     param->perm          =PERMSMC64AMF_SP;
#elif defined _PARDISO_MATCHING_
		     param->perm0         =PERMSMWMAMF_SP;
		     param->perm          =PERMSMWMAMF_SP;
#else // _MUMPS_MATCHING_ assumed by default
		     param->perm0         =PERMSMATCHINGAMF_SP;
		     param->perm          =PERMSMATCHINGAMF_SP;
#endif
		     param->permf         =SPDPERMPP;
		  }
		  else {
#ifdef _MC64_MATCHING_
		     param->perm0         =PERMSMC64AMF;
		     param->perm          =PERMSMC64AMF;
#elif defined _PARDISO_MATCHING_
		     param->perm0         =PERMSMWMAMF;
		     param->perm          =PERMSMWMAMF;
#else // _MUMPS_MATCHING_ assumed by default
		     param->perm0         =PERMSMATCHINGAMF;
		     param->perm          =PERMSMATCHINGAMF;
#endif
		     param->permf         =SPDPERMPP;
		  }
		  param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		  param->flags  |=PREPROCESS_SUBSYSTEMS;
		  param->flags  &=~FINAL_PIVOTING;
	       }
	       else if (!strncmp("mmd",param->ordering,3)) {
		  if (param->flags&SADDLE_POINT) {
#ifdef _MC64_MATCHING_
		     param->perm0         =PERMSMC64MMD_SP;
		     param->perm          =PERMSMC64MMD_SP;
#elif defined _PARDISO_MATCHING_
		     param->perm0         =PERMSMWMMMD_SP;
		     param->perm          =PERMSMWMMMD_SP;
#else // _MUMPS_MATCHING_ assumed by default
		     param->perm0         =PERMSMATCHINGMMD_SP;
		     param->perm          =PERMSMATCHINGMMD_SP;
#endif
		     param->permf         =SPDPERMPP;
		  }
		  else {
#ifdef _MC64_MATCHING_
		     param->perm0         =PERMSMC64MMD;
		     param->perm          =PERMSMC64MMD;
#elif defined _PARDISO_MATCHING_
		     param->perm0         =PERMSMWMMMD;
		     param->perm          =PERMSMWMMMD;
#else // _MUMPS_MATCHING_ assumed by default
		     param->perm0         =PERMSMATCHINGMMD;
		     param->perm          =PERMSMATCHINGMMD;
#endif
		     param->permf         =SPDPERMPP;
		  }
		  param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		  param->flags  |=PREPROCESS_SUBSYSTEMS;
		  param->flags  &=~FINAL_PIVOTING;
	       }
	       /*
	       else if (!strncmp("indset",param->ordering,6)) {
#ifdef _MC64_MATCHING_
		  param->perm0         =PERMSMC64INDSET;
		  param->perm          =PERMSMC64INDSET;
#elif defined _PARDISO_MATCHING_
		  param->perm0         =PERMSMWMINDSET;
		  param->perm          =PERMSMWMINDSET;
#else // _MUMPS_MATCHING_ assumed by default
		  param->perm0         =PERMSMATCHINGINDSET;
		  param->perm          =PERMSMATCHINGINDSET;
#endif
		  param->permf         =SPDPERMPP;
		  param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		  param->flags  |=PREPROCESS_SUBSYSTEMS;
		  param->flags  &=~FINAL_PIVOTING;
	       } 
	       else if (!strncmp("none",param->ordering,4)) {
#ifdef _MC64_MATCHING_
		  param->perm0         =PERMSMC64;
		  param->perm          =PERMSMC64;
#elif defined _PARDISO_MATCHING_
		  param->perm0         =PERMSMWM;
		  param->perm          =PERMSMWM;
#else // _MUMPS_MATCHING_ assumed by default
		  param->perm0         =PERMSMATCHING;
		  param->perm          =PERMSMATCHING;
#endif
		  param->permf         =SPDPERMPP;
		  param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		  param->flags  |=PREPROCESS_SUBSYSTEMS;
		  param->flags  |=FINAL_PIVOTING;
	       }
	       */
	       else if (!strncmp("pp",param->ordering,2)) {
		  param->perm0         =SPDPERMPP;
		  param->perm          =SPDPERMPP;
		  param->permf         =SPDPERMPP;
		  // ignore permf
		  param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		  param->flags  |=PREPROCESS_SUBSYSTEMS;
		  param->flags  &=~FINAL_PIVOTING;
	       }
	       // no sensible string
	       else {
		  // custom settings from the user
	       }
	    }
	 }
	 // no sensible string
	 else {
	    // custom settings from the user
	 }
      }
      // no matching
      else {
	 // do we want to pre-select coarse grid nodes? yes
	 if (param->FCpart!=NULL && strlen(param->FCpart)>0) {
	    if (!strncmp("yes",param->FCpart,3)) {
	       // do we want to use test vectors for filtering? yes
	       if (param->typetv!=NULL && strlen(param->typetv)>0) {
		  if (strncmp("none",param->typetv,4)) {
		     // 1. no matching
		     // 2. fine/coarse grid partitioning
		     // 3. ... based on static or dynamic test vector
		     // no sensible string
		     if (param->ordering==NULL || strlen(param->ordering)==0) {
		        // custom settings from the user
		     }
		     else if (!strncmp("amd",param->ordering,3)) {
		        param->perm0         =SYMPERMAMDFCV;
			param->perm          =SYMPERMAMDFCV;
			param->permf         =SPDPERMPP;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  |=FINAL_PIVOTING;
		     }
		     else if (!strncmp("metisn",param->ordering,6)) {
		        param->perm0         =SYMPERMMETISNFCV;
			param->perm          =SYMPERMMETISNFCV;
			param->permf         =SPDPERMPP;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  |=FINAL_PIVOTING;
		     }
		     else if (!strncmp("metise",param->ordering,6)) {
		        param->perm0         =SYMPERMMETISEFCV;
			param->perm          =SYMPERMMETISEFCV;
			param->permf         =SPDPERMPP;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  |=FINAL_PIVOTING;
		     }
		     else if (!strncmp("rcm",param->ordering,3)) {
		        param->perm0         =SYMPERMRCMFCV;
			param->perm          =SYMPERMRCMFCV;
			param->permf         =SPDPERMPP;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  |=FINAL_PIVOTING;
		     }
		     else if (!strncmp("amf",param->ordering,3)) {
		        param->perm0         =SYMPERMAMFFCV;
			param->perm          =SYMPERMAMFFCV;
			param->permf         =SPDPERMPP;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  |=FINAL_PIVOTING;
		     }
		     else if (!strncmp("mmd",param->ordering,3)) {
		        param->perm0         =SYMPERMMMDFCV;
			param->perm          =SYMPERMMMDFCV;
			param->permf         =SPDPERMPP;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  |=FINAL_PIVOTING;
		     }
		     /*
		     else if (!strncmp("indset",param->ordering,6)) {
		        param->perm0         =SYMPERMINDSETFCV;
			param->perm          =SYMPERMINDSETFCV;
			param->permf         =SPDPERMPP;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  |=FINAL_PIVOTING;
		     }
		     */
		     else if (!strncmp("none",param->ordering,4)) {
		        param->perm0         =SYMPERMFCV;
			param->perm          =SYMPERMFCV;
			param->permf         =SPDPERMPP;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  |=FINAL_PIVOTING;
		     }
		     else if (!strncmp("pp",param->ordering,2)) {
		        param->perm0         =SPDPERMPP;
			param->perm          =SPDPERMPP;
			param->permf         =SPDPERMPP;
			// ignore permf
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  &=~FINAL_PIVOTING;
		     }
		     // no sensible string
		     else  {
		        // custom settings from the user
		     }
		  }
		  // 3. no test vector
		  else {
		     // 1. no matching
		     // 2. fine/coarse grid partitioning
		     // 3. no test vector
		     // no sensible string
		     if (param->ordering==NULL || strlen(param->ordering)==0) {
		        // custom settings from the user
		     }
		     else if (!strncmp("amd",param->ordering,3)) {
		        param->perm0         =SYMPERMAMDFC;
			param->perm          =SYMPERMAMDFC;
			param->permf         =SPDPERMPP;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  |=FINAL_PIVOTING;
		     }
		     else if (!strncmp("metisn",param->ordering,6)) {
		        param->perm0         =SYMPERMMETISNFC;
			param->perm          =SYMPERMMETISNFC;
			param->permf         =SPDPERMPP;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  |=FINAL_PIVOTING;
		     }
		     else if (!strncmp("metise",param->ordering,6)) {
		        param->perm0         =SYMPERMMETISEFC;
			param->perm          =SYMPERMMETISEFC;
			param->permf         =SPDPERMPP;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  |=FINAL_PIVOTING;
		     }
		     else if (!strncmp("rcm",param->ordering,3)) {
		        param->perm0         =SYMPERMRCMFC;
			param->perm          =SYMPERMRCMFC;
			param->permf         =SPDPERMPP;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  |=FINAL_PIVOTING;
		     }
		     else if (!strncmp("amf",param->ordering,3)) {
		        param->perm0         =SYMPERMAMFFC;
			param->perm          =SYMPERMAMFFC;
			param->permf         =SPDPERMPP;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  |=FINAL_PIVOTING;
		     }
		     else if (!strncmp("mmd",param->ordering,3)) {
		        param->perm0         =SYMPERMMMDFC;
			param->perm          =SYMPERMMMDFC;
			param->permf         =SPDPERMPP;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  |=FINAL_PIVOTING;
		     }
		     /*
		     else if (!strncmp("indset",param->ordering,6)) {
		        param->perm0         =SYMPERMINDSETFC;
			param->perm          =SYMPERMINDSETFC;
			param->permf         =SPDPERMPP;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  |=FINAL_PIVOTING;
		     }
		     */
		     else if (!strncmp("none",param->ordering,4)) {
		        param->perm0         =SYMPERMFC;
			param->perm          =SYMPERMFC;
			param->permf         =SPDPERMPP;
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  |=FINAL_PIVOTING;
		     }
		     else if (!strncmp("pp",param->ordering,2)) {
		        param->perm0         =SPDPERMPP;
			param->perm          =SPDPERMPP;
			param->permf         =SPDPERMPP;
			// ignore permf
			param->flags  |=PREPROCESS_INITIAL_SYSTEM;
			param->flags  |=PREPROCESS_SUBSYSTEMS;
			param->flags  &=~FINAL_PIVOTING;
		     }
		     // no sensible string
		     else  {
		        // custom settings from the user
		     }
		  }
	       }
	       // no sensible string
	       else {
		  // custom settings from the user
	       }
	    }
	    // do we want to pre-select coarse grid nodes? no
	    else {
	       // 1. no matching
	       // 2. no fine/coarse grid partitioning
	       // 3. do not care about the test vector
	       // no sensible string
	       if (param->ordering==NULL || strlen(param->ordering)==0) {
	          // custom settings from the user
	       }
	       else if (!strncmp("amd",param->ordering,3)) {
		  param->perm0         =SYMPERMAMD;
		  param->perm          =SYMPERMAMD;
		  param->permf         =SPDPERMPP;
		  param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		  param->flags  |=PREPROCESS_SUBSYSTEMS;
		  param->flags  |=FINAL_PIVOTING;
	       }
	       else if (!strncmp("metisn",param->ordering,6)) {
		  if (param->flags&SADDLE_POINT) {
		    /* in principle we should later replace this 
		       drive by one without matching !!! */
#ifdef _MC64_MATCHING_
		     param->perm0         =PERMSMC64METISN_SP;
		     param->perm          =PERMSMC64METISN_SP;
#elif defined _PARDISO_MATCHING_
		     param->perm0         =PERMSMWMMETISN_SP;
		     param->perm          =PERMSMWMMETISN_SP;
#else // _MUMPS_MATCHING_ assumed by default
		     param->perm0         =PERMSMATCHINGMETISN_SP;
		     param->perm          =PERMSMATCHINGMETISN_SP;
#endif
		     param->permf         =SPDPERMPP;
		  }
		  else {
		     param->perm0         =SYMPERMMETISN;
		     param->perm          =SYMPERMMETISN;
		     param->permf         =SPDPERMPP;
		  }
		  param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		  param->flags  |=PREPROCESS_SUBSYSTEMS;
		  param->flags  |=FINAL_PIVOTING;
	       }
	       else if (!strncmp("metise",param->ordering,6)) {
		  param->perm0         =SYMPERMMETISE;
		  param->perm          =SYMPERMMETISE;
		  param->permf         =SPDPERMPP;
		  param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		  param->flags  |=PREPROCESS_SUBSYSTEMS;
		  param->flags  |=FINAL_PIVOTING;
	       }
	       else if (!strncmp("rcm",param->ordering,3)) {
		  param->perm0         =SYMPERMRCM;
		  param->perm          =SYMPERMRCM;
		  param->permf         =SPDPERMPP;
		  param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		  param->flags  |=PREPROCESS_SUBSYSTEMS;
		  param->flags  |=FINAL_PIVOTING;
	       }
	       else if (!strncmp("amf",param->ordering,3)) {
		  param->perm0         =SYMPERMAMF;
		  param->perm          =SYMPERMAMF;
		  param->permf         =SPDPERMPP;
		  param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		  param->flags  |=PREPROCESS_SUBSYSTEMS;
		  param->flags  |=FINAL_PIVOTING;
	       }
	       else if (!strncmp("mmd",param->ordering,3)) {
		  param->perm0         =SYMPERMMMD;
		  param->perm          =SYMPERMMMD;
		  param->permf         =SPDPERMPP;
		  param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		  param->flags  |=PREPROCESS_SUBSYSTEMS;
		  param->flags  |=FINAL_PIVOTING;
	       }
	       /*
	       else if (!strncmp("indset",param->ordering,6)) {
	          param->perm0         =SYMPERMINDSET;
		  param->perm          =SYMPERMINDSET;
		  param->permf         =SPDPERMPP;
		  param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		  param->flags  |=PREPROCESS_SUBSYSTEMS;
		  param->flags  |=FINAL_PIVOTING;
	       } 
	       */
	       else if (!strncmp("none",param->ordering,4)) {
		  param->perm0         =SYMPERMNULL;
		  param->perm          =SYMPERMNULL;
		  param->permf         =SPDPERMPP;
		  param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		  param->flags  |=PREPROCESS_SUBSYSTEMS;
		  param->flags  |=FINAL_PIVOTING;
	       }
	       else if (!strncmp("pp",param->ordering,2)) {
		  param->perm0         =SPDPERMPP;
		  param->perm          =SPDPERMPP;
		  param->permf         =SPDPERMPP;
		  // ignore permf
		  param->flags  |=PREPROCESS_INITIAL_SYSTEM;
		  param->flags  |=PREPROCESS_SUBSYSTEMS;
		  param->flags  &=~FINAL_PIVOTING;
	       }
	       // no sensible string
	       else {
		  // custom settings from the user
	       }
	    }
	 }
	 // no sensible string
	 else {
	    // custom settings from the user
	 }
      }

      
      param->fpar[1]=param->droptol;
      param->fpar[8]=param->droptolS;
      param->fpar[2]=param->condest;
      param->ipar[0]=ceil(param->elbow);
      param->ipar[3]=param->lfil;
      param->ipar[9]=param->lfilS;
      
      // test vector
      if (param->typetv!=NULL && strlen(param->typetv)>0) {
 	 if (!strncmp("static",param->typetv,6)) {
	    param->flags  |=DIAGONAL_COMPENSATION|STATIC_TESTVECTOR; 
	 }
	 else if (strncmp("none",param->typetv,4)) {
	    param->flags  |=DIAGONAL_COMPENSATION|DYNAMIC_TESTVECTOR;
	 }
	 if (strncmp("none",param->typetv,4)) {
	    if (param->ntestvector==0) {
	       param->ntestvector=2*A->nc;
	       param->testvector=(FLOAT *)MALLOC((size_t)param->ntestvector*sizeof(FLOAT),
						 "AMGsetupparameters:param->testvector");
	    }
	    else {
	       param->ntestvector=MAX(2*A->nc,param->ntestvector);
	       param->testvector=(FLOAT *)REALLOC(param->testvector,
						  (size_t)param->ntestvector*sizeof(FLOAT),
						  "AMGsetupparameters:param->testvector");
	    }
	    memcpy(param->testvector, param->tv, A->nc*sizeof(FLOAT));
	 }
      }

      // capture the old style
      if (param->flags&DIAGONAL_COMPENSATION) {
	 if (param->ntestvector==0)
	    param->ntestvector=2*A->nc;
	 else
	    param->ntestvector=MAX(2*A->nc,param->ntestvector);

	 if (param->testvector==NULL)
	    param->testvector=(FLOAT *)MALLOC((size_t)param->ntestvector*sizeof(FLOAT),
					      "AMGsetupparameters:param->testvector");
	 else
	    param->testvector=(FLOAT *)REALLOC(param->testvector,
					       (size_t)param->ntestvector*sizeof(FLOAT),
					       "AMGsetupparameters:param->testvector");
	 // diagonal compensation in the classical sense using the 1-vector 
	 if (!(param->flags&STATIC_TESTVECTOR) && 
	     !(param->flags&DYNAMIC_TESTVECTOR)) {
	    for (i=0; i<A->nc; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
	        param->testvector[i]=1.0;
#else
		param->testvector[i].r=1.0;
		param->testvector[i].i=0.0;
#endif
	    } // end for
	 }
      }
      
      // type of coarse grid system
      if (param->typecoarse!=NULL && strlen(param->typecoarse)>0) {
	 if (!strncmp("ilu",param->typecoarse,3)) {
	    param->flags&=~TISMENETSKY_SC;
	    param->flags|=SIMPLE_SC;
	 }
	 else if (!strncmp("amg",param->typecoarse,3)) {
	    param->flags&=~TISMENETSKY_SC;
	    param->flags&=~SIMPLE_SC;
	 }
      }
            
      // type of multigrid
      if (strncmp("ilu",param->amg,3) && strncmp("amli",param->amg,4) && 
	  strncmp("mg",param->amg,2)) {
	 param->amg="ilu";
      }
      if (param->amg!=NULL && strlen(param->amg)>0) {
	 if (!strncmp("ilu",param->amg,3))
	    param->ipar[10]=0;
	 else if (!strncmp("amli",param->amg,4))
	    param->ipar[10]=1;
	 else if (!strncmp("mg",param->amg,2))
	    param->ipar[10]=2;
	 else {
	    param->amg="ilu";
	    param->ipar[10]=0;
	 }
      }


      // flags only used to set up the preconditioner
      param->ipar[6] =param->flags;
   }
   // env!=0
   // setup parameters that only affect the iterative part
   else {
      param->npresmoothing=MAX(param->npresmoothing,param->npostsmoothing);
      param->npostsmoothing=param->npresmoothing;
      param->ipar[12]=param->ipar[13]=param->npresmoothing;
      param->ipar[11]=param->ncoarse;
      param->fpar[20]=param->restol;
      param->ipar[24]=param->nrestart;
      param->ipar[25]=param->maxit;


      // pre- and post smoother (if used with "mg")
      if (param->presmoother!=NULL && strlen(param->presmoother)>0) {
	 if (!strncmp("gsf",param->presmoother,3)) {
	    param->ipar[14]=1; 
	    param->ipar[15]=2; 
	 }
	 else if (!strncmp("gsb",param->presmoother,3)) {
	    param->ipar[14]=2;
	    param->ipar[15]=1;
	 }
	 else if (!strncmp("j",param->presmoother,1)) {
	    param->ipar[14]=3;
	    param->ipar[15]=3;
	 }
	 else if (!strncmp("ilu",param->presmoother,3)) {
	    param->ipar[14]=4;
	    param->ipar[15]=4;
	 }
	 else {
	    param->ipar[14]=5;
	    param->ipar[15]=5;
	 }
      }


      // set up solver and prepare memory allocation for the 
      // iterative solver 
      i=param->ipar[24];
      if (!strncmp("sbcg",param->solver,4)) {
	 param->ipar[5]=2;
	 i=5*A->nr;
      }
      else if (!strncmp("bcg",param->solver,3)) {
	 param->ipar[5]=3;
	 i=7*A->nr;
      }
      else if (!strncmp("gmres",param->solver,5)) {
	 param->ipar[5]=8;
	 i=(A->nr+3)*(i+2)+(i+1)*i/2;
      }
      else if (!strncmp("fgmres",param->solver,6)) {
	 param->ipar[5]=9;
	 i=2*A->nr*(i+1)+((i+1)*i)/2 + 3*i + 2;
      }
      else {
	 param->solver="sqmr";
	 param->ipar[5]=4;
	 i=6*A->nr;
      } // end switch
      // memory required by the iterative method
      param->ipar[23]=i;

      // type of multigrid
      if (strncmp("ilu",param->amg,3) && strncmp("amli",param->amg,4) && 
	  strncmp("mg",param->amg,2)) {
	 param->amg="ilu";
      }
      if (param->amg!=NULL && strlen(param->amg)>0) {
         if (!strncmp("ilu",param->amg,3))
	    param->ipar[10]=0;
	 // note that in order to apply amli or mg the coarse grid
	 // systems had to be kept during the computation of the preconditioner
	 else if (!(param->ipar[16]&DISCARD_MATRIX)) {
	    if (!strncmp("amli",param->amg,4))
	       param->ipar[10]=1;
	    else if (!strncmp("mg",param->amg,2))
	       param->ipar[10]=2;
	    else {
	       param->amg="ilu";
	       param->ipar[10]=0;
	    }
	 }
	 else {
	    param->amg="ilu";
	    param->ipar[10]=0;
	 }
      }

   } // end else-if prec==0
} // end symAMGsetupparameters

