#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
#define _REAL_PREC_
#define _COMPLEX_SYMMETRIC_
#include "symAMGsolver.c"
#else
void myilupackdummy15()
{
}
#endif
