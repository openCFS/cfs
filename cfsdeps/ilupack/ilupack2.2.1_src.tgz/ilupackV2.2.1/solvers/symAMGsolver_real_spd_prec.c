#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
#define _SPD_PREC_
#define _REAL_PREC_
#include "symAMGsolver.c"
#else
void myilupackdummy17()
{
}
#endif
