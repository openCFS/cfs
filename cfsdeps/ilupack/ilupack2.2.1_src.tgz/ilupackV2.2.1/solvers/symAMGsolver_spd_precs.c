#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
#define _COMPLEX_SYMMETRIC_
#define _SPD_PREC_
#include "symAMGsolver.c"
#else
void myilupackdummy19()
{
}
#endif
