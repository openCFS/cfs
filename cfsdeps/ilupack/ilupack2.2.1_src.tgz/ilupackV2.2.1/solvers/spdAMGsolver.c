#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include <blas.h>
#include <ilupack.h>

#include <ilupackmacros.h>

#define STDERR          stdout
#define STDOUT          stdout
#define MAX(A,B)        (((A)>(B))?(A):(B))
#define MIN(A,B)        (((A)<(B))?(A):(B))


#define PRINT_INFO


// complex case with real preconditioner
#ifdef _REAL_PREC_

#ifdef _SINGLE_COMPLEX_
#define MYSPDAMGSOLVER           CHPDSSPDAMGsolver
#define MYSPDAMGSOL              SSPDAMGsol
#define MYAMGLEVELMAT            SAMGlevelmat
#define MYILUPACKPARAM           SILUPACKparam
#define MYSPDAMGSETUPPARAMETERS  SSPDAMGsetupparameters
#define MYCSRMAT                 Smat
#define MYFLOAT                  real
#define DUPLICATE                2
#else
#define MYSPDAMGSOLVER           ZHPDDSPDAMGsolver
#define MYSPDAMGSOL              DSPDAMGsol
#define MYAMGLEVELMAT            DAMGlevelmat
#define MYILUPACKPARAM           DILUPACKparam
#define MYSPDAMGSETUPPARAMETERS  DSPDAMGsetupparameters
#define MYFLOAT                  doubleprecision
#define MYCSRMAT                 Dmat
#define DUPLICATE                2
#endif

#else

#define MYSPDAMGSOLVER           SPDAMGSOLVER
#define MYSPDAMGSOL              SPDAMGSOL
#define MYAMGLEVELMAT            AMGLEVELMAT
#define MYILUPACKPARAM           ILUPACKPARAM
#define MYSPDAMGSETUPPARAMETERS  SPDAMGSETUPPARAMETERS
#define MYFLOAT                  FLOAT
#define MYCSRMAT                 CSRMAT
#define DUPLICATE                1

#endif





/*
 Solve Ax=b using the ILU computed by ILUPACK and an iterative solvers
 Default is GMRES
*/
integer MYSPDAMGSOLVER(CSRMAT *A, MYAMGLEVELMAT *PRE, MYILUPACKPARAM *IPparam,
		       FLOAT *rhs, FLOAT *sol)

{
   /*
      A          initial matrix stored in sparse row format

      PRE        AMG preconditioner
      nlev       number of levels 

      transpose  if the following bits are set: Bit 0:  A^T   instead of A   is 
                                                        stored  
                                                Bit 1:  CONJG(A) instead of A
                                                        is stored

                                                Bit 2:  solve A^Tx=b instead of
                                                        Ax=b  
                                                Bit 3:  solve CONJG(A)x=b
                                                        instead of Ax=b  

                 REMARK: Note that P is derived from A. So if A^T is stored
                         instead of A, it follows that P^T is stored instead of
                         P. Similar relations hold for CONJG(A)
						
      sol        initial solution, MUST be set on input (e.g. sol=(0,...,0)^T)
      rhs        right hand side

      nrestart   number of restart steps for GMRES
      max_it     maximum number of iteration steps
      restol     terminating tolerance for the residual

      *dbuff     buffers of size *ndbuff and *nibuff. If the buffer size is too
                 small
      *ibuff     new buffer is reallocated
      
      On entry
      ========
      All parameters need to be set

      On exit
      =======
      return code:         negative -> seperate GMRES error codes
                           positive -> number of iterations exceeded
			   0           success

      max_it               overwritten by the true number of iteration steps


      written by Matthias Bollhoefer, October 2006
   */




    float         systime, time_start,   time_stop,   secnds,
                  timeAx_start, timeAx_stop, secndsAx=0;
    integer       n=A->nr, i,j,k, flag, ierr=0, nAx=0, transa, transp, param,
                  sumn, nbf, nlev=PRE->nlev, *ia,*ja;
    FLOAT         *w,*a;
    MYFLOAT       *scale, *r,*c;
    MYCSRMAT      myA;
    MYAMGLEVELMAT *current=PRE;
    REALS         val,vb, conja, conjp;


    // start iterative solver
    evaluate_time(&time_start,&systime);


    // initially do scaling
    r=PRE->rowscal;
    c=PRE->colscal;
    // adjust arrays
    ia=A->ia;
    ja=A->ja;
    a =A->a;
    ja--;
    a--;
    c--;
    for (i=0; i<A->nr; i++) {
        for (j=ia[i]; j<ia[i+1]; j++) {
	    k=ja[j];
#if defined _SINGLE_REAL_ || defined _DOUBLE_REAL_
	    a[j]*=r[i]*c[k];
#else
#ifdef _REAL_PREC_
	    a[j].r*=r[i]*c[k];
	    a[j].i*=r[i]*c[k];
#else
	    a[j].r*=r[i].r*c[k].r;
	    a[j].i*=r[i].r*c[k].r;
#endif	  
#endif	  
	}
    }


    // set up parameters for the iterative part
    myA.nr=A->nr;
    myA.nc=A->nc;
    myA.ia=A->ia;
    myA.ja=A->ja;
    myA.a =NULL;
    MYSPDAMGSETUPPARAMETERS(&myA,IPparam,1);

    param=IPparam->ipar[6];
    // which matrix-vector multiplication is required
    // system          meaning flags bit 0,2
    // A   x=b  (Ax)                     0 0 
    // A^T x=b  (A^Tx)                   0 1 solve transposed system
    // A   y=b  (A^Tx)       A^T stored  1 0
    // A^T y=b  (Ax)         A^T stored  1 1 solve transposed system
    if (((IPparam->ipar[4]&1) && !(IPparam->ipar[4]&4)) || 
        ((IPparam->ipar[4]&4) && !(IPparam->ipar[4]&1))){
       // use A^Tx instead of Ax
       transa=1;
    } // end if
    else {
       transa=0;
    } // end else 

    // When do we need CONJG(A) instead of A
    // remember we use RIGHT preconditioning
    // system                meaning flags Bit 1,3
    // A        x=b                            0 0 
    // CONJG(A) x=b  (cjg)                     0 1 solve conjugated system
    //       A  x=b  (cjg)   CONJG(A) stored   1 0
    // CONJG(A) x=b          CONJG(A) stored   1 1 solve conjugated system
    if (((IPparam->ipar[4]&2) && !(IPparam->ipar[4]&8)) || 
        ((IPparam->ipar[4]&8) && !(IPparam->ipar[4]&2))){
       // use CONJG(A) instead of A
       conja=-1;
    } // end if
    else {
       conja=1;
    } // end else 


    // which preconditioner has to be applied
    // remember we use RIGHT preconditioning
    // system                meaning flags bit 0,2
    // A   P   y=b  (P,  rc)                   0 0 
    // A^T P^T y=b  (P^T,cr)                   0 1 solve transposed system
    // A   P^T y=b  (P^T,cr)    A^T is stored  1 0
    // A^T P   y=b  (P,  rc)    A^T is stored  1 1 solve transposed system
    if (((IPparam->ipar[4]&1) && !(IPparam->ipar[4]&4)) || 
        ((IPparam->ipar[4]&4) && !(IPparam->ipar[4]&1))){
       // use P^T instead of P
       transp=1;
    } // end if
    else {
       transp=0;
    } // end else 
    scale =PRE->colscal;

    // When do we need CONJG(P) instead of P
    // remember we use RIGHT preconditioning
    // system                           meaning flags Bit 1,3
    // A        P        y=b                              0 0 
    // CONJG(A) CONJG(P) y=b  (cjg)                       0 1 solve conjugated
    //                                                        system
    //       A  CONJG(P) y=b  (cjg)   CONJG(A) is stored  1 0
    // CONJG(A) P        y=b          CONJG(A) is stored  1 1 solve conjugated
    //                                                        system
    if (((IPparam->ipar[4]&2) && !(IPparam->ipar[4]&8)) || 
        ((IPparam->ipar[4]&8) && !(IPparam->ipar[4]&2))){
       // use CONJG(P) instead of P
       conjp=-1;
    } // end if
    else {
       conjp=1;
    } // end else 

#ifdef PRINT_INFO
    switch (IPparam->ipar[5]) {
    case  2:   /* sbcg */
      printf("use SBCG as iterative solver\n");
      break;
    case  3:   /* bcg */
      printf("use SBCG as iterative solver\n");
      break;
    case  4:   /* sqmr */
      printf("use SQMR as iterative solver\n");
      break;
    case  8:   /* gmres */
      printf("use GMRES(%d) as iterative solver\n",IPparam->ipar[24]);
      break;
    case  9: 
      printf("use fGMRES(%d) as iterative solver\n",IPparam->ipar[24]);
      break;
    case 21:   // fpcg
      printf("use fCG(%d) as iterative solver\n",IPparam->ipar[24]);
      break;
    default:   /* pcg */
      printf("use CG as iterative solver\n");
      break;
    }
#endif

    // 3n words are required by spdAMGsol, 2n+2*sum_lev nB for spdAMGsol1,2
    nbf=0;
    if (IPparam->ipar[10]==2) 
       nbf=2*n;
    if (IPparam->ipar[10]!=0) {
       sumn=0;
       for (i=1; i<=nlev; i++) {
	   sumn+=current->nB;
	   nbf+=2*(n-sumn);
	   current=current->next;
       } // end for i
       if (IPparam->ipar[10]==2) nbf+=n;
    }
    nbf=2*n+MAX(n,nbf);

#ifdef PRINT_MEM
    printf("dbuffmem=%8.2lfMB\n",IPparam->ndbuff/DMEGA);fflush(stdout);
#endif
    if (IPparam->ndbuff==0) {
       IPparam->ndbuff=DUPLICATE*((size_t)IPparam->ipar[23]+(size_t)nbf+2*(size_t)n);
       IPparam->dbuff=(MYFLOAT *) MALLOC(IPparam->ndbuff*sizeof(MYFLOAT),
					 "spdAMGsolver:dbuff");
#ifdef PRINT_MEM
       printf("dbuff(%8.2lfMB) allocated\n",IPparam->ndbuff/DMEGA);fflush(stdout);
#endif
    }
    else if (DUPLICATE*((size_t)IPparam->ipar[23]+(size_t)nbf+2*(size_t)n)>IPparam->ndbuff) {
       IPparam->ndbuff=DUPLICATE*((size_t)IPparam->ipar[23]+(size_t)nbf+2*(size_t)n);
       IPparam->dbuff=(MYFLOAT *)REALLOC(IPparam->dbuff,
					 IPparam->ndbuff*sizeof(MYFLOAT),
					 "spdAMGsolver:dbuff");
#ifdef PRINT_MEM
       printf("dbuff(%8.2lfMB) re-allocated\n",IPparam->ndbuff/DMEGA);fflush(stdout);
#endif
    }
    w=((FLOAT*)IPparam->dbuff) + (size_t)nbf;


    // rescale solution and right hand side 
    for (i=0; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
        sol[i]/=scale[i];
        rhs[i]*=scale[i];
#else

#ifdef _REAL_PREC_
        sol[i].r/=scale[i];
        sol[i].i/=scale[i];
        rhs[i].r*=scale[i];
        rhs[i].i*=scale[i];
#else
	val=1.0/(scale[i].r*scale[i].r +
  	         scale[i].i*scale[i].i);
	vb=sol[i].r;
	sol[i].r=( vb*      scale[i].r+sol[i].i*conjp*scale[i].i)*val;
	sol[i].i=(-vb*conjp*scale[i].i+sol[i].i      *scale[i].r)*val;
	vb=rhs[i].r;
	rhs[i].r=vb*      scale[i].r-rhs[i].i*conjp*scale[i].i;
	rhs[i].i=vb*conjp*scale[i].i+rhs[i].i*      scale[i].r;
#endif

#endif
    } // end for i

    // init output parameters for SPARSKIT
    IPparam->ipar[20]=0;
    // init with zeros
    IPparam->ipar[26]=
      IPparam->ipar[27]=
      IPparam->ipar[28]=
      IPparam->ipar[29]=
      IPparam->ipar[30]=
      IPparam->ipar[31]=
      IPparam->ipar[32]=
      IPparam->ipar[35]=0;
    // init with zeros 
    IPparam->fpar[22]=
      IPparam->fpar[23]=
      IPparam->fpar[24]=
      IPparam->fpar[25]=
      IPparam->fpar[26]=
      IPparam->fpar[27]=
      IPparam->fpar[28]=
      IPparam->fpar[29]=
      IPparam->fpar[30]=
      IPparam->fpar[31]=
      IPparam->fpar[32]=
      IPparam->fpar[33]=
      IPparam->fpar[34]=
      IPparam->fpar[35]=0;


    flag=-1;
    while (flag) {
          // which solver do we use?
	  switch (IPparam->ipar[5]) {
	  case  1:   // pcg 
	    PCG(&n,rhs,sol,IPparam->ipar+20,IPparam->fpar+20,w);
	    break;
	  case  2:   // sbcg
	    SBCG(&n,rhs,sol,IPparam->ipar+20,IPparam->fpar+20,w);
	    break;
	  case  3:   // bcg 
	    BCG(&n,rhs,sol,IPparam->ipar+20,IPparam->fpar+20,w);
	    break;
	  case  4:   // sqmr 
	    SQMR(&n,rhs,sol,IPparam->ipar+20,IPparam->fpar+20,w);
	    i=6*A->nr;
	    break;
	  case  5:   // bcgstab 
	    break;
	  case  6:   // tfqmr 
	    break;
	  case  7:   // fom 
	    break;
	  case  8:   // gmres 
	    GMRES(&n,rhs,sol,IPparam->ipar+20,IPparam->fpar+20,w);
	    break;
	  case  9:   // fgmres 
	    FGMRES(&n,rhs,sol,IPparam->ipar+20,IPparam->fpar+20,w);
	    break;
	  case 10:   // dqgmres 
	    break;
	  case 21:   // fpcg
	    FPCG(&n,rhs,sol,IPparam->ipar+20,IPparam->fpar+20,w);
	    break;
	  } // end switch 

	  // what is required by the solver?
	  w--;
	  switch (IPparam->ipar[20]) {
	  case  1:   // apply matrix vector multiplication
	        evaluate_time(&timeAx_start,&systime);
		nAx++;

#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
		// if CONJG(A) is requested y=CONJG(A)*x <=> y=CONJG(A*CONJG(x))
		if (conja<0) {
		   w+=IPparam->ipar[27];
		   for (i=0; i<n; i++)
		       w[i].i=-w[i].i;
		   w-=IPparam->ipar[27];
		} // end if
#endif
		// if A^T is needed
		if (transa)
		   HERMATVEC(*A,w+IPparam->ipar[27],w+IPparam->ipar[28]);
		else
		   HERMATVEC(*A,w+IPparam->ipar[27],w+IPparam->ipar[28]);
#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
		// if CONJG(A) is requested
		if (conja<0) {
		   w+=IPparam->ipar[28];
		   for (i=0; i<n; i++)
		       w[i].i=-w[i].i;
		   w-=IPparam->ipar[28];
		} // end if
#endif

	        evaluate_time(&timeAx_stop,&systime);
		secndsAx+=timeAx_stop-timeAx_start;
		break;
	  case  2:   // apply transposed matrix vector multiplication
	        evaluate_time(&timeAx_start,&systime);
		nAx++;

#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
		// if CONJG(A) is requested y=CONJG(A)*x <=> y=CONJG(A*CONJG(x))
		if (conja<0) {
		   w+=IPparam->ipar[27];
		   for (i=0; i<n; i++)
		       w[i].i=-w[i].i;
		   w-=IPparam->ipar[27];
		} // end if
#endif
		// if A^T is needed
		if (transa)
		   HERMATVEC(*A,w+IPparam->ipar[27],w+IPparam->ipar[28]);
		else
		   HERMATVEC(*A,w+IPparam->ipar[27],w+IPparam->ipar[28]);
#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
		// if CONJG(A) is requested
		if (conja<0) {
		   w+=IPparam->ipar[28];
		   for (i=0; i<n; i++)
		       w[i].i=-w[i].i;
		   w-=IPparam->ipar[28];
		} // end if
#endif

	        evaluate_time(&timeAx_stop,&systime);
		secndsAx+=timeAx_stop-timeAx_start;
		break;
	  case  3:   // left preconditioner
		if (IPparam->ipar[21]==1) {
#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
		  // if CONJG(P) is requested y=CONJG(P)*x <=> y=CONJG(P*CONJG(x))
		  if (conjp<0) {
		     w+=IPparam->ipar[27];
		     for (i=0; i<n; i++)
		         w[i].i=-w[i].i;
		     w-=IPparam->ipar[27];
		  } // end if
#endif
		  // if P^T is needed
		  if (transp) {
#ifdef _REAL_PREC_
		     // real preconditioner has to be applied twice
		     for (i=0; i<n; i++)
		         IPparam->dbuff[nbf+i]=w[IPparam->ipar[27]+i].r;
		     MYSPDAMGSOL(PRE, IPparam, IPparam->dbuff+nbf,
				 IPparam->dbuff+nbf+n, IPparam->dbuff);
		     for (i=0; i<n; i++)
		         w[IPparam->ipar[28]+i].r=IPparam->dbuff[nbf+n+i];

		     for (i=0; i<n; i++)
		         IPparam->dbuff[nbf+i]=w[IPparam->ipar[27]+i].i;
		     MYSPDAMGSOL(PRE, IPparam, IPparam->dbuff+nbf,
				 IPparam->dbuff+nbf+n, IPparam->dbuff);
		     for (i=0; i<n; i++)
		         w[IPparam->ipar[28]+i].i=IPparam->dbuff[nbf+n+i];
#else
		     MYSPDAMGSOL(PRE, IPparam, w+IPparam->ipar[27],w+IPparam->ipar[28], IPparam->dbuff);
#endif
		  }
		  else {
#ifdef _REAL_PREC_
		     // real preconditioner has to be applied twice
		     for (i=0; i<n; i++)
		         IPparam->dbuff[nbf+i]=w[IPparam->ipar[27]+i].r;
		     MYSPDAMGSOL(PRE, IPparam, IPparam->dbuff+nbf,
				 IPparam->dbuff+nbf+n, IPparam->dbuff);
		     for (i=0; i<n; i++)
		         w[IPparam->ipar[28]+i].r=IPparam->dbuff[nbf+n+i];

		     for (i=0; i<n; i++)
		         IPparam->dbuff[nbf+i]=w[IPparam->ipar[27]+i].i;
		     MYSPDAMGSOL(PRE, IPparam, IPparam->dbuff+nbf,
				 IPparam->dbuff+nbf+n, IPparam->dbuff);
		     for (i=0; i<n; i++)
		         w[IPparam->ipar[28]+i].i=IPparam->dbuff[nbf+n+i];
#else
		     MYSPDAMGSOL(PRE, IPparam, w+IPparam->ipar[27],w+IPparam->ipar[28], IPparam->dbuff);
#endif
		  }
#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
		  // if CONJG(P) is requested
		  if (conjp<0) {
		     w+=IPparam->ipar[28];
		     for (i=0; i<n; i++)
		         w[i].i=-w[i].i;
		     w-=IPparam->ipar[28];
		  } // end if
#endif
		} // end if 
		else {
		   i=1;
		   COPY(&n,w+IPparam->ipar[27],&i,w+IPparam->ipar[28],&i);
		} // end else
		break;
	  case  4:   // left preconditioner transposed 
	        if (IPparam->ipar[21]==1) {
#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
		   // if CONJG(P) is requested y=CONJG(P)*x <=> y=CONJG(P*CONJG(x))
		   if (conjp<0) {
		      w+=IPparam->ipar[27];
		      for (i=0; i<n; i++)
		          w[i].i=-w[i].i;
		      w-=IPparam->ipar[27];
		   } // end if
#endif
		   // if P^T is needed
		   if (transp) {
#ifdef _REAL_PREC_
		      // real preconditioner has to be applied twice
		      for (i=0; i<n; i++)
			  IPparam->dbuff[nbf+i]=w[IPparam->ipar[27]+i].r;
		      MYSPDAMGSOL(PRE, IPparam, IPparam->dbuff+nbf,
				  IPparam->dbuff+nbf+n, IPparam->dbuff);
		      for (i=0; i<n; i++)
			  w[IPparam->ipar[28]+i].r=IPparam->dbuff[nbf+n+i];

		      for (i=0; i<n; i++)
		          IPparam->dbuff[nbf+i]=w[IPparam->ipar[27]+i].i;
		      MYSPDAMGSOL(PRE, IPparam, IPparam->dbuff+nbf,
				  IPparam->dbuff+nbf+n, IPparam->dbuff);
		      for (i=0; i<n; i++)
		          w[IPparam->ipar[28]+i].i=IPparam->dbuff[nbf+n+i];
#else
		      MYSPDAMGSOL(PRE, IPparam, w+IPparam->ipar[27],w+IPparam->ipar[28], IPparam->dbuff);
#endif
		   }
		   else {
#ifdef _REAL_PREC_
		      // real preconditioner has to be applied twice
		      for (i=0; i<n; i++)
			  IPparam->dbuff[nbf+i]=w[IPparam->ipar[27]+i].r;
		      MYSPDAMGSOL(PRE, IPparam, IPparam->dbuff+nbf,
				  IPparam->dbuff+nbf+n, IPparam->dbuff);
		      for (i=0; i<n; i++)
		          w[IPparam->ipar[28]+i].r=IPparam->dbuff[nbf+n+i];

		      for (i=0; i<n; i++)
			  IPparam->dbuff[nbf+i]=w[IPparam->ipar[27]+i].i;
		      MYSPDAMGSOL(PRE, IPparam, IPparam->dbuff+nbf,
				  IPparam->dbuff+nbf+n, IPparam->dbuff);
		      for (i=0; i<n; i++)
		          w[IPparam->ipar[28]+i].i=IPparam->dbuff[nbf+n+i];
#else
		      MYSPDAMGSOL(PRE, IPparam, w+IPparam->ipar[27],w+IPparam->ipar[28], IPparam->dbuff);
#endif
		   }
#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
		   // if CONJG(P) is requested
		   if (conjp<0) {
		      w+=IPparam->ipar[28];
		      for (i=0; i<n; i++)
		          w[i].i=-w[i].i;
		      w-=IPparam->ipar[28];
		   } // end if
#endif
		} // end if
		else {
		   i=1;
		   COPY(&n,w+IPparam->ipar[27],&i,w+IPparam->ipar[28],&i);
		} // end else
		break;
	  case  5:   // right preconditioner
		if (IPparam->ipar[21]==2) {
#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
		   // if CONJG(P) is requested y=CONJG(P)*x <=> y=CONJG(P*CONJG(x))
		   if (conjp<0) {
		      w+=IPparam->ipar[27];
		      for (i=0; i<n; i++)
		          w[i].i=-w[i].i;
		      w-=IPparam->ipar[27];
		   } // end if
#endif
		   // if P^T is needed
		   if (transp) {
#ifdef _REAL_PREC_
		      // real preconditioner has to be applied twice
		      for (i=0; i<n; i++)
		          IPparam->dbuff[nbf+i]=w[IPparam->ipar[27]+i].r;
		      MYSPDAMGSOL(PRE, IPparam, IPparam->dbuff+nbf,
				  IPparam->dbuff+nbf+n, IPparam->dbuff);
		      for (i=0; i<n; i++)
		          w[IPparam->ipar[28]+i].r=IPparam->dbuff[nbf+n+i];

		      for (i=0; i<n; i++)
		          IPparam->dbuff[nbf+i]=w[IPparam->ipar[27]+i].i;
		      MYSPDAMGSOL(PRE, IPparam, IPparam->dbuff+nbf,
				  IPparam->dbuff+nbf+n, IPparam->dbuff);
		      for (i=0; i<n; i++)
		          w[IPparam->ipar[28]+i].i=IPparam->dbuff[nbf+n+i];
#else
		      MYSPDAMGSOL(PRE, IPparam, w+IPparam->ipar[27],w+IPparam->ipar[28], IPparam->dbuff);
#endif
		   }
		   else {
#ifdef _REAL_PREC_
		      // real preconditioner has to be applied twice
		      for (i=0; i<n; i++)
			  IPparam->dbuff[nbf+i]=w[IPparam->ipar[27]+i].r;
		      MYSPDAMGSOL(PRE, IPparam, IPparam->dbuff+nbf,
				  IPparam->dbuff+nbf+n, IPparam->dbuff);
		      for (i=0; i<n; i++)
			  w[IPparam->ipar[28]+i].r=IPparam->dbuff[nbf+n+i];

		      for (i=0; i<n; i++)
		          IPparam->dbuff[nbf+i]=w[IPparam->ipar[27]+i].i;
		      MYSPDAMGSOL(PRE, IPparam, IPparam->dbuff+nbf,
				  IPparam->dbuff+nbf+n, IPparam->dbuff);
		      for (i=0; i<n; i++)
		          w[IPparam->ipar[28]+i].i=IPparam->dbuff[nbf+n+i];
#else
		      MYSPDAMGSOL(PRE, IPparam, w+IPparam->ipar[27],w+IPparam->ipar[28], IPparam->dbuff);
#endif
		   }
#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
		   // if CONJG(P) is requested
		   if (conjp<0) {
		      w+=IPparam->ipar[28];
		      for (i=0; i<n; i++)
		          w[i].i=-w[i].i;
		      w-=IPparam->ipar[28];
		   } // end if
#endif
		} // end if
		else {
		   i=1;
		   COPY(&n,w+IPparam->ipar[27],&i,w+IPparam->ipar[28],&i);
		} // end else
		break;
	  case  6:   //  right preconditioner transposed
		if (IPparam->ipar[21]==2) {
#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
		   // if CONJG(P) is requested y=CONJG(P)*x <=> y=CONJG(P*CONJG(x))
		   if (conjp<0) {
		      w+=IPparam->ipar[27];
		      for (i=0; i<n; i++)
		          w[i].i=-w[i].i;
		      w-=IPparam->ipar[27];
		   } // end if
#endif
		   // if P^T is needed
		   if (transp) {
#ifdef _REAL_PREC_
		      // real preconditioner has to be applied twice
		      for (i=0; i<n; i++)
			  IPparam->dbuff[nbf+i]=w[IPparam->ipar[27]+i].r;
		      MYSPDAMGSOL(PRE, IPparam, IPparam->dbuff+nbf,
				  IPparam->dbuff+nbf+n, IPparam->dbuff);
		      for (i=0; i<n; i++)
			  w[IPparam->ipar[28]+i].r=IPparam->dbuff[nbf+n+i];

		      for (i=0; i<n; i++)
			  IPparam->dbuff[nbf+i]=w[IPparam->ipar[27]+i].i;
		      MYSPDAMGSOL(PRE, IPparam, IPparam->dbuff+nbf,
				  IPparam->dbuff+nbf+n, IPparam->dbuff);
		      for (i=0; i<n; i++)
		          w[IPparam->ipar[28]+i].i=IPparam->dbuff[nbf+n+i];
#else
		      MYSPDAMGSOL(PRE, IPparam, w+IPparam->ipar[27],w+IPparam->ipar[28], IPparam->dbuff);
#endif
		   }
		   else {
#ifdef _REAL_PREC_
		      // real preconditioner has to be applied twice
		      for (i=0; i<n; i++)
			  IPparam->dbuff[nbf+i]=w[IPparam->ipar[27]+i].r;
		      MYSPDAMGSOL(PRE, IPparam, IPparam->dbuff+nbf,
				  IPparam->dbuff+nbf+n, IPparam->dbuff);
		      for (i=0; i<n; i++)
			  w[IPparam->ipar[28]+i].r=IPparam->dbuff[nbf+n+i];

		      for (i=0; i<n; i++)
			  IPparam->dbuff[nbf+i]=w[IPparam->ipar[27]+i].i;
		      MYSPDAMGSOL(PRE, IPparam, IPparam->dbuff+nbf,
				  IPparam->dbuff+nbf+n, IPparam->dbuff);
		      for (i=0; i<n; i++)
		          w[IPparam->ipar[28]+i].i=IPparam->dbuff[nbf+n+i];
#else
		      MYSPDAMGSOL(PRE, IPparam, w+IPparam->ipar[27],w+IPparam->ipar[28], IPparam->dbuff);
#endif
		   }
#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
		   // if CONJG(P) is requested
		   if (conjp<0) {
		      w+=IPparam->ipar[28];
		      for (i=0; i<n; i++)
		          w[i].i=-w[i].i;
		      w-=IPparam->ipar[28];
		   } // end if
#endif
		} // end if
		else {
		   i=1;
		   COPY(&n,w+IPparam->ipar[27],&i,w+IPparam->ipar[28],&i);
		} // end else
		break;
	  case 10:   // call my own stopping test routine
	        break;
	  default:   // the iterative solver terminated with code=IPparam->ipar[20]
	        ierr=IPparam->ipar[20];
	        flag=0;
		break;
	  } // end switch
	  w++;
    } // end while
    // rescale solution and right hand side 
    for (i=0; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
        sol[i]*=scale[i];
        rhs[i]/=scale[i];
#else
#ifdef _REAL_PREC_
        sol[i].r*=scale[i];
        sol[i].i*=scale[i];
        rhs[i].r/=scale[i];
        rhs[i].i/=scale[i];
#else
	vb=sol[i].r;
	sol[i].r=vb*      scale[i].r-sol[i].i*conjp*scale[i].i;
	sol[i].i=vb*conjp*scale[i].i+sol[i].i*      scale[i].r;
	val=1.0/(scale[i].r*scale[i].r +
  	         scale[i].i*scale[i].i);
	vb=rhs[i].r;
	rhs[i].r=( vb*      scale[i].r+rhs[i].i*conjp*scale[i].i)*val;
	rhs[i].i=(-vb*conjp*scale[i].i+rhs[i].i*      scale[i].r)*val;
#endif
#endif
    } // end for i
    evaluate_time(&time_stop,&systime);

    // iteration time
    ILUPACK_secnds[5]=time_stop-time_start;
    // compute TOTAL time
    ILUPACK_secnds[8]=time_stop-ILUPACK_secnds[8];
    // average time for matrix-vector multiplication
    ILUPACK_secnds[6]=secndsAx/((double)nAx);


    // finally undo scaling
    r=PRE->rowscal;
    c=PRE->colscal;
    // adjust arrays
    ia=A->ia;
    ja=A->ja;
    a =A->a;
    ja--;
    a--;
    c--;
    for (i=0; i<A->nr; i++) {
        for (j=ia[i]; j<ia[i+1]; j++) {
	    k=ja[j];
#if defined _SINGLE_REAL_ || defined _DOUBLE_REAL_
	    a[j]/=r[i]*c[k];
#else
#ifdef _REAL_PREC_
	    a[j].r/=r[i]*c[k];
	    a[j].i/=r[i]*c[k];
#else
	    a[j].r/=r[i].r*c[k].r;
	    a[j].i/=r[i].r*c[k].r;
#endif	  
#endif	  
	}
    }
    return (ierr);

} // end spdAMGsolver

