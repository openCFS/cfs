#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
#define _REAL_PREC_
#define _SPD_PREC_
#include "AMGsolver.c"
#else
void myilupackdummy52()
{
}
#endif
