#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
#define _COMPLEX_SYMMETRIC_
#define _SYM_PREC_
#include "AMGsolver.c"
#else
void myilupackdummy54()
{
}
#endif
