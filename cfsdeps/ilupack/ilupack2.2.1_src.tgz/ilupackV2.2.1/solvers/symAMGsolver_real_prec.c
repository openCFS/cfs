#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
#define _REAL_PREC_
#include "symAMGsolver.c"
#else
void myilupackdummy14()
{
}
#endif
