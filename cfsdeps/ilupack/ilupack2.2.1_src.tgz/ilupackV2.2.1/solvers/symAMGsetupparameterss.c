#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
#define _COMPLEX_SYMMETRIC_
#include "symAMGsetupparameters.c"
#else
void myilupackdummy205()
{
}
#endif
