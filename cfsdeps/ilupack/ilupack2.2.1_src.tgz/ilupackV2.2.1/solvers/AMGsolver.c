#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include <blas.h>
#include <ilupack.h> 

#include <ilupackmacros.h>

//#define PRINT_MEM
#define MEGA      1048576.0
#define IMEGA      262144.0
#define DMEGA      131072.0

#define STDERR          stdout
#define STDOUT          stdout
#define MAX(A,B)        (((A)>(B))?(A):(B))
#define MIN(A,B)        (((A)<(B))?(A):(B))



//#define PRINT_INFO



// complex case with real preconditioner
#ifdef _REAL_PREC_

// single precision
#if defined _SINGLE_COMPLEX_

// SPD preconditioner
#ifdef _SPD_PREC_
#define MYAMGSOLVER     CGNLSSPDAMGsolver
#define MYAMGSOL        SSPDAMGsol
#define MYAMGTSOL       SSPDAMGsol
#define MYAMGLSOL       SSPDAMGsol
#define MYAMGTLSOL      SSPDAMGsol
#define MYAMGUSOL       SSPDAMGsol
#define MYAMGTUSOL      SSPDAMGsol
#define MYAMGTDUSOL     SSPDAMGsol
#define MYAMGTDLSOL     SSPDAMGsol
#define MYAMGDUSOL      SSPDAMGsol
#define MYAMGDLSOL      SSPDAMGsol

// complex case with real prec. + single precision + non SPD
// if-else _SPD_PREC_
#else

// symmetric prec.
#ifdef _SYM_PREC_
#define MYAMGSOLVER     CGNLSSYMAMGsolver
#define MYAMGSOL        SSYMAMGsol
#define MYAMGTSOL       SSYMAMGsol
#define MYAMGLSOL       SSYMAMGsol
#define MYAMGTLSOL      SSYMAMGsol
#define MYAMGUSOL       SSYMAMGsol
#define MYAMGTUSOL      SSYMAMGsol
#define MYAMGTDUSOL     SSYMAMGsol
#define MYAMGTDLSOL     SSYMAMGsol
#define MYAMGDUSOL      SSYMAMGsol
#define MYAMGDLSOL      SSYMAMGsol

// complex case with real prec. + single precision + non SPD/non SYM
// if-else _SYM_PREC_
#else
#define MYAMGSOLVER     CGNLSGNLAMGsolver
#define MYAMGSOL        SGNLAMGsol
#define MYAMGTSOL       SGNLAMGtsol
#define MYAMGLSOL       SGNLAMGlsol
#define MYAMGTLSOL      SGNLAMGtlsol
#define MYAMGUSOL       SGNLAMGusol
#define MYAMGTUSOL      SGNLAMGtusol
#define MYAMGTDUSOL     SGNLAMGtdusol
#define MYAMGTDLSOL     SGNLAMGtdlsol
#define MYAMGDUSOL      SGNLAMGdusol
#define MYAMGDLSOL      SGNLAMGdlsol
#endif
// end _SYM_PREC_

#endif
// end _SPD_PREC_

#define MYAMGLEVELMAT         SAMGlevelmat
#define MYILUPACKPARAM        SILUPACKparam
#define MYAMGSETUPPARAMETERS  SGNLAMGsetupparameters
#define MYFLOAT               real
#define MYCSRMAT              Smat
#define DUPLICATE             2

// complex case with real prec. + double precision
// if-else _SINGLE_COMPLEX_
#else

// complex case with real prec. + double precision + SPD prec.
#ifdef _SPD_PREC_
#define MYAMGSOLVER     ZGNLDSPDAMGsolver
#define MYAMGSOL        DSPDAMGsol
#define MYAMGTSOL       DSPDAMGsol
#define MYAMGLSOL       DSPDAMGsol
#define MYAMGTLSOL      DSPDAMGsol
#define MYAMGUSOL       DSPDAMGsol
#define MYAMGTUSOL      DSPDAMGsol
#define MYAMGTDUSOL     DSPDAMGsol
#define MYAMGTDLSOL     DSPDAMGsol
#define MYAMGDUSOL      DSPDAMGsol
#define MYAMGDLSOL      DSPDAMGsol

// complex case with real prec. + double precision + non SPD prec.
// if-else _SPD_PREC_
#else

// complex case with real prec. + double precision + SYM prec.
#ifdef _SYM_PREC_
#define MYAMGSOLVER     ZGNLDSYMAMGsolver
#define MYAMGSOL        DSYMAMGsol
#define MYAMGTSOL       DSYMAMGsol
#define MYAMGLSOL       DSYMAMGsol
#define MYAMGTLSOL      DSYMAMGsol
#define MYAMGUSOL       DSYMAMGsol
#define MYAMGTUSOL      DSYMAMGsol
#define MYAMGTDUSOL     DSYMAMGsol
#define MYAMGTDLSOL     DSYMAMGsol
#define MYAMGDUSOL      DSYMAMGsol
#define MYAMGDLSOL      DSYMAMGsol

// complex case with real prec. + double precision + non SPD/SYM prec.
// if-else _SYM_PREC_
#else
#define MYAMGSOLVER     ZGNLDGNLAMGsolver
#define MYAMGSOL        DGNLAMGsol
#define MYAMGTSOL       DGNLAMGtsol
#define MYAMGLSOL       DGNLAMGlsol
#define MYAMGTLSOL      DGNLAMGtlsol
#define MYAMGUSOL       DGNLAMGusol
#define MYAMGTUSOL      DGNLAMGtusol
#define MYAMGTDUSOL     DGNLAMGtdusol
#define MYAMGTDLSOL     DGNLAMGtdlsol
#define MYAMGDUSOL      DGNLAMGdusol
#define MYAMGDLSOL      DGNLAMGdlsol
#endif
// end _SYM_PREC_

#endif
// end _SPD_PREC_

#define MYAMGLEVELMAT         DAMGlevelmat
#define MYILUPACKPARAM        DILUPACKparam
#define MYFLOAT               doubleprecision
#define MYCSRMAT              Dmat
#define MYAMGSETUPPARAMETERS  DGNLAMGsetupparameters
#define DUPLICATE             2
#endif
// end _SINGLE_COMPLEX_

// general case with prec. of same precision S/D/C/Z
// if-else _REAL_PREC_
#else

#ifdef _SPD_PREC_

#ifdef _SINGLE_REAL_
#define MYAMGSOLVER     SGNLSPDAMGsolver
#define MYAMGSOL        SSPDAMGsol
#define MYAMGTSOL       SSPDAMGsol
#define MYAMGLSOL       SSPDAMGsol
#define MYAMGTLSOL      SSPDAMGsol
#define MYAMGUSOL       SSPDAMGsol
#define MYAMGTUSOL      SSPDAMGsol
#define MYAMGTDUSOL     SSPDAMGsol
#define MYAMGTDLSOL     SSPDAMGsol
#define MYAMGDUSOL      SSPDAMGsol
#define MYAMGDLSOL      SSPDAMGsol

// D/C/Z
// if-else _SINGLE_REAL_
#else

#ifdef _DOUBLE_REAL_
#define MYAMGSOLVER     DGNLSPDAMGsolver
#define MYAMGSOL        DSPDAMGsol
#define MYAMGTSOL       DSPDAMGsol
#define MYAMGLSOL       DSPDAMGsol
#define MYAMGTLSOL      DSPDAMGsol
#define MYAMGUSOL       DSPDAMGsol
#define MYAMGTUSOL      DSPDAMGsol
#define MYAMGTDUSOL     DSPDAMGsol
#define MYAMGTDLSOL     DSPDAMGsol
#define MYAMGDUSOL      DSPDAMGsol
#define MYAMGDLSOL      DSPDAMGsol

// C/Z
// if-else _DOUBLE_REAL_
#else

#ifdef _SINGLE_COMPLEX_
#define MYAMGSOLVER     CGNLHPDAMGsolver
#define MYAMGSOL        CHPDAMGsol
#define MYAMGTSOL       CHPDAMGsol
#define MYAMGLSOL       CHPDAMGsol
#define MYAMGTLSOL      CHPDAMGsol
#define MYAMGUSOL       CHPDAMGsol
#define MYAMGTUSOL      CHPDAMGsol
#define MYAMGTDUSOL     CHPDAMGsol
#define MYAMGTDLSOL     CHPDAMGsol
#define MYAMGDUSOL      CHPDAMGsol
#define MYAMGDLSOL      CHPDAMGsol

// Z
// if-else _SINGLE_COMPLEX_
#else
#define MYAMGSOLVER     ZGNLHPDAMGsolver
#define MYAMGSOL        ZHPDAMGsol
#define MYAMGTSOL       ZHPDAMGsol
#define MYAMGLSOL       ZHPDAMGsol
#define MYAMGTLSOL      ZHPDAMGsol
#define MYAMGUSOL       ZHPDAMGsol
#define MYAMGTUSOL      ZHPDAMGsol
#define MYAMGTDUSOL     ZHPDAMGsol
#define MYAMGTDLSOL     ZHPDAMGsol
#define MYAMGDUSOL      ZHPDAMGsol
#define MYAMGDLSOL      ZHPDAMGsol
#endif
// end _SINGLE_COMPLEX_

#endif
// end _DOUBLE_REAL_

#endif
// end _SINGLE_REAL_

// general case with non-SPD prec. of same precision S/D/C/Z
// if-else _SPD_PREC_
#else

#ifdef _SYM_PREC_

#ifdef _SINGLE_REAL_
#define MYAMGSOLVER     SGNLSYMAMGsolver
#define MYAMGSOL        SSYMAMGsol
#define MYAMGTSOL       SSYMAMGsol
#define MYAMGLSOL       SSYMAMGsol
#define MYAMGTLSOL      SSYMAMGsol
#define MYAMGUSOL       SSYMAMGsol
#define MYAMGTUSOL      SSYMAMGsol
#define MYAMGTDUSOL     SSYMAMGsol
#define MYAMGTDLSOL     SSYMAMGsol
#define MYAMGDUSOL      SSYMAMGsol
#define MYAMGDLSOL      SSYMAMGsol

// D/C/Z
// if-else _SINGLE_REAL_
#else

#ifdef _DOUBLE_REAL_
#define MYAMGSOLVER     DGNLSYMAMGsolver
#define MYAMGSOL        DSYMAMGsol
#define MYAMGTSOL       DSYMAMGsol
#define MYAMGLSOL       DSYMAMGsol
#define MYAMGTLSOL      DSYMAMGsol
#define MYAMGUSOL       DSYMAMGsol
#define MYAMGTUSOL      DSYMAMGsol
#define MYAMGTDUSOL     DSYMAMGsol
#define MYAMGTDLSOL     DSYMAMGsol
#define MYAMGDUSOL      DSYMAMGsol
#define MYAMGDLSOL      DSYMAMGsol

// C/Z
// if-else _DOUBLE_REAL_
#else

#ifdef _SINGLE_COMPLEX_

#ifdef _COMPLEX_SYMMETRIC_
#define MYAMGSOLVER     CGNLSYMAMGsolver
#define MYAMGSOL        CSYMAMGsol
#define MYAMGTSOL       CSYMAMGsol
#define MYAMGLSOL       CSYMAMGsol
#define MYAMGTLSOL      CSYMAMGsol
#define MYAMGUSOL       CSYMAMGsol
#define MYAMGTUSOL      CSYMAMGsol
#define MYAMGTDUSOL     CSYMAMGsol
#define MYAMGTDLSOL     CSYMAMGsol
#define MYAMGDUSOL      CSYMAMGsol
#define MYAMGDLSOL      CSYMAMGsol

// if-else _COMPLEX_SYMMETRIC_
#else
#define MYAMGSOLVER     CGNLHERAMGsolver
#define MYAMGSOL        CHERAMGsol
#define MYAMGTSOL       CHERAMGsol
#define MYAMGLSOL       CHERAMGsol
#define MYAMGTLSOL      CHERAMGsol
#define MYAMGUSOL       CHERAMGsol
#define MYAMGTUSOL      CHERAMGsol
#define MYAMGTDUSOL     CHERAMGsol
#define MYAMGTDLSOL     CHERAMGsol
#define MYAMGDUSOL      CHERAMGsol
#define MYAMGDLSOL      CHERAMGsol
#endif
// end _COMPLEX_SYMMETRIC_

// Z
// if-else _SINGLE_COMPLEX_
#else

#ifdef _COMPLEX_SYMMETRIC_
#define MYAMGSOLVER     ZGNLSYMAMGsolver
#define MYAMGSOL        ZSYMAMGsol
#define MYAMGTSOL       ZSYMAMGsol
#define MYAMGLSOL       ZSYMAMGsol
#define MYAMGTLSOL      ZSYMAMGsol
#define MYAMGUSOL       ZSYMAMGsol
#define MYAMGTUSOL      ZSYMAMGsol
#define MYAMGTDUSOL     ZSYMAMGsol
#define MYAMGTDLSOL     ZSYMAMGsol
#define MYAMGDUSOL      ZSYMAMGsol
#define MYAMGDLSOL      ZSYMAMGsol

// if-else _COMPLEX_SYMMETRIC_
#else
#define MYAMGSOLVER     ZGNLHERAMGsolver
#define MYAMGSOL        ZHERAMGsol
#define MYAMGTSOL       ZHERAMGsol
#define MYAMGLSOL       ZHERAMGsol
#define MYAMGTLSOL      ZHERAMGsol
#define MYAMGUSOL       ZHERAMGsol
#define MYAMGTUSOL      ZHERAMGsol
#define MYAMGTDUSOL     ZHERAMGsol
#define MYAMGTDLSOL     ZHERAMGsol
#define MYAMGDUSOL      ZHERAMGsol
#define MYAMGDLSOL      ZHERAMGsol
#endif
// end _COMPLEX_SYMMETRIC_

#endif
// end _SINGLE_COMPLEX_

#endif
// end _DOUBLE_REAL_

#endif
// end _SINGLE_REAL_


// general case with non-SPD/SYM prec. of same precision S/D/C/Z
// if-else _SYM_PREC_
#else

#define MYAMGSOLVER     AMGSOLVER
#define MYAMGSOL        AMGSOL
#define MYAMGTSOL       AMGTSOL
#define MYAMGLSOL       AMGLSOL
#define MYAMGTLSOL      AMGTLSOL
#define MYAMGUSOL       AMGUSOL
#define MYAMGTUSOL      AMGTUSOL
#define MYAMGTDUSOL     AMGTDUSOL
#define MYAMGTDLSOL     AMGTDLSOL
#define MYAMGDUSOL      AMGDUSOL
#define MYAMGDLSOL      AMGDLSOL
#endif
// end _SYM_PREC_

#endif
// end _SPD_PREC_

#define MYAMGLEVELMAT         AMGLEVELMAT
#define MYILUPACKPARAM        ILUPACKPARAM
#define MYFLOAT               FLOAT
#define MYCSRMAT              CSRMAT
#define MYAMGSETUPPARAMETERS  AMGSETUPPARAMETERS
#define DUPLICATE             1
#endif
// end _REAL_PREC_



/*
 Solve Ax=b using the ILU computed by ILUPACK and an iterative solvers
 Default is GMRES
*/
integer MYAMGSOLVER(CSRMAT *A, MYAMGLEVELMAT *PRE, MYILUPACKPARAM *IPparam, 
		    FLOAT *rhs, FLOAT *sol)

{
   /*
      A          initial matrix stored in sparse row format

      PRE        AMG preconditioner
      nlev       number of levels 

      transpose  if the following bits are set: Bit 0:  A^T   instead of A   is 
                                                        stored  
                                                Bit 1:  CONJG(A) instead of A
                                                        is stored

                                                Bit 2:  solve A^Tx=b instead of
                                                        Ax=b  
                                                Bit 3:  solve CONJG(A)x=b 
                                                        instead of Ax=b  

                 REMARK: Note that P is derived from A. So if A^T is stored
                         instead of A, it follows that P^T is stored instead of
                         P. Similar relations hold for CONJG(A)
						
      sol        initial solution, MUST be set on input (e.g. sol=(0,...,0)^T)
      rhs        right hand side

      nrestart   number of restart steps for GMRES
      max_it     maximum number of iteration steps
      restol     terminating tolerance for the residual

      *dbuff     buffers of size *ndbuff and *nibuff. If the buffer size is too
                 small
      *ibuff     new buffer is reallocated
      
      On entry
      ========
      All parameters need to be set

      On exit
      =======
      return code:         negative -> seperate GMRES error codes
                           positive -> number of iterations exceeded
			   0           success

      max_it               overwritten by the true number of iteration steps


      written by Matthias Bollhoefer, October 2006
   */




    float         systime, time_start,   time_stop,   secnds,
                  timeAx_start, timeAx_stop, secndsAx=0;
    integer       n=A->nr, i,j,k, flag, ierr=0, nAx=0, transa, transp, param,
                  sumn, nbf, nlev=PRE->nlev, *ia,*ja;
    FLOAT         *w, *a;
    MYFLOAT       *leftscale, *rightscale, *r,*c;
    MYAMGLEVELMAT *current=PRE;
    MYCSRMAT      myA;
    REALS         val,vb, conja, conjp, *rbuff;


    // start iterative solver
    evaluate_time(&time_start,&systime);

    // initially do scaling
    r=PRE->rowscal;
    c=PRE->colscal;
    // adjust arrays
    ia=A->ia;
    ja=A->ja;
    a =A->a;
    ja--;
    a--;
    c--;
    for (i=0; i<A->nr; i++) {
        for (j=ia[i]; j<ia[i+1]; j++) {
	    k=ja[j];
#if defined _SINGLE_REAL_ || defined _DOUBLE_REAL_
	    a[j]*=r[i]*c[k];
#else
#ifdef _REAL_PREC_
	    a[j].r*=r[i]*c[k];
	    a[j].i*=r[i]*c[k];
#else
	    a[j].r*=r[i].r*c[k].r;
	    a[j].i*=r[i].r*c[k].r;
#endif	  
#endif	  
	}
    }

    // set up parameters for the iterative part
    myA.nr=A->nr;
    myA.nc=A->nc;
    myA.ia=A->ia;
    myA.ja=A->ja;
    myA.a =NULL;
    MYAMGSETUPPARAMETERS(&myA,IPparam,1);

    param=IPparam->ipar[6];
    // which matrix-vector multiplication is required
    // system          meaning flags bit 0,2
    // A   x=b  (Ax)                     0 0 
    // A^T x=b  (A^Tx)                   0 1 solve transposed system
    // A   y=b  (A^Tx)       A^T stored  1 0
    // A^T y=b  (Ax)         A^T stored  1 1 solve transposed system
    if (((IPparam->ipar[4]&1) && !(IPparam->ipar[4]&4)) ||
        ((IPparam->ipar[4]&4) && !(IPparam->ipar[4]&1))){
       // use A^Tx instead of Ax
       transa=1;
    } // end if
    else {
       transa=0;
    } // end else 

    // When do we need CONJG(A) instead of A
    // system                meaning flags Bit 1,3
    // A        x=b                            0 0 
    // CONJG(A) x=b  (cjg)                     0 1 solve conjugated system
    //       A  x=b  (cjg)   CONJG(A) stored   1 0
    // CONJG(A) x=b          CONJG(A) stored   1 1 solve conjugated system
    if (((IPparam->ipar[4]&2) && !(IPparam->ipar[4]&8)) ||
        ((IPparam->ipar[4]&8) && !(IPparam->ipar[4]&2))){
       // use CONJG(A) instead of A
       conja=-1;
    } // end if
    else {
       conja=1;
    } // end else 


    // which preconditioner has to be applied
    // system                             meaning flags bit 0,2
    //      A   P     y=b  (P,        rc)                   0 0 
    // P    A         y=b  (P,        rc)                   0 0 
    // PL   A   PR    y=b  (PL PR,    rc)                   0 0 

    // A^T      P^T   y=b  (P^T,      cr)                   0 1 solve transposed system
    // P^T  A^T       y=b  (P^T,      cr)                   0 1 solve transposed system
    // PR^T A^T PL^T  y=b  (PR^T PL^T,cr)                   0 1 solve transposed system

    //      A   P^T   y=b  (P^T,      cr)    A^T is stored  1 0
    // P^T  A         y=b  (P^T,      cr)    A^T is stored  1 0
    // PR^T A   PL^T  y=b  (PR^T PL^T,cr)    A^T is stored  1 0

    //      A^T P     y=b  (P,  rc     )     A^T is stored  1 1 solve transposed system
    // P    A^T       y=b  (P,  rc)          A^T is stored  1 1 solve transposed system
    // PL   A^T PR    y=b  (PL PR,  rc)      A^T is stored  1 1 solve transposed system
    if (((IPparam->ipar[4]&1) && !(IPparam->ipar[4]&4)) ||
        ((IPparam->ipar[4]&4) && !(IPparam->ipar[4]&1))){
       // use P^T instead of P
       transp=1;
       leftscale =PRE->colscal;
       rightscale=PRE->rowscal;
    } // end if
    else {
       transp=0;
       leftscale =PRE->rowscal;
       rightscale=PRE->colscal;
    } // end else 

    // When do we need CONJG(P) instead of P
    // system                                      meaning flags Bit 1,3
    // A         P                  y=b                              0 0 
    // P         A        P         y=b                              0 0 
    // PL        A        PR        y=b                              0 0 

    // CONJG(A)  CONJG(P)           y=b  (cjg)                       0 1 solve conjugated system
    // CONJG(P)  CONJG(A)           y=b  (cjg)                       0 1 solve conjugated system
    // CONJG(PL) CONJG(A) CONJG(PR) y=b  (cjg)                       0 1 solve conjugated system

    //           A        CONJG(P)  y=b  (cjg)   CONJG(A) is stored  1 0
    // CONJG(P)  A                  y=b  (cjg)   CONJG(A) is stored  1 0
    // CONJG(PL) A        CONJG(PR) y=b  (cjg)   CONJG(A) is stored  1 0

    // CONJG(A)  P                  y=b          CONJG(A) is stored  1 1 solve conjugated system
    // P         CONJG(A)           y=b          CONJG(A) is stored  1 1 solve conjugated system
    // PL        CONJG(A) PR        y=b          CONJG(A) is stored  1 1 solve conjugated system
    if (((IPparam->ipar[4]&2) && !(IPparam->ipar[4]&8)) || 
        ((IPparam->ipar[4]&8) && !(IPparam->ipar[4]&2))){
       // use CONJG(P) instead of P
       conjp=-1;
    } // end if
    else {
       conjp=1;
    } // end else 

#ifdef PRINT_INFO
    switch (IPparam->ipar[5]) {
    case  3:   /* bcg */
      printf("use BiCG as iterative solver\n");
      break;
    case  9:   /* fgmres */
      printf("use FGMRES(%d) as iterative solver\n",IPparam->ipar[24]);
      break;
    default: 
      printf("use GMRES(%d) as iterative solver\n",IPparam->ipar[24]);
      break;
    }
#endif

    // 3n words are required by AMGsol, 2n+2*sum_lev nB for AMGsol1,2
    nbf=0;
    if (IPparam->ipar[10]==2) 
       nbf=2*n;
    if (IPparam->ipar[10]!=0) {
       sumn=0;
       for (i=1; i<=nlev; i++) {
	   sumn+=current->nB;
	   nbf+=2*(n-sumn);
	   current=current->next;
       } // end for i
       if (IPparam->ipar[10]==2) nbf+=n;
    }
    nbf=2*n+MAX(n,nbf);
#ifdef PRINT_MEM
    printf("dbuffmem=%8.2lfMB\n",IPparam->ndbuff/DMEGA);fflush(stdout);
#endif
    if (IPparam->ndbuff==0) {
       IPparam->ndbuff=DUPLICATE*((size_t)IPparam->ipar[23]+(size_t)nbf+2*(size_t)n);
       IPparam->dbuff=(MYFLOAT *) MALLOC(IPparam->ndbuff*sizeof(MYFLOAT),
					 "AMGsolver:dbuff");
#ifdef PRINT_MEM
       printf("dbuff(%8.2lfMB) allocated\n",IPparam->ndbuff/DMEGA);fflush(stdout);
#endif
    }
    else if (DUPLICATE*((size_t)IPparam->ipar[23]+(size_t)nbf+2*(size_t)n)>IPparam->ndbuff) {
       IPparam->ndbuff=DUPLICATE*((size_t)IPparam->ipar[23]+(size_t)nbf+2*(size_t)n);
       IPparam->dbuff=(MYFLOAT *)REALLOC(IPparam->dbuff,
					 IPparam->ndbuff*sizeof(MYFLOAT),
					 "AMGsolver:dbuff");
#ifdef PRINT_MEM
       printf("dbuff(%8.2lfMB) re-allocated\n",IPparam->ndbuff/DMEGA);fflush(stdout);
#endif
    }
    w=((FLOAT*)IPparam->dbuff) + (size_t)nbf;


    // rescale solution and right hand side 
    for (i=0; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
        sol[i]/=rightscale[i];
        rhs[i]*=leftscale[i];
#else
#ifdef _REAL_PREC_
        sol[i].r/=rightscale[i];
        sol[i].i/=rightscale[i];
        rhs[i].r*=leftscale[i];
        rhs[i].i*=leftscale[i];
#else
	val=1.0/(rightscale[i].r*rightscale[i].r +
  	         rightscale[i].i*rightscale[i].i);
	vb=sol[i].r;
	sol[i].r=( vb*      rightscale[i].r+sol[i].i*conjp*rightscale[i].i)*val;
	sol[i].i=(-vb*conjp*rightscale[i].i+sol[i].i      *rightscale[i].r)*val;
	vb=rhs[i].r;
	rhs[i].r=vb*      leftscale[i].r-rhs[i].i*conjp*leftscale[i].i;
	rhs[i].i=vb*conjp*leftscale[i].i+rhs[i].i*      leftscale[i].r;
#endif
#endif
    } // end for i


    // init output parameters for SPARSKIT
    IPparam->ipar[20]=0;
    // init with zeros
    IPparam->ipar[26]=
      IPparam->ipar[27]=
      IPparam->ipar[28]=
      IPparam->ipar[29]=
      IPparam->ipar[30]=
      IPparam->ipar[31]=
      IPparam->ipar[32]=
      IPparam->ipar[33]=
      IPparam->ipar[34]=
      IPparam->ipar[35]=0;
    // init with zeros 
    IPparam->fpar[22]=
      IPparam->fpar[23]=
      IPparam->fpar[24]=
      IPparam->fpar[25]=
      IPparam->fpar[26]=
      IPparam->fpar[27]=
      IPparam->fpar[28]=
      IPparam->fpar[29]=
      IPparam->fpar[30]=
      IPparam->fpar[31]=
      IPparam->fpar[32]=
      IPparam->fpar[33]=
      IPparam->fpar[34]=
      IPparam->fpar[35]=0;

    
    // if backward error is desired then substitute the matrix 2-norm
    // by taking the geometric mean of the 1-norm and the inifinity-norm
    if (IPparam->ipar[22]==3) {
      // init buffer for column sumns
      rbuff=(REALS *)IPparam->dbuff;
      for (i=0; i<n; i++)
	  rbuff[i]=0.0;
      // val = maximum row sum
      val=0.0;
      for (i=0; i<n; i++) {
	  j=1;
	  k=A->ia[i+1]-A->ia[i];
	  val=MAX(val,ASUM(&k,A->a+A->ia[i]-1,&j));
	  for (j=A->ia[i]-1; j<A->ia[i+1]-1; j++) {
	      k=A->ja[j]-1;
	      rbuff[k]+=FABS(A->a[j]);
	  } // end for j
      } // end for i
      vb=0;
      for (i=0; i<n; i++)
	  vb=MAX(vb,rbuff[i]);
      IPparam->fpar[31]=sqrt((double)val*vb);
    } // end if


    flag=-1;
    while (flag) {

          // which solver do we use?
          switch (IPparam->ipar[5]) {
	  case  3:   /* bcg */
	    BCG(&n,rhs,sol,IPparam->ipar+20,IPparam->fpar+20,w);
	    break;
	  case  9:   /* fgmres */
	    FGMRES(&n,rhs,sol,IPparam->ipar+20,IPparam->fpar+20,w);
	    break;
	  default:   /* gmres */
	    GMRES(&n,rhs,sol,IPparam->ipar+20,IPparam->fpar+20,w);
	    break;
	  }


	  // what is required by the solver?

	  w--;
	  switch (IPparam->ipar[20]) {
	  case  1:   // apply matrix vector multiplication
	        evaluate_time(&timeAx_start,&systime);
		nAx++;
#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
		// if CONJG(A) is requested y=CONJG(A)*x <=> y=CONJG(A*CONJG(x))
		if (conja<0) {
		   w+=IPparam->ipar[27];
		   for (i=0; i<n; i++)
		       w[i].i=-w[i].i;
		   w-=IPparam->ipar[27];
		} // end if
#endif
		// if A^T is needed
		if (transa)
		   CSRMATTVEC(*A,w+IPparam->ipar[27],w+IPparam->ipar[28]);
		else
		   CSRMATVEC(*A,w+IPparam->ipar[27],w+IPparam->ipar[28]);
#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
		// if CONJG(A) is requested
		if (conja<0) {
		   w+=IPparam->ipar[28];
		   for (i=0; i<n; i++)
		       w[i].i=-w[i].i;
		   w-=IPparam->ipar[28];
		} // end if
#endif

	        evaluate_time(&timeAx_stop,&systime);
		secndsAx+=timeAx_stop-timeAx_start;
		break;
	  case  2:   // apply transposed matrix vector multiplication
	        evaluate_time(&timeAx_start,&systime);
		nAx++;

#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
		// if CONJG(A) is requested y=CONJG(A)*x <=> y=CONJG(A*CONJG(x))
		if (conja<0) {
		   w+=IPparam->ipar[27];
		   for (i=0; i<n; i++)
		       w[i].i=-w[i].i;
		   w-=IPparam->ipar[27];
		} // end if
#endif
		// if A^T is needed
		if (transa)
		   CSRMATVEC(*A,w+IPparam->ipar[27],w+IPparam->ipar[28]);
		else
		   CSRMATTVEC(*A,w+IPparam->ipar[27],w+IPparam->ipar[28]);
#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
		// if CONJG(A) is requested
		if (conja<0) {
		   w+=IPparam->ipar[28];
		   for (i=0; i<n; i++)
		       w[i].i=-w[i].i;
		   w-=IPparam->ipar[28];
		} // end if
#endif

	        evaluate_time(&timeAx_stop,&systime);
		secndsAx+=timeAx_stop-timeAx_start;
		break;
	  case  3:   // left preconditioner
		if (IPparam->ipar[21]==1) {
#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
		  // if CONJG(P) is requested y=CONJG(P)*x <=> y=CONJG(P*CONJG(x))
		  if (conjp<0) {
		     w+=IPparam->ipar[27];
		     for (i=0; i<n; i++)
		         w[i].i=-w[i].i;
		     w-=IPparam->ipar[27];
		  } // end if
#endif
		  // if P^T is needed
		  if (transp) {
#ifdef _REAL_PREC_
		     // real preconditioner has to be applied twice
		     for (i=0; i<n; i++)
		         IPparam->dbuff[nbf+i]=w[IPparam->ipar[27]+i].r;
		     MYAMGTSOL(PRE, IPparam, IPparam->dbuff+nbf,
			       IPparam->dbuff+n+nbf, IPparam->dbuff);
		     for (i=0; i<n; i++)
		         w[IPparam->ipar[28]+i].r=IPparam->dbuff[nbf+n+i];

		     for (i=0; i<n; i++)
		         IPparam->dbuff[nbf+i]=w[IPparam->ipar[27]+i].i;
		     MYAMGTSOL(PRE, IPparam, IPparam->dbuff+nbf,
			       IPparam->dbuff+nbf+n, IPparam->dbuff);
		     for (i=0; i<n; i++)
		         w[IPparam->ipar[28]+i].i=IPparam->dbuff[nbf+n+i];
#else
		     MYAMGTSOL(PRE, IPparam, w+IPparam->ipar[27],
			       w+IPparam->ipar[28], IPparam->dbuff);
#endif
		  }
		  else {
#ifdef _REAL_PREC_
		     // real preconditioner has to be applied twice
		     for (i=0; i<n; i++)
		         IPparam->dbuff[nbf+i]=w[IPparam->ipar[27]+i].r;
		     MYAMGSOL(PRE, IPparam, IPparam->dbuff+nbf,
			      IPparam->dbuff+nbf+n, IPparam->dbuff);
		     for (i=0; i<n; i++)
		         w[IPparam->ipar[28]+i].r=IPparam->dbuff[nbf+n+i];

		     for (i=0; i<n; i++)
		         IPparam->dbuff[nbf+i]=w[IPparam->ipar[27]+i].i;
		     MYAMGSOL(PRE, IPparam, IPparam->dbuff+nbf,
			      IPparam->dbuff+nbf+n, IPparam->dbuff);
		     for (i=0; i<n; i++)
		         w[IPparam->ipar[28]+i].i=IPparam->dbuff[nbf+n+i];
#else
		     MYAMGSOL(PRE, IPparam, w+IPparam->ipar[27],
			      w+IPparam->ipar[28], IPparam->dbuff);
#endif
		  }
#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
		  // if CONJG(P) is requested
		  if (conjp<0) {
		     w+=IPparam->ipar[28];
		     for (i=0; i<n; i++)
		         w[i].i=-w[i].i;
		     w-=IPparam->ipar[28];
		  } // end if
#endif
		} // end if 
		else 
		   if (IPparam->ipar[21]==3) {
#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
		      // if CONJG(P) is requested y=CONJG(P)*x <=> y=CONJG(P*CONJG(x))
		      if (conjp<0) {
			 w+=IPparam->ipar[27];
			 for (i=0; i<n; i++)
			     w[i].i=-w[i].i;
			 w-=IPparam->ipar[27];
		      } // end if
#endif
		      // if P^T is needed
		      if (transp) {
#ifdef _REAL_PREC_
			 // real preconditioner has to be applied twice
			 for (i=0; i<n; i++)
			     IPparam->dbuff[nbf+i]=w[IPparam->ipar[27]+i].r;
			 MYAMGTUSOL(PRE, IPparam, IPparam->dbuff+nbf,
				    IPparam->dbuff+nbf+n, IPparam->dbuff);
			 for (i=0; i<n; i++)
			     w[IPparam->ipar[28]+i].r=IPparam->dbuff[nbf+n+i];

			 for (i=0; i<n; i++)
			     IPparam->dbuff[nbf+i]=w[IPparam->ipar[27]+i].i;
			 MYAMGTUSOL(PRE, IPparam, IPparam->dbuff+nbf,
				    IPparam->dbuff+nbf+n, IPparam->dbuff);
			 for (i=0; i<n; i++)
			     w[IPparam->ipar[28]+i].i=IPparam->dbuff[nbf+n+i];
#else
			 MYAMGTUSOL(PRE, IPparam, w+IPparam->ipar[27],
				    w+IPparam->ipar[28], IPparam->dbuff);
#endif
		      }
		      else {
#ifdef _REAL_PREC_
			 // real preconditioner has to be applied twice
			 for (i=0; i<n; i++)
			     IPparam->dbuff[nbf+i]=w[IPparam->ipar[27]+i].r;
			 MYAMGLSOL (PRE, IPparam, IPparam->dbuff+nbf,
				    IPparam->dbuff+nbf+n, IPparam->dbuff);
			 for (i=0; i<n; i++)
			     w[IPparam->ipar[28]+i].r=IPparam->dbuff[nbf+n+i];

			 for (i=0; i<n; i++)
			     IPparam->dbuff[nbf+i]=w[IPparam->ipar[27]+i].i;
			 MYAMGLSOL (PRE, IPparam, IPparam->dbuff+nbf,
				    IPparam->dbuff+nbf+n, IPparam->dbuff);
			 for (i=0; i<n; i++)
			     w[IPparam->ipar[28]+i].i=IPparam->dbuff[nbf+n+i];
#else
			 MYAMGLSOL (PRE, IPparam, w+IPparam->ipar[27],
				    w+IPparam->ipar[28], IPparam->dbuff);
#endif
		      }
#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
		      // if CONJG(P) is requested
		      if (conjp<0) {
			 w+=IPparam->ipar[28];
			 for (i=0; i<n; i++)
			     w[i].i=-w[i].i;
			 w-=IPparam->ipar[28];
		      } // end if
#endif
		   } // end if 
		   else {
		      i=1;
		      COPY(&n,w+IPparam->ipar[27],&i,w+IPparam->ipar[28],&i);
		   } // end else
		break;
	  case  4:   // left preconditioner transposed 
	        if (IPparam->ipar[21]==1) {
#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
		   // if CONJG(P) is requested y=CONJG(P)*x <=> y=CONJG(P*CONJG(x))
		   if (conjp<0) {
		      w+=IPparam->ipar[27];
		      for (i=0; i<n; i++)
		          w[i].i=-w[i].i;
		      w-=IPparam->ipar[27];
		   } // end if
#endif
		   // if P^T is needed
		   if (transp) {
#ifdef _REAL_PREC_
		      // real preconditioner has to be applied twice
		      for (i=0; i<n; i++)
			  IPparam->dbuff[nbf+i]=w[IPparam->ipar[27]+i].r;
		      MYAMGSOL (PRE, IPparam, IPparam->dbuff+nbf,
				IPparam->dbuff+nbf+n, IPparam->dbuff);
		      for (i=0; i<n; i++)
			  w[IPparam->ipar[28]+i].r=IPparam->dbuff[nbf+n+i];

		      for (i=0; i<n; i++)
			   IPparam->dbuff[nbf+i]=w[IPparam->ipar[27]+i].i;
		      MYAMGSOL (PRE, IPparam, IPparam->dbuff+nbf,
				IPparam->dbuff+nbf+n, IPparam->dbuff);
		      for (i=0; i<n; i++)
			   w[IPparam->ipar[28]+i].i=IPparam->dbuff[nbf+n+i];
#else
		      MYAMGSOL (PRE, IPparam, w+IPparam->ipar[27],
				w+IPparam->ipar[28], IPparam->dbuff);
#endif
		   }
		   else {
#ifdef _REAL_PREC_
		      // real preconditioner has to be applied twice
		      for (i=0; i<n; i++)
			  IPparam->dbuff[nbf+i]=w[IPparam->ipar[27]+i].r;
		      MYAMGTSOL(PRE, IPparam, IPparam->dbuff+nbf,
				IPparam->dbuff+nbf+n, IPparam->dbuff);
		      for (i=0; i<n; i++)
			  w[IPparam->ipar[28]+i].r=IPparam->dbuff[nbf+n+i];

		      for (i=0; i<n; i++)
			   IPparam->dbuff[nbf+i]=w[IPparam->ipar[27]+i].i;
		      MYAMGTSOL(PRE, IPparam, IPparam->dbuff+nbf,
				IPparam->dbuff+nbf+n, IPparam->dbuff);
		      for (i=0; i<n; i++)
			   w[IPparam->ipar[28]+i].i=IPparam->dbuff[nbf+n+i];
#else
		      MYAMGTSOL(PRE, IPparam, w+IPparam->ipar[27],
			      w+IPparam->ipar[28], IPparam->dbuff);
#endif
		   }
#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
		   // if CONJG(P) is requested
		   if (conjp<0) {
		      w+=IPparam->ipar[28];
		      for (i=0; i<n; i++)
		          w[i].i=-w[i].i;
		      w-=IPparam->ipar[28];
		   } // end if
#endif
		} // end if
	        else
		   if (IPparam->ipar[21]==3) {
#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
		      // if CONJG(P) is requested y=CONJG(P)*x <=> y=CONJG(P*CONJG(x))
		      if (conjp<0) {
			 w+=IPparam->ipar[27];
			 for (i=0; i<n; i++)
			     w[i].i=-w[i].i;
			 w-=IPparam->ipar[27];
		      } // end if
#endif
		      // if P^T is needed
		      if (transp) {
#ifdef _REAL_PREC_
			 // real preconditioner has to be applied twice
			 for (i=0; i<n; i++)
			     IPparam->dbuff[nbf+i]=w[IPparam->ipar[27]+i].r;
			 MYAMGUSOL (PRE, IPparam, IPparam->dbuff+nbf,
				    IPparam->dbuff+nbf+n, IPparam->dbuff);
			 for (i=0; i<n; i++)
			     w[IPparam->ipar[28]+i].r=IPparam->dbuff[nbf+n+i];

			 for (i=0; i<n; i++)
			     IPparam->dbuff[nbf+i]=w[IPparam->ipar[27]+i].i;
			 MYAMGUSOL (PRE, IPparam, IPparam->dbuff+nbf,
				    IPparam->dbuff+nbf+n, IPparam->dbuff);
			 for (i=0; i<n; i++)
			     w[IPparam->ipar[28]+i].i=IPparam->dbuff[nbf+n+i];
#else
			 MYAMGUSOL (PRE, IPparam, w+IPparam->ipar[27],
				    w+IPparam->ipar[28], IPparam->dbuff);
#endif
		      }
		      else {
#ifdef _REAL_PREC_
			 // real preconditioner has to be applied twice
			 for (i=0; i<n; i++)
			     IPparam->dbuff[nbf+i]=w[IPparam->ipar[27]+i].r;
			 MYAMGTLSOL(PRE, IPparam, IPparam->dbuff+nbf,
				    IPparam->dbuff+nbf+n, IPparam->dbuff);
			 for (i=0; i<n; i++)
			     w[IPparam->ipar[28]+i].r=IPparam->dbuff[nbf+n+i];

			 for (i=0; i<n; i++)
			     IPparam->dbuff[nbf+i]=w[IPparam->ipar[27]+i].i;
			 MYAMGTLSOL(PRE, IPparam, IPparam->dbuff+nbf,
				    IPparam->dbuff+nbf+n, IPparam->dbuff);
			 for (i=0; i<n; i++)
			     w[IPparam->ipar[28]+i].i=IPparam->dbuff[nbf+n+i];
#else
			 MYAMGTLSOL(PRE, IPparam, w+IPparam->ipar[27],
				    w+IPparam->ipar[28], IPparam->dbuff);
#endif
		      }
#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
		      // if CONJG(P) is requested
		      if (conjp<0) {
		 	 w+=IPparam->ipar[28];
			 for (i=0; i<n; i++)
			     w[i].i=-w[i].i;
			 w-=IPparam->ipar[28];
		      } // end if
#endif
		   } // end if
		   else {
		      i=1;
		      COPY(&n,w+IPparam->ipar[27],&i,w+IPparam->ipar[28],&i);
		   } // end else
		break;
	  case  5:   // right preconditioner
		if (IPparam->ipar[21]==2) {
#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
		   // if CONJG(P) is requested y=CONJG(P)*x <=> y=CONJG(P*CONJG(x))
		   if (conjp<0) {
		      w+=IPparam->ipar[27];
		      for (i=0; i<n; i++)
		          w[i].i=-w[i].i;
		      w-=IPparam->ipar[27];
		   } // end if
#endif
		   // if P^T is needed
		   if (transp) {
#ifdef _REAL_PREC_
		      // real preconditioner has to be applied twice
		      for (i=0; i<n; i++)
			  IPparam->dbuff[nbf+i]=w[IPparam->ipar[27]+i].r;
		      MYAMGTSOL(PRE, IPparam, IPparam->dbuff+nbf,
				IPparam->dbuff+nbf+n, IPparam->dbuff);
		      for (i=0; i<n; i++)
			  w[IPparam->ipar[28]+i].r=IPparam->dbuff[nbf+n+i];

		      for (i=0; i<n; i++)
			  IPparam->dbuff[nbf+i]=w[IPparam->ipar[27]+i].i;
		      MYAMGTSOL(PRE, IPparam, IPparam->dbuff+nbf,
				IPparam->dbuff+nbf+n, IPparam->dbuff);
		      for (i=0; i<n; i++)
			  w[IPparam->ipar[28]+i].i=IPparam->dbuff[nbf+n+i];
#else
		      MYAMGTSOL(PRE, IPparam, w+IPparam->ipar[27],
				w+IPparam->ipar[28], IPparam->dbuff);
#endif
		   }
		   else {
#ifdef _REAL_PREC_
		      // real preconditioner has to be applied twice
		      for (i=0; i<n; i++)
			  IPparam->dbuff[nbf+i]=w[IPparam->ipar[27]+i].r;
		      MYAMGSOL (PRE, IPparam, IPparam->dbuff+nbf,
				IPparam->dbuff+nbf+n, IPparam->dbuff);
		      for (i=0; i<n; i++)
			  w[IPparam->ipar[28]+i].r=IPparam->dbuff[nbf+n+i];

		      for (i=0; i<n; i++)
			  IPparam->dbuff[nbf+i]=w[IPparam->ipar[27]+i].i;
		      MYAMGSOL (PRE, IPparam, IPparam->dbuff+nbf,
				IPparam->dbuff+nbf+n, IPparam->dbuff);
		      for (i=0; i<n; i++)
			  w[IPparam->ipar[28]+i].i=IPparam->dbuff[nbf+n+i];
#else
		      MYAMGSOL (PRE, IPparam, w+IPparam->ipar[27],
				w+IPparam->ipar[28], IPparam->dbuff);
#endif
		   }
#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
		   // if CONJG(P) is requested
		   if (conjp<0) {
		      w+=IPparam->ipar[28];
		      for (i=0; i<n; i++)
		          w[i].i=-w[i].i;
		      w-=IPparam->ipar[28];
		   } // end if
#endif
		} // end if
		else
		   if (IPparam->ipar[21]==3) {
#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
		      // if CONJG(P) is requested y=CONJG(P)*x <=> y=CONJG(P*CONJG(x))
		      if (conjp<0) {
			 w+=IPparam->ipar[27];
			 for (i=0; i<n; i++)
			     w[i].i=-w[i].i;
			 w-=IPparam->ipar[27];
		      } // end if
#endif
		      // if P^T is needed
		      if (transp) {
#ifdef _REAL_PREC_
			 // real preconditioner has to be applied twice
			 for (i=0; i<n; i++)
			     IPparam->dbuff[nbf+i]=w[IPparam->ipar[27]+i].r;
			 MYAMGTDLSOL(PRE, IPparam, IPparam->dbuff+nbf,
				     IPparam->dbuff+nbf+n, IPparam->dbuff);
			 for (i=0; i<n; i++)
			     w[IPparam->ipar[28]+i].r=IPparam->dbuff[nbf+n+i];

			 for (i=0; i<n; i++)
			     IPparam->dbuff[nbf+i]=w[IPparam->ipar[27]+i].i;
			 MYAMGTDLSOL(PRE, IPparam, IPparam->dbuff+nbf,
				     IPparam->dbuff+nbf+n, IPparam->dbuff);
			 for (i=0; i<n; i++)
			     w[IPparam->ipar[28]+i].i=IPparam->dbuff[nbf+n+i];
#else
			 MYAMGTDLSOL(PRE, IPparam, w+IPparam->ipar[27],
				     w+IPparam->ipar[28], IPparam->dbuff);
#endif
		      }
		      else {
#ifdef _REAL_PREC_
			 // real preconditioner has to be applied twice
			 for (i=0; i<n; i++)
			     IPparam->dbuff[nbf+i]=w[IPparam->ipar[27]+i].r;
			 MYAMGDUSOL (PRE, IPparam, IPparam->dbuff+nbf,
				     IPparam->dbuff+nbf+n, IPparam->dbuff);
			 for (i=0; i<n; i++)
			     w[IPparam->ipar[28]+i].r=IPparam->dbuff[nbf+n+i];

			 for (i=0; i<n; i++)
			     IPparam->dbuff[nbf+i]=w[IPparam->ipar[27]+i].i;
			 MYAMGDUSOL (PRE, IPparam, IPparam->dbuff+nbf,
				     IPparam->dbuff+nbf+n, IPparam->dbuff);
			 for (i=0; i<n; i++)
			     w[IPparam->ipar[28]+i].i=IPparam->dbuff[nbf+n+i];
#else
			 AMGDUSOL (PRE, IPparam, w+IPparam->ipar[27],
				   w+IPparam->ipar[28], IPparam->dbuff);
#endif
		      }
#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
		      // if CONJG(P) is requested
		      if (conjp<0) {
			 w+=IPparam->ipar[28];
			 for (i=0; i<n; i++)
			     w[i].i=-w[i].i;
			 w-=IPparam->ipar[28];
		      } // end if
#endif
		   } // end if
		   else {
		      i=1;
		      COPY(&n,w+IPparam->ipar[27],&i,w+IPparam->ipar[28],&i);
		   } // end else
		break;
	  case  6:   //  right preconditioner transposed
		if (IPparam->ipar[21]==2) {
#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
		   // if CONJG(P) is requested y=CONJG(P)*x <=> y=CONJG(P*CONJG(x))
		   if (conjp<0) {
		      w+=IPparam->ipar[27];
		      for (i=0; i<n; i++)
		          w[i].i=-w[i].i;
		      w-=IPparam->ipar[27];
		   } // end if
#endif
		   // if P^T is needed
		   if (transp) {
#ifdef _REAL_PREC_
		      // real preconditioner has to be applied twice
		      for (i=0; i<n; i++)
			  IPparam->dbuff[nbf+i]=w[IPparam->ipar[27]+i].r;
		      MYAMGLSOL(PRE, IPparam, IPparam->dbuff+nbf,
				IPparam->dbuff+nbf+n, IPparam->dbuff);
		      for (i=0; i<n; i++)
			  w[IPparam->ipar[28]+i].r=IPparam->dbuff[nbf+n+i];

		      for (i=0; i<n; i++)
			  IPparam->dbuff[nbf+i]=w[IPparam->ipar[27]+i].i;
		      MYAMGSOL(PRE, IPparam, IPparam->dbuff+nbf,
			       IPparam->dbuff+nbf+n, IPparam->dbuff);
		      for (i=0; i<n; i++)
			  w[IPparam->ipar[28]+i].i=IPparam->dbuff[nbf+n+i];
#else
		      MYAMGSOL(PRE, IPparam, w+IPparam->ipar[27],
			       w+IPparam->ipar[28], IPparam->dbuff);
#endif
		   }
		   else {
#ifdef _REAL_PREC_
		      // real preconditioner has to be applied twice
		      for (i=0; i<n; i++)
			  IPparam->dbuff[nbf+i]=w[IPparam->ipar[27]+i].r;
		      MYAMGTSOL(PRE, IPparam, IPparam->dbuff+nbf,
				IPparam->dbuff+nbf+n, IPparam->dbuff);
		      for (i=0; i<n; i++)
			  w[IPparam->ipar[28]+i].r=IPparam->dbuff[nbf+n+i];

		      for (i=0; i<n; i++)
			  IPparam->dbuff[nbf+i]=w[IPparam->ipar[27]+i].i;
		      MYAMGTSOL(PRE, IPparam, IPparam->dbuff+nbf,
				IPparam->dbuff+nbf+n, IPparam->dbuff);
		      for (i=0; i<n; i++)
			  w[IPparam->ipar[28]+i].i=IPparam->dbuff[nbf+n+i];
#else
		      MYAMGTSOL(PRE, IPparam, w+IPparam->ipar[27],
				w+IPparam->ipar[28], IPparam->dbuff);
#endif
		   }
#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
		   // if CONJG(P) is requested
		   if (conjp<0) {
		      w+=IPparam->ipar[28];
		      for (i=0; i<n; i++)
		          w[i].i=-w[i].i;
		      w-=IPparam->ipar[28];
		   } // end if
#endif
		} // end if
		else
		   if (IPparam->ipar[21]==3) {
#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
		      // if CONJG(P) is requested y=CONJG(P)*x <=> y=CONJG(P*CONJG(x))
		      if (conjp<0) {
			 w+=IPparam->ipar[27];
			 for (i=0; i<n; i++)
		             w[i].i=-w[i].i;
			 w-=IPparam->ipar[27];
		      } // end if
#endif
		      // if P^T is needed
		      if (transp) {
#ifdef _REAL_PREC_
			 // real preconditioner has to be applied twice
			 for (i=0; i<n; i++)
			     IPparam->dbuff[nbf+i]=w[IPparam->ipar[27]+i].r;
			 MYAMGDLSOL (PRE, IPparam, IPparam->dbuff+nbf,
				     IPparam->dbuff+nbf+n, IPparam->dbuff);
			 for (i=0; i<n; i++)
			     w[IPparam->ipar[28]+i].r=IPparam->dbuff[nbf+n+i];

			 for (i=0; i<n; i++)
			     IPparam->dbuff[nbf+i]=w[IPparam->ipar[27]+i].i;
			 MYAMGDLSOL (PRE, IPparam, IPparam->dbuff+nbf,
				     IPparam->dbuff+nbf+n, IPparam->dbuff);
			 for (i=0; i<n; i++)
			     w[IPparam->ipar[28]+i].i=IPparam->dbuff[nbf+n+i];
#else
			 MYAMGDLSOL (PRE, IPparam, w+IPparam->ipar[27],
				     w+IPparam->ipar[28], IPparam->dbuff);
#endif
		      }
		      else {
#ifdef _REAL_PREC_
			 // real preconditioner has to be applied twice
			 for (i=0; i<n; i++)
			     IPparam->dbuff[nbf+i]=w[IPparam->ipar[27]+i].r;
			 MYAMGTDUSOL(PRE, IPparam, IPparam->dbuff+nbf,
				     IPparam->dbuff+nbf+n, IPparam->dbuff);
			 for (i=0; i<n; i++)
			     w[IPparam->ipar[28]+i].r=IPparam->dbuff[nbf+n+i];

			 for (i=0; i<n; i++)
			     IPparam->dbuff[nbf+i]=w[IPparam->ipar[27]+i].i;
			 MYAMGTDUSOL(PRE, IPparam, IPparam->dbuff+nbf,
				     IPparam->dbuff+nbf+n, IPparam->dbuff);
			 for (i=0; i<n; i++)
			     w[IPparam->ipar[28]+i].i=IPparam->dbuff[nbf+n+i];
#else
			 MYAMGTDUSOL(PRE, IPparam, w+IPparam->ipar[27],
				     w+IPparam->ipar[28], IPparam->dbuff);
#endif
		      }
#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
		      // if CONJG(P) is requested
		      if (conjp<0) {
			 w+=IPparam->ipar[28];
			 for (i=0; i<n; i++)
		             w[i].i=-w[i].i;
			 w-=IPparam->ipar[28];
		      } // end if
#endif
		   } // end if
		   else {
		      i=1;
		      COPY(&n,w+IPparam->ipar[27],&i,w+IPparam->ipar[28],&i);
		   } // end else
		break;
	  case 10:   // call my own stopping test routine
	        break;
	  default:   // the iterative solver terminated with code=IPparam->ipar[20]
	        ierr=IPparam->ipar[20];
	        flag=0;
		break;
	  } // end switch
	  w++;
    } // end while
    // rescale solution and right hand side 
    for (i=0; i<n; i++) {
#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
        sol[i]*=rightscale[i];
        rhs[i]/=leftscale[i];
#else
#ifdef _REAL_PREC_
        sol[i].r*=rightscale[i];
        sol[i].i*=rightscale[i];
        rhs[i].r/=leftscale[i];
        rhs[i].i/=leftscale[i];
#else
	vb=sol[i].r;
	sol[i].r=vb*      rightscale[i].r-sol[i].i*conjp*rightscale[i].i;
	sol[i].i=vb*conjp*rightscale[i].i+sol[i].i*      rightscale[i].r;
	val=1.0/(leftscale[i].r*leftscale[i].r +
  	         leftscale[i].i*leftscale[i].i);
	vb=rhs[i].r;
	rhs[i].r=( vb*      leftscale[i].r+rhs[i].i*conjp*leftscale[i].i)*val;
	rhs[i].i=(-vb*conjp*leftscale[i].i+rhs[i].i*      leftscale[i].r)*val;
#endif
#endif
    } // end for i
    evaluate_time(&time_stop,&systime);

    // iteration time
    ILUPACK_secnds[5]=time_stop-time_start;
    // compute TOTAL time
    ILUPACK_secnds[8]=time_stop-ILUPACK_secnds[8];
    // average time for matrix-vector multiplication
    ILUPACK_secnds[6]=secndsAx/((double)nAx);

    // finally undo scaling
    r=PRE->rowscal;
    c=PRE->colscal;
    // adjust arrays
    ia=A->ia;
    ja=A->ja;
    a =A->a;
    ja--;
    a--;
    c--;
    for (i=0; i<A->nr; i++) {
        for (j=ia[i]; j<ia[i+1]; j++) {
	    k=ja[j];
#if defined _SINGLE_REAL_ || defined _DOUBLE_REAL_
	    a[j]/=r[i]*c[k];
#else
#ifdef _REAL_PREC_
	    a[j].r/=r[i]*c[k];
	    a[j].i/=r[i]*c[k];
#else
	    a[j].r/=r[i].r*c[k].r;
	    a[j].i/=r[i].r*c[k].r;
#endif	  
#endif	  
	}
    }
    return (ierr);

} // end AMGsolver
 
