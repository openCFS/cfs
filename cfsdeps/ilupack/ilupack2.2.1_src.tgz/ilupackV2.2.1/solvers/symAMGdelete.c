#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>


#include <ilupack.h>
#include <ilupackmacros.h>


//#define PRINT_INFO

#if defined _DOUBLE_REAL_ || defined _SINGLE_REAL_
#define CONJG(A)      (A)

#ifdef _DOUBLE_REAL_
#define MYSYMAMGDELETE       DSYMAMGdelete

#else
#define MYSYMAMGDELETE       SSYMAMGdelete
#endif



#else



#ifdef _COMPLEX_SYMMETRIC_
#define CONJG(A)     (A)

#ifdef _SINGLE_COMPLEX_
#define MYSYMAMGDELETE       CSYMAMGdelete
#else
#define MYSYMAMGDELETE       ZSYMAMGdelete
#endif

#else

#ifdef _SINGLE_COMPLEX_
#define CONJG(A)     (conjg(A))
#define MYSYMAMGDELETE       CHERAMGdelete
#else
#define CONJG(A)     (dconjg(A))
#define MYSYMAMGDELETE       ZHERAMGdelete
#endif

#endif



#endif



#define MAX_LINE        255
#define STDERR          stderr
#define STDOUT          stdout
#define MAX(A,B)        (((A)>(B))?(A):(B))
#define MIN(A,B)        (((A)<(B))?(A):(B))

// #define PRINT_INLINE





/*
  delete components of an existing multilevel ILU
*/
void MYSYMAMGDELETE(CSRMAT *A, AMGLEVELMAT *PRE, ILUPACKPARAM *IPparam)
{
/*
  A        input matrix, matrix is altered by the function
           diagonal scaling is directly applied to A
           only the diagonal part of A and its upper triangular part
           are stored
  PRE      Linked list of partial preconditioners
  nlev     number of levels(blocks)
  IPparam  ILUPACK parameter list

  Code written by Matthias Bollhoefer February 2005
*/


  integer lev, param, PILUCparam, nlev=PRE->nlev;
  AMGLEVELMAT *current, *prev;

  param  =IPparam->ipar[6];
  // buffer to store 'true' ipar[6] from the time of the factorization
  PILUCparam=IPparam->ipar[16];

  current=PRE;
  lev=0;
  while (lev<nlev) {
	lev++;
	if (lev<nlev)
	   current=current->next;
  } // end while
  // now "current" points to the last level

  while (lev) {
	/* give up row and column scaling */
	free(current->colscal);
	free(current->p);
	free(current->invq);
	
	// skip F (and E=F^T)
	if (lev<nlev) {
	  free(current->F.ia);
	  free(current->F.ja);
	  free(current->F.a);
	}
	if (current->absdiag!=NULL && current->LU.ja[0]<0)
	   free(current->absdiag);

	if (current->nextblock!=NULL)
	   free(current->nextblock);

	prev=current;
	current=current->prev;
	if (lev>1) {
 	   if (lev==nlev && prev->LU.ja==NULL) {
	     // do nothing, full matrix is not stored twice
	   }
	   else if (!(PILUCparam&DISCARD_MATRIX)) {
	      free(prev->A.ia);
	      free(prev->A.ja);
	      free(prev->A.a);
	   }
	   free(prev);
	}

	lev--;
  } /* end while */

  if (!(param&RE_FACTOR)) {
     free(IPparam->jlu);
     free(IPparam->alu);
     IPparam->nju=0;
     IPparam->njlu=0;
     IPparam->nalu=0;

     free(IPparam->ibuff);
     free(IPparam->dbuff);
     IPparam->nibuff=0;
     IPparam->ndbuff=0;
     if (IPparam->ntestvector>0) {
        free(IPparam->testvector);
        IPparam->ntestvector=0;
     }
     if (IPparam->nindicator>0) {
        free(IPparam->indicator);
        IPparam->nindicator=0;
     }
        
  }
  

} /* end symAMGdelete */


