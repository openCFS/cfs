#define _SYM_PREC_
#include "AMGsolver.c"
