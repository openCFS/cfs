#if !defined _DOUBLE_REAL_ && !defined _SINGLE_REAL_
#define _REAL_PREC_
#include "spdAMGsolver.c"
#else
void myilupackdummy13()
{
}
#endif
