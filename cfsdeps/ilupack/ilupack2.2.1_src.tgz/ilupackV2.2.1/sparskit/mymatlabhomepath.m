function p=mymatlabhomepath, p='/home/bolle/matlab';
