
/*****************************************************************************
   This include file is used for the ANSYS solution database objects.  The values
   in this file should match those found in ansysdef.inc.  Any changes should be
   included in both files
*****************************************************************************/


/***********  define database inquire constants   ************/
# define DB_SELECTED      1                  /* ansysdef.inc */
# define DB_NUMDEFINED    12                 /* ansysdef.inc */
# define DB_NUMSELECTED   13                 /* ansysdef.inc */
# define DB_MAXDEFINED    14                 /* ansysdef.inc */
# define DB_MAXRECLENG    15                 /* ansysdef.inc */
# define DB_OBJFLAG      -777                /* ansysdef.inc */
# define DB_NEXT         -888                /* ansysdef.inc */
# define DB_MODIFIED     -999                /* ansysdef.inc */
# define DB_INTERNAL     -9999               /* ansysdef.inc */

/***********  define element data constants       ************/
# define EL_DIM           10                 /* ansysdef.inc */
# define IELCSZ           200                /* echprm.inc   */
# define MAXLIB           300                /* echprm.inc   */

/***********  define some constants               ************/
# define BSEARCH_THRESH   8

/***********  define some material property constants  *******/
# define NLKWVAL          2                  /* ansysdef.inc */
# define NLKWMAX          12                 /* ansysdef.inc */
# define NLKWSIZE         NLKWVAL*NLKWMAX    /* ansysdef.inc */
# define NLPROP           80                 /* mpcom.inc    */
# define NAPROP           158                /* mpcom.inc    */

/***********  define some load constants          ************/
# define BODYLOAD_TEMP    1                  /* ansysdef.inc */
# define BODYLOAD_FLUE    2                  /* ansysdef.inc */
# define BODYLOAD_HGEN    3                  /* ansysdef.inc */
# define BODYLOAD_MOIS    4                  /* ansysdef.inc */
# define BODYLOAD_VDSP    5                  /* ansysdef.inc */
# define BODYLOAD_CHRG    6                  /* ansysdef.inc */
# define BODYLOAD_CURR    7                  /* ansysdef.inc */
# define BODYLOAD_VOLT    8                  /* ansysdef.inc */
# define BODYLOAD_EFLD    9                  /* ansysdef.inc */
# define BODYLOAD_MFLD    10                 /* ansysdef.inc */
# define BODYLOAD_PORT    11                 /* ansysdef.inc */
# define BODYLOAD_FVIN    12                 /* ansysdef.inc */
# define BODYLOAD_SRCE    13                 /* ansysdef.inc */
# define BODYLOAD_LUMP    14                 /* ansysdef.inc */
# define BODYLOAD_INIS    15                 /* ansysdef.inc */
# define BODYLOAD_RSHT    16                 /* ansysdef.inc */
# define BODYLOAD_HGIN    17                 /* ansysdef.inc */
# define BODYLOAD_FSOU    18                 /* ansysdef.inc */
# define BODYLOAD_FORC    19                 /* ansysdef.inc */
# define MAXBODYLOADTYPE  19                 /* ansysdef.inc */

# define SURFLOAD_PRES    1                  /* ansysdef.inc */
# define SURFLOAD_CONV    2                  /* ansysdef.inc */
# define SURFLOAD_IMPE    3                  /* ansysdef.inc */
# define SURFLOAD_MFLX    4                  /* ansysdef.inc */
# define SURFLOAD_FLGS    5                  /* ansysdef.inc */
# define SURFLOAD_CHRG    6                  /* ansysdef.inc */
# define SURFLOAD_PORT    7                  /* ansysdef.inc */
# define SURFLOAD_RADN    8                  /* ansysdef.inc */
# define SURFLOAD_FREE    9                  /* ansysdef.inc */
# define SURFLOAD_RADM    10                 /* ansysdef.inc */
# define SURFLOAD_SUPR    11                 /* ansysdef.inc */
# define SURFLOAD_COND    12                 /* ansysdef.inc */
# define SURFLOAD_FFLX    13                 /* ansysdef.inc */
# define MAXSURFLOADTYPE  13                 /* ansysdef.inc */

/***********  define some element result contants  ***********/
# define ELMRESULT_FORC   1                  /* ansysdef.inc */
# define ELMRESULT_EPEL   2                  /* ansysdef.inc */
# define ELMRESULT_EPPL   3                  /* ansysdef.inc */
# define ELMRESULT_EPCR   4                  /* ansysdef.inc */
# define ELMRESULT_EPTH   5                  /* ansysdef.inc */
# define ELMRESULT_EULR   6                  /* ansysdef.inc */
# define ELMRESULT_FLUX   7                  /* ansysdef.inc */
# define ELMRESULT_MSCS   8                  /* ansysdef.inc */
# define ELMRESULT_NONL   9                  /* ansysdef.inc */
# define ELMRESULT_MSCN   10                 /* ansysdef.inc */
# define ELMRESULT_ESTR   11                 /* ansysdef.inc */
# define ELMRESULT_HGEN   12                 /* ansysdef.inc */
# define ELMRESULT_CONT   13                 /* ansysdef.inc */
# define ELMRESULT_LOCI   14                 /* ansysdef.inc */
# define ELMRESULT_BSTR   15                 /* ansysdef.inc */
# define ELMRESULT_SVAR   16                 /* ansysdef.inc */
# define ELMRESULT_SSTR   17                 /* ansysdef.inc */
# define ELMRESULT_CURR   18                 /* ansysdef.inc */
# define ELMRESULT_TEMP   19                 /* ansysdef.inc */
# define ELMRESULT_NFOR   20                 /* ansysdef.inc */
# define ELMRESULT_ENGR   21                 /* ansysdef.inc */
# define ELMRESULT_GRAD   22                 /* ansysdef.inc */
# define ELMRESULT_NSTR   23                 /* ansysdef.inc */
# define ELMRESULT_DPAR   24                 /* ansysdef.inc */
# define MAXELMRESULTTYPE 24                 /* ansysdef.inc */

/***********  define MPI constants                 ***********/
# define MPI_NUMCPU       1                  /* ansysdef.inc */
# define MPI_THISCPU      2                  /* ansysdef.inc */
# define MPI_WORLD        3                  /* ansysdef.inc */
# define MPI_BUFFERSIZE   524288             /* ansysdef.inc */

/***********  define processor constants           ***********/
# define PPMAXPROC        64                    /* ppcom.inc */
# define MAX_NUMCPU       8192                 /* mpicom.inc */

/***********  define statistics constants          ***********/
# define STATLVLMAX       10             /* statTableCom.inc */
# define STAT_TOTAL       1                  /* ansysdef.inc */
# define STAT_PREP7       2                  /* ansysdef.inc */
# define STAT_SOLUTION    3                  /* ansysdef.inc */
# define STAT_POST1       4                  /* ansysdef.inc */
# define STAT_CHECK       5                  /* ansysdef.inc */
# define STAT_OBJECTS     6                  /* ansysdef.inc */
# define STAT_FORM        7                  /* ansysdef.inc */
# define STAT_SOLVER      8                  /* ansysdef.inc */
# define STAT_OUTPUT      9                  /* ansysdef.inc */
# define STAT_COMBINE     10                 /* ansysdef.inc */
# define STAT_LINESEARCH  11                 /* ansysdef.inc */
# define STAT_CONTACT     12                 /* ansysdef.inc */
# define STAT_CONVERGENCE 13                 /* ansysdef.inc */
# define STAT_GATHER      14                 /* ansysdef.inc */
# define STAT_ASSEMBLE    15                 /* ansysdef.inc */
# define STAT_PRECOND     16                 /* ansysdef.inc */
# define STAT_AMULTX      17                 /* ansysdef.inc */
# define STAT_PCSOLVE     18                 /* ansysdef.inc */
# define STAT_INPUTK      19                 /* ansysdef.inc */
# define STAT_ORDERK      20                 /* ansysdef.inc */
# define STAT_FACTORK     21                 /* ansysdef.inc */
# define STAT_SOLVEK      22                 /* ansysdef.inc */
# define STAT_DOMORDER    23                 /* ansysdef.inc */
# define STAT_TOTSOLVE    24                 /* ansysdef.inc */

/***********  define word sizes                    ***********/
#if defined(FULL_64)
# define BYTPINT           8                 /* syspar.inc   */
# define BYTPLONG          8                 /* syspar.inc   */
# define BYTPDP            8                 /* syspar.inc   */
#else
# define BYTPINT           4                 /* syspar.inc   */
# define BYTPLONG          8                 /* syspar.inc   */
# define BYTPDP            8                 /* syspar.inc   */
#endif

/***********  define sparse solver key array lengths  ********/
# define NUMINTKEYS       51                 /* ansysdef.inc */
# define NUMDPKEYS        21                 /* ansysdef.inc */

