/*******************************************************************************
 *
 *   connectivity.h  --- Prototypes for connectivity.c functions
 *               
 * 
 * |Module:  
 *
 * |Description: 
 *
 * |Includes:	
 *        
 * |Auteur: Jerome Margat
 *
 * |Creation: December 2003
 *
 * |Version: $Id: sx_connectivity.h,v 1.5 2010/04/16 20:11:11 srpailla Exp $
 *
 * |Copyright:	Copyright(c)  2010
 *
 ********************************************************************************/

#ifndef __SX_CONNECTIVITY_H
#define __SX_CONNECTIVITY_H 1

#ifdef __cplusplus
extern "C" {
#endif

extern IVEC *DdlToNode(IVEC *DdlToKeep, int *ier);
extern IVEC *NodeToDdl(IVEC *Nodes, int nbeq, int *ier);
extern IVEC *NodeToElem(IVEC *DdlToKeep, int *ier);
extern IVEC *NodeToElem01(IVEC *DdlToKeep, int *ier);
extern IVEC *DdlToElem(IVEC *DdlToKeep, int *ier);

extern IVEC *DdlWithDeplacementMax(int NbDdlToKeep,VEC *U, int *ier);
extern IVEC *DdlWithoutParam(T_modele *modele, int nbeq, int *ier);
extern IVEC *DdlWithParam(T_modele *modele, PAR *par, int iparam, double epsi, int NbElemMax, int nbeq, int *ier);
extern int   nb_vec(double prec, VEC *errmax_svd);
extern IVEC *getLoadedDdlFromFext(VEC* Fext, int NbDdlMax, int *ier);
extern IVEC *getLargestDdlFromFext(VEC *Fext, int NbDdlMax, int *ier);

extern void initConnectivity(T_modele* modele);
extern IVEC *getDdlFromNode(IVEC* nodes,int *ier);
extern IVEC *getDdlFromElem(T_modele *modele, IVEC *Elem, IVEC **Ddl01, int *ier);
extern IVEC *getNodeFromElem(T_modele* modele,IVEC* elements, int *ier);
extern void  getEntityFromDDL(T_modele* modele,IVEC* ddl,IVEC** nodes,IVEC** elements,IVEC** ddl_dispo,IVEC** ddl_incomplets, int *ier);
extern IVEC *getElemForCurrentParam(T_modele* modele, int *ier);
extern IVEC *getElemForParam(T_modele* modele, PAR *par, int ip, int *ier);
extern IVEC *getDdlForParam(T_modele *modele, PAR *par, int iparam, double epsi, T_statut FILTRE_SUPPRESSED, 
			    T_statut FILTRE_PRESCRIBED, int *ier);
extern IVEC *getDdlForParamConnex(T_modele *modele, PAR *par, int iparam, double epsi_param, T_statut FILTRE_SUPPRESSED, 
				  T_statut FILTRE_PRESCRIBED, int *ier);
extern void  getSupportParam01(T_modele *modele, PAR *par, VEC *variation, IVEC **ElemActif01, BVEC **DdlActive, 
			       T_statut FILTRE_SUPPRESSED, T_statut FILTRE_PRESCRIBED, int *ier);
extern void getSupportParamWithFext01(T_modele *modele, PAR *par, int iparam, VEC *Fext, IVEC **ElemActif01, IVEC **DdlActif01,
				      T_statut FILTRE_SUPPRESSED, T_statut FILTRE_PRESCRIBED, int *ier);
extern IVEC *SortDdlPerturbMax(T_modele *modele, PAR *par, IVEC *ListeParamActifs, VEC *epsi, IVEC *DdlToKeep, 
			       int CRITERE_SORT, int *ier);
extern IVEC *getDdlInactive(T_modele *modele, PAR *par, VEC *variation, VEC *epsi, int *ier);
extern IVEC *getActiveDdlFromFext(T_modele *modele, PAR *par, int iparam, double epsi, VEC *Fext, int *ier);
extern IVEC *getInactiveDdlFromFext(T_modele *modele, PAR *par, VEC *variation_in, VEC *epsi, VEC *Fext, int *ier);
extern IVEC *DdlToElem01(T_modele *modele, IVEC *DdlToKeep, int *ier);

extern void LM_iv_inter(IVEC* iv1,IVEC* iv2,IVEC** out, int *ier);
extern void LM_iv_fusion(IVEC* iv1,IVEC* iv2,IVEC** out, int *ier);

/*Other prototypes*/
extern void DistretiseHypercube(PAR *par, VEC *variation, int NbParametre, int NbPtsByParametre, VEC **PtsVerif, int ier);


/*Enum used to define the sort type that can be used on the dofs*/
enum E_TypeSortDdl
{
  E_NOSORT = 1,
  E_SORT_BY_EPS_MAX,
  E_SORT_BY_PERTURB_MAX
};


#ifdef __cplusplus
}
#endif

#endif				/* __CONNECTIVITY_H */
