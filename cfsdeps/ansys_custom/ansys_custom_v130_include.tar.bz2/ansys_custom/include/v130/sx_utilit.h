/* CADOE */
/*
 *  utilit.h
 *   
 *  Version: $Id: sx_utilit.h,v 1.3 2009/11/13 16:13:04 jtm Exp $
 *   
*/
#ifndef __UTILIT_X_DEJA_INCLUS__
#define __UTILIT_X_DEJA_INCLUS__ 1
#include "sx_CADOE_solver.h"
#include "chaine.h"
#include "erreur.h"

/*
#define	CADOEDEBUG(var, type)	printf(#var "= %" #type "\n", var)
#define IVDEBUG( var ) printf( #var "\n" ); iv_output( var )
#define VDEBUG( var )  printf( #var "\n" ); v_output( var )
#define MDEBUG( var )  printf( #var "\n" ); m_output( var )
*/

/* Gestion des messages */
#define MSG_INF_INT 1
#define MSG_INF_EXT 2
#define MSG_WARNING 3
#define MSG_ERREUR  4
#define AFF_FILE    5
#define AFF_SCREEN_FILE 6
#define MSG_TRACEBACK 7
#define AFF_LIST_WINDOW 7

/* definition de la fonction d'affichage des messages */

#ifdef __cplusplus
extern "C" {
#endif
  
  extern VEC * modif_geom(T_modele*, VEC * , int, int * );
  extern VEC **deriv_cs(T_modele *modele, VEC *vec_param, int ordre, IVEC **rabouge, int *ordre_donnees, int isVecParamAdomesh, int *ier);
  extern int extract_nb_par_shape( T_modele* );
  extern T_statut MSH_FiltreDxyz( VEC *);

/*    extern void FEM_set_on_code_affichage( int code ); */
  extern T_booleen FEM_is_on_code_affichage( int code ); 
/*    extern void FEM_set_off_code_affichage( int code ); */
  extern void FEM_message( int , const char *, int , const char *, ... );
/*    extern void FEM_trace_file( FILE* ); */
/*    extern void FEM_print_fct( T_fctaff fct ); */
/*    extern void FEM_print_warning_fct( T_fctaff fct ); */
/*    extern void FEM_print_error_fct( T_fctaff fct ); */

  extern void UTIL_set_unit_coef( double length, double forcePerLength, double force, double temperature, double tempOffset );
  extern double* UTIL_get_unit_array( T_booleen* );
  extern T_statut UTIL_retour_unite_utilisateur(double *valeur, int valeur_type_physique );
  extern double UTIL_coefficient(int valeur_type_physique );
  extern T_statut UTIL_utilisateur_to_SI(double *valeur, int valeur_type_physique );
  extern double UTIL_parametre_SI_2_user( int /*CParameter::Type*/ type, double* );
  extern T_statut calcule_coef_unite( int, double*, double* );
  extern void convert_CDC8(char *string);

#ifdef __cplusplus
}
#endif

#endif


