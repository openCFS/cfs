////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         copyright(c) 2008 SAS IP, Inc.  All rights reserved.             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: INIS_NodalData.h $
// $Revision: 1.5 $ 7.0
// $Date: 2009/11/13 16:19:04 $ October 04 2005
// $Author: jtm $ rjayasee
//
// Decription :
// Data at individual integration point.
//
////////////////////////////////////////////////////////////////////////////

#include "ANS_StandardIncludes.h"
#include "INIS_Object.h"
#include "INIS_DataCollection.h"

#ifndef INIS_NodalData_H
#define INIS_NodalData_H

class INIS_NodalData : public INIS_Object
{
    public:

    INIS_NodalData();
    //Constructor

    INIS_NodalData( INIS_NodalData const& );
    //Copy Constructor

    static INIS_NodalData* ConstructFromDoubleArray(DOUBLE* pDoubleArray, INT iStart, INT iSize) ;
    //Constructor

    ~INIS_NodalData();
    //Destructor

    bool WriteToHeader( DOUBLE* pDoubleArray ) ;
    //R
    //I pDoubleArray
    //- Write the Element Data Header To Double Array

    bool ReadFromHeader( DOUBLE* pDoubleArray ) ;
    //R
    //I pDoubleArray
    //- Read the Element Data Header from a Double Array

    INT GetWrittenDoubleArraySize() ;
    //Get DB Format Array Size
    
    bool WriteToDoubleArray( DOUBLE* pISData, INT iPos, INT iSz, INT& iWrittenSz ) ;
    //R Status
    //I pISData
    //I-Double Array to be written to
    //I iPos
    //I Starting Pos of write
    //I iSz
    //I Size for total Array
    //0 iWrittenSz
    //O-Written Array Size

    bool SetData( INT* pPar, INT iNumPar,
                  DOUBLE* pData, INT iDataSize, INT iDataType ) ;
    //R Result
    //I pPar
    //I-Parameters
    //I iNumPar
    //I Num Parameters
    //I pData
    //I iDataSize
    //- Sets Initial State Data

    INT m_iTotalDataSize ;
    INT m_iDataFormat ;
    INT m_iHeaderSize ;
    INT m_iDataSource ;
    INIS_DataCollection* m_pDataCollection ;
} ;

#endif

