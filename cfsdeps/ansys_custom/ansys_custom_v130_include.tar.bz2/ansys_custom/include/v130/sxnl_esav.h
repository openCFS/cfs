////////////////////////////////////////////////////////////////////////////
//                                                                        //
//          copyright(c) 2010 SAS IP, Inc.  All rights reserved.            //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: sxnl_esav.h $
// $Revision: 1.9 $Id: 
// $Date: 2010/04/16 19:55:07 $
// $Author: srpailla $ Emmanuel Delor
//
// Decription: 
//
////////////////////////////////////////////////////////////////////////////


#ifndef __SXNL_ESAV_H__
#define __SXNL_ESAV_H__ 1

#include <stdio.h> 
#include <stdlib.h> 
#include "computer.h" 
#include "globals.h" 
#include "sysparh.h" 
#include "cadoe.h" 
#include "cadoe_map.h"
#include "C_VecPi.h"

#if defined(LOWERCASENOUNDER_SYS)
#define eosave			eosave
#define OsavRestore		osavrestore
#define saveEsav		saveesav
#define restoreEsav		restoreesav
#endif

#if defined(UPPERCASENOUNDER_SYS)
#define eosave			EOSAVE
#define OsavRestore		OSAVRESTORE
#define saveEsav		SAVEESAV
#define restoreEsav		RESTOREESAV
#endif

#if defined(LOWERCASEUNDER_SYS)
#define eosave			eosave_
#define OsavRestore		osavrestore_
#define saveEsav		saveesav_
#define restoreEsav		restoreesav_
#endif

extern "C"
{
  SUBROUTINE eosave();
  SUBROUTINE OsavRestore();
  
  SUBROUTINE saveEsav(char *nameFile, int *unit);
  SUBROUTINE restoreEsav(char *nameFile, int *unit);
}

//-----------------------------------------------------------------
class C_EsavState
//-----------------------------------------------------------------
{
public:
  C_EsavState();
  ~C_EsavState();

  static int S_unit [100];
  
  int save();
  int restore();
  
protected:
  string _nameFile;
  int	 _unit;
  
  C_VecPi<double> _UPrev;
  C_VecPi<double> _UInci;
  C_VecPi<double> _UIncn;
};

#endif
