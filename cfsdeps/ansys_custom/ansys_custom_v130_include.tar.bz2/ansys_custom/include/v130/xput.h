/* ANSI_C xput.h - "xput" interface */

/*--------------------------------------------------------------------------*/
/* copyright(c) 2010 SAS IP, Inc.  All rights reserved. */
/* ansys, inc.                */
/*--------------------------------------------------------------------------*/

/* NOTE:
 *
 * Be advised that this is only a TEMPORARY replacement for the old putXXX
 * FORTRAN functions.  It is handling NURBS only, and will never do more.
 *
 * The functions are ANSYS FORTRAN callable; all parameters are by reference
 */

/*--------------------------------------------------------------------------*/

#ifndef __XPUT_H__  /* Include this file only once! */
#define __XPUT_H__

#ifdef __cplusplus
extern "C" {
#endif

/*--------------------------------------------------------------------------*/

/* Get ANSYS' *_SYS switches, ... VOID, CALLTYP, INT, and DOUBLE */

#include "computer.h"
#include "globals.h"

/*--------------------------------------------------------------------------*/

/* Select proper FORTRAN object-file identifiers */

#if defined(UPCASE_SYS)

#define xputbgn   XPUTBGN
#define xputend   XPUTEND
#define xputkpt   XPUTKPT
#define xputbsc   XPUTBSC
#define xputbss   XPUTBSS
#define xputvlm   XPUTVLM

#define xput_xanf XPUT_XANF
#define xx_aux_   XX_AUX

#elif defined(NOUNDER_SYS)

#define xputbgn   xputbgn
#define xputend   xputend
#define xputkpt   xputkpt
#define xputbsc   xputbsc
#define xputbss   xputbss
#define xputvlm   xputvlm

#define xput_xanf xput_xanf
#define xx_aux_   xx_aux

#else

#define xputbgn   xputbgn_
#define xputend   xputend_
#define xputkpt   xputkpt_
#define xputbsc   xputbsc_
#define xputbss   xputbss_
#define xputvlm   xputvlm_

#define xput_xanf xput_xanf_
#define xx_aux_   xx_aux_

#endif

/*--------------------------------------------------------------------------*/

VOID CALLTYP xputbgn (
                      INT *kerr     /* out: nonzero for error */
                      );
     /* xput initialization */

/*--------------------------------------------------------------------------*/

VOID CALLTYP xputend (
                      INT *kerr       /* out: nonzero for error */
                      );
     /* xput shutdown */

/*--------------------------------------------------------------------------*/

VOID CALLTYP xputpro (
                      INT *icode,     /* 1 process and transfer model to ANSYS
                                         2 peform some model validation
                                         3 save model to 'file.model'
                                         */
                      INT *kerr       /* out: nonzero for error */
                    );

/*--------------------------------------------------------------------------*/

VOID CALLTYP xputkpt (
                      INT *kpoin,     /* inout: 0 or ANSYS id */
                      DOUBLE *xyzd,   /* in: coordinates array(3) */
                      INT *kcrot,     /* in: local coordinate system */
                      INT *kerr       /* out: nonzero for error */
                      );
     /* putkpt replacement
      * restriction: kcrot == 0
      */

/*--------------------------------------------------------------------------*/

VOID CALLTYP xputbsc (
                      INT *lnum,      /* inout: 0 or ANSYS id */
                      INT *kp1,       /* in: 1st keypoint ANSYS id */
                      INT *kp2,       /* in: 2nd keypoint ANSYS id */
                      INT *ncur,      /* in: curve control info, array(16) */
                      DOUBLE *s1,     /* in: 1st parameter value */
                      DOUBLE *s2,     /* in: 2nd parameter value */
                      DOUBLE *cur,    /* in: curve data, array(*) */
                      INT *kerr       /* out: nonzero for error */
                      );
     /* putbsc replacement
      * restriction: *s1 == 0.0, *s2 == 1.0
      * for a description of the ncur and cur arrays see putbsc.F
      * ... and ANSYS doucmentation
      */

/*--------------------------------------------------------------------------*/

VOID CALLTYP xputbss (
                      INT *anum,   /* inout: o or ANSYS id */
                      INT *nlmax,  /* in: max.num.of lines in a loop */
                      INT *nloop,  /* in: number of loops */
                      INT *lsg,    /* in: loops, array(nlmax,nloop) */
                      INT *nsur,   /* in: surf control, array(24) */
                      DOUBLE *sur, /* in: surf data, array(*) */
                      INT *itree,  /* in: loop tree, array(nloop)  */
                      INT *kerr    /* out: nonzero for error */
                      );
     /* putbsc replacement
      * restriction: itree array is ignored
      * for a description of the nsur and sur arrays see putbss.F
      * ... and ANSYS doucmentation
      */

/*--------------------------------------------------------------------------*/

VOID CALLTYP xputvlm (
                      INT *vnum,   /* inout: 0 or ANSYS id */
                      INT *narv,   /* in: max.num of areas in a shell */
                      INT *nshell, /* in: number of shells */
                      INT *arv,    /* in: area list */
                      INT *itree,  /* in: shell tree */
                      INT *kerr    /* out: nonzero for error */
                      );
     /* putvlm replacement
      * restriction: itree array is ignored */

/*--------------------------------------------------------------------------*/

void xputbgn_opt (char *string);  /* C callable only! */
void xputbgn_txt (char *string);

/*--------------------------------------------------------------------------*/

void xput_xanf_c_opt (const char *user_options);

void xput_xanf_c (const char *fname);  /* C callable version of xput_xanf
                                          (Sorry about the naming :) */

/*--------------------------------------------------------------------------*/

VOID CALLTYP xput_xanf (INT *code, INT *istring);
    /* This is called from aux15.F for the 'XANF' undocumented command.
       code == 1 ... actual command
       code == 0 ... pass option string
       (the latter is optional, but MUST PRECEED xput_anf (1, ...) */

/*--------------------------------------------------------------------------*/

VOID CALLTYP xx_aux_ (INT *icode);  /* see xx_aux.F */

/*--------------------------------------------------------------------------*/

#if defined(__cplusplus)
}
#endif

#endif  /* #ifdef __XPUT_H__ */
