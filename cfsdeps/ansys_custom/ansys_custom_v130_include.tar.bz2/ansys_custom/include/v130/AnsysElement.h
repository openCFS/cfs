/*****************************************************************************
 *                   Copyright (C) 1999 CMSoft                               *
 *                                                                           *
 *  These lines of code and declarations contain unpublished proprietary     *
 *  information of CMSoft. They may not be copied or duplicated in whole     *
 *  or part without prior authorization from CMSoft.                         *
 *                                                                           *
 *****************************************************************************/
#ifndef _ANSYS_ELEM_H_
#define _ANSYS_ELEM_H_

#include <stdio.h>
#include "FSElement.h"
#include "dofset.h"

class FullSquareMatrix;

#define MAXNNODES 250

class AnsysElement : public FSElement {
   int eleNum;
   int _type, tInfo;
   int numnodes;
   int numNZnodes;
   int nd[MAXNNODES];
   DofSet dofFlags;
 public:
  AnsysElement() {}
   AnsysElement(int iele, int _type, int tI,
		int nnodes, int *nodes, int dofFlags);
  
   void setNumNodes(int nnodes);
   void setNodes(int nnodes, int *nodes);
   
   FullSquareMatrix stiffness(double *v, double *f);
   void renum(int *);

   int    numDofs();
   void   markDofs(DofSetArray &);
   int*   dofs(DofSetArray &, int *p=0);

   int    numNodes();
   int    nodes(int * = 0);
   void dumpTop(FILE *outFile);
   int buffer(int *);
  
   int getIndice();
   int type();
   int prType();
   bool isContact();
  
   void Send(int iCPU, int *Back = NULL);
   void Recv(int iCPU, int *Forward = NULL);
};

#endif
