/*
 *    author/date: yu-hua ting/03-01-94
 *
 *    primary function:
 *
 *       Header for the setup routines for initialization and termination.
 *
 *    secondary function:
 *
 *        none
 *
 *    routines included:
 *
 *
 *    history
 *
 *        none
 *
 *    comments:
 *
 *        none
 *
 *    Notice - This file contains ANSYS Confidential information ***
 *
 */
/* 
 * *** copyright(c) 2010 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */



 
/****************************************************************************
 *    Set the Shapes/xox print mode                                         *
 ****************************************************************************/

 
      extern VOID xShapesSetStatusPrintMode_xax ansPROTO((
             xINT level,        /* I    verbosity of output
                                 *      == 1 (xcSTATUS_PRINT_MIN)   -
                                 *            prints out information about the code, the
                                 *            descriptions and the function generating the
                                 *            status. This is the default.
                                 *      == 2 (xcSTATUS_PRINT_DEBUG) - 
                                 *            prints out verbose information for each object.
                                 *            Where possible, prints out interpretation of
                                 *            auxiliary data associated with the objects        */
             xINT numElements,  /* I    depth of stack to print. This determines the depth of
                                 *      of the status stack that is printed. Setting this to 0
                                 *      essentially turns off printing. A negative value implies
                                 *      that the entire stack will be printed                   */
             CHAR *errFile,     /* I    errFile to which output about errors should be directed.
                                 *      If errFILE == NULL, no errors are printed.              */
             CHAR *warnFile,    /* I    warnFile to which output about warnings should be directed. 
                                 *      If warnFILE == NULL, no warnings are printed.           */
             INT  *iretp));     /*   O  error code
                                 *      == 0 - no error
                                 *      != 0 - error                                            */

 
/****************************************************************************
 *    Set the Shapes/xox warning mode                                       *
 ****************************************************************************/

 
      extern VOID xShapesSetWarnMode_xax ansPROTO((
             xINT mode,         /* I    warning generation mode.
                                 *      != 0 - it enables the generation of warnings.
                                 *             This is the default                 
                                 *      == 0 - warnings will be suppressed until a
                                 *             subsequent call to this function to
                                 *             enable warning.                       */
             INT  *iretp));     /*   O  error code
                                 *      == 0 - no error
                                 *      != 0 - error                                 */


 
/****************************************************************************
 *    Start Ansys/Shapes Interface Log facility                             *
 ****************************************************************************/
 
 
      extern VOID xStartLog_xax ansPROTO((
             CHAR *filename,    /* I    Ansys/Shapes Interface LOG file name       */
             INT  *iretp));     /*   O  error code
                                 *      == 0 - no error
                                 *      != 0 - error                               */



/****************************************************************************
 *    End Ansys/Shapes Interface Log facility                               *
 ****************************************************************************/


      extern VOID xEndLog_xax ansPROTO((
             INT  *iretp));     /*   O  error code
                                 *      == 0 - no error
                                 *      != 0 - error                               */



/*
 *    Read the information from Ansys Common blocks for the initialization
 */
      extern VOID xReadAnsysCommons_xax ansPROTO(());
 
/*
 *    Signal handlers set up
 */
   

      extern VOID xSignalHandlerSet_xax ansPROTO(());
 
/*
 *    Signal handlers Reset
 */
   

      extern VOID xSignalHandlerReSet_xax ansPROTO(());
 
/*
 *    Boolean tolerance parameters set up
 */
  
 
      extern VOID xBooleanTolerancesSet_xax ansPROTO((
             INT  *iretp));     /*   O  error code
                                 *      == 0 - no error
                                 *      != 0 - error                               */

 
/*
 *    Loop splitting mode set up
 */
  
 
      extern VOID xLoopSplittingModeSet_xax ansPROTO((
             INT  *iretp));     /*   O  error code
                                 *      == 0 - no error
                                 *      != 0 - error                               */


/*
 *    Set up the scaling factors
 */
      extern VOID xScaleTranslationSet_xax ansPROTO(());

 
/*
 *    Set up the shapes/xox detectation of non-manifold
 */
      extern VOID xShapesDetectNonManifoldSet_xax ansPROTO(());


 
/*
 *    UserIds set up
 */
  
 
      extern VOID xUserIdsSet_xax ansPROTO((
             INT  *iretp));     /*   O  error code
                                 *      == 0 - no error
                                 *      != 0 - error                               */


 
/*
 *    Shapes Graphics Initialization
 */
  
  
      extern VOID xShapesGraphicsInit_xax ansPROTO((
             INT  *iretp));     /*   O  error code
                                 *      == 0 - no error
                                 *      != 0 - error                               */
 
 
/*
 *    Shapes Graphics Close
 */
  
  
      extern VOID xShapesGraphicsClose_xax ansPROTO((
             INT  *iretp));     /*   O  error code
                                 *      == 0 - no error
                                 *      != 0 - error                               */
 
 

/*
 *    Memory and timing usages set up  for intersection curve approximation
 */
 
 
      extern VOID xApproxIntersectionUsage_xax ansPROTO(());

 
/*
 *    Collect memory usage for intersection curve approximation
 */
  

      extern VOID xApproxIntersectionMemory_xax ansPROTO(());

 


 
/*
 *    Collect timing usage for intersection curve approximation
 */
 
 
      extern VOID xApproxIntersectionTime_xax ansPROTO(());
