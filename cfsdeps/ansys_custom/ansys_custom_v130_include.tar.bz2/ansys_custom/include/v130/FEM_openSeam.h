#ifndef __OPEN_SEAM_H_
#define __OPEN_SEAM_H_

#include "FEM_cdbtypes.h"
#include "FEM_Public.h"
#include "FEM_periodic.h"
#include <vector>
#include <algorithm>
#include "FEM_model.h"
#include "FEM_lnMeshData.h"
#include "FEM_aeMeshData.h"
#include "FEM_vlMeshData.h"


class COpenSeamLoop
{
private:
    INT m_iLoopId;
    std::vector<EDGE_OBJ> m_cLoopEdges;
    std::vector<NODE_OBJ> m_cLoopNodes;
    
public:
    COpenSeamLoop();
    ~COpenSeamLoop();
    INT splitLoop();
    INT mergeInOneLoop( COpenSeamLoop &cLoop );
    INT addOneEdge( EDGE_OBJ obj_edge );
    INT removeOneEdge( EDGE_OBJ obj_edge );
};

class COpenSeam 
{
public: // make it temp public
    INT m_iAreaId; // the area this seam open is operate
    SEAM_DIR m_eSeamDir;  // the dir of the surface closed. e.g., if a cyl is closed on U dir, the seamDir=U
    DOUBLE m_dRange[2];// [0]--min, [1]--max
    DOUBLE m_dTT;      // TT=range[1]-range[0] 
    //EDGE_OBJ xEdges[2]; // an area might have many seams (like a spring shape). Each time
                        // only one section is handled. Each section might have up to 2 cross edges.
    //NODE_OBJ endNodes[2][2]; // end nodes of a seam [0][] lower end, [1][] higher end, wrt param value
                             //[][0] -- the original node, [][1] -- duplicated node
    FEM_BOOLEAN m_bIsSeamEdgeNegOriented; // when a seam edge is created, we need make sure its orient correct
    //EDGE_OBJ aobj_edgeChians[2]; // start edges on lower and higher edge chains -- cylinder has two chains
    //NODE_OBJ aobj_nodeChinas[2]; // start nodes on lower and higher node chains -- cylinder has two chains
    DOUBLE m_dEdgeTol; // = 0.55 * dDiffParam;   dDiffParam    = fabs( range[1]-range[0]); // paramMax - paramMin;
    DOUBLE m_dCloseTol; // = dDiffParam * 0.0001;
    INT m_iNumLoops;
    INT m_iNumExtLoops;
    INT m_iNumIntLoops;
    FEM_BOOLEAN m_bInitialized;



    DOUBLE m_ranges[2][2];
    DOUBLE m_TT[2];

private:
    // not sure I want these array and lists -- for tmp use for now
    std::vector<EDGE_OBJ> m_cExtEdgeList; // external loop edge list
    EDGE_OBJ *m_aobj_bndEdges; // all the bnd edges 
    INT m_iNumBndEdges;
    INT *m_piBndEdgeDir; // all bnd edge dirs 
    AREAMSHDAT_PTYP m_pcMshArea;
    AREA_PTYP m_pcGeoArea;

public:
    COpenSeam();
    ~COpenSeam();
    INT init();
    INT init( INT areaId, SEAM_DIR seamDir );
    void setAreaId( INT areaId ) { this->m_iAreaId = areaId; };
    INT initArea( INT areaId );
    INT initSeamDir( SEAM_DIR seamDir );
    INT getAreaParamRange();
    INT moveNonManifoldEdges( FEM_BOOLEAN &bMoved );
    INT setNodeParam( NODE_OBJ obj_node, DOUBLE param );
    DOUBLE getNodeParam( NODE_OBJ obj_node );
    DOUBLE getEdgeUvDiff( EDGE_OBJ obj_edge );
    INT tryShiftSeamOut(INT &iDid);
    INT shiftBack(); // to put nodes in correct range
    NODE_OBJ FEM_edGetTailNode( EDGE_OBJ obj_edge );
    INT setEdgeMidNodeUv( EDGE_OBJ obj_edge );
    INT putOneNodeIntoAreaUvRange( NODE_OBJ obj_node, DOUBLE ranges[2][2] );

public:
    // not sure I want these functions -- they related to temp member var
    INT setupBndEdges();
    EDGE_OBJ FEM_noGetNextBndEdge( NODE_OBJ obj_node, EDGE_OBJ obj_edge );
    FEM_BOOLEAN isBndEdge( EDGE_OBJ obj_edge );
    FEM_BOOLEAN couldLoopOpenByShift(std::vector<EDGE_OBJ> &cOneLoopEdgeList);
    INT getMinUvNodeOnLoop( std::vector<EDGE_OBJ> &cOneLoopEdgeList, NODE_OBJ &obj_minNode );
    INT getShortestExtUvEdgeOnLowerHalf( EDGE_OBJ &obj_minEdge );
    FEM_BOOLEAN hasLoopEdgeCrossSeam(std::vector<EDGE_OBJ> &cOneLoopEdgeList);
    INT shiftExternalLoop( INT &iShifted );
    INT shiftInternalLoops();
    INT debug_qqq(INT status);
    INT shiftOneLoop( std::vector<EDGE_OBJ> &cOneLoopEdgeList, INT &iShifted );
    void moveSeamEdgeToLowSide( INT iNumEdges, EDGE_OBJ *aobj_edges );
    INT setupExtLoopEdgeList( INT &iNumExtEdgeloops);
    void removeOneEdgeFromExternalLoopEdgeList( EDGE_OBJ obj_edge );
    INT updateBndRecord() { return setupBndEdges(); };
    INT getNumEdgesCrossSeam( INT &iNumX, SEAM_DIR eSeamDir  );
};

#endif