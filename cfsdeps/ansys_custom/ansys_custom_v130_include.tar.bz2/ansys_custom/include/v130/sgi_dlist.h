/* define display list data structures */
/* 
 * *** copyright(c) 2010 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */

typedef struct {
        double  x, y, z;
} GPxyz;

typedef struct ch {
        char      *data1, *data2, *data3, *data4;
        struct ch *prev, *next;
        int       n;
        char      flag;
} chunk;

#if !defined(PCWINNT_SYS)
   void dl_init();
   void dl_open();
   void dl_delete();
   void dl_renew();
   static chunk *nextchunk();
   void dl_coord();
   void dl_text();
   void dl_area();
   void dl_line();
   void dl_attr();
   void dl_datt();
   void dl_cntr();
   void dl_datm();
   void dl_ldmp();
   void dl_tristrip();
   void dl_trifan();
   void dl_getminmax();
#if defined(SOLARIS_SYS) && !defined(USPARC_SYS)
#define  dl_init     dl_init_
#define  dl_open     dl_open_
#define  dl_delete   dl_delete_
#define  dl_renew    dl_renew_
#define  dl_coord    dl_coord_
#define  dl_text     dl_text_
#define  dl_area     dl_area_
#define  dl_line     dl_line_
#define  dl_attr     dl_attr_
#define  dl_datt     dl_datt_
#define  dl_cntr     dl_cntr_
#define  dl_datm     dl_datm_
#define  dl_ldmp     dl_ldmp_
#define  dl_tristrip dl_tristrip_
#define  dl_trifan   dl_trifan_
#define  dl_getminmax   dl_getminmax_
#endif
#else
   void dl_init( void );
   void dl_open( int * );
   void dl_delete( int *);
   void dl_renew( int*, int* );
   static chunk *nextchunk( void );
   void dl_coord( int*, double [] );
   void dl_text( int*, double [], int*, int[] );
   void dl_area( double *, int*, double *, int*, double *,
                 int*, int* );
   void dl_line( int*, int*, double * );
   void dl_attr( int*, int* );
   void dl_datt( int*, double* );
   void dl_cntr( int*, double [] );
   void dl_datm( int*, double [], int* );
   void dl_ldmp( int*, int*, int*, double*, int* );
   void dl_tristrip ( int *, double *, double *, int *);
   void dl_trifan ( int *, double *, double *, int *);
   void dl_getminmax ( double *, double *);

#endif


