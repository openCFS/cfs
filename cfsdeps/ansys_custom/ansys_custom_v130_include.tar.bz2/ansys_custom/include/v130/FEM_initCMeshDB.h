/*  FEM_initCMeshDB.h */
/*
 * *** copyright(c) 2010 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_initCMeshDB.h
 *  header file for FEM_initCMeshDB.c
 *
 */
#ifndef FEM_INITCMESHDB_INCLUDE
#define FEM_INITCMESHDB_INCLUDE

/*----------------- Globally accessible function prototypes -----------------*/

                       /*=================================================== */
                       /* === FEM_coInitCMeshDB: Initialize the C mesh       */
                       /* === data base and the node hash table based on     */
                       /* === given number of nodes and element information  */
                       /* === Return: INT  EXIT_SUCCESS or EXIT_FAILURE      */
                       /*=================================================== */
INT FEM_initAreaCMeshDB (
   INT num_nodes,      /* (IN) number of nodes                               */
   DOUBLE *a_coord,    /* (IN) current node coodinates (3*num_nodes)         */
   INT *a_geo_assoc,   /* (IN) geometry associativity  (num_nodes)           */
   INT *a_geo_types,   /* (IN) geo type 0= point, 1=line, 2=area (num_nodes) */
   INT num_elements,   /* (IN) number of elements                            */
   INT node_per_elem,  /* (IN) number nodes per element                      */
   INT *a_elements,    /* (IN) element list (node_per_elem, num_elements)    */
   INT *a_elem_shape); /* (IN) element shape (num_elements)                  */
                       /*=================================================== */

                       /*=================================================== */
                       /* === FEM_coInitDetachedCMeshDB: Initialize the C    */
					   /* === mesh data base and the node hash table based   */
                       /* === on given number of nodes and element           */
                       /* === information                                    */
                       /* === Return: INT  EXIT_SUCCESS or EXIT_FAILURE      */
                       /*=================================================== */
INT FEM_initDetachedAreaCMeshDB (
   INT num_nodes,      /* (IN) number of nodes                               */
   DOUBLE *a_coord,    /* (IN) current node coodinates (3*num_nodes)         */
   INT num_elements,   /* (IN) number of elements                            */
   INT node_per_elem,  /* (IN) number nodes per element                      */
   INT *a_elements,    /* (IN) element list (node_per_elem, num_elements)    */
   INT *a_elem_shape); /* (IN) element shape (num_elements)                  */
                       /*=================================================== */

                       /*=================================================== */
                       /* === FEM_coInitCMeshDB: Initialize the C mesh       */
                       /* === data base and the node hash table based on     */
                       /* === given number of nodes and element information  */
                       /* === Return: INT  EXIT_SUCCESS or EXIT_FAILURE      */
                       /*=================================================== */
INT FEM_initVolCMeshDB (
   INT num_nodes,      /* (IN) number of nodes                               */
   DOUBLE *a_coord,    /* (IN) current node coodinates (3*num_nodes)         */
   INT *a_geo_assoc,   /* (IN) geometry associativity  (num_nodes)           */
   INT *a_geo_types,   /* (IN) geo type 0= point, 1=line, 2=area (num_nodes) */
   INT num_elements,   /* (IN) number of elements                            */
   INT node_per_elem,  /* (IN) number nodes per element                      */
   INT *a_elements,    /* (IN) element list (node_per_elem, num_elements)    */
   INT *a_elem_shape); /* (IN) element shape (num_elements)                  */
                       /*=================================================== */

                       /*=================================================== */
                       /* === FEM_coInitDetachedCMeshDB: Initialize the C    */
                       /* === mesh data base and the node hash table based   */
                       /* === on given number of nodes and element           */
                       /* === information                                    */
                       /* === Return: INT  EXIT_SUCCESS or EXIT_FAILURE      */
                       /*=================================================== */
INT FEM_initDetachedVolCMeshDB (
   INT num_nodes,      /* (IN) number of nodes                               */
   DOUBLE *a_coord,    /* (IN) current node coodinates (3*num_nodes)         */
   INT num_elements,   /* (IN) number of elements                            */
   INT node_per_elem,  /* (IN) number nodes per element                      */
   INT *a_elements,    /* (IN) element list (node_per_elem, num_elements)    */
   INT *a_elem_shape); /* (IN) element shape (num_elements)                  */
                       /*=================================================== */

#endif

