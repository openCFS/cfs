/*
 *    author/date: yu-hua ting/02-18-94
 *
 *    primary function:
 *
 *        header for the ANSYS/SHAPES interface main sources 
 *
 *    secondary function:
 *
 *        none
 *
 *    routines included:
 *
 *        none
 *
 *    history
 *
 *        none
 *
 *    comments:
 *
 *        none
 *
 *    Notice - This file contains ANSYS Confidential information ***
 *
 */
/* 
 * *** copyright(c) 2010 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */

/*
 * delete "static" in order to look at the static variables inside "dbx"
 */

#ifndef SYSTEM_SIGNAL_H
#  define SYSTEM_SIGNAL_H
#  include <signal.h>
#endif

#ifndef SYSTEM_SETJMP_H
#  define SYSTEM_SETJMP_H
#  include <setjmp.h>
#endif
 


#include "ansys.h"
#include "sccsdef.h"
#include "shapesge.h"
#include "xoxansys.h"
#include "xoxgeome.h"

#define static
/*
#define xTrimGeomFramesA(A,B,C) A
 */
#include "xbsymbol.h"
#include "xberror.h"

#include "xbtype.h"
#include "xbglobal.h"

#include "xbheapm.h"
#include "xbdynm.h"
#include "xberrhdl.h"
#include "xbdbase.h"
#include "xbf77.h"
#include "xbansys.h"

#include "xxconv.h"
#include "xxlist.h"
#include "xxvert.h"
#include "xxquery.h"
#include "xxattr.h"
#include "xxuserid.h"
#include "xxorien.h"
#include "xxnurbs.h"
#include "xbnurbs.h"
#include "xxframe.h"
#include "xxbound.h"
#include "xxbool.h"
 
#include "xbbool.h"

#include "xxgeom.h"

#include "xbutil.h"
#include "xbshape.h"

#include "xxsetup.h"

#include "xbattr.h"
#include "xbsetup.h"
#include "xbconv.h"
#include "xbexport.h"

#include "xoxprim.h"
#include "xx_toansys.h"
