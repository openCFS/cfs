/*******************************************************************************
 *
 *   sx_cadoeglobal.h  --- CADOE global variables management
 *               
 * 
 * |Module: SX
 *
 * |Description: Global variables management routines
 *
 * |Includes:	
 *        
 * |Auteur: Stephane Marguerin
 *
 * |Creation: December 2002
 *
 * |Version: $Id: sx_cadoeglobal.h,v 1.4 2009/11/13 16:19:07 jtm Exp $
 *
 * |Copyright:	Copyright(c)  2002
 *
 ********************************************************************************/
#ifndef __sx_cadoeglobal_h__
#define __sx_cadoeglobal_h__ 1

#ifdef __cplusplus
extern "C" {
#endif

  T_statut GLOB_InitCadoeGlobal( void );
  T_statut GLOB_FreeCadoeGlobal( void );



  void GLOB_SetModele( T_modele *modele );
  T_modele* GLOB_GetModele( void );

  void GLOB_SetDerModele( T_der_modele *der_modele );
  T_der_modele* GLOB_GetDerModele( void );

  void GLOB_SetPar( PAR *par );
  PAR * GLOB_GetPar( void );

  void GLOB_SetParUtilisateur( PAR *par_u );
  PAR * GLOB_GetParUtilisateur( void );

  void GLOB_SetNbParPhys( int NbParPhys );
  int GLOB_GetNbParPhys( void );

#ifdef __cplusplus
}
#endif

#endif /* __sx_cadoeglobal_h__ */
