/****************************************************************************
 w32h.h

 The DC module handles setting and reading of the DC attributes.

****************************************************************************/
/* 
 * *** copyright(c) 2010 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */


/****************************************************************************
   Types
****************************************************************************/

/* Values needed to setup a DC */
typedef struct
{
   short    mapMode;
   POINT    windowOrg;
   POINT    windowExt;
   POINT    viewportOrg;
   POINT    viewportExt;

   POINT    penPos;
   POINT    brushOrg;

   BOOL     intersect;
   RECT     rIntersect;
   BOOL     exclude;
   RECT     rExclude;

   COLORREF bkColor;
   short    bkMode;

   LOGFONT  fontLarge;
   LOGFONT  fontSmall;
   LOGFONT  fontAnnot;
   LOGFONT  fontUserL;
   WORD     textAlign;
   short    breakExtra;
   short    breakCount;
   short    textExtra;
   COLORREF textColor;

   short    rop2;
   short    polyFillMode;
   short    bltMode;

   BYTE     patChecks[64];   /* treated as array of boolean, TRUE => 0 bit */

   /* Handles */
   HFONT    hFontLarge;
   HFONT    hFontSmall;
   HFONT    hFontAnnot;
   HFONT    hFontUserL;

   int      fontSize;
   BOOL     releaseDC;
   BOOL     resetDC;
   HRGN     hClipRgn;
   HRGN     hClipRgnOld;
} DCValues;

/* The mouseGraph structure is also located in nt_Graph3DWnd.c.  If  */
/* any changes are made to this structure, change the one in         */
/* nt_Graph3DWnd.c too. */
struct mouseGraph
{
   UINT cmd;
   WORD fwKeys;            /* key flags                              */
   short xPos;              /* horizontal position of cursor          */
   short yPos;              /* vertical position of cursor            */
   WORD leftBtnDwnXPos;    /* initial horizontal position of cursor  */
   WORD leftBtnDwnYPos;    /* initial vertical position of cursor    */
   WORD leftBtnUpXPos;     /* final horizontal position of cursor    */
   WORD leftBtnUpYPos;     /* final vertical position of cursor      */
   WORD middleBtnDwnXPos;  /* initial horizontal position of cursor  */
   WORD middleBtnDwnYPos;  /* initial vertical position of cursor    */
   WORD middleBtnUpXPos;   /* final horizontal position of cursor    */
   WORD middleBtnUpYPos;   /* final vertical position of cursor      */
   WORD rightBtnDwnXPos;   /* initial horizontal position of cursor  */
   WORD rightBtnDwnYPos;   /* initial vertical position of cursor    */
   WORD rightBtnUpXPos;    /* final horizontal position of cursor    */
   WORD rightBtnUpYPos;    /* final vertical position of cursor      */
   RECT rcUpdate;          /* update rectangle for WM_PAINT          */
   HWND hwnd;              /* The hwnd for the current message       */
   WPARAM wParam;          /* key flags for the current message      */
   LPARAM lParam;          /* Used to store an object of the message */
};

/****************************************************************************
   Globals
****************************************************************************/

/* The global DC settings */
   DCValues dcv;
   HFONT    prevFont;
   HPEN     prevPen;
   HBRUSH   prevBrush;


/****************************************************************************
   Functions
****************************************************************************/

void ReadDC( HDC hdc );
void SetupDC( HDC hdc );
void x11_resize (void * , void *, void *);

#define PALVERSION       (0x300)
#define MAXPALETTE       (0X100)      /* max # supported palette entries */

/* Flags used for display of messages */
#define NT_NONE    (0X0)            /* Don't display any msgs */

/* Types */
static int NT_ERROR  = (0X1);    /* Display non window and function errors */
static int NT_WARN   = (0X2);    /* Display warnings */
static int NT_INF    = (0X4);    /* Display informative messages*/
static int NT_WM     = (0X8);    /* Display windows wm_... messages*/
static int NT_ENTRY  = (0X10);   /* Display message on entry to subroutine */
static int NT_COLOR  = (0X20);   /* Active show color function */
static int NT_WINERR  = (0X40);  /* Display windows errors */
static int NT_EXIT      = (0X80);   /* Display message on exit from subroutine */
static int NT_DBG0      = (0X100);  /* Display debug info */
static int NT_DBG1      = (0X200);  /* Display debug info */
static int NT_DBG2      = (0X400);  /* Display debug info */
static int NT_DBG3      = (0X800);  /* Display debug info */
static int NT_DBG4      = (0X1000); /* Display debug info */

/* Options */
static int NT_TYPE      = (0X2000); /* Display message type with message */

/* Where to display */
static int NT_CONSOLE = (0X4000); /* Display all messages in the colsole window */
static int NT_NOFILE  = (0X8000);   /* Don't display any messages in the error file */

/* Special type */
static int NT_CONMSG  = (0X10000); /* Always force display this msg in the consol */
static int NT_FILMSG  = (0X20000); /* Always force display this msg in the file */
static int NT_MSGBOX  = (0X40000); /* Always force display this msg to the message box */

static int NT_ALL     = (0X4000 - 0X1);/* Display all errors */

int errMsgFlag;

#if defined(PCWINNT_SYS)
#define get_animzz_ GET_ANIMZZ
#define set_animzz_ SET_ANIMZZ
#endif
void CALLTYP get_animzz_ (INT *);
void CALLTYP set_animzz_ (INT *);

#if defined(PCWINNT_SYS)
#define killit_ KILLIT
#define animnt_ ANIMNT
#define beepnt_ BEEPNT
void CALLTYP killit_ (void);
#endif
