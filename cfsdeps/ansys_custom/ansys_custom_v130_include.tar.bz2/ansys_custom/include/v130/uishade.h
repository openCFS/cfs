/* 
 * *** copyright(c) 2010 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */
#ifndef SHADY
#define WHERE extern
#else
#define WHERE
#endif

#define MAX_TOPICS   10
#define MAX_SPECIFIC 30
#define MAX_LABEL_LENGTH 10

#define PD_FILE          0
#define PD_EDIT          1
#define PD_SELECT        2
#define PD_LIST          3
#define PD_PLOT          4
#define PD_VIEW_CTRLS    5
#define PD_WORK_PLANE    6
#define PD_PARAMETERS    7
#define PD_MACRO         8
#define PD_MENU_CTRLS    9

#if !defined (PCWINNT_SYS)
WHERE Widget  MBar_Topic_Btns[MAX_TOPICS];
WHERE Widget  MBar_Topic_Pdwns[MAX_TOPICS];
WHERE Widget  MBar_Pdwn_Btns[MAX_TOPICS][MAX_SPECIFIC];
WHERE int     MBar_Pdwn_Btns_Count[MAX_TOPICS];
#else
WHERE HMENU   MBar_Topic_Btns[MAX_TOPICS];
WHERE HMENU   MBar_Topic_Pdwns[MAX_TOPICS];
WHERE int     MBar_Pdwn_Btns[MAX_TOPICS][MAX_SPECIFIC];
WHERE int     MBar_Pdwn_Btns_Count[MAX_TOPICS];
#endif
