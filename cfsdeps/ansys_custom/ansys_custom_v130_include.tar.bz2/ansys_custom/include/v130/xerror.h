

/*
 *    author/date: yu-hua ting/07-28-93
 *
 *    primary function:
 *
 *        error code definition
 *
 *    secondary function:
 *
 *        none
 *
 *    routines included:
 *
 *        none
 *
 *    history
 *
 *        none
 *
 *    comments:
 *
 *        none
 *
 *    Notice - This file contains ANSYS Confidential information ***
 *
 */

/* 
 * *** copyright(c) 2010 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */

/*
 *    last digit = 1 - shapes error 
 *               = 2 - ansys  error
 *               = 3 - ansys/shapes interface error 
 */

#define SHAPES_VALID_MERGE                                                                    0
#define SHAPES_INTERSECTION_IS_EMPTY                                                          1
#define SHAPES_VALID_OVERLAP                                                                  2
 
#define SHAPES_NO_ENOUGH_MEMORY                                                               XE_BadMem   
#define SHAPES_NON_MANIFOLD_GEOMETRY                                                          999900
#define ANSYS_COMPOSITE_VOLUME                                                                999902
#define ANSYS_COMPOSITE_AREA                                                                  999912
#define ANSYS_COMPOSITE_LINE                                                                  999922
 
#define SHAPES_COMPOSITE_VOLUME                                                               999931
#define SHAPES_COMPOSITE_AREA                                                                 999941
#define SHAPES_COMPOSITE_LINE                                                                 999951
 
#define INPUT_GEOMETRIES_ARE_DISJOINTED                                                       999888
#define ALL_CUT_GEOMETRIES_ARE_DISJOINTED_WITH_CUTTING_GEOMETRY                               999777
#define CUTTING_AREAS_ARE_DISJOINTED                                                          999666
 
#define NO_ENOUGH_MEMORY                                                                      988888
 
#define CAN_NOT_FREE_MEMORY                                                                   977777
 
#define GEOMETRY_IS_EMPTY                                                                     966666
 
#define GEOMETRIES_DO_NOT_OVERLAP                                                             955555
#define GEOMETRIES_DO_NOT_MERGE                                                               944444
 
#define NOT_YET_IMPLEMENTED                                                                   933333
 
#define ERROR_CODE_STACK_IS_FULL                                                              933302
#define ERROR_CODE_STACK_IS_EMPTY                                                             933312
 
#define DEGENERACY_DETECTED_IN_BOOLEAN                                                        922212
#define NON_MANIFOLD_GEOMETRY                                                                 922222
 
#define SHAPES_SYSTEM_ERROR                                                                   900001
#define ANSYS_SYSTEM_ERROR                                                                    900002
#define INTERFACE_SYSTEM_ERROR                                                                900003
 
#define DEGENERACY_DETECTED_BY_SHAPES_IN_BOOLEAN                                              999091
 
#define SHAPES_SHELL_HAVING_1_XSUBAREA                                                        999101
#define SHAPES_SHELL_HAVING_LESS_THAN_1_XSUBAREA                                              999111
#define SHAPES_LOOP_HAVING_2_XSUBLINES                                                        999121
#define SHAPES_LOOP_HAVING_1_XSUBLINE                                                         999131
#define SHAPES_LOOP_HAVING_LESS_THAN_1_XSUBLINE                                               999141
 
#define ANSYS_SHELL_HAVING_1_AREA                                                             999002
#define ANSYS_SHELL_HAVING_1_SUBAREA                                                          999012

#define ANSYS_SHELL_HAVING_LESS_THAN_1_AREA                                                   999022
#define ANSYS_SHELL_HAVING_LESS_THAN_1_SUBAREA                                                999032

#define ANSYS_LOOP_HAVING_2_LINES                                                             999042
#define ANSYS_LOOP_HAVING_2_SUBLINES                                                          999052

#define ANSYS_LOOP_HAVING_1_LINE                                                              999062
#define ANSYS_LOOP_HAVING_1_SUBLINE                                                           999072

#define ANSYS_LOOP_HAVING_LESS_THAN_1_LINE                                                    999082
#define ANSYS_LOOP_HAVING_LESS_THAN_1_SUBLINE                                                 999092

#define ANSYS_POINTS_ARE_COLINEAR                                                             999142
 
#define ANSYS_DUPLICATE_SUBLINES_ALREADY_EXIST                                                999202
#define ANSYS_DUPLICATE_SUBAREAS_ALREADY_EXIST                                                999212
#define ANSYS_DUPLICATE_SUBVOLUMES_ALREADY_EXIST                                              999222

#define ANSYS_DUPLICATE_SUBLINES_WITH_DIFFERENT_GEOMETRIES                                    999232
#define ANSYS_DUPLICATE_SUBAREAS_WITH_DIFFERENT_GEOMETRIES                                    999242
#define ANSYS_DUPLICATE_SUBVOLUMES_WITH_DIFFERENT_GEOMETRIES                                  999252
               

#define ERROR_IN_xGeomOrientation_IN_xGeomOrientation_Ansys_FILE_xshape                       100001

#define ERROR_IN_xGeomFromAnsysCurve_IN_xNurbGeom_Curve_Ansys_FILE_xshape                     100021

#define ERROR_IN_xInvertGeomOrientation_IN_xInvertGeomOrient_Ansys_FILE_xshape                100031
#define ERROR_IN_xuidg_IN_xInvertGeomOrient_Ansys_FILE_xshape                                 100041
#define ERROR_IN_xuids_IN_xInvertGeomOrient_Ansys_FILE_xshape                                 100051

#define ERROR_IN_xGeomFromAnsysSurface_IN_xNurbGeom_Surface_Ansys_FILE_xshape                 100061

#define ERROR_IN_xSewnGeom_IN_xSewnGeom_Ansys_FILE_xshape                                     100071

#define ERROR_IN_xReplaceSubGeoms_IN_xReplaceSubGeoms_Ansys_FILE_xshape                       100081

#define GEOMETRY_DIMENSION_NOT_CORRECT_IN_xBasicGeom_Manifold_Check_FILE_xshape               100101 
#define ERROR_IN_xKSubGeoms_1_IN_xBasicGeom_Manifold_Check_FILE_xshape                        100111
#define ERROR_IN_xKSubGeoms_2_IN_xBasicGeom_Manifold_Check_FILE_xshape                        100121  
#define ERROR_IN_xIntListLength_1_IN_xBasicGeom_Manifold_Check_FILE_xshape                    100131 
#define ERROR_IN_xIntListLength_2_IN_xBasicGeom_Manifold_Check_FILE_xshape                    100141
#define ERROR_IN_xIntListElement_1_IN_xBasicGeom_Manifold_Check_FILE_xshape                   100151
#define ERROR_IN_xIntListElement_2_IN_xBasicGeom_Manifold_Check_FILE_xshape                   100161
#define ERROR_IN_xPushIntListElement_IN_xBasicGeom_Manifold_Check_FILE_xshape                 100171
#define NO_ENOUGH_MEMORY_IN_xBasicGeom_Manifold_Check_FILE_xshape                             100181
#define CAN_NOT_FREE_MEMORY_IN_xBasicGeom_Manifold_Check_FILE_xshape                          100191

#define ERROR_IN_xBasicGeoms_IN_xvusvq_FILE_xshape                                            100601
#define ERROR_IN_xIntListLength_IN_xvusvq_FILE_xshape                                         100611

#define ERROR_IN_xBasicGeoms_IN_xvusvg_FILE_xshape                                            100701

#define ERROR_IN_xNumGeomFrames_IN_xvushq_FILE_xshape                                         100801

#define ERROR_IN_xGeomFrameTreeA_IN_xvushg_FILE_xshape                                        100901
#define NO_ENOUGH_MEMORY_1_IN_xvushg_FILE_xshape                                              100911
#define CAN_NOT_FREE_MEMORY_1_IN_xvushg_FILE_xshape                                           100921

#define ERROR_IN_xNumGeomFrames_IN_xsvshq_FILE_xshape                                         101001

#define ERROR_IN_xGeomFrameTreeA_IN_xsvshg_FILE_xshape                                        101101
#define NO_ENOUGH_MEMORY_1_IN_xsvshg_FILE_xshape                                              101111
#define CAN_NOT_FREE_MEMORY_1_IN_xsvshg_FILE_xshape                                           101121
 
#define ERROR_IN_xNumFrameComponents_IN_xshsaq_FILE_xshape                                    101201
#define SHAPES_NON_MANIFOLD_GEOMETRY_IN_xshsaq_FILE_xshape                                    101211
#define SHAPES_SHELL_HAVING_1_XSUBAREA_IN_xshsaq_FILE_xshape                                  101221
#define SHAPES_SHELL_HAVING_LESS_THAN_1_XSUBAREA_IN_xshsaq_FILE_xshape                        101231

#define ERROR_IN_xFrameComponentsA_IN_xshsag_FILE_xshape                                      101301
#define ERROR_IN_xFrameComponentOrientsA_IN_xshsag_FILE_xshape                                101311
#define NO_ENOUGH_MEMORY_1_IN_xshsag_FILE_xshape                                              101321
#define CAN_NOT_FREE_MEMORY_1_IN_xshsag_FILE_xshape                                           101331

#define ERROR_IN_xBasicGeoms_IN_xarsaq_FILE_xshape                                            101401
#define ERROR_IN_xIntListLength_IN_xarsaq_FILE_xshape                                         101411

#define ERROR_IN_xBasicGeoms_IN_xarsag_FILE_xshape                                            101501

#define ERROR_IN_xNumGeomFrames_IN_xarlpq_FILE_xshape                                         101601

#define ERROR_IN_xGeomFrameTreeA_IN_xarlpg_FILE_xshape                                        101701
#define NO_ENOUGH_MEMORY_1_IN_xarlpg_FILE_xshape                                              101711
#define CAN_NOT_FREE_MEMORY_1_IN_xarlpg_FILE_xshape                                           101721
 
#define ERROR_IN_xNumGeomFrames_IN_xsalpq_FILE_xshape                                         101801

#define ERROR_IN_xGeomFrameTreeA_IN_xsalpg_FILE_xshape                                        101901
#define NO_ENOUGH_MEMORY_1_IN_xsalpg_FILE_xshape                                              101911
#define CAN_NOT_FREE_MEMORY_1_IN_xsalpg_FILE_xshape                                           101921

#define ERROR_IN_xNumFrameComponents_IN_xlpslq_FILE_xshape                                    102001

#define ERROR_IN_xFrameComponentOrientsA_IN_xlpslg_FILE_xshape                                102011
#define ERROR_IN_xFrameComponentsA_IN_xlpslg_FILE_xshape                                      102021
#define ERROR_IN_xslptt_1_IN_xlpslg_FILE_xshape                                               102031
#define ERROR_IN_xslptt_2_IN_xlpslg_FILE_xshape                                               102041
#define ERROR_IN_xslptg_IN_xlpslg_FILE_xshape                                                 102051
#define SHAPES_NON_MANIFOLD_GEOMETRY_IN_xlpslg_FILE_xshape                                    102061

#define SHAPES_LOOP_HAVING_2_XSUBLINES_IN_xlpslg_FILE_xshape                                  102111
#define SHAPES_LOOP_HAVING_1_XSUBLINE_IN_xlpslg_FILE_xshape                                   102121
#define SHAPES_LOOP_HAVING_LESS_THAN_1_XSUBLINE_IN_xlpslg_FILE_xshape                         102131
#define NO_ENOUGH_MEMORY_1_IN_xlpslg_FILE_xshape                                              102141
#define CAN_NOT_FREE_MEMORY_1_IN_xlpslg_FILE_xshape                                           102151

#define ERROR_IN_xBasicGeoms_IN_xlsslq_FILE_xshape                                            102201
#define ERROR_IN_xIntListLength_IN_xlsslq_FILE_xshape                                         102211

#define ERROR_IN_xBasicGeoms_IN_xlsslg_FILE_xshape                                            102301

#define ERROR_IN_xSubGeoms_IN_xslptt_FILE_xshape                                              102401
#define ERROR_IN_xIntListLength_1_IN_xslptt_FILE_xshape                                       102411
#define ERROR_IN_xSubGeomOrientations_IN_xslptt_FILE_xshape                                   102421
#define ERROR_IN_xIntListLength_2_IN_xslptt_FILE_xshape                                       102431

#define ERROR_IN_xslptt_IN_xslptg_FILE_xshape                                                 102501

#define ERROR_IN_xAnsysNsurFromGeom_IN_xsasuq_FILE_xshape                                     102601
#define ERROR_IN_xApproximateGeomNurbStructure_IN_xsasuq_FILE_xshape                          102611
#define SURFACE_IS_NOT_IN_3D_SPACE_IN_xsasuq_FILE_xshape                                      102621
#define SURFACE_DIMENSION_IS_NOT_2_IN_xsasuq_FILE_xshape                                      102631

#define ERROR_IN_xAnsysSurFromGeom_IN_xsasug_FILE_xshape                                      102701
#define ERROR_IN_xApproximateGeomNurbStructure_IN_xsasug_FILE_xshape                          102711
#define SURFACE_IS_NOT_IN_3D_SPACE_IN_xsasug_FILE_xshape                                      102721
#define SURFACE_DIMENSION_IS_NOT_2_IN_xsasug_FILE_xshape                                      102731

#define ERROR_IN_xAnsysNcurFromGeom_IN_xslcuq_FILE_xshape                                     102801
#define XOX_DATA_LENGTH_IS_TOO_SMALL_IN_xslcuq_FILE_xshape                                    102811
#define ERROR_IN_xApproximateGeomNurbStructure_IN_xslcuq_FILE_xshape                          102821
#define PERIODIC_NURBS_CURVE_IN_xslcuq_FILE_xshape                                            102831
#define CURVE_DIMENSION_IS_NOT_1_IN_xslcuq_FILE_xshape                                        102841

#define ERROR_IN_xAnsysCurFromGeom_IN_xslcug_FILE_xshape                                      102901
#define XOX_DATA_LENGTH_IS_TOO_SMALL_IN_xslcug_FILE_xshape                                    102911
#define ERROR_IN_xApproximateGeomNurbStructure_IN_xslcug_FILE_xshape                          102921
#define CURVE_DIMENSION_IS_NOT_1_IN_xslcug_FILE_xshape                                        102931
#define ERROR_IN_xVertexForParams_IN_xptcog_FILE_xshape                                       102941

#define ERROR_IN_xVertexCoords_IN_xptcog_FILE_xshape                                          103001

#define ERROR_IN_xSetUserId_IN_xuids_FILE_xshape                                              103101

#define ERROR_IN_xUserIds_IN_xuidq_FILE_xshape                                                103201

#define ERROR_IN_xUserIds_IN_xuidg_FILE_xshape                                                103301

#define ERROR_IN_xIntListLength_IN_xuidg_FILE_xshape                                          103401
#define ERROR_IN_xGeomP_IN_xuidg_FILE_xshape                                                  103411
#define ERROR_IN_xGeomDimension_IN_xuidg_FILE_xshape                                          103421
#define INVALID_ANSYS_ENTITY_NUMBER_IN_xuidg_FILE_xshape                                      103431
#define ERROR_IN_xPointGeom_IN_xptcr_FILE_xshape                                              103441

#define ERROR_IN_xNurbGeom_Curve_Ansysm_IN_xtrmsl_FILE_xshape                                 103501
#define ERROR_IN_xMakeFrameA_IN_xtrmsl_FILE_xshape                                            103511
#define ERROR_IN_xReplaceGeomFramesA_IN_xtrmsl_FILE_xshape                                    103521
#define ERROR_IN_xCopyGeom_1_IN_xtrmsl_FILE_xshape                                            103531
#define ERROR_IN_xCopyGeom_2_IN_xtrmsl_FILE_xshape                                            103541
#define ERROR_IN_xPushIntListElement_1_IN_xtrmsl_FILE_xshape                                  103551
#define ERROR_IN_xPushIntListElement_2_IN_xtrmsl_FILE_xshape                                  103561
#define ERROR_IN_xPushIntListElement_3_IN_xtrmsl_FILE_xshape                                  103571
#define ERROR_IN_xPushIntListElement_4_IN_xtrmsl_FILE_xshape                                  103581
#define ERROR_IN_xReplaceSubGeoms_Ansys_IN_xtrmsl_FILE_xshape                                 103591

#define SEWING_WHEN_USING_FRAME_TREE_INPUT_IN_xsewls_FILE_xshape                              103701
#define ERROR_IN_xCopyGeom_IN_xsewls_FILE_xshape                                              103711
#define ERROR_IN_xInvertGeomOrient_Ansys_IN_xsewls_FILE_xshape                                103721
#define ERROR_IN_xPushIntListElement_IN_xsewls_FILE_xshape                                    103731
#define ERROR_IN_xSewnGeom_Ansys_IN_xsewls_FILE_xshape                                        103741

#define ERROR_IN_xMakeFrameA_IN_xsewlp_FILE_xshape                                            103801
#define ERROR_IN_xsewls_IN_xsewlp_FILE_xshape                                                 103811
#define NO_ENOUGH_MEMORY_1_IN_xsewlp_FILE_xshape                                              103821
#define CAN_NOT_FREE_MEMORY_1_IN_xsewlp_FILE_xshape                                           103831

#define ERROR_IN_xNurbGeom_Surface_Ansys_IN_xtrmsa_FILE_xshape                                103901
#define ERROR_IN_xReplaceGeomFramesA_IN_xtrmsa_FILE_xshape                                    103911
#define ERROR_IN_xCopyGeom_IN_xtrmsa_FILE_xshape                                              103921
#define ERROR_IN_xPushIntListElement_1_IN_xtrmsa_FILE_xshape                                  103931
#define ERROR_IN_xPushIntListElement_2_IN_xtrmsa_FILE_xshape                                  103941
#define ERROR_IN_xPushIntListElement_3_IN_xtrmsa_FILE_xshape                                  103951
#define ERROR_IN_xPushIntListElement_4_IN_xtrmsa_FILE_xshape                                  103961
#define ERROR_IN_xReplaceSubGeoms_Ansys_IN_xtrmsa_FILE_xshape                                 103971
#define NO_ENOUGH_MEMORY_1_IN_xtrmsa_FILE_xshape                                              103981
#define CAN_NOT_FREE_MEMORY_1_IN_xtrmsa_FILE_xshape                                           103991


#define SEWING_WHEN_USING_FRAME_TREE_INPUT_IN_xsewar_FILE_xshape                              104101
#define ERROR_IN_xCopyGeom_IN_xsewar_FILE_xshape                                              104111
#define ERROR_IN_xInvertGeomOrient_Ansys_IN_xsewar_FILE_xshape                                104121
#define ERROR_IN_xPushIntListElement_IN_xsewar_FILE_xshape                                    104131
#define ERROR_IN_xSewnGeom_Ansys_IN_xsewar_FILE_xshape                                        104141

#define ERROR_IN_xMakeFrameA_IN_xsewsh_FILE_xshape                                            104201
#define ERROR_IN_xsewar_IN_xsewsh_FILE_xshape                                                 104211
#define NO_ENOUGH_MEMORY_1_IN_xsewsh_FILE_xshape                                              104221
#define CAN_NOT_FREE_MEMORY_1_IN_xsewsh_FILE_xshape                                           104231

#define ERROR_IN_xReplaceGeomFramesA_IN_xtrmsv_FILE_xshape                                    104301
#define ERROR_IN_xsewnc_IN_xtrmsv_FILE_xshape                                                 104311
#define ERROR_IN_xHalfspaceGeom_IN_xtrmsv_FILE_xshape                                         104321
#define NO_ENOUGH_MEMORY_1_IN_xtrmsv_FILE_xshape                                              104331
#define CAN_NOT_FREE_MEMORY_1_IN_xtrmsv_FILE_xshape                                           104341

#define SEWING_WHEN_USING_FRAME_TREE_INPUT_IN_xsewvu_FILE_xshape                              104401
#define ERROR_IN_xCopyGeom_IN_xsewvu_FILE_xshape                                              104411
#define ERROR_IN_xInvertGeomOrient_Ansys_IN_xsewvu_FILE_xshape                                104421
#define ERROR_IN_xPushIntListElement_IN_xsewvu_FILE_xshape                                    104431
#define ERROR_IN_xSewnGeom_Ansys_IN_xsewvu_FILE_xshape                                        104441


#define ERROR_IN_xNumFrameComponents_IN_xlpchk_FILE_xshape                                    104501
#define SHAPES_LOOP_HAVING_LESS_THAN_1_XSUBLINE_IN_xlpchk_FILE_xshape                         104511
#define ERROR_IN_xlpslg_IN_xlpchk_FILE_xshape                                                 104521
#define ERROR_IN_xslptg_IN_xlpchk_FILE_xshape                                                 104531
#define NO_ENOUGH_MEMORY_1_IN_xlpchk_FILE_xshape                                              104541
#define CAN_NOT_FREE_MEMORY_1_IN_xlpchk_FILE_xshape                                           104551

    

#define ERROR_IN_xtkpc_IN_xconvt_FILE_xchang                                                  200103
#define ERROR_IN_xtlsc_IN_xconvt_FILE_xchang                                                  200113
#define ERROR_IN_xtarc_IN_xconvt_FILE_xchang                                                  200123
#define ERROR_IN_xtvuc_IN_xconvt_FILE_xchang                                                  200133
#define ERROR_IN_xfkpc_IN_xconvt_FILE_xchang                                                  200143
#define ERROR_IN_xfptc_IN_xconvt_FILE_xchang                                                  200153
#define ERROR_IN_xflsc_IN_xconvt_FILE_xchang                                                  200163
#define ERROR_IN_xfslc_IN_xconvt_FILE_xchang                                                  200173
#define ERROR_IN_xfarc_IN_xconvt_FILE_xchang                                                  200183
#define ERROR_IN_xfsac_IN_xconvt_FILE_xchang                                                  200193
#define ERROR_IN_xfvuc_IN_xconvt_FILE_xchang                                                  200203
#define ERROR_IN_xfsvc_IN_xconvt_FILE_xchang                                                  200213

#define ERROR_IN_xheap_init_IN_xoxopn_FILE_xchang                                             200303
#define ERROR_IN_xInitShapes_IN_xoxopn_FILE_xchang                                            200311

#define CAN_NOT_FREE_MEMORY_IN_xoxcls_FILE_xchang                                             200401
#define ERROR_IN_ErrorHandler_IN_xoxcls_FILE_xchang                                           200411
#define ERROR_IN_xFreeAnsysMemory_IN_xoxcls_FILE_xchang                                       200421
#define ERROR_IN_xDisconnectShapes_IN_xoxcls_FILE_xchang                                      200431

#define ERROR_IN_xBasicGeoms_IN_xngeom_FILE_xchang                                            200501
#define ERROR_IN_xIntListLength_IN_xngeom_FILE_xchang                                         200511

#define ERROR_IN_xBasicGeoms_IN_xgeoms_FILE_xchang                                            200601
#define ERROR_IN_xIntListLength_IN_xgeoms_FILE_xchang                                         200611

#define ERROR_IN_xCopyGeom_1_IN_xclafy_FILE_xchang                                            200701
#define ERROR_IN_xCopyGeom_2_IN_xclafy_FILE_xchang                                            200711
#define SHOULD_NOT_CALL_xInvertGeomOrient_Ansys_1_IN_xclafy_FILE_xchang                       200723
#define ERROR_IN_xInvertGeomOrient_Ansys_1_IN_xclafy_FILE_xchang                              200731
#define SHOULD_NOT_CALL_xInvertGeomOrient_Ansys_2_IN_xclafy_FILE_xchang                       200743
#define ERROR_IN_xInvertGeomOrient_Ansys_2_IN_xclafy_FILE_xchang                              200751
#define ERROR_IN_xClassifyGeoms_IN_xclafy_FILE_xchang                                         200761

#define ERROR_IN_xCopyGeom_1_IN_xintsr_FILE_xchang                                            200801
#define ERROR_IN_xCopyGeom_2_IN_xintsr_FILE_xchang                                            200811
#define SHOULD_NOT_CALL_xInvertGeomOrient_Ansys_1_IN_xintsr_FILE_xchang                       200823
#define ERROR_IN_xInvertGeomOrient_Ansys_1_IN_xintsr_FILE_xchang                              200831
#define SHOULD_NOT_CALL_xInvertGeomOrient_Ansys_2_IN_xintsr_FILE_xchang                       200843
#define ERROR_IN_xInvertGeomOrient_Ansys_2_IN_xintsr_FILE_xchang                              200851
#define ERROR_IN_xIntersectionGeom_IN_xintsr_FILE_xchang                                      200861

#define ERROR_IN_xCopyGeom_1_IN_xdiffn_FILE_xchang                                            200901
#define ERROR_IN_xCopyGeom_2_IN_xdiffn_FILE_xchang                                            200911
#define SHOULD_NOT_CALL_xInvertGeomOrient_Ansys_1_IN_xdiffn_FILE_xchang                       200923
#define ERROR_IN_xInvertGeomOrient_Ansys_1_IN_xdiffn_FILE_xchang                              200931
#define SHOULD_NOT_CALL_xInvertGeomOrient_Ansys_2_IN_xdiffn_FILE_xchang                       200943
#define ERROR_IN_xInvertGeomOrient_Ansys_2_IN_xdiffn_FILE_xchang                              200951
#define ERROR_IN_xDifferenceGeom_IN_xdiffn_FILE_xchang                                        200961

#define ERROR_IN_xCopyGeom_1_IN_xunion_FILE_xchang                                            201001
#define ERROR_IN_xCopyGeom_2_IN_xunion_FILE_xchang                                            201011
#define SHOULD_NOT_CALL_xInvertGeomOrient_Ansys_1_IN_xunion_FILE_xchang                       201023
#define ERROR_IN_xInvertGeomOrient_Ansys_1_IN_xunion_FILE_xchang                              201031
#define SHOULD_NOT_CALL_xInvertGeomOrient_Ansys_2_IN_xunion_FILE_xchang                       201043
#define ERROR_IN_xInvertGeomOrient_Ansys_2_IN_xunion_FILE_xchang                              201051
#define ERROR_IN_xUnionGeom_IN_xunion_FILE_xchang                                             201061

#define ERROR_IN_xCopyGeom_1_IN_xmerge_FILE_xchang                                            201101
#define ERROR_IN_xCopyGeom_2_IN_xmerge_FILE_xchang                                            201111
#define SHOULD_NOT_CALL_xInvertGeomOrient_Ansys_1_IN_xmerge_FILE_xchang                       201123
#define ERROR_IN_xInvertGeomOrient_Ansys_1_IN_xmerge_FILE_xchang                              201131
#define SHOULD_NOT_CALL_xInvertGeomOrient_Ansys_2_IN_xmerge_FILE_xchang                       201143
#define ERROR_IN_xInvertGeomOrient_Ansys_2_IN_xmerge_FILE_xchang                              201151
#define ERROR_IN_xUnionMergeGeom_IN_xmerge_FILE_xchang                                        201161
#define INVALID_GEOMETRY_IN_xmerge_FILE_xchang                                                201171

#define ERROR_IN_xGeomDimension_1_IN_xoverlap_FILE_xchang                                     201201
#define ERROR_IN_xGeomDimension_2_IN_xoverlap_FILE_xchang                                     201211
#define ERROR_IN_xCopyGeom_1_IN_xoverlap_FILE_xchang                                          201221
#define ERROR_IN_xCopyGeom_2_IN_xoverlap_FILE_xchang                                          201231
#define SHOULD_NOT_CALL_xInvertGeomOrient_Ansys_1_IN_xoverlap_FILE_xchang                     201243
#define ERROR_IN_xInvertGeomOrient_Ansys_1_IN_xoverlap_FILE_xchang                            201251
#define SHOULD_NOT_CALL_xInvertGeomOrient_Ansys_2_IN_xoverlap_FILE_xchang                     201263
#define ERROR_IN_xInvertGeomOrient_Ansys_2_IN_xoverlap_FILE_xchang                            201271
#define ERROR_IN_xClassifyGeoms_IN_xoverlap_FILE_xchang                                       201281
#define ERROR_IN_xNullGeomP_IN_xoverlap_FILE_xchang                                           201291
#define ERROR_IN_xGeomDimension_3_IN_xoverlap_FILE_xchang                                     201301
#define GEOMETRIES_DO_NOT_OVERLAP_IN_xoverlap_FILE_xchang                                     201313
#define ERROR_IN_xSewnGeom_IN_xoverlap_FILE_xchang                                            201321

#define ERROR_IN_xIntersectingGeomsP_IN_xintst_FILE_xchang                                    201401

#define SHOULD_NOT_CALL_xInvertGeomOrient_Ansys_IN_xintss_FILE_xchang                         201503
#define ERROR_IN_xInvertGeomOrient_Ansys_IN_xintss_FILE_xchang                                201511
#define ERROR_IN_xintsr_IN_xintss_FILE_xchang                                                 201521

#define ERROR_IN_xintsr_IN_xintsp_FILE_xchang                                                 201541
#define ERROR_IN_xSewnGeom_IN_xintsp_FILE_xchang                                              201551


#define SHOULD_NOT_CALL_xInvertGeomOrient_Ansys_IN_xaddss_FILE_xchang                         201603
#define ERROR_IN_xInvertGeomOrient_Ansys_IN_xaddss_FILE_xchang                                201611
#define ERROR_IN_xunion_IN_xaddss_FILE_xchang                                                 201621
#define ERROR_IN_xmerge_IN_xaddss_FILE_xchang                                                 201631
    
#define SHOULD_NOT_CALL_xInvertGeomOrient_Ansys_IN_xmerss_FILE_xchang                         201703
#define ERROR_IN_xInvertGeomOrient_Ansys_IN_xmerss_FILE_xchang                                201711
#define ERROR_IN_xmerge_IN_xmerss_FILE_xchang                                                 201721
#define GEOMETRIES_DO_NOT_MERGE_1_IN_xmerss_FILE_xchang                                       201731
#define GEOMETRIES_DO_NOT_MERGE_2_IN_xmerss_FILE_xchang                                       201741

#define SHOULD_NOT_CALL_xInvertGeomOrient_Ansys_IN_xovers_FILE_xchang                         201803
#define ERROR_IN_xInvertGeomOrient_Ansys_IN_xovers_FILE_xchang                                201811
#define ERROR_IN_xmerge_IN_xovers_FILE_xchang                                                 201821
#define GEOMETRIES_DO_NOT_OVERLAP_1_IN_xovers_FILE_xchang                                     201831
#define GEOMETRIES_DO_NOT_OVERLAP_2_IN_xovers_FILE_xchang                                     201841


#define ERROR_IN_xCopyGeom_1_IN_xcutc_FILE_xchang                                             201901
#define ERROR_IN_xCopyGeom_2_IN_xcutc_FILE_xchang                                             201911
#define ERROR_IN_xCopyGeom_3_IN_xcutc_FILE_xchang                                             201921
#define ERROR_IN_xCopyGeom_4_IN_xcutc_FILE_xchang                                             201931
#define ERROR_IN_xHalfspaceGeom_1_IN_xcutc_FILE_xchang                                        201941
#define ERROR_IN_xInvertGeomOrient_Ansys_IN_xcutc_FILE_xchang                                 201951
#define ERROR_IN_xHalfspaceGeom_2_IN_xcutc_FILE_xchang                                        201961
#define ERROR_IN_xClassifyGeoms_IN_xcutc_FILE_xchang                                          201971
#define ERROR_IN_xintsr_1_IN_xcutc_FILE_xchang                                                201981
#define ERROR_IN_xintsr_2_IN_xcutc_FILE_xchang                                                201991
#define NOT_YET_IMPLEMENTED_IN_xcutc_FILE_xchang                                              202013

#define ERROR_IN_xCopyGeom_IN_xsewnc_FILE_xchang                                              202101
#define ERROR_IN_xInvertGeomOrient_Ansys_IN_xsewnc_FILE_xchang                                202111
#define ERROR_IN_xPushIntListElement_IN_xsewnc_FILE_xchang                                    202121
#define ERROR_IN_xSewnGeom_Ansys_IN_xsewnc_FILE_xchang                                        202131

#define ERROR_IN_xGeomDimension_IN_xnseam_FILE_xchang                                         202201
#define ERROR_IN_xKSeamGeoms_1_IN_xnseam_FILE_xchang                                          202211
#define ERROR_IN_xKSeamGeoms_2_IN_xnseam_FILE_xchang                                          202221
#define ERROR_IN_xKSeamGeoms_3_IN_xnseam_FILE_xchang                                          202231


#define ERROR_IN_xGeomDimension_IN_xnsub_FILE_xchang                                          202301
#define ERROR_IN_xKSubGeoms_1_IN_xnsub_FILE_xchang                                            202311
#define ERROR_IN_xKSubGeoms_2_IN_xnsub_FILE_xchang                                            202321
#define ERROR_IN_xKSubGeoms_3_IN_xnsub_FILE_xchang                                            202331
          
#define ERROR_IN_xBasicGeoms_IN_xfiltr_FILE_xchang                                            202401
#define ERROR_IN_xIntListLength_IN_xfiltr_FILE_xchang                                         202411
#define ERROR_IN_xCopyGeom_1_IN_xfiltr_FILE_xchang                                            202421
#define ERROR_IN_xSewnGeom_Ansys_IN_xfiltr_FILE_xchang                                        202431


#define ERROR_IN_vlviqr_IN_vusvq_FILE_xansys                                                  300102
#define ANSYS_COMPOSITE_VOLUME_IN_vusvq_FILE_xansys                                           300112

#define ERROR_IN_vlvget_IN_vusvg_FILE_xansys                                                  300202

#define ERROR_IN_vlaiqr_IN_svshq_FILE_xansys                                                  300302
#define ERROR_IN_svaiqr_IN_svshq_FILE_xansys                                                  300312

#define ERROR_IN_vlgtre_IN_svshg_FILE_xansys                                                  300402
#define ERROR_IN_svgtre_IN_svshg_FILE_xansys                                                  300412

#define ERROR_IN_vlaiqr_IN_shsaq_FILE_xansys                                                  300502
#define ANSYS_SHELL_HAVING_1_AREA_IN_shsaq_FILE_xansys                                        300512
#define ANSYS_SHELL_HAVING_1_SUBAREA_IN_shsaq_FILE_xansys                                     300522
#define ANSYS_SHELL_HAVING_LESS_THAN_1_AREA_IN_shsaq_FILE_xansys                              300532
#define ANSYS_SHELL_HAVING_LESS_THAN_1_SUBAREA_IN_shsaq_FILE_xansys                           300542
#define ERROR_IN_svaiqr_IN_shsaq_FILE_xansys                                                  300552

#define ERROR_IN_vlaget_IN_shsag_FILE_xansys                                                  300602
#define ERROR_IN_svagto_IN_shsag_FILE_xansys                                                  300612

#define ERROR_IN_araiqr_IN_arsaq_FILE_xansys                                                  300702
#define ANSYS_COMPOSITE_AREA_IN_arsaq_FILE_xansys                                             300712

#define ERROR_IN_araget_IN_arsag_FILE_xansys                                                  300802

#define ERROR_IN_arliqr_IN_salpq_FILE_xansys                                                  300902
#define ERROR_IN_saliqr_IN_salpq_FILE_xansys                                                  300912

#define ERROR_IN_argtre_IN_salpg_FILE_xansys                                                  301002
#define ERROR_IN_sagtre_IN_salpg_FILE_xansys                                                  301012

#define ERROR_IN_arliqr_IN_lpslq_FILE_xansys                                                  301102
#define ANSYS_LOOP_HAVING_2_LINES_IN_lpslq_FILE_xansys                                        301112
#define ANSYS_LOOP_HAVING_2_SUBLINES_IN_lpslq_FILE_xansys                                     301122
#define ANSYS_LOOP_HAVING_1_LINE_IN_lpslq_FILE_xansys                                         301132
#define ANSYS_LOOP_HAVING_1_SUBLINE_IN_lpslq_FILE_xansys                                      301142
#define ANSYS_LOOP_HAVING_LESS_THAN_1_LINE_IN_lpslq_FILE_xansys                               301152
#define ANSYS_LOOP_HAVING_LESS_THAN_1_SUBLINE_IN_lpslq_FILE_xansys                            301162
#define ERROR_IN_saliqr_IN_lpslq_FILE_xansys                                                  301172

#define ERROR_IN_arlgt2_IN_lpslg_FILE_xansys                                                  301202
#define ERROR_IN_salgto_IN_lpslg_FILE_xansys                                                  301212

#define ERROR_IN_lsliqr_IN_lsslq_FILE_xansys                                                  301302
#define ANSYS_COMPOSITE_LINE_IN_lsslq_FILE_xansys                                             301312

#define ERROR_IN_lsglsl_IN_lsslg_FILE_xansys                                                  301402

#define ERROR_IN_slgpts_IN_slptg_FILE_xansys                                                  301502

#define ERROR_IN_sainqr_IN_sasuq_FILE_xansys                                                  301602
#define ERROR_IN_nsrget_IN_sasuq_FILE_xansys                                                  301612

#define ERROR_IN_supgt2_IN_sasug_FILE_xansys                                                  301702

#define ERROR_IN_slgcvn_IN_slcuq_FILE_xansys                                                  301802
#define ERROR_IN_ncrget_IN_slcuq_FILE_xansys                                                  301812

#define ERROR_IN_cvpgt2_IN_slcug_FILE_xansys                                                  301902

#define ERROR_IN_svlvol_IN_vusva_FILE_xansys                                                  302002

#define ERROR_IN_sarare_IN_arsaa_FILE_xansys                                                  302102

#define ERROR_IN_slslsg_IN_lssla_FILE_xansys                                                  302202

#define ERROR_IN_kpinqr_IN_kpptq_FILE_xansys                                                  302302

#define ERROR_IN_ptggx2_IN_ptcog_FILE_xansys                                                  302402


#define NO_ENOUGH_MEMORY_1_IN_sewsh_FILE_xansys                                               302502
#define CAN_NOT_FREE_MEMORY_1_IN_sewsh_FILE_xansys                                            302512


#define ERROR_IN_putare_IN_sewar_FILE_xansys                                                  302602


#define NO_ENOUGH_MEMORY_1_IN_sewlp_FILE_xansys                                               302702
#define CAN_NOT_FREE_MEMORY_1_IN_sewlp_FILE_xansys                                            302712

#define ERROR_IN_slptg_1_IN_sewls_FILE_xansys                                                 302802
#define ERROR_IN_slptg_2_IN_sewls_FILE_xansys                                                 302812
#define ERROR_IN_ptskpt_IN_sewls_FILE_xansys                                                  302822
#define ERROR_IN_volpls_IN_sewls_FILE_xansys                                                  302832


#define NO_ENOUGH_MEMORY_1_IN_trmsv_FILE_xansys                                               302902
#define CAN_NOT_FREE_MEMORY_1_IN_trmsv_FILE_xansys                                            302912
#define ERROR_IN_entdup_IN_trmsv_FILE_xansys                                                  302922
#define ERROR_IN_xdelfm_1_IN_trmsv_FILE_xansys                                                302932
#define ERROR_IN_xdelfm_2_IN_trmsv_FILE_xansys                                                302932
#define ANSYS_DUPLICATE_SUBVOLUMES_ALREADY_EXIST_IN_trmsv_FILE_xansys                         302942
#define ANSYS_DUPLICATE_SUBVOLUMES_WITH_DIFFERENT_GEOMETRIES_IN_trmsv_FILE_xansys             302952


#define SCALING_FACTOR_IS_NOT_POSITIVE_IN_trmsa_FILE_xansys                                   303002
#define NO_ENOUGH_MEMORY_1_IN_trmsa_FILE_xansys                                               303012
#define CAN_NOT_FREE_MEMORY_1_IN_trmsa_FILE_xansys                                            303022
#define ERROR_IN_entdup_IN_trmsa_FILE_xansys                                                  303032
#define ERROR_IN_xdelfm_1_IN_trmsa_FILE_xansys                                                303042
#define ERROR_IN_xdelfm_2_IN_trmsa_FILE_xansys                                                303042
#define ANSYS_DUPLICATE_SUBAREAS_ALREADY_EXIST_IN_trmsa_FILE_xansys                           303052
#define ANSYS_DUPLICATE_SUBAREAS_WITH_DIFFERENT_GEOMETRIES_IN_trmsa_FILE_xansys               303062


#define SCALING_FACTOR_IS_NOT_POSITIVE_IN_trmsl_FILE_xansys                                   303102
#define ERROR_IN_ptcog_1_IN_trmsl_FILE_xansys                                                 303112
#define ERROR_IN_ptcog_2_IN_trmsl_FILE_xansys                                                 303122
#define ERROR_IN_sccutp_IN_trmsl_FILE_xansys                                                  303132
#define ERROR_IN_putsl2_IN_trmsl_FILE_xansys                                                  303142
#define ERROR_IN_entdup_IN_trmsl_FILE_xansys                                                  303152
#define ANSYS_DUPLICATE_SUBLINES_ALREADY_EXIST_IN_trmsl_FILE_xansys                           303162
#define ANSYS_DUPLICATE_SUBLINES_WITH_DIFFERENT_GEOMETRIES_IN_trmsl_FILE_xansys               303172
#define NO_ENOUGH_MEMORY_1_IN_trmsl_FILE_xansys                                               303182
#define CAN_NOT_FREE_MEMORY_1_IN_trmsl_FILE_xansys                                            303192


#define SCALING_FACTOR_IS_NOT_POSITIVE_IN_ptcr_FILE_xansys                                    303202
#define ERROR_IN_ptskpt_IN_ptkp_FILE_xansys                                                   303302



 
#define ENTRY_IS_NOT_IN_THE_TABLE_IN_xax_signint_FILE_xconv                                   400103

#define ERROR_IN_vusvq_IN_xtvuc_FILE_xconv                                                    400203
#define ERROR_IN_vusvg_IN_xtvuc_FILE_xconv                                                    400213
#define ERROR_IN_xtsvc_IN_xtvuc_FILE_xconv                                                    400223
#define ERROR_IN_xsewvu_IN_xtvuc_FILE_xconv                                                   400233
#define ANSYS_VOLUME_ALREADY_CONVERTED_IN_xtvuc_FILE_xconv                                    400243
#define ERROR_IN_xdbint_IN_xtvuc_FILE_xconv                                                   400253
#define NO_ENOUGH_MEMORY_1_IN_xtvuc_FILE_xconv                                                400263
#define CAN_NOT_FREE_MEMORY_1_IN_xtvuc_FILE_xconv                                             400273


#define ERROR_IN_svshq_IN_xtsvc_FILE_xconv                                                    400303
#define ERROR_IN_svshg_IN_xtsvc_FILE_xconv                                                    400313
#define ERROR_IN_xtshc_IN_xtsvc_FILE_xconv                                                    400323
#define ERROR_IN_xtrmsv_IN_xtsvc_FILE_xconv                                                   400333
#define ERROR_IN_xuids_IN_xtsvc_FILE_xconv                                                    400343
#define ANSYS_SUBVOLUME_ALREADY_CONVERTED_IN_xtsvc_FILE_xconv                                 400353
#define ERROR_IN_xdbint_IN_xtsvc_FILE_xconv                                                   400363
#define NO_ENOUGH_MEMORY_1_IN_xtsvc_FILE_xconv                                                400373
#define CAN_NOT_FREE_MEMORY_1_IN_xtsvc_FILE_xconv                                             400383



#define ERROR_IN_shsaq_IN_xtshc_FILE_xconv                                                    400403
#define ERROR_IN_shsag_IN_xtshc_FILE_xconv                                                    400413
#define ERROR_IN_xtsac_IN_xtshc_FILE_xconv                                                    400423
#define ERROR_IN_xsewsh_IN_xtshc_FILE_xconv                                                   400433
#define ERROR_IN_xuids_IN_xtshc_FILE_xconv                                                    400443
#define ANSYS_SHELL_ALREADY_CONVERTED_IN_xtshc_FILE_xconv                                     400453
#define ERROR_IN_xdbint_IN_xtshc_FILE_xconv                                                   400463
#define NO_ENOUGH_MEMORY_1_IN_xtshc_FILE_xconv                                                400473
#define CAN_NOT_FREE_MEMORY_1_IN_xtshc_FILE_xconv                                             400483



#define ERROR_IN_arsaq_IN_xtarc_FILE_xconv                                                    400503
#define ERROR_IN_arsag_IN_xtarc_FILE_xconv                                                    400513
#define ERROR_IN_xtsac_IN_xtarc_FILE_xconv                                                    400523
#define ERROR_IN_xsewar_IN_xtarc_FILE_xconv                                                   400533
#define ANSYS_AREA_ALREADY_CONVERTED_IN_xtarc_FILE_xconv                                      400543
#define ERROR_IN_xdbint_IN_xtarc_FILE_xconv                                                   400553
#define NO_ENOUGH_MEMORY_1_IN_xtarc_FILE_xconv                                                400563
#define CAN_NOT_FREE_MEMORY_1_IN_xtarc_FILE_xconv                                             400573


#define ERROR_IN_salpq_IN_xtsac_FILE_xconv                                                    400603
#define ERROR_IN_salpg_IN_xtsac_FILE_xconv                                                    400613
#define ERROR_IN_xtlpc_IN_xtsac_FILE_xconv                                                    400623
#define ERROR_IN_sasuq_IN_xtsac_FILE_xconv                                                    400633
#define ERROR_IN_sasug_IN_xtsac_FILE_xconv                                                    400643
#define ERROR_IN_xtrmsa_IN_xtsac_FILE_xconv                                                   400653
#define ERROR_IN_xuids_IN_xtsac_FILE_xconv                                                    400663
#define ANSYS_SUBAREA_ALREADY_CONVERTED_IN_xtsac_FILE_xconv                                   400673
#define ERROR_IN_xdbint_IN_xtsac_FILE_xconv                                                   400683
#define NO_ENOUGH_MEMORY_1_IN_xtsac_FILE_xconv                                                400693
#define NO_ENOUGH_MEMORY_2_IN_xtsac_FILE_xconv                                                400703
#define CAN_NOT_FREE_MEMORY_1_IN_xtsac_FILE_xconv                                             400713
#define CAN_NOT_FREE_MEMORY_2_IN_xtsac_FILE_xconv                                             400723

#define ERROR_IN_lpslq_IN_xtlpc_FILE_xconv                                                    400803
#define ERROR_IN_lpslg_IN_xtlpc_FILE_xconv                                                    400813
#define ERROR_IN_xtslc_IN_xtlpc_FILE_xconv                                                    400823
#define ERROR_IN_xsewlp_IN_xtlpc_FILE_xconv                                                   400833
#define ERROR_IN_xuids_IN_xtlpc_FILE_xconv                                                    400843
#define ANSYS_LOOP_ALREADY_CONVERTED_IN_xtlpc_FILE_xconv                                      400853
#define ERROR_IN_xdbint_IN_xtlpc_FILE_xconv                                                   400863
#define NO_ENOUGH_MEMORY_1_IN_xtlpc_FILE_xconv                                                400873
#define CAN_NOT_FREE_MEMORY_1_IN_xtlpc_FILE_xconv                                             400883


#define ERROR_IN_lsslq_IN_xtlsc_FILE_xconv                                                    400903
#define ERROR_IN_lsslg_IN_xtlsc_FILE_xconv                                                    400913
#define ERROR_IN_xtslc_IN_xtlsc_FILE_xconv                                                    400923
#define ERROR_IN_xsewls_IN_xtlsc_FILE_xconv                                                   400933
#define ANSYS_LINE_ALREADY_CONVERTED_IN_xtlsc_FILE_xconv                                      400943
#define ERROR_IN_xdbint_IN_xtlsc_FILE_xconv                                                   400953
#define NO_ENOUGH_MEMORY_1_IN_xtlsc_FILE_xconv                                                400963
#define CAN_NOT_FREE_MEMORY_1_IN_xtlsc_FILE_xconv                                             400973


#define ERROR_IN_slptg_IN_xtslc_FILE_xconv                                                    401003
#define ERROR_IN_xtptc_IN_xtslc_FILE_xconv                                                    401013
#define ERROR_IN_slcuq_IN_xtslc_FILE_xconv                                                    401023
#define ERROR_IN_slcug_IN_xtslc_FILE_xconv                                                    401033
#define ERROR_IN_xtrmsl_IN_xtslc_FILE_xconv                                                   401043
#define ERROR_IN_xuids_IN_xtslc_FILE_xconv                                                    401053
#define ANSYS_SUBLINE_ALREADY_CONVERTED_IN_xtslc_FILE_xconv                                   401063
#define ERROR_IN_xdbint_IN_xtslc_FILE_xconv                                                   401073
#define NO_ENOUGH_MEMORY_1_IN_xtslc_FILE_xconv                                                401083
#define CAN_NOT_FREE_MEMORY_1_IN_xtslc_FILE_xconv                                             401093



#define ERROR_IN_kpptq_IN_xtkpc_FILE_xconv                                                    401203
#define ERROR_IN_xtptc_IN_xtkpc_FILE_xconv                                                    401213
#define NO_ENOUGH_MEMORY_1_IN_xtkpc_FILE_xconv                                                401223
#define CAN_NOT_FREE_MEMORY_1_IN_xtkpc_FILE_xconv                                             401233



#define ERROR_IN_ptcog_IN_xtptc_FILE_xconv                                                    401303
#define ERROR_IN_xptcr_IN_xtptc_FILE_xconv                                                    401313
#define ERROR_IN_xuids_IN_xtptc_FILE_xconv                                                    401323
#define ANSYS_POINT_ALREADY_CONVERTED_IN_xtptc_FILE_xconv                                     401333
#define ERROR_IN_xdbint_IN_xtptc_FILE_xconv                                                   401343




#define ERROR_IN_xvusvq_IN_xfvuc_FILE_xconv                                                   401403
#define ERROR_IN_xvusvg_IN_xfvuc_FILE_xconv                                                   401413
#define ERROR_IN_xfsvc_IN_xfvuc_FILE_xconv                                                    401423
#define ERROR_IN_xvushq_IN_xfvuc_FILE_xconv                                                   401433
#define ERROR_IN_xvushg_IN_xfvuc_FILE_xconv                                                   401443
#define ERROR_IN_xfshc_IN_xfvuc_FILE_xconv                                                    401453
#define ERROR_IN_sewvu_IN_xfvuc_FILE_xconv                                                    401463
#define ERROR_IN_vusva_IN_xfvuc_FILE_xconv                                                    401473
#define ERROR_IN_xdbint_IN_xfvuc_FILE_xconv                                                   401483
#define NO_ENOUGH_MEMORY_1_IN_xfvuc_FILE_xconv                                                401493
#define NO_ENOUGH_MEMORY_2_IN_xfvuc_FILE_xconv                                                401503
#define CAN_NOT_FREE_MEMORY_1_IN_xfvuc_FILE_xconv                                             401513
#define CAN_NOT_FREE_MEMORY_2_IN_xfvuc_FILE_xconv                                             401523


#define ERROR_IN_xBasicGeom_Manifold_Check_IN_xfsvc_FILE_xconv                                401553
#define SHAPES_NON_MANIFOLD_GEOMETRY_IN_xfsvc_FILE_xconv                                      401563
#define ERROR_IN_xuidg_IN_xfsvc_FILE_xconv                                                    401573
#define ERROR_IN_xsvshq_IN_xfsvc_FILE_xconv                                                   401583
#define ERROR_IN_xsvshg_IN_xfsvc_FILE_xconv                                                   401593
#define ERROR_IN_xfshc_IN_xfsvc_FILE_xconv                                                    401603
#define ERROR_IN_trmsv_IN_xfsvc_FILE_xconv                                                    401613
#define SHAPES_XSUBVOLUME_ALREADY_CONVERTED_IN_xfsvc_FILE_xconv                               401623
#define ERROR_IN_xdbint_IN_xfsvc_FILE_xconv                                                   401633
#define NO_ENOUGH_MEMORY_1_IN_xfsvc_FILE_xconv                                                401643
#define CAN_NOT_FREE_MEMORY_1_IN_xfsvc_FILE_xconv                                             401653


#define ERROR_IN_xshsaq_IN_xfshc_FILE_xconv                                                   401703
#define ERROR_IN_xshsag_IN_xfshc_FILE_xconv                                                   401713
#define ERROR_IN_xfarc_IN_xfshc_FILE_xconv                                                    401723
#define ERROR_IN_xfsac_IN_xfshc_FILE_xconv                                                    401733
#define ERROR_IN_sewsh_IN_xfshc_FILE_xconv                                                    401743
#define SHAPES_XSHELL_ALREADY_CONVERTED_IN_xfshc_FILE_xconv                                   401753
#define ERROR_IN_xdbint_IN_xfshc_FILE_xconv                                                   401763
#define NO_ENOUGH_MEMORY_1_IN_xfshc_FILE_xconv                                                401773
#define CAN_NOT_FREE_MEMORY_1_IN_xfshc_FILE_xconv                                             401783


#define ERROR_IN_xarsaq_IN_xfarc_FILE_xconv                                                   401803
#define ERROR_IN_xarsag_IN_xfarc_FILE_xconv                                                   401813
#define ERROR_IN_xfsac_IN_xfarc_FILE_xconv                                                    401823
#define ERROR_IN_xarlpq_IN_xfarc_FILE_xconv                                                   401833
#define ERROR_IN_xarlpg_IN_xfarc_FILE_xconv                                                   401843
#define ERROR_IN_xflpc_IN_xfarc_FILE_xconv                                                    401853
#define ERROR_IN_sewar_IN_xfarc_FILE_xconv                                                    401863
#define ERROR_IN_arsaa_IN_xfarc_FILE_xconv                                                    401873
#define ERROR_IN_xdbint_IN_xfarc_FILE_xconv                                                   401883
#define NO_ENOUGH_MEMORY_1_IN_xfarc_FILE_xconv                                                401893
#define NO_ENOUGH_MEMORY_2_IN_xfarc_FILE_xconv                                                401903
#define CAN_NOT_FREE_MEMORY_1_IN_xfarc_FILE_xconv                                             401913
#define CAN_NOT_FREE_MEMORY_2_IN_xfarc_FILE_xconv                                             401923


#define ERROR_IN_xBasicGeom_Manifold_Check_IN_xfsac_FILE_xconv                                401983
#define SHAPES_NON_MANIFOLD_GEOMETRY_IN_xfsac_FILE_xconv                                      401993
#define ERROR_IN_xGeomOrientation_Ansys_IN_xfsac_FILE_xconv                                   402003
#define ERROR_IN_xuidg_IN_xfsac_FILE_xconv                                                    402013
#define ERROR_IN_xsalpq_IN_xfsac_FILE_xconv                                                   402023
#define ERROR_IN_xsalpg_IN_xfsac_FILE_xconv                                                   402033
#define ERROR_IN_xflpc_IN_xfsac_FILE_xconv                                                    402043
#define ERROR_IN_sasuq_IN_xfsac_FILE_xconv                                                    402053
#define ERROR_IN_xsasuq_IN_xfsac_FILE_xconv                                                   402063
#define ERROR_IN_sasug_IN_xfsac_FILE_xconv                                                    402073
#define ERROR_IN_xsasug_IN_xfsac_FILE_xconv                                                   402083
#define ERROR_IN_trmsa_IN_xfsac_FILE_xconv                                                    402093
#define SHAPES_XSUBAREA_ALREADY_CONVERTED_IN_xfsac_FILE_xconv                                 402103
#define ERROR_IN_entgt1_IN_xfsac_FILE_xconv                                                   402113
#define ERROR_IN_xdbint_IN_xfsac_FILE_xconv                                                   402123
#define NO_ENOUGH_MEMORY_1_IN_xfsac_FILE_xconv                                                402133
#define NO_ENOUGH_MEMORY_2_IN_xfsac_FILE_xconv                                                402143
#define CAN_NOT_FREE_MEMORY_1_IN_xfsac_FILE_xconv                                             402153
#define CAN_NOT_FREE_MEMORY_2_IN_xfsac_FILE_xconv                                             402163


#define ERROR_IN_xlpslq_IN_xflpc_FILE_xconv                                                   402203
#define ERROR_IN_xlpslg_IN_xflpc_FILE_xconv                                                   402213
#define ERROR_IN_xflsc_IN_xflpc_FILE_xconv                                                    402223
#define ERROR_IN_xfslc_IN_xflpc_FILE_xconv                                                    402233
#define ERROR_IN_sewlp_IN_xflpc_FILE_xconv                                                    402243
#define SHAPES_XLOOP_ALREADY_CONVERTED_IN_xflpc_FILE_xconv                                    402253
#define ERROR_IN_xdbint_IN_xflpc_FILE_xconv                                                   402263
#define NO_ENOUGH_MEMORY_1_IN_xflpc_FILE_xconv                                                402273
#define CAN_NOT_FREE_MEMORY_1_IN_xflpc_FILE_xconv                                             402283

#define ERROR_IN_xlsslq_IN_xflsc_FILE_xconv                                                   402303
#define ERROR_IN_xlsslg_IN_xflsc_FILE_xconv                                                   402313
#define ERROR_IN_xfslc_IN_xflsc_FILE_xconv                                                    402323
#define ERROR_IN_sewls_IN_xflsc_FILE_xconv                                                    402333
#define ERROR_IN_lssla_IN_xflsc_FILE_xconv                                                    402343
#define ERROR_IN_xdbint_IN_xflsc_FILE_xconv                                                   402353
#define NO_ENOUGH_MEMORY_1_IN_xflsc_FILE_xconv                                                402363
#define CAN_NOT_FREE_MEMORY_1_IN_xflsc_FILE_xconv                                             402373


#define ERROR_IN_xGeomOrientation_Ansys_IN_xfslc_FILE_xconv                                   402403
#define ERROR_IN_xuidg_IN_xfslc_FILE_xconv                                                    402413
#define ERROR_IN_xslptg_IN_xfslc_FILE_xconv                                                   402423
#define ERROR_IN_xfptc_IN_xfslc_FILE_xconv                                                    402433
#define ERROR_IN_slcuq_IN_xfslc_FILE_xconv                                                    402443
#define ERROR_IN_xslcuq_IN_xfslc_FILE_xconv                                                   402453
#define ERROR_IN_slcug_IN_xfslc_FILE_xconv                                                    402463
#define ERROR_IN_xslcug_IN_xfslc_FILE_xconv                                                   402473
#define ERROR_IN_trmsl_IN_xfslc_FILE_xconv                                                    402483
#define SHAPES_XSUBLINE_ALREADY_CONVERTED_IN_xfslc_FILE_xconv                                 402493
#define ERROR_IN_entgt1_IN_xfslc_FILE_xconv                                                   402503
#define ERROR_IN_xdbint_IN_xfslc_FILE_xconv                                                   402513
#define NO_ENOUGH_MEMORY_1_IN_xfslc_FILE_xconv                                                402523
#define CAN_NOT_FREE_MEMORY_1_IN_xfslc_FILE_xconv                                             402533


#define ERROR_IN_xfptc_IN_xfkpc_FILE_xconv                                                    402603
#define ERROR_IN_ptkp_IN_xfkpc_FILE_xconv                                                     402613
#define NO_ENOUGH_MEMORY_1_IN_xfkpc_FILE_xconv                                                402623
#define CAN_NOT_FREE_MEMORY_1_IN_xfkpc_FILE_xconv                                             402633



#define ERROR_IN_xuidg_IN_xfptc_FILE_xconv                                                    402703
#define ERROR_IN_xptcog_IN_xfptc_FILE_xconv                                                   402713
#define ERROR_IN_ptcr_IN_xfptc_FILE_xconv                                                     402723
#define SHAPES_XPOINT_ALREADY_CONVERTED_IN_xfptc_FILE_xconv                                   402733
#define ERROR_IN_xdbint_IN_xfptc_FILE_xconv                                                   402743


#define ENTITY_EXIST_1_IN_xdbint_FILE_xdb                                                     500003
#define NO_ENOUGH_MEMORY_1_IN_xdbint_FILE_xdb                                                 500013
#define NO_ENOUGH_MEMORY_2_IN_xdbint_FILE_xdb                                                 500023
#define NO_ENOUGH_MEMORY_3_IN_xdbint_FILE_xdb                                                 500033
#define NO_ENOUGH_MEMORY_4_IN_xdbint_FILE_xdb                                                 500043
#define NO_ENOUGH_MEMORY_5_IN_xdbint_FILE_xdb                                                 500053
#define NO_ENOUGH_MEMORY_6_IN_xdbint_FILE_xdb                                                 500063
#define NO_ENOUGH_MEMORY_7_IN_xdbint_FILE_xdb                                                 500073
#define NO_ENOUGH_MEMORY_8_IN_xdbint_FILE_xdb                                                 500083
#define NO_ENOUGH_MEMORY_9_IN_xdbint_FILE_xdb                                                 500093
#define NO_ENOUGH_MEMORY_10_IN_xdbint_FILE_xdb                                                500103
#define NO_ENOUGH_MEMORY_11_IN_xdbint_FILE_xdb                                                500113
#define NO_ENOUGH_MEMORY_12_IN_xdbint_FILE_xdb                                                500123
#define NO_ENOUGH_MEMORY_13_IN_xdbint_FILE_xdb                                                500133
#define NO_ENOUGH_MEMORY_14_IN_xdbint_FILE_xdb                                                500143
#define NO_ENOUGH_MEMORY_15_IN_xdbint_FILE_xdb                                                500153
#define NO_ENOUGH_MEMORY_16_IN_xdbint_FILE_xdb                                                500163
#define NO_ENOUGH_MEMORY_17_IN_xdbint_FILE_xdb                                                500173
#define NO_ENOUGH_MEMORY_18_IN_xdbint_FILE_xdb                                                500183


#define NOT_VALID_ANSYS_ENTITY_TYPE_IN_xdelfm_FILE_xdb                                        500203
#define ANSYS_FRAMES_NOT_FOUND_IN_xdelfm_FILE_xdb                                             500213
#define SHAPES_FRAMES_NOT_FOUND_IN_xdelfm_FILE_xdb                                            500223
#define ERROR_IN_xdbdel_IN_xdelfm_FILE_xdb                                                    500323


#define FAIL_ON_ALIGNMENT_REQUIREMENT_1_IN_xheap_init_FILE_xheapm                             600003
#define FAIL_ON_ALIGNMENT_REQUIREMENT_2_IN_xheap_init_FILE_xheapm                             600013
#define NO_ENOUGH_MEMORY_1_IN_xheap_init_FILE_xheapm                                          600023
#define NO_ENOUGH_MEMORY_2_IN_xheap_init_FILE_xheapm                                          600033
