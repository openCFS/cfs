
/*
 *    author/date: yu-hua ting/05-04-94
 *
 *    primary function:
 *
 *      Header for the generic "heap memory management" routines
 *
 *    secondary function:
 *
 *        none
 *
 *    routines included:
 *
 *        none
 *
 *    history
 *
 *        none
 *
 *    comments:
 *
 *        none
 *
 *    Notice - This file contains ANSYS Confidential information ***
 *
 */
/* 
 * *** copyright(c) 2010 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */



/****************************************************************************
 *    Initialize the heap memory management and return a "heap tag"         *
 *   (source_memory, *top_ptr, *bottom_ptr, *positive_ptr, *negative_ptr,   *
 *    should be aligned along the boundary of data type DOUBLE)             *
 *                                                                          *
 *    Return heap_memory_size                                               *
 *                                                                          *
 ****************************************************************************/

      extern INT xaxHeapInit ansPROTO((
             xaxADDR source_memory, /* I   - source memory of a heap 
                                            (the beginning of the source memory should 
                                             be aligned along the boundary of DOUBLE      */
             INT *top_ptr,          /* I   - pointer to the top(start) position of the
                                             heap                                         */
             INT *bottom_ptr,       /* I   - pointer to the bottom(end) position of the
                                             heap                                         */
             INT *positive_ptr,     /* I/O - pointer to the position which moves in 
                                             positive direction from top to bootom
                                             of the heap                                  */
             INT *negative_ptr,     /* I/O - pointer to the position which moves in 
                                             negative direction from bottom to top
                                             of the heap                                  */ 
             INT growing_direction, /* I   - heap moving direction
                                             == 1  - positive direction (top -> bottom)
                                     *       == -1 - negative direction (bottom -> top)   */
             INT *num_nodes,        /* I/O - number of memory nodes to be used to manage 
                                     *       the heap memory                              */
             INT *initial_heap_size,/* I/O - initial heap size to be allocated            */
             INT imethod,           /* I   - == USE_SEPARATED_BOOK_KEEPING_SPACE
                                             == DO_NOT_USE_SEPARATED_BOOK_KEEPING_SPACE   */
             INT *heap_tag,
             INT     *iretp));      /*   O - error code
                                     *       == 0 - no error
                                     *       != 0 - error                                 */



/****************************************************************************
 *    Close the heap memory management                                      *
 *                                                                          *
 *    Return error_code  == 0 - ok                                          *
 *                       != 0 - error                                       *
 *                                                                          *
 ****************************************************************************/

      extern INT xaxHeapClose ansPROTO((
             INT *positive_ptr,     /* I   - pointer to the position which moves in
                                             positive direction from top to bootom
                                             of the heap                                  */
             INT *negative_ptr,     /* I   - pointer to the position which moves in
                                             negative direction from bottom to top
                                             of the heap                                  */
             INT heap_tag));        /* I     heap tag                                     */

/****************************************************************************
 *    Allocate a heap memory in bytes, it will return the start             *
 *    virtual memory address of the heap memory to be allocated             *
 ****************************************************************************/

      extern xaxADDR xaxHeapMalloc ansPROTO((
             INT *positive_ptr,            /* I/0 - pointer to the position which moves
                                                    in positive direction from top to
                                                    bootom of the heap                  */
             INT *negative_ptr,            /* I   - pointer to the position which moves
                                                    to negative direction from bottom to
                                                    top of the heap                     */
             INT num_bytes,                /* I   - number of bytes of the heap memory  
                                            *       to be allocated                     */
             INT initialize_to_zero_bytes, /* I   - flag for initializing the allocated 
                                            *       memory to zero bytes
                                            *       == TRUE  - initializing to zero bytes
                                            *       == FALSE - otherwise                */
             INT application_id,           /* I   - application id of the memory        */
             INT heap_tag));               /* I     heap tag                            */


              

/****************************************************************************
 *    Free a heap memory with a given virtual memory address                *
 ****************************************************************************/


      extern INT xaxHeapFree ansPROTO(( 
             xaxADDR virtual_memory_address,
             INT     application_id,         /* I    application id of the memory  */
             INT     heap_tag));
       





/****************************************************************************
 *    Return a free "heap tag" >= 0 - ok                                    *
 *                             <  0 - error                                 *
 ****************************************************************************/

      extern INT xaxHeapGetTag ansPROTO(( 
             INT tag));
     

/****************************************************************************
 *    Adjust the alignments                                                 *
 ****************************************************************************/

      extern INT xaxHeapAdjustAlignments ansPROTO((
             INT *num_nodes,         /* I/0 - number of memory nodes to be used to  
                                      *       manage the heap memory                      */
             INT *initial_heap_size, /* I/O - initial heap size to be allocated           */
             INT imethod,            /* I   - == USE_SEPARATED_BOOK_KEEPING_SPACE
                                             == DO_NOT_USE_SEPARATED_BOOK_KEEPING_SPACE  */
             INT heap_tag));


/****************************************************************************
 *    Verify the initial address alignments                                 *
 *                                                                          *
 ****************************************************************************/


      extern INT xaxHeapVerifyInitialAlignments ansPROTO((
             xaxADDR source_memory, /* I   - source memory of a heap 
                                            (the beginning of the source memory should 
                                             be aligned along the boundary of DOUBLE      */
             INT *top_ptr,          /* I   - pointer to the top(start) position of the
                                             heap                                         */
             INT *bottom_ptr,       /* I   - pointer to the bottom(end) position of the
                                             heap                                         */
             INT *positive_ptr,     /* I/O - pointer to the position which moves in 
                                             positive direction from top to bootom
                                             of the heap                                  */
             INT *negative_ptr,     /* I/O - pointer to the position which moves in 
                                             negative direction from bottom to top
                                             of the heap                                  */ 
             INT growing_direction, /* I   - heap moving direction
                                             == 1  - positive direction (top -> bottom)
                                     *       == -1 - negative direction (bottom -> top)   */
             INT heap_tag));        /* I   - heap tag                                     */

/****************************************************************************
 *    Check for enough memory                                               *
 *                                                                          *
 *    Return  >  0 - ok       (min_memory_size                               *
 *            <= 0 - error    (-min_memory_size)                            *
 *                                                                          *
 ****************************************************************************/

      extern INT xaxHeapCheckForEnoughMemory ansPROTO((
             INT available_memory_size, /* I   - available source memory size                */
             INT *num_nodes,            /* I   - number of memory nodes to be used to  
                                         *       manage the heap memory                      */
             INT *initial_heap_size,    /* I   - initial heap size to be allocated           */
             INT imethod));             /* I   - == USE_SEPARATED_BOOK_KEEPING_SPACE
                                                 == DO_NOT_USE_SEPARATED_BOOK_KEEPING_SPACE  */


/****************************************************************************
 *    Save initial heap information                                         *
 ****************************************************************************/

      extern VOID xaxHeapSaveInitInfo ansPROTO((
             xaxADDR source_memory, /* I   - source memory of a heap 
                                            (the beginning of the source memory should 
                                             be aligned along the boundary of DOUBLE      */
             INT *top_ptr,          /* I   - pointer to the top(start) position of the
                                             heap                                         */
             INT *bottom_ptr,       /* I   - pointer to the bottom(end) position of the
                                             heap                                         */
             INT *positive_ptr,     /* I   - pointer to the position which moves in 
                                             positive direction from top to bootom
                                             of the heap                                  */
             INT *negative_ptr,     /* I   - pointer to the position which moves in 
                                             negative direction from bottom to top
                                             of the heap                                  */ 
             INT growing_direction, /* I   - heap moving direction
                                             == 1  - positive direction (top -> bottom)
                                     *       == -1 - negative direction (bottom -> top)   */
             INT *num_nodes,        /* I   - number of memory nodes to be used to manage 
                                     *       the heap memory                              */
             INT *initial_heap_size,/* I   - initial heap size to be allocated            */
             INT imethod,           /* I   - == USE_SEPARATED_BOOK_KEEPING_SPACE
                                             == DO_NOT_USE_SEPARATED_BOOK_KEEPING_SPACE   */
             INT heap_tag));        /* I     heap tag                                     */
       
       
/****************************************************************************
 *    Initialize the memory nodes of the storage pool                       *
 ****************************************************************************/



      extern VOID xaxHeapInitMemoryNodes ansPROTO((
             INT nodes[],    /* I/O  storage pool for the memory nodes. It has the
                              *      size == *num_nodes * XHEAP_NODE_SIZE          */
             INT heap_tag)); /* I    heap tag                                      */



/****************************************************************************
 *    Allocate memory in integer words from the source memory               *
 ****************************************************************************/

      extern VOID xaxHeapAllocSourceMemory ansPROTO((
             INT *positive_ptr,     /* I   - pointer to the position which moves in
                                             positive direction from top to bootom
                                             of the heap                                  */
             INT *negative_ptr,     /* I   - pointer to the position which moves in
                                             negative direction from bottom to top
                                             of the heap                                  */
             INT growing_direction, /* I   - heap moving direction   
                                             == 1  - positive direction (top -> bottom)
                                     *       == -1 - negative direction (bottom -> top)   */
             INT imethod,           /* I   - == USE_SEPARATED_BOOK_KEEPING_SPACE
                                             == DO_NOT_USE_SEPARATED_BOOK_KEEPING_SPACE   */
             INT *isize,            /* I/O - size of the allocated source memory          */

             INT *offset,           /*   O - pointer to the offset of the allocated 
                                             source memory     
                                             >  0 - ok
                                             <= 0 - error                                 */
             INT     *iretp));      /*   O - error code
                                     *       == 0 - no error
                                     *       != 0 - error                                 */



 
/****************************************************************************
 *    Initialize the memory node storage pool as a double-linked list       *
 *                                                                          *
 *    Return offset  >  0 - ok                                              *
 *                   <= 0 - error                                           *
 *                                                                          *
 ****************************************************************************/

      extern INT xaxHeapInitStoragePool ansPROTO((
             INT *positive_ptr,     /* I/O - pointer to the position which moves in 
                                             positive direction from top to bootom
                                             of the heap                                  */
             INT *negative_ptr,     /* I/O - pointer to the position which moves in 
                                             negative direction from bottom to top
                                             of the heap                                  */ 
             INT heap_tag));        /* I     heap tag                                     */



/****************************************************************************
 *    Allocate the initial heap                                             *
 *                                                                          *
 *    Return offset  >  0  - ok                                             *
 *                   <= 0  - error                                          *
 *                                                                          *
 ****************************************************************************/

      extern INT xaxHeapAllocateInit ansPROTO((
             INT *positive_ptr,     /* I/O - pointer to the position which moves in
                                             positive direction from top to bootom
                                             of the heap                                  */
             INT *negative_ptr,     /* I/O - pointer to the position which moves in
                                             negative direction from bottom to top
                                             of the heap                                  */
             INT heap_tag));        /* I     heap tag                                     */

/****************************************************************************
 *    get the next available node pointer from the memory node storage pool *
 ****************************************************************************/

      extern INT xaxHeapGetNode ansPROTO((
             INT nodes[],           /* I/O - storage pool for the memory nodes.          */
             INT *num_nodes,        /* I/O - number of free memory nodes                 */
             INT *head_nodep));     /* I/O - pointer to the head pointer to the list of
                                             free memory nodes                           */


 


 
/****************************************************************************
 *    free a node to the memory node storage pool                           *
 ****************************************************************************/
 
      extern VOID xaxHeapFreeNode ansPROTO((
             INT nodes[],          /* I/O - storage pool for the memory nodes.            */
             INT *num_nodes,       /* I/O - number of free memory nodes                   */
             INT *head_nodep,      /* I/O - pointer to the head pointer to the list of 
                                    *       free memory nodes                             */
             INT *nodep));         /* I     pointer to the node pointer to be free        */
       


/****************************************************************************
 *    Fill the information into the node                                    *
 ****************************************************************************/


      extern VOID xaxHeapFillNode ansPROTO((
             INT nodes[],          /* I O  storage pool for the memory nodes             */
             INT nodep,            /* I    pointer to the memory node pointer            */
             INT offset,           /* I    pointer to the offset of the memory           */
             INT isize,            /* I    pointer to the size of the memory             */
             INT application_id)); /* I    application id of the memory                  */




/****************************************************************************
 *    insert a memory node into a sorted double-linked list                 *
 ****************************************************************************/


      extern VOID xaxHeapInsertNode ansPROTO((
             INT nodes[],           /* I O  storage pool for the memory nodes            */
             INT *num_nodes,        /* I/O - number of free memory nodes                 */
             INT *head_nodep,       /* I/O - pointer to the head pointer to the list of
                                    *       free memory nodes                            */
             INT *list_size,        /* I O  size of the double-linked list               */
             INT *list_headp,       /* I O  pointer to the head pointer of the 
                                     *      double-linked list                           */
             INT *list_tailp,       /* I O  pointer to the tail pointer of the
                                     *      double-linked list                           */
             INT *nodep,            /* I    pointer to node pointer to be inserted       */
             INT iopt));            /* I    == 0 - search from the head of the list
                                     *      == 1 - search from the tail of the list     
                                     *      == 2 - search from the head of the list and
                                     *             combine memory nodes if they are
                                     *             adjacent to each other               
                                     *      == 3 - search from the tail of the list and
                                     *             combine memory nodes if they are
                                     *             adjacent to each other                */
       
 
/****************************************************************************
 *    Search a used memory node from the used_memory_list                   *
 ****************************************************************************/

      extern INT xaxHeapSearchUsedNode ansPROTO((
             INT nodes[],           /* I O  storage pool for the memory nodes             */
             INT *list_size,        /* I O  size of the double-linked list                */
             INT *list_headp,       /* I O  pointer to the head pointer of the 
                                     *      double-linked list                            */
             INT *list_tailp,       /* I O  pointer to the tail pointer of the
                                     *      double-linked list                            */
             INT *offset,           /* I    pointer to the offset of the used memory node 
                                     *      to be searched                                */
             INT *isize,            /*   O  pointer to the size of the used memory node
                                     *      found                                         */
             INT application_id,    /* I    application id of the used memory node to be 
                                     *      searched                                      */
             INT iopt));            /* I    == 0 - search from the head of the list
                                     *      == 1 - search from the tail of the list       */


 
/****************************************************************************
 *    Search a free memory node from the free_memory_list                   *
 *                                                                          *
 *    return nodep >  0 - ok                                                *
 *                 <  0 - error (application_id does not match)             *
 *                 =  0 - error (not found)                                 *
 ****************************************************************************/
 
      extern INT xaxHeapSearchFreeNode ansPROTO((
             INT nodes[],           /* I O  storage pool for the memory nodes             */
             INT *num_nodes,        /* I/O - number of free memory nodes                  */
             INT *head_nodep,       /* I/O - pointer to the head pointer to the list of   */
             INT *list_size,        /* I O  size of the double-linked list                */
             INT *list_headp,       /* I O  pointer to the head pointer of the 
                                     *      double-linked list                            */
             INT *list_tailp,       /* I O  pointer to the tail pointer of the
                                     *      double-linked list                            */
             INT *offset,           /*   O  pointer to the offset of the free memory node 
                                     *      found                                         */
             INT growing_direction,
             INT isize,             /* I    the size of the free memory node 
                                     *      to be searched                                */
             INT application_id,    /* I    application id of the used memory node to be 
                                     *      searched                                      */
             INT iopt));            /* I    == 0 - search from the head of the list
                                     *      == 1 - search from the tail of the list       */

/****************************************************************************
 *    Delete the initial free memory node with the offset                   *
 *    initial_heap_offset , and the size xheap_initial_heap_size            *
 ****************************************************************************/

      extern VOID xaxHeapDeleteInitFreeNodes ansPROTO((
             INT nodes[],                 /* I/O - storage pool for the memory nodes      */
             INT initial_heap_size,       /* I/O - initial heap size to be allocated      */
             INT initial_heap_offset,     /* I/O - initial heap offset                    */
             INT *num_nodes,              /* I/O - number of free memory nodes            */
             INT *head_nodep,             /* I/O - pointer to the head pointer to the 
                                           *       list of free memory nodes              */
             INT *free_memory_list_size,  /* I/O - size of the free_memory list           */
             INT *free_memory_list_headp, /* I/O  pointer to the head pointer of the
                                     *            free_memory list                        */
             INT *free_memory_list_tailp)); /* I/O  pointer to the tail pointer of the  
                                           *      free_memory  list                       */




/****************************************************************************
 *    get the heap memory usage                                             *
 ****************************************************************************/

      extern INT xaxHeapMemoryUsage ansPROTO((
             INT iopt,
             INT heap_tag));

