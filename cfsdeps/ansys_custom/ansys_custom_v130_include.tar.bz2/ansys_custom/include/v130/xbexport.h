/*
 *    author/date: yu-hua ting/05-12-94
 *
 *    primary function:
 *
 *       Header for the Exported Fortran-callable routines
 *
 *    secondary function:
 *
 *        Header for Fortran-callable (from aux15.F) isf_wrap() routine
 *        for importing of STEP files.
 *        --epm.
 *
 *        And lots more... is probably in desperate need of cleaning up!!!
 *        --epm
 *
 * comments:
 *
 * i). Since the input geoms will be destroyed during the boolean operations,
 *     any subgeoms shared by input geoms with other non_input geoms will be
 *     destroyed too and hence we can not perform any boolean operation (may be
 *     except "merge" and "overlap" operations) with mutiple inputs (i.e., the
 *     number of inputs > 2) by translating all input geoms simultaneously and
 *     without making copies of input geoms. But the connectness may be lost,
 *    if we use copies.
 *
 *    Notice - This file contains ANSYS Confidential information ***
 */
/* 
 * *** copyright(c) 2010 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */



#if defined(RS6000_SYS) || defined(HP32_SYS)
#define xAnsysAreaClosed_       xansysareaclosed
#define xAnsysSaveTol_          xansyssavetol
#define xAnsysResumeTol_        xansysresumetol
#define xAnsysEntityType_       xansysentitytype
#define xAnsysSmoothEvl_        xansyssmoothevl
#define xAnsysMerge_            xansysmerge
#define xAnsysSplitEdge_        xansyssplitedge
#define xAnsysSplitSurface_     xansyssplitsurface
#define xAnsysCollapse_         xansyscollapse
#define xAnsysRemoveHole_       xansysremovehole
#define xAnsysRemoveEnts_       xansysremoveents
#define xAnsysChangeTol_        xansyschangetol
#define xAnsysTessMax_          xansystessmax
#define xAnsysUnSewEnts_        xansysunsewents
#define xAnsysAutoIges_         xansysautoiges
#define xAnsysIgesGms_          xansysigesgms
#define xAnsysPointWeld_        xansyspointweld
#define xAnsysForceWeld_        xansysforceweld
#define xAnsysImposeMatch_      xansysimposematch
#define xAnsysGetUnMatch_       xansysgetunmatch
#define xAnsysGetSeamEdg_       xansysgetseamedg
#define xAnsysGetMatch_         xansysgetmatch
#define xAnsysSetMatchTol_      xansyssetmatchtol
#define xAnsysGetLimits_        xansysgetlimits
#define xAnsysWeld_             xansysweld
#define xAnsysUnWeld_           xansysunweld
#define xAnsysSetTessTol_       xansyssettesstol
#define xAnsysTessRefine_       xansystessrefine
#define xAnsysChkIsoEnt_        xansyschkisoent
#define xAnsysChkUnsewEnt_      xansyschkunsewent
#define xAnsysWebify_           xansyswebify
#define xAnsysSolids_           xansyssolids
#define xAnsysSurFromBnd_       xansyssurfrombnd
#define xAnsysCurFromPts_       xansyscurfrompts
#define xAnsysSetData_          xansyssetdata
#define xPrintGeom_             xprintgeom
#define xAnsysGmsFromIges_      xansysgmsfromiges
#define xAnsysEntCenter_        xansysdencenter
#define xAnsysClosedEntInq_     xansysclosedentinq
#define xAnsysDegenInq_         xansysdegeninq
#define xAnsysCheckConnect_     xansyscheckconnect
#define xAnsysGmDelete_         xansysgmdelete
#define xAnsysGmDeleteAll_      xAnsysgmdeleteall
#define xAnsysGeomSize_         xansysgeomsize
#define xAnsysGeomId_           xansysgeomid
#define xAnsysSubEntXYZ_        xansyssubentxyz
#define xAnsysSubEntEnts_       xansyssubentents
#define xAnsysSubEntSurface_    xansyssubentsurface
#define xAnsysSESupCells_       xansyssesupcells
#define xAnsysSubEntCurveSurfaceMaps_ xansyssubentcurvesurfacemaps
#define xAnsysSubEntEndPoints_  xansyssubentendpoints
#define xAnsysSubEntSubLineData_ xansyssubentsublinedata
#define xAnsysSEFrameSize_      xansysseframesize
#define xAnsysSEFrameTree_      xansysseframetree
#define xAnsysSEFrameCells_     xansysseframecells
#define xAnsysSubEntSubAreaData_ xansyssubentsubareadata
#define xAnsysSubEntNumNodes_   xansyssubentnumnodes
#define xAnsysSubEntNodes_      xansyssubentnodes
#define xAnsysSubEntElements_   xansyssubentelements
#define xAnsysSubEntNumFrames_  xansyssubentnumframes

#define xAnsysEntFrameTree_     xansysentframetree
#define xAnsysEntSupEnts_       xansysentsupents
#define xAnsysLineEndPoints_    xansyslineendpoints
#define xAnsysEntCells_         xansysentcells
#define xAnsysLineParamData_    xansyslineparamdata
#define xAnsysEntFrameSize_     xansysentframesize
#define xAnsysEntFrame_         xansysentframe
#define xAnsysAreaParamData_    xansysareaparamdata
#define xAnsysVolumeParamData_  xansysvolumeparamdata
#define xAnsysEntNumFrames_     xansysentnumframes

#define xAnsysMapCells_         xansysmapcells
#define xAnsysMapType_          xansysmaptype
#define xAnsysMapForm_          xansysmapform

#define xAnsysSubEntIdMax_      xansyssubentidmax
#define xAnsysSubEntSupCellMax_ xansyssubentsupcellmax
#define xAnsysSubEntMax_        xansyssubentmax
#define xAnsysEntCellMax_       xansysentcellmax
#define xAnsysMapCellMax_       xansysmapcellmax
#define xAnsysEntSupEntMax_     xansysentsupentmax

#define xAnsysTessInq_ xansystessinq
#define xAnsysTessEnt_ xansystessent
#define xAnsysGetTess_ xansysgettess
#define xAnsysEntDrv_  xansysentdrv
#define xAnsysEntEvl_  xansysentevl
#define xAnsysEntPrj_  xansysentprj

#define axoxrecover_   axoxrecover
#define axoxinit_      axoxinit
#define axoxvminit_    axoxvminit
#define xAnsysSavGms_  xansyssavgms
#define xAnsysResGms_  xansysresgms
#define aXoxVmOpen_    axoxvmopen
#define aXoxVmClose_   axoxvmclose

#define run_xox_ run_xox
#define xx_toansys_geom_ xx_toansys_geom
#define xx_gcom_flag_ xx_gcom_flag
#define xoxopn_ xoxopn
#define xoxcls_ xoxcls
#define xoxcls1_ xoxcls1
#define xconvt_ xconvt
#define xconvt_wp_ xconvt_wp
#define xconvt_ig53_ xconvt_ig53
#define frn_cr_wrkpl_ frn_cr_wrkpl
#define frn_subtract_ frn_subtract
#define frn_addition_ frn_addition
#define xngeom_ xngeom
#define xgeoms_ xgeoms
#define xhalfspaces_ xhalfspaces
#define xsubc_sepo_  xsubc_sepo
#define xcomp_conn_  xcomp_conn
#define xclafy_ xclafy
#define xdiffn_ xdiffn
#define xsubc_  xsubc
#define xsubc_ig53_  xsubc_ig53
#define xintst_ xintst
#define xintss_ xintss
#define xintsp_ xintsp
#define xaddss_ xaddss
#define xmerss_ xmerss
#define xovers_ xovers
#define xcutc_  xcutc
#define xgsimp_ xgsimp
#define xdstpg_ xdstpg
#define xevalg_ xevalg
#define xsewnc_ xsewnc
#define xgrpc_  xgrpc
#define xnseam_ xnseam
#define xnsub_ xnsub
#define xfiltr_ xfiltr
#define xmemgt_ xmemgt
#define ahpini_ ahpini
#define ahpcls_ ahpcls

#define isf_wrap_ isf_wrap


/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

#elif defined(WATCOMC_SYS) \
      || defined(PCWINNT_SYS)

#define xAnsysAreaClosed_       XANSYSAREACLOSED
#define xAnsysSaveTol_          XANSYSSAVETOL
#define xAnsysResumeTol_        XANSYSRESUMETOL
#define xAnsysEntityType_       XANSYSENTITYTYPE
#define xAnsysSmoothEvl_        XANSYSSMOOTHEVL
#define xAnsysMerge_            XANSYSMERGE
#define xAnsysSplitEdge_        XANSYSSPLITEDGE
#define xAnsysSplitSurface_     XANSYSSPLITSURFACE
#define xAnsysCollapse_         XANSYSCOLLAPSE
#define xAnsysRemoveHole_       XANSYSREMOVEHOLE
#define xAnsysRemoveEnts_       XANSYSREMOVEENTS
#define xAnsysChangeTol_        XANSYSCHANGETOL
#define xAnsysTessMax_          XANSYSTESSMAX
#define xAnsysUnSewEnts_        XANSYSUNSEWENTS
#define xAnsysAutoIges_         XANSYSAUTOIGES
#define xAnsysIgesGms_          XANSYSIGESGMS
#define xAnsysPointWeld_        XANSYSPOINTWELD
#define xAnsysForceWeld_        XANSYSFORCEWELD
#define xAnsysWeld_             XANSYSWELD
#define xAnsysSetTessTol_       XANSYSSETTESSTOL
#define xAnsysTessRefine_       XANSYSTESSREFINE
#define xAnsysImposeMatch_      XANSYSIMPOSEMATCH
#define xAnsysGetMatch_         XANSYSGETMATCH
#define xAnsysGetUnMatch_       XANSYSGETUNMATCH
#define xAnsysGetSeamEdg_       XANSYSGETSEAMEDG
#define xAnsysSetMatchTol_      XANSYSSETMATCHTOL
#define xAnsysGetLimits_        XANSYSGETLIMITS
#define xAnsysUnWeld_           XANSYSUNWELD
#define xAnsysChkIsoEnt_        XANSYSCHKISOENT
#define xAnsysChkUnsewEnt_      XANSYSCHKUNSEWENT
#define xAnsysWebify_           XANSYSWEBIFY
#define xAnsysSolids_           XANSYSSOLIDS
#define xAnsysSurFromBnd_       XANSYSSURFROMBND
#define xAnsysCurFromPts_       XANSYSCURFROMPTS
#define xAnsysSetData_          XANSYSSETDATA
#define xPrintGeom_             XPRINTGEOM
#define xAnsysGmsFromIges_      XANSYSGMSFROMIGES
#define xAnsysEntCenter_        XANSYSENTCENTER
#define xAnsysClosedEntInq_     XANSYSCLOSEDENTINQ
#define xAnsysDegenInq_         XANSYSDEGENINQ
#define xAnsysCheckConnect_     XANSYSCHECKCONNECT
#define xAnsysGmDelete_         XANSYSGMDELETE
#define xAnsysGmDeleteAll_      XANSYSGMDELETEALL
#define xAnsysGeomSize_         XANSYSGEOMSIZE
#define xAnsysGeomId_           XANSYSGEOMID
#define xAnsysSubEntXYZ_        XANSYSSUBENTXYZ
#define xAnsysSubEntEnts_       XANSYSSUBENTENTS
#define xAnsysSubEntSurface_    XANSYSSUBENTSURFACE
#define xAnsysSESupCells_       XANSYSSESUPCELLS
#define xAnsysSubEntCurveSurfaceMaps_ XANSYSSUBENTCURVESURFACEMAPS
#define xAnsysSubEntEndPoints_  XANSYSSUBENTENDPOINTS
#define xAnsysSubEntSubLineData_ XANSYSSUBENTSUBLINEDATA
#define xAnsysSEFrameSize_      XANSYSSEFRAMESIZE
#define xAnsysSEFrameTree_      XANSYSSEFRAMETREE
#define xAnsysSEFrameCells_     XANSYSSEFRAMECELLS
#define xAnsysSubEntSubAreaData_ XANSYSSUBENTSUBAREADATA
#define xAnsysSubEntNumNodes_   XANSYSSUBENTNUMNODES
#define xAnsysSubEntNodes_      XANSYSSUBENTNODES
#define xAnsysSubEntElements_   XANSYSSUBENTELEMENTS
#define xAnsysSubEntNumFrames_  XANSYSSUBENTNUMFRAMES

#define xAnsysEntFrameTree_     XANSYSENTFRAMETREE
#define xAnsysEntSupEnts_       XANSYSENTSUPENTS
#define xAnsysLineEndPoints_    XANSYSLINEENDPOINTS
#define xAnsysEntCells_         XANSYSENTCELLS
#define xAnsysLineParamData_    XANSYSLINEPARAMDATA
#define xAnsysEntFrameSize_     XANSYSENTFRAMESIZE
#define xAnsysEntFrame_         XANSYSENTFRAME
#define xAnsysAreaParamData_    XANSYSAREAPARAMDATA
#define xAnsysVolumeParamData_  XANSYSVOLUMEPARAMDATA
#define xAnsysEntNumFrames_     XANSYSENTNUMFRAMES

#define xAnsysMapCells_         XANSYSMAPCELLS
#define xAnsysMapType_          XANSYSMAPTYPE
#define xAnsysMapForm_          XANSYSMAPFORM

#define xAnsysSubEntIdMax_      XANSYSSUBENTIDMAX
#define xAnsysSubEntSupCellMax_ XANSYSSUBENTSUPCELLMAX
#define xAnsysSubEntMax_        XANSYSSUBENTMAX
#define xAnsysEntCellMax_       XANSYSENTCELLMAX
#define xAnsysMapCellMax_       XANSYSMAPCELLMAX
#define xAnsysEntSupEntMax_     XANSYSENTSUPENTMAX

#define xAnsysTessInq_ XANSYSTESSINQ
#define xAnsysTessEnt_ XANSYSTESSENT
#define xAnsysGetTess_ XANSYSGETTESS
#define xAnsysEntDrv_  XANSYSENTDRV
#define xAnsysEntEvl_  XANSYSENTEVL
#define xAnsysEntPrj_  XANSYSENTPRJ

#define axoxrecover_   AXOXRECOVER
#define axoxinit_      AXOXINIT
#define axoxvminit_    AXOXVMINIT
#define xAnsysSavGms_  XANSYSSAVGMS
#define xAnsysResGms_  XANSYSRESGMS
#define aXoxVmOpen_    AXOXVMOPEN
#define aXoxVmClose_   AXOXVMCLOSE

#define run_xox_ RUN_XOX
#define xx_toansys_geom_ XX_TOANSYS_GEOM
#define xx_gcom_flag_ XX_GCOM_FLAG
#define xoxopn_ XOXOPN
#define xoxcls_ XOXCLS
#define xoxcls1_ XOXCLS1
#define xconvt_ XCONVT
#define xconvt_wp_ XCONVT_WP
#define xconvt_ig53_ XCONVT_IG53
#define frn_cr_wrkpl_ FRN_CR_WRKPL
#define frn_subtract_ FRN_SUBTRACT
#define frn_addition_ FRN_ADDITION
#define xngeom_ XNGEOM
#define xgeoms_ XGEOMS
#define xhalfspaces_ XHALFSPACES
#define xsubc_sepo_  XSUBC_SEPO
#define xcomp_conn_  XCOMP_CONN
#define xclafy_ XCLAFY
#define xdiffn_ XDIFFN
#define xsubc_  XSUBC
#define xsubc_ig53_  XSUBC_IG53
#define xintst_ XINTST
#define xintss_ XINTSS
#define xintsp_ XINTSP
#define xaddss_ XADDSS
#define xmerss_ XMERSS
#define xovers_ XOVERS
#define xcutc_  XCUTC
#define xgsimp_ XGSIMP
#define xdstpg_ XDSTPG
#define xevalg_ XEVALG
#define xsewnc_ XSEWNC
#define xgrpc_  XGRPC
#define xnseam_ XNSEAM
#define xnsub_  XNSUB
#define xfiltr_ XFILTR
#define xmemgt_ XMEMGT
#define ahpini_ AHPINI
#define ahpcls_ AHPCLS

#define isf_wrap_ ISF_WRAP


#else
#define xAnsysAreaClosed_       xansysareaclosed_
#define xAnsysSaveTol_          xansyssavetol_
#define xAnsysResumeTol_        xansysresumetol_
#define xAnsysEntityType_       xansysentitytype_
#define xAnsysSmoothEvl_        xansyssmoothevl_
#define xAnsysMerge_            xansysmerge_
#define xAnsysSplitEdge_        xansyssplitedge_
#define xAnsysSplitSurface_     xansyssplitsurface_
#define xAnsysCollapse_         xansyscollapse_
#define xAnsysRemoveHole_       xansysremovehole_
#define xAnsysRemoveEnts_       xansysremoveents_
#define xAnsysChangeTol_        xansyschangetol_
#define xAnsysTessMax_          xansystessmax_
#define xAnsysUnSewEnts_        xansysunsewents_
#define xAnsysAutoIges_         xansysautoiges_
#define xAnsysIgesGms_          xansysigesgms_
#define xAnsysPointWeld_        xansyspointweld_
#define xAnsysForceWeld_        xansysforceweld_
#define xAnsysImposeMatch_      xansysimposematch_
#define xAnsysGetMatch_         xansysgetmatch_
#define xAnsysGetUnMatch_       xansysgetunmatch_
#define xAnsysGetSeamEdg_       xansysgetseamedg_
#define xAnsysGetMatch_         xansysgetmatch_
#define xAnsysSetMatchTol_      xansyssetmatchtol_
#define xAnsysGetLimits_        xansysgetlimits_
#define xAnsysWeld_             xansysweld_
#define xAnsysUnWeld_           xansysunweld_
#define xAnsysSetTessTol_       xansyssettesstol_
#define xAnsysTessRefine_       xansystessrefine_
#define xAnsysChkIsoEnt_        xansyschkisoent_
#define xAnsysChkUnsewEnt_      xansyschkunsewent_
#define xAnsysWebify_           xansyswebify_
#define xAnsysSolids_           xansyssolids_
#define xAnsysSurFromBnd_       xansyssurfrombnd_
#define xAnsysCurFromPts_       xansyscurfrompts_
#define xAnsysSetData_          xansyssetdata_
#define xPrintGeom_             xprintgeom_
#define xAnsysGmsFromIges_      xansysgmsfromiges_
#define xAnsysEntCenter_        xansysdencenter_
#define xAnsysClosedEntInq_     xansysclosedentinq_
#define xAnsysDegenInq_         xansysdegeninq_
#define xAnsysCheckConnect_     xansyscheckconnect_
#define xAnsysGmDelete_         xansysgmdelete_
#define xAnsysGmDeleteAll_      xansysgmdeleteall_
#define xAnsysGeomSize_         xansysgeomsize_
#define xAnsysGeomId_           xansysgeomid_
#define xAnsysSubEntXYZ_        xansyssubentxyz_
#define xAnsysSubEntEnts_       xansyssubentents_
#define xAnsysSubEntSurface_    xansyssubentsurface_
#define xAnsysSESupCells_       xansyssesupcells_
#define xAnsysSubEntCurveSurfaceMaps_ xansyssubentcurvesurfacemaps_
#define xAnsysSubEntEndPoints_  xansyssubentendpoints_
#define xAnsysSubEntSubLineData_ xansyssubentsublinedata_
#define xAnsysSEFrameSize_      xansysseframesize_
#define xAnsysSEFrameTree_      xansysseframetree_
#define xAnsysSEFrameCells_     xansysseframecells_
#define xAnsysSubEntSubAreaData_ xansyssubentsubareadata_
#define xAnsysSubEntNumNodes_   xansyssubentnumnodes_
#define xAnsysSubEntNodes_      xansyssubentnodes_
#define xAnsysSubEntElements_   xansyssubentelements_
#define xAnsysSubEntNumFrames_  xansyssubentnumframes_

#define xAnsysEntFrameTree_     xansysentframetree_
#define xAnsysEntSupEnts_       xansysentsupents_
#define xAnsysLineEndPoints_    xansyslineendpoints_
#define xAnsysEntCells_         xansysentcells_
#define xAnsysLineParamData_    xansyslineparamdata_
#define xAnsysEntFrameSize_     xansysentframesize_
#define xAnsysEntFrame_         xansysentframe_
#define xAnsysAreaParamData_    xansysareaparamdata_
#define xAnsysVolumeParamData_  xansysvolumeparamdata_
#define xAnsysEntNumFrames_     xansysentnumframes_

#define xAnsysMapCells_         xansysmapcells_
#define xAnsysMapType_          xansysmaptype_
#define xAnsysMapForm_          xansysmapform_

#define xAnsysSubEntIdMax_      xansyssubentidmax_
#define xAnsysSubEntSupCellMax_ xansyssubentsupcellmax_
#define xAnsysSubEntMax_        xansyssubentmax_
#define xAnsysEntCellMax_       xansysentcellmax_
#define xAnsysMapCellMax_       xansysmapcellmax_
#define xAnsysEntSupEntMax_     xansysentsupentmax_

#define xAnsysTessInq_ xansystessinq_
#define xAnsysTessEnt_ xansystessent_
#define xAnsysGetTess_ xansysgettess_
#define xAnsysEntDrv_  xansysentdrv_
#define xAnsysEntEvl_  xansysentevl_
#define xAnsysEntPrj_  xansysentprj_


#define xAnsysSavGms_  xansyssavgms_
#define xAnsysResGms_  xansysresgms_
#define aXoxVmOpen_    axoxvmopen_
#define aXoxVmClose_   axoxvmclose_

#endif

#ifdef _ShapesGeom_hdr
/* "shapesge.h" has already been included! */

#include "ansattr.h"
#include "xox_fix.h"

#else

#include "entity.h"
#include "subent.h"
#include "max.h"
#include "geom.h"
#include "tess.h"

#endif

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

/*
 *    primary function: Subtract the second geometry from the first
 *                      one. The input geometries can be individual
 *                      entity or a group of entities
 *                      (A1 # A2 # .. # Am) - (B1 + B2 + .. + Bn)
 */

  extern VOID CALLTYP xsubc_ig53_ ansPROTO((
      INT geoma[],         /* I    geom numbers of geometries to be subtracted
                            *      from                                       */
      INT *na,             /* I    pointer to the number of geometries to be
                            *      subtracted from                            */
      INT geomb[],         /* I    geom numbers of geometries to be subtracted
                            *                                                 */
      INT *nb,             /* I    pointer to the number of geometries to be
                            *      subtracted                                 */
      INT *sepflg,         /* I    pointer to the resulting entity separation
                            *      flag                                       */
      INT *desflg,         /*      pointer to the flag indicating destructive
                            *      or non-destrucive boolean                  */
      INT *geomo,          /*   O  geom number of the group geom containing
                            *      or non-destrucive boolean                  */
      INT *iretp));        /*   O  error code
                            *      == 0 - no error
                            *      != 0 - error                               */
/*
 * Get SHAPES geometry pointers from given ANSYS enitity numbers
 */
   extern VOID CALLTYP xconvt_ig53_ ansPROTO((
      INT entn[],          /* I/O  ANSYS entity numbers                     */
      INT xentn[],         /* I/O  SHAPES entity numbers                    */
      INT gdims[],         /*      geometry dimensions of entities          */
      INT *nentp,          /* I    pointer to the number of entities        */
      INT *dimp,           /* I    pointer to the common dimensions         */
      INT *dimuse,         /* I    != 0 - data dimp is used
                            *      == 0 - data dimp is not used             */
      INT *iretp));        /*   O  error code
                           *      == 0 - no error
                           *      != 0 - error                             */

   extern INT CALLTYP frn_subtract_ ansPROTO((
     INT geoma[],         /* I    First ansys id list to subtract */
     INT dima[],          /* I    Dimensions of first ansys id list */
     INT *na,             /* I    Size of the first ansys id list */
     INT geomb[],         /* I    Second ansys id list to subtract  */
     INT dimb[],          /* I    Dimensions of second ansys id list */
     INT *nb,             /* I    Size of the second ansys id list */
     INT *sepflg,         /* I    Separation flag                  */
     INT *desflg,         /* I    Keep/delete flag                 */
     INT *geomo,          /* O    Output geometry list             */
     INT *ngeom));          /* O    Size of the output geometry list */

   extern INT CALLTYP frn_addition_ ansPROTO((
     INT geoma[],         /* I    First ansys id list to subtract */
     INT dima[],          /* I    Dimensions of first ansys id list */
     INT *na,             /* I    Size of the first ansys id list */
     INT *mode,           /* I   Mode for simplification          */
     INT *ngeom));          /* O    Size of the output geometry list */
/*
 *    Create a SHAPES 3-D sheet geom from ANSYS working plane
 */
   extern VOID CALLTYP frn_cr_wrkpl_ ansPROTO((
      INT *num_wplan,      /* I    number of working planes inputted        */
      INT wp_type[],       /* I    working plane type                       */
                           /*      = 0 - plane  type x-y plane              */
                           /*      = 1 - cylinder  type                     */
                           /*      = 2 - spherical type                     */
      DOUBLE wp_trans[4][4],
                           /* I    working plane transformation 4x3         */
      DOUBLE wp_boxes[2],
                           /* I    working plane box information for sizing */
                           /*      for planar types wp_axis = 0             */
                           /*      word 1 - length used as -length/2 to
                                   length/2 in the x-axis                   */
                           /*      word 2 - hieght used as -hieght/2 to
                                   hieght/2 in the y-axis                   */
                           /*      for cylinder types wp_axis = 1           */
                           /*      word 1 - radius                          */
                           /*      word 2 - hieght used as 0 to hieght in
                                            the zy-axis                     */
                           /*      for spherical types wp_axis = 2          */
                           /*      word 1 - radius                          */
                           /*      word 2 - not used                        */
      INT xentn[],         /* I/O  SHAPES entity numbers                    */
      INT *iretp));        /*   O  error code
                           *      == 0 - no error
                           *      != 0 - error                             */

    extern VOID CALLTYP axoxrecover_ ansPROTO(( ));
    extern INT  CALLTYP axoxinit_ ansPROTO(( ));

    extern INT  CALLTYP axoxvminit_ ansPROTO((
           INT *length,
           INT *key));

    extern VOID CALLTYP aXoxVmOpen_ ansPROTO((
           INT *length,
           INT *alloc_key,
           INT *iretp));

    extern VOID CALLTYP aXoxVmClose_ ansPROTO((
           INT *iretp));

    extern INT  CALLTYP xAnsysSavGms_ ansPROTO(( ));

    extern VOID CALLTYP xAnsysResGms_ ansPROTO((
           INT *startID));

    extern INT  CALLTYP xAnsysGmsFromIges_ ansPROTO((
           INT *label,
           INT *dim));

    extern INT  CALLTYP xAnsysGmDelete_ ansPROTO((
           INT *gms,
           INT *len));

    extern INT  CALLTYP xAnsysGmDeleteAll_ ansPROTO((
           INT *dim));


    extern INT  CALLTYP xAnsysGeomSize_ ansPROTO((
           xGEOM *geom));

    extern INT  CALLTYP xAnsysCheckConnect_ ansPROTO((
           INT *id_array,
           INT *size,
           INT *dim_array));

    extern INT  CALLTYP xAnsysGeomId_ ansPROTO((
           INT *geom,
           INT *size,
           INT *id_array));

    extern INT  CALLTYP xAnsysSmoothEvl_ ansPROTO((
           INT *geom,
           DOUBLE *param,
           INT *normalP,
           DOUBLE *vec,
           DOUBLE *curvature));

    extern INT  CALLTYP xAnsysMerge_ ansPROTO((
           INT *id_array,
           INT *dim,
           INT *size,
           INT *boundary_flag));

    extern INT  CALLTYP xAnsysSplitEdge_ ansPROTO((
           INT *entity,
           DOUBLE *param));

    extern INT  CALLTYP xAnsysSplitSurface_ ansPROTO((
           INT *entity,
           INT *kp1,
           INT *kp2));

    extern INT  CALLTYP xAnsysCollapse_ ansPROTO((
           INT *entity,
           INT *dim,
           INT *subent,
           INT *length,
           DOUBLE *smooth,
           INT *collapsedent));

    extern INT  CALLTYP xAnsysRemoveHole_ ansPROTO((
           INT *entity,
           INT *dim,
           INT *subent,
           INT *length));

    extern INT  CALLTYP xAnsysRemoveEnts_ ansPROTO((
           INT *entity,
           INT *dim,
           INT *length));

    extern INT  CALLTYP xAnsysChangeTol_ ansPROTO((
           DOUBLE *factor));

    extern VOID CALLTYP xPrintGeom_ ansPROTO(( 
           INT *geom,
           INT *dim));
    
    extern VOID CALLTYP run_xox_ ansPROTO(( INT *flag));


/*
 *    open the SHAPES process of XOX
 */
      extern VOID CALLTYP xoxopn_ ansPROTO((
             INT *iretp));                     /*   O  pointer to the error code
                                                *      == 0 - no error
                                                *      != 0 - error                        */

/*
 *    close the SHAPES process of XOX called by ANSYS Boolean operation
 */
      extern VOID CALLTYP xoxcls_ ansPROTO((
             INT *iretp));        /*   O  pointer to the error code
                                   *      == 0 - no error
                                   *      != 0 - error                                */

/*
 *    close the SHAPES process of XOX called by XOX IGES related operation
 */
      extern VOID CALLTYP xoxcls1_ ansPROTO((
             INT *iretp));        /*   O  pointer to the error code
                                   *      == 0 - no error
                                   *      != 0 - error                                */

/*
 *    convert ANSYS entities to (from) SHAPES entities
 */
      extern VOID CALLTYP xconvt_ ansPROTO((
             INT entn[],          /* I/O  ANSYS entity numbers                     */
             INT xentn[],         /* I/O  SHAPES entity numbers                    */
             INT gdims[],         /*      geometry dimensions of entities          */
             INT *nentp,          /* I    pointer to the number of entities        */
             INT *dimp,           /* I    pointer to the common dimensions         */
             INT *dimuse,         /* I    != 0 - data dimp is used
                                   *      == 0 - data dimp is not used             */
             INT *iopt,           /* I    option
                                   *      == FROM_ANSYS_ENTITIES    (== 0)
                                   *      == TO_ANSYS_SUBENTITIES   (== 1)
                                   *      == FROM_ANSYS_SUBENTITIES (== 2)         */
             INT *iretp));        /*   O  error code
                                   *      == 0 - no error
                                   *      != 0 - error                             */
/*
 *    convert the working plane from ANSYS to SHAPES
 */
      extern VOID CALLTYP xconvt_wp_ ansPROTO((
             INT *num_wplan,      /* I    number of working planes inputted        */
             INT wp_type[],       /* I    working plane type                       */
                                  /*      = 0 - plane  type x-y plane              */
                                  /*      = 1 - cylinder  type                     */
                                  /*      = 2 - spherical type                     */
             INT wp_sanum[],      /* I    working plane subarea number             */
             DOUBLE wp_trans[4][4],
                                  /* I    working plane transformation 4x3         */
             DOUBLE wp_boxes[2],
                                  /* I    working plane box information for sizing */
                                  /*      for planar types wp_axis = 0             */
                                  /*      word 1 - length used as -length/2 to
                                          length/2 in the x-axis                   */
                                  /*      word 2 - hieght used as -hieght/2 to
                                          hieght/2 in the y-axis                   */
                                  /*      for cylinder types wp_axis = 1           */
                                  /*      word 1 - radius                          */
                                  /*      word 2 - hieght used as 0 to hieght in
                                                   the zy-axis                     */
                                  /*      for spherical types wp_axis = 2          */
                                  /*      word 1 - radius                          */
                                  /*      word 2 - not used                        */

      INT xentn[],         /* I/O  SHAPES entity numbers                    */
      INT *iretp));          /*   O  error code
                            *      == 0 - no error
                            *      != 0 - error                             */


/*
 *    Compute the number of component geoms of a geom
 */
      extern VOID CALLTYP xngeom_ ansPROTO((
             INT *geom,           /* I    pointer to the geom number of a geom        */
             INT *ngeom,          /*   O  pointer to the number of component geoms    */
             INT *iretp));        /*   O  pointer to the error code
                                   *      == 0 - no error
                                   *      != 0 - error                                */



/*
 *    Compute the information of the component geoms of a geom
 */
      extern VOID CALLTYP xgeoms_ ansPROTO((
             INT *geom,           /* I    pointer to the geom number of a geom        */
             INT geoms[],         /*   O  geom numbers of the component geoms         */
             INT gdims[],         /*   O  geometry dimensions of the component geoms  */
             INT *mindim,         /*   O  pointer to the minimum dimension of the
                                   *      component geoms                             */
             INT *maxdim,         /*   O  pointer to the maximum dimension of the
                                   *      component geoms                             */
             INT *iretp));        /*   O  error code
                                   *      == 0 - no error
                                   *      != 0 - error                                */

/*
 *    Compute the halfspace geom, and the complement halfspace geom of a 2-D geom
 *    in a 3-D space
 */
      extern VOID CALLTYP xhalfspaces_ ansPROTO((
             INT *geom,             /* I    pointer to the geom number of a 2-geom      */
             INT halfspace_geoms[], /*   O  geom numbers of the halfspace geom and its
                                     *      complement                                  */
             INT *iopt,             /* I    option
                                     *      == DESTROY_INPUT_GEOMS or
                                     *      == DO_NOT_DESTROY_INPUT_GEOMS               */
             INT *iretp));          /*   O  error code
                                     *      == 0 - no error
                                     *      != 0 - error                                */

/****************************************************************************
 *    Extended Boolean subtraction which separates the output geoms         *
 *                                                                          *
 *    (A1 # A2 # .. # Am) - (B1 + B2 + .. + Bn)                             *
 *                                                                          *
 *    where B1,B2,... Bn are 2-geoms                                        *
 *                                                                          *
 ****************************************************************************/

      extern VOID CALLTYP xsubc_sepo_ ansPROTO((
             INT *geoma,          /* I    geom number of the group geom containing
                                   *      geometries to be subtracted from           */
             INT geomb[],         /* I    geom numbers of geometries to be subtracted
                                   *                                                 */
             INT *nb,             /* I    pointer to the number of geometries to be
                                   *      subtracted                                 */
             INT *geomo,          /*   O  geom number of the group geom containing
                                   *      the output geometries                      */
             INT *ioopta,         /* I    operation type for the geometries "geoma"
                                   *      before the subtraction
                                   *      == 0 - "disjoint add" operation
                                   *      == 1 - "sewing" operation
                                   *      == 2 - "add" operation
                                   *      == 3 - "group" operation                   */
             INT *iopt,           /* I    option
                                   *      == DESTROY_INPUT_GEOMS or
                                          == DO_NOT_DESTROY_INPUT_GEOMS              */
             INT *iretp));        /*   O  error code
                                   *      == 0 - no error
                                   *      != 0 - error                               */



/****************************************************************************
 *                                                                          *
 *    Find the set of connected components from a set of geoms              *
 *                                                                          *
 ****************************************************************************/

      extern VOID CALLTYP xcomp_conn_ ansPROTO((
             INT geoma[],         /* I    geom numbers of geoms from a set           */
             INT *na,             /* I    pointer to the number of geoms in the set  */
             INT *idim,           /* I    common dimension of geoms in geoma[]       */
             INT geomb[],         /*   O  geom numbers of connected components of the
                                   *      set geoma[]                                */
             INT *nb,             /*   O  pointer to the number of geoms in geomb[]  */
             INT *iretp));        /*   O  error code
                                   *      == 0 - no error
                                   *      != 0 - error                               */


/*****************************************************************************
 *                                                                           *
 *    Boolean operations in SHAPES                                           *
 *                                                                           *
 *****************************************************************************/


/*
 *    classify the parts inside, outside, and on the boundary of 2 geoms
 *    with respect to each other
 */
      extern VOID CALLTYP xclafy_ ansPROTO((
             INT *geom1,          /* I    geom number of the 1st geom                */
             INT *geom2,          /* I    geom number of the 2nd geom                */
             INT comp1[],         /* I    computing expression of geom1
                                   *      comp1[0] == 1 - compute the part of geom1
                                   *                      which is inside of geom2
                                   *               == 0 - do not compute
                                   *      comp1[1] == 1 - compute the part of geom1
                                   *                      which is on the boundary
                                   *                      of geom2
                                   *               == 0 - do not compute
                                   *      comp1[2] == 1 - compute the part of geom1
                                   *                      which is outside of geom2
                                   *               == 0 - do not compute             */
             INT comp2[],         /* I    computing expression of geom2
                                   *      comp2[0] == 1 - compute the part of geom2
                                   *                      which is inside of geom1
                                   *               == 0 - do not compute
                                   *      comp2[1] == 1 - compute the part of geom2
                                   *                      which is on the boundary
                                   *                      of geom1
                                   *               == 0 - do not compute
                                   *      comp2[2] == 1 - compute the part of geom2
                                   *                      which is outside of geom1
                                   *               == 0 - do not compute
                                   *
                                   *      if calling from FORTRAN, the indexes of
                                   *      comp1, and comp2 should start from 1
                                   *      instead of 0                               */
             INT cgeom1[],        /*   O  classifying expression of geom1
                                   *      cgeom1[0] == geom number of the part of
                                   *                   geom1 which is inside of geom2
                                   *      cgeom1[1] == geom number of the part of
                                   *                   geom1 which is on the boundary
                                   *                   of geom2
                                   *      cgeom1[2] == geom number of the part of
                                   *                   geom1 which is outside of
                                   *                   geom2                         */
             INT cgeom2[],        /*   O  classifying expression of geom2
                                   *      cgeom2[0] == geom number of the part of
                                   *                   geom2 which is inside of geom1
                                   *      cgeom2[1] == geom number of the part of
                                   *                   geom2 which is on the boundary
                                   *                   of geom1
                                   *      cgeom2[2] == geom number of the part of
                                   *                   geom2 which is outside of
                                   *                   geom1
                                   *
                                   *      if calling from FORTRAN, the indexes of
                                   *      cgeom1, and cgeom2 should start from 1
                                   *      instead of 0                               */
             INT *iopt,           /* I    option
                                   *      == DESTROY_INPUT_GEOMS or
                                          == DO_NOT_DESTROY_INPUT_GEOMS              */
             INT *iretp));        /*   O  error code
                                   *      == 0 - no error
                                   *      != 0 - error                               */




/*
 *    Find the difference of 2 geoms
 */
      extern VOID CALLTYP xdiffn_ ansPROTO((
             INT *geom1,          /* I    geom number of the 1st geom                */
             INT *geom2,          /* I    geom number of the 2nd geom                */
             INT *geom,           /*   O  geom number of the difference of geom1
                                   *      and geom2
                                   *      geom = geom1 - geom2                       */
             INT *iopt1,          /* I    option for geom1
                                   *      == DESTROY_INPUT_GEOMS or
                                          == DO_NOT_DESTROY_INPUT_GEOMS              */
             INT *iopt2,          /* I    option for geom2
                                   *      == DESTROY_INPUT_GEOMS or
                                          == DO_NOT_DESTROY_INPUT_GEOMS              */
             INT *iretp));        /*   O  error code
                                   *      == 0 - no error
                                   *      == GEOMETRY_IS_EMPTY
                                   *      otherwise - error                          */



/****************************************************************************
 *    Extended Boolean subtraction                                          *
 *                                                                          *
 *    (A1 # A2 # .. # Am) - (B1 + B2 + .. + Bn)                             *
 *                                                                          *
 ****************************************************************************/

      extern VOID CALLTYP xsubc_ ansPROTO((
             INT geoma[],         /* I    geom numbers of geometries to be subtracted
                                   *      from                                       */
             INT *na,             /* I    pointer to the number of geometries to be
                                   *      subtracted from                            */
             INT geomb[],         /* I    geom numbers of geometries to be subtracted
                                   *                                                 */
             INT *nb,             /* I    pointer to the number of geometries to be
                                   *      subtracted                                 */
             INT *geomo,          /*   O  geom number of the group geom containing
                                   *      the output geometries                      */
             INT *ioopta,         /* I    operation type for the geometries "geoma"
                                   *      before the subtraction
                                   *      == 0 - "disjoint add" operation
                                   *      == 1 - "sewing" operation
                                   *      == 2 - "add" operation                     */
             INT *iooptb,         /* I    operation type for the geometries "geomb"
                                   *      before the subtraction
                                   *      == 0 - "disjoint add" operation
                                   *      == 1 - "sewing" operation
                                   *      == 2 - "add" operation                     */
             INT *iopt,           /* I    option
                                   *      == DESTROY_INPUT_GEOMS or
                                          == DO_NOT_DESTROY_INPUT_GEOMS              */
             INT *iretp));        /*   O  error code
                                   *      == 0 - no error
                                   *      != 0 - error                               */


/*
 *    Test if 2 geoms intersect within a given tolerance
 */
      extern VOID CALLTYP xintst_ ansPROTO((
             INT *geom1,          /* I    geom number of the 1st geom                */
             INT *geom2,          /* I    geom number of the 2nd geom                */
             INT *result,         /*   O  result
                                   *      == INTERSECT or
                                   *      == DO_NOT_INTERSECT                        */
             DOUBLE *tol,         /* I    tolerance                                  */
             INT *iretp));        /*   O  error code
                                   *      == 0 - no error
                                   *      != 0 - error                               */



/****************************************************************************
 *    Find the intersection of geoms                                        *
 ****************************************************************************/

      extern VOID CALLTYP xintss_ ansPROTO((
             INT geoms[],         /* I    geom numbers of geoms                      */
             INT *ng,             /* I    pointer to the number of geoms             */
             INT *geom,           /*   O  geom number of the intersection            */
             INT *iopt,           /* I    option
                                   *      == DESTROY_INPUT_GEOMS or
                                          == DO_NOT_DESTROY_INPUT_GEOMS              */
             INT *iretp));        /*   O  error code
                                   *      == 0 - no error
                                   *      == GEOMETRY_IS_EMPTY
                                   *      otherwise - error                          */



/****************************************************************************
 *    Find the pairwise intersection of geoms                               *
 ****************************************************************************/

      extern VOID CALLTYP xintsp_ ansPROTO((
             INT geoms[],         /* I    geom numbers of geoms                      */
             INT *ng,             /* I    pointer to the number of geoms             */
             INT *geom,           /*   O  geom number of the intersection            */
             INT *iopt,           /* I    option
                                   *      == DESTROY_INPUT_GEOMS or
                                          == DO_NOT_DESTROY_INPUT_GEOMS              */
             INT *iretp));        /*   O  error code
                                   *      == 0 - no error
                                   *      == GEOMETRY_IS_EMPTY
                                   *      otherwise - error                          */


/****************************************************************************
 *    Find the union of geoms                                               *
 ****************************************************************************/

      extern VOID CALLTYP xaddss_ ansPROTO((
             INT geoms[],         /* I    geom numbers of geoms                      */
             INT *ng,             /* I    pointer to the number of geoms             */
             INT *geom,           /*   O  geom number of the union            */
             INT *iopt,           /* I    option
                                   *      == DESTROY_INPUT_GEOMS or
                                          == DO_NOT_DESTROY_INPUT_GEOMS              */
             INT *iretp));        /*   O  error code
                                   *      == 0 - no error
                                   *      != 0 - error                               */


/****************************************************************************
 *    Find the union-merge of geoms                                         *
 ****************************************************************************/

      extern VOID CALLTYP xmerss_ ansPROTO((
             INT geoms[],         /* I    geom numbers of geoms                      */
             INT *ng,             /* I    pointer to the number of geoms             */
             INT *geom,           /*   O  geom number of the union-merge             */
             INT *iopt,           /* I    option
                                   *      == DESTROY_INPUT_GEOMS or
                                          == DO_NOT_DESTROY_INPUT_GEOMS              */
             INT *iretp));        /*   O  error code
                                   *      == 0 - a valid merge
                                   *      != 0 - error                               */




/****************************************************************************
 *    Find the union_overlap of geoms                                       *
 ****************************************************************************/

      extern VOID CALLTYP xovers_ ansPROTO((
             INT geoms[],         /* I    geom numbers of geoms                      */
             INT *ng,             /* I    pointer to the number of geoms             */
             INT *geom,           /*   O  geom number of the union_overlap           */
             INT *iopt,           /* I    option
                                   *      == DESTROY_INPUT_GEOMS or
                                          == DO_NOT_DESTROY_INPUT_GEOMS              */
             INT *iretp));        /*   O  error code
                                   *      == 0 - no error
                                   *      != 0 - error                               */



/****************************************************************************
 *    simplify a geom by removing common faces                              *
 ****************************************************************************/

      extern VOID CALLTYP xgsimp_ ansPROTO((
             INT *geom,           /* I/O  geom number of the geom to be simpilfied  */
             INT *mode,           /* I    simplification code which specifies how
                                          much merging is desired on the output
                                          results.
                                          == 0 - no simplification done.
                                          == xcGM_SIMPLIFY_SPACE - remove any
                                             removable boundaries between cells
                                             defining regions in modeling space
                                             (i.e. solids).
                                          == xcGM_SIMPLIFY_EQ_MAP - remove any
                                             removable boundaries between cells
                                             that are defined on the same map
                                          == xcGM_SIMPLIFY_ALL    - perform the
                                             above 2 and additional tries to merge
                                             cells that are defined on maps that
                                             cover the same point set even though
                                             they are parametrically not the same.
                                             For example, differently parametrized
                                             but overlapping planes are merged      */
             INT *iretp));        /*   O  error code
                                   *      == 0 - no error
                                   *      != 0 - error                               */



/****************************************************************************
 *    Cut geoms by a geom                                                   *
 ****************************************************************************/


      extern VOID CALLTYP xcutc_ ansPROTO((
             INT gins[],          /* I    geom numbers of the input geoms to be cut  */
             INT gouts[][2],      /*   O  geom numbers of the output geoms obtained
                                   *      by cutting
                                   *      gouts[i][0] and gouts[i][1] are the geom
                                   *      number of the geoms obtained by cutting
                                   *      the geom gins[i] by using *gcut.
                                   *      gouts[i][j] == 0, if its geom is a null
                                   *                           geometry              */
             INT *ng,             /* I    pointer to the number of geoms to be cut   */
             INT *gcut,           /* I    pointer to the geom number to be used to
                                   *      cut "gins"                                 */
             INT *dimcut,         /* I    pointer to the geometry dimension of the
                                   *      geom *gcut                                 */
             INT *iopt,           /* I    option
                                   *      == DESTROY_INPUT_GEOMS or
                                          == DO_NOT_DESTROY_INPUT_GEOMS
                                   *      (*gcut will not be destroyed)              */
             INT *iretp));        /*   O  error code
                                   *      == 0      - no error
                                   *      == ALL_CUT_GEOMETRIES_ARE_DISJOINTED_WITH_CUTTING_GEOMETRY
                                   *      otherwise - error                          */


/****************************************************************************
 *    Find minimum distance points from a geom to given points              *
 ****************************************************************************/

      extern VOID CALLTYP xdstpg_ ansPROTO((
             INT *gmin,           /* I    a given geom                               */
             DOUBLE ptcors[],     /* I    coordinates of given points                */
             INT gmouts[],        /*   O  the computed 0-D point geoms               */
             DOUBLE mndsts[],     /*   O  minimum distances to be returned           */
             INT *np,             /* I    number of given points                     */
             INT *iretp));        /*   O  error code
                                   *      == 0 - no error
                                   *      otherwise - error                          */


/****************************************************************************
 *    Evaluate on a cell geom                                               *
 ****************************************************************************/

      extern VOID CALLTYP xevalg_ ansPROTO((
             INT *gm,             /* I    a given cell geom                          */
             INT *gdim,           /* I    geometry dimension of the geom             */
             INT *nu,             /* I    number of evaluations along u-direction    */
             INT *nv,             /* I    number of evaluations along v-direction    */
             INT ptgms[],         /*   O  the computed 0-D evaluated point geoms     */
             DOUBLE ptcors[][3],  /*   O  coordinates of evaluated points            */
             INT *iretp));        /*   O  error code
                                   *      == 0 - no error
                                   *      otherwise - error                          */

/****************************************************************************
 *    sew an array of geoms (for ANSYS)                                     *
 ****************************************************************************/


      extern VOID CALLTYP xsewnc_ ansPROTO((
             INT geoms[],         /* I    geom numbers of geoms                      */
             INT *ng,             /* I    pointer to the number of geoms             */
             INT *geom,           /*   O  geom number of the resulting geom          */
             INT *iopt,           /* I    option
                                   *      == DESTROY_INPUT_GEOMS or
                                          == DO_NOT_DESTROY_INPUT_GEOMS              */
             INT *iretp));        /*   O  error code
                                   *      == 0 - no error
                                   *      != 0 - error                               */

/****************************************************************************
 *    group an array of geoms (for ANSYS)                                     *
 ****************************************************************************/


      extern VOID CALLTYP xgrpc_ ansPROTO((
             INT geoms[],         /* I    geom numbers of geoms                      */
             INT *ng,             /* I    pointer to the number of geoms             */
             INT *geom,           /*   O  geom number of the resulting geom          */
             INT *iopt,           /* I    option
                                   *      == DESTROY_INPUT_GEOMS or
                                          == DO_NOT_DESTROY_INPUT_GEOMS              */
             INT *iretp));        /*   O  error code
                                   *      == 0 - no error
                                   *      != 0 - error                               */




/****************************************************************************
 *    compute the sums of the number of seam geoms                          *
 ****************************************************************************/

      extern VOID CALLTYP xnseam_ ansPROTO((
             INT geoms[],         /* I    geom numbers of geoms                      */
             INT *ngeom,          /* I    pointer to the number of geoms             */
             INT nseams[],        /*   O  nseams[0] == sum of the number of 0-D
                                   *                   seam geoms
                                   *      nseams[1] == sum of the number of 1-D
                                   *                   seam geoms
                                   *      nseams[2] == sum of the number of 2-D
                                   *                   seam geoms                    */
             INT *iretp));        /*   O  error code
                                   *      == 0 - no error
                                   *      != 0 - error                               */



/****************************************************************************
 *    compute the sums of the number of subgeoms                            *
 ****************************************************************************/

      extern VOID CALLTYP xnsub_ ansPROTO((
             INT geoms[],         /* I    geom numbers of geoms                      */
             INT *ngeom,          /* I    pointer to the number of geoms             */
             INT nsubs[],         /*   O  nsubs[0] == sum of the number of 0-D
                                   *                  subgeoms
                                   *      nsubs[1] == sum of the number of 1-D
                                   *                  subgeoms
                                   *      nsubs[2] == sum of the number of 2-D
                                   *                  subgeoms                       */
             INT *iretp));        /*   O  error code
                                   *      == 0 - no error
                                   *      != 0 - error                               */




/****************************************************************************
 *    filter out unwanted geometries of dimensions between gdiml and gdimu  *
 *    from a geom                                                           *
 ****************************************************************************/

      extern VOID CALLTYP xfiltr_ ansPROTO((
             INT *gmin,           /* I    geom number of input geom                  */
             INT *gmout,          /*   O  geom number of the resulting geom          */
             INT *gdiml,          /* I    lower limit of the unwanted geometries to
                                          be filtered out                            */
             INT *gdimu,          /* I    upper limit of the unwanted geometries to
                                          be filtered out                            */
             INT *iretp));        /*   O  error code
                                   *      == 0 - no error
                                   *      != 0 - error                               */



/****************************************************************************
 *    get the memory usage                                                  *
 ****************************************************************************/

      extern VOID CALLTYP xmemgt_ ansPROTO((
             INT *heap_tag,
             INT *iopt,
             INT *memory_usage));           /*   O  memory usage */



/****************************************************************************
 *    Initialize the heap memory management for attribute Handler           *
 *    warning: this routine does not release the stack space allocated and  *
 *             it is the resposibility of the calling routine               *
 ****************************************************************************/

      extern VOID CALLTYP ahpini_ ansPROTO((
             INT     *iretp));      /*   O - error code
                                     *       == 0 - no error
                                     *       != 0 - error                             */




/****************************************************************************
 *    Close the heap memory management for attribute handler                *
 *                                                                          *
 ****************************************************************************/

      extern VOID CALLTYP ahpcls_ ansPROTO((
             INT     *iretp));      /*   O - error code
                                     *       == 0 - no error
                                     *       != 0 - error                                 */


/****************************************************************************
 *     STEPIN Command - Import of STEP FIle                                 *
 ****************************************************************************/

