/* parallel.h	1.1 IBM version*/
/* 
 * *** copyright(c) 2010 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */

/*HFILE parallel.h                                      fjb,system
------------------------------------------------------------------------
------- Notice - This file contains ANSYS Confidential information --------
------------------------------------------------------------------------
*/


#ifndef PARALLEL_H
#  define PARALLEL_H

/* Macros to switch on or off suffix underscore for routines called
	from FORTRAN		*/
#ifdef ENTRYSUFF
#define PPPROC ppproc_
#define PPRESU ppresu_
#define PPRANGE	pprange_
#define PPCHUNK ppchunk_
#define PPFRK ppfrk_
#define PPFRK1 ppfrk1_
#define PPFRK2 ppfrk2_
#define PPFRK3 ppfrk3_
#define PPFRK4 ppfrk4_
#define PPFRK5 ppfrk5_
#define PPFRK6 ppfrk6_
#define PPFRK7 ppfrk7_
#define PPFRK8 ppfrk8_
#define PPFRK9 ppfrk9_
#define PPFRK10 ppfrk10_
#define PPFRK11 ppfrk11_
#define PPFRK12 ppfrk12_
#define PPFRK13 ppfrk13_
#define PPFRK14 ppfrk14_
#define PPFRK15 ppfrk15_
#define PPPARK pppark_
#define PPNEXT ppnext_
#define PPRSET pprset_
#define PPINFO ppinfo_
#define PPLOCK pplock_
#define PPUNLOCK ppunlock_
#define LOCKST lockst_
#define LOCKCL lockcl_
#define PPINQR ppinqr_
#define PPFINI ppfini_
#define PPINIT ppinit_
#else
#define PPPROC ppproc
#define PPRESU ppresu
#define PPRANGE	pprange
#define PPCHUNK ppchunk
#define PPFRK ppfrk
#define PPFRK1 ppfrk1
#define PPFRK2 ppfrk2
#define PPFRK3 ppfrk3
#define PPFRK4 ppfrk4
#define PPFRK5 ppfrk5
#define PPFRK6 ppfrk6
#define PPFRK7 ppfrk7
#define PPFRK8 ppfrk8
#define PPFRK9 ppfrk9
#define PPFRK10 ppfrk10
#define PPFRK11 ppfrk11
#define PPFRK12 ppfrk12
#define PPFRK13 ppfrk13
#define PPFRK14 ppfrk14
#define PPFRK15 ppfrk15
#define PPPARK pppark
#define PPNEXT ppnext
#define PPRSET pprset
#define PPINFO ppinfo
#define PPLOCK pplock
#define PPUNLOCK ppunlock
#define LOCKST lockst
#define LOCKCL lockcl
#define PPINQR ppinqr
#define PPFINI ppfini
#define PPINIT ppinit
#endif
/*------------------ Header files and declarations -------------------*/
/* BELOW DEFINE ADDED TO FORCE STRICT ANSI C COMPILES */
# define ansANSI

#include <pthread.h>

/*------------------------------ Dependencies ------------------------*/

/*----------------------- Static Macro Definitions -------------------*/

/*
   ppDebug = 0, no debug, create threads.
   ppDebug = 1, yes debug, create threads.
   ppDebug = 2, yes debug, direct calls -no- threads.

   OPTION : compile with -DDEBUG to get debugging messages -or-
            compile with -DNO_DEBUG to get -no- debugging messages ever.
*/
# define debug 0
#ifdef DEBUG
# define debug 1
#endif
#ifdef NO_DEBUG
# define debug 0
#endif

/***********************************************************************
                  * * *  N O T I C E  * * *
The definition of MAX_LOCKS MUST be the same size as the PPNUMLOCK 
parameter statement in FORTRAN common PPCOM.  Also, the definition of 
MAXARGS is the maximum number of FORTRAN arguments permitted by this 
version.  This MUST be consistent with the FORTRAN ppfrkx calls.
                  * * *  N O T I C E  * * *
***********************************************************************/
#define MAX_LOCKS 128
#define MAXARGS 15
#define MAXARGS1 (MAXARGS + 1)

/* define the MAX_CPUS permitted for this version */
#define MAX_CPUS 32

/*--------------------- Static TypeDefs/Structures -------------------*/

/*
** Barrier data type
*/
typedef struct {
	pthread_mutex_t	lk;
	pthread_cond_t	wait_cv;	/* cv for waiters at barrier	*/
	pthread_cond_t	leave_cv;	/* cv for wake-up thread	*/
	pthread_cond_t	next_cv;	/* cv for next iteration	*/
	int	runners;	/* number of running threads	*/
	int	waiters;	/* number of waiting threads	*/
	int	maxcnt;		/* maximum number of runners	*/
	int	next;		/* 1 - OK for next iteration	*/
} barrier_t;

/* App may want to dynamically allocate as many of these as it needs, for
   now we just have one the app.
   These barriers once initialized are labeled, e.g., cannot be  reinitialized.
   If more than one is needed, need to allocate more.
*/

/*----------------------- Variable Definitions -----------------------*/
/* global variables */
INT ppDebug;
INT ppDebug_lock;



/*------------------------- Internal Functions -----------------------*/

VOID cwfrk( VOID *[] );
VOID (*subr1) ();
VOID (*subr2) (VOID *);
VOID (*subr3) (VOID *,VOID *);
VOID (*subr4) (VOID *,VOID *,VOID *);
VOID (*subr5) (VOID *,VOID *,VOID *,VOID *);
VOID (*subr6) (VOID *,VOID *,VOID *,VOID *,VOID *);
VOID (*subr7) (VOID *,VOID *,VOID *,VOID *,VOID *,VOID *);
VOID (*subr8) (VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *);
VOID (*subr9) (VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *);
VOID (*subr10) (VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,
                VOID *);
VOID (*subr11) (VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,
		VOID *,VOID *);
VOID (*subr12) (VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,
		VOID *,VOID *,VOID *);
VOID (*subr13) (VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,
		VOID *,VOID *,VOID *,VOID *);
VOID (*subr14) (VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,
		VOID *,VOID *,VOID *,VOID *,VOID *);
VOID (*subr15) (VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,
		VOID *,VOID *,VOID *,VOID *,VOID *,VOID *);
VOID (*subr16) (VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,
		VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *);
VOID thr_init( VOID * );
VOID thread_create( VOID *[] , pthread_t *);

VOID 	ppbarrier (barrier_t *);
int	barrier_init( barrier_t *bp, int count );
int	barrier_wait( barrier_t *bp );
int	barrier_destroy( barrier_t *bp );
void    start_threads();
void    wait_for_start();
extern INT  get_proc_id_( VOID );

/*------------------------- Exported Functions -----------------------*/
/* used either from fortran and/or cc */
extern VOID ppfrk_ ( VOID *(*)() );
extern VOID ppfrk1_( VOID *(*)(VOID *), VOID *[] );
extern VOID ppfrk2_( VOID *(*)(VOID *,VOID *), VOID *[], VOID *[] );
extern VOID ppfrk3_( VOID *(*)(VOID *,VOID *,VOID *), VOID *[], VOID *[], 
		     VOID *[] );
extern VOID ppfrk4_( VOID *(*)(VOID *,VOID *,VOID *,VOID *), VOID *[], 
                     VOID *[], VOID *[], VOID *[] );
extern VOID ppfrk5_( VOID *(*)(VOID *,VOID *,VOID *,VOID *,VOID *), VOID *[], 
		     VOID *[], VOID *[], VOID *[], VOID *[] );
extern VOID ppfrk6_( VOID *(*)(VOID *,VOID *,VOID *,VOID *,VOID *,VOID *), 
		     VOID *[], VOID *[], VOID *[], VOID *[], VOID *[], 
                     VOID *[] );
extern VOID ppfrk7_( VOID *(*)(VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,
                     VOID *), VOID *[], VOID *[], VOID *[], VOID *[], VOID *[], 
                     VOID *[], VOID *[] );
extern VOID ppfrk8_( VOID *(*)(VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,
		     VOID *), VOID *[], VOID *[], VOID *[], VOID *[], VOID *[], 
                     VOID *[], VOID *[], VOID *[] );
extern VOID ppfrk9_( VOID *(*)(VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,
                     VOID *,VOID *), VOID *[], VOID *[], VOID *[], VOID *[], 
                     VOID *[], VOID *[], VOID *[], VOID *[], VOID *[] );
extern VOID ppfrk10_( VOID *(*)(VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,
                      VOID *,VOID *, VOID *), VOID *[], VOID *[], VOID *[], 
                      VOID *[], VOID *[], VOID *[], VOID *[], VOID *[], VOID *[], 
                      VOID *[] );
extern VOID ppfrk11_( VOID *(*)(VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,
                      VOID *,VOID *, VOID *, VOID *), VOID *[], VOID *[], 
                      VOID *[], VOID *[], VOID *[], VOID *[], VOID *[], VOID *[], 
                      VOID *[], VOID *[], VOID *[] );
extern VOID ppfrk12_( VOID *(*)(VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,
                      VOID *,VOID *, VOID *, VOID *,VOID *), VOID *[], VOID *[], 
                      VOID *[], VOID *[], VOID *[], VOID *[], VOID *[], VOID *[], 
                      VOID *[], VOID *[], VOID *[], VOID *[] );
extern VOID ppfrk13_( VOID *(*)(VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,
                      VOID *,VOID *, VOID *, VOID *,VOID *,VOID *), VOID *[], 
                      VOID *[], VOID *[], VOID *[], VOID *[], VOID *[], VOID *[], 
                      VOID *[], VOID *[], VOID *[], VOID *[], VOID *[], VOID *[] );
extern VOID ppfrk14_( VOID *(*)(VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,
                      VOID *,VOID *, VOID *, VOID *,VOID *,VOID *,VOID *), VOID *[], 
                      VOID *[], VOID *[], VOID *[], VOID *[], VOID *[], VOID *[], 
                      VOID *[], VOID *[], VOID *[], VOID *[], VOID *[], VOID *[], 
                      VOID *[] );
extern VOID ppfrk15_( VOID *(*)(VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,
                      VOID *,VOID *, VOID *, VOID *,VOID *,VOID *,VOID *,VOID *), 
                      VOID *[], VOID *[], VOID *[], VOID *[], VOID *[], VOID *[], 
                      VOID *[], VOID *[], VOID *[], VOID *[], VOID *[], VOID *[], 
                      VOID *[], VOID *[], VOID *[] );

extern VOID ppinit_( CHAR [], INT *,INT * );
extern VOID ppinit2_ ( VOID );
extern VOID ppfini_( VOID );
extern VOID ppresu_( VOID );
extern VOID pppark_( VOID );
extern VOID pprset_( VOID );
extern VOID pplock_( INT * );
extern VOID lockst_( INT * );
extern VOID ppunlock_( INT * );
extern VOID lockcl_( INT * );
extern VOID ppinfo_( INT*, INT * );
extern INT ppinqr_( INT * );
extern INT ppnext_( VOID );
extern INT ppproc_( VOID );

extern VOID pplockprt_( VOID );
extern VOID ppunlockprt_( VOID );
extern VOID printf_lck(const char *format, ...);

#endif		/* PARALLEL_H */
/*---------------------------- End Of Module -------------------------*/

