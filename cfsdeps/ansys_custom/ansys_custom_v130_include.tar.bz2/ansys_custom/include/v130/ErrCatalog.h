/*CFILE ErrCatalog.h  ANSI_C      <author, date> */
/*
 * ***  copyright(c) 2010 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */
/*---------------------------------------------------------------------*/
#ifndef ErrCatalog_H
#define ErrCatalog_H

#ifndef FORTRAN                            /* Fortran wrapper */
 /*
  * PROJECT : ANSYS Internationalization
  * CREATED BY: Vishal Mehrotra   March 11 1996
  * REVISION HISTORY:
  * NAME         DATE        PURPOSE
  * Vishal     11.03.96     to define prototype for getindex and binsearch 
  *                         function 
  * DESCRIPTION: 
  * This file consist of all the prototypes for the functions being used in
  * the file catf.c
  */

#if defined (SGIR8K_SYS) || defined (SGIR4K_SYS) 
#include <ctype.h>
#include <widec.h>
#include <wctype.h>
#else
#include <wchar.h>
#endif

#include "StandardH.h"
#include "globals.h"

#if defined (PCWINNT_SYS) 
#define F_OK                    0
#define R_OK                    4
#define memccpy                 _memccpy
#define strdup                  _strdup
#define putenv                  _putenv
#define access                  _access
#define wcswcs                  wcsstr
#endif

#if defined (SGIR8K_SYS) || defined (SGIR4K_SYS)
/* Match Function Names for the SGI machines. */
#define wcscat                  wscat
#define wcsncat                 wsncat
#define wcscmp                  wscmp
#define wcsncmp                 wsncmp
#define wcscpy                  wscpy
#define wcsncpy                 wsncpy
#define wcslen                  wslen
#define wcschr                  wschr
#define wcsrchr                 wsrchr
#define wcspbrk                 wspbrk 
#define wcsspn                  wsspn
#define wcscspn                 wscspn
#define wcstok                  wstok
#endif

typedef wchar_t                 WCS ;

#endif                                   /* NOT A FORTRAN PORTION */

#define WCS_NULL                0
#define MAX_ERROR_SIZE          4096     
#define MAX_STD_ERROR_SIZE_WCS  MAX_ERROR_SIZE

#define MAX_ERROR_COLUMNS       72
#define MAX_ERROR_COLUMNS_MBCS  MAX_ERROR_COLUMNS*2

#define MAX_ERR_LINES           30      

#define MAX_LABEL_LEN_WCS       80      
#define MAX_LABEL_LEN_MBCS      MAX_LABEL_LEN_WCS * 2

#define MAX_FILENAME_SIZE       256
#define MAX_NLSPATH_SIZE        MAX_FILENAME_SIZE * 10     


#ifndef FORTRAN                            /* Fortran wrapper */

#define NLSPATH                 "NLSPATH"      /* Environment variable */
#define MAX_LANG_LEN            20
#define LANG_SUBST_STR          "%L"
#define NAME_SUBST_STR          "%N"
#define LOCALE_FROM_ENV         ""

#if defined (PCWINNT_SYS) 
#define DEFAULT_LOCALE          "default"
#define PATH_DELIMITER          ';'
#define PATH_DELIMITER_STRING   ";"
#define INI_FILE                "\\ansys.ini"
#define SECTION                 "Locale"
#define INI_NOT_FOUND           "Unable to Locate the Ini file."
#define LANG                    "Lang"
#define DOCU_DIR                "\\docu"
#define DIR_DELIMITER           '\\'
#define DIR_DELIMITER_STRING    "\\"
#else
#define DEFAULT_LOCALE          "C"
#define LANG                    "LANG"
#define PATH_DELIMITER          ':'
#define DOCU_DIR                "/docu"
#define DIR_DELIMITER_STRING    "/"
#endif



typedef struct
/*>typedef struct        ** Structure of the catlog file */
   {
   INT        mesg_id;
   INT        mesg_strn_len;
   } MESG ;


typedef struct
/*>typedef struct        ** Structure of the index file used for indexing messages */
   {
   INT        mesg_id;
   INT        loc_id;
   } INDEX ;

/*
 * Prototypes
 */
#ifdef ANSI_C_COMPAT

              /* catf.c Prototypes */

           INT  fnmfgets( FILE *fnamFP, char *subroutine, INT n_subroutine);
           void fnmfputs( FILE *fnamFP, char *subroutine                  );
           int  fnmsearch(char *fnam,char *list_ara[], int list_ara_siz);
           void catfgets( FILE *dataFP, FILE *indexFP, INT mesg_id, WCS *result);
           void catfputs( FILE *dataFP, FILE *indexFP, INT mesg_id, WCS *strn);
           FILE * catfopenUpdate( char * filename, FILE ** indexFP);
           FILE * catfopen( char * filename, FILE ** indexFP);
           void catfclose( FILE *dataFP, FILE * indexFP);
           int getindex( FILE * indexFP,  INT mesg_id);
           INT binsearch( INT x,FILE *indexFP,INT tot_records);


              /* ErrDbfunc.c Prototypes */

           INT  OpenErrorDb (void) ;
           void CloseErrDb (void) ;
           void GetMsgFromDb ( INT mesg_id, WCS * mesg, INT szMsg ) ;
           void GetStdMsgFromDbWcs ( INT mesg_id, WCS * mesg ) ;
           void GetStdMsgFromDbMbcs ( INT mesg_id, char * mesg ) ;
           void InitStandardMessages (void) ;
           INT  BuildPath (char *path, char *lang, char *name) ;
           INT  GetDbFilePath ( char *path) ;
           INT  PutEnvStr ( char *envVar, char *value) ;
           char* GetEnvString ( char *envVar) ;
           INT FileIsThere ( char *file) ;
#if defined(PCWINNT_SYS) 
           int FindIniPath(char szIniPath[]) ;
#endif
           char *GetNLSPATH (char *lang);
           char *GetLANG (void);

              /* WcsFuncs.c Prototypes */
           INT     isLineFeed ( WCS c ) ;
           INT     isWhiteSpace ( WCS c ) ;
           void    SpaceLineFeedInit(void) ;
           void    SubstituteParameters (WCS Inp[], double DpIn[],
                                            char *ChInptr, INT szchin) ;
           WCS *   IntegerToWcs ( INT );
           INT     WcsToMbs ( char *, WCS * , INT ) ;
           void    FStrToC ( char *Fstring, int length, char *Cstring) ;
           INT     FormatString (WCS *str,INT Ichar[]) ;
           INT     wrapLine ( WCS *str ) ;
           INT     stripLeadingSpaces ( WCS *str ) ;
#if !defined (PCWINNT_SYS)
           WCS     *wcswcs ( const WCS *str, const WCS *subStr ) ;
#endif


              /* WcsErrWindow.c Prototypes */
           void wcserrmsg ( INT *level, WCS wchdata[MAX_ERROR_SIZE]) ;

#else /* ANSI_C_COMPAT */

              /* catf.c Prototypes */

           int  fnmfgets( );
           void fnmfputs( );
           int  fnmsearch( );
           void catfgets( );
           void catfputs( );
           FILE * catfopenUpdate( );
           FILE * catfopen( );
           void catfclose( );
           int getindex( );
           int binsearch( );


              /* ErrDbfunc.c Prototypes */

           INT  OpenErrorDb ( ) ;
           void CloseErrDb ( ) ;
           void GetMsgFromDb ( ) ;
           void GetStdMsgFromDbWcs ( ) ;
           void GetStdMsgFromDbMbcs ( ) ;
           void InitStandardMessages ( ) ;
           INT  BuildPath ( ) ;
           INT  GetDbFilePath ( ) ;
           INT  PutEnvStr ( ) ;
           char* GetEnvString ( ) ;
           INT FileIsThere ( ) ;
#if defined(PCWINNT_SYS) 
        int FindIniPath( ) ;
#endif
           char *GetNLSPATH ( );
           char *GetLANG ( );

              /* WcsFuncs.c Prototypes */
           INT  isLineFeed ( ) ;
           INT  isWhiteSpace ( ) ;
           void SpaceLineFeedInit ( ) ;
           void SubstituteParameters ( ) ;
           WCS *IntegerToWcs ( );
           INT  WcsToMbs ( ) ;
           void FStrToC ( ) ;
           INT  FormatString ( ) ;
           INT  wrapLine ( ) ;
           INT  stripLeadingSpaces ( ) ;
#if !defined (PCWINNT_SYS)
           WCS  *wcswcs ( ) ;
#endif

              /* WcsErrWindow.c Prototypes */
           void wcserrmsg ( ) ;

#endif /* ANSI_C_COMPAT */

              /* Fortran 77 Interfaceing Functions from WcsF77Intrfc.c */

#ifdef ANSI_C_COMPAT

#if defined (UPCASE_SYS)
           void CALLTYP GETWCSSTRING (
               INT* , double [], char *, INT[],INT 
           );

           INT CALLTYP GETMBCSSTRING(
              INT [],  char *, INT[] , INT
           );
           void CALLTYP WCSERRPOP ( INT *, INT []);
           void CALLTYP GETSTDMSGFROMDBMBCS ( INT *, char *, INT );
#else              /* UPCASE_SYS */
#if defined (NOUNDER_SYS)
           void CALLTYP getwcsstring(
              INT[], INT*, INT* , double [], char *, INT[],INT
           );
           INT CALLTYP getmbcsstring( 
              INT [],  char *, INT[] , INT 
           );
           void CALLTYP wcserrpop ( INT *, INT []);
           void getstdmsgfromdbmbcs(INT *, char *,INT);
#else /* NOUNDER_SYS */
           void CALLTYP getwcsstring_(
              INT[], INT*, INT* , double [], char *, INT[],INT
           );
           INT CALLTYP getmbcsstring_( 
              INT [],  char *, INT[] , INT
           );
           void CALLTYP wcserrpop_ ( INT *, INT []);
           void CALLTYP getstdmsgfromdbmbcs_ (INT *,char *, INT);
#endif /* NOUNDER_SYS */
#endif /* UPCASE_SYS */

#else  /* ANSI_C_COMPAT */

#if defined (UPCASE_SYS)
           void CALLTYP GETWCSSTRING(); 
           INT CALLTYP GETMBCSSTRING(); 
           void CALLTYP WCSERRPOP (); 
           void CALLTYP GETSTDMSGFROMDBMBCS();
#else  /* UPCASE_SYS */
#if defined (NOUNDER_SYS)
           void CALLTYP getwcsstring(); 
           INT CALLTYP getmbcsstring(); 
           void CALLTYP wcserrpop (); 
           void CALLTYP getstdmsgfromdbmbcs();
#else  /* NOUNDER_SYS */
           void CALLTYP getwcsstring_(); 
           INT CALLTYP getmbcsstring_(); 
           void CALLTYP wcserrpop_(); 
           void CALLTYP getstdmsgfromdbmbcs_();
#endif /* NOUNDER_SYS */
#endif /* UPCASE_SYS */

#endif /* ANSI_C_COMPAT */

#endif /* Fortran wrapper */
#endif /* ErrCatalog_H */ 

