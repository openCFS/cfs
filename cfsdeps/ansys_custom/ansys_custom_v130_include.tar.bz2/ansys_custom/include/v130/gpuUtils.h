/*HFILE gpuUtils.h                                              jrb */

/*
------------------------------------------------------------------------
------- Notice - This file contains ANSYS Confidential information
------------------------------------------------------------------------
*/

struct gpu_matrix {
  int    nBlocks;
  int    nRows;
  int    *extentVec;
  double *diagVec;
  int    *nzVec;
  int    **matInds;
  double **matVals;
};

typedef struct gpu_matrix *gpuMatrix;

extern gpuMatrix  GPUmatObj;

extern void initMatrixOnGPU(int, int, int*);
extern void loadMatrixRowOnGPU(int, int, double, int, int*, double*);
extern void AxOnGPU(double*, double*);
extern void freeMatrixOnGPU();
extern void printGPUmatrix();
extern void writeGPUmatrix(FILE*);
extern void readGPUmatrix(FILE*);

