/*HFILE ansMPIComm.h                       ANSI_C                           sam
------------------------------------------------------------------------
------- Notice - This file contains ANSYS Confidential information
------------------------------------------------------------------------
*/

/*------------------------------ Description ---------------------------

\Author:    Sam Murgie

\Title:     Standard MPI C Header

\Desc:      Include standard MPI C header
            Also provides prototypes for ansMPIComm.c


            Currently contains the following MPI functions:

                   cansMPI_Init
                   cansMPI_Finalize
                   cansMPI_Abort
                   cansMPI_Send
                   cansMPI_BSend
                   cansMPI_ImmedSend
                   cansMPI_Recv
                   cansMPI_ImmedRecv
                   cansMPI_Reduce
                   cansMPI_AllReduce
                   cansMPI_Bcast
                   cansMPI_Gather
                   cansMPI_GatherV
                   cansMPI_Barrier
                   cansMPI_Probe
                   cansMPI_Test
                   cansMPI_Wait
                   cansMPI_WaitAny
                   cansMPI_WaitAll
                   cansMPI_Request_Free
                   cansMPI_CommGroup
                   cansMPI_GroupIncl
                   cansMPI_CommCreate
                   cansMPI_GroupFree
                   cansMPI_CommFree
                   cansMPI_CommSize
                   cansMPI_CommRank
                   cansMPI_BufferAttach
                   cansMPI_BufferDetach
                   cansMPI_GetProcName
                   cansMPI_GetParameter
                   cansMPI_Inquire
                   cansMPI_Setup

\History:   Created 5/1/03 (dc): Combined dpcg MPIComm.h and c_ampi_lib.h

\Function(s)
 -Primary:      Include standard MPI C header
 -Secondary:    Prototypes for cansMPICommm.c
 -External:     none
 -Internal:     none
 -Static:       thisCPU, numCPU

----------------------------------------------------------------------*/

#ifndef __ANSMPICOMM_H__
#define __ANSMPICOMM_H__ 1

/*-------------------------------- Globals ---------------------------*/

#ifdef __cplusplus
  extern "C" {
#endif /* __cplusplus */

extern INT  numCPU;
extern INT  thisCPU;

extern INT  ANSMPI_MAX;
extern INT  ANSMPI_MIN;
extern INT  ANSMPI_SUM;
extern INT  ANSMPI_MAXLOC;
extern INT  ANSMPI_MINLOC;
extern INT  ANSMPI_BITAND;
extern INT  ANSMPI_BITOR;

extern INT  ANSMPI_CHARACTER;
extern INT  ANSMPI_INTEGER;
extern INT  ANSMPI_LONGINT;
extern INT  ANSMPI_REAL;
extern INT  ANSMPI_DOUBLE;
extern INT  ANSMPI_COMPLEX;

extern INT  ANSMPI_ANY_SOURCE;
extern INT  ANSMPI_ANY_TAG;
extern INT  ANSMPI_GROUP_NULL;
extern INT  ANSMPI_COMM_NULL;
extern INT  ANSMPI_REQUEST_NULL;
extern INT  ANSMPI_STATUS_SIZE;
extern INT  ANSMPI_STATUS_SOURCE;
extern INT  ANSMPI_STATUS_TAG;

extern INT  ANSMPI_WORLD;

/*------------------------------ Prototypes --------------------------*/

/* initialization and termination routines */
void     cansMPI_Initialized(INT*);
void     cansMPI_Init(void);
void     cansMPI_Finalize(void);
void     cansMPI_Abort(INT, INT);

/* point-to-point communication routines */
void     cansMPI_Send(void*, INT, INT, INT, INT, INT);
void     cansMPI_BSend(void*, INT, INT, INT, INT, INT);
void     cansMPI_ImmedSend(void*, INT, INT, INT, INT, INT, INT*);
void     cansMPI_Recv(void*, INT*, INT, INT, INT, INT);
void     cansMPI_ImmedRecv(void*, INT, INT, INT, INT, INT, INT*);

/* collective communication routines */
void     cansMPI_Reduce(void*, void*, INT, INT, INT, INT, INT);
void     cansMPI_AllReduce(void*, void*, INT, INT, INT, INT);
void     cansMPI_Bcast(void*, INT, INT, INT, INT);
void     cansMPI_Gather(void*, INT, INT, void*, INT, INT, INT, INT);
void     cansMPI_GatherV(void*, INT, INT, void*, INT*, INT*, INT, INT, INT);
void     cansMPI_Barrier(INT);

/* message utility routines */
INT      cansMPI_Probe(INT, INT*, INT*, INT);

/* request utility routines */
void     cansMPI_Test(INT*,INT*);
void     cansMPI_Wait(INT*);
void     cansMPI_WaitAny(INT, INT*, INT*);
void     cansMPI_WaitAll(INT, INT*);
void     cansMPI_Request_Free(INT*);

/* communicator utility routines */
void     cansMPI_CommGroup(INT, INT*);
void     cansMPI_GroupIncl(INT, INT, INT*, INT*);
void     cansMPI_CommCreate(INT, INT, INT*);
void     cansMPI_GroupFree(INT*);
void     cansMPI_CommFree(INT*);
void     cansMPI_CommSize(INT, INT*);
void     cansMPI_CommRank(INT, INT*);

/* miscellaneous utility routines */
void     cansMPI_BufferAttach(INT);
void     cansMPI_BufferDetach(void);
void     cansMPI_GetProcName(char*, INT*);
INT      cansMPI_GetParameter(INT);
INT      cansMPI_Inquire(INT);
void     cansMPI_Setup(INT, INT);

/* error handler routines */
void     handleMPIerror(char*,INT);

#ifdef __cplusplus
}
#endif /* __cplusplus */

/*--------------------------End of Prototypes ------------------------*/

/*---------------------------- End Of Module -------------------------*/

#endif
