/*****************************************************************************
 *                   Copyright (C) 1999 CMSoft                               *
 *                                                                           *
 *  These lines of code and declarations contain unpublished proprietary     *
 *  information of CMSoft. They may not be copied or duplicated in whole     *
 *  or part without prior authorization from CMSoft.                         *
 *                                                                           *
 *****************************************************************************/

#ifndef FS_SKY_MATRIX_H_
#define FS_SKY_MATRIX_H_

#include <stdio.h>
#include "cadoe.h"
#include "Solver.h"
#include "C_MatMGe.h"
#include "C_MatCSR.h"
#include "C_TimeManager.h"
#include "commun.h"
#include "FSConnectivity.h"

class FSRbm;
class FSFullMatrix;
class FSConnectivity;
class EqNumberer;
class ConstrainedDSA;
class C_Communicator;

class FSSkyData 
{
protected: 
  int *lacol;		// last active column
  int *pivot;		// stores pivot information
  int *dlp;		// diagonal location pointer array
  int *rowColNum;	// unconstrained row/column numbers
  int *zeroDiag;	// 1 if diangonal, column and row are all zero
  int neq;		// number of equations of the unconstrained system
  int numUncon;		// number of unconstrained degrees of freedom (dofs)
  double tolerance;	// factorization tolerance
  double avgTol;	// factorization tolerance
  int nzem;		// number of  zero energy modes
  FSRbm *_rbm;          // stores rigid body mode information
  int isTRBM;		// 0 = geometric rigid body modes
			// 1 = tolerance rigid body modes
  
public:
  FSSkyData(FSConnectivity *cn, ConstrainedDSA *cdsa,double trbm,FSRbm *rigid=0);
  FSSkyData(FSConnectivity *cn, EqNumberer *dsa, double trbm, int *rCN );
  FSSkyData(FSConnectivity *cn, EqNumberer *dsa, compStruct &csCoarse, int *CompToDof);
  FSSkyData(FSConnectivity *cn, EqNumberer *dsa, double trbm);
  FSSkyData(C_MatMGe<double> &mat, int nbRbms, double trbm);
  FSSkyData(C_MatSp<double> &mat, int nbRbms, double trbm);
  virtual ~FSSkyData();
  
  int getKstop(int len);
  
  C_TimeManager _selfTimer;
};

class FSSkyMatrix : public FSSkyData, public FSAssembledSolver {
  double *skyA;        // Skyline array 
protected:
  void allocateZeroAndRbm(int _isTRBM);
public:

  // local solver constructor
  FSSkyMatrix(FSConnectivity *cn, ConstrainedDSA *, 
	      double trbm, FSRbm *rigid=0);

  // local preconditioner solver constructor
  FSSkyMatrix(FSConnectivity *cn, EqNumberer *dsa, double trbm,int *rCN);

  // coarse problem solver constructor
  FSSkyMatrix(FSConnectivity *cn, EqNumberer *dsa, double trbm);
  FSSkyMatrix(FSConnectivity *cn, EqNumberer *dsa, compStruct &csCoarse, int *CompToDof);
    
  FSSkyMatrix(C_MatMGe<double> &mat, int nbRbms, double trbm);
  FSSkyMatrix(C_MatSp<double> &mat, int nbRbms, double trbm);
  
  virtual ~FSSkyMatrix() {LM_FREE(skyA);}
  
  double diag(int dof); // returns diagonal entry
  void  decouple();

  // assembly
  void add(FullSquareMatrix &kel, int *dofs);
  void add(FSFullMatrix &kel, int *dofs);
  void add(FSFullMatrix &matrix, int rowStart, int colStart);

  // Unification for distributed
  void unify(C_Communicator *);

  // factor calls either Factor() or Factor(rbm)
  void factor() {}
  void Factor();             // Factors a matrix in sky line form.
  void Factor(int numComp, int *CompToDof, int *CompToNbRbms); // Factors a matrix in sky line form.
  void parallelFactor();

  void pfact(int, int, double *);
  
  void solve(double *rhs, double *solution);
  void solve(FSVector &rhs, FSVector &solution );

  void solve(FSVector & rhs); // Forward & Backward solve 
  void solve(double * rhs); // re solve the system, overwriting rhs

  void solve(int numRHS, double **RHS);
  void solve(FSFullMatrix &);

  void addDiscreteMass(int cdof, double diMass);
  void zeroAll();
  void print(char *msg);
  void WriteMatlab(FILE *fp);

  void toMatMGe(C_MatMGe<double> &fullMat);
  void toMatSp(C_MatSp<double> &csrMat, char mattype = 'L');
  
  double* getNullSpace();           // retrieve zero energy modes 
  void    getNullSpace(double *rbm);// retrieve zero energy modes
  FSRbm* getRBMs();      // retrieve the rigid body modes
  int  numRBM() { return nzem; }    // retrieve the number of rigid body modes

  long size()  { return (numUncon) ? dlp[numUncon - 1] : 0; }
  int  neqs()  { return numUncon;          }
  void setAvgTol(double x) { avgTol = x; }
  double trace(); 

  int MemSize();
}; 

#endif
