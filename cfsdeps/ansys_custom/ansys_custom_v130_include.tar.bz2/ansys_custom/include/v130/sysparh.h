/* sid 60.1 copy of sysparh.h last changed by hjm on 2005/07/20 18:24:32 */
/*sysparh.h							SAM,system
------------------------------------------------------------------------
------- Notice - This file contains ANSYS Confidential information --------
------------------------------------------------------------------------
*/
/* 
 * *** ansys(r) copyright(c) 2003
 * *** ansys, inc.
 */

/*------------------------------ Description ---------------------------
\Author:	Sam Murgie
\Title:		System dependent parameters and paths include file.
\Desc:		Similar to SYSPAR, this file should contain ALL system
\               dependent paths, parameters, etc.
\History:	94/03/02 : sam - initial creation
\               94/05/11 : sam - added AP_CLASS_NAME
\               94/05/12 : sam - added DEFDIR and DEFEXT
\               94/05/17 : sam - added IBYT
\               94/05/24 : sam - added XTERM
\               94/05/31 : sam - added paths to XANSYS scripts:
					XANSSUB_PATH
					XANSBAT_PATH
					XANSINT_PATH
					XANSHLP_PATH
					XANSDSP_PATH
					XANSCMP_PATH
					XANSDMO_PATH
\               94/06/16 : sam - removed WIN_OPT_INT_2
				 renamed WIN_OPT_INT-1 to WIN_OPT_INT
				 added comments
\               94/06/29 : sam - change name of DEMO to EXAMPLES
\               94/07/06 : sam - remove /usr from installation path
\               98/02/26 : sam - add COPYRIGHT
\               04/05/17 : smarguer - add INT_VERSION and INT_MINOR_VERSION
\               04/05/25 : smarguer - add STR_VERSION and FLOAT_VERSION


\Function(s)
 -Primary:	none
 -Secondary:	none
 -External:	none	
 -Internal:	none
 -Static:	none
----------------------------------------------------------------------*/



/*------------------------------ Header files ------------------------*/

/*------------------------------ Dependencies ------------------------*/

/* PROGRAMMERS NOTE:  all paths which are inherently system dependent
                      should be placed in this file.  S&P should make
                      sure the production paths are used              */

/*----------------------- Static Macro Definitions -------------------*/

/*          SYSTEM DEPENDENT PATH AND FILE NAMES                      */

/*            SASI DEVELOPMENT PATHS                                  */

#if !defined (__SYSPARH_H__)         /* Below spans entire file */
#  define __SYSPARH_H__


/*  the following should be used with development versions            */

#if defined (PCWINNT_SYS)
#   define DOCDIR         "\\ansys_inc\\v130\\ansys\\docu"
#   define NAMBIN         "\bin\\"
#   define NAMDOC         "\docu\\"
#   define NAMINST        "\ansys_inc\v130\ansys"
#   define ANSYS_PRODUCT  "ANSYS130_PRODUCT"
#else
#   define DOCDIR         "/ansys_inc/v130/ansys/docu"
#   define NAMBIN         "/bin/"
#   define NAMDOC         "/docu/"
#   define NAMINST        "/ansys_inc/v130/ansys"
#endif

/*  the following should be used for production and S&P versions      */
/*
#   define DOCDIR         "/ansys_inc/v130/ansys/docu"
#   define NAMBIN         "/bin/"
#   define NAMDOC         "/docu/"
#   define NAMINST        "/ansys_inc/v130/ansys"
                                                                      */


/*          UI FILE NAMES                                             */
#   define ENTRY_HLP_PATH "ENTRY.HLP"
#   define UIINDEX_PATH   "UIINDEX.GRN"


/*          ENVIRONMENT VARIABLE NAMES                                */
#   define ANS_DIR        "ANSYS130_DIR"
#   define ANS_PRODUCT    "ANSYS130_PRODUCT"
#   define ANS_SYSDIR     "ANSYS_SYSDIR"

/*          LAUNCHER FILE NAMES                                       */
#   define XANSSUB_PATH   "xanssub.csh"
#   define XANSBAT_PATH   "xansbat.csh"
#   define XANSINT_PATH   "xansint.csh"
#   define XANSHLP_PATH   "xanshelp.csh"
#   define XANSDSP_PATH   "xansdisp.csh"
#   define XANSCMP_PATH   "xanscmap.csh"
#   define XANSEXM_PATH   "xansexmpl.csh"

#   define XANSHLP_URL_PATH   "toc.html"


/*          SYSTEM DEPENDENT KEYS AND FLAGS                           */
#define SYCASE            0
#if defined (FULL_64)
#   define IBYT              8
#else
#   define IBYT              4
#endif
/*          LAUNCH NEEDS updated with REVISION NUMBER                */
#define LAUNCH "130"
#define XTERM             "xterm"
#if defined (PCWINNT_SYS)
#define DEFDIR            "\\"
#define DEFDIR_CHAR       '\\'
#else
#define DEFDIR            "/"
#define DEFDIR_CHAR       '/'
#endif
#define DEFEXT  	  "."

#define SYS_PATH_MAX     260
#define INPUT_PATH_MAX   260
#define DIRECTORY_MAX    248
#define FNAME_MAX        248
#define EXTENSION_MAX      8
#define SYS_LNG_CMDLN    640
#define COMMAND_WORD_LEN   8

/*          RELEASE DEPENDENT DEFINITIONS                            */
#define AP_CLASS_NAME     "ANSYS130"
#define ANSYS_REV_NUM     "ANSYS 13.0"
#define COPYRIGHT         "2010"
#define INT_VERSION       13
#define INT_MINOR_VERSION 0
#define STR_VERSION       "13.0"
#define FLOAT_VERSION     13.0

/*          XANSYS DEPENDENT DEFINITIONS                            */
#define ICON_YES          "ICONIC"
#define ICON_NO           "NOICONIC"
#define WIN_OPT_BAT       "-title ANSYS130 -n ANSYS130 -name ANSTERM"
#define WIN_OPT_INT       "-title ANSYS_13.0_Output -n Output -name ANSTERM"
#define WIN_OPT_HELP      "-title anshelp130 -n anshelp -name ANSTERM"
#define WIN_OPT_DISP      "-title DISPLAY130 -n DISPLAY -name ANSTERM"
#define WIN_OPT_CMAP      "-title CMAP130 -n CMAP -name ANSTERM"
#define WIN_OPT_EXMPL     "-title ANSYS_Examples -n Examples -name ANSTERM"
#define OUTPUT_EXT        "out"

/*                      D E S C R I P T I O N                         */
/*
DOCDIR                  identical to DOCDIR in SYSPAR, docu file path
NAMBIN                  name of the binary file directory
NAMINST                 name of ANSYS installation directory
ENTRY_HLP_PATH          file name to entry screen picture file
UIINDEX_PATH            file name to UIINDEX help engine file
XANSSUB_PATH		file name to xanssub script
XANSBAT_PATH		file name to xansbat script
XANSINT_PATH		file name to xansint script
XANSHLP_PATH		file name to xanshelp script
XANSDSP_PATH		file name to xansdisp script
XANSCMP_PATH		file name to xanscmap script
XANSEXM_PATH		file name to xansexmpl script

SYCASE                  identical to SYCASE in SYSPAR:
                            0 = mixed case file names
                            1 = upper case only
IBYT			identical to IBYT in SYSPAR:
			number of bytes per integer word
XTERM			default name of X window program
			(e.g. xterm, hpterm, decterm, aixterm, etc.)
DEFDIR			delimeter between directory names and file names
DEFEXT			delimeter between file names and extensions

AP_CLASS_NAME		application class name which is also used
                        for the resource file name by Motif (this
			should be updated every revision); same
			as APNAME in SYSPAR
ANSYS_REV_NUM		ANSYS Revision Number

ICON_YES		string passed to the XANSYS script xanssub specifying
			that the window created should be opened as an icon
ICON_NO			string passed to the XANSYS script xanssub specifying
			that the window created should be opened as a windo
WIN_OPT_BAT		title and name of ANSYS batch window as created by
			XANSYS
WIN_OPT_INT  		title and name of ANSYS interactive window as created by
			XANSYS
WIN_OPT_HELP		title and name of ANSHELP window as created by
			XANSYS
WIN_OPT_DISP		title and name of DISPLAY window as created by
			XANSYS
WIN_OPT_CMAP		title and name of CMAP window as created by
			XANSYS
WIN_OPT_EXMPL		title and name of ANSYS demo window as created by
			XANSYS
OUTPUT_EXT		default extension for the output file as created by
			XANSYS


                                                                      */

#endif                  /* End of if that spans entire file. */

/*---------------------------- End Of Module -------------------------*/
