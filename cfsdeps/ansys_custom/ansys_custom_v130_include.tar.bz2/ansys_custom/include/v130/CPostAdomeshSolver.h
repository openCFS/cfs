/* CPostAdomeshSolver.h CADOE */
/*******************************************************************************
 *
 *   CPostAdomeshSolver.h -- Classe d'interface avec adomesh derivee 
 *                           dans le contexte solveur
 *
 * |Module:  Solver
 *
 * |Description:
 *
 * |Auteur: Emmanuel DELOR
 *
 * |Creation: May 2005
 *
 * |Version:
 *
 * |Copyright:  copyright(c) 2010 SAS IP, Inc.  All rights reserved.
 *
 ******************************************************************************/

#ifndef __CPostAdomeshSolver_h__ 
#define __CPostAdomeshSolver_h__ 1 

#include "cadoe.h"
#include "CPostAdomesh.h"
#include "sx_CADOE_solver.h"

class CPostAdomeshSolver : public CPostAdomesh
{
public:
  CPostAdomeshSolver() {_modele = NULL;};
  CPostAdomeshSolver(T_modele *modele) {_modele = modele;}
  ~CPostAdomeshSolver() {};
  
  IVEC *buildElemActive(VEC *dxyz, T_statut *ier) const;
  
protected:
  T_modele *_modele;
};

#endif
