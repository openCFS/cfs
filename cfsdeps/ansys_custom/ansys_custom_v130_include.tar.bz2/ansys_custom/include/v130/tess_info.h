/*  tess_info.h */
/* 
 * *** copyright(c) 2010 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  tess_info.h
 *  header file for tess_info.c
 *
 */

/*----------------- Globally accessible structure types     -----------------*/

#define     SIZE_6                  6
#define     SIZE_4                  4
typedef struct {
   INT      length;                 /* length of data                     */
   DOUBLE   uv[SIZE_6];             /* node data                          */
} NINFO;

typedef struct {
   INT      node[SIZE_4];           /* element connectivity               */
   INT      nummx;                  /* number of nodes per element        */
} FACET;

typedef struct {
   INT      num_node;               /* number of nodes                    */
   INT      num_elem;               /* number of facets                   */
   INT      max_node;               /* max number of nodes                */
   INT      max_elem;               /* max number of facets               */
   INT      num_loop;               /* number of loops                    */
   NINFO    *ndata;                 /* node records                       */
   FACET    *elem;                  /* element records                    */
   INT      *loop;                  /* loop record                        */
} TESS;


/*----------------- Globally accessible function prototypes --------------*/



/* (1)-------------------------------------------------------------*/

#if defined(RS6000_SYS) || defined(HP32_SYS)

/* === C functions called from FORTRAN */

#define tess_init_    tess_init
#define tess_get_     tess_get
#define tess_put_     tess_put
#define tess_ndget_   tess_ndget
#define tess_elget_   tess_elget
#define tess_inqr_    tess_inqr
#define tess_ndput_   tess_ndput
#define tess_elput_   tess_elput
#define tess_reset_   tess_reset
#define tess_free_    tess_free
#define tess_bndget_  tess_bndget

/* === FORTRAN subroutines called from C */

#define saniqr_        saniqr
#define saeiqr_        saeiqr
#define saliqr_        saliqr
#define sanget_        sanget
#define saeget_        saeget
#define saeput_        saeput
#define sanput_        sanput
#define sansel_        sansel
#define saesel_        saesel
#define slinqr_        slinqr
#define salget_        salget
#define slgcvn_        slgcvn
#define cvinqr_        cvinqr
#define cvpiqr_        cvpiqr
#define nbdiqr_        nbdiqr
#define slgcuv_        slgcuv
#define sclen_         sclen


#endif

/* (2)-------------------------------------------------------------*/

#if defined(WATCOMC_SYS) \
    || defined(PCWINNT_SYS)
/* === C functions called from FORTRAN */

#define tess_init_     TESS_INIT
#define tess_get_      TESS_GET
#define tess_put_      TESS_PUT
#define tess_ndget_    TESS_NDGET
#define tess_elget_    TESS_ELGET
#define tess_inqr_     TESS_INQR
#define tess_init_     TESS_INIT
#define tess_ndput_    TESS_NDPUT
#define tess_elput_    TESS_ELPUT
#define tess_reset_    TESS_RESET
#define tess_free_     TESS_FREE
#define tess_bndget_   TESS_BNDGET

/* === FORTRAN subroutines called from C */

#define saniqr_         SANIQR
#define saeiqr_         SAEIQR
#define saliqr_         SALIQR
#define sanget_         SANGET
#define saeget_         SAEGET
#define sanput_         SANPUT
#define saeput_         SAEPUT
#define sansel_         SANSEL
#define saesel_         SAESEL
#define slinqr_         SLINQR
#define salget_         SALGET
#define slgcvn_         SLGCVN
#define cvinqr_         CVINQR
#define cvpiqr_         CVPIQR
#define nbdiqr_         NBDIQR
#define slgcuv_         SLGCUV
#define sclen_          SCLEN



#endif

/* (3)-------------------------------------------------------------*/
#if defined(WATCOMC_SYS)

/* === C functions called from FORTRAN */
#pragma aux TESS_INIT "^";
#pragma aux TESS_GET "^";
#pragma aux TESS_PUT "^";
#pragma aux TESS_NDGET "^";
#pragma aux TESS_ELGET "^";
#pragma aux TESS_INQR "^";
#pragma aux TESS_NDPUT "^";
#pragma aux TESS_ELPUT "^";
#pragma aux TESS_RESET "^";
#pragma aux TESS_FREE "^";
#pragma aux TESS_BNDGET "^";

/* === FORTRAN subroutines called from C */
#pragma aux SANIQR "^";
#pragma aux SAEIQR "^";
#pragma aux SALIQR "^";
#pragma aux SANGET "^";
#pragma aux SAEGET "^";
#pragma aux SANPUT "^";
#pragma aux SAEPUT "^";
#pragma aux SANSEL "^";
#pragma aux SAESEL "^";
#pragma aux SLINQR "^";
#pragma aux SALGET "^";
#pragma aux SLGCVN "^";
#pragma aux CVINQR "^";
#pragma aux CVPIQR "^";
#pragma aux NBDIQR "^";
#pragma aux SLGCUV "^";
#pragma aux SCLEN  "^";


#endif

/* (4)-------------------------------------------------------------*/
/*
 * *** FUNCTION RETURN TYPE DECLARATION
 */

#if !defined(PCWINNT_SYS)

/* === C functions called from FORTRAN */
   INT  tess_get_(INT *p_subarea_id, PTR *p_tess);
   void tess_put_(INT *p_subarea_id, PTR *p_tess);
   INT  tess_ndget_(PTR *p_tess, INT *node_id, DOUBLE *array);
   INT  tess_elget_(PTR *p_tess, INT *elem_id, INT *iarray, INT *type);
   INT  tess_inqr_(PTR *p_tess, INT *key);
   void tess_init_(INT *p_subarea_id, PTR *p_tess, INT *facet_type);
   void tess_ndput_(PTR *p_tess, INT *node_id, INT *length, DOUBLE *array);
   void tess_elput_(PTR *p_tess, INT *elem_id, INT *length, INT *iarray, INT *type);
   void tess_reset_(PTR *p_tess);
   void tess_free_(PTR *p_tess);
   void tess_bndget_(INT *p_subarea_id, INT *p_surf_id, PTR *p_tess, INT *iloop, INT *nsur, INT *nnode, INT *nloop, INT *beg_list, INT *end_list, DOUBLE *avglen, DOUBLE *uvmax, INT *nvert, INT *vert_list, INT *kerr);

/* === FORTRAN subroutines called from C */
   INT    saniqr_();
   INT    saeiqr_();
   INT    saliqr_();
   INT    sanget_();
   INT    saeget_();
   void   sanput_();
   void   saeput_();
   void   sansel_();
   void   saesel_();
   INT    slinqr_();
   INT    salget_();
   INT    slgcvn_();
   INT    cvinqr_();
   INT    cvpiqr_(); 
   DOUBLE nbdiqr_();  
   INT    slgcuv_(); 
   INT    sclen_();  

/* (5)-------------------------------------------------------------*/
#else

/* === C functions called from FORTRAN */
   void CALLTYP tess_init_( INT *, PTR *, INT *);
   INT CALLTYP tess_get_( INT *, PTR *);
   void CALLTYP tess_put_( INT *, PTR *);
   INT  CALLTYP tess_ndget_( PTR *, INT *, DOUBLE *);
   INT  CALLTYP tess_elget_( PTR *, INT *, INT *, INT *);
   void CALLTYP tess_ndput_( PTR *, INT *, INT *, DOUBLE *);
   void CALLTYP tess_elput_( PTR *, INT *, INT *, INT *, INT *);
   void CALLTYP tess_reset_( PTR *);
   void CALLTYP tess_free_( PTR *);
   void CALLTYP tess_bndget_( INT *,    INT *, PTR *, INT *, INT *, 
                              INT *,    INT *, INT *, INT *, DOUBLE *, 
                              DOUBLE *, INT *, INT *, INT *);
   INT  CALLTYP tess_inqr_ ( PTR *, INT *);


/* === FORTRAN subroutines called from C */
   INT    CALLTYP saniqr_( INT *, INT *, INT * );
   INT    CALLTYP saeiqr_( INT *, INT *, INT * );
   INT    CALLTYP saliqr_( INT *, INT *, INT * );
   INT    CALLTYP sanget_( INT *, INT *, DOUBLE * );
   INT    CALLTYP saeget_( INT *, INT *, INT * );
   void   CALLTYP sanput_( INT *, INT *, INT *, DOUBLE * );
   void   CALLTYP saeput_( INT *, INT *, INT *, INT * );
   void   CALLTYP sansel_( INT * );
   void   CALLTYP saesel_( INT * );
   INT    CALLTYP slinqr_( INT *, INT * );
   INT    CALLTYP salget_( INT *, INT *, INT * );
   INT    CALLTYP slgcvn_( INT *, INT * );
   INT    CALLTYP cvinqr_( INT *, INT * );
   INT    CALLTYP cvpiqr_( INT *, INT * );
   DOUBLE CALLTYP nbdiqr_( INT * );
   INT    CALLTYP slgcuv_( INT *, INT *, INT *, DOUBLE *);
   INT    CALLTYP sclen_( DOUBLE *, INT *, DOUBLE *, DOUBLE *, DOUBLE *,
                          DOUBLE *, INT *);




#endif
