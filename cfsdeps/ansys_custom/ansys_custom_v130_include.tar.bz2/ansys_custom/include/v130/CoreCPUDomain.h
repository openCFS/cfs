#ifndef _CORE_CPU_DOMAIN_H_
#define _CORE_CPU_DOMAIN_H_

class FSElement;
class FSCoordSet;
class FSConnectivity;
class FSSubDTopo;
class DofSetArray;
class DofSet;
template <class T> class FSCommPattern;
class BCond;
class FSFullMatrix;
class FSSubDomCore;
class FSDistInfo;
class FSCoreSolver;
class FSDistVector;
class FSVector;
class FSAssembledSolver;
class EqNumberer;
class FSInfo;
class ConstrainedDSA;
class StackFSFullMatrix;
class FSSubPreprocessor;
class C_Gmat;

#include "C_ContactPair.h"
#include "FSConnectivity.h"
#include "C_Gmat.h"
#include "FSBodyRbm.h"

class FSCoreCPUPreprocessor 
{
protected:
  int _glNumSub;		// total number of sub-domains over all CPUs
  int _localNumSub;		// number of sub-domains for this CPU
  
  string _jobname;
  int _glNumEle, _glNumNodes;	// of the whole model
  int _numEle, _numNodes;	// of this CPU
  FSElement **_allElements;	// of this CPU (_numEle)
  FSCoordSet *_allNodes;	// of this CPU (_numNodes)
  FSConnectivity *_subToElem, *_subToNode;	// local subs because local numbering
  FSConnectivity *_nodeToSub, *_subToSub;	// global subs, global numbering
  FSConnectivity *_subToNodeT, *_subToNodeC;
  FSConnectivity *_allSubToElem;

  // RBMs
  vector <FSBody *> _bodies;
  vector <FSBodyRbm *> _bodiesRbm;
  vector <FSRbm *> _rbms;
  int *_nbRbmsSub;		// size = number of sub-domains over all CPUs
  FSConnectivity *_subToBody;		// size = number of sub-domains over all CPUs
  int *_nbRbmsBody;		// size = number of bodies
  int _sumDimPhi;		// sum of number of RBMs over all bodyRbms
  
  DofSetArray *_gdsa;
  ConstrainedDSA *_gcdsa;
  
  int *_isElemUnsym;		// size = nbElements
  multimap<int,int> _pairsDual;	// pairs of neighbour domains <subI,subJ> where subI<subJ
  
  // contact pairs
  C_ContactPairMgr *_cPairs;
  int _nbLagPairs;
  int _nbPenPairs;
  
  int *_elemToSub;
  FSConnectivity *_cpuToSub;  
  FSSubPreprocessor **_subPreproc;
  FSSubDomCore **_subCore;
  C_SubContactLagMgr _subContactLagMgr;
  int *_isContactQuadElem;
  int _dim;
  
  C_MatSp<double> _Kccg;
  
  FSInfo *_fsInfo; 
  FSSubDTopo *_subDTopo;
  FSCommPattern<double> *_interPat;
  
  int _nCrn;		// Number of corners nodes
  int _nCoarse;		// 
  int _numContactCoarse, _numCEcoarse, _numLMPCcoarse;
  DofSet *_crnDofs;	// 
  
  void makeAllConnect();
  FSConnectivity *makeSubComList(int glSubNum, int &numNeighb, int *&neighbSubs);
  
  int _nRotNodes;
  int *_rotNodes;
  double (*_nodeRot)[3];
  
  void makeCEConnect();
  void makeSubICore(int iSub);
  void makeMaps(int iSub);
  void allocateKccg(int, int);
  void allocateKrr(int iSub);
  void allocateKrc(int iSub);
  void allocateKbb(int iSub);
  void allocateKii(int iSub);
  void allocateKccStar(int iSub);
  void allocateKrrm1Krc(int iSub);
  void allocateBrKrrm1Krc(int iSub);
  void allocateBrKrrm1Brt(int iSub);
  void allocateKbiKiim1Kib(int iSub);
  
  void allocateSolvers(int iSub);
  void printInfosSubs();
  void printInfosSubs(int iSub);
  void makeElemToSub(FSConnectivity *subToE);
  FSConnectivity *updateConnec(FSConnectivity *subToE);
  void makeSubToNode(FSConnectivity *&subToNode);
  virtual void makeContactConnect(FSConnectivity *nodeToSub);
  void makeDualPairs();

public:
  FSCoreCPUPreprocessor();
  virtual ~FSCoreCPUPreprocessor();
  void markUnsymElems();
  virtual void makeBodiesAndRbms(int nbc, BCond *bcs) = 0;
  virtual void makeBodyRbms() = 0;
  void renumToLocal();
  void makeDSAs();
  void makeDofComm(C_Gelem *Gmat, C_Gcpce *Gcpce, C_Gcpce *Glmpc, C_Gcpce *Gmpc184, C_Gcpce *GmpcUP);
  void setParamElems();
  void setNonLinearities();
  void updatePenaltyElements();
  int getNbGlobDomains()	{return _glNumSub;	}
  int getNbLocDomains()		{return _localNumSub;	}
  string getJobname()		{return _jobname;	}
  
  multimap<int,int> &getPairs() {return _pairsDual;}
  C_ContactPairMgr *getcPairs() {return _cPairs;}
  C_SubContactLagMgr &getSubContactLagMgr() {return _subContactLagMgr;}
  int getBoundSize(int subI, int subJ);
  
  void Print();
  void PrintSubDomains();
  void PutStats();
  
  virtual void makeSubProcessors() = 0;
  void setBCs(int nbc, BCond *bc);
  
  // corner selection routine
  void selectCorners(FSCommPattern<int> &, C_Gcpce *, C_Gcpce *, C_Gcpce *, C_Gcpce *);
  void buildSubP(int iSub);
  void buildSubLMPC(int iSub);
  void makeSubCores(DofSet gds);
  void makeSubCoresMatrices(int, int);
  void makeSubCoresSolvers();
  void initMatrices(int iSub);
  void initMatrices();
  virtual void addStiffnesses(int indElem, double *zs, double *mass, int *ls, int nr, bool unsym);
  void setPlast(int indElem, double deppl);
  
  void setNodeRot(int nr, int *nd, double (*rv)[3])
  { _nRotNodes = nr; _rotNodes = nd; _nodeRot = rv; }
  
  FSDistInfo boundDistInfo();
  FSDistInfo internalDistInfo();
  FSCoreSolver *getSolver(C_TimeManager &tm, DofSet &probDofs);
  
  FSAssembledSolver *makeKccStar();
  void setNodes(FSCoordSet *nodes) { _allNodes = nodes;}
  int localRep(int);
  void setDim(int d) { _dim = d; }
  double getOrder();
  
  // add CEs to coarse problem
  void setCECoarse(int n, int *l, int **nd,
                   int **dofs, double **coefs, double *rhs);
  void setCPCoarse(int n, int *l, int **nd, int *dofs);
  
  friend class FSCoreSolver;
};

class FSSlaveDomainPreprocessor : public FSCoreCPUPreprocessor
{
public:
  FSSlaveDomainPreprocessor(int glNumNodes, int glNumEle, string jobname,
			    int nele, int nnode, FSElement **elem,
			    FSInfo *fsInformation);
  
  ~FSSlaveDomainPreprocessor();
  
  void receiveAll();
  void makeBasicConnect();
  void makeSubProcessors();
  void makeBodiesAndRbms(int nbc, BCond *bcs);
  void makeBodyRbms();
  void makeCommList(FSConnectivity *subToNode, FSConnectivity *nodeToSub,
		    FSConnectivity *subToNodeT, FSConnectivity *subToNodeC); 
};

class FSMasterDomainPreprocessor : public FSCoreCPUPreprocessor
{ 
public:
  FSMasterDomainPreprocessor(int glNumNodes, int glNumEle, string jobname, 
			     int nele, int nnode, FSElement **elem,
			     FSInfo *fsInformation,
			     FSConnectivity *subToE,
			     FSConnectivity *cpuToSub);
  
  ~FSMasterDomainPreprocessor();
  
  FSConnectivity *makeSubComList(int glSubNum, FSConnectivity *subToNode, FSConnectivity *nodeToSub,
				 int &numNeighb, int *&neighbSubs);
  void sendAll();
  void makeBasicConnect();
  void makeSubProcessors();
  void makeBodiesAndRbms(int nbc, BCond *bcs);
  void makeBodyRbms();
  void makeCommList(FSConnectivity *subToNode, FSConnectivity *nodeToSub, 
		    FSConnectivity *subToNodeT, FSConnectivity *subToNodeC,
		    FSConnectivity *subTogNode, FSConnectivity *gnodeToSub);
};


#endif
