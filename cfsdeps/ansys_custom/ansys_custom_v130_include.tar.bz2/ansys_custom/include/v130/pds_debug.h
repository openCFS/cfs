/* ---------------------------------------------------------------------- */
/* *** copyright(c) 2010 SAS IP, Inc.  All rights reserved.                                         */
/* *** ansys, inc.                                                        */
/* ---------------------------------------------------------------------- */


/*
* Author/date: Mu-Tsang Chen 2/25/98
* Primary function:
*    Header file for Probabilistic Design System
*/

#ifndef _PDS_DEBUG_
#define _PDS_DEBUG_

#include "pds_constants.h"


#ifdef PDS_DEBUG
#define		DEBUG_LOG_FILE			file_debug = fopen("pds_debug.log","w");		
#define		DEBUG_FILE				file_debug
#define		DBMSG(msg)				fprintf(DEBUG_FILE,"*** DEBUG **** \n %s (%s:%d)\n",\
									msg,__FILE__,__LINE__);
#define		DBUSERINPUT(func)		debug_user_input(DEBUG_FILE,func);
#define		DBINTPTR(m,ptr,i,j)		debug_int_pointer(DEBUG_FILE,m,ptr,i,j);
#define		DBDBLEPTR(m,ptr,i,j)	debug_dble_pointer(DEBUG_FILE,m,ptr,i,j);


#if(PDS_DEBUG >= 1)
	#define		ENTER(func)			fprintf(DEBUG_FILE,"*** DEBUG **** \nENTER %s (%s:%d)\n",\
									func,__FILE__,__LINE__);
	#define		EXIT(func)			fprintf(DEBUG_FILE,"EXIT %s (%s:%d)\n",\
									func,__FILE__,__LINE__);
	#define		DBGLOBAL(func)		debug_global(DEBUG_FILE,func);
	#if(PDS_DEBUG >= 2)
		#define	DBLOCALINT(name,i)		fprintf(DEBUG_FILE,"    LOCAL INTERGER %s = %d (%s:%d)\n",\
											name,i,__FILE__,__LINE__);
		#define	DBLOCALDBLE(name,i)		fprintf(DEBUG_FILE,"    LOCAL DOBULE %s = %15.6e (%s:%d)\n",\
											name,i,__FILE__,__LINE__);
		#define	DBLOCALCHAR(name,i)		fprintf(DEBUG_FILE,"    LOCAL CHARACTER %s = %s (%s:%d)\n",\
											name,i,__FILE__,__LINE__);
		#define	DBLOCALINTPTR(m,ptr,i,j)	debug_int_pointer(DEBUG_FILE,m,ptr,i,j);
		#define	DBLOCALDBLEPTR(m,ptr,i,j)	debug_dble_pointer(DEBUG_FILE,m,ptr,i,j);
	#else
		#define	DBLOCALINT(name,i)
		#define	DBLOCALDBLE(name,i)	
		#define	DBLOCALCHAR(name,i)
		#define	DBLOCALINTPTR(m,ptr,i,j)
		#define	DBLOCALDBLEPTR(m,ptr,i,j)
	#endif
#else
	#define		ENTER(func)
	#define		EXIT(func)
	#define		DBGLOBAL(func)
	#define		DBLOCALINT(name,i)
	#define		DBLOCALDBLE(name,i)	
	#define		DBLOCALCHAR(name,i)
	#define		DBLOCALINTPTR(m,ptr,i,j)
	#define		DBLOCALDBLEPTR(m,ptr,i,j)
#endif	/* (PDS_DEBUG >= 1)*/


#else
#define		DEBUG_LOG_FILE
#define		DEBUG_FILE
#define		DBMSG(msg)
#define		DBUSERINPUT(func)
#define		DBINTPTR(m,ptr,i,j)
#define		DBDBLEPTR(m,ptr,i,j)
#define		ENTER(func)
#define		EXIT(func)
#define		DBGLOBAL(func)
#define		DBLOCALINT(name,i)
#define		DBLOCALDBLE(name,i)	
#define		DBLOCALCHAR(name,i)
#define		DBLOCALINTPTR(m,ptr,i,j)
#define		DBLOCALDBLEPTR(m,ptr,i,j)

#endif /* PDS_DEBUG */

#endif /* _PDS_DEBUG_ */


