/* CADOE */
/**
 *   
 **/

#ifndef __CHGLOB_X_DEJA_INCLUS__
#define __CHGLOB_X_DEJA_INCLUS__ 1

#include "sx_cons_solver.h"
#include "sx_CADOE_solver.h"

#ifndef __cplusplus
#error "This file must be included by C++ source files"
#endif

/**
 * |Fonction: CHG_ext_tens_layer
 *
 * |Statut: public
 *
 * |Appel: ier = CHG_ext_tens_layer( champ_global, noeud, prem_val_noe, ipeau, modele, ier )
 *
 * |Arguments:
 *  champ_global	T_champ_global*	E	champ_global dans lequel on recherche les valeurs pour ipeau
 *  noeud		T_noeud*	E	noeud support
 *  prem_val_noe	double*		E	pointeur sur la premiere valeur pour noeud
 *  ipeau		int		E	indice de peau (de 0-bottom a n-top)
 *  ier			T_statut*	E/S	statut d'execution
 *
 * |Retour:
 *  ptrval		double*		pointeur sur la premiere valeur de la peau ipeau
 *
 * |Description:
 *  Retourne un pointeur sur la premiere valeur de la peau ipeau dans un champ global, de maniere independante
 *  du contexte solveur. Gere de maniere transparente l'ordre des peaux en fonction du contexte solveur.
 *
 **/
  
inline double *
CHG_ext_tens_layer( T_champ_global *champ_global, T_noeud *noeud, double *prem_val_noe, int ipeau, T_statut *ier)
{
  // *ier=SUCCES;

  if (ipeau == -100 || ipeau == -1) {*ier = ECHEC; return NULL;}

  return &(prem_val_noe[ipeau*6]);
}


  extern T_statut CHG_creer_champ_global (int , T_champ_global **);
  extern T_statut CHG_detruire(T_champ_global *);
  extern T_statut CHG_allouer( T_groupe *, E_resultat_parametre, T_champ_global** );
  extern T_statut CHG_moyenner( T_groupe *, T_champ_local*, T_champ_global** );
  extern T_statut CHG_moyenner_vecteur( T_groupe *, T_champ_local*, T_champ_global** );
  extern T_statut CHG_pert_part_2_glob(T_modele *, T_champ_global *);
  extern T_statut CHG_part_2_glob(T_modele *, T_champ_global *);
  extern T_statut CHG_disp_2_disp_comp( T_groupe *, E_resultat_parametre, T_champ_global *, IVEC *, T_champ_global **);
  extern T_statut CHG_stress_2_stress_comp( T_groupe *, E_resultat_parametre, T_champ_global *, IVEC *, int, T_champ_global ** );
  extern T_statut CHG_tg_2_tg_comp( T_groupe *, E_resultat_parametre, T_champ_global *, IVEC *, int, T_champ_global ** );
  extern T_champ_node* CHG_rechercher_champ_node( T_champ_global *, T_noeud *, T_groupe *grp);
  extern T_statut CHG_copier_champ_node( T_champ_node *src, T_champ_node *copie );
  extern T_champ_global* CHG_reduire_au_groupe( T_groupe *grp, T_champ_global *src, T_statut *ier );

#endif   /* __CHGLOB_X_DEJA_INCLUS__ */
