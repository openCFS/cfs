/* ---------------------------------------------------------------------- */
/* *** copyright(c) 2010 SAS IP, Inc.  All rights reserved.                                         */
/* *** ansys, inc.                                                        */
/* ---------------------------------------------------------------------- */

/*
 *    author/date: Stefan Reh 03-10-2000
 *
 *    primary function:
 *
 *        Definiton of macros that are used for response surfaces
 *
 *    Notice - This file contains ANSYS Confidential information ***
 *
 */

#ifndef _RS_MACROS_
#define _RS_MACROS_

#include "rs_c_types.h"

/* Response Surface Sets data */
#define RSSetLabel(i)            ResponseSurfaces[i].Label
#define RSSetSoluIdx(i)          ResponseSurfaces[i].SoluIdx

#define RSSetNumRSOut(i)         ResponseSurfaces[i].NumRSOut
#define RSSetIdx2Rp(i)           ResponseSurfaces[i].Idx2Rp
#define RSSetRegMod(i)           ResponseSurfaces[i].RegMod
#define RSSetYTrans(i)           ResponseSurfaces[i].YTrans
#define RSSetYTrVal(i)           ResponseSurfaces[i].YTrVal
#define RSSetXFilt(i)            ResponseSurfaces[i].XFilt
#define RSSetXFiltConf(i)        ResponseSurfaces[i].XFiltConf
#define RSSetXTrans(i)           ResponseSurfaces[i].XTrans

#define RSSetScaleSlopes(i)      ResponseSurfaces[i].dScaleSlopes
#define RSSetScaleIntercepts(i)  ResponseSurfaces[i].dScaleIntercepts
#define RSSetYPower(i)           ResponseSurfaces[i].YPower
#define RSSetNumTerms(i)         ResponseSurfaces[i].NumTerms
#define RSSetIdx2Terms(i)        ResponseSurfaces[i].Idx2Terms
#define RSSetCoefs(i)            ResponseSurfaces[i].Coefs
#define RSSetXPowers(i)          ResponseSurfaces[i].XPowers

#define RSSetCoefCovarMtx(i)      ResponseSurfaces[i].dCoefCovarMtx
#define RSSetCoefCovarNumDims(i)  ResponseSurfaces[i].iCoefCovarNumDims


/* macros for accessing the variables associated with the goodness of fit measures */
/* ------------------------------------------------------------------------------- */

/* model parameter based goodness of fits i = PDS soln index, j = num RS, k = parameter no.*/

#define RSSetRegCoefGOF(i)         ResponseSurfaces[i].RegCoefGOFs  
#define RSSetVIF(i,j,k)            ResponseSurfaces[i].RegCoefGOFs[j][k].dVIF
#define RSSetCoefStdev(i,j,k)      ResponseSurfaces[i].RegCoefGOFs[j][k].dCoefStdev
#define RSSetCoefProbZero(i,j,k)   ResponseSurfaces[i].RegCoefGOFs[j][k].dCoefProbZero

/* sample based goodness of fits,  i = PDS soln index, j = num RS, k = sample no.*/

#define RSSetSampleGOF(i)          ResponseSurfaces[i].SampleGOFs
#define RSSetHatMtxDiag(i,j,k)     ResponseSurfaces[i].SampleGOFs[j][k].dHatMtxDiag
#define RSSetStudRes(i,j,k)        ResponseSurfaces[i].SampleGOFs[j][k].dStudRes
#define RSSetStudDelRes(i,j,k)     ResponseSurfaces[i].SampleGOFs[j][k].dStudDelRes
#define RSSetCooksDist(i,j,k)      ResponseSurfaces[i].SampleGOFs[j][k].dCooksDist
#define RSSetStudResError(i,j,k)   ResponseSurfaces[i].SampleGOFs[j][k].iStudResError

/* scalar goodness of fits, i = PDS soln index, j = num RS */

#define RSSetScalarGOF(i)              ResponseSurfaces[i].ScalarGOFs
#define RSSetSSE(i,j)                  ResponseSurfaces[i].ScalarGOFs[j][0].dSSE
#define RSSetSSEadj(i,j)               ResponseSurfaces[i].ScalarGOFs[j][0].dSSEAdj
#define RSSetErrorVariance(i,j)        ResponseSurfaces[i].ScalarGOFs[j][0].dErrorVariance 
#define RSSetR2(i,j)                   ResponseSurfaces[i].ScalarGOFs[j][0].dR2
#define RSSetR2adj(i,j)                ResponseSurfaces[i].ScalarGOFs[j][0].dR2Adj
#define RSSetConstVarStat(i,j)         ResponseSurfaces[i].ScalarGOFs[j][0].dConstVarStat
#define RSSetConstVarProb(i,j)         ResponseSurfaces[i].ScalarGOFs[j][0].dConstVarProb
#define RSSetConstVarMaxIdx(i,j)       ResponseSurfaces[i].ScalarGOFs[j][0].iConstVarMaxIdx
#define RSSetMaxStudRes(i,j)           ResponseSurfaces[i].ScalarGOFs[j][0].dMaxStudRes
#define RSSetMaxStudDelRes(i,j)        ResponseSurfaces[i].ScalarGOFs[j][0].dMaxStudDelRes
#define RSSetMaxStudDelResProb(i,j)    ResponseSurfaces[i].ScalarGOFs[j][0].dMaxStudDelResProb
#define RSSetMaxResAbs(i,j)            ResponseSurfaces[i].ScalarGOFs[j][0].dMaxResAbs
#define RSSetMaxResRel(i,j)            ResponseSurfaces[i].ScalarGOFs[j][0].dMaxResRel
#define RSSetMaxCooksDist(i,j)         ResponseSurfaces[i].ScalarGOFs[j][0].dMaxCooksDist
#define RSSetMaxCooksProb(i,j)         ResponseSurfaces[i].ScalarGOFs[j][0].dMaxCooksProb
#define RSSetAndDarlStat(i,j)          ResponseSurfaces[i].ScalarGOFs[j][0].dAndDarlStat
#define RSSetAndDarlStatNormCorr(i,j)  ResponseSurfaces[i].ScalarGOFs[j][0].dAndDarlStatNormCorr
#define RSSetAndDarlProb(i,j)          ResponseSurfaces[i].ScalarGOFs[j][0].dAndDarlProb
#define RSSetMaxCoefProb(i,j)          ResponseSurfaces[i].ScalarGOFs[j][0].dMaxCoefProb

#define RSSetMaxLeverage(i,j)          ResponseSurfaces[i].ScalarGOFs[j][0].dMaxHatMtxFullModel
#define RSSetMaxLeverageLocation(i,j)  ResponseSurfaces[i].ScalarGOFs[j][0].iMaxHatMtxLocation
#define RSSetMaxVIFFullModel(i,j)      ResponseSurfaces[i].ScalarGOFs[j][0].dMaxVIFFullModel
#define RSSetMaxVIFLocation(i,j)       ResponseSurfaces[i].ScalarGOFs[j][0].iMaxVIFLocation 


#endif /* _RS_MACROS_ */
