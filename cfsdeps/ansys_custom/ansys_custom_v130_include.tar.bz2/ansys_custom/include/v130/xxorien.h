

/*
 *    author/date: yu-hua ting/10-29-93
 *
 *    primary function:
 *
 *      Header for the Interface to SHAPES "orientations" routines
 *
 *    secondary function:
 *
 *        none
 *
 *    routines included:
 *
 *
 *    history
 *
 *        none
 *
 *    comments:
 *
 *        1). direct interface with Shapes/xox 2.0 will be added later
 *
 *    Notice - This file contains ANSYS Confidential information ***
 *
 */

/* 
 * *** copyright(c) 2010 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */


/*
 *    get the subgeom orientations for a geom
 */
      extern xINT_LIST xSubGeomOrientations_xox ansPROTO((
      xGEOM_ID gm_id,      /* I    geom number of a geom                      */ 
      INT *iretp));        /*   O  error code   
                            *      == 0 - no error
                            *      != 0 - error                               */




/*
 *    Invert the orientation of a geom
 */

      extern xGEOM_ID xInvertGeomOrientation_xox ansPROTO((
      xGEOM_ID gm_id,
      INT *iretp));        /*   O  pointer to the error code
                            *      == 0 - no error
                            *      != 0 - error                              */

