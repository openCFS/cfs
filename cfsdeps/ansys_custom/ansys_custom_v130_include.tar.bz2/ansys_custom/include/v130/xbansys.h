/*
 *    author/date: yu-hua ting/02-22-94
 *
 *    primary function:
 *
 *       Header for routines which call ANSYS fortran routines
 *
 *    secondary function:
 *
 *        none
 *
 *    routines included:
 *
 *
 *    history
 *
 *        none
 *
 *    comments:
 *
 *        none
 *
 *    Notice - This file contains ANSYS Confidential information ***
 *
 */
/* 
 * *** copyright(c) 2010 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */



/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 +                                                                    +
 +        routines which call ANSYS fortran routines                  +
 +                                                                    +
 +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/



/*   
 *    get the number of subvolumes in the subvolume list of an
 *    ANSYS volume
 */
      extern VOID vusvq ansPROTO((
	     INT *vunp,
	     INT *nsvp,
	     INT *iretp));

/*   
 *    get the subvolume list of an ANSYS volume
 */
      extern VOID vusvg ansPROTO((
	     INT *vunp,
	     INT svn[],
	     INT *iretp));

/*   
 *    get the number of shells in the shell tree of an ANSYS subvolume 
 *    (or volume)
 */
      extern VOID svshq ansPROTO((
	     INT *svnp,
	     INT *nshp,
	     INT *ientyp,
	     INT *iretp));

/*   
 *    get the shell tree of an ANSYS subvolume (or volume)
 */
      extern VOID svshg ansPROTO((
	     INT *svnp,
	     INT shn[],
	     INT *ientyp,
	     INT *iretp));

/*   
 *    get the number of subareas (area) in the subarea (area) list 
 *    of an ANSYS shell
 */
      extern VOID shsaq ansPROTO((
	     INT *svnp,
	     INT *shnp,
	     INT *nsap,
	     INT *ientyp,
	     INT *iretp));

/*   
 *    get the subarea (area) list of an ANSYS shell
 */
      extern VOID shsag ansPROTO((
	     INT *svnp,
	     INT *shnp,
	     INT san[],
	     INT *ientyp,
	     INT *iretp));

/*   
 *    get the number of subareas in the subarea list of an
 *    ANSYS area
 */
      extern VOID arsaq ansPROTO((
	     INT *arnp,
	     INT *nsap,
	     INT *iretp));

/*   
 *    get the subarea list of an ANSYS area
 */
      extern VOID arsag ansPROTO((
	     INT *arnp,
	     INT san[],
	     INT *iretp));

/*   
 *    get the number of loops in the loop tree of an ANSYS subarea (or area)
 */
      extern VOID salpq ansPROTO((
             INT *sanp,
	     INT *nlpp,
	     INT *ientyp,
	     INT *iretp));

/*   
 *    get the loop tree of an ANSYS subarea
 */
      extern VOID salpg ansPROTO((
	     INT *sanp,
	     INT lpn[],
	     INT *ientyp,
	     INT *iretp));

/*   
 *    get the number of sublines (lines) in the subline (line) list 
 *    of an ANSYS loop
 */
      extern VOID lpslq ansPROTO((
	     INT *sanp,
	     INT *lpnp,
	     INT *nslp,
	     INT *ientyp,
	     INT *iretp));

/*   
 *    get the subline (line) list of an ANSYS loop
 */
      extern VOID lpslg ansPROTO((
	     INT *sanp,
	     INT *lpnp,
	     INT sln[],
	     INT *ientyp,
	     INT *iretp));

/*   
 *    get the number of sublines in the subline list of an ANSYS line
 */
      extern VOID lsslq ansPROTO((
	     INT *lsnp,
	     INT *nslp,
	     INT *iretp));

/*   
 *    get the subline list of an ANSYS line
 */
      extern VOID lsslg ansPROTO((
	     INT *lsnp,
	     INT sln[],
	     INT *iretp));

/*
 *    get the end points of an ANSYS subline
 */
      extern VOID slptg ansPROTO((
	     INT *slnp,
	     INT ptn[],
	     INT *iretp));

/*
 *    get the nsur of the 3-D nurbs surface of an ANSYS subarea
 */
      extern VOID sasuq ansPROTO((
	     INT *sanp,
	     INT nsur[],
	     INT *surn,
	     INT *iretp));

/*
 *    get the sur of the 3-D nurbs surface of an ANSYS subarea
 */
      extern VOID sasug ansPROTO((
	     INT *sanp,
	     DOUBLE sur[],
	     INT *surn,
	     INT *iretp));

/*
 *    get the ncur of the 3-D nurbs curve of an ANSYS subline
 */
      extern VOID slcuq ansPROTO((
	     INT *slnp,
	     INT ncur[],
	     INT *curn,
	     INT *iretp));

/*
 *    get the cur of the 3-D nurbs curve of an ANSYS subline
 */
      extern VOID slcug ansPROTO((
	     INT *slnp,
	     DOUBLE cur[],
	     INT *curn,
	     INT *iretp));

/* 
 *    attach volumes to subvolumes
 */

      extern VOID vusva ansPROTO((
	     INT svn[],
	     INT *nsvp,
	     INT vun[],
	     INT *iretp));

/*
 *    attach areas to subareas
 */

      extern VOID arsaa ansPROTO((
	     INT san[],
	     INT *nsap,
	     INT arn[],
	     INT *iretp));

/*
 *    attach lines to sublines
 */
      extern VOID lssla ansPROTO((
	     INT sln[],
	     INT *nslp,
	     INT lsn[],
	     INT *iretp));


/*
 *    get the attached ANSYS points of an ANSYS keypoints
 */
      extern VOID kpptq ansPROTO((
	     INT kpn[],
	     INT *np,
	     INT ptn[],
	     INT *iretp));

/*
 *    get the 3-D point coordinates of an ANSYS point
 */
      extern VOID ptcog ansPROTO((
	     INT *ptnp,
	     DOUBLE cor[],
	     INT *iretp));

/*
 *    get the next ANSYS volume number
 */
      extern VOID vunxt ansPROTO((
	     INT *vunp));

/*
 *    get the next ANSYS subvolume number
 */
      extern VOID svnxt ansPROTO((
	     INT *svnp));

/*
 *    get the next shell number of an ANSYS subvolume (or volume)
 */
      extern VOID shnxt ansPROTO((
	     INT *svnp,
	     INT *shnp,
	     INT *ientyp));


/*
 *    get the next ANSYS area number
 */
      extern VOID arnxt ansPROTO((
	     INT *arnp));

/*
 *    get the next ANSYS subarea number
 */
      extern VOID sanxt ansPROTO((
	     INT *sanp));

/*
 *    get the next loop number of an ANSYS subarea (or area)
 */
      extern VOID lpnxt ansPROTO((
	     INT *sanp,
	     INT *lpnp,
	     INT *ientyp));

/*
 *    get the next ANSYS line number
 */
      extern VOID lsnxt ansPROTO((
	     INT *lsnp));

/*
 *    get the next ANSYS subline number
 */
      extern VOID slnxt ansPROTO((
	     INT *slnp));

/*
 *    get the next ANSYS point number
 */
      extern VOID ptnxt ansPROTO((
	     INT *ptnp));

/*
 *    sew ANSYS subvolumes to a volume 
 */
      extern VOID sewvu ansPROTO((
	     INT svn[],
	     INT *nsvp,
	     INT shn[],
	     INT *nshp,
	     INT *vunp,
	     INT *iretp));

/*
 *    sew ANSYS subareas (areas)  to a shell of a subvolume (or volume)
 */
      extern VOID sewsh ansPROTO((
	     INT *svnp,
	     INT san[],
	     INT orient[],
	     INT *np,
	     INT *shnp,
	     INT *ientyp,
	     INT *iretp));

/*
 *    sew ANSYS subareas to an area 
 */
      extern VOID sewar ansPROTO((
	     INT san[],
	     INT *nsap,
	     INT lpn[],
	     INT *nlpp,
	     INT *arnp,
	     INT *iretp));

/*
 *    sew ANSYS sublines (lines) to a loop of a subarea (or area)
 */
      extern VOID sewlp ansPROTO((
	     INT *sanp,
	     INT sln[],
	     INT orient[],
	     INT *np,
	     INT *lpnp,
	     INT *ientyp,
	     INT *iretp));

/*
 *    sew ANSYS sublines to an line 
 */
      extern VOID sewls ansPROTO((
	     INT sln[],
	     INT *np,
	     INT *lsnp,
	     INT *iretp));

/*
 *    trim the 3-D space by a shell tree and create a subvolume
 */
      extern VOID trmsv ansPROTO((
	     INT shn[],
	     INT orient[],
	     INT *np,
	     INT *svnp,
	     INT *iretp));

/*
 *    trim the nurbs surface by a loop tree and create a subarea
 */
      extern VOID trmsa ansPROTO((
	     DOUBLE sur[],
	     INT nsur[],
	     INT lpn[],
	     INT orient[],
	     INT *np,
	     INT *sanp,
	     INT *iretp));

/*
 *    trim the nurbs curve by end points and create a subline
 */
      extern VOID trmsl ansPROTO((
	     DOUBLE cur[],
	     INT ncur[],
	     INT ptn[],
	     INT *slnp,
	     INT *iretp));

/*
 *    create an ANSYS point 
 */
      extern VOID ptcr ansPROTO((
	     DOUBLE cor[],
	     INT *ptnp,
             INT *iretp));

/*
 *    attach keypoints to points
 */
      extern VOID ptkp ansPROTO((
	     INT ptn[],
	     INT *np,
	     INT kpn[],
	     INT *iretp));



