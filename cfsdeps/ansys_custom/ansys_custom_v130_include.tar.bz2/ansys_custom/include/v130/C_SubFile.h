/**
 * @file   C_SubFile.h
 * @author 
 * @date   Thu Apr 10 16:44:40 2008
 * 
 * @brief  
 * 
 */

#ifndef __C_SUBFILE_H__
#define __C_SUBFILE_H__	1

#include "C_AnsysFile.h"
#include "C_MatMGe.h"

/*!
 *  \class	C_SubFile
 *  \brief	
 *  \author	Frederic Thevenon
 *  \version	1.0
 *  \date	2008
 *  \bug	
 *  \warning	
 *
 *  version 1.0 :       Initial Revision
 */

// ======================================================================
// ===== BLOCKS OF THE SUB FILE

//	SUB_HEADER
//	SUB_XFM
//	SUB_CTXM
//	SUB_DOF
//	SUB_DST
//	SUB_POS
//	SUB_ORG
//	SUB_BAC
//	SUB_TIT
//	SUB_NOD
//	SUB_XYZ
//	SUB_EDG
//	SUB_GDF
//	SUB_CG
//	SUB_LOD

class C_SubFile : public C_AnsysFile
{
public:
  CADOE_EXPORT virtual const char *StrType() { return "C_SubFile";}

  CADOE_EXPORT C_SubFile( const _TCHAR *FileName, bool Create = false);
  CADOE_EXPORT ~C_SubFile(void) {};

  CADOE_EXPORT int	SubHeader(int ival) { return _SubHead[ival];}
  CADOE_EXPORT bool	SparseMatrix( void) { return _SparseMatrices;}
  
  CADOE_EXPORT bool MatrixIsOnFile( int numMat);

  template <typename T> CADOE_EXPORT C_Mat<T>	*getMat( int numMat, C_Mat<T> *Mat = NULL, char Format = 'D');
  template <typename T> CADOE_EXPORT void	setMat( int numMat, C_Mat<T> *Mat);

  template <typename T> CADOE_EXPORT C_Vec<T>	*getVec( int IDVec, C_Vec<T> *Vec = NULL, int iVec=1);

  CADOE_EXPORT void	setMat( int numMat, C_Mat<double> &Mat);

  CADOE_EXPORT virtual void	WriteFile( _TCHAR *FileName);
  CADOE_EXPORT void		dumpFile( int kuns);
    
protected:
  C_VecPi<int>	_SubHead;
  bool		_SparseMatrices;
  int		_nmatrx, _nvect, _nmrow;

  map< int, C_Mat<double> *>	_lMat;
  C_Mat<int>			*_RowInfo;
};

template <> C_Mat<int> *C_SubFile::getMat<int>( int numMat, C_Mat<int> *Min, char Format);
template <> void	C_SubFile::setMat<int>( int numMat, C_Mat<int> *Min);

#endif
