
/*
////////////////////////////////////////////////////////////////////////////
//                                                                        //
//        copyright(c) 2010 SAS IP, Inc.  All rights reserved.             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MAT_TBCDWrite.h $
// $Revision: 1.9 $ 7.0
// $Date: 2010/04/16 15:39:23 $ Feb 9 2005
// $Author: srpailla $ rjayasee
//
// Decription :
//
//	C Entry point from Ansys to the Curve Fitting Code. This has all the
//  Command Parsing code
//////////////////////////////////////////////////////////////////////////////
*/

/*  tbfit.h */
#if !defined(MAT_TBCDWrite__1)
#define MAT_TBCDWrite__1
#define MAT_TBCDWrite_Get__1


/* (1)----------------------------------------------------------------*/
#if defined(LOWERCASENOUNDER_SYS)

/*
 *   The pattern for these platforms is the lowercased version of the name
 */

#define MAT_TBCDWrite          mat_tbcdwrite
#define MAT_TBCompCDW          mat_tbcompcdw
#endif


/* (2)----------------------------------------------------------------*/
#if defined(UPPERCASENOUNDER_SYS)

/*
 *   The pattern for these platforms is the uppercased version of the name
 */

#define MAT_TBCDWrite          MAT_TBCDWRITE
#define MAT_TBCompCDW          MAT_TBCOMPCDW

#endif


/* (3)----------------------------------------------------------------*/
#if defined(LOWERCASEUNDER_SYS)

/*
 *   The pattern for these platforms is the lowercased version of the name 
 *   followed by an underscore
 */

#define MAT_TBCDWrite          mat_tbcdwrite_
#define MAT_TBCompCDW          mat_tbcompcdw_


#endif


/* (4)----------------------------------------------------------------*/

/*
 *   This section is for definition of prototypes.  Each prototype 
 *   should be ANSI compliant and specify the types of each parameter 
 *   as well as the return type.
 */
#ifdef __cplusplus
extern "C"
{
#endif

INT FUNCTION MAT_TBCDWrite(INT* pUnit, INT* pMatId, DOUBLE* pTBData, FCHAR(str) FCHARL(str_len)) ;
INT FUNCTION MAT_TBCompCDW(INT* pUnit, INT* pMatId, DOUBLE* pTBData, FCHAR(str) FCHARL(str_len)) ;

#ifdef __cplusplus
}

#endif

#endif
