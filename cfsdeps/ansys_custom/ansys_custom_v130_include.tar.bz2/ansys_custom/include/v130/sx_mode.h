/* CADOE */
/*
 *  mode.h
 *
 * |Version: $Id: sx_mode.h,v 1.3 2009/11/13 16:13:04 jtm Exp $
 *
 *   
 * HISTORY
 *   
 *   09/25/00 10:39 <       Brian Jantzen> Rel:ms8m1    SCCA:79107  Delta:81.2
 *   
 *   02/15/00 13:10 <       Brian Jantzen> Rel:ms8      SCCA:68558  Delta:8.3
 *   
 *   09/30/99 17:38 <         James Silva> Rel:ms8      SCCA:56512  Delta:8.2
 */

#include "sx_CADOE_solver.h"
#ifndef __MODE_X__
#define __MODE_X__ 1

#ifdef __cplusplus
extern "C" {
#endif

extern T_mode *MDE_allouer( T_statut* );
extern void MDE_detruire( T_mode* );
extern T_statut MDE_boutput( FILE*, T_mode* );
extern T_mode *MDE_binput( FILE*, T_modele*, T_statut* );
extern MAT *MDE_calculer_MAC( T_liste*, T_liste*, MAT*, T_statut* );
extern T_statut MDE_identifier( T_liste*, T_liste* );
extern T_statut MDE_identifier_adoc( int, T_mode*, T_liste* );
extern T_statut MDE_unit_displacement( T_mode*, T_mode* );

#ifdef __cplusplus
}
#endif

#endif /* __MODE_X__ */
