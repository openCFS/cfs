/*  Mstat.h */
/*
 * *** ansys(r) copyright(c) 2009
 * *** ansys, inc.
 */

/* *** Notice - This file contains ANSYS Confidential information  *** */

/*
 *  Mstat.h
 *  header file for Mstat.F  
 *
 *  This file corresponds identically to Mstat.inc.  It should be included
 *  in c source files when the mesh status/abort functions are used
 *  NOTE: ANY CHANGES TO THIS FILE MUST ALSO BE MADE TO MSTAT.INC
 *
 */
#ifndef MSTAT_INCLUDE
#define MSTAT_INCLUDE

/* === Number of commands currently using the Meshing abort/status facility */

#define NUM_COMMANDS 15

/* === Command to be used with mstatsetup */

#define CMND_AMESH        1 
#define CMND_TETSHLO      2 
#define CMND_TETPLG       3 
#define CMND_MAPVMESH     4 
#define CMND_REFINE       5
#define CMND_SMRTSIZE     6
#define CMND_TIMP         7
#define CMND_HEXTOTET     8
#define CMND_FVMESH       9
#define CMND_VIMP         10
#define CMND_VSWEEP       11
#define CMND_VSWEEP2      12
#define CMND_MORPH        13
#define CMND_VMORPH       14
#define CMND_QMORPH       15
#define CMND_ANSYS_AMESH  16

/* === Sub-processes used with mstatupdate */

#define PROC_SMRT_SMLANG 138
#define PROC_SMRT_ITER   101
#define PROC_AMESH       102
#define PROC_PROX        132
#define PROC_FACCHK      103
#define PROC_TETMSH      104
#define PROC_TIMP        105
#define PROC_BTCFIN      106
#define PROC_BRICK       107
#define PROC_SMRT_EVEN   119
#define PROC_BRICK_POST  120
#define PROC_VERIFY      122
#define PROC_PYRAMID     131
#define PROC_BUILD_C_HEX 133
#define PROC_MORPH       139
#define PROC_MORPH_INIT1 140
#define PROC_MORPH_INIT2 141


/* === Mesh Refinement sub-processes */

#define PROC_TO_NODES_REF   108
#define PROC_GET_GEO_REF    109
#define PROC_BUILD_C_REF    110
#define PROC_MARK_REF       111
#define PROC_MARK_CHECK_REF 112
#define PROC_SPLIT          113
#define PROC_CLEAN          123
#define PROC_SMOOTH         114
#define PROC_UPDATE         115

/* === AMESH sub-processes */

#define PROC_INIT_AMESH    134
#define PROC_TRIAN         116
#define PROC_CLEAN_TRI     135
#define PROC_TRI_SMTH      137
#define PROC_QUADS         117
#define PROC_AMESH_SMTH1   136
#define PROC_IMPROVE1      124
#define PROC_AMESH_SMTH2   125
#define PROC_IMPROVE2      126
#define PROC_QTCFIN        118

/* === TIMP sub-processes */

#define PROC_ELEMCHK       127
#define PROC_CONVERT_C     128
#define PROC_TIMPITER      129
#define PROC_TIMPSTORE     130

/* === CMND_VSWEEP sub-processes */

#define PROC_BUILD_C_VSWEEP           200
#define PROC_BUILD_C_VSWEEP2          201
#define PROC_VSWEEP_EXAMINE           202
#define PROC_VSWEEP_MESH_KPS          203
#define PROC_VSWEEP_INTERVALS         204
#define PROC_VSWE_MSH_LNS             205
#define PROC_VSWE_MSH_AES             206
#define PROC_VSWE_MSH_VLS             207

/* ===  CMND_QMORPH sub_processes */

#define PROC_QMORPH_AREA  208

/* ===  CMND_ANSYS_AMESH sub_processes */

#define PROC_ANSYS_AMESH  209



#if 0

For the ANSYS Mesh Toolkit the possible values that can be sent to
FEMe_SetUpdStatusWindow in the process_type argument are:

---------------------------------------------------------------------------
process_type   |  a_values[3] values
---------------------------------------------------------------------------
CMND_TETPLG    |  a_values[0] = the id of the volume being meshed.
               |  a_values[1] = the number that this volume is in the list of
               |                volumes to mesh.
               |  a_values[2] = the number of volumes that will be meshed
               |                with this call to FEM_TetMesh().
               |  example:  Meshing Volume 3 (2 of 4):
---------------------------------------------------------------------------
CMND_AMESH     |  a_values[0] = the id of the area being meshed.
               |  a_values[1] = the number that this area is in the list of
               |                areas to mesh.
               |  a_values[2] = the number of areas that will be meshed
               |                with this call to FEM_MeshAreas().
               |  example:  Meshing Area 2 (2 of 17)
---------------------------------------------------------------------------


For CMND_TETPLG the possible values that can be sent to
FEMe_CheckStatusWindow and FEMe_UpdateStatusWindow in the process_subtype
argument are:

---------------------------------------------------------------------------
process_subtype |  a_values[3] values
---------------------------------------------------------------------------
PROC_AMESH      |  a_values[0] = the id of the area currently being meshed
                |                in preparation for tet meshing.
                |  a_values[1] = the number that this area is in the list of
                |                areas to be meshed on this volume.
                |  a_values[2] = the number of areas on the volume.
                |  example:  Meshing Volume 3 (2 of 4): Meshing Area 2 (2 of 17)
                |
                |  Note:  During this subprocess, some calls may be recieved
                |         with process_subtype equal to one of the values
                |         listed below under CMND_AMESH.  This is ok and
                |         they should be ignored.
---------------------------------------------------------------------------
PROC_FACCHK     |  a_values is not used.  boundary facets are being checked
                |  before calling actual tet mesher.
                |  example:  Meshing Volume 3 (2 of 4): Checking facets
---------------------------------------------------------------------------
PROC_TETMSH     |  a_values[0] = approximate number of elements already
                |                placed in the volume.
                |  example:  Meshing Volume 3 (2 of 4): Element Count = 1500
---------------------------------------------------------------------------
PROC_TIMP       |  a_values is not used.  Tet meshing is complete, no we
                |  are attempting to improve the quality of the elements by
                |  swapping, smoothing, etc.
                |  example:  Meshing Volume 3 (2 of 4): Improving element shapes
---------------------------------------------------------------------------


For CMND_AMESH the possible values that can be sent to
FEMe_CheckStatusWindow and FEMe_UpdateStatusWindow in the process_subtype
argument are:

---------------------------------------------------------------------------
process_subtype |  a_values[3] values
---------------------------------------------------------------------------
PROC_INIT_AMESH |  a_values is not used.  We are initializing the area mesher,
                |  meshing the lines, etc, in preparation to area mesh.
                |  example:  Meshing area 3 (2 of 4): Initializing
---------------------------------------------------------------------------
PROC_TRIAN      |  a_values[0] = approximate number of elements already
                |                placed in the area.
                |  example:  Meshing area 3 (2 of 4): Element Count = 450
---------------------------------------------------------------------------
PROC_CLEAN_TRI  |  a_values is not used.  The area is meshed with triangles,
                |  and we are improving the quality of the triangles.
                |  example:  Meshing Volume 3 (2 of 4): Improving element shapes
---------------------------------------------------------------------------
PROC_TRI_SMTH   |  a_values is not used.  The area is meshed with triangles,
                |  and we are smoothing the nodes on the triangles.  
                |  example:  Meshing Volume 3 (2 of 4): Improving element shapes
---------------------------------------------------------------------------
PROC_QUADS      |  a_values is not used. If quad mesh was requested, the
                |  triangles are being combined into quads.
---------------------------------------------------------------------------
PROC_AMESH_SMTH1|  a_values is not used.  If quad meshing was requested,
                |  we now perform smoothing to improve the quality of the quads.
---------------------------------------------------------------------------
PROC_IMPROVE1   |  a_values is not used. If quad meshing was requested, we
                |  now try to improve the quality of the quads with
                |  topological cleanup.
---------------------------------------------------------------------------
PROC_AMESH_SMTH2|  a_values is not used.  If quad meshing was requested,
                |  we now perform a final pass of smoothing to improve the 
                |  quality of the quads.
---------------------------------------------------------------------------
PROC_IMPROVE2   |  a_values is not used.  If quad meshing was requested,
                |  we do one final pass at cleanup to try to improve quality
                |  of quads.
---------------------------------------------------------------------------

#endif


#endif

