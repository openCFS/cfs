/* 
 * *** copyright(c) 2010 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */

/***********************************************/
/***  include file used for DISPLAY routines ***/
/***********************************************/
#if defined(PCWINNT_SYS)
    /*  c routines called from fortran  */
#define display_avi_init_  DISPLAY_AVI_INIT
#define display_avi_start_ DISPLAY_AVI_START
#define display_avi_end_   DISPLAY_AVI_END
#define write_mbox_        WRITE_MBOX
#define nt_dspmsgc_        NT_DSPMSGC
    /*  fortran routines called from c  */
#define disply_     DISPLY
#define dispmn_     DISPMN
#define pgetpsc_    PGETPSC
#define sysend_     SYSEND
#endif
