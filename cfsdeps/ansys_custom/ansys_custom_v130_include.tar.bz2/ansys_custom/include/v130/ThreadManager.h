/*****************************************************************************
 *                   Copyright (C) 1999 CMSoft                               *
 *                                                                           *
 *  These lines of code and declarations contain unpublished proprietary     *
 *  information of CMSoft. They may not be copied or duplicated in whole     *
 *  or part without prior authorization from CMSoft.                         *
 *                                                                           *
 *****************************************************************************/
#ifndef _FS_THREAD_MANAGER_H_
#define _FS_THREAD_MANAGER_H_

#include "CadoeAnsys.h"
#include "cwrap_ansys.h"
#include "locknm.h"

class IntegerException {
public:
	int equation;
	IntegerException(int n) { equation=n;}
};

class AllocException {
 public:
	size_t attempt;
	AllocException(size_t x) { attempt = x; }
};
/********************************************************************
   FSTaskGroup: object representing a group of tasks number from
   0 to ntask-1 (this number is not available explicitely).
   This class is pure virtual. it needs to be subclassed and
   its children must define the function run that executes the ith
   task in the group.
 ********************************************************************/

class FSTaskGroup {
  public:
    virtual void run(int iTask) = 0;
};
/********************************************************************
  FSTaskDistribution is a class which role is to distribute work in
  a group to thread in order to balance the thread work. It is here
  a pure virtual class with two functions:
    - numTasks(i) returns the number of tasks to be performed by 
      thread i.
    - taskNum(i,j) returns the task number for thread i, subtask j
 ********************************************************************/
class FSTaskDistribution {
   public:
     virtual int numTasks(int threadNum) const = 0;
     virtual int taskNum(int threadNum, int subTaskNum) const = 0;
};

/********************************************************************
  FSTrivialTaskDistribution is a convenience class to distribute work
  to threads in a trivial way.
 ********************************************************************/
class FSTrivialTaskDistribution {
     int ntasks;
   public:
     FSTrivialTaskDistribution(const int ntasks);
     int numTasks(int threadNum) const;
     int taskNum(int threadNum, int subTaskNum) const;
};

class FSThreadLock 
{
protected:
  INT _ilock;
  
public:
  FSThreadLock(int ilock) {_ilock = ilock;}
  ~FSThreadLock() {};
  void lock()	{cwPplock(&_ilock);}
  void unlock() {cwPpunlock(&_ilock);};
};

/********************************************************************
   FSThreadManager: class that organizes threads and distributes
   basic work tasks to them.
 ********************************************************************/
class FSThreadManager 
{
protected:
  int _nthrd;		// number of threads
  bool _parallel;	// do we parallelize the loop?       
  
  void activateOmp();
  void desactivateOmp();

  static void subTask(FSTaskGroup *tg, int *);
  
public:
  FSThreadManager(int nthreads);
  ~FSThreadManager();
  void schedule(FSTaskDistribution *, FSTaskGroup &);
  void schedule(int, FSTaskGroup &);
  void execute(FSTaskDistribution *, FSTaskGroup &);
  void execute(int, FSTaskGroup &);
  
  int  numThreads() { return _nthrd; }
  void ppfrk(int *nsub, FSTaskGroup *tg);
  
  void lock(INT ilock);
  void unlock(INT ilock);
  
  void setParallelOn() {_parallel = true;}
  void setParallelOff() {_parallel = false;}
  
  FSThreadLock getLock(INT ilock) { return FSThreadLock(ilock); }
};

extern FSThreadManager *G_fsThreadManager;

double memoryUsed();


#endif

