#if !defined (FORTRAN)                       /* FORTRAN wrapper */
/* C style Comments cannot be include for FORTRAN files. */

/*  Note:  See also syspar.inc for system dependent information  */

/* computer.h                                                        JAS,SYS
------------------------------------------------------------------------
------- Notice - This file contains ANSYS Confidential information --------
------------------------------------------------------------------------
*/
/* ***copyright(c) 2010 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */
/* Notice - changes to this header file DO NOT cause a recompile of
            all routines which reference it (it is called by impcom.inc).
            If a change is made which is other than a comment it should
            be checked in on Friday to hit the weekend full recompile.
            Changes will however force a recompile of the 744 .c routines
            which reference this header file.
*/
/* *** mpg computer.h < impcom.inc: machine specific info math         */
/*------------------------------ Description ---------------------------
\Author:        John A. Swanson (From F. J. Bogden)
\Title:         Computer macro definition header file
\Desc:          This file contains computer(machine) dependent macros
                which should be included in any file which needs to
                distinguish between computing environments.  Many but
                -not- all C preprocessors contain predefined machine
                macros. These are keyed on below as much as possible.
                When none was available, we invented one for that
                machine in which case you will need to add to your
                compile command :  cc -D<computermacro> flag  where
                <computermacro> is defined within this file.  Example,
                cc -DRS6000_SYS  is to be used for the IBM risc rs6000
                system. To be consistent, please use these as
                specified below. If a system is used which is -not-
                contained on this file, then you must add the
                appropriate changes for that system.  All variables
                defined here are usually self explanatory.  Current list :

   Machine Name            Comments         Owner
   --------                --------         -----
   NT_SYS               Any NT system
   PCWINNT_SYS          Any NT system       Lou Muccioli 
   PCWIN64_SYS                              Mike McGovern

   LINUX_SYS            Any LINUX system    Chris Aiken
   LINUXIA32_SYS                            Chris Aiken
   LINUXIA64_SYS                            Chris Aiken
   LINUXEM64T_SYS                           Chris Aiken

   SUN_SYS              Any SUN system      Tom Schroll
   SOLARIS_SYS                              Tom Schroll
   SUN64_SYS                                Tom Schroll
   SOLX64_SYS           Solaris X64         Tom Schroll  

   IBM_SYS              Any IBM system      Tom Schroll
   RS6000_SYS                               Tom Schroll
   RS64K_SYS                                Tom Schroll

   HP_SYS               Any HP system       Joe Huba 
   HP32_SYS             HP 32-bit(obsolete) Joe Huba
   HP64_SYS             HP 64-bit           Joe Huba
   HPIA64_SYS           HP Itanium          Joe Huba

   DECAXPOSF_SYS        Tru64 internal      Tom Schroll  


   These systems were discontinued at 12.0 (Flags left for legacy reasons)
   FUJITSU_SYS          Fujitsu compiler    Tom Schroll  

   LINUXOP64_SYS        AMD compiler        Chris Aiken

   SGI_SYS              Any SGI system      Joe Huba
   SGIR4K_SYS           SGI 32-bit          Joe Huba
   SGI64_SYS            SGI 64-bit          Joe Huba
   SGIR8K_SYS           SGI 64-bit          Joe Huba


\Function(s)
 -Primary:      To supply standard macros for different computer systems
 -Secondary:    To supply additional macros and to foster portability

    OTHER MACROS BEING DEFINED

   Name                    Comments
   ----                    --------
   PTR64                   Defined if pointers are 64 bits
   LITTLE_ENDIAN           Defined for PC, DEC
   LONGINT                 Set to integer*8 if supported, else integer 
   LONGINT2                Defined if LONGINT is integer*8
   PTRFTN                  Set to integer*8 for 64 bit pointers, else integer
   IEEE_SYS                Defined if system uses IEEE data format
   INLINE_VECT             Defined if inline vectors are faster
   NOUNDER_SYS             Systems which do not require _ on c to fortran calls
   UPCASE_SYS              Systems which user upper case for routine names
   ARGTRAIL_SYS            Systems which put all FORTRAN character variable lengths 
                           at the end of the calling signature
   LOWERCASEUNDER_SYS      Systems which use lower case and add an underscore 
                           to FORTRAN link symbols
   LOWERCASENOUNDER_SYS    Systems which use lower case and DO NOT add an 
                           underscore to FORTRAN link symbols
   UPPERCASENOUNDER_SYS    Systems which use upper case and DO NOT add an 
                           underscore to FORTRAN link symbols
   

   INT_DYNA                define integer for dyna interface routines
   REAL_DYNA               define real for dyna interface routines
   ANS_NEWCPPLIBS          Defined if the new version of c++ libraries are
                           used on a particular machine.
   CALLINT64               Defined if INTEGERs at the interface between ANSYS
                           and the Sparse solver codes are INTEGER*8

----------------------------------------------------------------------*/
#endif        /* End of first FORTRAN wrapper C comments */

#if !defined (__COMPUTER_H__)         /* Below spans entire file */
#  define __COMPUTER_H__


#if defined (DECAXPOSF_SYS)                      /* ALPHA 64 */
#  define LITTLE_ENDIAN
#  define PTRFTN       integer*8
#  define LONGINT      integer*8
#  define LONGINT2
#  define PTR64
#  define INLINE_VECT
#endif



#if defined (HP32_SYS)                           /* HP 32 */
#  define HP_SYS
#  define HP700_SYS
#  define SHORT_FILES
#  define PTRFTN       integer
#  define LONGINT      integer
#  define IEEE_SYS
#endif


#if defined (HP64_SYS) || defined (HPIA64_SYS)   /* HP 64 */
#  define HP_SYS
#  define HP700_SYS
#  define PROTOIZE_RUN
#  define PTRFTN       integer*8
#  define LONGINT      integer*8
#  define LONGINT2
#  define PTR64
#  define IEEE_SYS
#endif

#if defined (HPIA64_SYS)   /* HP 64 */
#  define ANS_NEWCPPLIBS
#endif

#if defined (SGIR4K_SYS)                         /* SGI 32 */
#  define SGI_SYS
#  define PTRFTN       integer
#  define LONGINT      integer*8
#  define LONGINT2
#  define IEEE_SYS
#endif


#if defined(SGI64_SYS)                           /* SGI 64 */
#  define SGI_SYS
#  define PTRFTN       integer*8
#  define LONGINT      integer*8
#  define LONGINT2
#  define PTR64
#  define IEEE_SYS
#endif


#if defined (SGIR8K_SYS)                         /* SGI R8000 */
#  define SGI_SYS
#  define SGI64_SYS
#  define PTRFTN       integer*8
#  define LONGINT      integer*8
#  define LONGINT2
#  define PTR64
#  define INLINE_VECT
#  define IEEE_SYS
#endif


#if defined (PCWINNT_SYS)                         /* ANY NT */
#  define NT_SYS
#  define LITTLE_ENDIAN
#if defined (PCWIN64_SYS)
#  define PTRFTN         integer*8
#  define LONGINT        integer*8
#  define LONGINT2
#  define PTR64
#else
#  define PTRFTN         integer
#  define LONGINT        integer*8
#  define LONGINT2
#endif
#endif

#if defined (SOLARIS_SYS)                        /* SUN 32 */
#  define SUN_SYS
#  define PTRFTN       integer
#  define LONGINT      integer*8
#  define LONGINT2
#  define INLINE_VECT
#  define IEEE_SYS
#endif

#if defined (SUN64_SYS)                          /* SUN 64 */
#  define SUN_SYS
#  undef PTRFTN
#  define PTRFTN       integer*8
#  define LONGINT      integer*8
#  define LONGINT2
#  define PTR64
#  define INLINE_VECT
#  define IEEE_SYS
#endif

#if defined (SOLX64_SYS)                        /* SOLARIS X64 */
#  define SUN_SYS
#  undef  IEEE_SYS
#  undef  PTRFTN
#  define PTR64
#  define PTRFTN       integer*8
#  define LONGINT      integer*8
#  define LONGINT2
#  define INLINE_VECT
#  define LITTLE_ENDIAN
#endif

#if defined (RS6000_SYS)                         /* IBM 32 */
#  define IBM_SYS
#  define PTRFTN       integer
#  define LONGINT      integer*8
#  define LONGINT2
#  define IEEE_SYS
#  define ANS_NEWCPPLIBS
#endif

#if defined (RS64K_SYS)                          /* IBM 64 */
#  define IBM_SYS
#  undef PTRFTN
#  define PTRFTN       integer*8
#  define LONGINT      integer*8
#  define LONGINT2
#  define PTR64
#  define IEEE_SYS
#endif

#if defined (LINUXIA32_SYS)                      /* LINUX 32 */
#  define LINUX_SYS 
#  define LITTLE_ENDIAN
#  define PTRFTN integer
#  define LONGINT integer*8
#  define LONGINT2
#endif

#if defined (LINUXIA64_SYS)                      /* LINUX 64 */
#  define LINUX_SYS
#  define LITTLE_ENDIAN
#  define PTRFTN integer*8
#  define LONGINT integer*8
#  define LONGINT2
#  define PTR64
#endif

#if defined (LINUXOP64_SYS)                      /* LINUX Opteron 64 */
#  define LINUX_SYS
#  define LITTLE_ENDIAN
#  define PTRFTN integer*8
#  define LONGINT integer*8
#  define LONGINT2
#  define PTR64
#endif

#if defined (LINUXEM64T_SYS)                     /* LINUX EM64T 64 */
#  define LINUX_SYS
#  define LITTLE_ENDIAN
#  define PTRFTN integer*8
#  define LONGINT integer*8
#  define LONGINT2
#  define PTR64
#endif


#if defined (autodouble) || defined (AUTODOUBLE)  /* DYNA DEFINITIONS */
#  define INT_DYNA      integer*8
#  define REAL_DYNA     double precision
#else
#  define INT_DYNA      integer
#  define REAL_DYNA     real
#endif

#define BIGIARRY   integer
#define BIGDARRY   double precision
#define BIGRARRY   real
#define BIGCARRY   complex*16
#define BIGLARRY   LONGINT

#define RPCPTR     integer*8

#if defined (PTR64)
#  define CALLINT64
#  define BCS_INT integer*8
#  define DSP_INT integer*8
#else
#  define BCS_INT integer*4
#  define DSP_INT integer*4
#endif


#if !defined (FORTRAN)                  /* Second FORTRAN wrapper */
/*
 ***********************************************************************
 * BELOW SECTION DEFINES SPECIAL MACHINE DEPENDANT FLAGS
 *
 * THIS SECTION IS ONLY ACTIVE IN C FILES.  DEFINITIONS THAT ARE NOT NEEDED 
 * IN FORTRAN SHOULD BE ADDED HERE.
 *
 * Use_drem :		If true, use drem() in lieu of default fmod()
 * Use_memmove :	If true, use memmove/memset in lieu of bcopy/bzero
 * Use_memcpy :		If true, use memcpy/memset in lieu of bcopy/bzero
 * UseSpecialSqrt :	If true, uses a special squartroot in lieu of sqrt()
 * UseSystem_fabs :	If true, uses the fabs() function
 *
 ***********************************************************************
 */

/* For most -ALL- systems, define below macros */

/*
 * Generic stuff for C to FORTRAN connections
 */
#define CALLTYP
#define FUNCTION
#define SUBROUTINE void


#if defined (DECAXPOSF_SYS)                      /* ALPHA 64 */
#  define ARGTRAIL_SYS
#  define LOWERCASEUNDER_SYS
#endif


#if defined (HP_SYS)                             /* ALL HPs */
#  if !defined (SYSTEM_VALUES_H)
#    define SYSTEM_VALUES_H
#    include <values.h>
#  endif
#  define Use_memmove
#  if !defined (SYSTEM_FLOAT_H)
#    define SYSTEM_FLOAT_H
#    include <float.h>
#  endif
#  define ARGTRAIL_SYS
#endif


#if defined (HP32_SYS)                           /* HP 32 */
#  define LOWERCASENOUNDER_SYS
#  define NOUNDER_SYS
#endif


#if defined (HP64_SYS) || defined (HPIA64_SYS)   /* HP 64 */
#  define LOWERCASEUNDER_SYS
#endif


#if defined (PCWINNT_SYS)                        /* ALL NTs */
#  if !defined (NOSTDCALL)
#    undef FUNCTION
#    define FUNCTION __stdcall
#    undef SUBROUTINE
#    define SUBROUTINE void __stdcall
#    undef CALLTYP
#    define CALLTYP __stdcall
#  endif
#  define UPPERCASENOUNDER_SYS
#  define UPCASE_SYS
#  if !defined (SYSTEM_FLOAT_H)
#    define SYSTEM_FLOAT_H
#    include <float.h>
#  endif
#  if !defined (MAXDOUBLE)
#    define MAXDOUBLE       DBL_MAX
#  endif
#  if !defined (MAXFLOAT)
#    define MAXFLOAT        FLT_MAX
#  endif
#  if !defined (MINDOUBLE)
#    define MINDOUBLE       DBL_MIN
#  endif
#  if !defined (MINFLOAT)
#    define MINFLOAT        FLT_MIN
#  endif
#  define Use_memcpy
#  define ANS_NEWCPPLIBS
#endif


#if defined(PCWIN64_SYS) || defined (ARGTRAIL)   /* NT 64 or Intel NT 32 */
#  define ARGTRAIL_SYS
#endif


#if defined(SGI_SYS)                             /* ALL SGIs */
#  define ARGTRAIL_SYS
#  define LOWERCASEUNDER_SYS
#  define Use_drem
#endif


#if defined (SGIR4K_SYS)                         /* SGI 32 */
/* no special definitions needed */
#endif


#if defined(SGI64_SYS)                           /* SGI 64 */
/* no special definitions needed */
#  define PROTOIZE_RUN      /* probably not needed once code is converted to 
                               new C to FORTRAN conventions */
#endif


#if defined (SGIR8K_SYS)                         /* SGI R8000 */
/* no special definitions needed */
#endif


#if defined (SUN_SYS)                            /* ALL SUNs */
#  define ARGTRAIL_SYS
#  define LOWERCASEUNDER_SYS
#endif


#if defined (SOLARIS_SYS)                        /* SUN 32 */
#  define Use_memmove
#endif

#if defined (SOLX64_SYS)                          /* SOLARIS x64 */
/* no special definitions needed */
#endif

#if defined (SUN64_SYS)                          /* SUN 64 */
/* no special definitions needed */
#endif


#if defined (IBM_SYS)                            /* ALL IBMs */
#  define ARGTRAIL_SYS
#  define LOWERCASENOUNDER_SYS
#  define NOUNDER_SYS
#endif

#if defined (RS6000_SYS)                         /* IBM 32 */
#  if !defined (SYSTEM_VALUES_H)
#    define SYSTEM_VALUES_H
#    include <values.h>
#  endif
#endif


#if defined (RS64K_SYS)                          /* IBM 64 */
/* no special definitions needed */
#endif


#if defined(LINUX_SYS)                           /* ALL LINUXs */
#  define ARGTRAIL_SYS
#  define LOWERCASEUNDER_SYS
#endif


#if defined(LINUXIA32_SYS)                       /* LINUX 32 */
/* no special definitions needed */
#endif


#if defined(LINUXIA64_SYS)                       /* LINUX 64 */
/* no special definitions needed */
#endif


#if defined(LINUXOP64_SYS)                       /* LINUX Opteron 64 */
/* no special definitions needed */
#endif


#if defined(LINUXEM64T_SYS)                      /* LINUX EM64T 64 */
/* no special definitions needed */
#endif


/* stuff for passing strings from C to FORTRAN and vice versa */
#if defined (ARGTRAIL_SYS)
# define FCHAR(x) char * x
# define FCHARL(x) , int x
# define CCHAR(x) x
# define CCHARL(x) , x
#else
# define FCHAR(x) char * x , int x ## _len
# define FCHARL(x)
# define CCHAR(x) x , x ## _len
# define CCHARL(x)
#endif

#endif                  /* End of non-FORTRAN definitions */

#endif                  /* End of if that spans entire file. */
