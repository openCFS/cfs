/*****************************************************************************
 *                   Copyright (C) 1999 CMSoft                               *
 *                                                                           *
 *  These lines of code and declarations contain unpublished proprietary     *
 *  information of CMSoft. They may not be copied or duplicated in whole     *
 *  or part without prior authorization from CMSoft.                         *
 *                                                                           *
 *****************************************************************************/
#ifndef _FS_ELEMENT_H_
#define _FS_ELEMENT_H_

#include <math.h>
#include "BlockAlloc.h"

static const int maxNumNodes = 256;
// Boundary Condition Structure
class BCond {
public:
  int    nnum;   // node number
  int    dofnum; // dof number
  double val;    // value of bc
};

class DofSetArray;

class FSElement {
public:
  virtual int    numNodes() = 0;
  virtual int    nodes(int *ndList) = 0;
  virtual void   renum(int *renumTable) = 0;
  virtual void   markDofs(DofSetArray &) = 0;
  virtual int*   dofs(DofSetArray &, int *p=0)=0;
  virtual int    numDofs()=0;
  virtual int    nodeDofs() { return 0; } // dofs for a given node
  // This is outdated
  // 0 regular, 1 axisym, 2 contact
  virtual bool   isContact() {return false;}
  virtual int    type() = 0;
  virtual int    prType() = 0; 
  virtual void   setNumNodes(int nnodes) = 0;
  virtual void   setNodes(int nnodes, int *nodes) = 0;
  virtual void   Send(int iCPU, int *Back = NULL) = 0;
  virtual void   Recv(int iCPU, int *Forward = NULL) = 0;
};

//****************************************************************
//*
//*     class Node: Keeps the coordinates of a node
//*
//****************************************************************

class FSNode {
public:
  // Constructors
  FSNode() {}
  FSNode(double *xyz) { x = xyz[0]; y = xyz[1]; z = xyz[2];}
  FSNode(FSNode &nd) { x = nd.x; y = nd.y; z = nd.z;}
  
  // Coordinates
  double  x;
  double  y;
  double  z;
  
  double distance(FSNode &n)
  { return sqrt((x-n.x)*(x-n.x)+
		(y-n.y)*(y-n.y)+ (z-n.z)*(z-n.z)); }
};

class FSCoordSet {
  int nmax;
  FSNode **nodes;
  
public:
  // Constructors
  FSCoordSet(int iSize = 256);
  FSCoordSet(FSCoordSet &allNodes, int n, int *nodes);
  ~FSCoordSet();
  
  // Member functions
  int   size() { return nmax ; }
  void  nodeadd(int n, double *xyz)
  { 
    if (n < 0) return; 
    if (n >= nmax) 
      nmax = n+1; 
    nodes[n] = new FSNode(xyz);
  }
  
  FSNode &getNode(int i) { return *nodes[i]; }
  
  FSNode *operator[] (int i) { return nodes[i]; }
};
#endif
