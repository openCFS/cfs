
/*
////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         copyright(c) 2010 SAS IP, Inc.  All rights reserved.             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MAT_TBUtilCToF.h $
// $Revision: 1.12 $ 7.0
// $Date: 2010/04/16 15:57:37 $ Feb 9 2005
// $Author: srpailla $ rjayasee
//
// Decription :
//
//	C Entry point from Ansys to the Curve Fitting Code. This has all the
//  Command Parsing code
//////////////////////////////////////////////////////////////////////////////
*/

/*  AnsCmdCtoF.h */
#if !defined(MAT_TBUtilCToF)
#define MAT_TBUtilCToF

#include "ansys.h"

#if defined (HP_SYS) || defined(HPIA64_SYS) || defined(HP32_SYS) 
    #define const const
#endif 

/* (1)----------------------------------------------------------------*/
#if defined(LOWERCASENOUNDER_SYS)

/*
 *   The pattern for these platforms is the lowercased version of the name
 */

#define MAT_ErHandler         mat_erhandler
#define NlpSubTbHeadNext      nlpsubtbheadnext
#define NlPut                 nlput
#define NlGet                 nlget
#define NlInqr                nlinqr
#define NlDel                 nldel
#define TbHdUp                tbhdup
#define GetMaterialMaxTableSize getmaterialmaxtablesize
#define SetMaterialMaxTableSize setmaterialmaxtablesize
#define TbleCm tblecm
#define TblcCm tblccm
#define TbInterp              tbinterp
#define LocTem loctem
#define AbSetUp absetup
#define AbFinish abfinish
#define TbLabl tblabl
#define GetElMatR getelmatr
#define MAT_WriteToUnit     mat_writetounit

#endif


/* (2)----------------------------------------------------------------*/
#if defined(UPPERCASENOUNDER_SYS)

/*
 *   The pattern for these platforms is the uppercased version of the name
 */

#define MAT_ErHandler         MAT_ERHANDLER
#define NlpSubTbHeadNext      NLPSUBTBHEADNEXT
#define NlPut                 NLPUT
#define NlGet                 NLGET
#define NlInqr                NLINQR
#define NlDel                 NLDEL
#define TbHdUp                TBHDUP
#define GetMaterialMaxTableSize GETMATERIALMAXTABLESIZE
#define SetMaterialMaxTableSize SETMATERIALMAXTABLESIZE
#define TbleCm TBLECM
#define TblcCm TBLCCM
#define TbInterp              TBINTERP
#define LocTem LOCTEM
#define AbSetUp ABSETUP
#define AbFinish ABFINISH
#define TbLabl TBLABL
#define GetElMatR GETELMATR
#define MAT_WriteToUnit     MAT_WRITETOUNIT
#endif


/* (3)----------------------------------------------------------------*/
#if defined(LOWERCASEUNDER_SYS)

/*
 *   The pattern for these platforms is the lowercased version of the name 
 *   followed by an underscore
 */

#define MAT_ErHandler         mat_erhandler_
#define NlpSubTbHeadNext      nlpsubtbheadnext_
#define NlPut                 nlput_
#define NlGet                 nlget_
#define NlInqr                nlinqr_
#define NlDel                 nldel_
#define TbHdUp                tbhdup_
#define GetMaterialMaxTableSize getmaterialmaxtablesize_
#define SetMaterialMaxTableSize setmaterialmaxtablesize_
#define TbleCm tblecm_
#define TblcCm tblccm_
#define TbInterp              tbinterp_
#define LocTem loctem_
#define AbSetUp absetup_
#define AbFinish abfinish_
#define TbLabl tblabl_
#define GetElMatR getelmatr_
#define MAT_WriteToUnit     mat_writetounit_

#endif

#define mxtbls 72
#define tbhdsz 15
#define tbhdszext 5
/* (4)----------------------------------------------------------------*/

/*
 *   This section is for definition of prototypes.  Each prototype 
 *   should be ANSI compliant and specify the types of each parameter 
 *   as well as the return type.
 */
#ifdef __cplusplus
extern "C"
{
#endif

SUBROUTINE MAT_ErHandler( FCHAR(fname), INT*, INT*, FCHAR(emsg) FCHARL(fname_len) FCHARL(emsg_len) ) ;
SUBROUTINE MAT_WriteToUnit( INT*, FCHAR(emsg), INT* FCHARL(emsg_len) ) ;
SUBROUTINE NlpSubTbHeadNext(INT*,DOUBLE*,INT*) ;
SUBROUTINE NlPut(INT*, INT*, INT*, DOUBLE*) ;
INT FUNCTION NlGet(INT*, INT*, DOUBLE*) ;
INT FUNCTION NlInqr(INT*, INT*, INT*) ;
SUBROUTINE NlDel(INT*, INT*) ;
SUBROUTINE TbHdUp( INT* , DOUBLE* ) ;
INT FUNCTION GetMaterialMaxTableSize() ;
SUBROUTINE SetMaterialMaxTableSize( INT* ) ;
SUBROUTINE MAT_GetTBCOMNumTemps( INT* pNTemps ) ;
INT FUNCTION LocTem(INT*,INT*,INT*,INT*,INT*) ;
SUBROUTINE AbSetUp( INT*, FCHAR(title), INT*, INT* FCHARL(title_len) ) ;
SUBROUTINE AbFinish( INT* ) ;
#define CHAROCT char*

SUBROUTINE TbLabl (INT* ,FCHAR(title),FCHAR(tbopttitle),INT*,FCHAR(LC),INT*,FCHAR(LR) FCHARL(title_len) FCHARL(tbopttitle_len) FCHARL(LC_len) FCHARL(LR_len)) ;
FUNCTION INT GetElMatR() ;
SUBROUTINE TbInterp (DOUBLE*,INT*,INT*,DOUBLE*,INT*,DOUBLE*) ;

/*
      common /tblecm/
c     --- dp vars
     x curtem, dtbsp(4),
c     --- integer vars
     x curtb,curmat,tbsiz,tbtyp,tbrow,tbcol,tbtems,dprtem,rowkey,
     x nxtloc,nxttem,temloc,tbmxsz,temptr,tbpt,tbopt,hypopt,tbnpts,
     x tbnfield,itbsp(1),
     x tbpnum(mxtbls),ltype
c     --- character vars
      common /tblccm/
*/

/* ORDER OF THE VARIABLES IN FORTRAN AND C MUST MATCH EXACTLY */
extern struct 
{
      DOUBLE curtem, dtbsp[4] ;
      INT    curtb,curmat,tbsiz,tbtyp,tbrow,tbcol,tbtems,dprtem,rowkey,
             nxtloc,nxttem,temloc,tbmxsz,temptr,tbpt,tbopt,hypopt,tbnpts,
             tbnfield,itbsp[1],tbpnum[mxtbls],ltype ;
} TbleCm ;

extern struct 
{
      CHAR   tblab[mxtbls] ;
} TblcCm ;
#ifdef __cplusplus
}
#endif

#endif
