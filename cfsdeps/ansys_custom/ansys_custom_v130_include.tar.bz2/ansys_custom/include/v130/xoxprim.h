  /************************************************************
   *  author/date: Chun Li/01-07-97
   *
   *  primary function:
   *       header for the functions for "primtive creation" 
   *       definition in the ANSYS/SHAPES interface 
   *
   *  secondary function:
   *       none
   *
   *  routines included: 
   *       INT xPointCreate_();
   *       INT xBlockCreate_();
   *       INT xCylinCreate_();
   *       INT xConeCreate_();
   *       INT xSphereCreate_();
   *
   *  history
   *       none
   *
   *  comments:
   *       none
   *
   *  Notice - This file contains ANSYS Confidential information 
   */ 
   /************************************************************/
/* 
 * *** copyright(c) 2010 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */

#if defined(RS6000_SYS) || defined(HP32_SYS)
    /*  c routines called from fortran  */
#define xPointCreate_		xpointcreate
#define xBlockCreate_		xblockcreate
#define xCylinCreate_		xcylincreate
#define xConeCreate_		xconecreate
#define xSphereCreate_          xspherecreate
#define frn_cr_hgmatrix_        frn_cr_hgmatrix 

#elif defined(WATCOMC_SYS) \
      || defined(PCWINNT_SYS)
    /*  c routines called from fortran  */
#define xPointCreate_ 		XPOINTCREATE
#define xBlockCreate_           XBLOCKCREATE
#define xCylinCreate_		XCYLINCREATE
#define xConeCreate_		XCONECREATE
#define xSphereCreate_          XSPHERECREATE
#define frn_cr_hgmatrix_	FRN_CR_HGMATRIX

#else
#define xPointCreate_		xpointcreate_
#define xBlockCreate_		xblockcreate_
#define xCylinCreate_		xcylincreate_
#define xConeCreate_		xconecreate_
#define xSphereCreate_          xspherecreate_
#endif 

       extern INT CALLTYP xPointCreate_ ansPROTO((
	      DOUBLE coords[3], INT *spacedim));
 
       extern INT CALLTYP xBlockCreate_ ansPROTO((
              DOUBLE *x_length, DOUBLE *y_width, DOUBLE *z_height, 
	      DOUBLE trans[16]));

       extern INT CALLTYP xCylinCreate_ ansPROTO((
              DOUBLE *radius, DOUBLE *height, DOUBLE trans[16]));

       extern INT CALLTYP xConeCreate_ ansPROTO((
              DOUBLE *baserad, DOUBLE *toprad, DOUBLE *height,
              DOUBLE trans[16]));

       extern INT CALLTYP xSphereCreate_ ansPROTO((
              DOUBLE *radius, DOUBLE trans[16]));

       extern void CALLTYP frn_cr_hgmatrix_ ansPROTO((
              DOUBLE trnwpc[3][3], DOUBLE focwpc[3], DOUBLE *xoffs,
              DOUBLE *yoffs, DOUBLE *zoffs, DOUBLE hmgarr[4][4]));
