////////////////////////////////////////////////////////////////////////////
//                                                                        //
//          copyright(c) 2009 SAS IP, Inc.  All rights reserved.            //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: vt_global.h $
// $Revision: 1.5 $Id: 
// $Date: 2009/11/13 16:19:08 $
// $Author: jtm $
//
// Decription: 
//
////////////////////////////////////////////////////////////////////////////


#ifndef __VT_GLOBAL__
#define __VT_GLOBAL__ 1

#include "C_AnsysModele.h"

extern C_AnsysModele *G_AnsysModele;

#endif
