/*******************************************************************************
 *
 *   sxf_post.h  --- FAST routines for the post context.
 *               
 * 
 * |Module:  DXVT
 *
 * |Description: 
 *
 * |Includes:	
 *        
 * |Auteur: Stephane Marguerin
 *
 * |Creation: August 2004
 *
 * |Version: $Id: sxf_post.h,v 1.4 2009/11/13 16:19:07 jtm Exp $
 *
 * |Copyright:	Copyright(c)  2004
 *
 ********************************************************************************/
#ifndef __SXF_POST_H__
#define __SXF_POST_H__ 1


#include "sx_cons_solver.h"
#include "sx_CADOE_solver.h"

#if defined(LOWERCASENOUNDER_SYS)
#define sxf_init_flags 		sxf_init_flags
#define sxf_closePost		sxf_closepost
#define sxf_start_assembly      sxf_start_assembly
#define sxf_end_assembly        sxf_end_assembly
#endif

#if defined(UPPERCASENOUNDER_SYS)
#define sxf_init_flags 		SXF_INIT_FLAGS
#define sxf_closePost		SXF_CLOSEPOST
#define sxf_start_assembly      SXF_START_ASSEMBLY
#define sxf_end_assembly        SXF_END_ASSEMBLY
#endif

#if defined(LOWERCASEUNDER_SYS)
#define sxf_init_flags 		sxf_init_flags_
#define sxf_closePost		sxf_closepost_
#define sxf_start_assembly      sxf_start_assembly_
#define sxf_end_assembly        sxf_end_assembly_
#endif

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/*c++ only*/
#ifdef __cplusplus
	extern T_statut  sxf_openPost( E_solveur, const char *rsxName, C_AdocSession **, PAR **, T_modele **);
#endif

	SUBROUTINE sxf_closePost();
	SUBROUTINE sxf_init_flags();
	SUBROUTINE sxf_start_assembly();
	SUBROUTINE sxf_end_assembly();

#ifdef __cplusplus
}
#endif

#endif /* __SXF_POST_H__ */
