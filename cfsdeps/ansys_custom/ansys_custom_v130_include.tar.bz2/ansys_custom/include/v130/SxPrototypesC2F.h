/* ---------------------------------------------------------------------- */
/* *** copyright(c) 2010 SAS IP, Inc.  All rights reserved.                                         */
/* *** ansys, inc.                                                        */
/* ---------------------------------------------------------------------- */


/*
 *    author/date: Stefan Reh 2002-02-06
 *
 *    primary function:
 *
 *        header for "C and Fortran interface"
 *
 *    Notice - This file contains ANSYS Confidential information ***
 *
 */

#ifndef _SX_PROTOTYPES_CTOF_H_
#define _SX_PROTOTYPES_CTOF_H_  1



/* ===================================================================== */
/* For systems needing lower case names without an underscore at the end */
/* ===================================================================== */
#if defined(LOWERCASENOUNDER_SYS)

/* C functions called from FORTRAN */
/* ------------------------------- */
#define F2C_SxEnter                 f2c_sxenter
#define F2C_QrySxEnterStatus        f2c_qrysxenterstatus

#define F2C_QrySxSolvStatus         f2c_qrysxsolvstatus
#define F2C_PutSxSolvStatus         f2c_putsxsolvstatus

#define F2C_Sxfreq                  f2c_sxfreq
#define F2C_QrySxfreqStatus         f2c_qrysxfreqstatus
#define F2C_GetSxfreqData           f2c_getsxfreqdata
#define F2C_PutSxfreqData           f2c_putsxfreqdata

#define F2C_Sxtemp                  f2c_sxtemp
#define F2C_QrySxtempStatus         f2c_qrysxtempstatus
#define F2C_GetSxtempData           f2c_getsxtempdata
#define F2C_PutSxtempData           f2c_putsxtempdata

#define F2C_Sxmp                    f2c_sxmp
#define F2C_GetSxmpData             f2c_getsxmpdata
#define F2C_PutSxmpData             f2c_putsxmpdata

#define F2C_Sxin                    f2c_sxin
#define F2C_PutSxinData             f2c_putsxindata             

#define F2C_Sxreal                  f2c_sxreal
#define F2C_GetSxrealData           f2c_getsxrealdata
#define F2C_PutSxrealData           f2c_putsxrealdata

#define F2C_Sxsec                   f2c_sxsec
#define F2C_GetSxsecData            f2c_getsxsecdata
#define F2C_PutSxsecData            f2c_putsxsecdata

#define F2C_Sxce                    f2c_sxce
#define F2C_GetSxceData             f2c_getsxcedata
#define F2C_PutSxceData             f2c_putsxcedata

#define F2C_Sxhi                    f2c_sxhi
#define F2C_GetSxhiData             f2c_getsxhidata
#define F2C_PutSxhiData             f2c_putsxhidata

#define F2C_Sxgeom                  f2c_sxgeom
#define F2C_GetSxgeomData           f2c_getsxgeomdata
#define F2C_PutSxgeomData           f2c_putsxgeomdata

#define F2C_Sxdisc                  f2c_sxdisc
#define F2C_GetSxdiscData           f2c_getsxdiscdata
#define F2C_PutSxdiscData           f2c_putsxdiscdata

#define F2C_Sxrslt                  f2c_sxrslt
#define F2C_GetSxrsltData           f2c_getsxrsltdata
#define F2C_GetSxrsltEntyList       f2c_getsxrsltentylist
#define F2C_PutSxrsltData           f2c_putsxrsltdata

#define F2C_Sxvmod                  f2c_sxvmod

#define F2C_Sxrfil                  f2c_sxrfil
#define F2C_QrySxrfilStatus         f2c_qrysxrfilstatus
#define F2C_GetSxrfilPathName       f2c_getsxrfilpathname
#define F2C_PutSxrfilData           f2c_putsxrfildata

#define F2C_Sxmeth                  f2c_sxmeth
#define F2C_GetSxmethData           f2c_getsxmethdata
#define F2C_PutSxmethData           f2c_putsxmethdata

#define F2C_Sxeval                  f2c_sxeval

#define F2C_Sxstat                  f2c_sxstat
#define F2C_Sxclr                   f2c_sxclr
#define F2C_Sxexit                  f2c_sxexit
#define F2C_PutSxJobName            f2c_putsxjobname
#define F2C_GetSxVarTypeByVarName   f2c_getsxvartypebyvarname

#define F2C_GetNumSxCmd             f2c_getnumsxcmd
#define F2C_GetSxCmdElemList        f2c_getsxcmdelemlist
#define F2C_GetSxinData             f2c_getsxindata  

#define F2C_Sxqa                    f2c_sxqa

#define F2C_Sxoption                f2c_sxoption

#define F2C_Sxsfe                   f2c_sxsfe
#define F2C_GetSxsfeData            f2c_getsxsfedata
#define F2C_PutSxsfeData            f2c_putsxsfedata

/* FORTRAN functions called from C */
/* ------------------------------- */
/*
#define C2F_Test                    c2f_test
*/

#endif


/* ===================================================================== */
/* For systems needing upper case names without an underscore at the end */
/* ===================================================================== */
#if defined(UPPERCASENOUNDER_SYS)

/* C functions called from FORTRAN */
/* ------------------------------- */
#define F2C_SxEnter                 F2C_SXENTER
#define F2C_QrySxEnterStatus        F2C_QRYSXENTERSTATUS

#define F2C_QrySxSolvStatus         F2C_QRYSXSOLVSTATUS
#define F2C_PutSxSolvStatus         F2C_PUTSXSOLVSTATUS

#define F2C_Sxfreq                  F2C_SXFREQ
#define F2C_QrySxfreqStatus         F2C_QRYSXFREQSTATUS
#define F2C_GetSxfreqData           F2C_GETSXFREQDATA
#define F2C_PutSxfreqData           F2C_PUTSXFREQDATA

#define F2C_Sxtemp                  F2C_SXTEMP
#define F2C_QrySxtempStatus         F2C_QRYSXTEMPSTATUS
#define F2C_GetSxtempData           F2C_GETSXTEMPDATA
#define F2C_PutSxtempData           F2C_PUTSXTEMPDATA

#define F2C_Sxmp                    F2C_SXMP
#define F2C_GetSxmpData             F2C_GETSXMPDATA
#define F2C_PutSxmpData             F2C_PUTSXMPDATA

#define F2C_Sxin                    F2C_SXIN
#define F2C_PutSxinData             F2C_PUTSXINDATA             

#define F2C_Sxreal                  F2C_SXREAL
#define F2C_GetSxrealData           F2C_GETSXREALDATA
#define F2C_PutSxrealData           F2C_PUTSXREALDATA

#define F2C_Sxsec                   F2C_SXSEC
#define F2C_GetSxsecData            F2C_GETSXSECDATA
#define F2C_PutSxsecData            F2C_PUTSXSECDATA

#define F2C_Sxce                    F2C_SXCE
#define F2C_GetSxceData             F2C_GETSXCEDATA
#define F2C_PutSxceData             F2C_PUTSXCEDATA

#define F2C_Sxhi                    F2C_SXHI
#define F2C_GetSxhiData             F2C_GETSXHIDATA
#define F2C_PutSxhiData             F2C_PUTSXHIDATA

#define F2C_Sxgeom                  F2C_SXGEOM
#define F2C_GetSxgeomData           F2C_GETSXGEOMDATA
#define F2C_PutSxgeomData           F2C_PUTSXGEOMDATA

#define F2C_Sxdisc                  F2C_SXDISC
#define F2C_GetSxdiscData           F2C_GETSXDISCDATA
#define F2C_PutSxdiscData           F2C_PUTSXDISCDATA

#define F2C_Sxrslt                  F2C_SXRSLT
#define F2C_GetSxrsltData           F2C_GETSXRSLTDATA
#define F2C_GetSxrsltEntyList       F2C_GETSXRSLTENTYLIST
#define F2C_PutSxrsltData           F2C_PUTSXRSLTDATA

#define F2C_Sxvmod                  F2C_SXVMOD

#define F2C_Sxrfil                  F2C_SXRFIL
#define F2C_QrySxrfilStatus         F2C_QRYSXRFILSTATUS
#define F2C_GetSxrfilPathName       F2C_GETSXRFILPATHNAME
#define F2C_PutSxrfilData           F2C_PUTSXRFILDATA

#define F2C_Sxmeth                  F2C_SXMETH
#define F2C_GetSxmethData           F2C_GETSXMETHDATA
#define F2C_PutSxmethData           F2C_PUTSXMETHDATA

#define F2C_Sxeval                  F2C_SXEVAL

#define F2C_Sxstat                  F2C_SXSTAT
#define F2C_Sxclr                   F2C_SXCLR
#define F2C_Sxexit                  F2C_SXEXIT
#define F2C_PutSxJobName            F2C_PUTSXJOBNAME
#define F2C_GetSxVarTypeByVarName   F2C_GETSXVARTYPEBYVARNAME

#define F2C_GetNumSxCmd       	    F2C_GETNUMSXCMD
#define F2C_GetSxCmdElemList        F2C_GETSXCMDELEMLIST
#define F2C_GetSxinData             F2C_GETSXINDATA  

#define F2C_Sxqa                    F2C_SXQA

#define F2C_Sxoption				F2C_SXOPTION

#define F2C_Sxsfe                   F2C_SXSFE
#define F2C_GetSxsfeData            F2C_GETSXSFEDATA
#define F2C_PutSxsfeData            F2C_PUTSXSFEDATA

/* FORTRAN functions called from C */
/* ------------------------------- */
/*
#define C2F_Test                    C2F_TEST
*/

#endif


/* ================================================================== */
/* For systems needing upper case names with an underscore at the end */
/* ================================================================== */
#if defined(LOWERCASEUNDER_SYS)

/* C functions called from FORTRAN */
/* ------------------------------- */
#define F2C_SxEnter                 f2c_sxenter_
#define F2C_QrySxEnterStatus        f2c_qrysxenterstatus_

#define F2C_QrySxSolvStatus         f2c_qrysxsolvstatus_
#define F2C_PutSxSolvStatus         f2c_putsxsolvstatus_

#define F2C_Sxfreq                  f2c_sxfreq_
#define F2C_QrySxfreqStatus         f2c_qrysxfreqstatus_
#define F2C_GetSxfreqData           f2c_getsxfreqdata_
#define F2C_PutSxfreqData           f2c_putsxfreqdata_

#define F2C_Sxtemp                  f2c_sxtemp_
#define F2C_QrySxtempStatus         f2c_qrysxtempstatus_
#define F2C_GetSxtempData           f2c_getsxtempdata_
#define F2C_PutSxtempData           f2c_putsxtempdata_

#define F2C_Sxmp                    f2c_sxmp_
#define F2C_GetSxmpData             f2c_getsxmpdata_
#define F2C_PutSxmpData             f2c_putsxmpdata_

#define F2C_Sxin                    f2c_sxin_
#define F2C_PutSxinData             f2c_putsxindata_             

#define F2C_Sxreal                  f2c_sxreal_
#define F2C_GetSxrealData           f2c_getsxrealdata_
#define F2C_PutSxrealData           f2c_putsxrealdata_

#define F2C_Sxsec                   f2c_sxsec_
#define F2C_GetSxsecData            f2c_getsxsecdata_
#define F2C_PutSxsecData            f2c_putsxsecdata_

#define F2C_Sxce                    f2c_sxce_
#define F2C_GetSxceData             f2c_getsxcedata_
#define F2C_PutSxceData             f2c_putsxcedata_

#define F2C_Sxhi                    f2c_sxhi_
#define F2C_GetSxhiData             f2c_getsxhidata_
#define F2C_PutSxhiData             f2c_putsxhidata_

#define F2C_Sxgeom                  f2c_sxgeom_
#define F2C_GetSxgeomData           f2c_getsxgeomdata_
#define F2C_PutSxgeomData           f2c_putsxgeomdata_

#define F2C_Sxdisc                  f2c_sxdisc_
#define F2C_GetSxdiscData           f2c_getsxdiscdata_
#define F2C_PutSxdiscData           f2c_putsxdiscdata_

#define F2C_Sxrslt                  f2c_sxrslt_
#define F2C_GetSxrsltData           f2c_getsxrsltdata_
#define F2C_GetSxrsltEntyList       f2c_getsxrsltentylist_
#define F2C_PutSxrsltData           f2c_putsxrsltdata_

#define F2C_Sxvmod                  f2c_sxvmod_

#define F2C_Sxrfil                  f2c_sxrfil_
#define F2C_QrySxrfilStatus         f2c_qrysxrfilstatus_
#define F2C_GetSxrfilPathName       f2c_getsxrfilpathname_
#define F2C_PutSxrfilData           f2c_putsxrfildata_


#define F2C_Sxmeth                  f2c_sxmeth_
#define F2C_GetSxmethData           f2c_getsxmethdata_
#define F2C_PutSxmethData           f2c_putsxmethdata_

#define F2C_Sxeval                  f2c_sxeval_

#define F2C_Sxstat                  f2c_sxstat_
#define F2C_Sxclr                   f2c_sxclr_
#define F2C_Sxexit                  f2c_sxexit_
#define F2C_PutSxJobName            f2c_putsxjobname_
#define F2C_GetSxVarTypeByVarName   f2c_getsxvartypebyvarname_
#define F2C_GetNumSxCmd             f2c_getnumsxcmd_
#define F2C_GetSxCmdElemList        f2c_getsxcmdelemlist_
#define F2C_GetSxinData             f2c_getsxindata_  

#define F2C_Sxqa                    f2c_sxqa_

#define F2C_Sxoption				f2c_sxoption_

#define F2C_Sxsfe                   f2c_sxsfe_
#define F2C_GetSxsfeData            f2c_getsxsfedata_
#define F2C_PutSxsfeData            f2c_putsxsfedata_

/* FORTRAN functions called from C */
/* ------------------------------- */
/*
#define C2F_Test                    c2f_test_
*/

#endif



/* ===================== */
/* Prototype definitions */
/* ===================== */

#ifdef __cplusplus
extern "C" {
#endif

INT FUNCTION  F2C_SxEnter( INT *iPrintKeyIn );
INT FUNCTION  F2C_QrySxEnterStatus( void );


INT FUNCTION  F2C_Sxfreq         ( FCHAR(cVarNameIn), DOUBLE *dCurrValIn, DOUBLE *dUserMinValIn, DOUBLE *dUserMaxValIn,
                                   INT *iFreqIncrIn, INT *iRedOptIn
                                   FCHARL(cVarNameIn_len) );
INT FUNCTION  F2C_GetSxfreqData  ( FCHAR(cVarNameOut), DOUBLE *dCurrValOut, DOUBLE *dUserMinValOut, DOUBLE *dUserMaxValOut,
                                   INT *iNumIncrOut, INT *iRedOptOut, INT *iSxfreqStatusOut,
                                   DOUBLE *dSolvMinValOut, DOUBLE *dSolvMaxValOut
                                   FCHARL(cVarNameOut_len) );
INT FUNCTION  F2C_PutSxfreqData  ( FCHAR(cVarNameIn), DOUBLE *dCurrValIn, DOUBLE *dUserMinValIn, DOUBLE *dUserMaxValIn, 
                                   INT *iNumIncrIn, INT *iRedOptIn, INT *iStatusIn,
                                   DOUBLE *dSolvMinValIn, DOUBLE *dSolvMaxValIn
                                   FCHARL(cVarNameIn_len) );
INT FUNCTION  F2C_QrySxfreqStatus( INT *iSxfreqStatusOut );


INT FUNCTION  F2C_Sxtemp         ( FCHAR(cVarNameIn), DOUBLE *dCurrValIn, DOUBLE *dUserMinValIn, DOUBLE *dUserMaxValIn,
                                   INT *iRedOptIn, INT *iNodeDefTypeIn, FCHAR(cNodeCompNameIn),
                                   INT *iNumNodeIn, INT *iNodeListIn,
                                   INT *iVariaTypeIn, INT *iOrder
                                   FCHARL(cVarNameIn_len) FCHARL(cNodeCompNameIn_len) );

INT FUNCTION  F2C_GetSxtempData  ( INT *iSxtempIdx, 
				   FCHAR(cVarNameOut), 
				   DOUBLE *dCurrValOut, DOUBLE *dUserMinValOut, DOUBLE *dUserMaxValOut,
                                   INT *iRedOptOut, INT *iNodeDefTypeOut, 
				   FCHAR(cNodeCompNameIn),
                                   INT *iNumNodeOut, INT *iVariaTypeOut, INT *iOrder, INT *iSxtempStatusOut,
                                   DOUBLE *dSolvMinValOut, DOUBLE *dSolvMaxValOut
                                   FCHARL(cVarNameOut_len) FCHARL(cNodeCompNameOut_len) );

INT FUNCTION  F2C_PutSxtempData  ( INT *iSxtempIdx, 
				   FCHAR(cVarNameIn), 
				   DOUBLE *dCurrValIn, DOUBLE *dUserMinValIn, DOUBLE *dUserMaxValIn, 
                                   INT *iRedOptIn, INT *iNodeDefTypeIn, 
				   FCHAR(cNodeCompNameIn),
                                   INT *iNumNodeIn, INT *iNodeListIn, INT *iOrderIn, INT *iVariaTypeIn, INT *iStatusIn,
                                   DOUBLE *dSolvMinValIn, DOUBLE *dSolvMaxValIn
                                   FCHARL(cVarNameIn_len) FCHARL(cNodeCompNameIn_len) );

INT FUNCTION  F2C_Sxmp           ( FCHAR(cVarNameIn), DOUBLE *dCurrValIn, DOUBLE *dMinValIn, DOUBLE *dMaxValIn, 
                                   INT *iRedOptIn, INT *iPropTypeIn,
                                   INT *iElemDefTypeIn, INT *iMatIdIn, FCHAR(cElemCompNameIn),
                                   INT *iNumElemIn, INT *iElemListIn,
                                   INT *iVariaTypeIn, INT *iOrder
                                   FCHARL(cVarNameIn_len) FCHARL(cElemCompNameIn_len) );
INT FUNCTION  F2C_GetSxmpData    ( INT *iSxmpIdxIn, 
                                   FCHAR(cVarNameOut), DOUBLE *dCurrValOut, DOUBLE *dUserMinValOut, DOUBLE *dUserMaxValOut, 
                                   INT *iRedOptOut, INT *iPropTypeOut,
                                   INT *iElemDefTypeOut, INT *iMatIdOut, FCHAR(cElemCompNameOut),
                                   INT *iNumElemOut,
                                   INT *iVariaTypeOut, INT *iOrder, 
                                   INT *iStatusOut,
                                   DOUBLE *dSolvMinValOut, DOUBLE *dSolvMaxValOut
                                   FCHARL(cVarNameOut_len) FCHARL(cElemCompNameOut_len) );
INT FUNCTION  F2C_PutSxmpData    ( INT *iSxmpIdxIn, 
                                   FCHAR(cVarNameIn), DOUBLE *dCurrValIn, DOUBLE *dUserMinValIn, DOUBLE *dUserMaxValIn, 
                                   INT *iRedOptIn, INT *iPropTypeIn,
                                   INT *iElemDefTypeIn, INT *iMatIdIn, FCHAR(cElemCompNameIn),
                                   INT *iNumElemOut, INT *iElemListIn,
                                   INT *iVariaTypeIn, INT *iOrderIn, 
                                   INT *iStatusIn,
                                   DOUBLE *dSolvMinValIn, DOUBLE *dSolvMaxValIn
                                   FCHARL(cVarNameIn_len) FCHARL(cElemCompNameIn_len) );


INT FUNCTION  F2C_Sxin           ( FCHAR(cVarNameIn), DOUBLE *dCurrValIn, DOUBLE *dMinValIn, DOUBLE *dMaxValIn, 
                                   INT *iRedOptIn, INT *iLoadTypeIn, INT *iLoadCompIn, 
                                   INT *iVariaTypeIn, INT *iOrder FCHARL(cVarNameIn_len));

INT FUNCTION  F2C_PutSxinData    ( INT *iSxinIdxIn,
				   FCHAR(cVarNameIn), DOUBLE *dCurrValIn, DOUBLE *dUserMinValIn, DOUBLE *dUserMaxValIn, 
				   INT *iRedOptIn, INT *iLoadTypeIn, INT *iLoadCompIn,
				   INT *iVariaTypeIn, INT *iOrderIn, 
				   INT *iStatusIn,
				   DOUBLE *dSolvMinValIn, DOUBLE *dSolvMaxValIn
				   FCHARL(cVarNameIn_len) );


INT FUNCTION  F2C_Sxreal           ( FCHAR(cVarNameIn), DOUBLE *dCurrValIn, DOUBLE *dMinValIn, DOUBLE *dMaxValIn, 
                                     INT *iRedOptIn, INT *iPropTypeIn,
                                     INT *iElemDefTypeIn, INT *iRealIdIn, FCHAR(cElemCompNameIn),
                                     INT *iNumElemIn, INT *iElemListIn,
                                     INT *iVariaTypeIn, INT *iOrder
                                     FCHARL(cVarNameIn_len) FCHARL(cElemCompNameIn_len) );
INT FUNCTION  F2C_GetSxrealData    ( INT *iSxrealIdxIn, 
                                     FCHAR(cVarNameOut), DOUBLE *dCurrValOut, DOUBLE *dUserMinValOut, DOUBLE *dUserMaxValOut, 
                                     INT *iRedOptOut, INT *iPropTypeOut,
                                     INT *iElemDefTypeOut, INT *iRealIdOut, FCHAR(cElemCompNameOut),
                                     INT *iNumElemOut,
                                     INT *iVariaTypeOut, INT *iOrder, 
                                     INT *iStatusOut,
                                     DOUBLE *dSolvMinValOut, DOUBLE *dSolvMaxValOut
                                     FCHARL(cVarNameOut_len) FCHARL(cElemCompNameOut_len) );
INT FUNCTION  F2C_PutSxrealData    ( INT *iSxmpIdxIn, 
                                     FCHAR(cVarNameIn), DOUBLE *dCurrValIn, DOUBLE *dUserMinValIn, DOUBLE *dUserMaxValIn, 
                                     INT *iRedOptIn, INT *iPropTypeIn,
                                     INT *iElemDefTypeIn, INT *iRealIdIn, FCHAR(cElemCompNameIn),
                                     INT *iNumElemOut, INT *iElemListIn,
                                     INT *iVariaTypeIn, INT *iOrderIn,
                                     INT *iStatusIn,
                                     DOUBLE *dSolvMinValIn, DOUBLE *dSolvMaxValIn
                                     FCHARL(cVarNameIn_len) FCHARL(cElemCompNameIn_len) );



INT FUNCTION  F2C_Sxsec           ( FCHAR(cVarNameIn), DOUBLE *dCurrValIn, DOUBLE *dMinValIn, DOUBLE *dMaxValIn, 
                                    INT *iRedOptIn, INT *iPropTypeIn,
                                    INT *iElemDefTypeIn, INT *iSecIdIn, INT *iLayerDefTypeIn, INT *iLayerIdIn, FCHAR(cElemCompNameIn),
                                    INT *iNumElemIn, INT *iElemListIn,
                                    INT *iVariaTypeIn, INT *iOrder
                                    FCHARL(cVarNameIn_len) FCHARL(cElemCompNameIn_len) );
INT FUNCTION  F2C_GetSxsecData    ( INT *iSxsecIdxIn, 
                                    FCHAR(cVarNameOut), DOUBLE *dCurrValOut, DOUBLE *dUserMinValOut, DOUBLE *dUserMaxValOut, 
                                    INT *iRedOptOut, INT *iPropTypeOut,
                                    INT *iElemDefTypeOut, INT *iSecIdOut, INT *iLayerDefTypeOut, INT *iLayerIdOut, FCHAR(cElemCompNameOut),
                                    INT *iNumElemOut,
                                    INT *iVariaTypeOut, INT *iOrder, 
                                    INT *iStatusOut,
                                    DOUBLE *dSolvMinValOut, DOUBLE *dSolvMaxValOut
                                    FCHARL(cVarNameOut_len) FCHARL(cElemCompNameOut_len) );
INT FUNCTION  F2C_PutSxsecData    ( INT *iSxmpIdxIn, 
                                    FCHAR(cVarNameIn), DOUBLE *dCurrValIn, DOUBLE *dUserMinValIn, DOUBLE *dUserMaxValIn, 
                                    INT *iRedOptIn, INT *iPropTypeIn,
                                    INT *iElemDefTypeIn, INT *iSecIdIn, INT *iLayerDefTypeIn, INT *iLayerIdIn,
                                    FCHAR(cElemCompNameIn),
                                    INT *iNumElemOut, INT *iElemListIn,
                                    INT *iVariaTypeIn, INT *iOrderIn, 
                                    INT *iStatusIn,
                                    DOUBLE *dSolvMinValIn, DOUBLE *dSolvMaxValIn
                                    FCHARL(cVarNameIn_len) FCHARL(cElemCompNameIn_len) );


INT FUNCTION  F2C_Sxce             ( FCHAR(cVarNameIn), DOUBLE *dCurrValIn, DOUBLE *dMinValIn, DOUBLE *dMaxValIn, 
                                     INT *iRedOptIn, INT *iCEIdIn, INT *iComp, 
                                     INT *iVariaTypeIn
                                     FCHARL(cVarNameIn_len) );

INT FUNCTION  F2C_Sxhi             ( FCHAR(cVarNameIn), INT *iCurrValIn, INT *dMinValIn, INT *dMaxValIn, INT *iRedOptIn
                                     FCHARL(cVarNameIn_len) );



INT FUNCTION  F2C_Sxgeom           ( FCHAR(cVarNameIn), INT *iRangeDefinedIn, DOUBLE *dMinValIn, DOUBLE *dMaxValIn,
                                     INT *iRedOptIn, INT *iOrder 
				     FCHARL(cVarNameIn_len) );
INT FUNCTION  F2C_GetSxgeomData    ( INT *iSxgeomIdxIn, 
                                     FCHAR(cVarNameOut),
                                     INT *iStatusOut, INT *iRangeDefinedOut, DOUBLE *dMinValOut, DOUBLE *dMaxValOut,
                                     INT *iRedOptOut, INT *iOrderOut, 
                                     DOUBLE *dSolvMinValOut, DOUBLE *dSolvMaxValOut
                                     FCHARL(cVarNameOut_len) );
INT FUNCTION  F2C_PutSxgeomData    ( INT *iSxgeomIdxIn, 
                                     FCHAR(cVarNameIn), 
                                     INT *iStatusIn, 
                                     INT *iRangeDefinedIn, DOUBLE *dUserMinValIn, DOUBLE *dUserMaxValIn,
                                     INT *iRedOptIn, INT *iOrderIn, 
                                     DOUBLE *dSolvMinValIn, DOUBLE *dSolvMaxValIn
                                     FCHARL(cVarNameIn_len) );


INT FUNCTION  F2C_Sxdisc           ( FCHAR(cVarNameIn), INT *iElemDefTypeIn, FCHAR(cElCompNameIn),
                                     INT *iNumElemIn, INT *iElemListIn
                                     FCHARL(cVarNameIn_len) FCHARL(cElCompNameIn_len) );
INT FUNCTION  F2C_GetSxdiscData    ( INT *iSxdiscIdxIn, 
                                     FCHAR(cVarNameOut), DOUBLE *dCurrValOut, 
                                     INT *iElemDefTypeOut, FCHAR(cElemCompNameOut),
                                     INT *iNumElemOut,
                                     INT *iStatusOut
                                     FCHARL(cVarNameOut_len) FCHARL(cElemCompNameOut_len) );
INT FUNCTION  F2C_PutSxdiscData    ( INT *iSxmpIdxIn, 
                                     FCHAR(cVarNameIn), DOUBLE *dCurrValIn,
                                     INT *iElemDefTypeIn, FCHAR(cElemCompNameIn),
                                     INT *iNumElemOut, INT *iElemListIn,
                                     INT *iStatusIn
                                     FCHARL(cVarNameIn_len) FCHARL(cElemCompNameIn_len) );


INT FUNCTION  F2C_Sxrslt           ( FCHAR(cVarNameIn), INT *iEntyTypeIn, INT *iRstTypeIn, INT *iCompTypeIn,
                                     DOUBLE *dAccuracyIn,
                                     INT *iEntyDefTypeIn,
                                     FCHAR(cEntyCompNameIn), 
                                     INT *iNumEntyIn , INT *iEntyList 
                                     FCHARL(cVarNameIn_len) FCHARL(cEntyCompNameIn_len) );
INT FUNCTION  F2C_GetSxrsltData    ( INT *iSxrsltIdxIn, 
                                     FCHAR(cVarNameOut), INT *iEntyKeyOut, INT *iTypeIdOut, INT *iCompIdOut,
                                     DOUBLE *dAccuracyOut,
                                     INT *iEntyDefTypeOut,
                                     FCHAR(cEntyCompNameOut),
                                     INT *iNumEntyOut, INT *iStatusOut
                                     FCHARL(cVarNameOut_len) FCHARL(cEntyCompNameOut_len) );
INT FUNCTION  F2C_GetSxrsltEntyList( INT *iSxrsltIdxIn, INT *iNumEntyIn, INT *iEntyListOut );
INT FUNCTION  F2C_PutSxrsltData    ( INT *iSxrsltIdxIn,
                                     FCHAR(cVarNameIn), INT *iEntyKeyIn, INT *iTypeIdIn, INT *iCompIdIn,
                                     DOUBLE *dAccuracyIn,
                                     INT *iEntyDefTypeIn,
                                     FCHAR(cEntyCompNameIn),
                                     INT *iNumEntyIn, INT *iEntyListIn, INT *iStatusIn
                                     FCHARL(cVarNameIn_len) FCHARL(cEntyCompNameIn_len) );


INT FUNCTION  F2C_Sxvmod ( FCHAR(cVarNameIn), INT *iOperOptIn, DOUBLE *dCurrValIn, INT *iCheckValIn
                           FCHARL(cVarNameIn_len) );


INT FUNCTION  F2C_Sxrfil           ( FCHAR(cPathNameIn) , FCHAR(cPathNameIn2) 
				     FCHARL(cPathNameIn_len) FCHARL(cPathNameIn2_len) );
INT FUNCTION  F2C_QrySxrfilStatus  ( void );
INT FUNCTION  F2C_GetSxrfilPathName( FCHAR(cPathNameIn) FCHARL(cPathNameIn_len) );
INT FUNCTION  F2C_GetSxrfilPathName2( FCHAR(cPathNameIn) FCHARL(cPathNameIn_len) );
INT FUNCTION  F2C_PutSxrfilData    ( FCHAR(cPathNameIn), INT *iStatusIn FCHARL(cPathNameIn_len) );


INT FUNCTION  F2C_Sxmeth       ( INT *iSoluTypeIn, INT *iApprTypeIn, INT *iVerifyTypeIn, INT *iTrackTypeIn );
INT FUNCTION  F2C_GetSxmethData( INT *iSoluTypeOut, INT *iApprTypeOut, INT *iTrackTypeOut, INT *iStatusOut );
INT FUNCTION  F2C_PutSxmethData( INT *iSoluTypeIn, INT *iApprTypeIn, INT *iTrackTypeIn, INT *iStatusIn );


INT FUNCTION  F2C_QrySxSolvStatus( void );
INT FUNCTION  F2C_PutSxSolvStatus( INT *iSxSolvStatusIn );


INT FUNCTION  F2C_Sxeval      ( INT    *iPrintKeyIn,
                                INT    *iModeIdxIn,
                                INT    *iEntyKeyIn, INT *iTypeIdIn,
                                DOUBLE *dEigenFrequency,
                                INT    *iNumEnty,
                                INT    *iMaxResPerEnty,
                                LONG   *piEntyL,
                                LONG   *piNumResPerEntyL,
                                LONG   *pdResultL );

INT FUNCTION  F2C_Sxstat ( INT *iPrintEntyKeyIn );
INT FUNCTION  F2C_Sxclr  ( INT *iTypeIn, INT* iPrintKeyIn );
INT FUNCTION  F2C_Sxexit ( void );
INT FUNCTION  F2C_PutSxJobName( FCHAR(cNameIn) FCHARL(cNameIn_len));

INT FUNCTION F2C_GetSxVarTypeByVarName( FCHAR(cNameIn), INT *iVarType, INT *iVarIdx FCHARL(cNameIn_len) );
INT FUNCTION F2C_GetNumSxCmd ( INT *fVarType );
INT FUNCTION F2C_GetSxCmdElemList( INT *iSxCmdIdxIn, INT *iVarTypeIn, INT *iNumElemIn, INT *iElemListOut );
INT FUNCTION  F2C_GetSxinData( INT *iSxinIdxIn, 
                               FCHAR(cVarNameOut), DOUBLE *dCurrValOut, DOUBLE *dUserMinValOut, DOUBLE *dUserMaxValOut, 
                               INT *iRedOptOut, INT *iLoadTypeOut, INT *iLoadCompOut,
                               INT *iVariaTypeOut, INT *iOrderOut, 
                               INT *iStatusOut,
                               DOUBLE *dSolvMinValOut, DOUBLE *dSolvMaxValOut
                               FCHARL(cVarNameOut_len) );

INT FUNCTION F2C_Sxqa( INT *iActionIn, INT *iCritIn, INT *iInfoItemIn, FCHAR(pnameIn), 
		       INT *iNodeBoolIn, INT *iNodeIn, INT *iElemBoolIn, INT *iElemIn, 
		       INT *iCompBoolIn, FCHAR(cCompIn),
		       INT *iLayerIn, 
		       INT *iOptAbsIn, INT *iOptNegIn, INT *iOptGlobIn, INT *iOptMinIn, INT *iNumSensiPointsIn, INT *iNumRandomPointsIn
		       FCHARL(cpnameIn_len) FCHARL(cCompIn_len));

INT FUNCTION F2C_Sxoption(FCHAR(cCommandOptionIn), FCHAR(cNameOptionIn), FCHAR(cValOptionIn) FCHARL(cCommandOptionIn_len) FCHARL(cNameOptionIn_len) FCHARL(cValOptionIn_len));
       
INT FUNCTION  F2C_Sxsfe( FCHAR(cVarNameIn), DOUBLE *dCurrValIn, DOUBLE *dUserMinValIn, DOUBLE *dUserMaxValIn, 
	  INT *iRedOptIn,
	  INT *iSurfLoadTypeIn, INT *iLoadKeyIn,
	  INT *iElemDefTypeIn, FCHAR(cElemCompNameIn),
	  INT *iNumElemIn, INT *iElemListIn, INT *iElemTypeIn,
	  INT *iVariaTypeIn, INT *iOrderIn
	  FCHARL(cVarNameIn_len) FCHARL(cElemCompNameIn_len) );

INT FUNCTION  F2C_GetSxsfeData( INT *iSxsfeIdxIn, 
		 FCHAR(cVarNameOut), DOUBLE *dCurrValOut, DOUBLE *dUserMinValOut, DOUBLE *dUserMaxValOut, 
		 INT *iRedOptOut, INT *iSurfLoadTypeOut, INT *iLoadKeyOut,
		 INT *iElemDefTypeOut, FCHAR(cElemCompNameOut),
		 INT *iNumElemOut, INT *iElemTypeOut,
		 INT *iVariaTypeOut,
		 INT *iOrderOut, 
		 INT *iStatusOut,
		 DOUBLE *dSolvMinValOut, DOUBLE *dSolvMaxValOut
		 FCHARL(cVarNameOut_len) FCHARL(cElemCompNameOut_len) );

INT FUNCTION  F2C_PutSxsfeData( INT *iSxsfeIdxIn,
		 FCHAR(cVarNameIn), DOUBLE *dCurrValIn, DOUBLE *dUserMinValIn, DOUBLE *dUserMaxValIn, 
		 INT *iRedOptIn, INT *iSurfLoadTypeIn, INT *iLoadKeyIn,
		 INT *iElemDefTypeIn, FCHAR(cElemCompNameIn),
		 INT *iNumElemIn, INT *iElemListIn, INT *iElemTypeIn,
		 INT *iVariaTypeIn, INT *iOrderIn, 
		 INT *iStatusIn,
		 DOUBLE *dSolvMinValIn, DOUBLE *dSolvMaxValIn
		 FCHARL(cVarNameIn_len) FCHARL(cElemCompNameIn_len) );

/* FORTRAN functions called from C */
/* ------------------------------- */
/*
INT FUNCTION  C2F_Test( );
*/

#ifdef __cplusplus
}
#endif


#endif /* _SX_PROTOTYPES_CTOF_H_ */

