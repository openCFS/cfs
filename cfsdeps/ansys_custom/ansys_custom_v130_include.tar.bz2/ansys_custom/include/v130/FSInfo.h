/*****************************************************************************
 *                   Copyright (C) 1999 CMSoft                               *
 *                                                                           *
 *  These lines of code and declarations contain unpublished proprietary     *
 *  information of CMSoft. They may not be copied or duplicated in whole     *
 *  or part without prior authorization from CMSoft.                         *
 *                                                                           *
 *****************************************************************************/

#ifndef _FS_INFO_H_
#define _FS_INFO_H_

// maxiter = maximum number of FETI iterations
// maxorth = maximum number of reorthogonalization directions
// tol     = global tolerance

// Preconditioners:
// precond = 0       no preconditioner
// precond = 1       lumped            (default)
// precond = 2       dirichlet

// Projectors:
// nonLocalQ = 0	basic projector		(default)
// nonLocalQ = 1	Q(preconditioner type)  projector

// Scaling Methods:
// scaling = 0		tscaling (topology)
// scaling = 1		kscaling (stiffness)	(default)

// FETI Version:
// version = 0		FETI 1			(default)
// version = 1		FETI 2

// verbose
// verbose = 0         (default)
// verbose = 1         lots of screen output

// How often to print the error during iterations
// printNumber =  n     every n iterations

// rcvNodes indicates whether slave should expect nodes or not

class FSInfo {
public:
  FSInfo();
  string getPrecondName();
  string getScalingName();
  string getInterfaceSolverName();
  string getCpceMethodName();
  
  double _tol;			// tolerance (has to be at the first place!!!)
  double _maxtol;		// 
  double _final_residual;	// final residual reached
  double _skyTol;		// skyline tolerance to be used, default 1.0E-6
  double _bcsScale;		// to scale the size of the BCS workspace
  
  int    _maxiter;
  int    _maxorth;
  int    _maxDimQ;		// 
  int    _nonLocalQ;
  int    _verbose;
  int    _iterused;		// number of PCG/GMRES iterations
  int    _nbAx;			// number of matrix-vector product (FIrr * lambda)
  int    _stagnated;	       	// 0 - didn't stagnate 1 - stagnated
  int    _memOption;		// 1=incore, 2=opti, 3=ooc
  int    _antype; 
  int	 _edgeAugmentation;
  int	 _cornerOnMPC;
  int	 _conditionning;	// print conditionning of the matrices
  int	 _chkresults;
  int	 _timer;
  int    _checkAXmB;
  int	 _dumpMatrices;
  int	 _createCEs;
  int	 _subspaceid;
  int    _parametric;
  int    _cleanUp;
  int    _ktUpdate;
  int    _fetidpc;
  int    _freeSolvers;
  int    _level;
  
  E_SOLVER _KrrSolver;
  E_SOLVER _KccSolver;
  E_SOLVER _CtCSolver;
  
  enum Preconditioner { 
    noPrec = 1, 
    lumped, 
    dirichlet 
  } _precond;
  
  enum Scaling { 
    tscaling = 1,
    kscaling,
    wscaling
  } _scaling;
  
  enum CpceMethod {
    primal, 
    dual
  } _cpceMethod;
  
  enum InterfaceMethod {
    sparse,
    dense
  } _interfaceMethod;
};

#endif
