/*****************************************************************************
 *                   Copyright (C) 1999 CMSoft                               *
 *                                                                           *
 *  These lines of code and declarations contain unpublished proprietary     *
 *  information of CMSoft. They may not be copied or duplicated in whole     *
 *  or part without prior authorization from CMSoft.                         *
 *                                                                           *
 *****************************************************************************/

#include "ThreadManager.h"

#ifdef SUNOS
#include "ParalExecSun.h"
#else

#ifndef _FS_PARAL_EXEC_H_
#define _FS_PARAL_EXEC_H_

// Here is a weird bug of Visual C++
#ifndef PCWINNT_SYS

template <class DT, class A>
void paralExec(DT n, A *, void(A::*fct)(int));

template <class DT, class A, class Arg1, class PArg1>
void paralExec(DT n, A *a, void(A::*fct)(int, Arg1), PArg1 arg1);

template <class DT, class A,
          class Arg1,  class Arg2,
          class PArg1, class PArg2>
void paralExec(DT n, A *, void(A::*fct)(int, Arg1, Arg2),  PArg1, PArg2);

template <class DT, class A,
          class Arg1,  class Arg2,  class Arg3,
          class PArg1, class PArg2, class PArg3>
void paralExec(DT n, A *a, void(A::*fct)(int, Arg1, Arg2, Arg3),
                PArg1 arg1, PArg2 arg2, PArg3 arg3);

template <class DT, class A>
void paralApply(DT n, A **a, void(A::*fct)());

template <class DT, class A, class Arg1, class PArg1>
void paralApply(DT n, A **a, void(A::*fct)(Arg1), PArg1 arg1);

template <class DT, class A, 
          class Arg1,  class Arg2, 
          class PArg1, class PArg2>
void paralApply(DT n, A **a, void(A::*fct)(Arg1, Arg2),PArg1 arg1,PArg2 arg2);

template <class DT, class A, 
          class Arg1,  class Arg2,  class Arg3, 
          class PArg1, class PArg2, class PArg3>
void paralApply(DT n, A **a, void(A::*fct)(Arg1, Arg2, Arg3), 
                PArg1 arg1, PArg2 arg2, PArg3 arg3);

template <class DT, class A, 
          class Arg1,  class Arg2,  class Arg3,  class Arg4,
          class PArg1, class PArg2, class PArg3, class PArg4>
void paralApply(DT n, A **a, void(A::*fct)(Arg1,  Arg2,  Arg3, Arg4),
                     PArg1 arg1, PArg2 arg2, PArg3 arg3, PArg4 arg4);

template <class DT, class A,
          class Arg1, class Arg2,  class Arg3,  class Arg4,  class Arg5, 
          class PArg1,class PArg2, class PArg3, class PArg4, class PArg5>
void paralApply(DT n, A **a, void(A::*fct)(Arg1, Arg2, Arg3, Arg4, Arg5),
                PArg1 arg1, PArg2 arg2, PArg3 arg3, PArg4 arg4, PArg5 arg5);

template <class DT, class A,
          class Arg1, class Arg2, class Arg3, class Arg4, class Arg5, class Arg6,
          class PArg1,class PArg2,class PArg3,class PArg4,class PArg5,class PArg6>
void paralApply(DT n, A **a, void(A::*fct)(Arg1,Arg2,Arg3,Arg4,Arg5,Arg6),
             PArg1 arg1, PArg2 arg2, PArg3 arg3, PArg4 arg4, PArg5 arg5,PArg6 arg6);


template <class DT, class R, class A,
          class Arg1, class Arg2,
          class PArg1,class PArg2>
R paralSum(DT n, R initVal, A **a, R (A::*fct)(Arg1,Arg2), 
                 PArg1 arg1, PArg2);
#endif

#include "ThreadManager.h"

#ifdef PCWINNT_SYS

template <class A, class B>
class Indexer
{
        A   a;
        A *pa;
   public:
           Indexer(A  aa)  { a=aa; pa = 0; }
           Indexer(A *aa)  { pa = aa; }
           A access(int i) { return ((pa) ? pa[i] : a); }
};

#else

template <class A, class B>
class Indexer
{
};

template <class T>
class Indexer<T, T>
{
  T a;
 public:
  Indexer(T aa)   { a = aa;   }
  T access(int i) { return a; }
};

template <class T>
class Indexer<T, T*>
{
  T *a;
 public:
  Indexer(T *aa)  { a = aa;      }
  T access(int i) { return a[i]; }
};

#endif

template <class A>
class ParalExec0ArgOp : public FSTaskGroup {
     A *target;
     void(A::*fct)(int);
  public:
     ParalExec0ArgOp(A *t, void(A::*f)(int)) {target=t; fct=f; }

     void run(int);
};

template <class A>
void
ParalExec0ArgOp<A>::run(int itask)
{
 (target->*fct)(itask);
}

template <class DT, class A>
void paralExec(DT ntasks, A *targ, void(A::*fct)(int))
{
 ParalExec0ArgOp<A> taskGroup(targ,fct);

 G_fsThreadManager->execute(ntasks, taskGroup);
}
// --- One Argument Parallel Exec Class

template <class A, class Arg1, class PArg1>
class ParalExec1ArgOp : public FSTaskGroup {
     Indexer<Arg1, PArg1> parg1;
     A *target;
     void(A::*fct)(int, Arg1);
  public:
     ParalExec1ArgOp(A *a, void(A::*f)(int, Arg1), PArg1 a1) :
        parg1(a1), target(a), fct(f) { }
     void run(int);
};

template <class A, class Arg1, class PArg1>
void ParalExec1ArgOp<A, Arg1, PArg1>::run(int itask)
{
 (target->*fct)(itask, parg1.access(itask));
}

template <class DT, class A, class Arg1, class PArg1>
void paralExec(DT n, A *a, void(A::*fct)(int, Arg1), PArg1 arg1)
{
 ParalExec1ArgOp<A, Arg1, PArg1> taskGroup(a, fct, arg1);
 G_fsThreadManager->execute(n, taskGroup);
}

// --- Two Argument Parallel Exec Class

template <class A, class Arg1, class Arg2, class PArg1, class PArg2>
class ParalExec2ArgOp : public FSTaskGroup {
     Indexer<Arg1, PArg1> parg1;
     Indexer<Arg2, PArg2> parg2;
     A *target;
     void(A::*fct)(int, Arg1, Arg2);
  public:
     ParalExec2ArgOp(A *a, void(A::*f)(int, Arg1, Arg2), PArg1 a1, PArg2 a2) :
        parg1(a1), parg2(a2), target(a), fct(f) { }

     void run(int);
};

template <class A, class Arg1, class Arg2, class PArg1, class PArg2>
void ParalExec2ArgOp<A, Arg1, Arg2, PArg1, PArg2>::run(int itask)
{
 (target->*fct)(itask, parg1.access(itask), parg2.access(itask));
}


template <class DT, class A,
          class Arg1,  class Arg2,
          class PArg1, class PArg2>
void paralExec(DT n, A *a, void(A::*fct)(int, Arg1, Arg2),
                PArg1 arg1, PArg2 arg2)
{
 ParalExec2ArgOp<A,Arg1,Arg2,PArg1,PArg2> taskGroup(a,fct,arg1,arg2);
 G_fsThreadManager->execute(n, taskGroup);
}

// --- Zero Argument Parallel Apply Class

template <class A>
class ParalApply0ArgOp : public FSTaskGroup {
     A **target;
     void(A::*fct)();
  public:
     ParalApply0ArgOp(A **a, void(A::*f)()) :
        target(a), fct(f) { }
     void run(int);
};

template <class A>
void ParalApply0ArgOp<A>::run(int itask)
{
  (target[itask]->*fct)();
}

template <class DT, class A>
void paralApply(DT n, A **a, void(A::*fct)())
{
 ParalApply0ArgOp<A> taskGroup(a, fct);
 G_fsThreadManager->execute(n, taskGroup);
}
 
// --- One Argument Parallel Apply Class

template <class A, class Arg1, class PArg1>
class ParalApply1ArgOp : public FSTaskGroup {
     Indexer<Arg1, PArg1> parg1;
     A **target;
     void(A::*fct)(Arg1);
  public:
     ParalApply1ArgOp(A **a, void(A::*f)(Arg1), PArg1 a1) :
        parg1(a1), target(a), fct(f) { }
     void run(int);
};

template <class A, class Arg1, class PArg1>
void ParalApply1ArgOp<A, Arg1, PArg1>::run(int itask)
{
 (target[itask]->*fct)(parg1.access(itask));
}

template <class DT, class A, class Arg1, class PArg1>
void paralApply(DT n, A **a, void(A::*fct)(Arg1), PArg1 arg1)
{
 ParalApply1ArgOp<A, Arg1, PArg1> taskGroup(a, fct, arg1);
 G_fsThreadManager->execute(n, taskGroup);
}
 
// --- Two Argument Parallel Apply Class

template <class A, class Arg1, class Arg2, class PArg1, class PArg2>
class ParalApply2ArgOp : public FSTaskGroup {
     Indexer<Arg1, PArg1> parg1;
     Indexer<Arg2, PArg2> parg2;
     A **target;
     void(A::*fct)(Arg1, Arg2);
  public:
     ParalApply2ArgOp(A **a, void(A::*f)(Arg1, Arg2), PArg1 a1, PArg2 a2) :
        parg1(a1), parg2(a2), target(a), fct(f) { }
     
     void run(int);
};

template <class A, class Arg1, class Arg2, class PArg1, class PArg2>
void ParalApply2ArgOp<A, Arg1, Arg2, PArg1, PArg2>::run(int itask)
{
 (target[itask]->*fct)(parg1.access(itask), parg2.access(itask));
}

template <class DT, class A, class Arg1, class Arg2, class PArg1, class PArg2>
void paralApply(DT n, A **a, void(A::*fct)(Arg1, Arg2), PArg1 arg1, PArg2 arg2)
{
 ParalApply2ArgOp<A, Arg1, Arg2, PArg1, PArg2> taskGroup(a, fct, arg1, arg2);

 G_fsThreadManager->execute(n, taskGroup);
}

// --- Three Argument Parallel Apply Class

template <class A, class Arg1,  class Arg2,  class Arg3,
                   class PArg1, class PArg2, class PArg3>
class ParalApply3ArgOp : public FSTaskGroup {
     Indexer<Arg1, PArg1> parg1;
     Indexer<Arg2, PArg2> parg2;
     Indexer<Arg3, PArg3> parg3;
     A **target;
     void(A::*fct)(Arg1, Arg2, Arg3);
  public:
     ParalApply3ArgOp(A **a, void(A::*f)(Arg1, Arg2, Arg3), 
                      PArg1 a1, PArg2 a2, PArg3 a3) :
        parg1(a1), parg2(a2), parg3(a3), target(a), fct(f) { }

     void run(int);
};

template <class A, class Arg1,  class Arg2,  class Arg3,
                   class PArg1, class PArg2, class PArg3>
void ParalApply3ArgOp<A, Arg1, Arg2, Arg3, PArg1, PArg2, PArg3>::run(int itask)
{
 (target[itask]->*fct)(parg1.access(itask), parg2.access(itask),
                       parg3.access(itask));
}


template <class DT, class A, class Arg1,  class Arg2,  class Arg3,
                             class PArg1, class PArg2, class PArg3>
void paralApply(DT n, A **a, void(A::*fct)(Arg1,  Arg2,  Arg3),
                                            PArg1 a1, PArg2 a2, PArg3 a3)
{
 ParalApply3ArgOp<A,Arg1,Arg2,Arg3,PArg1,PArg2,PArg3> taskGroup(a,fct,a1,a2,a3);
 G_fsThreadManager->execute(n, taskGroup);
}

// --- Three Argument Parallel Exec Class

template <class A, class Arg1,  class Arg2,  class Arg3,
                   class PArg1, class PArg2, class PArg3>
class ParalExec3ArgOp : public FSTaskGroup {
     Indexer<Arg1, PArg1> parg1;
     Indexer<Arg2, PArg2> parg2;
     Indexer<Arg3, PArg3> parg3;
     A *target;
     void(A::*fct)(int, Arg1, Arg2, Arg3);
  public:
     ParalExec3ArgOp(A *a, void(A::*f)(int, Arg1, Arg2, Arg3),
                      PArg1 a1, PArg2 a2, PArg3 a3) :
        parg1(a1), parg2(a2), parg3(a3), target(a), fct(f) { }

     void run(int);
};

template <class A, class Arg1,  class Arg2,  class Arg3,
                   class PArg1, class PArg2, class PArg3>
void ParalExec3ArgOp<A, Arg1, Arg2, Arg3, PArg1, PArg2, PArg3>::run(int itask)
{
 (target->*fct)(itask, parg1.access(itask), parg2.access(itask),
                       parg3.access(itask));
}


template <class DT, class A, class Arg1,  class Arg2,  class Arg3,
                             class PArg1, class PArg2, class PArg3>
void paralExec(DT n, A *a, void(A::*fct)(int, Arg1,  Arg2,  Arg3),
                                            PArg1 a1, PArg2 a2, PArg3 a3)
{
 ParalExec3ArgOp<A,Arg1,Arg2,Arg3,PArg1,PArg2,PArg3> taskGroup(a,fct,a1,a2,a3); G_fsThreadManager->execute(n, taskGroup);
}

// --- Four Argument Parallel Apply

template <class A, class Arg1,  class Arg2,  class Arg3,  class Arg4,
                   class PArg1, class PArg2, class PArg3, class PArg4>
class ParalApply4ArgOp : public FSTaskGroup {
     Indexer<Arg1, PArg1> parg1;
     Indexer<Arg2, PArg2> parg2;
     Indexer<Arg3, PArg3> parg3;
     Indexer<Arg4, PArg4> parg4;
     A **target;
     void(A::*fct)(Arg1, Arg2, Arg3, Arg4);
  public:
     ParalApply4ArgOp(A **a, void(A::*f)(Arg1, Arg2, Arg3, Arg4),
                      PArg1 a1, PArg2 a2, PArg3 a3, PArg4 a4) :
        parg1(a1), parg2(a2), parg3(a3), parg4(a4), target(a), fct(f) { }

     void run(int);
};

template <class A, class Arg1,  class Arg2,  class Arg3,  class Arg4,
                   class PArg1, class PArg2, class PArg3, class PArg4>
void ParalApply4ArgOp<A, Arg1,  Arg2,  Arg3,  Arg4,
                        PArg1, PArg2, PArg3, PArg4>::run(int itask)
{
 (target[itask]->*fct)(parg1.access(itask), parg2.access(itask),
                       parg3.access(itask), parg4.access(itask));
}


template <class DT, class A, class Arg1,  class Arg2,  class Arg3,  class Arg4,
                             class PArg1, class PArg2, class PArg3, class PArg4>
void paralApply(DT n, A **a, void(A::*fct)(Arg1,  Arg2,  Arg3, Arg4),
                              PArg1 a1, PArg2 a2, PArg3 a3, PArg4 a4)
{
 ParalApply4ArgOp<A,Arg1, Arg2, Arg3, Arg4,
                   PArg1,PArg2,PArg3,PArg4> taskGroup(a,fct,a1,a2,a3,a4);
 G_fsThreadManager->execute(n, taskGroup);
}

// --- Five Argument Parallel Apply

template <class A,class Arg1, class Arg2,  class Arg3,  class Arg4, class Arg5,
                 class PArg1,class PArg2, class PArg3, class PArg4, class PArg5>
class ParalApply5ArgOp : public FSTaskGroup {
     Indexer<Arg1, PArg1> parg1;
     Indexer<Arg2, PArg2> parg2;
     Indexer<Arg3, PArg3> parg3;
     Indexer<Arg4, PArg4> parg4;
     Indexer<Arg5, PArg5> parg5;
     A **target;
     void(A::*fct)(Arg1, Arg2, Arg3, Arg4, Arg5);
  public:
     ParalApply5ArgOp(A **a, void(A::*f)(Arg1, Arg2, Arg3, Arg4, Arg5),
                      PArg1 a1, PArg2 a2, PArg3 a3, PArg4 a4, PArg5 a5) :
     parg1(a1), parg2(a2), parg3(a3), parg4(a4), parg5(a5), 
     target(a), fct(f) { }

     void run(int);
};

template <class A,class Arg1, class Arg2,  class Arg3,  class Arg4, class Arg5,
                 class PArg1,class PArg2, class PArg3, class PArg4, class PArg5>
void ParalApply5ArgOp<A, Arg1,  Arg2,  Arg3,  Arg4,  Arg5,
                        PArg1, PArg2, PArg3, PArg4, PArg5>::run(int itask)
{
 (target[itask]->*fct)(parg1.access(itask), parg2.access(itask),
                       parg3.access(itask), parg4.access(itask),
                       parg5.access(itask));
}



template <class DT,class A, 
          class Arg1, class Arg2,  class Arg3,  class Arg4,  class Arg5,
          class PArg1,class PArg2, class PArg3, class PArg4, class PArg5>
void paralApply(DT n, A **a, void(A::*fct)(Arg1,  Arg2,  Arg3, Arg4, Arg5),
                PArg1 a1, PArg2 a2, PArg3 a3, PArg4 a4, PArg5 a5)
{
 ParalApply5ArgOp<A,Arg1, Arg2, Arg3, Arg4, Arg5,
                   PArg1,PArg2,PArg3,PArg4,PArg5> 
                  taskGroup(a,fct,a1,a2,a3,a4,a5);
 G_fsThreadManager->execute(n, taskGroup);
}

// Six argument parallel apply function
template <class A,
          class Arg1, class Arg2, class Arg3, 
          class Arg4, class Arg5, class Arg6,
          class PArg1,class PArg2, class PArg3,
          class PArg4, class PArg5, class PArg6>
class ParalApply6ArgOp : public FSTaskGroup {
     Indexer<Arg1, PArg1> parg1;
     Indexer<Arg2, PArg2> parg2;
     Indexer<Arg3, PArg3> parg3;
     Indexer<Arg4, PArg4> parg4;
     Indexer<Arg5, PArg5> parg5;
     Indexer<Arg6, PArg6> parg6;
     A **target;
     void(A::*fct)(Arg1, Arg2, Arg3, Arg4, Arg5, Arg6);
  public:
     ParalApply6ArgOp(A **a, void(A::*f)(Arg1, Arg2, Arg3, Arg4, Arg5, Arg6),
                      PArg1 a1, PArg2 a2, PArg3 a3, PArg4 a4, PArg5 a5,
                      PArg6 a6) :
     parg1(a1), parg2(a2), parg3(a3), parg4(a4), parg5(a5),parg6(a6),
     target(a), fct(f) { }

     void run(int);
};

template <class A,class Arg1,class Arg2,class Arg3,class Arg4,class Arg5,
          class Arg6,class PArg1,class PArg2, class PArg3, class PArg4,                   class PArg5, class PArg6>
void ParalApply6ArgOp<A, Arg1,  Arg2,  Arg3,  Arg4,  Arg5, Arg6,
                     PArg1, PArg2, PArg3, PArg4, PArg5, PArg6>::run(int itask)
{
 (target[itask]->*fct)(parg1.access(itask), parg2.access(itask),
                       parg3.access(itask), parg4.access(itask),
                       parg5.access(itask), parg6.access(itask));
}

template <class DT, class A,
          class Arg1, class Arg2, class Arg3, class Arg4, class Arg5,  class Arg6,
          class PArg1,class PArg2,class PArg3,class PArg4,class PArg5, class PArg6>
void paralApply(DT n, A **a, void(A::*fct)(Arg1,Arg2,Arg3,Arg4,Arg5,Arg6),
     PArg1 a1, PArg2 a2, PArg3 a3, PArg4 a4, PArg5 a5,PArg6 a6)
{
 ParalApply6ArgOp<A,Arg1, Arg2, Arg3, Arg4, Arg5,  Arg6,
                   PArg1,PArg2,PArg3,PArg4,PArg5, PArg6> 
                  taskGroup(a,fct,a1,a2,a3,a4,a5,a6);
 G_fsThreadManager->execute(n, taskGroup);
}

// Sevan argument parallel apply function
template <class A,
          class Arg1, class Arg2, class Arg3, 
          class Arg4, class Arg5, class Arg6, class Arg7,
          class PArg1,class PArg2, class PArg3,
          class PArg4, class PArg5, class PArg6, class PArg7>
class ParalApply7ArgOp : public FSTaskGroup {
     Indexer<Arg1, PArg1> parg1;
     Indexer<Arg2, PArg2> parg2;
     Indexer<Arg3, PArg3> parg3;
     Indexer<Arg4, PArg4> parg4;
     Indexer<Arg5, PArg5> parg5;
     Indexer<Arg6, PArg6> parg6;
     Indexer<Arg7, PArg7> parg7;
     A **target;
     void(A::*fct)(Arg1, Arg2, Arg3, Arg4, Arg5, Arg6, Arg7);
  public:
     ParalApply7ArgOp(A **a, void(A::*f)(Arg1, Arg2, Arg3, Arg4, Arg5, Arg6, Arg7),
                      PArg1 a1, PArg2 a2, PArg3 a3, PArg4 a4, PArg5 a5,
                      PArg6 a6, PArg7 a7) :
       parg1(a1), parg2(a2), parg3(a3), parg4(a4), parg5(a5), parg6(a6), parg7(a7),
     target(a), fct(f) { }

     void run(int);
};

template <class A,class Arg1,class Arg2,class Arg3,class Arg4,class Arg5,class Arg6,class Arg7,
	class PArg1,class PArg2, class PArg3, class PArg4, class PArg5, class PArg6, class PArg7>
void ParalApply7ArgOp<A, Arg1,  Arg2,  Arg3,  Arg4,  Arg5, Arg6, Arg7, 
                     PArg1, PArg2, PArg3, PArg4, PArg5, PArg6, PArg7>::run(int itask)
{
 (target[itask]->*fct)(parg1.access(itask), parg2.access(itask),
                       parg3.access(itask), parg4.access(itask),
                       parg5.access(itask), parg6.access(itask),
		       parg7.access(itask));
}

template <class DT, class A,
          class Arg1, class Arg2, class Arg3, class Arg4, class Arg5,  class Arg6, class Arg7,
          class PArg1,class PArg2,class PArg3,class PArg4,class PArg5, class PArg6, class PArg7>
void paralApply(DT n, A **a, void(A::*fct)(Arg1,Arg2,Arg3,Arg4,Arg5,Arg6,Arg7),
     PArg1 a1, PArg2 a2, PArg3 a3, PArg4 a4, PArg5 a5, PArg6 a6, PArg7 a7)
{
  ParalApply7ArgOp<A,Arg1, Arg2, Arg3, Arg4, Arg5, Arg6, Arg7,
                   PArg1,PArg2,PArg3,PArg4,PArg5,PArg6,PArg7> 
                  taskGroup(a,fct,a1,a2,a3,a4,a5,a6,a7);
 G_fsThreadManager->execute(n, taskGroup);
}

// Eight argument parallel apply function
template <class A,
          class Arg1, class Arg2, class Arg3, 
          class Arg4, class Arg5, class Arg6, class Arg7,
          class Arg8, 
          class PArg1,class PArg2, class PArg3,
          class PArg4, class PArg5, class PArg6, class PArg7, 
          class PArg8>
class ParalApply8ArgOp : public FSTaskGroup {
     Indexer<Arg1, PArg1> parg1;
     Indexer<Arg2, PArg2> parg2;
     Indexer<Arg3, PArg3> parg3;
     Indexer<Arg4, PArg4> parg4;
     Indexer<Arg5, PArg5> parg5;
     Indexer<Arg6, PArg6> parg6;
     Indexer<Arg7, PArg7> parg7;
     Indexer<Arg8, PArg8> parg8;
     A **target;
     void(A::*fct)(Arg1, Arg2, Arg3, Arg4, Arg5, Arg6, Arg7, Arg8);
  public:
     ParalApply8ArgOp(A **a, void(A::*f)(Arg1, Arg2, Arg3, Arg4, Arg5, Arg6, Arg7, Arg8),
                      PArg1 a1, PArg2 a2, PArg3 a3, PArg4 a4, PArg5 a5,
                      PArg6 a6, PArg7 a7, PArg8 a8) :
       parg1(a1), parg2(a2), parg3(a3), parg4(a4), parg5(a5), parg6(a6), parg7(a7), parg8(a8), 
     target(a), fct(f) { }

     void run(int);
};

template <class A,class Arg1,class Arg2,class Arg3,class Arg4,class Arg5,class Arg6,class Arg7, class Arg8, 
	class PArg1,class PArg2, class PArg3, class PArg4, class PArg5, class PArg6, class PArg7, class PArg8>
void ParalApply8ArgOp<A, Arg1,  Arg2,  Arg3,  Arg4,  Arg5, Arg6, Arg7, Arg8,
                     PArg1, PArg2, PArg3, PArg4, PArg5, PArg6, PArg7, PArg8>::run(int itask)
{
 (target[itask]->*fct)(parg1.access(itask), parg2.access(itask),
                       parg3.access(itask), parg4.access(itask),
                       parg5.access(itask), parg6.access(itask),
		       parg7.access(itask), parg8.access(itask));
}

template <class DT, class A,
          class Arg1, class Arg2, class Arg3, class Arg4, class Arg5,  class Arg6, class Arg7, class Arg8,
          class PArg1,class PArg2,class PArg3,class PArg4,class PArg5, class PArg6, class PArg7, class PArg8>
void paralApply(DT n, A **a, void(A::*fct)(Arg1,Arg2,Arg3,Arg4,Arg5,Arg6,Arg7,Arg8),
     PArg1 a1, PArg2 a2, PArg3 a3, PArg4 a4, PArg5 a5, PArg6 a6, PArg7 a7, PArg8 a8)
{
  ParalApply8ArgOp<A,Arg1, Arg2, Arg3, Arg4, Arg5, Arg6, Arg7, Arg8, 
                   PArg1,PArg2,PArg3,PArg4,PArg5,PArg6,PArg7,PArg8> 
                  taskGroup(a,fct,a1,a2,a3,a4,a5,a6,a7,a8);
 G_fsThreadManager->execute(n, taskGroup);
}

// Nine argument parallel apply function
template <class A,
          class Arg1, class Arg2, class Arg3, 
          class Arg4, class Arg5, class Arg6, class Arg7,
          class Arg8, class Arg9,
          class PArg1,class PArg2, class PArg3,
          class PArg4, class PArg5, class PArg6, class PArg7, 
          class PArg8, class PArg9>
class ParalApply9ArgOp : public FSTaskGroup {
     Indexer<Arg1, PArg1> parg1;
     Indexer<Arg2, PArg2> parg2;
     Indexer<Arg3, PArg3> parg3;
     Indexer<Arg4, PArg4> parg4;
     Indexer<Arg5, PArg5> parg5;
     Indexer<Arg6, PArg6> parg6;
     Indexer<Arg7, PArg7> parg7;
     Indexer<Arg8, PArg8> parg8;
     Indexer<Arg9, PArg9> parg9;
     A **target;
     void(A::*fct)(Arg1, Arg2, Arg3, Arg4, Arg5, Arg6, Arg7, Arg8, Arg9);
  public:
     ParalApply9ArgOp(A **a, void(A::*f)(Arg1, Arg2, Arg3, Arg4, Arg5, Arg6, Arg7, Arg8, Arg9),
                      PArg1 a1, PArg2 a2, PArg3 a3, PArg4 a4, PArg5 a5,
                      PArg6 a6, PArg7 a7, PArg8 a8, PArg9 a9) :
       parg1(a1), parg2(a2), parg3(a3), parg4(a4), parg5(a5), parg6(a6), parg7(a7), parg8(a8), parg9(a9),
     target(a), fct(f) { }

     void run(int);
};

template <class A,class Arg1,class Arg2,class Arg3,class Arg4,class Arg5,class Arg6,class Arg7, class Arg8, class Arg9,
	class PArg1,class PArg2, class PArg3, class PArg4, class PArg5, class PArg6, class PArg7, class PArg8, class PArg9>
void ParalApply9ArgOp<A, Arg1,  Arg2,  Arg3,  Arg4,  Arg5, Arg6, Arg7, Arg8, Arg9,
                     PArg1, PArg2, PArg3, PArg4, PArg5, PArg6, PArg7, PArg8, PArg9>::run(int itask)
{
 (target[itask]->*fct)(parg1.access(itask), parg2.access(itask),
                       parg3.access(itask), parg4.access(itask),
                       parg5.access(itask), parg6.access(itask),
		       parg7.access(itask), parg8.access(itask),
                       parg9.access(itask));
}

template <class DT, class A,
          class Arg1, class Arg2, class Arg3, class Arg4, class Arg5,  class Arg6, class Arg7, class Arg8, class Arg9,
          class PArg1,class PArg2,class PArg3,class PArg4,class PArg5, class PArg6, class PArg7, class PArg8, class PArg9>
void paralApply(DT n, A **a, void(A::*fct)(Arg1,Arg2,Arg3,Arg4,Arg5,Arg6,Arg7,Arg8,Arg9),
     PArg1 a1, PArg2 a2, PArg3 a3, PArg4 a4, PArg5 a5, PArg6 a6, PArg7 a7, PArg8 a8, PArg9 a9)
{
  ParalApply9ArgOp<A,Arg1, Arg2, Arg3, Arg4, Arg5, Arg6, Arg7, Arg8, Arg9,
                   PArg1,PArg2,PArg3,PArg4,PArg5,PArg6,PArg7,PArg8,PArg9> 
                  taskGroup(a,fct,a1,a2,a3,a4,a5,a6,a7,a8,a9);
 G_fsThreadManager->execute(n, taskGroup);
}

// --- One Argument Parallel PartialSum Class

template <class R, class A, class Arg1, class PArg1>
class ParalSum1ArgOp : public FSTaskGroup {
     R initVal, *pSums;
     Indexer<Arg1, PArg1> parg1;
     A **target;
     R (A::*fct)(Arg1);
  public:
     ParalSum1ArgOp(R iv, R *ps, A **a, R (A::*f)(Arg1),
                    PArg1 a1) :
        initVal(iv), pSums(ps), parg1(a1), target(a), fct(f) { }

     void run(int);
};

template <class R, class A, class Arg1, class PArg1>
void ParalSum1ArgOp<R, A, Arg1,PArg1>::run(int itask)
{
 pSums[itask] = (target[itask]->*fct)(parg1.access(itask));
}

template <class DT, class R, class A, class Arg1, class PArg1>
R paralSum(DT n, R initVal, A **a, R (A::*fct)(Arg1), PArg1 arg1)
{
 R *partialSums = (R *) allocad(sizeof(R)* n); // not good MLX

 ParalSum1ArgOp<R,A,Arg1,PArg1> taskGroup(initVal, partialSums, a, fct, arg1);

 G_fsThreadManager->execute(n, taskGroup);
 R res(initVal);
 int i;
 for(i = 0; i < n; ++i)
   res += partialSums[i];
 return res;
}



// --- Two Argument Parallel PartialSum Class

template <class R, class A, class Arg1, class Arg2, class PArg1, class PArg2>
class ParalSum2ArgOp : public FSTaskGroup {
     R initVal, *pSums;
     Indexer<Arg1, PArg1> parg1;
     Indexer<Arg2, PArg2> parg2;
     A **target;
     R (A::*fct)(Arg1, Arg2);
  public:
     ParalSum2ArgOp(R iv, R *ps, A **a, R (A::*f)(Arg1, Arg2),
                    PArg1 a1, PArg2 a2) :
        initVal(iv), pSums(ps), parg1(a1), parg2(a2), target(a), fct(f) { }

     void run(int);
};

template <class R, class A, class Arg1, class Arg2, class PArg1, class PArg2>
void ParalSum2ArgOp<R, A, Arg1, Arg2, PArg1, PArg2>::run(int itask)
{
 pSums[itask] =
  (target[itask]->*fct)(parg1.access(itask), parg2.access(itask));
}


template <class DT, class R, class A,
          class Arg1, class Arg2,
          class PArg1,class PArg2>
R paralSum(DT n, R initVal, A **a, R (A::*fct)(Arg1,Arg2), 
                 PArg1 arg1, PArg2 arg2)
{
 R *partialSums = (R *) malloc(sizeof(R)* n); // not good MLX

 ParalSum2ArgOp<R,A,Arg1, Arg2, PArg1,PArg2> 
    taskGroup(initVal, partialSums, a, fct, arg1,arg2);

 G_fsThreadManager->execute(n, taskGroup);
 R res(initVal);
 int i;
 for(i = 0; i < n; ++i)
   res += partialSums[i];
 return res;
}

#endif
#endif
