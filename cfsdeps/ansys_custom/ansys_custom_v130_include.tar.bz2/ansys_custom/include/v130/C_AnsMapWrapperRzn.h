////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         copyright(c) 2006 SAS IP, Inc.  All rights reserved.           //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: C_AnsMapWrapperRzn.h $
// $Revision: 1.5 $ 7.0
// $Date: 2009/11/13 16:19:03 $ October 04 2005
// $Author: smukherj
//
// Description :
// Header file for wrapper of a integer STL map which can be used in Fortran
// data structures. Hides the implementation under 1 abastraction layer.
////////////////////////////////////////////////////////////////////////////

#pragma once
#ifndef __C_ANSMAPWRAPPERRZN_H__     
#define __C_ANSMAPWRAPPERRZN_H__       1

#if defined (SGIR8K_SYS)
    #pragma set woff 584,584
#else
    #pragma warning(disable: 584)
#endif

// headers required
#include "ANS_StandardIncludes.h"
#include "C_AnsProtoRzn.h"
#include "ANS_Allocator.h"

// use the ansys memory manager for the allocation of memory 
#define RZN_MALLOC(x)  cAnsMemAlloc((x),0,__FILE__,__LINE__)
#define RZN_FREE(x)    cAnsMemFree((x),__FILE__,__LINE__)
#define RZN_NEW(x,y)   (x*)cAnsMemAlloc(sizeof(x)*y,0,__FILE__,__LINE__)
#define RZN_DELETE(x)  cAnsMemFree((x),__FILE__,__LINE__)

// reference map allocation from C_AnsMeshDefRzn.h
//typedef pair<const unsigned long, Ans3DNodeRzn*>                                        ANS_3DNODE_PAIR;
//typedef ANS_Allocator<ANS_3DNODE_PAIR>                                                  ANS_Map3DNodeRznAllocator;
//typedef map<unsigned long, Ans3DNodeRzn*,less<unsigned long>,ANS_Map3DNodeRznAllocator> ANS_3DNODE_MAP;
//typedef ANS_3DNODE_MAP::iterator                                                        ANS_3DNODE_ITER;
//typedef ANS_Allocator<AnsNodeRzn* >                                                     ANS_NodeRznAllocator;
//typedef vector<AnsNodeRzn*, ANS_NodeRznAllocator>                                       ANS_NodeRznVector;

// custom allocators,pairs,maps and iterators
typedef pair<const unsigned long, unsigned long >                                       ANS_ULPair;
typedef ANS_Allocator<ANS_ULPair>                                                       ANS_ULPairAllocator;
typedef multimap<unsigned long, unsigned long ,less<unsigned long>,ANS_ULPairAllocator> ANS_ULMULTIMAP;
typedef ANS_ULMULTIMAP::iterator                                                        ANS_ULMULTIMAP_ITER;
typedef ANS_Allocator<unsigned long >                                                   ANS_ULAllocator;
typedef std::vector<unsigned long , ANS_ULAllocator>                                    ANS_ULVector;


//======================================================================================//
//                               class AnsMapWrapperRzn
//======================================================================================//
// DESCRIPTION: 
// 
//
// PARENTS: 
// None.                                                                                                                                                                    
//                                                                                      
// CONTENTS:                                                                                                                                                       
// None.
//======================================================================================//

class AnsMapWrapperRzn
{
    public:
        // lifecycle operators       
        AnsMapWrapperRzn(AnsMapWrapperRzn &oObj)
        {
            exit(0);
        }
        static AnsMapWrapperRzn *Instance(void);
        static void Destroy();
                                 
        // overloading 'new' for single variable 
        inline void *operator new(size_t iSize)        
        {
            return RZN_MALLOC(iSize);
        }
        // overloading 'new' for arrays
        inline void *operator new[](size_t iSize)
        {
            return RZN_MALLOC(iSize);
        }
        // overloading 'delete' for single variables
        inline void operator delete(void * pMemPtr)
        {            
            RZN_FREE(pMemPtr) ;
        }
        // overlaoding 'delete' for arrays
        inline void operator delete[](void * pMemPtr )
        {
            RZN_FREE(pMemPtr) ;
        }
        // load data as nonunique pair
        inline void PutPairData(unsigned long &iKey,
                                unsigned long &iData)
        {
	        m_oDataMap.insert(ANS_ULPair(iKey, iData));
            return;
        }
        // given the key, return the number of data elements
        int GetNumDataElem(unsigned long &);
        // get the data elements
        unsigned long GetDataElem(const int &);
        // gets size of map
        inline int GetSize(void)const
        {
            return (int )m_oDataMap.size();
        }
        // return the pointer
        inline AnsMapWrapperRzn* ReturnThis(void)
        {
            return (AnsMapWrapperRzn *)this;
        }
         inline void ClearData(void)
        {
            m_oDataMap.clear();
            m_vCurrKeyData.clear();
            m_iCurrKey = 0;
        }

    protected:       
        // multimap data structure holding main data
        ANS_ULMULTIMAP   m_oDataMap;
        // current key for retrieval
        unsigned long    m_iCurrKey;
        // current vector for retrieval
        ANS_ULVector     m_vCurrKeyData; 
        // delete the contaners
       
        virtual ~AnsMapWrapperRzn()
        { 
            ClearData();
        }                         

    private:
        static bool             m_bInstanceFlag;
        static AnsMapWrapperRzn *m_CreateEntity;
        // private constructor
        AnsMapWrapperRzn()
        {
	        // static constructor                
        }        
};//AnsMapWrapperRzn

#endif


