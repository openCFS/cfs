/* sid 30.15 copy of MAT_Api.cpp last changed by rjayasee on 2003/04/01 17:00:41 */

/*
////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         Copyright (C) 2010 ANSYS Inc.  All Rights Reserved             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: cAnsTclTkCurveFit.cpp $
// $Revision: 1.1 $
// $Date: 2010/04/07 14:22:20 $  March 28 2002
// $Author: srpailla $ rjayasee
//
// Description :
//  Implements Curve Fitting Tcl/Tk Interface
///////////////////////////////////////////////////////////////////////////
*/

#ifndef CANSTCLTKCURVEFIT
#define CANSTCLTKCURVEFIT

#include <string.h>
#include <math.h>

#include "libAnsTclTk.h"
#include "globals.h"
/* header for ANSYS query API */
#include "cAnsQuery.h"

/* tcl header */
#include "tcl.h"

/*
#ifdef __cplusplus
extern "C"
{
#endif
*/
  #undef const

  static int cAnsTclTkCurveFitGetFittedData ( ClientData clientData, Tcl_Interp *pInterp,
                      int iNumObjects, Tcl_Obj * const pObjectArray[] ) ;
/*
#ifdef __cplusplus
}
#endif
*/

#endif
