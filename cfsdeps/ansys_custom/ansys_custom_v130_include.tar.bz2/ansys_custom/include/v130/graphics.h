/****************************************************/
/******  include file used for graphic routines *****/
/****************************************************/
/* 
 * ***  copyright(c) 2010 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */

#if defined(RS6000_SYS) || defined(HP32_SYS)
    /*  c routines called from fortran  */
#define decimate_     decimate
#define tri_strip_    tri_strip
#define d2dith_       d2dith
#define pdp_yclp_     pdp_yclp
#define z33txt_       z33txt
#define z2mnmx_       z2mnmx
#define z2line_       z2line
#define z2area_       z2area
#define z2move_       z2move
#define z2logo_       z2logo
#define z2alph_       z2alph
#define z2wwhh_       z2wwhh
#define z2font_       z2font
#define z2info_       z2info
#define z2inqr_       z2inqr
#define z2wind_       z2wind
#define iqlook_       iqlook
#define iqpack_       iqpack
#define d2rfnt_       d2rfnt
#define d3rlab_init_  d3rlab_init
#define d3rlab_fini_  d3rlab_fini
#define zbuf_init_    zbuf_init
#define zbuf_copy_    zbuf_copy
#define zbuf_z3line_  zbuf_z3line
#define zbuf_z3flat_  zbuf_z3flat
#define zbuf_z3gour_  zbuf_z3gour
#define zbuf_z3phon_  zbuf_z3phon
#define zbuf2_init_   zbuf2_init
#define zbuf2_copy_   zbuf2_copy
#define zbuf2_z3line_ zbuf2_z3line
#define zbuf2_z3flat_ zbuf2_z3flat
#define zbuf2_z3gour_ zbuf2_z3gour
#define zbuf2_z3phon_ zbuf2_z3phon
#define zbuf2_d2lwid_ zbuf2_d2lwid
#define wtitlset_     wtitlset
#define gr_startanim_ gr_startanim
#define gr_anim_io_   gr_anim_io
#define gr_start_macro_ gr_start_macro
#define gr_end_macro_   gr_end_macro
#define gr_demo_      gr_demo
#define zbuf2_d2tran_  zbuf2_d2tran
#define hc_writefile_  hc_writefile
    /*  fortran routines called from c  */
#define draw_cell_    draw_cell
#define gr_docu_sort_ gr_docu_sort
#define gr_ang_       gr_ang
#define gr_angs_      gr_angs
#define gr_fang_      gr_fang
#define d2rl33_slow_  d2rl33_slow
#define d3rlxx_slow_  d3rlxx_slow
#define d2rlzz_slow_  d2rlzz_slow
#define d3rlxx_fast_  d3rlxx_fast
#define d2rlzz_fast_  d2rlzz_fast
#define d3qlxx_fast_  d3qlxx_fast
#define d2qlzz_fast_  d2qlzz_fast
#define vdot_         vdot
#define vnorm_        vnorm
#define gr_drawseg_   gr_drawseg
#define gr_savewin_   gr_savewin
#define icmdmac_      icmdmac
#define syssec_       syssec
#define timget_       timget
#define d3tris_       d3tris
#define d3tfan_       d3tfan
#define sectionpreview_ sectionpreview
#define sectionpreview1_ sectionpreview1
#define beaminquire_    beaminquire
#define get_cmp_iname_    get_cmp_iname
#define pdp_rv_graph_     pdp_rv_graph
#define pdp_hist_         pdp_hist
#define pdp_cdf_          pdp_cdf
#define pdp_samp_         pdp_samp
#define pdp_scat_         pdp_scat
#define pdp_sens_         pdp_sens
#define pdp_rs3d_         pdp_rs3d
#endif

#if defined(WATCOMC_SYS) \
    || defined(PCWINNT_SYS)
    /*  c routines called from fortran  */
#define decimate_     DECIMATE
#define tri_strip_    TRI_STRIP
#define d2dith_       D2DITH
#define pdp_yclp_     PDP_YCLP
#define z33txt_       Z33TXT
#define z2mnmx_       Z2MNMX
#define z2line_       Z2LINE
#define z2area_       Z2AREA
#define z2move_       Z2MOVE
#define z2logo_       Z2LOGO
#define z2alph_       Z2ALPH
#define z2wwhh_       Z2WWHH
#define z2font_       Z2FONT
#define z2info_       Z2INFO
#define z2inqr_       Z2INQR
#define z2wind_       Z2WIND
#define iqlook_       IQLOOK
#define iqpack_       IQPACK
#define d2rfnt_       D2RFNT
#define d3rlab_init_  D3RLAB_INIT
#define d3rlab_fini_  D3RLAB_FINI
#define zbuf_init_    ZBUF_INIT
#define zbuf_copy_    ZBUF_COPY
#define zbuf_z3line_  ZBUF_Z3LINE
#define zbuf_z3flat_  ZBUF_Z3FLAT
#define zbuf_z3gour_  ZBUF_Z3GOUR
#define zbuf_z3phon_  ZBUF_Z3PHON
#define zbuf2_init_   ZBUF2_INIT
#define zbuf2_copy_   ZBUF2_COPY
#define zbuf2_z3line_ ZBUF2_Z3LINE
#define zbuf2_z3flat_ ZBUF2_Z3FLAT
#define zbuf2_z3gour_ ZBUF2_Z3GOUR
#define zbuf2_z3phon_ ZBUF2_Z3PHON
#define zbuf2_d2lwid_ ZBUF2_D2LWID
#define wtitlset_     WTITLSET
#define gr_startanim_ GR_STARTANIM
#define gr_anim_io_   GR_ANIM_IO
#define gr_start_macro_ GR_START_MACRO
#define gr_end_macro_   GR_END_MACRO
#define gr_demo_      GR_DEMO
#define zbuf2_d2tran_  ZBUF2_D2TRAN
#define hc_writefile_  HC_WRITEFILE
    /*  fortran routines called from c  */
#define draw_cell_    DRAW_CELL
#define gr_docu_sort_ GR_DOCU_SORT
#define gr_ang_       GR_ANG
#define gr_angs_      GR_ANGS
#define gr_fang_      GR_FANG
#define d2rl33_slow_  D2RL33_SLOW
#define d3rlxx_slow_  D3RLXX_SLOW
#define d2rlzz_slow_  D2RLZZ_SLOW
#define d3rlxx_fast_  D3RLXX_FAST
#define d2rlzz_fast_  D2RLZZ_FAST
#define d3qlxx_fast_  D3QLXX_FAST
#define d2qlzz_fast_  D2QLZZ_FAST
#define vdot_         VDOT
#define vnorm_        VNORM
#define gr_drawseg_   GR_DRAWSEG
#define gr_savewin_   GR_SAVEWIN
#define icmdmac_      ICMDMAC
#define syssec_       SYSSEC
#define timget_       TIMGET
#define d3tris_       D3TRIS
#define d3tfan_       D3TFAN
#define sectionpreview_ SECTIONPREVIEW
#define sectionpreview1_ SECTIONPREVIEW1
#define beaminquire_    BEAMINQUIRE
#define get_cmp_iname_  GET_CMP_INAME
#define pdp_rv_graph_   PDP_RV_GRAPH
#define pdp_hist_       PDP_HIST
#define pdp_cdf_        PDP_CDF
#define pdp_samp_       PDP_SAMP
#define pdp_scat_       PDP_SCAT
#define pdp_sens_       PDP_SENS
#define pdp_rs3d_       PDP_RS3D
#endif

#if defined(WATCOMC_SYS) 
    /*  c routines called from fortran  */
#pragma aux DECIMATE "^";
#pragma aux TRI_STRIP "^";
#pragma aux D2DITH "^";
#pragma aux PDP_YCLP "^";
#pragma aux Z33TXT "^";
#pragma aux Z2MNMX "^";
#pragma aux Z2LINE "^";
#pragma aux Z2AREA "^";
#pragma aux Z2MOVE "^";
#pragma aux Z2LOGO "^";
#pragma aux Z2ALPH "^";
#pragma aux Z2WWHH "^";
#pragma aux Z2FONT "^";
#pragma aux Z2INFO "^";
#pragma aux Z2INQR "^";
#pragma aux Z2WIND "^";
#pragma aux IQLOOK "^";
#pragma aux IQPACK "^";
#pragma aux D2RFNT "^";
#pragma aux D3RLAB_INIT "^";
#pragma aux D3RLAB_FINI "^";
#pragma aux ZBUF_INIT "^";
#pragma aux ZBUF_COPY "^";
#pragma aux ZBUF_Z3LINE "^";
#pragma aux ZBUF_Z3FLAT "^";
#pragma aux ZBUF_Z3GOUR "^";
#pragma aux ZBUF_Z3PHON "^";
#pragma aux ZBUF2_INIT "^";
#pragma aux ZBUF2_COPY "^";
#pragma aux ZBUF2_Z3LINE "^";
#pragma aux ZBUF2_Z3FLAT "^";
#pragma aux ZBUF2_Z3GOUR "^";
#pragma aux ZBUF2_Z3PHON "^";
#pragma aux ZBUF2_D2LWID "^";
#pragma aux WTITLSET    "^";
#pragma aux GR_STARTANIM "^";
#pragma aux GR_ANIM_IO "^";
#pragma aux GR_RESUMEANIM "^";
#pragma aux GR_START_MACRO "^";
#pragma aux GR_END_MACRO "^";
#pragma aux GR_DEMO "^";
#pragma aux ZBUF2_D2TRAN "^";
#pragma aux HC_WRITEFILE "^";
    /*  fortran routines called from c  */
#pragma aux DRAW_CELL "^";
#pragma aux GR_DOCU_SORT "^";
#pragma aux GR_ANG "^";
#pragma aux GR_ANGS "^";
#pragma aux GR_FANG "^";
#pragma aux D2RL33_SLOW "^";
#pragma aux D3RLXX_SLOW "^";
#pragma aux D2RLZZ_SLOW "^";
#pragma aux D3RLXX_FAST "^";
#pragma aux D2RLZZ_FAST "^";
#pragma aux D3QLXX_FAST "^";
#pragma aux D2QLZZ_FAST "^";
#pragma aux VDOT "^";
#pragma aux VNORM "^";
#pragma aux GR_DRAWSEG "^";
#pragma aux GR_SAVEWIN "^";
#pragma aux D3TRIS "^";
#pragma aux D3TFAN "^";
#pragma aux SECTIONPREVIEW "^";
#pragma aux SECTIONPREVIEW1 "^";
#pragma aux BEAMINQUIRE "^";
#pragma aux GET_CMP_INAME "^";
#pragma aux PDP_RV_GRAPH "^";
#pragma aux PDP_HIST "^";
#pragma aux PDP_CDF  "^";
#pragma aux PDP_SAMP "^";
#pragma aux PDP_SCAT "^";
#pragma aux PDP_SENS "^";
#pragma aux PDP_RS3D "^";
#endif

/*******************************************************/
/**********  FUNCTION RETURN TYPE DECLARATION **********/
/*******************************************************/
#if !defined(PCWINNT_SYS)
    /*  C routines called from FORTRAN  */ 
   void    decimate_(INT *nvert, INT *iinode, double *xyz, double *uv, INT *nelm, INT *elm, INT *nxref, double *ang_l, double *ang_f, INT *kbound, INT *kall);
   void    tri_strip_(INT *nvert, DOUBLE *Geom, INT *nelm, INT *elm, INT *kedg, INT *nxref, INT*eadj, INT*eused);
   void    d2dith_(INT *keyz, INT *ixywin, INT *ixyimg, INT *istk);
   void    pdp_yclp_(double *,double *,double *,double *,double *,double *,
                     INT *);
   void    z33txt_(double *, double *, INT *, INT *, INT *, INT *, INT *);
   void    z2mnmx_(INT *Xmin, INT *Xmax, INT *Ymin, INT *Ymax);
   void    z2line_(INT *ixy1, INT *ixy2, INT *iclrg, INT *idata);
   void    z2area_(INT *n,  INT *ixy, INT *iclra,INT *inorm, INT *idata);
   void    z2move_(INT z1[], INT *w1, INT z2[], INT *w2, INT *nx, INT *ny);
   void    z2logo_(INT z1[], INT *w1, INT z2[], INT *w2, INT *nx, INT *ny,
                   INT *iclr_blak);
   void    z2alph_(INT *,INT *,INT *,INT *,INT *,INT *, INT *, INT *, INT *);
   void    z2wwhh_(INT *, INT *, double *, double *);
   void    z2font_(INT *,INT *,INT *);
   void    z2info_(INT *,INT *);
   INT     z2inqr_(INT *);
   void    z2wind_(INT *, INT *, INT *, INT *);
   INT     iqlook_(INT *, INT *, INT *);
   INT     iqpack_(INT *, INT *, INT *);
   void    d2rfnt_(INT *,INT *);
   void    d3rlab_init_(INT *, INT *,INT *,INT *,INT *,double *,double *);
   void    d2rlab_fini_(INT *, double *);
   void    zbuf_init_(INT *ixmin, INT *ixmax, INT *iymin, INT *iymax, double *vpl, INT *istack);
   void    zbuf_copy_(INT *image);
   void    zbuf_z3line_(INT *ixyz1, INT *ixyz2, INT *cline);
   void    zbuf_z3flat_(INT *n, INT *ixyz, INT *cedge, INT *cfill, INT *inorm, INT *kedge);
   void    zbuf_z3gour_(INT *n, INT *ixyz, INT *inrm, INT *cedge, INT *cfill, INT *kedge);
   void    zbuf_z3phon_(INT *n, INT *ixyz, INT *inrms, INT *cedge, INT *cfill, INT *kedge);
   void    zbuf2_init_();
   void    zbuf2_copy_();
   void    zbuf2_z3line_();
   void    zbuf2_z3flat_();
   void    zbuf2_z3gour_();
   void    zbuf2_z3phon_();
   void    zbuf2_d2lwid_();
   void    wtitlset_();
   void    gr_startanim_();
   void    gr_anim_io_();
   void    gr_start_macro_(void);
   void    gr_end_macro_(void);
   void    gr_demo_();
   void    zbuf2_d2tran_ ();
   void    hc_writefile_ (INT *key, INT *kscreen, INT *kcolor, INT *krev, 
                          INT *korient, INT *kcmp);
    /*  FORTRAN routines called from C  */
   void    draw_cell_();
   void    gr_docu_sort_(double [][5], INT *);
   double  gr_ang_();
   void    gr_angs_();
   void    gr_fang_();
   void    d2rl33_slow_(INT *,INT *,INT *,INT *,double *);
   void    d3rlxx_slow_(INT *,INT *,INT *,INT *,double *);
   void    d2rlzz_slow_(INT *,INT *,INT *,INT *,double *);
   void    d3rlxx_fast_(INT *,INT *,INT *,INT *,
                        double *,double *,double *,double *);
   void    d2rlzz_fast_(INT *,INT *,INT *,INT *,
                        double *,double *,double *,double *);
   void    d3qlxx_fast_(INT *,INT *,INT *,INT *,double *,double *,double *);
   void    d2qlzz_fast_(INT *,INT *,INT *,INT *,double *,double *,double *);
   double  vdot_();
   void    vnorm_();
   void    gr_drawseg_();
   void    gr_savewin_();
   void    icmdmac_();
   void    syssec_();
   void    timget_();
   void    d3tris_();
   void    d3tfan_();
   void    sectionpreview_();
   void    sectionpreview1_();
   void    beaminquire_();
   void    get_cmp_iname_(INT *, INT*);
   INT     pdp_rv_graph_();
   INT     pdp_hist_();
   INT     pdp_cdf_();
   INT     pdp_samp_();
   INT     pdp_scat_();
   INT     pdp_sens_();
   INT     pdp_rs3d_();
#else
    /*  C routines called from FORTRAN  */
   void   CALLTYP decimate_();
   void   CALLTYP tri_strip_();
   void   CALLTYP d2dith_();
   void   CALLTYP pdp_yclp_();
   void   CALLTYP z33txt_();
   void   CALLTYP z2mnmx_();
   void   CALLTYP z2line_();
   void   CALLTYP z2area_();
   void   CALLTYP z2move_();
   void   CALLTYP z2logo_();
   void   CALLTYP z2alph_();
   void   CALLTYP z2wwhh_();
   void   CALLTYP z2font_();
   void   CALLTYP z2info_();
   INT    CALLTYP z2inqr_();
   void   CALLTYP z2wind_();
   INT    CALLTYP iqlook_();
   INT    CALLTYP iqpack_();
   void   CALLTYP d2rfnt();
   void   CALLTYP d3rlabl_init();
   void   CALLTYP d3rlabl_fini();
   void   CALLTYP zbuf_init_();
   void   CALLTYP zbuf_copy_();
   void   CALLTYP zbuf_z3line_();
   void   CALLTYP zbuf_z3flat_();
   void   CALLTYP zbuf_z3gour_();
   void   CALLTYP zbuf_z3phon_();
   void   CALLTYP zbuf2_init_();
   void   CALLTYP zbuf2_copy_();
   void   CALLTYP zbuf2_z3line_();
   void   CALLTYP zbuf2_z3flat_();
   void   CALLTYP zbuf2_z3gour_();
   void   CALLTYP zbuf2_z3phon_();
   void   CALLTYP zbuf2_d2lwid_();
   void   CALLTYP wtitlset_();
   void   CALLTYP gr_startanim_();
   void   CALLTYP gr_anim_io_();
   void   CALLTYP gr_start_macro_();
   void   CALLTYP gr_end_macro_();
   void   CALLTYP gr_demo_();
   void   CALLTYP zbuf2_d2tran_();
   void   CALLTYP hc_writefile_();
    /*  FORTRAN routines called from C  */
   extern void   CALLTYP draw_cell_();
   extern void   CALLTYP gr_docu_sort_(double [][5], INT *);
   extern double CALLTYP gr_ang_();
   extern void   CALLTYP gr_angs_();
   extern void   CALLTYP gr_fang_();
   extern void   CALLTYP d2rl33_slow_(INT *,INT *,INT *,INT *,double *);
   extern void   CALLTYP d3rlxx_slow_(INT *,INT *,INT *,INT *,double *);
   extern void   CALLTYP d2rlzz_slow_(INT *,INT *,INT *,INT *,double *);
   extern void   CALLTYP d3rlxx_fast_(INT *,INT *,INT *,INT *,
                                      double *,double *,double *,double *);
   extern void   CALLTYP d2rlzz_fast_(INT *,INT *,INT *,INT *,
                                      double *,double *,double *,double *);
   extern void   CALLTYP d3qlxx_fast_(INT *,INT *,INT *,INT *,
                                      double *,double *,double *);
   extern void   CALLTYP d2qlzz_fast_(INT *,INT *,INT *,INT *,
                                      double *,double *,double *);
   extern double CALLTYP vdot_();
   extern void   CALLTYP vnorm_();
   extern void   CALLTYP gr_drawseg_();
   extern void   CALLTYP gr_savewin_();
   extern void   CALLTYP icmdmac_();
   extern void   CALLTYP syssec_();
   extern void   CALLTYP timget_();
   extern void   CALLTYP d3tris_();
   extern void   CALLTYP d3tfan_();
   extern void   CALLTYP sectionpreview_();
   extern void   CALLTYP sectionpreview1_();
   extern void   CALLTYP beaminquire_();
   extern void   CALLTYP get_cmp_iname_();
   extern INT    CALLTYP pdp_rv_graph_( INT*, DOUBLE*, DOUBLE*, DOUBLE*, 
                                        INT*, INT*, INT*, INT*, 
                                        INT*, DOUBLE*, DOUBLE*, DOUBLE*, DOUBLE*,
                                        DOUBLE*, DOUBLE*,
                                        INT*, DOUBLE*, INT*, DOUBLE* );
   extern INT    CALLTYP pdp_hist_    ( INT*, DOUBLE*, DOUBLE*, INT*, 
                                        INT*, DOUBLE*, DOUBLE*, 
                                        INT*, INT*, INT*, INT*, 
                                        DOUBLE*, DOUBLE*, DOUBLE*, DOUBLE*,
                                        DOUBLE*, DOUBLE* );
   extern INT    CALLTYP pdp_cdf_     ( INT*, 
                                        DOUBLE*, DOUBLE*, 
                                        DOUBLE*, DOUBLE*, 
                                        INT*, INT*, INT*, INT*, 
                                        INT*, DOUBLE*, DOUBLE*, 
                                        INT*, DOUBLE*, DOUBLE*, 
                                        DOUBLE*, DOUBLE*, DOUBLE*, DOUBLE*, DOUBLE*,
                                        DOUBLE*, DOUBLE* );
   extern INT    CALLTYP pdp_samp_    ( INT*, INT*, INT*,
                                        INT*, DOUBLE*, INT*,
                                        INT*, INT*, INT*, INT*, 
                                        DOUBLE*, DOUBLE*, DOUBLE*, DOUBLE*, DOUBLE*,
                                        DOUBLE*, DOUBLE* );
   extern INT    CALLTYP pdp_scat_    ( INT*, INT*, DOUBLE*, DOUBLE*, 
                                        INT*, INT*, INT*, INT*, INT*, INT*, 
                                        DOUBLE*, DOUBLE*,
                                        INT*, DOUBLE*, DOUBLE*,
                                        DOUBLE*, DOUBLE*,
                                        INT*, INT*, DOUBLE*,
                                        DOUBLE*, DOUBLE* );
   extern INT    CALLTYP pdp_sens_    ( INT*, DOUBLE*, DOUBLE*, INT*, INT*,
                                        INT*, INT*, INT*, INT*, 
                                        INT*, INT*,
                                        INT*, INT*,
                                        DOUBLE* );
   extern INT    CALLTYP pdp_rs3d_    ( INT*, INT*, INT*, INT*, INT*, INT*, INT*, INT*, 
                                        INT*, INT*, DOUBLE*, DOUBLE*, DOUBLE*, 
                                        INT*,
                                        INT*, DOUBLE*, DOUBLE*, DOUBLE* );
#endif
