/* STR_util.h CADOE  */
/*
 * $Id: STR_util.h,v 1.6 2009/11/13 16:13:03 jtm Exp $
 */

#ifndef __strutilh__
#define __strutilh__ 1

#include "cadoesys.h"
#include "cbf.h"
/* Specifique AIX */
#ifdef AIX
#include <strings.h>
#endif
#ifdef WINNT
#define STRDUP _strdup
#define STRCMP _stricmp
#else
#define STRDUP strdup
#define STRCMP strcasecmp
#endif



extern _TCHAR *   get_racine ( const _TCHAR * );
extern _TCHAR *   get_chaine_extremite ( _TCHAR * );
extern _TCHAR *cadoe_tchardup( const _TCHAR *str, const char *fct );

extern char	*STR_vprintf ( const char *message, ... );
extern void	STR_rename ( char **nom, const char *message, ... );

#endif
