/*
 * *** copyright(c) 2010 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */
#define True 1
#define False 0

#include "computer.h"

#if defined (__STDC__)
#define ANSI_C_COMPAT			1
#endif
