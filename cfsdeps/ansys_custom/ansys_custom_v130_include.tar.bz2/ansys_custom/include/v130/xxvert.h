

/*
 *    author/date: yu-hua ting/04-02-94
 *
 *    primary function:
 *
 *      Header for the Interface to SHAPES "vertex" routines
 *
 *    secondary function:
 *
 *        none
 *
 *    routines included:
 *
 *
 *    history
 *
 *        none
 *
 *    comments:
 *
 *        1). direct interface with Shapes/xox 2.0 will be added later
 *
 *    Notice - This file contains ANSYS Confidential information ***
 *
 */

/* 
 * *** copyright(c) 2010 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */

/*
 *    get the vertex on a cell for given parameters
 */
      extern xVERTEX_ID xVertexForParams_xox ansPROTO((
             xGEOM_ID gm_id,      /* I    geom number of a geom                      */ 
             DOUBLE params[],     /* I    parameters                                 */
             xINT domaindim,      /* I    dimension of the geom                      */
             INT *iretp));        /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                               */


/*
 *    get the vertex coordinates
 */
      extern DOUBLE *xVertexCoords_xox ansPROTO((
             xVERTEX_ID vertex,   /* I    vertex                                     */ 
             DOUBLE coords[],     /* I    coordinates                                */
             INT *iretp));        /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                               */


 
/*
 *    Construct a vertex at the minmum distance from a geom to defined point
 */
      extern xVERTEX_ID xGmFindMinVertForPnt_xox ansPROTO((
             xGEOM_ID gm_id,      /* I    geom number of a geom                      */
             DOUBLE coords[],     /* I    coordinates of a given point               */
             DOUBLE maxtol,       /* I    maximum distance to abort at               */
             DOUBLE *mindist,     /*   O  minimum distance to be returned            */
             xTAG tag,            /* I    heap tag                                   */
             INT *iretp));        /*   O  error code
                                   *      == 0 - no error
                                   *      != 0 - error                               */
