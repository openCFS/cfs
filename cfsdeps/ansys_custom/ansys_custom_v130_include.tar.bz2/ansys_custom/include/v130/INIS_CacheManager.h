
/*
////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         copyright(c) 2010 SAS IP, Inc.  All rights reserved.             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: INIS_CacheManager.h $
// $Revision: 1.9 $ 7.0
// $Date: 2010/04/16 15:25:42 $ October 04 2005
// $Author: srpailla $ rjayasee
//
// Decription :
// Manages the Cache for Initial Stress
//
// This is the single point/junction for writing and reading data.
//
////////////////////////////////////////////////////////////////////////////
*/

#include "INIS_Database.h"
#include "ANS_TagMemManager.h"

#ifndef INIS_CACHEMANAGER_H
#define INIS_CACHEMANAGER_H

class INIS_CacheManager
{
    public:
        void * operator new(size_t iMemSize )
        {
            return ANS_MALLOC(iMemSize) ;
        }

        void * operator new[]( size_t iSize )
        {
            return ANS_MALLOC(iSize) ;
        }

        void operator delete(void * pMemPtr)
        {
                ANS_FREE(pMemPtr) ;
        }

        void operator delete[](void * pMemPtr )
        {
                ANS_FREE(pMemPtr) ;
        }

        static INIS_CacheManager* Instance();
        //Instantiator singleton
        
        static void Destroy();
        //Destructor

        void DeleteCache( INT iProcessId );
        //R Delete a cache for a specific process

        INIS_Database* GetCachePtr( INT iProcessId );
        //R INIS_Database Pointer

        INIS_CommandParams* g_pCommandParams ;

    protected:
        INIS_CacheManager( INT iNumProcs ) ;
        //Constructor

        ~INIS_CacheManager() ;
        //Destructor

        static INIS_CacheManager* m_pINIS_CacheManager ;
        //Singleton

        INIS_Database** m_ppINIS_Database ;
        //Collection of Initial Stress Inmemory Caches

        INT m_iNumProcs ;
        //Number of Databases or processes. By default we have only one process
};

#endif
