/********** DUE TO THE SYSTEM DEPENDENT NATURE OF THIS CODE, ***********
*********** ROUTINE IS STUBBED UNLESS ON A SUPPORTED SYSTEM  **********/
/* 
 * *** copyright(c) 2010 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */

#if defined(DECAXPOSF_SYS) \
 || defined(SOLARIS_SYS) || defined(SGIR4K_SYS) || defined(HP32_SYS) \
 || defined(SGIR8K_SYS) || defined (HP64_SYS) || defined (HPIA64_SYS) \
 || defined(PCWINNT_SYS) \
 || defined(RS6000_SYS) || defined(LINUX_SYS)



/* Ansys shared commands/library header */
#include <limits.h>
#include <stdlib.h>
#include "computer.h" /* cwa */
#include "globals.h"  /* for MAXPATHLEN */

#if defined(DECAXPOSF_SYS)    /* cwa */
#   include <sys/syslimits.h> 
#   include <sys/param.h> 
#endif

#if defined(HP_SYS)
#   include <dl.h>
#endif

#define SCF_MAX_LINE_LEN 1536

#define GLOBAL_EXT_DIR "/ansys/docu"
#define EXTERNAL_COMMAND_TABLE_FILE_NAME "ans_ext.tbl"

/* Error codes passed to share_error */
/* Pass only SFLOOKUP_PTR with the following */
#define NO_ENV_PATH        991
#define NO_FILE_FOUND      992
#define CANNOT_OPEN_FILE   993
#define CANNOT_READ_FILE   989
#define CANNOT_CLOSE_FILE  994
#define BAD_SYNTAX         995
#define MEMORY_ERROR       990

/* Pass void* with NO_COMMAND_MATCH*/
#define NO_COMMAND_MATCH   996

/* Pass only SFLINE_PTR with DL_ERROR1 */
#define DL_ERROR1          997

/* Pass only char* with DL_ERROR2 */
#define DL_ERROR2          998

/* Pass only int* with LAST_ERROR_REQUEST (returns last error key) */
#define LAST_ERROR_REQUEST 999

/* Pass only int* with INITIALIZE_LAST_ERROR */
#define INITIALIZE_LAST_ERROR 1000

/* Pass void* with EXT_RESET*/
#define EXT_RESET             1001

/* Pass void* with EXT_RESET*/
#define IGNORE_MESSAGE        1002

/* PATH_MAX is defined by most systems, we will provide 
   a definition for certain others */

#if defined(PCWINNT_SYS) /* cwa */
#   include <windows.h>
#   define PATH_MAX _MAX_PATH
#endif

#if !defined PATH_MAX
#   define PATH_MAX MAXPATHLEN  
#endif

typedef struct shared_file_line
    {
     int dlhandle_num;           /* index into an array of dlhandles.  This will
                                    tell which dlhandle to reference for this
                                    command's shared library */
     char path_name[PATH_MAX];   /* path to shared library */
     char command[256];          /* command to respond to */
     char function_name[256];    /* function to invoke */
     int  tbl_num;               /* the number of the ans_ext.tbl file this 
                                    command entry came from */
    } SFLINE, *SFLINE_PTR;
     
typedef struct shared_file_lookup
    {
     char **shared_cmd_paths;  /* paths to ans_ext.tbl files */
     int    num_lines;         /* number of lines in the internal table 
                                  of commands and functions */
     int    num_tables;        /* number of ans_ext.tbl files read in */
     int    num_dlhandles;     /* number of dlhandles that have been stored */
     SFLINE_PTR *lines;        /* lines from ans_ext.tbl files (external command
                                  mappings) */

     /* this is a definition for an array of dlhandles */

#if defined(PCWINNT_SYS)   /* cwa */
     HINSTANCE *dlhandles;
#elif defined(HP_SYS)        /* cwa */
     shl_t **dlhandles;       /* handle returned by dlopen */
#else
     void **dlhandles;       /* handle returned by dlopen */
#endif
    } SFLOOKUP, *SFLOOKUP_PTR;


#endif
