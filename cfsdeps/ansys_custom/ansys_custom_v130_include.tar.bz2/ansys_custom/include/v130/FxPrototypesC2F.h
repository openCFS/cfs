/* ---------------------------------------------------------------------- */
/* ***  copyright(c) 2010 SAS IP, Inc.  All rights reserved.                                         */
/* *** ansys, inc.                                                        */
/* ---------------------------------------------------------------------- */


/*
 *    author/date: Stefan Reh 2002-02-06
 *
 *    primary function:
 *
 *        header for "C and Fortran interface"
 *
 *    Notice - This file contains ANSYS Confidential information ***
 *
 */

#ifndef _FX_PROTOTYPES_CTOF_H_
#define _FX_PROTOTYPES_CTOF_H_



/* ===================================================================== */
/* For systems needing lower case names without an underscore at the end */
/* ===================================================================== */
#if defined(LOWERCASENOUNDER_SYS)

/* C functions called from FORTRAN */
/* ------------------------------- */
#define F2C_FxFreq                  f2c_fxfreq
#define F2C_FxOut                   f2c_fxout
#define F2C_FxSetJobName            f2c_fxsetjobname


/* FORTRAN functions called from C */
/* ------------------------------- */
/*
#define C2F_Test                    c2f_test
*/

#endif


/* ===================================================================== */
/* For systems needing upper case names without an underscore at the end */
/* ===================================================================== */
#if defined(UPPERCASENOUNDER_SYS)

/* C functions called from FORTRAN */
/* ------------------------------- */
#define F2C_FxFreq                  F2C_FXFREQ
#define F2C_FxOut                   F2C_FXOUT
#define F2C_FxSetJobName            F2C_FXSETJOBNAME


/* FORTRAN functions called from C */
/* ------------------------------- */
/*
#define C2F_Test                    C2F_TEST
*/

#endif


/* ================================================================== */
/* For systems needing upper case names with an underscore at the end */
/* ================================================================== */
#if defined(LOWERCASEUNDER_SYS)

/* C functions called from FORTRAN */
/* ------------------------------- */
#define F2C_FxFreq                  f2c_fxfreq_
#define F2C_FxOut                   f2c_fxout_
#define F2C_FxSetJobName            f2c_fxsetjobname_


/* FORTRAN functions called from C */
/* ------------------------------- */
/*
#define C2F_Test                    c2f_test_
*/

#endif



/* ===================== */
/* Prototype definitions */
/* ===================== */
INT FUNCTION  F2C_FxFreq( FCHAR(cNameIn), DOUBLE *dMinFreqIn, DOUBLE *dMaxFreqIn, INT *iFreqIncrIn FCHARL(cNameIn_len) );
INT FUNCTION  F2C_FxOut( FCHAR(cNameIn), FCHAR(cTypeIn), FCHAR(cCompIn), DOUBLE *dAccuracy, INT *iNumElems , INT *iElemList FCHARL(cNameIn_len) FCHARL(cTypeIn_len) FCHARL(cCompIn_len) );
INT FUNCTION  F2C_FxSetJobName( FCHAR(cNameIn) FCHARL(cCompIn_len));
/* FORTRAN functions called from C */
/* ------------------------------- */
/*
void CALLTYP Fx_C2F_Freq_( DOUBLE*, INT*, INT*, DOUBLE*, DOUBLE*, INT* );
*/


#endif /* _FX_PROTOTYPES_CTOF_H_ */
