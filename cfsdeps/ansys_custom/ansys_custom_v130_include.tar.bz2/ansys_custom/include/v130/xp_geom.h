/* ANSI_C xp_geom.h - Interface to API/XOX functions */

/*--------------------------------------------------------------------------*/
/* copyright(c) 2010 SAS IP, Inc.  All rights reserved. */
/* ansys, inc.                */
/*--------------------------------------------------------------------------*/

#ifndef __xp_geom_H_FILE__ /* Include this file only once! */
#define __xp_geom_H_FILE__

#if defined(__cplusplus)
extern "C" {
#endif

/*--------------------------------------------------------------------------*/

  xx_VOID xx_set_base_name (const char *base);

  xx_VOID      xx_initialize(
			     xx_INT       model_id,
			     xx_REAL      size_measure,       /* or 0.0 */
			     xx_REAL      min_max_box[6],     /* or NULL */
			     xx_REAL      tols[2],            /* or NULL */
			     xx_INT       code,
			     xx_INT       create_solid,
			     xx_INT       merge_entities,
			     xx_INT       debug);

  xx_VOID  xx_terminate(
                        xx_INT       model_id);
  
  xx_VOID xx_process(
                     xx_INT       model_id,
                     xx_INT       option);
  
  xx_INT xx_entity_has_been_put(
                                xx_ENTITY  entity);

  xx_ENTITY xp_brep_solid_by_shells(
                                    xx_ENTITY    solid,
                                    xx_ENTITY   *shells,
                                    xx_INT      *shell_orients,
                                    xx_INT      *shell_tree,
                                    xx_INT       num_shells);

  xx_ENTITY xp_face_shell(
                          xx_ENTITY    face_shell,
                          xx_ENTITY   *faces,
                          xx_INT      *face_orients,
                          xx_INT       num_faces);
  xx_ENTITY xp_face(
                    xx_ENTITY    face,
                    xx_ENTITY    surface,
                    xx_INT       surface_orient,
                    xx_ENTITY   *loops,   
                    xx_INT      *loop_orients,
                    xx_INT      *loop_tree,
                    xx_INT       num_loops);

  xx_ENTITY xp_edge_loop(
                         xx_ENTITY    edge_loop,
                         xx_ENTITY   *edges,
                         xx_INT      *edge_orients,
                         xx_INT       num_edges);

  xx_ENTITY xp_edge(
                    xx_ENTITY    edge,
                    xx_ENTITY    curve,   
                    xx_INT       curve_orient,
                    xx_ENTITY    start_vertex,
                    xx_ENTITY    end_vertex);

  xx_ENTITY xp_vertex_by_coordinates(
                                     xx_ENTITY    vertex,
                                     xx_REAL     *xyz);

  xx_ENTITY xp_vertex_by_point(
                               xx_ENTITY    vertex,
                               xx_ENTITY    point);
  xx_ENTITY xp_point(
                     xx_ENTITY    point,
                     xx_REAL     *xyz);

  xx_ENTITY xp_nurb_curve(
                          xx_ENTITY      nurb_curve, 
                          xx_REAL       *knots, 
                          xx_REAL       *control_points, 
                          xx_REAL       *weights,
                          xx_INT         form,
                          xx_INT         degree, 
                          xx_INT         planar,
                          xx_INT         closed,
                          xx_INT         polynomial,
                          xx_INT         periodic,
                          xx_INT         num_control_points,
                          xx_REAL       *bounds);

  xx_ENTITY xp_nurb_surf(
                         xx_ENTITY      nurb_surf, 
                         xx_REAL       *u_knots,
                         xx_REAL       *v_knots,
                         xx_REAL       *control_points,
                         xx_REAL       *weights,
                         xx_INT         form,
                         xx_INT         u_degree,
                         xx_INT         v_degree,
                         xx_INT         u_closed,
                         xx_INT         v_closed,
                         xx_INT         polynomial,
                         xx_INT         u_periodic,
                         xx_INT         v_periodic,
                         xx_INT         num_u_control_points,
                         xx_INT         num_v_control_points,
                         xx_REAL       *u_bounds,
                         xx_REAL       *v_bounds);

  xx_ENTITY xp_transform(
                         xx_ENTITY    transform, 
                         xx_REAL     *matrix);
  
  xx_ENTITY xp_line(
                    xx_ENTITY    line,
                    xx_REAL       *start_xyz,
                    xx_REAL       *end_xyz);
  
  xx_ENTITY xp_polyline(
                        xx_ENTITY      polyline, 
                        xx_REAL       *points,
                        xx_INT         num_points);

  xx_ENTITY xp_trimmed_curve(
                             xx_ENTITY      trimmed_curve,
                             xx_ENTITY      curve,
                             xx_INT         curve_orient,
                             xx_REAL       *bounds);
  
  xx_ENTITY xp_conic_arc(
                         xx_ENTITY    conic_arc,
                         xx_REAL      center[],
                         xx_REAL      axis_direction[],
                         xx_REAL      reference_direction[],
                         xx_REAL     *coefficients,
                         xx_REAL     *bounds,
                         xx_INT       form);

  xx_ENTITY xp_circular_arc(
                            xx_ENTITY    circular_arc,
                            xx_REAL      center[],
                            xx_REAL      axis_direction[],
                            xx_REAL      reference_direction[],
                            xx_REAL      radius,
                            xx_REAL     *bounds);

  xx_ENTITY xp_elliptical_arc(
                              xx_ENTITY    elliptical_arc,
                              xx_REAL      center[],
                              xx_REAL      axis_direction[],
                              xx_REAL      reference_direction[],
                              xx_REAL      major_radius,
                              xx_REAL      minor_radius,
                              xx_REAL     *bounds);

  xx_ENTITY xp_hyperbolic_arc(
                              xx_ENTITY    hyperbolic_arc,
                              xx_REAL      center[],
                              xx_REAL      axis_direction[],
                              xx_REAL      reference_direction[],
                              xx_REAL      major_radius,
                              xx_REAL      minor_radius,
                              xx_REAL     *bounds);

  xx_ENTITY xp_parabolic_arc(
                             xx_ENTITY    parabolic_arc,
                             xx_REAL      center[],
                             xx_REAL      axis_direction[],
                             xx_REAL      reference_direction[],
                             xx_REAL      focal_distance,
                             xx_REAL     *bounds);

  xx_ENTITY xp_offset_curve(
                            xx_ENTITY    offset_curve,
                            xx_ENTITY    basis_curve, 
                            xx_INT       offset_distance_flag,
                            xx_ENTITY    offset_distance_function_curve,
                            xx_INT       i_coordinate,
                            xx_INT       tapered_offset_type_flag,
                            xx_REAL      first_offset_distance,
                            xx_REAL      first_offset_parameter,
                            xx_REAL      second_offset_distance,
                            xx_REAL      second_offset_parameter,
                            xx_REAL      offset_reference_direction[],
                            xx_REAL     *bounds);
  
  xx_ENTITY xp_surface_curve(
                             xx_ENTITY    surface_curve,
                             xx_ENTITY    model_space_curve,
                             xx_ENTITY   *pcurves,
                             xx_ENTITY   *surfaces,
                             xx_INT       num_pcurves,
                             xx_INT       way_of_curve_created,
                             xx_INT       preferred_representation,
                             xx_REAL      fit_tolerance);

  xx_ENTITY xp_composite_curve(
                               xx_ENTITY    composite_curve,
                               xx_ENTITY   *curve_segments,
                               xx_INT      *curve_segment_orients,
                               xx_REAL     *parameter_ranges,
                               xx_INT       closed,
                               xx_INT      *transition_codes,
                               xx_INT       num_segments);

  xx_ENTITY xp_plane(
                     xx_ENTITY    plane,
                     xx_REAL      center[],
                     xx_REAL      axis_direction[],
                     xx_REAL      reference_direction[]);

  xx_ENTITY    xp_cylindrical_surf(
                                   xx_ENTITY    cylindrical_surf,
                                   xx_REAL      center[],
                                   xx_REAL      axis_direction[],
                                   xx_REAL      reference_direction[],
                                   xx_REAL      radius);

  xx_ENTITY    xp_conical_surf(
                               xx_ENTITY    conical_surf,
                               xx_REAL      center[],
                               xx_REAL      axis_direction[],
                               xx_REAL      reference_direction[],
                               xx_REAL      radius,
                               xx_REAL      semi_angle);

  xx_ENTITY    xp_spherical_surf(
                                 xx_ENTITY    spherical_surf,
                                 xx_REAL      center[],
                                 xx_REAL      axis_direction[],
                                 xx_REAL      reference_direction[],
                                 xx_REAL      radius);

  xx_ENTITY    xp_toroidal_surf(
                                xx_ENTITY    toroidal_surf,
                                xx_REAL      center[],
                                xx_REAL      axis_direction[],
                                xx_REAL      reference_direction[],
                                xx_REAL      major_radius,
                                xx_REAL      minor_radius);

  xx_ENTITY    xp_surf_of_linear_extrusion(
                                           xx_ENTITY  surf_of_linear_extrusion,
                                           xx_ENTITY  generatrix_curve,
                                           xx_REAL    extrusion_vector[]);

  xx_ENTITY    xp_surf_of_revolution(
                                     xx_ENTITY    surf_of_revolution,
                                     xx_ENTITY    generatrix_curve,
                                     xx_REAL      axis_point[],
                                     xx_REAL      axis_direction[],
                                     xx_REAL     *bounds);

  xx_ENTITY    xp_ruled_surf(
                             xx_ENTITY    ruled_surf,
                             xx_ENTITY    first_curve,
                             xx_ENTITY    second_curve,
                             xx_INT       form,
                             xx_INT       direction_flag,
                             xx_INT       developable);

  xx_ENTITY    xp_offset_surf(
                              xx_ENTITY    offset_surf,
                              xx_ENTITY    surface,
                              xx_REAL      offset_distance);

  xx_ENTITY      xp_rect_trimmed_surf(
                                      xx_ENTITY      rect_trimmed_surf, 
                                      xx_ENTITY      surface,   
                                      xx_INT         u_orient,
                                      xx_INT         v_orient,
                                      xx_REAL       *u_bounds,
                                      xx_REAL       *v_bounds);

  xx_ENTITY    xp_curve_bounded_surf(
                                     xx_ENTITY    curve_bounded_surf, 
                                     xx_INT       implicit_outer,
                                     xx_ENTITY    surface,
                                     xx_ENTITY   *curves, 
                                     xx_INT       num_curves);

/*--------------------------------------------------------------------------*/

#if defined(__cplusplus)
}
#endif

#endif /* #ifndef __xp_geom_H_FILE__ */
