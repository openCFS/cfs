#ifndef _DDS_GLOBALS_H_
#define _DDS_GLOBALS_H_ 1

#include <stdio.h>

#include "cadoe.h"
#include "commun.h"
#include "computer.h" 
#include "C_CadoeTrace.h"
#include "C_Algorithm.h"

extern "C" void printDomain(int glSubNum);

extern "C" void cwTrackBegin(char *);
extern "C" void cwTrackEnd(char *);

class C_DDS_Options : public C_Algorithm
{
protected:
  C_DDS_Options() {};
  ~C_DDS_Options() {};
  
  static C_DDS_Options *S_DDS_Options;
  
public:
  static C_DDS_Options* Instance() 
  { 
    if (S_DDS_Options == NULL) S_DDS_Options = new C_DDS_Options();
    return S_DDS_Options;
  }
  
  static void kill() { if (S_DDS_Options) delete S_DDS_Options; S_DDS_Options = NULL;}
};

class C_TraceDDS : public  C_Trace 
{
public:
  C_TraceDDS(const char *fct, const char *file, int line) : C_Trace(fct,file,line) 
  {
    cwTrackBegin((char*) fct);
    _fct = fct;
  }
  ~C_TraceDDS() 
  {
    cwTrackEnd((char*) _fct.c_str());
  }
  
protected:
  string _fct;
};

#undef CADOE_TRACE
#define CADOE_TRACE( x ) C_TraceDDS _trace( ( x ),__FILE__,__LINE__) 

#define allocadd(size) (size == 0 ? NULL : NEW_AD(size,char,"allocad",MUP,__FILE__,__LINE__))

#endif
