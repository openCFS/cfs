/* 
 * *** copyright(c) 2010 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */
#if !defined (PCWINNT_SYS)
#ifdef X11_START

/* Note: Routines using this file require "globals.h" to appear before it */

/*   Global Variables for uiloop  */
XtAppContext  app_context;
Display   *display;
Widget    appshell, cmdshell, menushell, listershell;
Widget    helpshell, promptshell;
Widget    ew;
int       key_visual;
int       fcpan,fpktyp;
int       pfcnt,pff,pnfld;
int       fpcount[20];
int       fpstack[20];
/* temporary entity and location pick stack space */
int       *entstk;
DOUBLE    locstk[3000];
Boolean   dtabshell_actions = False;
Boolean   dtab_up = False;
Widget    menuctrls_GRPH = 0;
Widget    menuctrls_MAIN = 0;
Widget    menuctrls_CMD  = 0;
Widget    menuctrls_TOOL = 0;
Widget    menuctrls_SGUI = 0;
int       key_cpset = 0;

#else

extern XtAppContext  app_context;
extern Display   *display;
extern Widget    appshell, cmdshell, menushell, listershell;
extern Widget    ew;
extern Widget    helpshell, promptshell;
extern int       key_visual;
extern int       fcpan,fpktyp;
extern int       pfcnt,pff,pnfld;
extern int       fpcount[];
extern int       fpstack[];
extern int       *entstk;
extern DOUBLE    locstk[3000];
extern Boolean   dtabshell_actions;
extern Boolean   dtab_up;
extern Widget    menuctrls_GRPH;
extern Widget    menuctrls_MAIN;
extern Widget    menuctrls_CMD;
extern Widget    menuctrls_TOOL;
extern Widget    menuctrls_SGUI;
extern int       key_cpset;

#endif

#else
FILE *stream;      /* Needed for nt_printf */
struct list_struct {
     int     num;
     HWND    hwnd;
     char    name[81];
    };

#ifdef WINNT_START

/* Note: Routines using this file require "globals.h" to appear before it */

/*   Global Variables for uiloop  */
WNDPROC wpAnsCmdOrigEditProc;
HANDLE  ghInst;
HWND    hwndFrame;
HWND	hwndOutputWindow;	   // Handle to PJMs Output window
HWND    hDlgCurrent = NULL;            // Handle of currently active modeless
                                       //   dialog box
HWND    hwndActive = NULL;             // Handle of currently active
                                       //   top-level window
HWND    hwndMenuPopup, hwndGraphPopup, hwndAnsCmdPopup, hwndToolbarPopup;
HWND    hwndListerPopup, hwndSelectEntPopup, hwndHelpPopup;
HWND    hwndToplevel;
HWND    hwndAnsCmdControls[3];
HWND    hDlgEditAbbr = NULL;
HWND    hDlgWPSettings  = NULL;
HWND    hDlgOffsetWP = NULL;
HWND    hDlgPanZoomRot = NULL;
HWND    hDlgMeshControl = NULL;
HWND    hDlgAnimate = NULL;
HWND    hDlgChangeTitle = NULL;
HWND    hDlgScalarParm = NULL;
HWND    hDlgPick = NULL;
HWND    hDlgQPick = NULL;
HWND    hDlgLPick = NULL;
HWND    hDlgSPick = NULL;
HWND    hwndMPick = NULL;
HWND    hwndRPick = NULL;
HWND    hDlgHelpHistory = NULL;
HWND    hDlgHelpSearch = NULL;
HWND    hDlgHelpArticle = NULL;
HWND    hDlgHelpOn = NULL;
HWND    ano_shell = NULL;
HWND    anno3d_shell = NULL;
HWND    beam_shell = NULL;
HWND    contShell = NULL;
HWND    hDlgModelessMB = NULL;
HMENU   hMenuEraseOptions = NULL;
HMENU   hMenuAnnotate = NULL;
HMENU   hMenuStyle = NULL;
HBRUSH  hMsgBoxBrush;
HBRUSH  hRedBrush, hYellowBrush;
COLORREF  crAnsCmd, crMsgBox;
COLORREF  crSkyBlue, crTurquoise, crGray;
COLORREF  crAquaMarineLight, crAquaMarineDark;
COLORREF  crRed, crYellow;
COLORREF  crTextForeground, crTextBackground;
char    szListerClass[] = "ListerPopup";
char    szMenuClass[] = "MainMenuPopup";
char    szConPanClass[] = "GRANULE_DIALOG";  // child window class
char    szSelectEntClass[] = "SelectEntPopup";
char    szHelpClass[] = "HelpPopup";
char    szAnsCmdEditClass[] = "AnsCmdEdit";
int     fWhichGraphWndEventHandler = 0;
int     fWhichCmdWndEventHandler = 0;
int     fWhichCmdEnteredCallback = 0;
int       fcpan,fpktyp;
int       pfcnt,pff,pnfld;
int       fpcount[20];
/* temporary entity and location pick stack space */
int       *entstk;
DOUBLE    locstk[3000];
BOOL      dtab_up = FALSE;
char    gszRegProd[80];
struct  list_struct  list_datum[20];
BOOL    fIsProRun;
BOOL    bIsWinNT;
int     key_cpset = 0;

#else

extern WNDPROC wpAnsCmdOrigEditProc;
extern HANDLE  ghInst;
extern HWND    hwndFrame;
extern HWND    hwndOutputWindow;
extern HWND    hDlgCurrent;
extern HWND    hwndActive;
extern HWND    hwndMenuPopup, hwndGraphPopup, hwndAnsCmdPopup, hwndToolbarPopup;
extern HWND    hwndListerPopup, hwndSelectEntPopup, hwndHelpPopup;
extern HWND    hwndToplevel;
extern HWND    hwndAnsCmdControls[3];
extern HWND    hDlgEditAbbr;
extern HWND    hDlgWPSettings;
extern HWND    hDlgOffsetWP;
extern HWND    hDlgPanZoomRot;
extern HWND    hDlgMeshControl;
extern HWND    hDlgAnimate;
extern HWND    hDlgChangeTitle;
extern HWND    hDlgScalarParm;
extern HWND    hDlgPick;
extern HWND    hDlgQPick;
extern HWND    hDlgLPick;
extern HWND    hDlgSPick;
extern HWND    hwndMPick;
extern HWND    hwndRPick;
extern HWND    hDlgHelpHistory ;
extern HWND    hDlgHelpSearch;
extern HWND    hDlgHelpArticle;
extern HWND    hDlgHelpOn;
extern HWND    ano_shell;
extern HWND    anno3d_shell;
extern HWND    beam_shell;
extern HWND    contShell;
extern HWND    hDlgModelessMB;
extern HBRUSH  hMsgBoxBrush;
extern HBRUSH  hAquaMarineBrush;
extern HBRUSH  hRedBrush, hYellowBrush;
extern HMENU   hMenuEraseOptions;
extern HMENU   hMenuAnnotate;
extern HMENU   hMenuStyle;
extern COLORREF  crAnsCmd, crMsgBox;
extern COLORREF  crSkyBlue, crTurquoise, crGray;
extern COLORREF  crAquaMarineLight, crAquaMarineDark;
extern COLORREF  crRed, crYellow;
extern COLORREF  crTextForeground, crTextBackground;
extern char    szListerClass[];
extern char    szMenuClass[];
extern char    szConPanClass[];
extern char    szSelectEntClass[];
extern char    szHelpClass[];
extern char    szAnsCmdEditClass[];
extern int     fWhichGraphWndEventHandler;
extern int     fWhichCmdWndEventHandler;
extern int     fWhichCmdEnteredCallback;
extern int       fcpan,fpktyp;
extern int       pfcnt,pff,pnfld;
extern int       fpcount[];
extern int       *entstk;
extern DOUBLE    locstk[3000];
extern BOOL      dtab_up;
extern char    gszRegProd[80];
extern struct  list_struct  list_datum[20];
extern BOOL    fIsProRun;
extern BOOL    bIsWinNT;
extern int     key_cpset;

#endif
#endif

#define MAX_IN_LIST 800
