/* 
 * *** copyright(c) 2010 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */
#if defined(XOX_DEBUG)
#define CALLTYP
typedef int INT;
typedef double xREAL;
typedef  void VOID;
#include "ansproto.h"
#endif
/*       tess.h                         kz372     */

/*  Inquire a geom for tessellation info.*/ 
INT  CALLTYP
xAnsysTessInq_ ansPROTO((
     INT *id,        /* I: - Entity id to inquire  */

     INT *dim,       /* I: - Dimension of the input entity;
			             0 - model vertex (never used)
                                     1 - model edge
                                     2 - model face
                                     3 - model region (currently not used) */
     INT *tess_flag, /* O: - Tesselation flag:
                                     0 - not yet tessellated
                                     1 - entity tessellated
                                     2 - entity has tessellation error */
     xREAL *tol,       /* O: - Tesselation tolerance values
                                    tess_tol[0] - point to point tolerance
                                    tess_tol[1] - angular tolerance */
     INT *code,     /* O: - Tolerance code used during
                                     tessellation;
                                     1 - Only point tolerance used
                                     2 - only angular tolerance used
                                     3 - both the tolerances used
                                     4 - either of the tolerances used */
     INT *norm_flag, /* O:  - facet vertex normal flag
			             0 - norms not available at facet vertices
			             1 - norms available at vertices */
     INT *tess_len, /* O: - If tessellated, number of tesselated entities,
			         0 otherwise
                             tess_len[0] - no. of facet vertices
                             tess_len[1] - no. of facet edges
                             tess_len[2] - no. of facet faces
                             tess_len[3] - no. of facet regions (not used) */
     INT *facet_vert  /* O: - If tessellated, verts per element, 0 otherwise */
));

/* Get maxinum number of elements or nodes for areas/lines     */
INT CALLTYP
xAnsysTessMax_ ansPROTO((
    xINT *dim,
    xINT *flag
));

/*  Perform tessellation on a entity*/ 
INT  CALLTYP 
xAnsysTessEnt_ ansPROTO((
     INT *id,        /* I: - Entity id to tessellate       */

     INT *dim,      /* I: - Dimension of the input entity;
                                  0 - model vertex (never used)
                                  1 - model edge
                                  2 - model face
                                  3 - model region (currently not used) */
     xREAL *tol,       /* I: - Tesselation tolerance values
                                  tess_tol[0] - point to point tolerance
                                  tess_tol[1] - angular tolerance
                                  Use default tolerance if both set to zero  */
     INT *code,      /* I: - Tolerance code used during tessellation;
                                  0 - use default setting
                                  1 - use point tolerance
                                  2 - use angular tolerance
                                  3 - use both the tolerances
				  4 - use either of the tolerances  */
     INT *norm_flag, /* I: - Facet vertex normal flag
                                  0 - don't eval normals at facet vertices
                                  1 - evaluate normals at the vertices  */
     INT *tess_len,  /* O: - Number of tessellated entities
                                  tess_len[0]- # facet vertices
                                  tess_len[1]- # facet edges
                                  tess_len[2]- # facet faces
                                  tess_len[3]- # facet regions (not used) */
     INT *facet_vert  /* O: - Vertices per finite element   */
));

/*  Get Tesselation information for an entity*/ 
INT  CALLTYP 
xAnsysGetTess_ ansPROTO((
     INT   *id,         /* I: - Entity id to inquire */

     INT   *dim,        /* I: - Dimension of the input entity;
                                   0 - model vertex (never used)
                                   1 - model edge
                                   2 - model face
                                   3 - model region (currently not used)  */
     INT   *nvert_elem, /* O: - No. of vertices per f.e. element */

     INT   *tess_len, /* O: - Number of tessellated entities
                                   tess_len[0] - # facet vertices
                                   tess_len[1] - # facet edges
                                   tess_len[2] - # facet faces
                                   tess_len[3] - # facet regions (Not used)*/
     xREAL *vert_coord,  /* O: - Cordinates of the facet vertices   */
     xREAL *vert_norm,   /* O: - If available, entity normals at the vertices;
			         otherwise return as is         */
     INT  *facet        /* O: - Facet vertex connectivity and boundary 
			         entity flag.
				      0 - interior entity
				      1 - boundary entity
				      e.g. (1,3,2,1,0,0) means
				      edge between 1 and 3 is on boundary
				      edge between 3 and 2 is on interior
				      edge between 2 and 1 is on interior */
));

/*  Calculate Derivatives for param value.*/ 
INT  CALLTYP 
xAnsysEntDrv_ ansPROTO((
     xINT *geom,    /* I: - Geom for which information is requested   */
     INT   *dim,     /* I: - Dimension of the input geom;
                                     0 - model vertex (never used)
                                     1 - model edge
                                     2 - model face
                                     3 - model region (currently not used)  */
     xREAL *param,   /* I: - Parameter value  */
     INT   *nderiv,  /* I: - Number of components desired for derivatives;
			used as the first dimension of derivs array. */
     xREAL *vector,  /* O: - Derivative component vectors;
			   - (1,1:3) - for edge: 1st derivative wrt u
			   - (2,1:3) - for face: 1st derivative wrt v
			               for edge: 2nd derivative
			   - (3,1:3) - for face: 1st derivative wrt u
			               for edge: 3nd derivative
			   - (4,1:3) - for face: 2nd derivative wrt u
			   - (5,1:3) - for face: 2nd derivative wrt v */
     INT   *orien_flag  /* O: - orientation flag                     */
     
));
/*  Evaluate global coordinates for param value.*/ 
INT  CALLTYP 
xAnsysEntEvl_ ansPROTO((
     xINT *geom,    /* I: - Geom for which information is requested   */
     xREAL *param,   /* I: - Parameter value  */
     xREAL *pcoord   /* O: - Coordinates of point  */
));

/*  Determine the center of an entity             */
INT 
CALLTYP xAnsysEntCenter_ ansPROTO((
     INT  *id,
     INT  *dim,
     xREAL *center
));

/*  Determine if an entity has any degeneracy    */
INT 
CALLTYP xAnsysDegenInq_ ansPROTO((
     INT  *id,
     INT  *dim
));

/*  Determine if an entity has closed loop/surface    */
INT 
CALLTYP xAnsysClosedEntInq_ ansPROTO((
     INT  *id,
     INT  *dim
));

/*  Determine if an entity has closed surface    */
INT 
CALLTYP xAnsysAreaClosed_ ansPROTO((
     INT  *id,    /* I: ANSYS area id  */
     INT  *s,     /* O: 1 if closed in s direction */
     INT  *t      /* O; 1 if closed in t direction */
));

/*  Project a point onto an entity.*/ 
INT  CALLTYP 
xAnsysEntPrj_ ansPROTO((
     INT  *id,     /* I:   - Entity id for which information is requested   */

     INT  *dim,    /* I:   - Dimension of the input entity;
                                     0 - model vertex (never used)
                                     1 - model edge
                                     2 - model face
                                     3 - model region (currently not used)   */
     xREAL *prjtol, /* I:   - Projection tolerance values
                                    projtol[0] - min tol for lower threshold
                                    projtol[1] - max tol for upper threshold
                                    Use default tolerance if both zero */
     xREAL *pcoord, /* I/O: - Coordinates of the point to project
                               If the point is out of region, return closest */
     xREAL *param,   /* I/O: - Parameters of the point for initial
                                     guess; parameters are initialized
                                     for no guess; uses only param(1)
                                     for edges           */
     INT  *subent  /* O:   - Geom id    */
 ));

/*  Determine if a facet edge is a boundary edge.*/ 
INT
xAnsysTessTest xmP((
     INT *id,
		 xINT *dim 
));

/*  Determine if a facet edge is a boundary edge.*/ 
static INT
xsBoundaryEdgeP xmP((
     xFACET  facet,
		 INT    edge 
));

/*  Initialize global vars;*/ 
void
xAnsysTessInit ();
