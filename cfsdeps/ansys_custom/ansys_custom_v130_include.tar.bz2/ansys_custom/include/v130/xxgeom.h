/*
 *    author/date: yu-hua ting/10-29-93
 *
 *    primary function:
 *
 *      Header for the Interface to SHAPES "Geom" routines 
 *
 *    secondary function:
 *
 *        none
 *
 *    routines included:
 *
 *
 *    history
 *
 *        none
 *
 *    comments:
 *
 *        none
 *
 *    Notice - This file contains ANSYS Confidential information ***
 *
 */

/* 
 * *** copyright(c) 2010 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */



/*
 *    create a point geom
 */
      extern xGEOM_ID xPointGeom_xox ansPROTO((
             DOUBLE ptcoords[],   /* I    point coordinates                         */
             xINT spdim,          /* I    space dimension                           */
             INT *iretp));        /*   O  pointer to the error code  
                                   *      == 0 - no error
                                   *      != 0 - error                              */


/*
 *    create a copy of a geom
 */
      extern xGEOM_ID xGmCopy_xox ansPROTO((
             xGEOM_ID gm_id,      /* I    geom number of a geom                     */ 
             xTAG tag,            /* I    heap tag                                  */
             INT *iretp));        /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                              */




/*
 *    sew a list of geoms (for ANSYS)
 */
      extern xGEOM_ID xSewnGeom_xox ansPROTO((
             xINT_LIST geomlist,  /* I    list of geoms to be sewn                */
             INT *iretp));        /*   O  pointer to the error code  
                                   *      == 0 - no error
                                   *      != 0 - error                              */



/*
 *    create a halfspace geom of a geom
 */
      extern xGEOM_ID xGmNewHalfspace_xox ansPROTO((
             xGEOM_ID gm_id,      /* I    geom number of a geom                     */ 
             xTAG tag,            /* I    heap tag                                  */
             INT *iretp));        /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                              */



/*
 *    create the complement of a complement_halfspace geom
 */
      extern xGEOM_ID xGmComplement_xox ansPROTO((
             xGEOM_ID gm_id,      /* I    geom number of a half space geom          */ 
             xTAG tag,            /* I    heap tag                                  */
             INT *iretp));        /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                              */


/*
 *    group a list of geoms (for ANSYS)
 */
      extern xGEOM_ID xGmGroup_xox ansPROTO((
             xINT_LIST geomlist,  /* I    list of geoms to be grouped               */
             xTAG tag,            /* I    heap tag                                  */
             INT *iretp));        /*   O  pointer to the error code  
                                   *      == 0 - no error
                                   *      != 0 - error                              */



/*
 *    Construct/Modify a geom to isolate it from external controls
 */
      extern xGEOM_ID xGmCopySupCtrldCells_xox ansPROTO((
             xGEOM_ID gm_id,      /* I    geom number of a geom                     */
             xTAG tag,            /* I    heap tag                                  */
             INT *iretp));        /*   O  error code
                                   *      == 0 - no error
                                   *      != 0 - error                              */


/*   
 *    create a 3-D nurbs surface in SHAPES 
 */
      extern xGEOM_ID xGmNewNurbSurf_xox ansPROTO((
      DOUBLE sur[],        /* I    sur of a nurbs surface                  */
      INT nsur[],          /* I    nsur of the nurbs surface               */
      INT *iretp));        /*   O  pointer to the error code  
                            *      == 0 - no error
                            *      != 0 - error                            */
