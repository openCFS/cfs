

/*
 *    author/date: yu-hua ting/04-23-94
 *
 *    primary function:
 *
 *      Header for the Interface to Ansys/Shapes Interface "nurbs" routines
 *
 *    secondary function:
 *
 *        none
 *
 *    routines included:
 *
 *
 *    history
 *
 *        none
 *
 *    comments:
 *
 *        1). direct interface with Shapes/xax 2.0 will be added later
 *
 *    Notice - This file contains ANSYS Confidential information ***
 *
 */
/* 
 * *** copyright(c) 2010 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */



/*
 *    Check the divided knot locations.
 *    (knot locations should be strictly increasing, and between beginning knot
 *    and ending knot)
 *
 *    returns TRUE , if they are Bad
 *            FALSE, otherwise
 */
      extern INT xBadDividedKnotLocations_xax ansPROTO((
             DOUBLE ktd[],                       /* I    knot locations to be divided            */
             INT nkd,                            /* I    number of knot locations to be divided  */
             DOUBLE k0,                          /* I    beginning knot                          */
             DOUBLE k1,                          /* I    Ending knot                             */
             DOUBLE tolk,                        /* I    knot tolerance                          */
             INT *iretp));                       /*   O  pointer to the error code
                                                  *      == 0 - no error
                                                  *      != 0 - error                            */


/*   
 *    Divide the underlying curve and create an array of 1-D geoms
 */
      extern VOID xDivideUnderlyingCurve_xax ansPROTO((
             DOUBLE cur[],                       /* I    cur of a nurbs curve                    */
             INT ncur[],                         /* I    ncur of the nurbs curve                 */
             DOUBLE ktd[],                       /* I    knot locations to be divided            */
             INT nkd,                            /* I    number of knot locations to be divided  */
             xGEOM_ID xnurbs_sub_curves[],       /*   O  shapes/xox output sub_curves            */
             INT        ansys_sub_lines[],       /*   O  ansys output sub_lines                  */
             INT *iretp));                       /*   O  pointer to the error code  
                                                  *      == 0 - no error
                                                  *      != 0 - error                            */


/*   
 *    Divide the underlying surface and create an array of 2-D geoms
 */
      extern VOID xDivideUnderlyingSurface_xax ansPROTO((
             DOUBLE sur[],                       /* I    sur of a nurbs surve                     */
             INT nsur[],                         /* I    nsur of the nurbs surve                  */
             DOUBLE ktdu[],                      /* I    U-knot locations to be divided           */
             DOUBLE ktdv[],                      /* I    V-knot locations to be divided           */
             INT nkdu,                           /* I    number of U-knot locations to be divided */
             INT nkdv,                           /* I    number of V-knot locations to be divided */
             xGEOM_ID xnurbs_sub_surfaces[],     /*   O  shapes/xox output sub_surfaces           */
             INT         xnurbs_sub_areas[],     /*   O  ansys output sub_areas                   */
             INT *iretp));                       /*   O  pointer to the error code  
                                                  *      == 0 - no error
                                                  *      != 0 - error                             */
      

/*   
 *    create a 3-D nurbs curve in SHAPES (for ANSYS)
 */
      extern xGEOM_ID xNurbGeomCurve_xax ansPROTO((
             INT sln,             /* I    subline number                          */
             DOUBLE cur[],        /* I    cur of a nurbs curve                    */
             INT ncur[],          /* I    ncur of the nurbs curve                 */
             INT *geom_type,      /*   O  == SHAPES_COMPOSITE_GEOM 
                                   *      == SHAPES_BASIC_GEOM                     */ 
             INT *iretp));        /*   O  pointer to the error code  
                                   *      == 0 - no error
                                   *      != 0 - error                            */

/*   
 *    create a 3-D nurbs surface in SHAPES (for ANSYS)
 */
      extern xGEOM_ID xNurbGeomSurface_xax ansPROTO((
             INT san,             /* I    subarea number                          */
             DOUBLE sur[],        /* I    sur of a nurbs surface                  */
             INT nsur[],          /* I    nsur of the nurbs surface               */
             INT *geom_type,      /*   O  == SHAPES_COMPOSITE_GEOM  
                                   *      == SHAPES_BASIC_GEOM                     */  
             INT *iretp));        /*   O  pointer to the error code  
                                   *      == 0 - no error
                                   *      != 0 - error                            */
