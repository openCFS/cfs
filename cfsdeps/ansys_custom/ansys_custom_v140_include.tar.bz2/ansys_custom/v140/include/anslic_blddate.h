/* anslic_blddate is the date of the current version in the format yyyymmdd used for FLEXlm checkouts */
#ifndef _ANSLIC_BLDDATE_H_
#define _ANSLIC_BLDDATE_H_ 1
static const char anslic_blddate[]="20111010";
#endif
