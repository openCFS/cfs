#ifndef _DECOPTI_H_
#define _DECOPTI_H_

#include "DomainDec.h"

class Connectivity;
class Decomposition;
class Elemset;

class DecOpti {
   Decomposition *dec;
   Connectivity *eToN, *nToE, *eToE;
   INT *subAssign;   // to which sub an element belongs
   INT numEle, numSub;
   INT *firstElem;   // first element in a sub
   INT *nextElem;    // link to next element in subdomain
   INT *previousElem;

   INT *subWeight;
   INT *subMask;
   INT *weight, *mask;
   INT *subNode;

   INT improve;
 public:
   DecOpti(Connectivity *eton, Connectivity *ntoe, Connectivity *etoe, Decomposition *dec);
   void minInterface(INT sub);
   Decomposition *minInterface();
   INT findBestSub(INT elem);
   void reAssign(INT elem, INT sub);
   void assign(INT elem, INT sub);
   Decomposition *faceComponents(Elemset *es);

};

Decomposition * improveDec(Decomposition *dec);

Decomposition *
improveDec(Elemset *es,
           Connectivity *eton, Connectivity *ntoe, Connectivity *etoe,
           Decomposition *dec);

#endif
