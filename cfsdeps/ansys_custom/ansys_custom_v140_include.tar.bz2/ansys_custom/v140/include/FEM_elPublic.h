/*  FEM_elPublic.h */
/*
 * *** ansys(r) copyright(c) 2009
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/* 
 *  FEM_elPublic.h
 *  Prototypes and macros for FEM element data type
 *
 */
/* *** mpg math array c
 FEM_array.c FEM_matrix.c FEM_MeshTable.h FEM_Public.h FEM_array.h
 FEM_array_static.h  FEM_cdbtypes.h FEM_edPublic.h FEM_elPublic.h
 FEM_errors.h FEM_external.h FEM_faPublic.h FEM_matrix.h
 FEM_matrix_static.h FEM_meshTree.h FEM_noGeom.h FEM_noPublic.h
 FEM_publicElementDefinition.h fem_Struct.h
 ansproto.h computer.h float.h globals.h mathfun.h
*/
#ifndef FEM_ELPUBLIC
#define FEM_ELPUBLIC

#ifdef EXTERNAL_COMPILE
#include "FEM_cdbtypes.h"
#else
#include "globals.h"
#include "computer.h"
#endif
#include "FEM_external.h"

/* === property masks used with the property field in the element */

#ifndef NO_PROPERTY
#define NO_PROPERTY        0
#endif
#define ELEM_DEGENERATE_HEX    (1<<0)
#define ELEM_SELECTED          (1<<1)
#define ELEM_PROPERTY_2        (1<<2)
#define ELEM_PROPERTY_3        (1<<3)
#define ELEM_PROPERTY_4        (1<<4)
#define ELEM_ID_DUPLICATED     (1<<5)
#define ELEM_HAS_MIDNODES      (1<<6)
#define ELEM_SPLIT             (1<<7)
#define ELEM_MID_PROJECT       (1<<8)
#define ELEM_CONSTRAINED       (1<<9)
#define ELEM_EDELEMS_FLAG      (1<<10)
#define ELEM_HEXMORPHED        (1<<11)
#define ELEM_VISITED           (1<<12) 
#define ELEM_FROM_SHEET (1<<13 )
/* etc... */

/* === manipulating and inquiring on the linked list object */


#ifdef __cplusplus
extern "C" {
#endif
                             /* ============================================= */
                             /* === FEM_elNewList: create a new element list  */
                             /* === and initialize (ELEMENTLIST_OBJ           */
                             /* === constructor)                              */
ELEMENTLIST_OBJ FEM_elNewList ( void  );

                             /* ============================================= */
                             /* === FEM_elDeleteList: delete the element list */
                             /* === (ELEMENTLIST_OBJ destructor)              */
void FEM_elDeleteList (
   ELEMENTLIST_OBJ obj_elist );        /* The element list object             */

                             /* ============================================= */
                             /* === FEM_elNew: create a new element and add   */
                             /* === it to the element list                    */
                             /* === (ELEMENT_OBJ constructor)                 */
ELEMENT_OBJ FEM_elNew (
   ELEMENTLIST_OBJ obj_elist );        /* The element list object             */

                             /* ============================================= */
                             /* === FEM_elDelete: delete an element and       */
                             /* === remove from list                          */
                             /* === (ELEMENT_OBJ destructor)                  */
void FEM_elDelete (
   ELEMENTLIST_OBJ obj_elist,          /* The element list object             */
   ELEMENT_OBJ obj_element  );         /* element object to be deleted        */

                             /* ============================================= */
                             /* === FEM_elNewTet: Create a tet in the data    */
                             /* === base from 4 nodes. Update all adjacencies */
ELEMENT_OBJ FEM_elNewTet (
   NODE_OBJ aobj_node[10]  );          /* array[10] of node objects that are  */
                                       /* nodes of the new tet. (Nodes must   */
                                       /* already exist in nodelist)          */
                                       /* Note: Nodes 4-9 should be NULL if   */
                                       /* midnodes don't exist on this element*/

                             /* ============================================= */
                             /* === FEM_elNewWedge: Create a wedge in the data*/
                             /* === base from 6 nodes. Update all adjacencies */
ELEMENT_OBJ FEM_elNewWedge (
   NODE_OBJ aobj_node[15]  );          /* array[15] of node objects that are  */
                                       /* nodes of the new wdg. (Nodes must   */
                                       /* already exist in nodelist)          */
                                       /* Note: Nodes 6-14 should be NULL if  */
                                       /* midnodes don't exist on this element*/

                             /* ============================================= */
                             /* === FEM_elNewPyramid: Create a pyr in the data*/
                             /* === base from 5 nodes. Update all adjacencies */
ELEMENT_OBJ FEM_elNewPyramid (
   NODE_OBJ aobj_node[13]  );          /* array[13] of node objects that are  */
                                       /* nodes of the new pyr. (Nodes must   */
                                       /* already exist in nodelist)          */
                                       /* Note: Nodes 5-12 should be NULL if  */
                                       /* midnodes don't exist on this element*/

                             /* ============================================= */
                             /* === FEM_elNewPyramid: Create a pyr in the data*/
                             /* === base from 5 nodes. Update all adjacencies */
ELEMENT_OBJ FEM_elNewPyramidWK  (
   NODE_OBJ aobj_node[13]  );          /* array[13] of node objects that are  */
                                       /* nodes of the new pyr. (Nodes must   */
                                       /* already exist in nodelist)          */
                                       /* Note: Nodes 5-12 should be NULL if  */
                                       /* midnodes don't exist on this element*/

                             /* ============================================= */
                             /* === FEM_CalPyramidMetric: cal a pyramid shape */
                             /* === metric value                              */
DOUBLE FEM_CalPyramidMetric(
   NODE_OBJ aobj_nodes[13],    /* element nodes   */
   INT mtype );                /* type of metric to use */

                             /* ============================================= */
                             /* === FEM_elNewHex: Create a hex in the data    */
                             /* === base from 8 nodes. Update all adjacencies */
ELEMENT_OBJ FEM_elNewHex (
   NODE_OBJ aobj_node[20]  );          /* array[20] of node objects that are  */
                                       /* nodes of the new pyr. (Nodes must   */
                                       /* already exist in nodelist)          */
                                       /* Note: Nodes 8-19 should be NULL if  */
                                       /* midnodes don't exist on this element*/

                             /* ============================================= */
                             /* === FEM_elMaxId: return max element id in list*/
INT FEM_elMaxId (
   ELEMENTLIST_OBJ obj_elist  );       /* the element list object             */

                             /* ============================================= */
                             /* === FEM_elDeleteTet: delete a tet from the    */
                             /* === main element list object. Delete any edge */
                             /* === or face no longer used.  Unused nodes will*/
                             /* === not be deleted. All adjacencies will be   */
                             /* === updated.                                  */
INT FEM_elDeleteTet (
   ELEMENT_OBJ obj_element  );         /* element object to be deleted        */

                             /* === FEM_elDeleteElem: delete an elem from the */
                             /* === main element list object. Delete any edge */
                             /* === or face no longer used.  Unused nodes will*/
                             /* === not be deleted. All adjacencies will be   */
                             /* === updated.                                  */
INT FEM_elDeleteElem (
   ELEMENT_OBJ obj_element  );         /* element object to be deleted        */

                             /* === FEM_elDeleteElemII: same as               */
                             /* === FEM_elDeleteElem except does not delete   */
                             /* === faces and edges associated with an area   */
                             /* === or line                                   */ 
INT FEM_elDeleteElemII (
   ELEMENT_OBJ obj_element  );         /* element object to be deleted        */


                             /* ============================================= */
                             /* === FEM_elFaceIndex: return face index of face*/
                             /* === on element                                */
INT FEM_elFaceIndex (
   ELEMENT_OBJ obj_element,            /* element object                      */
   FACE_OBJ obj_face  );               /* face object on element              */

                             /* ============================================= */
                             /* === FEM_elEdgeIndex: return edge index of     */
                             /* === edge on element                           */
INT FEM_elEdgeIndex (
   ELEMENT_OBJ obj_element,            /* element object                      */
   EDGE_OBJ obj_edge  );               /* edge object on element              */

                             /* ============================================= */
                             /* === FEM_elNodeIndex: return index of node     */
                             /* === on element                                */
INT FEM_elNodeIndex (
   ELEMENT_OBJ obj_element,            /* the element object                  */
   NODE_OBJ obj_node  );               /* node on element                     */

                             /* ============================================= */
                             /* === FEM_elFaceOrientation: return orientation */
                             /* === and initial edge index on face with       */
                             /* === respect to element                        */
INT FEM_elFaceOrientation(
   ELEMENT_OBJ obj_elem,               /* the element                         */
   FACE_OBJ obj_face,                  /* a face on the element               */
   INT *p_edge_orientation,            /* return orientation of edges         */
   INT *p_initial_edge_idx );          /* return initial edge index           */

/* === element utility functions */

                             /* ============================================= */
                             /* === FEM_elNode: get one node of an element    */
                             /* === index is defined by diagram in FEM_Public */
NODE_OBJ FEM_elNode (
   ELEMENT_OBJ obj_element,            /* element object                      */
   INT inode );                        /* the node number                     */

                             /* ============================================= */
                             /* === FEM_elNodes: get the all nodes of element */
                             /* === in order specified in FEM_Public.h.       */
                             /* === Includes midnodes                         */
INT FEM_elNodes (
   ELEMENT_OBJ obj_element,            /* element object                      */
   NODE_OBJ aobj_node[20]  );          /* return array of nodes on element    */

                             /* ============================================= */
                             /* === FEM_elCorNodes: same as FEM_elNodes but   */
                             /* === ignores any mid nodes                     */
INT FEM_elCorNodes (
   ELEMENT_OBJ obj_element,            /* element object                      */
   NODE_OBJ aobj_node[8]  );           /* array[8] or array[4] of node objects*/
                                       /* returned                            */


                             /* ============================================= */
                             /* === FEM_elOrientedNodes: return the corner    */
                             /* === nodes on the element such that the node   */
                             /* === passed in will be node index 0 and the    */
                             /* === rest will be ordered according to         */
                             /* === FEM_Public.c (with respect to obj_node)   */
INT FEM_elOrientedNodes(
   ELEMENT_OBJ obj_element,            /* the element                         */
   NODE_OBJ obj_node,                  /* a node on the element               */
   NODE_OBJ *aobj_nodes );             /* return the oriented array of nodes  */
                                       /* where aobj_nodes[0] is obj_node     */

                             /* === FEM_elOrientedNodes2: same as             */
                             /* === FEM_elOrientedNodes but returns the       */
                             /* === corresponding element node indecies       */
INT FEM_elOrientedNodes2(
   ELEMENT_OBJ obj_element,            /* the element                         */
   NODE_OBJ obj_node,                  /* a node on the element               */
   NODE_OBJ *aobj_nodes,               /* return the oriented array of nodes  */
                                       /* where aobj_nodes[0] is obj_node     */
   INT *a_index );                     /* element node indecies               */

                             /* ============================================= */
                             /* === FEM_elHasMidnodes: Determines if an       */
                             /* === element has midnodes.                     */
                             /* === Return: TRUE or FALSE.                    */
INT FEM_elHasMidnodes (
   ELEMENT_OBJ obj_element  );

                             /* ============================================= */
                             /* === FEM_elTetCorNodes: get corner nodes of tet*/
                             /* === element in order specified in FEM_Public.h*/
void FEM_elTetCorNodes (
   ELEMENT_OBJ obj_element,            /* element object                      */
   NODE_OBJ aobj_node[4]  );           /* array[4] of node objects            */

                             /* ============================================= */
                             /* === FEM_elTetMidNodes: get mid nodes of tet   */
                             /* === element in order specified in FEM_Public.h*/
void FEM_elTetMidNodes (
   ELEMENT_OBJ obj_element,            /* element object                      */
   NODE_OBJ aobj_node[6]  );           /* array[6] of node objects            */

                             /* ============================================= */
                             /* === FEM_elEdge: given the element index of an */
                             /* === edge return the obj_edge                  */
EDGE_OBJ FEM_elEdge (
   ELEMENT_OBJ obj_element,            /* element object                      */
   INT iedge );                        /* element edge index                  */

                             /* ============================================= */
                             /* === FEM_elEdges: get ordered list of edges on */
                             /* === an element (as defined in FEM_Public.h)   */
INT FEM_elEdges (
   ELEMENT_OBJ obj_element,            /* element object                      */
   EDGE_OBJ aobj_edge[12]  );          /* array[12] of edge objects returned  */

                             /* ============================================= */
                             /* === FEM_elAdjElement: get the element         */
                             /* === adjacent to iface (NULL if no element)    */
ELEMENT_OBJ FEM_elAdjElement (
   ELEMENT_OBJ obj_element,            /* element object                      */
   INT iface );                        /* element face number                 */

                            /* ============================================= */
                            /* === FEM_elAdjUpdate: update element adjacencies*/
INT FEM_elAdjUpdate (
   ELEMENT_OBJ obj_element );          /* element object                      */

                            /* ============================================== */
                            /* === FEM_elAdjRemove: delete any adjacency      */
                            /* === info for the element                       */
INT FEM_elAdjRemove (
   ELEMENT_OBJ obj_element );          /* element object                      */

                             /* ============================================= */
                             /* === FEM_elNextElemAtEdge: given a previous    */
                             /* === face at an edge, the edge and an element  */
                             /* === adjacent to the edge (and face), return   */
                             /* === the next element adjacent to the edge     */
ELEMENT_OBJ FEM_elNextElemAtEdge (
   ELEMENT_OBJ obj_element,           /* element adjacent to edge             */
   NODE_OBJ obj_face,                 /* previous face adjacent to edge       */
   EDGE_OBJ obj_edge,                 /* edge to rotate about                 */
   FACE_OBJ *pobj_nextface );         /* return next face                     */

                             /* ============================================= */
                             /* === FEM_elFaceBetween: return the face between*/
                             /* === two elements.  NULL if they aren't        */
                             /* === adjacent                                  */
FACE_OBJ FEM_elFaceBetween (
   ELEMENT_OBJ obj_element1,          /* first element                        */
   ELEMENT_OBJ obj_element2  );       /* second element                       */

                            /* === FEM_elFacesAtNodeID: return the faces on an*/
                            /* === element adjacent a node (given its index)  */
INT FEM_elFacesAtNodeID (
   ELEMENT_OBJ obj_element,            /* the element                         */
   INT index,                          /* index of node on element  (0-7)     */
   FACE_OBJ aobj_face[4]  );           /* return array of faces (up to 4)     */

                             /* ============================================= */
                             /* === FEM_elPlaceAtFront: Given a PROPERTY and  */
                             /* === a geo_entity, place all elements in the   */
                             /* === element list with this property and       */
                             /* === geo_entity (if necessary ) at the front   */
                             /* === of the list.  If you do not want to sort  */
                             /* === on geo_entity then set geo_entity to -1.  */
INT FEM_elPlaceAtFront (
   ELEMENTLIST_OBJ obj_ellist,   /* elem list to rearrange                    */
   FEM_LONG property,                /* property to rearrange on                  */
   INT geo_entity  );            /* geo_entity to rearrange on                */

                            /* ============================================== */
                            /* === FEM_elPlaceAtRear: Given a property (or    */
                            /* === properties), place all elements in element */
                            /* === list with this property at the rear of the */
                            /* === list; this is equivalent to placing elems  */
                            /* === without this property at the front of list */
void FEM_elPlaceAtRear (
   ELEMENTLIST_OBJ obj_ellist,         /* elem list to rearrange              */
   FEM_LONG property  );                   /* property to rearrange on            */

                            /* ============================================== */
                            /* === FEM_elExtendUnconstraints:  Unconstrain    */
                            /* === all selected tets maxlevel levels out from */
                            /* === the tets that are already marked as        */
                            /* === !ELEM_CONSTRAINED.  All Faces on any       */
                            /* === constrained element get set to be          */
                            /* === FACE_CONSTRAINED.  All constrained faces   */
                            /* === and elems get put at the rear of the       */
                            /* === obj_flist/obj_ellist.  All elem Generic    */
                            /* === Pointers must be NULL before use.          */
INT FEM_elExtendUnconstraints (
   INT maxlevel  );                    /* number of levels out to unconstrain */

                            /* ============================================== */
                            /* === FEM_elFacesAtEdge: return the faces on an  */
                            /* === element adjacent an edge                   */
INT FEM_elFacesAtEdge (
   ELEMENT_OBJ obj_element,            /* the element                         */
   EDGE_OBJ obj_edge,                  /* edge on element                     */
   FACE_OBJ aobj_face[2]  );           /* return array of faces (2)           */


DOUBLE FEM_elAngleAtEdge (
   ELEMENT_OBJ obj_element,            /* the element                         */
   EDGE_OBJ obj_edge );                /* edge on element                     */
                            /* ============================================== */
                            /* === FEM_elFacesAtNode: return the faces on an  */
                            /* === element adjacent a node                    */
INT FEM_elFacesAtNode (
   ELEMENT_OBJ obj_element,            /* the element                         */
   NODE_OBJ obj_node,                  /* node on element                     */
   FACE_OBJ aobj_face[4]  );           /* return array of faces (up to 4)     */

                            /* ============================================== */
                            /* === FEM_elOppositeTetFace: return opposite     */
                            /* === face on a tet given a node on tet          */
FACE_OBJ FEM_elOppositeTetFace (
   ELEMENT_OBJ obj_tet,
   NODE_OBJ obj_node );
                            /* ============================================== */
                            /* === FEM_elOppositeTetEdge: return opposite     */
                            /* === edge on a tet given an edge on tet         */
EDGE_OBJ FEM_elOppositeTetEdge( 
   ELEMENT_OBJ obj_tet,
   EDGE_OBJ obj_edge );

                            /* ============================================== */
                            /* === FEM_elOppositeTetNode: return opposite     */
                            /* === node on a tet given a face on tet          */
NODE_OBJ FEM_elOppositeTetNode(
   ELEMENT_OBJ obj_tet,           
   FACE_OBJ obj_face );

                            /* ============================================== */
                            /* === FEM_elOppositeHexNode: return opposite     */
                            /* === node on a hex given a node on hex          */
NODE_OBJ FEM_elOppositeHexNode(
   ELEMENT_OBJ obj_hex,                /* the hex */
   NODE_OBJ obj_node );

                            /* ============================================== */
                            /* === FEM_elOppositePyrNode: return opposite     */
                            /* === node on a pyramid given an edge            */
NODE_OBJ FEM_elOppositePyrNode( 
   ELEMENT_OBJ obj_pyr,                /* the pyramid */
   EDGE_OBJ obj_edge );

                            /* ============================================== */
                            /* === FEM_elCentroid: return centroid of elems   */
                            /* === corner nodes                               */
void FEM_elCentroid(
   ELEMENT_OBJ obj_elem,              /* the element */
   VECTOR3D *p_ctr );
 
                            /* ============================================== */  
                            /* === FEM_elCircumSphere: compute the            */
                            /* === circumsphere radius and center             */
void FEM_elCircumSphere (
   ELEMENT_OBJ obj_elem,                  /* the elem object                  */
   DOUBLE *p_radius, VECTOR3D *p_center );/* return NULL                      */

                            /* ============================================== */
                            /* === FEM_elVolume: return approx volume of elem */
                            /* === sums volume of constituative tetrahedra    */
DOUBLE FEM_elVolume(
   ELEMENT_OBJ obj_elem );


DOUBLE FEM_elVolEdgeRatio(
   ELEMENT_OBJ obj_elem );

FEM_BOOLEAN FEM_elCoplanar(
   ELEMENT_OBJ obj_elem,
   DOUBLE      tol );


#ifdef __cplusplus
}
#endif

/*
 * === Element Macros
 */
/*
 * --- The function definition of the element macros can be used instead of
 * --- the macros themselves by including -D NO_ELEM_MACRO on the
 * --- compile line.  The equivalent functions are found in FEM_elPublicMacro.c
 * --- Note: When adding a Macro - make sure the prototype and the macro
 * ---       appear in this file.
 */
#ifndef NO_ELEM_MAC
#include "fem_Struct.h"
#endif

/*============================================================================*/
/* === Macro: FEM_elNext_C
 * === Author: sjo
 * === Description: return the next element in the linked list of elements
 * === Arguments: 
 *     ELEMENT_OBJ obj_element          current element in list
 * === Return: ELEMENT_OBJ              next element in list
 *             NULL if macro not defined for g_meshtype
 */
#ifdef NO_ELEM_MAC
ELEMENT_OBJ FEM_elNext_C ( ELEMENT_OBJ obj_element  );
#else
#define FEM_elNext_C( obj_element )\
   ((g_meshtype == STANDARD_MESH) ?\
      (ELEMENT_OBJ)(((ELEMENT_PTYP)(obj_element))->ps_next) :\
   NULL)
#endif

/*============================================================================*/
/* === Macro:  FEM_elPrevious_C
 * === Author: sjo
 * === Description: get the previous element in the linked list object
 * === Arguments: 
 *     ELEMENT_OBJ obj_element          current element in list
 * === Return: ELEMENT_OBJ              previous element in list
 *             NULL if macro not defined for g_meshtype
 */
#ifdef NO_ELEM_MAC
ELEMENT_OBJ FEM_elPrevious_C ( ELEMENT_OBJ obj_element  );
#else
#define FEM_elPrevious_C( obj_element )\
   ((g_meshtype == STANDARD_MESH) ?\
      (ELEMENT_OBJ)(((ELEMENT_PTYP)(obj_element))->ps_previous) :\
   NULL)
#endif

/*============================================================================*/
/* === Macro: FEM_elTotal_C
 * === Author: sjo
 * === Description: get the total number of elements in list
 * === Arguments: 
 *     ELEMENTLIST_OBJ obj_elist   The element list
 * === Return: INT                 total number of elements in list
 *             -1 if macro not defined for g_meshtype
 */
#ifdef NO_ELEM_MAC
INT FEM_elTotal_C ( ELEMENTLIST_OBJ obj_elist  );
#else
#define FEM_elTotal_C( obj_elist )\
   ((g_meshtype == STANDARD_MESH) ?\
      (INT)(((ELEMENTLIST_PTYP)(obj_elist))->total) :\
   -1)
#endif


/*============================================================================*/
/* === Macro: FEM_elList_C
 * === Author: sjo
 * === Description: return the head of the element linked list
 * === Arguments: 
 *     ELEMENTLIST_OBJ obj_elist      element list
 * === Return: ELEMENT_OBJ            head of element list
 *             NULL if macro not defined for g_meshtype
 */
#ifdef NO_ELEM_MAC
ELEMENT_OBJ FEM_elList_C ( ELEMENTLIST_OBJ obj_elist  );
#else
#define FEM_elList_C( obj_elist )\
   ((g_meshtype == STANDARD_MESH) ?\
      (ELEMENT_OBJ)(((ELEMENTLIST_PTYP)(obj_elist))->ps_list) :\
   NULL)
#endif
  

/*============================================================================*/
/* === Macro: FEM_elId_C
 * === Author: sjo
 * === Description: return the element id
 * === Arguments:
 *     ELEMENT_OBJ obj_element  element object
 * === Return: INT              elment id
 *             -1 if macro not defined for g_meshtype
 */
#ifdef NO_ELEM_MAC
INT FEM_elId_C ( ELEMENT_OBJ obj_element  );
#else
#define FEM_elId_C( obj_element )\
   ((g_meshtype == STANDARD_MESH) ?\
      (INT)(((ELEMENT_PTYP)(obj_element))->id) :\
   -1)
#endif
  

/*============================================================================*/
/* === Macro: FEM_elSetId_C
 * === Author: sjo
 * === Description: set the element id
 * === Arguments:
 *     ELEMENT_OBJ obj_element      element object
 *     INT elem_id                  the new element id 
 * === Return: nothing
 */
#ifdef NO_ELEM_MAC
void FEM_elSetId_C ( ELEMENT_OBJ obj_element, INT elem_id  );
#else
#define FEM_elSetId_C( obj_element, elem_id )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((ELEMENT_PTYP)(obj_element))->id = (INT)elem_id;\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }
#endif

/*============================================================================*/
/* === Macro: FEM_elParent_C
 * === Author: mls
 * === Description: return the parent element id
 * === Arguments:
 *     ELEMENT_OBJ obj_element  element object
 * === Return: INT              parent element id
 *             -1 if macro not defined for g_meshtype
 */
#ifdef NO_ELEM_MAC
INT FEM_elParent_C ( ELEMENT_OBJ obj_element  );
#else
#define FEM_elParent_C( obj_element )\
   ((g_meshtype == STANDARD_MESH) ?\
      (INT)(((ELEMENT_PTYP)(obj_element))->parent) :\
   -1)
#endif
  

/*============================================================================*/
/* === Macro: FEM_elSetParent_C
 * === Author: mls
 * === Description: set the element id
 * === Arguments:
 *     ELEMENT_OBJ obj_element      element object
 *     INT elem_id                  the new element id 
 * === Return: nothing
 */
#ifdef NO_ELEM_MAC
void FEM_elSetParent_C ( ELEMENT_OBJ obj_element, INT newparent  );
#else
#define FEM_elSetParent_C( obj_element, newparent )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((ELEMENT_PTYP)(obj_element))->parent = (INT)newparent;\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }
#endif


/*============================================================================*/
/* === Macro: FEM_elShape_C
 * === Author: sjo
 * === Description: get the element shape
 * === Arguments:
 *     ELEMENT_OBJ obj_element   element object
 * === Return: SHAPE_ENUM        shape (from SHAPE_ENUM)
 *             -1 if macro not defined for g_meshtype 
 */
#ifdef NO_ELEM_MAC
SHAPE_ENUM FEM_elShape_C ( ELEMENT_OBJ obj_element  );
#else
#define FEM_elShape_C( obj_element )\
   ((g_meshtype == STANDARD_MESH) ?\
      (SHAPE_ENUM)(((ELEMENT_PTYP)(obj_element))->shape) :\
   (SHAPE_ENUM)(-1))
#endif

/*============================================================================*/
/* === Macro: FEM_elNumEdges_C
 * === Author: mls
 * === Description: get the number of edges on this element.
 * === Arguments:
 *     ELEMENT_OBJ obj_element   element object
 * === Return: INT number of edges on this element.
 *             -1 if macro not defined for g_meshtype 
 */
#ifdef NO_ELEM_MAC
INT FEM_elNumEdges_C ( ELEMENT_OBJ obj_element  );
#else
#define FEM_elNumEdges_C( obj_element )\
   ((g_meshtype == STANDARD_MESH) ?\
      ((((ELEMENT_PTYP)(obj_element))->shape==HEX_SHAPE) ? (INT)(12) :\
       ((((ELEMENT_PTYP)(obj_element))->shape==WEDGE_SHAPE) ? (INT)(9) :\
        ((((ELEMENT_PTYP)(obj_element))->shape==PYRAMID_SHAPE) ? (INT)(8) :\
         ((((ELEMENT_PTYP)(obj_element))->shape==TET_SHAPE) ? (INT)(6) :\
          (INT)(-1)) ) ) ) : (INT)(-1))
#endif


/*============================================================================*/
/* === Macro: FEM_elSetShape_C
 * === Author: sjo
 * === Description: set the element shape
 * === Arguments: 
 *     ELEMENT_OBJ obj_element    element object
 *     SHAPE_ENUM elem_shape      the new element shape
 * === Return: nothing
 */
#ifdef NO_ELEM_MAC
void FEM_elSetShape_C ( ELEMENT_OBJ obj_element, 
                                 SHAPE_ENUM elem_shape  );
#else
#define FEM_elSetShape_C( obj_element, elem_shape )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((ELEMENT_PTYP)(obj_element))->shape = (SHAPE_ENUM)elem_shape;\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }
#endif


/*============================================================================*/
/* === Macro: FEM_elNumFaces_C
 * === Author: sjo
 * === Description: get the number of faces on the element
 * === Arguments:
 *     ELEMENT_OBJ obj_element    element object
 * === Return: INT                number of faces on the element
 *             -1 if macro not defined for g_meshtype
 */
#ifdef NO_ELEM_MAC
INT FEM_elNumFaces_C ( ELEMENT_OBJ obj_element  );
#else
#define FEM_elNumFaces_C( obj_element )\
   ((g_meshtype == STANDARD_MESH) ?\
      (INT)(((ELEMENT_PTYP)(obj_element))->numfaces) :\
   -1)
#endif


/*============================================================================*/
/* === Macro: FEM_elSetNumfaces_C
 * === Author: sjo
 * === Description: set the number of faces on the element
 * === Arguments:
 *     ELEMENT_OBJ obj_element   element object
 *     INT num_fac               number of faces on element
 * === Return: nothing
 */
#ifdef NO_ELEM_MAC
void FEM_elSetNumFaces_C ( ELEMENT_OBJ obj_element, INT num_fac  );
#else
#define FEM_elSetNumFaces_C( obj_element, num_fac )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((ELEMENT_PTYP)(obj_element))->numfaces = (INT)num_fac;\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }
#endif


/*============================================================================*/
/* === Macro: FEM_elFace_C
 * === Author: sjo
 * === Description: get the iface face object from the element
 * === Arguments: 
 *     ELEMENT_OBJ obj_element   element object
 *     INT iface                 number of face to return
 * === Return: FACE_OBJ          face object corresponding to iface
 *             NULL if macro not defined for g_meshtype
 */
#ifdef NO_ELEM_MAC
FACE_OBJ FEM_elFace_C ( ELEMENT_OBJ obj_element, INT iface  );
#else
#define FEM_elFace_C( obj_element, iface )\
   ((g_meshtype == STANDARD_MESH) ?\
      (FACE_OBJ)(((ELEMENT_PTYP)(obj_element))->aps_face_use[iface]->ps_face) :\
   (FACE_OBJ)NULL)
#endif


/*============================================================================*/
/* === Macro: FEM_elSetFace_C
 * === Author: sjo
 * === Description: set the iface face object to the element
 * === Arguments:
 *     ELEMENT_OBJ obj_element     element object
 *     INT iface                   number of face to set
 *     FACE_OBJ obj_face           new face object for the element
 * === Return:
 */
#ifdef NO_ELEM_MAC
void FEM_elSetFace_C ( ELEMENT_OBJ obj_element, 
                                INT iface, 
                                FACE_OBJ obj_face  );
#else
#define FEM_elSetFace_C( obj_element, iface, obj_face )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((ELEMENT_PTYP)(obj_element))->aps_face_use[iface]->ps_face =\
                (FACE_PTYP)(obj_face);\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }
#endif

/*============================================================================*/
/* === Macro: FEM_elProperty_C
 * === Author: sjo
 * === Description: return the status of a property for the element
 * === Arguments:
 *     ELEMENT_OBJ obj_element     element object
 *     FEM_LONG property_mask    one of the element properties specified above
 * === Return: FEM_LONG 0 or !=0      0 = not set, !=0 = set
 */
#ifdef NO_ELEM_MAC
FEM_LONG FEM_elProperty_C ( ELEMENT_OBJ obj_element, 
                                 FEM_LONG property_mask  );
#else
#define FEM_elProperty_C( obj_element, property_mask )\
   ((g_meshtype == STANDARD_MESH) ?\
      (FEM_LONG)(((ELEMENT_PTYP)(obj_element))->property & (FEM_LONG)(property_mask)) :\
   0L)
#endif

/*============================================================================*/
/* === Macro: FEM_elSetProperty_C
 * === Author: sjo
 * === Description: Set the status of a property for the element
 * === Arguments:
 *     ELEMENT_OBJ obj_element     element object
 *     FEM_LONG property_mask    one of the element properties specified above
 *     FEM_BOOLEAN status;   0 or 1, TRUE or FALSE, ON or OFF
 * === Return: 0 or !=0      0 = not set, !=0 = set
 */
#ifdef NO_ELEM_MAC
void FEM_elSetProperty_C ( ELEMENT_OBJ obj_element, 
                                    FEM_LONG property_mask, 
                                    FEM_BOOLEAN status  );
#else
#define FEM_elSetProperty_C( obj_element, property_mask, status )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         if (status) {\
            ((ELEMENT_PTYP)(obj_element))->property = \
               ((ELEMENT_PTYP)(obj_element))->property |\
               (FEM_LONG)(property_mask);\
         }\
         else {\
            if(((ELEMENT_PTYP)(obj_element))->property & \
               (FEM_LONG)(property_mask)) {\
               ((ELEMENT_PTYP)(obj_element))->property =\
                  ((ELEMENT_PTYP)(obj_element))->property ^\
                  (FEM_LONG)(property_mask);\
            }\
         }\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }
#endif

/*============================================================================*/
/* === Macro: FEM_elInitProperties_C
 * === Author: sjo
 * === Description: Initialize all properties for the element to OFF
 * === Arguments:
 *     ELEMENT_OBJ obj_element     element object
 * === Return: nothing
 */
#ifdef NO_ELEM_MAC
void FEM_elInitProperties_C ( ELEMENT_OBJ obj_element  );
#else
#define FEM_elInitProperties_C( obj_element )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((ELEMENT_PTYP)(obj_element))->property = NO_PROPERTY;\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }
#endif

/*============================================================================*/
/* === Macro: FEM_elGetAllProperties_C
 * === Author: mls
 * === Description: return the variable bit field for all properties
 * === Arguments:
 *     FACE_OBJ obj_face     face object
 * === Return: FEM_LONG the property
 */
#define FEM_elGetAllProperties_C( obj_elem )\
   ((g_meshtype == STANDARD_MESH) ?\
      (FEM_LONG)(((ELEMENT_PTYP)(obj_elem))->property) : 0L)


/*============================================================================*/
/* === Macro: FEM_elSetAllProperties_C
 * === Author: mls
 * === Description: Set the entire property bit field
 * === Arguments:
 *     FACE_OBJ obj_face     face object
 *     FEM_LONG property         the bit field
 * === Return: none
 */
#define FEM_elSetAllProperties_C( obj_elem, new_property )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((ELEMENT_PTYP)(obj_elem))->property = new_property;\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }

/*============================================================================*/
/* === Macro: FEM_elGeoEntity_C
 * === Author: sjo
 * === Description: get the element underlying geometric entity id
 * === Arguments:
 *     ELEMENT_OBJ obj_element     element object
 * === Return: INT geo_entity
 */
#ifdef NO_ELEM_MAC
INT FEM_elGeoEntity_C ( ELEMENT_OBJ obj_element  );
#else
#define FEM_elGeoEntity_C( obj_element )\
   ((g_meshtype == STANDARD_MESH) ?\
      (INT)((ELEMENT_PTYP)(obj_element))->geo_entity : -1)
#endif

/*============================================================================*/
/* === Macro: FEM_elSetGeoEntity_C
 * === Author: sjo
 * === Description: set the element underlying geometric entity id
 * === Arguments:
 *     ELEMENT_OBJ obj_element     element object
 *     INT the_entity        number of the entity (user defined)
 * === Return: void
 */
#ifdef NO_ELEM_MAC
void FEM_elSetGeoEntity_C ( ELEMENT_OBJ obj_element, INT the_entity  );
#else
#define FEM_elSetGeoEntity_C( obj_element, the_entity )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((ELEMENT_PTYP)(obj_element))->geo_entity = (INT)the_entity;\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }
#endif

/*============================================================================*/
/* === Macro: FEM_elShapeMetric_C
 * === Author: sjo
 * === Description: get the element shape metric
 * === Arguments:
 *     ELEMENT_OBJ obj_element     element object
 * === Return: DOUBLE shape_metric
 */
#ifdef NO_ELEM_MAC
void FEM_elShapeMetric_C ( ELEMENT_OBJ obj_element  );
#else
#define FEM_elShapeMetric_C( obj_element )\
   ((g_meshtype == STANDARD_MESH) ?\
      (DOUBLE)(((ELEMENT_PTYP)(obj_element))->shape_metric) :\
   -999.)
#endif

/*============================================================================*/
/* === Macro: FEM_elSetShapeMetric_C
 * === Author: sjo
 * === Description: set the element shape metric
 * === Arguments:
 *     ELEMENT_OBJ obj_element     element object
 *     DOUBLE the_metric     the element shape metric
 * === Return: nothing
 */
#ifdef NO_ELEM_MAC
void FEM_elSetShapeMetric_C ( ELEMENT_OBJ obj_element, 
                                       DOUBLE the_metric  );
#else
#define FEM_elSetShapeMetric_C( obj_element, the_metric )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((ELEMENT_PTYP)(obj_element))->shape_metric = (DOUBLE)(the_metric);\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }
#endif

/*============================================================================*/
/* === Macro: FEM_elGenericPointer_MAC
 * === Author: mls
 * === Description: retreive the generic pointer from the element object
 * === Arguments:
 *     ELEMENT_OBJ obj_elem     element object
 * === Return: (void *) a generic pointer (must be caste to correct type)
 */
#define FEM_elGenericPointer_MAC( obj_elem )\
   ((g_meshtype == STANDARD_MESH) ?\
      (((ELEMENT_PTYP)(obj_elem))->p_info) :\
   NULL)

/*============================================================================*/
/* === Macro: FEM_elSetGenericPointer_C
 * === Author: sjo
 * === Description: set a generic pointer into the elem object
 * === Arguments:
 *     EDGE_OBJ obj_element    element object
 *     ADDRESS_TYP obj_entity  any object entity or generic void pointer
 * === Return: void
 */
#define FEM_elSetGenericPointer_C( obj_elem, obj_entity )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((ELEMENT_PTYP)(obj_elem))->p_info = (ADDRESS_TYP)obj_entity;\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }

/*============================================================================*/
/* === Macro: FEM_elTetEdgeNodeIndex_C
 * === Author: mls
 * === Description: get the index of node_index_th node of the edge_index_th
 * ===              edge on a tetrahedral element
 * === Arguments:
 *     INT edge_index          edge index with respect to tetrahedral element
 *     INT node_index          node index with respect to edge #edge_index
 * === Return: node index on the tetrahedral element.
 */
#define FEM_elTetEdgeNodeIndex_C( edge_index, node_index )\
   ((g_meshtype == STANDARD_MESH) ?\
         TET_EDGE_NODE[edge_index][node_index] : -999 )

/*============================================================================*/
/* === Macro: FEM_elHexEdgeNodeIndex_C
 * === Author: mls
 * === Description: get the index of node_index_th node of the edge_index_th
 * ===              edge on a hexahedral element
 * === Arguments:
 *     INT edge_index          edge index with respect to hexahedral element
 *     INT node_index          node index with respect to edge #edge_index
 * === Return: node index on the hexahedral element.
 */
#define FEM_elHexEdgeNodeIndex_C( edge_index, node_index )\
   ((g_meshtype == STANDARD_MESH) ?\
         HEX_EDGE_NODE[edge_index][node_index] : -999 )

/*============================================================================*/
/* === Macro: FEM_elTetFaceNodeIndices_C
 * === Author: mls
 * === Description: get the indices of nodes of the face_index_th
 * ===              face on a tetrahedral element
 * === Arguments:
 *     INT face_index          face index with respect to tetrahedral element
 *     INT node_index1         RETURNED node index with respect to tet numbering
 *     INT node_index2         RETURNED node index with respect to tet numbering
 *     INT node_index3         RETURNED node index with respect to tet numbering
 * === Return: nothing
 */
#define FEM_elTetFaceNodeIndices_C( face_index, index1, index2, index3 )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         index1 = TET_FACE_NODE[face_index][0];\
         index2 = TET_FACE_NODE[face_index][1];\
         index3 = TET_FACE_NODE[face_index][2];\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }

/*============================================================================*/
/* === Macro: FEM_elHexFaceNodeIndices_C
 * === Author: mls
 * === Description: get the indices of nodes of the face_index_th
 * ===              face on a hexahedral element
 * === Arguments:
 *     INT face_index          face index with respect to hexahedral element
 *     INT index1              RETURNED node index with respect to hex numbering
 *     INT index2              RETURNED node index with respect to hex numbering
 *     INT index3              RETURNED node index with respect to hex numbering
 *     INT index4              RETURNED node index with respect to hex numbering
 * === Return: nothing
 */
#define FEM_elHexFaceNodeIndices_C( face_index, index1, index2,\
                                    index3, index4 )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         index1 = HEX_FACE_NODE[face_index][0];\
         index2 = HEX_FACE_NODE[face_index][1];\
         index3 = HEX_FACE_NODE[face_index][2];\
         index4 = HEX_FACE_NODE[face_index][3];\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }

/*============================================================================*/
/* === Macro: FEM_elSetLazyElements_C
 * === Author: jrt
 */
#define   FEM_elSetLazyElements_C(obj_elist, bLazyElements )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         (((ELEMENTLIST_PTYP)(obj_elist))->bLazyElementsExist) = (bLazyElements);\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }

/*============================================================================*/
/* === Macro: FEM_elGetLazyElements_C
 * === Author: jrt
 */
#define FEM_elGetLazyElements_C(obj_elist)\
   ((g_meshtype == STANDARD_MESH) ?(FEM_BOOLEAN)((ELEMENTLIST_PTYP)(obj_elist))->bLazyElementsExist:0)  

#endif
