
/* globalmapped.h -- mapped table data type ycl*/

struct mapped_type {
  INT  setupTag;                 /* tag for data used to setup for solver iterations */
  INT  solveTag;                 /* tag for data used during the solver iterations   */
  INT **localToglobalNode;
  INT **globalTolocalNode;
  INT **localToglobalNodeStart;
  INT **localToglobalNodeExt;
  INT **localToglobalElem;
  INT **globalTolocalElem;
  INT *localUlength;
  INT *localNumNodes;
  INT **localToglobalEq;
  INT *localnCe;
  INT **globalTolocalCEmapFull;
  INT **localToglobalV;
  INT **localToglobalG;
  INT *localVlength;
  INT *localGlength;
  INT *localNumSuperNodes;
  INT **localToglobalSuperNode;
  INT **localToglobalSuperNodeStart;
  INT *localDistGlength;
  INT **localToGlobalDistG;

  INT **localToglobalACG;
  INT *localACGlength;

  INT **gToL_AcCEmapFull;
  INT *localAcCe;
};

#define mpSetupTag(mp)                     (mp->setupTag)
#define mpSolveTag(mp)                     (mp->solveTag)
#define mpSize(mp)                         (mp->ndomain)
#define mplclToGlbNodeFull(mp)             (mp->localToglobalNode)
#define mplclToGlbNode(mp,i)               (mplclToGlbNodeFull(mp)[i])
#define mpGlbTolclNodeFull(mp)             (mp->globalTolocalNode)
#define mpGlbTolclNode(mp,i)               (mpGlbTolclNodeFull(mp)[i])
#define mplclToGlbNodeStart(mp)            (mp->localToglobalNodeStart)
#define mplclToGlbStart(mp,i)              (mplclToGlbNodeStart(mp)[i])
#define mplclToGlbNodeExt(mp)              (mp->localToglobalNodeExt)
#define mplclToGlbExt(mp,i)                (mplclToGlbNodeExt(mp)[i])
#define mplclToGlbElemFull(mp)             (mp->localToglobalElem)
#define mplclToGlbElem(mp,i)               (mplclToGlbElemFull(mp)[i])
#define mpGlbTolclElemFull(mp)             (mp->globalTolocalElem)
#define mpGlbTolclElem(mp,i)               (mpGlbTolclElemFull(mp)[i])
#define mplclUlength(mp)                   (mp->localUlength)
#define mplclUlengthDomain(mp,i)           (mplclUlength(mp)[i])
#define mplclNumNodes(mp)                  (mp->localNumNodes)
#define mplclNumNodesDomain(mp,i)          (mplclNumNodes(mp)[i])
#define mplclToGlbEqFull(mp)               (mp->localToglobalEq)
#define mplclToGlbEq(mp,i)                 (mplclToGlbEqFull(mp)[i])
#define mplcnCe(mp)                        (mp->localnCe)
#define mplcnCeDomain(mp,i)                (mplcnCe(mp)[i])
#define mpGlbTolcCEmapFull(mp)             (mp->globalTolocalCEmapFull)
#define mpGlbTolcCEmap(mp,i)               (mpGlbTolcCEmapFull(mp)[i])
#define mplclToGlbVeqn(mp)                 (mp->localToglobalV)
#define mplclToGlbGeqn(mp)                 (mp->localToglobalG)
#define mplclToGlbVeqnI(mp,i)              (mplclToGlbVeqn(mp)[i])
#define mplclToGlbGeqnI(mp,i)              (mplclToGlbGeqn(mp)[i])
#define mplclVlength(mp)                   (mp->localVlength)
#define mplclGlength(mp)                   (mp->localGlength)
#define mplclVlengthI(mp,i)                (mplclVlength(mp)[i])
#define mplclGlengthI(mp,i)                (mplclGlength(mp)[i])
#define mplclNumSuperNodes(mp)             (mp->localNumSuperNodes)
#define mplclNumSuperNodesDomain(mp,i)     (mplclNumSuperNodes(mp)[i])
#define mplclToGlbSuperNodeFull(mp)        (mp->localToglobalSuperNode)
#define mplclToGlbSuperNode(mp,i)          (mplclToGlbSuperNodeFull(mp)[i])
#define mplclToGlbSuperNodeStartFull(mp)   (mp->localToglobalSuperNodeStart)
#define mplclToGlbSuperNodeStart(mp,i)     (mplclToGlbSuperNodeStartFull(mp)[i])
#define mplclDistGlength(mp)               (mp->localDistGlength)
#define mplclDistGlengthDomain(mp,i)       (mplclDistGlength(mp)[i])
#define mplclToGlbDistG(mp)                (mp->localToGlobalDistG)
#define mplclToGlbDistGDomain(mp,i)        (mplclToGlbDistG(mp)[i])

#define mplclToGlbACGeqn(mp)               (mp->localToglobalACG)
#define mplclToGlbACGeqnI(mp,i)            (mplclToGlbACGeqn(mp)[i])
#define mplclACGlength(mp)                 (mp->localACGlength)
#define mplclACGlengthI(mp,i)              (mplclACGlength(mp)[i])

#define mpGToL_AcCEmapFull(mp)             (mp->gToL_AcCEmapFull)
#define mpGToL_AcCEmap(mp,i)               (mpGToL_AcCEmapFull(mp)[i])
#define mplcAcCe(mp)                       (mp->localAcCe)
#define mplcAcCeDomain(mp,i)               (mplcAcCe(mp)[i])
