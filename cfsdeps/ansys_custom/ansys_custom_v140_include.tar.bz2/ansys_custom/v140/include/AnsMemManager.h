/*
 *    AnsMemManager.h
 */

/* *** copyright(c) 2010 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */

#if !defined(__ANSMEMMANAGER_H__)
#define __ANSMEMMANAGER_H__ 1

#include "ansys.h"

/*
 *  Some assumptions and limits of the manager
 *
 *  the memory table can be indexed via an integer (i.e. there are not more open
 *  memory blocks than an integer can hold).
 *
 *  sizes are specified internally and externally in bytes
 */



/*
 * Blocks are stored in the manager as pointers and lengths.  Blocks also store
 * (in the actual memory area) a "back-pointer" to the memory table that tells
 * the manager where the record for this block can be found.  This will allow
 * constant time freeing of memory.  The memory blocks look like this in memory:
 *
 * Memory addresses
 * -----+-------------+-------------------------------+----------+--------------
 *      | back-       |                               | next     |         
 * ...  | pointer     | User's requested data length  | back-    | user data ...
 *      | (an int)    |                               | pointer  |         
 * -----+-------------+-------------------------------+----------+--------------
 *      ^             ^                               ^          ^
 *      |             |                               |          |
 *      |             |                   next address stored    |
 * start of memory    |                   in memory table        |
 * block (value       |                                          |
 * stored in table)   |                                    next pointer returned
 *                    |                                       to user
 *               pointer returned to user via AnsMemAlloc
 *
 * The pointer returned to the user must be aligned for the worst case on the
 * current machine.  Therefore, the addresses stored in the memory table may not
 * be properly aligned for the machine (almost definitely, unless doubles are 
 * the same size as integers, or the manager gets re-written to handle more 
 * records in the memory table than an integer can index).
 */


/* 
 * MASSAGE_LENGTH_WITH_BACKPOINTER will recalculate the given length so that 
 * it contains enough room for an extra integer (the back-pointer for 
 * the memory table), and also is a multiple of the alignment criterion in length.
 */
#define MASSAGE_LENGTH_WITH_BACKPOINTER(x) (((((x)+sizeof(INT)) + \
                                 (MM.alignment-1)) \
                                 / MM.alignment) \
                                 * MM.alignment)

/*
 * 
 * MASSAGE_LENGTH will recalculate the a given length so that it is a multiple of the
 * alignment criterion.
 */
#define MASSAGE_LENGTH(x) ((((x) + MM.alignment-1) \
                            / MM.alignment) \
                            * MM.alignment)

/*
 * ALIGN_POOL_POINTER will recalculate a pointer for a pool (from malloc) so that
 * it is always one integer behind the alignment criterion boundary.
 */
#define ALIGN_POOL_POINTER(x) ((void *)(((((PTR)(x) \
                           + sizeof(INT)) + (MM.alignment-1)) \
                           / MM.alignment) \
                           * MM.alignment - sizeof(INT))) \

/*
 * ALIGNMENT_DELTA is the maximum size that will need to be added to 
 * a block to bring its pointer to the next memory alignment boundary.
 */
#define ALIGNMENT_DELTA (MM.alignment-1)


/*
 * UPDATE_MANAGEMENT_OVERHEAD will recalculate the amount of memory that is 
 * being used by the manager itself and assign to managementOverhead member of 
 * the manager.
 */
#define UPDATE_MANAGEMENT_OVERHEAD MM.managementOverhead = \
   sizeof(MemAlign) + \
   MM.table.size * sizeof(MemNode) + \
   sizeof(MemManager) + \
   sizeof(MemTable) + \
   MM.numMemPools * sizeof(MemPool)

/* 
 *  User defined types for the memory manager
 */

/* define a structure to calculate memory alignments */
typedef struct MemAlignTag {
   CHAR x;
   DOUBLE offset;
} MemAlign;

/* define structure for a node in the linked list of used nodes */
typedef struct MemNodeTag {
   INT next;                      /* next node in list's index in table */
   INT prev;                      /* previous node in list's index in table */
   size_t size;                   /* size of the memory block (includes the 
                                     backpointer index) */
   void *address;                 /* pointer to the memory block */
   INT poolNum;                   /* the pool number this block is located in */
   SHORT usedOrFree;              /* used/free status for this block */
   SHORT lockOrUnlock;            /* locked/unlocked status for this block */
} MemNode;

/* define the accessor for the memory table (actually a linked list) */
typedef struct MemTableTag {
   INT head;                      /* head for the circularly linked list */
   INT size;                      /* current size of the table */
   INT usedToHere;                /* all records to this point are used */
   INT lastUnused;                /* the last record marked used was here
                                     (ie this is available) */
   INT highestUsed;               /* the highest record marked as used */
   INT finger;                    /* finger to the "current" spot in the list */
   MemNode *ptr;                  /* pointer to the table itself */
} MemTable;

/* define a pool of memory */
typedef struct MemPoolTag {
   void *mallocPtr;               /* the pointer returned by malloc for this pool */
   void *poolPtr;                 /* the pointer used to access the pool's 
                                     memory (may be moved based on alignment 
                                     concerns */
   size_t size;                   /* the size of this pool */
   INT numBlocks;                 /* the number of blocks in this mem pool 
                                     (used or free) */
} MemPool;

/* define the memory manager data structure */
typedef struct MemManagerTag {
   MemPool *pools;                /* array of memory pools */
   INT numMemPools;               /* current number of memory pools (this is the
                                     number of pool items in the list, NOT the 
                                     actual number of malloced memory pools) */
   INT maxNumMemPools;            /* the maximum number of pools the manager is 
                                     allowed to manage (will set a limit to the
                                     manager's size if used) */
   size_t growthPoolSize;         /* size of growth pools */
   MemTable table;                /* the memory table */
   UNSIGNED_INT debug;            /* debug level */
   UNSIGNED_INT debugMask;        /* mask to apply to all debug settings */
   UNSIGNED_INT alignment;        /* the memory alignment criterion for this 
                                     platform */
   size_t blockSplitTolerance;    /* the minimal amount of memory (in bytes) to
                                     leave in a free block when the manager 
                                     needs to perform a split on a memory 
                                     block */
   size_t maxMemSize;             /* "high-water mark" for memory usage by client */
   size_t currentMemSize;         /* current amount of memory used by client */
   size_t managementOverhead;     /* cost of the manager itself */
   size_t maxMemImage;            /* "high-water mark" for the amount of memory
                                     actually malloced by manager */
   size_t currentMemImage;        /* current amount of memory actually malloced
                                     by manager */
   size_t maxMemSizePersist;      /* persistent version of the maxMemSize 
                                     -- it does not get reset on destroys or 
                                     inits */
   size_t maxMemImagePersist;     /* persistent version of the maxMemImage
                                     -- it does not get reset on destroys or 
                                     inits */
   PTR lowAddress;                /* lowest address the manager may return when
                                     allocating in restricted mode */
   PTR highAddress;               /* highest address the manager may return when
                                     allocating in restricted mode */
   DOUBLE fragRatio;              /* ratio of largest free block size to amount
                                     of free memory being managed */
   DOUBLE fragRatioLevel;         /* level of fragmentation to monitor */
   SHORT initialized;             /* if 0, manager is not initialized
                                     if 1, manager is initialized */

   INT trackDepth;                /* memory manager tracking depth */
   INT trackLevel;                /* level of routine to watch */
   INT iTrack;                    /* index to use on tracking reports */
} MemManager;


/* define prototypes for the manager */
INT MallocGrowthPool(size_t blockSize);
INT CreateMemNode(void);
INT SplitMemBlock(INT thisNodeNum, size_t size);
INT FindMemLeaks(void);
void AnsMemJournal(INT messageCode, void *value);
void DestroyMemNode(INT memNodeNum); 
INT GetMemoryTableIndex(void *ptr);
INT MergeMemBlocks(INT lowerNodeNum, INT upperNodeNum, INT checkFree);
void UpdateMemImageSizes(void);
size_t CurrentLargestBlockSize(INT type);
UNSIGNED_INT CalculateProperAlignment(UNSIGNED_INT reqAlignment);
DOUBLE CalculateFragmentationRatio(SHORT force);
void *cmalloc(size_t size);
void cfree(void *ptr);
void *crealloc(void *ptr, size_t size);
MemManager *GetLowMemManager(void);
INT FreePool(INT freeNodeNum);
INT AnsMemDetermineFailure(INT blockLen, INT elemSize, INT key);

void AnsMemLowError(CHAR *format, ...);
void AnsMemLowDebugMessage(CHAR *format, ...);
void AnsMemLowWarningMessage(CHAR *format, ...);
void AnsMemLowOutputOperation(CHAR *format, ...);
PTR CountBlocks(SHORT code);


/* these prototypes are specific to the ANSYS implementation */

#ifdef __cplusplus
extern "C" {
#endif

void erhandlerc(CHAR *filein,INT msgid,INT level,CHAR *msg,DOUBLE dpVec[],INT dplen, CHAR *cvar, INT cvpnum);
void anserrc(INT, CHAR *);

#ifdef __cplusplus
}
#endif

#endif
