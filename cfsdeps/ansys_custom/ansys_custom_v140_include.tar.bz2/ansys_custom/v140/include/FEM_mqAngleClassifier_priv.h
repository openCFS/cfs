#ifndef _FEM_MQANGLECLASSIFIER_PRIV_
#define _FEM_MQANGLECLASSIFIER_PRIV_

#include <map>

class CAngles
{
private:
        DOUBLE m_dCorner;
        DOUBLE m_dEnd;
        DOUBLE m_dSide;
public:
    CAngles()
    {
        resetAnlges();
    }

    void resetAnlges();
 
    inline void setCorner( DOUBLE dCorner ) { m_dCorner = dCorner;};
    inline DOUBLE getCorner() { return m_dCorner;};

    inline void setEnd( DOUBLE dEnd ) { m_dEnd = dEnd;};
    inline DOUBLE getEnd() { return m_dEnd;};

    inline void setSide( DOUBLE dSide ) { m_dSide = dSide;};
    inline DOUBLE getSide() { return m_dSide;};
};

class CMQAngleClassifer
{
   private:
       std::map<INT,CAngles *> m_cAreaToAngles;
   public:
       CMQAngleClassifer() {};
       ~CMQAngleClassifer();
       void setAreaAngles(INT iAreaId, CAngles *pcAngles);
       CAngles* getAreaAngles( INT iAreaId );
       void resetAreaAngles( INT iAreaId );
       void clear();
};

#endif
