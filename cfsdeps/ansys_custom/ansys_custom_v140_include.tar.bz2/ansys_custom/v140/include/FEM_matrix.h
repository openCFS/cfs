/* ********************************** */
/* *** ansys(r) copyright(c) 2009 *** */
/* *** ansys, inc.                *** */
/* ********************************** */

/*  FEM_array.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_array.h
 *  header file for FEM_array.c
 *
 */
/* *** mpg math array c
 FEM_array.c FEM_matrix.c FEM_MeshTable.h FEM_Public.h FEM_array.h
 FEM_array_static.h  FEM_cdbtypes.h FEM_edPublic.h FEM_elPublic.h
 FEM_errors.h FEM_external.h FEM_faPublic.h FEM_matrix.h
 FEM_matrix_static.h FEM_meshTree.h FEM_noGeom.h FEM_noPublic.h
 FEM_publicElementDefinition.h fem_Struct.h
 ansproto.h computer.h float.h globals.h mathfun.h
*/
#ifndef FEM_ARRAY_INCLUDE
#define FEM_ARRAY_INCLUDE

/*----------------- Globally accessible function prototypes -----------------*/

#ifdef __cplusplus
extern "C" {
#endif

                        /* ================================================= */
                        /* === FEM_mxZero: Zero out a matrix.                */
                        /* === Return: void                                  */
                        /* ================================================= */
void FEM_mxZero(
   DOUBLE a_mat[4][4] );/* (IN/OUT) matrix to zero out.                      */
                        /* ================================================= */

                        /* ================================================= */
                        /* === FEM_mxVectMult: Multiply a vector by a matrix.*/
                        /* === Return: void                                  */
                        /* ================================================= */
void FEM_mxVectMult(
   DOUBLE a_vect[4],    /* (IN)  a vector                                    */
   DOUBLE a_mat2[4][4], /* (IN)  a matrix                                    */
   DOUBLE a_ans[4] );   /* (OUT) the result                                  */
                        /* ================================================= */

                        /* ================================================= */
                        /* === FEM_mxMult: Multiply 2 matrices.              */
                        /* === Return: void                                  */
                        /* ================================================= */
void FEM_mxMult(
   DOUBLE a_mat1[4][4], /* (IN)  matrix1                                     */
   DOUBLE a_mat2[4][4], /* (IN)  matrix2                                     */
   DOUBLE a_ans[4][4] );/* (OUT) the result                                  */
                        /* ================================================= */

#ifdef __cplusplus
}
#endif

#endif

