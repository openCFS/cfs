/*HFILE cansmpi_interface.h    ANSI_C                <jrb, 03/01/2011> */
/*---------------------------------------------------------------------*/
/*
------------------------------------------------------------------------
------- Notice - This file contains ANSYS Confidential information
------------------------------------------------------------------------
*/

/*------------------------------ Description ---------------------------
\Author:   Jeff Beisheim
\Title:    C interface to MPI routines
\Desc:     C interface to MPI routines

\History:  Created 3/1/11 (jrb): extracted from ansMPIComm.c

\Function(s)
 -Primary:   To provide an interface for ANSYS to the standard MPI libraries
 -Secondary: Perform stats tracking operations for all MPI calls
 -External:
 -Internal:  None
 -Static:    None

----------------------------------------------------------------------*/


#ifndef CANSMPI_INTERFACE_H__
#define CANSMPI_INTERFACE_H__ 1

#ifdef __cplusplus
extern "C" {
#endif


/* initialization and termination routines */
INT      cMPI_Initialized(INT*);
INT      cMPI_Init(INT*, char**[]);
INT      cMPI_Finalize(void);
INT      cMPI_Abort(INT, INT);

/* point-to-point communication routines */
INT      cMPI_Send(void*, INT, INT, INT, INT, INT);
INT      cMPI_Bsend(void*, INT, INT, INT, INT, INT);
INT      cMPI_Isend(void*, INT, INT, INT, INT, INT, INT*);
INT      cMPI_Recv(void*, INT, INT, INT, INT, INT, INT*);
INT      cMPI_Irecv(void*, INT, INT, INT, INT, INT, INT*);

/* collective communication routines */
INT      cMPI_Reduce(void*, void*, INT, INT, INT, INT, INT);
INT      cMPI_Allreduce(void*, void*, INT, INT, INT, INT);
INT      cMPI_Scan(void*, void*, INT, INT, INT, INT);
INT      cMPI_Bcast(void*, INT, INT, INT, INT);
INT      cMPI_Gather(void*, INT, INT, void*, INT, INT, INT, INT);
INT      cMPI_Gatherv(void*, INT, INT, void*, INT*, INT*, INT, INT, INT);
INT      cMPI_Scatter(void*, INT, INT, void*, INT, INT, INT, INT);
INT      cMPI_Scatterv(void*, INT*, INT*, INT, void*, INT, INT, INT, INT);
INT      cMPI_Allgather(void*, INT, INT, void*, INT, INT, INT);
INT      cMPI_Allgatherv(void*, INT, INT, void*, INT*, INT*, INT, INT);
INT      cMPI_Alltoall(void*, INT, INT, void*, INT, INT, INT);
INT      cMPI_Alltoallv(void*, INT*, INT*, INT, void*, INT*, INT*, INT, INT);
INT      cMPI_Barrier(INT);

/* message utility routines */
INT      cMPI_Iprobe(INT, INT, INT, INT*, INT*);
INT      cMPI_Get_count(INT*, INT, INT*);

/* request utility routines */
INT      cMPI_Test(INT*, INT*, INT*);
INT      cMPI_Testsome(INT, INT*, INT*, INT*, INT*);
INT      cMPI_Wait(INT*, INT*);
INT      cMPI_Waitany(INT, INT*, INT*, INT*);
INT      cMPI_Waitall(INT, INT*, INT*);
INT      cMPI_Request_free(INT*);
INT      cMPI_Cancel(INT*);

/* communicator utility routines */
INT      cMPI_Comm_group(INT, INT*);
INT      cMPI_Group_incl(INT, INT, INT*, INT*);
INT      cMPI_Comm_create(INT, INT, INT*);
INT      cMPI_Comm_dup(INT, INT*);
INT      cMPI_Comm_split(INT, INT, INT, INT*);
INT      cMPI_Group_translate_ranks(INT, INT, INT*, INT, INT*);
INT      cMPI_Group_free(INT*);
INT      cMPI_Comm_free(INT*);
INT      cMPI_Comm_size(INT, INT*);
INT      cMPI_Comm_rank(INT, INT*);

/* process toplogy utility routines */
INT      cMPI_Dims_create(INT, INT, INT*);
INT      cMPI_Cart_create(INT, INT, INT*, INT*, INT, INT*);
INT      cMPI_Cart_dim_get(INT, INT*);
INT      cMPI_Cart_get(INT, INT, INT*, INT*, INT*);
INT      cMPI_Cart_rank(INT, INT*, INT*);
INT      cMPI_Cart_coords(INT, INT, INT, INT*);
INT      cMPI_Cart_sub(INT, INT*, INT*);

/* error handling utility routines */
INT      cMPI_Error_string(INT,char*,INT*);
INT      cMPI_Comm_create_errhandler(void*, INT*);
INT      cMPI_Comm_set_errhandler(INT, INT);
INT      cMPI_Comm_get_errhandler(INT, INT*);

/* miscellaneous utility routines */
INT      cMPI_Buffer_attach(void*, INT);
INT      cMPI_Buffer_detach(void*, INT*);
INT      cMPI_Get_processor_name(char*, INT*);
DOUBLE   cMPI_Wtime();
DOUBLE   cMPI_Wtick();
INT      cMPI_Get_parameter(INT);


#ifdef __cplusplus
}
#endif

#endif  /* ANSMPICTOF_H__ */
