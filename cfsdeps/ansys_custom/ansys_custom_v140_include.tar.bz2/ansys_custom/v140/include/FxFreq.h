/* ---------------------------------------------------------------------- */
/* ***  copyright(c) 2011 SAS IP, Inc.  All rights reserved.                                         */
/* *** ansys, inc.                                                        */
/* ---------------------------------------------------------------------- */
/*
 *    author/date: Stefan Reh  2002-02-06
 *
 *    primary function:
 *
 *        header for prototype definitions in ANSI C
 *
 *    Notice - This file contains ANSYS Confidential information ***
 *
 */

#ifndef _FX_FREQ_H_
#define _FX_FREQ_H_

extern int	PutFxFreqSettings ( char[], double, double, int );
extern char	*FxFreqGetName(void);
extern void	FxFreq_end( void);

#endif /* _FX_FREQ_H_ */
