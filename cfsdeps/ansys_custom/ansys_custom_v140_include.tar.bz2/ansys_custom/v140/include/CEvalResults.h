/*! \file CEvalResults.h

  \brief This header file defines the CEvalResults class.

  \author Stephane MARGUERIN &copy; CADOE

  \date 20 April 2002

  \version $Id: CEvalResults.h,v 1.3 2009/11/13 16:13:02 jtm Exp $

 */

#ifndef __CEvalResults_h__ 
#define __CEvalResults_h__ 1 

#include "CCadoePortable.h"

typedef struct {
  char* xTitle;
  char* yTitle;
  char* title;
  char* subTitle;
  int nb_pts;
  double* x;
  double* y;
} T_courbe;

/*! \class CEvalResults CEvalResults.h
  \brief The CEvalResults class is a container for the scalar results
  returned by the evaluation process. 

  It is organized in a number of results depending on the post
  type you have chosen at the CEvalProcess creation time. In the most general case,
  one result contains all the values for one y-line (X direction, Y value) and it
  holds the values for all the criteria selected.
  
  Call getNumberOfResults() to retrieve the number of results.

  Each result provides different sets of data. \em X, \em results and
  \em accuracy have the same dimension that can be retrieved by
  calling getNumberOfData(). \em Y contains only one value by result because of the y-line
  structure of the storage.

  Call getX(), getY(), getResults() and getAccuracy() to obtain a
  pointer to an array of values (or the unique value for Y) for a given result and criterion.

  The CEvalResults is memory independent: the deletion of its parent
  CEvalProcess has no effect on it, so you can keep it on your side as
  long as you need it. 

  \warning This class handles only scalar results. For field results, see
  CEvalResultsField.

 */
class CEvalResults
{
public:
  //! default constructor
  CEvalResults();
  //! destructor
  ~CEvalResults();

  /*! \brief retrieve the number of results
    \return number of results
  */
  int getNumberOfResults(void) { return _numRes; }
  
  /*! \brief retrieve the number of data in a result
    \return number of data
  */
  int getNumberOfData(void) { return _blockSize; }

  
  /*! \brief returns a pointer to the array of X values for one given result.
    \param iRes result number
    \return pointer to the array of X values
  */
  double * getX( int iRes );

  /*! \brief returns the Y values for one given result.
    \param iRes result number
    \return Y value
  */
  double getY( int iRes );
  /*! \brief returns a pointer to the array of values for the result
    \param iRes result number
    \param criterionId internal id of the criterion to return
  \param resultsSize output, gives the size of the return results array
    \return pointer to the result's values
  */
  double * getResults( int iRes, int criterionId, int *resultsSize=NULL );
  /*! \brief returns a pointer to the array of accuracy values for the result
    \param iRes results number
    \param criterionId internal id of the criterion to return
    \return pointer to the array of accuracy values
  */
  double * getAccuracy( int iRes, int criterionId );
  int * getLocation( int iRes, int criterionId );

  string& getResOptim() { return _res_optim; }
  void setResOptim(string str) { _res_optim = str; }
  T_courbe* getCourbes(int* nb) { *nb = _nb_courbes; return _courbes; }
  void setCourbes(int nb,T_courbe* courbes) { _nb_courbes = nb; _courbes = courbes; }
  //  T_optim* getOptim() { return _optim; }
  //  void setOptim(T_optim* opt { _optim = opt; }

  // internal usage only

  int initialize( int nbCrit, int nbXDir, int nbXStep, int nbYDir, int nbYStep, bool withAccuracy=false );
  void release(void);

  void setCritId( int pos, int criterionId ) { _critPos[criterionId] = pos; }
  void setX( int iBlock, int iStep, double xVal);
  void setY( int iBlock, double yVal );
  void setResult( int iRes, int criterionId, int iStep, double result );
  void setAccuracy( int iRes, int criterionId, int iStep, double accuracy );
  void setLocation( int iRes, int criterionId, int iStep, int location );

private:
  CEvalResults( const CEvalResults &res );
  CEvalResults& operator =( const CEvalResults &res);

  int     _numBlocks; // number of result blocks (block= 1 curve, 1 histogram bar, ...)
  int     _blockSize; // number of data for each block
  double  *_x;    // X axis values
  double  *_y;    // Y axis value
  double  *_results;  // results values
  double  *_resAccuracy;  // accuracy on the results
  int   *_resLocation;  // location of results

  int     _numRes;
  int     _numCrit; 
  int     _numXDir; 
  int     _numXStep; 
  int     _numYDir; 
  int     _numYStep;
  bool    _withAccuracy;
  map<int,int> _critPos; // position order of the criteria selected
  
  //  T_optim* _optim;
  string _res_optim;
  T_courbe* _courbes;
  int _nb_courbes;
};

#endif
