#ifndef DEBUG_______________H
#define DEBUG_______________H

/* prototypes for debug printing by other files */

#ifdef __cplusplus
extern "C" {
#endif

void debug_print(lprec *lp, char *format, ...);
void debug_print_solution(lprec *lp);
void debug_print_bounds(lprec *lp, REAL *upbo, REAL *lowbo);

#ifdef __cplusplus
}
#endif

#endif

