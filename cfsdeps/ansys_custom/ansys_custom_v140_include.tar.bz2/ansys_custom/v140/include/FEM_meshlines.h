/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 2009 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_meshlines.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_meshlines.h
 *  header file for FEM_meshlines.cpp
 *
 */
#ifndef FEM_MESHLINES_________________H
#define FEM_MESHLINES_________________H

/*----------------- Globally datatypes --------------------------------------*/

typedef struct SIZEFUNC_TYP {
   INT id;
   INT ndiv;
   DOUBLE *a_sizefunc;
   INT closed;
} SIZEFUNC_TYP;

typedef struct SIZEFUNC_TYP  *SIZEFUNC_PTYP;

/*----------------- Globally accessible function prototypes -----------------*/

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
                               /* =========================================== */
                               /* === FEM_mlMeshLines: mesh all lines in a    */
                               /* === model.                                  */
                               /* === Return: EXIT_SUCCESS or EXIT_FAILURE    */
                               /* =========================================== */
INT FEM_mlMeshLines(
   MODEL_TYP &model );         /* (IN)  The model to mesh the lines in.       */
                               /* =========================================== */
#endif

                               /* =========================================== */
                               /* === FEM_mlInitLines: Save information about */
                               /* === the goal number of divisions on the     */
                               /* === lines in this model.  This is called    */
                               /* === before you call any FEM_meshvols.  Once */
                               /* === Smart sizing is implemented in the C    */
                               /* === Meshing Database, this will not be      */
                               /* === necessary.                              */
                               /* =========================================== */
INT FEM_mlInitLines(
   INT numlines,               /* (IN)  number of lines being passed in.      */
   INT *a_lines,               /* (IN)  id of each line.                      */
   SIZEFUNC_PTYP a_ndfunc );   /* (IN)  Array of nodal functions for each     */
                               /*       line.                                 */
                               /* =========================================== */

                               /* =========================================== */
                               /* === FEM_mlDelete: Cleanup memory, etc. used */
                               /* === by this module.                         */
                               /* =========================================== */
void FEM_mlDelete( void );

#ifdef __cplusplus
}
#endif

#endif

