/* 
 * *** copyright(c) 2011 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */

#if defined(RS6000_SYS) || defined(HP32_SYS)
#define d2aatk_ d2aatk
#define hp_gl_d2altk_ hp_gl_d2altk
#define d2artk_ d2artk
#define d2betk_ d2betk
#define d2fotk_ d2fotk
#define d2mstk_ d2mstk
#define d2bmtk_ d2bmtk
#define d2cetk_ d2cetk
#define d2citk_ d2citk
#define d2cmtk_ d2cmtk
#define d2cotk_ d2cotk
#define d2cptk_ d2cptk
#define d2cstk_ d2cstk
#define d2crtk_ d2crtk
#define d2cttk_ d2cttk
#define d2ditk_ d2ditk
#define d2drtk_ d2drtk
#define d2dttk_ d2dttk
#define d2entk_ d2entk
#define d2evtk_ d2evtk
#define d2gctk_ d2gctk
#define d2ggtk_ d2ggtk
#define d2gmtk_ d2gmtk
#define d2iftk_ d2iftk
#define d2iqtk_ d2iqtk
#define d2iwtk_ d2iwtk
#define d2kctk_ d2kctk
#define d2kitk_ d2kitk
#define d2kotk_ d2kotk
#define d2lttk_ d2lttk
#define d2lutk_ d2lutk
#define d2lwtk_ d2lwtk
#define d2mvtk_ d2mvtk
#define d2nmtk_ d2nmtk
#define d2optk_ d2optk
#define d2patk_ d2patk
#define d2potk_ d2potk
#define d2putk_ d2putk
#define d2rctk_ d2rctk
#define d2retk_ d2retk
#define d2rstk_ d2rstk
#define d2sdtk_ d2sdtk
#define d2sgtk_ d2sgtk
#define d2sptk_ d2sptk
#define d2sttk_ d2sttk
#define d2swtk_ d2swtk
#define d2tctk_ d2tctk
#define d2titk_ d2titk
#define d2tmtk_ d2tmtk
#define d2tntk_ d2tntk
#define d2totk_ d2totk
#define d2trtk_ d2trtk
#define d2tstk_ d2tstk
#define d2tttk_ d2tttk
#define d2wntk_ d2wntk
#define d3artk_ d3artk
#define d3cntk_ d3cntk
#define d3dltk_ d3dltk
#define d3drtk_ d3drtk
#define d3dttk_ d3dttk
#define d3fitk_ d3fitk
#define d3imtk_ d3imtk
#define d3lbtk_ d3lbtk
#define hp_gl_d3lbtk_ hp_gl_d3lbtk
#define d3lntk_ d3lntk
#define d3lotk_ d3lotk
#define d3mvtk_ d3mvtk
#define d3rntk_ d3rntk
#define d3sttk_ d3sttk
#define d3uptk_ d3uptk
#define d3vdtk_ d3vdtk
#define d3vrtk_ d3vrtk
#define d3vwtk_ d3vwtk
#define d3wetk_ d3wetk
#define d3wstk_ d3wstk
#define d2cvtk_ d2cvtk
#define d2fctk_ d2fctk
#define d2ictk_ d2ictk
#define d2zotk_ d2zotk
#define d2svtk_ d2svtk
#define d2vstk_ d2vstk
#define d2xrtk_ d2xrtk
#define d3dbtk_ d3dbtk
#define d3tritk_ d3tritk
#define d3tfantk_ d3tfantk
#endif

#if defined(WATCOMC_SYS) \
    || defined(PCWINNT_SYS)
#define d2aatk_ D2AATK
#define hp_gl_d2altk_ HP_GL_D2ALTK
#define d2artk_ D2ARTK
#define d2betk_ D2BETK
#define d2fotk_ D2FOTK
#define d2mstk_ D2MSTK
#define d2bmtk_ D2BMTK
#define d2cetk_ D2CETK
#define d2citk_ D2CITK
#define d2cmtk_ D2CMTK
#define d2cotk_ D2COTK
#define d2cptk_ D2CPTK
#define d2cstk_ D2CSTK
#define d2crtk_ D2CRTK
#define d2cttk_ D2CTTK
#define d2ditk_ D2DITK
#define d2drtk_ D2DRTK
#define d2dttk_ D2DTTK
#define d2entk_ D2ENTK
#define d2evtk_ D2EVTK
#define d2gctk_ D2GCTK
#define d2ggtk_ D2GGTK
#define d2gmtk_ D2GMTK
#define d2iftk_ D2IFTK
#define d2iqtk_ D2IQTK
#define d2iwtk_ D2IWTK
#define d2kctk_ D2KCTK
#define d2kitk_ D2KITK
#define d2kotk_ D2KOTK
#define d2lttk_ D2LTTK
#define d2lutk_ D2LUTK
#define d2lwtk_ D2LWTK
#define d2mvtk_ D2MVTK
#define d2nmtk_ D2NMTK
#define d2optk_ D2OPTK
#define d2patk_ D2PATK
#define d2potk_ D2POTK
#define d2putk_ D2PUTK
#define d2rctk_ D2RCTK
#define d2retk_ D2RETK
#define d2rstk_ D2RSTK
#define d2sdtk_ D2SDTK
#define d2sgtk_ D2SGTK
#define d2sptk_ D2SPTK
#define d2sttk_ D2STTK
#define d2swtk_ D2SWTK
#define d2tctk_ D2TCTK
#define d2titk_ D2TITK
#define d2tmtk_ D2TMTK
#define d2tntk_ D2TNTK
#define d2totk_ D2TOTK
#define d2trtk_ D2TRTK
#define d2tstk_ D2TSTK
#define d2tttk_ D2TTTK
#define d2wntk_ D2WNTK
#define d3artk_ D3ARTK
#define d3cntk_ D3CNTK
#define d3dltk_ D3DLTK
#define d3drtk_ D3DRTK
#define d3dttk_ D3DTTK
#define d3fitk_ D3FITK
#define d3imtk_ D3IMTK
#define d3lbtk_ D3LBTK
#define hp_gl_d3lbtk_ HP_GL_D3LBTK
#define d3lntk_ D3LNTK
#define d3lotk_ D3LOTK
#define d3mvtk_ D3MVTK
#define d3rntk_ D3RNTK
#define d3sttk_ D3STTK
#define d3uptk_ D3UPTK
#define d3vdtk_ D3VDTK
#define d3vrtk_ D3VRTK
#define d3vwtk_ D3VWTK
#define d3wetk_ D3WETK
#define d3wstk_ D3WSTK
#define d2cvtk_ D2CVTK
#define d2fctk_ D2FCTK
#define d2ictk_ D2ICTK
#define d2zotk_ D2ZOTK
#define d2svtk_ D2SVTK
#define d2vstk_ D2VSTK
#define d2xrtk_ D2XRTK
#define d3dbtk_ D3DBTK
#define d3tritk_ D3TRITK
#define d3tfantk_ D3TFANTK
#endif

#if defined(WATCOMC_SYS)
#pragma aux D2AATK "^";
#pragma aux HP_GL_D2ALTK "^";
#pragma aux D2ARTK "^";
#pragma aux D2BETK "^";
#pragma aux D2FOTK "^";
#pragma aux D2MSTK "^";
#pragma aux D2BMTK "^";
#pragma aux D2CETK "^";
#pragma aux D2CITK "^";
#pragma aux D2CMTK "^";
#pragma aux D2COTK "^";
#pragma aux D2CPTK "^";
#pragma aux D2CSTK "^";
#pragma aux D2CRTK "^";
#pragma aux D2CTTK "^";
#pragma aux D2DITK "^";
#pragma aux D2DRTK "^";
#pragma aux D2DTTK "^";
#pragma aux D2ENTK "^";
#pragma aux D2EVTK "^";
#pragma aux D2GCTK "^";
#pragma aux D2GGTK "^";
#pragma aux D2GMTK "^";
#pragma aux D2IFTK "^";
#pragma aux D2IQTK "^";
#pragma aux D2IWTK "^";
#pragma aux D2KCTK "^";
#pragma aux D2KITK "^";
#pragma aux D2KOTK "^";
#pragma aux D2LTTK "^";
#pragma aux D2LUTK "^";
#pragma aux D2LWTK "^";
#pragma aux D2MVTK "^";
#pragma aux D2NMTK "^";
#pragma aux D2OPTK "^";
#pragma aux D2PATK "^";
#pragma aux D2POTK "^";
#pragma aux D2PUTK "^";
#pragma aux D2RCTK "^";
#pragma aux D2RETK "^";
#pragma aux D2RSTK "^";
#pragma aux D2SDTK "^";
#pragma aux D2SGTK "^";
#pragma aux D2SPTK "^";
#pragma aux D2STTK "^";
#pragma aux D2SWTK "^";
#pragma aux D2TCTK "^";
#pragma aux D2TITK "^";
#pragma aux D2TMTK "^";
#pragma aux D2TNTK "^";
#pragma aux D2TOTK "^";
#pragma aux D2TRTK "^";
#pragma aux D2TSTK "^";
#pragma aux D2TTTK "^";
#pragma aux D2WNTK "^";
#pragma aux D3ARTK "^";
#pragma aux D3CNTK "^";
#pragma aux D3DLTK "^";
#pragma aux D3DRTK "^";
#pragma aux D3DTTK "^";
#pragma aux D3FITK "^";
#pragma aux D3IMTK "^";
#pragma aux D3LBTK "^";
#pragma aux HP_GL_D3LBTK "^";
#pragma aux D3LNTK "^";
#pragma aux D3LOTK "^";
#pragma aux D3MVTK "^";
#pragma aux D3RNTK "^";
#pragma aux D3STTK "^";
#pragma aux D3UPTK "^";
#pragma aux D3VDTK "^";
#pragma aux D3VRTK "^";
#pragma aux D3VWTK "^";
#pragma aux D3WETK "^";
#pragma aux D3WSTK "^";
#pragma aux D2CVTK "^";
#pragma aux D2FCTK "^";
#pragma aux D2ICTK "^";
#pragma aux D2ZOTK "^";
#pragma aux D2SVTK "^";
#pragma aux D2VSTK "^";
#pragma aux D2XRTK "^";
#pragma aux D3DBTK "^";
#pragma aux D3TRITK "^";
#pragma aux D3TFANTK "^";
#endif


#if !defined(PCWINNT_SYS)
   void d2aatk_();
   void hp_gl_d2altk_();
   void d2artk_();
   void d2betk_();
   void d2fotk_();
   void d2mstk_();
   void d2bmtk_();
   void d2cetk_();
   void d2citk_();
   void d2cmtk_();
   void d2cotk_();
   void d2cptk_();
   void d2cstk_();
   void d2crtk_();
   void d2cttk_();
   void d2ditk_();
   void d2drtk_();
   void d2dttk_();
   void d2entk_();
   void d2evtk_();
   void d2gctk_();
   void d2ggtk_();
   void d2gmtk_();
   void d2iftk_();
   void d2iqtk_();
   void d2iwtk_();
   void d2kctk_();
   void d2kitk_();
   void d2kotk_();
   void d2lttk_();
   void d2lutk_();
   void d2lwtk_();
   void d2mvtk_();
   void d2nmtk_();
   void d2optk_();
   void d2patk_();
   void d2potk_();
   void d2putk_();
   void d2rctk_();
   void d2retk_();
   void d2rstk_();
   void d2sdtk_();
   void d2sgtk_();
   void d2sptk_();
   void d2sttk_();
   void d2swtk_();
   void d2tctk_();
   void d2titk_();
   void d2tmtk_();
   void d2tntk_();
   void d2totk_();
   void d2trtk_();
   void d2tstk_();
   void d2tttk_();
   void d2wntk_();
   void d3artk_();
   void d3cntk_();
   void d3dltk_();
   void d3drtk_();
   void d3dttk_();
   void d3fitk_();
   void d3imtk_();
   void d3lbtk_();
   void hp_gl_d3lbtk_();
   void d3lntk_();
   void d3lotk_();
   void d3mvtk_();
   void d3rntk_();
   void d3sttk_();
   void d3uptk_();
   void d3vdtk_();
   void d3vrtk_();
   void d3vwtk_();
   void d3wetk_();
   void d3wstk_();
   void d2cvtk_();
   void d2fctk_();
   void d2ictk_();
   void d2zotk_();
   void d2svtk_();
   void d2vstk_();
   void d2xrtk_();
   void d3dbtk_();
   void d3tritk_();
   void d3tfantk_();
#else
   void CALLTYP d2aatk_( int * );
   void CALLTYP hp_gl_d2altk_( double *, double *, int *, int * );
   void CALLTYP d2artk_( double (*)[2], int *, int * );
   void CALLTYP d2betk_( void );
   void CALLTYP d2fotk_( int *, int[8][65] );
   void CALLTYP d2mstk_( int * );
   void CALLTYP d2bmtk_( void );
   void CALLTYP d2cetk_( void );
   void CALLTYP d2citk_( double *, double *, int * );
   void CALLTYP d2cmtk_( int *, int *, int *, int * );
   void CALLTYP d2cotk_( void );
   void CALLTYP d2cptk_( void );
   void CALLTYP d2cstk_( double *, double *, int * );
   void CALLTYP d2crtk_( int *, double *, double *, double *, double *, int * );
   void CALLTYP d2cttk_( void );
   void CALLTYP d2ditk_( int * );
   void CALLTYP d2drtk_( double *, double * );
   void CALLTYP d2dttk_( double *, double * );
   void CALLTYP d2entk_( void );
   void CALLTYP d2evtk_( int *, double *, double *, int * );
   void CALLTYP d2gctk_( int *, int *, int *, int *, int * );
   void CALLTYP d2ggtk_( int * );
   void CALLTYP d2gmtk_( void );
   void CALLTYP d2iftk_( int *, int * );
   void CALLTYP d2iqtk_( int *, int * );
   void CALLTYP d2iwtk_( int *, int *, int *, int * );
   void CALLTYP d2kctk_( void );
   void CALLTYP d2kitk_( int * );
   void CALLTYP d2kotk_( void );
   void CALLTYP d2lttk_( int * );
   void CALLTYP d2lutk_( void );
   void CALLTYP d2lwtk_( int * );
   void CALLTYP d2mvtk_( double *, double * );
   void CALLTYP d2nmtk_( int * );
   void CALLTYP d2optk_( void );
   void CALLTYP d2patk_( void );
   void CALLTYP d2potk_( void );
   void CALLTYP d2putk_( double *, double *, double *, double * );
   void CALLTYP d2rctk_( double *, double *, double *, double *, int * );
   void CALLTYP d2retk_( void );
   void CALLTYP d2rstk_( void );
   void CALLTYP d2sdtk_( void );
   void CALLTYP d2sgtk_( int *, int * );
   void CALLTYP d2sptk_( void );
   void CALLTYP d2sttk_( void );
   void CALLTYP d2swtk_( int * );
   void CALLTYP d2tctk_( void );
   void CALLTYP d2titk_( int *, int * );
   void CALLTYP d2tmtk_( void );
   void CALLTYP d2tntk_( int *, int * );
   void CALLTYP d2totk_( void );
   void CALLTYP d2trtk_( double * );
   void CALLTYP d2tstk_( int * );
   void CALLTYP d2tttk_( int * );
   void CALLTYP d2wntk_( double *, double *, double *, double * );
   void CALLTYP d3artk_( double (*)[3], int *, double [], int *, double (*)[3],
                         int *, int * );
   void CALLTYP d3cntk_( double *, double * );
   void CALLTYP d3dltk_( int * );
   void CALLTYP d3drtk_( double [] );
   void CALLTYP d3dttk_( double [] );
   void CALLTYP d3fitk_( void );
   void CALLTYP d3imtk_( void );
   void CALLTYP d3lbtk_( double [] , char [], int, int *);
   void CALLTYP hp_gl_d3lbtk_( double *, int *, int * );
   void CALLTYP d3lntk_( double (*)[3], int * );
   void CALLTYP d3lotk_( int *, int *, int * );
   void CALLTYP d3mvtk_( double [] );
   void CALLTYP d3rntk_( int *, int * );
   void CALLTYP d3sttk_( int * );
   void CALLTYP d3uptk_( int *, double *, double *, double *, double *,
                         double *, int *, int *, double *, double *,
                         double *, double *, double *, double * );
   void CALLTYP d3vdtk_( int * );
   void CALLTYP d3vrtk_( int *, double [], double * );
   void CALLTYP d3vwtk_( int *, double *, double *, double *, double *,
                         double *, int *, int *, double *, double *,
                         int *, int *, double *, double *, double *,
                         double *, double *, int *);
   void CALLTYP d3wetk_( int * );
   void CALLTYP d3wstk_( int * );
   void CALLTYP d2cvtk_( double *, double *, int *, int * );
   void CALLTYP d2fctk_( double *, double *, int *, int * );
   void CALLTYP d2ictk_( int *, int *, double *, double * );
   void CALLTYP d2zotk_( int [], int [], int * );
   void CALLTYP d2svtk_( void );
   void CALLTYP d2vstk_( int * );
   void CALLTYP d2xrtk_( int *, int * );
   void CALLTYP d3dbtk_( int *, int * );
   void CALLTYP d3tritk_( int *, double (*)[3], double (*)[3], int*);
   void CALLTYP d3tfantk_( int *, double (*)[3], double (*)[3], int *);
#endif
