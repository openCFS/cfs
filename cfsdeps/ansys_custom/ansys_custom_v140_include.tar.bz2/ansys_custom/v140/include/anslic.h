/*
 * Copyright 2003-2009 ANSYS, Inc.
 * All Rights Reserved
 */
#ifndef __ANSLIC_H__
#define __ANSLIC_H__

#include <wchar.h>
#include "anslic_blddate.h"
#include "ansprod.h"

typedef enum{anslic_false = 0,anslic_true} anslic_bool;

#if defined(c_plusplus) || defined(__cplusplus)
#  define anslicext extern "C"

   extern "C" typedef void (*LostCallbackPtr)(char*, char*, int, int);
   extern "C" typedef void (*TimeoutCallbackPtr)(char*, char*);
   extern "C" typedef void (*ReconnectCallbackPtr)(char*, char*);
   extern "C" typedef void (*MsgCallbackPtr)(char*, char*);
   extern "C" typedef void (*ExitCallbackPtr)(void);
   extern "C" typedef void (*AcleCallbackPtr)(void);
#else
#	define anslicext extern

   typedef void (*LostCallbackPtr)(char*, char*,int, int);
   typedef void (*TimeoutCallbackPtr)(char*, char*);
   typedef void (*ReconnectCallbackPtr)(char*, char*);
   typedef void (*MsgCallbackPtr)(char*, char*);
   typedef void (*ExitCallbackPtr)(void);
   typedef void (*AcleCallbackPtr)(void);
#endif

#if !defined(ANSLIC_NO_CPLUSPLUS) && (defined(c_plusplus) || defined(__cplusplus))

#  include <string>
#  include <map>
#  include <list>
#  if !defined(HP_SYS) || defined(_HP_NAMESPACE_STD)
#     include <fstream>
#  else
#     include <iostream/fstream.h>
#  endif

#  if !defined(HP_SYS) || defined(_HP_NAMESPACE_STD)
      using namespace std;
#  endif


   typedef enum
   {
      anslic_msg_info = 0,
      anslic_msg_warning,
      anslic_msg_error,
      anslic_msg_timeout,
      anslic_msg_reconnect,
      anslic_msg_lost,
      anslic_msg_typecnt
   } ANSLIC_MSG_TYPE;

   typedef enum
   {
      anslic_to_exit = 0,
      anslic_to_readonly,
      anslic_to_halt_iterations,
      anslic_to_custom
   } ANSLIC_TO_ACTION;

   class anslic_feature;
   class request;

   class anslic_client
   {
      public:
         /*
         // We only want one 'client' per application
         */
         static anslic_client* new_instance(const char* szApp);
         static anslic_client* new_instance(const int iAppId);
         static anslic_client* get_instance() {return m_pAnsLic;}
         static map<string, anslic_client*> get_mapAppClients() {return m_mapAppClients;}
         static anslic_client* get_instance(const char* szApp);
         static anslic_client* get_instance(const int iAppId);

         static void exit(void);
         virtual ~anslic_client(void);

         /*
         // initialization members (these should be called before any checkout, etc. method):
         */
         anslic_bool set_version(const char* szUseVer);           /* Allows override of the default version number used, must be >= internal value */
         anslic_bool set_revn(const char* szUseRevn);             /* Allows override of the default revision number used, must be >= internal value */
         anslic_bool set_ali_version(const char* szUseVer);       /* Allows override of the default ALI version number used, must be >= internal value */
         void register_exit_callback(ExitCallbackPtr pCallback);  /* Registers a function to be called when a license server connection is lost for longer than the grace period */
         void remove_exit_callback(ExitCallbackPtr pCallback);    /* Removes the passed registered exit callback */
         void register_msg_callback(ANSLIC_MSG_TYPE amtMsgType, MsgCallbackPtr pCallback);   /* Registers the passed function pointer for the message type */
         void register_timeout_callback(TimeoutCallbackPtr pCallback);
         void register_lost_callback(LostCallbackPtr pCallback);
         void register_reconnect_callback(ReconnectCallbackPtr pCallback);
         void set_logger(ofstream * logger);
         void set_ali_timeout_action_type(ANSLIC_TO_ACTION atoAct);  /* Note that this is only to identify the action taken in messages, the action should be
                                                                        handled by setting up registering the timeout callback via register_timeout_callback
                                                                        if the default (exit) action is not desired. */
         void set_ali_timeout_action_custom(string sActType);
         string get_ali_timeout_action_type_str();
         string get_log_file() {return m_log_file;};
         void set_log_file(string file) {m_log_file = file;};

         /*
         // ACLE callback members:
         */
         void register_aclelock_callback(string sId, AcleCallbackPtr pCallback);    /* Registers a function to be called when ACLE is in use, informing app when to lock itself down */
         void remove_aclelock_callback(string sId, AcleCallbackPtr pCallback);      /* Removes the passed registered ACLE lock callback */
         void register_aclerelease_callback(string sId, AcleCallbackPtr pCallback); /* Registers a function to be called when ACLE is freed, informing app when to unlock itself */
         void remove_aclerelease_callback(string sId, AcleCallbackPtr pCallback);   /* Removes the passed registered ACLE release callback */

         anslic_bool acle_checkout(string sId);
         anslic_bool acle_checkin(string sId);
         anslic_bool acle_checkexists(string sId);

         anslic_bool acle_checkout_interact(string sId, const int iWithAppId = -1);

         anslic_bool register_aclelock(string sId);
         anslic_bool remove_aclelock(string sId);
         anslic_bool register_aclerelease(string sId);
         anslic_bool remove_aclerelease(string sId);


         map<string,map<AcleCallbackPtr,AcleCallbackPtr> > get_mapAcleLockCallbacks();
         map<string,map<AcleCallbackPtr,AcleCallbackPtr> > get_mapAcleReleaseCallbacks();

         /*
         // License reservation members (returns the reservation id to pass to design studies):
         */
         anslic_bool reserve(const char* szXml, char* szId);
         anslic_bool return_reserve();
         anslic_bool return_reserve(char *szReserveId);

         /*
         // checkout members (Each returns the id associated with the checkout in szId):
         */
         anslic_bool checkout(const char* szWhat, const int iTaskCnt, char* szId);   /* Checkout requested feature (ane3fl) or capability (ANS_SIM)*/
         anslic_bool checkout(const int iProductNo, const int iTaskCnt, char* szId); /* Checkout requested product number (ANSYS_ANE3FL_CODE) from ansprod.h */
         anslic_bool checkout(const char* szWhat, const int iTaskCnt, const char * szPreferredServer, const char * szSharedInfo, char* szId);   /* Same as above but this time passes an extra shared information [RSM requirement]*/
         anslic_bool checkout(const int iProductNo, const int iTaskCnt, const char * szPreferredServer, const char * szSharedInfo, char* szId); /* Same as above but this time passes an extra shared information [RSM requirement] */
         anslic_bool checkout(const char* szWhat, const int iTaskCnt, const char * szPreferredServer, const char * szSharedInfo, const char* szPreferredFeature, char* szId); /* Same as above but this time passes an extra shared information [RSM requirement] and preferred feature */
         anslic_bool checkout(const char* szWhat, const int iTaskCnt, const char* szPreferredFeature, char* szId); /*  */
         anslic_bool checkout(const int iCapabilityId, const int iTaskCnt, const char * szPreferredServer, const char * szSharedInfo, const char* szPreferredFeature, char* szId); /* Same as above but this time passes an extra shared information [RSM requirement] and preferred feature */
         anslic_bool checkout(const int iCapabilityId, const int iTaskCnt, const char* szPreferredFeature, char* szId); /*  */
         anslic_bool checkout(const int iCapabilityId, const int iTaskCnt, const int iPreferredFeatureId, char* szId); /*  */
         anslic_bool checkout(const int iCapabilityId, const int iTaskCnt, list<unsigned int> listReqCapIds, char* szId, anslic_bool bAndCaps = anslic_true); /* Checkout license with 'all' (bAndCaps  == anslic_true) or 'one of' (bAndCaps = anslic_false) passed capablities */
         anslic_bool checkout(const int iCapabilityId, const int iTaskCnt, const int iHpcCnt, list<unsigned int> listReqCapIds, char* szId, anslic_bool bAndCaps = anslic_true); /* Checkout license with 'all' (bAndCaps  == anslic_true) or 'one of' (bAndCaps = anslic_false) passed capablities */
         anslic_bool checkout(const int iCapabilityId, const int iTaskCnt, const int iHpcCnt, const char * szPreferredServer, const char * szSharedInfo, list<unsigned int> listReqCapIds, char* szId, anslic_bool bAndCaps = anslic_true); /* Checkout license with 'all' (bAndCaps  == anslic_true) or 'one of' (bAndCaps = anslic_false) passed capablities with the HPC count and server/shared info */

         /*
         // existance check members:
         */
         anslic_bool check(const char* szWhat, const int iTaskCnt);           /* Check if the requested feature (ane3fl) or capability (ANS_SIM) is a valid one (doing a checkout and an immediate checkin)*/
         anslic_bool checkexists(const char* szWhat, const int iTaskCnt);     /* Check if the requested feature (ane3fl) or capability (ANS_SIM) is a valid one */
         anslic_bool checkexists(const int iProductNo, const int iTaskCnt);   /* Check if the requested product number (ANSYS_ANE3FL_CODE) from ansprod.h is a valid one */
         char* checklistexists(const char* szListProductNo);                  /* Check for a list of capabilities in the format "EKM_DESKTOP,ANS_SOLVER,ANS_DM", the return string is "TRUE,FALSE,FALSE" for existence or not of each capability*/
         void checkexists_clear_cache(void);

         /*
         // checkin members:
         */
         anslic_bool checkin(const char* szWhat, const int iTaskCnt); /* Checkin requested feature (ane3fl) or capability (ANS_SIM) */
         anslic_bool checkin(const int iProductNo, const int iTaskCnt);
         anslic_bool checkin(const char* szId);                       /* Checkin specific checked out id */
         anslic_bool checkin(const int iProductNo);                   /* Checkin license checked out via checkout(iProductNo,...) */
         anslic_bool checkin(void);                                   /* Checkin all outstanding features */

	/*
	// Misc
	*/
	void crash(void);/*simulates a server crash*/
	void hang(void);/*simulates a server hang*/
	void slow(void);/*simulates a slow server*/
	char * prddef(void);
	char * capdef(void);
         /*
         // Status/usage members:
         */
         char* status(void);                          /* Retrieve the status info for all features available */
         char* status(const char* szFeat);            /* Retrieve the status info for the passed feature */

         char* usage(const char* szFeat);             /* Retrieve the usage info for the passed feature */

         char* fullexists(const char* szFeat);        /* Retrieve the availability info for the passed feature/capability */
         char* fullexists(const int iId);             /* Retrieve the availability info for the passed feature/capability */

         char* site_prefs();                          /* gets the site preferences by reading the products order file */
         char* site_prefs(const int iProductNo);      /* gets the site preferences for this capability by reading the products order file */
         char* site_prefs(const char* szWhat);        /* gets the site preferences for this capability by reading the products order file */

         char* prefs_with_count(anslic_bool bForRes = anslic_true);  /* gets the licensed preferences (user and/or site) with counts broken down by preference category (solver, preppost, etc.) */

         char* get_active_reserves_xml();                    /* Retrieves the currently active reserves */

         char* site_licensed();                       /* gets only licensed products */
         char* site_licensed(const int iProductNo);   /* gets only licensed products for this capability */
         char* site_licensed(const char* szWhat);     /* gets only licensed products for this capability */

         char* capability_preferences(const char* szCapNm, anslic_bool bLicensed = anslic_true);   /* Retrieve the active (user or site) preferences for the passed capability name in the order they will be tried */
         char* capability_preferences(const int iCapId, anslic_bool bLicensed = anslic_true);      /* Retrieve the active (user or site) preferences for the passed capability id in the order they will be tried */
         
         char* default_usage(const char* szFeat);

         char* product_data(const char* szFeat);      /* Retrieve the product definition info for the passed feature */

         /*
         // Information retrieval members:
         */
         const char* get_app(void);
         const char* get_version(void);
         const char* get_revn(void);
         void set_preferred_server(const char *);
         void set_server(const char *);
         char* get_preferred_server();
         char* get_server();
         char* get_ansysli_version();
         anslic_bool get_product_info(int* piProductNo, char** pszFeatureName, char** pszProductName);
         anslic_bool get_product_names(const int iProductNo, char** pszFeatureName, char** pszProductName);
         int get_product_id(const char* szFeatureName);
         bool is_sharable(const char* szForId); /*Tells if the checked out feature has a SHARE attribute*/

         char* get_checkout_information(const char* szForId, const char* szWhatInfo);  /* retrieves checkout information on a particular checkout (identified by szForId) */
         char* get_checkout_information(const int iProductNo, const char* szWhatInfo); /* retrieves checkout information on a particular checkout (identified by iProductNo) */
         char* get_resolve_information(const char* szForId, const char* szWhatInfo);  /* retrieves resolve information on a particular checkout (identified by szForId) */
         char* get_resolve_information(const int iProductNo, const char* szWhatInfo); /* retrieves resolve information on a particular checkout (identified by iProductNo) */
         char* get_lasterror(void);

         anslic_bool get_state(void);
         anslic_bool get_state(const char* szForId);

         char* get_representative_xml(int iFormatted = 0);

         int get_last_flexerror(void);

         anslic_bool get_daysleft(const char* szWhat, int* piDaysLeft);
         anslic_bool get_daysleft(const int iProductNo, int* piDaysLeft);

         anslic_bool is_academic(const char* szForId);
         anslic_bool has_academic_logo(const char* szForId);
         anslic_bool has_academic_logo(const int iProductNo);
         anslic_bool is_acfd_preppost(const char* szForId);
         int get_max_h_elem(const char* szForId);
         int get_max_nodes(const char* szForId);

         char* get_productname(const char* szForId);
         char* get_productname(const int iProductNo);
         char* get_featurename(const char* szForId);
         char* get_featurename(const int iProductNo);

         char* feat_to_prod_name(char* szFeatNm);
         char* prod_to_feat_name(char* szProdNm);

         char* gets_customerno(void);

         int get_customerno(void);
         int get_customerno(const char* szForId);
         int get_customerno(const int iProductNo);
         int get_featureid(const char* szForId);
         int get_featureid(const int iProductNo);
         int get_capability_level(const char* szForId);
         int get_capability_level(const int iProductNo);

         /*
         // The following 'public' methods should only be called when absolutely necessary.
         */
         void display_flexerror(request* pRequest);
         void display_message(ANSLIC_MSG_TYPE amtMsgType, string sMsg, string sCaption = "");
         void reconnect_callback(ANSLIC_MSG_TYPE amtMsgType, string sMsg, string sCaption = "");
         void timeout_callback(ANSLIC_MSG_TYPE amtMsgType, string sMsg, string sCaption = "");
         void lost_callback(ANSLIC_MSG_TYPE amtMsgType, string sMsg, string sCaption,int timelost, int timeout);
#ifdef _WIN32
         void set_icon(ANSLIC_MSG_TYPE amtMsgType);
#endif
         /*
         // Connection API members (connection is automatically made when checkout is called):
         */
         anslic_bool connect();                             /* Force a connection to the ANSYS Licensing Interconnect server */
         anslic_bool disconnect();                          /* Force a dicconnection to the ANSYS Licensing Interconnect server */
         anslic_bool check_connection(int * iMinutesLost);  /*returns the number of minutes since the last time the client has talked to the server */
         anslic_bool close_instance(void);

         /*
         // Internal use members
         */
         static void anslic_exit();                         /* static member function called via atexit() */

         /*
         // Borrow members (for future use only):
         */
         char* borrow(char* features);
         anslic_bool return_borrow(char* features);

         string name_acle(string sId);
      protected:
         static anslic_client* m_pAnsLic;
         static map<string, anslic_client*> m_mapAppClients;
         static map<int, string> m_mapAppIdToName;
         static map<int, anslic_feature*> m_mapFeature;
         static map<string, anslic_feature*> m_mapFeatureName;
         static map<string, anslic_feature*> m_mapProductName;

         string m_sApp;
         string m_sVer;
         string m_sRevn;

         int m_iLastFlexError;

         ANSLIC_TO_ACTION m_atoActionType;
         string m_sActionType;

         map<ANSLIC_MSG_TYPE, MsgCallbackPtr> m_mapMsgCallbacks;
         map<int,string> m_mapProductNo2OutId;
         map<string, anslic_bool> m_mapExistenceCache;
         static map<ExitCallbackPtr,ExitCallbackPtr> m_mapExitCallbacks;

         map<string,map<AcleCallbackPtr,AcleCallbackPtr> > m_mapAcleLockCallbacks;
         map<string,map<AcleCallbackPtr,AcleCallbackPtr> > m_mapAcleReleaseCallbacks;

         LostCallbackPtr m_LostCallback;
         TimeoutCallbackPtr m_TimeoutCallback;
         ReconnectCallbackPtr m_ReconnectCallback;

         string m_sLastError;
         ofstream * m_ofsLicLog;
         string m_log_file;
         static ofstream* get_log_stream(string sFileName);
         anslic_client(const char* szApp);

         request* get_acle_request(string sId);
         anslic_bool acle_client(string sId);

         static string get_app_name(int iAppId);

         int get_featureid(request* pFromRequest);
         int get_capability_level(request* pForReq);

         char* get_checkout_information(request* pFromRequest, const char* szWhatInfo);
         char* get_productname(request* pFromRequest);
         char* get_featurename(request* pFromRequest);
         char* copy_string2sz(const string sVal);
         char* copy_xmlstring2sz(const string sVal, int iFormat = 1);

         anslic_bool checkout(request* pCheckoutRequest);

         request* get_request(const char* szForId);

         anslic_feature* add_feature(request* pReq);

         string get_to_base_ccluster_msg();
   };
#endif

/*
////////////////////////////////////////////////////////////////////////////////
//
// C/C++ ANSYS LI API function declarations:
//
////////////////////////////////////////////////////////////////////////////////
*/
anslicext anslic_bool anslic_useli(void);

anslicext char* anslic_version(void);

/*
// C initialization functions:
*/
anslicext anslic_bool anslic_init_id(const int iAppId);
anslicext anslic_bool anslic_init(const char* szApp);
anslicext anslic_bool anslic_init_set_version(const char* szApp, const char* szUseVer);
anslicext anslic_bool anslic_init_id_set_version(const int iAppId, const char* szUseVer);
anslicext anslic_bool anslic_setlogger(const char* szLogFile, anslic_bool bCreate);

/*
// Initialized App initialization calls (note these depend on either anslic_init or anslic_set_version being called first):
*/
anslicext void anslic_register_exit_callback(ExitCallbackPtr pCallback);
anslicext void anslic_remove_exit_callback(ExitCallbackPtr pCallback);
anslicext void anslic_register_callback_info(MsgCallbackPtr pInfo);
anslicext void anslic_register_callback_warning(MsgCallbackPtr pWarn);
anslicext void anslic_register_callback_error(MsgCallbackPtr pError);
anslicext void anslic_register_callback_timeout(TimeoutCallbackPtr pTimeout);
anslicext void anslic_register_callback_lost(LostCallbackPtr pLostout);
anslicext void anslic_register_callback_reconnect(ReconnectCallbackPtr pReconnect);

/*
// Acles callbacks
*/
anslicext void anslic_register_aclerelease_callback(char* szId, AcleCallbackPtr pCallback);
anslicext void anslic_remove_aclerelease_callback(char* szId, AcleCallbackPtr pCallback);
anslicext void anslic_register_aclelock_callback(char* szId, AcleCallbackPtr pCallback);
anslicext void anslic_remove_aclelock_callback(char* szId, AcleCallbackPtr pCallback);

/*
// Initialized App Checkout, Checkin, etc. calls (note these depend on either anslic_init or anslic_set_version being called first):
*/
anslicext anslic_bool anslic_i_checkout(const char* szWhat, const int iTaskCnt, char* szId);
anslicext anslic_bool anslic_i_checkin(const char* szWhat, const int iTaskCnt);

anslicext anslic_bool anslic_i_checkout_preferred(const int iCategoryId, const int iTaskCnt, const char* szFeature, char* szId);
anslicext anslic_bool anslic_i_checkout_preferredid(const int iCategoryId, const int iTaskCnt, const int iFeatureId, char* szId);

anslicext anslic_bool anslic_i_shared_checkout(const char* szWhat, const int iTaskCnt, const char * szPreferredServer, const char * szSharedInfo, char* szId);
anslicext anslic_bool anslic_i_shared_checkoutid(const int iWhatId, const int iTaskCnt, const char * szPreferredServer, const char * szSharedInfo, char* szId);
anslicext anslic_bool anslic_i_shared_checkoutid_feat(const int iWhatId, const int iTaskCnt, const char * szPreferredServer, const char * szSharedInfo, const char* szPrefFeat, char* szId);

anslicext anslic_bool anslic_i_checkoutid(const int iWhatId, const int iTaskCnt, char* szId);
anslicext anslic_bool anslic_i_checkinid(const int iWhatId, const int iTaskCnt);

anslicext anslic_bool anslic_i_checkout_with_capabilities(const int iWhatId, const int iTaskCnt, const int iaReqCapIds[], const int iReqCapIdCnt, anslic_bool bAndCaps, char* szId);
anslicext anslic_bool anslic_i_checkout_with_capabilities_str(const int iWhatId, const int iTaskCnt, const char* szReqCapIds, const char* szReqCapIdSep, anslic_bool bAndCaps, char* szId);
anslicext anslic_bool anslic_i_shared_checkout_with_hpc_and_capabilities(const int iWhatId, const int iTaskCnt, const int iHpcCnt,
   const char * szPreferredServer, const char * szSharedInfo, const int iaReqCapIds[], const int iReqCapIdCnt, anslic_bool bAndCaps, char* szId);

anslicext anslic_bool anslic_i_check(const char* szWhat, const int iTaskCnt);
anslicext anslic_bool anslic_i_checkexists(const char* szWhat, const int iTaskCnt);
anslicext anslic_bool anslic_i_checkidexists(const int iWhatId, const int iTaskCnt);
anslicext void anslic_i_checkexists_clear_cache(void);

anslicext anslic_bool anslic_i_checkin_id(const char* szId);
anslicext anslic_bool anslic_i_checkin_all(void);

anslicext char* anslic_i_get_checkout_information(const char* szForId, const char* szWhatInfo);
anslicext char* anslic_i_get_checkout_information_id(const int iProductNo, const char* szWhatInfo);
anslicext char* anslic_i_get_lasterror(void);
anslicext int anslic_i_get_last_flexerror(void);
anslicext char* anslic_get_lasterror(void);
anslicext int anslic_get_last_flexerrorno(void);

anslicext int anslic_get_product_id(const char* szFeatureName);
anslicext anslic_bool anslic_is_sharable(const char* szOutId);

/*ACLE calls*/
anslicext void anslic_i_register_aclelock_callback(char* szId, AcleCallbackPtr pCallback);
anslicext void anslic_i_remove_aclelock_callback(char* szId, AcleCallbackPtr pCallback);
anslicext void anslic_i_register_aclerelease_callback(char* szId, AcleCallbackPtr pCallback);
anslicext void anslic_i_remove_aclerelease_callback(char* szId, AcleCallbackPtr pCallback);

anslicext anslic_bool anslic_i_acle_checkin(char* szId);
anslicext anslic_bool anslic_i_acle_checkout(char* szId);
anslicext anslic_bool anslic_i_acle_checkout_interact(char* szId);
anslicext anslic_bool anslic_i_acle_checkout_interact_with_app(char* szId, const int iWithAppId);
anslicext anslic_bool anslic_i_acle_checkexists(char* szId);

anslicext anslic_bool anslic_acle_checkin(const char* szApp, char* szId);
anslicext anslic_bool anslic_acle_checkout(const char* szApp, char* szId);
anslicext anslic_bool anslic_acle_checkexists(const char* szApp, char* szId);
/*
// App specific initialization calls:
*/
anslicext void anslic_app_register_exit_callback(const char* szApp, ExitCallbackPtr pCallback);
anslicext void anslic_app_remove_exit_callback(const char* szApp, ExitCallbackPtr pCallback);
anslicext void anslic_app_register_callback_info(const char* szApp, MsgCallbackPtr pInfo);
anslicext void anslic_app_register_callback_warning(const char* szApp, MsgCallbackPtr pWarn);
anslicext void anslic_app_register_callback_error(const char* szApp, MsgCallbackPtr pError);
anslicext void anslic_app_register_callback_timeout(const char* szApp, TimeoutCallbackPtr pTimeout);
anslicext void anslic_app_register_callback_lost(const char* szApp, LostCallbackPtr pLostout);
anslicext void anslic_app_register_callback_reconnect(const char* szApp, ReconnectCallbackPtr pReconnect);

anslicext anslic_bool anslic_checkout(const char* szApp, const char* szWhat, const int iTaskCnt, char* szId);
anslicext anslic_bool anslic_checkoutid(const char* szApp, const int iWhatId, const int iTaskCnt, char* szId);
anslicext anslic_bool anslic_checkout_preferred(const char* szApp, const int iCategoryId, const int iTaskCnt, const char* szFeature, char* szId);
anslicext anslic_bool anslic_checkout_preferredid(const char* szApp, const int iCategoryId, const int iTaskCnt, const int iFeatureId, char* szId);

anslicext anslic_bool anslic_shared_checkout(const char* szApp, const char* szWhat, const int iTaskCnt, const char * szPreferredServer, const char * szSharedInfo, char* szId);
anslicext anslic_bool anslic_shared_checkoutid(const char* szApp, const int iWhatId, const int iTaskCnt, const char * szPreferredServer, const char * szSharedInfo, char* szId);

anslicext anslic_bool anslic_checkin(const char* szApp, const char* szWhat, const int iTaskCnt);
anslicext anslic_bool anslic_checkinid(const char* szApp, const int iWhatId, const int iTaskCnt);

anslicext anslic_bool anslic_check(const char* szApp, const char* szWhat, const int iTaskCnt);
anslicext anslic_bool anslic_checkexists(const char* szApp, const char* szWhat, const int iTaskCnt);
anslicext anslic_bool anslic_checkidexists(const char* szApp, const int iWhatId, const int iTaskCnt);
anslicext char* anslic_checklistexists(const int iAppId, const char* szListProductNo);
anslicext void anslic_checkexists_clear_cache(const char* szApp);

anslicext anslic_bool anslic_checkin_id(const char* szApp, const char* szId);
anslicext anslic_bool anslic_checkin_all(const char* szApp);

anslicext char* anslic_get_checkout_information(const char* szForId, const char* szWhatInfo);
anslicext char* anslic_get_checkout_information_id(const int iProductNo, const char* szWhatInfo);
anslicext char* anslic_get_lasterror_for_app(const char* szApp);

anslicext anslic_bool anslic_connect_id(const int iAppId);
anslicext anslic_bool anslic_connect(const char* szApp);
anslicext anslic_bool anslic_check_connection(const char* szApp, int * iMinuteslost);
anslicext anslic_bool anslic_disconnect(const char* szApp);
anslicext char* anslic_status_feature(const char* szApp, const char* szFeat);
anslicext char* anslic_usage_feature(const char* szApp, const char* szFeat);
anslicext char* anslic_default_usage_feature(const char* szApp, const char* szFeat);
anslicext char* anslic_product_data(const char* szFeat);
anslicext char* anslic_status(const char* szApp);

anslicext char* anslic_fullexists(const char* szApp, const char* szFeat);
anslicext char* anslic_fullexistsid(const char* szApp, const int iId);
anslicext char* anslic_site_prefs(const char* szApp);
anslicext char* anslic_site_licensed(const char* szApp);
anslicext char* anslic_site_licensed_capid(const char* szApp, const int iProductNo);
anslicext char* anslic_site_licensed_capstr(const char* szApp, const char* szWhat);
anslicext char* anslic_capability_preferences(const char* szApp, const char* szCapNm, anslic_bool bLicensed);
anslicext char* anslic_capability_preferencesid(const char* szApp, const int iCapId, anslic_bool bLicensed);
anslicext char* anslic_i_fullexists(const char* szFeat);
anslicext char* anslic_i_fullexistsid(const int iId);
anslicext char* anslic_i_site_prefs();
anslicext char* anslic_i_site_licensed();
anslicext char* anslic_i_site_licensed_capid(const int iProductNo);
anslicext char* anslic_i_site_licensed_capstr(const char* szWhat);
anslicext char* anslic_i_capability_preferences(const char* szCapNm, anslic_bool bLicensed);
anslicext char* anslic_i_capability_preferencesid(const int iCapId, anslic_bool bLicensed);

anslicext char* anslic_cap_prefs(const char* szApp,const int iProductNo);
anslicext char* anslic_cap_licensed(const char* szApp,const int iProductNo);
anslicext char* anslic_i_cap_prefs(const int iProductNo);
anslicext char* anslic_i_cap_licensed(const int iProductNo);

anslicext char* anslic_borrow(const char* szApp, char* features);
anslicext anslic_bool anslic_return_borrow(const char* szApp, char* features);
anslicext const char* anslic_get_app(void);
anslicext const char* anslic_get_version(void);

anslicext char* anslic_get_server();
anslicext void anslic_set_server(const char* szSvr);
anslicext char* anslic_get_preferred_server();
anslicext void anslic_set_preferred_server(const char* szSvr);
anslicext char* anslic_get_checkout_information(const char* szForId, const char* szWhatInfo);
anslicext anslic_bool anslic_get_daysleft(const char* szApp, const char* szWhat,int * iDaysLeft);
anslicext anslic_bool anslic_get_daysleftid(const char* szApp, const int iProductNo,int * iDaysLeft);

anslicext anslic_bool anslic_get_product_names(const int iProductNo, char** pszFeatureName, char** pszProductName);
anslicext anslic_bool anslic_get_id_and_featurename(int* piProductNo, char** pszFeatureName, char* szProductName);
anslicext anslic_bool anslic_get_id_and_productname(int* piProductNo, char* szFeatureName, char** pszProductName);
anslicext anslic_bool anslic_has_academic_logo(const char* szForId);
anslicext anslic_bool anslic_has_academic_logo_id(const int iProductNo);
anslicext anslic_bool anslic_is_academic(const char* szForId);
anslicext anslic_bool anslic_is_acfd_preppost(const char* szForId);
anslicext int anslic_get_max_h_elem(const char* szForId);
anslicext int anslic_get_max_nodes(const char* szForId);

anslicext int anslic_get_firstcustomerno();
anslicext int anslic_get_customerno(const char* szForId);
anslicext int anslic_get_customernobyid(const int iProductNo);
anslicext int anslic_get_featureid(const char* szForId);
anslicext int anslic_get_featureidbyid(const int iProductNo);
anslicext char* anslic_get_productname(const char* szForId);
anslicext char* anslic_get_productnamebyid(const int iProductNo);
anslicext char* anslic_get_featurename(const char* szForId);
anslicext char* anslic_get_featurenamebyid(const int iProductNo);
anslicext char* anslic_feat_to_prod_name(char* szFeatNm);
anslicext char* anslic_prod_to_feat_name(char* szProdNm);
anslicext char* anslic_gets_firstcustomerno();
anslicext int anslic_get_capability_level(const char* szForId);
anslicext int anslic_get_capability_level_byid(const int iProductNo);

anslicext int check_bguhl_state();
anslicext char* get_bguhl_data();
anslicext wchar_t* get_bguhl_wdata();

#endif  /* ndef __ANSLIC_H__ */
