#ifndef FEM_AEMESHDATA________________H
#define FEM_AEMESHDATA________________H
#include "FEM_MeshData.h"
class AREAMSHDAT_TYP;
typedef class AREAMSHDAT_TYP *AREAMSHDAT_PTYP;
typedef enum 
{  
    FREE_MESH_ONLY=0,
	MAP_MESH_ONLY,
	MAP_MESH_PREFERED
} MESH_TYPE;

typedef enum
{
    kTriSurfaceMesh = 3,
    kQuadTriSurfaceMesh = 4,
    kQuadSurfaceMesh = 5
} _eSurfaceMeshShape;

/* the above definition comes from INT FEM_areamesh() */
/* (IN) 0 = Use free Mesher Always.             */
/*      1 = Use Map Mesher Always.              */
/*      2 = Use Map Mesher if possible, and if  */
/*          not, use the free mesher.           */
class TRGINFO_TYP;
typedef TRGINFO_TYP *TRGINFO_PTYP;

class TRGINFO_TYP : public NEXTCELL_TYP 
{
private:
      AREAMSHDAT_PTYP m_p_sareainfo;

public:
      void InitTrgInfo( )
      {
         SetCell( NULL );
         m_p_sareainfo = NULL;
         SetNext( NULL );
      };

      TRGINFO_PTYP GetNext( ) { return (TRGINFO_PTYP)mps_next; };

      void SetVol( const VOL_PTYP obj_vol )
      {
         SetCell( obj_vol );
      };
      VOL_PTYP GetVol( ) const { return (VOL_PTYP)GetCell(); };

      void SetSrcArea( const AREAMSHDAT_PTYP p_sareainfo )
      {
         m_p_sareainfo = p_sareainfo;
      };
      AREAMSHDAT_PTYP GetSrcArea( ) const { return m_p_sareainfo; };
};

class AREAMSHDAT_TYP : public MSHDAT_TYP {

private:
    /* unsigned m_premeshed:1; */
    unsigned m_mapable:1;
    unsigned m_mapableharddivs:1;
    unsigned m_needsmidndoes:1;
    unsigned m_projectmids:1;
    unsigned m_dropmidndoes:1;
    unsigned m_volloopsrc:1;
    unsigned m_side:1;
    unsigned m_numkps;
    unsigned m_num_anodes_inc_mids:1;
    unsigned m_num_bnodes_inc_mids:1;
    unsigned m_flat:1;
    unsigned m_OnSweepableVol:1;
    unsigned m_bWasMapped:1;
    unsigned m_bPassQualityByLineSmoothing:1;
    unsigned m_bInflated:1; /* inflated ? */
    unsigned m_bImportedMesh:1; /* the mesh is imported from outside */
    INT m_source;
    _eSurfaceMeshShape m_shape;
    INT m_num_bnd_nodes;
    INT m_num_bnd_crn_nodes;
    INT m_num_area_nodes;
    INT m_num_area_edges;
    INT m_num_area_quads;
    INT m_num_area_tris;
    INT m_max_node_id;
    INT *m_a_kpstat;
    DOUBLE *m_kpangles;
    INT *m_a_kps;
    LINE_PTYP *m_aobj_lines;
    INT *m_a_linedirs;
    FEM_BOOLEAN *m_a_axiskps;
    NODE_OBJ *m_aobj_bnd_nodes;
    INT *m_a_iel;
    INT m_num_bnd_edges;
    INT m_numtrgs;
    TRGINFO_PTYP m_p_trginfo;
    NODE_OBJ *m_aobj_cornernodes;
    INT m_num_cornernodes;
    INT *m_a_cornernodestat;
    INT m_numaxiskps;
    INT m_forceMap; // force to do map mesh, mostly for src or trg faces 
    INT m_iNumRadialDivs; // contains # of divisions in radial dir
    /* DOUBLE m_esize; */

public:
    AREAMSHDAT_TYP() { };
    ~AREAMSHDAT_TYP() { Delete(); };
    void Init( );
    void delMem();
    void Delete(); 

    inline void SetMapable( const FEM_BOOLEAN mapable = TRUE )
    {
        if ( mapable ) m_mapable = 1;
        else m_mapable = 0;
    };

    FEM_BOOLEAN IsMapable( ) ;

    inline void SetMapableHardDivs( const FEM_BOOLEAN mapable = TRUE )
    {
        if ( mapable ) m_mapableharddivs = 1;
        else m_mapableharddivs = 0;
    };

    inline FEM_BOOLEAN IsMapableHardDivs( ) const
    {
        if ( m_mapableharddivs == 1 ) return TRUE;
        else return FALSE;
    };

    inline void SetIsSide( const FEM_BOOLEAN status = FALSE )
    {
        if ( status ) m_side = 1;
        else m_side = 0;
    };

    inline FEM_BOOLEAN IsSide( ) const
    {
        if ( m_side == 1 ) return TRUE;
        else return FALSE;
    };

    inline void SetIsSource( const FEM_BOOLEAN status = FALSE )
    {
        if ( status ) m_source++;
        else m_source = 0;
    };

    inline FEM_BOOLEAN IsSource( ) const
    {
        if ( m_source != 0 ) return TRUE;
        else return FALSE;
    };

    inline void RemoveOneSource( )
    {
        if ( m_source != 0 ) m_source--;
    };

    INT SetTarget( const AREAMSHDAT_PTYP p_sareainfo = NULL,
        const VOL_PTYP obj_trgvol = NULL );
    void RemoveAllTargets( );
    void RemoveTarget( const VOL_PTYP obj_trgvol );
    inline AREA_PTYP GetSource( )
    {
        if ( m_numtrgs == 0 ) {
            return NULL;
        }
        else {
            return m_p_trginfo->GetSrcArea()->GetArea();
        }
    }

    inline FEM_BOOLEAN IsTarget( ) const
    {
        if ( m_numtrgs > 0 ) return TRUE;
        else return FALSE;
    };

    inline FEM_BOOLEAN IsSrcOrTrg( ) const
    {
        if ( m_numtrgs > 0 ) return TRUE;
        else if ( m_source != 0 ) return TRUE;
        else return FALSE;
    };

    INT Fix2Trgs( );
    INT CanBeTarget( AREAMSHDAT_PTYP &p_reference_area,
        FEM_BOOLEAN &canbetrg );

    inline void SetNeedsMidnodes( const FEM_BOOLEAN status = TRUE )
    {
        if ( status ) m_needsmidndoes = 1;
        else m_needsmidndoes = 0;
    };

    inline FEM_BOOLEAN NeedsMidnodes( ) const
    {
        if ( m_needsmidndoes == 1 ) return TRUE;
        else return FALSE;
    };

    inline void SetDropMidnodes( const FEM_BOOLEAN status = TRUE )
    {
        if ( status ) m_dropmidndoes = 1;
        else m_dropmidndoes = 0;
    };

    inline FEM_BOOLEAN CanDropMidnodes( ) const
    {
        if ( m_dropmidndoes == 1 ) return TRUE;
        else return FALSE;
    };

    inline void SetVolLoopSrc( const FEM_BOOLEAN status = TRUE )
    {
        if ( status ) m_volloopsrc = 1;
        else m_volloopsrc = 0;
    };

    inline FEM_BOOLEAN VolLoopSrc( ) const
    {
        if ( m_volloopsrc == 1 ) return TRUE;
        else return FALSE;
    };

    inline void SetProjectMids( const FEM_BOOLEAN status = TRUE )
    {
        if ( status ) m_projectmids = 1;
        else m_projectmids = 0;
    };

    inline FEM_BOOLEAN ProjectMids( ) const
    {
        if ( m_projectmids == 1 ) return TRUE;
        else return FALSE;
    };

    LINE_PTYP const *Lines( INT & num_lines );
    inline void SetShape( const _eSurfaceMeshShape shape = kTriSurfaceMesh ) { m_shape = shape; };
    inline _eSurfaceMeshShape Shape( ) const { return m_shape; };

    inline INT NumLines( ) const
    {
        AREA_PTYP obj_area = (AREA_PTYP)GetCell();
        return obj_area->NumLines();
    };

    inline INT NumKps( ) const { return m_numkps; };
    void SetNumKps( const INT numkps );
    inline INT KpId( const INT index ) const { return m_a_kps[index]; };
    inline INT const *KpIds( ) const { return m_a_kps; };
    inline void SetKpIds( INT * a_kps ) { m_a_kps = a_kps; };

    INT KpAreaStat( KP_PTYP obj_kp, INT &kpstat ) const;
    INT getKpAreaAngle( KP_PTYP obj_kp,DOUBLE &kpAngle );
    inline INT const *KpAreaStat( ) const { return m_a_kpstat; };
    inline INT KpAreaStat( INT index ) { return m_a_kpstat[index]; };
    void SetKpAreaStat( KP_PTYP const obj_kp, INT const stat );
    inline void SetKpAreaStat( INT const ikp, INT const stat )
    {
        if ( m_a_kpstat ) {
            m_a_kpstat[ikp] = stat;

            /* === By changing the status of this kp, the linedirs are
            === probably messed up so free them if they are already
            === determined. */

            FEM_Free_C( m_a_linedirs );
        }
    };
    inline void SetKpAreaStat( INT * a_kpstat )
    {
        m_a_kpstat = a_kpstat;

        /* === By changing the status of this kp, the linedirs are
        === probably messed up so free them if they are already
        === determined. */

        FEM_Free_C( m_a_linedirs );
    };

    void SetAxisKp( INT kpid );
    void InitAxisKps( void );
    FEM_BOOLEAN IsKpASweepAxis( KP_PTYP obj_kp ) const;
    FEM_BOOLEAN IsKpASweepAxis( INT kpid ) const;

    inline DOUBLE const *KpAngles( ) const { return m_kpangles; };
    inline void SetKpAngles( DOUBLE * kpangles ) { m_kpangles = kpangles; };
    inline DOUBLE KpAngle( INT index ) { return m_kpangles[index]; };

    inline void SetArea( const AREA_PTYP obj_area ) { SetCell( obj_area ); };
    inline AREA_PTYP GetArea( ) const { return (AREA_PTYP)GetCell(); };

    INT const *GetLineDirs( void );
    INT GetLineDir( LINE_PTYP obj_line );

    INT ClassifyLines( FEM_BOOLEAN &classified );

    inline FEM_BOOLEAN IsAreaHpt( INT kp_id ) const
    {
        AREA_PTYP obj_area = (AREA_PTYP)GetCell();
        return obj_area->IsHpt( kp_id );
    };

    INT IsBndLine( const INT line_id, FEM_BOOLEAN &bndline );
    INT IsBndKp( const INT line_id, FEM_BOOLEAN &bndkp );
    INT IsBndHdpt( const INT kp_id, FEM_BOOLEAN &bndhpt );
    INT FindCornerNodes( );
    INT CountNumBndNodes( FEM_BOOLEAN include_mids );
    INT CountNumAreaNodes( FEM_BOOLEAN include_mids );
    INT CountNumAreaEdges( void );
    INT CountNumAreaElems( void );
    inline INT NumTrgs( void ) const { return m_numtrgs; };
    INT GetMaxNodeId( INT &max_id );
    INT GetNumBndNodes( INT &num_nodes, INT &num_crn_nodes,
        FEM_BOOLEAN include_mids );
    INT GetNumAreaNodes( INT &num_nodes, FEM_BOOLEAN include_mids );
    INT GetNumAreaEdges( INT &num_edges );
    INT GetNumAreaElems( INT &num_quads, INT &num_tris );
    INT SetNotMapped( VOL_PTYP obj_testvol, VOL_PTYP obj_startvol, FEM_BOOLEAN &possible );
    INT CheckHardLineMapable( void );
    inline  void SetOnSweepableVol( FEM_BOOLEAN onvol =TRUE ) { m_OnSweepableVol = onvol; };
    FEM_BOOLEAN OnSweepableVol( FEM_BOOLEAN bMustSweep = FALSE );
    // below this line, new functions, all the above functions will be replaced gradually
    INT mesh( INT iOpt );
    inline INT getId() {return Id(); }
    inline INT getShape() {return (INT)Shape();}
    inline FEM_BOOLEAN needProjMids() {return ProjectMids();}
    inline INT getNumKps() { return (INT)NumKps();}
    INT isMapable();
    INT getNumAxisKps() const {return m_numaxiskps;}
    inline void setNumAxisKps(const int & iNum)
    {
        m_numaxiskps = iNum;
        return;
    }
    INT copyMeshFromSrc(INT smooth, AREAMSHDAT_PTYP mMshStartFace);
    inline AREA_PTYP getGeom() {return (AREA_PTYP)GetCell();}
    INT retriveBndNodesAndEdgesV1(AREAMSHDAT_PTYP mStartFac);
    inline AREAMSHDAT_PTYP getSource() { return m_p_trginfo->GetSrcArea();}
    AREAMSHDAT_PTYP getOtherSource(); 
    INT getBndNodes( INT &num_nodes, INT &num_crn_nodes, NODE_OBJ *&bndNodes );
    INT getBndEdges( INT &num_edges, INT *&bndEdgeIds );
    inline void setMeshed( INT meshed ) { m_meshed = meshed; }
    inline INT isMeshed() { return m_meshed ;}
    //inline void setPreMeshed( INT meshed ){ m_premeshed = meshed ;}
    //inline INT isPreMeshed() { return m_premeshed ;}
    inline void setMapable( INT mapable ) {m_mapable = mapable ; }
    inline void setMapableHardDivs( INT mapable ) {m_mapableharddivs = mapable; }
    inline INT isMapableHardDivs(){ return m_mapableharddivs; }
    inline void setIsSide( INT isSide ){m_side = isSide; }
    inline INT isSide(){ return m_side; } 
    inline void setIsSource( INT isSrc ) 
    {
        if ( isSrc ) 
            m_source++;
        else m_source = 0;
    }
    inline INT isSource( ) { return m_source; }
    inline void removeOneSource()
    {
        if( m_source > 0 ) 
            m_source--;
    }
    inline INT isTarget( ) { return m_numtrgs ; }
    inline INT isSrcOrTrg() { return isSource() || isTarget(); } 
    inline void setNeedMidNodes( INT needMid ) { m_needsmidndoes = needMid ; }
    inline INT needMidNodes() { return m_needsmidndoes; } 
    inline void setDropMidNodes( INT dropMid ){m_dropmidndoes = dropMid ;}
    inline INT canDropMidNodes() { return m_dropmidndoes ; }
    inline void setVolLoopSrc( INT VolLoopSrc ){ m_volloopsrc = VolLoopSrc; }
    inline INT isVolLoopSrc( ) { return m_volloopsrc;}
    inline void setProjectMids( INT proj ) {m_projectmids = proj; }
    inline INT projectMids( ) { return m_projectmids ; } 
    INT checkMapableByNbrUsage(VOL_PTYP gTestVol,VOL_PTYP gStartVol, FEM_BOOLEAN &notMapable );
    INT checkCanBeTarget(AREAMSHDAT_PTYP &mTrg,FEM_BOOLEAN &canBeTarget );
    INT fixTwoTrg( );
    INT getNumAreaNodes(INT &num_nodes  );
    INT getNumAreaCornerNodes(INT &num_nodes  );
    INT classifyLines( FEM_BOOLEAN &classified ) ;
    INT getLineDirs( INT *&lineDirs );
    INT makeMeshConsistent();
    INT premeshHasMid();

    FEM_BOOLEAN doesAreaHave4EndsAnd0Corners();

private:
    INT preMeshJunk();
    INT postMeshJunk();
private:
    INT mNumBndNodes; // all the bnd nodes, including corner and mid
    INT mNumBndNodesMid; // all the bnd mid node
    INT mNumBndNodesCor; // all the bnd corner node
    INT mNumAreaNodes; // all nodes on the area, including IN area and on area bnd nodes
    INT mNumAreaNodesMid; // all nodes on the area, mid node only, including IN area and on area bnd nodes
    INT mNumAreaNodesCor; // all nodes on the area, corner node only, including IN area and on area bnd nodes
    EDGE_OBJ *m_a_obj_bnd_edges; // bnd edge list
    INT *mBndEdgeDirs; // bnd edge dir 1 for from node0 to node 1, -1 for from node1 to node0
    INT mShifted;
    INT mShiftDir;
    DOUBLE mShiftLim[2];
    INT m_mark ;

public:
    void setNumBndNodes( INT nMid, INT nCor );
    void setNumAreaNodes(INT nMid, INT nCor );
    INT getNumBndNodes( INT *nMid, INT *nCor );
    INT getNumAreaNodes(INT *nMid, INT *nCor );
    INT countNumBndNodes( INT &nMid, INT &nCor );
    INT countNumAreaNodes(INT &nMid, INT &nCor );
    INT countNumNodes(INT &nInMid, INT &nInCor, INT &nBndMid, INT &nBndCor);
    inline void setNumBndEdges( INT ne ) { m_num_bnd_edges=ne;}
    inline INT  getNumBndEdges() { return m_num_bnd_edges;}
    void setBndEdges( EDGE_OBJ *edges, INT *dirs ) ; 
    void getBndEdges( EDGE_OBJ *&edges, INT *&dirs) ;
    void setBndNodes( NODE_OBJ *nodes ) ;
    NODE_OBJ *getBndNodes() { return m_aobj_bnd_nodes; }
    void setUvShiftInfo( INT shifted, INT shiftDir, DOUBLE minPar, DOUBLE maxPar ) ;
    void getUvShiftInfo( INT &shifted, INT &shiftDir, DOUBLE &minPar, DOUBLE &maxPar ) ;
    void setEdgeIdxArray( INT *a_iel ) ;// do not know waht to call for m_a_iel
    inline INT *getEdgeIdxArray( void ) { return m_a_iel ;};
    inline void setMark( INT mark ) { m_mark = mark ; };
    inline INT getMark() { return m_mark ; }
    FEM_BOOLEAN hasMapMeshControl();
    FEM_BOOLEAN onThinModelVolume();
    INT doForceMap() { return m_forceMap; };
    void setForceMap( INT bForceMap=1) { m_forceMap = bForceMap; FEM_Free_C(m_a_linedirs);};
    void setNumRadialDivs( INT iNumDiv ) { m_iNumRadialDivs = iNumDiv; setForceMap();};
    INT  getNumRadialDivs() { return m_iNumRadialDivs; };
    INT nbr2ForcedMap();
    void setWasMapped( INT bWasMapped ) { m_bWasMapped = bWasMapped; };
    void setPassQualityByLineSmoothing( INT bDidLineSmooth ){ m_bPassQualityByLineSmoothing=bDidLineSmooth;};
    INT getPassQualityByLineSmoothing(){ return m_bPassQualityByLineSmoothing;};
    INT getWasMapped( ) { return m_bWasMapped;};
    void setInflated( FEM_BOOLEAN bInflated ) { m_bInflated = bInflated; };
    FEM_BOOLEAN isInflated() { return m_bInflated;};
    void setImportedMesh( FEM_BOOLEAN flag );/* { m_bImportedMesh = flag; };*/
    FEM_BOOLEAN isImportedMesh(); /* { return m_bImportedMesh; };*/
};

void FEM_aeMd( AREAMSHDAT_PTYP obj_areadata );
extern "C"
INT FEM_aeGetKpAreaAngle( INT anum, INT iKp, DOUBLE *angle);
#endif

