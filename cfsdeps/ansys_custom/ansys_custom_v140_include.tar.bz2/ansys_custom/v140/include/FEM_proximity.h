/* CFILE FEM_proximity.h        meshing                           alc */
/*
 * *** ansys(r) copyright(c) 2009
 * *** ansys, inc.
 */

/*************************************************************************
  PLEASE, UPDATE HISTORY FIELD BELOW WHEN YOU MAKE ANY MODIFICATION
 *************************************************************************

 Description    : Data types used on surface proximity processing
                  are declared here as well as all function prototypes,
                  globals, enumerations, constants and macros.
 Author         : alc
 History        : 96/09/12 - created by alc

 *************************************************************************/

#ifndef SP_PROXIMITY_H
#define SP_PROXIMITY_H

/*************************************************************************
 DATA TYPES
 *************************************************************************/

struct RANGEDATA_TYP;
struct RECTANGLE_TYP;

typedef struct RECTLIST_TYP    *RECTLIST_PTYP;
typedef struct VERTEX_TYP      *VERTEX_PTYP;
typedef struct VERTEXLIST_TYP  *VERTEXLIST_PTYP;
typedef struct RECTANGLE_TYP   *RECTANGLE_PTYP;
typedef struct BOUNDINGBOX_TYP *BOUNDINGBOX_PTYP;
typedef struct RANGEDATA_TYP   *RANGEDATA_PTYP;
typedef struct RANGETREE_TYP   *RANGETREE_PTYP;
typedef struct VERTEXAREA_TYP  *VERTEXAREA_PTYP;

#define DOUBLE_TYP              DOUBLE
#define DOUBLE_PTYP             DOUBLE_TYP*

#include "FEM_point.h"

/*=========================================================================
 * === Data type name: RECTLIST_TYP
 * === Description   : Single linked list of RECTANGLE_TYP
 * === Fields   : ps_rect - points to a rectangle
 * ===            ps_next - points to next element on the list
 * === Author   : alc
 * ========================================================================*/
typedef struct RECTLIST_TYP {
  struct RECTANGLE_TYP *ps_rect;
  struct RECTLIST_TYP  *ps_next;
} RECTLIST_TYP;


/*=========================================================================
 * === Data type name: VERTEX_TYP
 * === Description   : the counterpart of a node with additional info
 * ===                 for surface proximity processing
 * === Fields   : obj_node  - node object
 * ===            size      - vertex size
 * ===            ref_level - level of refinement
 * ===            flag      - nodes have different flags
 * ===            ps_rlist  - list of rectangles/facets vertex belongs to
 * === Author   : alc
 * ========================================================================*/
typedef struct VERTEX_TYP {
  NODE_OBJ          obj_node;
  DOUBLE            size;
  SHORT             ref_level;
  SHORT             flag;
  RECTLIST_TYP      *ps_rlist;
} VERTEX_TYP;


/*=========================================================================
 * === Data type name: VERTEXLIST_TYP
 * === Description   : Doubly linked list of VERTEX_TYP's
 * === Fields   : ps_vertex - points to a vertex
 * ===            ps_prev   - points to previous vertex on the list
 * ===            ps_next   - points to next vertex on the list
 * === Author   : alc
 * ========================================================================*/
typedef struct VERTEXLIST_TYP {
  VERTEX_TYP            *ps_vertex;
  struct VERTEXLIST_TYP *ps_prev;
  struct VERTEXLIST_TYP *ps_next;
} VERTEXLIST_TYP;


/*=========================================================================
 * === Data type name: RECTANGLE_TYP
 * === Description   : a rectangle is defined by a facet and it works as a
 * ===                 bounding box
 * === Author   : alc
 * ========================================================================*/
typedef struct RECTANGLE_TYP {
  FACE_OBJ   obj_face;     /* face object the rectangle surrounds. */
  DOUBLE     a,b,c,d;      /* coefficients of the plane equation defined by
                              the facets. (a,b,c are the normal vector
                              coordinates. */
  DOUBLE     size;         /* representative size of obj_face */
  SHORT      flag;         /* rectangles have different flags when performing
                              bounding box intersections. */
  INT        minindex[3];  /* indices in range tree for min x,y,z coords */
  INT        maxindex[3];  /* indices in range tree for max x,y,z coords */
} RECTANGLE_TYP;


/*=========================================================================
 * === Data type name: BOUNDINGBOX_TYP
 * === Description   : A rectangular bounding box is used as a representation of 
 * ===                 the vicinity of a node on the space.
 * === Fields   : ps_vertex - the vertex that defines the bounding box
 * ===            Lx, Rx    - x interval [Lx, Rx]
 * ===            Ly, Ry    - y interval [Ly, Ry]
 * ===            Lz, Rz    - z interval [Lz, Rz]
 * === Author   : alc
 * ========================================================================*/
typedef struct BOUNDINGBOX_TYP {
  VERTEX_TYP   *ps_vertex;   /* corresponding vertex */
  DOUBLE   Lx, Rx;      /* x interval [Lx, Rx] */
  DOUBLE   Ly, Ry;      /* y interval [Ly, Ry] */
  DOUBLE   Lz, Rz;      /* z interval [Lz, Rz] */
} BOUNDINGBOX_TYP;


/*=========================================================================
 * === Data type name: RANGEDATA_TYP
 * === Description   : This is the info stored in the leaf nodes of the
 * ===                 range tree (defined below). Each facet implies a
 * ===                 rectangle/boundig box which is defined by six coordinates
 * ===                 stored as six RANGEDATA_TYP
 * === Fields   : coord  - coordinate of the range data
 * ===            rect   - the rectangle the coord belongs to
 * ===            index  - an array is used to store the range data; index
 * ===                     is this array index after performing a sorting
 * ===                     on it
 * === Author   : alc
 * ========================================================================*/
typedef struct RANGEDATA_TYP {
  DOUBLE         coord;     /* node key value (a x,y or z value) */
  RECTANGLE_TYP *rect;      /* rectangle it belongs to */
} RANGEDATA_TYP;


/*=========================================================================
 * === Data type name: RANGETREE_TYP
 * === Description   : This is a simple 3D version of the range tree. It is
 * ===                 composed of three sorted arrays each
 * ===                 with N elements and primarily used to perform three
 * ===                 dimensional searchs (bounding box intersections).
 * === Author   : alc
 * ========================================================================*/
typedef struct RANGETREE_TYP {
  RANGEDATA_PTYP *aps_x_rdata;   /* array of range data in x direction     */
  RANGEDATA_PTYP *aps_y_rdata;   /* array of range data in y direction     */
  RANGEDATA_PTYP *aps_z_rdata;   /* array of range data in z direction     */
  INT      N;                    /* number of elements used in each array  */
  INT      max_N;                /* max number of elements  in each array  */
                                 /* (can be reallocated to be larger)      */
} RANGETREE_TYP;



/*=========================================================================
 * === Data type name: VERTEXAREA_TYP
 * === Description   : A pair of area id and vertex on that area with the
 * ===                 highest refinement level
 * === Fields   : area_id     - area id
 * ===            ps_vertex   - pointer to a vertex
 * === Author   : alc
 * ========================================================================*/
typedef struct VERTEXAREA_TYP {
    INT           area_id;     /* area id */
    VERTEX_TYP   *ps_vertex;   /* vertex with max ref level on the area */
} VERTEXAREA_TYP;



/*************************************************************************
 ENUMERATIONS 
 *************************************************************************/

/*=========================================================================
 * === Enumeration name: projection_plane
 * === Description: The three projection planes in 3D: XY, XZ and YZ
 * === Author: alc
 * ========================================================================*/
typedef enum { XY = 0, XZ, YZ } projection_plane;


/*************************************************************************
 MACROS
 *************************************************************************/

/*=========================================================================
 * === Macro name: COORD
 * === Author: alc
 * === Description: Returns coordinate value associated with a leaf node
 * === Arguments: bnode    - a binary node, BINNODE_TYP (see file 
 * ===                       FEM_binnode.h)
 * === Return: DOUBLE* - the coordinate value associated with bnode
 * === Notes: 
 * ========================================================================*/
#define COORD(bnode) ((DOUBLE*)((*(RANGEDATA_TYP**)bnode->data))->coord)


/*=========================================================================
 * === Macro name: fem_spSignedDistPointPlane_C
 * === Author: alc
 * === Description: Returns the signed distance from a point, POINT_TYP, to
 * ===              a plane stored on ps_rect
 * === Arguments: POINT_TYP *ps_point    - a pointer to a point
 * ===            RECTANGLE_TYP *ps_rect - a pointer to a rectangle
 * === Return:    DOUBLE                - signed distance value
 * === Notes: If the plane normal vector stored on ps_rect points 
 * ===        INWARDS and the point ps_point is NOT behind the plane,
 * ===        the returned value must be NON negative. When the
 * ===        point IS behind the plane, it returns a negative
 * ===        value.
 * ========================================================================*/
#define fem_spSignedDistPointPlane_C(ps_point, ps_rect) \
          (DOUBLE) ((ps_rect)->d + (ps_point)->x * (ps_rect)->a + \
     (ps_point)->y * (ps_rect)->b + (ps_point)->z * (ps_rect)->c)



/*=========================================================================
 * === Macro name: fem_spInsertRectList_C
 * === Author: alc
 * === Description: Insert a rectangle, ps_rect, in the rectangle list
 * ===              ps_rlist using ps_new as a new member of the list
 * === Arguments: RECTLIST_TYP *ps_new   - points to a rectlist
 * ===            RECTLIST_TYP *ps_rlist - points to head of current
 * ===                                     rectangle list
 * ===            RECTANGLE_TYP *ps_rect - the rectangle to be inserted
 * === Return: none
 * === Notes: In the very beginning, initialize ps_rlist with NULL
 * ===        to guarantee the last element on the list points to
 * ===        NULL (and you can correctly loop through the list!)
 * ========================================================================*/
#define fem_spInsertRectList_C(ps_new, ps_rlist, ps_rect) \
    ps_new = (RECTLIST_PTYP)FEM_spMalloc( RECTLIST );\
    if ( !ps_new ) {\
       FEMe_Error( GENERIC, GEN_OUT_OF_MEMORY, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
       return EXIT_FAILURE;\
    }\
    ps_new->ps_rect = ps_rect;\
    ps_new->ps_next = ps_rlist;\
    ps_rlist = ps_new

/*=========================================================================
 * === Macro name: fem_spRemoveRectFromList_C
 * === Author: mls
 * === Description: Remove a rectangle, ps_rect, from the rectangle list
 * ===              ps_rlist
 * === Arguments: RECTLIST_TYP *ps_rlist - points to head of current
 * ===                                     rectangle list
 * ===            RECTANGLE_TYP *ps_rect - the rectangle to be removed
 * === Return: none
 * ========================================================================*/
#define fem_spRemoveRectFromList_C( ps_therect, ps_rlist ) \
    ps_temp = ps_rlist;\
    ps_last = NULL;\
    while ( ps_temp ) {\
      if ( ps_temp->ps_rect == ps_therect ) {\
         if ( ps_last ) {\
            ps_last->ps_next = ps_temp->ps_next;\
         }\
         else {\
            ps_rlist = ps_temp->ps_next;\
         }\
         FEM_spFree( RECTLIST, ps_temp );\
         break;\
      }\
      ps_last = ps_temp;\
      ps_temp = ps_temp->ps_next;\
    }


/*=========================================================================
 * === Macro name: fem_spInsertVertList_C
 * === Author: alc
 * === Description: Insert a vertex, ps_vertex, in the head of the vertex list
 * ===              ps_vertexlist using ps_new as a new member of the list
 * === Arguments:   VERTEXLIST_TYP *ps_new        - new member
 * ===              VERTEXLIST_TYP *ps_vertexlist - vertex list
 * ===              VERTEX_TYP     *ps_vertex     - vertex to be inserted
 * === Return: none
 * === Notes: In the very beginning, initialize ps_vertexlist with NULL
 * ===        to guarantee the last element on the list points to
 * ===        NULL (and you can correctly loop through it!)
 * ========================================================================*/
#define fem_spInsertVertList_C(ps_new, ps_vertexlist, ps_vertex) \
   ps_new = (VERTEXLIST_PTYP)FEM_spMalloc( VERTEXLIST );\
   if ( !ps_new ) {\
      FEMe_Error( GENERIC, GEN_OUT_OF_MEMORY, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
      return EXIT_FAILURE;\
   }\
   ps_new->ps_vertex = ps_vertex;\
   ps_new->ps_next = ps_vertexlist;\
   ps_new->ps_prev = NULL;\
   if (ps_vertexlist) ps_vertexlist->ps_prev = ps_new;\
   ps_vertexlist = ps_new


/*=========================================================================
 * === Macro name: fem_spRemoveVertList_C
 * === Author: alc
 * === Description: Remove ps_vlist from its vertex list ps_vertexlist
 * === Arguments:   VERTEXLIST_TYP *ps_vlist      - member to be removed
                    VERTEXLIST_TYP *ps_vertexlist - vertex list
 * === Return: none
 * === Notes:  Assumed ps_vlist is a member of the list
 * ========================================================================*/
#define fem_spRemoveVertList_C(ps_vlist, ps_vertexlist) \
   if (ps_vlist->ps_prev) { \
     ps_vlist->ps_prev->ps_next = ps_vlist->ps_next;\
   }\
   else {\
     ps_vertexlist = ps_vertexlist->ps_next;\
   }\
   if (ps_vlist->ps_next) {\
     ps_vlist->ps_next->ps_prev = ps_vlist->ps_prev;\
   }\
   FEM_spFree( VERTEXLIST, ps_vlist );


/*=========================================================================
 * === Macro name: fem_spNotMidnode_C
 * === Author: alc
 * === Description: return "TRUE" if node is not a midside node and "FALSE"
 * ===              otherwise
 * === Arguments: NODE_OBJ obj_node   - the node object
 * === Retur: int         - 0  = FALSE
 * ===                       !0 = TRUE
 * === Notes:
 * ========================================================================*/
#define fem_spNotMidnode_C(obj_node) \
    !FEM_noProperty_C(obj_node, NODE_MIDSIDE)


/*=========================================================================
 * === Macro name: fem_spValidNode_C
 * === Author: alc
 * === Description: According to surface proximity refinement, a node is
 * ===              considered valid for refinement if it is not a
 * ===              midside node, not a node on a geometry line and nor
 * ===              a node on a face adjacent to a geometry line.
 * ===
 * === Arguments: NODE_OBJ obj_node   - the node object
 * === Return: int         - 0  = FALSE
 * ===                       !0 = TRUE
 * === Notes:
 * ========================================================================*/
#define fem_spValidNode_C(obj_node) \
   (!FEM_noProperty_C(obj_node, NODE_MIDSIDE) && \
    !FEM_noProperty_C(obj_node, NODE_ON_LINE))


/*************************************************************************
 GLOBALS AND CONSTANTS FOR SURFACE PROXIMITY
 *************************************************************************/

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  Constant name   : DOTPROD_TRESHOLD
  Author   : alc
  Description   : If the dot product between a node normal and a facet
        normal is less than DOTPROD_TRESHOLD then they are
        assumed to face each other.
  Notes      : Assume normal of facets point outwards
 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
#define DOTPROD_TRESHOLD -0.2   /* angle between normals is ~ 100 degrees */


/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  Constant name   : MIN_ANGLE_COS
  Author   : alc
  Description   : If the dot product of two face normals sharing a common 
        edge which it is on a line is less than this value, then
        we consider them to form a sharp corner.
  Notes      : Assume normal of facets point inwards
 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
#define MIN_ANGLE_COS   -0.707      /* 45 degrees angle */


/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  Constant name   : INV_LN_2
  Author   : alc
  Description   : 1/ln(2)
  Notes      : 
 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
#define INV_LN_2   1.442695

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  Constant name   : LN_ONE_HALF
  Author   : mls
  Description   : ln(0.5) 
  Notes      : 
 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
#define LN_ONE_HALF   -0.69314718056

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  Constant name   : POINT_ON_PLANE_PRECISION
  Author   : alc
  Description   : Precision for point on plane
  Notes      : 
 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
#define POINT_ON_PLANE_PRECISION   1.0E-03


/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  Constant name : POINT_ON_LINE_PRECISION
  Author        : alc
  Description   : Precision for point on line
  Notes         : 
 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
#define POINT_ON_LINE_PRECISION      1.0E-03

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  Constant name   : AUX_NUMBER
  Author   : alc
  Description   : sqrt(2/3)*(1/3)*(1/(alpha = 1.4)) - used in
                  fem_spInitFacets function
 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
#define AUX_NUMBER   0.22680461

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  Constant name   : AUX_NUMBER2
  Author   : alc
  Description   : sqrt(2/3)*(1/(alpha = 1.4)) - used in
                  fem_spTagNodesForRefinement function
 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
#define AUX_NUMBER2  0.68041383

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  Constant name   : AREA_TO_EDGE_LENGTH_FACTOR
  Author   : mls
  Description   : sqrt( 2/sin(60 degrees) ).  This is used to calculate
                  the edge length of an equilateral area given the
                  area.

                    edge_length = AREA_TO_EDGE_LENGTH_FACTOR * sqrt(area)
 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
#define AREA_TO_EDGE_LENGTH_FACTOR 1.5196713713

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  Constant name : Various (see below)
  Author        : alc
  Description   : Node flags for different stages of the surface proximity
                  computation
  Notes         : 
 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
#define NODE_INIT      0
#define NODE_TAGED      1
#define NODE_REFINED      2
#define NODE_NONREFINABLE   99



/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  Constant name : Various (see below)
  Author        : alc
  Description   : Node position relative to an edge line
  Notes         : 
 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
#define NODE_AT_LEFT      (0)
#define NODE_AT_RIGHT      (1<<0)
#define NODE_ON_LINE      (1<<1)


/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  Constant name   : Various (see below)
  Author          : alc
  Description     : Node position relative to a triangle (see diagram below)
  Notes           : Triangle edges divide the plane in seven regions
 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
#define INSIDE         0
#define REGION_1      1
#define REGION_2      2
#define REGION_3      3
#define REGION_4      4
#define REGION_5      5
#define REGION_6      6

/*
            \ (5) /
             \   /      [.] = node number
              \ /         (.) = region number
              [0]         {.} = edge number
              / \
     (1)     /   \     (4)
         {0}/     \{2}
           / INSIDE\
          /   (0)   \
 -------[1]---------[2]--------
        /     {1}     \
 (3)   /      (2)      \   (6)
      /                 \
*/



/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  Constant name   : Various (see below)
  Author   : alc
  Description   : Rectangle flags for different stages of the surface 
        proximity computation
  Notes      : 
 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
#define RECT_INIT      1
#define RECT_FIRST_INTERS   1
#define RECT_SECOND_INTERS   2
#define RECT_THIRD_INTERS   3
#define RECT_INTERSECTED   4
#define RECT_NON_INTERSECTABLE  99

/*************************************************************************
 Debugging FUNCTION PROTOTYPES FOR SURFACE PROXIMITY
 *************************************************************************/

                          /* =============================================== */
                          /* === FEM_spCheckSurfProx: Perform Surface        */
                          /* === proximity refinement on the facets in the c */
                          /* === meshing database.  The C meshing database   */
                          /* === should be initialized with shell elements   */
                          /* === only (i.e. no 3D volume elements).          */
                          /* === Return: EXIT_FAILURE or EXIT_SUCCESS        */
                          /* =============================================== */
INT FEM_spCheckSurfProx (
   DOUBLE growth_ratio,     /* (IN)  max allowable growth ratio              */
   DOUBLE minesize,         /* (IN)  min edge length size                    */
   INT *a_refineableareas,  /* (IN)  array of areas that can be refined on   */
   INT num_refineableareas, /* (IN)  length of a_refineableareas             */
   INT *a_refineablelines,  /* (IN)  array of lines that can be refined on   */
   INT num_refineablelines, /* (IN)  length of a_refineablelines             */
   INT *a_refineablekps,    /* (IN)  array of lines that can be refined on   */
   INT num_refineablekps,   /* (IN)  length of a_refineablekps               */
   INT midnodes,            /* (IN)  True if midnodes exist                  */
   INT change_shells,       /* (IN)  True if shell elems can be changed      */
   INT *abort  );           /* (OUT) !0 if user requests abort               */

                          /* =============================================== */
                          /* === FEM_spPrintAllRect: print contents of all   */
                          /* === rectangles.                                 */
                          /* === Return: void                                */
                          /* =============================================== */
void FEM_spPrintAllRect (
   INT faceids_only  );

                          /* =============================================== */
                          /* === FEM_spFindRectInList: Find and print a      */
                          /* === particular face in a list given its id.     */
                          /* === Return: void                                */
                          /* =============================================== */
void FEM_spFindRectInList (
   INT faceid,               /* The face to find in the list */
   RECTANGLE_TYP **aps_rect, /* array of pointers to rectangles */
   INT length  );            /* number of rectangles in aps_rect */

                          /* =============================================== */
                          /* === FEM_spPrintRectArray: print contents of an  */
                          /* === array of rectangles.                        */
                          /* === Return: void                                */
                          /* =============================================== */
void FEM_spPrintRectArray (
   RECTANGLE_TYP **aps_rect,
   INT length,
   INT faceids_only  );

                          /* =============================================== */
                          /* === FEM_spPrintRect: print contents of a        */
                          /* === rectangles.                                 */
                          /* === Return: void                                */
                          /* =============================================== */
void FEM_spPrintRect (
   FACE_OBJ obj_face  );

                          /* =============================================== */
                          /* === FEM_spPrintTagedNodes: print taged nodes    */
                          /* === for refinement.                             */
                          /* === Return: void                                */
                          /* =============================================== */
void FEM_spPrintTagedNodes (
   VERTEXLIST_TYP *ps_vertexlist  );

                          /* =============================================== */
                          /* === FEM_spPrintAllVert: print all nodes/vertices*/
                          /* === Return: void                                */
                          /* =============================================== */
void FEM_spPrintAllVert ( );

                          /* =============================================== */
                          /* === FEM_spPtonPlane: test if point is on a plane*/
                          /* === Return: Double (the distance from the point */
                          /* === to the plane)                               */
                          /* =============================================== */
DOUBLE FEM_spPtonPlane (
   POINT_TYP *ps_point,
   RECTANGLE_TYP *ps_rect  );

#endif /* SP_PROXIMITY_H */


