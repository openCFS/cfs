
/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 2009 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_MeshTree.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_MeshTree.h
 *  header file for FEM_MeshTree.cpp
 *
 */
/* *** mpg math array c
 FEM_array.c FEM_matrix.c FEM_MeshTable.h FEM_Public.h FEM_array.h
 FEM_array_static.h  FEM_cdbtypes.h FEM_edPublic.h FEM_elPublic.h
 FEM_errors.h FEM_external.h FEM_faPublic.h FEM_matrix.h
 FEM_matrix_static.h FEM_meshTree.h FEM_noGeom.h FEM_noPublic.h
 FEM_publicElementDefinition.h fem_Struct.h
 ansproto.h computer.h float.h globals.h mathfun.h
*/
#ifndef FEM_MeshTREE_H
#define FEM_MeshTREE_H


typedef enum { kQuad2DTree = 0, kQuad3DTree, kOctTree, kQuad2DAndOctTree, kQuad3DAndOctTree } _eTreeType;



#ifdef __cplusplus
extern "C" {
#endif

    void FEM_buildMeshTree ( MESH_OBJ obj_mesh, _eTreeType eType );
    void FEM_detroyMeshTree ( MESH_OBJ obj_mesh );

#ifdef __cplusplus
}
#endif

#endif

