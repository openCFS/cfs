/*****************************************************************************
 *                   Copyright (C) 1999 CMSoft                               *
 *                                                                           *
 *  These lines of code and declarations contain unpublished proprietary     *
 *  information of CMSoft. They may not be copied or duplicated in whole     *
 *  or part without prior authorization from CMSoft.                         *
 *                                                                           *
 *****************************************************************************/
#ifndef _FS_GEN_SOLVER_H_
#define _FS_GEN_SOLVER_H_

class FSGenSolver {
 public:
    virtual void solve(double *) = 0;
};

#endif
