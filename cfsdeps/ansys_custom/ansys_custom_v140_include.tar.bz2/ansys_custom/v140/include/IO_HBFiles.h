#ifndef IO_HBFILES_H
#define IO_HBFILES_H

#include<stdio.h>
#include<stdlib.h>
#include<malloc.h>
#ifdef __cplusplus
extern "C" {
#endif

int HBRead_info(const char* filename, int* M, int* N, int* nz, char** Type, 
                                                      int* Nrhs);

int HBRead_header(FILE* in_file, char* Title, char* Key, char* Type, 
                    int* Nrow, int* Ncol, int* Nnzero, int* Nrhs,
                    char* Ptrfmt, char* Indfmt, char* Valfmt, char* Rhsfmt, 
                    int* Ptrcrd, int* Indcrd, int* Valcrd, int* Rhscrd, 
                    char *Rhstype);

int HBRead_mat_double(const char* filename, int colptr[], int rowind[], 
                                                                 double val[]);

int HBRead_newmat_double(const char* filename, int* M, int* N, int* nonzeros, 
                         int** colptr, int** rowind, double** val);

int HBRead_aux_double(const char* filename, const char AuxType, double b[]);

int HBRead_newaux_double(const char* filename, const char AuxType, double** b);

int HBWrite_mat_double(const char* filename, int M, int N, 
                        int nz, const int colptr[], const int rowind[], 
                        const double val[], int Nrhs, const double rhs[], 
                        const double guess[], const double exact[],
                        const char* Title, const char* Key, const char* Type, 
                        char* Ptrfmt, char* Indfmt, char* Valfmt, char* Rhsfmt,
                        const char* Rhstype);

int HBRead_mat_char(const char* filename, int colptr[], int rowind[], 
                                           char val[], char* Valfmt);

int HBRead_newmat_char(const char* filename, int* M, int* N, int* nonzeros, int** colptr, 
                          int** rowind, char** val, char** Valfmt);

int HBRead_aux_char(const char* filename, const char AuxType, char b[]);

int HBRead_newaux_char(const char* filename, const char AuxType, char** b, char** Rhsfmt);

int HBWrite_mat_char(const char* filename, int M, int N, 
                        int nz, const int colptr[], const int rowind[], 
                        const char val[], int Nrhs, const char rhs[], 
                        const char guess[], const char exact[], 
                        const char* Title, const char* Key, const char* Type, 
                        char* Ptrfmt, char* Indfmt, char* Valfmt, char* Rhsfmt,
                        const char* Rhstype);

int ParseIfmt(char* fmt, int* perline, int* width);

int ParseRfmt(char* fmt, int* perline, int* width, int* prec, int* flag);

void IOHBTerminate(char* message);
#ifdef __cplusplus
}
#endif

#endif
