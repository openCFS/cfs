
/*
////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         	Copyright (C) 2010 ANSYS Inc.  All Rights Reserved             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MAT_CurveFitCommandParser.h $
// $Revision: 1.7 $ 7.0
// $Date: 2010/04/06 19:56:50 $ March 28 2002
// $Author: srpailla $ rjayasee/jlo
//
// Decription :
//
//	Code to*GET Curve Fitting Data
//////////////////////////////////////////////////////////////////////////////
*/

/*  tbfit.h */
#if !defined(MAT_CurveFitCommandParser_H)
#define MAT_CurveFitCommandParser_H


#ifdef __cplusplus
extern "C"
{
#endif

void MAT_CurveFitFCaseCommandParser( char pParamList[6][129] ) ;

void MAT_CurveFitExpCommandParser( char pParamList[6][129] ) ;

#ifdef __cplusplus
}
#endif

#endif
