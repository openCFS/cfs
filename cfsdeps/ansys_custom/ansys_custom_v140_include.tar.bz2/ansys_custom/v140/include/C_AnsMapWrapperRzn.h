////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         copyright(c) 2011 SAS IP, Inc.  All rights reserved.           //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: C_AnsMapWrapperRzn.h $
// $Revision: 501292 $ 7.0
// $Date: 2011-08-26 15:10:43 -0400 (Fri, 26 Aug 2011) $ October 04 2005
// $Author: smukherj
//
// Description :
// Header file for wrapper of a integer STL map which can be used in Fortran
// data structures. Hides the implementation under 1 abstraction layer.
////////////////////////////////////////////////////////////////////////////

#pragma once
#ifndef __C_ANSMAPWRAPPERRZN_H__     
#define __C_ANSMAPWRAPPERRZN_H__       1

#if defined (SGIR8K_SYS)
    #pragma set woff 584,584
#else
    #pragma warning(disable: 584)
#endif

// headers required
#include "ANS_StandardIncludes.h"
#include "C_AnsProtoRzn.h"
#include "ANS_Allocator.h"

// use the ansys memory manager for the allocation of memory 
#define RZN_MALLOC(x)  cAnsMemAlloc((x),0,__FILE__,__LINE__)
#define RZN_FREE(x)    cAnsMemFree((x),__FILE__,__LINE__)
#define RZN_NEW(x,y)   (x*)cAnsMemAlloc(sizeof(x)*y,0,__FILE__,__LINE__)
#define RZN_DELETE(x)  cAnsMemFree((x),__FILE__,__LINE__)

// custom allocators,pairs,maps and iterators
typedef pair<const unsigned long, unsigned long >                                       ANS_ULPair;
typedef ANS_Allocator<ANS_ULPair>                                                       ANS_ULPairAllocator;
typedef multimap<unsigned long, unsigned long ,less<unsigned long>,ANS_ULPairAllocator> ANS_ULMULTIMAP;
typedef ANS_ULMULTIMAP::iterator                                                        ANS_ULMULTIMAP_ITER;
typedef ANS_Allocator<unsigned long >                                                   ANS_ULAllocator;
typedef std::vector<unsigned long , ANS_ULAllocator>                                    ANS_ULVector;

// forward declaration
class AnsCoordObj;

typedef pair<const unsigned long, AnsCoordObj*>                                           ANS_COORD_PAIR;
typedef ANS_Allocator<ANS_COORD_PAIR>                                                     ANS_CoordPairAllocator;
typedef multimap<unsigned long, AnsCoordObj *,less<unsigned long>,ANS_CoordPairAllocator> ANS_CPMULTIMAP;
typedef ANS_CPMULTIMAP::iterator                                                          ANS_CPMULTIMAP_ITER;
typedef ANS_Allocator<AnsCoordObj *>                                                      ANS_COORDAllocator;
typedef std::vector<AnsCoordObj *, ANS_COORDAllocator>                                    ANS_COORDVector;


//======================================================================================//
//                               class AnsCoordObj
//======================================================================================//
// DESCRIPTION: DP coordinate object which holds 3 generic coordinate values.
//
// PARENTS: 
// None.                                                                                                                                                                    
//                                                                                      
// CONTENTS:                                                                                                                                                       
// None.
//======================================================================================//

class AnsCoordObj
{
    public:
          // lifecycle operators
          AnsCoordObj()
          {
              m_dCoord[0] = 0.0;
              m_dCoord[1] = 0.0;
              m_dCoord[2] = 0.0;
              m_bIsDeleted = false;
          }
          virtual ~AnsCoordObj()
          {
              m_dCoord[0] = 0.0;
              m_dCoord[1] = 0.0;
              m_dCoord[2] = 0.0;   
              m_bIsDeleted = true;       
          }
          AnsCoordObj(AnsCoordObj &oObj)
          {
              exit(0);
          }
          // overloading 'new' for single variable 
          inline void *operator new(size_t iSize)        
          {
              return RZN_MALLOC(iSize);
          }
          // overloading 'new' for arrays
          inline void *operator new[](size_t iSize)
          {
              return RZN_MALLOC(iSize);
          }
          // overloading 'delete' for single variables
          inline void operator delete(void * pMemPtr)
          {            
              RZN_FREE(pMemPtr) ;
          }
          // overlaoding 'delete' for arrays
          inline void operator delete[](void * pMemPtr )
          {
              RZN_FREE(pMemPtr) ;
          }
          // data
          double m_dCoord[3];
          // signal indicator
          bool m_bIsDeleted;
      protected:
          // none
      private:
          // none
}; //AnsCoordObj 

          
//=====================================================================================//
//                               class AnsMapWrapperRzn
//======================================================================================//
// DESCRIPTION: Wrapper for multi-map data structure which holds several long integer 
// data objects linked to a single key. E.g. the key can be a FE node and the objects can
// be elements connected to that node. In addition, a multimap object with 3 DP values 
// corresponding to the key is also stored.
//
// PARENTS: 
// None.                                                                                                                                                                    
//                                                                                      
// CONTENTS:                                                                                                                                                       
// None.
//======================================================================================//

class AnsMapWrapperRzn
{
    public:
        // lifecycle operators       
        AnsMapWrapperRzn(AnsMapWrapperRzn &oObj)
        {
            exit(0);
        }
        static AnsMapWrapperRzn *Instance(void);
        static void Destroy();
                                 
        // overloading 'new' for single variable 
        inline void *operator new(size_t iSize)        
        {
            return RZN_MALLOC(iSize);
        }
        // overloading 'new' for arrays
        inline void *operator new[](size_t iSize)
        {
            return RZN_MALLOC(iSize);
        }
        // overloading 'delete' for single variables
        inline void operator delete(void * pMemPtr)
        {            
            RZN_FREE(pMemPtr) ;
        }
        // overlaoding 'delete' for arrays
        inline void operator delete[](void * pMemPtr )
        {
            RZN_FREE(pMemPtr) ;
        }
        // load data as nonunique pair
        inline void PutPairData(unsigned long &iKey,
                                unsigned long &iData)
        {
            m_oDataMap.insert(ANS_ULPair(iKey, iData));
            return;
        }
        // load the DP data as a nonunique pair
        void PutPairDPData(unsigned long &,
                           double        &,
                           double        &,
                           double        &);                         
        // given the key, return the number of data elements
        int GetNumDataElem(unsigned long &);
        // get the data elements
        unsigned long GetDataElem(const int &);
        // get the DP data 
        void GetDataDP(const int &, 
                       double    &, 
                       double    &, 
                       double    &);        
        // gets size of map
        inline int GetSize(void)const
        {
            return (int )m_oDataMap.size();
        }
        // return the pointer
        inline AnsMapWrapperRzn* ReturnThis(void)
        {
            return (AnsMapWrapperRzn *)this;
        }
        
    protected:       
        // multimap data structure holding main data
        ANS_ULMULTIMAP   m_oDataMap;
        // multimap holding coordinate info
        ANS_CPMULTIMAP   m_oCoordMap;        
        // current key for retrieval
        unsigned long    m_iCurrKey;
        // current vector for retrieval
        ANS_ULVector     m_vCurrKeyData;
        // current vector of coordinate objects
        ANS_COORDVector  m_vCurrDPData; 
        // clear the data
        void ClearData(void);
                
        // delete the containers in protected destructor      
        virtual ~AnsMapWrapperRzn()
        { 
            ClearData();
        }                         

    private:
        static bool             m_bInstanceFlag;
        static AnsMapWrapperRzn *m_CreateEntity;
        // private constructor
        AnsMapWrapperRzn()
        {
	    // static constructor
	    m_iCurrKey = 0;                
        }        
};//AnsMapWrapperRzn

#endif


