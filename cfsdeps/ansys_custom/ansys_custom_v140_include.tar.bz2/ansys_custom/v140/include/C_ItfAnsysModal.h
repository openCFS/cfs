/**
 * @file   Sx_HarmIndex.h
 * @author 
 * @date   Mon Nov 28 12:44:24 2005
 * 
 * @brief  
 * 
 * 
 */

#ifndef __SX_ITFANSYSMODAL_H__
#define __SX_ITFANSYSMODAL_H__ 1

#include "Sx_AnsysFast.h"
#include "C_HarmIndex.h"

/*********************************************************************************
 *! \class	C_ItfAnsysModal
 *  \brief	Class Ansys for VT Modal Analysis
 *  \author	Frederic Thevenon
 *  \date	2006
 *  \bug
 *  \warning
 *
 *  \version 1. :       Initial Revision ( Ansys 11.0)
 */

class C_ItfAnsysModal
  : public C_ItfHarmIndex<double>, public C_ItfAnsys<double>
{
public :

  virtual int	GetDebugScope(void) { return E_SCOPE_ITFPARAMFAST;}  
  virtual const char *Version() const		{ return "0.1";}
  
  C_ItfAnsysModal( const string &nom = "", PAR *par = NULL);
  virtual ~C_ItfAnsysModal();
  
  virtual bool		IndexIsActive( int Hi);
  virtual double	HiToAngle( int NumHI);

  virtual int	InitSolver( int NbModesMax, C_VecPi<double> &Eval,
			    C_VSTRUCT<double> &Evec, double &FreqMin, 
			    double &FreqMax, bool KeepMat=false);  

  virtual int	InitParam( int &Korder, int &Morder);

  virtual int MltMatVect( char IdMat, int order, C_VSTRUCT<double> &Q,
			  C_VSTRUCT<double> &AQ);
  
  virtual int MltMatVect( int HrmIndex, C_VSTRUCT<double> &Q,
			  C_VSTRUCT<double> &KQ, C_VSTRUCT<double> &MQ,
			  int UpdateLevel=1);

  virtual int GetProjOperators( double angle, C_VSTRUCT<double> &Q,
				C_VSTRUCT<double> &AQ,
				C_MatMSym<double> &QtKQ, C_MatMSym<double> &QtMQ);

  virtual int	GetUpdatedResults( int HrmIndex, int NbModes, double &FreqMin,
				   double &FreqMax, C_VecPi<double> &Eval,
				   C_VSTRUCT<double> &Evec, bool KeepMat=false);

  virtual int	SetUpdatedResults( int HrmIndex, int NbModes, 
				   C_VecPi<double> &Eval,
				   C_VSTRUCT<double> &Evec);

  virtual void updateCE(int HrmIndex, int step);

  bool _updateCE;
  virtual void SetUpdateCE (bool updatece) {_updateCE = updatece;}
  virtual bool GetUpdateCE () {return _updateCE;}

protected :
  
  T_m_ooc	*CreateMatrixFromFull( int idmat, char *matname);
  void		SetHrmIdx( int Hi);
  void		SetLdStep( int i);
  void		IncLdStep( bool inv = false);

  // ===== Members

  C_CadoeMessage	_MsgDebug1;

  map< double, T_mso *>	_Kupd;
  map< double, T_mso *>	_Mupd;

  C_VSTRUCT<double>	_Qnod;

  int		_NbModes;
  int		_HiInit;
  double	_AngleInit, _IncAngle;
  int		_NbPointsHi;  
  int		_InCore;
  bool		_FirstRes;
  int		_NumFirstRes;
  int		_sstif, _strout;

  T_m_ooc	*_HI_K0;
  T_m_ooc	*_HI_M0;
  T_m_ooc	*_HI_coef_K;
  T_m_ooc	*_HI_coef_M;
  T_m_ooc	*_HI_K0ct;
  T_m_ooc	*_HI_M0ct;

  VEC		*_Variation;
  
  C_VecPi<int>		_iSolverKeys;	///! Sparse Solver Int keys
  C_VecPi<double>	_dpSolverKeys;	///! Sparse Solver Dp keys
};

#endif /* __SX_ITFANSYSMODAL_H__ */

