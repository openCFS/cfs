/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 2009 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  fem_swAngleSort.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  fem_swAngleSort.h
 *  header file for fem_swAngleSort.c
 *
 */
#ifndef FEM_SWANGLESORT_INCLUDE
#define FEM_SWANGLESORT_INCLUDE

/*----------------- Globally accessible data types --------------------------*/

/*----------------- Globally accessible variables ---------------------------*/

/*----------------- Globally accessible macros ------------------------------*/

typedef struct {
   INT kp_id;
   INT iareakp;
   DOUBLE angle;
} ANGLESORT_TYPE;

#ifdef __cplusplus
extern "C" {
#endif

                               /* ========================================== */
                               /* === FEM_swSortAngle: Sort a list of angles */
                               /* === into increasing angle size.            */
                               /* === Return: void                           */
                               /* ========================================== */
void FEM_swAngleSort(
   ANGLESORT_TYPE *a_angles,   /* === (IN/OUT) the angles to sort.           */
   INT num_angles );           /* === (IN)     length of a_angles.           */

#ifdef __cplusplus
}
#endif

#endif

