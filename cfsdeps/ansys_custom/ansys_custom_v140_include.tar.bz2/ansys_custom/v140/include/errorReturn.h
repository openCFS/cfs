/* 
 * ***  copyright(c) 2011 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */
  
  /**********************************************
    Use setjmp to remember the entry to this subroutine.
    If there are any abnormal termination and an error
    code has to be returned to the calling program,
    a longjmp is called with the appropriate error
    level. It is the responsibility of the calling
    program to decode the severity level of the error
    code. The code is kept in a global pcglssStatus.
    The message is in a global pcglssMessage.
   **********************************************/
  INT lockval = LOCKPCGERR;

  cwPplock(&lockval);
  pcglssStatus = setjmp(pcglssEnv);
  cwPpunlock(&lockval);

  if (pcglssStatus != 0) {      /* Reached here through longjmp           */
    cwPplock(&lockval);

    /* Call anserror to print the error                                   */
    cwLngerr(pcglssStatus,pcglssMessage);

    removeSemiPermFiles();      /* Cleanup to remove all intermediate     */
    removeTempFiles();          /* Cleanup to remove all temporary files  */

    /* specifically delete these data structures so tag number gets reset */
    deleteSetStructures();
    deleteFelFreeStructures();
    deleteCelFreeStructures();

    deletePcgTags();            /* Deallocate all PCG solver tag memory   */

    /* we cannot delete the non-tag memory because other non-PCG code may be */
    /* using this part of the PCG memory manager.  slvend.F will cleanup the */
    /* PCG memory manager and ender.F will cleanup the ANSYS memory manager  */

    /* flushCasiMallocFree();*/ /* Deallocate all non-tag memory          */

    cwPpunlock(&lockval);

    return(pcglssStatus);       /* Return to the calling environment      */
  }

