
/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 2009 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_smooth.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_smooth.h
 *  header file for FEM_smooth.c
 *
 */
#ifndef FEM_SMOOTHUTIL_INCLUDE
#define FEM_SMOOTHUTIL_INCLUDE

/*----------------- Globally accessible function prototypes -----------------*/


                              /* === FEM_smShapeMetric: compute shell        */
                              /* === element metric (for quads and tris).    */
DOUBLE FEM_smShapeMetric (
   FACE_OBJ obj_face,
   VECTOR3D *surf_norm  );



#endif
