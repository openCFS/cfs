/*****************************************************************************
 *                   Copyright (C) 1999 CMSoft                               *
 *                                                                           *
 *  These lines of code and declarations contain unpublished proprietary     *
 *  information of CMSoft. They may not be copied or duplicated in whole     *
 *  or part without prior authorization from CMSoft.                         *
 *                                                                           *
 *****************************************************************************/
#ifndef _FS_COMMUNICATOR_H_
#define _FS_COMMUNICATOR_H_

#include <fstream>
#include "C_Communicator.h"

struct
FSRecInfo{
  int cpu, len;
};

#if defined(LOWERCASENOUNDER_SYS)
#define SendCheckPoint	sendcheckpoint
#define RecvCheckPoint	recvcheckpoint
#define MpiInqr		mpiinqr
#endif

#if defined(UPPERCASENOUNDER_SYS)
#define SendCheckPoint	SENDCHECKPOINT
#define RecvCheckPoint	RECVCHECKPOINT
#define MpiInqr		MPIINQR
#endif

#if defined(LOWERCASEUNDER_SYS)
#define SendCheckPoint	sendcheckpoint_
#define RecvCheckPoint	recvcheckpoint_
#define MpiInqr		mpiinqr_
#endif

extern "C" void SendCheckPoint(int *);
extern "C" void RecvCheckPoint(int *);
extern "C" int MpiInqr(int &);
extern void checkPoint(int );

#define DIST_PROC		1
#define DIST_DEBUG		2
#define DIST_DISABLECOMMD	3
#define DIST_DISABLESOLU	4
#define DIST_INPUTUNIT		5    
#define DIST_MAXNUMCPU		6
#define DIST_CPUAPPTOJOB	7  
#define DIST_DISTCOMMAND	8
#define DIST_ELDBWSAVE		9

class DofSet;

class FSCommunicator : public C_Communicator
{
public:
  FSCommunicator();
  ~FSCommunicator();
  
  void glbSum(int nVal, double *val);
  void glbSum(int nVal, int *val);
  void glbSum(int nVal, complex16_t *val);
  void glbSum(int nVal, LONGINTC *val);
  
  void glbOr(int num, int *x);
  void glbOr(int num, bool *x);
  
  void glbMax(int nVal, double *val);
  void glbMax(int nVal, int *val);
  void glbMax(int nVal, LONGINTC *val);
  
  void glbMin(int nVal, double *val);
  void glbMin(int nVal, int *val);
  void glbMin(int nVal, LONGINTC *val);
  
  void exchange(int tag, int numNeighb, int *cpus,
		int *sndPtr, int *sndData, int *rcvPtr, int *rcvData);
  void exchange(int tag, int numNeighb, int *cpus,
		int *sndLen, int **sndData, int *crvLen, int **rcvData); 
  void exchange(int tag, int numNeighb, int *cpus,
		int *sndLen, double **sndData, int *crvLen, double **rcvData); 
  
  void Bcast(bool *buffer, int len, int root);
  void Bcast(int *buffer, int len, int root);
  void Bcast(Hyper *buffer, int len, int root);
  void Bcast(double *buffer, int len, int root);
  void Bcast(complex16_t *buffer, int len, int root);
  
  void send(int cpu, int tag, int *buffer, int len);
  void send(int cpu, int tag, LONGINTC *buffer, int len);
  void send(int cpu, int tag, Real *buffer, int len);
  void send(int cpu, int tag, double *buffer, int len);
  void send(int cpu, int tag, complex8_t *buffer, int len);
  void send(int cpu, int tag, complex16_t *buffer, int len);
  
  void recv(int cpu, int tag, int *buffer, int len);
  void recv(int cpu, int tag, LONGINTC *buffer, int len);
  void recv(int cpu, int tag, Real *buffer, int len);
  void recv(int cpu, int tag, double *buffer, int len);
  void recv(int cpu, int tag, complex8_t *buffer, int len);
  void recv(int cpu, int tag, complex16_t *buffer, int len);
  
  void check(int tag);
  void barrier(int world);
  
  void abort(int world, int errorcode = 99);
};

class FSConnectivity;

class FSSubDTopo {
    struct CPair { int from, to, cpuID;
          CPair() {} 
          CPair(int f, int t, int c)
             { from =f; to = t; cpuID =c; } 
          // the following operator is required by the STL sort algorithm
          bool operator < (const CPair &x) const
             { 
                 // we want to order first by cpuID (with local coms first)
                 // then by origin and then by destination
                 return cpuID < x.cpuID || (cpuID  == x.cpuID && 
                  (from < x.from || (from == x.from && to < x.to))); }
          bool operator == (const CPair &x) const
             { return cpuID == x.cpuID && from == x.from && to == x.to; }
    };


    int _numCPU;// number of CPUs
    int _cpuNum;// this CPU's number
    int localNumSub;
    int *glSubToLocal;
    int *localSubToGl;
    int *subNumNeighb;
    int *glSubToCPU;

    int *neighbCPU;
    FSConnectivity *cpuSC;
    FSConnectivity *cpuRC;
    int numPairs;
    CPair *allPairs;

    void makeLocalPairIndex(FSConnectivity *subToSub);
    void makeCrossConnect(); // builds neighbCPU cpuSC and cpuRC
  public:
    // The constructor only needs the connectivity of the subdomains of 
    // this CPU to be correct, the connectivity of other subdomains can be
    // (and is in slave domain) ommited.
    FSSubDTopo (int CPU, FSConnectivity *subToSub, FSConnectivity *CPUToSub);
    int getChannelID(int glFrom, int glTo);
    int numChannels() { return numPairs; }
    int numNeighbCPUs();
    int crossNeighb(int iCpu) { return neighbCPU[iCpu]; }
    int *crossNeighb() { return neighbCPU; }
    FSConnectivity *cpuSndChannels() { return cpuSC; }
    FSConnectivity *cpuRcvChannels() { return cpuRC; }
    int reverseChannel(int);
    int sourceIsLocal(int channel) 
       { return glSubToCPU[allPairs[channel].from] == _cpuNum; }
    bool isSubLocal(int sub) { return glSubToCPU[sub] == _cpuNum; }
    int locSubNum(int sub) { return glSubToLocal[sub]; }
};

template <class T>
struct FSSubRecInfo {
    T *data;
    int len;
    int leadDim;
    int nvec;
};

/*****************************************************************************
   FSCommPattern represent a communication pattern. 
     Communication is based on the model that a message from one
     subdomain to another subdomain is made of a number of vectors.
     Such vectors are stored in a matrix form. That matrix may have
     larger columns than the actual message length. This allows a subdomain
     to send different subparts of a given matrix to different subdomains.

   A communication patterns contains the following information:
     - Length of a vector from one subdomain to its neighbors
     - Number of vectors in each message
     - Leading dimension of the matrix containing the vectors
 *****************************************************************************/
template <class T>
class FSCommPattern {
  public:
     enum Mode { Share, CopyOnSend };
     enum Symmetry { Sym, NonSym };
     // Buffers for local copy-communication
  protected:
     Mode mode;
     Symmetry sym;
     T *localDBuffer;

     // for non-local communication we need a few more info
     int _numCPUs;
     int numNeighbCPUs;
     int *neighbCPUs;
     FSConnectivity *sndConnect;
     FSConnectivity *rcvConnect;
     // in cpuForChannel, we use the convention that this CPU is marked as -1
     int *cpuForChannel;
     int *isSend;  // wether this channel is a send or receive channel
     int *reverseChannel; // corresponding reverse channel
     // Buffers for cross-memory communication on a cpu per cpu basis
     int *crossSendLen, *crossRcvLen;
     T **crossSendBuffer;
     T **crossRcvBuffer;

     int numChannels;
     FSSubRecInfo<T> *sRecInfo;

  public:
    
     FSCommPattern(FSSubDTopo *, Mode = Share, Symmetry = Sym);

#ifdef MEM_TMPL_FUNC
     template <class TB>
       FSCommPattern(FSCommPattern<TB> &, Mode = Share, Symmetry = Sym);
#endif

     void setLen(int ID, int size, int lDim=-1, int nv = 1);
     void finalize(); // complete the internal setup
     FSSubRecInfo<T> recData(int channel);
     void sendData(int channel, T *);
     FSSubRecInfo<T> getSendBuffer(int channel);
     void exchange();
     int numCh(){ return numChannels; }
};

template <class T>
FSCommPattern<T>::FSCommPattern(FSSubDTopo *topo, Mode _mode, Symmetry _sym)
{
  C_Communicator *comm = C_Communicator::Instance();
  int i, j;
  mode = _mode;
  sym = _sym;
  numChannels = topo->numChannels();
  _numCPUs = comm->size();
  sRecInfo = new FSSubRecInfo<T>[numChannels];
  isSend = new int[numChannels];
  reverseChannel = new int[numChannels];
  cpuForChannel = new int[numChannels]; // -1 if local, cpu number otherwise
  for(i = 0; i < numChannels; ++i) {
    sRecInfo[i].len = 1;
    sRecInfo[i].leadDim = 1;
    sRecInfo[i].nvec = 1;
    reverseChannel[i] = topo->reverseChannel(i);
    isSend[i] = topo->sourceIsLocal(i);
    cpuForChannel[i] = -1;
  }
  if(_numCPUs > 1) {
    sndConnect = topo->cpuSndChannels();
    rcvConnect = topo->cpuRcvChannels();
    numNeighbCPUs = sndConnect->size();
    neighbCPUs = topo->crossNeighb();
    for(i = 0; i < numNeighbCPUs; ++i) {
      for(j = 0; j < sndConnect->num(i); ++j)
	cpuForChannel[(*sndConnect)[i][j] ] = neighbCPUs[i];
      for(j = 0; j < rcvConnect->num(i); ++j)
	cpuForChannel[(*rcvConnect)[i][j] ] = neighbCPUs[i];
    }
  }
}

template <class T>
void
FSCommPattern<T>::setLen(int channel, int len, int ldim, int nvec)
{
 if(ldim < 0) ldim = len;
 sRecInfo[channel].len  = len;
 sRecInfo[channel].leadDim = ldim;
 sRecInfo[channel].nvec = nvec;
}

template <class T>
void
FSCommPattern<T>::finalize()
{
 // If the number of cpus is > 1 then we need to get the length of messages
 // for the other CPUs.
 if(_numCPUs > 1) {
   if(sym == Sym) {
      int i;
      for(i = 0; i < numChannels; ++i) {
        if(cpuForChannel[i] >= 0 && isSend[i]) {
          sRecInfo[reverseChannel[i]].len  = sRecInfo[i].len;
          sRecInfo[reverseChannel[i]].leadDim = sRecInfo[i].leadDim;
          sRecInfo[reverseChannel[i]].nvec = sRecInfo[i].nvec;
        }
      } 
   } else {
      // send and receive the message length and number of vectors (leadDim is
      // implicitely set to the message length)
      int nSndCh = sndConnect->numConnect();
      int nRcvCh = rcvConnect->numConnect();
      //fprintf(stderr, "Number of neighb: %d with %d and %d\n", numNeighbCPUs,nSndCh,nRcvCh);
      int *sndMsg = new int[2*nSndCh];
      int *rcvMsg = new int[2*nRcvCh];
      int **sndPtr = new int*[numNeighbCPUs];
      int **rcvPtr = new int*[numNeighbCPUs];
      int *sndLen = new int[numNeighbCPUs];
      int *rcvLen = new int[numNeighbCPUs];
      int offset = 0;
      int iCPU, i;
      int totLen = 0;
      for(iCPU = 0; iCPU < numNeighbCPUs; ++iCPU) {
        sndPtr[iCPU] = sndMsg + offset;
        rcvPtr[iCPU] = rcvMsg + offset;
        sndLen[iCPU] = 2* sndConnect->num(iCPU);
        rcvLen[iCPU] = 2* sndConnect->num(iCPU);
        for(i = 0; i < sndConnect->num(iCPU); ++i) {
          sndPtr[iCPU][2*i]   = sRecInfo[ (*sndConnect)[iCPU][i] ].len;
          sndPtr[iCPU][2*i+1] = sRecInfo[ (*sndConnect)[iCPU][i] ].nvec;
          totLen += sndMsg[offset]*sndMsg[offset+1];
          offset += 2;
        }
      }
      // Do the actual exchange MLX
      //fprintf(stderr, "Tot len is %d  for %d\n", totLen, communicator->cpuNum());
      C_Communicator *comm = C_Communicator::Instance();
      comm->exchange(101, numNeighbCPUs, neighbCPUs, sndLen, sndPtr,
		     rcvLen, rcvPtr);
      offset = 0;
      totLen = 0;
      for(iCPU = 0; iCPU < numNeighbCPUs; ++iCPU)
        for(i = 0; i < sndConnect->num(iCPU); ++i) {
          sRecInfo[ (*rcvConnect)[iCPU][i] ].len = rcvMsg[offset];
          sRecInfo[ (*rcvConnect)[iCPU][i] ].leadDim = rcvMsg[offset];
          sRecInfo[ (*rcvConnect)[iCPU][i] ].nvec = rcvMsg[offset+1];
          totLen += rcvMsg[offset]*rcvMsg[offset+1];
          offset += 2;
        }    
     //fprintf(stderr, "Tot=len is %d  for %d\n", totLen, communicator->cpuNum());
   }
 }
 // in the case of single CPU communication, Share mode does not require any
 // work, independently of whether we are symmetric or not
 if(mode == Share && _numCPUs == 1) return;

 if(_numCPUs != 1 && numNeighbCPUs > 0){ 
    // When there are several other CPUs, we need to allocadte
    // the cross CPU memory buffers
    int i, j, totLen=0;
    crossSendBuffer = new T *[numNeighbCPUs];
    crossRcvBuffer  = new T *[numNeighbCPUs];
    crossSendLen = new int[numNeighbCPUs];
    crossRcvLen  = new int[numNeighbCPUs];
    for(i = 0; i < numNeighbCPUs; ++i)
      crossSendLen[i] = crossRcvLen[i] = 0;
    for(i = 0; i < numNeighbCPUs; ++i) {
      for(j = 0; j < sndConnect->num(i); ++j) {
    	int channel = (*sndConnect)[i][j];
    	int msgLen = sRecInfo[channel].len*sRecInfo[channel].nvec;
    	crossSendLen[i] += msgLen;
    	totLen += msgLen;
       }
       for(j = 0; j < rcvConnect->num(i); ++j) {
    	int channel = (*rcvConnect)[i][j];
    	int msgLen = sRecInfo[channel].len*sRecInfo[channel].nvec;
    	crossRcvLen[i] += msgLen;
    	totLen += msgLen;
       }
    }
    T *crBuff = new T[totLen];
    for(i = 0; i < numNeighbCPUs; ++i) {
       crossSendBuffer[i] = crBuff;
       for(j = 0; j < sndConnect->num(i); ++j) {
    	 int channel = (*sndConnect)[i][j];
    	 int msgLen = sRecInfo[channel].len*sRecInfo[channel].nvec;
         sRecInfo[channel].data = crBuff;
         crBuff += msgLen;
       }
       crossRcvBuffer[i] = crBuff;
       for(j = 0; j < rcvConnect->num(i); ++j) {
    	 int channel = (*rcvConnect)[i][j];
    	 int msgLen = sRecInfo[channel].len*sRecInfo[channel].nvec;
         sRecInfo[channel].data = crBuff;
         crBuff += msgLen;
       }
    }
 }
 if(mode == Share) return;
 // In Copy On Send mode, we need to allocadte a T array of appropriate length
 // Compute the length:
 int i, len=0;
 for(i = 0; i < numChannels; ++i)
   if(_numCPUs == 1 || cpuForChannel[i] < 0)
        len += sRecInfo[i].len*sRecInfo[i].nvec;
 localDBuffer = new T[len];

 // Now update the pointers.
 T *cBuf = localDBuffer;
 for(i = 0; i < numChannels; ++i)
   if(_numCPUs == 1 || cpuForChannel[i] < 0)
     {
      sRecInfo[i].data = cBuf;
      cBuf += sRecInfo[i].len*sRecInfo[i].nvec;
     }
}

template <class T>
void
FSCommPattern<T>::exchange()
{
 if(_numCPUs == 1) return;
// Do the actual exchange MLX  
 C_Communicator *comm = C_Communicator::Instance();
 comm->exchange(101, numNeighbCPUs, neighbCPUs, crossSendLen, 
		crossSendBuffer, crossRcvLen, crossRcvBuffer);
}

template <class T>
FSSubRecInfo<T>
FSCommPattern<T>::recData(int channel)
{
 if(mode == Share) return sRecInfo[channel];
 FSSubRecInfo<T> ret = sRecInfo[channel];
 // in Copy On Send mode, for sending we have packed the vectors and therefore
 // the leading dimension of received data is the length of a vector
 ret.leadDim = ret.len;
 return ret;
}

template <class T>
void
FSCommPattern<T>::sendData(int channel, T *data)
{
 if(mode == Share && (_numCPUs == 1 || cpuForChannel[channel] < 0)) {
   sRecInfo[channel].data = data;
   return;
 }
 // For Copy On Send, or non local communication,
 // copy the data into the right buffer
 int i, iVec;
 FSSubRecInfo<T> chObj = sRecInfo[channel];

 for(iVec = 0; iVec < chObj.nvec; ++iVec)
   for(i = 0; i < chObj.len; ++ i)
      chObj.data[iVec*chObj.len + i] = data[iVec*chObj.leadDim + i];
}

template <class T>
FSSubRecInfo<T>
FSCommPattern<T>::getSendBuffer(int channel)
{
 FSSubRecInfo<T> chObj = sRecInfo[channel];
 if(mode == Share) // Check if we have a send buffer. If not, return NULL
   chObj.data = NULL;
 return chObj;
}

#ifdef MEM_TMPL_FUNC

template <class T>
template <class TB>
FSCommPattern<T>::FSCommPattern(FSCommPattern<TB> &pb, 
                                Mode _mode, Symmetry _sym)
{
 mode = _mode;
 sym = _sym;
 numChannels = pb.numCh();
 sRecInfo = new FSSubRecInfo<T>[numChannels];
 for(int i = 0; i < numChannels; ++i) {
    FSSubRecInfo<TB> rInfo = pb.getSendBuffer(i);
    sRecInfo[i].len = rInfo.len;
    sRecInfo[i].leadDim = rInfo.leadDim;
    sRecInfo[i].nvec = rInfo.nvec;
 }
 finalize();
}

#endif

#endif
