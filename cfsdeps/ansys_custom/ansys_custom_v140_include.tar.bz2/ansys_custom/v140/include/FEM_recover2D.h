/*  FEM_recover2D.h */
/*
 * *** ansys(r) copyright(c) 2009
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_recover2D.h
 *  header file for FEM_recover2D.c
 *
 */
#ifndef FEM_RECOVER2D_INCLUDE
#define FEM_RECOVER2D_INCLUDE

#define CANT_RECOVER_EDGE -999
#ifdef __cplusplus
extern "C" {
#endif

/*----------------- Globally accessible function prototypes -----------------*/

                             /* === FEM_recover2D: Recover an edge from a    */
                             /* === set of triangle faces                    */
INT FEM_recover2D (
   NODE_OBJ obj_node0,                 /* node on edge                       */
   NODE_OBJ obj_node1,                 /* other node on edge                 */
   INT debug,                          /* debug flag                         */
   INT anum,                           /* The area number                    */
   INT flat,                           /* flag - is area flat                */
   VECTOR3D *ps_norm,                  /* normal of flat surface             */
   EDGE_OBJ *pobj_edge  );             /* return recovered edge              */

#ifdef __cplusplus
}
#endif

#endif
