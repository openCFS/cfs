/* ANSI_C af.h - ANSYS Geometry Interface: input/output */

/*--------------------------------------------------------------------------*/
/* ansys(r) copyright(c) 2009 */
/* ansys, inc.                */
/*--------------------------------------------------------------------------*/

/* NOTE: This file requires "#include "ax.h" */

/*--------------------------------------------------------------------------*/

#ifndef __AF_H__  /* Include this file only once! */
#define __AF_H__ 

#ifdef __cplusplus
extern "C" {
#endif

/*--------------------------------------------------------------------------*/

/* Saving and printing (af.c) */

void af_save (const char *path);
void af_save_entity (ax_ENTITY entity, void *generic, void *app_data);

/*--------------------------------------------------------------------------*/

/* ...and loading (af_load.c) */

#define ax_load         af_load
#define ax_load_entity  af_load_entity

#define ax_read_entity(F,E) af_load_entity (E, ax_entity_node (E), F)

void af_load (const char *path);
void af_load_entity (ax_ENTITY entity, void *generic, void *app_data);
void af_load_note_msg_hook (void * (* user_hook) (char msg[]));

/*--------------------------------------------------------------------------*/

#if defined(__cplusplus)
}
#endif

#endif  /* #ifdef __AF_H__ */
