#ifndef FEM_MODEL________H
#define FEM_MODEL________H

#include "FEM_cdbtypes.h"
#include "FEM_Public.h"
#include <math.h>


class KP_TYP;
class LINE_TYP;
class AREA_TYP;
class VOL_TYP;
typedef class KP_TYP   *KP_PTYP;
typedef class LINE_TYP *LINE_PTYP;
typedef class AREA_TYP *AREA_PTYP;
typedef class VOL_TYP  *VOL_PTYP;

#include "FEM_hashtable.h"
#include "FEM_Lists.h"

class KP_TYP;
class LINE_TYP;
class AREA_TYP;
class VOL_TYP;
class MODEL_TYP;
typedef class KP_TYP   *KP_PTYP;
typedef class LINE_TYP *LINE_PTYP;
typedef class AREA_TYP *AREA_PTYP;
typedef class VOL_TYP  *VOL_PTYP;
typedef class MODEL_TYP *MODEL_PTYP;

#include "FEM_kpPublic.h"
#include "FEM_lnPublic.h"
#include "FEM_aePublic.h"
#include "FEM_vlPublic.h"
#include "FEM_meshvols.h"

class MODEL_TYP {

   private:
      static INT count;
      INT *ma_lines;
      INT *ma_dir;
      INT *ma_areas;

      LIST_TYP<KP_TYP>   mp_kplist;
      LIST_TYP<LINE_TYP> mp_lnlist;
      LIST_TYP<AREA_TYP> mp_aelist;
      LIST_TYP<VOL_TYP>  mp_vllist;

      KP_PTYP CreateKp( INT kp_id );
      LINE_PTYP CreateLine( INT line_id );
      AREA_PTYP CreateArea( INT area_id );
      VOL_PTYP CreateVolume( INT vol_id );

      HASHTABLE<KP_PTYP>   m_kphashtable; 
      HASHTABLE<LINE_PTYP> m_linehashtable; 
      HASHTABLE<AREA_PTYP> m_areahashtable; 
      HASHTABLE<VOL_PTYP>  m_volhashtable; 
      DOUBLE m_sizescale;

   public:
      MODEL_TYP() { Init(); };
      ~MODEL_TYP()
      {
         FEM_Free_C( ma_areas );
         FEM_Free_C( ma_dir );
         FEM_Free_C( ma_lines );
      };
      void Init( void )
      {
         ma_areas = NULL;
         ma_lines = NULL;
         ma_dir = NULL;
         mp_kplist.Init();
         mp_lnlist.Init();
         mp_aelist.Init();
         mp_vllist.Init();
         m_kphashtable.Init();
         m_linehashtable.Init();
         m_areahashtable.Init();
         m_volhashtable.Init();
         m_sizescale = -1.0;
      };
      void Delete()
      {
         mp_kplist.Delete();
         mp_lnlist.Delete();
         mp_aelist.Delete();
         mp_vllist.Delete();
         m_kphashtable.Delete();
         m_linehashtable.Delete();
         m_areahashtable.Delete();
         m_volhashtable.Delete();
         FEM_Free_C( ma_areas );
         FEM_Free_C( ma_dir );
         FEM_Free_C( ma_lines );
      };

      INT Create( INT *a_vols, INT num_vols, INT stat_process );
      INT CreateShell( INT *a_areas, INT num_areas, INT stat_process );
      INT DeleteVolume( VOL_PTYP obj_vol );
      INT DeleteVolumeAndBelow( VOL_PTYP obj_vol );
      INT DeleteAreaAndBelow( AREA_PTYP obj_area );
      INT DeleteLineAndBelow( LINE_PTYP obj_line );
      INT DeleteKp( KP_PTYP obj_kp );

      INT NumKps()   const { return mp_kplist.Length(); };
      INT NumLines() const { return mp_lnlist.Length(); };
      INT NumAreas() const { return mp_aelist.Length(); };
      INT NumVols()  const { return mp_vllist.Length(); };

      INT KpList( INT **a_kps, INT &num_kps ) const;
      INT LineList( INT **a_lines, INT &num_lines ) const;
      INT AreaList( INT **a_areas, INT &num_areas ) const;

      KP_PTYP KpList( ) const { return mp_kplist.GetList(); };
      LINE_PTYP LineList( ) const { return mp_lnlist.GetList(); };
      AREA_PTYP AreaList( ) const { return mp_aelist.GetList(); };
      VOL_PTYP VolList( ) const { return mp_vllist.GetList(); };

      KP_PTYP FindKp( const INT id, FEM_BOOLEAN & exists ) const
      {
         return m_kphashtable.Find( id, exists );
      };

      LINE_PTYP FindLine( const INT id, FEM_BOOLEAN & exists ) const
      {
         return m_linehashtable.Find( id, exists );
      };

      AREA_PTYP FindArea( const INT id, FEM_BOOLEAN & exists ) const
      {
         return m_areahashtable.Find( id, exists );
      };

      VOL_PTYP FindVol( const INT id, FEM_BOOLEAN & exists ) const
      {
         return m_volhashtable.Find( id, exists );
      };

      DOUBLE SizeScale( void ) const;
};


typedef class MODEL_TYP  *MODEL_PTYP;

void FEM_SetModel( MODEL_PTYP p_model );
void FEM_vl( VOL_PTYP obj_vol );
void FEM_ae( AREA_PTYP obj_area );
void FEM_ln( LINE_PTYP obj_line );
void FEM_kp( KP_PTYP obj_kp );
void FEM_vlN( INT vol_num );
void FEM_aeN( INT area_num );
void FEM_lnN( INT line_num );
void FEM_kpN( INT kp_num );

#endif
