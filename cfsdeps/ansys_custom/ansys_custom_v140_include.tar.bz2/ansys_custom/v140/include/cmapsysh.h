/********************************************/
/***  include file used for CMAP routines ***/
/********************************************/
/* 
 * ***copyright(c) 2011 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */
#if defined(PCWINNT_SYS)
    /*  c routines called from fortran  */
#define cmapstop_   CMAPSTOP

    /*  fortran routines called from c  */
#define cmap_       CMAP
#endif
