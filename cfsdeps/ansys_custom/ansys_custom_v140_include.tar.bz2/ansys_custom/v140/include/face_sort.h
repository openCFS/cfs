/*CFILE face_sort.h                                              
------------------------------------------------------------------------
------- Notice - This file contains ANSYS Confidential information 
------------------------------------------------------------------------
*/
/* 
 * *** copyright(c) 2011 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */

/*------------------------------ Description ---------------------------
\Author:        sjo
\Title:         face_sort.h
\Desc:          header file for face_sort.c
\History:       95/12/20 - sjo: initial creation
                96/01    - ycl: modified

----------------------------------------------------------------------*/

typedef struct ENTITY_TYP *ENTITY_PTYP; 

typedef struct ENTITY_TYP{
   INT reference;
   ENTITY_PTYP ps_next;
} ENTITY_TYP;

/* typedef struct ENTITY_TYP *ENTITY_PTYP; */

/*
 *  Prototypes and various protocall for calling the functions in  
 *  face_sort.c from FORTRAN
 */


/* (1)-------------------------------------------------------------*/
#if defined(RS6000_SYS) || defined(HP32_SYS)

/* === C functions called from FORTRAN */

#define face_init_   face_init
#define face_free_   face_free
#define face_insert_ face_insert
#define face_delete_ face_delete
#define face_total_  face_total
#define face_get_    face_get
#define face_del_all_  face_del_all

#endif

/* (2)-------------------------------------------------------------*/

#if defined(WATCOMC_SYS) \
    || defined(PCWINNT_SYS)
/* === C functions called from FORTRAN */

#define face_init_   FACE_INIT
#define face_free_   FACE_FREE
#define face_insert_ FACE_INSERT
#define face_delete_ FACE_DELETE
#define face_total_  FACE_TOTAL
#define face_get_    FACE_GET
#define face_del_all_ FACE_DEL_ALL

#endif

/* (3)-------------------------------------------------------------*/
#if defined(WATCOMC_SYS)

/* === C functions called from FORTRAN */
#pragma aux FACE_INIT "^";
#pragma aux FACE_FREE "^";
#pragma aux FACE_INSERT "^";
#pragma aux FACE_DELETE "^";
#pragma aux FACE_TOTAL "^";
#pragma aux FACE_GET "^";
#pragma aux FACE_DEL_ALL "^";


#endif

/* (4)-------------------------------------------------------------*/
/*
 * *** FUNCTION RETURN TYPE DECLARATION
 */

#if !defined(PCWINNT_SYS)

/* === C functions called from FORTRAN */
   INT face_init_(INT *_face_size, INT *_max_item_to_store, 
		  ENTITY_PTYP *fg_face, ENTITY_PTYP *fg_stack, 
		  ENTITY_PTYP *fg_stack_mem, INT *fg_stack_ptr, 
		  INT *fg_stack_length, INT *fg_face_size);
   void face_free_(ENTITY_PTYP *fg_stack_mem, INT *fg_stack_ptr, 
		   INT *fg_stack_length, INT *fg_face_size);
   INT face_insert_(INT *_face_id, INT *_reference, ENTITY_PTYP *fg_face, 
		    ENTITY_PTYP *fg_stack, INT *fg_stack_ptr, 
		    INT *fg_face_size);
   INT face_delete_(INT *_face_id, INT *_reference, ENTITY_PTYP *fg_face, 
		    ENTITY_PTYP *fg_stack, INT *fg_stack_ptr, 
		    INT *fg_face_size);
   INT face_total_(INT *_face_id, ENTITY_PTYP *fg_face, INT *fg_face_size);
   INT face_get_(INT *_face_id, INT *a_reference, INT *total, 
		 ENTITY_PTYP *fg_face, INT *fg_face_size);
   INT face_del_all_(INT *_face_id, ENTITY_PTYP *fg_face, 
		     ENTITY_PTYP *fg_stack, INT *fg_stack_ptr, 
		     INT *fg_face_size);


/* (5)-------------------------------------------------------------*/
#else

/* === C functions called from FORTRAN */
   INT CALLTYP face_init_( INT *,INT *, INT *, INT *, INT *, INT *, INT *, 
			  INT * );
   void CALLTYP face_free_(INT *,INT *, INT *, INT *);
   INT CALLTYP face_insert_( INT *, INT *, INT *,INT *, INT *, INT *);
   INT CALLTYP face_delete_( INT *, INT *, INT *,INT *, INT *, INT *);
   INT CALLTYP face_total_( INT *, INT *,INT *);
   INT CALLTYP face_get_( INT *, INT *, INT *, INT *, INT *);
   INT CALLTYP face_del_all_( INT *, INT *,INT *, INT *, INT *);
 
#endif
