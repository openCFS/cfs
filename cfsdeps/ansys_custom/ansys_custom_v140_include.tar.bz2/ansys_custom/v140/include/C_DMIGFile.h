/**
 * @file   C_DMIGFile.h
 * @author  <ftheveno@LYOFTHEVENO8>
 * @date   Fri Sep 04 18:39:18 2009
 * 
 * @brief  Nastran DMIG File Interface Object
 * 
 * 
 */

#ifndef __C_DMIGFILE_H__
#define __C_DMIGFILE_H__	1

#include "C_MatMGe.h"
#include "C_DataFile.h"

/*!
 *  \class	C_DMIGFile
 *  \brief	
 *  \author	Frederic Thevenon
 *  \version	1.0
 *  \date	2009
 *
 *		Notes :
 *		- the 1st card is a header card
 *		-  a  * in the 1st field means that next fields are doubled up to 
 *		   be able to enter double precision numbers.
 *  \bug	
 *  \warning	
 *
 *  version 1.0 :       Initial Revision
 */

class C_DMIGFile : public C_DataFile
{
public:

  CADOE_EXPORT C_DMIGFile( const _TCHAR *FileName, bool create = false);
  CADOE_EXPORT virtual ~C_DMIGFile( void);
  
  CADOE_EXPORT void	Init( char Delim = ' ', int FieldLength = 0);

  template <typename T> CADOE_EXPORT C_Mat<T>	*getMat( int numMat, C_Mat<T> *Min = NULL, char Format = 'D');
  template <typename T> CADOE_EXPORT void	setMat( char *MatName, C_Mat<T> &Min);

  CADOE_EXPORT string	&getMatName( void) { return _MatName;}
  CADOE_EXPORT int	getNumNodes( void) { return (int)_NodeDofList.size();}

  CADOE_EXPORT bool	MatSym( void) { return (_IFO == 6);}

  CADOE_EXPORT int	GetDofNumber( int NumNode, int NumComp);
  CADOE_EXPORT void	FillNodDofLists( C_VecPi<int> &NodByRow, C_VecPi<int> &DofByRow, C_VecPi<int> &NodesList);

protected:

  int		FirstLine( void);		///< Method to read the First Line of the File
  int		NextLine( void);		///< Method use to point to the next line to scan in the file

  inline char	*NextToken( bool First = false);

  void		ReadNodesDofsList( void);	/*! Method used to build the list of Nodes/Dofs
						    referenced in the DMIG File */

  bool			_NewFile;		///< true if we generate a new file
  int			_iLine;			///< Number of current line in the DMIG File  
  char			_Delim;			///< Delimitor character
  int			_FieldLength;		///< If the file is formatted (fixed length fields)
  fstream		_file;			///< C++ std File Object
  char			_Line[4096], *_Str;	///< Current Line string
  int			_iChar, _iEnd, _StrLen;	///< Number of current char in the Active Line.
  int			_nField;
  string		_MatName;		///< Name of the Matrix written in the File
  
  // =====		Header Data

  int			_IFO;			///< Form of Matrix Input (1=Square, 9/2=Rectangular 6=Symmetric)
  int			_TIN;			///< Type of Matrix Being Input ( 1=s, 2=d, 3=c, 4=z)
  int			_TOUT;			///< Type of Matrix That Will Be Created (1/2/3/4)
  int			_POLAR;			///< Input Format of Ai,Bi ( 0 = real/imag, >0 = ampl./phase)
  int			_NCOL;			///< Number of Columns in a rectangular format

  // =====		Matrix Data

  map< int, unsigned char>	_NodeDofList;	///< List of Dofs for each Active Node
  map< int, int>		_NodeToRow;	///< Mapping between Row Num && Node Num
  int				_NmRow;		///< Total Number Rows in the Matrix

  C_Mat<int>		*ArrayInfo;
};

template <> C_Mat<int> *C_DMIGFile::getMat<int>( int numMat, C_Mat<int> *Min, char Format);
template <> void	C_DMIGFile::setMat<int>( char *MatName, C_Mat<int> &Min);

#endif
