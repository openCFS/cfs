/******************************************************************/
/*!
\file CLMesh.h
\brief Classe de base pour la gestion des maillages ligths
\version 1.00
*/
/******************************************************************/

#ifndef CLMESHBASE_H
#define CLMESHBASE_H 11


#include "cadoe.h"
#include "CCadoePortable.h"
#include "expmdb_struct.h"
//#include "LIGHT_struct_base.h"
#include "Nodes.h"
#include "Elements.h"

class CLMpertBase;
class Point3D;

extern FILE *openMVWfile ( const string nom );

class CLMeshBase 
{

protected:
	int NB_NOEUD_MAX_PAR_ELT;

	T_statut			ReplaceNumeroByIndex();
	

public:
	CLMeshBase( T_Mesh *mesh );
	CLMeshBase( CLMeshBase * pMeshBase );
	CLMeshBase();
	T_statut InitCLMesh();
	virtual ~CLMeshBase();

	/* save & read */
	bool loadData ( T_cbf *cbf, T_Mesh * );
	int			writeDataBin ( FILE *fic );     // ecriture du CLmesh dans le bloc cbf courant
	int			readDataBin ( FILE *fic );		// lecture du CLmesh 

	void        setMesh ( T_Mesh *mesh ) { _mesh = mesh; _dimension = mesh->dimension; };

	int	Copy(CLMeshBase * pObjectToCopy);

	int			getID()	{return m_id;};
	void		setID(int id) {m_id = id;};

	IntegerAdr	getNbElements()	{ if ( m_pElements != NULL ) return m_pElements->getNbElements(); return 0; };
	IntegerAdr	getNbNodes()	{ if ( m_pNodes != NULL ) return m_pNodes->getNbNodes(); return 0; };

	inline int			GetNumNoeud(int ind);
	

	//les noeuds
	bool		setNbNodes ( IntegerAdr nb_noeud );
	int			addNode ( IntegerAdr numero, double *xyz, IntegerAdr &ind );
	int			addNode ( int numero, double *xyz, double lengthFactor = 1 );
	CNodes		*getNodes() { return m_pNodes; };						// recupere le pointeur des noeuds
	void		setNodes ( CNodes *nodes );		// charge le pointeur des noeuds
	bool		sortNodes ( );

	//les elementss
	bool		setNbElements ( int nb_element, E_ele_type_geo *types = NULL, int *nbNodesEle = NULL );
	CElements	*getElements() { return m_pElements; };                    // recupere le pointeur des elements
	void		setElements ( CElements *eles ) { m_pElements = eles; };      // charge le pointeur des elements
	virtual void deleteElements();

	int  IdentifierFacetteByNumero( int nume_ini,unsigned int *nodes);
	
	//les groupes
	bool	isComponentExist(const char * nom);

	/* critere qualit� */
	int				calculateDistortion  ( VEC *perturbation, VEC **distortion ) ;
//	T_booleen		LIGHT_verif_convexite( T_booleen avec_perturb, T_statut *ier );

	/* le polynome */
	BVEC *getSupportOfParam( const char *param, bool only_config_mono, double filtre, double filtre2, T_statut *ier );


	bool        addCSdepla ( int numero, int indice = -1 );
	int getCSdepla ( int indNoe );

	/* Sur les elts */
//	unsigned int	getNbNodes();
	unsigned int	getNbNodesMax();
//	unsigned int	GetNbElements(); 

	unsigned int	GetNbElementsMax(){return m_pElements->getNbElementsMax();}; 

	VecIdNode		*ElementGetPrimaryNode(int IndexEle, int &nb_noeud, vector<int> &IdxNode);

	/* Sur les nds */
	double			getDistanceTwoNodes ( int n0, int n1 );

	/* taille */
	void		setTaille ( );
	double		 getTaille ();

	/* pour les contact */
	bool isMeshUseContact();
//	double	get_dist_to_elt( int elem, int noeud );


	/* sortie pour meshViewer */
	//  void ecrireMeshViewerFile ( const string nom );
	/* sortie pour meshViewer */
	void ecrireMeshViewerFile ( const string nom, VEC *perturb = NULL );
	void ecrireANSYSCDB ( const string nom, VEC *perturb = NULL );
	void ecrireMeshViewerFileNodeData ( const string nom, VEC *input_pert );
	void ecrireMeshViewerFileEleData ( const string nom, VEC *input_pert, VEC *Npert = NULL );
	void ecrireMeshViewerFileEleData ( const string nom, IVEC *input_pert, VEC *Npert = NULL );
	void ecrireNoeudData ( FILE *fic, int indN, VEC *Npert, double Ndata );

	void WRITE_ELEMENT_VIEWER( const char *name );
	/* Pour le debug  */
	T_statut	DBG_check_element(int numero);
	void		DBG_check_element_by_index(int indice);
	unsigned int getNumeroMaxForNode()/*{ return _numMaxForNode;}*/;

	VecIdNode	convertToAnsys ( IntegerAdr indE, E_ele_type_geo *newType, bool *err );

	/*=================================*/
	/*		les donn�es membres		   */
	/*=================================*/
public:

	T_Mesh					*_mesh;					/*	uniquement l entete et les dimensions du maillage */

protected:
	int						m_id;
	double					_taille;				/* taille du maillage */
	double					_precision;				/* precision absolue */
//	unsigned int			_degre ;				
	unsigned int			_dimension;
	IVEC					*_cs_depla_label;
	IVEC					*_cs_def_label;
//	unsigned int			_numMaxForNode;
//	unsigned int			_numMaxForElement;
	CNodes					*m_pNodes;
	CElements				*m_pElements;
	unsigned int			m_iId;

private:
	BVEC					*_Nsupport;
	BVEC					*_Esupport;
	bool					convertToAnsysDKT ( IntegerAdr indE, VecIdNode &VnodeAnsys, E_ele_type_geo *newType );
	bool					convertToAnsysDKT12 ( IntegerAdr indE, VecIdNode &VnodeAnsys, E_ele_type_geo *newType );
	bool					convertToAnsysQUA8 ( IntegerAdr indE, VecIdNode &VnodeAnsys, E_ele_type_geo *newType );
	bool					convertToAnsysCUB20 ( IntegerAdr indE, VecIdNode &VnodeAnsys, E_ele_type_geo *newType );
	bool					convertToAnsysTET4 ( IntegerAdr indE, VecIdNode &VnodeAnsys, E_ele_type_geo *newType );
	bool					convertToAnsysTET10 ( IntegerAdr indE, VecIdNode &VnodeAnsys, E_ele_type_geo *newType );
	bool					convertToAnsysPOU3_3D ( IntegerAdr indE, VecIdNode &VnodeAnsys, E_ele_type_geo *newType );
	bool					convertToAnsysPRI6 ( IntegerAdr indE, VecIdNode &VnodeAnsys, E_ele_type_geo *newType );
	bool					convertToAnsysPRI15 ( IntegerAdr indE, VecIdNode &VnodeAnsys, E_ele_type_geo *newType );
	bool					convertToAnsysPYRA13 ( IntegerAdr indE, VecIdNode &VnodeAnsys, E_ele_type_geo *newType );

};


inline int			
CLMeshBase::GetNumNoeud(int ind)
{ 
	CnodesErr Nerr;
	if (!m_pNodes)
		return 0;

	return (int) m_pNodes->getUserNumber((IntegerAdr )ind, &Nerr);
}


#endif /* CLMESH_H */



