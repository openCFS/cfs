
/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 2009 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_edPublic.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_edPublic.h
 *  Prototypes and macros for FEM edge data type
 *
 */
/* *** mpg math array c
 FEM_array.c FEM_matrix.c FEM_MeshTable.h FEM_Public.h FEM_array.h
 FEM_array_static.h  FEM_cdbtypes.h FEM_edPublic.h FEM_elPublic.h
 FEM_errors.h FEM_external.h FEM_faPublic.h FEM_matrix.h
 FEM_matrix_static.h FEM_meshTree.h FEM_noGeom.h FEM_noPublic.h
 FEM_publicElementDefinition.h fem_Struct.h
 ansproto.h computer.h float.h globals.h mathfun.h
*/
#ifndef FEM_EDPUBLIC
#define FEM_EDPUBLIC

#include "FEM_cdbtypes.h"
#include "FEM_external.h"

/* === property masks used with the property field in the edge */

#ifndef NO_PROPERTY
#define NO_PROPERTY        0
#endif
#define EDGE_ON_LINE         (1<<0)
#define EDGE_ON_AREA         (1<<1)
#define EDGE_IN_VOLUME       (1<<2)
#define EDGE_MID_PROJECT     (1<<3)
#define EDGE_SPLIT           (1<<4)  /* used for layer meshing */
#define EDGE_VSWEEP_FRONT    (1<<4)  /* reused for vsweeping */
#define EDGE_NEEDS_MIDNODE   (1<<5)
#define EDGE_QUAD_RETAIN     (1<<6)  /* use for refinement */
#define EDGE_VSWEEP_RIB      (1<<6)  /* reuse for vsweeping */
#define EDGE_MULTIFRONT      (1<<7)
#define EDGE_NEG_ORIENT      (1<<8)
#define EDGE_PERIODIC_TEMP   (1<<9)
#define EDGE_PERIODIC_ENDS   (1<<10)
#define EDGE_PRE_EXISTING    (1<<11)
#define EDGE_MARKED          (1<<12)
#define EDGE_ON_SEAMLINE     (1<<13)
#define EDGE_ON_BND          (1<<14)
#define EDGE_NON_MANIFOLD    (1<<15)
#define EDGE_VISITED         (1<<16)
#define EDGE_CONSTRAINED     (1<<17)
#define EDGE_CHILDGEOS_SET   (1<<18)
#define EDGE_SELECTED        (1<<19) /* temp use for selecet a group of edges */
#define EDGE_AT_HIGH_CURV    (1<<20)
#define EDGE_AT_CONE_TIP     (1<<21)
#define EDGE_INFLATION       (1<<22)
#define EDGE_LAST_EDGE_CLOSED (1<<23) /* the last edge in a closed loop, in param */

/* etc... */

/* === manipulating and inquiring on the linked list object */

#ifdef __cplusplus
extern "C" {
#endif

                             /* === FEM_edNewList: create a new edge list     */
                             /* === and initialize (EDGELIST_OBJ              */
                             /* === constructor)                              */
EDGELIST_OBJ FEM_edNewList ( void  );

                             /* === FEM_edDeleteList: delete the edge list    */
                             /* === (EDGELIST_OBJ destructor)                 */
void FEM_edDeleteList (
   EDGELIST_OBJ obj_edge );            /* The edge list object                */

                             /* === FEM_edNew: create a new edge and add      */
                             /* === it to the edge list                       */
                             /* === (EDGE_OBJ constructor)                    */
EDGE_OBJ FEM_edNew (
   EDGELIST_OBJ obj_edlist );          /* The element list object             */

                             /* === FEM_edDelete: delete a edge and           */
                             /* === remove from list                          */
                             /* === (EDGE_OBJ destructor)                     */
void FEM_edDelete (
   EDGELIST_OBJ obj_edlist,            /* The edge list object                */
   EDGE_OBJ obj_edge );                /* edge object to be deleted           */

                             /* === FEM_edHashEdge: Hash the edge into the    */
                             /* === edge list.  If it does not exist, then    */
                             /* === create one.  Return the (new) edge        */
EDGE_OBJ FEM_edHashEdge (
   EDGELIST_OBJ obj_edlist,        /* the edge list object                    */
   NODE_OBJ obj_node0,             /* an endpoint of the edge                 */
   NODE_OBJ obj_node1,             /* the other endpoint of the edge          */
   NODE_OBJ obj_node2,             /* the mid-side node                       */
   FEM_BOOLEAN *node_orientation,  /* RETURN: direction edge is oriented with */
                                   /* respect to how the edge is stored       */
                                   /* (1 or -1) (used for edge_use)           */
   FEM_BOOLEAN *newedge );         /* RETURN: TRUE if a new edge was created  */
                        

                             /* === FEM_edBetween2Nodes: Get the edge btwn 2 nodes   */
                             /* === edge list.  If it does not exist, return NULL        */
EDGE_OBJ FEM_edBetween2Nodes (
   EDGELIST_OBJ obj_edlist,        /* the edge list object                    */
   NODE_OBJ obj_node0,             /* an endpoint of the edge                 */
   NODE_OBJ obj_node1);             /* the other endpoint of the edge          */


                             /* === FEM_edMaxId: return max edge id in list   */
INT FEM_edMaxId (
   EDGELIST_OBJ obj_edlist  );     /* the edge list object                    */


/* === edge utility functions */

                             /* === FEM_edAdjFace: get an adjacent            */
                             /* === face to the edge                          */
FACE_OBJ FEM_edAdjFace (
   EDGE_OBJ obj_edge );                /* edge object                         */

                             /* === FEM_edNextAdjFace: get next adjacent      */
                             /* === face to the edge                          */
FACE_OBJ FEM_edNextAdjFace (
   EDGE_OBJ obj_edge,                  /* edge object                         */
   FACE_OBJ obj_face );                /* one of the faces adjacent to edge   */

FACE_OBJ FEM_edUsingFace(   /* === given an edge, a face, return the other face using the edge */
	EDGE_OBJ obj_edge,       /* === the edge */
	FACE_OBJ obj_face ) ;    /* === one face using the edge, could be NULL */

                            /* === FEM_edAdjUpdate: update edge adjacencies   */
INT FEM_edAdjUpdate (
   EDGE_OBJ obj_edge );                /* edge object                         */

                            /* === FEM_edInsertAdjFace: Add a face to the     */
                            /* === edge's adjacency list.                     */
INT FEM_edInsertAdjFace (
   EDGE_OBJ obj_edge,                  /* The edge object                     */
   FACE_OBJ obj_face,                  /* face to add to edge's adj list      */
   INT iedge  );                       /* index of edge on face               */

                            /* === FEM_edAdjRemove: delete any adjacency      */
                            /* === info for the edge                          */
INT FEM_edAdjRemove (
   EDGE_OBJ obj_edge );                /* edge object                         */

                            /* === FEM_edLength2: compute length^2 of edge    */
DOUBLE FEM_edLength2 (
   EDGE_OBJ obj_edge );                /* edge object                         */

                            /* === FEM_edLength2: compute length^2 of edge    */
DOUBLE FEM_edLeng2 (
   EDGE_OBJ obj_edge,
   FEM_BOOLEAN bLinear );

                            /* === FEM_edUVLength2: compute length^2 of edge  */
                            /* === in UV space                                */
DOUBLE FEM_edUVLength2 (
   EDGE_OBJ obj_edge );                /* edge object                         */


                            /* === FEM_edRemoveUnusedEdges: searches through  */
                            /* === the list and removes any edges that aren't */
                            /* === associated with any faces.                 */
void FEM_edRemoveUnusedEdges (
   EDGELIST_OBJ obj_edlist  );         /* edge list object                    */

                            /* === FEM_edDetermineEdgeGeoEntity: for an edge  */
                            /* === determine what geo entity is associated    */
                            /* === with it. Areas must be completely          */
                            /* === constructed before calling. The node       */
                            /* === entities and face entities must be up to   */
                            /* === date (stores result in geo_entity field)   */
INT FEM_edDetermineEdgeGeoEntity (
   EDGE_OBJ obj_edge );                /* edge object                         */


                            /* === FEM_edDropMidnode: remove any reference of */
                            /* === midnode from the edge and the midnode      */
INT FEM_edDropMidnode (
   EDGE_OBJ obj_edge  );               /* edge object                         */

                            /* === FEM_edAddMidnode: store the node as the    */
                            /* === midnode on the edge and add pointer from   */
                            /* === node to edge                               */
INT FEM_edAddMidnode (
   EDGE_OBJ obj_edge,                  /* edge object                         */
   NODE_OBJ obj_node  );               /* node object                         */


                            /* === FEM_edAdjustMidnode: move the midnode to   */
                            /* === the midway of the edge                     */
INT FEM_edAdjustMidnode (
   EDGE_OBJ obj_edge );                /* edge object                         */

                            /* === FEM_edNumAdjFaces: return the number of    */
                            /* === faces attached to an edge                  */
INT FEM_edNumAdjFaces (
   EDGE_OBJ obj_edge  );               /* edge object                         */

                            /* === FEM_edReplaceOneNode: edge replace a node  */
                            /* === return EXIT_FAILURE/EXIT_SUCCES            */
INT FEM_edReplaceOneNode( 
   EDGE_OBJ *edge, 
   NODE_OBJ newNode, 
   NODE_OBJ oldNode, 
   DEQUE_OBJ *aobj_deques) ;
#ifndef STANDALONE_DELAUNAY
                            /* === FEM_edHasAdjElems: Determine if there are  */
                            /* === elements adjacent to this edge.            */
INT FEM_edHasAdjElems (
   EDGE_OBJ obj_edge,
   FEM_BOOLEAN *has_adj_elems );/* (OUT) TRUE or FALSE. */
#endif

                            /* === FEM_edOppositeNode: given an edge and a    */
                            /* === node on that edge, return the other node   */
                            /* === (not the midnode) that defines the edge.   */
NODE_OBJ FEM_edOppositeNode (
   EDGE_OBJ obj_edge,                  /* edge object */
   NODE_OBJ obj_node  );               /* node object */

                            /* === FEM_edVector: compute the normalized vector*/
                            /* === defined by the edge                        */
INT FEM_edVector (
   EDGE_OBJ obj_edge,                 /* the edge object                      */
   NODE_OBJ obj_node,                 /* node on edge serves as the origin    */
                                      /*   of vector                          */
   VECTOR3D *ps_vector  );            /* the returned vector                  */
                            /* === FEM_edVectorAndLen: compute the normalized vector*/
                            /* === defined by the edge                        */
DOUBLE FEM_edVectorAndLen (
   EDGE_OBJ obj_edge,                 /* the edge object                      */
   NODE_OBJ obj_node,                 /* node on edge serves as the origin    */
                                      /*   of vector                          */
   VECTOR3D *ps_vector  );            /* the returned vector                  */

                            /* === FEM_edPlaceAtFront: Given a PROPERTY and a */
                            /* === geo_entity, place all edges in the edge    */
                            /* === list with this property and geo_entity (if */
                            /* === necessary ) at the front of the list.      */
INT FEM_edPlaceAtFront (
   EDGELIST_OBJ obj_ellist,           /* edge list to rearrange               */
   FEM_LONG property,                 /* property to rearrange on             */
   INT geo_entity  );                 /* geo_entity to rearrange on           */

                            /* === FEM_edPlaceAtFront2: Given an edge, place  */
                            /* === it at the front of an edge list.           */
INT FEM_edPlaceAtFront2 (
   EDGE_OBJ obj_edge,                 /* edge to put at front                 */
   EDGELIST_OBJ obj_edlist  );        /* edge list to rearrange               */

                            /* === FEM_edPlaceAtRear: Given a property (or    */
                            /* === properties), place all edges in the edge   */
                            /* === list with this property at the rear of the */
                            /* === list; this is equivalent to placing edges  */
                            /* === without this property at the front of list */
void FEM_edPlaceAtRear (
   EDGELIST_OBJ obj_edlist,            /* edg list to rearrange              */
   FEM_LONG property  );               /* property to rearrange on            */

                            /* === FEM_edPlaceAtRear2: Given an edge, place   */
                            /* === it at the rear of an edge list.            */
void FEM_edPlaceAtRear2 (
   EDGE_OBJ obj_edge,                 /* edge to put at front                 */
   EDGELIST_OBJ obj_edlist  );        /* edge list to rearrange               */

                            /* === FEM_edClearGenericPointers: Set all generic*/
                            /* === pointers in obj_edlist to NULL             */
void FEM_edClearGenericPointers (
   EDGELIST_OBJ obj_edlist  );

                            /* === FEM_edCCWFace: get the counterclockwise    */
                            /* === face with respect to one of the nodes on   */
                            /* === the edge (only useful for surface meshes)  */
FACE_OBJ FEM_edCCWFace (
   EDGE_OBJ obj_edge,                 /* the edge object                      */
   NODE_OBJ obj_node  );              /* node on the edge                     */

                            /* === FEM_edCWFace: get the clockwise            */
                            /* === face with respect to one of the nodes on   */
                            /* === the edge (only useful for surface meshes)  */
FACE_OBJ FEM_edCWFace (
   EDGE_OBJ obj_edge,                 /* the edge object                      */
   NODE_OBJ obj_node  );              /* node on the edge                     */

                            /* === FEM_edAdjLeftFace: return the face on the  */
                            /* === left side of the edge based on orientation */
                            /* === flag (assumes 2D topology)                 */
FACE_OBJ FEM_edAdjLeftFace (
   EDGE_OBJ obj_edge,                  /* the edge object                     */
   INT orientation  );                 /* direction of edge with respect to   */
                                       /* current orientation (nd[0],nd[1])   */
                                       /* 1  = node0 -> node1,                */
                                       /* -1 = node1 -> node0                 */
                            /* === FEM_edAdjLFaceArea: return the face on the */
                            /* === left side of the edge based on orientation */
                            /* === flag (assumes 2D topology)                 */
FACE_OBJ FEM_edAdjLFaceArea (
   EDGE_OBJ obj_edge,                  /* the edge object                     */
   INT orientation,                    /* direction of edge with respect to   */
                                       /* current orientation (nd[0],nd[1])   */
                                       /* 1  = node0 -> node1,                */
                                       /* -1 = node1 -> node0                 */
   INT area_id );                      /* area containing the left face       */
                            /* === FEM_edCCWFaceArea: get the counterclockwise    */
                            /* === face with respect to one of the nodes on   */
                            /* === the edge (only useful for surface meshes)  */
FACE_OBJ FEM_edCCWFaceArea (
   EDGE_OBJ obj_edge,                 /* the edge object                      */
   NODE_OBJ obj_node,                 /* node on the edge                     */
   INT area_id );             

                            /* === FEM_edCWFaceArea: get the clockwise            */
                            /* === face with respect to one of the nodes on   */
                            /* === the edge (only useful for surface meshes)  */
FACE_OBJ FEM_edCWFaceArea (
   EDGE_OBJ obj_edge,                 /* the edge object                      */
   NODE_OBJ obj_node,                 /* node on the edge                     */
   INT area_id );             


#ifndef STANDALONE_DELAUNAY
                            /* === FEM_edElements: return array of elements   */
                            /* === adjacent to edge                           */
INT FEM_edElements (
   EDGE_OBJ obj_edge,                  /* the edge object                     */
   INT *num_elements,                  /* number of elements in list          */
   INT max_elems,                      /* size of the aobj_faces array        */
   ELEMENT_OBJ *aobj_elems  );         /* return preallocated list of elem    */
                                       /* objects adjacent to edge            */
#endif

                            /* === FEM_edTets: return array of tets           */
                            /* === adjacent to edge                           */
INT FEM_edTets (
   EDGE_OBJ obj_edge,                  /* the edge object                     */
   INT *num_tets,                      /* number of tets in list              */
   INT max_elems,                      /* size of the aobj_elems array        */
   ELEMENT_OBJ *aobj_elems  );         /* return preallocated list of elem    */
                                       /* objects adjacent to edge            */

                            /* === FEM_edFace: given a list of edges find a   */
                            /* === face that has exactly those edges. Return  */
                            /* === NULL if one does not exist                 */
FACE_OBJ FEM_edFace (
   EDGE_OBJ obj_edge0,                 /* edges on face                       */
   EDGE_OBJ obj_edge1,
   EDGE_OBJ obj_edge2,
   EDGE_OBJ obj_edge3   );             /* can be NULL if triangle             */

                            /* === FEM_edGet: return the edge object given its*/
                            /* === ID.  (Does a linear search)                */
EDGE_OBJ FEM_edGet(
   INT id );

                            /* === FEM_edNodeAtEdges: given 2 edges find a   */
                            /* === node shared by these edges. Return         */
                            /* === NULL if one does not exist                 */
NODE_OBJ FEM_edNodeAtEdges (
   EDGE_OBJ obj_edge0,                 
   EDGE_OBJ obj_edge1   );   
   
   
FEM_BOOLEAN FEM_edNodeOnEdge(
   EDGE_OBJ obj_edge,
   NODE_OBJ obj_node );
   
                           /* === FEM_edIsStraight: given an edge tell if it is straight */   
FEM_BOOLEAN FEM_edIsStraight( EDGE_OBJ obj_edge );

/* === create a node at the mid of an edge */

INT FEM_edCreateNodeAtMid(
	EDGE_OBJ obj_edge,  /* the edge */
	NODE_OBJ *newNode ) ;

/* === break an edge from the middle -- break the edge ONLY when the edge is not used */
INT FEM_edBreakEdgeOnly( 
	EDGE_OBJ obj_edge,          /* the edge to be broken */
	EDGE_OBJ *aobj_newEdges ) ;

INT FEM_edMergeEdgeOnly( 
	EDGE_OBJ *aobj_edges,     /* the edges to be merged */
	EDGE_OBJ *obj_newEdge );


                            /* === FEM_edShapeMetric:return shape metric of edge   */
DOUBLE FEM_edShapeMetric( 
   EDGE_OBJ obj_edge ,      /* the edge */
   FEM_BOOLEAN user_midpoint,  /* if the user supplies a projected midpoint, if not just use the actual midpoint */
   DOUBLE mx,                  /* the user supplied midpoint */
   DOUBLE my,
   DOUBLE mz,
   DOUBLE *pdHoverLMetricSquared );

                                /* === Function: FEM_edCollapes
                                 * === Author: jrt
                                 * === Description: Collapse and edge  only attached to tris
                                 * === Return: status EXIT_FAILURE OR EXIT_SUCCESS */
INT FEM_edCollapse( 
   EDGE_OBJ *pobj_edge,        /* the edge */
   NODE_OBJ *pnKeep,
   DEQUE_OBJ *aobj_deques,
   INT iUserInfo,
   INT *did);

INT FEM_edNodeBetween( 
   EDGE_OBJ *aobj_edges, /* only for two edges */ 
   NODE_OBJ *aobj_nodes,
   INT *iNumBetween );

INT FEM_edCommonNode( 
   EDGE_OBJ *aobj_edges, /* only for two edges */ 
   NODE_OBJ *aobj_nodes,
   INT *iNumBetween );

/* return the mid node location if there is a mid node, otherwise return the center of the edge */
INT FEM_edMidPoint(
	EDGE_OBJ obj_edge,  
	VECTOR3D *pMid );

/* return the center of the edge */
INT FEM_edCenterPoint(
	EDGE_OBJ obj_edge,  
	VECTOR3D *pCnt );

INT FEM_edCollapseForTris( 
   EDGE_OBJ *pobj_edge,        /* the edge */
   NODE_OBJ *pnKeep,
   DEQUE_OBJ *aobj_deques,
   INT iUserInfo );

INT FEM_edNotMoveable( EDGE_OBJ obj_edge, INT opt ); 
 


#ifdef __cplusplus
}
#endif

/*
 * === Edge Macros
 */
#include "fem_Struct.h"

/*============================================================================*/
/* === Macro: FEM_edNext_C
 * === Author: sjo
 * === Description: return the next edge in the linked list of edges
 * === Arguments:
 *     EDGE_OBJ obj_edge          current edge in list
 * === Return: EDGE_OBJ              next edge in list
 *             NULL if macro not defined for g_meshtype
 */
#define FEM_edNext_C( obj_edge )\
   ((g_meshtype == STANDARD_MESH) ?\
      (EDGE_OBJ)(((EDGE_PTYP)(obj_edge))->ps_next) :\
   NULL)

/*============================================================================*/
/* === Macro:  FEM_edPrevious_C
 * === Author: sjo
 * === Description: get the previous edge in the linked list object
 * === Arguments:
 *     EDGE_OBJ obj_element          current edge in list
 * === Return: EDGE_OBJ              previous edge in list
 *             NULL if macro not defined for g_meshtype
 */
#define FEM_edPrevious_C( obj_edge )\
   ((g_meshtype == STANDARD_MESH) ?\
      (EDGE_OBJ)(((EDGE_PTYP)(obj_edge))->ps_previous) :\
   NULL)

/*============================================================================*/
/* === Macro: FEM_edTotal_C
 * === Author: sjo
 * === Description: get the total number of edges in list
 * === Arguments:
 *     EDGELIST_OBJ obj_edlist   The edge list
 * === Return: INT              total number of edges in list
 *             -1 if macro not defined for g_meshtype
 */
#define FEM_edTotal_C( obj_edlist )\
   ((g_meshtype == STANDARD_MESH) ?\
      (INT)(((EDGELIST_PTYP)(obj_edlist))->total) :\
   -1)

/*============================================================================*/
/* === Macro: FEM_edList_C
 * === Author: sjo
 * === Description: return the head of the edge linked list
 * === Arguments:
 *     EDGELIST_OBJ obj_edlist      edge list
 * === Return: EDGE_OBJ            head of edge list
 *             NULL if macro not defined for g_meshtype
 */
#define FEM_edList_C( obj_edlist )\
   ((g_meshtype == STANDARD_MESH) ?\
      (EDGE_OBJ)(((EDGELIST_PTYP)(obj_edlist))->ps_list) :\
   NULL)

/*============================================================================*/
/* === Macro: FEM_edId_C
 * === Author: sjo
 * === Description: return the edge id
 * === Arguments:
 *     EDGE_OBJ obj_edge        edge object
 * === Return: INT              edge id
 *             -1 if macro not defined for g_meshtype
 */
#define FEM_edId_C( obj_edge )\
   ((g_meshtype == STANDARD_MESH) ?\
      (INT)(((EDGE_PTYP)(obj_edge))->id) :\
   -1)

/*============================================================================*/
/* === Macro: FEM_edSetId_C
 * === Author: sjo
 * === Description: set the edge id
 * === Arguments:
 *     EDGE_OBJ obj_edge      edge object
 *     INT edge_id            the new edge id
 * === Return: nothing
 */
#define FEM_edSetId_C( obj_edge, edge_id )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((EDGE_PTYP)(obj_edge))->id = (INT)edge_id;\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__);\
         break;\
   }

/*============================================================================*/
/* === Macro: FEM_edNode_C
 * === Author: sjo
 * === Description: get the inode node object from the edge
 * === Arguments:
 *     EDGE_OBJ obj_edge   edge object
 *     INT inode           number of node to return (0,1 or 2)
 * === Return: NODE_OBJ          node object corresponding to inode
 *             NULL if macro not defined for g_meshtype
 */
#define FEM_edNode_C( obj_edge, inode )\
   ((g_meshtype == STANDARD_MESH) ?\
      (NODE_OBJ)(((EDGE_PTYP)(obj_edge))->aps_node[inode]) :\
   NULL)

/*============================================================================*/
/* === Macro: FEM_edSetNode_C
 * === Author: sjo
 * === Description: set the inode node object to the edge
 * === Arguments:
 *     EDGE_OBJ obj_edge     edge object
 *     INT inode             number of node to set (0,1 or 2)
 *     NODE_OBJ obj_node     new node object for the edge
 * === Return: nothing
 */
#define FEM_edSetNode_C( obj_edge, inode, obj_node )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((EDGE_PTYP)(obj_edge))->aps_node[inode] = (NODE_PTYP)obj_node;\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__);\
         break;\
   }

/*============================================================================*/
/* === Macro: FEM_edProperty_C
 * === Author: sjo
 * === Description: return the status of a property for the edge
 * === Arguments:
 *     EDGE_OBJ obj_edge      edge object
 *     FEM_LONG property_mask one of the edge properties specified above
 * === Return: FEM_LONG 0 or !=0      0 = not set, !=0 = set
 */
#define FEM_edProperty_C( obj_edge, property_mask )\
   ((g_meshtype == STANDARD_MESH) ?\
      (FEM_LONG)(((EDGE_PTYP)(obj_edge))->property & (FEM_LONG)(property_mask)) :\
   0L)

/*============================================================================*/
/* === Macro: FEM_edGetAllProperties_C
 * === Author: mls
 * === Description: return the variable bit field for all properties
 * === Arguments:
 *     EDGE_OBJ obj_edge     edge object
 * === Return: FEM_LONG the property
 */
#define FEM_edGetAllProperties_C( obj_edge )\
   ((g_meshtype == STANDARD_MESH) ?\
      (FEM_LONG)(((EDGE_PTYP)(obj_edge))->property) : 0L)

/*============================================================================*/
/* === Macro: FEM_edSetProperty_C
 * === Author: sjo
 * === Description: Set the status of a property for the edge
 * === Arguments:
 *     EDGE_OBJ obj_edge       edge object
 *     FEM_LONG property_mask  one of the edge properties specified above
 *     FEM_BOOLEAN status;   0 or 1, TRUE or FALSE, ON or OFF
 * === Return: 0 or !=0      0 = not set, !=0 = set
 */
#define FEM_edSetProperty_C( obj_edge, property_mask, status )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         if (status) {\
            ((EDGE_PTYP)(obj_edge))->property = \
               ((EDGE_PTYP)(obj_edge))->property | (FEM_LONG)(property_mask);\
         }\
         else {\
            if(((EDGE_PTYP)(obj_edge))->property & (FEM_LONG)(property_mask)) {\
               ((EDGE_PTYP)(obj_edge))->property =\
                  ((EDGE_PTYP)(obj_edge))->property ^ (FEM_LONG)(property_mask);\
            }\
         }\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__);\
         break;\
   }

/*============================================================================*/
/* === Macro: FEM_edSetAllProperties_C
 * === Author: mls
 * === Description: Set the entire property bit field
 * === Arguments:
 *     EDGE_OBJ obj_edge     edge object
 *     FEM_LONG property     the bit field
 * === Return: none
 */
#define FEM_edSetAllProperties_C( obj_edge, new_property )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((EDGE_PTYP)(obj_edge))->property = new_property;\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__);\
         break;\
   }

/*============================================================================*/
/* === Macro: FEM_edInitProperties_C
 * === Author: sjo
 * === Description: Initialize all properties for the edge to OFF
 * === Arguments:
 *     EDGE_OBJ obj_edge     edge object
 * === Return: nothing
 */
#define FEM_edInitProperties_C( obj_edge )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((EDGE_PTYP)(obj_edge))->property = NO_PROPERTY;\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__);\
         break;\
   }

/*============================================================================*/
/* === Macro: FEM_edGenericPointer_MAC
 * === Author: sjo
 * === Description: retreive the generic pointer from the edge object
 * === Arguments:
 *     EDGE_OBJ obj_edge     edge object
 * === Return: (void *) a generic pointer (must be caste to correct type)
 */
#define FEM_edGenericPointer_MAC( obj_edge )\
   ((g_meshtype == STANDARD_MESH) ?\
      (((EDGE_PTYP)(obj_edge))->p_info) :\
   NULL)

/*============================================================================*/
/* === Macro: FEM_edSetGenericPointer_C
 * === Author: sjo
 * === Description: set a generic pointer into the edge object
 * === Arguments:
 *     EDGE_OBJ obj_edge       edge object
 *     ADRESS_TYP obj_entity   any object entity or generic void pointer
 * === Return: void
 */
#define FEM_edSetGenericPointer_C( obj_edge, obj_entity )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((EDGE_PTYP)(obj_edge))->p_info = (ADDRESS_TYP)obj_entity;\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__);\
         break;\
   }

/*============================================================================*/
/* === Macro: FEM_edGeoEntity_C
 * === Author: sjo
 * === Description: get the edge underlying geometric entity id
 * === Arguments:
 *     EDGE_OBJ obj_edge     edge object
 * === Return: INT geo_entity
 */
#define FEM_edGeoEntity_C( obj_edge )\
   ((g_meshtype == STANDARD_MESH) ?\
      (INT)((EDGE_PTYP)(obj_edge))->geo_entity : -1)

/*============================================================================*/
/* === Macro: FEM_edSetGeoEntity_C
 * === Author: sjo
 * === Description: set the edge underlying geometric entity id
 * === Arguments:
 *     EDGE_OBJ obj_edge     edge object
 *     INT the_entity        number of the entity (user defined)
 * === Return: void
 */
#define FEM_edSetGeoEntity_C( obj_edge, the_entity )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((EDGE_PTYP)(obj_edge))->geo_entity = (INT)the_entity;\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__);\
         break;\
   }
  

#endif
