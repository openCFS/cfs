
#include "ansysdef.h"


extern  INT  cCreateAnsEAdj(INT);
extern  INT  cDeleteAnsEAdj(void);
extern  INT  cInquireAnsEAdj(INT,INT);
extern  INT  cPutAnsEAdj(INT,INT,INT*);
extern  INT  cGetAnsEAdj(INT,INT*,INT*);
extern  INT  cGetAnsEAdjPtr(INT,INT*,INT**);
extern  INT  cDumpAnsEAdj(INT);


/****************************************************************
 global-level structure for ANSYS element adjacency
 ****************************************************************/
struct ansEAdj_str {           /* Name of the structure                                     */
  INT        tag;              /* Tag for this instance of the element adjacency structure  */
  INT        maxElemsPerElem;  /* Maximum number of elements connected to any element       */
};

#define ansEAdjTag(eadj)                (eadj->tag)
#define ansEAdjMaxElemsPerElem(eadj)    (eadj->maxElemsPerElem)



/******************************************************************
 data-level structure for ANSYS node-element cross reference list
 ******************************************************************/
struct eadjData_str {   /* Name of the structure                                       */
  INT      numElems;    /* Number of elements adjacent to this element                 */
  INT     *elems;       /* Array of external element numbers connected to this element */
};

#define eadjDataNumElems(aData)         (aData->numElems)

#define eadjDataElemsPtr(aData)         (aData->elems)
#define eadjDataElemsVec(aData,i)       (aData->elems[i])

