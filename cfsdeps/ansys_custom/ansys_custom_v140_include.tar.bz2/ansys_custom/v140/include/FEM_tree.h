
/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 2009 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_Tree.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_Tree.h
 *  header file for FEM_Tree.cpp
 *
 */
#ifndef FEM_TREE_H
#define FEM_TREE_H

#include <vector>
#include <set>

#ifndef RWSTD_NO_NAMESPACE
using namespace std;
#endif
#include "FEM_Box.h"

#ifdef DSPACE_CMDB
#include "DSMemManager.h"
#endif


#ifdef SGI64_SYS
        using namespace std;
#endif


#define DEFAULT_MAX_FACES_PER_NODE  4
#define MAX_LEVEL_OF_TREE           4
#define SCALE_UP_TREE               0.01
#define UNDEFINED_LEVEL             -1

typedef enum { kTreeUnknown=0, kTreeRoot, kTreeRootWithoutLeaf, kTreeNode, kTreeLeaf } _eNodeStatus;

class Tree_Node {
	
public:
	
    Tree_Node( bool bUse3DCoorForQuadTree = false);
	~Tree_Node( );
	
    int         init ( bool bIsTree=true, vector<FACE_OBJ> * pvFaceListPassedIn = NULL, unsigned int maxLevel = 4 );
    void        getFaceListFromRoot ( double *pXYZ, vector<FACE_OBJ> *& pvFaceList,
                int iLevel = UNDEFINED_LEVEL );
    
    void        getFaceList ( CBBox & cBox, set<FACE_OBJ> & sFaces, int iLevel = UNDEFINED_LEVEL );
    void        getTreeBox ( CBBox * pcBox );

    bool        FaceExist  ( FACE_OBJ obj_face );
    int         removeFace ( FACE_OBJ obj_face );
    int         insertFace ( FACE_OBJ obj_face );

    int         outputBox ( int id );
    int         outputBox  ( int id, FILE  * & pOutfile );
    int         outputTree ( int id, FILE  * & pOutfile );
    void        outputTree ();

#ifdef DSPACE_CMDB
     static CDSMemManager<Tree_Node> m_cMemManager;

#if defined(ux11) || defined(_WIN64)
	 inline void* operator new( size_t nSize )
#else
	 inline void* operator new( unsigned int nSize )
#endif
    {
        Tree_Node* pcT = m_cMemManager.getNextAvailablePointerToData(); 
        return pcT;
    }

    inline void operator delete( void* pcTVoid )
    {
        Tree_Node* pcT = (Tree_Node*)pcTVoid;
        m_cMemManager.returnPointerToDSMemManager( pcT );
    }
#endif

private:
    void        build( vector<FACE_OBJ> * & pvFaceList, int iMaxFacesPerNode );
    inline void setParent( Tree_Node  *pcParent );
    inline void getNodeCoords ( NODE_OBJ obj_node, double *pX, double *pY, double *pZ );
    bool isInsideBox( NODE_OBJ *aobj_nodes, int iNumNodes, FACE_OBJ obj_face ); 
    void        getFaceList ( double *pXYZ, vector<FACE_OBJ> *& cFaceList, int iLevel = UNDEFINED_LEVEL );
    void        getFaceList ( CBBox & cBox, vector <vector<FACE_OBJ> *>& vFaceVectorList, int iLevel = UNDEFINED_LEVEL );

    static unsigned int m_iTotalNumber;

    unsigned int        m_maxLevel;
    unsigned int        m_iNumOctants;
    unsigned int        m_iMaxFacesPerNode;
    bool                m_bUse3DCoorForQuadTree;

    unsigned int        m_iLevel;
    unsigned int        m_id;
    _eNodeStatus        m_eStatus;
	Tree_Node           *m_pcParent;
	Tree_Node           *m_pcOctants[8];
	CBBox                m_cbox;
    bool                 m_bFacesPassedIn;
    vector<FACE_OBJ>    *m_pvFaceList;
    double               m_adCenter[3];
}; 

#endif

