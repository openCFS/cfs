/*  FEM_cleantopo.h */
/*
 * *** ansys(r) copyright(c) 2009
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_cleantopo.h
 *  header file for FEM_cleantopo.c
 *
 */
#ifndef FEM_CLEANTOPO_INCLUDE
#define FEM_CLEANTOPO_INCLUDE

/* defined in Mstat.inc */
#define CMND_AMESH  1
#define CMND_REFINE 5

/*----------------- Globally accessible function prototypes -----------------*/
                                /* ========================================= */
                                /* === FEM_clQuadTriCleanUp: perform         */
                                /* === topological cleanup on a mesh composed*/
                                /* === of both triangles and quads.  Called  */
                                /* === from FEM_refine.c                     */
                                /* ========================================= */
INT FEM_clQuadTriCleanUp ( 
   INT area,                    /* only the faces on area will be cleaned up */
   NODELIST_OBJ obj_nlist,      /* the node list object                      */
   EDGELIST_OBJ obj_edlist,     /* the edge list object                      */
   FACELIST_OBJ obj_flist,      /* the face list object                      */
   FEM_BOOLEAN midnodes,        /* TRUE of midnodes exist                    */
   DOUBLE tolerance,            /* smoothing tolerance                       */
   INT *cleanedup,              /* returned as TRUE if something was changed */
   INT process,
   INT userInfo );              /* Where cleanup is called from. Possible    */
                                /* values:    PROC_CLEAN  (see Mstat.h)      */
                                /*            PROC_IMPROVE1                  */
                                /* if this equals -1, no progress will be    */
                                /* done                                      */


INT FEM_clPerformSmooth( 
   NODELIST_OBJ obj_nlist,
   FACELIST_OBJ obj_flist,
   DOUBLE tolerance,
   INT area,
   INT localSmooth,
   INT stat_process );
#endif

