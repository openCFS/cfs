/*
 * ***copyright(c) 2011 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */
/* This is a header file created for the express porpoise of 
 * confusing the ansi compiler by making TESTv7.c mixed 
 * K&R and ANSI C  -- mjr  2.14.97
 */
/*-----------------Function Prototypes---------------------------*/

static int dummy1(int I1, float F1);

static int dummy2(int I2, float F2);

static int dummy3(int I3, float F3, char C3);

static int dummy4(int *ptr, double *ptr2, 
            int (*func)(void), double (*func2)(void));

void test_dummy(void);
void test_dummie(void);

/*----------------------------------------------------------------*/
