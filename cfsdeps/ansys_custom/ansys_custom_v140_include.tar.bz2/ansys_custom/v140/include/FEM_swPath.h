#ifndef FEM_SWPATH________H
#define FEM_SWPATH________H

#include "FEM_cdbtypes.h"
#include "FEM_Public.h"
#include "FEM_deque.h"

class SWPATH_TYP;
typedef class SWPATH_TYP *SWPATH_PTYP;

class SWPATH_TYP {

   private:
      INT m_length;
      INT m_allocatedlength;
      unsigned m_allharddivs:1;
      CELL_PTYP *m_aobj_pathcells;

   public:
      SWPATH_TYP() { m_allharddivs = 0; m_length = 0; m_allocatedlength = 0;
                     m_aobj_pathcells = NULL; };
      ~SWPATH_TYP() { Delete(); };
      void Init()
      {
         m_allharddivs = 0;
         m_length = 0;
         m_allocatedlength = 0;
         m_aobj_pathcells = NULL;
      }

      void Delete()
      {
         m_allharddivs = 0;
         m_length = 0;
         m_allocatedlength = 0;
         FEM_Free_C( m_aobj_pathcells );
      }
      INT Length() const { return m_length; };

      void SetAllHardDivs( const FEM_BOOLEAN stat = TRUE )
      {
         if ( stat ) m_allharddivs = 1;
         else m_allharddivs = 0;
      };
      FEM_BOOLEAN AllHardDivs( void ) const
      {
         if ( m_allharddivs ) return 1;
         else return 0;
      };
      CELL_PTYP operator[] ( const INT index ) const
      {
         if ( index < 0 || index >= m_length ) {
            return NULL;
         }
         return m_aobj_pathcells[index];
      };

      INT StorePathCells( DEQUE_OBJ obj_linedeque );
      INT Copy( SWPATH_PTYP pobj_path );

      void isPathSingularAndStraight(FEM_BOOLEAN &bSingular, FEM_BOOLEAN &bStraight)
      {
          INT error;
          bSingular = bStraight = FALSE;
          if( m_length == 1 )
          {
              CELL_PTYP pcCell = m_aobj_pathcells[ 0 ];
              if ( pcCell->IsLine() )
              {

                  LINE_PTYP pcLine = (LINE_PTYP)pcCell;

                  INT geoId = pcLine->GetId();
                  bSingular = TRUE;;
                  if( FEMe_IsLineStraight( geoId, &error ) )
                      bStraight = TRUE;
              }
              else if ( pcCell->IsArea() )
              {
                  if ( 7 == FEMe_GeometryType( pcCell->GetId(), 2, &error ))
                      bStraight = TRUE;
              }
          }
      };
      
      FEM_BOOLEAN doesPathContainAnArea()
      {
          for ( INT i = 0; i < m_length; i++ )
          {
              if ( m_aobj_pathcells[i]->IsArea() )
                  return TRUE;
          }
          return FALSE;
      };

      FEM_BOOLEAN doesPathContainALine()
      {
          for ( INT i = 0; i < m_length; i++ )
          {
              if ( m_aobj_pathcells[i]->IsLine() )
                  return TRUE;
          }
          return FALSE;
      };

      DOUBLE PathLength()
      {
          DOUBLE dPathLength = 0.0;
          for ( INT i = 0; i < m_length; i++ )
          {
              if ( m_aobj_pathcells[i]->IsArea() )
                dPathLength += ((AREA_PTYP)m_aobj_pathcells[i])->Length();
              else if (  m_aobj_pathcells[i]->IsLine())
                dPathLength += ((LINE_PTYP)m_aobj_pathcells[i])->Length();
          }
          return dPathLength;
      };
}; 

class SWPATH_CELL_TYP {

};


#endif
