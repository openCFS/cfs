
/*
////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         Copyright (C) 2010 ANSYS Inc.  All Rights Reserved             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MAT_Main.h $
// $Revision: 1.6 $ 7.0
// $Date: 2010/04/06 20:21:12 $ March 28 2002
// $Author: srpailla $ rjayasee/jlo
//
// Decription :
//
//	C Entry point from Ansys to the Curve Fitting Code. This has all the
//  Command Parsing code
//////////////////////////////////////////////////////////////////////////////
*/

/*  tbfit.h */
#if !defined(MAT_Main__1)
#define MAT_Main__1
#define MAT_Main_Get__1


/* (1)----------------------------------------------------------------*/
#if defined(LOWERCASENOUNDER_SYS)

/*
 *   The pattern for these platforms is the lowercased version of the name
 */

#define MAT_MainTbft          mat_maintbft
#define MAT_MainCfit          mat_maincfit
#define MAT_MainGet           mat_mainget
#define MAT_MainClear         mat_mainclear
#endif


/* (2)----------------------------------------------------------------*/
#if defined(UPPERCASENOUNDER_SYS)

/*
 *   The pattern for these platforms is the uppercased version of the name
 */

#define MAT_MainTbft           MAT_MAINTBFT
#define MAT_MainCfit           MAT_MAINCFIT
#define MAT_MainGet            MAT_MAINGET
#define MAT_MainClear          MAT_MAINCLEAR
#endif


/* (3)----------------------------------------------------------------*/
#if defined(LOWERCASEUNDER_SYS)

/*
 *   The pattern for these platforms is the lowercased version of the name 
 *   followed by an underscore
 */

#define MAT_MainTbft           mat_maintbft_
#define MAT_MainCfit           mat_maincfit_
#define MAT_MainGet            mat_mainget_
#define MAT_MainClear          mat_mainclear_


#endif


/* (4)----------------------------------------------------------------*/

/*
 *   This section is for definition of prototypes.  Each prototype 
 *   should be ANSI compliant and specify the types of each parameter 
 *   as well as the return type.
 */
#ifdef __cplusplus
extern "C"
{
#endif

SUBROUTINE MAT_MainTbft() ;
SUBROUTINE MAT_MainCfit() ;
SUBROUTINE MAT_MainGet() ;
SUBROUTINE MAT_MainClear() ;

#ifdef __cplusplus
}

#endif

#endif
