/*****************************************************************************
 *                   Copyright (C) 1999 CMSoft                               *
 *                                                                           *
 *  These lines of code and declarations contain unpublished proprietary     *
 *  information of CMSoft. They may not be copied or duplicated in whole     *
 *  or part without prior authorization from CMSoft.                         *
 *                                                                           *
 *****************************************************************************/
#ifndef _FS_DIST_VECTOR_H_
#define _FS_DIST_VECTOR_H_

class FSTaskDistribution;
class FSDistVector;
class FSDistInfo;

#include "cadoe_string.h"

struct FSMixedProd {
  double coef;
  const FSDistVector &vec;
  FSMixedProd(double c, const FSDistVector &v) : coef(c), vec(v) {}
};

class FSDistVector {
  int		_len;		// length of the overall vector
  int		_numSub;
  double	*_v;		// overall vector
  int		*_subs;		// sub-domains (size=numSub, global numbering)
  int		*_subLen;	// each subdomain's vector length
  double	**_subV;	// each subdomain's vector
  int		_numThreads;    // total number of threads
  int		* _threadLen;	// each thread's vector length
  double	**_threadV;	// each thread's vector
  bool		_ownMemory;
  
public:
  FSDistVector(const FSDistInfo &distInfo, const FSTaskDistribution &td);
  FSDistVector(const FSDistInfo &distInfo);
  FSDistVector(FSDistInfo &distInfo, FSDistVector &rb, int *subs);
  ~FSDistVector();
  
  FSDistVector &operator=(const FSDistVector &x);
  FSDistVector &operator=(const double &val);
  
  double operator*(const FSDistVector &x);
  
  void zero();  // Zero  the vector
  void print(char *msg); // Print the vector
  double Nrm2();
  void Nrm2(string message = "", bool displayMax = false) const;
  
  void Axpy(double coef, const FSDistVector &);  
  friend FSMixedProd operator *(double a, const FSDistVector &v) { return FSMixedProd(a,v); }
  void operator += (const FSMixedProd &);
  void operator -= (const FSMixedProd &);
  void operator += (const FSDistVector &);
  void operator -= (const FSDistVector &);
  void operator *= (const double &);
  
  double *  subVector(int i) const { return _subV[i];      }
  double ** subVector()      const { return _subV;         }
  int       subLength(int i) const { return _subLen[i];    }
  int *     subLength()      const { return _subLen;       }
  double *  thVector(int i)  const { return _threadV[i];   } 
  double ** thVector()       const { return _threadV;      }
  int       thLength(int i)  const { return _threadLen[i]; }
  int *     thLength()       const { return _threadLen;    }
  double *  data()	     const { return _v;	}
  int	    locLen()	     const { return _len; }

private:
  // thread level functions
  void thZero(int iThread);
  void subDot(int iThread, const FSDistVector *v, double *res);
  void subCopy(int iThread, const FSDistVector *v);
  void Axpy(int iThread, double *coef, const FSDistVector *v);
};

#endif
