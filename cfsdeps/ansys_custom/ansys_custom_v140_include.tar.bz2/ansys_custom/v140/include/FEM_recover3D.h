/*  FEM_recover3D.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_recover3D.h
 *  Prototypes and macros for FEM_recover3D.c
 *
 */

#ifndef RECOVER3D_H
#define RECOVER3D_H




/*------------------------ Prototypes ------------------------------------------*/

                            /* === FEM_recover3D: recover edges and faces from  */
                            /* === a tet mesh                                   */
INT FEM_recover3D (
   NODE_OBJ obj_node0,                /* (IN) nodes of the face to be recovered */
   NODE_OBJ obj_node1,
   NODE_OBJ obj_node2,
   FEM_BOOLEAN steiner,               /* (IN) insert steiner point if necessary */
                                      /*      otherwise fail                    */
   FACE_OBJ *p_obj_face  );           /* (OUT) return recovered face            */

                            /* === FEM_recover3DQuad: recover edges and 2 faces */
                            /* === a tet mesh                                   */
INT FEM_recover3DQuad( 
   NODE_OBJ obj_node0,                /* (IN) nodes of the face to be recovered */
   NODE_OBJ obj_node1,
   NODE_OBJ obj_node2,
   NODE_OBJ obj_node3,
   FEM_BOOLEAN steiner,               /* (IN) flag - if necessary insert steiner node,
                                         otherwise return with EXIT_CANT_RECOVER */
   FACE_OBJ *p_obj_face0,             /* (OUT) return the recovered faces */
   FACE_OBJ *p_obj_face1 );


#endif

