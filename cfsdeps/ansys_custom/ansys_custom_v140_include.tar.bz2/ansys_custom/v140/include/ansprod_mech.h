/*
 * Copyright 2003-2010 ANSYS, Inc.
 * All Rights Reserved
 */
#ifndef __ANSYS_PRODUCT_MECH_H__
#define __ANSYS_PRODUCT_MECH_H__

#define ASSEMBLY_CAPABILTY                1
#define SHEET_CAPABILTY                   2
#define CAE_TEMPLATES                     3
#define FATIGUE                           4
#define ADVANCED_CONTACT                  5
#define ACADEMIC_WATERMARK                22
#define MESH_CAPABILITY                   267
#define ADV_MESH_CAPABILITY               268
#define MANUAL_MESHING_CONTROLS           6
#define MESH_MANUAL_MESHING_CONTROLS      6
#define MESH_CFX_MESH                     24
#define MESH_PATCH_INDEPENDENT            25
#define MESH_EXPLICIT_PATCH_INDEPENDENT   26
#define HEX_DOMINANT_MESHING              18
#define MESH_HEXA_DOMINANT                18
#define MESH_HEXA_CORE                    27
#define MESH_THIN_SOLID_SWEEP             28
#define MESH_UNIFORM_QUAD                 29
#define MESH_ICEM_CFD_HEXA_BLOCKING       30
#define MESH_ICEM_CFD_MESH_EDITING        31
#define SKIN_DETECTION                    32
#define MESH_MORPHING                     33
#define PB_MESH_MATERIAL                  39
#define CUSTOMIZED_USAGE                  8
#define FEA_IN_OUT                        9
#define LOW_PRICE_SOLVER                  10
#define TIME_DOMAIN_ANALYSIS              11
#define NON_LINEAR_STRUCTURAL             12
#define STRUCTURAL_DYNAMICS               13
#define STRUCTURAL_BUCKLING               14
#define THERMAL                           15
#define TRANS_THERMAL                     16
#define ADV_PREP_POST                     17
#define PRETENSION_BOLT_LOAD              19
#define SOLUTION_COMBINATION              20
#define NON_LINEAR_MATERIAL               21
#define PB_FRICTIONAL_CONTACT             34
#define PB_RADIATION_LOAD                 35
#define PB_NLGEOM_ALL_TYPES               37
#define PB_BILINEAR_PLASTICITY            38
#define ANSYS_CAPABILITY                  90
#define DS_CAPABILITY                     91
#define AGP_CAPABILITY                    92
#define BLADEMODELER_CAPABILITY           377
#define FES_CAPABILITY                    93
#define DXVT_CAPABILITY                   174
#define AIENV_CAPABILITY                  241
#define CAD2MESH_CAPABILITY               303
#define CFX_SOLVER_CAPABILITY             310
#define CFX_CAPABILITY                    312
#define CFX_PREPPOST_CAPABILITY           318
#define CFX_TG_CAPABILITY                 348
#define WBLI_CAE_4ABAQUS                  236
#define WBLI_CAE_4SAMCEF                  237
#define WBLI_CAE_4NASTRAN                 238
#define WBLI_SOLVER_ANSYS                 750
#define WBLI_SOLVER_MBD                   751
#define WBLI_SOLVER_AUTODYN               752
#define WBLI_SOLVER_FLUENT                753
#define KINEMATIC_CAPABILITY              260
#define DYNAMIC_CAPABILITY                264
#define PB_AUTODYN_CAPABILITY             420
#define WBLI_EXPLICIT_DYNAMIC             426
#define WBLI_EXPLICIT_DYNAOUT             428
#define WBLI_EXPLICIT_DYNAPREP            428
#define WBLI_EXPLICIT_EULER               1501
#define WBLI_TAS_CAPABILITY               385
#define ACIS_READER                       101
#define PARASOLID_READER                  102
#define SOLIDWORKS_PLUGIN                 103
#define SOLIDEDGE_PLUGIN                  104
#define MDT_PLUGIN                        105
#define INVENTOR_PLUGIN                   106
#define PROE_PLUGIN                       107
#define UG_PLUGIN                         108
#define CATIA4_READER                     109
#define ANSYS_GEOMETRY_PLUGIN             110
#define CATIA5_READER                     111
#define IGES_READER                       136
#define ONESPACEDESIGNER_PLUGIN           210
#define CAPRI_CATIA5_READER               235
#define PDM_IMAN                          229
#define DESIGN_EXPLORER_FULL              254
#define INTERFACE_TO_NASTRAN              261
#define INTERFACE_TO_ABACUS               262
#define ELECTROMAGNETIC                   263
#define WBFRAMEWORK                       265
#define PRESSURE_VESSEL_LOADS             1000
#define PRESSURE_VESSEL_DESIGN            1001
#define PRESSURE_VESSEL_CODAP             1002
#define PRESSURE_VESSEL_EN13445           1003
#define PRESSURE_VESSEL_ASME              1004
#define CFX_POST                          2000

typedef int PB_PRODUCT_NUMBER;

#define PB_PRODNUM_ANY           9999
#define PB_PRODNUM_UNKNOWN       -1

#define PB_PRODNUM_DSPE          1000
#define PB_PRODNUM_DMPE          1001
#define PB_PRODNUM_DSPE_CODAP    1002
#define PB_PRODNUM_DSPE_EN13445  1003
#define PB_PRODNUM_DSPE_ASME     1004
#define PB_PRODNUM_ALI_CAP       1500

#endif   // __ANSYS_PRODUCT_MECH_H__
