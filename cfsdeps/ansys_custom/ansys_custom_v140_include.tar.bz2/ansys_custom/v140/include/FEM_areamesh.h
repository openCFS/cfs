/*  FEM_areamesh.h */
/*
 * *** ansys(r) copyright(c) 2008
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_areamesh.h
 *  header file for FEM_areamesh.c
 *
 */

#ifndef FEM_AREAMESH_INCLUDE
#define FEM_AREAMESH_INCLUDE

#define EXIT_FAILURE_QMESH -100
#define EXIT_FAILURE_TMESH -101
#define EXIT_FAILURE_CLEAN -102
#define EXIT_FAILURE_FRONTINTERSECT -103
#define EXIT_FAILURE_BGMESH -104
#define EXIT_FAILURE_SMOOTHING -105
#define EXIT_NOT_MAPPABLE -113
#define EXIT_BOUNDARY_ALTERED -106

#define EXIT_WARNING_QMESH -110
#define EXIT_WARNING_CLEAN -112

#include "FEM_periodic.h"

#ifdef __cplusplus
extern "C" {
#endif
static INT fg_FEM_areaMeshMapMethod=2 ;


                              /* ============================================ */
                              /* === FEM_areamesh: do area meshing            */
                              /* ============================================ */
INT FEM_areamesh (
   INT anum,                  /* (IN) the area number                         */
   MESH_OBJ obj_mesh,         /* (IN) current mesh we are working on or adding*/
                              /*      to. The first numbound edges in the edge*/
                              /*      list are used as the loops for the      */
                              /*      current meshing process                 */
   INT numbound,              /* (IN) total number of nodes on bdry           */
   INT degen_quad,            /* (IN) flag - elements are degenerate quads    */
   INT shape,                 /* (IN) 3 = triangles, 4 = quad/tri             */
   INT mshkey,                /* (IN) 0 = Use free Mesher Always.             */
                              /*      1 = Use Map Mesher Always.              */
                              /*      2 = Use Map Mesher if possible, and if  */
                              /*          not, use the free mesher.           */
   INT command,               /* (IN) 2 = area meshing, 3 = vol meshing       */
   INT midnodes,              /* (IN) 1 = midnodes on edges                   */
   INT project,               /* (IN) 0 = project midnodes, 1 = striaght      */
   INT mesher,                /* (IN) 1 = 2D Delaunay, 2 = 2D Advancing front */
   INT layermesh,             /* (IN) 1 = generate a layer mesh               */
   PERIODIC_TYPE periodic,    /* (IN) whether a surface is periodic or not.   */
   INT debug,                 /* (IN) debug flag.                             */
   FEM_BOOLEAN *p_was_mapped );/* (OUT) return whether area was map meshed    */
                              /* ============================================ */

                              /* ============================================ */
                              /* === FEM_amNodesTo2DPeriodic: define the 2D   */
                              /* === parametric space for meshing and         */
                              /* === transform an array of 3D coords to 2D    */
                              /* === for a periodic surface.                  */
                              /* === Assumption: All nodes on the seam lines  */
                              /* === have been marked with the                */
                              /* === NODE_ON_SEAMLINE property.  All boundary */
                              /* === edges and nodes are at the fronts of     */
                              /* === their respective lists.                  */
                              /* === Return: EXIT_SUCCESS or EXIT_FAILURE     */
                              /* ============================================ */
INT FEM_amNodesTo2DPeriodic(
   INT anum,                  /* (IN) the current area number                 */
   INT num_bnd_nodes );       /* (IN) number of nodes to transform            */
                              /* ============================================ */

                              /* ============================================ */
                              /* === FEM_amNodesTo2D: define the 2D           */
                              /* === parametric space for meshing and         */
                              /* === transform an array of 3D coords to 2D    */
                              /* === Return: EXIT_SUCCESS or EXIT_FAILURE     */
                              /* ============================================ */
INT FEM_amNodesTo2D(
   INT anum,                  /* (IN)  The area number we are meshing.        */
   INT numbound );            /* (IN)  number of nodes to transform           */
                              /* ============================================ */
INT FEM_amAllNodesTo2D( INT anum );
                              /* ============================================ */
                              /* === FEM_amNodeTo2D: define the 2D parametric */
                              /* === space for meshing and transform an array */
                              /* === of 3D coords to 2D                       */
                              /* === Return: EXIT_SUCCESS or EXIT_FAILURE     */
                              /* ============================================ */
INT FEM_amNodeTo2D( 
   NODE_OBJ obj_node,          /* (IN)  the node to convert to 2d             */
   DOUBLE *p_uguess,           /* (IN)  u parametric guess. (OUT) u location  */
   DOUBLE *p_vguess,           /* (IN)  v parametric guess. (OUT) v location  */
   FEM_BOOLEAN no_guess );     /* (IN)  TRUE if no guess is available.        */

                              /* ============================================ */
                              /* === FEM_amNodesTo3D: project (transform) all */
                              /* === nodes to the 3D surface. Assumes all     */
                              /* === nodes on the area are at the top of the  */
                              /* === list                                     */
                              /* === Return: EXIT_SUCCESS or EXIT_FAILURE     */
                              /* ============================================ */
INT FEM_amNodesTo3D(
   INT anum,                 /* (IN) The area number */
   INT iSkipSeamlineNode );


                              /* ============================================ */
                              /* === FEM_amCleanFace: cleanip quads on an area */
                              /* === Return: EXIT_SUCCESS or EXIT_FAILURE     */
                              /* ============================================ */
INT FEM_amQuadCleanFace(
   INT anum,                  /* (IN) the area number                         */
                              /*      anum=0 indicates no area associativity. */
                              /*      Boundary loop vertices are all co-planar*/
   INT midnodes,              /* (IN) 1 = midnodes on edges                   */
   INT project );            /* (IN) 1 = project midnodes, 0 = striaght      */

INT FEM_shiftUvBack(
   INT anum ) ;

INT FEM_shiftUvAway( 
	INT area_id,        /* the area */
	INT *numLoop,       /* number of loops */
	INT *numLoopEdges);

INT FEM_amAreaNodesTo2D( 
   INT anum) ;

INT FEM_amListNodeTo2D(
   NODE_OBJ *aobj_nodes,
   INT num_nodes,
   INT area,
	INT interval);

INT FEM_amQuadTriMixedCleanup(
   INT anum,                  /* (IN) the area number                         */
   INT shape,                 /* (IN) 3 = triangles, 4 = quad/tri             */
   INT command,               /* (IN) 2 = area meshing, 3 = vol meshing , 4 = qmorph only   */
   INT highcurv,
   INT midnodes,              /* (IN) 1 = midnodes on edges                   */
   INT project,               /* (IN) 1 = project midnodes, 0 = striaght      */
   INT layermesh,             /* (IN) 1 = generate a layer mesh               */
   FEM_BOOLEAN was_mapped );  /* (OUT) return whether the area was map meshed */

INT FEM_amGetKpAreaAngle( INT anum, INT iKp, DOUBLE *angle );

INT FEM_amCheckInversion           ( INT anum );

void FEM_amCheckQuality( INT anum, FEM_BOOLEAN *qual_ok, DOUBLE *minMetrics );
void FEM_amCheckFaceEdgeQuality( INT anum, FEM_BOOLEAN *qual_ok, DOUBLE *minMetrics );
INT  FEM_amCheckAndImproveQuality( INT iAreaId, INT *piQualityOK );
#ifdef __cplusplus
}
#endif

#endif
