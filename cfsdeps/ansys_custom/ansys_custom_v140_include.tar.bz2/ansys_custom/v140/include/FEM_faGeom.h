/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 2009 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_faGeom.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_faGeom.h
 *  header file for FEM_faGeom.c
 *
 */
#ifndef FEM_FAGEOM_INCLUDE
#define FEM_FAGEOM_INCLUDE

/*----------------- Globally accessible function prototypes -----------------*/


#ifdef __cplusplus
extern "C" {
#endif
INT FEM_faFacetedNormal( 
   FACE_OBJ obj_face,
   INT		iUseFacets,
   DOUBLE	*xn,
   DOUBLE	*yn,
   DOUBLE	*zn );

#ifdef __cplusplus
}
#endif

#endif

