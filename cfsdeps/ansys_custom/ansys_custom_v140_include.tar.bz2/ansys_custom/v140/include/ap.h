/* ANSI_C ap.h - ANSYS Geometry Interface: "put" functions */

/*--------------------------------------------------------------------------*/
/* ansys(r) copyright(C) 2009 */
/* ansys, inc.                */
/*--------------------------------------------------------------------------*/

/* NOTE: This file requires "#include "ax.h" */

/*--------------------------------------------------------------------------*/

#ifndef __AX_P__  /* Include this file only once! */
#define __AX_P__ 

#ifdef __cplusplus
extern "C" {
#endif

/*--------------------------------------------------------------------------*/

ax_ENTITY ap_brep_solid (
                         ax_ENTITY brep_solid,
                         ax_ENTITY shell[],        /* [0..n-1] */
                         ax_BIT    shell_orient[], /* [0..n-1] */
                         ax_INDEX  shell_tree[],   /* [0..n-1] */
                         ax_INDEX  n
                         );

/*--------------------------------------------------------------------------*/

ax_ENTITY ap_shell (
                    ax_ENTITY shell,
                    ax_ENTITY face[],        /* [0..n-1] */
                    ax_BIT    face_orient[], /* [0..n-1] */
                    ax_INDEX  n
                    );

/*--------------------------------------------------------------------------*/

ax_ENTITY ap_face (
                   ax_ENTITY face,
                   ax_ENTITY surf,
                   ax_BIT    surf_orient,
                   ax_ENTITY loop[],         /* [0..n-1] */
                   ax_BIT    loop_orient[],  /* [0..n-1] */
                   ax_INDEX  loop_tree[],    /* [0..n-1] */
                   ax_INDEX  n
                   );

/*--------------------------------------------------------------------------*/

ax_ENTITY ap_loop (
                   ax_ENTITY loop,
                   ax_ENTITY edge[],         /* [0..n-1] */
                   ax_BIT    edge_orient[],  /* [0..n-1] */
                   ax_INDEX  n
                   );

/*--------------------------------------------------------------------------*/

ax_ENTITY ap_edge (
                   ax_ENTITY edge,
                   ax_ENTITY curve,
                   ax_BIT    curve_orient,
                   ax_ENTITY vertex_a,
                   ax_ENTITY vertex_b
                   );

/*--------------------------------------------------------------------------*/

ax_ENTITY ap_vertex (
                     ax_ENTITY vertex,
                     ax_ENTITY point
                     );

/*--------------------------------------------------------------------------*/

ax_ENTITY ap_nurbs_surf (
                         ax_ENTITY nurbs_surf,
                         ax_ENTITY cp,
                         ax_ENTITY uk,
                         ax_ENTITY vk,
                         ax_DEGREE p,
                         ax_DEGREE q,
                         ax_INDEX  n,
                         ax_INDEX  m,
                         ax_FLAGS  flags,
                         ax_INDEX  form
                         );

/*--------------------------------------------------------------------------*/

ax_ENTITY ap_plane (
                    ax_ENTITY plane,
                    ax_ENTITY placement
                    );

/*--------------------------------------------------------------------------*/

ax_ENTITY ap_cylindrical_surf (
                               ax_ENTITY cylindrical_surf,
                               ax_ENTITY placement,
                               ax_ENTITY radius
                               );

/*--------------------------------------------------------------------------*/

ax_ENTITY ap_conical_surf (
                           ax_ENTITY conical_surf,
                           ax_ENTITY placement,
                           ax_ENTITY radius,
                           ax_ENTITY semi_angle
                           );

/*--------------------------------------------------------------------------*/

ax_ENTITY ap_spherical_surf (
                             ax_ENTITY spherical_surf,
                             ax_ENTITY placement,
                             ax_ENTITY radius
                             );

/*--------------------------------------------------------------------------*/

ax_ENTITY ap_toroidal_surf (
                             ax_ENTITY toroidal_surf,
                             ax_ENTITY placement,
                             ax_ENTITY major_radius,
                             ax_ENTITY minor_radius
                             );

/*--------------------------------------------------------------------------*/

ax_ENTITY ap_revolution_surf (
                              ax_ENTITY revolution_surf,
                              ax_ENTITY swept_curve,
                              ax_ENTITY axis_point,
                              ax_ENTITY axis_vector,
                              ax_ENTITY start,
                              ax_ENTITY end
                              );

/*--------------------------------------------------------------------------*/

ax_ENTITY ap_linear_extrusion_surf (
                                    ax_ENTITY linear_extrusion_surf,
                                    ax_ENTITY gen_curve,
                                    ax_ENTITY ext_vector
                                    );

/*--------------------------------------------------------------------------*/

ax_ENTITY ap_nurbs_curve (
                          ax_ENTITY nurbs_curve,
                          ax_ENTITY cp,
                          ax_ENTITY kn,
                          ax_DEGREE p,
                          ax_INDEX  n,
                          ax_FLAGS  flags,
                          ax_FORM   form
                          );

/*--------------------------------------------------------------------------*/

ax_ENTITY ap_conic_arc (
                        ax_ENTITY conic_arc,
                        ax_ENTITY placement,
                        ax_REAL   a,
                        ax_REAL   b,
                        ax_REAL   c,
                        ax_REAL   d,
                        ax_REAL   e,
                        ax_REAL   f,
                        ax_FORM   form,
                        ax_ENTITY start_point,
                        ax_ENTITY end_point
                        );

/*--------------------------------------------------------------------------*/

ax_ENTITY ap_circular_arc (
                           ax_ENTITY circular_arc,
                           ax_ENTITY placement,
                           ax_ENTITY radius,
                           ax_ENTITY start_point,
                           ax_ENTITY end_point
                           );

/*--------------------------------------------------------------------------*/

ax_ENTITY ap_elliptical_arc (
                             ax_ENTITY elliptical_arc,
                             ax_ENTITY placement,
                             ax_ENTITY radius1,
                             ax_ENTITY radius2,
                             ax_ENTITY start_point,
                             ax_ENTITY end_point
                             );

/*--------------------------------------------------------------------------*/

ax_ENTITY ap_hyperbolic_arc (
                             ax_ENTITY hyperbolic_arc,
                             ax_ENTITY placement,
                             ax_ENTITY semi_axis1_length,
                             ax_ENTITY semi_axis2_length,
                             ax_ENTITY start_point,
                             ax_ENTITY end_point
                             );

/*--------------------------------------------------------------------------*/

ax_ENTITY ap_parabolic_arc (
                            ax_ENTITY parabolic_arc,
                            ax_ENTITY placement,
                            ax_ENTITY focal_distance,
                            ax_ENTITY start_point,
                            ax_ENTITY end_point
                            );

/*--------------------------------------------------------------------------*/

ax_ENTITY ap_line_segment (
                           ax_ENTITY line_segment,
                           ax_ENTITY start_point,
                           ax_ENTITY end_point
                           );

/*--------------------------------------------------------------------------*/

ax_ENTITY ap_polyline_segments (
                                ax_ENTITY polyline_segments,
                                ax_ENTITY point[],  /* [0..n-1] */
                                ax_INDEX  n,
                                ax_FLAGS  flags
                                );

/*--------------------------------------------------------------------------*/

ax_ENTITY ap_trimmed_curve (
                            ax_ENTITY trimmed_curve,
                            ax_ENTITY basis_curve,
                            ax_BIT    orient,
                            ax_ENTITY start_point,
                            ax_ENTITY end_point
                            );

/*--------------------------------------------------------------------------*/

ax_ENTITY ap_composite_curve (
                              ax_ENTITY composite_curve,
                              ax_ENTITY curve_segment[],         /* [0..n-1] */
                              ax_BIT    curve_segment_orient[],  /* [0..n-1] */
                              ax_FORM   transition_code[], /* NULL, [0..n-1] */
                              ax_INDEX  n,
                              ax_FLAGS  flags
                              );

/*--------------------------------------------------------------------------*/

ax_ENTITY ap_point (
                    ax_ENTITY point,
                    ax_REAL   coord[] /* [0..2] */
                    );

/*--------------------------------------------------------------------------*/

ax_ENTITY ap_point_2d (
                       ax_ENTITY point,
                       ax_REAL   coord[] /* [0..1] */
                       );

/*--------------------------------------------------------------------------*/

ax_ENTITY ap_cpoint_array (
                           ax_ENTITY cpoint_array,
                           ax_REAL a[],  /* [0..4*n-1] */
                           ax_INDEX n
                           );

/*--------------------------------------------------------------------------*/

ax_ENTITY ap_placement (
                        ax_ENTITY placement,
                        ax_ENTITY center_point,
                        ax_ENTITY axis_vector,
                        ax_ENTITY ref_vector
                        );

/*--------------------------------------------------------------------------*/

ax_ENTITY ap_vector (
                        ax_ENTITY vector,
                        ax_REAL   unit_vector[] /* [0..2] */
                        );

#define ap_direction  ap_vector /* downward compatibility */

/*--------------------------------------------------------------------------*/

ax_ENTITY ap_scalar (
                     ax_ENTITY scalar,
                     ax_REAL   value
                     );

/*--------------------------------------------------------------------------*/

ax_ENTITY ap_scalar_array (
                           ax_ENTITY scalar_array,
                           ax_REAL   v[],      /* [0..n-1] */
                           ax_INDEX  n
                           );

/*--------------------------------------------------------------------------*/

ax_ENTITY ap_unused (
                     ax_ENTITY unused
                     );

/*--------------------------------------------------------------------------*/

#if defined(__cplusplus)
}
#endif

#endif  /* #ifdef __AX_P__ */
