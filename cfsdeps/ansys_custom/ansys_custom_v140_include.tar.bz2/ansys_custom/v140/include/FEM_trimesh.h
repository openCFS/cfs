/*  FEM_trimesh.h */
/*
 * *** ansys(r) copyright(c) 2009
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_trimesh.h
 *  header file for FEM_trimesh.c
 *
 */
#ifndef FEM_TRIMESH_INCLUDE
#define FEM_TRIMESH_INCLUDE

                            /* ============================================== */
                            /* === FEM_trimesh: define a triangle mesh from a */
                            /* === set of node loops in 2D                    */
                            /* ============================================== */
INT FEM_trimesh (
   DOUBLE *a_coor2d,        /* (IN) array of 2D (uv) coords on boundary       */
   INT numbound,            /* (IN) total number of nodes on bdry             */
   INT *a_loops_begin,      /* (IN) node numbers for beginning of loops       */
   INT *a_loops_end,        /* (IN) node numbers for end of loops             */
   INT num_loops,           /* (IN) number of loops in area                   */
   INT *a_ibound,           /* (IN) node numbers of nodes on boundary         */
                            /*      already stored in ANSYS (including        */
                            /*      midnodes)                                 */
   INT degen_quad,          /* (IN) elements can be degenerate quads          */
   INT anum  );             /* (IN) the area number                           */


#endif
