#ifndef _ANSLONGOPT_H_
#define _ANSLONGOPT_H_

#define ANSLONGOPT_NO_ARGUMENT       0
#define ANSLONGOPT_REQUIRED_ARGUMENT 1
#define ANSLONGOPT_OPTIONAL_ARGUMENT 2

#include "ali_string_utilities.h"

#if defined(c_plusplus) || defined(__cplusplus)
#  define anslongoptext extern "C"

#  include <string>
#  include <deque>
#  include <list>
#  include <map>

#  if !defined(HP_SYS) || defined(_HP_NAMESPACE_STD)
      using namespace std;
#  endif

   class ans_mutex;
   class CAnsLongCommandLine;

#  define ANSLONGOPT_HEADER      0xffff
#  define ANSLONGOPT_DISP_WIDTH  150

   class CAnsLongOpt
   {
      public:
         CAnsLongOpt() : 
            m_pCmndLine(NULL),
            m_iOptId(-1),
            m_iArgType(ANSLONGOPT_NO_ARGUMENT),
            m_bHidden(false)
         {
            init();
         }
         CAnsLongOpt(int iOptId, ALI_STRING sName, ALI_STRING sDesc, bool bHide = false) : 
            m_pCmndLine(NULL),
            m_iOptId(iOptId),
            m_sName(sName),
            m_sDesc(sDesc),
            m_iArgType(ANSLONGOPT_NO_ARGUMENT),
            m_bHidden(bHide)
         {
            init();
         }
         CAnsLongOpt(int iOptId, ALI_STRING sName, ALI_STRING sDesc, int iHasArg, bool bHide = false) :
            m_pCmndLine(NULL),
            m_iOptId(iOptId),
            m_sName(sName),
            m_sDesc(sDesc),
            m_iArgType(iHasArg),
            m_bHidden(bHide)
         {
            init();
         }
         CAnsLongOpt(int iOptId, ALI_STRING sName, ALI_STRING sDesc, ALI_STRING sArg, int iHasArg, bool bHide = false) :
            m_pCmndLine(NULL),
            m_iOptId(iOptId),
            m_sName(sName),
            m_sDesc(sDesc),
            m_sArg(sArg),
            m_iArgType(iHasArg),
            m_bHidden(bHide)
         {
            init();
         }
         CAnsLongOpt(ALI_STRING sDesc) :
            m_pCmndLine(NULL),
            m_iOptId(ANSLONGOPT_HEADER),
            m_sDesc(sDesc),
            m_iArgType(ANSLONGOPT_NO_ARGUMENT),
            m_bHidden(false)
         {
            init();
         }
         virtual ~CAnsLongOpt();

         void output_help_description(int iDescIndent);

         ALI_STRING get_cmndline_option();
         ALI_STRING get_option(int iLen = -1);
         void set_option(struct ali_option*);
         bool is_hidden(void) {return m_bHidden;}
         bool has_arg(void) {return get_arg_type() != ANSLONGOPT_NO_ARGUMENT;}
         int get_arg_type(void) {return m_iArgType;}
         int get_option_id(void) {return m_iOptId;}

      protected:
         void display_description(ALI_STRING sOutText, int iDescIndent);

      private:
         CAnsLongCommandLine* m_pCmndLine;

         int m_iOptId;
         ALI_STRING m_sName;
         ALI_STRING m_sDesc;
         ALI_STRING m_sArg;

         int m_iArgType;

         bool m_bHidden;

         void init(void);
   };

   class CAnsLongCommandLine
   {
      public:
         static CAnsLongCommandLine* get_instance();
         static void free_instance();

      public:
         CAnsLongCommandLine() : m_szCurrentArgument(NULL), m_bIgnoreUnknownOpts(false)
         {
         }
         virtual ~CAnsLongCommandLine();

         void add_option_definition(CAnsLongOpt* pNew);
         void usage(int iDescIndent = -1);
         void ignore_unknown_options(bool bIgnore = true) {m_bIgnoreUnknownOpts = bIgnore;}

         bool initialize_arguments(int argc, ALI_CHAR *argv[]);
         bool initialize_arguments(list<ALI_STRING> listArgs);
         bool have_option_remaining(void) {return !m_listArguments.empty();}
         bool get_next_argument(int iStopAtOption, ALI_CHAR** pszArg);

         int get_next_option(ALI_CHAR** pszArg);
         int get_option_count(void) {return (int)m_dequeLongOpts.size();}

         CAnsLongOpt* get_anslongopt(const ALI_CHAR* szOpt);
         CAnsLongOpt* get_anslongopt(const int iOptId);

         ALI_STRING get_command(void) {return m_sExe;}

      protected:
         static CAnsLongCommandLine* s_pCommandLine;
         static ans_mutex* s_mutexClear;

         ALI_STRING m_sExe;
         list<ALI_STRING> m_listArguments;
         list<ALI_STRING> m_listOrigArguments;
         ALI_CHAR* m_szCurrentArgument;
         bool m_bIgnoreUnknownOpts;

         deque<CAnsLongOpt*> m_dequeLongOpts;
         deque<CAnsLongOpt*> m_dequeOtherOpts;
         map<ALI_STRING, list<CAnsLongOpt*> > m_mapLongOpts;

         bool is_option(ALI_STRING sArg);
         bool get_current_argument(ALI_CHAR** pszArg);
   };
#else
#	define anslongoptext extern
#endif

anslongoptext void anslongopt_initialize(int argc, ALI_CHAR *argv[]);
anslongoptext void anslongopt_initialize_from_string(ALI_CHAR* wszCommandLine);
anslongoptext void anslongopt_ignore_unknown_options(void);
anslongoptext void anslongopt_free();

anslongoptext int anslongopt_get_next_argument(int iStopAtOption, ALI_CHAR** pszArg);
anslongoptext int anslongopt_get_next_option(ALI_CHAR** pszArg);
anslongoptext int anslongopt_get_option_count(void);
anslongoptext int anslongopt_have_option(void);

anslongoptext void anslongopt_usage(int iDescIndent);

#endif   /* _ANSLONGOPT_H_ */
