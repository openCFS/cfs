#ifndef _DECOMP_H_
#define _DECOMP_H_

#include "Connectivity.h"


class Elemset;

class Decomposition {
  public:
     INT nsub;      // Number of subdomains
     INT *pele;     // poINTer INTo eln
     INT *eln;      // List of elements in each subdomain


     enum Alg { Greedy , Experimental } ;

     Decomposition() {}
     ~Decomposition() {}
     Decomposition(INT ns, INT *pe, INT *el) { nsub = ns; pele = pe; eln = el; }

     void greedyBuild(INT, Connectivity *etoe, Connectivity *ntoe, 
                      Connectivity*eton);
     void cpuGreedyBuild(INT,Connectivity *etoe, Connectivity *ntoe, 
                         Connectivity*eton, long *sizes, INT numSub);
     void newGreedyBuild(INT nsub, Connectivity *ntoe,
                      Connectivity*eton);

     INT num(INT i) { return pele[i+1]-pele[i]; }
     INT *operator[](INT i) { return eln + pele[i]; }

     void toAnsys(INT *, INT *, INT *, Connectivity *, Connectivity *,
           Elemset *);
     // ObjDisplayer *controler();

     void outputDump(FILE *,INT);
};

#endif
