/*    geom.h                                kz372              */
/* 
 * *** copyright(c) 2010 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */

/*  Get/Inquire the cells that are defined on a map*/ 
INT 
CALLTYP xAnsysMapCells_ ansPROTO((
     xINT  *map,
     INT  *cells,
     INT  *flag 
));

/*  Get the map type for a map*/ 
INT 
CALLTYP xAnsysMapType_ ansPROTO((
  xINT *map 			/* I: Map */
));

/*  Get the map form for a map*/ 
INT 
CALLTYP xAnsysMapForm_ ansPROTO((
  xINT *map 			/* I: Map */
));
