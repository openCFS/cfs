
/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 2009 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_InOut.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_InOut.h
 *  header file for FEM_InOut.c
 *
 */
#ifndef FEM_INOUT_INCLUDE
#define FEM_INOUT_INCLUDE

#include "FEM_cdbtypes.h"

/*----------------- Globally accessible constants ---------------------------*/
#define REFINEMENT_SETUP       (1<<0)
#define SMOOTHING_SETUP        (1<<1)
#define CLEANUP2D_SETUP        (1<<2)
#define QUAD_CONV_SETUP        (1<<3)

/*----------------- Globally accessible function prototypes -----------------*/


/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* +++++++++++++++ Routines to initialize and Fill MeshToolBox +++++++++++++ */
/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

                             /* ============================================ */
                             /* === FEM_ioInitMeshToolBox:  Initialize the   */
                             /* === Mesh ToolBox.  this routine must be      */
                             /* === called before doing anything in the      */
                             /* === Mesh TookBox.                            */
                             /* === Return: 0 is successful, otherwise 1.    */
                             /* ============================================ */
INT FEM_ioInitMeshToolBox (
   INT num_nodes  );         /* (IN) approximate number of nodes that will be*/
                             /*      stored in the Mesh ToolBox.  Used to    */
                             /*      guess basic size for initialization.    */
                             /* ============================================ */

                             /* ============================================ */
                             /* === FEM_ioStoreOneNode:  Store a single node */
                             /* === in the MeshToolBox.                      */
                             /* === Return: 0 is successful, otherwise 1.    */
                             /* ============================================ */
INT FEM_ioStoreOneNode (
   INT id,                   /* (IN)  id of new node to store.               */
   DOUBLE a_xyz[3],          /* (IN)  location of new node                   */
   DOUBLE a_uv[2],           /* (IN)  parametric location of new node.  If   */
                             /*       node is on a line, only a_uv[0] is     */
                             /*       used.  If node is on a kp or volume,   */
                             /*       both are ignored.                      */
   INT geo_entity,           /* (IN)  id of geo entity node is on            */
   INT geo_type,             /* (IN)  identifier specifying what type of geo */
                             /*       entity the node lies on:               */
                             /*         1: node is on a keypoint             */
                             /*         2: node is on a line                 */
                             /*         3: node is on a area                 */
                             /*         4: node is in a volume               */
   INT midnode,              /* (IN)  1 if the node is a midnode, 0 if the   */
                             /*       node is a corner node.                 */
   INT *new  );              /* (OUT) returned as 0 if there was already a   */
                             /*       node with the same id.  If so, the     */
                             /*       previous node was overwritten in place */
                             /*       of this new node.  returned as 1 if    */
                             /*       there was no node with that id.        */
                             /* ============================================ */

                             /* ============================================ */
                             /* === FEM_ioStoreOneElem:  Store a single elem */
                             /* === in the MeshToolBox.                      */
                             /* === Return: 0 is successful, otherwise 1.    */
                             /* ============================================ */
INT FEM_ioStoreOneElem (
   INT id,                   /* (IN)  id of new elem to store.               */
   INT *a_nodeids,           /* (IN)  list of nodes defining element.  Node  */
                             /*       are not duplicated for degenerate elems*/
   INT geo_entity,           /* (IN)  id of geo entity element is in.  If    */
                             /*       shape <= 3, geo_entity is the area id. */
                             /*       if shape > 3, geo_entity is the vol id.*/
   INT shape,                /* (IN)  identifier specifying what shape the   */
                             /*       element is.                            */
                             /*         1: Triangle                          */
                             /*         2: quadrilateral that degenerated    */
                             /*            into a triangle.                  */
                             /*         3: quadrilateral.                    */
                             /*         4: Tetrahedra                        */
                             /*         5: Hex, that degenerated into a tet  */
                             /*         6: Pyramid                           */
                             /*         7: Hex, that degenerated into a      */
                             /*            pyramid                           */
                             /*         8: Wedge                             */
                             /*         9: Hex, that degenerated into a wedge*/
                             /*        10: Hex                               */
   INT midnodes  );          /* (IN) TRUE if the element has midnodes.       */
                             /* ============================================ */

                             /* ============================================ */
                             /* === FEM_ioFinishFillingToolBox:  Signifies   */
                             /* === the Mesh ToolBox has been filled with    */
                             /* === starting mesh.  This routine finishes    */
                             /* === initializing datastructure for the       */
                             /* === upcoming operation.                      */
                             /* === Return: 0 is successful, otherwise 1.    */
                             /* ============================================ */
INT FEM_ioFinishFillingToolBox (
   FEM_LONG process,         /* (IN) Indicates what the upcoming operation   */
                             /*      will be.  See FEM_InOut.h               */
   INT detached,             /* (IN) 1 if no solid model attachment,         */
                             /*      otherwise 0                             */
   INT* a_areas,             /* (IN) array of area ids that will need be     */
                             /*      involved in the upcoming operation      */
                             /*      (i.e. all areas that have face elements */
                             /*      or area adjacent to volumes are meshed  */
                             /*      with volume elements.                   */
   INT num_areas,            /* (IN) length of a_areas                       */
   INT next_nodeid,          /* (IN) id available for start numbering of new */
                             /*      nodes created in the upcoming operation.*/
   INT next_elemid  );       /* (IN) id available for start numbering of new */
                             /*      elems created in the upcoming operation.*/

                             /* ============================================ */
                             /* === FEM_ioKillMeshToolBox:  Free up all      */
                             /* === memory used by the MeshToolBox, deleting */
                             /* === the current mesh.  No more MeshToolBox   */
                             /* === operations can be done until             */
                             /* === FEM_ioInitMeshToolBox and                */
                             /* === FEM_ioFinishFillingMeshToolBox are       */
                             /* === called again.                            */
                             /* === Return: 0 is successful, otherwise 1.    */
                             /* ============================================ */
INT FEM_ioKillMeshToolBox ( void  );
                          
                      
/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* +++++++++++ Routines to Retrieve data from the MeshToolBox ++++++++++++++ */
/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

                             /* ============================================ */
                             /* === FEM_ioGetFirstNode: Get the first node   */
                             /* === Stored in the MeshToolBox in preparation */
                             /* === to loop through all the node stored.     */
                             /* === Return: 0 if no nodes in list, otherwise */
                             /* === a (void *) used to get next node in list.*/
                             /* ============================================ */
void* FEM_ioGetFirstNode (
   INT *id,                  /* (OUT) id of first node in list               */
   DOUBLE a_xyz[3],          /* (OUT) location of first node in list         */
   INT *geo_entity,          /* (OUT) id of geo entity of first node in list */
   INT *geo_type,            /* (OUT) type of geo entity  of first node in   */
                             /*       list (See FEM_ioStoreOneNode for       */
                             /*       possible values.)                      */
   INT *midnode  );          /* (OUT) returned as 1 if the first node is a   */
                             /*       midnode.  Otherwise 0.                 */

                             /* ============================================ */
                             /* === FEM_ioGetNextNode: Get the next node     */
                             /* === stored in the MeshToolBox.               */
                             /* === Return: 0 if no more nodes in list,      */
                             /* === otherwise a (void *) used to get next    */
                             /* === node in list.                            */
                             /* ============================================ */
void* FEM_ioGetNextNode (
   void *lastnode,           /* (IN)  the last node retrieved. (return value */
                             /*       from FEM_ioGetFirstNode or             */
                             /*       FEM_ioGetNextNode)                     */
   INT *id,                  /* (OUT) id of next node in list                */
   DOUBLE a_xyz[3],          /* (OUT) location of next node in list          */
   INT *geo_entity,          /* (OUT) id of geo entity of next node in list  */
   INT *geo_type,            /* (OUT) type of geo entity  of next node in    */
                             /*       list (See FEM_ioStoreOneNode for       */
                             /*       possible values.)                      */
   INT *midnode  );          /* (OUT) returned as 1 if the next node is a    */
                             /*       midnode.  Otherwise 0.                 */
                             /* ============================================ */

                             /* ============================================ */
                             /* === FEM_ioGetFirstFaceElem: Get the first    */
                             /* === face elem stored in the MeshToolBox in   */
                             /* === preparation to loop through all the      */
                             /* === face elems stored.                       */
                             /* === Return: 0 if no face elems in list,      */
                             /* === otherwise a (void *) used to get next    */
                             /* === elem in list.                            */
                             /* ============================================ */
void * FEM_ioGetFirstFaceElem (
   INT *id,                  /* (OUT) id of first face elem.                 */
   INT *a_nodeids,           /* (OUT) list of nodes defining element.  Node  */
                             /*       are not duplicated for degenerate elems*/
   INT *area_id,             /* (OUT) id of area this element is in.         */
   INT *shape,               /* (OUT) identifier specifying what shape the   */
                             /*       element is.                            */
                             /*         1: Triangle                          */
                             /*         2: quadrilateral that degenerated    */
                             /*            into a triangle.                  */
                             /*         3: quadrilateral.                    */
   INT *midnodes  );         /* (OUT) TRUE if the element has midnodes.       */
                             /* ============================================ */

                             /* ============================================ */
                             /* === FEM_ioGetNextFaceElem: Get the next face */
                             /* === elem stored in the MeshToolBox.          */
                             /* === Return: 0 if no more face elems in list, */
                             /* === otherwise a (void *) used to get next    */
                             /* === elem in list.                            */
                             /* ============================================ */
void * FEM_ioGetNextFaceElem (
   void *lastfaceelem,       /* (IN)  last face element retrieved.  (return  */
                             /*       value from FEM_ioGetFirstElem or       */
                             /*       FEM_ioGetNextElem)                     */
   INT *id,                  /* (OUT) id of next face elem.                  */
   INT *a_nodeids,           /* (OUT) list of nodes defining element.  Node  */
                             /*       are not duplicated for degenerate elems*/
   INT *area_id,             /* (OUT) id of area element is on.              */
   INT *shape,               /* (OUT) identifier specifying what shape the   */
                             /*       element is.                            */
                             /*         1: Triangle                          */
                             /*         2: quadrilateral that degenerated    */
                             /*            into a triangle.                  */
                             /*         3: quadrilateral.                    */
   INT *midnodes  );         /* (OUT) TRUE if the element has midnodes.       */
                             /* ============================================ */

                             /* ============================================ */
                             /* === FEM_ioGetFirstVolElem: Get the first vol */
                             /* === elem stored in the MeshToolBox in        */
                             /* === preparation to loop through all the vol  */
                             /* === elems stored.                            */
                             /* === Return: 0 if no vol elems in list,       */
                             /* === otherwise a (void *) used to get next    */
                             /* === elem in list.                            */
                             /* ============================================ */
void * FEM_ioGetFirstVolElem (
   INT *id,                  /* (OUT) id of vol first elem.                  */
   INT *a_nodeids,           /* (OUT) list of nodes defining element.  Node  */
                             /*       are not duplicated for degenerate elems*/
   INT *vol_id,              /* (OUT) id of volume this element is in.       */
   INT *shape,               /* (OUT) identifier specifying what shape the   */
                             /*       element is.                            */
                             /*         4: Tetrahedra                        */
                             /*         5: Hex, that degenerated into a tet  */
                             /*         6: Pyramid                           */
                             /*         7: Hex, that degenerated into a      */
                             /*            pyramid                           */
                             /*         8: Wedge                             */
                             /*         9: Hex, that degenerated into a wedge*/
                             /*        10: Hex                               */
   INT *midnodes  );         /* (OUT) TRUE if the element has midnodes.       */
                             /* ============================================ */

                             /* ============================================ */
                             /* === FEM_ioGetNextVolElem: Get the next volume*/
                             /* === elem Stored in the MeshToolBox in        */
                             /* === preparation to loop through all the      */
                             /* === elems stored.                            */
                             /* === Return: 0 if no more volume elems in     */
                             /* === list, otherwise a (void *) used to get   */
                             /* === next elem in list.                       */
                             /* ============================================ */
void * FEM_ioGetNextVolElem (
   void *lastvolelem,        /* (IN)  last vol element retrieved.  (return   */
                             /*       value from FEM_ioGetFirstElem or       */
                             /*       FEM_ioGetNextElem)                     */
   INT *id,                  /* (OUT) id of next elem.                       */
   INT *a_nodeids,           /* (OUT) list of nodes defining element.  Node  */
                             /*       are not duplicated for degenerate elems*/
   INT *vol_id,              /* (OUT) id of volume this element is in.       */
   INT *shape,               /* (OUT) identifier specifying what shape the   */
                             /*       element is.                            */
                             /*         4: Tetrahedra                        */
                             /*         5: Hex, that degenerated into a tet  */
                             /*         6: Pyramid                           */
                             /*         7: Hex, that degenerated into a      */
                             /*            pyramid                           */
                             /*         8: Wedge                             */
                             /*         9: Hex, that degenerated into a wedge*/
                             /*        10: Hex                               */
   INT *midnodes  );         /* (OUT) TRUE if the element has midnodes.       */
                             /* ============================================ */
#endif

