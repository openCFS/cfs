/* sid 60.20 copy of INIS_Database.h last changed by jtm on 2006/05/15 19:43:21 */
/* ---------------------------------------------------------------------- */
/* *** copyright(c) 2011 SAS IP, Inc.  All rights reserved. */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */

#include "ansys.h"

#if !defined(INIS_DATABASE_H)
#define INIS_DATABASE_H

#include "INIS_DataCollection.h"
#include "INIS_Object.h"
#include "INIS_ElementData.h"
#include "INIS_NodalData.h"

/* Data Stucture for Individual Data */
/*Data Structure for a Collection of Data */

/* Has information on element type */
/* Primarily to dictate the size of the data for each element */
struct INIS_ElementTemplate : public INIS_Object
{
    INIS_ElementTemplate() ;

    ~INIS_ElementTemplate() ;
    
    void SetParams( INT iNumLays, INT iNumIntPts ) ;
    //R
    //I iNumLays
    //- Number Of Layers
    //I iNumSects
    //- Number Of Sections
    //I iNumIntPts
    //- Num Gauss Integration Pts
    //- Sets the necessary parameters

    INT m_iNumNodes ;
    INT m_iNumLayers ;
    INT m_iNumIntegrationPoints ;
    INT* m_pNumIntPtsInLayer ;
    INT m_iIs3DElement ;
} ;

class INIS_ElementTemplateArray : public INIS_Object
{
    public:

    INIS_ElementTemplateArray() ;

    ~INIS_ElementTemplateArray() ;

    struct INIS_ElementTemplate** m_ppElemTempate ;
    /* Array of Element Templates*/
    INT*                   m_pElementTypeIndex ;
    /* Array of Element Type Indices*/
} ;

class INIS_Database : public INIS_Object
{
    public:

    INIS_Database();
    //Constructor

    ~INIS_Database();
    //Destructor

    void SetDatabaseType(INT iType) { if ( iType < 0 || iType > 1 ) return ; m_iDatabaseType = iType ; }
    //Set Database type 0 for Element Based, 1 for node based

    INT GetDatabaseType() { return m_iDatabaseType; }

    INT GetWrittenDoubleArraySize() ;
    //R Gets Written Database Size

    bool ConstructFromDoubleArray( DOUBLE* pISData, INT iPos, INT iSz ) ;
    //R Status
    //O pISData
    //O-Array to Write the Data from
    //O iStart
    //O Position in array from which to start reading
    //O iSz
    //O-Size of Array
    //- Read from Ansys DB format array

    bool WriteToDoubleArray( DOUBLE* pISData, INT iPos, INT iSz, INT iWrittenSz ) ;
    //R Status
    //O pISData
    //O-Array to Write the Data to
    //O iStart
    //O Position in array from which to start writing to
    //O iWrittenSz
    //O-Size of Data Written
    //- Write in Ansys DB format to array


    bool SetData( INT iDBType, INT* pPar, INT iNumPar,
                  DOUBLE* pData, INT iDataSize, INT iDataType ) ;
    //R Result
    //I iDBType
    //I-Database Type 0 for Element Based, 1 for Node Based
    //I pPar
    //I-Parameters
    //I iNumPar
    //I Num Parameters
    //I pData
    //I iDataSize
    //- Sets Initial State Data

    bool LoadCache(DOUBLE* pISData) ;
    //R Result
    //I pISData
    //I-Initial State Data

    INIS_ElementData* m_pElemINISData ;
    /* Element Has Data for each intpt,secpt,layerid combination */

    INIS_NodalData* m_pNodeBasedData ;
    //Node based initial state

    INT m_iElemId ;
    /* Current Element Id*/

    INIS_ElementTemplateArray* m_pElemTemplateArray ;
    /* Maximum Possible Element Id*/

    INT m_iDatabaseType ;
    //0 Element Based
    //1 Node Based
} ;

class INIS_CommandParams : public INIS_Object
{
    public:

    void * operator new(size_t iMemSize )
    {
        return ANS_MALLOC(iMemSize) ;
    }

    void * operator new[]( size_t iSize )
    {
        return ANS_MALLOC(iSize) ;
    }

    void operator delete(void * pMemPtr)
    {
            ANS_FREE(pMemPtr) ;
    }

    void operator delete[](void * pMemPtr )
    {
            ANS_FREE(pMemPtr) ;
    }

    INIS_CommandParams() ;
    //Constructor

    INT m_iCSID ;
    INT m_iDataType ;
    INT m_iMatId ;
    INT m_iStorageType ;
};
//Code to store the Parameters necessary for Initial State Data

extern int g_iMaxRecSize ;
extern INT g_iINIS_NewVersionUsed ;
extern INT g_iINIS_IStrainUsed ;
extern INT g_iINIS_Write ;
extern INT g_iINIS_SSToWrite ;
extern INT g_iINIS_LSToWrite ;
extern INT g_iINIS_DTypesToWrite[INIS_MAXDATATYPES] ;
#endif
