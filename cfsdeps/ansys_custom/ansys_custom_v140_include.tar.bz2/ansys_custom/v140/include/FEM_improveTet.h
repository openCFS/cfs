/*  FEM_improveTet.h */
/*
 * *** ansys(r) copyright(c) 2009
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  ***     */
/*
 *  FEM_improveTet.h
 *  header file for FEM_improveTet.c
 *
 */
#ifndef FEM_IMPROVE_TET_INCLUDE
#define FEM_IMPROVE_TET_INCLUDE


#ifdef __cplusplus
extern "C" {
#endif

/* --- Error flags used in FEMe_Error for TET_IMPROVE */

/*----------------- Globally accessible function prototypes -----------------*/

                              /* =========================================== */
                              /* === FEM_improveTet: improve a given tet     */
                              /* === mesh (in a global data structure,       */
                              /* === possibly containing non-tet elements)   */
                              /* === by applying flips to transformable      */
                              /* === transformable interior faces, based on  */
                              /* === local empty circumsphere criterion or   */
                              /* === local max-min tetrahedron shape measure */
                              /* === criterion; all tets must be put in      */
                              /* === NEGATIVE volume vertex order since shape*/
                              /* === measure functions calculate signed      */
                              /* === values (positive for NEGATIVE volume);  */
                              /* === shape measures for each tet should      */
                              /* === already be set if mtype >= 1; generic   */
                              /* === pointer field for all faces should be   */
                              /* === NULL on entry                           */
                              /* =========================================== */
INT FEM_improveTet (
   FEM_BOOLEAN bndcon,        /* (IN) TRUE if boundary is constrained        */
                              /*      (no T22 flips); FALSE if only          */
                              /*      certain boundary edges may be          */
                              /*      constrained                            */
   FEM_BOOLEAN combfl,        /* (IN) TRUE iff combination of flips are      */
                              /*      to be applied to improve               */
                              /*      triangulation further                  */
   INT mtype,                 /* (IN) measure type                           */
                              /*      (1 to 4 or 0 for empty ccsph)          */
   FEM_BOOLEAN midnode,       /* (IN) TRUE if quadratic elements             */
   INT nexpass,               /* (IN) number of expensive passes for         */
                              /*      combination flips when mtype > 0;      */
                              /*      after nexpass passes, combination      */
                              /*      flips are only used to remove          */
                              /*      tets with measure < minratio           */
   DOUBLE minratio,           /* (IN) ratio < minratio considered poorly     */
                              /*      shaped (not used for mtype 0)          */
   FEM_BOOLEAN *abort  );     /* (OUT) return TRUE (with EXIT_SUCCESS)       */
                              /*       if user abort occurred                */

/* ************** Further comments on usage of FEM_improveTet **************

   a) Possible mtype values are EMPTY_CCSPH (0), MIN_SOL_ANG (1),
      RADIUS_RATIO (2), MEAN_RATIO (3), and QUAD_MEAN_RATIO (4).
      The first is used to get a "constrained Delaunay" triangulation.
      The last can only be used for quadratic tets (midnode is TRUE);
      the others can be used for both linear and quadratic tets.
      Measure values for mtype = 1, 2, and 3 range from 0 to 1 (for poorly
      shaped tet to regular tet). Negative measure values occur for inverted
      tets (absolute value is measure of unoriented tet).
      For mtype = 4, the maximum may be larger than 1; no measure larger
      than 2 has been observed so far. The quadratic mean ratio is not
      really a shape measure; it is an estimate of shape quality based
      on samples of Jacobian determinant and quadratic version of mean
      ratio using volume and arclength approximations.
   b) Midnodes do not have to be present on all edges. Any missing midnode is
      taken to be the midpoint of edge for quadratic tet measure evaluation.
   c) The initial shape measures of tets can be set by calling function
      FEM_imInitElemMetric. They are set and updated in the shape metric
      field of the C meshing data structure.
   d) The generic pointer field for faces can be set to NULL using function
      FEM_faClearGenericPointers, if their status is not known on entry.
      On normal exit, all generic pointers for faces will be NULL.
   e) The other fields that must be set in C data structure are node
      coordinates and adjacency info for tets, faces, and edges in
      triangulation.
   f) Interior faces can be constrained by setting the FACE_ON_AREA property
      flag to TRUE. 4-4 flips are not performed if the coplanar adjacent
      faces of configuration lie on different areas.
   g) If bndcon is FALSE, then 2-2 flips may be performed on faces with
      no geo entity (area number) or with an area number that has been
      cached as modifiable (the flipped-out edge must not have
      EDGE_ON_LINE property).
   h) Non-tet elements (e.g. pyramids, wedges, hexes) may be present in
      mesh. Flipping is applied to tet elements only.
   i) Constrained faces may have FACE_CONSTRAINED property set, and
      constrained elements may have ELEM_CONSTRAINED property set;
      all faces of constrained elements should be FACE_CONSTRAINED.
      All FACE_CONSTRAINED faces should be moved to rear of face list using
      FEM_faPlaceAtRear, and all ELEM_CONSTRAINED elements should be moved
      to rear of element list using FEM_elPlaceAtRear. This movement is done
      for efficiency since lists will be traversed until first constrained
      entity or end of list, whichever occurs first.
   j) The global relative tolerance used in the flipping routines should
      be set to about DBL_EPSILON*1.0e2 to DBL_EPSILON*1.0e6 depending on
      number of correct significant digits in input data; default value is
      DBL_EPSILON*1.0e2. Function FEM_teSetTolerance can be used to
      initialize tolerance.
   k) See file fem_swapnsmo_.c for example of required initialization.

   ************** End of comments on usage of FEM_improveTet *************** */


                              /* =========================================== */
                              /* === FEM_imTetCorNodes: get the corner nodes */
                              /* === of tet element                          */
                              /* =========================================== */
INT FEM_imTetCorNodes (
   ELEMENT_OBJ obj_element,   /* (IN)  tet element object                    */
   NODE_OBJ aobj_node[4]  );  /* (OUT) array of 4 node objects returned      */

                              /* =========================================== */
                              /* === FEM_imInitElemMetric: initialize shape  */
                              /* === metric field for all unconstrained elems*/
                              /* === (tets, pyramids, etc.) in possibly mixed*/
                              /* === mesh (metric currently set to arbitrary */
                              /* === value for wedges and hexes); it is      */
                              /* === assumed all constrained elements are    */
                              /* === moved to rear of elem list              */
                              /* =========================================== */
DOUBLE FEM_imInitElemMetric (
   INT mtype,                 /* (IN)      measure type (1 to 4)             */
   INT vnum );                /* (IN)    volume number                       */

                              /* =========================================== */
                              /* === FEM_imFlipShapeMeasure: apply flips in  */
                              /* === 3D region triangulation to transformable*/
                              /* === interior faces, based on local max-min  */
                              /* === tet shape measure criterion, until all  */
                              /* === faces are mu-locally-optimal            */
                              /* =========================================== */
INT FEM_imFlipShapeMeasure (
   FEM_BOOLEAN bndcon,        /* (IN) TRUE iff boundary is constrained       */
                              /*      (no T22 flips)                         */
   INT mtype,                 /* (IN) measure type (1 to 4)                  */
   DEQUE_OBJ obj_queue,       /* (IN) queue of interior faces to be          */
                              /*      tested for optimal                     */
   FEM_BOOLEAN midnode  );    /* (IN) TRUE if quadratic elements             */

                              /* =========================================== */
                              /* === FEM_imAddFace: add face to bottom of    */
                              /* === queue if it is interior face and not    */
                              /* === yet in queue                            */
                              /* =========================================== */
INT FEM_imAddFace (
   FACE_OBJ obj_fac,          /* (IN)  face object                           */
   DEQUE_OBJ obj_queue  );    /* (OUT) queue of interior faces to be tested  */
                              /*       for optimal.  obj_fac may be added to */
                              /*       queue.                                */

                              /* =========================================== */
                              /* === FEM_imUninvertQuadTets: un-invert any   */
                              /* === inverted quad tets (with nonpositive    */
                              /* === metric) by moving midnodes towards      */
                              /* === midpoints                               */
                              /* =========================================== */
INT FEM_imUninvertQuadTets (
   INT mtype,                 /* (IN)  quadratic measure type                */
   FEM_BOOLEAN change_bound,  /* (IN)  TRUE if boundary can be modified      */
   FEM_BOOLEAN msg_on,        /* (IN)  TRUE if error message displayed       */
                              /*       for inverted tets that cannot be      */
                              /*       un-inverted                           */
   INT *ninvtet,              /* (OUT) return number of inverted tets        */
   INT *nmidmov_ncb  );       /* (OUT) return count of midnode moves on      */
                              /*       non-changeable boundary parts         */

                      /* === Process queue to make all interior faces */
                      /* === locally optimal                          */
INT FEM_imFlipDelaunay       ( FEM_BOOLEAN bndcon, 
                               DEQUE_OBJ obj_queue,
                               NODE_OBJ obj_vert, 
                               ELEMENT_OBJ *pobj_tet,
                               FEM_BOOLEAN midnode );
INT fem_imImproveDelaunay    ( FEM_BOOLEAN bndcon, 
                                   INT maxdec, 
                                   INT *cntnlo,
                                   FEM_BOOLEAN midnode );

INT fem_imImproveShapeMeasure
                                 ( FEM_BOOLEAN bndcon, 
                                   INT mtype,
                                   FEM_BOOLEAN midnode,
                                   INT nexpass,
                                   DOUBLE minratio,
                                   FEM_BOOLEAN *abort );

#ifdef __cplusplus
}
#endif


#endif

