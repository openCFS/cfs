/* cAnsQuery.h	                                        
------------------------------------------------------------------------
------- Notice - This file contains ANSYS Confidential information 
------------------------------------------------------------------------
*/

/* ---------------------------------------------------------------------
 * Copyright 2011 SAS IP, Inc. 
 * ---------------------------------------------------------------------*/

/*------------------------------ Description ---------------------------
 * Description:   The include file to be used for the ANSYS Querying
 *                API routines.
 *----------------------------------------------------------------------*/

/*--------------------- Static TypeDefs/Structures ---------------------*/

/* Macros for parsing data from cAnsGetVector */
#define TAB(PTR,I,J,K) (*(PTR+((K-1)*nrows*ncols)+(nrows*(J)+(I))))
#define MAC0(PTR,I,J,K) (*(PTR+((K)*nrows*ncols)+(nrows*(J)+I)))
#define MAC1(PTR,I,J,K) (*(PTR+((K-1)*nrows*ncols)+(nrows*(J-1)+I-1)))

/*------------------------- API Functions ------------------------------*/
extern INT cAnsEvalExpr(char*, double*, char*, INT*);
extern INT cAnsGetFilter(char*, INT, INT*);
extern INT cAnsGetList(char*, INT*, char*, INT);
extern INT cAnsGetValue(char*, double*, char*, INT*);
extern INT cAnsGetVect(double*, char*);
extern INT cAnsGetVectInfo(char*, INT*, INT*);

/*---------------------------- End Of Module ---------------------------*/
/*------------------------------ API Description -----------------------
cAnsEvalExpr

  INT cAnsEvalExpr(strGet, dblValue, strMsg, intType)
     char    *strGet;
     double  *dblValue;
     char    *strMsg;
     INT     *intType;


Header file: cAnsQuery.h

Purpose:
     To get the character or dp value of an APDL parameter function

Parameters:
     Input
     -----------------------------
       strGet
         The ANSYS APDL expression to evaluate.  This is a null terminated 
         string which may be an APDL function, arithmatic expression, or 
         APDL variable. The length of strGet cannot be longer than 64 
         characters. 

       ex:    vect(4);  STR(1,2); A+B; NDINQR(1,14) 

     Output
     -----------------------------
       dblValue
          The double precision value for strGet, if the value is not
          string data.  The value returned for strMsg will be an empty
          string.  If the value is a string this will be 0.0d0.
       strMsg
          The string value for strGet (null terminated).  The maximum
           length of the returned string (strMsg) is 128 characters. If
           the value is not string this will be an empty string.
       intType
          The type of value that was returned
             0  - no information returned because of error
             1  - double in dblValue (string null)
             2  - string in strMsg (dblValue=0.0d0)

Return Value:
     If the function is successful, the return value is 0;
     otherwise it has one of the following values:
          1 - The command produced a NOTE
          2 - The command produced a WARNING and possibly a NOTE
          3 - The command produced an ERROR and possibly a WARNING
              and/or a NOTE.
         -3 - Indicates that a string length error was detected.


Notes:
    If an error condition is caused an error dialog will come up in
    the GUI.

----------------------------- End API Description --------------------*/
/*------------------------------ API Description -----------------------
cAnsGetFilter

  int cAnsGetFilter(strFilter, intType, intFilter)
      char   *strFilter;
      int    intType;
      int    *intFilter;

Purpose:
     To get a value from ANSYS.

Parameters:
     Input
     -----------------------------
       strFilter
         The ANSYS filter expression to evaluate. This is a null
         terminated string.  The expression can be enclosed in
         parentheses up to three levels deep.  The expression is
         limited to 256 characters.

       intType
         The type of evaluation to use on the filter expression.
            0 - Use keywords for the evaluation.
            1 - Use product words for the evaluation.

     Output
     -----------------------------
       intFilter
         The result of the filter expression.
            0 - The expression returned FALSE.
            1 - The expression returned TRUE.

Return Value:
     If the function is successful, the return value is 0;
     otherwise it has one of the following values:
          1 - The length of strFilter exceeded 256 characters.
          2 - The levels of parentheses exceeded 3 levels.

----------------------------- End API Description --------------------*/
/*------------------------------ API Description -----------------------
cAnsGetList

  int cAnsGetList(*strList, *lngList, *ptrList, ptrListSize)
     char *strList;
     int  *lngList;
     char *ptrList;
     int  ptrListSize;

Purpose:
     To get a list of values from ANSYS.

Parameters:
     Input
     -----------------------------
       strList
         The ANSYS list information to get.  This is null terminated 
         string which can have one of the following values:
				DOF   -  Current degree-of-freedom set
				F     -  Current force set
				CM    -  Current defined components
				ETAB  -  Current element table items
				PATH  -  Current path items
				VP26  -  Current post26 variables
				DV    -  Current design variables
				SV    -  Current state variables
				OBJ   -  Current objective function
				PAR   -  Current defined parameters
				ASSM  -  Current defined assemblies
				PARX  -  Current defined parameters excluding DV's, SV's and OBJ's
				FIT   -  Current fit functions
				MAT   -  Current defined material numbers
				DPTH  -  Current defined list of paths
				TYPE  -  Current defined element types
				REAL  -  Current defined real constant sets
				ESYS  -  Current defined element systems
				TITL  -  Current defined list of physics file titles
				PART  -  Current defined parts for LSDYNA
				PATB  -  Current defined table parameters
				PARA  -  Current defined array parameters
				SECT  -  Current defined sections
				TOFA  -  Current defined topological opt functions
				TOFC  -  Current candidates for a topological constraint
				TOCO  -  Current defined constraints for topological opt
				RV    -  Current random input variables
				RP    -  Current random output variables
				PARP  -  Current random variables excluding RV's and RP's
				SLAB  -  Current PDS solution labels
				SLMC  -  Current PDS solution labels for MSC
				SLRS  -  Current PDS solution labels for RSM

       ptrListSize
         The size of memory to be allocated for this list.  If this has
         a value of 0 (zero) the return value will be a negative number
         that gives the size needed.

     Output
     -----------------------------
       lngList
         The integer value of the number of items in the list.

       ptrList
         This must be a char pointer to a memory location that has a
         size of ptrListSize.  The memory will be filled with a combination
         of string and command up to lngList that are null terminated.

Return Value:
     If the function is successful, the return value is 0;
     otherwise it has one of the following values:
          1 - The requested list item doesn't exist.
          2 - The ptrListSize was too small to accomadate the list.


----------------------------- End API Description --------------------*/
/*------------------------------ API Description -----------------------
cAnsGetValue

  int cAnsGetValue(strGet, dblValue, strMsg, intType)
     char    *strGet;
     double  *dblValue;
     char    *strMsg;
     int     *intType;


Header file: cAnsQuery.h

Purpose:
     To get a value from ANSYS.

Parameters:
     Input
     -----------------------------
       strGet
         The ANSYS value to get.  This is null terminated string which
         uses the ANSYS *GET format without the parameter as follows:
              'Entity, ENTNUM, Item1, IT1NUM, Item2, IT2NUM'
         without the quotes.  This is limited to 630 characters.

     Output
     -----------------------------
       dblValue
         The double precision value for strGet, if the value is not
         string data.  The value returned for strMsg will be an
         empty string.
       strMsg
         The string value for strGet.  If the value is not string
         data this will be an empty string.  The size of strMsg will
         be set to 8 if it gets a zero length.  To get more than 8
         characters (32 Max.) you must blank pad strMsg in the calling 
         function and NULL terminate it.
       intType
         The type of value that was returned 0 (no information returned
         because of warning or error) or 1 (double in dblValue) or
         2 (string in strMsg)

Return Value:
     If the function is successful, the return value is 0;
     otherwise it has one of the following values:
          1 - The command produced a NOTE
          2 - The command produced a WARNING and possibly a NOTE
          3 - The command produced an ERROR and possibly a WARNING
              and/or a NOTE.


Notes:
    If an error condition is caused an error dialog will come up in
    the GUI.

----------------------------- End API Description --------------------*/
/*------------------------------ API Description -----------------------
cAnsGetVect


  int cAnsGetVect(arrload, APDLvect)
     void    *arrload;
     char    *APDLvect;


Header file: cAnsQuery.h

Purpose:
     To get a copy of an APDL array, table of char array from ANSYS.

Parameters:
     Input
     -----------------------------
       arrload
         Array to contain a copy of the data.
         This is a typeless pointer to a segment of memory large enough to
         hold the data represented by the APDL variable named in APDLvect.
         This memory must be allocated by the calling function. Two general
         cases exist. For APDL arrays and tables arrload will point to a
         vector of doubles. For APDL character arrays arrload will point to
         an array of char pointers. In turn each char pointer must address
         an array of 9 (nine) elements of type char. The function
         cAnsGetVectInfo should be used to assertain an APDL vectors size,
         type and memory storage requirements

       APDLvect
         The ANSYS APDL vector to get.  This is null terminated string which
         contains the name of the ANSYS APDL vector to copy. In ANSYS the
         length of an APDL variable can not be longer than 32 characters. This
         implies that it should be char APDLvect[33].

     Output
     -----------------------------
       arrload
         A copy of the APDL vector data will be placed at this address.
         For arrays and tables this is an array of doubles.
         For char type arrays this is an array of 9 character, NULL
         terminated, strings.

Return Value:
     If the function fails, the return value is 0;
     otherwise it will return a count of the total number of array
     elements copied.

----------------------------- End API Description --------------------*/

/*------------------------------ API Description -----------------------
cAnsGetVectInfo


  int cAnsGetVectInfo(APDLvect, itype, num_ents)
     char    *APDLvect;
     int     *itype;
     int     *num_ents;


Header file: cAnsQuery.h

Purpose:
     To get information about an APDL array, table of char array from ANSYS.

Parameters:
     Input
     -----------------------------

       APDLvect
         The ANSYS APDL vector of interest.  This is null terminated string which
         contains the name of the ANSYS APDL vector. In ANSYS the length of an
         APDL variable can not be longer than 32 characters. This implies that
         should be char APDLvect[33].

     Output
     -----------------------------
       itype
         A pointer to an integer that will return the type of vector defined
         by the APDL variable named in APDLvect.
         The possible values returned are:
         -1 = unknown APDL variable
          1 = ARRAY
          2 = TABLE
          4 = CHAR ARRAY
         For arrays and tables this type implies an array of doulbles.
         For char type arrays this type implies an array of strings, 8
         characters each. Note that in "C" code the are 9 characters
         due to NULL termination.

      num_ents
        A pointer to an integer that will return the number of elements
        that define the vector space. The value returned in num_ents
        varies depending on the type of vector in question.

        For itype = 1 num_ents = xsize * ysize * zsize
            itype = 2 num_ents = xsize+1 * ysize * zsize
            itype = 4 num_ents = xsize * ysize * zsize

Return Value:
     If the function fails, the return value is 0;
     otherwise it will return a count of the total number of bytes
     necessarily allocated to hold the ADPL vector in question.

----------------------------- End API Description --------------------*/
