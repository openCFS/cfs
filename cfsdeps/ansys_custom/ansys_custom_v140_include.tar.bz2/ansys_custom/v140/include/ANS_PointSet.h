////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         Copyright (C) 2010 ANSYS Inc.  All Rights Reserved             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: ANS_PointSet.h $
// $Revision: 1.7 $ 7.0
// $Date: 2010/04/06 19:21:05 $ March 28 2002
// $Author: srpailla $ rjayasee/jlo
//
// Decription :
//
// Collection of points
////////////////////////////////////////////////////////////////////////////

#if !defined(ANS_POINTSET_H)
#define  ANS_POINTSET_H

 


#ifndef RWSTD_NO_NAMESPACE
using namespace std ;
#endif

#include "ANS_Point.h"

class ANS_PointSet  
{
public:
	static ANS_PointSet* construct( vector<bool> const& oIsDependent ) ;
    //R-Pointer to an ansys point set
    //I-oIsDependent
    //I-Indicates in the nth data is the Point object is Dependent
	//F-Constructor with dependent and independent variables

	bool AddPoint( ANS_Point* pPoint) ;
    //R-bool
    //R-false is the pPoint is NULL or if the Data does not match
	//F-Add a ANS_Point to the Database

    bool GetPoint( INT index, ANS_Point const*& rPoint ) const;
	//R-Status
    //R-false if one such point does not exist
    //I-index
    //I-Nth Point
    //O-rPoint
    //O-Pointer to the Nthe Point
    //F-Gets the nth item in the PointSet
    
    bool RemovePoint( ANS_Point const* pPoint) ;
    //R-bool
    //I-pPoint
    //I-A Point exisiting in the Set
    //I-This just removes this particular point from the Set
	//F-Removes a ANS_Point from the database

	INT GetNumberOfPoints() const ;
    //R-INT
    //F-Returns the number of Points in the Point Set

	void Print() const ;
	//R-void
    //R-Prints the data

	virtual ~ANS_PointSet();
	//destructor

protected:

    ANS_PointSet() ;
    // Default Constructor

private :

    vector<ANS_Point*> m_oPointVector ;
    // A vector or array of points

    vector<bool> m_oIsDependent ;
    // Whether each component in the vector is dependent or independent

};

#endif // !defined(ANS_POINTSET_H)
