/*
 * *** copyright(c) 2011 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */
#define USER_INITIALIZE WM_USER
#define USER_BTNCHANGE WM_USER + 2
#define CMDLINE_FILE_OPEN WM_USER + 4
char command[SYS_LNG_CMDLN];
char jobname[FNAME_MAX+1];
char gdvname[9];

char curdrvr[SYS_LNG_CMDLN];
HCURSOR  hpointer, hwait;

struct Settings
{
  char overide[2];
  char hardcopies[5];
  char numloops[5];
  char timedelay[5];
  int checkstate;
  char start[5];  // plot dialog
  char end[5];
  BOOL more_colors;
  BOOL isColorMap;
  char increment[5];
  char cstart[6];
  char cend[6];
  char cincrement[4];
  char cfilename[256];
  char ctimedelay[10];
  int bpushed;
  char portfile[32]; // hpgl dialog
  int colorchk;
  int modelbtn;
  int outputbtn;
  int orienbtn; // page layout dialog
  int listitem;
  char tranx[5]; // postscript controls dialog
  char trany[5];
  char rotate[10];
  char scale[10];
  char preview[5];
  int keypreview;
  int keycolor;
  int pview;
  char strt[5]; // export dialog
  char iend[5];
  char inc[5];
  int  exportto;
  char resizePixels[5]; //for the RESIZE command
  int  dith;            //for the /DEVDISP command
  int  metaclr;

};

struct Settings settings;

