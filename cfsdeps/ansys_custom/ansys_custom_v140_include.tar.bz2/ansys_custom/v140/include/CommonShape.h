/*
 * ***copyright(c) 2011 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */
#if defined(XOX_DEBUG)
#define CALLTYP
typedef int INT;
typedef  void VOID;
#include "ansproto.h"
#endif

#if !defined(include_xoxbolh)
#define include_xoxbolh
#include "xoxbol.h"
#endif
#include "shapesmt.h"
