
/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 2009 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEMa_refine.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_refine.h
 *  header file for FEM_refine.c
 *
 */
#ifndef FEM_RESETUP_INCLUDE
#define FEM_RESETUP_INCLUDE

                        /* Error flags used in FEMa_reError */
#define REF_A_NO_ELEMENTS                           1
#define REF_A_ELEMS_NOT_SELECTED                    2
#define REF_A_HEX_2_REFINEMENT                      3
#define REF_A_NO_NODES_MARKED                       4
#define REF_A_ADJACENT_TO_CONTACT                   5
#define REF_A_ON_MESHED_LINE                        6
#define REF_A_ADJACENT_TO_MESHED_AREA               7
#define REF_A_ADJACENT_TO_MESHED_VOLUME             8
#define REF_A_REFINEMENT_SHP_CHK_FAILURE_QUAD       9
#define REF_A_REFINEMENT_SHP_CHK_FAILURE           10
#define REF_A_BAD_LEVEL_ARG                        11
#define REF_A_REFINEMENT_SHP_CHK_FAILURE_TET       12
#define REF_A_QUAD_TO_TET                          13

INT FEMa_reError ( INT error, INT entity, char *thefile, INT theline  );

#endif
