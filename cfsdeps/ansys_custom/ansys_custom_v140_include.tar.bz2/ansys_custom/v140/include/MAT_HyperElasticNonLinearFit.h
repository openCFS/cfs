////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         	Copyright (C) 2010 ANSYS Inc.  All Rights Reserved             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MAT_HyperElasticNonLinearFit.h $
// $Revision: 1.7 $ 7.0
// $Date: 2010/04/06 19:56:51 $ May 8 2002
// $Author: srpailla $ rjayasee
//
// Decription :
//
//	This class is the arruda boyce abstraction for material curve fitting
//////////////////////////////////////////////////////////////////////////////

#if !defined( MAT_HyperElasticNonLinearFit_H )
#define MAT_HyperElasticNonLinearFit_H


#include "MAT_ConstitutiveFunction.h"
#include "MAT_ArrudaBoyceVolumetricMode.h"

// #include "MAT_ConstitutiveFunction.h"
class MAT_ExperimentalDataSet ;

class MAT_HyperElasticNonLinearFit : public MAT_ConstitutiveFunction
{

public:

     MAT_HyperElasticNonLinearFit();
     //Constructor

     virtual INT GetNumberOfCoeffs() ;
    //R-bool
    //I-iOrder
    //I-Number of Coeffs
    //F-Set the Number of Coeffs
    //F-This is calculated from the polynomial order

    virtual bool CalculateFittedExperimentalDataPoint
                ( double* pCoeffs,
                  INT iNumCoeffs,
                  ANS_String oExpName,
                  vector<double>& oPoint ) 
    {
        return false ;
    }
    //R bool
    //I oExpName
    //I-Experiment Type
    //I oPoint
    //I-Point at which the stress is to be calculated
    //- Calculates the Stress at a strain point given the experiment type

    virtual bool CalculateFittedExperimentalDataPoint
                ( ANS_String const& oExperimentType,
                  vector<MAT_CFAttribute*> const& oParamVector,
                  double& oCalculatedValue ) ;
    //R Status of Function
    //I oExperimentType
    //I-Type of Experiment
    //I oParamVector
    //I-Vector of Parameters
    //O oCalculateValue
    //O-Value of Fitted Data
    //- Calculated Fitted Data Given Input

    virtual bool GenerateMaterialParameters() ;
    //R-bool
    //F-Function that Generates the Material Parameters given
    //F-some experimental data

    virtual bool GenerateMaterialParametersWithLMMethod() 
    {
        return false ;
    }
    //R-bool
    //F-Function that Generates the Material Parameters given
    //F-some experimental data with Levenberg Marquardt's Method

    virtual bool GenerateMaterialParametersWithNRMethod() ;
    //R-bool
    //F-Function that Generates the Material Parameters given
    //F-some experimental data with Newton's Method

    bool GetPrincipalStretchFromStrain( double dStrain, MAT_ExperimentType iExpType,
                                        double& dStretch ) ;
    //R bool
    //I iExpType
    //I-Experiment Type
    //O dStretch
    //O-Stretch
    
    virtual void Print() ;
    //F-Print

  	 virtual ~MAT_HyperElasticNonLinearFit();
    //F-Destructor


protected:

    double** m_pD2FMatrix ;
    INT m_iNumRowsD2FMatrix ;
    INT m_iNumColsD2FMatrix ;

    double** m_pD1FMatrix ;
    INT m_iNumRowsD1FMatrix ;
    INT m_iNumColsD1FMatrix ;
    
    virtual bool FirstDerivativeOfUnsquaredError
                                        ( double* dVariables,
                                          INT iNumVariables,
                                          double dLambdaN, 
                                          double dStressN,
                                          MAT_ExperimentType iExpType,
                                          INT iVariableIndex,
                                          double& dResult ) ;
    //R bool
    //R-false if unknown exp type or null dVariables
    //I dAlphaj
    //I-Coefficent Alpha in ArrudaBoyce Expr
    //I dLambdan
    //I-Value of Stretch
    //I iExpType
    //I 1 for unia, 2 for biax, 3 for tension
    //-Calculates the value of the first derivative of the ArrudaBoyce Potential
    //-for a stress/stretch point


    virtual bool FunctionValue( double* dVariables,
                                INT iNumVariables,
                                double dLambdaN, 
                                MAT_ExperimentType iExpType,
                                double& dStressN ) ;
    //R bool
    //I dVariables
    //I-Input Coeffecients
    //I iNumVariables
    //I-Number of Coeffecients = 2
    //I dLambdaN
    //I-Stretch
    //I iExpType
    //I 1 for unia, 2 for biax, 3 for tension
    //- Calculate Stress given stretch and coeffs

    virtual bool FirstDerivativeTerm( double* dVariables, 
                              INT iNumVariables,
                              double dLambdaN, 
                              double dStressN,
                              MAT_ExperimentType iExpType,
                              INT iVariableIndex,
                              double& dResult )
    {
        return false ;
    }
    //R-Value of the Derivative for a value of Stress and Strain
    //I dAlphaj
    //I-Coefficent Alpha in ArrudaBoyce Expr
    //I dLambdaN
    //I-Value of Stretch
    //I dC
    //I iExpType
    //I- 1 for uniaxial, 2 for biaxial, 3 for shear
    //I iVariableIndex
    //I-Variable w.r.t which  we differentiatee
    //- Calculates the value of the first derivative of the ArrudaBoyce Stress Error Squared
    //- for a stress/stretch point

    virtual bool SecondDerivativeTerm( double* dVariables,
                                       INT iNumVariables,
                                       double dLambdaN, 
                                       double dStressN,
                                       MAT_ExperimentType iExpType,
                                       INT iVariableIndexJ,
                                       INT iVariableIndexK,
                                       double& dResult ) 
    {
        return false ;
    };
    //R-true if if was a success
    //I dAlpha
    //I-Coefficent Alpha in ArrudaBoyce Expr
    //I dMu
    //I-Coefficent Mu in ArrudaBoyce Expr
    //I dLambdaN
    //I-Value of Stretch
    //I dStressN
    //I-Value of Stress
    //I iExpType
    //I- 1 for uniaxial, 2 for biaxial, 3 for shear
    //I-iVariableIndexJ
    //I-Variable by which it is differentiated first
    //I-iVariableIndexK
    //I-Variable by which it is differentiated next
    //O-dResult
    //I-Value of the second derivative
    //- Calculates the value of the first derivative of the ArrudaBoyce Stress
    //- Error Squared at a point

    virtual bool Assemble1stDerivativeMatrix
        ( double* dCoeffs,
          INT iNumCoeffs,
          double** d1stDerMatrix ) ;
    //R-Status of the function
    //I pDataSet
    //I-Collection of Experimental Data
    //I dCoeff                      
    //I-array of coefficients
    //I iNumCoeffs                  
    //I-Number of Coefficients
    //I d1stDerMatrix               
    //I-The Resulting Matrix of 1st Derivatives
    //-Assemble the RHS Matrix for the Newton-Raphson Loop

    virtual bool Assemble1stDerivativeMatrixAtAllPoints
        ( double* dCoeffs,
          INT iNumCoeffs,
          INT iNumPoints,
          double** d1stDerMatrix ) ;
    //R-Status of the function
    //I pDataSet
    //I-Collection of Experimental Data
    //I dCoeff                      
    //I-array of coefficients
    //I iNumCoeffs                  
    //I-Number of Coefficients
    //I iNumPoints
    //I-Number of points
    //I d1stDerMatrix               
    //I-The Resulting Matrix of 1st Derivatives
    //-Assemble the 1st Derivatives of Error ( Numpoints * Numcoeffs)
   
    
    virtual bool Assemble2ndDerivativeMatrix
        ( double* dCoeffs,
          INT iNumCoeffs,
          double** d2ndDerMatrix ) ;
    //R-Status of the function
    //I dCoeff                      
    //I-array of coefficients
    //I iNumCoeffs                  
    //I-Number of Coefficients
    //I d1stDerMatrix               
    //I-The Resulting Matrix of 2nd Derivatives
    //-Assemble the RHS Matrix for the Newton-Raphson Loop

    virtual bool Residual
        ( double* dCoeffs,
          INT iNumCoeffs,
          double& dResidual ) ;
    //R-Status of the function
    //I dCoeff                      
    //I-array of coefficients
    //I iNumCoeffs                  
    //I-Number of Coefficients
    //I dResidual               
    //I-The Resulting Resisuals
    //-Assemble the RHS Matrix for the Newton-Raphson Loop

    virtual bool ResidualAtAllPoints
        ( double* dCoeffs,
          INT iNumCoeffs,
          INT iNumPoints,
          double** dResidual ) ;
    //R-Status of the function
    //I dCoeff                      
    //I-array of coefficients
    //I iNumCoeffs                  
    //I-Number of Coefficients
    //I iNumPoints
    //I-Number of Points
    //I dResidual               
    //I-The Resulting Array of Errors ( NumPoints * 1)
    //-Assemble the Error Matrix
};

#endif // !defined(MAT_HyperElasticNonLinearFit_H)
