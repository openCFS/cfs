
/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 2009 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_swRibs.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_swRibs.h
 *  header file for FEM_swRibs.c
 *
 */
#ifndef FEM_SWRIBS_INCLUDE
#define FEM_SWRIBS_INCLUDE

#include "FEM_delaunay.h"
#include "fem_swPriv.h"

/*----------------- Globally accessible data types --------------------------*/

/*----------------- Globally accessible function prototypes -----------------*/

                               /* ========================================== */
                               /* === FEM_swAllocRibs:  Initialize Memory    */
                               /* === needed to create and store nodes on    */
                               /* === the ribs of a volume swept mesh.       */
                               /* === Return: EXIT_SUCCESS or EXIT_FAILURE   */
                               /* ========================================== */
INT FEM_swAllocRibs(
   INT num_divs );             /* (IN) number of element divisions on each rib*/

                               /* ========================================== */
                               /* === FEM_swRibs: Create the ribs on         */
                               /* === the exterior and interior of the       */
                               /* === volume.  Also create the nodes on the  */
                               /* === interior ribs.                         */
                               /* === Return: EXIT_SUCCESS or EXIT_FAILURE   */
                               /* ========================================== */
INT FEM_swRibs (
   VOL_PTYP obj_vol,           /* (IN)  The volume being swept.              */
   AREA_PTYP obj_sarea,        /* (IN)  the source area                      */
   AREA_PTYP obj_tarea,        /* (IN)  the target area                      */
   FEM_BOOLEAN sweepmids,      /* (IN)  TRUE if midnodes should be added by  */
                               /*       sweeping.                            */
   FEM_BOOLEAN do_progress,    /* (IN)  TRUE if doing status window          */
   FEM_BOOLEAN debug );

                               /* ========================================== */
                               /* === FEM_swRibCleanUp:  Delete all Memory  */
                               /* === used to store the ribs for volume      */
                               /* === sweeping                               */
                               /* === Return: void                           */
                               /* ========================================== */
void FEM_swRibCleanUp ( void  );

#endif

