////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         	Copyright (C) 2010 ANSYS Inc.  All Rights Reserved             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MAT_MaterialModel.h $
// $Revision: 1.7 $ 7.0
// $Date: 2010/04/06 19:56:50 $ March 28 2002
// $Author: srpailla $ rjayasee/jlo
//
// Decription :
//
// An abstraction for capturing material response. That is stress vs strain
// and temparature etc. 
//////////////////////////////////////////////////////////////////////////////

#if !defined(MAT_ExperimentalData_H)
#define  MAT_ExperimentalData_H


#include "ANS_PointSet.h"
#include "MAT_ExperimentalDataFormat.h"

class MAT_ExperimentalData  : public ANS_PointSet
{

public:

//	static MAT_ExperimentalData* ConstructFromXMLDataFile
//		( ANS_String s_FileName ) ;
	//constructor for reading one graph from the file
    //may have to change this interface
	
//	static MAT_ExperimentalData* ConstructFromXMLDataStream
//		( ifstream& oFileStream ) ;
	//constructor for reading one graph from the file stream
    //may have to change this interface

   static MAT_ExperimentalData* Construct
        ( ANS_String oExpType ) ;

   static MAT_ExperimentalData* ConstructFromDelimitedDataFile
        ( ANS_String oFileName, 
          char c_Delimiter,
          MAT_ExperimentalDataFormat* pMatRTPtr ) ;
	//R-MAT_ExperimentalData*
    //I-oFileName
    //I-File Name(Directory Name also has to be implemented here)
    //I-c_Delimiter
    //I-File Delimiter(Currently not implemented fully)
    //I-pMatRTPtr
    //I-Defines the structure of the Data in the file
    //F-This function reads data from a delimited file and constructs
    //F-an experimental data object

    static MAT_ExperimentalData* ConstructFromDelimitedDataFileUsingCFileIO
        ( ANS_String oFileName, 
          char c_Delimiter,
          MAT_ExperimentalDataFormat* pMatRTPtr ) ;
	//R-MAT_ExperimentalData*
    //I-oFileName
    //I-File Name(Directory Name also has to be implemented here)
    //I-c_Delimiter
    //I-File Delimiter(Currently not implemented fully)
    //I-pMatRTPtr
    //I-Defines the structure of the Data in the file
    //F-This function reads data from a delimited file and constructs
    //F-an experimental data object

    static MAT_ExperimentalData* ConstructFromDelimitedDataStream
        ( ifstream& oFileStream, 
          char c_Delimiter,
          MAT_ExperimentalDataFormat* pMatRTPtr ) ;
	//R-MAT_ExperimentalData*
    //I-oFileStream
    //I-File Stream
    //I-c_Delimiter
    //I-File Delimiter(Currently not implemented fully)
    //I-pMatRTPtr
    //I-Defines the structure of the Data in the file
    //F-This function reads data from a delimited file stream and constructs
    //F-an experimental data object

    ANS_String const& GetName() const;
    // Gets the Name of the Experimental Data object

	// bool WriteToDelimitedDataFile( ANS_String fileName, char delimiter) ;
	// Writes Data to File with a delimiter

    void GetExperimentalDataFormat( MAT_ExperimentalDataFormat *& pEDFormat ) ;
    //R-void
    //I pEDFormat
    //I-Experimental Data Format Object
    //- Gets the Experimental Data Format Object

    void GetExperimentalDataFormat( MAT_ExperimentalDataFormat const *& pEDFormat )  const;
    //R-void
    //I pEDFormat
    //I-Experimental Data Format Object
    //- Gets the Experimental Data Format Object

    bool GetValue( ANS_String oAttName,
                   ANS_Point const * pPoint,
                   double& oAttValue ) ;
    //R Status
    //I oAttName
    //I-Name of the Attribute
    //I pPoint
    //I-Point Data
    //I oAttValue
    //I-Value of Attribute
    //- Returns the value requested. Looks for it in Point
    //- then in ExpDataFormat

    bool GetColumnPosition( ANS_String oAttributeName, INT& iAttPosition ) ;
    //R status
    //R-false if no such attrib exists
    //I oAttributeName
    //I-Name of Attribute
    //I iAttPosition
    //I-Position of Attribute
    //- Gets a position of Attribute
                            

	void Print() const ;
	//Print the data

	virtual ~MAT_ExperimentalData();
	//destructor

private :

   MAT_ExperimentalDataFormat* m_pExperimentalDataFormat ;
   // Describes the various terms in the Material Response Diagram/Plot/List ..

   MAT_ExperimentalData();
   //Constructor in Private
};

#endif // !defined(MAT_ExperimentalData_H)
