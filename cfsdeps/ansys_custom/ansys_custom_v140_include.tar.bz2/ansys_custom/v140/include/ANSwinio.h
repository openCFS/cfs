// windows I/O data structures
typedef struct
{
    DWORD Bytes;
    OVERLAPPED Overlapped;
} WINIOCONTEXT;

typedef struct
{
    WINIOCONTEXT* IoContext;
    HANDLE      FileHandle;
} WINIOEVENT;

#define MAXIOUNITS 100
WINIOEVENT WinIoUnitsArray[MAXIOUNITS];
DWORD MaxIoBytes;
INT   MaxPipelineDepth;
