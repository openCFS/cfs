/* ---------------------------------------------------------------------- */
/* *** copyright(c) 2011 SAS IP, Inc.  All rights reserved. */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */
/*                                                                        */
/* This header file is for setting up c routines that will be called by   */
/* a fortran routine.                                                     */
/*                                                                        */
/* ---------------------------------------------------------------------- */


/*  cAnsFtoC.h */
#if !defined(__CANSFTOC_H__)
#define __CANSFTOC_H__ 1

#include "ansys.h"

/* (1)----------------------------------------------------------------*/
#if defined(LOWERCASENOUNDER_SYS)

/*
 *   The pattern for these platforms is the lowercased version of the name
 */

#define pauseconsole             pauseconsole
#define setexitflag              setexitflag
#define tclexit                  tclexit
#define dispatch_dump			 dispatch_dump

#endif


/* (2)----------------------------------------------------------------*/
#if defined(UPPERCASENOUNDER_SYS)

/*
 *   The pattern for these platforms is the uppercased version of the name
 */

#define pauseconsole             PAUSECONSOLE
#define setexitflag              SETEXITFLAG
#define tclexit                  TCLEXIT
#define dispatch_dump            DISPATCH_DUMP

#endif


/* (3)----------------------------------------------------------------*/
#if defined(LOWERCASEUNDER_SYS)

/*
 *   The pattern for these platforms is the lowercased version of the name 
 *   followed by an underscore
 */

#define pauseconsole             pauseconsole_
#define setexitflag              setexitflag_
#define tclexit                  tclexit_
#define	dispatch_dump			 dispatch_dump_

#endif


/* (4)----------------------------------------------------------------*/

/*
 *   This section is for definition of prototypes.  Each prototype 
 *   should be ANSI compliant and specify the types of each parameter 
 *   as well as the return type.
 */

SUBROUTINE pauseconsole(VOID);
SUBROUTINE setexitflag(VOID);
SUBROUTINE tclexit(VOID);
SUBROUTINE dispatch_dump(int*);
#endif

