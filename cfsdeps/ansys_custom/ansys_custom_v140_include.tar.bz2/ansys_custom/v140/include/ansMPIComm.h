/*HFILE ansMPIComm.h                       ANSI_C                           sam
------------------------------------------------------------------------
------- Notice - This file contains ANSYS Confidential information
------------------------------------------------------------------------
*/

/*------------------------------ Description ---------------------------

\Author:    Sam Murgie

\Title:     ANSYS MPI Layer C Header

\Desc:      Provides prototypes for ANSYS MPI layer (ansMPIComm.c)

\History:   Created 5/1/03 (dc): Combined dpcg MPIComm.h and c_ampi_lib.h

\Function(s)
 -Primary:      Provide prototypes for ANSYS MPI layer (ansMPIComm.c)
 -Secondary:    none
 -External:     none
 -Internal:     none
 -Static:       thisCPU, numCPU

----------------------------------------------------------------------*/

#ifndef __ANSMPICOMM_H__
#define __ANSMPICOMM_H__ 1

/*-------------------------------- Globals ---------------------------*/

#ifdef __cplusplus
  extern "C" {
#endif /* __cplusplus */

extern INT  numCPU;
extern INT  thisCPU;

extern INT  ANSMPI_MAX;
extern INT  ANSMPI_MIN;
extern INT  ANSMPI_SUM;
extern INT  ANSMPI_MAXLOC;
extern INT  ANSMPI_MINLOC;
extern INT  ANSMPI_BITAND;
extern INT  ANSMPI_BITOR;

extern INT  ANSMPI_CHARACTER;
extern INT  ANSMPI_INTEGER;
extern INT  ANSMPI_LONGINT;
extern INT  ANSMPI_REAL;
extern INT  ANSMPI_DOUBLE;
extern INT  ANSMPI_COMPLEX;

extern INT  ANSMPI_ANY_SOURCE;
extern INT  ANSMPI_ANY_TAG;
extern INT  ANSMPI_GROUP_NULL;
extern INT  ANSMPI_COMM_NULL;
extern INT  ANSMPI_REQUEST_NULL;
extern INT  ANSMPI_STATUS_SIZE;
extern INT  ANSMPI_STATUS_SOURCE;
extern INT  ANSMPI_STATUS_TAG;

extern INT  ANSMPI_WORLD;

/*------------------------------ Prototypes --------------------------*/

/* initialization and termination routines */
void     cansMPI_Initialized(INT*);
void     cansMPI_Init(void);
void     cansMPI_Finalize(void);
void     cansMPI_Abort(INT, INT);

/* point-to-point communication routines */
void     cansMPI_Send(void*, INT, INT, INT, INT, INT);
void     cansMPI_BSend(void*, INT, INT, INT, INT, INT);
void     cansMPI_ImmedSend(void*, INT, INT, INT, INT, INT, INT*);
void     cansMPI_Recv(void*, INT*, INT, INT, INT, INT);
void     cansMPI_ImmedRecv(void*, INT, INT, INT, INT, INT, INT*);

/* collective communication routines */
void     cansMPI_Reduce(void*, void*, INT, INT, INT, INT, INT);
void     cansMPI_AllReduce(void*, void*, INT, INT, INT, INT);
void     cansMPI_Scan(void*, void*, INT, INT, INT, INT);
void     cansMPI_Bcast(void*, INT, INT, INT, INT);
void     cansMPI_Gather(void*, INT, INT, void*, INT, INT, INT, INT);
void     cansMPI_GatherV(void*, INT, INT, void*, INT*, INT*, INT, INT, INT);
void     cansMPI_Scatter(void*, INT, INT, void*, INT, INT, INT, INT);
void     cansMPI_ScatterV(void*, INT*, INT*, INT, void*, INT, INT, INT, INT);
void     cansMPI_AllGather(void*, INT, INT, void*, INT, INT, INT);
void     cansMPI_AllGatherV(void*, INT, INT, void*, INT*, INT*, INT, INT);
void     cansMPI_AlltoAll(void*, INT, INT, void*, INT, INT, INT);
void     cansMPI_AlltoAllV(void*, INT*, INT*, INT, void*, INT*, INT*, INT, INT);
void     cansMPI_Barrier(INT);

/* message utility routines */
INT      cansMPI_Probe(INT, INT*, INT*, INT);
void     cansMPI_GetCount(INT*, INT, INT*);

/* request utility routines */
void     cansMPI_Test(INT*,INT*);
void     cansMPI_TestSome(INT, INT*, INT*, INT*);
void     cansMPI_Wait(INT*);
void     cansMPI_WaitAny(INT, INT*, INT*);
void     cansMPI_WaitAll(INT, INT*);
void     cansMPI_Request_Free(INT*);
void     cansMPI_Cancel(INT*);

/* communicator utility routines */
void     cansMPI_CommGroup(INT, INT*);
void     cansMPI_GroupIncl(INT, INT, INT*, INT*);
void     cansMPI_CommCreate(INT, INT, INT*);
void     cansMPI_CommDup(INT, INT*);
void     cansMPI_CommSplit(INT, INT, INT, INT*);
void     cansMPI_GroupTranslateRanks(INT, INT, INT*, INT, INT*);
void     cansMPI_GroupFree(INT*);
void     cansMPI_CommFree(INT*);
void     cansMPI_CommSize(INT, INT*);
void     cansMPI_CommRank(INT, INT*);

/* process toplogy utility routines */
void     cansMPI_DimsCreate(INT, INT, INT*);
void     cansMPI_CartCreate(INT, INT, INT*, INT*, INT, INT*);
void     cansMPI_CartDimGet(INT, INT*);
void     cansMPI_CartGet(INT, INT, INT*, INT*, INT*);
void     cansMPI_CartRank(INT, INT*, INT*);
void     cansMPI_CartCoords(INT, INT, INT, INT*);
void     cansMPI_CartSub(INT, INT*, INT*);

/* error handling utility routines */
void     cansMPI_GetErrorString(INT,char*,INT*);
void     cansMPI_CommCreateErrhandler(void*, INT*);
void     cansMPI_CommSetErrhandler(INT, INT);
void     cansMPI_CommGetErrhandler(INT, INT*);

/* miscellaneous utility routines */
void     cansMPI_BufferAttach(INT);
void     cansMPI_BufferDetach(void);
void     cansMPI_GetProcName(char*, INT*);
DOUBLE   cansMPI_WTime();
DOUBLE   cansMPI_WTick();
INT      cansMPI_GetParameter(INT);
INT      cansMPI_Inquire(INT);
void     cansMPI_Setup(INT, INT);

/* error handler routines */
void     handleMPIerror(char*,INT);
void     catchMPIerror(void*,int*,...);

#ifdef __cplusplus
}
#endif /* __cplusplus */

/*--------------------------End of Prototypes ------------------------*/

/*---------------------------- End Of Module -------------------------*/

#endif
