
/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 2009 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_midnode.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_midnode.h
 *  header file for FEM_midnode.c
 *
 */
#ifndef FEM_MIDNODE_INCLUDE
#define FEM_MIDNODE_INCLUDE

/*----------------- Globally accessible constants  --------------------------*/

/*----------------- Globally accessible data types --------------------------*/

/*----------------- Globally accessible function prototypes -----------------*/

#ifdef __cplusplus
extern "C" {
#endif

#ifndef STANDALONE_DELAUNAY
                      /* ==================================================== */
                      /* === FEM_mdAddMidNodes: Create midnodes on all new    */
                      /* === edges that need them.                            */
                      /* === Return: EXIT_SUCCESS or EXIT_FAILURE             */
                      /* ==================================================== */
INT FEM_mdAddMidNodes (
   FEM_BOOLEAN project,      /* (IN)  TRUE if midnode need to be projected to */
                             /*       the underlying geometry.                */
   EDGE_OBJ obj_oldedge,     /* (IN)  first edge in the edge list not created */
                             /*       by last meshing process.                */
   FACE_OBJ obj_oldface,     /* (IN)  first face in the face list not created */
                             /*       by last meshing process.                */
   FEM_BOOLEAN do_progress,  /* (IN)  TRUE if doing status window             */
   FEM_BOOLEAN *abort,       /* (OUT) TRUE if user abort.                     */
   INT solid_assoc );        /* (IN)  solid model associativity               */
                             /* ============================================= */

                      /* ==================================================== */
                      /* === FEM_mdNewMidNode: create a new midnode on an     */
                      /* === edge (interior to volume or on an area)          */
                      /* === Return: EXIT_SUCCESS or EXIT_FAILURE             */
                      /* ==================================================== */
INT FEM_mdNewMidNode(
   EDGE_OBJ obj_edge );      /* (IN)  edge to create midnode on               */

                       /* =================================================== */
                       /* === FEM_mdAreaProjectMidnodes: deterimine if        */
                       /* === midnodes on a given area should be projected.   */
                       /* === Return: TRUE if midnodes should be projected,   */
                       /* === otherwise FALSE.                                */
                       /* =================================================== */
FEM_BOOLEAN FEM_mdAreaProjectMidnodes (
   INT anum,                 /* (IN) area number                              */
   EDGELIST_OBJ obj_edlist,  /* (IN) edge list                                */
   EDGE_OBJ obj_lastedge  ); /* (IN) search list up till this edge            */


INT FEM_mdAdjustMidNode(
   EDGE_OBJ obj_edge,
   FEM_BOOLEAN bForceAdjust );

INT FEM_mdSimpleUvMid( INT anum );

                      /* ==================================================== */
                      /* === FEM_mdAddMidNodesOnArea: Create midnodes on all new    */
                      /* === edges that need them.                            */
                      /* === Return: EXIT_SUCCESS or EXIT_FAILURE             */
                      /* ==================================================== */
INT FEM_mdAddMidNodesOnArea (
   INT anum,
   FEM_BOOLEAN project,      /* (IN)  TRUE if midnode need to be projected to */
                             /*       the underlying geometry.                */
                             /*       by last meshing process.                */
   FEM_BOOLEAN do_progress,  /* (IN)  TRUE if doing status window             */
   FEM_BOOLEAN *abort,       /* (OUT) TRUE if user abort.                     */
   INT solid_assoc );        /* (IN)  solid model associativity               */
                             /* ============================================= */


#endif

#ifdef __cplusplus
}
#endif

#endif

