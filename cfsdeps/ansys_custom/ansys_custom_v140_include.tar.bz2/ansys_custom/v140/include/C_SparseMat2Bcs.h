/*CFILE C_SparseMat2Bcs.h CADOE */
/**
 * @file   C_SparseMat2Bcs.h
 * @author Frederic Thevenon
 * @date   2009
 * 
 * @brief  
 */

#include "CadoeAnsys.h"
#include "BoeingItf.h"
#include "C_SparseMat.h"

template <typename T, typename T2> void 
C_SparseMat2BcsGraph( char *MatName, C_SparseMat<T2> *Mat, C_VecPi<BCSINT> &CIdx, C_VecPi<BCSINT> &RIdx,
		      bool GlobalSym, T *hold, BCSINT &nhold, BCSINT &info);

template <typename T, typename T2> void 
C_SparseMat2BcsVal( char *MatName, C_SparseMat<T2> *Mat, T coef, C_VecPi<BCSINT> &CIdx, C_VecPi<BCSINT> &RIdx,
		    C_VecPi<T> &NzVal, bool GlobalSym, T *hold, BCSINT &nhold, BCSINT &info, double &maxTerm, double &minTerm);
