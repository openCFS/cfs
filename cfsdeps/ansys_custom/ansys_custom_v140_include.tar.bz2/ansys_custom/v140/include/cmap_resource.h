
/* ---------------------------------------------------------------------- */
/* ***copyright(c) 2011 SAS IP, Inc.  All rights reserved. */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by cmap.rc
//
#define IDS_STRING1                     1
#define IDS_STRING2                     2
#define IDD_DIALOG1                     101
#define IDD_DIALOG2                     102
#define IDI_ICON1                       110
#define IDC_COMBO1                      1001
#define IDC_SCROLLBAR4                  1003
#define IDC_SCROLLBAR5                  1004
#define IDC_SCROLLBAR6                  1005
#define IDC_GPERCENT                    1006
#define IDC_BPERCENT                    1007
#define IDC_DFLT_CLR                    1008
#define IDC_DFLT_MAP                    1009
#define IDC_QUIT                        1010
#define IDC_COPY_CLR                    1011
#define IDC_REVERSE                     1012
#define IDC_WRITE                       1013
#define IDC_DRIVER                      1014
#define IDC_PLANES                      1015
#define IDC_FILE                        1016
#define IDC_EDIT1                       1016
#define IDC_DRIVERNAME                  1017
#define IDC_EDIT2                       1017
#define IDC_NUMPLANES                   1018
#define IDC_FILENAME                    1019
#define IDC_100                         1020
#define IDC_FILEOPEN                    1020
#define IDC_50                          1021
// #define IDCONTINUE                      1021
#define IDC_0                           1022
#define IDC_PBC                         1023
#define IDC_PNUM                        1024
#define IDC_COLOR                       1025
#define IDC_15                          1026
#define IDC_14                          1027
#define IDC_13                          1028
#define IDC_12                          1029
#define IDC_11                          1030
#define IDC_10                          1031
#define IDC_9                           1032
#define IDC_8                           1033
#define IDC_7                           1034
#define IDC_6                           1035
#define IDC_5                           1036
#define IDC_4                           1037
#define IDC_3                           1038
#define IDC_2                           1039
#define IDC_1                           1040
#define IDC_ZERO                        1041
#define IDC_CONTOURS                    1042
#define IDC_CONTOURSNUM                 1043
#define IDC_RPERCENT                    -1
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        111
#define _APS_NEXT_COMMAND_VALUE         102
#define _APS_NEXT_CONTROL_VALUE         1044
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
