
/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 2009 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_SheetToSolid.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_SheetToSolid.h
 *  header file for FEM_SheetToSolid.c
 *
 */
#ifndef FEM_SHEETTOSOLID_INCLUDE
#define FEM_SHEETTOSOLID_INCLUDE

#ifdef __cplusplus
extern "C" {
#endif

                            /* ============================================== */
                            /* === FEM_SheetToSolid:  create a solid mesh from a sheet mesh */
                            /* ============================================== */
INT FEM_SheetToSolid ( DOUBLE thicknes ); /* the thickness of the midplane */
	
#ifdef __cplusplus
}
#endif


#endif
