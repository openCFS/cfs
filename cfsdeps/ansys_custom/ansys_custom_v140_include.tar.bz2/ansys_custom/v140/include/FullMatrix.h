
/*****************************************************************************
 *                   Copyright (C) 1999 CMSoft                               *
 *                                                                           *
 *  These lines of code and declarations contain unpublished proprietary     *
 *  information of CMSoft. They may not be copied or duplicated in whole     *
 *  or part without prior authorization from CMSoft.                         *
 *                                                                           *
 *****************************************************************************/

#ifndef FS_FULL_MATRIX_H_
#define FS_FULL_MATRIX_H_

#include <stdio.h>

// ======================================================== //
//                                                          //
// Author: K. H. Pierson                                    //
//                                                          //
// ======================================================== //
// Description:                                             //
//                                                          //
//             FSFullMatrix = Feti Solver Full Matrix class //
//             stores an mxn full matrix, certain member    //
//             functions only work for the square full      //
//             matrix case (nxn)                            //
// ======================================================== //

class FSVector;

class FSFullMatrix {

 protected:
   int nrow;	// number of rows
   int ncolumn; // number of columns
   int ld;      // leading dimension
   double *v;   // pointer to matrix data
 public:

   // Constructors
   FSFullMatrix();                               // Creates an empty full matrix
   FSFullMatrix(int nr);                         // Creates M(nr,nr) 
   FSFullMatrix(int nr, int nc);                 // Creates M(nr,nc)
   FSFullMatrix(int nr, int nc, double initVal); // Creates M(nr,nc)=initVal
   FSFullMatrix(int nr, int nc, double *array);  // Creates M(nr,nc)=array(i,j)

   // Copy Constructors
   FSFullMatrix(const FSFullMatrix &A); // Creates a new full matrix equal to A
   FSFullMatrix(const FSFullMatrix &A, int nr, int sr, int nc, int sc);

   // Destructor
   ~FSFullMatrix();

   double MemSize();
   void reSize(int nr, int nc, double d=0.0); // resize to M(nr,nc)=0.0

   // Operators
   double* operator[](int i)const;
   void  operator = (const FSFullMatrix &B);
   void  operator = (const double c);
   void  operator *= (const double c);

   // matrix-matrix multiplication
   FSFullMatrix operator *(FSFullMatrix &B); // product C=A*B
   FSFullMatrix operator ^(FSFullMatrix &B); // product C=A^T*B
   FSFullMatrix operator %(FSFullMatrix &B); // product C=A*B^T

   FSFullMatrix* transpose();
   FSFullMatrix* reorder(int*);

   // matrix-vector multiplication routines (calls BLAS-3 routines)
   // y=alpha*A*x + beta*y
   void mult(  const double *x, double *y, double alpha=1.0,double beta=0.0);
   // y=alpha*A^T*x + beta*y
   void trMult(const double *x, double *y, double alpha=1.0,double beta=0.0 );
   // y=alpha*A*x + beta*y
   void mult(  const FSVector &x, FSVector &y, double alpha=1.0,double beta=0.0);
   // y=alpha*A^T*x + beta*y
   void trMult(const FSVector &x, FSVector &y, double alpha=1.0,double beta=0.0);

   // general matrix-matrix multiplication routines (calls BLAS-3 routines)
   // C=alpha*A*B + beta*C
   void mult(    const FSFullMatrix &B, FSFullMatrix &C, 
                 double alpha=1.0, double beta=0.0);
   // C=alpha*A^T*B + beta*C
   void trMult(  const FSFullMatrix &B, FSFullMatrix &C, 
                 double alpha=1.0, double beta=0.0);
   // C=alpha*A*B^T + beta*C
   void multTr(  const FSFullMatrix &B, FSFullMatrix &C, 
                 double alpha=1.0, double beta=0.0);
   // C=alpha*A^T*B^T + beta*C
   void trMultTr(const FSFullMatrix &B, FSFullMatrix &C, 
                 double alpha=1.0, double beta=0.0);


   FSFullMatrix invert();      // form A^-1
   double maxVal();               // maximum matrix entry
   void luFactor();            // perform LU factorization
   void symLuFactor();            // perform LU factorization
   int  symLuFactor(int *perm, double tol, double *origDiag);
   void Lm1Mult(double *a, int nc, int lda);
   void Um1Mult(double *a, int nc, int lda);
   void Um1TMult(double *a, int nc, int lda);
   void Lm1Mult(double *a, int nc, int lda, int *perm); 
   void Um1Mult(double *a, int nc, int lda, int *perm);
   void Um1TMult(double *a, int nc, int lda, int *perm);
   void solve(double *rhs);    // perform forward/backward
   void zero();                // zero all matrix entries
   void identity();            // set square full matrix to identity matrix
   void print(char *msg = ""); // print the full matrix
   void WriteMatlab(FILE *fp);
   
   void add(FSFullMatrix& subMatrix, int sr, int sc);

   // inline functions
   int dim()      const { return nrow;    }
   int ldim()     const { return ld;      }
   int numRow()   const { return nrow;    }
   int numCol()   const { return ncolumn; }
   double* data() const { return v;       }
   double MemSize()   const {return (double)(nrow*ncolumn*sizeof(double));}
};

inline
double *
FSFullMatrix::operator[](int i) const
 { return v+i*ld; }

class StackFSFullMatrix : public FSFullMatrix {
 public:
   StackFSFullMatrix(const FSFullMatrix &matrix);
   StackFSFullMatrix(const FSFullMatrix &matrix, int nr, int nc,
          int rOff, int cOff);
   StackFSFullMatrix(int nr, double *data);
   StackFSFullMatrix(int nr, int nc, double *data);
   StackFSFullMatrix(int nr, int nc, int ldim, double *data);
   ~StackFSFullMatrix() { v = 0; }
};

inline
StackFSFullMatrix::StackFSFullMatrix(const FSFullMatrix &mat)
{
 nrow    = mat.numRow();
 ncolumn = mat.numCol();
 ld      = mat.ldim();
 v       = mat.data();
}

inline
StackFSFullMatrix::StackFSFullMatrix(const FSFullMatrix &mat, int nr, int nc,
          int rOff, int cOff)
{
 nrow    = nr;
 ncolumn = nc;
 ld      = mat.ldim();
 v       = mat.data() + rOff*ld + cOff;
}


inline
StackFSFullMatrix::StackFSFullMatrix(int nr, double *data)
{
 nrow    = nr;
 ncolumn = nr;
 ld      = nr;
 v       = data;
}

inline
StackFSFullMatrix::StackFSFullMatrix(int nr, int nc, double *data)
{
 nrow    = nr;
 ncolumn = nc;
 ld      = nc;
 v       = data;
}

inline
StackFSFullMatrix::StackFSFullMatrix(int nr, int nc, int ldim, double *data)
{
 nrow    = nr;
 ncolumn = nc;
 ld      = ldim;
 v       = data;
}

#endif
