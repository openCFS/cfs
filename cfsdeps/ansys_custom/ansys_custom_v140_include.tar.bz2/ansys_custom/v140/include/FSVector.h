/*****************************************************************************
 *                   Copyright (C) 1999 CMSoft                               *
 *                                                                           *
 *  These lines of code and declarations contain unpublished proprietary     *
 *  information of CMSoft. They may not be copied or duplicated in whole     *
 *  or part without prior authorization from CMSoft.                         *
 *                                                                           *
 *****************************************************************************/

#ifndef _FS_VECTOR_H_
#define _FS_VECTOR_H_

#include "dds_globals.h"

class SMV;
class FSCommunicator;

class FSVector {
  public:
   int   _len;  // vector length
   double *_d;  // vector elements
  public:

   FSVector() { _len = 0; _d = 0; }
   FSVector(int length); 
   FSVector(const FSVector &v);
   FSVector(const FSVector &v, double initialValue);
   FSVector(int length, double initialValue);
   FSVector(double  *v, int length);
   FSVector(const SMV &smv);

   ~FSVector();

   int size() const     { return _len; }
   double* data() const { return _d;   }
   void zero() { *this = 0.0; }

   void copy(const FSVector &v);
   void copy(const double *v);
   void copy(const double  value);

   double   operator * (const FSVector &);
   double   operator ^ (const FSVector &);
   FSVector operator / (const FSVector &);
   FSVector operator + (const FSVector &);
   FSVector operator - (const FSVector &);
   double &operator[] (int i) const;

   FSVector &operator=(const FSVector &);   // v2 = v1
   FSVector &operator=(const double c);     // v1 = 0.0
   FSVector &operator=(const double *data); // v1 = data

   void operator*=(const double c);         // v =  c*v
   void operator+=(const FSVector &v2);     // v += v2
   void operator-=(const FSVector &v2);     // v -= v2
   void operator/=(const FSVector &v2);     // v /= v2

   FSVector &operator =(const SMV &smv);
   FSVector &operator-=(const SMV &smv);

   void linAdd(double alpha, FSVector &v);
   void linAdd(double alpha, const FSVector &, double beta, const FSVector &);
   void linC( double c, const FSVector &v );
   void linC( const FSVector &v, double c );
   void linC( const FSVector & , double , const FSVector & );
   void linC( double, const FSVector &, double, const FSVector &);
   void swap( FSVector &);
   void mapTo(int *map, FSVector &v);
   void mapFrom(int *map, FSVector &v);

   void print(char *msg = "");
   void mult(FSVector &v);
   void diff(FSVector &v1, FSVector &v2);
   double Nrm2();

   void Send(int iCPU);
   void Recv(int iCPU);
   void sum(FSCommunicator *);

   friend FSVector operator * (const double c,const FSVector &);
};

inline double &
FSVector::operator[] (int i) const { return _d[i]; }

inline
FSVector::FSVector(int l)           // Constructor
{ 
  _len = l;
  if (_len)
    _d = (double *) allocadd(_len*sizeof(double));
  else
    _d = NULL;
}

inline
FSVector::FSVector(const FSVector &v, double val)
{
  _len = v._len;
 if (_len)
   _d = (double *) allocadd(_len*sizeof(double));
 else
   _d = NULL;
 copy(val);
}

inline
FSVector::~FSVector()
{
  LM_FREE(_d);
}

class StackFSVector : public FSVector {
  public:
    StackFSVector(double *data, int length);
    ~StackFSVector() { _d=0; }
    StackFSVector &operator =(const SMV &smv);
    StackFSVector &operator-=(const SMV &smv);
};

inline
StackFSVector::StackFSVector(double *ptr, int length)
{
  _len = length;
  _d   = ptr;
}

#endif
