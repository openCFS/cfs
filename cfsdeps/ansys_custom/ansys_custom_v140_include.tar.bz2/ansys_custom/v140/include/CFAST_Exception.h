/* CFILE CFAST_Exception.h CADOE */
#ifndef _CFAST_Exception
#define _CFAST_Exception

#include <string.h>

class CFAST_Exception
{
  int  iErrorcode;
  char sExceptMsg[255];    // Stores the exception message
 public:
  // Constructor.  Stores the application defined exception message
  CFAST_Exception(char *sMsg) {strcpy(sExceptMsg, sMsg); iErrorcode = -1;}
  CFAST_Exception(char *sMsg, int err) {strcpy(sExceptMsg, sMsg); iErrorcode = err;}
  
  // Returns the exception message
  char *sGetException() { return sExceptMsg; }
  int   iGetErrorCode() { return iErrorcode; }
};

#endif
