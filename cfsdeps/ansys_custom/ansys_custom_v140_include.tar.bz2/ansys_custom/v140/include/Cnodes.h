/******************************************************************/
/* CADOE file */
/*!
\file Cnodes.h
\brief CADOE class for adomesh2005 nodes
\version 1.00
*/
/******************************************************************/


#ifndef CNODESBASE_H
#define CNODESBASE_H 11

#include "m_matrix.h"
#include "cbf.h"

class Cnodes 
{
public:
	Cnodes( );
	~Cnodes( );
	bool setNbNodes( unsigned int );
	void setDimension ( unsigned int dime ) { _dimension = dime; };
	bool setMap ( );

	unsigned int getNbNodes ();
	unsigned int getNbNodesMax ();
	void addNode ( unsigned int numero, double *Nxyz );
	bool readFromFile ( T_cbf *cbf, int numero );

private:
	map	<int,int> _num2id;
	unsigned int _dimension;
	unsigned int _currentId;
	VEC *_xyz;
	IVEC *_numero;
};

#endif
