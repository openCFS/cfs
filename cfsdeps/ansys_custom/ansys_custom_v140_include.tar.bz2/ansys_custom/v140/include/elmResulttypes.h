
#include "ansysdef.h"

/****************************************************************
 data-level structure for ANSYS element results
 ****************************************************************/
struct elmResult_str {                  /* Name of the structure                                   */
  char resultTypes[MAXELMRESULTTYPE+1]; /* Array to flag element result types for this element     */
                                        /* i.e., if resultTypes[ELMRESULT_NSTR] = FALSE then no    */
                                        /* nodal stresses exist for this element and if            */
                                        /* resultTypes[ELMRESULT_NSTR] = TRUE then nodal stresses  */
                                        /* do exist for this element.                              */
                                        /* NOTE: we allocate 1 extra since we start at 1 and not 0 */
  elmResultData   *result;              /* Pointer to the first result on this element.  If this   */
                                        /* pointer is NULL that means this element has no element  */
                                        /* results stored.                                         */
};

#define elmResultTypesPtr(eresult)         (eresult->resultTypes)
#define elmResultTypesVec(eresult,i)       (eresult->resultTypes[i])

#define elmResultResultPtr(eresult)        (eresult->result)

