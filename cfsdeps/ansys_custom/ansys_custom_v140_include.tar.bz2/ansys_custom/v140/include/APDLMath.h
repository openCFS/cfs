/**
 * @file   APDLMath.h
 * @author 
 * @date   Thu Apr 10 10:17:07 2008
 * 
 * @brief  
 * 
 * 
 */

#ifndef _C_APDLMATH_
#define _C_APDLMATH_	1

#include "CadoeAnsys.h"
#include "C_Singleton.h"
#include "C_MatFunc.h"
#include "C_MatMGe.h"
#include "C_Engine.h"
#include "spdefines.h"
#include "syssys.h"
#include "C_DataFile.h"
#include "C_DynLibrary.h"

typedef void		(* EXEC_ENGINE)( ...);
typedef C_Engine *	(* ENGINE_GENERATOR)( char , C_GenericMat *, const char *Option);
typedef void		(* EXPORT_FILTER)( char type, C_GenericMat *Mat, char *FileName, 
					   const char *Arg1, const char *Arg2, const char *Arg3);
typedef void *		(* IMPORT_FILTER)( char type, char DataFormat, char *FileName, void *Mat, char *Arg3, char *Arg4);

#include "APDLMathInternal.h"

class C_APDLMath : public C_Singleton<C_APDLMath>
{
  friend class C_Singleton<C_APDLMath>;

private:

  C_APDLMath();
  ~C_APDLMath();

public:

  CADOE_EXPORT void ProcessCommand( string &Command);
  CADOE_EXPORT void AffInfo( C_CadoeMessage &);
  
  template <typename T> CADOE_EXPORT void AllocMatrix( string &Name, Hyper NRows = 0,
						       Hyper NCols = 0, bool OutOfCore = false, string FillOpt = "");
  
  template <typename T> CADOE_EXPORT void AllocVector( string &Name, Hyper NRows = 0, string FillOpt = "");

  template <typename T> CADOE_EXPORT void ImportMatrix( string &Name, T Tdum, string &FileName,
							string &Format, char *Arg3 = NULL, char *Arg4 = NULL);
  
  template <typename T> CADOE_EXPORT void ExportMatrix( C_Mat<T> *Mat, char *Format, string &FileName,
							string &Arg1, string &Arg2, string &Arg3);

  CADOE_EXPORT void CDwrite(int *unit);

  CADOE_EXPORT void	Resize( string &MName, int nbRows=1, int nbCols=-1);

  template <typename T>	CADOE_EXPORT void CopyMatrix( C_Mat<T> &Min, string &MtxName, char Opt);
  template <typename T>	CADOE_EXPORT void LinkToMatrix( C_Mat<T> &Min, string &MtxName);

  CADOE_EXPORT void	CreateLSEngine( string SolverType, string SolverName, string &MtxName, string &ArgMem);
  CADOE_EXPORT void	FactorLSEngine( string &MtxName, bool invert = false);

  template <typename T> CADOE_EXPORT void CreateITEngine( string SolverType, string SolverName,
							  string PrecondName, C_Mat<T> &Mat);

  template <typename T> CADOE_EXPORT void SolveLSEngine( string &MtxName, C_Mat<T> &VecsB, string &VecsX);
  
  template <typename T> CADOE_EXPORT void Compress( C_Mat<T> &Mat);

  CADOE_EXPORT void FFTAlgo( string typeTransform, string typeResult, C_GenericVec *VecIn, C_GenericVec *VecOut, int NbTerm);

  CADOE_EXPORT void FFTAlgo( string typeTransform, string typeResult, C_GenericMat *MatIn, C_GenericMat *MatOut, int NbTerm1, int NbTerm2);

  CADOE_EXPORT void Nrm( string &ObjName, string &TypeNrm, string &ValueName, bool Normalize=false);
  
  template <typename T1, typename T2> CADOE_EXPORT void Mult( C_Mat<T1> &M1, char M1Trans, C_Mat<T2> &M2,
							      char M2Trans, string &MOutName);

  template <typename T1, typename T2> CADOE_EXPORT void Axpy( T2 alpha, C_Mat<T1> &M1, T2 beta, C_Mat<T2> &M2);

  CADOE_EXPORT void Dot( void);
  template <typename T, class C> CADOE_EXPORT void Init( C &Object);

  CADOE_EXPORT void	DumpRestoreLsEngine( string &LsName, string &FileName);

  CADOE_EXPORT void Print( string &MtxName, C_GenericMat &Mat, string &FileName, int NumRow=-1, int NumCol=-1);
  CADOE_EXPORT void Print( string &MtxName, C_GenericVec &Vec, string &FileName);

  CADOE_EXPORT C_GenericMat		*GetMAT( const char *Cmd, string &Name, bool ShowError = true);
  CADOE_EXPORT C_GenericMat		*GetActiveMat( void) { return _ItM->second;}
  CADOE_EXPORT const string		&GetActiveMatName( void) { return _ItM->first;}
  
  CADOE_EXPORT C_Mat<double>		*GetdMAT( const char *Cmd, string &Name, bool ShowError = true);
  CADOE_EXPORT C_Mat<complex16_t>	*GetzMAT( const char *Cmd, string &Name, bool ShowError = true);

  CADOE_EXPORT C_GenericVec		*GetVEC( const char *Cmd, string &Name, bool ShowError = true);

  C_Engine		*GetEngine( const char *Cmd, char *Name);

  void			FreeAll(void);
  void			FreeObject( string &ObjName);
  void			FreeWrkSpace( int NumWrk);

  string		GetStrArg( int NumArg, bool ValueRequired, bool UpperCase = true, char *DefaultValue = NULL);
  template <typename T> T	GetValArg( int NumArg, T DefaultValue = (T)0);

  void			Load( string &LibName, string &SymbName, string &Feature, string &Name);
  void			Exec( string &SymbName, string &Arg1, string &Arg2, string &Arg3, string &Arg4);

  void			HandleError( C_CadoeException &e);

protected:

  void			AddLsEngine( string &EngineName, ENGINE_GENERATOR Generator);
  template < typename IMPEXP, class TypeFilter> void
			AddFilter( string &FilterName, IMPEXP Filter, map< string, TypeFilter> &FiltersList);
  void			AddExecEngine( string &EngineName, EXEC_ENGINE Exec);

  template < typename TFile> TFile *OpenFile( string &FileName, bool create = false)
  {
    TFile *F = NULL;
    
    if ( (_ItF = _DataFile.find(FileName)) != _DataFile.end())
      {
	F = dynamic_cast<TFile *>(_DataFile[FileName]);
	if ( F->HasChanged())
	  {
	    // ===== We suppress references to this file for existing matrices

	    map< C_GenericMat *, C_DataFile *>::iterator ItMF = _MatFile.begin();
	    while ( ItMF != _MatFile.end()) 
	      { 
		if (ItMF->second == F)
		  {
		    _MatFile.erase( ItMF); 
		    ItMF = _MatFile.begin();
		  }
		else
		  ItMF++;
	      }
	    
	    delete F; F = NULL;
	  }
      }
    
    if ( F == NULL)
      _DataFile[FileName] = F = new TFile( FileName.c_str(), create);
    
    return F;
  }

  template <typename T1, typename T2> CADOE_EXPORT void _CopyMatrix( C_Mat<T1> &Min, string &MtxName, string &Opt);

  void			UpdateSizeValues( void);
  void			UpdateSize( map< string, C_GenericVec *>::iterator &ItV, bool ToDelete = false);
  void			UpdateSize( map< string, C_GenericMat *>::iterator &ItM, bool ToDelete = false);

  C_TimeManager					_TM;
  C_CadoeMessage				_MsgPublic, _MsgVerbose1;
  string					_ActiveCommand;
  int						_NumArg;
  string					_StrArg;
  char						_Type;
  int						_CurWorkSpace;
  
  map< string, bool>				_Options;		//! Map of all APLDMath options

  map< string, C_GenericMat *>			_Mat;			//! Map of all Allocated [Dense,Sparse] Matrices
  map< string, C_GenericMat *>::iterator	_ItM;
  map< C_GenericMat *, C_DataFile *>		_MatFile;		//! Each matrices keeps the link to its input file

  map< string, C_GenericVec *>			_Vec;			//! Map of all Allocated Vectors
  map< string, C_GenericVec *>::iterator	_ItV;

  map< string, C_Engine *>			_Engine;		//! Map of all Allocated Solver Engines.

  map< string, C_DataFile *>			_DataFile;		//! Map of all Input Data Files
  map< string, C_DataFile *>::iterator		_ItF;

  map< string, int>				_WrkSpaces;		//! Map of defined Memory Workspaces. Reference all Vector/Matrices

  map< string, string>				_Perm;
  
  map< string, C_APDLMathCommand>		_Coms;			//! Map of all existing APDLMath commands. Used to validate input commands.

  map< string, C_DynLibrary *>			_Libs;			//! Map of all opened ADPLMath Library Plugins
  map< string, ENGINE_GENERATOR>		_CustEngine;		//! Map of all customized Solver Engines 
  map< string, C_APDLMathImportFilter>		_ImportFilters;		//! Map of all customized Import Filters
  map< string, C_APDLMathExportFilter>		_ExportFilters;		//! Map of all customized Export Filters
  map< string, EXEC_ENGINE>			_CustExec;		//! Map of all customized APDLMath Commands
};

extern CADOE_EXPORT C_APDLMath	*GetAPDLMath(void);
extern "C" CADOE_EXPORT void	APDLMathReset(void);

#endif
