/* ANSI_C ax_internal.h - ANSYS Geometry Interface: general but internal */

/*--------------------------------------------------------------------------*/
/* ansys(r) copyright(c) 2009 */
/* ansys, inc.                */
/*--------------------------------------------------------------------------*/

/* NOTE:
 *
 * For internal use only!
 *
 * ANY Interface Implementation MUST   #include "ax_internal.h"
 *                        instead of   #include "ax.h"
 */

/*--------------------------------------------------------------------------*/

#ifndef __AX_H_INTERNAL__  /* Include this file only once! */
#define __AX_H_INTERNAL__

#ifdef __cplusplus
extern "C" {
#endif

/*--------------------------------------------------------------------------*/

/* ANSYS Geometry Interface includes */

#include "rx_ansys.h"
#include "ax.h"
#include "ax_malloc.h"
#include "ax_nodes.h"
#include "ap.h"
#include "af.h"
  
/*--------------------------------------------------------------------------*/

/* rx Print file */

#define print        rx_print
#define print_space  rx_print_space
#define flush        rx_print_flush

/*--------------------------------------------------------------------------*/

/* Standard C imports */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

/*--------------------------------------------------------------------------*/

/* ax implementation level ax_LEVEL:
 *
 *   2 ... a[xp] + at -> xx -> XOX -> ANSYS (default!)
 *   1 ... a[xp] + at -> dummy xx (-> temporary!) --> No longer used!
 *   0 ... a[xp] only
 */

#if !defined(ax_LEVEL)
# define ax_LEVEL 2
#endif

/*--------------------------------------------------------------------------*/

/* Debugging */

#ifdef    __pedantic
# define ax_PEDANTIC 1
#else
# define ax_PEDANTIC 0
#endif

#define ax_MALLOC_DEBUG 0
  
/* NOTE: non-0 ax_MALLOC_DEBUG requires -D__lmalloc -lmalloc ... and SGI */
#if ! (defined(__sgi) && defined(__lmalloc))
#  undef  ax_MALLOC_DEBUG
#  define ax_MALLOC_DEBUG 0
#endif

/*--------------------------------------------------------------------------*/

/* Currently we'r only dealing with one model: id=1*/

#define ax_M1  1

/*--------------------------------------------------------------------------*/

typedef struct ax_note_rec
  {
    char *note;
    struct ax_note_rec *next;
  } AX_NOTE;

/*--------------------------------------------------------------------------*/

/* Internal, but shared amongst Implementation's modules */

typedef struct ax_internal_rec
{
  int    debug_level;
  int    array_base;
  char   separator;
  char   escape;

  char  *flavor;
  double global_tolerance;
  double global_mmbox[6];
  double xfactor;
  int    brep;
  int    solid;
  int    merge;

  int    ignore_opts_in_ifile;
  double xox_tols[2];
  int    ethreshold[2];
  
  int    xx2order;
  int    xx2reorient;

  char  *filebase;
  char  *preamble;

  AX_NOTE *list_of_notes;

  size_t node_bytes;
  size_t array_bytes;
  size_t strdup_bytes;

  int    invalid_db_flag;
} AX_INTERNAL;

extern AX_INTERNAL ax_internal;

/*--------------------------------------------------------------------------*/

/* Shortcuts to above ax_internal's */

#define _debug_level    ax_internal.debug_level
#define _array_base     ax_internal.array_base
#define _separator      ax_internal.separator
#define _escape         ax_internal.escape

#define _flavor           ax_internal.flavor
#define _global_tolerance ax_internal.global_tolerance
#define _global_mmbox     ax_internal.global_mmbox
#define _xfactor          ax_internal.xfactor
#define _brep             ax_internal.brep
#define _solid            ax_internal.solid
#define _merge            ax_internal.merge

#define _ignore_opts_in_ifile ax_internal.ignore_opts_in_ifile
#define _xox_tols             ax_internal.xox_tols
#define _ethreshold           ax_internal.ethreshold

#define _xx2order     ax_internal.xx2order
#define _xx2reorient  ax_internal.xx2reorient

#define _filebase     ax_internal.filebase
#define _preamble     ax_internal.preamble

#define _list_of_notes ax_internal.list_of_notes
 
#define _node_bytes   ax_internal.node_bytes
#define _array_bytes  ax_internal.array_bytes
#define _strdup_bytes ax_internal.strdup_bytes

#define _invalid_db_flag ax_internal.invalid_db_flag

/*--------------------------------------------------------------------------*/

/* Pedantic test */

#if (ax_PEDANTIC == 1)
  /* NOTE: this is going to be slooow (see ax_internal.c) */
     
# define ax_pedantic() ax_pedantic_test (__FILE__, __LINE__)
  void ax_pedantic_test (const char *fname, int lnum);
  
#else
  /* never mind... */

# define ax_pedantic() /*relax*/

#endif

/*--------------------------------------------------------------------------*/

/* Each official Interface function needs to call this (ax_internal.c)  */

void ax_interface (const char* fpoint);

/*--------------------------------------------------------------------------*/

/* Transfer to xx (at.c) */

void at_process (int process_code);

#define at_PROCESSING_MODE 1
#define at_VALIDATION_MODE 0

/* For at*.c only! */
#define at_error(CODE,MESSAGE,CONTEXT) at_error_f (CODE, MESSAGE, __FILE__, \
                                                   __LINE__, CONTEXT)
void at_error_f (int code, const char *message,
                 const char *fname, int lnum, const void* context);

/*--------------------------------------------------------------------------*/

/* Container mamangement (ax_internal.c) */

void ax_internal_initialize (void);
void ax_internal_terminate (void);

ax_ENTITY ax_lookup (char *label);

void ax_traverse (void (*func) (
                                ax_ENTITY entity,
                                void     *generic_node,
                                void     *app_data
                                ),
                  void *app_data
                  );

void ax_traverse_1node (void (*func) (
                                      ax_ENTITY entity,
                                      void     *generic_node,
                                      void     *app_data
                                      ),
                        ax_ENTITY e,
                        void *app_data);

ax_ENTITY ax_container_new (char *label, char *escape_string);

void ax_container_t (ax_ENTITY entity, int type, void *node_ptr,
                     const char *assertion_failed_string,
                     const char *fname, int lnum);

int ax_entity_high (void);

/*--------------------------------------------------------------------------*/

/* Container access functions (ax_internal.c) */

void *ax_entity_node     (ax_ENTITY entity);
int   ax_entity_code     (ax_ENTITY entity);
int   ax_entity_type     (ax_ENTITY entity);

const char *ax_label_str  (ax_ENTITY entity);

int         ax_encode (const char *escape_string);
const char *ax_decode_type (int code);
int         ax_decode_id   (int code);

const char *ax_escape_str (ax_ENTITY entity);
const char *ax_type_str   (ax_ENTITY entity);

const char *ax_escape_str2 (int code);
const char *ax_type_str2   (int type);

/*--------------------------------------------------------------------------*/

/* Dependency lists */

ax_ENTITY *ax_downward_dependency_list (ax_ENTITY e);
ax_ENTITY *ax_upward_dependency_list (ax_ENTITY e);

void ax_dependency (ax_ENTITY e1, ax_ENTITY e2);

/*--------------------------------------------------------------------------*/

/* Error handling via ax_error.c and rx_abort() */

#define ax_issue_error(CODE,MESSAGE,CONTEXT) \
ax_issue_error_f (CODE, MESSAGE, __FILE__, __LINE__, CONTEXT)

void ax_issue_error_f (int code, const char* message,
                       const char *fname, int lnum, const void* context);

void ax_error_clear_last (const char *fpoint);
const char *ax_error_last_fpoint (void);

/* NOTE:
 *
 * Whenever the Interface Implementation encounters an error,
 * it will either call, directly or indirectly:
 * - ax_issue_error() or
 * - rx_abort()
 *
 */

#define ax_ABORT_(_FMT_PARLIST_) ax_abort_macro (rx_fmt _FMT_PARLIST_)
#define ax_abort_macro(MSG)      rx_abort (ax_abfrmt, ax_error_last_fpoint (),\
                                           __FILE__, __LINE__, MSG)
extern char ax_abfrmt[];
extern char ax_assstr[];

/*--------------------------------------------------------------------------*/

#if defined(__cplusplus)
}
#endif

#endif  /* #ifdef __AX_H_INTERNAL__ */
