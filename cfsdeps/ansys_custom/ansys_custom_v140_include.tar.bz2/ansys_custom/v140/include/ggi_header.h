/*
 *  Names and Keywords for Control Parameters
 */

/********************************************************\
 *                     Integer                          * 
\********************************************************/

#define __ggilib_ok__     0
#define __ggilib_error__  1

#define __ggilib_side_a__ 1
#define __ggilib_side_b__ 2

#define __ggilib_false__  0
#define __ggilib_true__   1

/********************************************************\
 *  Debug parameters                                    *
\********************************************************/

#define DEBUG_FTOC        0
#define DEBUG_SETUP       0
#define DEBUG_SRF_FRAC    0
#define DEBUG_MESH        0

/********************************************************\
 *  define the REAL_GGI type as either float or         * 
 *  double precision depending on the compiler option   * 
\********************************************************/

#if defined (ggireal) || defined (GGIREAL)
typedef float REAL_GGI;
#else
typedef double REAL_GGI;
#endif

