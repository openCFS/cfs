/*HFILE LinuxSysInfoDefs.h                                            jrb
------------------------------------------------------------------------
------- Notice - This file contains ANSYS Confidential information
------------------------------------------------------------------------
*/

/*
 *  This file contains symbolic definitions for Linux system information function LinuxSysInfo
 *
 *   CAUTION WHEN EDITING THIS FILE!!!
 *
 *   THIS FILE HAS A TWIN FILE NAMED fLinuxSysInfoDefs.inc, AND ALL DEFINITIONS
 *   MUST REMAIN IN SYNC FOR THE MANAGER TO WORK PROPERLY!!!
 */


#define LINUX_TOTAL_PHYSICAL           1 //Total amount of physical memory in bytes
#define LINUX_TOTAL_VIRTUAL            2 //Total amount of virtual memory in bytes
#define LINUX_AVAIL_PHYSICAL           4 //Available amount of physical memory in bytes
#define LINUX_AVAIL_VIRTUAL            8 //Available amount of virtual memory in bytes
#define LINUX_SYSTEM_CACHE            16 //Size of system cache memory in bytes
