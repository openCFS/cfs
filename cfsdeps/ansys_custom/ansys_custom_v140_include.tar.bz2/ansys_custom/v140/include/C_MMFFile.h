/**
 * @file   C_MMFFile.h
 * @author  <ftheveno@LYOFTHEVENO8>
 * @date   Fri Nov 13 11:40:36 2009
 * 
 * @brief  
 * 
 * 
 */

#ifndef __C_MMFFILE_H__
#define __C_MMFFILE_H__	1

#include "C_MMFExport.h"
#include "C_DataFile.h"

/*!
 *  \class	C_MMFFile
 *  \brief	
 *  \author	Frederic Thevenon
 *  \version	1.0
 *  \date	2009
 *  \bug	
 *  \warning	
 *
 *  version 1.0 :       Initial Revision
 */

class C_MMFFile : public C_DataFile
{
public:

  C_MMFFile( const _TCHAR *FileName, bool create = false)
  {
    this->_FName = FileName;
    _tim = cadoe_file_mod_time( _FName.c_str());
  }
  
  virtual ~C_MMFFile( void) {};

  template <class MAT> void Generate( MAT &MatIn)
  {
    int		nrow = MatIn.NbLig(), ncol = MatIn.NbCol();
    int		MatrixType, Format;
    bool	Sym = MatIn.Sym();
    
    if ( strcmp( MatIn.AffType(), "C_MatMGe Type") == 0)
      {
	MatrixType = MATRIX_GENERAL;
	Format = ARRAY_FORMAT;
      }
    else if ( strcmp( MatIn.AffType(), "C_MatSp") == 0 || strcmp( MatIn.AffType(), "T_mso Type") == 0 )
      {
	MatrixType = ((Sym) ? MATRIX_SYMMETRIC : MATRIX_GENERAL); 
	Format = COORDINATE_FORMAT;
      }

    if ( MatIn.NbVal() > BIGINT)
      CADOE_THROW(E_IntegerOverFlow);

    int	nTerm = (int)MatIn.NbVal();

    _ExportEngine.Init( nrow, ncol, MatIn.Type(), MatrixType, Format, nTerm);
    _ExportEngine.Export<MAT >( (char *)_FName.c_str(), MatIn);
  }

  template <class MAT> void ReadMatrix( MAT &MatIn);

  template <class MAT> CADOE_EXPORT inline void GetMat( MAT &MatOut)
  {
    _infile.open( this->_FName.c_str());
    if (!_infile) CADOE_THROW( E_ErrorWhileOpeningFile);
    
    this->ReadHeader();
    this->ReadMatrix<MAT >( MatOut);

    _infile.close();			// Close ASCII File
  }

  bool SymMat( void) { return (_MatrixType != MATRIX_GENERAL);}

protected:  
  
  void		ReadHeader( void);

  ifstream	_infile;		///< C++ std File Object
  int		_iLine;			///< Number of current line in the DMIG File  
  char		_Line[4096], *_Str;	///< Current Line string
  
  C_MMFExport	_ExportEngine;
  int		_MatrixType;	//! symmetric (hermitian) matrix ?
  E_Type	_ScalarType;	//! complex values ? default value = false
  int		_Format;
};

template <> void C_MMFFile::ReadMatrix( C_MatSp<int> &MatIn);
template <> void C_MMFFile::ReadMatrix( C_MatSp<double> &MatIn);
template <> void C_MMFFile::ReadMatrix( C_MatSp<complex16_t> &MatIn);

#endif
