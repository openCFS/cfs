/*  FEM_ughardpoints.h */
/*
 * *** ansys(r) copyright(c) 2009
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_ughardpoints.h
 *  header file for FEM_ughardpoints.c
 *
 */
#ifndef FEM_UGHARDPOINTS_INCLUDE
#define FEM_UGHARDPOINTS_INCLUDE

/*----------------- Globally accessible function prototypes -----------------*/

                              /* =========================================== */
                              /* === FEM_hpAddHardPoints:  Add hardpoint to  */
                              /* === this area.  This was written special    */
                              /* === for UG/Scenario should be re-written    */
                              /* === time-permitting.  The better way to do  */
                              /* === it is to put hardpoints in the          */
                              /* === background mesh.                        */
                              /* === Return: EXIT_SUCCESS or EXIT_FAILURE    */
                              /* =========================================== */
INT FEM_hpAddHardPoints(
   INT anum,                  /* (IN)  The area to add hard point to.        */
   INT flat,                  /* (IN)  TRUE if anum is flat.                 */
   FEM_BOOLEAN *hpt_added );  /* (OUT) TRUE if one or more hardpoints was    */
                              /*       added.                                */

#endif

