/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 2009 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_swSrcTrg_static.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_swSrcTrg_static.h
 *  header file for FEM_swSrcTrg.c
 *
 */
#ifndef FEM_SWSRCTRG_STATIC_INCLUDE
#define FEM_SWSRCTRG_STATIC_INCLUDE

/*------------------ Prototypes for static routines ------------------*/

static INT fem_swCheckSrcTrg         ( VOLMSHDAT_PTYP obj_vol,
                                AREAMSHDAT_PTYP obj_sarea,
                                AREAMSHDAT_PTYP obj_tarea,
                                AREA_PTYP *aobj_areas,
                                FEM_BOOLEAN userspecified,
                                DEQUE_OBJ *obj_badkpdeque,
                                FEM_BOOLEAN *ok,
                                FEM_BOOLEAN *repairable,
                                FEM_BOOLEAN *axis_sweep );

static INT fem_swMakeMapable         ( AREAMSHDAT_PTYP p_areadata,
                                VOLMSHDAT_PTYP p_obj_voldata );

static INT fem_swStoreBadKp          ( KPMSHDAT_PTYP p_kpdata,
                                VOLMSHDAT_PTYP p_obj_voldata,
                                DEQUE_OBJ *obj_badkpdeque );

static INT fem_swAttemptRepair       ( VOLMSHDAT_PTYP p_obj_voldata,
                                DEQUE_OBJ obj_badkpdeque,
                                FEM_BOOLEAN *ok );

static INT fem_swIncreaseKpStat      ( KPMSHDAT_PTYP p_kpdata,
                                AREAMSHDAT_PTYP p_areadata,
                                VOLMSHDAT_PTYP p_voldata );

static INT fem_swDecreaseKpStat      ( KPMSHDAT_PTYP p_kpdata,
                                AREAMSHDAT_PTYP p_areadata,
                                VOLMSHDAT_PTYP p_voldata );

static INT fem_swChangeStat          ( AREAMSHDAT_PTYP p_areadata,
                                INT num_to_change,
                                VOLMSHDAT_PTYP p_obj_voldata,
                                INT stat1,
                                INT stat2 );

static INT fem_swIsKpOk              ( KPMSHDAT_PTYP p_kpdata,
                                VOLMSHDAT_PTYP p_voldata,
                                FEM_BOOLEAN *kp_ok );

static INT fem_swCheckHardDivs       ( VOLMSHDAT_PTYP obj_voldata,
                                       AREA_PTYP obj_srcarea,
                                       AREA_PTYP obj_trgarea,
                                       AREA_PTYP *aobj_areas,
                                       INT numareas,
                                       FEM_BOOLEAN &ok );

static void fem_swSortSrcTrg(  SRCTRG_TYPE a_srctrg[3]  , INT num_matches, const VOL_PTYP  obj_curvol );
 


#endif
