
/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 2009 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_copyAreaMesh_static.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_copyAreaMesh_static.h
 *  header file for FEM_copyAreaMesh.c
 *
 */
#ifndef FEM_COPYAREAMESH_STATIC_INCLUDE
#define FEM_COPYAREAMESH_STATIC_INCLUDE

/*------------------ Prototypes for static routines ------------------*/

static INT  fem_cpFindSrcNodes( INT needMidNode );

static INT fem_cpMakeTrgMeshV1(
   NODE_OBJ *aobj_src_bnd_nodes,   /* (IN)  nodes on source boundary */
   NODE_OBJ *aobj_trg_bnd_nodes,   /* (IN)  nodes on target boundary */
   INT num_bnd_nodes,              /* (IN)  length of 2 arrays */
   INT *a_iel,                     /* (IN)  edges connecting nodes in a_iel */
   INT num_bnd_edges,              /* (IN)  number of edges in a_iel */
   FEM_BOOLEAN trg_smooth,    
   FEM_BOOLEAN line_smooth,         
   FEM_BOOLEAN return_data,    
   FEM_BOOLEAN midnodes,               /* (IN)  TRUE if we need to make midnodes */
   FEM_BOOLEAN project_mids, FEM_BOOLEAN bWithImportedSrcMesh);

static INT  fem_cpFillTargetMatchData         ( NODE_OBJ *aobj_trg_bnd_nodes );

static INT  fem_cpAddMidNodes                 ( FEM_BOOLEAN project,
                                         EDGE_OBJ obj_oldedge,
                                         FEM_BOOLEAN do_progress,
                                         FEM_BOOLEAN *abort );

static DOUBLE fem_cpCalcMoveTol               ( INT *a_iel,
                                         INT num_edges,
                                         NODE_OBJ *aobj_trg_bnd_nodes );

static INT fem_cpIsSmoothNeeded               ( NODE_OBJ *aobj_src_bnd_nodes,
                                                NODE_OBJ *aobj_trg_bnd_nodes,
                                                INT num_bnd_nodes,
                                                FEM_BOOLEAN *smooth_needed );
static INT fem_cpMakeTrgMeshV1(
   NODE_OBJ *aobj_src_bnd_nodes,   /* (IN)  nodes on source boundary */
   NODE_OBJ *aobj_trg_bnd_nodes,   /* (IN)  nodes on target boundary */
   INT num_bnd_nodes,              /* (IN)  length of 2 arrays */
   INT *a_iel,                     /* (IN)  edges connecting nodes in a_iel */
   INT num_bnd_edges,              /* (IN)  number of edges in a_iel */
   FEM_BOOLEAN trg_smooth,    
   FEM_BOOLEAN line_smooth,         
   FEM_BOOLEAN return_data,    
   FEM_BOOLEAN midnodes,               /* (IN)  TRUE if we need to make midnodes */
   FEM_BOOLEAN project_mids,
   FEM_BOOLEAN bWithImportedSrcMesh ) ;

static INT fem_cpIsSmoothNeededV1(
   NODE_OBJ *aobj_srcBndNodes,
   NODE_OBJ *aobj_trgBndNodes,
   INT num_bnd_nodes,
   INT *smooth_needed );
static INT fem_cpSmoothTrg( INT line_smooth);

#endif
