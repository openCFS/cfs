#ifndef	_FULLSQUAREMATRIX_H_
#define	_FULLSQUAREMATRIX_H_

#include <stdio.h>
#include "C_VecPi.h"

class FSFullMatrix;

class FullSquareMatrix 
{
protected:
  C_VecPi<double> _values;
  
public:
  FullSquareMatrix(int i, double *l = NULL);
  FullSquareMatrix();
  ~FullSquareMatrix();
  
  void setSize(int i);
  double *operator[] (int row)  { return _values.Adr()+dim()*row;		}
  int dim()			{ return sqrt(_values.Dim());			}
  double* data()		{ return _values.Adr();				}  
  
  void zero();
  virtual double MemSize();
  
  void WriteMatlab(FILE *fp);
};

class FSFullSquareAssmblMat : public FullSquareMatrix 
{
protected:
  int *dMap;
  
public:
  FSFullSquareAssmblMat(int size, int *maps);
  void add(FullSquareMatrix &, int *dofs);
  void add(FSFullMatrix &, int *dofs); 
  void Copy(FSFullSquareAssmblMat &);
};

#endif
