
/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 2009 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_copyAreaMesh.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_copyAreaMesh.h
 *  header file for FEM_copyAreaMesh.c
 *
 */
#ifndef FEM_COPY_AREA_MESH_INCLUDE
#define FEM_COPY_AREA_MESH_INCLUDE

/*----------------- Globally accessible constants  --------------------------*/

/*----------------- Globally accessible data types --------------------------*/

#include "FEM_delaunay.h"

typedef struct {
   NODE_OBJ obj_source_node;
   NODE_OBJ obj_target_node;
   INT nodes[3];
   VECTOR3D src_location;
   VECTOR3D trg_location;
} MATCH_DATA;

/*----------------- Globally accessible function prototypes -----------------*/

#ifdef __cplusplus
extern "C" {
#endif

                      /* =================================================== */
                      /* === FEM_cpCopyAreaMeshV1:  Copy an area mesh from one */
                      /* === area to another.                                */
                      /* === Return: INT EXIT_SUCCESS or EXIT_FAILURE        */
                      /* =================================================== */
INT FEM_cpCopyAreaMeshV1(
   INT srcId, 
   INT trgId,  
   NODE_OBJ *aobj_srcBndNodes, /* (IN)  ordered src bnd node list */
   NODE_OBJ *aobj_trgBndNodes, /* (IN)  ordered src bnd node list, mapping to above node list */
   INT num_bnd_nodes,          /* (IN)  length of aobj_srcBndNodes and aobj_trgBndNodes.      */
   INT *a_iel,                 /* (IN)  edges connecting nodes in a_iel     */
   INT num_edges,              /* (IN)  number of edges in a_iel            */
   INT needAreaSmooth,         /* (IN)  make sense only to trg area  */
   INT canLineSmooth,          /* (IN)  can trg bnd nodes be smoothed along boundary lines.  */
   INT needMidNode,            /* (IN)  make sense only to trg */
   INT needProjMid,            /* (IN)  make sense only to trg */
   MATCH_DATA **a_node_matches,/* (OUT) list of node pairs. NOTE: 1) Boundary nodes are not included; 
													 2) mem must be released by caller */
   INT *num_node_matches, 
   FEM_BOOLEAN bWithImportedSrcMesh );
   INT FEM_cpHandleSphericalSurf( INT trgId, INT num_bnd_nodes, NODE_OBJ *aobj_trgBndNodes);


#ifdef __cplusplus
}
#endif

#endif

