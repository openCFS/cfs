
/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 2009 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_swMatch.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_swMatch.h
 *  header file for FEM_swMatch.c
 *
 */
#ifndef FEM_SWMATCH_INCLUDE
#define FEM_SWMATCH_INCLUDE


/*----------------- Globally accessible data types --------------------------*/

/*----------------- Globally accessible variables ---------------------------*/

/*----------------- Globally accessible macros ------------------------------*/

/*----------------- Globally accessible function prototypes -----------------*/

                               /* =========================================== */
                               /* === FEM_swMatchTrgNodes:  Determine which   */
                               /* === nodes on the target surface coorespond  */
                               /* === to which nodes on the source surface.   */
                               /* === Return: EXIT_SUCCESS or EXIT_FAILURE    */
                               /* =========================================== */
INT FEM_swMatchTrgNodes (
   INT vnum,                   /* (IN)  The volume we are sweeping.           */
   EDGE_OBJ *aobj_bound_edges, /* (IN)  array of edge on boundary of source   */
                               /*       area                                  */
   INT num_bound_edges,        /* (IN)  length of aobj_bound_edges            */
   INT source_area,            /* (IN)  an area on vnum that is meshed and is */
                               /*       to be swept through volume.           */
   INT target_area,            /* (IN)  an area on vnum that is meshed and is */
                               /*       the destination of sweeping the       */
                               /*       source_area.                          */
   FEM_BOOLEAN do_progress,    /* (IN)  TRUE if doing status window           */
   INT debug  );               /* (IN)  debug flag                            */
                               /* =========================================== */
INT FEM_swMatchTrgNodesV1(
	INT sweepmids,
   INT volId,                   /* (IN)  The volume we are sweeping            */
   EDGE_OBJ *aobj_srcBndEdges, /* (IN)  array of edge on boundary of source area*/
   INT numBndEdges,        /* (IN)  length of aobj_srcBndEdges            */
   INT srcId,       
   INT trgId) ;
#endif

