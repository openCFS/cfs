////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         copyright(c) 2011 SAS IP, Inc.  All rights reserved.             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: INIS_Data.h $
// $Revision: 456468 $ 7.0
// $Date: 2011-03-02 11:38:16 -0500 (Wed, 02 Mar 2011) $ October 04 2005
// $Author: ajkang $ rjayasee
//
// Decription :
// Data at individual integration point.
//
////////////////////////////////////////////////////////////////////////////

#include "ANS_StandardIncludes.h"
#include "INIS_Object.h"

#ifndef INIS_DATA_H
#define INIS_DATA_H

class INIS_Data : public INIS_Object
{
    public:

    INIS_Data();
    //Constructor

    INIS_Data( INIS_Data const& );
    //Copy Constructor

    static INIS_Data* ConstructFromDoubleArray(DOUBLE* pDoubleArray, INT iStart, INT iSize) ;
    //Constructor

    ~INIS_Data();
    //Destructor

    INT GetWrittenDoubleArraySize();
    //R Get the size of the array needed to write the datastructure

    void SetData( DOUBLE* pData, INT iSize, INT iType ) ;
    //R void
    //I pData
    //- Data to be set
    //I iSize
    //- Size of the data
    //I iType
    //- Data Type
    //- Sets data

    bool GetData( DOUBLE* pData, INT iSize, INT iType ) ;
    //R void
    //O pData
    //- Data to be obtained
    //I iSize
    //- Size of the data
    //I iType
    //- Data Type
    //- Gets data

    bool WriteToDoubleArray(DOUBLE* pDoubleArray, INT iPos, INT iSize, INT& iWrittenSize);
    //R bool
    //I pDoubleArray
    //I iPos
    //  Position to start writing to
    //I iSize
    //I-Size of Array Provided
    //I iWrittenSize
    //I Written Data length
    //- Write the INIS_Data Struct to an Double Array Format

    INT m_iNumDataTypes ;
    // Number of Data Type

    INT* m_pDataTypeList ;
    // Indices of Data Types

    DOUBLE** m_ppDataPtrList ;
    // Value of Data Types

    INT* m_pVarSizeList ;
    // Size of Data Types
} ;

#endif

