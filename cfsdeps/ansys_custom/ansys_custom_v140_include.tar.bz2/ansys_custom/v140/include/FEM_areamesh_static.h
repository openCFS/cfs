/*  FEM_areamesh_static.h */
/*
 * *** ansys(r) copyright(c) 2009
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_areamesh_static.h
 *  header file for FEM_areamesh.c
 *
 */

#ifndef FEM_AREAMESH_STATIC_INCLUDE
#define FEM_AREAMESH_STATIC_INCLUDE

/*----------------- Static Function Prototypes -------------------------------*/


static INT fem_amAdjNodeTo2D              ( NODE_OBJ obj_node );


static INT fem_amTriClean                 ( INT anum,
                                     INT numbound,
                                     INT shape,
                                     INT midnodes,
                                     INT highcurv,
                                     EDGE_OBJ obj_oldedge,
                                     INT flat,
                                     INT layermesh,
                                     FEM_BOOLEAN hardpoints,
                                     FEM_BOOLEAN determineEdgeGeoEntities );


static INT fem_amProcessEdges             ( INT anum,
                                     INT numbound,
                                     DOUBLE *p_avglen,
                                     DOUBLE *p_smallen,
                                     EDGE_OBJ obj_oldedge,
                                     FEM_BOOLEAN determineEdgeGeoEntities  );

static INT fem_amConvertToQuads           ( INT anum, FEM_BOOLEAN bAllQuadMesh, INT debug );


static INT fem_amQuadClean                ( INT anum,
                                     INT midnodes,
                                     INT highcurv,
                                     INT layermesh,
                                     INT topoOverride );

static INT fem_amQuadSplit         ( INT anum,
                                     INT command,
                                     INT iAllQuad );




static INT fem_amAddHardPoints            ( INT anum,
                                     INT flat,
                                     INT numbound,
                                     INT shape,
                                     INT midnodes,
                                     INT highcurv,
                                     EDGE_OBJ obj_oldedge,
                                     INT layermesh );

static void fem_amCheckMeshDirection       ( INT anum,
                                           INT flat,
                                            FACE_OBJ obj_oldface );


static INT fem_amMapMeshArea          (    INT anum,                  /* (IN) the area number                         */
                                           INT flat,
                                           INT numbound,              /* (IN) total number of nodes on bdry           */
                                           INT mshkey,                /* (IN) 0 = Use free Mesher Always.             */
                                                                      /*      1 = Use Map Mesher Always.              */
                                                                      /*      2 = Use Map Mesher if possible, and if  */
                                                                      /*          not, use the free mesher.           */
                                           INT midnodes,              /* (IN) 1 = midnodes on edges                   */
                                           INT project,               /* (IN) 0 = project midnodes, 1 = striaght      */
                                           PERIODIC_TYPE periodic,    /* (IN) whether a surface is periodic or not.   */
                                           INT numLoop,               /* (IN) numberof loops*/
                                           FEM_BOOLEAN *p_was_mapped, /* (OUT) return whether area was map meshed    */
                                           INT *highcurv );           /* (IN/OUT) in case bgmesh is created for map meshing */

static INT FEM_amNodesTopOrBottom(
   INT anum,                  
   INT numbound ) ;

static int fem_amNeedSmoothUV( 
   INT anum, 
   INT *needSmooth );


static INT fem_amHandleInfluenceSpheres ( INT iAreaId );
static void fem_amChooseMapMethod( INT anum, INT numLoop, INT numbound, INT flat, 
                            INT aiMethods[] ); /* 0: main method; 1: backup method */
static void fem_amMsgFeedBack( INT anum );
#endif
