#ifndef FEM_LIST__________________H
#define FEM_LIST__________________H

#include "FEM_cdbtypes.h"
#include "FEM_MemManager.h"


template <class Ltype> class LIST_TYP {

   private:
      INT m_count;
      Ltype *mp_list;
      MemManager<Ltype> m_memory;

   public:
      LIST_TYP( ) { Init(); };
      ~LIST_TYP( )
      {
         Delete();
      };
      void Delete( )
      {
         Ltype *p_link = mp_list;
         while ( p_link ) {
            Ltype *p_nextlink = p_link->GetNext();
            p_link->Delete();
            p_link = p_nextlink;
         }
         m_memory.FreeAll();
         m_count = 0;
         mp_list = NULL;
      };
      void Init( void ) { m_count = 0; mp_list = NULL;
                          m_memory.Init(); };

      Ltype *New()
      {
         m_count++;
         Ltype *p_thelink = m_memory.Allocate();
         if ( p_thelink ) {
            p_thelink->SetNext( mp_list );
            mp_list = p_thelink;
            return p_thelink;
         }
         else {
            return NULL;
         }
      };

      void Remove( Ltype *p_thelink )
      {
         Ltype *p_prevlink = NULL;
         Ltype *p_nextlink = NULL;
         Ltype *p_link = mp_list;
         while ( p_link ) {
            p_nextlink = p_link->GetNext();
            if ( p_link == p_thelink ) {
               m_count--;
               if ( p_prevlink ) {
                  p_prevlink->SetNext( p_nextlink );
               }
               else {
                  mp_list = p_nextlink;
               }
            }
            p_prevlink = p_link;
            p_link = p_nextlink;
         }
      };

      Ltype *GetList() const { return mp_list; };
      
      INT Length() const { return m_count; };
};

#endif
