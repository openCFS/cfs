/* CADOE */
/**
 *	extmodl.h -- Fonctions d'interface modl /va
 *  
 * |Version: $Id: extmodl.h 145002 2009-11-13 16:20:27Z jtm $
 *
 *   
 **/


#ifndef __EXTMODL_X_DEJA_INCLUS__
#define __EXTMODL_X_DEJA_INCLUS__ 1

#include "sx_CADOE_solver.h"
#include "computer.h"
#include "sysparh.h"

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */
  
  void vastssiz( int *stssiz );
  T_statut MOD_stssiz( T_modele *modele );
  int SX_GetNnewce();
  extern T_modele *ITF_extraire_modele_fs( T_statut *ier);
  
#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif	 /* __EXTMODL_X_DEJA_INCLUS__ */
