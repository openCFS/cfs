/* sid 60.20 copy of INIS_Database.h last changed by jtm on 2006/05/15 19:43:21 */
/* ---------------------------------------------------------------------- */
/* *** copyright(c) 2011 SAS IP, Inc.  All rights reserved. */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */

#include "ansys.h"

#if !defined(INIS_ELEMENDDATA_H)
#define INIS_ELEMENDDATA_H

#include "INIS_DataCollection.h"
#include "INIS_Object.h"

/* Data Stucture for Individual Data */
/*Data Structure for a Collection of Data */

/* Data Structure for a single element-intpt/secpt/layer pair */
struct INIS_ElementData : public INIS_Object
{
    public:

    INIS_ElementData() ;
    ~INIS_ElementData() ;
    //Constructor and Destructor

    static INIS_ElementData* ConstructFromDoubleArray( DOUBLE* pISData, INT iPos, INT iSz ) ;

    bool WriteToHeader( DOUBLE* pDoubleArray ) ;
    //R
    //I pDoubleArray
    //- Write the Element Data Header To Double Array

    bool ReadFromHeader( DOUBLE* pDoubleArray ) ;
    //R
    //I pDoubleArray
    //- Read the Element Data Header from a Double Array

    INT GetWrittenDoubleArraySize() ;
    //Get DB Format Array Size
    
    bool WriteToDoubleArray( DOUBLE* pISData, INT iPos, INT iSz, INT& iWrittenSz ) ;
    //R Status
    //I pISData
    //I-Double Array to be written to
    //I iPos
    //I Starting Pos of write
    //I iSz
    //I Size for total Array
    //0 iWrittenSz
    //O-Written Array Size

    bool SetData( INT* pPar, INT iNumPar,
                  DOUBLE* pData, INT iDataSize, INT iDataType ) ;
    //R Result
    //I pPar
    //I-Parameters
    //I iNumPar
    //I Num Parameters
    //I pData
    //I iDataSize
    //- Sets Initial State Data

    INT m_iTotalDataSize ;
    INT m_iDataFormat ;
    INT m_iHeaderSize ;
    INT m_iDataSource ;
    INT m_iIsMatBased ;
    INIS_DataCollection* m_pDataCollection ;
} ;

#endif
