/*
 *  This file contains internal symbolic definitions for the memory manager
 *
 *   CAUTION WHEN EDITING THIS FILE!!!
 *
 *   THIS FILE HAS A TWIN FILE NAMED fAnsMemInternalDefs.inc, AND ALL 
 *   DEFINITIONS MUST REMAIN IN SYNC FOR THE MANAGER TO WORK PROPERLY!!!
 *
 *   In addition, the external definitions file must be included BEFORE this 
 *   file in the memory manager, as many symbols here depend on definitions 
 *   in that file.
 */

/* this mask can be used to separate type info from various modifications on 
   the allocation */
#define ALLOC_KEY_MASK MEM_QUERY + MEM_RETURN + MEM_INITIAL + MEM_GROWTH + \
  MEM_FAIL + MEM_RESTRICTED

/* this mask keeps the journal from being called unnecessarily */
#define JOURNAL_BIT_MASK ECHO_OPERATIONS + ECHO_TABLE_ON_ERROR + \
  ECHO_REMARKABLE_EVENTS + ECHO_ERROR_MESSAGES + ECHO_TABLE_ON_OPERATIONS

/* this mask is used to pull out the type info from the allocation keys */
#define FLAG_TYPE_MASK      7

/* this mask is used to pull out the group allocation codes
   (bits 17-23) */
#define ALLOC_GROUP_MASK 8323072

/* This mask is necessary on HP for various pointer operations */
#if defined(HP64_SYS)
# define PTRMASK 0x8000000000000000
#else
# if defined(HPIA64_SYS)
#  define PTRMASK 0x6000000000000000
# else
#  define PTRMASK 0
# endif
#endif

/* various codes for the journal */
#define FREE_ON_EMPTY_MEM_TABLE                     -1002
#define BACK_POINTER_CLOBBERED_ON_FREE              -1003
#define POINTER_NOT_IN_TABLE_ON_FREE                -1004
#define GROWTH_POOL_MALLOC_FAILURE                  -1005
#define MEM_POOL_POINTERS_MALLOC_FAILURE            -1006
#define DESTROY_MANAGER_WITH_USED_MEMORY            -1007
#define MALLOC_GROWTH_POOL                          -1008
#define SPLIT_MEM_BLOCK_SUCCESS                     -1009
#define CREATE_NEW_MEM_NODE_FAILURE                 -1010
#define DESTROY_HEAD_NODE                           -1011
#define SPLITTING_BLOCK                             -1012
#define MERGING_BLOCKS                              -1013
#define BACK_POINTER_CLOBBERED_ON_REALLOC           -1014
#define POINTER_NOT_IN_TABLE_ON_REALLOC             -1015
#define GROWTH_POOL_PTR_MALLOC_FAILURE              -1016
#define MALLOC_GROWTH_POOL_PTRS                     -1017
#define ANS_MEM_HANDLE_CALL                         -1018
#define BACK_POINTER_CLOBBERED_ON_GET_INDEX         -1019
#define POINTER_NOT_IN_TABLE_ON_GET_INDEX           -1020
#define GROWTH_POOL_MALLOC_SUCCESS                  -1021
#define GROWTH_POOL_NOT_RESTRICTED                  -1022
#define DID_NOT_SPLIT_MEM_BLOCK                     -1023
#define MEMORY_FRAGMENTATION_WARNING                -1024
#define RESET_MANAGER_WITH_USED_MEMORY              -1025
#define MALLOC_REQUESTED_SIZE_TOO_LARGE             -1027
#define REALLOC_REQUESTED_SIZE_TOO_LARGE            -1028
#define BAD_HANDLE_ON_ANSMEMLOCK                    -1029
#define BAD_HANDLE_ON_ANSMEMPOINTER                 -1030
#define MISALIGNED_POINTER_ON_ANSMEMHANDLE          -1031
#define FREE_GROWTH_POOL                            -1032
#define BAD_CHECKFREE_ARGUMENT_TO_MERGE_MEM_BLOCKS  -1033
#define SPLIT_BLOCK_CANT_CREATE_NEW_NODE            -1034
#define SPLIT_BLOCK_FAILURE                         -1035
#define DESTROY_MANAGER_STATS                       -1036
#define MEMORY_LEAKS                                -1037
#define TABLE_CORRUPTION                            -1038


#define FREE_NULL_POINTER                           -2004
#define MALLOC_ZERO_OR_NEGATIVE_LENGTH              -2005
#define MEM_TABLE_GROWTH_MALLOC_FAILURE             -2006
#define NO_MEM_ERROR                                -2008
#define GROWING_MEM_TABLE                           -2009
#define FREE_CALL                                   -2010
#define MALLOC_CALL                                 -2011
#define REALLOC_CALL                                -2012
#define REALLOC_ZERO_OR_NEGATIVE_LENGTH             -2013
#define UNLOCK_BLOCK_FAILURE                        -2014
#define DESTROY_MANAGER                             -2015
#define INITIAL_POOL_FULL                           -2016
#define RESET_MANAGER                               -2017
#define MEM_BLOCK_NAME_LEN_MISMATCH                 -2018
#define GROUP_FREE_CALL                             -2019

#define MEM_IGROW                                   -3001
#define MEM_IERROR                                  -3002
#define MEM_IWARN                                   -3003
#define MEM_IDEBUG                                  -3004
#define MEM_IOUTPUT                                 -3005

   
#define ANS_MEM_HANDLE_FAILURE                      -4003
#define ANS_MEM_MALLOC_FAILURE                      -4004
#define ANS_MEM_FREE_FAILURE                        -4005
#define ANS_MEM_REALLOC_FAILURE                     -4006
#define ANS_MEM_UNLOCK_FAILURE                      -4007
#define ANS_MEM_LOCK_FAILURE                        -4008
#define MALLOC_IN_FIRST_POOL_FAILURE                -4009
#define REALLOC_IN_FIRST_POOL_FAILURE               -4010
#define ALLOC_NEGATIVE_LENGTH                       -4011
#define REALLOC_NEGATIVE_LENGTH                     -4013
#define C_RIGHT_DEBUG_PAD_VIOLATED                  -4016
#define F_RIGHT_DEBUG_PAD_VIOLATED                  -4017
#define C_LEFT_DEBUG_PAD_VIOLATED                   -4018
#define F_LEFT_DEBUG_PAD_VIOLATED                   -4019
#define MEM_NO_DEBUGGING_PADS                       -4020
#define ANS_MEM_HANDLE_FAILURE_ON_ALLOC             -4021
#define ANS_MEM_HANDLE_FAILURE_ON_FREE              -4022
#define ANS_MEM_GROUP_FREE_FAILURE                  -4023
#define MEM_DEBUG_MASK                              -4024

#define RESTRICTED_MALLOC_FAILURE                   -5001

#define BAD_TYPE_FLAG_ON_ALLOC                        -57
#define BAD_TYPE_FLAG_ON_REALLOC                      -58
#define MEM_ANSYS_FAILURE                            -101
#define MEM_COMMAND_FAILURE                          -102

#define LOW_LEVEL_MEMORY_MANAGER                    -6001

/*  Set this variable to 1 to enable memory block shuffling (not implemented 
    at this time)
#define BLOCK_SHUFFLING                           1   
*/

/* various definitions for the manager */
#define DEBUG_FILL               (CHAR)0xCC
#define MB                       (1024*1024)
#define GB                       (1024*1024*1024)
#define INITIAL_MEM_TABLE_SIZE   500
#define INITIAL_NUM_MEM_POOLS    10
#define BLOCK_NAMES_SIZE         16
#define C_CALL                   -10001
#define LOCKMEMMGR               88  /* THIS MUST ALWAYS MATCH LOCKMEMMGR1 IN 
                                        locknm.inc !!! */

#if defined (PTR64)
# define COMMON_ALIGNMENT_SIZE    4
#else
# define COMMON_ALIGNMENT_SIZE    5
#endif

#if defined (DEVELOPMENT)
# define MEM_BOUNDS_PAD_DEFAULT      24
# define LLM_MODE_DEFAULT            ECHO_ERROR_MESSAGES+FREE_GROWTH_BLOCKS
# define MEM_MODE_DEFAULT            ECHO_ERROR_MESSAGES+RANGE_PADS
#else
# define MEM_BOUNDS_PAD_DEFAULT      0
# define LLM_MODE_DEFAULT            FREE_GROWTH_BLOCKS
# define MEM_MODE_DEFAULT            0
#endif

/* various internal symbols */
#define FREE_BLOCK     0
#define USED_BLOCK     1
#define UNUSED_MEM_NODE -1

#define UNLOCKED_BLOCK 0
#define LOCKED_BLOCK   1

#define BOTH_FREE  -1
#define UPPER_FREE -2


/* error codes for the debugging pads */
#define LOWER_FROM_LEFT                            BIT_1
#define LOWER_FROM_RIGHT                           BIT_2
#define LOWER_WHOLE                                BIT_3
#define LOWER_OTHER                                BIT_4
#define UPPER_FROM_LEFT                            BIT_5
#define UPPER_FROM_RIGHT                           BIT_6
#define UPPER_WHOLE                                BIT_7
#define UPPER_OTHER                                BIT_8


/* error states for determining failures within the memory table */
#define TABLE_LENGTH_POINTER_MISALIGNMENT          BIT_1
#define TABLE_BACK_POINTER_CLOBBERED               BIT_2
#define TABLE_NEXT_PREV_MISALIGNMENT               BIT_3
#define TABLE_BLOCK_ADDRESS_NOT_ALIGNED            BIT_4
#define TABLE_POOL_SIZES_CHECK_MALLOC_FAILURE      BIT_5
#define TABLE_USED_COUNT_MISMATCH                  BIT_6
#define TABLE_HIGHEST_USED_MISMATCH                BIT_7
#define TABLE_USED_TO_HERE_MISMATCH                BIT_8
#define TABLE_POOL_SIZE_MISMATCH                   BIT_9
#define TABLE_DOESNT_WRAP                         BIT_10
#define TABLE_POOL_COUNT_MISMATCH                 BIT_11
#define TABLE_ADJACENT_FREE_BLOCKS                BIT_12
#define TABLE_MEM_SIZE_MISMATCH                   BIT_13
#define TABLE_NEXT_PREV_CLOBBER                   BIT_14
#define TABLE_NONDESTROYED_NODES                  BIT_15

#define TABLE_HIGH_BLOCK_NOT_IN_LOW_TABLE          BIT_1
#define TABLE_HIGH_BLOCK_POINTS_TO_UNUSED_NODE     BIT_2
#define TABLE_HIGH_BLOCK_NOT_USED                  BIT_3
#define TABLE_HIGH_BLOCK_HAS_BAD_SIZE              BIT_4
#define TABLE_LOW_BLOCK_NOT_IN_HIGH_TABLE          BIT_5


/* stuff for the virtual memory manager */
#define INITIAL_NUM_VIRT_MEM_PAGES                   500
#define STACK_NULL                                    -1
#define INITIAL_NUM_VIRT_MEM_POOLS                    10
#define PAGE_ON_DISK                               -1001
