////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         	Copyright (C) 2010 ANSYS Inc.  All Rights Reserved             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MAT_MaterialModel.h $
// $Revision: 1.7 $ 7.0
// $Date: 2010/04/06 19:56:50 $ March 28 2002
// $Author: srpailla $ rjayasee/jlo
//
// Decription :
//
//	Collection of Experimental Data for a single Material. This has to be 
//  evolved to include all kinds of data that might come in from experiments
//////////////////////////////////////////////////////////////////////////////

#if !defined(MAT_EXPERIMENTALDATASET_H)
#define MAT_EXPERIMENTALDATASET_H

#include "ANS_StandardIncludes.h"
#include "MAT_ExperimentalData.h"

class MAT_ExperimentalDataSet  
{
	public:
		MAT_ExperimentalDataSet();
        //Constructor

		virtual ~MAT_ExperimentalDataSet();
        //Destructor

		bool AddExperimentalData( MAT_ExperimentalData* pExpDat ) ;
		//R-bool
        //I-pExpDat
        //I-ExperimentalData Pointer
        //I-Adds an experimental data object to the Set

		MAT_ExperimentalData* GetExperimentalData( INT iIndex ) ;
		//R-MAT_ExperimentalData*
        //I-iIndex
        //I-index for the exp data
        //F-Get an experimental data object given the index

		MAT_ExperimentalData* GetExperimentalData( ANS_String oNameExpDat ) ;
		//Get a material response given the name of response
		//Enum?? Should this be here. ?? to be reviewed ??

		void GetExperimentalDataNameList
            ( vector<const ANS_String*>& oNameExpNameList ) ;
        //R void
        //O oNameExpNameList
        //O-Vector of Experiment Names
        //- Return a vector of Experiment Names

        INT GetNumberOfExperimentalData() const ;
        //R-INT
		//F-Get a material response given the name of response

        void Print() ;
        //R void
        //- Print Function

        bool DeleteExperimentalData ( INT iExpIndex ) ;
		//R-bool
        //F-Remove Material Response given the name
        //I iExpIndex
        //I-Reimplement this for given an index
        //- Delete an experimental data by index

        bool RemoveExperimentalData ( INT iExpIndex ) ;
		//R-bool
        //F-Remove Material Response given the name
        //I iExpIndex
        //I-Reimplement this for given an index
        //- Remove an experimental data by index. !!! Does not delete

    private:
        vector <MAT_ExperimentalData*> m_oExperimentalDataVector ;
		//List of graphs that describe the material
		//The graphs describe themselves.
};

#endif // !defined(MAT_EXPERIMENTALDATASET_H)
