////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         Copyright (C) 2010 ANSYS Inc.  All Rights Reserved             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MAT_MemoryManager.h $
// $Revision: 1.6 $ 7.0
// $Date: 2010/04/06 20:21:12 $ October 21 2003
// $Author: srpailla $ rjayasee
//
// Description :
//          Memory Manager for the Material Routines
////////////////////////////////////////////////////////////////////////////

#if !defined(MAT_MemoryManager_H)
#define MAT_MemoryManager_H

#include "ANS_StandardIncludes.h"

extern "C"
{
    void *cAnsMemAlloc(size_t length, INT key, CHAR *fileName, INT lineNum);
    void cAnsMemFree(void *memPtr, CHAR *fileName, INT lineNum);
}

#define MAT_MALLOC(x) cAnsMemAlloc((x),0,__FILE__,__LINE__)
#define MAT_FREE(x) cAnsMemFree((x),__FILE__,__LINE__)

#define MAT_FASTMALLOC(x)  MAT_MemoryManager::Instance()->Malloc((x),__FILE__,__LINE__)
#define MAT_FASTFREE(x)    MAT_MemoryManager::Instance()->Free((x),__FILE__,__LINE__)

class MAT_MemoryManager
{
    public:

    static MAT_MemoryManager* Instance() 
    {
        if ( m_pMAT_MemoryManager == NULL )
        {
            m_pMAT_MemoryManager = new MAT_MemoryManager ;
        }
        return m_pMAT_MemoryManager ;
    };
    //Singleton

    static void Destroy() 
    {
        delete m_pMAT_MemoryManager ;
        m_pMAT_MemoryManager = NULL ;
    };
    //Destructor

    void Init() ;
    //Initializes the Memory Manager

    void CleanUp() ;
    //Cleans up all memory

    void *Malloc(size_t iLength, CHAR *pFileName, INT iLineNum);
    //R void*
    //R-Pointer to the allocator memory
    //I length
    //I-length of the memory
    //I pFileName
    //I File Name where allocated
    //I iLineNum
    //I-Line Number where allocated

    void Free(void *pMemPtr, CHAR *pFileName, INT iLineNum);
    //R void
    //I pMemPtr
    //I-Pointer to the memory to be deleted
    //I pFileName
    //I File Name where allocated
    //I iLineNum
    //I-Line Number where allocated

    void CleanUp(INT iTagIndex) ;
    //R void
    //- Clean up current tag

    void Init(INT iNumTags) ;
    //R void
    //- Initializes all the necessary Tag memory

    protected:

    MAT_MemoryManager() 
    {
        m_pTagId = NULL ;
        m_iNumTags = 0 ;

    }
    //Creates/Initializes a Tag Memory

    ~MAT_MemoryManager() 
    {
        if ( NULL != m_pTagId )
        {
            for ( INT iIndex = 0 ; iIndex < m_iNumTags ; iIndex++ )
            {
                CleanUp( iIndex ) ;
            }
            MAT_FREE(m_pTagId) ;
            m_pTagId = NULL ;
        }
    };
    //Destroy Tag Memory


    INT* m_pTagId ;
    INT m_iNumTags ;

    static MAT_MemoryManager* m_pMAT_MemoryManager ;
} ;



#endif
