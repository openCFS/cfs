/*
////////////////////////////////////////////////////////////////////////////////
//
//          File: ali_string_utilities.h
//
//     Copyright: 2003-2010 ANSYS, Inc. - All Rights Reserved
//
//        Author: Tony Cavada
//       Created: 03/22/2010
//
//   Description: 
//
////////////////////////////////////////////////////////////////////////////////
//
*/
#ifndef _ALI_STRING_UTILITIES_
#define _ALI_STRING_UTILITIES_

#ifdef _UNICODE
#  define ALI_UNICODE
#endif

#if defined(ALI_UNICODE)
#  define ALI_CHAR            wchar_t
#  define ALI_STRING          wstring
#  define ALI_T(x)            L ## x
#  define ALI_TOLOWER         towlower
#  define ALI_TOUPPER         towupper
#  define ALI_OSTRINGSTREAM   wostringstream
#  define ALI_ISTRINGSTREAM   wistringstream
#  define ALI_COUT            wcout
#  ifdef _WIN32
#     define ALI_VSPRINTF(buf, buf_size, format, args)   vswprintf_s(buf, buf_size, format, args)
#     define ALI_STRCPY(dest, dest_size, src)            wcscpy_s(dest, dest_size, src)
#  else
#     define ALI_VSPRINTF(buf, buf_size, format, args)   vswprintf(buf, format, args)
#     define ALI_STRCPY(dest, dest_size, src)            wcscpy(dest, src)
#  endif

#  define ALI_LC_STRING       wstring_makelower
#  define ALI_GET_LIST        wget_list
#else
#  define ALI_CHAR            char
#  define ALI_STRING          string
#  define ALI_T(x)            x
#  define ALI_TOLOWER         tolower
#  define ALI_TOUPPER         toupper
#  define ALI_OSTRINGSTREAM   ostringstream
#  define ALI_ISTRINGSTREAM   istringstream
#  define ALI_COUT            cout
#  ifdef _WIN32
#     define ALI_VSPRINTF(buf, buf_size, format, args)   vsprintf_s(buf, buf_size, format, args)
#     define ALI_STRCPY(dest, dest_size, src)            strcpy_s(dest, dest_size, src)
#  else
#     define ALI_VSPRINTF(buf, buf_size, format, args)   vsprintf(buf, format, args)
#     define ALI_STRCPY(dest, dest_size, src)            strcpy(dest, src)
#  endif

#  define ALI_LC_STRING       string_makelower
#  define ALI_GET_LIST        get_list
#endif

#  if defined(c_plusplus) || defined(__cplusplus)
#  include <string>
#  include <list>
#  include <map>

#  if !defined(HP_SYS) || defined(_HP_NAMESPACE_STD)
      using namespace std;
#  endif

   bool ans_StringToInt(const ALI_STRING &s, int &i);
   bool strings_nocase_equal(ALI_STRING sLeft, ALI_STRING sRight);
   bool all_digit_string(ALI_STRING sString);
   bool in_list(list<ALI_STRING>& l, ALI_STRING s);
   bool value_on(ALI_STRING str_value);
#  ifndef value_off
#     define value_off(sVal) !value_on(sVal)
#  endif

   int ans_StringToInt(const ALI_STRING& sStr);
   int lower_case(int c);

   list<ALI_STRING> ALI_GET_LIST(ALI_STRING s, const ALI_STRING delim, bool bIgnoreQuotes = true);
   list<ALI_STRING> unique_list(list<ALI_STRING> input);

   map<ALI_STRING,ALI_STRING> get_map(ALI_STRING s,ALI_STRING sep, ALI_STRING equal);

   ALI_STRING NoExtraSpaces(ALI_STRING s);
   ALI_STRING NoSpaces(ALI_STRING s);
   ALI_STRING NoAllSpaces(ALI_STRING s);
   ALI_STRING ans_IntToString(int number);
   ALI_STRING quote_filename(ALI_STRING sFile);
   ALI_STRING unquote_filename(ALI_STRING sQuotedFile);
   ALI_STRING ALI_LC_STRING(ALI_STRING str_mixed);
   ALI_STRING string_makeupper(ALI_STRING str_mixed);
   ALI_STRING string_trimall(ALI_STRING str_buffered);
   ALI_STRING string_replacestring(ALI_STRING sInStr, ALI_STRING sReplaceStr, ALI_STRING sWithStr);
   ALI_STRING format_string(const ALI_CHAR* szFormat, ...);
   ALI_STRING ans_ListToString(list<ALI_STRING>& listIn, ALI_STRING sSep);
#  endif

#endif
