/* 
 * ***copyright(c) 2011 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */
#if defined(PCWINNT_SYS)
    /*  fortran routines called from c  */
extern LPTHREAD_START_ROUTINE CALLTYP cmap_( char [] ,int, char [], int, int *, int * );
#endif

void   CALLTYP xstart_( void );
void   CALLTYP cmapstop_( void );
