
#include "ansysdef.h"

/****************************************************************
 global-level structure for ANSYS nodal body loads
 ****************************************************************/
struct ansNodeBodyLoad_str { /* Name of the structure                                   */
  INT       tag;             /* Tag for this instance of the nodal body loads structure */
  INT       *numDef;         /* Number of defined body loads for each body load type    */
  INT       *maxSize;        /* Maximum number of values stored for each body load type */
};

#define ansNodeBodyLoadTag(load)                (load->tag)

#define ansNodeBodyLoadNumDefPtr(load)          (load->numDef)
#define ansNodeBodyLoadNumDefVec(load,i)        (load->numDef[i])
#define ansNodeBodyLoadMaxSizePtr(load)         (load->maxSize)
#define ansNodeBodyLoadMaxSizeVec(load,i)       (load->maxSize[i])



/******************************************************************
 data-level structure for ANSYS nodal body loads
 ******************************************************************/
struct nodeBodyLoadData_str {   /* Name of the structure                                        */
  char              modified;   /* Flag indicating whether this body load has been modified     */
  char              internal;   /* Flag indicating whether this body load is internal to object */
  INT               loadType;   /* Type of body load (see ansysdef.h for possible values)       */
  char              active;     /* Flag indicating if body load is active or inactive           */
  INT               numValues;  /* Number of values stored for this nodal body load             */
  DOUBLE           *values;     /* Array containing nodal body load values (numValues long)     */
                                /* NOTE: the first numValues/2 values are the current values    */
                                /* and the second numValues/2 values are the previous values    */
  nodeBodyLoadData *nextLoad;   /* Pointer to the next nodal body load data structure for       */
                                /* this node.  If this pointer is NULL, then this is the last   */
                                /* stored body load for this node                               */
};

#define nodeBodyLoadDataModified(nData)         (nData->modified)
#define nodeBodyLoadDataInternal(nData)         (nData->internal)
#define nodeBodyLoadDataType(nData)             (nData->loadType)
#define nodeBodyLoadDataActive(nData)           (nData->active)
#define nodeBodyLoadDataNumValues(nData)        (nData->numValues)

#define nodeBodyLoadDataValuesPtr(nData)        (nData->values)
#define nodeBodyLoadDataValuesVec(nData,i)      (nData->values[i])

#define nodeBodyLoadDataNextLoadPtr(nData)      (nData->nextLoad)

