////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         Copyright (C) 2010 ANSYS Inc.  All Rights Reserved             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MAT_Ogden.h $
// $Revision: 1.6 $ 7.0
// $Date: 2010/04/06 20:21:12 $ March 28 2002
// $Author: srpailla $ rjayasee/jlo
//
// Decription :
//
//	This class is the ogden abstraction for material curve fitting
//////////////////////////////////////////////////////////////////////////////

#if !defined( MAT_OGDEN_H )
#define MAT_OGDEN_H


#include "MAT_HyperElasticNonLinearFit.h"
#include "MAT_OgdenVolumetricMode.h"

// #include "MAT_ConstitutiveFunction.h"
class MAT_ExperimentalDataSet ;

class MAT_Ogden : public MAT_HyperElasticNonLinearFit
{

public:

    MAT_Ogden();
    //Constructor

    bool SetPolynomialOrder( INT iOrder ) ;
    //R-bool
    //I-True if > 0
    //I-iOrder
    //I-Order of the Polynomial
    //I-Sets the Order of the Polynomial

    virtual INT GetNumberOfCoeffs() ;
    //R-bool
    //I-iOrder
    //I-Number of Coeffs
    //F-Set the Number of Coeffs
    //F-This is calculated from the polynomial order

    virtual bool CalculateFittedExperimentalDataPoint
                    ( double* pCoeffs,
                      INT iNumCoeffs,
                      ANS_String oExpName,
                      vector<double>& oPoint ) ;
    //R bool
    //R oExpName
    //R-Experiment Name
    //O-Input/Output point data

    virtual bool GenerateMaterialParametersWithLMMethod() ;
    //R-bool
    //F-Function that Generates the Material Parameters given
    //F-some experimental data with Levenberg Marquardt's Method

    virtual bool GenerateMaterialParametersWithNRMethod() ;
    //R-bool
    //F-Function that Generates the Material Parameters given
    //F-some experimental data with Newton's Method
    
    virtual bool DeleteCoefficients( MAT_FieldVariableCollection const& oField  ) ;
    //R bool
    //I oField
    //I-Field Variable
    //- Removes/Deletes the Variable Independent coefficients at a particular temp/...

    virtual void Print() ;
    //F-Print

  	virtual ~MAT_Ogden();
    //F-Destructor


private:

    INT m_iOrder ;
    //Order of the Polynomial
    //For Ogden the number of coeff = 2 * m_iOrder

    MAT_OgdenVolumetricMode m_oVolumetricMode ;

    bool AssembleDerivativesMatrices
         ( MAT_ExperimentalDataSet* pDataSet) ;
    //R-bool
    //I-pDataSet
    //I-Pointer to a ExpDataSet
    //F-Assemble the matrix to be solved for the parameters

    // Utility Functions to calculate the derivatives of the Ogden Potential
    double AlphaTerm( double dAlphaJ,  double dLambdaN, 
                      double dC,  INT iCOrder) ;
    //R-Value of the odgen function
    //I-dAlphaJ
    //I-Value of the Coeff Alpha
    //I-dLambdaN
    //I-Value of the Stretch
    //I-dC
    //I-Value of dC depending on the experiment
    //                              -1/2 for simple tension
    //                              -1 for pure shear
    //                              -2 for equibiaxial tension
    // iCOrder                      Order of C in the expression

    // Utility Functions to calculate the derivatives of the Ogden Potential
    double DeltaTerm( INT iJ,  INT iK ) ;
    //R-Value of the delta function
    //- 1 if i=j or 0 if i != j

    bool FunctionValue( double* dVariables,
                        INT iNumVariables,
                        double dLambdaN, 
                        MAT_ExperimentType iExpType,
                        double& dStressN ) ;
    //R bool
    //I dVariables
    //I-Coefficients
    //I dLambdaN
    //I-Stretch
    //I iExpType
    //I Experiment Type
    //- Calculates the function value
                               
    bool ErrorTerm( double* dVariables, 
                    INT iNumVariables,
                    double dLambdaN, 
                    double dStressN,
                    MAT_ExperimentType iExpType,
                    double& dResult ) ;
    //R-Value of the Derivative for a value of Stress and Strain
    //I dAlphaj
    //I-Coefficent Alpha in Ogden Expr
    //I dLambdaN
    //I-Value of Stretch
    //I dC
    //I-Value of C 
    //I-  -1/2 for simple tension
    //I-  -1 for pure shear
    //I-  -2 for equibiaxial tension
    //- Calculates the Error Term for a stress-lambda point

    
    bool FirstDerivativeOfUnsquaredError( double* dVariables, 
                                          INT iNumVariables,
                                          double dLambdaN, 
                                          double dStressN,
                                          MAT_ExperimentType iExpType,
                                          INT iVariableIndex,
                                          double& dResult ) ;
    //R-Value of the Derivative for a value of Stress and Strain
    //I dAlphaj
    //I-Coefficent Alpha in Ogden Expr
    //I dLambdaN
    //I-Value of Stretch
    //I dC
    //I-iExpType
    //I-  1 for simple tension
    //I-  2 for equibiaxial tension
    //I-  3 for pure shear
    //- Calculates the value of the first derivative of the error in stress
    //- (not squared though)

    bool FirstDerivativeTerm( double* dVariables, 
                              INT iNumVariables,
                              double dLambdaN, 
                              double dStressN,
                              MAT_ExperimentType iExpType,
                              INT iVariableIndex,
                              double& dResult ) ;
    //R-Value of the Derivative for a value of Stress and Strain
    //I dAlphaj
    //I-Coefficent Alpha in Ogden Expr
    //I dLambdaN
    //I-Value of Stretch
    //I iExpType
    //I-  1 for simple tension
    //I-  2 for equibiaxial tension
    //I-  3 for pure shear
    //- Calculates the value of the first derivative of the Ogden Potential
    //- for a stress/stretch point

    bool SecondDerivativeTerm( double* dVariables,
                               INT iNumVariables,
                               double dLambdaN, 
                               double dStressN,
                               MAT_ExperimentType iExpType,
                               INT iVariableIndexJ,
                               INT iVariableIndexK,
                               double& dResult ) ;
    //R-true if if was a success
    //I dAlpha
    //I-Coefficent Alpha in Ogden Expr
    //I dMu
    //I-Coefficent Mu in Ogden Expr
    //I dLambdaN
    //I-Value of Stretch
    //I dStressN
    //I-Value of Stress
    //I iExpType
    //I-  1 for simple tension
    //I-  2 for equibiaxial tension
    //I-  3 for pure shear
    //I-iVariableIndexJ
    //I-Variable by which it is differentiated first
    //I-iVariableIndexK
    //I-Variable by which it is differentiated next
    //O-dResult
    //I-Value of the second derivative
    //- Calculates the value of the first derivative of the Ogden Potential
    //- for a stress/stretch point

    bool Assemble1stDerivativeMatrix
        ( double* dCoeffs,
          INT iNumCoeffs,
          double** d1stDerMatrix ) ;
    //R-Status of the function
    //I pDataSet
    //I-Collection of Experimental Data
    //I dCoeff                      
    //I-array of coefficients
    //I iNumCoeffs                  
    //I-Number of Coefficients
    //I d1stDerMatrix               
    //I-The Resulting Matrix of 1st Derivatives
    //-Assemble the RHS Matrix for the Newton-Raphson Loop  
    
    bool Assemble2ndDerivativeMatrix
    ( double* dCoeffs,
      INT iNumCoeffs,
      double** d2ndDerMatrix ) ;
    //R-Status of the function
    //I dCoeff                      
    //I-array of coefficients
    //I iNumCoeffs                  
    //I-Number of Coefficients
    //I d1stDerMatrix               
    //I-The Resulting Matrix of 2nd Derivatives
    //-Assemble the RHS Matrix for the Newton-Raphson Loop

    double GetCFromExpType(INT iExpType) ;
    //R C
    //R Return C from Experiment Type.= 1/2/3
};

#endif // !defined(MAT_OGDEN_H)
