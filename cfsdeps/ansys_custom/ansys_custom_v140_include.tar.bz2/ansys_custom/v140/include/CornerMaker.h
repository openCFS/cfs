#ifndef _CORNERMAKER_H_
#define _CORNERMAKER_H_

/*****************************************************************************
 *                   Copyright (C) 1999 CMSoft                               *
 *                                                                           *
 *  These lines of code and declarations contain unpublished proprietary     *
 *  information of CMSoft. They may not be copied or duplicated in whole     *
 *  or part without prior authorization from CMSoft.                         *
 *                                                                           *
 *****************************************************************************/

#include <fstream>

class FSElement;
class FSCoordSet;
class FSConnectivity;
class FSSubDTopo;
class FSCommunicator;
class DofSetArray;
class DofSet;
template <class T> class FSCommPattern;
class BCond;
class FSFullMatrix;
class FSSubDomCore;
class FSDistInfo;
class FSCoreSolver;
class FSDistVector;
class FSVector;
class FSAssembledSolver;
class EqNumberer;
class FSInfo;
class ConstrainedDSA;
class FSCommunicator;
class StackFSFullMatrix;
class FSSubPreprocessor;
class RectSparse;
class C_Communicator;

#include "FSConnectivity.h"
#include "FSInfo.h"

// This class is the algorithmic class to select corner nodes
class FSSubCornerHandler 
{
  int _dim;
  int _glNumSub;
  int _glSubNum;
  int _nnodes, _numEle;
  int *_localNodes;
  int *_deg;
  int *_weight;
  bool *_isCorner;
  FSInfo *_fsInfo;
  bool *_isSafe; // this is true if this node is safe for this sub 
  //AND the neighbor
  bool *_isLocalSafe; // This is true if this node is safe for me
  int _nNeighb;
  FSConnectivity &_sharedNodes;
  FSConnectivity &_nToN;
  int *_neighbSubs;
  int *_sendID, *_recID;
  FSCoordSet &_nodes;
  FSElement **_eles;
  DofSetArray &_dsa;
  set<int> &_types; 
  int *_isUserSingularDomain;
  int *_userCornerNode;
  // Total number of corner candidates for this sub
  int _nTC;
  bool checkForColinearCrossPoints(int numCornerPoints,
				   int *localCornerPoints);
  void addPotCornerPoints(int numShared, int *allNodes, bool *isSafe, bool *isCorner);
  
public:
  FSSubCornerHandler(int totsub, int sub, int nn, int *localNodes, 
		     FSCoordSet &n, int nele, FSElement **el, FSConnectivity &nTn, set<int> &types,
		     DofSetArray &d, FSConnectivity &sh, int *sid, int *rid, int *nsb, FSInfo *fsInfo);
  ~FSSubCornerHandler();
  void dispatchMultiDegNodes(FSCommPattern<int> *);
  void markMultiDegNodes(FSCommPattern<int> *);
  void dispatchSafeNodes(FSCommPattern<int> *, int *isContactLagNode, bool *, int *, bool);
  void markSafeNodes(FSCommPattern<int> *);
  void dispatchRotCorners(FSCommPattern<int> *);
  void markRotCorners(FSCommPattern<int> *);
  void HandleUserCornerNodes(FSCommPattern<int> *, int*, int*, int*);
  void HandleLink(FSCommPattern<int> *, int*, int*, bool);
  void HandlePenaltyContact(FSCommPattern<int> *, int*, int*, int*);
  // This routine internaly marks corner candidates
  // and returns the numbers of corners in 2 numbers. The ones for which
  // this subdomain is master and the total number of corners connectivities
  void countAndMarkCornerCand(int *mync, int *totnc);
  // get corner XYZ collects the coordinates of the
  // corner candidates and in addition lets the caller know which ones
  // are already essential corners and finaly fills the corner to sub 
  // connectivity data
  void getCornerXYZ(int *, double (*)[3], int *essent, int *cTsP, int *cTsT);
  // dispatchNumbering sends to the the neighbors the numbering of corners
  void printCornerNodes1(int *cPerSub);
  void printCornerNodes2(int *essential, int *cPerSub);
  void computeNbCornerSub(int *essential, int *cPerSub, int *nbMasterCorners, int **matNbCorners);
  void printNbCornerSub(int *nbMasterCorners, int **matNbCorners);
  void buildCToAnsysNum(int *cPerSub, int *cBeforeToAnsysNum);
  void dispatchNumbering(FSCommPattern<int> *, int *, bool *, int *, int *glList, int *origFC,
			 int *newFC, int *cntNum, bool cornerOnMPC);
  void dispatchInitialNumbering(FSCommPattern<int> *pat, int *firstC);
  void recNumbering(FSCommPattern<int> *, FSSubPreprocessor *, int *fMaster);
  void recInitialNumbering(FSCommPattern<int> *pat, int *numRotCrn);
  void listRotCorners(int *fN, int *crnNum);
  void countContact(int *, int *, int *crnMrk);
  void setDim(int d) { _dim = d; }
  void setUserSingularDomain(int *isUserSingularDomain) {_isUserSingularDomain = isUserSingularDomain;};
  void setUserCornerNode(int *userCornerNode) {_userCornerNode = userCornerNode;};
  
  void resendNumbers(FSCommPattern<int> *pat);
  void checkNumbers(FSCommPattern<int> *pat);
};

class FSCornerMaker 
{
  int _dim;  // 3D 2D or 1D
  int _nSub;
  int _glNumSub;
  int _numNodes;	// of this CPU
  bool _cornerOnMPC;
  bool _setPilotNodeAsCorner;
  int *_isUserSingularDomain;
  int *_userCornerNode;
  FSSubCornerHandler **_cornerHandler;
  FSCommPattern<int> &_cpat;
  FSSubPreprocessor **_subPreProc;
  C_Communicator *_comm;
  int *_elemToSub;
  void makeCornerHandler(int iSub, FSSubPreprocessor**subPre);
  
public:
  // The last parameters indicates if this is a 3 d problem, 2d or 1d
  FSCornerMaker(int nGlobSub, int nLocSub, int numNode, FSSubPreprocessor **, 
		C_Communicator *, FSCommPattern<int> &, int *, int d, bool, bool, int*, int*);
  int makeCorners(C_ContactPairMgr *, C_Gcpce *, C_Gcpce *, C_Gelem *, C_Gcpce *);
  void chooseCorners(int *glCornerList, double (*xyz)[3], int *cToAnsysNum,
		     FSConnectivity &cNConnect, FSConnectivity &subToRotCrn);
     
};

#endif
