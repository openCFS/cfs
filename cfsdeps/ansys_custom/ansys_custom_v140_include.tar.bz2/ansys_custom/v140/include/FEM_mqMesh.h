
/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 2009 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_MapQuadMesh.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_MapQuadMesh.h
 *  header file for FEM_MapQuadMesh.c
 *
 */
#ifndef FEM_MQ_MESH_INCLUDE
#define FEM_MQ_MESH_INCLUDE

/*----------------- Globally accessible function prototypes -----------------*/

                      /* =================================================== */
                      /* === FEM_mqMesh: Given a rectangular region bounded  */
                      /* === Nodes and edges, map mesh the region with quads.*/
                      /* === Return: EXIT_SUCCESS or EXIT_FAILURE            */
                      /* =================================================== */
INT FEM_mqMeshRegion(
   INT area,          /* (IN)  area to map mesh                              */
   NODE_OBJ *aobj_nodes,/*(IN) Nodes int boundary of region in clockwise    */
                      /*       order starting at one of the corners.  The    */
                      /*       length of this array is                       */
                      /*       2 * num_nodes1 + 2 * num_nodes2               */
                      /*                                                     */
                      /*                       [15][16][17]                  */
                      /*     aobj_nodes[14] *---*---*---*---* aobj_nodes[0]  */
                      /*                    |               |                */
                      /*     aobj_nodes[13] *               * aobj_nodes[1]  */
                      /*                    |               |                */
                      /*     aobj_nodes[12] *               * aobj_nodes[2]  */
                      /*                    |               |                */
                      /*     aobj_nodes[11] *               * aobj_nodes[3]  */
                      /*                    |               |                */
                      /*     aobj_nodes[10] *               * aobj_nodes[4]  */
                      /*                    |               |                */
                      /*     aobj_nodes[ 9] *---*---*---*---* aobj_nodes[5]  */
                      /*                       [8] [7] [6]                   */
                      /*                                                     */
                      /*       num_nodes1 = 5                                */
                      /*       num_nodes2 = 4                                */
                      /*                                                     */
                      /*       It is assumed that these nodes have been      */
                      /*       projected to area and that their uv           */
                      /*       coordinates are updated with the correct uv   */
                      /*       coordinates for area.                         */
                      /*                                                     */
   INT num_nodes1,    /* (IN)  number of divisions in first direction along  */
                      /*       region.                                       */
   INT num_nodes2,    /* (IN)  number of divisions in second direction along */
                      /*       region.                                       */
   FEM_BOOLEAN
           fan_mapped,/* (IN)  TRUE if one side of the mapped mesh is        */
                      /*       degenerated into a single point causing tris  */
                      /*       to be created around it.                      */
   FEM_BOOLEAN midnodes,/*(IN) TRUE if area needs midnodes.                  */
   INT debug, INT iCase );       /* (IN)  debug flag                                    */
                      /* =================================================== */

                      /* =================================================== */
                      /* === FEM_mqNewPoint: Given a 2d point, a 2d          */
                      /* === direction and a 3d distance, get a new point in */
                      /* === 2d that is that far away in the specified       */
                      /* === direction.                                      */
                      /* === Return: void.                                   */
                      /* =================================================== */
INT FEM_mqNewPoint(
   DOUBLE u,          /* (IN)  2d point                                      */
   DOUBLE v,
   DOUBLE vect_u,     /* (IN)  2d direction.                                 */ 
   DOUBLE vect_v,
   DOUBLE dist3d,     /* (IN)  3d distance.                                  */
   INT flat,          /* (IN)  if area is flat or not.                       */
   DOUBLE *u_out,     /* (OUT) the new point.                                */
   DOUBLE *v_out );

                      /* =================================================== */
                      /* === FEM_mqDist3D: Calculate the 3d Distance between */
                      /* === 2 points.                                       */
                      /* === Return: void.                                   */
                      /* =================================================== */
INT FEM_mqDist3D(
   NODE_OBJ obj_node1,
   NODE_OBJ obj_node2,
   INT flat,
   DOUBLE *dist3d );

                      /* =================================================== */
                      /* === FEM_mqDist3D_UV: Calculate the 3d Distance between */
                      /* === 2 points.                                       */
                      /* === Return: void.                                   */
                      /* =================================================== */
INT FEM_mqDist3D_UV(
   DOUBLE *uv1,
   DOUBLE *uv2,
   DOUBLE *dist3d );
                      /* =================================================== */
                      /* === FEM_mqDist3D_II: Calculate the 3d Distance      */
                      /* === between 2 points.                               */
                      /* === Return: void.                                   */
                      /* =================================================== */
INT FEM_mqDist3D_II(
   VECTOR3D *node1_xyz,
   VECTOR3D *node2_xyz,
   POINT2D *node1_uv,
   POINT2D *node2_uv,
   INT flat,
   DOUBLE *dist3d );

                      /* =================================================== */
                      /* === FEM_mqCleanUp: Free up any memory used by this  */
                      /* === module not needed anymore.                      */
                      /* === Return: void.                                   */
                      /* =================================================== */
void FEM_mqCleanUp( void );

void FEM_mqSetMapMeshMethod( INT method );
INT  FEM_mqGetMapMeshMethod( void );

void FEM_mqSetArea( INT area );
INT FEM_mqAlignBySmoothCir( INT num_divs2 );
static INT fem_mqGetSideSmoothInfoCir(
   NODE_OBJ *aobj_nodes,
   INT num_nodes_dir1,
   INT *aiSmoothInfo);
#endif

