/* ********************************** */
/* *** ansys(r) copyright(c) 2009 *** */
/* *** ansys, inc.                *** */
/* ********************************** */

/*  FEM_aeMeshDataCCallable.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/* 
 *  FEM_aeMeshDataCCallable.h
 *  Mesh table xref mesh to fea entity
 *
 */
#ifndef FEM_AEMESHDATACCALLABLE
#define FEM_AEMESHDATACCALLABLE

#ifndef ux11
#ifdef DSPACE_CMDB
#pragma warning (disable:4786)
#endif
#endif



#ifdef __cplusplus
extern "C" {
#endif

INT FEM_aeNumMapRadialDivs( INT areaid );
INT FEM_aeIsSrcOrTrg( INT anum, INT *iIsSrcTrg );
INT FEM_aeSetPassQualityByLineSmoothing( INT anum );

#ifdef __cplusplus
}
#endif

#endif
