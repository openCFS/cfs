#ifndef FEM_KPPUBLIC
#define FEM_KPPUBLIC

#include "FEM_cdbtypes.h"
#include "FEM_Public.h"
#include "FEM_cell.h"

class KP_TYP : public CELL_TYP {

   private:
      DOUBLE m_x, m_y, m_z;
      unsigned m_linehpt:1;
      unsigned m_areahpt:1;

   public:
      inline KP_TYP() { InitKP();};
      ~KP_TYP() { };
      void Delete() { DeleteCell(); };
      inline KP_PTYP GetNext( ) { return (KP_PTYP)CELL_TYP::GetNext(); };
      inline void InitKP( ) 
      { 
          setType( 0 );
          m_x = m_y = m_z = 0.0;
          m_areahpt = 0;
          m_linehpt = 0;
      };
      inline void InitKpCell() { InitCELL(); InitKP(); };
      inline DOUBLE GetX() const { return m_x; };
      inline DOUBLE GetY() const { return m_y; };
      inline DOUBLE GetZ() const { return m_z; };
      inline void XYZ( VECTOR3D *ps_xyz ) const { ps_xyz->x = m_x;
                                                  ps_xyz->y = m_y;
                                                  ps_xyz->z = m_z; };
      inline void SetX( const DOUBLE x ) { m_x = x; };
      inline void SetY( const DOUBLE y ) { m_y = y; };
      inline void SetZ( const DOUBLE z ) { m_z = z; };


      inline INT AreaList( AREA_PTYP **aobj_areas, INT &num_areas ) const
      {
         return List2LevelsAbove( (CELL_PTYP**)aobj_areas, num_areas );
      }

      inline INT VolList( VOL_PTYP **aobj_vols, INT &num_vols ) const
      {
         return List3LevelsAbove( (CELL_PTYP**)aobj_vols, num_vols );
      }

      inline void SetIsAreaHardPoint( const FEM_BOOLEAN hpt = TRUE )
      {
         if ( hpt ) m_areahpt = 1;
         else m_areahpt = 0;
      }

      inline void SetIsLineHardPoint( const FEM_BOOLEAN hpt = TRUE )
      {
         if ( hpt ) m_linehpt = 1;
         else m_linehpt = 0;
      }

      inline FEM_BOOLEAN IsAreaHardPoint() const
      {
         if ( m_areahpt == 1 ) return TRUE;
         else return FALSE;
      }

      inline FEM_BOOLEAN IsLineHardPoint() const
      {
         if ( m_linehpt == 1 ) return TRUE;
         else return FALSE;
      }

      inline FEM_BOOLEAN IsHardPoint() const
      {
         if ( m_linehpt == 1 || m_areahpt ) return TRUE;
         else return FALSE;
      }

      inline INT NumAdjLines() const { return NumAdjCells(); };

      inline LINE_PTYP GetAdjLine() const { return (LINE_PTYP)GetAdjCell(); };

      inline LINE_PTYP GetNextAdjLine( LINE_PTYP obj_line ) const
      {
         return (LINE_PTYP)GetNextAdjCell( (CELL_PTYP)obj_line );
      };

}; 

#endif
