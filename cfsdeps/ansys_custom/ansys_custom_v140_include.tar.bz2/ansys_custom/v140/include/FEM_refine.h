/*  FEM_refine.h */
/*
 * *** ansys(r) copyright(c) 2009
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_refine.h
 *  header file for FEM_refine.c
 *
 */
#ifndef FEM_REFINE_INCLUDE
#define FEM_REFINE_INCLUDE

/*------- the algorithm numbers --------------------------------------*/
#define TWO_REF   0
#define THREE_REF 1

/* ---------- ansys specific requirements */
#ifndef EXTERNAL_COMPILE
extern INT g_ref_command;          /* the current refinement command */
#define KREF    1
#define LREF    2
#define AREF    3
#define EREF    5
#define NREF    6
#endif

extern INT g_quads_refined;

/*------- the marking possibilities ----------------------------------*/
#define ONE_CASE1 ((1<<0))   /* node 0 marked */
#define ONE_CASE2 ((1<<1))   /* node 1 marked */
#define ONE_CASE3 ((1<<2))   /* node 2 marked */
#define ONE_CASE4 ((1<<3))   /* node 3 marked */

#define TWOADJ_CASE1 ((1<<0) | (1<<1))   /* nodes 0 and 1 marked */
#define TWOADJ_CASE2 ((1<<1) | (1<<2))   /* nodes 1 and 2 marked */
#define TWOADJ_CASE3 ((1<<2) | (1<<3))   /* nodes 2 and 3 marked */
#define TWOADJ_CASE4 ((1<<3) | (1<<0))   /* nodes 3 and 0 marked */

#define TWOOPP_CASE1 ((1<<0) | (1<<2))   /* nodes 0 and 2 marked */
#define TWOOPP_CASE2 ((1<<1) | (1<<3))   /* nodes 1 and 3 marked */

#define THREE_CASE1 ((1<<1) | (1<<2) | (1<<3))   /* node 0 not marked */
#define THREE_CASE2 ((1<<0) | (1<<2) | (1<<3))   /* node 1 not marked */
#define THREE_CASE3 ((1<<0) | (1<<1) | (1<<3))   /* node 2 not marked */
#define THREE_CASE4 ((1<<0) | (1<<1) | (1<<2))   /* node 3 not marked */

#define ALL_MARKED  ((1<<0) | (1<<1) | (1<<2) | (1<<3)) /* all nodes
                                                               marked */

                        /* Error flags used in FEMa_reError */
#define ON_MESHED_LINE             1
#define ADJACENT_TO_MESHED_AREA    2
#define ADJACENT_TO_MESHED_VOLUME  3
#define ON_MESHED_VOLUME           4
#define ADJACENT_TO_CONTACT        5
#define NO_NODES_MARKED            6
#define REFINEMENT_SHP_CHK_FAILURE 9
#define NO_MIDNODES                10
#define ELEMS_NOT_SELECTED         11
#define NO_TRI_QUAD_ELEMS          13
#define UNSUPPORTED_VOLUME_ELEM    15
#define ILLEGAL_VOLUME_ELEM        16
#define TRANS_QUAD_IN_TRI_MESH     17
#define CANNOT_FIND_TRI            18
#define INVALID_GEO_ENTITY         19
#define NON_NEW_NODE               20
#define POOR_QUAD_SPLIT            21
#define DETACHED_CLEANUP           22
#define HEX_2_REFINEMENT           23
#define TRI_IN_RETAIN_QUADS        24
#define TWO_EDGE_RETAIN            25
#define REFINE_ASD_ERROR           26
#define NO_ELEMENTS                27
#define MORE_TET_IMPROVEMENT       28

#define REFINE_TET_MTYPE           RADIUS_RATIO
#define MIN_REFINEMENT_MEASURE     0.1
#define CLOCKS_PER_SECOND 1000000

/*----------------- Globally accessible function prototypes -----------------*/

#ifdef __cplusplus
extern "C" {
#endif

                             /* ============================================ */
                             /* === FEM_reDoRefinement:  Main entry point    */
                             /* === for refinement.  Whatever mesh that      */
                             /* === exists in the C meshing database is      */
                             /* === refined.  Before calling this routine, 4 */
                             /* === things must be done:                     */
                             /* ===    1.  The C meshing database must be    */
                             /* ===        filled with a mesh containing     */
                             /* ===        face and (if desired) volume      */
                             /* ===        elements.                         */
                             /* ===    2.  Set FACE_ELEM property in all     */
                             /* ===        face elements to distinguish      */
                             /* ===        between actual face elements and  */
                             /* ===        faces used only to define volume  */
                             /* ===        elements.  To set this property,  */
                             /* ===        call, FEM_faSetProperty() with    */
                             /* ===        property_mask = FACE_ELEM and     */
                             /* ===        status = TRUE.                    */
                             /* ===    3.  Initialize all lines and areas    */
                             /* ===        involved in the refinement by     */
                             /* ===        calling FEMe_InitAreas() and      */
                             /* ===        FEMe_InitLines()                  */
                             /* ===    4.  Nodes must be marked where        */
                             /* ===        refinement is desired. To mark a  */
                             /* ===        node, call FEM_noSetProperty()    */
                             /* ===        with property_mask == NODE_MARKED */
                             /* ===        and status == TRUE.               */
                             /* === Return: EXIT_SUCCESS or EXIT_FAILURE     */
                             /* ============================================ */
INT FEM_reDoRefinement (
   INT *num_marked,          /* (IN/OUT) number of nodes in mesh that are    */
                             /*          marked                              */
   INT algorithm,            /* (IN) THREE_REF or TWO_REF                    */
   INT *a_areas,             /* (IN) array of area ids which contain face    */
                             /*      elements being refined.                 */
   INT num_areas,            /* (IN) length of a_areas.                      */
   FEM_BOOLEAN detached,     /* (IN) if elements are detached from geometry. */
                             /*      if detached == TRUE, new nodes are      */
                             /*      projected to geometry.                  */
   FEM_BOOLEAN midnodes,     /* (IN) TRUE if refining quadratic elements     */
   FEM_BOOLEAN smooth,       /* (IN) TRUE if smoothing should be done after  */
                             /*       refinement                             */
   FEM_BOOLEAN cleanup,      /* (IN) TRUE if topological cleanup should be   */
                             /*      done after refinement.  If this is      */
                             /*      TRUE, then smooth is ignored and        */
                             /*      smoothing is always performed.          */
   FEM_BOOLEAN quadsplit,    /* (IN) TRUE if poorquads should be split into  */
                             /*      2 tris rather than keep a poor quad.    */
   DOUBLE tolerance,         /* (IN) tolerance for smoothing.  Required if   */
                             /*      either smooth == TRUE or cleanup == TRUE*/
   FEM_BOOLEAN usetarget,    /* (IN) TRUE if targetsize is used for          */
                             /*      termination, otherwise, use num_iters   */
   FEM_BOOLEAN retain,       /* (IN) TRUE if quads must maintained.          */
   INT num_iters,            /* (IN) number of iterations or refinement,     */
                             /*      this is only used if                    */
                             /*      usetarget == FALSE.                     */
   DOUBLE targetsize  );     /* (IN) targetsize of elements in refinement    */
                             /*      region.  This is only used if           */
                             /*      usetarget == TRUE.                      */


                             /* ============================================ */
                             /* === FEM_reProcessElements: refine elements   */
                             /* === in the current data base, based on the   */
                             /* === marked nodes.  If algorithm == TWO_REF,  */
                             /* === and retain != 0, but quads cannot be     */
                             /* === retained with TWO_REF, algorithm will    */
                             /* === be changed to THREE_REF and numsplits    */
                             /* === will be changed accordingly.             */
                             /* ============================================ */
INT FEM_reProcessElements (
   INT *num_splits,          /* (IN)  number of times this function will be  */
                             /*       called (for status window only)        */
   INT count,                /* (IN)  the current iteration                  */
   FEM_BOOLEAN midnodes,     /* (IN)  TRUE if midnodes in the model          */
   FEM_BOOLEAN detached,     /* (IN)  TRUE if not associated with solid      */
   FEM_BOOLEAN no_lines,     /* (IN)  TRUE if new nodes not on lines         */
   FEM_BOOLEAN all_tri,      /* (IN)  TRUE if all tri mesh                   */
   FEM_BOOLEAN retain,       /* (IN)  TRUE if quads must be maintained       */
   FEM_BOOLEAN topoclean,    /* (IN)  type of post processing, 0, 1, or 2    */
   INT *algorithm );         /* (IN)  TWO_REF or THREE_REF                   */

                             /* ============================================ */
                             /* === FEM_reAdjustMidnodes: After smoothing    */
                             /* === the midnodes will not be positioned      */
                             /* === correctly - go back and fix their        */
                             /* === locations based on the corner node       */
                             /* === locations.                               */
                             /* === Return: EXIT_SUCCESS or EXIT_FAILURE     */
                             /* ============================================ */
INT FEM_reAdjustMidnodes (
   EDGELIST_OBJ obj_edlist,  /* (IN) the edge list                          */
   EDGE_OBJ obj_oldedge);   /*(IN ) the edge to adjust up to, if NULL do all */
INT FEM_reAdjustMidnodesV1(); /* this routine is good for future debuging */
INT FEM_RefineError (
   INT error,                 /* (IN) which error occured.                   */
   INT entity,                /* (IN) the entity associated with the error.  */
   char *thefile,             /* (IN) the file the error occured in          */
   INT theline  );            /* (IN) the line number where the error occured*/



                             /* ============================================ */
                             /* === FEM_reImproveWorstTets: Do some more tet */
                             /* === improvement targeted at improving the    */
                             /* === worst tets in the mesh.                  */
                             /* === Return: EXIT_SUCCESS or EXIT_FAILURE     */
                             /* ============================================ */
INT FEM_reImproveWorstTets(
   DOUBLE tolerance,         /* (IN)  smoothing tolerance.                   */
   FEM_BOOLEAN midnodes );   /* (IN)  TRUE if the mesh has midnodes.         */

INT FEM_reBruteForceFaceClean(
   INT *a_areas,        /* (IN) array of area ids containing face elements */
   INT num_areas,       /* (IN) length of a_areas.                            */
   FEM_BOOLEAN detached,/* (IN) if elements are detached from geometry.       */
	DOUBLE tolerance,
   INT iOptSmoothing) ;


INT FEM_reCleanup                ( INT *a_areas,
                                   INT num_areas,
                                   DOUBLE tolerance,
                                   INT midnodes,
                                   INT topoclean,
                                   INT quadsplit,
									  INT num_iters );


#ifdef __cplusplus
}
#endif

#endif
