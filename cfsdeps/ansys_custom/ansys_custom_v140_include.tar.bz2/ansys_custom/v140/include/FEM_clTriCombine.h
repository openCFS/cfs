/*  FEM_clTriCombine.h */
/*
 * *** ansys(r) copyright(c) 2009
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_clTriCombine.h
 *  header file for FEM_clTriCombine.c
 *
 */
#ifndef FEM_CLTRICOMBINE_INCLUDE
#define FEM_CLTRICOMBINE_INCLUDE

/*----------------- Globally accessible function prototypes -----------------*/

                                /* ========================================= */
                                /* === FEM_clTriangleCombine: See which      */
                                /* === triangles in the current mesh can be  */
                                /* === combined.  Only triangles which were  */
                                /* === created during refinement will be     */
                                /* === combined.                             */
                                /* ========================================= */
INT FEM_clTriangleCombine (
   NODELIST_OBJ obj_nlist,      /* node list to process                      */
   FACELIST_OBJ obj_flist,      /* face list to process                      */
   EDGELIST_OBJ obj_edlist,     /* edge list to process                      */
   INT area,                    /* area we are currently cleaning up         */
   INT *cleanedup  );           /* returned as TRUE if something was changed */

#endif

