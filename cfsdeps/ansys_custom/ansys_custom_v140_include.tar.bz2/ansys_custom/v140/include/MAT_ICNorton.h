////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         Copyright (C) 2010 ANSYS Inc.  All Rights Reserved             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MAT_ICNorton.h $
// $Revision: 1.6 $ 7.0
// $Date: 2010/04/06 20:21:11 $ March 28 2002
// $Author: srpailla $ rjayasee
//
// Decription :
//              This class implement Norton Implicit Creep Model
//              This is for secondary creep.
////////////////////////////////////////////////////////////////////////////// 

#if !defined(MAT_ICNorton_H)
#define MAT_ICNorton_H

#include  "MAT_ConstitutiveFunction.h"
#include  "MAT_Creep.h"

class MAT_ICNorton  : public MAT_Creep
{
public:

	MAT_ICNorton();
    // Default Constructor.

    static MAT_Creep* Construct() ;

    virtual bool FunctionValue( double* pVariables, INT iNumVariables,
                                double* pInputVariables, INT iNumInputVariables, double& dCreepStrainRate ) ;
    //I pVariable
    //I-Value of Coefficients
    //I iNumVariables
    //I- Number of variables
    //I dInputVariables
    //I-Input Variables
    //I iNumInputVariables
    //I-Num Input Variables
    //I dCreepStrainRate
    //I-Calculated Value of Creep Strain Rate
    //R- Calculates the value of the Creep Strain Rate 

    virtual bool FirstDerivativeOfUnsquaredError
            ( double* pVariables,INT iNumVariables,
              double* pInputVariables, INT iNumInputVariables,
              INT iVariableIndex, double& dResult ) ;
    //I pVariable
    //I-Value of Coefficients
    //I iNumVariables
    //I- Number of variables
    //I dInputVariables
    //I-Input Variables
    //I iNumInputVariables
    //I-Num Input Variables
    //I iVariableIndex
    //I-Variable w.r.t which the derivative is to be calculated
    //I dResult
    //I-Calculated value of derivative
    //R- Calculates the value of the Creep Strain Rate              
    
    virtual void Print() ;
    // Prints the constitutive function

    virtual void EliminateTemperatureCoefficients();
    //Eliminates Temperature term and fixes it.

    virtual ~MAT_ICNorton();
    //Destructor

protected:


} ;


class MAT_ICNortonFactory
{
    public:

    static MAT_ICNortonFactory* Instance() ;
    //I Pointer to Creep Factory
    //- Pointer to Singleton Instantiator

    static void Destroy() ;
    ~MAT_ICNortonFactory() ;
    // Destructor

    private:

    MAT_ICNortonFactory() ;
    // Constructor

    static MAT_ICNortonFactory* m_pInstance ;
    //Pointer to only instance of this class
} ;

#endif // !defined(MAT_ICNorton_H)
