/* computercfx.h                                            qzhang, sys
------------------------------------------------------------------------
------- Notice - This file contains ANSYS Confidential information --------
------------------------------------------------------------------------
*/
/* *** ansys(r) copyright(c) 2009
 * *** ansys, inc.
 */
/* Notice - 
*/
/* *** computercfx <  ipcapi.h, sifapi.h, ipcapi.c: machine specific info  */
/*------------------------------ Description ---------------------------
\Author:        qzhang, sys
\Title:         Define CFX machine names
\Desc:          For Ansys-CFX coupling through Socket                
 
----------Ansys Machine Names ----------------------
   Machine Name            Comments         Owner
   --------                --------         -----
   DECAXPOSF_SYS                            Dave Rubolino
   SOLX64_SYS                               Dave Rubolino

   HP_SYS               Any HP system       Joe Huba 
   HP32_SYS             HP 32-bit           Joe Huba
   HP64_SYS             HP 64-bit           Joe Huba
   HPIA64_SYS           HP Itanium          Joe Huba

   SGI_SYS              Any SGI system      Joe Huba
   SGIR4K_SYS           SGI 32-bit          Joe Huba
   SGI64_SYS            SGI 64-bit          Joe Huba
   SGIR8K_SYS           SGI 64-bit          Joe Huba

   NT_SYS               Any NT system
   PCWINNT_SYS          Any NT system       Rich Duritsa
   PCWIN64_SYS                              Mike McGovern

   SUN_SYS              Any SUN system      Tom Schroll
   SOLARIS_SYS                              Tom Schroll
   SUN64_SYS                                Tom Schroll

   IBM_SYS              Any IBM system      Tom Schroll
   RS6000_SYS                               Tom Schroll
   RS64K_SYS                                Tom Schroll

   LINUX_SYS            Any LINUX system    Chris Aiken
   LINUXIA32_SYS                            Chris Aiken
   LINUXIA64_SYS                            Chris Aiken
   LINUXOP64_SYS                            Chris Aiken
   LINUXEM64T_SYS                           Chris Aiken

\Function(s)
 -Primary:  Define CFX machine     
 -Secondary:    

----------------------------------------------------------------------*/
/* --------------- CFX machine Names --------------------------------
  To build ipcapi standalone, you will need to define 
  CFX5_ATTR_DOUBLE  
 (for a DP build), and one of the CFX5_OS_xxx defines:  
  CFX5_OS_WINNT           also WINDOWS_NT
  CFX5_OS_OSF 
  CFX5_OS_HPUX 
  CFX5_OS_LINUX 
  CFX5_OS_IRIX 
  CFX5_OS_AIX 
  CFX5_OS_SOLARIS 
  CFX5_OS_LINUX_IA64 
  CFX5_OS_LINUX_AMD64 
  CFX5_OS_HPUX_IA64
  CFX5_ATTR_32BIT not used 
  CFX5_ATTR_64BIT not used  
------------------------------------------------------------------- */

#if defined (DECAXPOSF_SYS)                     /* ALPHA 64 */
#  define ANSYS_SYS
#  define CFX5_ATTR_DOUBLE
#  define CFX5_OS_OSF
#endif


#if defined (HP32_SYS)                           /* HP 32 */
#  define ANSYS_SYS
#  define CFX5_ATTR_DOUBLE
#  define CFX5_OS_HPUX
#endif

#if defined (HP64_SYS)                          /* HP 64 */
#  define ANSYS_SYS
#  define CFX5_ATTR_DOUBLE
#  define CFX5_OS_HPUX
#endif

#if defined (HPIA64_SYS)                        /* HP IA64 */
#  define ANSYS_SYS
#  define CFX5_ATTR_DOUBLE
#  define CFX5_OS_HPUX_IA64
#endif


#if defined (SGIR4K_SYS)                         /* SGI 32 */
#  define ANSYS_SYS
#  define CFX5_ATTR_DOUBLE
#  define CFX5_OS_IRIX
#endif

#if defined(SGI64_SYS)                           /* SGI 64 */
#  define ANSYS_SYS
#  define CFX5_ATTR_DOUBLE
#  define CFX5_OS_IRIX
#endif

#if defined (SGIR8K_SYS)                         /* SGI R8000 */
#  define ANSYS_SYS
#  define CFX5_ATTR_DOUBLE
#  define CFX5_OS_IRIX
#endif


#if defined (PCWINNT_SYS)                         /* ANY NT */
#  define ANSYS_SYS
#  define CFX5_ATTR_DOUBLE
#  define WINDOWS_NT
#  define CFX5_OS_WINNT
#if defined (PCWIN64_SYS)
#  define ANSYS_SYS
#  define CFX5_ATTR_DOUBLE
#  define WINDOWS_NT
#  define CFX5_OS_WINNT_AMD64
#else
#endif
#endif


#if defined (SOLARIS_SYS)                        /* SUN 32 */
#  define ANSYS_SYS
#  define CFX5_ATTR_DOUBLE
#  define CFX5_OS_SOLARIS
#endif

#if defined (SOLX64_SYS)                        /* SOLARIS X64 */
#  define SUN_SYS
#  define PTRFTN       integer
#  define LONGINT      integer*8
#  define LONGINT2
#  define INLINE_VECT
#  define LITTLE_ENDIAN
#endif

#if defined (SUN64_SYS)                          /* SUN 64 */
#  define ANSYS_SYS
#  define CFX5_ATTR_DOUBLE
#  define CFX5_OS_SOLARIS
#endif


#if defined (RS6000_SYS)                         /* IBM 32 */
#  define ANSYS_SYS
#  define CFX5_ATTR_DOUBLE
#  define CFX5_OS_AIX
#endif

#if defined (RS64K_SYS)                          /* IBM 64 */
#  define ANSYS_SYS
#  define CFX5_ATTR_DOUBLE
#  define CFX5_OS_AIX
#endif


#if defined (LINUXIA32_SYS)                      /* LINUX 32 */
#  define ANSYS_SYS
#  define CFX5_ATTR_DOUBLE
#  define CFX5_OS_LINUX
#endif

#if defined (LINUXIA64_SYS) || defined (LINUXOP64_SYS) || defined (LINUXEM64T_SYS)
#  define ANSYS_SYS
#  define CFX5_ATTR_DOUBLE
#if defined (PGI_COMPILER)
#  define CFX5_OS_LINUX_AMD64
#else
#  define CFX5_OS_LINUX_IA64
#endif
#endif
