#ifndef FEM_CELL_____________H
#define FEM_CELL_____________H

#include "FEM_cdbtypes.h"
#include "FEM_Public.h"
#include "FEM_MemManager.h"

class CELL_TYP;
class CELLUSE_TYP;
class NEXTCELL_TYP;
typedef class CELL_TYP *CELL_PTYP;
typedef class NEXTCELL_TYP *NEXTCELL_PTYP;
typedef class CELLUSE_TYP *CELLUSE_PTYP;

/* ========================================================================== */
/* === NEXTCELL_TYP: The class used to create linked lists of cells           */
/* ========================================================================== */
class NEXTCELL_TYP 
{
    protected:
        CELL_PTYP     mps_cell;
        NEXTCELL_PTYP mps_next;

   public:
       NEXTCELL_TYP() { InitNEXTCELL(); };
       ~NEXTCELL_TYP() {};
                       /* =================================================== */
                       /* === InitNextCell:  Initialize this instance.        */
                       /* =================================================== */
      void InitNEXTCELL( ) { mps_cell = NULL; mps_next = NULL; };

                       /* =================================================== */
                       /* === SetNext:  Set the next link in the linked list. */
                       /* =================================================== */
      void SetNext( const NEXTCELL_PTYP next ) { mps_next = next; };

                       /* =================================================== */
                       /* === GetNext:  Get the next link in the linked list. */
                       /* =================================================== */
      NEXTCELL_PTYP GetNext( ) const { return mps_next; };

                       /* =================================================== */
                       /* === GetCell:  Get a pointer to the cell stored in   */
                       /* === this link.                                      */
                       /* =================================================== */
      CELL_PTYP GetCell( ) const { return mps_cell; };

                       /* =================================================== */
                       /* === SetCell:  Set a pointer to the cell stored in   */
                       /* === this link.                                      */
                       /* =================================================== */
      void SetCell( const CELL_PTYP cell ) { mps_cell = cell; };
};

/* ========================================================================== */
/* === CELLUSE_TYP: The class used to create linked lists of cells that bound */
/* === a particular cell.                                                     */
/* ========================================================================== */
class CELLUSE_TYP : public NEXTCELL_TYP 
{
   private:

                       /* =================================================== */
                       /* === m_orientation: The orientation of mps_cell with */
                       /* === respect to the cell that is bounded by it.      */
                       /* ===  m_orientation of 1 means with the base cell    */
                       /* ===  m_orientation of -1 means agains the base cell */
                       /* ===  m_orientation of 0 means neither (for example  */
                       /* ===         the seam on a closed area)              */
                       /* =================================================== */
      INT m_orientation;

   public:
       CELLUSE_TYP(){ m_orientation=0;};
       ~CELLUSE_TYP();
                       /* =================================================== */
                       /* === GetNext Get the next cell in the list of cells  */
                       /* === bounding a particular cell.                     */
                       /* =================================================== */
      CELLUSE_PTYP GetNext( ) const { return (CELLUSE_PTYP)mps_next; };

                       /* =================================================== */
                       /* === SetOrientation: Set the orientation of this cell*/
                       /* === with respect to the cell that this cell bounds. */
                       /* === See the comment above about m_orientation.      */
                       /* =================================================== */
      void SetOrientation( const INT orient ) { m_orientation = orient; };

                       /* =================================================== */
                       /* === Orientation: Get the orientation of this cell   */
                       /* === with respect to the cell that this cell bounds. */
                       /* === See the comment above about m_orientation.      */
                       /* =================================================== */
      INT Orientation( ) const { return m_orientation; };
};

                       /* =================================================== */
                       /* === g_adjcellptrmemory: The memory manager used to  */
                       /* === allocate links for the linked lists each cell   */
                       /* === has of adjacent cells of the next higher        */
                       /* === dimension.                                      */
                       /* =================================================== */
extern MemManager<NEXTCELL_TYP> *g_padjcellptrmemory;

                       /* =================================================== */
                       /* === g_celluseptrmemory: The memory manager used to  */
                       /* === allocate links for the linked lists each cell   */
                       /* === has of adjacent cells that bound it.            */
                       /* =================================================== */
extern MemManager<CELLUSE_TYP> *g_pcelluseptrmemory;

/* ========================================================================== */
/* === CELL_TYP: The base class for all the entities in a model.              */
/* ========================================================================== */
class CELL_TYP 
{
   private:
      ADDRESS_TYP mp_genptr; /* store information about this cell */
      INT m_flag; 
      static INT m_count; /* m_count: The number of CELL_TYPs in existence.  */

                       /* =================================================== */
                       /* === m_num_adjcells:  The number of cells of the     */
                       /* === next higher dimension that are adjacent to this */
                       /* === cell. I.E. the number of AREA_TYPs adjacent to  */
                       /* === a LINE_TYP, or number of LINE_TYPs adjacent to  */
                       /* === a KP_TYP.                                       */
                       /* =================================================== */
      INT m_num_adjcells;

                       /* =================================================== */
                       /* === m_type:  The type of entity this is.            */
                       /* ===       0 = KP_TYP                                */
                       /* ===       1 = LINE_TYP                              */
                       /* ===       2 = AREA_TYP                              */
                       /* ===       3 = VOL_TYP                               */
                       /* =================================================== */
      unsigned m_type:2;

                       /* =================================================== */
                       /* === mp_adjcells:  Pointer to a linked list of cells */
                       /* === of the next higher dimension that are adjacent  */
                       /* === to this cell.  The length of this list is       */
                       /* === m_num_adjcells;                                 */
                       /* =================================================== */
      NEXTCELL_PTYP mp_adjcells;
      INT m_id;        /* The integer id of this cell. */

                       /* =================================================== */
                       /* === mp_next: Pointer to the next CELL of this same  */
                       /* === dimension in the model.                         */
                       /* =================================================== */
      CELL_PTYP mp_next;

                       /* =================================================== */
                       /* === p_prev: Pointer to the previous CELL of this    */
                       /* === same dimension in the model.                    */
                       /* =================================================== */
      CELL_PTYP mp_prev;

   protected:
       void InitCELL();

                       /* =================================================== */
                       /* === NewCellUse:  Allocate a link for a linked list  */
                       /* === of CELLUSE_PTYP which are used to store cells   */
                       /* === which bound this cell and of a lower dimension  */
                       /* === than this cell.                                 */
                       /* =================================================== */
      CELLUSE_PTYP NewCellUse( ) { return g_pcelluseptrmemory->Allocate(); };

                       /* =================================================== */
                       /* === List2LevelsAbove:  Create a list of all         */
                       /* === adjacent cells that are 2 levels away from this */
                       /* === cell (i.e. if this is a kp, then a list of      */
                       /* === areas is created, etc.)                         */
                       /* =================================================== */
     INT List2LevelsAbove(
        CELL_PTYP **aobj_cell,
        INT &num_cells ) const;

                       /* =================================================== */
                       /* === List3LevelsAbove:  Create a list of all         */
                       /* === adjacent cells that are 3 levels away from this */
                       /* === cell (i.e. if this is a kp, then a list of      */
                       /* === vols is created, etc.)                          */
                       /* =================================================== */
     INT List3LevelsAbove(
        CELL_PTYP **aobj_cell,
        INT &num_cells ) const;

                       /* =================================================== */
                       /* === NumAdjCells: Return the number of cells of the  */
                       /* === next higher dimension that are adjacent to this */
                       /* === cell.                                           */
                       /* =================================================== */
      INT NumAdjCells() const { return m_num_adjcells; };

                       /* =================================================== */
                       /* === GetAdjCell: Return a pointer to the first cell  */
                       /* === adjacent to this cell.                          */
                       /* =================================================== */
      CELL_PTYP GetAdjCell() const
      {
         if ( !mp_adjcells ) return NULL;
         else return mp_adjcells->GetCell();
      };

                       /* =================================================== */
                       /* === GetNextAdjCell: Return a pointer to the next    */
                       /* === cell adjacent to this cell.                     */
                       /* =================================================== */
      CELL_PTYP GetNextAdjCell( CELL_PTYP obj_cell ) const;

   public:
      CELL_TYP() { InitCELL();};
      ~CELL_TYP() { DeleteCell(); };
      void DeleteCell(); /* === Free up the contents of this cell.  */


                       /* =================================================== */
                       /* === IsKp: Return TRUE if this cell is a keypoint.   */
                       /* =================================================== */
      FEM_BOOLEAN IsKp() const
      {
         if ( m_type == 0 ) return TRUE;
         else return FALSE;
      }

                       /* =================================================== */
                       /* === IsLine: Return TRUE if this cell is a line.     */
                       /* =================================================== */
      FEM_BOOLEAN IsLine() const
      {
         if ( m_type == 1 ) return TRUE;
         else return FALSE;
      }

                       /* =================================================== */
                       /* === IsArea: Return TRUE if this cell is an area.    */
                       /* =================================================== */
      FEM_BOOLEAN IsArea() const
      {
         if ( m_type == 2 ) return TRUE;
         else return FALSE;
      }

                       /* =================================================== */
                       /* === IsVolume: Return TRUE if this cell is a volume. */
                       /* =================================================== */
      FEM_BOOLEAN IsVolume() const
      {
         if ( m_type == 3 ) return TRUE;
         else return FALSE;
      }

                       /* =================================================== */
                       /* === GetId: Return the id of this cell.              */
                       /* =================================================== */
      INT GetId() const { return m_id; };

                       /* =================================================== */
                       /* === SetId: Set the id of this cell.                 */
                       /* =================================================== */
      void SetId( INT id ) { m_id = id; };

                       /* =================================================== */
                       /* === SetAdjCell: Store a pointer to a cell that is   */
                       /* === adjacent to this cell.                          */
                       /* =================================================== */
      INT SetAdjCell( CELL_PTYP p_adjcell );

                       /* =================================================== */
                       /* === RemoveAdjCell: Remove a pointer to a cell that  */
                       /* === is adjacent to this cell.                       */
                       /* =================================================== */
      void RemoveAdjCell( CELL_PTYP obj_cell );

                       /* =================================================== */
                       /* === SetGenPtr: Store a void pointer with            */
                       /* === information about this cell that is specific to */
                       /* === the current application.                        */
                       /* =================================================== */
      void SetGenPtr( ADDRESS_TYP p_genptr = NULL ) { mp_genptr = p_genptr; };

                       /* =================================================== */
                       /* === GenPtr: Get the  void pointer with              */
                       /* === information about this cell that is specific to */
                       /* === the current application.                        */
                       /* =================================================== */
      ADDRESS_TYP GenPtr( ) const { return mp_genptr; };

                       /* =================================================== */
                       /* === SetNext: Set a pointer to the next cell of      */
                       /* === this dimension in the model.                    */
                       /* =================================================== */
      void SetNext( const CELL_PTYP next ) { mp_next = next; };

                       /* =================================================== */
                       /* === GetNext: Set a pointer to the next cell of      */
                       /* === this dimension in the model.                    */
                       /* =================================================== */
      CELL_PTYP GetNext( ) const { return mp_next; };
      /*virtual DOUBLE Length() = 0; this one does not work */

      void SetFlag( const INT flag = 0 ) { m_flag = flag; };
      INT Flag() const { return m_flag; };
      void setType( INT dim ) { m_type = dim; };
};

#endif

