
/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 2008 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_meshvols.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_meshvols.h
 *  Prototypes and macros for FEM_meshvols.h
 *
 */

#ifndef FEM_MESHVOLS__________________H
#define FEM_MESHVOLS__________________H

#include "FEM_model.h"

/*------------------------ Constants -------------------------------------------*/

/*------------------------ Data Structures -------------------------------------*/

/*------------------------ Globals - used in only FEM_hd files -----------------*/

/*------------------------ Prototypes ------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif

#include "FEM_cdbtypes.h"

#include "FEM_Public.h"
#include "FEM_external.h"
#include "FEM_model.h"

typedef enum { FEM_SWEEP=1,
               FEM_TET=2,
               FEM_HEXDOM=3,
               FEM_SWEEP_TET=4,
               FEM_SWEEP_HEXDOM_TET=5 } VOLSHAPE;

                         /* ================================================= */
                         /* === FEM_mvSetUp: Prepare to mesh a list of        */
                         /* === volumes.                                      */
                         /* === Return: INT EXIT_SUCCESS or EXIT_FAILURE      */
                         /* ================================================= */
INT FEM_mvSetUp(
   INT *a_vols,          /* (IN) array of volume ids.                         */
                         /*       if *p_numvols == 1, then:                   */
                         /*           a_vols[1] is the specified source area, */
                         /*           a_vols[2] is the specified target.      */
                         /*           a_vols[3] is ndiv for sweeping.         */
                         /*           a_vols[4] is a bias for sweeping packed */
                         /*               by packed by multipling by 10000.   */
                         /*           a_vols[5] 3 if volume should be swept   */
                         /*               wedges, 4 if volume should be swept */
                         /*               with hexahedra.                     */
   INT num_vols,         /* (IN)  length of a_vols                            */
   INT *a_vshapes,       /* (IN)  The element shapes that each volume can     */
                         /*       have.                                       */
                         /*       This array is parallel to a_vols.           */
                         /*         0: Volume must be tet meshed.             */
                         /*         1: Volume can be either hex or tet meshed.*/
                         /*         2: Volume must be hex meshed.             */
   INT *a_mids,          /* (IN)  whether each volume needs midnodes or not.  */
                         /*       This array is parallel to a_vols.           */
                         /*         0: No midnodes are needed.                */
                         /*         1: Midnodes are needed, but can be dropped*/
                         /*            to avoid linear/quadratic              */
                         /*            incompatibilities. Midnodes should be  */
                         /*            projected to geometry.                 */
                         /*        -1: Midnodes are needed, but can be dropped*/
                         /*            to avoid linear/quadratic              */
                         /*            incompatibilities. Midnodes should not */
                         /*            be projected to geometry.              */
                         /*         2: Midnodes are needed, but cannot be ever*/
                         /*            dropped.  Midnodes should be           */
                         /*            projected to geometry.                 */
                         /*        -2: Midnodes are needed, but cannot be ever*/
                         /*            dropped.  Midnodes should not be       */
                         /*            projected to geometry.                 */
   FEM_BOOLEAN *no_vols);/* (OUT) TRUE if none of the volumes can be meshed   */
                         /*       because they are not sweepable and the tet  */
                         /*       mesher was not yet plugged in.              */
                         /* ================================================= */

                         /* ================================================= */
                         /* === FEM_mvSetUpShell: Prepare to mesh a list of   */
                         /* === areas.                                        */
                         /* === Return: INT EXIT_SUCCESS or EXIT_FAILURE      */
                         /* ================================================= */
INT FEM_mvSetUpShell(
   INT *a_areas,         /* (IN) array of area ids.                           */
   INT num_areas,        /* (IN)  length of a_areas                           */
   INT *a_ashapes,       /* (IN)  The element shapes that each area can       */
                         /*       have.                                       */
                         /*       This array is parallel to a_areas.          */
                         /*         0: area must be tri meshed.               */
                         /*         1: area can be either quad or tri meshed. */
                         /*         2: area must be quad meshed.              */
   INT *a_mids );        /* (IN)  whether each volume needs midnodes or not.  */
                         /*       This array is parallel to a_vols.           */
                         /*         0: No midnodes are needed.                */
                         /*         1: Midnodes are needed, but can be dropped*/
                         /*            to avoid linear/quadratic              */
                         /*            incompatibilities. Midnodes should be  */
                         /*            projected to geometry.                 */
                         /*        -1: Midnodes are needed, but can be dropped*/
                         /*            to avoid linear/quadratic              */
                         /*            incompatibilities. Midnodes should not */
                         /*            be projected to geometry.              */
                         /*         2: Midnodes are needed, but cannot be ever*/
                         /*            dropped.  Midnodes should be           */
                         /*            projected to geometry.                 */
                         /*        -2: Midnodes are needed, but cannot be ever*/
                         /*            dropped.  Midnodes should not be       */
                         /*            projected to geometry.                 */
                         /* ================================================= */

#ifdef __cplusplus
                         /* ================================================= */
                         /* === FEM_mvGetModel: Return a pointer to the       */
                         /* === current MODEL_PTYP.                           */
                         /* === Return: MODEL_PTYP                            */
                         /* ================================================= */
MODEL_PTYP FEM_mvGetModel( void );
#endif

                         /* ================================================= */
                         /* === FEM_mvMeshBnd: Mesh the boundary of the       */
                         /* === volumes stored by FEM_mvSetUp.                */
                         /* === Return: INT EXIT_SUCCESS or EXIT_FAILURE      */
                         /* ================================================= */
INT FEM_mvMeshBnd(
   INT trgsmooth );      /* (IN)  0: Do no target area or line smoothing.     */
                         /*       1: Do target area smoothing but no line     */
                         /*          smoothing.                               */
                         /*       2: Do both target area and line smoothing.  */
                         /* ================================================= */

                         /* ================================================= */
                         /* === FEM_mvMeshVol: Mesh a given volume in stored  */
                         /* === by FEM_mvSetUp.                               */
                         /* === Return: INT EXIT_SUCCESS or EXIT_FAILURE      */
                         /* ================================================= */
INT FEM_mvMeshVol(
   INT vol_id,           /* (IN)  The id of the volume to mesh.               */
   FEM_BOOLEAN *meshed );/* (OUT) TRUE if this volume was meshed.             */

                         /* ================================================= */
                         /* === FEM_mvSweepDirection: Sweep a given volume in */
                         /* === stored by FEM_mvSetUp in a specified          */
                         /* === direction.                                    */
                         /* === Return: INT EXIT_SUCCESS or EXIT_FAILURE      */
                         /* ================================================= */
INT FEM_mvSweepDirection(
   INT vol_id,           /* (IN)  The id of the volume to sweep.              */
   INT dir,              /* (IN)  The direction to sweep this volume in.      */
   FEM_BOOLEAN *meshed );/* (OUT) TRUE if this volume was meshed.             */

                         /* ================================================= */
                         /* === FEM_mvNumSweepDirs: return how many           */
                         /* === directions a given volume can be swept.       */
                         /* === Return: INT number of direction.              */
                         /* ================================================= */
INT FEM_mvNumSweepDirs(
   INT vnum );

                         /* ================================================= */
                         /* === FEM_mvSourceArea: return the id of the source */
                         /* === area used to sweep a given volume.            */
                         /* === Return: INT Id of the source area             */
                         /* ================================================= */
INT FEM_mvSourceArea(
   INT vnum );

                         /* ================================================= */
                         /* === FEM_mvGetSrcTrg: get the ids of the src & trg */
                         /* === Return: status             */
                         /* ================================================= */
INT FEM_mvGetSrcTrg( INT vnum, INT aiAreaIds[2] );

                         /* ================================================= */
                         /* === FEM_mvSweepCrackTip: Given a volume, and a kp */
                         /* === on its source area, adjust the location of    */
                         /* === the midnodes around this kp in the direction  */
                         /* === of the sweep so that they are skewed to the   */
                         /* === 1/4 point.                                    */
                         /* === Return: INT EXIT_SUCCESS or EXIT_FAILURE      */
                         /* ================================================= */
INT FEM_mvSweepCrackTip(
   INT vnum,
   INT kpid );

                         /* ================================================= */
                         /* === FEM_mvCleanUp: Cleanup memory used to mesh    */
                         /* === this model.                                   */
                         /* === Return: INT EXIT_SUCCESS or EXIT_FAILURE      */
                         /* ================================================= */
INT FEM_mvCleanUp( void );

INT FEM_mvMeshKps                ( void );

INT FEM_mvMeshAreas              ( const INT trgsmooth );

void FEM_mvRefreshAreaMark();

INT FEM_mvClassifyOneLine( INT lineNum );

#ifdef __cplusplus
}
#endif

#endif

