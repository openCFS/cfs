////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         Copyright (C) 2010 ANSYS Inc.  All Rights Reserved             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: ANS_Point.h $
// $Revision: 1.7 $ 7.0
// $Date: 2010/04/06 19:21:05 $ March 28 2002
// $Author: srpailla $ rjayasee/jlo
//
// Decription :
//
// This class defines the Point abstraction for the CurveFitting subsystem
// (if there is any). CurveFitting is done on a collection of points.
// These points could have been generated manually, experiments, from an
// equation etc.
// It has no knowledge of units, coordinate system. Can be interpreted
// in the situation
////////////////////////////////////////////////////////////////////////////


#if !defined(ANS_POINT_H)
#define ANS_POINT_H

 
class ANS_Point
{

public:

    ANS_Point() ;
    //Default Constructor

	ANS_Point ( vector<double> const& oCoordinateVector ) ;
    //I-oCoordinateVector
    //I-Constructor given a vector of cooordinates
    //I-Constructor

    virtual ~ANS_Point();
    //destructor

    void GetCoordinates( vector<double> const*& oCoordinateVector ) const ;
    //R-void
    //O-oCoordinateVector
    //O-Pointer to a vector of coordinates
    //F-Gets the coordinates all atonce

    bool GetCoordinate( INT index, double& dCoordinate ) const ;
    //R-void
    //R-false if such index does not exist
    //F-Returns the value of a coordinate given the index

    void SetCoordinates( vector<double> const& oCoordinateVector ) ;
    //R-void
    //I-oCoordinateVector
    //I-Pointer to a vector of coordinates
    //F-Sets the coordinates all atonce

    INT GetNumberOfCoordinates() const ;
    //R-Returns the number of Coordinates
    //F- ''''''''''''''''''''''''''''''''

private:

    vector<double> m_oCoordinateVector ;
	//The order in which data is entered might be important
    //vector does seem to provide us with this facility.
};

#endif // !defined(ANS_POINT_H)
