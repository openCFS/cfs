#ifndef FEM_LNMESHDATA________________H
#define FEM_LNMESHDATA________________H
#include "FEM_MeshData.h"

class LINEMSHDAT_TYP : public MSHDAT_TYP {

   private:
      unsigned int //m_premeshed:1,
                    m_sweep_perpendicular:1,
                    m_needsmidndoes:1,
                    m_projectmids:1,
                    m_trgsmoothed:1,
                    m_straight:1,
                    m_fromndvconstr:1;
      INT m_onSweepableVol;
      INT m_frozen;	
      DOUBLE *m_a_line_t;
      DOUBLE m_esize0;
      DOUBLE m_esize1; 
      DOUBLE m_curv;
      NODELIST_OBJ m_obj_nlist;
      NODE_OBJ *m_aobj_nodes ;
      INT m_num_nodes ;
      INT m_mark; // just for marking
      INT m_iEdgeMatchId;
      
   public:
      LINEMSHDAT_TYP() {Init(); };
      ~LINEMSHDAT_TYP() { Delete(); };
      void Init( );
      void delMem();
      void Delete(); 
      FEM_BOOLEAN IsOnSrcAndTrg( void ) const;
      FEM_BOOLEAN IsOnSrc( void ) const;
      FEM_BOOLEAN IsOnTrg( void ) const;

      inline void SetTargetSmoothed( const FEM_BOOLEAN trgsmoothed = TRUE )
      {
         if ( trgsmoothed ) m_trgsmoothed = 1;
         else m_trgsmoothed = 0;
      };

      inline FEM_BOOLEAN TargetSmoothed( ) const
      {
         if ( m_trgsmoothed == 1 ) return TRUE;
         else return FALSE;
      };

      inline void SetStraight( const FEM_BOOLEAN straight = TRUE )
      {
         if ( straight ) m_straight = 1;
         else m_straight = 0;
      };

      inline FEM_BOOLEAN Straight( ) const
      {
         if ( m_straight == 1 ) return TRUE;
         else return FALSE;
      };

      inline void SetNeedsMidnodes( const FEM_BOOLEAN status = TRUE )
      {
         if ( status ) m_needsmidndoes = 1;
         else m_needsmidndoes = 0;
      };

      inline FEM_BOOLEAN NeedsMidnodes( ) const
      {
         if ( m_needsmidndoes == 1 ) return TRUE;
         else return FALSE;
      };

      inline void SetProjectMids( const FEM_BOOLEAN status = TRUE )
      {
         if ( status ) m_projectmids = 1;
         else m_projectmids = 0;
      };

      inline FEM_BOOLEAN ProjectMids( ) const
      {
         if ( m_projectmids == 1 ) return TRUE;
         else return FALSE;
      };

      inline void ResetSweepDir( )
      {
         m_sweep_parallel = 0;
         m_sweep_perpendicular = 0;
      };

      inline void SetParallelToSweepDir( const FEM_BOOLEAN status = TRUE )
      {
         if ( status ) {
            m_sweep_parallel = 1;
            m_sweep_perpendicular = 0;
         }
         else {
            m_sweep_parallel = 0;
            m_sweep_perpendicular = 1;
         }
      };

      inline FEM_BOOLEAN ParallelToSweepDir( ) const
      {
         if ( m_sweep_parallel == 1 ) return TRUE;
         else return FALSE;
      };

      inline void SetPerpendicularToSweepDir( const FEM_BOOLEAN status = TRUE )
      {
         if ( status ) {
            m_sweep_parallel = 0;
            m_sweep_perpendicular = 1;
         }
         else {
            m_sweep_parallel = 1;
            m_sweep_perpendicular = 0;
         }
      };

      inline FEM_BOOLEAN PerpendicularToSweepDir( ) const
      {
         if ( m_sweep_perpendicular == 1 ) return TRUE;
         else return FALSE;
      };
      FEM_BOOLEAN OnSweepableVol( FEM_BOOLEAN bOnMustSweep = FALSE );
      inline void SetLine( const LINE_PTYP obj_line ) { SetCell( obj_line ); };
      inline LINE_PTYP GetLine( ) const { return (LINE_PTYP)GetCell(); };
      INT FindNodeLocs();
      inline void SetNodeLocs( DOUBLE *a_line_t )
      {
         FEM_Free_C( m_a_line_t);
         m_numdivs = 0; /* this is needed!!! Init after reset "node location" array */
         m_a_line_t = a_line_t;
      };
      inline void SetNumDivs( const INT iDiv )
      {
          if( m_numdivs && m_numdivs != iDiv )
          {
              FEM_Free_C( m_a_line_t);
          }
          m_numdivs = iDiv ;
      }

      inline FEM_BOOLEAN NodeLocsFound() const
      {
         if ( m_a_line_t ) return TRUE;
         else return FALSE;
      }
      inline DOUBLE const *NodeLocs() { return m_a_line_t; };
      inline INT Frozen() const {return m_frozen;} ;
      inline void SetFrozen( const INT frozen ) {m_frozen = frozen; };

      inline DOUBLE Esize0() const { return m_esize0; };
      inline void SetEsize0( const DOUBLE esize0 ) { m_esize0 = esize0; };

      inline DOUBLE Esize1() const { return m_esize1; };
      inline void SetEsize1( const DOUBLE esize1 ) { m_esize1 = esize1; };

      inline DOUBLE Curv() const { return m_curv;} ;
      inline void SetCurv( const DOUBLE curv ) { m_curv = curv; };

      inline NODELIST_OBJ NodeList() const { return m_obj_nlist; };
      inline NODELIST_OBJ NewNodeList() { m_obj_nlist = FEM_noNewList();
                                   return m_obj_nlist; };
      void setNodesOnLine( NODE_OBJ *aobj_nodes, INT numNodes ) ;
      void getNodesOnLine( NODE_OBJ *&aobj_nodes, INT &numNodes ) ;
      inline void setMark( INT mark ) { m_mark = mark ;}
      inline INT  getMark() { return m_mark; } 

      inline void setEdgeMatchId( INT id ) { m_iEdgeMatchId = id; };
      inline INT  getEdgeMatchId() { return m_iEdgeMatchId; };

      inline void setFromNdivConstr( FEM_BOOLEAN bFlag ) {m_fromndvconstr = bFlag;};
      inline FEM_BOOLEAN getFromNdivConstr( ) { return m_fromndvconstr;};
};    
typedef class LINEMSHDAT_TYP *LINEMSHDAT_PTYP;
void FEM_lnMd( LINEMSHDAT_PTYP obj_linedata );
#endif

