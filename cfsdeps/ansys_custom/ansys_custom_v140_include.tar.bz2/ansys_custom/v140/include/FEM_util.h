/*  FEM_util.h */
/*
 * *** ansys(r) copyright(c) 2009
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_util.h
 *  header file for FEM_util.c
 *
 */
#ifndef FEM_UTIL_INCLUDE
#define FEM_UTIL_INCLUDE

/* === Number of decimal digits of accuracy used for most applications === */
#define SIG_DEC_DIG 8
#define SIG_DIG_TOL 1.0e-8
#define CLOSE_TO_ZERO	0.1
#define CLOSE_TO_ONE	0.9

/*----------------- Globally accessible function prototypes -----------------*/

#ifdef __cplusplus
extern "C" {
#endif

                              /* =========================================== */
                              /* === FEM_utCalcBaryCoords:  Calculate the    */
                              /* === barycentric coordinates of a point      */
                              /* === given the point and a triangle.         */
                              /* === Return: EXIT_SUCCESS or EXIT_FAILURE    */
                              /* =========================================== */
INT FEM_utCalcBaryCoords (
   DOUBLE x,                  /* (IN)  the point                             */
   DOUBLE y,       
   DOUBLE pt1[2],             /* (IN)  first point on triangle               */
   DOUBLE pt2[2],             /* (IN)  second point on triangle              */
   DOUBLE pt3[2],             /* (IN)  third point on triangle               */
   VECTOR3D *bary_coords  );  /* (OUT) barycentric coordinate                */

                              /* =========================================== */
                              /* === FEM_utCalcBaryCoords2:  Calculate the   */
                              /* === barycentric coordinates of a node       */
                              /* === given the node and a triangle.          */
                              /* === Return: EXIT_SUCCESS or EXIT_FAILURE    */
                              /* =========================================== */
INT FEM_utCalcBaryCoords2 (
   NODE_OBJ obj_node,     /* (IN)  The node needing barycentric coordinates */
   NODE_OBJ obj_tnode1,   /* (IN)  Node1 of triangle */
   NODE_OBJ obj_tnode2,   /* (IN)  Node2 of triangle */
   NODE_OBJ obj_tnode3,   /* (IN)  Node3 of triangle */
   DOUBLE *A,             /* (OUT) barycentric coord w/ respect to obj_tnode1 */
   DOUBLE *B,             /* (OUT) barycentric coord w/ respect to obj_tnode2 */
   DOUBLE *C );           /* (OUT) barycentric coord w/ respect to obj_tnode3 */

                              /* =========================================== */
                              /* === FEM_utCalcBaryCoords3:  Calculate the   */
                              /* === barycentric coordinates of a 3d xyz     */
                              /* === given the loc and a triangle.           */
                              /* === Return: EXIT_SUCCESS or EXIT_FAILURE    */
                              /* =========================================== */
INT FEM_utCalcBaryCoords3 (
   DOUBLE x,              /* (IN)  The loc needing barycentric coordinates   */
   DOUBLE y,
   DOUBLE z,
   NODE_OBJ obj_tnode1,   /* (IN)  Node1 of triangle */
   NODE_OBJ obj_tnode2,   /* (IN)  Node2 of triangle */
   NODE_OBJ obj_tnode3,   /* (IN)  Node3 of triangle */
   DOUBLE *A,             /* (OUT) barycentric coord w/ respect to obj_tnode1 */
   DOUBLE *B,             /* (OUT) barycentric coord w/ respect to obj_tnode2 */
   DOUBLE *C );           /* (OUT) barycentric coord w/ respect to obj_tnode3 */

                              /* =========================================== */
                              /* === FEM_utCalcBaryCoords4: Calculate the    */
                              /* === barycentric coordinates of a 3d         */
                              /* === location given a location, a triangle,  */
                              /* === and a directions to project the location*/
                              /* === onto the triangle.  This is the same as */
                              /* === FEM_utCalcBaryCoords3 except that       */
                              /* === FEM_utCalcBaryCoords3 projects the      */
                              /* === location onto the triangle orthogonal   */
                              /* === to the triangle, while                  */
                              /* === FEM_utCalcBaryCoords4 projects the      */
                              /* === location onto the triangle using a      */
                              /* === vectors passed in.  This is an          */
                              /* === iterative process since we average the  */
                              /* === normal direction vectors at the corners */
                              /* === of the triangles and that is dependent  */
                              /* === upon the bary centric coordinates which */
                              /* === is what we are trying to find.          */
                              /* === Return: EXIT_SUCCESS or EXIT_FAILURE    */
                              /* =========================================== */
INT FEM_utCalcBaryCoords4(
   DOUBLE x,                  /* (IN)  the loc needing bary coordinates      */
   DOUBLE y,
   DOUBLE z,
   NODE_OBJ obj_tnode1,       /* (IN)  Node1 of triangle                     */
   NODE_OBJ obj_tnode2,       /* (IN)  Node2 of triangle                     */
   NODE_OBJ obj_tnode3,       /* (IN)  Node3 of triangle                     */
   VECTOR3D *ps_vect1,        /* (IN)  normal vector of projection at node1  */
   VECTOR3D *ps_vect2,        /* (IN)  normal vector of projection at node2  */
   VECTOR3D *ps_vect3,        /* (IN)  normal vector of projection at node3  */
   DOUBLE *A,                 /* (OUT) bary coord w/ respect to obj_tnode1   */
   DOUBLE *B,                 /* (OUT) bary coord w/ respect to obj_tnode2   */
   DOUBLE *C );               /* (OUT) bary coord w/ respect to obj_tnode3   */



                              /* =========================================== */
                              /* === FEM_utSort: sort an integer array       */
                              /* === into assending or descenting order      */
                              /* === based on actual values or absolute      */
                              /* === values                                  */
                              /* =========================================== */
void FEM_utSort (
   INT *iv,                   /* (IN/OUT)  integer vector to sort            */
   INT *iv2,                  /* (IN/OUT)  vector sorted with iv             */
   INT n,                     /* (IN)      dimension of iv and iv2           */
   INT kabs,                  /* (IN)      1 = sort on absolute values       */
                              /*           0 = sort on actual values         */
   INT krev  );               /* (IN)      1 = sort in descending order      */
                              /*           0 = sort in ascending order       */

                              /* =========================================== */
                              /* === FEM_utRoundOff: Round off a double to   */
                              /* === the specified number of sig figs.       */
                              /* === numsigs must be 1 or greater but no     */
                              /* === more than 12.                           */
                              /* === Return: EXIT_SUCCESS or EXIT_FAILURE    */
                              /* =========================================== */
INT FEM_utRoundOff (
   DOUBLE *number,            /* the number to be rounded.                   */
   INT numsigs  );            /* the number of significant figures desired.  */

                              /* =========================================== */
                              /* === Function: FEM_utQsort2b: sort an array  */
                              /* === into assending order.  Copied from      */
                              /* === sort2 out of Numerical Recipes in C,    */
                              /* === Second Edition, pg.334                  */
                              /* === NOTE: currently not used by anyone, use */
                              /* === at your own risk!!! Good for sorting    */
                              /* === large arrays, may not be so good for    */
                              /* === small arrays.                           */
                              /* === Return: void                            */
                              /* =========================================== */
INT FEM_utQsort2b (
   FEM_LONG length,           /* length of arr                               */
   ADDRESS_TYP *arr,          /* array to sort                               */
   INT *brr,                  /* array sorted same as arr                    */
   INT (*compare_func)( const ADDRESS_TYP,
                        const ADDRESS_TYP )  ); /* comparison routine
                     returns negative if arg 1 is considered to precede arg 2,
                     returns 0 if arg 1 is equivelant to arg 2
                     returns positive if arg 1 is considered to follow arg 2, */

                              /* =========================================== */
                              /* === FEM_utSolve3X3: Solves the matrix       */
                              /* === equation [A]*{x}={b} where [A] is 3x3   */
                              /* === and {x} and {b} are 3x1 vectors         */
                              /* === Return: EXIT_SUCCESS or EXIT_FAILURE    */
                              /* =========================================== */
INT FEM_utSolve3x3 (
    DOUBLE A[3][3],
    DOUBLE x[3],
    DOUBLE b[3]  );
                              /* =========================================== */
                              /* === FEM_utSolveNXN: Solves the matrix       */
                              /* === equation [A]*{x}={b} where [A] is NxN   */
                              /* === and {x} and {b} are Nx1 vectors         */
                              /* === Return: EXIT_SUCCESS or EXIT_FAILURE    */
                              /* =========================================== */
INT FEM_utSolveNxN (
    DOUBLE **A,
    DOUBLE *x,
    DOUBLE *b,
    INT n );

                              /* =========================================== */
                              /* === FEM_utLudcmp: Lower/Upper decomposition */
                              /* === from Numerical Recipes.  Use with       */
                              /* === FEM_utLubksb to solve NXN matrix.       */
                              /* === See FEM_utSolveNxN for usage example    */
                              /* === See page 46 of Numerical Recipes in C   */
                              /* === for complete description                */
                              /* === Return: EXIT_SUCCESS or EXIT_FAILURE    */
                              /* =========================================== */
INT FEM_utLudcmp ( 
   DOUBLE **mat,              /* (IN/OUT) N X N matrix                       */
   INT *indx,                 /* (IN) 1 X N matrix (pass to FEM_utLubksb)    */
   DOUBLE *d,                 /* (OUT) see page 46 of Numerical Recipes in C */
   INT n );                   /* (IN) size of matrix                         */

                              /* =========================================== */
                              /* === FEM_utLubksb: Back substitution         */
                              /* === Use with FEM_utLudcmp.  See             */
                              /* === FEM_utSolveNxN for example usage        */
                              /* === Return: EXIT_SUCCESS or EXIT_FAILURE    */
                              /* =========================================== */
INT FEM_utLubksb (
   DOUBLE **mat,              /* (IN) triangular matrix from FEM_utLudcmp    */
   INT *indx,                 /* (IN) from FEM_utLudcmp                      */
   DOUBLE *b,                 /* (IN/OUT) right hand side vector, replace    */
                              /*          with solution vector               */
   INT n );                   /* (IN) size of matrix                         */


                              /* =========================================== */
                              /* === Function: FEM_utCross: cross product    */
                              /* =========================================== */
void FEM_utCross (
   VECTOR3D *ps_A,
   VECTOR3D *ps_B,
   VECTOR3D *ps_C  );

                              /* =========================================== */
                              /* === Function: FEM_utCrossNorm: cross product*/
                              /* === normalize the result - return magnitude */
                              /* =========================================== */
DOUBLE FEM_utCrossNorm (
   VECTOR3D *ps_A,
   VECTOR3D *ps_B,
   VECTOR3D *ps_C  );

                              /* =========================================== */
                              /* === Function: FEM_utNorm:                   */
                              /* === normalize VECTOR3D   - return magnitude */
                              /* =========================================== */
DOUBLE FEM_utNorm (
   VECTOR3D *ps_A  );

                              /* =========================================== */
                              /* === Function: FEM_utCross: dot product      */
                              /* =========================================== */
DOUBLE FEM_utDot (
   VECTOR3D *ps_A,
   VECTOR3D *ps_B  );

                              /* =========================================== */
                              /* === Function: FEM_utDiff: vect diff         */
                              /* =========================================== */
void FEM_utDiff (
   VECTOR3D *ps_A,
   VECTOR3D *ps_B,
   VECTOR3D *ps_C);

void FEM_utVecA2B (
   VECTOR3D *ps_A,
   VECTOR3D *ps_B,
   VECTOR3D *ps_C);
                              /* =========================================== */
                              /* ===  Function: FEM_utDist: distance between */
                              /* ===  two 3D points                          */
                              /* =========================================== */
DOUBLE FEM_utDist(
   VECTOR3D *ps_A,
   VECTOR3D *ps_B );

                              /* =========================================== */
                              /* ===  Function: FEM_utDist2: distance square */
                              /* ===  between two 3D points                  */
                              /* =========================================== */
DOUBLE FEM_utDist2(
   VECTOR3D *ps_A,
   VECTOR3D *ps_B );


DOUBLE FEM_utDbDist2(
    DOUBLE *xyz0,
    DOUBLE *xyz1 );
                              /* =========================================== */
                              /* === Function: FEM_utVolume: volume enclosed */
                              /* === by a set of facets                      */
                              /* =========================================== */
DOUBLE FEM_utVolume (
   DOUBLE *a_nodes,                     /* array of node 3D mode locations   */
   INT *a_facets,                       /* array of facet connectivities     */
   INT numfacets  );                    /* number of facets                  */

                              /* =========================================== */
                              /* === FEM_utDistToPlane: compute the distance */
                              /* === from a point to a plane.  The sign of   */
                              /* === the distance indicates which side of    */
                              /* === the plane the point is on (based on a   */
                              /* === clockwise rotation of pt1, pt2, pt3)    */
                              /* === Return: DOUBLE distance to plane.       */
                              /* =========================================== */
DOUBLE FEM_utDistToPlane(
   VECTOR3D *pt1,             /* (IN)  vertex of plane.                      */
   VECTOR3D *pt2,             /* (IN)  vertex of plane.                      */
   VECTOR3D *pt3,             /* (IN)  vertex of plane.                      */
   VECTOR3D *the_point );     /* (IN)  the point.                            */

                              /* =========================================== */
                              /* === FEM_utColinear: See if 3 points are     */
                              /* === colinear within a tolerance.            */
                              /* === Return: TRUE if points are colinear,    */
                              /* === otherwise FALSE.                        */
                              /* =========================================== */
FEM_BOOLEAN FEM_utColinear(
    VECTOR3D *p0,
    VECTOR3D *p1,
    VECTOR3D *p2 );

                              /* =========================================== */
                              /* === FEM_utColinear2: See if 3 points are    */
                              /* === colinear within a looser tolerance based*/
                              /* === on distance between points.             */
                              /* === Return: TRUE if points are colinear,    */
                              /* === otherwise FALSE.                        */
                              /* =========================================== */
FEM_BOOLEAN FEM_utColinear2(
    VECTOR3D *p0,
    VECTOR3D *p1,
    VECTOR3D *p2 );

                              /* =========================================== */
                              /* === FEM_utGetBiasLocations: Determine the   */
                              /* === parametric locations of interior nodes  */
                              /* === on a line given a bias and number of    */
                              /* === divisions.                              */
                              /* === Return: EXIT_SUCCESS or EXIT_FAILURE    */
                              /* =========================================== */
INT FEM_utGetBiasLocations (
   INT num_divs,           /* (IN)  number of divisions on that line */
   DOUBLE space_ratio,     /* (IN)  bias or spacing ratio on that line. */
   DOUBLE *a_line_t  );    /* (OUT) parametric locations of interior nodes */

                              /* =========================================== */
                              /* === FEM_utVamax: get the biggest absolute   */
                              /* === value and location in vector            */
                              /* === Return: absolute value of largest       */
                              /* === component                               */
DOUBLE FEM_utVamax(
   VECTOR3D *ps_A,         /* (IN) the vector */
   INT *p_location );      /* (OUT) location of largest component 
                                    0=X, 1=Y, 2=Z */

                              /* =========================================== */
                              /* === FEM_utLagrangianPolynomialInterp:       */
                              /* === Interpolate a polynomial w/ iInterpPoints */
                              /* === Having iNumPoints data points  at Sinterp    */
                              /* === void                                    */

void FEM_utLagrangianPolynomialInterp( 
    INT iInterpPoints, 
    INT iNumPoints,
    DOUBLE *a_xyz,
    DOUBLE *a_sval,
    DOUBLE sInterp,
    DOUBLE *a_xyzout );

INT FEM_utMidVec(
   VECTOR3D *psA,
   VECTOR3D *psB,
   VECTOR3D *psC);

INT FEM_utScaleVec(
   DOUBLE scale,
   VECTOR3D *ps_A,
   VECTOR3D *ps_B );

int FEM_utIsimeq (double * a, int nd, int  n, int  nc);

double FEM_utH_evaluate ( int  num_nodes, VECTOR3D *xyz_nodes, double *h_nodes, VECTOR3D *xyz_eval);


void FEM_utVecToArray( VECTOR3D *ps_vec, DOUBLE *xyz ); 
void FEM_utArrayToVec( VECTOR3D *ps_vec, DOUBLE *xyz  );
void FEM_utSetVec( double *pa, double *pb, VECTOR3D *psVecAB);
void FEM_utSetVecNode2Node( NODE_OBJ a, NODE_OBJ b, VECTOR3D *ps_vab );
int FEM_utInterpolateByBryCrdAry(   double *adBryCrd, NODE_OBJ *aobj_nodes, int dim, double *adPnt );
int FEM_utInterpolateByBryCrdArray( double *adBryCrd, double adNodalLocs[3][3], int dim, double *adPnt );
int FEM_utInterpolateByBryCrdVec(   VECTOR3D *psBryCrd, NODE_OBJ *aobj_nodes, int dim, VECTOR3D *psPnt );
void FEM_utAdd( VECTOR3D *a, VECTOR3D *b, VECTOR3D *c);
void FEM_utVRotate( VECTOR3D *cVect, DOUBLE dAngle, double adAxis[3],  VECTOR3D *cVectout);
INT FEM_utProjectPtOnFaceNodes( NODE_OBJ aobj_node[3], DOUBLE *a_xyzin, INT iCheckFaceOnly,
						        DOUBLE *a_xyzout, ADDRESS_TYP *pobj_entity, INT *piMeshEntity );
INT FEM_utProjectPtOnFace( FACE_OBJ obj_face, DOUBLE *a_xyzin, INT iCheckFaceOnly, DOUBLE *a_xyzout, ADDRESS_TYP *pobj_entity, INT *iMeshEntity );
DOUBLE FEM_utProjectPtToSeg( VECTOR3D *p_a, VECTOR3D *p_b, VECTOR3D *p_c, DOUBLE  *t );
DOUBLE FEM_utProjectPtToSeg1( DOUBLE xyz0[3], DOUBLE xyz1[3], DOUBLE xyz2[3], DOUBLE  *t );
DOUBLE FEM_utCalAngle( VECTOR3D *psVect0, VECTOR3D *psVect1 ); 
INT FEM_utProjVectToPlane(
   VECTOR3D *ps_vector,        /* vector to project */
   VECTOR3D *ps_normal,        /* normal of projection plane */
   VECTOR3D *ps_proj );         /* resulting projected vector */
void FEM_utFindInArray( 
    void *pObj, 
    void **aArray, 
    INT  iNumInArray, 
    INT  *piIdx); /* if the *piIdx<0, the pObj is not in the array */
#ifdef __cplusplus
}
#endif

#endif

