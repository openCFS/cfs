/* CConfigMgr.h CADOE adomshinc */
/*! \file CConfigMgr.h

\brief This header file defines the CConfigMgr class.

\author Gilles VENET &copy; CADOE

\date February 2004
*/
#ifndef __CConfigMgrBase_h__ 
#define __CConfigMgrBase_h__ 1 

#include "CconfigBase.h"
#include "cadoesys.h"
#include "CCadoePortable.h"
#include "cbf.h"

#define CFGMGR_CLOSE_FILE(vaf)  CBF_close_database ( &vaf );

class CModeleBase;

/*! \class CConfigMgr CConfigMgr.h
\brief The CConfigMgr class is used to manage config set.
*/
class CConfigMgrBase
{
public:
	typedef list<CConfigBase*> ConfigBaseList;


	CConfigMgrBase();
	CConfigMgrBase( CModeleBase * );
	~CConfigMgrBase();

	// initialize for standalone usage (build is own adomesh model)
	virtual int readFile ( );
	void setName ( WString dbname ) { m_pSdbName = dbname; };
	virtual CConfigBase *getConfigById ( int configId );// recherhe une config par l'id de la config
	virtual CConfigBase *getConfigById ( int part_ini, int configId );// recherhe une config par l'id de la config
	virtual bool isInitialized( WString filename ) const;
	virtual ConfigBaseList getConfigsWithParameter ( string nomParam );
	virtual CConfigBase *getConfigDelta ( CParameter &param ); //CFG_construire_grand_pas
	virtual CConfigBase *getConfigMono ( CParameter &param, CConfigBase::EcodeParam type );
	virtual CConfigBase *getCurrentConfig ( ) { return _CfgCur; }
	void setPrecision ( double precis ) { _precision = precis; }
	virtual CModeleBase *getModele () { return _modele; }
	void setDatabaseFilename(const WString filename);
	
	//virtual ConfigBaseList getConfigsInPolynom( CConfigBase *config, T_liste *lres, T_statut *ier );

	virtual bool isConfigExist ( CDesignSet *dset, CConfigBase::EcodeParam type );
	virtual double getValueOfParameter ( CParameter &param, CConfigBase::EcodeParam minmax );
	int getNbConfigs();

protected:
	WString			m_pSdbName;
	int				_numeroMax;
	double			_precision;
	CConfigBase *	_CfgCur;
	bool			_initialized;
	ConfigBaseList	_lconfig;	
	CModeleBase *	_modele;
};


#endif
