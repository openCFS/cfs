/*  FEM_refineHex.h */
/*
 * *** ansys(r) copyright(c) 2009
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_refineHex.h
 *  Prototypes and macros for refining hexahedral meshes.
 *
 */

#ifndef FEM_REFINEHEX
#define FEM_REFINEHEX

#include "FEM_cdbtypes.h"

/* === valid node marking orientations on a hex */
#define VALID1  ((1<<0))  /* node 0 marked only */
#define VALID2  ((1<<1))  /* node 1 marked only */
#define VALID3  ((1<<2))  /* node 2 marked only */
#define VALID4  ((1<<3))  /* node 3 marked only */
#define VALID5  ((1<<4))  /* node 4 marked only */
#define VALID6  ((1<<5))  /* node 5 marked only */
#define VALID7  ((1<<6))  /* node 6 marked only */
#define VALID8  ((1<<7))  /* node 7 marked only */

#define VALID9  ((1<<0) | (1<<1))  /* nodes 0 & 1 marked only */
#define VALID10 ((1<<0) | (1<<4))  /* nodes 0 & 4 marked only */
#define VALID11 ((1<<1) | (1<<5))  /* nodes 1 & 5 marked only */
#define VALID12 ((1<<1) | (1<<2))  /* nodes 1 & 2 marked only */
#define VALID13 ((1<<2) | (1<<6))  /* nodes 2 & 6 marked only */
#define VALID14 ((1<<2) | (1<<3))  /* nodes 2 & 3 marked only */
#define VALID15 ((1<<3) | (1<<7))  /* nodes 3 & 7 marked only */
#define VALID16 ((1<<3) | (1<<0))  /* nodes 3 & 0 marked only */
#define VALID17 ((1<<4) | (1<<5))  /* nodes 4 & 5 marked only */
#define VALID18 ((1<<5) | (1<<6))  /* nodes 5 & 6 marked only */
#define VALID19 ((1<<6) | (1<<7))  /* nodes 6 & 7 marked only */
#define VALID20 ((1<<7) | (1<<4))  /* nodes 7 & 4 marked only */

#define VALID21 ((1<<0)|(1<<1)|(1<<2)|(1<<3))/* nodes 0,1,2,3 marked only */
#define VALID22 ((1<<4)|(1<<5)|(1<<6)|(1<<7))/* nodes 4,5,6,7 marked only */
#define VALID23 ((1<<0)|(1<<3)|(1<<4)|(1<<7))/* nodes 0,3,4,7 marked only */
#define VALID24 ((1<<0)|(1<<1)|(1<<4)|(1<<5))/* nodes 0,1,4,5 marked only */
#define VALID25 ((1<<1)|(1<<2)|(1<<5)|(1<<6))/* nodes 1,2,5,6 marked only */
#define VALID26 ((1<<2)|(1<<3)|(1<<6)|(1<<7))/* nodes 2,3,6,7 marked only */

#define VALID27 ((1<<0)|(1<<1)|(1<<2)|(1<<3)|\
                 (1<<4)|(1<<5)|(1<<6)|(1<<7)) /*all nodes are marked */



                              /* ============================================ */
                              /* === FEM_reProcessHex_3Ref: process a         */
                              /* === hexahedral element for splitting using   */
                              /* === 3-Refinement.                            */
INT FEM_reProcessHex_3Ref (
   ELEMENTLIST_OBJ obj_ellist,/* the element list                             */
   NODELIST_OBJ obj_nlist,    /* the node list                                */
   FACE_OBJ obj_elem,         /* hexahedron to be split                       */
   FEM_BOOLEAN detached,      /* TRUE if not associated with solid model      */
   FEM_BOOLEAN no_lines  );   /* TRUE if no new nodes can be created on lines */

#endif
