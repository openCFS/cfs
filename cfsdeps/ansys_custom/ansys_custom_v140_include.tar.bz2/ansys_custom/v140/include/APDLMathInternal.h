/**
 * @file   APDLMathInternal.h
 * @author  <ftheveno@LYOFTHEVENO8>
 * @date   Thu Feb 18 10:18:44 2010
 * 
 * @brief  
 * 
 * 
 */

#ifndef _C_APDLMATHINTERNAL_
#define _C_APDLMATHINTERNAL_	1

#if defined(LOWERCASENOUNDER_SYS)
#define	APDLMath	apdlmath
#define ch8insub	ch8insub
#define intinfun	intinfun
#define dpinfun		dpinfun
#define CmdInquire	cmdinquire
#define cFnamesub	cfnamesub
#define GetSession	getsession
#define SetSession	setsession
#define APDLMathSetVal	apdlmathsetval
#define APDLMathGetVal	apdlmathgetval
#define APDLMathVar	apdlmathvar
#define APDLMathReset	apdlmathreset
#define APDLMathFillArray	apdlmathfillarray
#endif

#if defined(UPPERCASENOUNDER_SYS)
#define	APDLMath	APDLMATH
#define ch8insub	CH8INSUB
#define intinfun	INTINFUN
#define dpinfun		DPINFUN
#define CmdInquire	CMDINQUIRE
#define cFnamesub	CFNAMESUB
#define GetSession	GETSESSION
#define SetSession	SETSESSION
#define APDLMathSetVal	APDLMATHSETVAL
#define APDLMathGetVal	APDLMATHGETVAL
#define APDLMathVar	APDLMATHVAR
#define APDLMathReset	APDLMATHRESET
#define APDLMathFillArray	APDLMATHFILLARRAY
#endif

#if defined(LOWERCASEUNDER_SYS)
#define	APDLMath	apdlmath_
#define ch8insub	ch8insub_
#define intinfun	intinfun_
#define dpinfun		dpinfun_
#define CmdInquire	cmdinquire_
#define cFnamesub	cfnamesub_
#define GetSession	getsession_
#define SetSession	setsession_
#define APDLMathSetVal	apdlmathsetval_
#define APDLMathGetVal	apdlmathgetval_
#define APDLMathVar	apdlmathvar_
#define APDLMathReset	apdlmathreset_
#define APDLMathFillArray	apdlmathfillarray_
#endif

extern "C" {
  SUBROUTINE APDLMath( char*);
  SUBROUTINE ch8insub( int *iField, FCHAR(c1) FCHARL(c1_len));
  SUBROUTINE cFnamesub( int *iField, FCHAR(c1) FCHARL(c1_len));
  INT FUNCTION intinfun( int *iField);
  DOUBLE FUNCTION dpinfun( int *iField);
  INT FUNCTION CmdInquire( int *iField, INT *key);
  SUBROUTINE GetSession( Hyper *HSession);
  SUBROUTINE SetSession( Hyper *HSession);
  INT FUNCTION APDLMathSetVal( char *Name, int *, double *subc, double *DVal);
  INT FUNCTION APDLMathGetVal( char *Name, int *, double *subc, double *DVal);
  INT FUNCTION APDLMathVar( char *cName);
  SUBROUTINE APDLMathFillArray( char *cName, INT *length, DOUBLE **AVec);

  void uplabl_( char *str, int *len, int *len_dummy);
}

inline void 
UpperString( string &str)
{
  int len = (int)strlen( str.c_str());
  uplabl_( (char *)str.c_str(), &len, &len);
}


inline void
SetEndStr( char *Str, int Len)
{
  int j=Len-1; 
  while( Str[j] == ' ' && j>0) j--;
  if ( j>=0) Str[j+1] = '\0';
}

inline void
Readch8( int *NumArg, char *str)
{
  ch8insub( NumArg, str, strlen(str));
  SetEndStr( str, 8);
}

inline void
ReadFName( int *NumArg, char *str)
{
  cFnamesub( NumArg, str, LENNAM);
  SetEndStr( str, LENNAM);
}

class C_APDLMathCommand		// typedef struct
{
public:
  char		_description[80];
  char		_name[8];
  void	*	_Handle;
};
  
class C_APDLMathImportFilter
{
public:
  char			_name[9];	// Id
  int			_type;		// (0=internal, 1=documented, 2=custom)
  int			_fromfile;	// (1 = true, 0 = false)
  IMPORT_FILTER		_Handle;	// Not yet used
};

class C_APDLMathExportFilter
{
public:
  char			_name[9];	// Id
  int			_type;		// (0=internal, 1=documented, 2=custom)
  EXPORT_FILTER		_Handle;	// Not yet used
};

#endif
