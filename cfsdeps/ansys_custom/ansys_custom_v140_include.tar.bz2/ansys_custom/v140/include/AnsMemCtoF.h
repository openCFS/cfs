/* ---------------------------------------------------------------------- */
/* *** copyright(c) 2010 SAS IP, Inc.  All rights reserved. */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  AnsMemCtoF.h */
#if !defined(__ANSMEMCTOF_H__)
#define __ANSMEMCTOF_H__ 1

#include "ansys.h"

/* (1)----------------------------------------------------------------*/
#if defined(LOWERCASENOUNDER_SYS)

/*
 *   The pattern for these platforms is the lowercased version of the name
 */

#define AnsMemAlloc              ansmemalloc
#define AnsMemFree               ansmemfree
#define AnsMemRealloc            ansmemrealloc
#define AnsMemInitial            ansmeminitial
#define AnsMemDestroy            ansmemdestroy
#define AnsMemReset              ansmemreset
#define AnsMemIqr                ansmemiqr
#define AnsMemIqrd               ansmemiqrd
#define AnsMemInf                ansmeminf
#define AnsMemInfd               ansmeminfd
#define AnsMemHandle             ansmemhandle
#define AnsMemPointer            ansmempointer
#define AnsMemLock               ansmemlock
#define AnsMemUnlock             ansmemunlock
#define cAnsMemInitial           cansmeminitial
#define cAnsMemDestroy           cansmemdestroy
#define cfAnsMemGrow             cfansmemgrow
#define SetDbgInfo               setdbginfo
#define cfAnsMemBlkNmInq         cfansmemblknminq
#define cfAnsMemInquire          cfansmeminquire
#define cfAnsMemInform           cfansmeminform
#define cfAnsMemJournal          cfansmemjournal
#define cfAnsMemInitial          cfansmeminitial
#define cfAnsMemDestroy          cfansmemdestroy
#define cfAnsMemReset            cfansmemreset
#define cfAnsMemFillPads         cfansmemfillpads
#define cfAnsMemFillBlock        cfansmemfillblock
#define CheckBothMemoryTables    checkbothmemorytables
#define CheckAnsMemTable         checkansmemtable
#define PrintAnsMemTable         printansmemtable
#define PrintcfAnsMemTable       printcfansmemtable
#define AnsMemCheckAll           ansmemcheckall
#define mempplock                mempplock
#define memppunlock              memppunlock
#define fmalloc                  fmalloc
#define ffree                    ffree
#define frealloc                 frealloc
#define ptrcmp                   ptrcmp
#define ptrmult                  ptrmult
#define fAnsMemInitial           fansmeminitial
#define fAnsMemDestroy           fansmemdestroy
#define HeapInitial              heapinitial
#define HeapDealloc              heapdealloc
#define HeapAllocPtr             heapallocptr
#define HeapGetSmallint          heapgetsmallint
#define HeapDestroyer            heapdestroyer
#define memiqr                   memiqr
#define memiqrp                  memiqrp
#define erinfo                   erinfo
#define erinqr                   erinqr
#define wrinqr                   wrinqr
#define pplock                   pplock
#define ppunlock                 ppunlock
#define ppproc                   ppproc
#define lowmemmessage            lowmemmessage
#define cfAnsMemDebugCheck       cfansmemdebugcheck
#define cfAnsMemAlloc            cfansmemalloc
#define cfAnsMemFree             cfansmemfree
#define cfAnsMemGroupFree        cfansmemgroupfree
#define cfAnsMemRealloc          cfansmemrealloc
#define cfAnsMemHandle           cfansmemhandle
#define cfAnsMemPointer          cfansmempointer
#define getMemoryTestVal         getmemorytestval
#define setMemoryTestVal         setmemorytestval

#define fatal                    fatal
#define iopiqr                   iopiqr

#define PrintStackTrace          printstacktrace
#define StkClnIni                stkclnini
#define sysgetenv                sysgetenv
#define erhandler                erhandler

#define dyncom                   dyncom

#endif


/* (2)----------------------------------------------------------------*/
#if defined(UPPERCASENOUNDER_SYS)

/*
 *   The pattern for these platforms is the uppercased version of the name
 */

#define AnsMemAlloc              ANSMEMALLOC
#define AnsMemFree               ANSMEMFREE
#define AnsMemRealloc            ANSMEMREALLOC
#define AnsMemInitial            ANSMEMINITIAL
#define AnsMemDestroy            ANSMEMDESTROY
#define AnsMemReset              ANSMEMRESET
#define AnsMemIqr                ANSMEMIQR
#define AnsMemIqrd               ANSMEMIQRD
#define AnsMemInf                ANSMEMINF
#define AnsMemInfd               ANSMEMINFD
#define AnsMemHandle             ANSMEMHANDLE
#define AnsMemPointer            ANSMEMPOINTER
#define AnsMemLock               ANSMEMLOCK
#define AnsMemUnlock             ANSMEMUNLOCK
#define cAnsMemInitial           CANSMEMINITIAL
#define cAnsMemDestroy           CANSMEMDESTROY
#define cfAnsMemGrow             CFANSMEMGROW
#define SetDbgInfo               SETDBGINFO
#define cfAnsMemBlkNmInq         CFANSMEMBLKNMINQ
#define cfAnsMemInquire          CFANSMEMINQUIRE
#define cfAnsMemInform           CFANSMEMINFORM
#define cfAnsMemJournal          CFANSMEMJOURNAL
#define cfAnsMemInitial          CFANSMEMINITIAL
#define cfAnsMemDestroy          CFANSMEMDESTROY
#define cfAnsMemReset            CFANSMEMRESET
#define cfAnsMemFillPads         CFANSMEMFILLPADS
#define cfAnsMemFillBlock        CFANSMEMFILLBLOCK
#define CheckBothMemoryTables    CHECKBOTHMEMORYTABLES
#define CheckAnsMemTable         CHECKANSMEMTABLE
#define PrintAnsMemTable         PRINTANSMEMTABLE
#define PrintcfAnsMemTable       PRINTCFANSMEMTABLE
#define AnsMemCheckAll           ANSMEMCHECKALL
#define mempplock                MEMPPLOCK
#define memppunlock              MEMPPUNLOCK
#define fmalloc                  FMALLOC
#define ffree                    FFREE
#define frealloc                 FREALLOC
#define ptrcmp                   PTRCMP
#define ptrmult                  PTRMULT
#define fAnsMemInitial           FANSMEMINITIAL
#define fAnsMemDestroy           FANSMEMDESTROY
#define HeapInitial              HEAPINITIAL
#define HeapDealloc              HEAPDEALLOC
#define HeapAllocPtr             HEAPALLOCPTR
#define HeapGetSmallint          HEAPGETSMALLINT
#define HeapDestroyer            HEAPDESTROYER
#define memiqr                   MEMIQR
#define memiqrp                  MEMIQRP
#define erinfo                   ERINFO
#define erinqr                   ERINQR
#define wrinqr                   WRINQR
#define pplock                   PPLOCK
#define ppunlock                 PPUNLOCK
#define ppproc                   PPPROC
#define lowmemmessage            LOWMEMMESSAGE
#define cfAnsMemDebugCheck       CFANSMEMDEBUGCHECK
#define cfAnsMemAlloc            CFANSMEMALLOC
#define cfAnsMemFree             CFANSMEMFREE
#define cfAnsMemGroupFree        CFANSMEMGROUPFREE
#define cfAnsMemRealloc          CFANSMEMREALLOC
#define cfAnsMemHandle           CFANSMEMHANDLE
#define cfAnsMemPointer          CFANSMEMPOINTER
#define getMemoryTestVal         GETMEMORYTESTVAL
#define setMemoryTestVal         SETMEMORYTESTVAL

#define fatal                    FATAL
#define iopiqr                   IOPIQR

#define PrintStackTrace          PRINTSTACKTRACE
#define StkClnIni                STKCLNINI
#define sysgetenv                SYSGETENV
#define erhandler                ERHANDLER

#define dyncom                   DYNCOM

#endif


/* (3)----------------------------------------------------------------*/
#if defined(LOWERCASEUNDER_SYS)

/*
 *   The pattern for these platforms is the lowercased version of the name 
 *   followed by an underscore
 */

#define AnsMemAlloc              ansmemalloc_
#define AnsMemFree               ansmemfree_
#define AnsMemRealloc            ansmemrealloc_
#define AnsMemInitial            ansmeminitial_
#define AnsMemDestroy            ansmemdestroy_
#define AnsMemReset              ansmemreset_
#define AnsMemIqr                ansmemiqr_
#define AnsMemIqrd               ansmemiqrd_
#define AnsMemInf                ansmeminf_
#define AnsMemInfd               ansmeminfd_
#define AnsMemHandle             ansmemhandle_
#define AnsMemPointer            ansmempointer_
#define AnsMemLock               ansmemlock_
#define AnsMemUnlock             ansmemunlock_
#define cAnsMemInitial           cansmeminitial_
#define cAnsMemDestroy           cansmemdestroy_
#define cfAnsMemGrow             cfansmemgrow_
#define SetDbgInfo               setdbginfo_
#define cfAnsMemBlkNmInq         cfansmemblknminq_
#define cfAnsMemInquire          cfansmeminquire_
#define cfAnsMemInform           cfansmeminform_
#define cfAnsMemJournal          cfansmemjournal_
#define cfAnsMemInitial          cfansmeminitial_
#define cfAnsMemDestroy          cfansmemdestroy_
#define cfAnsMemReset            cfansmemreset_
#define cfAnsMemFillPads         cfansmemfillpads_
#define cfAnsMemFillBlock        cfansmemfillblock_
#define CheckBothMemoryTables    checkbothmemorytables_
#define CheckAnsMemTable         checkansmemtable_
#define PrintAnsMemTable         printansmemtable_
#define PrintcfAnsMemTable       printcfansmemtable_
#define AnsMemCheckAll           ansmemcheckall_
#define mempplock                mempplock_
#define memppunlock              memppunlock_
#define fmalloc                  fmalloc_
#define ffree                    ffree_
#define frealloc                 frealloc_
#define ptrcmp                   ptrcmp_
#define ptrmult                  ptrmult_
#define fAnsMemInitial           fansmeminitial_
#define fAnsMemDestroy           fansmemdestroy_
#define HeapInitial              heapinitial_
#define HeapDealloc              heapdealloc_
#define HeapAllocPtr             heapallocptr_
#define HeapGetSmallint          heapgetsmallint_
#define HeapDestroyer            heapdestroyer_
#define memiqr                   memiqr_
#define memiqrp                  memiqrp_
#define erinfo                   erinfo_
#define erinqr                   erinqr_
#define wrinqr                   wrinqr_
#define pplock                   pplock_
#define ppunlock                 ppunlock_
#define ppproc                   ppproc_
#define lowmemmessage            lowmemmessage_
#define cfAnsMemDebugCheck       cfansmemdebugcheck_
#define cfAnsMemAlloc            cfansmemalloc_
#define cfAnsMemFree             cfansmemfree_
#define cfAnsMemGroupFree        cfansmemgroupfree_
#define cfAnsMemRealloc          cfansmemrealloc_
#define cfAnsMemHandle           cfansmemhandle_
#define cfAnsMemPointer          cfansmempointer_
#define getMemoryTestVal         getmemorytestval_
#define setMemoryTestVal         setmemorytestval_

#define fatal                    fatal_
#define iopiqr                   iopiqr_

#define PrintStackTrace          printstacktrace_
#define StkClnIni                stkclnini_
#define sysgetenv                sysgetenv_
#define erhandler                erhandler_

#define dyncom                   dyncom_

#endif


/* (4)----------------------------------------------------------------*/

/*
 *   This section is for definition of prototypes.  Each prototype 
 *   should be ANSI compliant and specify the types of each parameter 
 *   as well as the return type.
 */

#ifdef __cplusplus
extern "C" {
#endif

PTR FUNCTION AnsMemAlloc(INT *insize, INT *sizeOfElement, INT *key);
SUBROUTINE AnsMemFree(PTR *inPtr);
PTR FUNCTION AnsMemRealloc(PTR *inPtr, INT *insize, INT *sizeOfElement, 
  INT *key);
INT FUNCTION AnsMemInitial(PTR *initialPoolSize, PTR *growthPoolSize, 
  UNSIGNED_INT *blockSplitTolerance, UNSIGNED_INT *inAlignment, PTR *lowAddress,
  PTR *highAddress, UNSIGNED_INT *debugLevel);
INT FUNCTION AnsMemDestroy(INT *checkLeaks);
SUBROUTINE AnsMemReset(INT *checkLeaks);
PTR FUNCTION AnsMemIqr(INT *what);
DOUBLE FUNCTION AnsMemIqrd(INT *what);
SUBROUTINE AnsMemInf(INT *what, PTR *value);
SUBROUTINE AnsMemInfd(INT *what, DOUBLE *value);
INT FUNCTION AnsMemHandle(PTR *);
PTR FUNCTION AnsMemPointer(INT *);
INT FUNCTION AnsMemUnlock(PTR *);
PTR FUNCTION AnsMemLock(INT *);
INT FUNCTION cAnsMemInitial(void);
SUBROUTINE cAnsMemDestroy(void);
SUBROUTINE cfAnsMemReset(void);
INT FUNCTION cfAnsMemGrow(INT *);
INT FUNCTION cfAnsMemInitial(INT *, INT *);
SUBROUTINE cfAnsMemDestroy(void);
SUBROUTINE cfAnsMemFillPads(INT *);
SUBROUTINE cfAnsMemFillBlock(INT *);
PTR FUNCTION cfAnsMemInquire(INT *handle, INT *key);
SUBROUTINE cfAnsMemInform(INT *item, PTR *val);
INT FUNCTION CheckBothMemoryTables(void);
INT FUNCTION CheckAnsMemTable(void);
SUBROUTINE PrintAnsMemTable(void);
SUBROUTINE PrintcfAnsMemTable(void);
SUBROUTINE mempplock(void);
SUBROUTINE memppunlock(void);
PTR FUNCTION fmalloc(PTR *size);
SUBROUTINE ffree(PTR *ptr);
PTR FUNCTION frealloc(PTR *ptr, PTR *size);
INT FUNCTION ptrcmp(PTR *ptr1, PTR *ptr2);
PTR FUNCTION ptrmult(PTR *inPtr, PTR *inM, INT *inOperation);
INT FUNCTION fAnsMemInitial(void);
SUBROUTINE fAnsMemDestroy(void);
INT FUNCTION HeapInitial(INT *fixed);
SUBROUTINE HeapDealloc(INT *handle);
INT FUNCTION HeapAllocPtr(INT *num, FCHAR(blockname), INT *iType, INT *handle FCHARL(blockname_len));
INT FUNCTION HeapGetSmallint(void);
SUBROUTINE HeapDestroyer(void);
INT FUNCTION memiqr(INT *);
PTR FUNCTION memiqrp(INT *);
SUBROUTINE erinfo(INT *, INT *);
INT FUNCTION erinqr(INT *);
INT FUNCTION wrinqr(INT *);
SUBROUTINE pplock(INT *);
SUBROUTINE ppunlock(INT *);
INT FUNCTION ppproc(void);
INT FUNCTION lowmemmessage(INT *level, PTR *needed);
INT FUNCTION cfAnsMemDebugCheck(INT *what, PTR *data);
INT FUNCTION AnsMemCheckAll(FCHAR(msg) FCHARL(msg_len));
SUBROUTINE SetDbgInfo(INT *handle, FCHAR(blockName), INT *blockLength, 
  INT *blockElementSize, INT *blockType FCHARL(blockName_len));
SUBROUTINE cfAnsMemJournal(INT *, PTR *, FCHAR(str) FCHARL(str_len));
SUBROUTINE cfAnsMemBlkNmInq(INT *handle, FCHAR(blockName) 
  FCHARL(blockName_len));
PTR FUNCTION cfAnsMemAlloc(PTR *iLenIn, INT *key, PTR *cNameIn, INT *cLineNumIn,
  FCHAR(blockNameIn) FCHARL(blockNameIn_len));
SUBROUTINE cfAnsMemFree(PTR *memPtr, CHAR *cNameIn, INT *cLineNumIn);
SUBROUTINE cfAnsMemGroupFree(INT *groupKey);
PTR FUNCTION cfAnsMemRealloc(PTR *memPtr, PTR *iLenIn, INT *key, PTR *cNameIn, 
  INT *cLineNumIn, FCHAR(blockNameIn) FCHARL(blockNameIn_len));
INT FUNCTION cfAnsMemHandle(PTR *memPtr);
PTR FUNCTION cfAnsMemPointer(INT *handle);

SUBROUTINE fatal(INT *type, INT *unit, INT *ios);
INT FUNCTION iopiqr(INT *what);

SUBROUTINE PrintStackTrace(void);
SUBROUTINE StkClnIni(void);
INT FUNCTION sysgetenv(FCHAR(name), FCHAR(string), INT *nstring, INT *nsub FCHARL(name_len) FCHARL(string_len));
void erhandler(FCHAR(file), INT *msgid, INT *msglvl, FCHAR(string), DOUBLE *dperr, FCHAR(cherr) FCHARL(file_len) FCHARL(string_len) FCHARL(cherr_len));

INT FUNCTION getMemoryTestVal(INT *which);
SUBROUTINE setMemoryTestVal(INT *which, INT *val);


#ifdef __cplusplus
}
#endif

#endif
