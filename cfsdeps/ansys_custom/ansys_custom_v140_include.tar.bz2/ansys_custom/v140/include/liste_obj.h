/* liste_obj.h CADOE  */
/**
 *  liste_obj.h - definitions, prototypes des fonctions de listes chainees
 *            s'appuyant sur les listes non typees de OAstd.
 *
 *   
 * HISTORY
 *   
 *   06/21/00 16:30 <       Brian Jantzen> Rel:ms8m1    SCCA:74307  Delta:81.2
 **/

/* $Id: liste_obj.h,v 1.4 2009/11/13 16:13:03 jtm Exp $ */


/* protection contre lecture multiple */
#ifndef __adolisteobjh__ 
#define __adolisteobjh__ 1 

/* types d'objets */
#define OBJ_ELEMENT     1
#define OBJ_NOEUD       2
#define OBJ_ENTIER      5
#define OBJ_DEPEND      8
#define OBJ_LOOP        9
#define OBJ_SHELL       10
#define OBJ_CONFIG      12
#define OBJ_TRANSFORMATION      13
#define OBJ_RESULTAT    15
#define OBJ_IVEC        16
#define OBJ_COEFM       17
#define OBJ_LISTE       18
#define OBJ_REPERE      23

#endif

