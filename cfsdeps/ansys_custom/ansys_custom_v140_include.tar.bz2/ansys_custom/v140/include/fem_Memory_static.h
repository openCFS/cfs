/*  fem_Memory_static.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  fem_Memory_static.h
 *  header file for finite element mesh module memory management (mmmm:-)
 *
 */
/* 
 * *** ansys(r) copyright(c) 2009
 * *** ansys, inc.
 */
#ifndef FEM_MEMORY_STATIC_INCLUDE
#define FEM_MEMORY_STATIC_INCLUDE

/*------------------ Static Internal Functions ------------------------*/

static void *fem_malloc_element( void );
static void *fem_malloc_face( void );
static void *fem_malloc_edge( void );
static void *fem_malloc_node( void );
static void *fem_malloc_face_use( void );
static void *fem_malloc_edge_use( void );
static void *fem_malloc_nextnode( void );
static void fem_free_element ( void *point );
static void fem_free_face( void *point );
static void fem_free_edge( void *point );
static void fem_free_node( void *point );
static void fem_free_face_use( void *point );
static void fem_free_edge_use( void *point );
static void fem_free_nextnode( void *point );

#endif
