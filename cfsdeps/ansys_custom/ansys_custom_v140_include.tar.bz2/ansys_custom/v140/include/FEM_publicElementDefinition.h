#ifndef __FEM_PUBLIC_ELEMENT_DEFINITION_H__
#define __FEM_PUBLIC_ELEMENT_DEFINITION_H__

/* The mesh topology arrays */
/* the data comes from cmdb */
/* -------------------------------------*/
/* this is the define from FEM_publicElementDefinition.h */
/* -------------------------------------*/
/* *** mpg math array c
 FEM_array.c FEM_matrix.c FEM_MeshTable.h FEM_Public.h FEM_array.h
 FEM_array_static.h  FEM_cdbtypes.h FEM_edPublic.h FEM_elPublic.h
 FEM_errors.h FEM_external.h FEM_faPublic.h FEM_matrix.h
 FEM_matrix_static.h FEM_meshTree.h FEM_noGeom.h FEM_noPublic.h
 FEM_publicElementDefinition.h fem_Struct.h
 ansproto.h computer.h float.h globals.h mathfun.h
*/
#if 0
                                 *** TRI ***

              NODES                   EDGES

                *2                      *              EDGE     NODES
               / \                     / \             --------------
              /   \                   /   \             0       1 2 4
           5 *     * 4               1     0            1       2 0 5
            /       \               /       \           2       0 1 3
           /         \             /         \
         0*-----*-----*1          *-----2-----*
                3

#endif
static int TRI_FACE_NODE[1][6] = {0,1,2,3,4,5};
static int TRI_EDGE_NODE[3][3] = {{1, 2, 4}, {2, 0, 5}, {0, 1, 3}};
static int TRI_NODE_EDGE[6][2] = {{2, 1}, {0, 2}, {1, 0}, {2, -1}, {0, -1}, {1, -1}};
static int TRI_FACE_EDGE[1][4] = {0, 1, 2, -1};

#if 0
                                 *** QUAD ***
                6
         3*-----*-----*2          *----2------*
          |           |           |           |        EDGE    NODES
          |           |           |           |        -------------
          |           |           |           |         0      0 1 4
         7*           *5          3           1         1      1 2 5
          |           |           |           |         2      2 3 6
          |           |           |           |         3      3 0 7
          |           |           |           |     
         0*-----*-----*1          *-----0-----*
                4 

#endif
static int QUAD_FACE_NODE[1][8]={0,1,2,3,4,5,6,7};
static int QUAD_EDGE_NODE[4][3] = {{0, 1, 4}, {1, 2, 5}, {2, 3, 6}, {3, 0, 7}};
static int QUAD_NODE_EDGE[8][2] = {{0, 3}, {1, 0}, {2, 1}, {3, 2},{0, -1}, {1, -1}, {2, -1}, {3, -1}};
static int QUAD_FACE_EDGE[1][4] = { 0, 1, 2, 3 };
/* === TET === */
#if 0
                                 *** TET ***

             NODES                   EDGES                 FACES

               3
               *                       *                     *
              /|\                     /|\                   /|\  /---1
             / | \                   / | \                 / | \/
           7*  |  *9                3  |  5               /  | /\
           /   |   \               /   |   \             / 2 | 0 \
          /    *8   \             /    4    \           /    |    \
        0*- - *|- - -*2          *- - -|-2- -*         *- - -|- - -*
          \   6|    /             \    |    /           \    |    /
           \   |   /               \   |   /             \   |  |/
           4*  |  *5                0  |  1               \  |  /
             \ | /                   \ | /                 \ | /|
              \|/                     \|/                   \|/ |
               *1                      *                     *  |
                                                                3

   FACE     NODES        EDGES            EDGE   NODES    EDGE   NODES
   -----------------------------          ------------    ------------
    0       3 1 2        4 1 5             0      1 4 0   3      3 7 0
    1       3 2 0        5 2 3             1      2 5 1   4      3 8 1
    2       3 0 1        3 0 4             2      0 6 2   5      3 9 2
    3       2 1 0        1 0 2

#endif

                               /* Face   Nodes */
static int TET_FACE_NODE[4][3] = {/* 0 */ {3, 1, 2},
                                 /* 1 */ {3, 2, 0},
                                 /* 2 */ {3, 0, 1},
                                 /* 3 */ {2, 1, 0}};

static                      /* Face   Edges */
int TET_FACE_EDGE[4][3] = {/* 0 */ {4, 1, 5},
                           /* 1 */ {5, 2, 3},
                           /* 2 */ {3, 0, 4},
                           /* 3 */ {1, 0, 2}};

static                      /* Edge   Nodes */
int TET_EDGE_NODE[6][3] = {/* 0 */ {1, 0, 4}, 
                           /* 1 */ {2, 1, 5}, 
                           /* 2 */ {0, 2, 6},
                           /* 3 */ {3, 0, 7}, 
                           /* 4 */ {3, 1, 8}, 
                           /* 5 */ {3, 2, 9}};

static                      /* Nodes   Faces */
int TET_NODE_FACE[4][3] = {/* 0 */ {3, 2, 1},
                           /* 1 */ {3, 0, 2},
                           /* 2 */ {3, 1, 0},
                           /* 3 */ {0, 1, 2}};

static                      /* Nodes   Edges */
int TET_NODE_EDGE[4][3] = {/* 0 */ {2, 0, 3},
                           /* 1 */ {0, 1, 4},
                           /* 2 */ {1, 2, 5},
                           /* 3 */ {4, 5, 3}};

static                      /* Edge  Faces */
int TET_EDGE_FACE[6][2] = {/* 0 */ {3, 2},
                           /* 1 */ {3, 0},
                           /* 2 */ {3, 1},
                           /* 3 */ {2, 1},
                           /* 4 */ {0, 2},
                           /* 5 */ {1, 0}};

static  /* index of node 0, required index with respect to 0 */
int TET_NODE_ORIENT[4][4] = { /* 0 */ {0, 1, 2, 3},
                              /* 1 */ {2, 0, 1, 3},
                              /* 2 */ {1, 2, 0, 3},
                              /* 3 */ {3, 2, 1, 0}};

   /* --- This array traces a nonunique path from the element to
      --- a specific node. Used for elNode (return the node corresponding
      --- to the ith index of the element) Numbers represent local
      --- array indices in the parent entity */

static                      /* Node  {iface,iedge,inode} */
int TET_NODE_ELEM[4][3] = {/* 0 */ {2, 1, 0},
                           /* 1 */ {2, 1, 1},
                           /* 2 */ {0, 2, 0},
                           /* 3 */ {0, 2, 1}};

   /* --- This one specifies how the edges are oriented on a face
      --- (as defined in the FACE_EDGE array) with respect to the 
      --- EDGE_NODE array.  This is used in setting up the edge
      --- use node_orientations for each of the faces */
                                   /* Face   edge orientations */
#if 0
                               *** WEDGE ***

              NODES                   EDGES                  FACES
                                                                   3 
               11                                                 /
         3*-----*-----*5          *-----5-----*          *-----------*
          |\         /|           |\         /|          |\     /   /|
          | \       / |           | \       / |          | \   /   / |
          |  *9  10*  |           |  3     4  |          |  \  4  /  |
        12*   \   /   *14         6   \   /   8          |   \   /   |
          |    \ /    |           |    \ /    |          |    \ /    |
          |     *4    |           |     *     |          |     *     |
          |     |     |           |     |     |          |  1  |  2  |
         0*- - -|*8- -*2          *- - -|2 - -*          *- - -|- - -*
           \    |    /             \    |    /            \    |    / 
            \ 13*   /               \   7   /              \   |   /
            6*  |  *7                0  |  1                \  || /
              \ | /                   \ | /                  \ ||/
               \|/                     \|/                    \|/
                *                       *                      *|
                1                                               |
                                                                0
 
   FACE     NODES        EDGES            EDGE   NODES    EDGE   NODES
   -----------------------------          ------------    ------------
   0      2 1 0        1 0 2              0      1 6 0    5      5 11 3
   1      4 3 0 1      3 6 0 7            1      2 7 1    6      3 12 0
   2      5 4 1 2      4 7 1 8            2      0 8 2    7      4 13 1
   3      3 5 2 0      5 8 2 6            3      3 9 4    8      5 14 2
   4      5 3 4        5 3 4              4      4 10 5
#endif

static                        /* Face   Nodes */
int WEDGE_FACE_NODE[5][4] = {/* 0 */ {2, 1, 0, -1},
                             /* 1 */ {4, 3, 0, 1},
                             /* 2 */ {5, 4, 1, 2},
                             /* 3 */ {3, 5, 2, 0},
                             /* 4 */ {5, 3, 4, -1} };

static                        /* Face   Edges */
int WEDGE_FACE_EDGE[5][4] = {/* 0 */ {1, 0, 2, -1},
                             /* 1 */ {3, 6, 0, 7},
                             /* 2 */ {4, 7, 1, 8},
                             /* 3 */ {5, 8, 2, 6},
                             /* 4 */ {5, 3, 4, -1} };

static                        /* Edge  Nodes */
int WEDGE_EDGE_NODE[9][3] = {/* 0 */  {1, 0, 6},
                             /* 1 */  {2, 1, 7},
                             /* 2 */  {0, 2, 8},
                             /* 3 */  {3, 4, 9},
                             /* 4 */  {4, 5, 10},
                             /* 5 */  {5, 3, 11},
                             /* 6 */  {3, 0, 12},
                             /* 7 */  {4, 1, 13},
                             /* 8 */  {5, 2, 14} };

static                        /* Node  Faces */
int WEDGE_NODE_FACE[6][3] = {/* 0 */ {1, 3, 0},
                             /* 1 */ {2, 1, 0},
                             /* 2 */ {3, 2, 0},
                             /* 3 */ {3, 1, 4},
                             /* 4 */ {1, 2, 4},
                             /* 5 */ {2, 3, 4} };

static                        /* Node   Edges */
int WEDGE_NODE_EDGE[6][3] = {/* 0 */ {6, 2, 0},
                             /* 1 */ {7, 0, 1},
                             /* 2 */ {8, 1, 2},
                             /* 3 */ {5, 6, 3},
                             /* 4 */ {3, 7, 4},
                             /* 5 */ {4, 8, 5} };

static                        /* Edge   Faces */
int WEDGE_EDGE_FACE[9][2] = {/* 0 */ {0, 1},
                             /* 1 */ {0, 2},
                             /* 2 */ {0, 3},
                             /* 3 */ {4, 1},
                             /* 4 */ {4, 2},
                             /* 5 */ {4, 3},
                             /* 6 */ {1, 3},
                             /* 7 */ {2, 1},
                             /* 8 */ {3, 2} };

static                        /* Node {iface,iedge,inode} */
int WEDGE_NODE_ELEM[6][3] = {/* 0 */ {0, 1, 1},
                             /* 1 */ {0, 1, 0},
                             /* 2 */ {0, 0, 0},
                             /* 3 */ {1, 0, 1},
                             /* 4 */ {1, 0, 0},
                             /* 5 */ {2, 0, 0} };

static
int WEDGE_NODE_ORIENT[6][6] = { /* 0 */ {0, 1, 2, 3, 4, 5},
                                /* 1 */ {2, 0, 1, 5, 3, 4},
                                /* 2 */ {1, 2, 0, 4, 5, 3},
                                /* 3 */ {3, 5, 4, 0, 2, 1},
                                /* 4 */ {4, 3, 5, 1, 0, 2},
                                /* 5 */ {5, 4, 3, 2, 1, 0}};

#if 0
                                *** PYRAMID ***

                  NODES               EDGES                 FACES

                    *4                  *                     *
                   /|\                 /|\                   /|\  3
                  / | \               / | \            4    / | \/
               12*  |  *11           7  |  6            \  /  | /\
                /   |   \       4   /   5   \            \/   |   \
               /    |7   \       \ /    |    \           /    | 2  \
             3*- - -|* - -*2      *- - 2|- - -*         *- - -|- - -*
             /      *10  /       /      |    /         /   1  |    /
            /       |   /       /       |   /         /       |   /
         8 *        |  * 6     3        |  1         /        |  /
          /         | /       /         | /         /      |  | /
         /          |/       /          |/         /       |  |/
       0*-----*-----*1      *-----0-----*         *-----------*
             5                                             |
                                                           0


       Or the same thing again but just with a different angle

           NODES               EDGES                 FACES
 
            4
            *                   *                   *
           /|\                 /|\                 /|\
          // \\               // \\               // \\  3
         / | | \             / | | \             / | | \/
      12* /   \ *11         7 /   \ 6           / /   \/\
       /  |   |  \         /  |   |  \         /  |  /|  \
      /  /  7  \  \       /  /     \  \       / 4/     \2 \
    3*- -|- * -|- -*2    *- -|- 2 -|- -*     *- -|- - -|- -*
     |  *9    10*  |     |  4       5  |     |  /   1   \  |
     |  |       |  |     |  |       |  |     |  |       |  |
    8* /         \ *6    3 /         \ 1     | /         \ |
     | |         | |     | |         | |     | |    |    | |
     |/           \|     |/           \|     |/     |     \|
     *------*------*     *------0------*     *-------------*
     0      5      1                                |
                                                    0

   FACE     NODES        EDGES            EDGE   NODES    EDGE  NODES
   -----------------------------          ------------    ------------
   0       3 2 1 0      2 1 0 3           0      1 5 0     4    4 9  0
   1         4 0 1        4 0 5           1      2 6 1     5    4 10 1
   2         4 1 2        5 1 6           2      3 7 2     6    4 11 2
   3         4 2 3        6 2 7           3      0 8 3     7    4 12 3
   4         4 3 0        7 3 4

#endif

static                          /* Face   Nodes */
int PYRAMID_FACE_NODE[5][4] = {/* 0 */ {3, 2, 1, 0},
                               /* 1 */ {4, 0, 1, -1},
                               /* 2 */ {4, 1, 2, -1},
                               /* 3 */ {4, 2, 3, -1},
                               /* 4 */ {4, 3, 0, -1}};

static                          /* Face   Edges */
int PYRAMID_FACE_EDGE[5][4] = {/* 0 */ {2, 1, 0, 3},
                               /* 1 */ {4, 0, 5, -1},
                               /* 2 */ {5, 1, 6, -1},
                               /* 3 */ {6, 2, 7, -1},
                               /* 4 */ {7, 3, 4, -1} };

static                          /* Edge  Nodes */
int PYRAMID_EDGE_NODE[8][3] = {/* 0 */  {1, 0, 5},
                               /* 1 */  {2, 1, 6},
                               /* 2 */  {3, 2, 7},
                               /* 3 */  {0, 3, 8},
                               /* 4 */  {4, 0, 9},
                               /* 5 */  {4, 1, 10},
                               /* 6 */  {4, 2, 11},
                               /* 7 */  {4, 3, 12}};

static                          /* Node  Faces */
int PYRAMID_NODE_FACE[5][4] = {/* 0 */ {1, 4, 0, -1},
                               /* 1 */ {2, 1, 0, -1},
                               /* 2 */ {3, 2, 0, -1},
                               /* 3 */ {4, 3, 0, -1},
                               /* 4 */ {1, 2, 3, 4}};

static                          /* Node   Edges */
int PYRAMID_NODE_EDGE[5][4] = {/* 0 */ {0, 4, 3, -1},
                               /* 1 */ {1, 5, 0, -1},
                               /* 2 */ {1, 2, 6, -1},
                               /* 3 */ {2, 3, 7, -1},
                               /* 4 */ {4, 5, 6, 7}};

static                          /* Edge   Faces */
int PYRAMID_EDGE_FACE[8][2] = {/* 0 */ {0, 1},
                               /* 1 */ {0, 2},
                               /* 2 */ {0, 3},
                               /* 3 */ {0, 4},
                               /* 4 */ {4, 1},
                               /* 5 */ {1, 2},
                               /* 6 */ {2, 3},
                               /* 7 */ {3, 4}};

static                      /* Node {iface,iedge,inode} */
int PYRAMID_NODE_ELEM[5][3] = {/* 0 */ {0, 2, 1},
                               /* 1 */ {0, 1, 1},
                               /* 2 */ {0, 0, 1},
                               /* 3 */ {0, 0, 0},
                               /* 4 */ {1, 0, 0} };

 static
int PYRAMID_NODE_ORIENT[5][5] = { /* 0 */ {0, 1, 2, 3, 4},
                                  /* 1 */ {3, 0, 1, 2, 4},
                                  /* 2 */ {2, 3, 0, 1, 4},
                                  /* 3 */ {1, 2, 3, 0, 4},
                                  /* 4 */ {1, 2, 3, 4, 0} /* special case */};                                                               
                                                                
#if 0

                                 *** HEX ***

              NODES                   EDGES                  FACES
                                                                        3
                 14                                                    /
           7*-----*-----*6           *----6------*            *----------*
           /|          /|           /|          /|           /|      /  /|
          /           / |          /           / |          /       /  / |
       15*  |      13*  |         7  |        5  |         /  |  5    /  |
        /   *20     /   *19      /   11      /   |        /          /   |
       /  12|      /    |       /    |      /   10       /    |     /    |
     4*-----*-----*5    |      *------4----*     |      *----------*     |
      |     |     |     |      |     |     |     |   4--|--   |    |  2  |
      |    3*- - *|- - -*2     |     *- - 2|- - -*      |     *- - |- - -*
      |    /    10|    /       |    /      |    /       |    /     |    /
    16*           *17 /        8           9            |     1    |   /
      |  *11      |  *9        |  3        |  1         |          |  /
      |           | /          |           |            |          | /
      |/          |/           |/          |/           |/     |   |/
     0*-----*-----*1           *-----0-----*            *----------*
            8                                                  |
                                                               0

   FACE     NODES        EDGES            EDGE   NODES    EDGE   NODES
   -----------------------------          ------------    ------------
   0      3 2 1 0      2 1 0 3            0      1 8 0     6    6 14 7
   1      5 4 0 1      4 8 0 9            1      2 9 1     7    7 15 4
   2      6 5 1 2      5 9 1 10           2      3 10 2    8    4 16 0
   3      7 6 2 3      6 10 2 11          3      0 11 3    9    5 17 1
   4      7 3 0 4      11 3 8 7           4      4 12 5    10   6 18 2
   5      7 4 5 6      7 4 5 6            5      5 13 6    11   7 19 3

#endif

static                      /* Face   Nodes */
int HEX_FACE_NODE[6][4] = {/* 0 */ {3, 2, 1, 0},
                           /* 1 */ {5, 4, 0, 1},
                           /* 2 */ {6, 5, 1, 2},
                           /* 3 */ {7, 6, 2, 3},
                           /* 4 */ {7, 3, 0, 4},
                           /* 5 */ {7, 4, 5, 6}};

static                      /* Face   Edges */
int HEX_FACE_EDGE[6][4] = {/* 0 */ {2, 1, 0, 3},
                           /* 1 */ {4, 8, 0, 9},
                           /* 2 */ {5, 9, 1, 10},
                           /* 3 */ {6, 10, 2, 11},
                           /* 4 */ {11, 3, 8, 7},
                           /* 5 */ {7, 4, 5, 6}};
                                   
static                       /* Edge  Nodes */
int HEX_EDGE_NODE[12][3] = {/* 0 */  {1, 0, 8}, 
                            /* 1 */  {2, 1, 9}, 
                            /* 2 */  {3, 2, 10},
                            /* 3 */  {0, 3, 11}, 
                            /* 4 */  {4, 5, 12}, 
                            /* 5 */  {5, 6, 13},
                            /* 6 */  {6, 7, 14}, 
                            /* 7 */  {7, 4, 15}, 
                            /* 8 */  {4, 0, 16},
                            /* 9 */  {5, 1, 17}, 
                            /* 10 */ {6, 2, 18}, 
                            /* 11 */ {7, 3, 19}};

static                      /* Node  Faces */
int HEX_NODE_FACE[8][3] = {/* 0 */ {4, 0, 1}, 
                           /* 1 */ {2, 1, 0},
                           /* 2 */ {3, 2, 0}, 
                           /* 3 */ {3, 0, 4},
                           /* 4 */ {5, 4, 1}, 
                           /* 5 */ {5, 1, 2},
                           /* 6 */ {5, 2, 3}, 
                           /* 7 */ {5, 3, 4}};

static                      /* Node   Edges */
int HEX_NODE_EDGE[8][3] = {/* 0 */ {8, 3, 0},
                           /* 1 */ {1, 9, 0},
                           /* 2 */ {2, 10, 1},
                           /* 3 */ {11, 2, 3},
                           /* 4 */ {4, 7, 8},
                           /* 5 */ {5, 4, 9},
                           /* 6 */ {6, 5, 10},
                           /* 7 */ {7, 6, 11}};

static                       /* Edge   Faces */ 
int HEX_EDGE_FACE[12][2] = {/* 0 */ {0, 1},
                            /* 1 */ {0, 2},
                            /* 2 */ {0, 3},
                            /* 3 */ {0, 4},
                            /* 4 */ {5, 1},
                            /* 5 */ {5, 2},
                            /* 6 */ {5, 3},
                            /* 7 */ {5, 4},
                            /* 8 */ {1, 4},
                            /* 9 */ {2, 1},
                            /* 10 */ {3, 2},
                            /* 11 */ {4, 3}};

static            /* index of node 0, required index with respect to 0 */
int HEX_NODE_ORIENT[8][8] = { /* 0 */ {0, 1, 2, 3, 4, 5, 6, 7},
                              /* 1 */ {3, 0, 1, 2, 7, 4, 5, 6},
                              /* 2 */ {2, 3, 0, 1, 6, 7, 4, 5},
                              /* 3 */ {1, 2, 3, 0, 5, 6, 7, 4},
                              /* 4 */ {4, 7, 6, 5, 0, 3, 2, 1},
                              /* 5 */ {5, 4, 7, 6, 1, 0, 3, 2},
                              /* 6 */ {6, 5, 4, 7, 2, 1, 0, 3},
                              /* 7 */ {7, 6, 5, 4, 3, 2, 1, 0}};

static                      /* Node {iface,iedge,inode} */
int HEX_NODE_ELEM[8][3] = {/* 0 */ {0, 2, 1},
                           /* 1 */ {0, 2, 0},
                           /* 2 */ {0, 1, 0},
                           /* 3 */ {0, 0, 0},
                           /* 4 */ {5, 1, 0},
                           /* 5 */ {5, 1, 1},
                           /* 6 */ {5, 2, 1},
                           /* 7 */ {5, 3, 1}};


/* this is the define from fem_public.h */


static int NUM_NODE_PER_ELEM[7]={0,6,8,20,15,13,10};
static int NUM_CORNER_NODE_PER_ELEM[7]={0,3,4,8,6,5,4};
static int NUM_EDGE_PER_ELEM[7]={0,3,4,12,9,8,6};
static int NUM_FACE_PER_ELEM[7]={0,1,1,6,5,5,4};

static int *ELEMENT_EDGE_NODE[7]={
    (int *)0,
    (int *)&(TRI_EDGE_NODE[0][0]),
    (int *)&(QUAD_EDGE_NODE[0][0]),
    (int *)&(HEX_EDGE_NODE[0][0]),
    (int *)&(WEDGE_EDGE_NODE[0][0]),
    (int *)&(PYRAMID_EDGE_NODE[0][0]),
    (int *)&(TET_EDGE_NODE[0][0]) };

static int *ELEMENT_FACE_NODE[7]={
    (int *)0,
    (int *)&(TRI_FACE_NODE[0][0]),
    (int *)&(QUAD_FACE_NODE[0][0]),
    (int *)&(HEX_FACE_NODE[0][0]),
    (int *)&(WEDGE_FACE_NODE[0][0]),
    (int *)&(PYRAMID_FACE_NODE[0][0]),
    (int *)&(TET_FACE_NODE[0][0]) };

static int *ELEMENT_FACE_EDGE[7]={
    (int *)0,
    (int *)&(TRI_FACE_EDGE[0][0]),
    (int *)&(QUAD_FACE_EDGE[0][0]),
    (int *)&(HEX_FACE_EDGE[0][0]),
    (int *)&(WEDGE_FACE_EDGE[0][0]),
    (int *)&(PYRAMID_FACE_EDGE[0][0]),
    (int *)&(TET_FACE_EDGE[0][0]) };

typedef enum{ NO_ERROR_LEVEL = 0,
              WARNING_LEVEL,
              ERROR_LEVEL 
} ERROR_LEVEL_ENUM;


typedef enum{
    UNDEFINED_SHAPE = 0,
    TRI_SHAPE,
    QUAD_SHAPE,
    HEX_SHAPE, 
    WEDGE_SHAPE, 
    PYRAMID_SHAPE, 
    TET_SHAPE,
    LINE_SHAPE,
    POINT_SHAPE
} SHAPE_ENUM;
#endif

