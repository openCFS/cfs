/*! \file CDirection.h

  \brief This header file defines the CDirection class.

  \author St�phane MARGUERIN &copy; CADOE

  \date Juillet 2002

  \version $Id: CDirection.h,v 1.3 2009/11/13 16:13:02 jtm Exp $
*/
#ifndef __CDirection_h__ 
#define __CDirection_h__ 1 

#include "cadoe_list.h"
#include "cadoe_map.h"
#include "CDesignSet.h"
#include "CParameterMgr.h"

#ifndef NO_CADOE_NAMESPACE 
namespace Cadoe { 
#endif 

  /*! \class CDirection CDirection.h
    \brief The CDirection class is defined by one starting point and one endinf point.
    It describes a direction in the parameteriwed space.
  */
  class CDirection
    {
    public:
      typedef enum {
	DNT_INITIAL=0,	/**< all parameters fixed at their initial value */
	DNT_POINT,	/**< some parameters fixed at a value different from the initial one, no varying parameters */
	DNT_CANONICAL,	/**< one parameter varying, all other fixed at their initial value */
	DNT_UNIAXIAL,	/**< one parameter varying, some other parameters fixed at a value different from the initial one. */
	DNT_COMBINED	/**< several parameters varying, several parameters fixed at a value different from the initial one */
      } Nature;

      typedef list<CDesignSet> DesignSetList;

      CDirection( const string &name, const CParameterMgr &pmgr );
      CDirection( const CDirection &drt );
      ~CDirection();

      CDirection& operator =( const CDirection &drt);



      int getId(void) {return _id;}

      /*! \brief Returns the direction name.
	\return direction name
      */
      string getName(void) const {return _name;}

      void setXAxis(  bool xaxis=true ) { _xaxis=xaxis; }
      bool isXAxis(void) const { return _xaxis; }

      /*! \brief Returns true if the direction is canonical.
	\return isCanonical
      */
      bool isCanonical(void) const { return (_nature==DNT_CANONICAL); }
      /*! \brief Returns true if the direction is uniaxial.
	\return isUniaxial
      */
      bool isUniaxial(void) const { return (_nature==DNT_UNIAXIAL); }

      /*! \brief Reset a parameter so it is not varying and fixed at its initial value. The parameter becomes
	inactive for this direction.
	\return isVarying
      */
      void resetParameter( const string &pName );
      void reset(void);
      /*! \brief Returns true if the pName parameter is varying in this direction.
	\return isVarying
      */
      bool paramIsVarying( const string &pName ) const;

      /*! \brief Activate a parameter with a constant value. 
	The value assigned is considered as the reference value for the normalization operations.
	\param pName parameter name
	\param val value to assign to the parameter
	\return 0 for success
      */
      int setConstantValue( const string &pName, double val );

      /*! \brief Activate a parameter with its full range of variation: the reference value 
	is equal to the initial value.
	\param pName parameter name
	\return 0 for success
      */
      int setFullRangeVariation( const string &pName );
      /*! \brief Activate a parameter with a given range of variation and reference value. 
	The reference is the reference for the normalization operations.
	\param pName parameter name
	\param startValue start value of the variation range
	\param endValue end value of the variation range
	\param refValue reference value for normalization operation.
	\return 0 for success
      */
      int setVariation( const string &pName, double startValue, double endValue, double refValue=0. );

      int setDesignSet ( const CDesignSet &set )
	{
	  _beginSet=set;
	  _endSet=set;
	  _refSet=set;
	  determineNature();
	  return 0;
	}
	
      int	setSets( const CDesignSet &beginSet, const CDesignSet &endSet ) 
	{ 
	  // steph- il faut faire bcp mieux ici: verifier la coherence des sets (longueur et parametres)
	  // + utiliser la methode setVariation() pour deteminer la nature, le pVarying, etc.
	  _beginSet = beginSet; _endSet = endSet; 
	  return 0;
	}
      int	setRefSet( const CDesignSet &set ) { _refSet = set; return 0; }

	
      /*! \brief Returns the number of varying parameters in the direction.
	\return number of varying parameters.
      */
      int numberOfVaryingParameters(void) const { return _numOfVarPar; }
      /*! \brief Returns the number of constant parameters in the direction. A parameter that is constant at its
	initial value is not considered as an active parameter in the direction so it is not counted as a constant parameter.
	\return number of varying parameters.
      */
      int numberOfConstantParameters(void) const { return _numOfConstantPar; }

      /*! \brief Returns a map table containing the active parameters in this direction. 
	\param pmap [in/out] map table of the active parameters
	\return execution status
      */
      int getActiveParameters( CParameterMgr::ParamMap &pmap ) const;
      int getActiveParametersName( list<string> &plis ) const;
	
      CDesignSet& getBeginSet(void) { return _beginSet; }
      CDesignSet& getEndSet(void) { return _endSet; }
      CDesignSet& getRefSet(void) { return _refSet; }

      /*! \brief Generate and returns a list of design sets built along the direction. 
	\param nbSteps	number of discretisation points
	\param setList	list of sets in which new sets must be added
	\return design sets list
      */
      int generateDesignSets(  int nbSteps, DesignSetList &setList );

      /*! \brief Generate a designSet on the direction, with position controlled by the ratio. By default
	the ratio is equal to 0.5, so the designSet is generated at the middle point.
	\param set [out] designSet to be generated
	\param ratio [in] value which determine the position of the designSet along the direction (0.0 to 1.0).
	\return execution status
      */
      int generateInterDesignSet( CDesignSet &set, double ratio=.5 );

      /*! \brief Normalize a parameter value relatively to the validated range of the parameter. If the parameter name
	is not specified, the first varying parameter of the direction is used. So in case of uniaxial or canonical direction,
	you do not need to specify the parameter name.
	\param val	parameter value
	\param norm	true if the normalization is possible
	\param paramName parameter name. If not specified, the first varying parameter is used.
	\return execution status
      */
      int normalizeValue( const CDesignSet &set, double *normVal, const string &paramName="" ) const;

      /*! \brief Returns the value of the given parameter in the given designSet. If the parameter name is not given,
	the method uses the first varying parameter known in the direction; so in case of uniaxial or canonical direction,
	you do not need to specify the parameter name.
	\param set [in] design set from which to extract the value
	\param paramValue [in/out]
	\param paramName [in] name of the parameter. If not specified, the first varying parameter found is used.
	\return execution status
      */
      double getParamValue( const CDesignSet &set, const string &paramName="" ) const;

      double getLength( void ) const;


      void print(void) const;


    private:

      void determineNature(void);

      static	int		_idGenerator;
      static const double	_precision;

      int			_id;			// unique id
      string			_name;		// direction name = identifier
      bool			_xaxis;		// X axis if true, Y otherwise
      Nature			_nature;  // describes the nature of the direction

      map<string,bool>		_pVarying;	// parameter is constant or variable, for each parameter
      int			_numOfConstantPar; // number of constants parameters
      int			_numOfVarPar; // number of varying parameters
      string			_uniqueVarParName; // name of the varying parameter when there is only one (uniaxial, canonical)

      const CParameterMgr&	_pmgr;	// parameter manager

      CDesignSet		_beginSet; // starting point of the direction
      CDesignSet		_refSet;	// reference point
      CDesignSet		_endSet;	// ending point of the direction
    };

#ifndef NO_CADOE_NAMESPACE 
} //namespace Cadoe 
using namespace Cadoe; 
#endif 

#endif
