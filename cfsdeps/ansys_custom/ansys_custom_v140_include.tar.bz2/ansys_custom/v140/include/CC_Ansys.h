/* CFILE CC_Ansys.h CADOE */
// fichier provenant de AnsEngineeringServer.h

#ifndef CC_ANSYS_H
#define CC_ANSYS_H

#include "cadoe.h"
#include "cadoe_version.h"
#include "sx_cons_solver.h"
#include "CC_SocketDriver.h"
#include "C_VecP.h"
#include "C_CadoeException.h"
#include "lmb.h"

#ifndef WINNT
#define MAX_PATH 1024
#endif

#define SX_DIRNAMESIZE 512
#define SX_COMMANDSIZE 512

#define DEFAULT_CADOE_PORT 10123
#define DEFAULT_ANSYS_PORT 20123

#define DEFAULT_HOST "127.0.0.1"

#define SCOPE_SOCKET	100


class CC_Ansys
{
public:
  typedef enum
  {
    E_SERVEUR,
    E_CLIENT
  } E_ConnectionType;
  
  CC_Ansys(const int port = DEFAULT_ANSYS_PORT, const char * host = DEFAULT_HOST, const bool freeNumPortToFind = false);
  virtual ~CC_Ansys();
  
  virtual void cleanUp(void);
  virtual void closeSocket(void);
  T_statut  findNumPort(void);
  virtual   T_statut initializeConnection(void) = 0;
  E_ConnectionType getConnectionType(void) { return m_connectionType; }
  int       getNumPort(void) { return m_port; };
  
  T_statut  iSendSize(unsigned int size);
  T_statut  iSendInteger(int ival);
  T_statut  iSendDouble(double dval);
  T_statut  iSendStatut(T_statut statut, C_CadoeException *ce=NULL );
  T_statut  iSendArrayChar(const char * ptr, unsigned int dim); 
  T_statut  iSendStr( const char* ptr); 
  T_statut  iSendWStr( const _TCHAR* ptr); 
  T_statut  iSendIvec(const IVEC * iv);
  T_statut  iSendVec(const VEC * v);
  T_statut  iSendBvec(const BVEC * bv);
  T_statut  iSendVec( C_VecP <int> &vec);
  T_statut  iSendVec( C_VecP <double> &vec);

  T_statut  iReceiveSize(unsigned int *size);
  T_statut  iReceiveInteger(int *ival);
  T_statut  iReceiveDouble(double *dval);
  T_statut  iReceiveStatut( void ) throw (C_CadoeException);
  T_statut  iReceiveIvec(IVEC *& iv);
  T_statut  iReceiveVec(VEC *& v);  
  T_statut  iReceiveBvec(BVEC *& bv);
  T_statut  iReceiveVec(C_VecP <int> &vec);
  T_statut  iReceiveVec(C_VecP <double> &vec);
  T_statut  iReceiveArrayChar(char **cArray, unsigned int * dim);
  T_statut  iReceiveWStr( _TCHAR **cArray, unsigned int * dim);
  void 	    SetSocketInterfacePointer(CC_SocketDriver *sockPtr);

protected:
  double		m_protocolVersion;
  E_ConnectionType	m_connectionType;
  int			m_port;
  char 			m_host [100];
  CC_SocketDriver *	m_pSocketDriver;    
  bool                  m_ByteToInverse;
  bool			m_freeNumPortToFind;
};

class CC_AnsysServeur : public CC_Ansys
{
 public:
  CC_AnsysServeur(const int port = DEFAULT_ANSYS_PORT, const char * host = DEFAULT_HOST, const bool freeNumPortToFind = false);
  virtual ~CC_AnsysServeur() {};
  
  T_statut initializeConnection(void);
  T_statut checkConsistencyRsxFile(const _TCHAR *cJobName, const _TCHAR *cRsxFileDataBase);
  T_statut checkProtocolVersion(void);
};

class CC_AnsysClient : public CC_Ansys
{
public:
  CC_AnsysClient(const int port = DEFAULT_ANSYS_PORT, const char * host = DEFAULT_HOST, const bool freeNumPortToFind = true);
  virtual ~CC_AnsysClient() {};
  
  void setAnsysPassword(const char * ansysPassword) 	{strcpy(m_ansysPassword,ansysPassword);}
  void setAnsysUserName(const char * ansysUserName)	{strcpy(m_ansysUserName,ansysUserName);}
  void setAnsysLicDir(const char * ansysLicDir)		{strcpy(m_ansysLicDir,ansysLicDir);}
  void setAnsysRev(const char * ansysRev)		{strcpy(m_ansysRev,ansysRev);}
  void setAnsysDir(const _TCHAR * ansysDir)		{CADOE_STRCPY(m_ansysDir,ansysDir);}
  void setFileName(const _TCHAR * cFileName)		{CADOE_STRCPY(m_cFileName,cFileName);}
  void setJobName(const _TCHAR * cJobName)		{CADOE_STRCPY(m_cJobName,cJobName);}
  void setDirName(const _TCHAR * cDirName)		{CADOE_STRCPY(m_cDirName,cDirName);}
  void setAnsysPath(const char * ansysPath)		{strcpy(m_ansysPath,ansysPath);}
  
  void setWorkspaceMemory( int mem ) { m_iWorkspaceMemory = mem; }
  int getWorkspaceMemory( void ) const { return m_iWorkspaceMemory; }
  void setDatabaseMemory( int mem ) { m_iDatabaseMemory = mem; }
  int getDatabaseMemory( void ) const { return m_iDatabaseMemory; }
  
  virtual T_statut 	launchAnsys(void);
  T_statut 	initializeConnection(void);
  T_statut 	checkConsistencyRsxFile(void);
  T_statut      checkProtocolVersion(void);
  T_statut 	setFirstSend(int);
  int Command( char cmdline[] );

protected:
  char m_ansysPassword[100];
  char m_ansysUserName[50];
  char m_ansysLicDir[MAX_PATH];
  char m_ansysRev[10];
  _TCHAR m_ansysDir[MAX_PATH];
  _TCHAR m_cFileName[CADOE_FILENAMEMAX];
  _TCHAR m_cJobName[CADOE_NAMESIZE];
  _TCHAR m_cDirName[SX_DIRNAMESIZE];
  char m_cCommand[SX_COMMANDSIZE]; 
  int  m_dashM;
  char m_ansysPath[MAX_PATH];
  int  m_iWorkspaceMemory; // ansys -m
  int  m_iDatabaseMemory; // ansys -db
};

#endif
