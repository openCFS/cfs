/* ********************************** */
/* *** ansys(r) copyright(c) 2009 *** */
/* *** ansys, inc.                *** */
/* ********************************** */

/*  FEM_MeshTableGuts.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/* 
 *  FEM_MeshTableGuts.h
 *  Mesh table xref mesh to fea entity
 *
 */
 #ifndef FEM_MESHTABLEGUTS
 #define FEM_MESHTABLEGUTS
#if defined( DSPACE_CMDB )  || defined(PCWINNT_SYS )
#pragma warning (disable:4786)
#endif

#include <vector>
#include <map>
#include <set>
#include "FEM_cdbtypes.h"
#include "FEM_Public.h"
#ifdef DSPACE_CMDB
#include "DSMemManager.h"
#endif

#ifndef RWSTD_NO_NAMESPACE
using namespace std;
#endif

typedef map<unsigned int,NODE_OBJ> NODE_VECTOR;
typedef map<unsigned int,EDGE_OBJ> EDGE_VECTOR;
typedef map<unsigned int,FACE_OBJ> FACE_VECTOR;
//typedef vector<ELEMENT_OBJ> ELEMENT_VECTOR;

class TOPO_MESHENTITY_VECTOR_TYP
{
public:
   // one vector of nodes
   NODE_VECTOR m_vect_nodes;
   // one vector of edges
   EDGE_VECTOR m_vect_edges;
   // one vector of faces
   FACE_VECTOR m_vect_faces;
   // one vector of elements
   //ELEMENT_VECTOR m_vect_elements;

#if 0
#ifdef unix
   TOPO_MESHENTITY_VECTOR_TYP() : m_vect_nodes(10),m_vect_edges(10),m_vect_faces(10)/*,m_vect_elements(10)*/
	{
		m_vect_nodes.clear();
		m_vect_edges.clear();
		m_vect_faces.clear();
		//m_vect_elements.clear();
	}
#endif
#endif

#ifdef DSPACE_CMDB
     static CDSMemManager<TOPO_MESHENTITY_VECTOR_TYP> m_cMemManager;

#if defined(ux11) || defined(_WIN64)
	 inline void* operator new( size_t nSize )
#else
	 inline void* operator new( unsigned int nSize )
#endif
    {
        TOPO_MESHENTITY_VECTOR_TYP* pcT = m_cMemManager.getNextAvailablePointerToData(); 
        return pcT;
    }

    inline void operator delete( void* pcTVoid )
    {
        TOPO_MESHENTITY_VECTOR_TYP* pcT = (TOPO_MESHENTITY_VECTOR_TYP*)pcTVoid;
        m_cMemManager.returnPointerToDSMemManager( pcT );
    }
#endif
};


class TOPOMAP_TYP {
public:
   map< unsigned int, TOPO_MESHENTITY_VECTOR_TYP * > m_topomap;
   map< ADDRESS_TYP, vector< unsigned int > > m_ptr_topo_map;
#ifdef DSPACE_CMDB

     static CDSMemManager<TOPOMAP_TYP> m_cMemManager;

#if defined(ux11) || defined(_WIN64)
	 inline void* operator new( size_t nSize )
#else
	 inline void* operator new( unsigned int nSize )
#endif
    {
        TOPOMAP_TYP* pcT = m_cMemManager.getNextAvailablePointerToData(); 
        return pcT;
    }

    inline void operator delete( void* pcTVoid )
    {
        TOPOMAP_TYP* pcT = (TOPOMAP_TYP*)pcTVoid;
        m_cMemManager.returnPointerToDSMemManager( pcT );
    }   
#endif
};

class MESHTABLE_TYP
{
public:
   //global map of meshes vs meshtables
   map< MESH_PTYP, TOPOMAP_TYP * > m_mastermap;
   //map
};

class CTopoIdVector
{
public:
    vector<unsigned int> m_vTopoIds;

#ifdef unix
	CTopoIdVector() : m_vTopoIds(10)
	{
		m_vTopoIds.clear();
	}
#endif

#ifdef DSPACE_CMDB

     static CDSMemManager<CTopoIdVector> m_cMemManager;

#if defined(ux11) || defined(_WIN64)
	 inline void* operator new( size_t nSize )
#else
	 inline void* operator new( unsigned int nSize )
#endif

    {
        CTopoIdVector* pcT = m_cMemManager.getNextAvailablePointerToData(); 
        return pcT;
    }

    inline void operator delete( void* pcTVoid )
    {
        CTopoIdVector* pcT = (CTopoIdVector*)pcTVoid;
        m_cMemManager.returnPointerToDSMemManager( pcT );
    }   
#endif
};

static INT FEM_mtGetTopoIdListForEntity(  CTopoIdVector* pcTopoList, 
       unsigned int **a_topoidlist, INT *length, INT iMaxSize = 0 );

#endif
