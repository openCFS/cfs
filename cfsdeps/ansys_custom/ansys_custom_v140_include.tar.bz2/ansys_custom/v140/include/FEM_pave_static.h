/*  FEM_pave_static.h */
/*
 * *** ansys(r) copyright(c) 2009
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_pave.h
 *  header file for FEM_pave.c
 *
 */
#ifndef FEM_PAVE_STATIC_INCLUDE
#define FEM_PAVE_STATIC_INCLUDE
#include <vector>

/*------------------ Constants ---------------------------------------*/
#define ANGLE_OK   2.35619449018  /* 2.00712864   2.35619449018    135 degrees */
#define BND_ANGLE_OK   2.00712864   /* 2.35619449018    135 degrees */
static DOUBLE SEAM_ANGLE1 = 0.52359877560;   /* 30 degrees */
static DOUBLE SEAM_ANGLE2 = 0.26179938780;   /* 15 degrees */
static DOUBLE SPLIT_ANGLE = 0.52359877560;   /* 30 degrees */
static DOUBLE CLOSE_SPLIT_ANGLE = 1.04719755;   /* 60 degrees */
#define ANGLE_5       0.087266462599716         /* 5 degree */ 
#define ANGLE_60      1.047197551196597          /* 60 degree */
#define ANGLE_90      1.5707963267949           /* 90 degree */
#define COS_60        0.5
#define COS_90        0
#define TUCK_ANGLE  1.36943840600  /* 78.46 degrees */
#define TUCK_ANGLE2 3.08923277602  /* 177 degrees */
#define TUCK_SHRINK_RATIO 0.9
#define MY_ARBITRARY_LIMIT 2.87979326578 /* 165 degrees */
#define SIZE_FACTOR		1.5

#define NODE0_BIT   (1<<0)
#define NODE1_BIT   (1<<1)
//#define MAX_UPDATE_FRONT 2000
#define MAX_UPDATE_ANGLE 2000
#define MAX_SEAMNODE 50
#define DUMMY_EDGEFRONT (EDGEFRONT_PTYP)0x1
#define EXIT_CANT_FORM_QUAD -999
#define EXIT_CANT_FORM_TRANSITION -998
#define EXIT_SMOOTH_ADJUSTED 100
#define EXIT_CANT_SMOOTH -997
#define EXIT_FRONT_INSIDE_FRONT -996

#define EDGE_AT_BND_OR_CURV( obj_edge )  ( FEM_edProperty_C ( obj_edge, EDGE_ON_LINE ) || \
                                           FEM_edProperty_C ( obj_edge, EDGE_AT_HIGH_CURV ) )

#define NODE_ON_AREA_NOR_CURV( obj_node )  ( FEM_noProperty_C ( obj_node, NODE_ON_AREA ) && \
                                             !FEM_noProperty_C ( obj_node, NODE_AT_HIGH_CURV ) )

#define EDGE_ON_LINE_OR_INLFATION_CAP( obj_edge ) ( FEM_edProperty_C ( obj_edge, EDGE_ON_LINE ) || \
                                                    FEM_edProperty_C ( obj_edge, EDGE_INFLATION ) )

#define EDGE_AT_BND_OR_CURV_OR_INFLATION_CAP( obj_edge )( FEM_edProperty_C ( obj_edge, EDGE_ON_LINE ) || \
                                                          FEM_edProperty_C ( obj_edge, EDGE_AT_HIGH_CURV ) || \
                                                          FEM_edProperty_C ( obj_edge, EDGE_INFLATION ) )

/* use absolute tolerance since comparing normalized values */
#define TOL 1.0e-3
static DOUBLE ZERO_TOL = DBL_EPSILON * 1.0e3;

                /* edgefront memory stuff */
#define FRONT_BLOCK_GROUP_SIZE      500
#define FRONT_BLOCK_SIZE            500
#define FRONT_STACK_GROUP_SIZE      500

#define NEXT_FRONT_EDGE 1
#define PREV_FRONT_EDGE 0

typedef struct EDGEFRONT_TYP *EDGEFRONT_PTYP;
typedef struct EDGEFRONT_TYP {
   INT state;
   INT level;
   INT maxlevel;
   INT orientation;
   INT loop;
   INT temp;
   INT numtry;
   DOUBLE length;
   EDGE_OBJ obj_edge;
   EDGEFRONT_PTYP ps_previous;
   EDGEFRONT_PTYP ps_next;
   EDGEFRONT_PTYP ps_coFront;
   FEM_BOOLEAN           bUpdate;
#ifdef _DEBUG
   INT iEdgeId;
   INT iFrontId;
#endif
   INT iStopGrowth;
} EDGEFRONT_TYP;

typedef struct ADJFAC_TYP *ADJFAC_PTYP;
typedef struct ADJFAC_TYP {
   DOUBLE angle;                   /* interior angle of face */
   FACE_OBJ obj_face;              /* adjacent face */
   EDGE_OBJ obj_edge0;             /* first edge adjacent face */
   EDGE_OBJ obj_edge1;             /* other edge adjacent face */
} ADJFAC_TYP;

typedef enum {
   BLACKER_SMOOTH_WITH_AVG_SIZE,
   BLACKER_SMOOTH,
   LAPLACIAN_SMOOTH,
   PROJECT_SMOOTH,
   OPTI_SMOOTH
}SMOOTH_ENUM;

typedef enum {
	kNON_ANALYTIC=0,
	kANALYTIC,
	kHIGH_CURVATURE_IN_U,
	kHIGH_CURVATURE_IN_V,
	kUNKNOWN_CURVATURE
} eSURFACE_TYPE;

typedef enum {
   kUNKNOWN_TEMPLATE = 0,
   kT111111,
   kT21111,
   kT2121,
   kT3111,
   kT2211,
   kT222,
   kT321,
   kT312,
   kT411,
   kT33,
   kT42,
   kT51
} QUAD_TEMPLATE;

typedef struct SEAMNODE_TYP *SEAMNODE_PTYP;
typedef struct SEAMNODE_TYP {
   NODE_OBJ obj_node;
   EDGEFRONT_PTYP ps_edgefront;
   INT side;
} SEAMNODE_TYP;

typedef struct LOOP_TYP *LOOP_PTYP;
typedef struct LOOP_TYP {
   INT loopnum;
   INT numlayers;
} LOOP_TYP;

typedef struct BNDEDGE_TYP *BNDEDGE_PTYP;
typedef struct BNDEDGE_TYP
{
   EDGE_OBJ      obj_edge;
   DOUBLE         length;
   BNDEDGE_PTYP   ps_next;
} BNDEDGE_TYP;


class CUpdateFrontHolder
{
public:
    CUpdateFrontHolder();
    ~CUpdateFrontHolder() { clearList(); };
    bool insertFront( EDGEFRONT_PTYP ps_front );
    void clearList();
    void setLoc( INT i );
    EDGEFRONT_PTYP getFrontAtCurrentLoc();
    INT    getOldStateAtCurrentLoc();
    void setFrontAtCurrentLoc(EDGEFRONT_PTYP ps_front);
    void setOldStateAtCurrentLoc(INT iOldState);
    void clearLoc( INT i );

    INT getNumUpdateFronts();
	EDGEFRONT_PTYP operator[]( int index );
    inline bool isFrontOnUpdateList( EDGEFRONT_PTYP ps_front ) { return (ps_front->bUpdate==TRUE);};

    void ifThisFrontIsOnTheListRemoveIt( EDGEFRONT_PTYP ps_front );

private:
    vector<EDGEFRONT_PTYP> m_cFrontListToUpdate;
    vector<INT>  m_cOldState;
    INT m_iCurrentLoc;

    INT validateCurrentLoc();
};
 
/*------------------ Prototypes for static functions -----------------*/

static INT      fem_pvSeamAtNode       ( SEAMNODE_PTYP ps_seamnode,
                                  INT level );
static INT      fem_pvInsertSeamWedge  ( NODE_OBJ obj_N0,
                                  EDGE_OBJ obj_E1,
                                  EDGE_OBJ obj_E4,
                                  DOUBLE lenratio,
                                  INT level );
static INT      fem_pvQuadState00      ( EDGEFRONT_PTYP ps_edgefront,
                                  INT level );
static INT      fem_pvQuadState10      ( EDGEFRONT_PTYP ps_edgefront,
                                  EDGEFRONT_PTYP ps_edgefront2,
                                  INT level,
                                  INT iTry );
static INT      fem_pvQuadState01      ( EDGEFRONT_PTYP ps_edgefront,
                                  EDGEFRONT_PTYP ps_edgefront1,
                                  INT level,
                                  INT iTry );
static INT      fem_pvQuadState11      ( EDGEFRONT_PTYP ps_edgefront,
                                  EDGEFRONT_PTYP ps_edgefront1,
                                  EDGEFRONT_PTYP ps_edgefront2,
                                  EDGEFRONT_PTYP ps_edgefront3,
                                  INT level,
                                  INT iTry,
								  INT iDoSmoothing );

static INT	 fem_pvCheckAdjTri( EDGEFRONT_PTYP aps_edgefronts[4], EDGE_OBJ obj_edge  );

static INT		fem_pvCheckSize( EDGEFRONT_PTYP aps_edgefronts[4], INT level, bool *pbTooBig );

static EDGE_OBJ	fem_pvCheckAdjFaces( EDGEFRONT_PTYP ps_edgefront, NODE_OBJ obj_node, EDGE_OBJ obj_edge );

static DOUBLE	fem_pvGetSize( EDGEFRONT_PTYP ps_edgefront = NULL, NODE_OBJ obj_node = NULL, DOUBLE *xyz = NULL);

static DOUBLE   fem_pvGetSizeInSphere( DOUBLE *xyz );

static INT      fem_pvFormTri          ( EDGEFRONT_PTYP ps_edgefront,
                                  EDGEFRONT_PTYP ps_edgefront1,
                                  EDGEFRONT_PTYP ps_edgefront2,
                                  INT level );
static INT      fem_pvFormConstrainedTri( NODE_OBJ obj_N1,
                                   NODE_OBJ obj_N2,
                                   EDGEFRONT_PTYP ps_edgefront,
                                   INT side,
                                   INT level );
static INT      fem_pvTryAgain         ( EDGEFRONT_PTYP ps_edgefront,
                                  EDGEFRONT_PTYP ps_edgefront1,
                                  EDGEFRONT_PTYP ps_edgefront2,
                                  INT level );
static INT      fem_pvUpdateFront      ( FACE_OBJ obj_face,
                                  INT level,
                                  CUpdateFrontHolder &a_update_front );
static INT      fem_pvCheckBdryQuad    ( NODE_OBJ obj_n0,
                                  NODE_OBJ obj_n1,
                                  NODE_OBJ obj_n3,
                                  NODE_OBJ obj_n4,
                                  INT on_bdry[4],
                                  INT num_on_bdry );
#if 0
static INT      fem_pvCheckTuck        ( CUpdateFrontHolder &a_update_front );
#endif

static EDGE_OBJ	fem_pvCalFaceAngles( EDGEFRONT_PTYP ps_edgefront, 
									 EDGEFRONT_PTYP ps_otherfront, 
									 INT side, 
									 ADJFAC_TYP a_adjface[], 
									 INT *piNumFaces,
									 INT *piFace,
									 DOUBLE	*pTotalAngle,
									 DOUBLE	*pTargetAngle,
									 DOUBLE *pDiffAngle,
									 INT	*numquad,
									 EDGE_OBJ *pobj_edge1);

static EDGE_OBJ fem_pvGetSide    ( EDGEFRONT_PTYP ps_edgefront,
                                  EDGEFRONT_PTYP ps_otherfront,
                                  INT side, 
                                  INT *loop,
                                  INT *numquad );
static void	fem_pvModifyNodeLoc	( EDGEFRONT_PTYP ps_edgefront, 
								  EDGEFRONT_PTYP ps_otherfront, 
								  EDGE_OBJ	obj_edge,
								  NODE_OBJ  obj_node );

static void     fem_pvNudge            ( EDGEFRONT_PTYP ps_edgefront,
                                  INT side,
                                  NODE_OBJ obj_node,
                                  NODE_OBJ obj_oppnode );
static INT      fem_pvNormalAtNode     ( NODE_OBJ obj_node,
                                  VECTOR3D *ps_norm );
static EDGE_OBJ fem_pvCloseLoop        ( EDGE_OBJ obj_edge,
                                  NODE_OBJ obj_node,
                                  NODE_OBJ obj_oppnode,
                                  INT opploop,
                                  DOUBLE diff_angle,
                                  ADJFAC_PTYP ps_adjface,
                                  EDGEFRONT_PTYP ps_edgefront,
                                  EDGEFRONT_PTYP ps_otherfront,
                                  INT side,
                                  INT *newloop );
static INT      fem_pvRenumberLoop     ( NODE_OBJ obj_node,
                                  INT newloop );
static INT      fem_pvRenumberSubLoop  ( EDGEFRONT_PTYP ps_edgefront,
                                  NODE_OBJ obj_node,
                                  INT side,
                                  INT *newloop );
static INT      fem_pvNodeIsOnFront    ( NODE_OBJ obj_node,
                                  INT *loop,
								  EDGEFRONT_PTYP ps_edgefront =NULL);
static INT		fem_pvCanBreakLoop ( );

static INT      fem_pvNodeOnNewQuad    ( NODE_OBJ obj_node,
                                  EDGEFRONT_PTYP ps_otherfront );
static EDGE_OBJ fem_pvSplitOppositeEdge
                                ( NODE_OBJ obj_node0,
                                  ADJFAC_PTYP ps_adjface,
                                  EDGE_OBJ obj_edge,
                                  DOUBLE diff_angle );
static INT      fem_pvGenerateFront    ( INT anum, 
                                  NODELIST_OBJ obj_nlist,
                                  EDGELIST_OBJ obj_edlist,
                                  FACELIST_OBJ obj_flist,
                                  INT          *pDone );
static INT      fem_pvIsEvenIntervalLoop
                                ( EDGEFRONT_PTYP ps_edgefront,
                                  NODE_OBJ obj_node,
                                  INT side, INT *p_even );

static INT		fem_pvIsEvenIntervalLoop(  EDGEFRONT_PTYP ps_edgefront,
										EDGEFRONT_PTYP ps_otherfront,
										NODE_OBJ obj_node,
										NODE_OBJ obj_node0,
										INT side, 
										INT *p_even );

static bool     fem_pvBreakLoopIntoEven( EDGEFRONT_PTYP ps_edgefront,
										EDGEFRONT_PTYP ps_otherfront,
										NODE_OBJ obj_node,
										NODE_OBJ obj_node0 );

static INT      fem_pvNumFrontsOnLoop  ( EDGEFRONT_PTYP ps_edgefront,
                                  NODE_OBJ obj_node,
                                  INT side );
static INT      fem_pv3or4Fronts       ( EDGEFRONT_PTYP ps_edgefront );
static INT      fem_pvNewSubLoop       ( EDGEFRONT_PTYP ps_edgefront,
                                  NODE_OBJ obj_node,
                                  INT side );
static DOUBLE   fem_pvAngleAtNode      ( NODE_OBJ obj_node,
                                  EDGEFRONT_PTYP ps_edgefront,
                                  INT side );
static INT      fem_pvDeleteTrisInQuad ( EDGEFRONT_PTYP aps_edgefront[4] );
static INT      fem_pvAddToTriDeque    ( FACE_OBJ obj_face,
                                  EDGEFRONT_PTYP aps_edgefront[4] );
static INT      fem_pvDeleteTri        ( FACE_OBJ obj_face );
static INT      fem_pvSmoothNodesOnFace
                                ( FACE_OBJ obj_face,
                                  CUpdateFrontHolder &a_update_front );
static INT      fem_pvSmoothNodesOnFront ( EDGEFRONT_PTYP ps_firstfront,
                                  INT level );
static void     fem_pvSetConstraint    ( EDGE_OBJ obj_edge );
static INT      fem_pvSmoothNodesNearFront
                                ( EDGEFRONT_PTYP ps_edgefront );

static INT      fem_pvLocalSmooth      ( NODE_OBJ obj_node,
                                  INT interior,
                                  CUpdateFrontHolder &a_update_front );
static INT      fem_pvSmoothNode       ( NODE_OBJ obj_node,
                                  CUpdateFrontHolder &a_update_front);
static INT      fem_pvProjectNode      ( NODE_OBJ obj_node,
                                  VECTOR3D *ps_last );
static INT      fem_pvSmoothNode2      ( NODE_OBJ obj_node,
                                  CUpdateFrontHolder &a_update_front );
static INT      fem_pvSmooothAtFace    ( NODE_OBJ obj_node,
                                  FACE_OBJ obj_face,
                                  VECTOR3D *ps_loc,
                                  CUpdateFrontHolder &a_update_front );
static INT      fem_pvSmoothQuad       ( NODE_OBJ obj_node,
                                  FACE_OBJ obj_face,
                                  VECTOR3D *ps_loc );
static INT      fem_pvSmoothTri        ( NODE_OBJ obj_node,
                                  FACE_OBJ obj_face,
                                  VECTOR3D *ps_loc );
static INT      fem_pvSmoothBadNodes   ( INT level );
static INT      fem_pvOptiSmooth       ( NODE_OBJ obj_node,
                                  CUpdateFrontHolder &a_update_front,
                                  INT *p_moved );
static INT      fem_pvBlackerSmooth    ( NODE_OBJ obj_node,
                                  CUpdateFrontHolder &a_update_front,
                                  INT interior, 
                                  INT *p_moved );
static INT      fem_pvInteriorSmooth   ( NODE_OBJ obj_node );
static INT      fem_pvSmoothAngle      ( NODE_OBJ obj_Ni,
                                  FACE_OBJ *aobj_faces,
                                  VECTOR3D *ps_dC,
                                  DOUBLE lenD );
static INT      fem_pvProjVectToPlane  ( VECTOR3D *ps_vector,
                                  VECTOR3D *ps_normal,
                                  VECTOR3D *ps_proj );
static INT      fem_pvSmoothSquare     ( NODE_OBJ obj_node_i,
                                  FACE_OBJ *aobj_faces,
                                  VECTOR3D *ps_dA,
                                  VECTOR3D *ps_dB,
                                  DOUBLE lenD );
static INT      fem_pvIsoParametricSmooth
                                ( NODE_OBJ obj_node0,
                                  FACE_OBJ *aobj_faces,
                                  INT num_quads,
                                  VECTOR3D *ps_delta,
                                  DOUBLE *p_lenD );
static INT      fem_pvFrontSmooth      ( NODE_OBJ obj_node );
static INT      fem_pvSmoothCornerNode ( NODE_OBJ obj_node0,
                                  FACE_OBJ obj_face );
static DOUBLE   fem_pvSize             ( EDGEFRONT_PTYP ps_edgefront );
static INT      fem_pvSmoothAdjust     ( NODE_OBJ obj_node,
                                  VECTOR3D *ps_last,
                                  VECTOR3D *ps_new,
                                  INT *p_adjusted );
static EDGEFRONT_PTYP
         fem_pvAdjacentFront    ( EDGEFRONT_PTYP ps_edgefront,
                                  INT side );
static EDGEFRONT_PTYP
         fem_pvAdjacentFront0   ( EDGEFRONT_PTYP ps_edgefront,
                                  INT side,
                        FEM_BOOLEAN selCurFront );
static EDGE_OBJ fem_pvClosestEdge      ( EDGEFRONT_PTYP ps_edgefront0,
                                  EDGEFRONT_PTYP ps_edgefront1,
                                  NODE_OBJ obj_node );
static EDGEFRONT_PTYP fem_pvNewFront   ( EDGE_OBJ obj_edge,
                                           NODE_OBJ obj_node0 );
static INT      fem_pvDiscardFront     ( EDGEFRONT_PTYP ps_edgefront );
static INT      fem_pvRemoveFrontFromList
                                ( EDGEFRONT_PTYP ps_edgefront );
static INT      fem_pvFindLongestFront ();

static INT      fem_pvAddFrontToList   ( EDGEFRONT_PTYP ps_edgefront );
static INT      fem_pvAddToBottomState ( EDGEFRONT_PTYP ps_edgefront,
                                           INT new_state );
static INT      fem_pvAddToTopState    ( EDGEFRONT_PTYP ps_edgefront,
                                           INT new_state );
static INT      fem_pvInsertState      ( EDGEFRONT_PTYP ps_insertfront,
                                  INT level );
static EDGEFRONT_PTYP 
         fem_pvGetNextEdgeFront ( INT level,
                                  INT *done );

static EDGEFRONT_PTYP fem_pvRetriveAdjFront( EDGEFRONT_PTYP ps_edgefront, 
                           INT nextOrPrev,
                           FEM_BOOLEAN selCurFront );

static INT      fem_pvSetShortFront    ( );
static INT      fem_pvSetLongFront     ( );
static INT      fem_pvRemoveFrontState ( EDGEFRONT_PTYP ps_edgefront );
static NODE_OBJ fem_pvFrontNode        ( EDGEFRONT_PTYP ps_edgefront,
                                  INT side );
static INT      fem_pvOrientFront      ( EDGEFRONT_PTYP ps_edgefront );
static INT      fem_pvCheckStates      ( );
static INT      fem_pvCheckState       ( EDGEFRONT_PTYP ps_list,
                                  EDGEFRONT_PTYP ps_last,
                                  INT forward,
                                  INT state );
static INT      fem_pvCheckLoops       ( void );
static INT      fem_pvDrawLoop         ( INT loop );
static EDGE_OBJ        fem_pvSplitQuadTriEdge ( EDGE_OBJ obj_edge2,
                                         NODE_OBJ obj_node1,
                                         NODE_OBJ *p_obj_node2,
                                         NODE_OBJ *p_obj_node3,
                                         NODE_OBJ *p_obj_node4 );
static EDGE_OBJ        fem_pvSplitQuadTriEdge2( EDGE_OBJ obj_edge2,
                                         NODE_OBJ obj_node1,
                                         NODE_OBJ *p_obj_node6,
                                         NODE_OBJ *p_obj_node3,
                                  NODE_OBJ *p_obj_node4 );
static INT      fem_pvCheckTransition  ( INT level,
                                  EDGEFRONT_PTYP ps_edgefront0,
                                  EDGEFRONT_PTYP ps_edgefront1,
                                  INT *p_wedge_inserted );
static INT      fem_pvBdryTransition( INT curlevel,
                                    EDGEFRONT_PTYP ps_edgefront,
                                    EDGEFRONT_PTYP ps_edgefront1,
                                    EDGEFRONT_PTYP ps_edgefront2 );
static INT      fem_pvCheckSmallFronts ( INT *p_level,
                                  INT *p_numtimes );
static INT      fem_pvCleanTris        ( FACELIST_OBJ obj_flist,
                                  EDGELIST_OBJ obj_edlist,
                                  NODELIST_OBJ obj_nlist,
                                  INT iSmoothIter,
                                  INT level);
static INT      fem_pvSmoothTris       ( FACELIST_OBJ obj_flist,
                                  EDGELIST_OBJ obj_edlist,
                                  NODELIST_OBJ obj_nlist,
                                  INT level);

static INT       fem_pvSmoothMesh ( FACELIST_OBJ obj_flist,      /* the face list */
                                    NODELIST_OBJ obj_nlist,     /* the node  */
                                    INT iNumIterations,         /* (IN)  number of iterations to smooth        */
                                    INT level );
static INT      fem_pvPutFront         ( EDGEFRONT_PTYP ps_edgefront,
                                  INT level );

static INT		fem_pvGetNormalAtNode( NODE_OBJ obj_node, VECTOR3D *psNorm, bool bNormalize=false  );
static INT		fem_pvGetNormal( DOUBLE dU, DOUBLE dV, VECTOR3D *psNorm, bool bNormalize=false );

static INT		fem_pvSplitEdge( EDGE_OBJ obj_edge, DOUBLE xyz[3], NODE_OBJ *pobj_newNode );
static INT		fem_pvLocate( EDGEFRONT_PTYP ps_edgefront,
							  NODE_OBJ obj_node,
						      ADJFAC_PTYP ps_adjface,
							  DOUBLE dDist2,
							  DOUBLE xyz[3],
							  DOUBLE xyzout[3],
							  ADDRESS_TYP *pobj_entity, 
							  INT	*iMeshEntity,
							  FACE_OBJ *pobj_face );

static INT		fem_pvGetEdge( EDGEFRONT_PTYP ps_edgefront,
							   EDGEFRONT_PTYP ps_otherfront,
							   NODE_OBJ obj_node,
							   ADJFAC_PTYP ps_adjface,
							   DOUBLE	dIdealAngle,
							   DOUBLE	dDiffAngle,
							   INT		side, 
                               INT		*loop,
							   EDGE_OBJ *pobj_edge );

static INT		fem_pvModifyLocation( EDGEFRONT_PTYP ps_edgefront,
									  EDGEFRONT_PTYP ps_otherfront,
									  NODE_OBJ obj_node,
									  DOUBLE dUin,
									  DOUBLE dVin,
									  DOUBLE xyzin[3] );
static INT   fem_pvModifyLocation( NODE_OBJ obj_newNode, EDGE_OBJ obj_newEdge, NODE_OBJ *pobj_node );

static INT		fem_pvMoveClosestNode( NODE_OBJ obj_node, NODE_OBJ	*pobj_newNode );

static INT	fem_pvCheckNearQuad( EDGEFRONT_PTYP ps_edgefront, 
								 EDGEFRONT_PTYP ps_otherfront,
								 NODE_OBJ obj_node, 
								 DOUBLE	xyz[3],
								 ADDRESS_TYP obj_entity, 
								 INT iMeshEntity, 
								 ADDRESS_TYP *pobj_entity, 
								 INT	*piMeshEntity );

static INT		fem_pvGenerateEdge(  EDGEFRONT_PTYP ps_edgefront,
									EDGEFRONT_PTYP ps_otherfront,
								    NODE_OBJ obj_node,
								    FACE_OBJ obj_face,
									ADDRESS_TYP obj_entity, 
									INT	iMeshEntity, 
									DOUBLE xyz[3],
									DOUBLE	dIdealAngle,
									EDGE_OBJ *pobj_edge );

static INT		fem_pvGetNearNodeFromQuad( EDGEFRONT_PTYP ps_edgefront,
										   EDGEFRONT_PTYP ps_otherfront,
										   INT	side,
										   NODE_OBJ obj_node, 
										   FACE_OBJ obj_face, 
									       DOUBLE xyz[3],
										   DOUBLE	dIdealAngle,
										   NODE_OBJ	*pobj_node );
				

static INT      fem_pvSwap             ( NODE_OBJ obj_node0,
                                  ADJFAC_PTYP ps_adjface,
                                  EDGE_OBJ obj_edge,
                                  DOUBLE diff_angle,
                                  EDGEFRONT_PTYP ps_otherfront,
                                  EDGE_OBJ *pobj_edge,
                                  DOUBLE *p_new_diff_angle,
                                  DOUBLE flength,
                                  INT *collapsed );
static INT      fem_pvSwapEdge         ( EDGE_OBJ obj_edge,
                                  EDGE_OBJ *pobj_edge );
static INT      fem_pvOnLists          ( EDGEFRONT_PTYP ps_edgefront,
                                  INT printerr );

static EDGEFRONT_PTYP  fem_pvNewFrontMemory        ( void );

static void     fem_pvDeleteFrontMemory( EDGEFRONT_PTYP ps_edgefront );

static INT      fem_pvDeleteAllFrontMemory ( void );

static INT      fem_pvInsertHardPoint  ( NODE_OBJ obj_node, INT *totalfront );

static INT      fem_pvNumPavedFacesOnFront( EDGEFRONT_PTYP ps_edgefront );

static INT      fem_pvCheckConvexFor3BndNodes ( NODE_OBJ   obj_node0,
                             NODE_OBJ   obj_node1,
                             NODE_OBJ   obj_node2,
                             NODE_OBJ   obj_node3 );

static INT      fem_pvCheckConvexFor4BndNodes ( NODE_OBJ   obj_node0,
                             NODE_OBJ   obj_node1,      
                             NODE_OBJ   obj_node2,      
                             NODE_OBJ   obj_node3,
                             FEM_BOOLEAN *pbForceCreation);
static INT      fem_pvCheckNewQuad( EDGEFRONT_PTYP   aps_edgefront[3],      
                     EDGE_OBJ      obj_newEdge );
static INT      fem_pvCheckPotentialQuad (  EDGEFRONT_PTYP   aps_edgefront[3] );

static void      fem_pvCreateMinMaxBox( );

static INT      fem_pvInsideMinMaxBox( NODE_OBJ   obj_node );


static FACE_OBJ fem_pvNextEdgeFace( EDGE_OBJ obj_edge, FACE_OBJ obj_face,set<int> & sFaceIds ) ;

static INT fem_pvRetriveAllFront(INT anum, INT *totalfront ) ;

static INT fem_pvRetriveFrontLoops(INT anum, INT *totalfront ) ;

static EDGEFRONT_PTYP fem_pvRetriveNextFront(EDGEFRONT_PTYP ps_edgefront );

static INT fem_pvCheckFrontInFace( EDGEFRONT_PTYP fnt, 
                            EDGE_OBJ edge, 
                            FACE_OBJ face, 
                            EDGEFRONT_PTYP fntEdgLst, 
                            EDGEFRONT_PTYP *front);

static INT fem_pvSearchFront( EDGE_OBJ obj_edge, 
                       FACE_OBJ obj_face, 
                       EDGEFRONT_PTYP *front);

static EDGEFRONT_PTYP fem_pvRetriveNextFront(EDGEFRONT_PTYP ps_edgefront );

static EDGEFRONT_PTYP fem_pvRetrivePrevFront(EDGEFRONT_PTYP ps_edgefront );

static INT fem_pvGetRealFrontEdge( EDGE_OBJ edge, FACE_OBJ face, EDGEFRONT_PTYP *front);

static INT fem_pvEdgeSearchForNextFront( EDGEFRONT_PTYP inputFnt, EDGEFRONT_PTYP *front);

static INT fem_pvSearchFrontNbr(EDGE_OBJ edge, EDGEFRONT_PTYP refF, EDGEFRONT_PTYP *f);

static EDGEFRONT_PTYP fem_pvGetFrontFromEdge_func( EDGE_OBJ obj_edge );

static INT fem_pvVerifyFront( EDGEFRONT_PTYP frnt, 
                       EDGE_OBJ edge, 
                       FACE_OBJ face, 
                       INT *frontIsTrue) ;

static INT fem_pvSetEdgeGenericPointer_func(EDGE_OBJ edge, 
                                     EDGEFRONT_PTYP val, 
                                     EDGEFRONT_PTYP front);

static INT fem_pvAngFromFrontToFront(EDGEFRONT_PTYP ps_edgefront,
                              EDGEFRONT_PTYP ps_edgefront1, 
                              DOUBLE *ang );

static INT fem_pvPaving( INT anum, 
                  NODELIST_OBJ nlist,
                  EDGELIST_OBJ edlist,
                  FACELIST_OBJ flist); 


static INT fem_pvBuildFrontFromFace( INT anum, INT *pDone ) ;

static INT fem_pvTestEdgeFront( INT area);

static EDGEFRONT_PTYP fem_pvModifyNextEdgeFront ( EDGEFRONT_PTYP ps_edgefront );

static INT fem_pvDoEdgeSplit( EDGE_OBJ obj_edge, EDGEFRONT_PTYP ps_edgefront ); 

static INT fem_pvInitBndEdges( INT size );

static INT fem_pvDetermineSize( );

static DOUBLE fem_pvDetermineAvgFrontSize();

static void fem_pvClearBndEdges();

static INT fem_pvInsertBndEdge ( EDGE_OBJ   obj_edge,
                  DOUBLE      length );

static INT fem_pvRemoveBndEdge ( EDGE_OBJ   obj_edge );

static EDGEFRONT_PTYP fem_pvFindShortBndEdge ( EDGEFRONT_PTYP   ps_oldfront );

static BNDEDGE_PTYP  fem_pvNewBndEdgeMemory        ( void );

static void   fem_pvDeleteBndEdgeMemory( BNDEDGE_PTYP ps_bndedge );

static INT  fem_pvDeleteAllBndEdgeMemory ( void );

static void fem_pvSetBuildFrontFlag( INT state ) ;

static INT fem_pvGetBuildFrontFlag() ;

static EDGEFRONT_PTYP fem_pvGetCurrentFront() ;

static void fem_pvSetCurrentFront(EDGEFRONT_PTYP fnt) ;

static DOUBLE FEM_pvAngleBetween3Nodes( NODE_OBJ obj_node1, NODE_OBJ obj_node2, NODE_OBJ obj_node3 );

static FEM_BOOLEAN fem_pvIsNodeAdjToCurvedBnd( NODE_OBJ obj_node, NODE_OBJ *pobj_oppnode, EDGE_OBJ *aobj_bndedges);

static INT fem_pvBndSmooth( NODE_OBJ obj_node, NODE_OBJ obj_oppnode, EDGE_OBJ aobj_bndedges[2], FACE_OBJ *aobj_faces, VECTOR3D *ps_new );
static INT fem_cleanupInterior( 
   int anum,  
   EDGEFRONT_PTYP ps_edgeFront,
   NODELIST_OBJ obj_nlist,           /* node list                             */
   EDGELIST_OBJ obj_edlist,          /* edge list                             */
   FACELIST_OBJ obj_flist  );

static INT fem_pvClosure3456( 
   INT anum, 
   EDGEFRONT_PTYP ps_edgefront,
   INT level,
   INT *piDid) ;
static INT fem_pvSmoothOneNode(
   NODE_OBJ obj_node,              /* smooth in region of this node */
   INT area_id,
   INT treat_as_interior,          /* 1 if treat all nodes as interior */
   CUpdateFrontHolder &a_update_front, /* array of edge fronts whose nodes have been moved */
   int *pMoved) ;
static INT fem_pvSmoothIsInverted(
   NODE_OBJ obj_node,          /* current smooth node */
   INT area_id,
   INT *pInverted );

static INT fem_pvCurvatureRefinement ( INT anum );
static INT fem_pvGetFrontLoopInfo(
   INT anum, 
   EDGEFRONT_PTYP ps_edgefront,
   INT *piNumFrontsInLoop,
   EDGEFRONT_PTYP *aps_edgefront);

static INT fem_pvInsertSpheres(INT *piTotalFront);

static INT FEM_pvCollapse( EDGE_OBJ *pobj_edge, NODE_OBJ *pobj_keepNode,  DEQUE_OBJ *aobj_deques,INT iUserInfo, INT *did);

static void fem_pvIncrementFlag();

static EDGE_OBJ fem_pvSplitAtEdgeWrap(
   EDGE_OBJ obj_edge2,         /* edge object (see diagram) */
   NODE_OBJ obj_node1,         /* node object (see diagram) */
   DOUBLE ratio,               /* ratio at which to split edge */
   NODE_OBJ obj_node4,         /* optional - node to be used for splitting
                                  edge.  Node not created if !NULL */
   INT check );                 /* flag - before splitting the edge, test
                                  the quality of the resulting tris.  If they
                                  are bad (< SMALL_METRIC) then downt split */

static INT fem_pvCombine3Tris( NODE_OBJ obj_node0, NODE_OBJ obj_node1, NODE_OBJ obj_node2, bool *pDid);

static INT fem_pvCheckAreaType( INT iAreaId );

static bool fem_pvCanMoveNode( NODE_OBJ obj_node, DOUBLE xyz[3] );

static INT fem_pvRecover2D( NODE_OBJ obj_node0, NODE_OBJ obj_node1, EDGE_OBJ *pobj_edge );

static void fem_pvInsertFrontAtBottomBeforeStopGrowth( EDGEFRONT_PTYP ps_edgefront, EDGEFRONT_PTYP &ps_listhead, EDGEFRONT_PTYP &ps_listbottom );

static FEM_BOOLEAN fem_pvIsAdjFrontAngleOKToIncreaseState( DOUBLE angle, EDGEFRONT_PTYP ps_edgefront, EDGEFRONT_PTYP ps_adjfront );

static NODE_OBJ fem_pvGetCloserNode( EDGE_OBJ obj_edge, INT iIndex );

static INT fem_pvIsColinear3NodesCreated( NODE_OBJ obj_node0, NODE_OBJ obj_node1 );

static INT	fem_pvIs3BndNodes( NODE_OBJ  obj_node0, NODE_OBJ obj_node1 );

static INT fem_pvProcessPairTris( );

static INT fem_pvProjectPtOnFace( FACE_OBJ obj_face, DOUBLE *a_xyzin, 
								  DOUBLE *a_xyzout, ADDRESS_TYP *pobj_entity,  
								  INT	*piMeshEntity  ) ;

static INT fem_pvDoSwap( 
   EDGELIST_OBJ obj_edlist,   /* the edge list object */
   FACELIST_OBJ obj_flist,    /* the face list object */
   EDGE_OBJ *pobj_edge,         /* edge between two faces */
   FACE_OBJ *pobj_face1,       /* face adjacent to edge */
   FACE_OBJ *pobj_face2 );      /* other face adjacent to edge */

static INT fem_pvProccesClosedArea( INT *iTotalFront );
#endif

