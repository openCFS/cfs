/**
 * @file   CDesignSetsCache.h
 * @author User Stephane Marguerin
 * @date   Wed Oct 27 17:58:11
 *
 * @brief  
 *               
 * 
 */

#ifndef __CDESIGNSETSCACHE_H__ 
#define __CDESIGNSETSCACHE_H__ 1 

#include "cadoe.h"
#include "cadoe_map.h"
#include "cadoe_list.h"
#include "cadoe_string.h"
#include "C_CbfObject.h"
#include "CDesignSet.h"
#include "CParameterMgr.h"

/*! \class CDesignSetsCache
 *  \brief Cache memory for CDesignSet objects
 *
 * Description : CDesignSetsCache allows to cache CDesignSet objects.
 * The key is the array of the CDesignSet input values. The memory assigned to the cache
 * and the fixed size of the member arrays are defined at the construction time so
 * that all the needed memory can be allocated immediately in a single operation.
 *
 * To reset completely the cache content, use the method Reset().
 *
 * To DEBUG:   
 * - each ADD and GET operations are verbose in E_DBG_1 with scope E_SCOPE_DESIGNSETSCACHE.
 * - defining the environment variable CADOE_NO_DESIGNSETSCACHE resets and deactivates completely
 *   the cache mecanism.
 */
class CDesignSetsCache : public C_CbfObject
{
public:
  virtual const char *Type() const { return (char *)"CDesignSetsCache";}
  virtual const char *Version() const { return (char *)"1.0";}
  virtual int	TypeCBF() const { return 3001;}
	
public:
  CDesignSetsCache( const WString &basename, CParameterMgr* pmgr, int maxItems=0 );
  virtual ~CDesignSetsCache();

  // add a new member. If the member already exists, it is just updated with the new dataValues
  int PutItem( const CDesignSet &dset );
  // try to cachedSet from dset definition. Returns false if it does exist.
  bool GetItem( const CDesignSet &dset, CDesignSet &cachedSet, int critId=-1 );
  bool IsCached( CDesignSet &dset, int critId=-1 );
	
  // completely erase the cache content
  void Reset( void );
	
  int GetMaxItems(void) const {return _maxItems;}
  int GetNumItems(void) const {return (int)_cache.size();}

  // Debug and info methods
  void PrintStats();
  void GetStats( unsigned int &numAdded, unsigned int &numUpdated, unsigned int &numRetrieved ) const;
  void ResetStats(void) { _numAdded=_numUpdated=_numRetrieved=_numGetCalls=0; }
  void DebugTrace( const char *comment, const CDesignSet&, FILE *f=stdout ) const;
	
public:
	T_statut	Write( FILE *fb ) { return ECHEC; }
	T_statut	Read( FILE *fb ) { return ECHEC; }
	void		Print( FILE *fic = stdout );
	
private:	
  bool Get( const string &key, int critId, CDesignSet &cachedSet );
  void GenerateKey( const CDesignSet &, string &key );
  void DecodeKey( const string &key );
  void SetupInternalFlags(void);

protected:
  bool							_doNotCache; // flag to inactivate the cache mecanism
  bool							_debug; // debug flag, activated by the E_DBG_1 verbosity level of the C_MessageTool. Also need DEBUG_SCOPE_CACHEARRAY.

  int							_maxItems; // max number of elements in the cache
	
  list<map<string,CDesignSet>::iterator> _items; // chronological list of the members, used to determine the older members
  map<string,CDesignSet>		_cache; // associative array key/data

  unsigned int					_numAdded;
  unsigned int					_numUpdated;
  unsigned int					_numGetCalls;
  unsigned int					_numRetrieved;

  WString						_BaseName; // name of the associated database
  int							_buildDate; // build date that generated this cache

  CParameterMgr::ParamVector	_vPar; // vector of the input parameters

  double						*_keyValues;
};

#endif
