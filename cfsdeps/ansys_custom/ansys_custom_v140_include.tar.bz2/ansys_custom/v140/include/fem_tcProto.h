/*CFILE fem_tcProto.h      meshing   [ANSI_C]                    zjc
------------------------------------------------------------------------
------- Notice - This file contains ANSYS Confidential information 
------------------------------------------------------------------------
*/

/*------------------------------ Description ---------------------------
\Author:        zjc
\Title:         fem_tcProto
\Desc:          Topological clean up of an existing surface quad mesh
                prototypes for TC
\History:       00/10/27 - zjc: initial creation

----------------------------------------------------------------------*/
#include <stdlib.h>
#include <stdio.h>
#include "FEM_cdbtypes.h"
#include "FEM_Public.h"
#include "FEM_globals.h"
#include "FEM_external.h"
#include "FEM_smooth.h"
#include "fem_cleanPriv.h"
#include "FEM_cleanTopo.h"
#include "FEM_coIds.h"
#include "FEM_deque.h"
#include "FEM_util.h"
#include "FEM_point.h"
#include "Mstat.h"

#ifndef FEM_TCPROTO_H_CLEANUP
#define FEM_TCPROTO_H_CLEANUP

#ifdef __cplusplus
extern "C" {
#endif

#define FEM_TC_BEGIN      123123
#define FEM_TC_NO_OP      FEM_TC_BEGIN + 1
#define FEM_TC_NOT_GOOD   FEM_TC_BEGIN + 2
#define FEM_TC_CAN_NOT_AVOID_2_EDGED_NODE_IN_CLOSE     FEM_TC_BEGIN + 3

#define LOWEST_PRIORITY  1
#define LOW_PRIORITY     2
#define MEDIUM_PRIORITY  3
#define HIGHEST_PRIORITY 4
#define MIN_BETA 0.05 
#define FEM_TC_BIG_SPAN_ANGLE 0.33333333333333*PI  /*0.5*PI*/

/* NOTE: ANS_TOL::gMaxSheetQuadAngle; is 170 degree */
#define fem_tc_small_bnd_angle 11*PI/180.0
#define fem_tc_small_int_angle 11*PI/180.0

void fem_tcSetBndElemRadLay( INT n );
INT fem_tcGetBndElemRadLay();
INT fem_tcNumToBestValence( NODE_OBJ node, INT surfId );
DOUBLE fem_tcNodeVV( NODE_OBJ node, INT surfId, INT adjust );
INT fem_tcCouldNodeDelEdge( NODE_OBJ node, INT surfId );
INT fem_tcCouldNodeAddEdge( NODE_OBJ node, INT surfId );
INT fem_tcFaceReplaceNode( FACE_OBJ *face, NODE_OBJ newNode, NODE_OBJ oldNode, 
                           DEQUE_OBJ *faceDeque) ;
INT fem_tcEdgeReplaceNode( EDGE_OBJ *edge, NODE_OBJ newNode, NODE_OBJ oldNode, 
                           INT area, DEQUE_OBJ *edgeDeque);
INT fem_tcIsOKSwapVV( NODE_OBJ *nodes, INT area, 
                      NODE_OBJ *newDiagNodes, NODE_OBJ *oldDiagNodes ) ;
INT fem_tcIsOKSwap_vv( NODE_OBJ *nodes, INT area, 
                       NODE_OBJ *newDiagNodes, NODE_OBJ *oldDiagNodes );
INT fem_tcClose(FACE_OBJ *pobj_face, NODE_OBJ *nKeep,NODE_OBJ nDel,DEQUE_OBJ *tcDeques, INT iForced );
/*INT fem_tcKill2EdgedNode(NODE_OBJ obj_node,DEQUE_OBJ faceDeque, DEQUE_OBJ edgeDeque,
                         DEQUE_OBJ nodeDeque, INT *changed);*/
INT fem_tc3e3( NODE_OBJ *nodes, FACE_OBJ *faces, DEQUE_OBJ *tcDeques) ;
INT fem_tcDel2EdgedNode(NODE_OBJ nDel, DEQUE_OBJ *tcDeques) ;
INT fem_tc5e3p3e5( FACE_OBJ face, DEQUE_OBJ *tcDeques, INT *did) ;
INT FEM_tc3e5op5e3( FACE_OBJ face, DEQUE_OBJ *tcDeques, INT *did);
INT fem_tcCouldNodeAddEdge( NODE_OBJ node, INT surfId );
INT fem_tcCouldNodeDelEdge( NODE_OBJ node, INT surfId );
INT fem_tcOpen(NODE_OBJ obj_node, NODE_OBJ node1,NODE_OBJ node2,FACE_OBJ *mvFaces, 
               INT numFaces,INT area,DEQUE_OBJ *tcDeques, FACE_OBJ *face,NODE_OBJ *node) ;
INT fem_tcAdd2EdgedNode( FACE_OBJ face, NODE_OBJ n1, NODE_OBJ n2, DEQUE_OBJ tcDeques, 
                         FACE_OBJ *newFace, NODE_OBJ *newNode ) ;
INT fem_tcMove3p5( FACE_OBJ face, DEQUE_OBJ *tcDeques ) ;
INT fem_tc6e4e3( NODE_OBJ node, INT area, DEQUE_OBJ *tcDeques, INT *did) ;
INT fem_tcOpenFace(FACE_OBJ *face,NODE_OBJ obj_node,EDGE_OBJ obj_edge1,EDGE_OBJ obj_edge2,      /* the ther edge to be opened                     */
   INT area,DEQUE_OBJ faceDeque,DEQUE_OBJ edgeDeque,INT *change ) ;
INT fem_tcOpenNode(
   NODE_OBJ openNode,
   NODE_OBJ node1,
   INT area,
	DEQUE_OBJ *tcDeques,
   FACE_OBJ *newFace,
	NODE_OBJ *newNode) ;
INT fem_tcOpen2EdgedNode( NODE_OBJ n2e, DEQUE_OBJ *tcDeques, INT area, 
								  FACE_OBJ *newFace, NODE_OBJ *newNode, INT iCaller ) ;
INT fem_tcOpen2EdgedNodes( INT area, INT *changed )  ;
INT fem_tcOpenBndNode( NODE_OBJ openNode, DEQUE_OBJ *tcDeques, INT area, 
								  FACE_OBJ *newFace, NODE_OBJ *newNode) ;
INT fem_tcOpenBndNodes( INT area, INT *changed ) ;
DOUBLE fem_tcNodeVV_eq( NODE_OBJ node, INT surfId, INT adjust ) ;
INT fem_tcNeedVerify();
INT fem_isRelatedToLayer( NODE_OBJ keyNode, FACE_OBJ keyFace, 
                                 FACE_OBJ *faces, INT numFaces );
INT fem_tcFindOpenInfo(NODE_OBJ openNode, NODE_OBJ node1,INT area, 
							  NODE_OBJ *oppNodes, INT *nMove, FACE_OBJ *moveFaces );
INT fem_tcCloseBndNode( FACE_OBJ bndFace, NODE_OBJ bndNode, DEQUE_OBJ *tcDeques, 
                        INT qualityCleaned, INT iPriority) ;
INT fem_tcSwapDiagIdx(EDGE_OBJ edge,
   FACE_OBJ *faces,
   NODE_OBJ obj_nodes[6],   /* nodes ordered around the 2 quads        */
   INT new_diag_idx,            /* which new diag.  If new_diag_idx == 1, new  */
   DEQUE_OBJ *tcDeques,
   INT iForDel2EN ); /* is to remove 2-edged-node 0:no, 1:yes, 2:... not used so far */
INT fem_tcOpenNode2PlusDo( NODE_OBJ openNode, DEQUE_OBJ *tcDeques, INT area, 
								  FACE_OBJ *newFace, NODE_OBJ *newNode) ;
INT fem_tcOpenNode2Plus( INT area, INT *changed, INT iPrty )    ;
INT fem_tcIsNodeNbrToBnd( NODE_OBJ node, INT area );
INT fem_tc343_1(NODE_OBJ *aobj_nodes,FACE_OBJ *aobj_faces,DEQUE_OBJ *tcDeques) ;
INT fem_tc343_3(NODE_OBJ *aobj_nodes,FACE_OBJ *aobj_faces,DEQUE_OBJ *tcDeques) ;
INT fem_tc343_4(NODE_OBJ *aobj_nodes,FACE_OBJ *aobj_faces,DEQUE_OBJ *tcDeques) ;
INT fem_tc343_5(NODE_OBJ *aobj_nodes,FACE_OBJ *aobj_faces,DEQUE_OBJ *tcDeques) ;
INT fem_tc343_7(NODE_OBJ *aobj_nodes,FACE_OBJ *aobj_faces,DEQUE_OBJ *tcDeques) ;
INT fem_tc343_8(NODE_OBJ *aobj_nodes,FACE_OBJ *aobj_faces,DEQUE_OBJ *tcDeques) ;
INT fem_tcNodeCcwConnNodes(NODE_OBJ openNode, INT area, 
									INT *numAreaNodes, NODE_OBJ *radiaNodes,
									INT *numAreaFaces, FACE_OBJ *nodeFaces);
INT fem_tcNodeCcwConnNodesV1(NODE_OBJ openNode, INT area, 
									INT *numAreaNodes, NODE_OBJ *radiaNodes,
									INT *numAreaFaces, FACE_OBJ *nodeFaces);
INT fem_tcCloseNode(INT area,NODE_OBJ *noKeep,NODE_OBJ noDel,DEQUE_OBJ *tcDeques) ;
INT fem_tcCloseBndNodes( INT area, INT *changed, INT ipriority, INT userInfo, INT qualityCleaned ) ;
INT fem_tcIsOkOpen3e6e3( NODE_OBJ obj_node, INT area ) ;
INT fem_tcAddEdgToBndNod( INT area, FEM_BOOLEAN *changed );
INT fem_tcDoubleClose(
   EDGE_OBJ obj_edge,        /* edge between two quads                  */
   FACE_OBJ obj_face1,       /* one quad                                */
   FACE_OBJ obj_face2,       /* one quad                                */
   NODE_OBJ obj_nodes[6],    /* ordered nodes around 2 quads            */
   INT nn[6],                /* extra edges at each node                */
   INT area,
   DEQUE_OBJ *tcDeques, /* edge deque                              */
   INT *change ) ;
INT fem_tcQuadSwap(
   FACE_OBJ faces[2],      /* one quad                                    */
   NODE_OBJ aobj_nodes[6],   /* ordered nodes around 2 quads                */
   DEQUE_OBJ *tcDeques ) ;
INT fem_tcIsOpenBetter_vv(NODE_OBJ openNode, NODE_OBJ node1, NODE_OBJ node2,
								  INT numFaces, INT area, INT absolute );

INT fem_tcGetCurrentPrty() ; /* in FEM_cleanTopo.c */
INT fem_tcAdd2EdgedNodeTo2EdgedNode( NODE_OBJ obj_node, INT area, DEQUE_OBJ *tcDeques,
                                     INT *changed, FACE_OBJ *newFace, NODE_OBJ *newNode, INT iCheck ) ;
INT fem_tcQualitySwap(INT area, INT *change ) ;
INT fem_tcQualitySplitBigAng(INT area, INT *change, DOUBLE tolerance,  INT process ) ;
INT fem_tcSplitFaceNode(FACE_OBJ obj_face, NODE_OBJ obj_node, DEQUE_OBJ *tcDeques, NODE_OBJ *aobj_newNodes); 
INT fem_tcSetupForSwap( EDGE_OBJ obj_edge, INT area, 
							   FACE_OBJ *faces, NODE_OBJ *aobj_nodes ) ;
INT fem_tcQualitySplitInversed(INT area, INT *change, DOUBLE tol, INT process );
INT FEM_tcNeedSplitBigAng(INT area);
INT FEM_tcIsFaceSkiny( FACE_OBJ obj_face );
INT FEM_tcIsFaceInSkinyZone( FACE_OBJ obj_face );
INT FEM_tcCloseSure(
   FACE_OBJ obj_face,  /* the face to be deleted                       */
   NODE_OBJ *noKeep,    /* one node to collapse                         */
   NODE_OBJ noDel,      /* other node to collapse                       */
   DEQUE_OBJ *tcDeques);
INT FEM_tcOpen3e4e3s( INT area, INT *changed );
INT FEM_tcWeekCloseBndNode( 
   NODE_OBJ obj_node, 
   INT area,
   DEQUE_OBJ *tcDeques );
INT FEM_tcCloseNodes2Plus( INT area, INT *changed, INT iPriority );
INT FEM_tcNodeTopoVariance(
   INT shape,           /* 3--for tri mesh, 4---for quad mesh */
   INT area_id,         /* the area of this cleanup */
   NODE_OBJ obj_node,   /* the node */   
   INT modifier,        /* a modifier */
   DOUBLE *variance );   /* the topo variance */
DOUBLE FEM_tcGetNodeMultiplier(
   NODE_OBJ obj_node );
INT FEM_tcCleanTmpPointers( INT area );
INT FEM_tcHasInversed(INT area, INT *piInversed );
INT FEM_tcHasBigAngle(INT area, INT *piBigAngle );
INT fem_tcBestFaceToClose(
   INT area,
   INT num_faces,
   FACE_OBJ *nodeFaces,
   NODE_OBJ obj_node, /* node asking reducing valence */
   INT *idx);
INT fem_tcCloseFaceGain(
   INT area,
   FACE_OBJ obj_face,
   NODE_OBJ obj_node,
   DOUBLE *gain);
INT FEM_tcQualityOpenBigSpanEdge(INT area, INT *change, DOUBLE tolerance,  INT process );
INT FEM_tcQualitySplitBigSpanAngFace(INT area, INT *change, DOUBLE tolerance,  INT process );
INT FEM_tcQualityFace(INT area, INT *bad) ;
INT FEM_tcQualityBigSpan(INT area, INT *change, DOUBLE tolerance, INT process);
INT FEM_tcTriSpanAngle(
   NODE_OBJ *aobj_nodes,
   INT option,             /* 0: -- return angle as cos(angle),  1: -- return true angle */
   DOUBLE *pdAngle );
   INT FEM_Close5p3e3(
   FACE_OBJ obj_face,
   DEQUE_OBJ *tcDeques,
   INT *ipDid );

INT FEM_tcCombine2Tris(
   EDGE_OBJ obj_edge,
   FACE_OBJ obj_tri1,          /* one triangle to combine                   */
   FACE_OBJ obj_tri2,          /* the other triangle to combine             */
   FACELIST_OBJ obj_flist,     /* face list                                 */
   EDGELIST_OBJ obj_edlist,    /* edge list                                 */
   NODELIST_OBJ obj_nlist,     /* node list                                 */
   INT area,                   /* area tris are in                          */
   DEQUE_OBJ obj_face_deque,   /* deque holding the triangles               */
   DEQUE_OBJ obj_edge_deque,   /* deque holding the edges                   */
   INT *change );

INT FEM_tcCombineTris(
   INT area,
   INT *piCombined);

INT FEM_tcSwapEdgeToNode( 
    EDGE_OBJ obj_edge,   /* edge to be swaped */
    NODE_OBJ obj_node,   /* node the new edge to connected to */
    INT area,
    DEQUE_OBJ *tcDeques ) ;

INT fem_tcOpen2EN_tightBnd(
    NODE_OBJ n2e, 
    INT area, 
    DEQUE_OBJ *tcDeques, 
    FACE_OBJ *newFace, 
    NODE_OBJ *newNode);

#ifdef __cplusplus
}
#endif
#endif

