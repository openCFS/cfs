#ifndef __CADOE_BUCKLING_H__
#define __CADOE_BUCKLING_H__

#ifdef __cplusplus
extern "C" {
#endif

  extern T_statut InitSession(void);
  extern T_statut CheckConsistency(T_modele *modele, PAR *par);
  extern T_statut EvalStatic(PAR *par,VEC *variation,double dp);
  extern void SX_FreeCadoeBuckling();
 
#ifdef __cplusplus
}
#endif

#endif
