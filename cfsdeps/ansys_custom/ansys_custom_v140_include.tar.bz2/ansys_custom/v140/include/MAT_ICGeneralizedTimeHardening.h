////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         Copyright (C) 2010 ANSYS Inc.  All Rights Reserved             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MAT_ICGeneralizedTimeHardening.h $
// $Revision: 1.6 $ 7.0
// $Date: 2010/04/06 20:21:11 $ March 28 2002
// $Author: srpailla $ rjayasee
//
// Decription :
//              This class implement Generalized Time Hardening Implicit Creep Model
//
////////////////////////////////////////////////////////////////////////////// 

#if !defined(MAT_ICGeneralizedTimeHardening_H)
#define MAT_ICGeneralizedTimeHardening_H

#include  "MAT_ConstitutiveFunction.h"
#include  "MAT_Creep.h"

class MAT_ICGeneralizedTimeHardening  : public MAT_Creep
{
public:

	MAT_ICGeneralizedTimeHardening();
    // Default Constructor.

    static MAT_Creep* Construct() ;

    virtual bool FunctionValue( double* pVariables, INT iNumVariables,
                                double* pInputVariables, INT iNumInputVariables, double& dCreepStrainRate ) ;
    //I pVariable
    //I-Value of Coefficients
    //I iNumVariables
    //I- Number of variables
    //I dInputVariables
    //I-Input Variables
    //I iNumInputVariables
    //I-Num Input Variables
    //I dCreepStrainRate
    //I-Calculated Value of Creep Strain Rate
    //R- Calculates the value of the Creep Strain Rate 

    virtual bool FunctionFTerm( double* pVariables, INT iNumVariables,
                                double* pInputVariables, INT iNumInputVariables, double& dCreepStrainRate ) ;
    //I pVariable
    //I-Value of Coefficients
    //I iNumVariables
    //I- Number of variables
    //I dInputVariables
    //I-Input Variables
    //I iNumInputVariables
    //I-Num Input Variables
    //I dCreepStrainRate
    //I-Calculated Value of Exponential Term/ RTerm
    //R- Calculates the value of the F Portion of the Creep Function 

    virtual bool FunctionRTerm( double* pVariables, INT iNumVariables,
                                double* pInputVariables, INT iNumInputVariables, double& dCreepStrainRate ) ;
    //I pVariable
    //I-Value of Coefficients
    //I iNumVariables
    //I- Number of variables
    //I dInputVariables
    //I-Input Variables
    //I iNumInputVariables
    //I-Num Input Variables
    //I dCreepStrainRate
    //I-Calculated Value of Exponential Term/ RTerm
    //R- Calculates the value of the R Portion of the Creep Function 
    
    virtual bool FirstDerivativeOfUnsquaredError
             ( double* pVariables,INT iNumVariables,
               double* pInputVariables, INT iNumInputVariables,
               INT iVariableIndex, double& dResult ) ;
    //I pVariable
    //I-Value of Coefficients
    //I iNumVariables
    //I- Number of variables
    //I dInputVariables
    //I-Input Variables
    //I iNumInputVariables
    //I-Num Input Variables
    //I iVariableIndex
    //I-Variable w.r.t which the derivative is to be calculated
    //I dResult
    //I-Calculated value of derivative
    //R- Calculates the value of the Creep Strain Rate 
          
    bool FirstDerivativeOfFTerm
         ( double* pVariables,INT iNumVariables,
           double* pInputVariables, INT iNumInputVariables,
           INT iVariableIndex, double& dResult ) ;
    //I pVariable
    //I-Value of Coefficients
    //I iNumVariables
    //I- Number of variables
    //I dInputVariables
    //I-Input Variables
    //I iNumInputVariables
    //I-Num Input Variables
    //I iVariableIndex
    //I-Variable w.r.t which the derivative is to be calculated
    //I dResult
    //I-Calculated value of derivative
    //R- Calculates the value of the derivative of the F Term 
    
    bool FirstDerivativeOfRTerm
         ( double* pVariables,INT iNumVariables,
           double* pInputVariables, INT iNumInputVariables,
           INT iVariableIndex, double& dResult ) ;
    //I pVariable
    //I-Value of Coefficients
    //I iNumVariables
    //I- Number of variables
    //I dInputVariables
    //I-Input Variables
    //I iNumInputVariables
    //I-Num Input Variables
    //I iVariableIndex
    //I-Variable w.r.t which the derivative is to be calculated
    //I dResult
    //I-Calculated value of derivative
    //R- Calculates the value of the derivative of the R Term 
    
    virtual void Print() ;
    // Prints the constitutive function

    virtual void EliminateTemperatureCoefficients();
    //Eliminates Temperature term and fixes it.

    virtual ~MAT_ICGeneralizedTimeHardening();
    //Destructor


protected:


} ;


class MAT_ICGeneralizedTimeHardeningFactory
{
    public:

    static MAT_ICGeneralizedTimeHardeningFactory* Instance() ;
    //I Pointer to Creep Factory
    //- Pointer to Singleton Instantiator

    static void Destroy() ;
    ~MAT_ICGeneralizedTimeHardeningFactory() ;
    // Destructor

    private:

    MAT_ICGeneralizedTimeHardeningFactory() ;
    // Constructor

    static MAT_ICGeneralizedTimeHardeningFactory* m_pInstance ;
    //Pointer to only instance of this class
} ;

#endif // !defined(MAT_ICGeneralizedTimeHardening_H)
