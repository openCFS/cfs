/**
 * @file   MatFortranWrap.h
 * @author  <ftheveno@LYOFTHEVENO8>
 * @date   Tue Mar 01 17:01:05 2011
 * 
 * @brief  
 * 
 * 
 */

#ifndef __MATFORTRANWRAP_I__
#define __MATFORTRANWRAP_I__

#include "C_VecP.h"
#include "C_VecPi.h"
#include "BoeingItf.h"
#include "CadoeAnsys.h"

#if defined(LOWERCASENOUNDER_SYS)
#define LoadModes	loadmodes
#define ReducedLoad	reducedload
#define MltMatrix	mltmatrix
#define GetMatrixCol	getmatrixcol
#define FreeMatrix	freematrix
#endif

#if defined(UPPERCASENOUNDER_SYS)
#define LoadModes	LOADMODES
#define ReducedLoad	REDUCEDLOAD
#define MltMatrix	MLTMATRIX
#define GetMatrixCol	GETMATRIXCOL
#define FreeMatrix	FREEMATRIX
#endif

#if defined(LOWERCASEUNDER_SYS)
#define LoadModes	loadmodes_
#define ReducedLoad	reducedload_
#define MltMatrix	mltmatrix_
#define GetMatrixCol	getmatrixcol_
#define FreeMatrix	freematrix_
#endif

extern "C" {
SUBROUTINE LoadModes( INT *Id, BCSINT *AdrMat);
SUBROUTINE ReducedLoad( BCSINT *AdrMat, complex16_t *zfvect);
SUBROUTINE MltMatrix( BCSINT *AdrMat, INT *Trans, INT *nVec, complex16_t *Vin, complex16_t *Vout);
SUBROUTINE GetMatrixCol( INT *ival, int *CplxEv, int *First, BCSINT *AdrMat, complex16_t *Vector);
SUBROUTINE FreeMatrix( BCSINT *lcpxEvec, int *cplx);
}

#endif	// __MATFORTRANWRAP_I__
