
/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 2009 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_sweep.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_sweep.h
 *  header file for FEM_sweep.c
 *
 */
#ifndef FEM_SWEEP_INCLUDE
#define FEM_SWEEP_INCLUDE

#include "FEM_model.h"

/*----------------- Globally accessible function prototypes -----------------*/

                      /* =================================================== */
                      /* === FEM_sweep:                                      */
                      /* === Return: EXIT_SUCCESS or EXIT_FAILURE            */
                      /* =================================================== */
INT FEM_sweep (
   VOL_PTYP obj_vol,  /* (IN)  The volume that we are sweeping.               */
   AREA_PTYP obj_sarea,/*(IN)  area on vnum that is meshed and is to be       */
                      /*       swept through volume.                          */
   AREA_PTYP obj_tarea,/*(IN)  an area on vnum that is meshed and is the      */
                      /*       destination of sweeping the source_area.       */
   INT do_progress,   /* (IN)  TRUE if status window is to be used.           */
   INT debug );
                      /* =================================================== */

#endif

