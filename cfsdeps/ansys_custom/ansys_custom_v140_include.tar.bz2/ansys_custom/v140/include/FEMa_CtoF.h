
/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 2009 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEMa_CtoF.h */
/* *** Notice - This file contains ANSYS Confidential information  *** */
/*                                                                         sjo
 *  FEMa_CtoF.h
 *  Prototypes and #defines for handling calls from
 *  C to FORTRAN and FORTRAN to C for the FEM module
 *
 *  To call FORTRAN from C:
 *  1.  A total of 5 entries into this file should be made under the
 *      headings "FORTRAN subroutines called from C".  Search for these
 *      headings and follow the pattern.
 *  2.  To call FORTRAN from C use an underscore at the end of the name
 *      All lower case is required!
 *      ie.           ffunc_(args);
 *  3.  Do not use the underscore in the FORTRAN definition of the function
 *      ie.           subroutine ffunc(arg1,arg2)
 *  4.  Pass the addresses of data to the FORTRAN subroutine i.e.
 *                    INT arg1;
 *                    DOUBLE arg2;
 *                    ffunc_(&arg1, &arg2);
 *  5.  Include this file in the C file that calls the FORTRAN. i.e.
 *                #include "FEMa_CtoF.h"
 *
 *  To call C from FORTRAN:
 *  1.  A C function callable from FORTRAN should be named with an
 *      underscore after the last letter.  All lower case is required!
 *       .ie cfunc_
 *  2.  The function definition should have the type and the #define
 *      CALLTYP preceding the function name. i.e.
 *               INT CALLTYP cfunc_ (args)
 *      CALLTYP is defined in computers.h - so do a #include "FEM_cdbtypes.h"
 *      since FEM_cdbtypes.h includes computers.h
 *  3.  Argument lists should use K&R standard rather than including
 *      types in the argument list (ANSI standard).  i.e.
 *               INT CALLTYP cfunc_ (arg1, arg2)
 *                   INT *arg1;
 *                   DOUBLE *arg2;
 *  4.  Arguments to the C function should be received as addresses and
 *      then dereferenced before being used.  i.e.
 *               INT CALLTYP cfunc_ (arg1, arg2)
 *                   INT *arg1;
 *                   DOUBLE *arg2;
 *               {
 *                   *arg1 = 1;  *arg2 = 1.0;
 *               }
 *  4.  A total of 5 entries into this file should be made under the
 *      headings "C functions called from FORTRAN".  Search for these
 *      headings and follow the pattern.
 *  5.  This file should be included in the C file where the function
 *      is located.  i.e.
 *               #include "FEMa_CtoF.h"
 *  6.  To call C from FORTRAN do not use the underscore i.e.
 *               call cfunc(arg1,arg2)
 *  7.  An extern definition should be included in the calling FORTRAN
 *      subroutine as well as the return type (if any).  i.e.
 *               extern cfunc
 *               integer cfunc
 *
 */

/* (1)-------------------------------------------------------------*/
#if defined(RS6000_SYS) || defined(HP32_SYS)


/* === C functions called from FORTRAN */

#define sethepoffset_   sethepoffset
#define fema_sweep_      fema_sweep
#define fema_smooth_     fema_smooth
#define fema_readmtkjor_ fema_readmtkjor
#define fema_refine_     fema_refine
#define fema_ugameshapi_ fema_ugameshapi
#define fema_ugvmeshapi_ fema_ugvmeshapi
#define fema_meshareas_  fema_meshareas
#define fema_mesharea_   fema_mesharea
#define fema_merecfac_   fema_merecfac
#define fema_cleantri_   fema_cleantri
#define fema_cleantopo_  fema_cleantopo
#define fema_cleanqual_  fema_cleanqual
#define fema_convert_    fema_convert
#define fema_convertbck_ fema_convertbck
#define fema_quadsplit_  fema_quadsplit
#define fema_killmesh_   fema_killmesh
#define fema_pave_       fema_pave
#define fema_hextotet_   fema_hextotet
#define fema_hextotet2_  fema_hextotet2
#define fema_hls_recv_   fema_hls_recv
#define fema_maptrimesh_ fema_maptrimesh
#define fema_bgmesh_     fema_bgmesh
#define fema_bgmesh_dele_ fema_bgmesh_dele
#define fema_bg_minsize_ fema_bg_minsize
#define fema_bg_avgsize_ fema_bg_avgsize
#define fema_bg_maxsize_ fema_bg_maxsize
#define fema_bgelemest_  fema_bgelemest
#define fema_interp_     fema_interp
#define fema_swapnsmo_   fema_swapnsmo
#define fema_areamesh_   fema_areamesh
#define fema_cofacet_    fema_cofacet
#define fema_proximity_  fema_proximity
#define fema_cofacetupdt_ fema_cofacetupdt
#define fema_hextopyr_   fema_hextopyr
#define fema_chktopo_    fema_chktopo
#define fema_stat_       fema_stat
#define fema_inistat_    fema_inistat
#define fema_ladeletelayer_ fema_ladeletelayer
#define fema_lainitlayer_ fema_lainitlayer
#define fema_get_coords_ fema_get_coords
#define fema_orinit_     fema_orinit
#define fema_ornew_      fema_ornew
#define fema_orandom_    fema_orandom
#define fema_ornext_     fema_ornext
#define fema_ordele_     fema_ordele
#define fema_orkill_     fema_orkill
#define fema_lasmooth_   fema_lasmooth
#define fema_erinitf_    fema_erinitf
#define fema_erprocerrf_ fema_erprocerrf
#define fema_erprocstringf_ fema_erprocstringf
#define fema_erdumpbufferf_ fema_erdumpbufferf
#define fema_erdeletef_  fema_erdeletef
#define fema_erseterrorf_ fema_erseterrorf
#define fema_ergeterrorf_ fema_ergeterrorf
#define fema_wpsetup_    fema_wpsetup
#define fema_wptoxyz_    fema_wptoxyz
#define fema_getnodeloc_ fema_getnodeloc
#define fema_getnodeuv_  fema_getnodeuv
#define fema_hexdom_     fema_hexdom
#define fema_xoxinit_    fema_xoxinit
#define fema_xxeval_     fema_xxeval
#define fema_xxslope_    fema_xxslope
#define fema_xxnorm_     fema_xxnorm
#define fema_xxproject_  fema_xxproject
#define fema_xxkill_     fema_xxkill
#define fema_xxcurv_     fema_xxcurv
#define fema_amorph_     fema_amorph
#define fema_vmorph_     fema_vmorph
#define fema_e2morph_    fema_e2morph
#define fema_e3morph_    fema_e3morph
#define fema_meshvols_   fema_meshvols
#define fema_xxbounds_   fema_xxbounds
#define fema_smareas_    fema_smareas
#define fema_smvols_     fema_smvols
#define fema_morph2d_setup_ fema_morph2d_setup
#define fema_morph3d_setup_ fema_morph3d_setup
#define fema_morph_done_    fema_morph_done
#define fema_morph2d_    fema_morph2d
#define fema_morph3d_    fema_morph3d



/* === FORTRAN subroutines called from C */

#define rdinqr_         rdinqr
#define ndinqr_         ndinqr
#define ledfnd_         ledfnd
#define ledfnd1_        ledfnd1
#define elmiqr_         elmiqr
#define arliqr_         arliqr
#define numarealooplines_ numarealooplines
#define arviqr_         arviqr
#define arnexp_         arnexp
#define ndgxyz_         ndgxyz
#define elmget_         elmget
#define lsnget_         lsnget
#define get_ielc_       get_ielc
#define get_vol_ielc_   get_vol_ielc
#define get_vol_size_   get_vol_size
#define get_area_size_  get_area_size
#define etyget_         etyget
#define ndpxyz_         ndpxyz
#define tetput_         tetput
#define ar2prj_         ar2prj
#define ar3prj_         ar3prj
#define draw_cell2_     draw_cell2
#define ar3psl_         ar3psl
#define lineevaladd_    lineevaladd
#define lineevalchek_   lineevalchek
#define lineevalinit_   lineevalinit
#define lineevalinil_   lineevalinil
#define lineevalinic_   lineevalinic
#define lineevalinid_   lineevalinid
#define lineevaldele_   lineevaldele
#define lineevalproj_   lineevalproj
#define lineevalparm_   lineevalparm
#define lineevalcurv_   lineevalcurv
#define lineevaltang_   lineevaltang
#define lineevaltgcv_   lineevaltgcv
#define lineevalstrt_   lineevalstrt
#define lineevalok_     lineevalok
#define lineevalremv_   lineevalremv
#define areaevaladd_    areaevaladd
#define areaevalnorm_   areaevalnorm
#define areaevaltang_   areaevaltang
#define areaevalchek_   areaevalchek
#define areaevalinit_   areaevalinit
#define areaevalparm_   areaevalparm
#define areaevalproj_   areaevalproj
#define areaevalnprj_   areaevalnprj
#define areaevallapj_   areaevallapj
#define areaevalcurv_   areaevalcurv
#define areaevalnmcv_   areaevalnmcv
#define areaevalflat_   areaevalflat
#define areaevalanly_   areaevalanly
#define areaevaldele_   areaevaldele
#define areaevalclsd_   areaevalclsd
#define areaevalbnds_   areaevalbnds
#define areaevalok_     areaevalok
#define area_int_get_   area_int_get
#define area_int_iqr_   area_int_iqr
#define line_int_iqr_   line_int_iqr
#define line_int_get_   line_int_get
#define lsinqr_         lsinqr
#define lsniqr_         lsniqr
#define ndinfo_         ndinfo
#define lsgprj_         lsgprj
#define kpinqr_         kpinqr
#define kpliqr_         kpliqr
#define kplvmx_         kplvmx
#define kpput_          kpput
#define lsliqr_         lsliqr
#define lsglsl_         lsglsl
#define lsaiqr_         lsaiqr
#define lsavmx2_        lsavmx2
#define lsavmx_         lsavmx
#define arinqr_         arinqr
#define araiqr_         araiqr
#define arlget_         arlget
#define arealooplines_  arealooplines
#define areexp_         areexp
#define ndmsme_         ndmsme
#define qtrput_         qtrput
#define erinqr_         erinqr
#define elmsme_         elmsme
#define pr7acl_         pr7acl
#define fema_setatt_     fema_setatt
#define lsnexp_         lsnexp
#define lsndel_         lsndel
#define lsnput_         lsnput
#define lsput_          lsput
#define arndel_         arndel
#define aredel_         aredel
#define arnget_         arnget
#define arnput_         arnput
#define areput_         areput
#define arput_          arput
#define vlndel_         vlndel
#define vledel_         vledel
#define vlnput_         vlnput
#define vleput_         vleput
#define vlput_          vlput
#define vlaget_         vlaget
#define vlaiqr_         vlaiqr
#define putelm_         putelm
#define putnelm_        putnelm
#define putelmv_        putelmv
#define enpput_         enpput
#define getshellthic_   getshellthic
#define eshapcompute_   eshapcompute
#define quadwarpwrap_   quadwarpwrap
#define eshaptestwarn_  eshaptestwarn
#define eshapput_cint_  eshapput_cint
#define midangspa_cint_ midangspa_cint
#define etyiqr_         etyiqr
#define elxiqr_         elxiqr
#define elxvmx_         elxvmx
#define vlinqr_         vlinqr
#define arvvmx_         arvvmx
#define arvvmx2_        arvvmx2
#define lsgkpt_         lsgkpt
#define disiqr_         disiqr
#define foriqr_         foriqr
#define mstatcont_      mstatcont
#define mstatupdate_    mstatupdate
#define mstatfinish_    mstatfinish
#define mstatsetup_     mstatsetup
#define mstatcheck_     mstatcheck
#define mstatactive_    mstatactive
#define mstatflush_     mstatflush
#define mstattime_      mstattime
#define grinfo_         grinfo
#define grinqr_         grinqr
#define quadck_         quadck
#define trichk_         trichk
#define warpck_         warpck
#define fema_erhndl_cint_  fema_erhndl_cint
#define fema_getelmdata_ fema_getelmdata
#define fema_geticommon_ fema_geticommon
#define fema_seticommon_ fema_seticommon
#define fema_getdcommon_ fema_getdcommon
#define fema_getesize_   fema_getesize
#define fema_deletemem_  fema_deletemem
#define fema_mapquadmesh_ fema_mapquadmesh
#define fema_printwarn_ fema_printwarn
#define fema_getnextids_ fema_getnextids
#define get_shpp_       get_shpp
#define refchknode_     refchknode
#define refchkbfnode_   refchkbfnode
#define refchkbfelem_   refchkbfelem
#define refchkelem_     refchkelem
#define egetea_         egetea
#define elinfo_         elinfo
#define elsel_          elsel
#define ndsel_          ndsel
#define rndoff_         rndoff
#define vbox_           vbox
#define alfund_         alfund
#define vnorm_          vnorm
#define vdot_           vdot
#define vamb_           vamb
#define vmult_          vmult
#define vapcb1_         vapcb1
#define chkprl_         chkprl
#define ivsrt2_         ivsrt2
#define vleexp_         vleexp
#define jrtet_          jrtet
#define jrbrwg_         jrbrwg
#define p_deg_btran_    p_deg_btran
#define global_         global
#define izero_          izero
#define erinfo_         erinfo
#define lcatlp_         lcatlp
#define prcstr_         prcstr
#define fliget_         fliget
#define cmdver_cint_    cmdver_cint
#define cmdverall_cint_ cmdverall_cint
#define fema_trackpoint_ fema_trackpoint
#define fema_trackbegin_ fema_trackbegin
#define fema_trackend_   fema_trackend
#define wrinfo_         wrinfo
#define wrinqr_         wrinqr
#define dbinqr_         dbinqr
#define hepiqr_         hepiqr
#define etweak_         etweak
#define face_in_area_   face_in_area
#define deg_node_       deg_node
#define tri_to_quad_    tri_to_quad
#define kpggxy_         kpggxy
#define acatsh_         acatsh
#define lsgpar_         lsgpar
#define line_spacing_   line_spacing
#define kpgpar_         kpgpar
#define lsgnor_         lsgnor
#define fema_eplo_      fema_eplo
#define ndbdpj_         ndbdpj
#define smnenx_         smnenx
#define frn_gttess_     frn_gttess
#define frn_tessiqr_    frn_tessiqr
#define araget_         araget
#define sainqr_         sainqr
#define frn_lsarprj_    frn_lsarprj
#define reset_mesh_keys_ reset_mesh_keys
#define set_mesh_keys_  set_mesh_keys
#define get_ielc_       get_ielc
#define get_genquad_ielc_ get_genquad_ielc
#define clearlnskps_    clearlnskps
#define lmeshvols_cint_ lmeshvols_cint
#define chkcrk_         chkcrk
#define fema_ameshstat_ fema_ameshstat
#define gt_curtyp_      gt_curtyp

#endif

/* (2)-------------------------------------------------------------*/

#if defined(WATCOMC_SYS) \
    || defined(PCWINNT_SYS) 
/* === C functions called from FORTRAN */

#define sethepoffset_            SETHEPOFFSET
#define fema_sweep_              FEMA_SWEEP
#define fema_smooth_             FEMA_SMOOTH
#define fema_readmtkjor_         FEMA_READMTKJOR
#define fema_refine_             FEMA_REFINE
#define fema_ugameshapi_         FEMA_UGAMESHAPI
#define fema_ugvmeshapi_         FEMA_UGVMESHAPI
#define fema_meshareas_          FEMA_MESHAREAS
#define fema_mesharea_           FEMA_MESHAREA
#define fema_merecfac_           FEMA_MERECFAC
#define fema_cleantri_           FEMA_CLEANTRI
#define fema_cleantopo_          FEMA_CLEANTOPO
#define fema_cleanqual_          FEMA_CLEANQUAL
#define fema_convert_            FEMA_CONVERT
#define fema_convertbck_         FEMA_CONVERTBCK
#define fema_quadsplit_          FEMA_QUADSPLIT
#define fema_killmesh_           FEMA_KILLMESH
#define fema_pave_               FEMA_PAVE
#define fema_hextotet_           FEMA_HEXTOTET
#define fema_hextotet2_          FEMA_HEXTOTET2
#define fema_hls_recv_           FEMA_HLS_RECV
#define fema_maptrimesh_         FEMA_MAPTRIMESH
#define fema_bgmesh_             FEMA_BGMESH
#define fema_bgmesh_dele_        FEMA_BGMESH_DELE
#define fema_bg_minsize_         FEMA_BG_MINSIZE
#define fema_bg_avgsize_         FEMA_BG_AVGSIZE
#define fema_bg_maxsize_         FEMA_BG_MAXSIZE
#define fema_bgelemest_          FEMA_BGELEMEST
#define fema_interp_             FEMA_INTERP
#define fema_swapnsmo_           FEMA_SWAPNSMO
#define fema_areamesh_           FEMA_AREAMESH
#define fema_cofacet_            FEMA_COFACET
#define fema_proximity_          FEMA_PROXIMITY
#define fema_cofacetupdt_        FEMA_COFACETUPDT
#define fema_hextopyr_           FEMA_HEXTOPYR
#define fema_chktopo_            FEMA_CHKTOPO
#define fema_stat_               FEMA_STAT
#define fema_inistat_            FEMA_INISTAT
#define fema_ladeletelayer_      FEMA_LADELETELAYER
#define fema_lainitlayer_        FEMA_LAINITLAYER
#define fema_get_coords_         FEMA_GET_COORDS
#define fema_orinit_             FEMA_ORINIT
#define fema_ornew_              FEMA_ORNEW
#define fema_orandom_            FEMA_ORANDOM
#define fema_ornext_             FEMA_ORNEXT
#define fema_ordele_             FEMA_ORDELE
#define fema_orkill_             FEMA_ORKILL
#define fema_lasmooth_           FEMA_LASMOOTH
#define fema_erinitf_            FEMA_ERINITF
#define fema_erprocerrf_         FEMA_ERPROCERRF
#define fema_erprocstringf_      FEMA_ERPROCSTRINGF
#define fema_erdumpbufferf_      FEMA_ERDUMPBUFFERF
#define fema_erdeletef_          FEMA_ERDELETEF
#define fema_ergeterrorf_        FEMA_ERGETERRORF
#define fema_erseterrorf_        FEMA_ERSETERRORF
#define fema_wpsetup_            FEMA_WPSETUP
#define fema_wptoxyz_            FEMA_WPTOXYZ
#define fema_getnodeloc_         FEMA_GETNODELOC
#define fema_getnodeuv_          FEMA_GETNODEUV
#define fema_hexdom_             FEMA_HEXDOM
#define fema_xoxinit_            FEMA_XOXINIT
#define fema_xxeval_             FEMA_XXEVAL
#define fema_xxslope_            FEMA_XXSLOPE
#define fema_xxnorm_             FEMA_XXNORM
#define fema_xxproject_          FEMA_XXPROJECT
#define fema_xxkill_             FEMA_XXKILL
#define fema_xxcurv_             FEMA_XXCURV
#define fema_amorph_             FEMA_AMORPH
#define fema_vmorph_             FEMA_VMORPH
#define fema_e2morph_            FEMA_E2MORPH
#define fema_e3morph_            FEMA_E3MORPH
#define fema_meshvols_           FEMA_MESHVOLS
#define fema_xxbounds_           FEMA_XXBOUNDS
#define fema_smareas_            FEMA_SMAREAS
#define fema_smvols_             FEMA_SMVOLS
#define fema_morph2d_setup_      FEMA_MORPH2D_SETUP
#define fema_morph3d_setup_      FEMA_MORPH3D_SETUP
#define fema_morph_done_         FEMA_MORPH_DONE
#define fema_morph2d_            FEMA_MORPH2D
#define fema_morph3d_            FEMA_MORPH3D


/* === FORTRAN subroutines called from C */

#define rdinqr_         RDINQR
#define ndinqr_         NDINQR
#define ledfnd_         LEDFND
#define ledfnd1_        LEDFND1
#define elmiqr_         ELMIQR
#define arliqr_         ARLIQR
#define numarealooplines_ NUMAREALOOPLINES
#define arviqr_         ARVIQR
#define arnexp_         ARNEXP
#define ndgxyz_         NDGXYZ
#define elmget_         ELMGET
#define lsnget_         LSNGET
#define get_ielc_       GET_IELC
#define get_vol_ielc_   GET_VOL_IELC
#define get_vol_size_   GET_VOL_SIZE
#define get_area_size_  GET_AREA_SIZE
#define etyget_         ETYGET
#define ndpxyz_         NDPXYZ
#define tetput_         TETPUT
#define ar2prj_         AR2PRJ
#define ar3prj_         AR3PRJ
#define draw_cell2_     DRAW_CELL2
#define ar3psl_         AR3PSL
#define lineevaladd_    LINEEVALADD
#define lineevalchek_   LINEEVALCHEK
#define lineevalinit_   LINEEVALINIT
#define lineevalinil_   LINEEVALINIL
#define lineevalinic_   LINEEVALINIC
#define lineevalinid_   LINEEVALINID
#define lineevaldele_   LINEEVALDELE
#define lineevalproj_   LINEEVALPROJ
#define lineevalparm_   LINEEVALPARM
#define lineevalstrt_   LINEEVALSTRT
#define lineevalok_     LINEEVALOK
#define lineevalremv_   LINEEVALREMV
#define lineevalcurv_   LINEEVALCURV
#define lineevaltang_   LINEEVALTANG
#define lineevaltgcv_   LINEEVALTGCV
#define areaevaladd_    AREAEVALADD
#define areaevalnorm_   AREAEVALNORM
#define areaevaltang_   AREAEVALTANG
#define areaevalchek_   AREAEVALCHEK
#define areaevalinit_   AREAEVALINIT
#define areaevalparm_   AREAEVALPARM
#define areaevalproj_   AREAEVALPROJ
#define areaevalnprj_   AREAEVALNPRJ
#define areaevallapj_   AREAEVALLAPJ
#define areaevalflat_   AREAEVALFLAT
#define areaevalanly_   AREAEVALANLY
#define areaevaldele_   AREAEVALDELE
#define areaevalok_     AREAEVALOK
#define areaevalcurv_   AREAEVALCURV
#define areaevalnmcv_   AREAEVALNMCV
#define areaevalbnds_   AREAEVALBNDS
#define areaevalclsd_   AREAEVALCLSD
#define area_int_get_   AREA_INT_GET
#define area_int_iqr_   AREA_INT_IQR
#define line_int_iqr_   LINE_INT_IQR
#define line_int_get_   LINE_INT_GET
#define lsinqr_         LSINQR
#define lsniqr_         LSNIQR
#define ndinfo_         NDINFO
#define lsgprj_         LSGPRJ
#define kpliqr_         KPLIQR
#define kpinqr_         KPINQR
#define kplvmx_         KPLVMX
#define kpput_          KPPUT
#define lsliqr_         LSLIQR
#define lsglsl_         LSGLSL
#define lsaiqr_         LSAIQR
#define lsavmx_         LSAVMX
#define lsavmx2_        LSAVMX2
#define arinqr_         ARINQR
#define araiqr_         ARAIQR
#define arlget_         ARLGET
#define arealooplines_  AREALOOPLINES 
#define areexp_         AREEXP
#define ndmsme_         NDMSME
#define qtrput_         QTRPUT
#define erinqr_         ERINQR
#define elmsme_         ELMSME
#define pr7acl_         PR7ACL
#define fema_setatt_     FEMA_SETATT
#define lsnexp_         LSNEXP
#define lsndel_         LSNDEL
#define lsnput_         LSNPUT
#define lsput_          LSPUT
#define arndel_         ARNDEL
#define aredel_         AREDEL
#define arnget_         ARNGET
#define arnput_         ARNPUT
#define areput_         AREPUT
#define arput_          ARPUT
#define vlndel_         VLNDEL
#define vledel_         VLEDEL
#define vlnput_         VLNPUT
#define vleput_         VLEPUT
#define vlput_          VLPUT
#define vlaget_         VLAGET
#define vlaiqr_         VLAIQR
#define putelm_         PUTELM
#define putnelm_        PUTNELM
#define putelmv_        PUTELMV
#define enpput_         ENPPUT
#define eshapcompute_   ESHAPCOMPUTE
#define getshellthic_   GETSHELLTHIC
#define quadwarpwrap_   QUADWARPWRAP
#define eshaptestwarn_  ESHAPTESTWARN
#define eshapput_cint_  ESHAPPUT_CINT
#define midangspa_cint_ MIDANGSPA_CINT
#define etyiqr_         ETYIQR
#define elxiqr_         ELXIQR
#define elxvmx_         ELXVMX
#define vlinqr_         VLINQR
#define arvvmx_         ARVVMX
#define arvvmx2_        ARVVMX2
#define lsgkpt_         LSGKPT
#define disiqr_         DISIQR
#define foriqr_         FORIQR
#define mstatcont_      MSTATCONT
#define mstatupdate_    MSTATUPDATE
#define mstatfinish_    MSTATFINISH
#define mstatsetup_     MSTATSETUP
#define mstatcheck_     MSTATCHECK
#define mstatactive_    MSTATACTIVE
#define mstatflush_     MSTATFLUSH
#define mstattime_      MSTATTIME
#define grinfo_         GRINFO
#define grinqr_         GRINQR
#define quadck_         QUADCK
#define trichk_         TRICHK
#define warpck_         WARPCK
#define fema_erhndl_cint_  FEMA_ERHNDL_CINT
#define fema_getelmdata_ FEMA_GETELMDATA
#define fema_geticommon_ FEMA_GETICOMMON
#define fema_seticommon_ FEMA_SETICOMMON
#define fema_getdcommon_ FEMA_GETDCOMMON
#define fema_getesize_   FEMA_GETESIZE
#define fema_deletemem_  FEMA_DELETEMEM
#define fema_mapquadmesh_ FEMA_MAPQUADMESH
#define fema_printwarn_ FEMA_PRINTWARN
#define fema_getnextids_ FEMA_GETNEXTIDS
#define get_shpp_       GET_SHPP
#define refchknode_     REFCHKNODE
#define refchkbfnode_   REFCHKBFNODE
#define refchkbfelem_   REFCHKBFELEM
#define refchkelem_     REFCHKELEM
#define egetea_         EGETEA
#define elinfo_         ELINFO
#define elsel_          ELSEL
#define ndsel_          NDSEL
#define rndoff_         RNDOFF
#define vbox_           VBOX
#define alfund_         ALFUND
#define vnorm_          VNORM
#define vamb_           VAMB
#define vdot_           VDOT
#define vmult_          VMULT
#define vapcb1_         VAPCB1
#define chkprl_         CHKPRL
#define ivsrt2_         IVSRT2
#define vleexp_         VLEEXP
#define jrtet_          JRTET
#define jrbrwg_         JRBRWG
#define p_deg_btran_    P_DEG_BTRAN
#define global_         GLOBAL
#define izero_          IZERO 
#define erinfo_         ERINFO
#define lcatlp_         LCATLP
#define prcstr_         PRCSTR
#define fliget_         FLIGET
#define cmdver_cint_    CMDVER_CINT
#define cmdverall_cint_ CMDVERALL_CINT
#define fema_trackpoint_ FEMA_TRACKPOINT
#define fema_trackbegin_ FEMA_TRACKBEGIN
#define fema_trackend_   FEMA_TRACKEND
#define wrinfo_         WRINFO
#define wrinqr_         WRINQR
#define dbinqr_         DBINQR
#define hepiqr_         HEPIQR
#define etweak_         ETWEAK
#define face_in_area_   FACE_IN_AREA
#define deg_node_       DEG_NODE
#define tri_to_quad_    TRI_TO_QUAD
#define kpggxy_         KPGGXY
#define acatsh_         ACATSH
#define lsgpar_         LSGPAR
#define line_spacing_   LINE_SPACING
#define kpgpar_         KPGPAR
#define lsgnor_         LSGNOR
#define fema_eplo_      FEMA_EPLO
#define ndbdpj_         NDBDPJ
#define smnenx_         SMNENX
#define frn_gttess_     FRN_GTTESS
#define frn_tessiqr_    FRN_TESSIQR
#define araget_         ARAGET
#define sainqr_         SAINQR
#define frn_lsarprj_    FRN_LSARPRJ
#define reset_mesh_keys_ RESET_MESH_KEYS
#define set_mesh_keys_  SET_MESH_KEYS
#define get_ielc_       GET_IELC
#define get_genquad_ielc_ GET_GENQUAD_IELC
#define clearlnskps_    CLEARLNSKPS
#define lmeshvols_cint_ LMESHVOLS_CINT
#define chkcrk_         CHKCRK
#define fema_ameshstat_ FEMA_AMESHSTAT
#define gt_curtyp_      GT_CURTYP

#endif

/* (3)-------------------------------------------------------------*/
#if defined(WATCOMC_SYS)

/* === C functions called from FORTRAN */
#pragma aux SETHEPOFFSET "^";
#pragma aux FEMA_SWEEP "^";
#pragma aux FEMA_SMOOTH "^";
#pragma aux FEMA_READMTKJOR "^";
#pragma aux FEMA_REFINE "^";
#pragma aux FEMA_UGAMESHAPI "^";
#pragma aux FEMA_UGVMESHAPI "^";
#pragma aux FEMA_MESHAREAS "^";
#pragma aux FEMA_MESHAREA "^";
#pragma aux FEMA_MERECFAC "^";
#pragma aux FEMA_CLEANTRI "^";
#pragma aux FEMA_CLEANTOPO "^";
#pragma aux FEMA_CLEANQUAL "^";
#pragma aux FEMA_CONVERT "^";
#pragma aux FEMA_CONVERTBCK "^";
#pragma aux FEMA_QUADSPLIT "^";
#pragma aux FEMA_KILLMESH "^";
#pragma aux FEMA_PAVE "^";
#pragma aux FEMA_HEXTOTET "^";
#pragma aux FEMA_HEXTOTET2 "^";
#pragma aux FEMA_HLS_RECV "^";
#pragma aux FEMA_MAPTRIMESH "^";
#pragma aux FEMA_BGMESH "^";
#pragma aux FEMA_BGMESH_DELE "^";
#pragma aux FEMA_BG_MINSIZE "^";
#pragma aux FEMA_BG_AVGSIZE "^";
#pragma aux FEMA_BG_MAXSIZE "^";
#pragma aux FEMA_BGELEMEST "^";
#pragma aux FEMA_INTERP "^";
#pragma aux FEMA_SWAPNSMO "^";
#pragma aux FEMA_AREAMESH "^";
#pragma aux FEMA_COFACET "^";
#pragma aux FEMA_PROXIMITY "^";
#pragma aux FEMA_COFACETUPDT "^";
#pragma aux FEMA_HEXTOPYR "^";
#pragma aux FEMA_CHKTOPO "^";
#pragma aux FEMA_STAT "^";
#pragma aux FEMA_INISTAT "^";
#pragma aux FEMA_LADELETELAYER "^";
#pragma aux FEMA_LAINITLAYER "^";
#pragma aux FEMA_GET_COORDS "^";
#pragma aux FEMA_ORINIT "^";
#pragma aux FEMA_ORNEW "^";
#pragma aux FEMA_ORANDOM "^";
#pragma aux FEMA_ORNEXT "^";
#pragma aux FEMA_ORDELE "^";
#pragma aux FEMA_ORKILL "^";
#pragma aux FEMA_LASMOOTH "^";
#pragma aux FEMA_ERINITF "^";
#pragma aux FEMA_ERPROCERRF "^";
#pragma aux FEMA_ERPROCSTRINGF "^";
#pragma aux FEMA_ERDUMPBUFFERF "^";
#pragma aux FEMA_ERDELETEF "^";
#pragma aux FEMA_ERGETERROR "^";
#pragma aux FEMA_ERSETERROR "^";
#pragma aux FEMA_WPTOXYZ "^";
#pragma aux FEMA_WPSETUP "^";
#pragma aux FEMA_GETNODELOC "^";
#pragma aux FEMA_GETNODEUV "^";
#pragma aux FEMA_HEXDOM "^";
#pragma aux FEMA_XOXINIT "^";
#pragma aux FEMA_XXEVAL "^";
#pragma aux FEMA_XXSLOPE "^";
#pragma aux FEMA_XXNORM "^";
#pragma aux FEMA_XXPROJECT "^";
#pragma aux FEMA_XXKILL "^";
#pragma aux FEMA_XXCURV "^";
#pragma aux FEMA_AMORPH "^";
#pragma aux FEMA_VMORPH "^";
#pragma aux FEMA_E2MORPH "^";
#pragma aux FEMA_E3MORPH "^";
#pragma aux FEMA_MESHVOLS "^";
#pragma aux FEMA_SMAREAS "^";
#pragma aux FEMA_SMVOLS "^";
#pragma aux FEMA_MORPH2D_SETUP "^";
#pragma aux FEMA_MORPH3D_SETUP "^";
#pragma aux FEMA_MORPH_DONE "^";
#pragma aux FEMA_MORPH2D "^";
#pragma aux FEMA_MORPH3D "^";




/* === FORTRAN subroutines called from C */
#pragma aux RDINQR "^";
#pragma aux NDINQR "^";
#pragma aux LEDFND "^";
#pragma aux LEDFND1 "^";
#pragma aux ELMIQR "^";
#pragma aux ARLIQR "^";
#pragma aux NUMAREALOOPLINES "^";
#pragma aux ARVIQR "^";
#pragma aux ARNEXP "^";
#pragma aux NDGXYZ "^";
#pragma aux ELMGET "^";
#pragma aux LSNGET "^";
#pragma aux GET_IELC "^";
#pragma aux GET_GENQUAD_IELC "^";
#pragma aux GET_VOL_IELC "^";
#pragma aux GET_VOL_SIZE "^";
#pragma aux GET_AREA_SIZE "^";
#pragma aux ETYGET "^";
#pragma aux NDPXYZ "^";
#pragma aux TETPUT "^";
#pragma aux AR2PRJ "^";
#pragma aux AR3PRJ "^";
#pragma aux DRAW_CELL2 "^";
#pragma aux AR3PSL "^";
#pragma aux LINEEVALADD "^";
#pragma aux LINEEVALCHEK "^";
#pragma aux LINEEVALINIT "^";
#pragma aux LINEEVALINIL "^";
#pragma aux LINEEVALINIC "^";
#pragma aux LINEEVALINID "^";
#pragma aux LINEEVALDELE "^";
#pragma aux LINEEVALPROJ "^";
#pragma aux LINEEVALPARM "^";
#pragma aux LINEEVALSTRT "^";
#pragma aux LINEEVALOK "^";
#pragma aux LINEEVALREMV "^";
#pragma aux LINEEVALCURV "^";
#pragma aux LINEEVALTANG "^";
#pragma aux LINEEVALTGCV "^";
#pragma aux AREAEVALADD "^";
#pragma aux AREAEVALDELE "^";
#pragma aux AREAEVALNORM "^";
#pragma aux AREAEVALTANG "^";
#pragma aux AREAEVALCHEK "^";
#pragma aux AREAEVALINIT "^";
#pragma aux AREAEVALPROJ "^";
#pragma aux AREAEVALNPRJ "^";
#pragma aux AREAEVALLAPJ "^";
#pragma aux AREAEVALFLAT "^";
#pragma aux AREAEVALOK "^";
#pragma aux AREAEVALCURV "^";
#pragma aux AREAEVALNMCV "^";
#pragma aux AREAEVALBNDS "^";
#pragma aux AREAEVALCLSD "^";
#pragma aux LINE_INT_IQR "^";
#pragma aux LINE_INT_GET "^";
#pragma aux AREA_INT_IQR "^";
#pragma aux AREA_INT_GET "^";
#pragma aux LSINQR "^";
#pragma aux LSNIQR "^";
#pragma aux NDPXYZ "^";
#pragma aux NDINFO "^";
#pragma aux LSGPRJ "^";
#pragma aux KPLIQR "^";
#pragma aux KPINQR "^";
#pragma aux KPLVMX "^";
#pragma aux KPPUT  "^";
#pragma aux LSLIQR "^";
#pragma aux LSGLSL "^";
#pragma aux LSAIQR "^";
#pragma aux LSAVMX "^";
#pragma aux LSAVMX2 "^";
#pragma aux ARINQR "^";
#pragma aux ARAIQR "^";
#pragma aux ARLGET "^";
#pragma aux AREALOOPLINES "^";
#pragma aux AREEXP "^";
#pragma aux NDMSME "^";
#pragma aux QTRPUT "^";
#pragma aux ERINQR "^";
#pragma aux ELMSME "^";
#pragma aux PR7ACL "^";
#pragma aux FEMA_SETATT "^";
#pragma aux LSNEXP "^";
#pragma aux LSNDEL "^";
#pragma aux LSNPUT "^";
#pragma aux LSPUT "^";
#pragma aux ARNDEL "^";
#pragma aux AREDEL "^";
#pragma aux ARNGET "^";
#pragma aux ARNPUT "^";
#pragma aux AREPUT "^";
#pragma aux ARPUT "^";
#pragma aux VLNDEL "^";
#pragma aux VLEDEL "^";
#pragma aux VLNPUT "^";
#pragma aux VLEPUT "^";
#define aux VLPUT "^";
#define aux VLAGET "^";
#define auz VLAIQR "^";
#pragma aux VRPUT "^";
#pragma aux PUTELM "^";
#pragma aux PUTNELM "^";
#pragma aux PUTELMV "^";
#pragma aux ENPPUT "^";
#pragma aux ESHAPCOMPUTE "^";
#pragma aux GETSHELLTHIC "^";
#pragma aux QUADWARPWRAP "^";
#pragma aux ESHAPTESTWARN "^";
#pragma aux ESHAPPUT_CINT "^";
#pragma aux MIDANGSPA_CINT "^";
#pragma aux ETYIQR "^";
#pragma aux ELXIQR "^";
#pragma aux ELXVMX "^";
#pragma aux VLINQR "^";
#pragma aux ARVVMX "^";
#pragma aux ARVVMX2 "^";
#pragma aux LSGKPT "^";
#pragma aux DISIQR "^";
#pragma aux FORIQR "^";
#pragma aux MSTATCONT "^";
#pragma aux MSTATUPDATE "^";
#pragma aux MSTATFINISH "^";
#pragma aux MSTATSETUP "^";
#pragma aux MSTATCHECK "^";
#pragma aux MSTATACTIVE "^";
#pragma aux MSTATFLUSH "^";
#pragma aux GRINFO "^";
#pragma aux GRINQR "^";
#pragma aux QUADCK "^";
#pragma aux TRICHK "^";
#pragma aux WARPCK "^";
#pragma aux FEMA_ERHNDL_CINT "^";
#pragma aux FEMA_GETELMDATA "^";
#pragma aux FEMA_GETICOMMON "^";
#pragma aux FEMA_SETICOMMON "^";
#pragma aux FEMA_GETDCOMMON "^";
#pragma aux FEMA_GETESIZE "^";
#pragma aux FEMA_DELETEMEM "^";
#pragma aux FEMA_MAPQUADMESH "^";
#pragma aux FEMA_PRINTWARN "^";
#pragma aux FEMA_GETNEXTIDS "^";
#pragma aux GET_SHPP "^";
#pragma aux REFCHKNODE "^";
#pragma aux REFCHKBFNODE "^";
#pragma aux REFCHKBFELEM "^";
#pragma aux REFCHKELEM "^";
#pragma aux EGETEA "^";
#pragma aux ELINFO "^";
#pragma aux ELSEL "^";
#pragma aux NDSEL "^";
#pragma aux RNDOFF "^";
#pragma aux VBOX "^";
#pragma aux ALFUND "^";
#pragma aux VNORM "^";
#pragma aux VDOT "^";
#pragma aux VAMB "^";
#pragma aux VMULT "^";
#pragma aux VAPCB1 "^";
#pragma aux CHKPRL "^";
#pragma aux IVSRT2 "^";
#pragma aux VLEEXP "^";
#pragma aux JRTET "^";
#pragma aux JRBRWG "^";
#pragma aux P_DEG_BTRAN "^";
#pragma aux GLOBAL "^";
#pragma aux IZERO "^";
#pragma aux ERINFO "^";
#pragma aux LCATLP "^";
#pragma aux PRCSTR "^";
#pragma aux FLIGET "^";
#pragma aux CMDVER_CINT "^";
#pragma aux CMDVERALL_CINT "^";
#pragma aux FEMA_TRACKPOINT "^";
#pragma aux FEMA_TRACKBEGIN "^";
#pragma aux FEMA_TRACKEND "^";
#pragma aux WRINFO "^";
#pragma aux WRINQR "^";
#pragma aux DBINQR "^";
#pragma aux HEPIQR "^";
#pragma aux ETWEAK "^";
#pragma aux FACE_IN_AREA "^";
#pragma aux DEG_NODE "^";
#pragma aux TRI_TO_QUAD "^";
#pragma aux KPGGXY "^";
#pragma aux ACATSH "^";
#pragma aux LSGPAR "^";
#pragma aux LINE_SPACING "^";
#pragma aux KPGPAR "^";
#pragma aux LSGNOR "^";
#pragma aux FEMA_EPLO "^";
#pragma aux NDBDPJ "^";
#pragma aux SMNENX "^";
#pragma aux FRN_GTTESS "^";
#pragma aux FRN_TESSIQR "^";
#pragma aux ARAGET "^";
#pragma aux SAINQR "^";
#pragma aux FRN_LSARPRJ "^";
#pragma aux RESET_MESH_KEYS "^";
#pragma aux SET_MESH_KEYS "^";
#pragma aux GET_IELC "^";
#pragma aux CLEARLNSKPS "^";
#pragma aux LMESHVOLS_CINT "^";
#pragma aux CHKCRK "^";
#pragma aux FEMA_AMESHSTAT "^";
#define aux GT_CURTYP "^";

#endif

/* (4)-------------------------------------------------------------*/
/*
 * *** FUNCTION RETURN TYPE DECLARATION
 */

#if !defined(PCWINNT_SYS) 

/* === C functions called from FORTRAN */
   void sethepoffset_();
   INT fema_sweep_();
   INT fema_smooth_();
   INT fema_readmtkjor_();
   INT fema_refine_();
   void fema_ugameshapi_();
   void fema_ugvmeshapi_();
   INT fema_meshareas_();
   INT fema_mesharea_();
   INT fema_merecfac_();
   INT fema_cleantri_();
   INT fema_cleantopo_();
   INT fema_cleanqual_();
   INT fema_convert_();
   INT fema_convertbck_();
   INT fema_quadsplit_();
   void fema_killmesh_();
   INT fema_pave_();
   INT fema_hextotet_();
   INT fema_hextotet2_();
   INT fema_hls_recv_();
   INT fema_maptrimesh_();
   INT fema_bgmesh_();
   void fema_bgmesh_dele_();
   DOUBLE fema_bg_minsize_();
   DOUBLE fema_bg_avgsize_();
   DOUBLE fema_bg_maxsize_();
   INT fema_bgelemest_();
   DOUBLE fema_interp_();
   INT fema_swapnsmo_();
   INT fema_areamesh_();
   INT fema_cofacet_();
   INT fema_proximity_();
   INT fema_cofacetupdt_();
   void fema_hextopyr_();
   INT fema_chktopo_();
   void fema_stat_();
   void fema_inistat_();
   void fema_ladeletelayer_();
   INT fema_lainitlayer_();
   void fema_get_coords_();
   INT fema_orinit_();
   void fema_ornew_();
   void fema_orandom_();
   INT fema_ornext_();
   void fema_ordele_();
   void fema_orkill_();
   INT fema_lasmooth_();
   void fema_erinitf_();
   INT fema_erprocerrf_();
   INT fema_erprocstringf_();
   void fema_erdumpbufferf_();
   void fema_erdeletef_();
   void fema_ergeterrorf_();
   void fema_erseterrorf_();
   void fem_wpsetup_();
   void fem_wptoxyz_(); 
   INT fema_getnodeloc_(); 
   INT fema_getnodeuv_(); 
   INT fema_hexdom_();
   INT fema_xoxinit_();
   INT fema_xxeval_();
   INT fema_xxslope_();
   INT fema_xxnorm_();
   INT fema_xxproject_();
   void fema_xxkill_();
   INT fema_xxcurv_();
   INT fema_amorph_();
   INT fema_vmorph_();
   INT fema_e2morph_();
   INT fema_e3morph_();
   INT fema_meshvols_();
   INT fema_xxbounds_();
   void fema_smareas_();
   void fema_smvols_();
   INT fema_morph2d_setup_();
   INT fema_morph3d_setup_();
   INT fema_morph_done_();
   INT fema_morph2d_();
   INT fema_morph3d_();


/* === FORTRAN subroutines called from C */
   INT rdinqr_();
   INT ndinqr_();
   void ledfnd_();
   void ledfnd1_();
   INT elmiqr_();
   INT arliqr_();
   INT numarealooplines_();
   INT arviqr_();
   INT arnexp_();
   INT ndgxyz_();
   INT elmget_();
   INT lsnget_();
   void get_ielc_();
   void get_vol_ielc_();
   void get_vol_size_();
   void get_area_size_();
   INT etyget_();
   void ndpxyz_();
   void tetput_();
   void ar2prj_();
   void ar3prj_();
   void draw_cell2_();
   void ar3psl_();
   void lineevaladd_();
   void lineevalchek_();
   void lineevalinit_();
   void lineevalinil_();
   void lineevalinic_();
   void lineevalinid_();
   void lineevaldele_();
   void lineevalproj_();
   void lineevalparm_();
   void lineevalstrt_();
   void lineevalok_();
   void lineevalremv_();
   void lineevacurv_();
   void lineevaltang_();
   void lineevaltgcv_();
   void areaevaladd_();
   void areaevalnorm_();
   void areaevaltang_();
   void areaevalchek_();
   void areaevalinit_();
   void areaevalparm_();
   void areaevalproj_();
   void areaevalnprj_();
   void areaevallapj_();
   void areaevalflat_();
   void areaevalanly_();
   void areaevaldele_();
   void areaevalcurv();
   void areaevalnmcv_();
   void areaevalok_();
   void areaevalclsd_();
   void areaevalbnds_();
   INT  area_int_get_();
   INT  area_int_iqr_();
   INT  line_int_get_();
   INT  line_int_iqr_();
   INT lsinqr_();
   INT lsniqr_();
   INT ndinfo_();
   void lsgprj_();
   INT kpliqr_();
   INT kpinqr_();
   INT kplvmx_();
   void kpput_();
   INT lsliqr_();
   INT lsglsl_();
   INT lsaiqr_();
   INT lsavmx_();
   INT lsavmx2_();
   INT arinqr_();
   INT araiqr_();
   INT arlget_();
   void arealooplines_();
   INT areexp_();
   void ndmsme_();
   void qtrput_();
   INT erinqr_();
   void elmsme_();
   void pr7acl_();
   void fema_setatt_();
   INT lsnexp_();
   void lsndel_();
   void lsnput_();
   void lsput_();
   void arndel_();
   void aredel_();
   INT arnget_();
   void arnput_();
   void areput_();
   void arput_();
   void vlndel_();
   void vledel_();
   void vlnput_();
   void vleput_();
   INT vlaget_();
   void vlput_();
   INT vlaiqr_();
   void putelm_();
   void putnelm_();
   void putelmv_();
   void enpput_();
   void eshapcompute_();
   void getshellthic_();
   void quadwarpwrap_();
   void eshaptestwarn_();
   void eshapput_cint_();
   void midangspa_cint_();
   INT etyiqr_();
   INT elxiqr_();
   INT elxvmx_();
   INT vlinqr_();
   INT arvvmx_();
   INT arvvmx2_();
   INT lsgkpt_();
   INT disiqr_();
   INT foriqr_();
   void mstatcont_();
   void mstatupdate_();
   void mstatfinish_();
   void mstatsetup_();
   void mstatcheck_();
   INT mstatactive_();
   void mstatflush_();
   void mstattime_();
   void grinfo_();
   INT grinqr_();
   void quadck_();
   void trichk_();
   void warpck_();
   INT fema_erhndl_cint_();
   void fema_getelmdata_();
   INT fema_geticommon_();
   void fema_seticommon_();
   DOUBLE fema_getdcommon_();
   DOUBLE fema_getesize_();
   void fema_deletemem_();
   void fema_mapquadmesh_();
   void fema_printwarn_();
   void fema_getnextids_();
   DOUBLE get_shpp_();
   void refchknode_();
   void refchkbfnode_();
   void refchkbfelem_();
   void refchkelem_();
   void egetea_();
   void elinfo_();
   void elsel_();
   void ndsel_();
   void rndoff_();
   void vbox_();
   DOUBLE alfund_();
   void vnorm_();
   void vamb_();
   DOUBLE vdot_();
   void vmult_();
   void vapcb1_();
   void chkprl_();
   void ivsrt2_();
   INT vleexp_();
   void jrtet_();
   void jrbrwg_(); 
   void p_deg_btran_(); 
   void global_();
   void izero_();
   void erinfo_();
   void lcatlp_();
   void prcstr_();
   INT fliget_();
   void cmdver_cint_();
   void cmdverall_cint_();
   void fema_trackpoint_();
   void fema_trackbegin();
   void fema_trackend_();
   void wrinfo_();
   INT wrinqr_();
   INT dbinqr_();
   INT hepiqr_();
   void etweak_();
   INT face_in_area_();
   void deg_node_();
   void tri_to_quad_();
   INT kpggxy_();
   void acatsh_();
   INT lsgpar_();
   INT line_spacing_();
   INT kpgpar_();
   INT lsgnor_();
   void fema_eplo_();
   void ndbdpj_();
   void smnenx_();
   INT frn_gttess_();
   INT frn_tessiqr_();
   INT araget_();
   INT sainqr_();
   void frn_lsarprj_();
   void reset_mesh_keys_();
   void set_mesh_keys_();
   void get_ielc_();
   void get_genquad_ielc_();
   INT clearlnskps_();
   void lmeshvols_cint_();
   void chkcrk_();
   void fema_ameshstat_();
   INT  gt_curtyp(); 

/* (5)-------------------------------------------------------------*/
#else

/* === C functions called from FORTRAN */
   void CALLTYP sethepoffset_( INT * );
   INT CALLTYP fema_sweep_( INT *, INT *, INT *, INT *, DOUBLE *, INT *,
                            INT *, INT *, INT *, INT *, INT * );
   INT CALLTYP fema_smooth_( INT *, INT *, DOUBLE *, INT *, INT *, DOUBLE *, INT * );
   INT CALLTYP fema_readmtkjor_( );
   void CALLTYP fema_ugameshapi_( INT *, INT *, INT *, INT *, INT *, INT *, INT *,
                                  DOUBLE * );
   void CALLTYP fema_ugvmeshapi_( INT *, INT *, INT *, INT *, INT *, DOUBLE * );
   INT CALLTYP fema_refine_( INT *, INT *, INT *, INT *, INT *,
                            INT *, INT *, DOUBLE *, INT *, INT * );
   INT CALLTYP fema_meshareas_( INT *, INT *, INT *, INT * );
   INT CALLTYP fema_mesharea_( INT *, INT *, INT *, INT *, INT *, INT *,
                               INT *, INT *, INT *, INT * );
   INT CALLTYP fema_merecfac_( INT *, INT *, INT *, INT *, INT *, 
                               INT *, INT * );
   INT CALLTYP fema_cleantri_( INT *, INT *, INT *, INT *, INT *, INT *,
                              DOUBLE *, INT *, INT *, INT *, DOUBLE *,
                              INT *, DOUBLE *, DOUBLE *, DOUBLE *, DOUBLE *,
                              DOUBLE *, DOUBLE *, INT *, INT *, INT *, INT *, 
                              INT *, INT * );
   INT CALLTYP fema_cleantopo_( INT *, INT *, DOUBLE *, INT * );
   INT CALLTYP fema_cleanqual_( INT *, INT * );
   INT CALLTYP fema_convert_( INT *, INT *, INT *, INT *, INT *, INT *, INT *,
                             DOUBLE *, DOUBLE *, DOUBLE *,
                             INT *, INT *, INT * );
   INT CALLTYP fema_convertbck_( INT *, INT *, INT *, INT *, INT *, DOUBLE *, 
                                DOUBLE *, DOUBLE *, INT *, INT *, INT *, INT *,
                                INT *, INT *, INT *, INT *, INT *,INT **,
                                INT *, INT *, INT * );
   INT CALLTYP fema_quadsplit_( INT *, INT * );
   void CALLTYP fema_killmesh_( );
   INT CALLTYP fema_pave_( INT *, INT *, INT *, INT *, INT *, INT *,
                          DOUBLE *, INT *, DOUBLE *, DOUBLE *, DOUBLE *,
                          INT *, INT *, INT *, INT *, INT *,
                          INT *, INT *, INT *, INT *, INT *,
                          DOUBLE *, DOUBLE *, DOUBLE *, DOUBLE * );
   INT CALLTYP fema_hextotet_( INT *, INT *, INT *, INT *, INT *, INT *, INT * );
   INT CALLTYP fema_hextotet2_( INT *, INT * );
   INT CALLTYP fema_hls_recv_( INT *);
   INT CALLTYP fema_maptrimesh_( INT *, INT *, INT * );
   INT CALLTYP fema_bgmesh_( INT *, DOUBLE *, DOUBLE *, INT *, INT *, INT *,
                             INT *, INT *, INT *, INT *, INT *, INT *, INT *,
                             INT *, INT *, INT * );
   void CALLTYP fema_bgmesh_dele_();
   DOUBLE CALLTYP fema_bg_minsize_();
   DOUBLE CALLTYP fema_bg_avgsize_();
   DOUBLE CALLTYP fema_bg_maxsize_();
   INT CALLTYP fema_bgelemest_();
   DOUBLE CALLTYP fema_interp_( DOUBLE *, DOUBLE * );
   INT CALLTYP fema_swapnsmo_( INT *, INT *, INT *, INT *, INT *, INT *,
                              INT *, INT *, DDOUBLE *, DDOUBLE *, INT *, INT *,
                              INT *, INT *, INT *, INT [], DDOUBLE [][3],
                              INT * );
   INT CALLTYP fema_areamesh_( INT *, INT *, INT *, INT *, INT *,
                               INT *, INT *, INT *, INT *,
                               INT *, INT *, INT *, INT * );
   INT CALLTYP fema_cofacet_( INT *, INT *, INT *, INT *, INT *,
                              INT *, INT *, INT *, INT *, INT * );
   INT CALLTYP fema_proximity_( INT *, DOUBLE *, DOUBLE *, INT *,
                               INT *, INT *, INT *, INT *, INT *, INT *, INT *,
                               INT * );
   INT CALLTYP fema_cofacetupdt_( INT *, INT *, INT *, INT *, INT *, INT *,
                                 INT *, DOUBLE * );
   void CALLTYP fema_hextopyr_( INT * );
   INT CALLTYP fema_chktopo_( INT * );
   void CALLTYP fema_stat_( INT *, INT * );
   void CALLTYP fema_inistat_();
   void CALLTYP fema_ladeletelayer_();
   INT CALLTYP fema_lainitlayer_( INT *, INT *, INT * );
   void CALLTYP fema_get_coords_( INT *, INT *, DOUBLE *, DOUBLE *, DOUBLE *);
   INT CALLTYP fema_orinit_( DOUBLE *, INT *, INT *, INT *, INT *, DOUBLE * );
   void CALLTYP fema_ornew_( INT *, INT *, INT *, DOUBLE *, DOUBLE * );
   void CALLTYP fema_orandom_( INT *, INT *, INT *, DOUBLE *, DOUBLE * );
   INT CALLTYP fema_ornext_( INT *, INT *, INT *, DOUBLE *, DOUBLE * ); 
   void CALLTYP fema_ordele_( INT *, INT *, INT *, DOUBLE *, DOUBLE * );
   void CALLTYP fema_orkill_( );
   INT CALLTYP fema_lasmooth_( DOUBLE * );
   void CALLTYP fema_erinitf_( INT * );
   INT CALLTYP fema_erprocerrf_( INT *, INT *, INT *, DOUBLE * );
   INT CALLTYP fema_erprocstringf_( INT *, INT * );
   void CALLTYP fema_erdumpbufferf_();
   void CALLTYP fema_erdeletef_();
   void CALLTYP fema_ergeterror_( INT *, INT *, INT * );
   void CALLTYP fema_erseterror_( INT *, INT *, INT * );
   void CALLTYP fema_wpsetup_( INT *, INT *, INT *, INT *, INT *, INT *, INT *,
                               DOUBLE *, DOUBLE *, DOUBLE *, DOUBLE *, INT * );
   void CALLTYP fema_wptoxyz_( INT *, INT *, INT *, DOUBLE *, DOUBLE *, 
                               DOUBLE *, INT * );
   INT CALLTYP fema_getnodeloc_( INT *, DOUBLE * );
   INT CALLTYP fema_getnodeuv_( INT *, DOUBLE * );
   INT CALLTYP fema_hexdom_( INT * );
   INT CALLTYP fema_xoxinit_( INT *, INT * );
   INT CALLTYP fema_xxeval_( INT *, DOUBLE *, DOUBLE * );
   INT CALLTYP fema_xxslope_( INT *, DOUBLE *, DOUBLE *, DOUBLE * );
   INT CALLTYP fema_xxnorm_( INT *, DOUBLE *, DOUBLE * );
   INT CALLTYP fema_xxproject_( INT *, INT *, DOUBLE *, DOUBLE * );
   void CALLTYP fema_xxkill_( );
   INT CALLTYP fema_xxcurv_( INT *, DOUBLE *, DOUBLE * );
   INT CALLTYP fema_amorph_( INT *, INT *, INT *, INT *, DOUBLE *, 
                             INT *, INT *, INT *, DOUBLE *, DOUBLE *, INT *, INT * );
   INT CALLTYP fema_vmorph_( INT *, INT *, INT *, INT *, DOUBLE *, 
                             INT *, INT *, INT *, DOUBLE *, DOUBLE *, INT *, INT * );
   INT CALLTYP fema_e2morph_( INT *, INT *, INT *, INT *, DOUBLE *, INT *, DOUBLE *,
                              DOUBLE *,  INT *, INT * );
   INT CALLTYP fema_e3morph_( INT *, INT *, INT *, INT *, DOUBLE *, INT *, DOUBLE *,
                              DOUBLE *,  INT *, INT * );
   INT CALLTYP fema_meshvols_( INT *, INT *, INT *, INT *, INT *, INT *, INT * );
   INT CALLTYP fema_xxbounds_( INT *, DOUBLE * );
   void CALLTYP fema_smareas_( INT *, INT *, INT *, INT *);
   void CALLTYP fema_smvols_( INT *, INT *, INT *, INT *, INT * );
   INT  CALLTYP fema_morph2d_setup_( INT *, DOUBLE *, INT *, INT *, INT *, INT *,
	                                 INT *, INT *, INT *, INT * );
   INT  CALLTYP fema_morph3d_setup_( INT *, DOUBLE *, INT *, INT *, INT *, INT *,
	                                 INT *, INT *, INT *, INT * );
   INT  CALLTYP fema_morph_done_( );
   INT  CALLTYP fema_morph2d_( INT *, DOUBLE *, INT *, INT *, DOUBLE *, INT *);
   INT  CALLTYP fema_morph3d_( INT *, DOUBLE *, INT *, INT *, DOUBLE *, INT *);


/* === FORTRAN subroutines called from C */
   INT CALLTYP ndinqr_( INT *, INT * );
   void CALLTYP ledfnd_( INT *, INT *, DOUBLE *, INT *, INT *, INT * );
   void CALLTYP ledfnd1_( INT *, INT *, DOUBLE *, INT *, INT * );
   INT CALLTYP rdinqr_( INT * );
   INT CALLTYP elmiqr_( INT *, INT * );
   INT CALLTYP arliqr_( INT *, INT *, INT * );
   INT CALLTYP numarealooplines_( INT *, INT * );
   INT CALLTYP arviqr_( INT *, INT * );
   INT CALLTYP arnexp_( INT *, INT * );
   INT CALLTYP ndgxyz_( INT *, DOUBLE * );
   INT CALLTYP elmget_( INT *, INT *, INT * );
   INT CALLTYP lsnget_( INT *, INT * );
   void CALLTYP get_ielc_( INT *, INT *, INT * );
   void CALLTYP get_genquad_ielc_( INT *, INT * );
   void CALLTYP get_vol_ielc_( INT *, INT *, INT * );
   void CALLTYP get_vol_size_( INT *, DOUBLE *, INT * );
   void CALLTYP get_area_size_( INT *, DOUBLE *, INT * );
   INT CALLTYP etyget_( INT *, INT * );
   INT CALLTYP tetput_( INT *, INT*, INT*, INT* );
   INT CALLTYP ar2prj_( DOUBLE*, DOUBLE*, DOUBLE*, INT* );
   INT CALLTYP ar3prj_( DOUBLE*, DOUBLE*, DOUBLE*, INT* );
   INT CALLTYP draw_cell2_( INT *, INT *, DOUBLE *, INT *, INT * );
   INT CALLTYP ar3psl_( INT *, INT *, DOUBLE *, INT *,
                        INT *, INT *, DOUBLE *, DOUBLE *);
   void CALLTYP lineevaladd_( INT *, INT *, INT * );
   void CALLTYP lineevalchek_( INT * );
   void CALLTYP lineevalinit_( INT *, INT *, INT * );
   void CALLTYP lineevalinil_( INT *, INT *, INT *, INT *, INT *, INT * );
   void CALLTYP lineevalinic_( INT *, INT *, INT *, INT *, INT *, INT * );
   void CALLTYP lineevalinid_( INT *, INT *, INT * );
   void CALLTYP lineevaldele_();
   void CALLTYP lineevalproj_( INT *, DOUBLE *, DOUBLE *,
                              DOUBLE *, DOUBLE *, INT * );
   void CALLTYP lineevalparm_( INT *, DOUBLE *, DOUBLE *, INT * );
   void CALLTYP lineevalstrt_( INT *, INT * );
   void CALLTYP lineevalok_( INT *, INT * );
   void CALLTYP lineevalremv_( INT * );
   void CALLTYP lineevalcurv_( INT *, DOUBLE *, DOUBLE *, INT * );
   void CALLTYP lineevaltang_( INT *, DOUBLE *, DOUBLE *, INT * );
   void CALLTYP lineevaltgcv_( INT *, DOUBLE *, DOUBLE *, DOUBLE *, INT * );
   void CALLTYP areaevaladd_( INT *, INT *, INT * );
   void CALLTYP areaevaltang_( INT *, DOUBLE *, DOUBLE *, DOUBLE *, INT * );
   void CALLTYP areaevalnorm_( INT *, DOUBLE *, DOUBLE *, DOUBLE *, 
                               DOUBLE *, INT * );
   void CALLTYP areaevalcurv_( INT *, DOUBLE *, DOUBLE *, DOUBLE *, INT * );
   void CALLTYP areaevalnmcv_( INT *, DOUBLE *, DOUBLE *, DOUBLE *, DOUBLE *,
                               DOUBLE *, INT * );
   void CALLTYP areaevalchek_( INT * );
   void CALLTYP areaevalinit_( INT *, INT *, INT * );
   void CALLTYP areaevalparm_( INT *, DOUBLE *, DOUBLE *, DOUBLE *, INT * );
   void CALLTYP areaevalproj_( INT *, DOUBLE *, DOUBLE *, DOUBLE *,
                               DOUBLE *, DOUBLE *, DOUBLE *, INT *);
   void CALLTYP areaevalnprj_( INT *, DOUBLE *, DOUBLE *, DOUBLE *,
                               DOUBLE *, DOUBLE *, DOUBLE *, INT *);
   void CALLTYP areaevallapj_( INT *, DOUBLE *, INT *, INT *, DOUBLE *, 
                               DOUBLE *, DOUBLE *, DOUBLE *, DOUBLE *, INT * );
   void CALLTYP areaevalflat_( INT *, INT * );
   void CALLTYP areaevalanly_( INT *, INT * );
   void CALLTYP areaevaldele_();
   void CALLTYP areaevalok_( INT *, INT * );
   void CALLTYP areaevalbnds_( INT *, DOUBLE *, DOUBLE *, DOUBLE *, DOUBLE *,
                               INT * );
   void CALLTYP areaevalclsd_( INT *, INT *, INT *, INT * );
   INT  CALLTYP area_int_get_( INT *, INT *, INT *);
   INT  CALLTYP area_int_iqr_( INT *, INT *, INT *);
   INT  CALLTYP line_int_iqr_( INT *, INT *, INT *);
   INT  CALLTYP line_int_get_( INT *, INT *, INT *);
   INT CALLTYP lsinqr_( INT *, INT * );
   INT CALLTYP lsniqr_( INT *, INT * );
   void CALLTYP ndpxyz_( INT *, DOUBLE * );
   INT CALLTYP ndinfo_( INT *, INT *, INT * );
   void CALLTYP lsgprj_( INT *, DOUBLE *, DOUBLE * );
   INT CALLTYP kpliqr_( INT *, INT * );
   INT CALLTYP kpinqr_( INT *, INT * );
   INT CALLTYP kplvmx_( INT *, INT * );
   INT CALLTYP kpput_( INT *, INT *, INT *, INT *);
   INT CALLTYP lsliqr_( INT *, INT * );
   INT CALLTYP lsglsl_( INT *, INT *, INT * );
   INT CALLTYP lsaiqr_( INT *, INT * );
   INT CALLTYP lsavmx_( INT *, INT * );
   INT CALLTYP lsavmx2_( INT *, INT * );
   INT CALLTYP arinqr_( INT *, INT * );
   INT CALLTYP araiqr_( INT *, INT * );
   INT CALLTYP arlget_( INT *, INT *, INT * );
   void CALLTYP arealooplines_( INT *, INT *, INT * );
   INT CALLTYP areexp_( INT *, INT * );
   void CALLTYP ndmsme_( INT *, INT *, INT * );
   void CALLTYP qtrput_( INT *, INT *, INT *, INT *,
                         INT *, INT *, INT *, INT * );
   INT CALLTYP erinqr_( INT * );
   void CALLTYP elmsme_( INT *, INT *, INT * );
   void CALLTYP pr7acl_( INT *, INT *, INT *, INT *,
                         INT *, INT *, INT * );
   void CALLTYP fema_setatt_( INT * );
   INT CALLTYP lsnexp_( INT *, INT * );
   void CALLTYP lsndel_( INT * );
   void CALLTYP lsnput_( INT *, INT *, INT * );
   void CALLTYP lsput_( INT *, INT *, INT *, INT * );
   void CALLTYP arndel_( INT * );
   void CALLTYP aredel_( INT * );
   INT CALLTYP arnget_( INT *, INT * );
   void CALLTYP arnput_( INT *, INT *, INT * );
   void CALLTYP areput_( INT *, INT *, INT * );
   void CALLTYP arput_( INT *, INT *, INT *, INT *);
   void CALLTYP vlndel_( INT * );
   void CALLTYP vledel_( INT * );
   void CALLTYP vlnput_( INT *, INT *, INT * );
   void CALLTYP vleput_( INT *, INT *, INT * );
   void CALLTYP vlput_( INT *, INT *, INT *, INT *);
   INT CALLTYP vlaget_( INT *, INT *, INT * );
   INT CALLTYP vlaiqr_( INT *, INT *, INT * );
   void CALLTYP putelm_( INT *, INT *, INT *, INT *, INT *, INT * );
   void CALLTYP putnelm_( INT *, INT *, INT *, INT *, INT *, DOUBLE *, INT * );
   void CALLTYP putelmv_( INT *, INT *, INT *, INT *, DOUBLE *, INT *,
                          DOUBLE *, INT * );
   void CALLTYP enpput_( INT *,  INT *, INT * );
   void CALLTYP getshellthic_( INT *, INT *, DOUBLE *, INT *, INT *, INT *, 
                               INT *, INT *, DOUBLE * );
   void CALLTYP eshapcompute_( INT *, DOUBLE *, INT *, DOUBLE *, DOUBLE * );
   void CALLTYP quadwarpwrap_( INT *, INT *, DOUBLE *, DOUBLE *, DOUBLE *,
                               INT *, INT * );
   void CALLTYP eshaptestwarn_( INT *, INT *, INT *, DOUBLE *, INT *,
                                INT *, INT *, INT * );
   void CALLTYP eshapput_cint_( INT *, DOUBLE *, INT * );
   void CALLTYP midangspa_cint_( INT *, INT *, INT *, DOUBLE *, INT * );
   INT CALLTYP etyiqr_( INT *, INT * );
   INT CALLTYP elxiqr_( INT *, INT * );
   INT CALLTYP elxvmx_( INT *, INT * );
   INT CALLTYP vlinqr_( INT *, INT * );
   INT CALLTYP arvvmx_( INT *, INT * );
   INT CALLTYP arvvmx2_( INT *, INT * );
   INT CALLTYP lsgkpt_( INT *, INT *, INT * );
   INT CALLTYP disiqr_( INT *, INT * );
   INT CALLTYP foriqr_( INT *, INT * );
   void CALLTYP mstatcont_( );
   void CALLTYP mstatupdate_( INT *, INT *, INT * );
   void CALLTYP mstatfinish_();
   void CALLTYP mstatsetup_( INT *, INT * );
   void CALLTYP mstatcheck_( INT *, INT *, INT *, INT * );
   INT CALLTYP mstatactive_( INT * );
   void CALLTYP mstatflush_( );
   void CALLTYP mstattime_( INT *, INT * );
   void CALLTYP grinfo_( INT *, INT * );
   INT CALLTYP grinqr_( INT * );
   void CALLTYP quadck_( INT *, INT *, INT *, DOUBLE *,
                         INT *, INT *, INT *, INT * );
   void CALLTYP trichk_( INT *, INT *, DOUBLE *, INT *, INT * );
   void CALLTYP warpck_( INT *, INT *, INT *, DOUBLE *,
                         DOUBLE *, INT *, INT *);
   INT CALLTYP fema_erhndl_cint_( INT *, INT *, INT *, DOUBLE *, INT *, INT * );
   void CALLTYP fema_getelmdata_( INT *, INT *, INT *, INT *, INT *, INT *, INT * );
   INT CALLTYP fema_geticommon_( INT * );
   void CALLTYP fema_seticommon_( INT *, INT * );
   DOUBLE CALLTYP fema_getdcommon_( INT * );
   DOUBLE CALLTYP fema_getesize_( INT * );
   void CALLTYP fema_deletemem_( );
   void CALLTYP fema_mapquadmesh_( INT *, INT *, INT *, INT *, INT *,
                                   INT *, DOUBLE *, INT *, INT *, INT * );
   void CALLTYP fema_printwarn_( INT *, INT * );
   void CALLTYP fema_getnextids_( INT *, INT * );
   DOUBLE CALLTYP get_shpp_( INT *);
   void CALLTYP refchknode_( INT *, INT *, INT *, INT *, INT * );
   void CALLTYP refchkbfnode_( INT *, INT *, INT *, INT *, INT * );
   void CALLTYP refchkbfelem_( INT *, INT *, INT *, INT * );
   void CALLTYP refchkelem_( INT *, INT *, INT *, INT * );
   void CALLTYP egetea_( INT *, INT *, INT *, INT *, INT *,
                         DOUBLE *, DOUBLE *, INT * );
   void CALLTYP elinfo_( INT *, INT *, INT * ); 
   void CALLTYP elsel_( INT *, INT * );
   void CALLTYP ndsel_( INT *, INT * );
   void CALLTYP rndoff_( DOUBLE *, INT * );
   void CALLTYP vbox_( INT *, DOUBLE *, DOUBLE *, DOUBLE *, DOUBLE * );
   DOUBLE CALLTYP alfund_( INT *, DOUBLE *, DOUBLE * );
   void CALLTYP vnorm_( DOUBLE *, INT * );
   void CALLTYP vmult_( DOUBLE *, DOUBLE *, INT *, DOUBLE * );
   DOUBLE CALLTYP vdot_( DOUBLE *, DOUBLE *, INT * );
   void CALLTYP vamb_( DOUBLE *, DOUBLE *, DOUBLE *, INT * );
   void CALLTYP vapcb1_( DOUBLE *, DOUBLE *, INT *, DOUBLE * );
   void CALLTYP chkprl_( DOUBLE *, DOUBLE *, DOUBLE *, DOUBLE *,
                         DOUBLE *, INT * );
   void CALLTYP ivsrt2_( INT *, INT *, INT *, INT *, INT * );
   INT CALLTYP vleexp_( INT *, INT * );
   void CALLTYP jrtet_( DOUBLE *, DOUBLE * );
   void CALLTYP jrbrwg_( INT *, DOUBLE *, DOUBLE * );
   void CALLTYP p_deg_btran_( INT *, INT *, INT *, INT *, DOUBLE *,
                              INT *, INT * );
   void CALLTYP global_( DOUBLE *, INT *, DOUBLE * );
   void CALLTYP izero_( INT *, INT * );
   void CALLTYP erinfo_( INT *, INT * );
   void CALLTYP lcatlp_( INT *, INT *, INT *, INT *, INT *, INT *, INT *,
                         INT *, INT * );
   void CALLTYP prcstr_( INT *, INT * );
   INT CALLTYP fliget_( INT *, INT * );
   void CALLTYP cmdver_cint_( INT *, INT *, INT * );
   void CALLTYP cmdverall_cint_( INT *, INT *, INT * );
   void CALLTYP fema_trackpoint_( INT *, INT * );
   void CALLTYP fema_trackbegin_( INT *, INT * );
   void CALLTYP fema_trackend_( INT *, INT * );
   void CALLTYP wrinfo_( INT *, INT * );
   INT CALLTYP wrinqr_( INT * );
   INT CALLTYP dbinqr_( INT * );
   INT CALLTYP hepiqr_( INT * );
   void CALLTYP etweak_( INT *, INT * );
   INT CALLTYP face_in_area_( INT *, INT *, INT *, INT * );
   void CALLTYP deg_node_( DOUBLE *, DOUBLE * );
   void CALLTYP tri_to_quad_( INT *, INT *, INT *,  DOUBLE *,  DOUBLE *, INT *, 
                    DOUBLE *, INT *, INT *, INT *, INT *, INT *, INT *,
                    INT *, INT *, INT *, DOUBLE *, INT *, DOUBLE *,
                    INT *, INT *, DOUBLE *, INT *, INT *);
   INT CALLTYP kpggxy_( INT *, DOUBLE * );
   void CALLTYP acatsh_( INT *, INT *, INT *, INT *, INT *, 
                 INT *, INT *, INT *, INT *);
   INT CALLTYP lsgpar_( INT *, INT *, INT *, DOUBLE * );
   INT CALLTYP line_spacing_( INT * );
   INT CALLTYP kpgpar_( INT *, INT *, INT *, DOUBLE * );
   INT CALLTYP lsgnor_( INT *, INT *, INT *, INT *, DOUBLE * );
   void CALLTYP fema_eplo_();
   void CALLTYP ndbdpj_( INT *, DOUBLE *, INT *, INT *, DOUBLE *, INT * );
   void CALLTYP smnenx_( INT *, INT *, INT *, INT *, INT * );
   INT CALLTYP frn_gttess_( INT *, INT *, INT *, INT *, DOUBLE *, DOUBLE *,
                            INT * );
   INT CALLTYP frn_tessiqr_( INT *, INT *, INT *, DOUBLE *, INT *, INT *,
                            INT *, INT * );
   INT CALLTYP araget_( INT *, INT * );
   INT CALLTYP sainqr_( INT *, INT * );
   void CALLTYP frn_lsarprj_( INT *, INT *, DOUBLE *,  DOUBLE *,  DOUBLE *,
                              INT *, INT * );
   void reset_mesh_keys_();
   void set_mesh_keys_( INT *, INT *, INT * );
   INT CALLTYP clearlnskps_( INT *, INT *, INT *, INT * );
   void CALLTYP lmeshvols_cint_( INT *, INT *, INT *, INT * );
   void CALLTYP chkcrk_( INT *, INT *, INT *, INT * );
   void CALLTYP fema_ameshstat_();
   INT CALLTYP get_curtyp( INT *, INT *, INT * );

#endif
