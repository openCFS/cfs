/*
////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         copyright(c) 2011 SAS IP, Inc.  All rights reserved.             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MAT_WriteToFortranUnit.h $
// $Revision: 456485 $ 7.0
// $Date: 2011-03-02 11:45:41 -0500 (Wed, 02 Mar 2011) $ March 01 2005
// $Author: ajkang $ rjayasee
//
// Decription :
//
// Write a command or line to a specific fortran unit
////////////////////////////////////////////////////////////////////////////
*/

#if !defined(MAT_WriteToFortranUnit)
#define MAT_WriteToFortranUnit

                         
#ifdef __cplusplus
extern "C"
{
#endif
    
void MAT_WriteToForUnit( int iUnit,
                             char* pFormat, ... ) ;
/*
//R void
//I oMsgType
//I-Type of Message, whether error,warning...
//I-Look at the defn of MAT_MessageType for the different types
//- This function is the message handler for the Material API
*/

#ifdef __cplusplus
}
#endif

#endif     

