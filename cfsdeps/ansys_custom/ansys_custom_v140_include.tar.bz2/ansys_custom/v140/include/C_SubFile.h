/**
 * @file   C_SubFile.h
 * @author 
 * @date   Thu Apr 10 16:44:40 2008
 * 
 * @brief  
 * 
 */

#ifndef __C_SUBFILE_H__
#define __C_SUBFILE_H__	1

#include "C_AnsysFile.h"
#include "C_MatMGe.h"

/*!
 *  \class	C_SubFile
 *  \brief	
 *  \author	Frederic Thevenon
 *  \version	1.0
 *  \date	2008
 *  \bug	
 *  \warning	
 *
 *  version 1.0 :       Initial Revision
 */

// ======================================================================
// ===== BLOCKS OF THE SUB FILE

//	SUB_HEADER
//	SUB_XFM
//	SUB_CTXM
//	SUB_DOF
//	SUB_DST
//	SUB_POS
//	SUB_ORG
//	SUB_BAC
//	SUB_TIT
//	SUB_NOD
//	SUB_XYZ
//	SUB_EDG
//	SUB_GDF
//	SUB_CG
//	SUB_LOD

class C_SubFile : public C_AnsysFile
{
public:

  enum E_SubHeader {
    E_FUN8=0,		E_NMROW,	E_NMATRX,	E_NEDGE,	E_NUMDOF,	//	5
    E_MAXN,		E_WFMAX,	E_LENBAC,	E_NNOD,		E_KUNSYM,	//	10
    E_KSTF,		E_KMASS,	E_KDAMP,	E_KSS,		E_NVECT,	//	15
    E_NWORKL,		E_LENU1,	E_SESORT,	E_LENLST,	E_PTRLODL,	//	20
    E_NTRANS,		E_PTRMTX,	E_PTRXFM,	E_PTRHED,	E_NAME1,	//	25
    E_NAME2,		E_PTRCGINF,	E_0_28,		E_NAME3,	E_NAME4,	//	30
    E_PTRDOF,		E_PTRDST,	E_PTRBAC,	E_PTRTIT,	E_PTRNOD,	//	35
    E_PTRXYZ,		E_PTREDG,	E_PTRGDF,	E_THSUBS,	E_PTRPOS,	//	40
    E_PTRORG,		E_STFMAX,	E_PTRLODH,	E_NMODES,	E_KEYDIM,	//	45
    E_CMSMETHOD,	E_NAME5,	E_NAME6,	E_NAME7,	E_NAME8,	//	50
    E_NVNODES,		E_PTRCTXM,	E_NWORKH,	E_PTRCG,	E_PTRTVAL,	//	55
    E_0_56,		E_0_57,		E_0_58,		E_PTRENDL,	E_PTRENDH
  };

  CADOE_EXPORT virtual const char *StrType() { return "C_SubFile";}

  CADOE_EXPORT C_SubFile( const _TCHAR *FileName, bool Create = false);
  CADOE_EXPORT ~C_SubFile(void) {};

  CADOE_EXPORT int	SubHeader( E_SubHeader ival) { return _SubHead[ival];}
  CADOE_EXPORT bool	SparseMatrix( void) { return _SparseMatrices;}
  
  CADOE_EXPORT bool MatrixIsOnFile( int numMat);

  template <typename T> CADOE_EXPORT C_Mat<T>	*getMat( int numMat, C_Mat<T> *Mat = NULL, char Format = 'D');
  template <typename T> CADOE_EXPORT void	setMat( int numMat, C_Mat<T> *Mat);

  template <typename T> CADOE_EXPORT C_Vec<T>	*getVec( int IDVec, C_Vec<T> *Vec = NULL, int iVec=1);

  CADOE_EXPORT void	setMat( int numMat, C_Mat<double> &Mat);

  CADOE_EXPORT virtual void	WriteFile( _TCHAR *FileName);
  CADOE_EXPORT void		dumpFile( int kuns);
    
protected:
  C_VecPi<int>	_SubHead;
  bool		_SparseMatrices;
  int		_nmatrx, _nvect, _nmrow;

  map< int, C_Mat<double> *>	_lMat;
  C_Mat<int>			*_RowInfo;
};

template <> C_Mat<int> *C_SubFile::getMat<int>( int numMat, C_Mat<int> *Min, char Format);
template <> void	C_SubFile::setMat<int>( int numMat, C_Mat<int> *Min);

#endif
