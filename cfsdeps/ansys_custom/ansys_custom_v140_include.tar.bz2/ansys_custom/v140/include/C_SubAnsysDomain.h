#ifndef _C_SUBANSYSDOMAIN_H_
#define _C_SUBANSYSDOMAIN_H_

#include "cadoesys.h" 
#include "computer.h" 

#include "FSConnectivity.h" 
#include "AnsysBin.h" 
#include "AnsysElement.h" 
#include "BlockAlloc.h"
#include "FSElement.h"
#include "dds_globals.h"

class C_SubAnsysDomain  
{ 
public: 
  C_SubAnsysDomain(); 
  virtual ~C_SubAnsysDomain(); 
  
  void Init(INT *ivect, INT len1, DOUBLE *dvect, INT len2);
  void setDomains(INT *Domain, INT *Order, INT nDomain);
  void setNodes(DOUBLE *Wrk, INT len);
  void setElem(INT *idump);
  void setRotate(INT *NodeRot, DOUBLE *Nrot, INT num_nrot);
  void releaseFEM();
  
  virtual void Print();
  
protected:  
  int _glNumSub;       	// total number of CPU
  int _localNumSub;    	// current CPU
  
  int _numNodes;	// number of nodes
  int _numEle;		// number of elements
  int _numRot;		// number of 
  
  double (*_coord)[3]; 
  AnsysElement *_contigous_elements; 
  FSElement **_elements; 
  FSCoordSet *_allNodes; 
  
  // rotate nodes
  int *_rotatenode; 
  double (*_rotateval)[3]; 
  
  // allocation
  BlockAlloc _ba; 
};

#endif
