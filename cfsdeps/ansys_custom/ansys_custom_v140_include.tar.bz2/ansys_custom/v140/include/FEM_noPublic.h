/*  FEM_noPublic.h *
 *
 * *** ansys(r) copyright(c) 2009
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_noPublic.h
 *  Prototypes and macros for FEM node data type
 *
 */
/* *** mpg math array c
 FEM_array.c FEM_matrix.c FEM_MeshTable.h FEM_Public.h FEM_array.h
 FEM_array_static.h  FEM_cdbtypes.h FEM_edPublic.h FEM_elPublic.h
 FEM_errors.h FEM_external.h FEM_faPublic.h FEM_matrix.h
 FEM_matrix_static.h FEM_meshTree.h FEM_noGeom.h FEM_noPublic.h
 FEM_publicElementDefinition.h fem_Struct.h
 ansproto.h computer.h float.h globals.h mathfun.h
*/
#ifndef FEM_NOPUBLIC
#define FEM_NOPUBLIC

#include "FEM_cdbtypes.h"
#include "FEM_external.h"

/* === property masks used with the property field in the node */

#ifndef NO_PROPERTY
#define NO_PROPERTY        0
#endif
#define NODE_AT_KP         (1<<0)
#define NODE_ON_LINE       (1<<1)
#define NODE_ON_AREA       (1<<2)
#define NODE_IN_VOLUME     (1<<3)
#define NODE_MOVED         (1<<4)
#define NODE_SMOOTHABLE    (1<<5)
#define NODE_MIDSIDE       (1<<6)
#define NODE_VISITED       (1<<7)
#define NODE_MARKED        (1<<8)
#define NODE_HAS_MBPOINT_VTX_FLAG  (1<<9)
#define NODE_FACE_SELECTED (1<<10)
#define NODE_ELEM_SELECTED (1<<10)
#define NODE_MULTIFRONT    (1<<11)
#define NODE_SMOOTHED      (1<<12)
#define NODE_ON_BOUNDARY   (1<<13)
#define NODE_SMOOTH_NEEDED (1<<14)
#define NODE_OPTI_SMOOTHED (1<<15)
#define NODE_ON_LAYER      (1<<16)
#define NODE_HIGH_SLOPE    (1<<17)
#define NODE_NATIVE        (1<<18)
#define NODE_ON_SEAMLINE   (1<<19)
#define NODE_PERIODIC_TIP  (1<<20)
#define NODE_AT_LINE_END   (1<<20)
#define NODE_ON_BBOX       (1<<21)
#define NODE_UNDELETEABLE  (1<<22)
#define NODE_DEGEN         (1<<23)
#define NODE_CONSTRAINED   (1<<24)  /* means that a node is NEVER movable , permanent flag before it is deleted */
#define NODE_AT_SEAM_END   (1<<25)
#define NODE_NON_MANIFOLD  (1<<26)
#define NODE_OFF_GEOM      (1<<27)
#define NODE_ON_INTERIOR   (1<<28)
#define NODE_AT_QUAD_END   (1<<29)
#define NODE_AT_SWP_DEGEN_CRN (1<<30)
#define NODE_AT_HIGH_CURV  (1<<31)  /* node is located at high curvature point */
/* etc... (maximum 31) */

#define EXIT_CONCAVE        -1

/* === manipulating and inquiring on the linked list object */

#ifdef __cplusplus
extern "C" {
#endif

                           /*=================================================*/
                             /* === FEM_noNewList: create a new node list     */
                             /* === and initialize (FACELIST_OBJ              */
                             /* === constructor)                              */
NODELIST_OBJ FEM_noNewList ( void  );

                           /*=================================================*/
                             /* === FEM_noDeleteList: delete the node list    */
                             /* === (NODELIST_OBJ destructor)                 */
void FEM_noDeleteList (
   NODELIST_OBJ obj_nlist );          /* The node list object                 */

                           /*=================================================*/
                             /* === FEM_noNew: create a new node and add      */
                             /* === it to the node list                       */
                             /* === (NODE_OBJ constructor)                    */
NODE_OBJ FEM_noNew (
   NODELIST_OBJ obj_nlist );           /* The node list object                */

                           /*=================================================*/
                             /* === FEM_noNewInsertAfter: create a new node   */
                             /* === and add it to the node list after the     */
                             /* === specified node in the list                */
                             /* === (NODE_TYP constructor)                    */
NODE_OBJ FEM_noNewInsertAfter(
   NODELIST_OBJ obj_nlist,             /* the node list object                */
   NODE_OBJ obj_node );                /* node in the list to insert after    */
                                       /* (if NULL then insert at beginning)  */

                           /*=================================================*/
                             /* === FEM_noDelete: delete a node and           */
                             /* === remove from list                          */
                             /* === (NODE_OBJ destructor)                     */
void FEM_noDelete (
   NODELIST_OBJ obj_nlist,             /* The node list object                */
   NODE_OBJ obj_node );                /* node object to be deleted           */

                           /*=================================================*/
                             /* === FEM_noMaxId: return max node id in list   */
INT FEM_noMaxId (
   NODELIST_OBJ obj_nlist  );          /* the node list object                */

/* === Node utility functions */

                           /*=================================================*/
                             /* === FEM_noAdEdge: get an adjacent             */
                             /* === edge to the node                          */
EDGE_OBJ FEM_noAdjEdge (
   NODE_OBJ obj_node  );               /* node object                         */

                           /*=================================================*/
                             /* === FEM_noNextAdjFace: get next adjacent      */
                             /* === face to the node                          */
FACE_OBJ FEM_noNextAdjEdge (
   NODE_OBJ obj_node,                  /* node object                         */
   EDGE_OBJ obj_edge  );               /* one of the faces adjacent to node   */

                           /*=================================================*/
                            /* === FEM_noInsertAdjEdge: Insert an adjacent    */
                            /* === edge into the node's adjacency list        */
INT FEM_noInsertAdjEdge (
   NODE_OBJ obj_node,                  /* The node object */
   EDGE_OBJ obj_edge,                  /* edge to add to node's adj list      */
   INT inode  );                       /* index of node on edge */

                           /*=================================================*/
                            /* === FEM_noNextCCWEdge: return next CCW edge    */
                            /* === from last edge (2D topology only)          */
EDGE_OBJ FEM_noNextCCWEdge( 
   NODE_OBJ obj_node,                  /*  The node object */
   EDGE_OBJ obj_edge );                /* Last edge (non-NULL) */

/*==============================================================================
 * === Function: FEM_noNextCCWEdge1
 * === Author: zjc
 * === Description: return the next ccw edge 
 * === Return: INT  EXIT_SUCCESS or EXIT_FAILURE
 *============================================================================*/
EDGE_OBJ FEM_noNextCCWEdge1( 
   NODE_OBJ obj_node, 
   EDGE_OBJ obj_edge,
   FACE_OBJ *pobj_face,  /* refence current face */
   INT *piRefArea );

                           /*=================================================*/
                            /* === FEM_noNextCCWFace: get the next adjacent   */
                            /* === face at the node (looping ccw). Assumes a  */
                            /* === 2D topology i.e. no elements exist - only  */
                            /* === faces edges and nodes and all faces ordered*/
                            /* === consistently                               */
FACE_OBJ FEM_noNextCCWFace (
   NODE_OBJ obj_node,                  /* the node object                     */
   FACE_OBJ obj_face );                /* a face object adjacent to the node  */
                                       /* (or NULL)                           */

FACE_OBJ FEM_noNextCCWAreaFace(
   NODE_OBJ obj_node,        /* the node object */
   FACE_OBJ obj_face,        /* a face object adjacent to the node (or NULL) */
	INT area) ;
                           /*=================================================*/
                            /* === FEM_noQuads: return a list of quads        */
                            /* === attached to the node in no particular      */
                            /* === order (no tris)                            */
INT FEM_noQuads (
   NODE_OBJ obj_node,                  /* the node object                     */
   INT *num_faces,                     /* number of faces in list             */
   INT max_faces,                      /* size of the aobj_faces array        */
   FACE_OBJ *aobj_faces  );            /* list of faces adjacent to node      */

                           /*=================================================*/
                            /* === FEM_noFaces: return a list of faces        */
                            /* === attached to the node in no particular      */
                            /* === order                                      */
INT FEM_noFaces (
   NODE_OBJ obj_node,                  /* the node object                     */
   INT *num_faces,                     /* number of faces in list             */
   INT max_faces,                      /* size of the aobj_faces array        */
   FACE_OBJ *aobj_faces  );            /* list of faces adjacent to node      */

                           /*=================================================*/
                            /* === FEM_noSurfFaces: same as FEM_noFaces       */
                            /* === but excludes any faces marked as           */
                            /* === FACE_IN_VOLUME                             */
INT FEM_noSurfFaces (
   NODE_OBJ obj_node,                  /* the node object                     */
   INT anum,                           /* area number                         */
   INT *num_faces,                     /* number of faces in list             */
   INT max_faces,                      /* size of the aobj_faces array        */
   FACE_OBJ *aobj_faces  );            /* list of faces adjacent to node      */



                           /*=================================================*/
                            /* === FEM_noEdges: return a list of edges        */
                            /* === attached to the node in no particular      */
                            /* === order                                      */
INT FEM_noEdges (
   NODE_OBJ obj_node,             /* (IN) the node object                     */
   INT *num_edges,                /* (OUT)number of edges in list             */
   INT max_edges,                 /* (IN)size of the aobj_edges array        */
   EDGE_OBJ *aobj_edges  );       /* (OUT list of edges adjacent to node      */

#ifndef STANDALONE_DELAUNAY
                           /*=================================================*/
                            /* === FEM_noElements: return a list of elements  */
                            /* === attached to the node in no particular      */
                            /* === order.                                     */
INT FEM_noElements (
   NODE_OBJ obj_node,                  /* the node object                     */
   INT *num_elems,                     /* number of elements in list          */
   INT max_elems,                      /* size of the aobj_elems array        */
   ELEMENT_OBJ *aobj_elems  );         /* list of elements adjacent to node   */
#endif

                           /*=================================================*/
                            /* === FEM_noAdjElement: return a single arbitrary*/
                            /* === element adjacent to this node. This is     */
                            /* === useful if you simply need to know that     */
                            /* === there are elements adjacent but do not     */
                            /* === care how many or specifics about them.     */
ELEMENT_OBJ FEM_noAdjElement (
   NODE_OBJ obj_node  );    /* the node object                                */

                           /*=================================================*/
                            /* === FEM_noRemoveUnconnectedNodes: remove any   */
                            /* === nodes from the list that don't have any    */
                            /* === edges connected to them                    */
INT FEM_noRemoveUnconnectedNodes (
   NODELIST_OBJ obj_nlist  );          /* the node list object                */

                           /*=================================================*/
                            /* === FEM_noEdge: given two nodes on an edge,    */
                            /* === return the edge. (NULL if the two nodes    */
                            /* === don't form an edge)                        */
EDGE_OBJ FEM_noEdge (
   NODE_OBJ obj_node0,                 /* node object on edge                 */
   NODE_OBJ obj_node1  );              /* the other node object on edge       */

                           /*=================================================*/
                            /* === FEM_noFace: given three/four nodes on a    */
                            /* === face, return the face. (NULL if the 3/4    */
                            /* === nodes don't form a face)                   */
                            /* === Nodes must be in order (CW or CCW) on face */
FACE_OBJ FEM_noFace(
   NODE_OBJ obj_node0,
   NODE_OBJ obj_node1,
   NODE_OBJ obj_node2,
   NODE_OBJ obj_node3 );               /* should be NULL if looking for tri   */    

                           /*=================================================*/
                            /* === FEM_noNumEdges: return the number of edges */
                            /* === attached to a node                         */
INT FEM_noNumEdges (
   NODE_OBJ obj_node  );               /* the node object                     */

                           /*=================================================*/
                            /* === FEM_noNumEdgesInArea: return the number of */
                            /* === edges connected to a node that are in or   */
                            /* === on a line defining an area.                */
INT FEM_noNumEdgesInArea (
   NODE_OBJ obj_node,         /* the NODE_OBJ */
   INT area  );               /* the area the counted edges are in or next to */

                           /*=================================================*/
                            /* === FEM_noNumEdgesOnAreaBnd: return the number */
                            /* === of edges connected to a node that are on a */
                            /* === line defining an area.                     */
INT FEM_noNumEdgesOnAreaBnd (
   NODE_OBJ obj_node,         /* the NODE_OBJ */
   INT area  );               /* the area the counted edges are in or next to */

                           /*=================================================*/
                            /* === FEM_noNumEdgesOnAreaMeshBnd: return the number */
                            /* === of edges connected to a node that are on the */
                            /* === the boundary of a area mesh.                     */
INT FEM_noNumEdgesOnAreaMeshBnd(
   NODE_OBJ obj_node, /* the NODE_OBJ */
   INT area );         /* the area the counted edges are next to */
                           /*=================================================*/
                            /* === FEM_noNumFacesInArea: return the number of */
                            /* === faces connected to a node that are in or   */
                            /* === on a line defining an area.                */
INT FEM_noNumFacesInArea (
   NODE_OBJ obj_node,         /* the NODE_OBJ */
   INT area  );               /* the area the counted faces are in or next to */

                           /*=================================================*/
                            /* === FEM_noAngleBetween3Nodes: return the angle */
                            /* === between 3 nodes in 3-space                 */
DOUBLE FEM_noAngleBetween3Nodes ( 
   NODE_OBJ obj_node1,            /* one node object */
   NODE_OBJ obj_node2,            /* one node object */
   NODE_OBJ obj_node3  );         /* one node object */

                           /*=================================================*/
                            /* === FEM_noCosAngleBetween3Nodes: return the angle */
                            /* === between 3 nodes in 3-space                 */
DOUBLE FEM_noCosAngleBetween3Nodes ( 
   NODE_OBJ obj_node1,            /* one node object */
   NODE_OBJ obj_node2,            /* one node object */
   NODE_OBJ obj_node3  );         /* one node object */

                           /*=================================================*/
                            /* === FEM_noNorm3Nodes: return the angle normal  */
                            /* === defined by 3 nodes in 3-space              */
VECTOR3D FEM_noNorm3Nodes ( 
   NODE_OBJ obj_node1,            /* one node object */
   NODE_OBJ obj_node2,            /* one node object */
   NODE_OBJ obj_node3,            /* one node object */
   FEM_BOOLEAN *undefined );      /* (OUT) TRUE if zero area triangle. */

							/*=================================================*/
                            /* === FEM_noFaceNorm: return the normal at node  */
                            /* === defined by adj face normal                 */
INT FEM_noFaceNorm(
	NODE_OBJ obj_node,
	INT		 iAreaId,
	DOUBLE	 *pdX,
	DOUBLE	 *pdY,
	DOUBLE	 *pdZ );

                           /*=================================================*/
                            /* === FEM_noIsProject: determines if the third   */
                            /* === node is exactly at the center of the first */
                            /* === 2 nodes.  If it is not, then chances are   */
                            /* === that the third node has been projected to  */
                            /* === the surface                                */
FEM_BOOLEAN FEM_noIsProjected (
   NODE_OBJ obj_node0,      /* first end node */
   NODE_OBJ obj_node1,      /* second end node */
   NODE_OBJ obj_midnode  ); /* node situated between the first and second */

                           /*=================================================*/
                            /* === FEM_noIsBoundaryNode: determines if this  */
                            /* === node lies on the boundary of an area or   */
                            /* === volume                                    */
FEM_BOOLEAN FEM_noIsBoundaryNode (
   NODE_OBJ obj_node,       /* node object */
   INT dimen  );            /* 2 if using areas, 3 if using volumes          */

                            /* ============================================== */
                            /* === FEM_noOppositeNodeOnBoundary: See if any   */
                            /* === nodes that share edges with obj_node are   */
                            /* === boundary nodes.                            */
FEM_BOOLEAN FEM_noOppositeNodeOnBoundary (
   NODE_OBJ obj_node  );    /* the node */

                           /*=================================================*/
                           /* === FEM_noPlaceAtFront: Given a PROPERTY and a  */
                           /* === geo_entity, place all nodes in the node     */
                           /* === list with this property and geo_entity (if  */
                           /* === necessary ) at the front of the list.       */
INT FEM_noPlaceAtFront (
   NODELIST_OBJ obj_ellist,/* node list to rearrange                          */
   FEM_LONG property,      /* property to rearrange on                        */
   INT geo_entity  );      /* geo_entity to rearrange on                      */

                           /*=================================================*/
                           /* === FEM_noPlaceAtFront2: Given a PROPERTY       */
                           /* === (property1) and a geo_entity, place all     */
                           /* === nodes in the node list with this property   */
                           /* === and geo_entity (if necessary ) at the front */
                           /* === of the list except for nodes that have      */
                           /* === property2.                                  */
INT FEM_noPlaceAtFront2(
   NODELIST_OBJ obj_nolist, /* node list to rearrange                         */
   FEM_LONG property1,      /* property to rearrange on                       */
   INT geo_entity,          /* geo_entity to rearrange on                     */
   FEM_LONG property2 );    /* property that overrides property1 so a node
                               does not get moved.                            */

                           /*=================================================*/
                           /* === FEM_noMoveNodeToFront: move a single node   */
                           /* === to the front of the list                    */
INT FEM_noMoveNodeToFront (
   NODELIST_OBJ obj_nlist,             /* the node list                       */
   NODE_OBJ obj_node  );               /* node to place at front              */


                           /*=================================================*/
                           /* === FEM_noMoveNodeToList: move a single node    */
                           /* === from one list to another                    */
INT FEM_noMoveNodeToList(
   NODELIST_OBJ obj_srclist,           /* the source node list */
   NODELIST_OBJ obj_destlist,          /* the destination list */
   NODE_OBJ obj_node );                /* the node object */

/* === Node hashing */

                           /*=================================================*/
                            /* === FEM_noInitHashTable: initialize the node   */
                            /* === hash table                                 */
INT FEM_noInitHashTable (
   NODELIST_OBJ obj_nlist,             /* nodelist associated with hash table */
   INT size  );                        /* approx size of table                */

                           /*=================================================*/
                           /* === FEM_noDoesHashTableExist: returns TRUE if   */
                           /* === the node list is hashed                     */

FEM_BOOLEAN FEM_noDoesHashTableExist(
   NODELIST_OBJ obj_nlist );      /* the source node list */

                           /*=================================================*/
                            /* === FEM_noDeleteHashTable: delete hash table   */
INT FEM_noDeleteHashTable (
   NODELIST_OBJ obj_nlist  );          /* nodelist associated with hash table */

                           /*=================================================*/
                           /* === FEM_noRehash: Rehash the hashtable to a new */
                           /* === size to better fit the current size of the  */
                           /* === hashtable.                                  */
INT FEM_noRehash (
   NODELIST_OBJ obj_nlist  );          /* nodelist associated with hash table */


                           /*=================================================*/
                            /* === FEM_noGetHashNode: retreive a node from    */
                            /* === the hash table using its node number.      */
                            /* === Return NULL if it does not exist           */
NODE_OBJ FEM_noGetHashNode (
   NODELIST_OBJ obj_nlist,             /* the node list object                */
   INT node_id  );                     /* the node id (hashes on node ids)    */

                           /*=================================================*/
                            /* === FEM_noHashNode: hash a node into table     */
                            /* === Return NULL if hash table does not exist   */
NODE_OBJ FEM_noHashNode (
   NODELIST_OBJ obj_nlist,             /* the node list object                */
   INT node_id,                        /* the node id (hashes on node ids)    */
   INT *new_node  );                   /* return 1 if new node in the table   */

                           /*=================================================*/
                            /* === FEM_noHashNode2: hash a node into table    */
INT FEM_noHashNode2 (
   NODELIST_OBJ obj_nlist,             /* the node list object                */
   NODE_OBJ obj_node );                /* the node to hash.                   */

                           /*=================================================*/
                            /* === FEM_noDeleteHashNode: delete a node from   */
                            /* === the node list object's hash table          */
INT FEM_noDeleteHashNode (
   NODELIST_OBJ obj_nlist,             /* The node list object                */
   NODE_OBJ obj_node  );               /* node to delete from hash table      */


                           /*=================================================*/
                           /* === FEM_noFindNodeXYZ: Given an xyz location,   */
                           /* === find the closest node to it within a        */
                           /* === tolerance that has a specified property.    */
                           /* === Return: INT  EXIT_SUCCESS or EXIT_FAILURE   */
INT FEM_noFindNodeXYZ(
   NODELIST_OBJ obj_nlist,      /* (IN) nodelist object                       */
   DOUBLE a_xyz[3],             /* (IN) xyz location to match                 */
   DOUBLE tolerance,            /* (IN)  size of bounding box to use.  Node   */
                                /*       not in this bounding box size will   */
                                /*       not be considered.                   */
   FEM_LONG property,           /* (IN)  single property that node must have  */
                                /*       to be considered.                    */
   NODE_OBJ *obj_closenode );   /* (OUT) the node that was found.             */

                           /*=================================================*/
                            /* === FEM_noSaveGenPtrs: save generic pointers   */
                            /* === of the node list in a deque                */
INT FEM_noSaveGenPtrs (
   DEQUE_OBJ  *obj_deque );            /* save generic pointers to obj_deque  */


                           /*=================================================*/
                            /* === FEM_noResetGenPtrs: reset node generic     */
                            /* === pointers from deque elements               */
INT FEM_noResetGenPtrs (
   DEQUE_OBJ  *obj_deque );            /* deque with generic pointer data     */

                           /*=================================================*/
                            /* === FEM_noVector: compute vector from obj_node0*/
                            /* === to obj_node1 (not normalized)              */
/* for debug purpose
 void FEM_noSetId_C ( NODE_OBJ obj_node, INT node_id  );*/
INT FEM_noVector (        
   NODE_OBJ obj_node0,      
   NODE_OBJ obj_node1,
   VECTOR3D *ps_vec  );

                           /*=================================================*/
                            /* === FEM_noDist2: compute distance squared      */
                            /* === between two nodes                          */
DOUBLE FEM_noDist2 ( 
   NODE_OBJ obj_n0, 
   NODE_OBJ obj_n1  );

                           /*=================================================*/
                            /* === FEM_noUVDist2: compute parametric distance */
                            /* === squared between two nodes                  */
DOUBLE FEM_noUVDist2 ( 
   NODE_OBJ obj_n0, 
   NODE_OBJ obj_n1  );

                           /*=================================================*/
                           /* === FEM_noSetAdjElemProp: Given a node, set a   */
                           /* === property in all adjacent elements.          */
                           /* === Return: INT EXIT_SUCCESS or EXIT_FAILURE    */
INT FEM_noSetAdjElemProp(
   NODE_OBJ obj_node,           /* (IN)  the node object */
   FEM_LONG property_mask,      /* (IN)  the property to set. */
   FEM_BOOLEAN status );        /* (IN)  the new value of the property */

                           /*=================================================*/
                           /* === FEM_noSetAdjFaceProp: Given a node, set a   */
                           /* === property in all adjacent faces.             */
                           /* === Return: INT EXIT_SUCCESS or EXIT_FAILURE    */
INT FEM_noSetAdjFaceProp(
   NODE_OBJ obj_node,           /* (IN)  the node object */
   FEM_LONG property_mask,      /* (IN)  the property to set. */
   FEM_BOOLEAN status );        /* (IN)  the new value of the property */

                           /*=================================================*/
                            /* === FEM_noMergeTwoNodes: merge two nodes       */

INT FEM_noMergeTwoNodes ( 
   NODE_OBJ obj_node,           /* (IN)  the node object       */
   NODE_OBJ obj_otherNode,      /* (IN)  the other node object */
   FACE_OBJ *pobj_faces  );     /* (OUT ) newly created faces  */


FEM_BOOLEAN FEM_noCanMergeTwoNodes (
   NODE_OBJ obj_nodeKept,
   NODE_OBJ obj_nodeRemoved );

FEM_BOOLEAN FEM_noCanMoveNode (
   NODE_OBJ obj_node,
   DOUBLE   adXYZNew[3],
   INT      iCrossBnd );
                           /*=================================================*/
                           /* === FEM_noMaxMinEdges: Given a node return edges*/
                           /* === of extream                                  */
                           /* === Return: INT EXIT_SUCCESS or EXIT_FAILURE    */
INT FEM_noMaxMinEdges(
   NODE_OBJ obj_node,           /* (IN) the node */
   INT checkFaceHeight,         /* (IN) if check face height */
   EDGE_OBJ *pobj_maxEdge,      /* (OUT) the longest edge */
   EDGE_OBJ *pobj_minEdge,      /* (OUT) the shortest edge */
   DOUBLE *pdMaxEdgeLength2,    /* (OUT) the length of the longest edge */
   DOUBLE *pdMinEdgeLength2,    /* (OUT) the length of the shortest edge */
   INT *piMinEdgeLenFromFace,   /* (OUT) is the shortest length from face height */
   FACE_OBJ *pobj_face);        /* (OUT) if from the height, this is the face */


                           /*=================================================*/
                           /* === FEM_noAdjToArea: Given a node on a line,    */
                           /* === See if it is adjacent to a particular area. */
                           /* === Return: INT EXIT_SUCCESS or EXIT_FAILURE    */
INT FEM_noAdjToArea(
   NODE_OBJ obj_node,           /* (IN)  the node object */
   INT anum,                    /* (IN)  an area number. */
   FEM_BOOLEAN *adjacent );     /* (OUT) TRUE if this node is adjacent to anum*/

void FEM_noCircumCircle (
   NODE_OBJ obj_node0,
   NODE_OBJ obj_node1,
   NODE_OBJ obj_node2,
   DOUBLE   *p_radius,                 /* radius                              */
   VECTOR3D *p_center );

                     /* === FEM_noClearGenericPointers: Set all generic*/
                            /* === pointers in obj_nlist to NULL              */
void FEM_noClearGenericPointers (
   NODELIST_OBJ obj_nlist  );
                            /*=================================================*/
                            /* === FEM_noIsAtWeldSpot: Given a node detect if it */
                            /* === is a node at weld spot */
									 /* === return: TRUE for node is at weld spot */
FEM_BOOLEAN FEM_noIsAtWeldSpot(NODE_OBJ obj_node, /* (IN) the node */
										 INT *status );     /* (out) status */
INT FEM_noIsInverted(
   NODE_OBJ obj_node,          /* current smooth node */
   INT area_id,
   INT *pInverted );

INT FEM_noAdjAreaNodes( 
    NODE_OBJ obj_node, /* the node */
    INT area,  /* the area */
    INT *iNumNode,  /* out, num adj nodes */
    NODE_OBJ *aobj_nodes ) /* node list */;

INT FEM_noDel2EdgedNode( 
    NODE_OBJ obj_node);
#ifdef __cplusplus
}
#endif

/*
 * === Node Macros
 */

/*
 * --- The function definition of the node macros can be used instead of 
 * --- the macros themselves by including -D NO_NODE_MACRO on the
 * --- compile line.  The equivalent functions are found in FEM_noPublicMacro.c
 * --- Note: When adding a Macro - make sure the prototype and the macro
 * ---       appear in this file.  
 */
#ifndef NO_NODE_MAC
#include "fem_Struct.h"
#endif

/*============================================================================*/
/* === Macro: FEM_noNext_C
 * === Author: sjo
 * === Description: return the next node in the linked list of nodes
 * === Arguments:
 *     NODE_OBJ obj_node          current node in list
 * === Return: NODE_OBJ              next node in list
 *             NULL if macro not defined for g_meshtype
 */
#ifdef NO_NODE_MAC
NODE_OBJ FEM_noNext_C ( NODE_OBJ obj_node  );
#else
#define FEM_noNext_C( obj_node )\
   ((g_meshtype == STANDARD_MESH) ?\
      (NODE_OBJ)(((NODE_PTYP)(obj_node))->ps_next) :\
   NULL)
#endif

/*============================================================================*/
/* === Macro:  FEM_noPrevious_C
 * === Author: sjo
 * === Description: get the previous node in the linked list object
 * === Arguments:
 *     NODE_OBJ obj_element          current node in list
 * === Return: NODE_OBJ              previous node in list
 *             NULL if macro not defined for g_meshtype
 */
#ifdef NO_NODE_MAC
NODE_OBJ FEM_noPrevious_C ( NODE_OBJ obj_node  );
#else
#define FEM_noPrevious_C( obj_node )\
   ((g_meshtype == STANDARD_MESH) ?\
      (NODE_OBJ)(((NODE_PTYP)(obj_node))->ps_previous) :\
   NULL)
#endif

/*============================================================================*/
/* === Macro: FEM_noTotal_C
 * === Author: sjo
 * === Description: get the total number of nodes in list
 * === Arguments:
 *     NODELIST_OBJ obj_nlist   The node list
 * === Return: INT              total number of nodes in list
 *             -1 if macro not defined for g_meshtype
 */
#ifdef NO_NODE_MAC
INT FEM_noTotal_C ( NODELIST_OBJ obj_nlist  );
#else
#define FEM_noTotal_C( obj_nlist )\
   ((g_meshtype == STANDARD_MESH) ?\
      (INT)(((NODELIST_PTYP)(obj_nlist))->total) :\
   -1)
#endif

/*============================================================================*/
/* === Macro: FEM_noList_C
 * === Author: sjo
 * === Description: return the head of the node linked list
 * === Arguments:
 *     NODELIST_OBJ obj_nlist      node list
 * === Return: NODE_OBJ            head of node list
 *             NULL if macro not defined for g_meshtype
 */
#ifdef NO_NODE_MAC
NODE_OBJ FEM_noList_C ( NODELIST_OBJ obj_nlist  );
#else
#define FEM_noList_C( obj_nlist )\
   ((g_meshtype == STANDARD_MESH) ?\
      (NODE_OBJ)(((NODELIST_PTYP)(obj_nlist))->ps_list) :\
   NULL)
#endif

/*============================================================================*/
/* === Macro: FEM_noId_C
 * === Author: sjo
 * === Description: return the node id
 * === Arguments:
 *     NODE_OBJ obj_node        node object
 * === Return: INT              node id
 *             -1 if macro not defined for g_meshtype
 */
#ifdef NO_NODE_MAC
INT FEM_noId_C ( NODE_OBJ obj_node  );
#else
#define FEM_noId_C( obj_node )\
   ((g_meshtype == STANDARD_MESH) ?\
      (INT)(((NODE_PTYP)(obj_node))->id) :\
   -1)
#endif

/*============================================================================*/
/* === Macro: FEM_noSetId_C
 * === Author: sjo
 * === Description: set the node id
 * === Arguments:
 *     NODE_OBJ obj_node      node object
 *     INT node_id            the new node id
 * === Return: nothing
 */
#ifdef NO_NODE_MAC
void FEM_noSetId_C ( NODE_OBJ obj_node, INT node_id  );
#else
#define FEM_noSetId_C( obj_node, node_id )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((NODE_PTYP)(obj_node))->id = (INT)node_id;\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }
#endif

/*============================================================================*/
/* === Macro: FEM_noX_C
 * === Author: sjo
 * === Description: return the x coordinate of node
 * === Arguments:
 *     NODE_OBJ obj_node   node object
 * === Return: DDOUBLE       X coordinate
 */
#ifdef NO_NODE_MAC
DDOUBLE FEM_noX_C ( NODE_OBJ obj_node  );
#else
#define FEM_noX_C( obj_node )\
   ((g_meshtype == STANDARD_MESH) ?\
      (DDOUBLE)(((NODE_PTYP)(obj_node))->x) :\
   -999.0)
#endif

/*============================================================================*/
/* === Macro: FEM_noY_C
 * === Author: sjo
 * === Description: return the y coordinate of node
 * === Arguments:
 *     NODE_OBJ obj_node   node object
 * === Return: DDOUBLE       Y coordinate
 */
#ifdef NO_NODE_MAC
DDOUBLE FEM_noY_C ( NODE_OBJ obj_node  );
#else
#define FEM_noY_C( obj_node )\
   ((g_meshtype == STANDARD_MESH) ?\
      (DDOUBLE)(((NODE_PTYP)(obj_node))->y) :\
   -999.0)
#endif

/*============================================================================*/
/* === Macro: FEM_noZ_C
 * === Author: sjo
 * === Description: return the z coordinate of node
 * === Arguments:
 *     NODE_OBJ obj_node   node object
 * === Return: DDOUBLE       Z coordinate
 */
#ifdef NO_NODE_MAC
DDOUBLE FEM_noZ_C ( NODE_OBJ obj_node  );
#else
#define FEM_noZ_C( obj_node )\
   ((g_meshtype == STANDARD_MESH) ?\
      (DDOUBLE)(((NODE_PTYP)(obj_node))->z) :\
   -999.0)
#endif

/*============================================================================*/
/* === Macro: FEM_noXYZ_C
 * === Author: sjo
 * === Description: return the x,y and z coordinate of node
 * === Arguments:
 *     NODE_OBJ obj_node   node object
 *     DDOUBLE *xVal, *yVal, *zVal;    *** address *** of coordinates
 * === Return: nothing
 */
#ifdef NO_NODE_MAC
void FEM_noXYZ_C ( NODE_OBJ obj_node,
                            DDOUBLE *xVal, DDOUBLE *yVal, DDOUBLE *zVal  );
#else
#define FEM_noXYZ_C( obj_node, xVal, yVal, zVal )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         *(xVal) = (DDOUBLE)(((NODE_PTYP)(obj_node))->x);\
         *(yVal) = (DDOUBLE)(((NODE_PTYP)(obj_node))->y);\
         *(zVal) = (DDOUBLE)(((NODE_PTYP)(obj_node))->z);\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }
#endif

/*============================================================================*/
/* === Macro: FEM_noaXYZ_C
 * === Author: jrt
 * === Description: return the x,y and z coordinate of node
 * === Arguments:
 *     NODE_OBJ obj_node   node object
 *     DDOUBLE xyz;    *** address *** of coordinates
 * === Return: nothing
 */
#define FEM_noaXYZ_C(  obj_node,  xyz )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
          FEM_noXYZ_C( obj_node, &xyz[0], &xyz[1], &xyz[2] );\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }

/*============================================================================*/
/* === Macro: FEM_noaSetXYZ_C
 * === Author: jrt
 * === Description: return the x,y and z coordinate of node
 * === Arguments:
 *     NODE_OBJ obj_node   node object
 *     DDOUBLE xyz;    *** address *** of coordinates
 * === Return: nothing
 */
#define FEM_noaSetXYZ_C(  obj_node,  xyz )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
          FEM_noSetXYZ_C( obj_node, xyz[0], xyz[1], xyz[2] );\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }

/*============================================================================*/
/* === Macro: FEM_nopvXYZ_C
 * === Author: jrt
 * === Description: return the x,y and z coordinate of node
 * === Arguments:
 *     NODE_OBJ obj_node   node object
 *     DDOUBLE xyz;    *** address *** of coordinates
 * === Return: nothing
 */
#define FEM_nopvXYZ_C(  obj_node,  ps_xyz )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
          FEM_noXYZ_C( obj_node, &(ps_xyz->x), &(ps_xyz->y), &(ps_xyz->z) );\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }

/*============================================================================*/
/* === Macro: FEM_nopvSetXYZ_C
 * === Author: jrt
 * === Description: return the x,y and z coordinate of node
 * === Arguments:
 *     NODE_OBJ obj_node   node object
 *     DDOUBLE xyz;    *** address *** of coordinates
 * === Return: nothing
 */
#define FEM_nopvSetXYZ_C(  obj_node,  ps_xyz )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
          FEM_noXYZ_C( obj_node, (ps_xyz->x), (ps_xyz->y), (ps_xyz->z) );\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }

/*============================================================================*/
/* === Macro: FEM_novXYZ_C
 * === Author: jrt
 * === Description: return the x,y and z coordinate of node
 * === Arguments:
 *     NODE_OBJ obj_node   node object
 *     DDOUBLE xyz;    *** address *** of coordinates
 * === Return: nothing
 */
#define FEM_novXYZ_C(  obj_node,  s_xyz )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
          FEM_noXYZ_C( obj_node, &(s_xyz.x), &(s_xyz.y), &(s_xyz.z) );\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }

/*============================================================================*/
/* === Macro: FEM_novSetXYZ_C
 * === Author: jrt
 * === Description: return the x,y and z coordinate of node
 * === Arguments:
 *     NODE_OBJ obj_node   node object
 *     DDOUBLE xyz;    *** address *** of coordinates
 * === Return: nothing
 */
#define FEM_novSetXYZ_C(  obj_node,  s_xyz )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
          FEM_noSetXYZ_C( obj_node, (s_xyz.x), (s_xyz.y), (s_xyz.z) );\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }

/*============================================================================*/
/* === Macro: FEM_noSetX_C
 * === Author: sjo
 * === Description: set the X coordinate of node
 * === Arguments:
 *     NODE_OBJ obj_node     node object
 *     DDOUBLE x                the new x coordinate
 * === Return: nothing
 */
#ifdef NO_NODE_MAC
void FEM_noSetX_C ( NODE_OBJ obj_node, DDOUBLE xVal  );
#else
#define FEM_noSetX_C( obj_node, xVal )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((NODE_PTYP)(obj_node))->x = (DDOUBLE)(xVal);\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }
#endif

/*============================================================================*/
/* === Macro: FEM_noSetY_C
 * === Author: sjo
 * === Description: set the y coordinate of node
 * === Arguments:
 *     NODE_OBJ obj_node     node object
 *     DDOUBLE y                the new y coordinate
 * === Return: nothing
 */
#ifdef NO_NODE_MAC
void FEM_noSetY_C ( NODE_OBJ obj_node, DDOUBLE yVal  );
#else
#define FEM_noSetY_C( obj_node, yVal )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((NODE_PTYP)(obj_node))->y = (DDOUBLE)(yVal);\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }
#endif

/*============================================================================*/
/* === Macro: FEM_noSetZ_C
 * === Author: sjo
 * === Description: set the Z coordinate of node
 * === Arguments:
 *     NODE_OBJ obj_node     node object
 *     DDOUBLE z                the new z coordinate
 * === Return: nothing
 */
#ifdef NO_NODE_MAC
void FEM_noSetZ_C ( NODE_OBJ obj_node, DDOUBLE zVal  );
#else
#define FEM_noSetZ_C( obj_node, zVal )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((NODE_PTYP)(obj_node))->z = (DDOUBLE)(zVal);\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }
#endif

/*============================================================================*/
/* === Macro: FEM_noSetXYZ_C
 * === Author: sjo
 * === Description: set the coordinates of node
 * === Arguments:
 *     NODE_OBJ obj_node     node object
 *     DDOUBLE x,y,z            the new coordinates
 * === Return: nothing
 */
#ifdef NO_NODE_MAC
void FEM_noSetXYZ_C ( NODE_OBJ obj_node,
                               DDOUBLE xVal, DDOUBLE yVal, DDOUBLE zVal  );
#else
#define FEM_noSetXYZ_C( obj_node, xVal, yVal, zVal )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((NODE_PTYP)(obj_node))->x = (DDOUBLE)(xVal);\
         ((NODE_PTYP)(obj_node))->y = (DDOUBLE)(yVal);\
         ((NODE_PTYP)(obj_node))->z = (DDOUBLE)(zVal);\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }
#endif

/*============================================================================*/
/* === Macro: FEM_noS_C
 * === Author: jrt
 * === Description: return the s parameter of node
 * === Arguments:
 *     NODE_OBJ obj_node   node object
 * === Return: DDOUBLE       s parameter
 */
#ifdef NO_NODE_MAC
DDOUBLE FEM_noS_C ( NODE_OBJ obj_node  );
#else
#define FEM_noS_C( obj_node )\
   ((g_meshtype == STANDARD_MESH) ?\
      (DDOUBLE)(((NODE_PTYP)(obj_node))->s) :\
   -999.0)
#endif

/*============================================================================*/
/* === Macro: FEM_noU_C
 * === Author: sjo
 * === Description: return the u coordinate of node
 * === Arguments:
 *     NODE_OBJ obj_node   node object
 * === Return: DDOUBLE       U coordinate
 */
#ifdef NO_NODE_MAC
DDOUBLE FEM_noU_C ( NODE_OBJ obj_node  );
#else
#define FEM_noU_C( obj_node )\
   ((g_meshtype == STANDARD_MESH) ?\
      (DDOUBLE)(((NODE_PTYP)(obj_node))->u) :\
   -999.0)
#endif

/*============================================================================*/
/* === Macro: FEM_noV_C
 * === Author: sjo
 * === Description: return the v coordinate of node
 * === Arguments:
 *     NODE_OBJ obj_node   node object
 * === Return: DDOUBLE       V coordinate
 */
#ifdef NO_NODE_MAC
DDOUBLE FEM_noV_C ( NODE_OBJ obj_node  );
#else
#define FEM_noV_C( obj_node )\
   ((g_meshtype == STANDARD_MESH) ?\
      (DDOUBLE)(((NODE_PTYP)(obj_node))->v) :\
   -999.0)
#endif

/*============================================================================*/
/* === Macro: FEM_noUV_C
 * === Author: sjo
 * === Description: return the u,v coordinates of node
 * === Arguments:
 *     NODE_OBJ obj_node   node object
 *     DDOUBLE *uVal, *vVal    *** address *** of coordinates
 * === Return: nothing
 */
#ifdef NO_NODE_MAC
void FEM_noUV_C ( NODE_OBJ obj_node,
                            DDOUBLE *uVal, DDOUBLE *vVal  );
#else
#define FEM_noUV_C( obj_node, uVal, vVal )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         *(uVal) = (DDOUBLE)(((NODE_PTYP)(obj_node))->u);\
         *(vVal) = (DDOUBLE)(((NODE_PTYP)(obj_node))->v);\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }
#endif

/*============================================================================*/
/* === Macro: FEM_noSetS_C
 * === Author: jrt
 * === Description: set the S parameter of node
 * === Arguments:
 *     NODE_OBJ obj_node     node object
 *     DDOUBLE s                the new s paramter
 * === Return: nothing
 */
#ifdef NO_NODE_MAC
void FEM_noSetS_C ( NODE_OBJ obj_node, DDOUBLE sVal  );
#else
#define FEM_noSetS_C( obj_node, sVal )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((NODE_PTYP)(obj_node))->s = (DDOUBLE)(sVal);\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }
#endif

/*============================================================================*/
/* === Macro: FEM_noSetU_C
 * === Author: sjo
 * === Description: set the U coordinate of node
 * === Arguments:
 *     NODE_OBJ obj_node     node object
 *     DDOUBLE u                the new u coordinate
 * === Return: nothing
 */
#ifdef NO_NODE_MAC
void FEM_noSetU_C ( NODE_OBJ obj_node, DDOUBLE uVal  );
#else
#define FEM_noSetU_C( obj_node, uVal )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((NODE_PTYP)(obj_node))->u = (DDOUBLE)(uVal);\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }
#endif

/*============================================================================*/
/* === Macro: FEM_noSetV_C
 * === Author: sjo
 * === Description: set the V coordinate of node
 * === Arguments:
 *     NODE_OBJ obj_node     node object
 *     DDOUBLE v                the new v coordinate
 * === Return: nothing
 */
#ifdef NO_NODE_MAC
void FEM_noSetV_C ( NODE_OBJ obj_node, DDOUBLE vVal  );
#else
#define FEM_noSetV_C( obj_node, vVal )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((NODE_PTYP)(obj_node))->v = (DDOUBLE)(vVal);\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }
#endif

/*============================================================================*/
/* === Macro: FEM_noSetUV_C
 * === Author: sjo
 * === Description: set the UV coordinates of node
 * === Arguments:
 *     NODE_OBJ obj_node     node object
 *     DDOUBLE u,v           the new coordinates
 * === Return: nothing
 */
#ifdef NO_NODE_MAC
void FEM_noSetUV_C ( NODE_OBJ obj_node,
                               DDOUBLE uVal, DDOUBLE vVal  );
#else
#define FEM_noSetUV_C( obj_node, uVal, vVal )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((NODE_PTYP)(obj_node))->u = (DDOUBLE)(uVal);\
         ((NODE_PTYP)(obj_node))->v = (DDOUBLE)(vVal);\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }
#endif

/*============================================================================*/
/* === Macro: FEM_noGetAllProperties_C
 * === Author: mls
 * === Description: return the variable bit field for all properties
 * === Arguments:
 *     FACE_OBJ obj_node     node object
 * === Return: FEM_LONG the property
 */
#define FEM_noGetAllProperties_C( obj_node )\
   ((g_meshtype == STANDARD_MESH) ?\
      (FEM_LONG)(((NODE_PTYP)(obj_node))->property) : 0L)

/*============================================================================*/
/* === Macro: FEM_noProperty_C
 * === Author: sjo
 * === Description: return the status of a property for the node
 * === Arguments:
 *     NODE_OBJ obj_node       node object
 *     FEM_LONG property_mask  one of the node properties specified above
 * === Return: FEM_LONG 0 or !=0      0 = not set, !=0 = set
 */
#ifdef NO_NODE_MAC
FEM_LONG FEM_noProperty_C ( NODE_OBJ obj_node,
                                 FEM_LONG property_mask  );
#else
#define FEM_noProperty_C( obj_node, property_mask )\
   ((g_meshtype == STANDARD_MESH) ?\
     (FEM_LONG)(((NODE_PTYP)(obj_node))->property & (FEM_LONG)(property_mask)) :\
   0L)
#endif

/*============================================================================*/
/* === Macro: FEM_noSetAllProperties_C
 * === Author: mls
 * === Description: Set the entire property bit field
 * === Arguments:
 *     FACE_OBJ obj_node     node object
 *     FEM_LONG property     the bit field
 * === Return: none
 */
#define FEM_noSetAllProperties_C( obj_node, new_property )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((NODE_PTYP)(obj_node))->property = new_property;\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }

/*============================================================================*/
/* === Macro: FEM_noSetProperty_C
 * === Author: sjo
 * === Description: Set the status of a property for the node
 * === Arguments:
 *     NODE_OBJ obj_node        node object
 *     FEM_LONG property_mask   one of the node properties specified above
 *     FEM_BOOLEAN status;       0 or 1, TRUE or FALSE, ON or OFF
 * === Return: 0 or !=0      0 = not set, !=0 = set
 */
#ifdef NO_NODE_MAC
void FEM_noSetProperty_C ( NODE_OBJ obj_node, 
                                    FEM_LONG property_mask,
                                    INT status );
#else
#define FEM_noSetProperty_C( obj_node, property_mask, status )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         if (status) {\
            ((NODE_PTYP)(obj_node))->property = \
               ((NODE_PTYP)(obj_node))->property | (FEM_LONG)(property_mask);\
         }\
         else {\
            if(((NODE_PTYP)(obj_node))->property & (FEM_LONG)(property_mask)) {\
               ((NODE_PTYP)(obj_node))->property =\
                  ((NODE_PTYP)(obj_node))->property ^ (FEM_LONG)(property_mask);\
            }\
         }\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }
#endif

/*============================================================================*/
/* === Macro: FEM_noInitProperties_C
 * === Author: sjo
 * === Description: Initialize all properties for the node to OFF
 * === Arguments:
 *     NODE_OBJ obj_node     node object
 * === Return: nothing
 */
#ifdef NO_NODE_MAC
void FEM_noInitProperties_C ( NODE_OBJ obj_node  );
#else
#define FEM_noInitProperties_C( obj_node )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((NODE_PTYP)(obj_node))->property = NO_PROPERTY;\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }
#endif

/*============================================================================*/
/* === Macro: FEM_noGeoEntity_C
 * === Author: sjo
 * === Description: get the node underlying geometric entity id
 * === Arguments:
 *     NODE_OBJ obj_node     node object
 * === Return: INT geo_entity
 */
#ifdef NO_NODE_MAC
INT FEM_noGeoEntity_C ( NODE_OBJ obj_node  );
#else
#define FEM_noGeoEntity_C( obj_node )\
   ((g_meshtype == STANDARD_MESH) ?\
      (INT)((NODE_PTYP)(obj_node))->geo_entity : -1)
#endif

/*============================================================================*/
/* === Macro: FEM_noSetGeoEntity_C
 * === Author: sjo
 * === Description: set the node underlying geometric entity id
 * === Arguments:
 *     NODE_OBJ obj_node     node object
 *     INT the_entity        number of the entity (user defined)
 * === Return: void
 */
#ifdef NO_NODE_MAC
void FEM_noSetGeoEntity_C ( NODE_OBJ obj_node, INT the_entity  );
#else
#define FEM_noSetGeoEntity_C( obj_node, the_entity )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((NODE_PTYP)(obj_node))->geo_entity = (INT)the_entity;\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }
#endif

/*============================================================================*/
/* === Macro: FEM_noGenericPointer_MAC
 * === Author: sjo
 * === Description: retreive the generic pointer from the node object
 * === Arguments:
 *     NODE_OBJ obj_node     node object
 * === Return: (void *) a generic pointer (must be cast to correct type)
 */
#ifdef NO_NODE_MAC
ADDRESS_TYP FEM_noGenericPointer_MAC ( NODE_OBJ obj_node  );
#else
#define FEM_noGenericPointer_MAC( obj_node )\
   ((g_meshtype == STANDARD_MESH) ?\
      (((NODE_PTYP)(obj_node))->p_info) :\
   NULL)
#endif

/*============================================================================*/
/* === Macro: FEM_noSetGenericPointer_C
 * === Author: sjo
 * === Description: set a generic pointer into the node object
 * === Arguments:
 *     NODE_OBJ obj_node       node object
 *     ADRESS_TYP obj_entity   any object entity or generic void pointer
 * === Return: void
 */
#ifdef NO_NODE_MAC
void FEM_noSetGenericPointer_C ( NODE_OBJ obj_node, INT obj_entity  );
#else
#define FEM_noSetGenericPointer_C( obj_node, obj_entity )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((NODE_PTYP)(obj_node))->p_info = (ADDRESS_TYP)obj_entity;\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }
#endif
/*============================================================================*/
/* === Macro: FEM_noSmoothingPointer_MAC
 * === Author: sjo
 * === Description: retreive the generic pointer from the node object
 * === Arguments:
 *     NODE_OBJ obj_node     node object
 * === Return: (void *) a generic pointer (must be caste to correct type)
 */
#ifdef NO_NODE_MAC
ADDRESS_TYP FEM_noSmoothingPointer_MAC ( NODE_OBJ obj_node  );
#else
#define FEM_noSmoothingPointer_MAC( obj_node )\
   ((g_meshtype == STANDARD_MESH) ?\
      (((NODE_PTYP)(obj_node))->p_info0) :\
   NULL)
#endif

/*============================================================================*/
/* === Macro: FEM_noSetSmoothingPointer_C
 * === Author: sjo
 * === Description: set a generic pointer into the node object
 * === Arguments:
 *     NODE_OBJ obj_node       node object
 *     ADRESS_TYP obj_entity   any object entity or generic void pointer
 * === Return: void
 */
#ifdef NO_NODE_MAC
void FEM_noSetSmoothingPointer_C ( NODE_OBJ obj_node, INT obj_entity  );
#else
#define FEM_noSetSmoothingPointer_C( obj_node, obj_entity )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((NODE_PTYP)(obj_node))->p_info0 = (ADDRESS_TYP)obj_entity;\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }
#endif


#endif
