
/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 2009 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_swRibs.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_swRibs.h
 *  header file for FEM_swRibs.c
 *
 */
#ifndef FEM_SWGETELEMINFO_INCLUDE
#define FEM_SWGETELEMINFO_INCLUDE

#include "fem_swPriv.h"

/*----------------- Globally accessible data types --------------------------*/

/*----------------- Globally accessible variables ---------------------------*/

/*----------------- Globally accessible macros ------------------------------*/

/*----------------- Globally accessible function prototypes -----------------*/

                                /* ========================================== */
                                /* === FEM_swGetElemInfo:  Gather information */
                                /* === about the elements on the boundary of  */
                                /* === the volume we are sweeping in          */
                                /* === preparation to sweep.                  */
                                /* === The information is stored in the       */
                                /* === Generic pointer of the AREAMSHDAT_PTYP */
                                /* === for the source area.                   */
                                /* === Return: EXIT_SUCCESS or EXIT_FAILURE   */
                                /* ========================================== */
INT FEM_swGetElemInfo (
   AREA_PTYP obj_sarea,           /* (IN)  The source area. */
   FEM_BOOLEAN do_progress,       /* (IN)  TRUE if doing status window */
   FEM_BOOLEAN debug );

#endif

