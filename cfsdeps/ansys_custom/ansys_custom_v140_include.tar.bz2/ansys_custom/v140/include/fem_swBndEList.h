
/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 2009 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_swBndEList.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_swBndEList.h
 *
 */
#ifndef FEM_SWBNDELIST_INCLUDE
#define FEM_SWBNDELIST_INCLUDE

/*----------------- Globally accessible variables ---------------------------*/

/*----------------- Globally accessible macros ------------------------------*/

/*==============================================================================
 * === Function: fem_swGetNextBndEdge
 * === Author: mls
 * === Description:
 * === Return: void
 *============================================================================*/
#define fem_swGetNextBndEdge_C( obj_edge )\
   obj_edge = (EDGE_OBJ)FEM_deBottomPop( fgobj_frontdeque );\
   FEM_edSetGenericPointer_C( obj_edge, NULL );

/*==============================================================================
 * === Function: fem_swKillBndEdgeList_C
 * === Author: mls
 * === Description:
 * === Return: void
 *============================================================================*/
#define fem_swKillBndEdgeList_C( )\
   if ( fgobj_frontdeque ) {\
      FEM_deKillDeque( fgobj_frontdeque );\
      fgobj_frontdeque = NULL;\
   }

/*==============================================================================
 * === Function: fem_swLookAtNextBndEdge_C
 * === Author: mls
 * === Description:
 * === Return: void
 *============================================================================*/
#define fem_swLookAtNextBndEdge_C()\
   (EDGE_OBJ)FEM_deBottomLook( fgobj_frontdeque )

#endif

