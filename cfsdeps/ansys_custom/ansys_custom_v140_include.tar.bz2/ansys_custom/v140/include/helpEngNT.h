/* 
 * *** copyright(c) 2011 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */
/***************************************************************************/
/* Definitions                                                             */
/***************************************************************************/
#define MAXPALETTE       (0x100)      /* max # supported palette entries */

/***************************************************************************/
/* Globals                                                                 */
/***************************************************************************/
PALETTEENTRY   palEntry[MAXPALETTE];
PALETTEENTRY   peDbg;               /* used for debug             */
LOGPALETTE     *pLogPalette;
HANDLE         hpLogPalette;     /* temp handle use for creating the logical palette*/

struct clrMap
{
   struct
   {
      COLORREF          clr;
      PALETTEENTRY      palEntry;
   } map[MAXPALETTE];
   SHORT numClr;
   SHORT curClr;
}  clrMap;

struct
{
   BOOL showLinks;
   BOOL caseSensitive;
   BOOL completeWord;
   BOOL partWord;
   BOOL startWord;
   BOOL endWord;
   BOOL procMan;
   BOOL cmdMan;
   BOOL eleMan;
   BOOL theoMan;
   BOOL othMan;
} checkBox;

/* Word to search for from word search dlg */

char dbgText[1024];

int kydbgz;
int errMsgFlag;

int nNumColors;
int nplane;

/***************************************************************************/
/* Flags used for display of messages                                      */
/***************************************************************************/
#define NT_NONE    (0X0)            /* Don't display any msgs */

/* Types */
static int NT_ERROR  = (0X1);    /* Display non window and function errors */
static int NT_WARN   = (0X2);    /* Display warnings */
static int NT_INF    = (0X4);    /* Display informative messages*/
static int NT_WM     = (0X8);    /* Display windows wm_... messages*/
static int NT_ENTRY  = (0X10);   /* Display message on entry to subroutine */
static int NT_COLOR  = (0X20);   /* Active show color function */
static int NT_WINERR  = (0X40);  /* Display windows errors */
static int NT_EXIT      = (0X80);   /* Display message on exit from subroutine */
static int NT_DBG0      = (0X100);  /* Display debug info */
static int NT_DBG1      = (0X200);  /* Display debug info */
static int NT_DBG2      = (0X400);  /* Display debug info */
static int NT_DBG3      = (0X800);  /* Display debug info */
static int NT_DBG4      = (0X1000); /* Display debug info */

/* Options */
static int NT_TYPE      = (0X2000); /* Display message type with message */

/* Where to display */
static int NT_CONSOLE = (0X4000); /* Display all messages in the colsole window */
static int NT_NOFILE  = (0X8000);   /* Don't display any messages in the error file */

/* Special type */
static int NT_CONMSG  = (0X10000); /* Always force display this msg in the consol */
static int NT_FILMSG  = (0X20000); /* Always force display this msg in the file */
static int NT_MSGBOX  = (0X40000); /* Always force display this msg to the message box */

static int NT_ALL     = (0X4000 - 0X1);/* Display all errors */


/******************************************************************************
* Borrowed from X                                                             *
******************************************************************************/

/* ImageFormat -- PutImage, GetImage */
#define XYBitmap     0  /* depth 1, XYFormat       */
#define XYPixmap     1  /* depth == drawable depth */
#define ZPixmap      2  /* depth == drawable depth */

typedef struct
{
    char *name;
    long value;
} Arg, *ArgList;

typedef char *XPointer;

/*
 * Data structure for "image" data, used by image manipulation routines.
 *
 */
typedef struct _XImage
{
   int width, height;       /* size of image                              */
   int xoffset;             /* number of pixels offset in X direction     */
   int format;              /* XYBitmap, XYPixmap, ZPixmap                */
   char *data;              /* pointer to image data                      */
   int byte_order;          /* data byte order, LSBFirst, MSBFirst        */
   int bitmap_unit;         /* quant. of scanline 8, 16, 32               */
   int bitmap_bit_order;    /* LSBFirst, MSBFirst                         */
   int bitmap_pad;          /* 8, 16, 32 either XY or ZPixmap             */
   int depth;               /* depth of image                             */
   int bytes_per_line;      /* accelarator to next line                   */
   int bits_per_pixel;      /* bits per pixel (ZPixmap)                   */
   unsigned long red_mask;  /* bits in z arrangment                       */
   unsigned long green_mask;
   unsigned long blue_mask;
   XPointer obdata;         /* hook for the object routines to hang on    */
   struct funcs
   {
      /* image manipulation routines                */
      struct _XImage *(*create_image)();
      // Display *, Visual *,
      // unsigned int, int, int, char *, unsigned int, unsigned int,
      // int, int);
      #ifdef NeedFunctionPrototypes
      int (*destroy_image)(struct _XImage *);
      unsigned long (*get_pixel)(struct _XImage *, int, int);
      int (*put_pixel)(struct _XImage *, int, int, unsigned long);
      struct _XImage *(*sub_image)(struct _XImage *, int, int,
          unsigned int, unsigned int);
      int (*add_pixel)(struct _XImage *, long);
      #else
      int (*destroy_image)();
      unsigned long (*get_pixel)();
      int (*put_pixel)();
      struct _XImage *(*sub_image)();
      int (*add_pixel)();
      #endif
    } f;
} XImage;

/* Data structure used by color operations */
typedef struct
{
    unsigned long pixel;
    unsigned short red, green, blue;
    char flags;                        /* do_red, do_green, do_blue        */
    char pad;
} XColor;

typedef ULONG Colormap;

/* Pseudo X functions */
unsigned long XGetPixel (XImage *image, int x, int y);
void XPutPixel (XImage *image, int x, int y, unsigned long ipix);

/***************************************************************************/
/*   Functions                                                             */
/***************************************************************************/
BOOL loadPalette (int *nc, XColor *xColor);
BYTE cmapFactor (int clr);
DWORD  errzz  (int type, int line, char *text);
int  numColors (void);
void Hlp_CB (int option);
void loadOneColor (int *i, int *ir, int *ig, int *ib);
void setErrRpt (void);
void winAnsysDbg (int type, int line, char *text, char *errMsg);

/*******************************************************************************/
/* DIB structures and pointers used to manage bitmap for display               */
/*******************************************************************************/
/* This is a pointer to a block of memory used to create bitmapped images */
#define MAXBITMAPSIZE 6000000
/* This is the last displayed XImage (used for screen refresh) */
XImage *currentXImage;

/* This is the default palette for the help engine.  It may be the ansys palette or the local */
/*	help palette */
HPALETTE currentPal;

/* key_share   (0) own palette (1) ansys palette */
int key_share;

/* Utility routines */
char *ckSum (XImage *image);
void showXimage (int line, XImage *image);
void showXColor (int line, int nColors, XColor *xcolor);
int xcolorFactor (int clr);
void colorTestBars (XImage *image);

