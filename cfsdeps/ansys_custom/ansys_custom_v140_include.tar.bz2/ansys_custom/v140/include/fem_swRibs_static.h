/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 2009 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_swRibs_static.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_swRibs_static.h
 *  header file for FEM_swRibs.c
 *
 */
#ifndef FEM_SWRIBS_STATIC_INCLUDE
#define FEM_SWRIBS_STATIC_INCLUDE

/*------------------ Prototypes for static routines ------------------*/

static INT   fem_swSetUpRibs            ( INT num_ribs );
static INT   fem_swGenerateRibsLevel    ( INT level,
                                   RIBDATA_TYP *a_interp_data,
                                   INT num_area_nodes,
                                   INT num_area_edges,
                                   INT num_bnd_nodes,
                                   NODE_OBJ const *aobj_src_area_nodes,
                                   NODE_OBJ const *aobj_src_bnd_nodes,
                                   FEM_BOOLEAN do_plane_offset,
                                   VECTOR3D *a_norms,
                                   DOUBLE *a_edgeratios );
static INT fem_swMakeInteriorRibs       ( RIBDATA_TYP *a_interp_data,
                                   INT num_area_nodes,
                                   INT num_area_edges,
                                   INT num_bnd_nodes,
                                   NODE_OBJ const *aobj_area_nodes,
                                   NODE_OBJ const *aobj_bnd_nodes,
                                   FEM_BOOLEAN do_plane_offset,
                                   VECTOR3D *a_src_normals,
                                   VECTOR3D *a_trg_normals,
                                   int aiInflation[3] );
static INT fem_swFindSourceAreaNodes    ( INT sweepmids, 
												   AREA_PTYP obj_sarea,
                                   NODE_OBJ *aobj_src_area_nodes, INT inum );
static INT fem_swSetUpBgMesh            ( AREA_PTYP obj_sarea,
                                   AREA_PTYP obj_tarea,
                                   NODE_OBJ const *aobj_src_bnd_nodes,
                                   NODE_OBJ const *aobj_trg_bnd_nodes,
                                   INT const *a_iel,
                                   INT num_edges,
                                   INT num_bnd_nodes,
                                   MESH_OBJ *obj_bgmesh,
                                   INT do_progress );
static INT fem_swCalcNormals            ( NODE_OBJ const *aobj_src_bnd_nodes,
                                   INT num_bnd_nodes,
                                   VECTOR3D **a_src_normals,
                                   VECTOR3D **a_trg_normals );

static INT fem_swIsLinearPossible( VOL_PTYP obj_vol,
                                   NODE_OBJ const *aobj_bnd_nodes,
                                   INT num_bnd_nodes,
                                   FEM_BOOLEAN *linear);

static INT fem_swMakeBgMeshRibs         ( AREA_PTYP obj_sarea,
                                   AREA_PTYP obj_tarea,
                                   INT num_area_nodes,
                                   INT num_area_edges,
                                   INT num_bnd_nodes,
                                   INT num_bnd_edges,
                                   NODE_OBJ const *aobj_src_bnd_nodes,
                                   NODE_OBJ const *aobj_trg_bnd_nodes,
                                   NODE_OBJ const *aobj_src_area_nodes,
                                   INT const *a_iel );
static INT fem_swMakeLinearRibs         ( INT num_area_nodes,
                                   NODE_OBJ *aobj_src_area_nodes );
static INT fem_swCalcEdgeRatios         ( INT irib,
                                   NODE_OBJ obj_srcnode,
                                   DOUBLE *a_edgeratios );
static INT fem_swCalcInterpolants       ( INT level,
                                   RIBDATA_TYP *node_data,
                                   DOUBLE ratioA,
                                   DOUBLE ratioB,
                                   DOUBLE ratioC,
                                   DOUBLE *areacoord_A,
                                   DOUBLE *areacoord_B,
                                   DOUBLE *areacoord_C,
                                   DOUBLE *interpolant );
static INT fem_swFindEdges              ( INT const *a_iel,
                                   INT num_edges,
                                   NODE_OBJ const *aobj_nodes,
                                   EDGE_OBJ **aobj_edges );
static INT fem_swFindCornerNodes        ( INT rib_id1,
                                   INT rib_id2,
                                   INT rib_id3,
                                   INT level,
                                   NODE_OBJ const *aobj_src_bnd_nodes,
                                   DOUBLE a_x[3],
                                   DOUBLE a_y[3],
                                   DOUBLE a_z[3] );
static INT fem_swGetCornerLocs(
    RIBDATA_TYP *node_data,   /* (IN)  data about the node rib we are on */
    INT level,                   /* (IN)  How far up the volume to get nodes. */
    NODE_OBJ const *aobj_src_bnd_nodes,/* (IN)  src bnd nodes. */
    DOUBLE adCornerLocs[3][3]); /* (OUT) corner nodal locs */

static INT fem_swFindBottomNodeLoc      ( INT irib,
                                          NODE_OBJ const *aobj_src_bnd_nodes,
                                          VECTOR3D *node_loc );
static INT fem_swFindTopNodeLoc         ( INT irib,
                                          NODE_OBJ const *aobj_src_bnd_nodes,
														VECTOR3D *node_loc );
static INT fem_swRetriveTrgBndNodes( 
	NODE_OBJ *&aobj_trg_bnd_nodes,
	INT num_bnd_ribs,
	NODE_OBJ *aobj_src_bnd_nodes);
static INT fem_swMakeLinearRibsV1(
	FEM_BOOLEAN needMidNode,
   INT numCornerNodes,
	INT numAreaEdges,
   NODE_OBJ *aobj_srcAreaNodes);
static INT fem_swIsLinearPossibleV1(
   NODE_OBJ const *aobj_bnd_nodes,  /* (IN)  source area boundary nodes. */
   INT num_bnd_nodes,         /* (IN)  num bnd nodes around source area. */
   FEM_BOOLEAN *linear );
static INT fem_swAllocRibsV1(
   INT num_divs );
static INT fem_swRibNodeCoLinear( 
    INT irib,
    NODE_OBJ const *aobj_bnd_nodes,
    INT &coLinear);
static INT fem_swAdjRibNodes(
    RIBDATA_TYP *a_interp_data,
    INT num_area_nodes,
    INT num_area_edges,
    INT num_bnd_nodes,
    NODE_OBJ const *aobj_src_area_nodes,
    NODE_OBJ const *aobj_src_bnd_nodes,
    FEM_BOOLEAN do_plane_offset,
    DOUBLE *a_edgeratios );  /* (IN) ratios of edge lengths along  boundary ribs.  */
static INT fem_swIterativeFitting(
    std::vector<NODE_OBJ> &cNodeList, // node list on the rib (including src and trg nodes )
    std::vector<DOUBLE>   &cNodeInterpolateList, // node list on the rib (including src and trg nodes )
    FEM_BOOLEAN &bConverage);
static INT fem_swBezierCurveEval( DOUBLE u, VECTOR3D *aPnts, INT iNumNodes, VECTOR3D &cNewPnt );
static INT fem_swAdjFittingPnts( 
    INT iNumNodes, 
    VECTOR3D *aPnts, // original pnts
    DOUBLE *aRates,  // curve length rate ( curve length parameters )
    DOUBLE *length ); // the curve length of fit curve
#endif
