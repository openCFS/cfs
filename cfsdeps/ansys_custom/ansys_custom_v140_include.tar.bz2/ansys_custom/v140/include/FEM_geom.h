/*  FEM_Geom.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_Geom.h
 *  Prototypes and macros for geometry functions
 *
 */

#ifndef FEM_GEOM_H
#define FEM_GEOM_H

/*------------------------ Constants -------------------------------------------*/
#define EXIT_NO_ISECT -456

/*------------------------ Data Structures -------------------------------------*/

/*------------------------ Globals ---------------------------------------------*/

/*------------------------ Prototypes ------------------------------------------*/
#ifdef __cplusplus
extern "C" {
#endif

INT        FEM_gmGeoWhichPlane          ( FACE_OBJ obj_face );
INT        FEM_gmGeoWhichPlane2         ( VECTOR3D *ps_norm );
INT        FEM_gmGeoVectorTo2D          ( INT iplane,
                                          VECTOR3D *ps_vec,
                                          DOUBLE *p_x,
                                          DOUBLE *p_y );
INT        FEM_gmGeoIsectVectSeg        ( VECTOR3D *ps_norm,
                                          VECTOR3D *ps_n0,
                                          VECTOR3D *ps_n1,
                                          VECTOR3D *ps_nv,
                                          VECTOR3D *ps_vec,
                                          VECTOR3D *ps_isec,
                                          DOUBLE *p_t );
INT        FEM_gmGeoIsectVectEdge       ( FACE_OBJ obj_face,
                                          EDGE_OBJ obj_edge,
                                          NODE_OBJ obj_node,
                                          VECTOR3D *ps_vec,
                                          VECTOR3D *ps_isec );
INT        FEM_gmGeoIsectVectFace       ( FACE_OBJ obj_face,
                                          NODE_OBJ obj_node,
                                          VECTOR3D *ps_vec,
                                          VECTOR3D *ps_isect );
INT        FEM_gmGeoIsectVectPlane      ( VECTOR3D *ps_norm,
                                          VECTOR3D *ps_point_on_plane,
                                          VECTOR3D *ps_vec_orig,
                                          VECTOR3D *ps_vec,
                                          VECTOR3D *ps_isect );
INT        FEM_gmGeoPointOnEdge         ( EDGE_OBJ obj_edge,
                                          NODE_OBJ obj_node0,
                                          DOUBLE ratio,
                                          VECTOR3D *ps_loc );
INT        FEM_gmProjVectToPlane        ( VECTOR3D *ps_vector,
                                          VECTOR3D *ps_normal,
                                          VECTOR3D *ps_proj );
INT        FEM_gmTrans3DVect            ( INT anum,
                                          DOUBLE u,
                                          DOUBLE v,
                                          VECTOR3D *vect3d,
                                          DOUBLE *uvec,
                                          DOUBLE *vvec );
INT        FEM_gmLineIntersect2D        ( POINT2D *line1pt1,
                                          POINT2D *line1pt2,
                                          POINT2D *line2pt1,
                                          POINT2D *line2pt2,
                                          FEM_BOOLEAN *intersect,
                                          POINT2D *intersection );
#ifdef __cplusplus
}
#endif
#endif

