/*****************************************************************************
 *                   Copyright (C) 1999 CMSoft                               *
 *                                                                           *
 *  These lines of code and declarations contain unpublished proprietary     *
 *  information of CMSoft. They may not be copied or duplicated in whole     *
 *  or part without prior authorization from CMSoft.                         *
 *                                                                           *
 *****************************************************************************/

#include "LinkFC.h"

#if defined(LOWERCASENOUNDER_SYS)
#define elemread		elemread
#define initelemread		initelemread
#define closelemread		closelemread
#endif

#if defined(UPPERCASENOUNDER_SYS)
#define elemread		ELEMREAD
#define initelemread		INITELEMREAD
#define closelemread		CLOSELEMREAD
#endif

#if defined(LOWERCASEUNDER_SYS)
#define elemread		elemread_
#define initelemread		initelemread_
#define closelemread		closelemread_
#endif

extern "C" {
  SUBROUTINE elemread(int *indElem, int *nr, int *dofs, double *stiff, double *load, int *unsym, int *ier);
  SUBROUTINE initelemread(int*);
  SUBROUTINE closelemread(FCHAR(c1) FCHARL(c1_len));
}
