////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         Copyright (C) 2009 ANSYS Inc.  All Rights Reserved             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MAT_CoefficientArray.h $
// $Revision: 1.5 $ 7.0
// $Date: 2009/11/13 16:13:02 $ March 28 2002
// $Author: jtm $ rjayasee
//
// Decription :
//
//	This is just an array of Coefficients
////////////////////////////////////////////////////////////////////////////// 

#if !defined(MAT_CoefficientArray_H)
#define MAT_CoefficientArray_H

class MAT_CoefficientArray  
{
public:

	MAT_CoefficientArray();
    // Default Constructor.

    ~MAT_CoefficientArray();
    //Destructor

    bool AddCoefficient(double dCoeff)
    {
        m_oParameterData.push_back( dCoeff ) ;
        return true ;
    }
    //R status
    //I dCoeff
    //I Coefficient to tbe added.
    //- Appends a Coefficient

    double operator []( INT iIndex ) const
    {
        double dVal ;
        if ( false == GetCoefficient(iIndex, dVal) )
        {
            assert(0) ;
        }
        return dVal ;
    }

    bool GetCoefficient(INT iIndex, double& dCoeff) const
    {
        if ( iIndex >= 0 && iIndex < m_oParameterData.size() )
        {
            dCoeff = m_oParameterData[iIndex] ;
            return true ;
        }
        return false ;
    }
    //R status
    //I iIndex
    //I Index of coefficient
    //O dCoeff
    //O Coefficient to tbe added.
    //- Appends a Coefficient

    bool SetCoefficient(INT iIndex, double dCoeff)
    {
        if ( iIndex < 0 )
        {
            return false ;
        }
        if ( iIndex >= this->m_oParameterData.size() )
        {
            this->m_oParameterData.resize(iIndex+1) ;
        }
        m_oParameterData[iIndex] = dCoeff ;
        return true ;
    }
    //R status
    //I iIndex
    //I Index of coefficient
    //O dCoeff
    //O Coefficient to tbe added.
    //- Appends a Coefficient

    bool RemoveCoefficient() 
    {
        m_oParameterData.pop_back() ;
        return true ;
    }
    //R status
    //Removes the Last added coefficient

    bool RemoveAllCoefficients() 
    {
        m_oParameterData.clear() ;
        return true ;
    }
    //R status
    //Removes all Coefficients

    INT GetNumberOfCoefficients() const
    {
        return m_oParameterData.size() ;
    }
    //R INT
    //- Returns the number of coefficients

    INT Size() const
    {
        return this->m_oParameterData.size() ;
    }

    void Resize(INT iSize)
    {
        this->m_oParameterData.resize(iSize) ;
    }
    
    void Print() ;
    //Print Function

private:

	vector<double> m_oParameterData ;
    // List of Constitutive Model data

} ;



#endif // !defined(MAT_CoefficientArray_H)

