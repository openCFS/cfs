
#include "ansysdef.h"


extern  INT  cCreateAnsDisp(INT);
extern  INT  cDeleteAnsDisp(void);
extern  INT  cInquireAnsDisp(INT,INT,INT);
extern  INT  cPutAnsDisp(INT,INT,DOUBLE*);
extern  INT  cGetAnsDisp(INT,INT,INT*,DOUBLE*);
extern  INT  cGetAnsDispPtr(INT,INT,INT*,DOUBLE**);
extern  INT  cActivateAnsDisp(INT,INT,INT);
extern  INT  cDumpAnsDisp(INT);

extern  INT  cPutAnsDispFlag(INT,INT,INT,INT);

#define FLAG_DISP   -5001
#define FLAG_VELO   -5002
#define FLAG_ACCL   -5003


/****************************************************************
 global-level structure for ANSYS nodal displacements
 ****************************************************************/
struct ansDisp_str {         /* Name of the structure                                  */
  INT       tag;             /* Tag for this instance of the displacement structure    */
  INT       numDispNodes;    /* Number of nodes with displacements                     */
  INT       maxDispNode;     /* Maximum external node number having displacement       */
  INT       numDisp;         /* Total number of displacements (zero and non-zero)      */
  INT       numVeloNodes;    /* Number of nodes with velocities                        */
  INT       maxVeloNode;     /* Maximum external node number having velocity           */
  INT       numVelo;         /* Total number of velocities (zero and non-zero)         */
  INT       numAcclNodes;    /* Number of nodes with accelerations                     */
  INT       maxAcclNode;     /* Maximum external node number having acceleration       */
  INT       numAccl;         /* Total number of accelerations (zero and non-zero)      */
  INT       vaKey;           /* Key denoting certain DOF are velocity and accleration  */
};

#define ansDispTag(disp)                (disp->tag)
#define ansDispNumDispNodes(disp)       (disp->numDispNodes)
#define ansDispMaxDispNode(disp)        (disp->maxDispNode)
#define ansDispNumDisp(disp)            (disp->numDisp)
#define ansDispNumVeloNodes(disp)       (disp->numVeloNodes)
#define ansDispMaxVeloNode(disp)        (disp->maxVeloNode)
#define ansDispNumVelo(disp)            (disp->numVelo)
#define ansDispNumAcclNodes(disp)       (disp->numAcclNodes)
#define ansDispMaxAcclNode(disp)        (disp->maxAcclNode)
#define ansDispNumAccl(disp)            (disp->numAccl)
#define ansDispVeloAcclKey(disp)        (disp->vaKey)



/******************************************************************
 data-level structure for ANSYS nodal displacements
 ******************************************************************/
struct dispData_str {    /* Name of the structure                                           */
  char      modified;    /* Flag indicating whether this displacement has been modified     */
  char      internal;    /* Flag indicating whether this displacement is internal to object */
  INT       dof;         /* External DOF value                                              */
  char      active;      /* Flag indicating if displacement is active or inactive           */
  INT       gaugeKey;    /* Flag indicating if displacement is gauged or not                */
  DOUBLE   *values;      /* Vector containing displacement values (we store 4 values)       */
                         /*        (1:2) current real,imag values                           */
                         /*        (3:4) previous real,imag values                          */ 
  dispData *nextDisp;    /* Pointer to the next displacement data structure for this        */
                         /* node.  If this pointer is NULL, then this is the last           */
                         /* stored displacement for this node                               */
};

#define dispDataModified(dData)         (dData->modified)
#define dispDataInternal(dData)         (dData->internal)
#define dispDataDof(dData)              (dData->dof)
#define dispDataDispActive(dData)       (dData->active)
#define dispDataGaugeKey(dData)         (dData->gaugeKey)

#define dispDataValuesPtr(dData)        (dData->values)
#define dispDataValuesVec(dData,i)      (dData->values[i])

#define dispDataNextDispPtr(dData)      (dData->nextDisp)

