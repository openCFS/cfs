/*
 * *** ansys(r) copyright(c) 2009
 * *** ansys, inc.
 */
#ifndef FEM_IMPUBLIC
#define FEM_IMPUBLIC

/*--- Header files ---*/
#include <math.h>
#include <float.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "FEM_cdbtypes.h"

#include "FEM_CtoF.h"
#include "FEM_Public.h"
#include "FEM_deque.h"

/*--- Definitions ---*/
#define DBGLVL       0
#define MEPSF        DBL_EPSILON*100.0

#define EMPTY_CCSPH  0
#define MIN_SOL_ANG  1
#define RADIUS_RATIO 2
#define MEAN_RATIO   3

/*--- Global variable declarations (defined in FEM_imSetGtol.c) ---*/
extern DDOUBLE g_tol; /* relative tolerance for comparison with 0.0 */
extern FILE *fg_dbg;  /* file pointer for debugging output if DBGLVL >= 3 */

/*--- Prototypes ---*/

      /* Call first to set relative tolerance g_tol */
void FEM_imSetGtol ( DDOUBLE tolin  );

      /* Calculate statistics and frequencies */
void FEM_imStats ( INT n, DDOUBLE x[], DDOUBLE a, DDOUBLE h, INT nf,
   DDOUBLE *xmin, DDOUBLE *xmax, DDOUBLE *mean, DDOUBLE *stdv,
   DDOUBLE freq[]  );

      /* Calculate barycentric coordinates, in-sphere test, shape measures */
void FEM_imBarytet ( DDOUBLE ax, DDOUBLE ay, DDOUBLE az,
   DDOUBLE bx, DDOUBLE by, DDOUBLE bz, DDOUBLE cx, DDOUBLE cy, DDOUBLE cz,
   DDOUBLE dx, DDOUBLE dy, DDOUBLE dz, DDOUBLE ex, DDOUBLE ey, DDOUBLE ez,
   DDOUBLE reltol, DDOUBLE loalp, DDOUBLE hialp, FEM_BOOLEAN *degen,
   DDOUBLE alpha[4]  );
void FEM_imCcsph3 ( DDOUBLE ax, DDOUBLE ay, DDOUBLE az,
   DDOUBLE bx, DDOUBLE by, DDOUBLE bz, DDOUBLE cx, DDOUBLE cy, DDOUBLE cz,
   DDOUBLE dx, DDOUBLE dy, DDOUBLE dz, DDOUBLE ex, DDOUBLE ey, DDOUBLE ez,
   DDOUBLE reltol, INT *in, DDOUBLE *radsq, DDOUBLE *centerx, DDOUBLE *centery,
   DDOUBLE *centerz  );
DDOUBLE FEM_imCcradinv ( DDOUBLE ax, DDOUBLE ay, DDOUBLE az,
   DDOUBLE bx, DDOUBLE by, DDOUBLE bz, DDOUBLE cx, DDOUBLE cy, DDOUBLE cz,
   DDOUBLE dx, DDOUBLE dy, DDOUBLE dz  );
DDOUBLE FEM_imSvoltet ( DDOUBLE ax, DDOUBLE ay, DDOUBLE az,
   DDOUBLE bx, DDOUBLE by, DDOUBLE bz, DDOUBLE cx, DDOUBLE cy, DDOUBLE cz,
   DDOUBLE dx, DDOUBLE dy, DDOUBLE dz  );
DDOUBLE FEM_imMeanrtet ( DDOUBLE ax, DDOUBLE ay, DDOUBLE az,
   DDOUBLE bx, DDOUBLE by, DDOUBLE bz, DDOUBLE cx, DDOUBLE cy, DDOUBLE cz,
   DDOUBLE dx, DDOUBLE dy, DDOUBLE dz  );
DDOUBLE FEM_imRadrtet ( DDOUBLE ax, DDOUBLE ay, DDOUBLE az,
   DDOUBLE bx, DDOUBLE by, DDOUBLE bz, DDOUBLE cx, DDOUBLE cy, DDOUBLE cz,
   DDOUBLE dx, DDOUBLE dy, DDOUBLE dz  );
DDOUBLE FEM_imSangmin ( DDOUBLE ax, DDOUBLE ay, DDOUBLE az,
   DDOUBLE bx, DDOUBLE by, DDOUBLE bz, DDOUBLE cx, DDOUBLE cy, DDOUBLE cz,
   DDOUBLE dx, DDOUBLE dy, DDOUBLE dz, DDOUBLE sang[4]  );
DDOUBLE FEM_imMeastet ( INT mtype, DDOUBLE ax, DDOUBLE ay, DDOUBLE az,
   DDOUBLE bx, DDOUBLE by, DDOUBLE bz, DDOUBLE cx, DDOUBLE cy, DDOUBLE cz,
   DDOUBLE dx, DDOUBLE dy, DDOUBLE dz  );

      /* Operations on queue of faces to be tested for local optimality */
INT FEM_imInitQue ( DEQUE_OBJ *pobj_queue  );
void FEM_imRemfacq ( FACE_OBJ obj_fac, DEQUE_OBJ obj_queue  );
INT FEM_imUpdfacq ( FACE_OBJ obj_fac, DEQUE_OBJ obj_queue  );

      /* Flip operations that update triangulation and queue */
INT FEM_imFlip23 ( ELEMENT_OBJ aobj_oldtet[2], NODE_OBJ obj_a,
   NODE_OBJ obj_b, NODE_OBJ obj_c, NODE_OBJ obj_d, NODE_OBJ obj_e,
   NODE_OBJ obj_vert, FEM_BOOLEAN dfault, DEQUE_OBJ obj_queue,
   ELEMENT_OBJ aobj_newtet[3]  );
INT FEM_imFlip32 ( ELEMENT_OBJ aobj_oldtet[3], NODE_OBJ obj_a,
   NODE_OBJ obj_b, NODE_OBJ obj_c, NODE_OBJ obj_d, NODE_OBJ obj_e,
   NODE_OBJ obj_vert, FEM_BOOLEAN dfault, DEQUE_OBJ obj_queue,
   ELEMENT_OBJ aobj_newtet[2]  );
INT FEM_imFlip22 ( ELEMENT_OBJ aobj_oldtet[2], NODE_OBJ obj_a,
   NODE_OBJ obj_b, NODE_OBJ obj_c, NODE_OBJ obj_d, NODE_OBJ obj_e,
   NODE_OBJ obj_vert, FEM_BOOLEAN dfault, DEQUE_OBJ obj_queue,
   ELEMENT_OBJ obj_newtet[2]  );
INT FEM_imFlip44 ( ELEMENT_OBJ aobj_oldtet[4], NODE_OBJ obj_a,
   NODE_OBJ obj_b, NODE_OBJ obj_c, NODE_OBJ obj_d, NODE_OBJ obj_e,
   NODE_OBJ obj_f, NODE_OBJ obj_vert, FEM_BOOLEAN dfault, DEQUE_OBJ obj_queue,
   ELEMENT_OBJ aobj_newtet[4]  );

      /* Process queue to make all interior faces locally optimal */
INT FEM_imFlipecs ( FEM_BOOLEAN bndcon, DEQUE_OBJ obj_queue,
   NODE_OBJ obj_vert, ELEMENT_OBJ *pobj_tet  );
INT FEM_imFlipmu ( FEM_BOOLEAN bndcon, INT mtype, DEQUE_OBJ obj_queue  );

      /* Functions for combination flips */
INT FEM_imFliptf ( INT mtype, DEQUE_OBJ obj_stack,
   DEQUE_OBJ obj_queue  );
void FEM_imFactyp ( FEM_BOOLEAN bndcon, ELEMENT_OBJ obj_tet, INT iface,
   char typ[4], INT ind[3]  );
INT FEM_imFndcomb ( FEM_BOOLEAN bndcon, INT mtype, FEM_BOOLEAN swap,
   NODE_OBJ obj_a, NODE_OBJ obj_b, NODE_OBJ obj_d, NODE_OBJ obj_e,
   NODE_OBJ obj_f, ELEMENT_OBJ obj_tetd, ELEMENT_OBJ obj_tete, DDOUBLE minbef,
   ADDRESS_TYP p_top, DEQUE_OBJ obj_stack, DEQUE_OBJ obj_stack2,
   FEM_BOOLEAN *impr  );
INT FEM_imImptrid ( FEM_BOOLEAN bndcon, INT maxdec, INT *cntnlo  );
INT FEM_imImptrimu ( FEM_BOOLEAN bndcon, INT mtype  );

      /* Main driver function to improve quality of triangulation */
INT FEM_imImptri3 ( FEM_BOOLEAN bndcon, FEM_BOOLEAN combfl, INT mtype  );

      /* Turn on a node property for all interior nodes */
void FEM_imIntNodPr ( int property_mask  );

      /* Main driver function to smooth triangulation */
INT FEM_imSmotri3 ( INT npass, INT mtype, DDOUBLE mtmov,
   DDOUBLE movtol  );

#endif
