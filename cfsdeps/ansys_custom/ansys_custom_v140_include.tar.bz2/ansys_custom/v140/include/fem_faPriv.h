/*  fem_faPriv.h */
/* 
 * *** ansys(r) copyright(c) 2009
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  *** */
/*                                                                         sjo
 *   fem_faPriv.h
 *   Private header file for faces in FEM module
 */
#ifndef FEM_FAPRIVATE
#define FEM_FAPRIVATE

#include "FEM_cdbtypes.h"

                             /* === fem_faRemoveAdjElem: remove pointers from */
                             /* === the face to one of its adjacent elements  */
void fem_faRemoveAdjElem (
   FACE_PTYP ps_face,                  /* the face                            */
   ELEMENT_PTYP ps_element );          /* the element that is to be removed   */
                                       /* from the face */
                             /* === fem_faEdgeIndex: return the actual index  */
                             /* === of an edge on a face based on the face_use*/
INT fem_faEdgeIndex (
   FACEUSE_PTYP ps_face_use,           /* A face use                          */
   INT index );                        /* ideal edge index                    */

                             /* === fem_faNewEdgeUses: create edge uses for   */
                             /* === the face                                  */
INT fem_faNewEdgeUses (
   FACE_OBJ obj_face );                /* face object                         */

                             /* === fem_faDeleteEdgeUses: delete the edge uses*/
                             /* === from the face                             */
void fem_faDeleteEdgeUses (
   FACE_OBJ obj_face );                /* face object                         */


/*
 * Macros
 */

/*============================================================================*/
/* === Macro:  fem_faSetTotal_C
 * === Author: sjo
 * === Description: set total number of faces in list
 * === Arguments:
 *     FACELIST_OBJ obj_flist      face list object
 *     INT totface                 new total number of faces
 * === Return: nothing
 */
#define fem_faSetTotal_C( obj_flist, totface )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((FACELIST_PTYP)(obj_flist))->total = totface;\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }

/*============================================================================*/
/* === Macro: fem_faSetList_C
 * === Author: sjo
 * === Description: set head of face list
 * === Arguments:
       FACELIST_OBJ  obj_flist       face list object
       FACE_OBJ obj_face             new first face in list
 * === Return:
 */
#define fem_faSetList_C( obj_flist, obj_face )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((FACELIST_PTYP)(obj_flist))->ps_list = (FACE_PTYP)obj_face;\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }

/*============================================================================*/
/* === Macro: fem_faSetCurrent_C
 * === Author: sjo
 * === Description: set current face in face object list
 * === Arguments:
 *     FACELIST_OBJ obj_flist          face list object
 *     FACE_OBJ obj_face               new current face
 * === Return:
 */
#define fem_faSetCurrent_C( obj_flist, obj_face )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((FACELIST_PTYP)(obj_flist))->ps_current = (FACE_PTYP)obj_face;\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }

/*============================================================================*/
/* === Macro: fem_faAddFaceToList_C
 * === Author: sjo
 * === Description: add face to linked list at front of list
 * === Arguments:
 *     FACELIST_OBJ obj_flist     face list object
 *     FACE_OBJ obj_element       new element to be added
 * === Return: nothing
 */
#define fem_faAddFaceToList_C( obj_flist, obj_face )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((FACE_PTYP)(obj_face))->ps_next =\
                   ((FACELIST_PTYP)(obj_flist))->ps_list;\
         ((FACELIST_PTYP)(obj_flist))->ps_list =\
                   (FACE_PTYP)(obj_face);\
         if (((FACE_PTYP)(obj_face))->ps_next != NULL) {\
            ((FACE_PTYP)(obj_face))->ps_next->ps_previous =\
                      (FACE_PTYP)(obj_face);\
         }\
         ((FACE_PTYP)(obj_face))->ps_previous = NULL;\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }

/*============================================================================*/
/* === Macro: fem_faDeleteFaceFromList_C
 * === Author: sjo
 * === Description: delete face from linked list
 * === Arguments:
 *     FACELIST_OBJ obj_flist   face list object
 *     FACE_OBJ obj_face     face to be deleted
 * === Return: nothing
 */
#define fem_faDeleteFaceFromList_C( obj_flist, obj_face )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         if (((FACE_PTYP)(obj_face))->ps_next != NULL) {\
            ((FACE_PTYP)(obj_face))->ps_next->ps_previous =\
                    ((FACE_PTYP)(obj_face))->ps_previous;\
         }\
         if (((FACE_PTYP)(obj_face))->ps_previous) {\
            ((FACE_PTYP)(obj_face))->ps_previous->ps_next =\
                    ((FACE_PTYP)(obj_face))->ps_next;\
         }\
         else{\
            ((FACELIST_PTYP)(obj_flist))->ps_list =\
               ((FACE_PTYP)(obj_face))->ps_next;\
         }\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }

/*============================================================================*/
/* === Macro: fem_faInsertAdjElem_MAC
 * === Author: sjo
 * === Description: insert into the face, a pointer to one of its
 *                  adjacent elements (use only for STANDARD_MESH data rep)
 * === Arguments:
 *     FACE_PTYP ps_face          face to be updated
 *     ELEMENT_PTYP ps_element    element to be added
 *     INT iface                  The location of face in element
 * === Return: nothing
 * === Note: if you move the face to a different slot in the element's face
 *           array you also need to move the pointer to the new slot.
 */
#define fem_faInsertAdjElem_MAC( ps_face, ps_element, iface )\
   ps_element->as_face_element[iface].ps_element = ps_element;\
   ps_element->as_face_element[iface].ps_next = ps_face->ps_adjelem;\
   ps_face->ps_adjelem = \
      (NEXTELEMENT_TYP *)(ps_element->as_face_element + iface);

/*============================================================================*/
/* === Macro: fem_faInit_C
 * === Author: sjo
 * === Description: initialize all fields of face structure
 * === Arguments:
 *     FACE_OBJ obj_face          face to be updated
 * === Return: nothing
 */
#define fem_faInit_C( obj_face )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((FACE_PTYP)(obj_face))->id = 0;\
         ((FACE_PTYP)(obj_face))->numedges = 0;\
         ((FACE_PTYP)(obj_face))->aps_edge_use[0] = NULL;\
         ((FACE_PTYP)(obj_face))->aps_edge_use[1] = NULL;\
         ((FACE_PTYP)(obj_face))->aps_edge_use[2] = NULL;\
         ((FACE_PTYP)(obj_face))->aps_edge_use[3] = NULL;\
         ((FACE_PTYP)(obj_face))->ps_adjelem = (NEXTELEMENT_PTYP)NULL;\
         ((FACE_PTYP)(obj_face))->as_edge_face[0].ps_face = \
         ((FACE_PTYP)(obj_face))->as_edge_face[1].ps_face = \
         ((FACE_PTYP)(obj_face))->as_edge_face[2].ps_face = \
         ((FACE_PTYP)(obj_face))->as_edge_face[3].ps_face = \
                                            (FACE_PTYP)(obj_face);\
         ((FACE_PTYP)(obj_face))->as_edge_face[0].ps_next = \
         ((FACE_PTYP)(obj_face))->as_edge_face[1].ps_next = \
         ((FACE_PTYP)(obj_face))->as_edge_face[2].ps_next = \
         ((FACE_PTYP)(obj_face))->as_edge_face[3].ps_next = \
                                            (NEXTFACE_PTYP)NULL;\
         ((FACE_PTYP)(obj_face))->property = NO_PROPERTY;\
         ((FACE_PTYP)(obj_face))->shape_metric = 0.0;\
         ((FACE_PTYP)(obj_face))->p_info = (ADDRESS_TYP)NULL;\
         ((FACE_PTYP)(obj_face))->geo_entity = 0;\
         ((FACE_PTYP)(obj_face))->parent = 0;\
         ((FACE_PTYP)(obj_face))->ps_next = (FACE_PTYP)NULL;\
         ((FACE_PTYP)(obj_face))->ps_previous = (FACE_PTYP)NULL;\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }

/*============================================================================*/
/* === Macro: fem_faSetEdgeOrientation_C
 * === Author: sjo
 * === Description: set the node orientation flag in the edge use structure
 * === Arguments:
 *     FACE_OBJ obj_face           face object
 *     INT iedge                   edge on the element to be set
 *     FEM_BOOLEAN node_orientation (-1 or 1) defines how the current use of
 *                                 the edge is oriented with respect to how
 *                                 the edge is stored
 * === Return: nothing
 */
#define fem_faSetEdgeOrientation_C( obj_face, iedge, nd_orient )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((FACE_PTYP)(obj_face))->aps_edge_use[iedge]->node_orientation =\
            (FEM_BOOLEAN)nd_orient;\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }

#endif
