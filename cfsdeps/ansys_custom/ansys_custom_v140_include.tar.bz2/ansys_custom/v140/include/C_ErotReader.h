//////////////////////////////////////////////////////////////////////////// 
//          Copyright (C) 2010 ANSYS Inc.  All Rights Reserved            // 
//                                                                        // 
// This file contains proprietary software licensed from ANSYS Inc.       // 
// This header must remain in any source code despite modifications or    // 
// enhancements by any party.                                             // 
//                                                                        // 
//////////////////////////////////////////////////////////////////////////// 
// 
// $Workfile: C_ErotReader.h
// $Revision: 
// $Date: 
// $Author: 
// 
// Decription:  
// 
//////////////////////////////////////////////////////////////////////////// 

#ifndef __C_EROTREADER_H__ 
#define __C_EROTREADER_H__ 1 

#include "C_AnsysModele.h"
#include "SxSparseMso.h"
#include "AnsysBin.h"
#include "CoreDomain.h"
#include "vt_global.h"

class AnsysBC;

class C_ErotReader
{
public:
  C_ErotReader(bool unsym, int *AnsToLocalRow, int *AnsToLocalCol, int dimLocal, bool readLoad, AnsysBC *ansysPres = NULL)
  {
    _unsym = unsym;
    _AnsToLocalRow = AnsToLocalRow; 
    _AnsToLocalCol = AnsToLocalCol; 
    _dimLocal = dimLocal;
    if (readLoad)
      _load = new C_VecPi<double> (dimLocal);
    else 
      _load = NULL;
    _ansysPres = ansysPres;
  }
  virtual ~C_ErotReader() {;}
  
  C_Vec<double> *getRhs() {return _load;}
  void readMatAndLoad(int matCode);
  
protected: 
  void openErotFile()
  {
    int ier(0);
    initelemread(&ier); 
    if (ier != 0) CADOE_THROW(E_VtcError);
  }
  
  void closeErotFile(char *pstat)
  {
    int pstat_len = strlen(pstat);
    closelemread(CCHAR(pstat) CCHARL(pstat_len));
  }
  
  void readErotElem(int indElem, int &nr, int *dofs, double stiff[][MAXNUMDOFSPERELEM], double *load, int *unsym)
  {
    int ier(0);
    int indElemFortran = indElem+1;
    elemread(&indElemFortran,&nr,dofs,&stiff[0][0],load,unsym,&ier);
    if (ier != 0) CADOE_THROW(E_VtcError); 
  }
  virtual void initFillStructure()
  {
    // open the .erot file file
    openErotFile();
  }
  virtual void fillStructure(int *dofs, int nr, bool unsym) {;};
  virtual void endFillStructure()
  {
    // close .erot file
    closeErotFile("K");
  }
  virtual void initFillValues()
  {
    // open the .erot file file
    openErotFile();
  }
  virtual void fillValues(int *dofs, double *stiff, int nr, bool unsym) = 0;
  virtual void endFillValues()
  {
    // close .erot file
    closeErotFile("K");
  }
  
protected:
  bool _unsym;
  int *_AnsToLocalRow; 
  int *_AnsToLocalCol; 
  int _dimLocal;
  AnsysBC *_ansysPres;
  C_Vec<double> *_load;
};

class C_ErotReaderMatMGe : public C_ErotReader
{
public:
  C_ErotReaderMatMGe(bool unsym, int *AnsToLocalRow, int *AnsToLocalCol, int dimLocal, bool readLoad, AnsysBC *ansysPres = NULL) : 
    C_ErotReader(unsym,AnsToLocalRow,AnsToLocalCol,dimLocal,readLoad,ansysPres) 
  {
    _mat = new C_MatMGe<double> (dimLocal,dimLocal); 
  }
  ~C_ErotReaderMatMGe() {};
  
  C_MatMGe<double> *getMat() {return _mat;}
  
protected:
  void fillValues(int *dofs, double *stiff, int nr, bool unsym)
  {
    char fctn [] = "C_ErotReaderMatMGe::fillValues";		CADOE_TRACE(fctn);
    
    for (int irow = 0; irow < nr; irow++)
      {
	if (dofs[irow] == 0) continue;
	int localRow = _AnsToLocalRow[dofs[irow]-1];
	if (localRow == -1) continue;
	for (int icol = 0; icol < nr; icol++)
	  {
	    int localCol = _AnsToLocalCol[dofs[icol]-1];
	    if (localCol == -1) continue;
	    (*_mat)(localRow,localCol) += stiff[irow*nr+icol];
	  }
      }
    
    return;
  }
  
protected:
  C_MatMGe<double> *_mat;
};

class C_ErotReaderMatSp : public C_ErotReader
{
public:
  C_ErotReaderMatSp(bool unsym, int *AnsToLocalRow, int *AnsToLocalCol, int dimLocal, bool readLoad, AnsysBC *ansysPres = NULL) : 
    C_ErotReader(unsym,AnsToLocalRow,AnsToLocalCol,dimLocal,readLoad,ansysPres) {_mat = NULL;}
  ~C_ErotReaderMatSp() {};

  C_MatSp<double> *getMat() {return _mat;}
  
protected:
  virtual void initFillStructure()
  { 
    char fctn [] = "C_ErotReaderMatSp::initFillStructure";	CADOE_TRACE(fctn);
    
    C_ErotReader::initFillStructure();
    
    // allocate matrix
    _mat = new C_MatSp<double> (_dimLocal,_dimLocal);
    _mat->setSymmetric(!_unsym);
    
    // initializw working array
    _cptPerRow.Resize(_dimLocal);
  }
  
  void fillStructure(int *dofs, int nr, bool unsym)
  {
    char fctn [] = "C_ErotReaderMatSp::fillStructure";		CADOE_TRACE(fctn);
    int nbddl = G_AnsysModele->getNbddl();
    
    for (int irow = 0; irow < nr; irow++)
      {
	if (dofs[irow] == 0) continue;
	int localRow = _AnsToLocalRow[dofs[irow]-1];
	if (localRow == -1) continue;
	for (int icol = 0; icol < nr; icol++)
	  {
	    if (dofs[icol] == 0) continue;
	    if (_unsym == 0 && dofs[irow] < dofs[icol]) continue; 
	    int localCol = _AnsToLocalCol[dofs[icol]-1];
	    if (localCol == -1) continue;
	    
	    _cptPerRow[localCol]++;
	    
	    if (_unsym == 1 && !unsym && localRow != localCol)
	      _cptPerRow[localRow]++;
	  }
      }
    
    return;
  }
  
  virtual void initFillValues()
  {
    char fctn [] = "C_ErotReaderMatSp::initFillValues";		CADOE_TRACE(fctn);
    
    C_ErotReader::initFillValues();
    
    // initialize _rows of the matrix
    Hyper *rows = _mat->Nz();
    rows[0] = 1;			// fortran indices
    for (int irow = 0; irow < _dimLocal; irow++)
      rows[irow+1] = rows[irow]+_cptPerRow[irow];
    _cptPerRow.Zero();
    _mat->Resize(_dimLocal,_dimLocal,rows[_dimLocal]-1);
  }

  void fillValues(int *dofs, double *stiff, int nr, bool unsym)
  {
    char fctn [] = "C_ErotReaderMatSp::fillValues";		CADOE_TRACE(fctn);
    
    Hyper *rows = _mat->Nz();
    int *cols = _mat->ColNum();
    double *vals = _mat->Adr();
    
    for (int irow = 0; irow < nr; irow++)
      {
	if (dofs[irow] == 0) continue;
	int localRow = _AnsToLocalRow[dofs[irow]-1];
	if (localRow == -1) continue;
	for (int icol = 0; icol < nr; icol++)
	  {
	    if (dofs[icol] == 0) continue;
	    if (_unsym == 0 && dofs[irow] < dofs[icol]) continue; 
	    int localCol = _AnsToLocalCol[dofs[icol]-1];
	    if (localCol == -1) continue;
	    
	    cols[rows[localCol]-1+_cptPerRow[localCol]] = localRow+1;
	    vals[rows[localCol]-1+_cptPerRow[localCol]] += stiff[irow*nr+icol];
	    _cptPerRow[localCol]++;
	    
	    if (_unsym == 1 && !unsym && localRow != localCol)
	      {
		// add the symmetric part
		cols[rows[localRow]-1+_cptPerRow[localRow]] = localCol+1;
		vals[rows[localRow]-1+_cptPerRow[localRow]] += stiff[irow*nr+icol];
		_cptPerRow[localRow]++;
	      }
	  }
      }
    
    return;
  }
  
  void endFillValues()
  {
    char fctn [] = "C_ErotReaderMatSp::endFillValues";	CADOE_TRACE(fctn);
    
    // we compact the sparse matrix
    int i, irow, icol;
    Hyper *rows = _mat->Nz();
    int *cols = _mat->ColNum();
    double *vals = _mat->Adr();
    
    C_VecPi<int> tmp(_dimLocal);
    C_VecPi<int> tmp2(_dimLocal);
    C_VecPi<double> val(_dimLocal);
    
    // count nnz of the compact matrix
    int compactNnz = 0;
    for (irow = 0; irow < _dimLocal; irow++)
      {
	// count nnz?
	int nnz = 0;
	int iStart = rows[irow]-1;
	int iEnd = rows[irow+1]-1;
	for (icol = iStart; icol < iEnd; icol++)
	  {
	    int idxCol = cols[icol]-1;
	    if (tmp[idxCol] == 0)
	      {
		tmp2[nnz++] = idxCol;
	      }
	    tmp[idxCol]++;
	  }
	for (int i = 0; i < nnz; i++)
	  tmp[tmp2[i]] = 0;
	
	compactNnz += nnz;
      }
    
    // fill new compact matrix
    C_MatSp<double> *compactmat = new C_MatSp<double>(_dimLocal,_dimLocal,compactNnz);
    compactmat->setSymmetric(this->_mat->Sym());

    Hyper *compactRows = compactmat->Nz();
    int *compactCols = compactmat->ColNum();
    double *compactVals = compactmat->Adr();
    
    compactRows[0] = 1;
    for (irow = 0; irow < _dimLocal; irow++)
      {
	compactRows[irow+1] = compactRows[irow];
	
	int nnz = 0;
	int iStart = rows[irow]-1;
	int iEnd = rows[irow+1]-1;
	for (icol = iStart; icol < iEnd; icol++)
	  {
	    int idxCol = cols[icol]-1;
	    if (tmp[idxCol] == 0)
	      {
		tmp2[nnz++] = idxCol;
	      }
	    tmp[idxCol]++;
	    val[idxCol] += vals[icol];
	  }
	if (nnz == 0) continue;

	for (i = 0; i < nnz; i++)
	  {
	    compactCols[compactRows[irow+1]-1] = tmp2[i]+1;
	    compactVals[compactRows[irow+1]-1] = val[tmp2[i]];
	    compactRows[irow+1]++;
	    
	    tmp[tmp2[i]] = 0;
	    val[tmp2[i]] = 0.;
	  }
	
	// reorder the indices
	C_VecPi<int>	vi(nnz,compactCols+compactRows[irow]-1);
	MEM_COPY(compactVals+compactRows[irow]-1,val.Adr(),nnz*sizeof(double));
	vi.Sort(tmp2);
	for (i = 0; i < nnz; i++)
	  {
	    compactVals[compactRows[irow]+i-1] = val[tmp2[i]];
	    val[tmp2[i]] = 0.;
	  }
      }
    
    delete _mat;
    _mat = compactmat;
    
    return;
  }
  
protected:
  C_MatSp<double> *_mat;
  C_VecPi<int> _cptPerRow;
};

#endif
