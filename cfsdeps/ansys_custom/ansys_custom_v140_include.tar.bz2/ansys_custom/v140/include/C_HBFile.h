/**
 * @file   C_HBFile.h
 * @author  <ftheveno@LYOFTHEVENO8>
 * @date   Wed Oct 14 11:41:47 2009
 * 
 * @brief  Harwell Boeing File
 * 
 * 
 */

#ifndef __C_HBFILE_H__
#define __C_HBFILE_H__	1

#include "CadoeAnsys.h"
#include "C_Mat.h"
#include "C_DataFile.h"

/*!
 *  \class	C_HBFile
 *  \brief	
 *  \author	Frederic Thevenon
 *  \version	1.0
 *  \date	2009
 *  \bug	
 *  \warning	
 *
 *  version 1.0 :       Initial Revision
 */

class C_HBFile : public C_DataFile
{
public:

  virtual const char *StrType() { return "C_HBFile";}

  C_HBFile( const _TCHAR *FileName = NULL, bool create=false);
  virtual ~C_HBFile() {};
  
  void	Initialize( bool Ascii = false);
  int	getNumRhs( void) { return _nRhs;}
  void	getMatSize( int &nRow, int &nCol, Hyper &ntermL);

  template <typename T> C_Mat<T>	*getMat( int numMat = 0, C_Mat<T> *Mat = NULL, char Format = 'S');
  template <typename T> C_Vec<T>	*getVec( int numVec = 0, C_Vec<T> *Vec = NULL);

private:
  bool			_Initialized;

  char		_cFName[LENFNM];
  int		_name_len;
  int		_Ascii;
  int		_nRow, _nCol;
  Hyper		_nTermL;
  int		_nRhs;
  int		_Unsym;
  int		_Cplx;
};

#endif	// __C_HBFILE_H__
