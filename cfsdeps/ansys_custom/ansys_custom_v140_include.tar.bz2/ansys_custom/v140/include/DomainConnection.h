/*HFILE DomainConnection.h                  ANSI_C                      dc
------------------------------------------------------------------------
------- Notice - This file contains ANSYS Confidential information
------------------------------------------------------------------------
*/

/*------------------------------ Description ---------------------------

\Author:    Dave Conover

\Title:     Standard Domain Connection C Header

\Desc:      Header for Domain Connections (xxToyy data structures)

            Currently contains the following Connection functions:

                   CreateConnections
                   DeleteConnection
                   DeleteConnections
                   ConnectionDefine
                   ConnectionTrans
                   ConnectionTransGeneral
                   ConnectionReverse
                   CreateSharedNodesAll
                   CreateSharedNodesForDomain
                   DomElemInqr
                   DomNodeInqr
                   NodeDomInqr

\History:   Created 6/5/03 (dc)

\Function(s)
 -Primary:      Standard Domain Connection C header
 -Secondary:    Prototypes for DomainConnection.c
 -External:     none
 -Internal:     none
 -Static:       none

----------------------------------------------------------------------*/

/*------------------------------ Strucs ------------------------------*/

#ifndef __DOMAINCONNECTION_H__
#define __DOMAINCONNECTION_H__ 1

typedef struct domain_connection_type *DomainConnection;

struct domain_connection_type {
  INT  numptr;
  INT  numtarget;
  INT *pointer;
  INT *target;
  INT *ptrID;    /* PtrID is used only by one case, sharedNode,*/
                 /* to identify the neighbor subdomain number  */
};

/*------------------------------ Macros -----------------------------*/

/* assume connection table  xxToyy, e.g. DomToElem
  where xx is a set of pointers to data (target) in yy

   ctPsize(ct)    returns # of pointers in xx
   ctTsize(ct)    returns # of target data in yy
   ctTnum(ct,n)   returns subset # of yy pointed to by the n-th xx
   ctTval(ct,n,i) returns i-th value of yy pointed to by the n-th xx
   ctPtrID(ct,n)  returns the pointer ID for the n-th xx   */

#define ctPsize(ct)     (ct ? ct->numptr : 0)
#define ctTsize(ct)     (ct->numtarget)
#define ctTnum(ct,n)    (n >= (ct->numptr) ? 0 :((ct->pointer[n+1])-(ct->pointer[n])))
#define ctTval(ct,n,i)  (ct->target[(ct->pointer[n])+i])
#define ctPtrID(ct,n)   (ct->ptrID[n])

/*-------------------------------- Globals ---------------------------*/

extern DomainConnection DomToElem, DomToNode, NodeToDom, SharedNodes;

#define MAX_DOMAINS    400000      /* from DomainCom.inc */

/*------------------------------ Prototypes --------------------------*/

DomainConnection ConnectionDefine(INT, INT*, INT*, INT*);
DomainConnection ConnectionTrans(DomainConnection, DomainConnection);
DomainConnection ConnectionTransGeneral(DomainConnection, DomainConnection);
DomainConnection ConnectionReverse(DomainConnection);

void CreateSharedNodesAll(DomainConnection, DomainConnection, INT);
DomainConnection CreateSharedNodesForDomain(DomainConnection, DomainConnection, INT);

void DumpConnection(CHAR*, CHAR*, CHAR*, DomainConnection, INT);


/*------------------------- C called from FORTRAN --------------------*/

#if defined(UPPERCASENOUNDER_SYS)
#define CreateConnections CREATECONNECTIONS
#define DeleteConnection  DELETECONNECTION
#define DeleteConnections DELETECONNECTIONS
#define DomElemInqr DOMELEMINQR
#define DomNodeInqr DOMNODEINQR
#define NodeDomInqr NODEDOMINQR
#define GetSharedNodeList GETSHAREDNODELIST
#define GetSharedNodeSize GETSHAREDNODESIZE
#endif

#if defined(LOWERCASENOUNDER_SYS)
#define CreateConnections createconnections
#define DeleteConnection  deleteconnection
#define DeleteConnections deleteconnections
#define DomElemInqr domeleminqr
#define DomNodeInqr domnodeinqr
#define NodeDomInqr nodedominqr
#define GetSharedNodeList getsharednodelist
#define GetSharedNodeSize getsharednodesize
#endif

#if defined(LOWERCASEUNDER_SYS)
#define CreateConnections createconnections_
#define DeleteConnection  deleteconnection_
#define DeleteConnections deleteconnections_
#define DomElemInqr domeleminqr_
#define DomNodeInqr domnodeinqr_
#define NodeDomInqr nodedominqr_
#define GetSharedNodeList getsharednodelist_
#define GetSharedNodeSize getsharednodesize_
#endif

SUBROUTINE CreateConnections(INT*, INT*, INT*, INT*, INT*, INT*, INT*, INT*);
SUBROUTINE DeleteConnection(DomainConnection);
SUBROUTINE DeleteConnections();

INT FUNCTION DomElemInqr(INT*, INT*);
INT FUNCTION DomNodeInqr(INT*, INT*);
INT FUNCTION NodeDomInqr(INT*, INT*);
INT FUNCTION GetSharedNodeList(INT*, INT*);
INT FUNCTION GetSharedNodeSize();

/*------------------------- FORTRAN called from C --------------------*/

#if defined(UPPERCASENOUNDER_SYS)
#define elmget ELMGET
#define elmiqr ELMIQR
#define etyget ETYGET
#define conget CONGET
#define hElemNodeRange HELEMNODERANGE
#define get_nnd_cont GET_NND_CONT
#endif

#if defined(LOWERCASENOUNDER_SYS)
#define elmget elmget
#define elmiqr elmiqr
#define etyget etyget
#define conget conget
#define hElemNodeRange helemnoderange
#define get_nnd_cont get_nnd_cont
#endif

#if defined(LOWERCASEUNDER_SYS)
#define elmget elmget_
#define elmiqr elmiqr_
#define etyget etyget_
#define conget conget_
#define hElemNodeRange helemnoderange_
#define get_nnd_cont get_nnd_cont_
#endif

INT FUNCTION  elmget(INT*, INT*, INT*);
INT FUNCTION  elmiqr(INT*, INT*);
INT FUNCTION  etyget(INT*, INT*);
INT FUNCTION  conget(INT*, INT*);
VOID FUNCTION hElemNodeRange(INT*, INT*, INT*, INT*, INT*);
VOID FUNCTION get_nnd_cont(INT *, INT *, INT *);
#endif
