/* sid 60.21 copy of INIS_Api.h last changed by rjayasee on 2006/08/01 18:37:13 */

/*
////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         copyright(c) 2011 SAS IP, Inc.  All rights reserved.             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: INIS_API.h $
// $Revision: 495681 $ 7.0
// $Date: 2011-08-02 14:31:04 -0400 (Tue, 02 Aug 2011) $ October 04 2005
// $Author: rjayasee $ rjayasee
//
// Decription :
// Api for the Initial State Cache. Data is stored here/cached here before
// written/exported to the database or a file ....
//
// This is the single point/junction for writing and reading data.
//
////////////////////////////////////////////////////////////////////////////
*/

#include "ANS_StandardIncludes.h"

/* (1)----------------------------------------------------------------*/
#if defined(LOWERCASENOUNDER_SYS)

/*
 *   The pattern for these platforms is the lowercased version of the name
 */

#define INIS_SetData          inis_setdata
#define INIS_SetDataNB        inis_setdatanb
#define INIS_SetParam         inis_setparam
#define INIS_GetCurDataType   inis_getcurdatatype
#define INIS_GetCurCSID       inis_getcurcsid
#define INIS_GetCurMatId      inis_getcurmatid
#define INIS_GetData          inis_getdata
#define INIS_DeleteData       inis_deletedata
#define INIS_WriteToFile      inis_writetofile
#define INIS_CDWrite          inis_cdwrite
#define INIS_ReadFromFile     inis_readfromfile
#define INIS_ListData         inis_listdata
#define INIS_GetInitialState  inis_getinitialstate
#define INIS_GetInitialStateNB  inis_getinitialstatenb
#define INIS_GetInitialStateGeneric  inis_getinitialstategeneric
#define INIS_GetInitialStateDataSize inis_getinitialstatedatasize
#define INIS_CalculateFieldAtIntPts inis_calculatefieldatintpts
#define INIS_CalculateFieldAtMSideNodes inis_calculatefieldatmsidenodes
#define INIS_CalculateFieldAtIPLay inis_calculatefieldatiplay
#define INIS_IsNewVersionUsed inis_isnewversionused
#define INIS_TriggerNewVersion inis_triggernewversion
#define INIS_TriggerWrite      inis_triggerwrite
#define INIS_GetLSToWrite      inis_getlstowrite
#define INIS_GetSSToWrite      inis_getsstowrite
#define INIS_IsWriteOn         inis_iswriteon
#define INIS_SetDTypeWriteFlag inis_setdtypewriteflag
#define INIS_GetDTypeWriteFlag inis_getdtypewriteflag
#define INIS_SetWrittenFlag    inis_setwrittenflag
#define INIS_ClearInMemDB     inis_clearinmemdb
#define INIS_ClearGlobals     inis_clearglobals
#define INIS_DeleteCacheForCurProc inis_deletecacheforcurproc
#define INIS_StartMemoryManager     inis_startmemorymanager
#define INIS_ShutDownMemoryManager  inis_shutdownmemorymanager
#define INIS_StartMemForProc     inis_startmemforproc
#define INIS_EndMemForProc       inis_endmemforproc
#define INIS_ReUseMemForProc     inis_reusememforproc
#define INIS_InitializeDatabase  inis_initializedatabase
#define INIS_GetWriteCS          inis_getwritecs
#define INIS_SetWriteCS          inis_setwritecs
#define INIS_IsIStrainUsed       inis_isistrainused
#define INIS_IsNodeBased         inis_isnodebased
#define INIS_UpdISFILEWarnCount  inis_updisfilewarncount
#define INIS_GetISFILEWarnCount  inis_getisfilewarncount
#define INIS_DistributeGlobalVariables inis_distributeglobalvariables
#define INIS_MergeDistrIstFiles  inis_mergedistristfiles
#define INIS_GetTypeGivenNameFToC inis_gettypegivennameftoc
#define INIS_SetDatabaseType     inis_setdatabasetype
#define INIS_IsNodeBasedDataUsed inis_isnodebaseddataused
#endif


/* (2)----------------------------------------------------------------*/
#if defined(UPPERCASENOUNDER_SYS)

/*
 *   The pattern for these platforms is the uppercased version of the name
 */

#define INIS_SetData          INIS_SETDATA
#define INIS_SetDataNB        INIS_SETDATANB
#define INIS_SetParam         INIS_SETPARAM
#define INIS_GetCurDataType   INIS_GETCURDATATYPE
#define INIS_GetCurCSID       INIS_GETCURCSID
#define INIS_GetCurMatId      INIS_GETCURMATID
#define INIS_GetData          INIS_GETDATA
#define INIS_DeleteData       INIS_DELETEDATA
#define INIS_WriteToFile      INIS_WRITETOFILE
#define INIS_CDWrite          INIS_CDWRITE
#define INIS_ReadFromFile     INIS_READFROMFILE
#define INIS_ListData         INIS_LISTDATA
#define INIS_GetInitialState  INIS_GETINITIALSTATE
#define INIS_GetInitialStateNB  INIS_GETINITIALSTATENB
#define INIS_GetInitialStateGeneric  INIS_GETINITIALSTATEGENERIC
#define INIS_GetInitialStateDataSize INIS_GETINITIALSTATEDATASIZE
#define INIS_CalculateFieldAtIntPts INIS_CALCULATEFIELDATINTPTS
#define INIS_CalculateFieldAtMSideNodes INIS_CALCULATEFIELDATMSIDENODES
#define INIS_CalculateFieldAtIPLay INIS_CALCULATEFIELDATIPLAY
#define INIS_IsNewVersionUsed INIS_ISNEWVERSIONUSED
#define INIS_TriggerNewVersion INIS_TRIGGERNEWVERSION
#define INIS_TriggerWrite      INIS_TRIGGERWRITE
#define INIS_GetLSToWrite      INIS_GETLSTOWRITE
#define INIS_GetSSToWrite      INIS_GETSSTOWRITE
#define INIS_IsWriteOn         INIS_ISWRITEON
#define INIS_SetDTypeWriteFlag INIS_SETDTYPEWRITEFLAG
#define INIS_GetDTypeWriteFlag INIS_GETDTYPEWRITEFLAG
#define INIS_SetWrittenFlag    INIS_SETWRITTENFLAG
#define INIS_ClearInMemDB     INIS_CLEARINMEMDB
#define INIS_ClearGlobals     INIS_CLEARGLOBALS
#define INIS_DeleteCacheForCurProc INIS_DELETECACHEFORCURPROC
#define INIS_StartMemoryManager     INIS_STARTMEMORYMANAGER
#define INIS_ShutDownMemoryManager  INIS_SHUTDOWNMEMORYMANAGER
#define INIS_StartMemForProc     INIS_STARTMEMFORPROC
#define INIS_EndMemForProc       INIS_ENDMEMFORPROC
#define INIS_ReUseMemForProc     INIS_REUSEMEMFORPROC
#define INIS_InitializeDatabase  INIS_INITIALIZEDATABASE
#define INIS_GetWriteCS          INIS_GETWRITECS
#define INIS_SetWriteCS          INIS_SETWRITECS
#define INIS_IsIStrainUsed       INIS_ISISTRAINUSED
#define INIS_IsNodeBased         INIS_ISNODEBASED
#define INIS_UpdISFILEWarnCount  INIS_UPDISFILEWARNCOUNT
#define INIS_GetISFILEWarnCount  INIS_GETISFILEWARNCOUNT
#define INIS_DistributeGlobalVariables INIS_DISTRIBUTEGLOBALVARIABLES
#define INIS_MergeDistrIstFiles  INIS_MERGEDISTRISTFILES
#define INIS_GetTypeGivenNameFToC INIS_GETTYPEGIVENNAMEFTOC
#define INIS_SetDatabaseType     INIS_SETDATABASETYPE
#define INIS_IsNodeBasedDataUsed INIS_ISNODEBASEDDATAUSED
#endif


/* (3)----------------------------------------------------------------*/
#if defined(LOWERCASEUNDER_SYS)

/*
 *   The pattern for these platforms is the lowercased version of the name 
 *   followed by an underscore
 */

#define INIS_SetData          inis_setdata_
#define INIS_SetDataNB        inis_setdatanb_
#define INIS_SetParam         inis_setparam_
#define INIS_GetCurDataType   inis_getcurdatatype_
#define INIS_GetCurCSID       inis_getcurcsid_
#define INIS_GetCurMatId      inis_getcurmatid_
#define INIS_GetData          inis_getdata_
#define INIS_DeleteData       inis_deletedata_
#define INIS_WriteToFile      inis_writetofile_
#define INIS_CDWrite          inis_cdwrite_
#define INIS_ReadFromFile     inis_readfromfile_
#define INIS_ListData         inis_listdata_
#define INIS_GetInitialState  inis_getinitialstate_
#define INIS_GetInitialStateNB  inis_getinitialstatenb_
#define INIS_GetInitialStateGeneric  inis_getinitialstategeneric_
#define INIS_GetInitialStateDataSize inis_getinitialstatedatasize_
#define INIS_CalculateFieldAtIntPts inis_calculatefieldatintpts_
#define INIS_CalculateFieldAtMSideNodes inis_calculatefieldatmsidenodes_
#define INIS_CalculateFieldAtIPLay inis_calculatefieldatiplay_
#define INIS_IsNewVersionUsed inis_isnewversionused_
#define INIS_TriggerNewVersion inis_triggernewversion_
#define INIS_TriggerWrite      inis_triggerwrite_
#define INIS_GetLSToWrite      inis_getlstowrite_
#define INIS_GetSSToWrite      inis_getsstowrite_
#define INIS_IsWriteOn         inis_iswriteon_
#define INIS_SetDTypeWriteFlag inis_setdtypewriteflag_
#define INIS_GetDTypeWriteFlag inis_getdtypewriteflag_
#define INIS_SetWrittenFlag    inis_setwrittenflag_
#define INIS_ClearInMemDB     inis_clearinmemdb_
#define INIS_ClearGlobals     inis_clearglobals_
#define INIS_DeleteCacheForCurProc inis_deletecacheforcurproc_
#define INIS_StartMemoryManager     inis_startmemorymanager_
#define INIS_ShutDownMemoryManager  inis_shutdownmemorymanager_
#define INIS_StartMemForProc     inis_startmemforproc_
#define INIS_EndMemForProc       inis_endmemforproc_
#define INIS_ReUseMemForProc     inis_reusememforproc_
#define INIS_InitializeDatabase  inis_initializedatabase_
#define INIS_GetWriteCS          inis_getwritecs_
#define INIS_SetWriteCS          inis_setwritecs_
#define INIS_IsIStrainUsed       inis_isistrainused_
#define INIS_IsNodeBased         inis_isnodebased_
#define INIS_UpdISFILEWarnCount  inis_updisfilewarncount_
#define INIS_GetISFILEWarnCount  inis_getisfilewarncount_
#define INIS_DistributeGlobalVariables inis_distributeglobalvariables_
#define INIS_MergeDistrIstFiles  inis_mergedistristfiles_
#define INIS_GetTypeGivenNameFToC inis_gettypegivennameftoc_
#define INIS_SetDatabaseType     inis_setdatabasetype_
#define INIS_IsNodeBasedDataUsed inis_isnodebaseddataused_

#endif


#ifdef __cplusplus
extern "C"
{
#endif


INT INIS_SetParam( FCHAR(oName), FCHAR(oVal), DOUBLE* pParamValue FCHARL(oName_len) FCHARL(oVal_len));
/*
//R Result
//R 0 if failure, 1 if success
//I oName
//- Parameter Name
//I pParamValue
//- Parameter Value
//- Set the Initial State Parameters
*/

FUNCTION INT INIS_GetCurDataType() ;
//R Returns the current datatype to be used by future INIS commands

FUNCTION INT INIS_GetCurCSID() ;
//R Returns the current cys to be used by future INIS commands

FUNCTION INT INIS_GetCurMatId() ;
//R Returns the current matid to be used by future INIS commands


FUNCTION INT INIS_GetWriteCS();
FUNCTION VOID INIS_SetWriteCS(INT*);
//- Gets the Current Coordinate System to be applied to future INIS commands
//- or the CS to which initial stress is written to.

FUNCTION INT INIS_IsNodeBased() ;
//Return 1 if node based

SUBROUTINE INIS_SetDatabaseType(INT* pType) ;
//I pType
//- Set pType to 1 for Node Based or 0 for Element Based

INT INIS_SetData( INT* pElemId, 
                  INT* pIntPtInfo, 
                  INT* pNumIntPtInfo, 
                  INT* pDataType,
                  INT* pCSId,
                  INT* pMatId,
                  DOUBLE* pData, 
                  INT* pDataSize,
                  INT* pWriteFlag ) ;
/*
//R Result
//R 0 if failure, 1 if success
//L pElemId
//- Element Id
//L pElemType
//- Element Type
//I pDataType
//I-Data Type
//I pCSID
//- Coordinate System ID
//I pIntPtInfo
//- Integration Point Info.
//- pIntPtInfo[0] --- Integration Point
//- pIntPtInfo[1] --- Layer Index for Composite Sections
//- pIntPtInfo[2] --- Section Int Pt within a Layer
//I pData
//- Data to be written
//I pDataSize
//- Size of the Data
//I iDataType
//- DataType
//I pWriteFlag
//- 0 to not write , 1 to write to DB
//- Set the Initial State of the Data
*/

INT INIS_SetDataNB( INT* pElemId, 
                    INT* pIntPtInfo, 
                    INT* pNumIntPtInfo, 
                    INT* pDataType,
                    INT* pCSId,
                    INT* pMatId,
                    DOUBLE* pData, 
                    INT* pDataSize,
                    INT* pWriteFlag ) ;
/*
//R Result
//R 0 if failure, 1 if success
//L pElemId
//- Element Id
//L pElemType
//- Element Type
//I pCSID
//- Coordinate System ID
//I pIntPtInfo
//- Integration Point Info.
//- pIntPtInfo[0] --- Integration Point
//- pIntPtInfo[1] --- Layer Index for Composite Sections
//- pIntPtInfo[2] --- Section Int Pt within a Layer
//I pData
//- Data to be written
//I pDataSize
//- Size of the Data
//I iDataType
//- DataType
//I pWriteFlag
//- 0 to not write , 1 to write to DB
//- Set the Initial State of the Data for Node based

INT INIS_DeleteData( INT* pElem, INT* pCSID,
                     INT* pIntPtInfo, INT* pNumIntPtInfo ) ;
/*
//R Result
//R 0 if failure, 1 if success
//L pElem
//- Element Id
//I pCSID
//- Coordinate System ID
//I pIntPtInfo
//- Integration Point Info.
//- pIntPtInfo[0] --- Integration Point
//- pIntPtInfo[1] --- Layer Index for Composite Sections
//- pIntPtInfo[2] --- Section Int Pt within a Layer
//I pData
//- Data to be written
//I pDataSize
//- Size of the Data
//I iDataType
//- DataType
//- Delete or Set to Zero the initial state of the element
*/

INT INIS_GetData( INT* pElem, INT* pCSID,
                  INT* pIntPtInfo, INT* pNumIntPtInfo, 
                  DOUBLE* pData, INT* pDataSize ) ;
/*
//R Result
//R 0 if failure, 1 if success
//L pElem
//- Element Id
//I pCSID
//- Coordinate System ID
//I pIntPtInfo
//- Integration Point Info.
//- pIntPtInfo[0] --- Integration Point
//- pIntPtInfo[1] --- Layer Index for Composite Sections
//- pIntPtInfo[2] --- Section Int Pt within a Layer
//I pData
//- Data to be written
//O pDataSize
//- Size of the Data
//O iDataType
//- DataType
//- Get the Initial State of the Data
*/

INT INIS_ListData( INT* pElemId,char* sDType FCHARL(sDType_len) );
/*
//R Result
//I pElemId
//- Element Id
//- Printing Initial State Data
*/

INT INIS_WriteToFile( INT* iSelFlag, INT* pDataTypes, INT* pNumDataTypes ) ;
/*
//R
//I iSelFlag
//-
//I pDataType
//- Data Type to be written to file
//I pNumDataType
//- Num Data Types provided
//- Writes All Initial State Information to a file
*/

FUNCTION INT INIS_ReadFromFile( char* pFileName FCHARL(pFileName_len)  ) ;
//R INT
//R 0 if failure
//I pFileName
//I IST File Name
//- Reads initial stress data from a file

FUNCTION INT INIS_CDWrite(INT* pUnit, INT* iElemId) ;
//R INT
//I pUnit
//- Fortran Unit to write the cdb data to
//I iElemId
//I-Element Id
//- Code to generate cdb data for initial state

FUNCTION VOID INIS_InitializeDatabase();
/*
//- Initialized/Creates the initial structure
*/

INT INIS_LoadCacheFromDatabase(INT iElem, DOUBLE*pISData) ;
/*
//R Result
//I iElem
//- Element Id
//I pISData
//- Array to use to load up the cache
//- Loads Cache from Database
*/

SUBROUTINE INIS_CalculateFieldAtIntPts( INT* iElemId, INT* pElemChar, DOUBLE* pShapeFn, INT* iNumNodes,
                                        INT* pPar1, INT*pPar2, INT* pPar3 ) ;
//R 
//I iElemId
//I-Element Id
//I pShapeFn
//I-Shape Function
//I iNumNodes
//I-Number of Nodes
//I pPar1 - Elem Intg, pPar2 - Layer, pPar3 - Sec Int Pt
//- Calculate and Store Field Data at Element Integration Points. InMemory Only . Not Saved to DB

SUBROUTINE INIS_CalculateFieldAtMSideNodes( INT* iElemId, INT* pElemChar, DOUBLE* pShapeFn, INT* iNumNodes,
                                            INT* pPar1, INT*pPar2, INT* pPar3 ) ;
//R 
//I iElemId
//I-Element Id
//I pShapeFn
//I-Shape Function
//I iNumNodes
//I-Number of Nodes
//I pPar1 - Elem Intg, pPar2 - Layer, pPar3 - Sec Int Pt
//- Calculate and Store Field Data at MidSide Nodes. InMemory Only. Not Saved to DB

SUBROUTINE INIS_CalculateFieldAtIPLay
        ( INT* pElemId, INT* pElemChar, 
          INT* pElemCharCont, DOUBLE* pLayThickess, DOUBLE* pSecThickness, DOUBLE* pSecIntLoc, DOUBLE* pDZ0,
          DOUBLE* pShapeFn, INT* pNumNodes,
          INT* pPar1, INT* pPar2, INT* pPar3 ) ;
//R 
//I iElemId
//I-Element Id
//I pElemChar
//I-Element Characteristics
//I pElemCharCont
//I-Cont Elem Char
//I pLayThickness
//I-Layer Thickness
//I pSectionThickness
//I-Average Section Thickness
//I pSecIntLoc
//I-Physical Location of Section Intg Pt
//I pDZ0
//I-Lower Value of Z for each layer
//I pShapeFn
//I-Shape Function
//I iNumNodes
//I-Number of Nodes
//I pPar1 - Elem Intg, pPar2 - Layer, pPar3 - Sec Int Pt
//- Calculate and Store Field Data at MidSide Nodes. InMemory Only. Not Saved to DB

INT INIS_GetInitialState( INT* pVar, INT* pCSID, INT* pElemId,
                          INT* pKLayer, INT* pKSect, INT* pIntPt,
                          INT* pMatId, DOUBLE* pDataVec, INT* pVecSize ) ;
/*
//R  1 if success,0 if failure
//I pVar
//- Variable Type
//I pCSID
//- Coordinate System Id
//I pElemId
//- Element Id
//I pKLayer
//- Layer Index
//I pKSect
//- Section Index
//I pIntPt
//- Integration Point
//I pDataVec
//- Data Vector
//I pVecSize
//- Vector Size
//- Returns the Initial State for an element
*/

INT INIS_GetInitialStateNB( INT* pVar, INT* pCSID, INT* pElemId,
                          INT* pKLayer, INT* pKSect, INT* pIntPt,
                          INT* pMatId, DOUBLE* pDataVec, INT* pVecSize ) ;
/*
//R  1 if success,0 if failure
//I pVar
//- Variable Type
//I pCSID
//- Coordinate System Id
//I pElemId
//- Element Id
//I pKLayer
//- Layer Index
//I pKSect
//- Section Index
//I pIntPt
//- Integration Point
//I pDataVec
//- Data Vector
//I pVecSize
//- Vector Size
//- Returns the Initial State for an element Node Based
*/

INT INIS_GetInitialStateGeneric( INT* pSType, INT* pVar, INT* pCSID, INT* pElemId,
                                 INT* pKLayer, INT* pKSect, INT* pIntPt,
                                 INT* pMatId, DOUBLE* pDataVec, INT* pVecSize ) ;
/*
//R  1 if success,0 if failure
//I pSType
//I-Storage Type - 1 if Node Based , 0 if Element Based
//I pVar
//- Variable Type
//I pCSID
//- Coordinate System Id
//I pElemId
//- Element Id
//I pKLayer
//- Layer Index
//I pKSect
//- Section Index
//I pIntPt
//- Integration Point
//I pDataVec
//- Data Vector
//I pVecSize
//- Vector Size
//- Returns the Initial State for an element
*/

INT INIS_GetInitialStateDataSize( INT* pSType, INT* pVar, INT* pCSID, INT* pElemId,
                                  INT* pKLayer, INT* pKSect, INT* pIntPt,
                                  INT* pMatId, INT* pVecSize ) ;
/*
//R  1 if success,0 if failure
//I pSType
//I-Storage Type - 1 if Node Based , 0 if Element Based
//I pVar
//- Variable Type
//I pCSID
//- Coordinate System Id
//I pElemId
//- Element Id
//I pKLayer
//- Layer Index
//I pKSect
//- Section Index
//I pIntPt
//- Integration Point
//I pDataVec
//- Data Vector
//I pVecSize
//- Vector Size
//- Returns the Initial State Array Size for a data type
*/

FUNCTION INT INIS_GetTypeGivenNameFToC(char* pFileName FCHARL(pFileName_len)) ;
//R DataType Integer
//I oName
//I Name of the Param
//- Returns the int equivalent given the name

INT INIS_IsNewVersionUsed();
//R- 1 if the new version of INIS is being used

VOID INIS_TriggerNewVersion( INT* pFlag );

VOID INIS_TriggerWrite( INT* pLSIndex, INT* pSSIndex, INT* pFlag );
//R
//I pLSIndex
//I-Load Step to write IST file
//I pSSIndex
//I-Sub Step to write IST file
//- Turn on/off ist file writing
//- Setting the Load Step and SubStep to write the IST file if turned on
//- -1 for the last step

INT INIS_IsWriteOn();
//R- 1 if the new version of INIS is being used

SUBROUTINE INIS_SetDTypeWriteFlag( INT* pDataType, INT* iFlag ) ;
//R- Sets the write flags for various data types

FUNCTION INT INIS_GetDTypeWriteFlag( INT* pDTypeFlags ) ;
//R- Returns the write flags for various data types

VOID INIS_SetWrittenFlag( INT* pFlag );
//R- Set the Flag indicating that ist file was written

FUNCTION INT INIS_GetLSToWrite();
//R-Gets the LoadStep at which to write the IST File

FUNCTION INT INIS_GetSSToWrite();
//R-Gets the SubStep at which to write the IST File

INT INIS_GetElementTemplate( INT pElemType, struct INIS_ElementTemplate& oElemTempate, INT& iCS  ) ;
//R
//I pElemType
//- Element Type
//I oElemTempate
//- Element Template
//- Returns the Element Template Info

FUNCTION INT INIS_IsIStrainUsed() ;
//Returns 1 if initial strain  is set
SUBROUTINE INIS_DeleteCacheForCurProc() ;
//-  Deletes the Local Cache for the current processor

SUBROUTINE INIS_ClearInMemDB() ;
//-  Deletes the Local Database Memory for INIS Stress.
//-  For all Threads/Procs

bool INIS_SaveToDatabase() ;
//Saves inis data to database

SUBROUTINE INIS_ClearGlobals() ;
//-  Deletes the Global Variables for INIS

SUBROUTINE INIS_StartMemoryManager();
SUBROUTINE INIS_ShutDownMemoryManager() ;
SUBROUTINE INIS_StartMemForProc();
SUBROUTINE INIS_EndMemForProc() ;
SUBROUTINE INIS_ReUseMemForProc() ;

SUBROUTINE INIS_UpdISFILEWarnCount();
FUNCTION INT  INIS_GetISFILEWarnCount();
//Sets and Update ISFILE Warning Count

SUBROUTINE INIS_DistributeGlobalVariables() ;
//Code to distribute global variables

SUBROUTINE INIS_MergeDistrIstFiles(char* pFileName FCHARL(pFileName_len)) ;
//R-Voild
//I pFileName
//I-FileName
//I pFileName_len
//I-Length of FileName
//- Code to Merge IST files for distr ansys solve

FUNCTION INT INIS_IsNodeBasedDataUsed() ;

class ANS_TagMemManager;
extern ANS_TagMemManager** g_ppINISMemManager ;

//Memory Manager for Initial Stress
#ifdef __cplusplus
}
#endif

