
/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 2009 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEMa_coGet.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEMa_coGet.h
 *  header file for FEMa_coGet.c
 *
 */
#ifndef FEMA_COGET_INCLUDE
#define FEMA_COGET_INCLUDE

/*----------------- Globally accessible function prototypes -----------------*/

#ifdef __cplusplus
extern "C" {
#endif

                       /*=================================================== */
                       /* === FEMa_coInitDetachedCMeshDataBase: Initialize   */
                       /* === the C mesh data base and the node hash table   */
                       /* === in preparation to calling                      */
                       /* === FEMa_coGetDetachedAreaElements or              */
                       /* === FEMa_coGetDetachedVolumeElements.              */
INT FEMa_coInitDetachedCMeshDataBase (  );

                       /*=================================================== */
                       /* === FEMa_coGetDetachedAreaElems: get all nodes and */
                       /* === 2D elements in the Ansys data base and store   */
                       /* === in the C meshing data base                     */
INT FEMa_coGetDetachedAreaElems (
   FEM_BOOLEAN *midnodes ,/* return if midnodes exist                        */
   INT stat_process,   /* process to be sent to status window routines       */
   INT      select );  /* what elements to store 0 - all defined             */
                       /*                       -1 - all selected            */

                       /*=================================================== */
                       /* === FEMa_coGetListDetachedAreaElems: get all nodes */
                       /* === 2D elements in the Ansys data base             */
                       /* === from a specified list and store in the C       */
                       /* === meshing data base                              */
INT FEMa_coGetListDetachedAreaElems(
   INT *a_elems,       /* (IN)  array of element numbers                     */
   INT num_elems,      /* (IN)  number of elements                           */
   FEM_BOOLEAN *midnodes,/* (OUT) return if midnodes exist                   */
   INT stat_process ); /* (IN)  process to send to status window routines    */

                       /*=================================================== */
                       /* === FEMa_coGetDetachedVolElems: Get all nodes and  */
                       /* === volume elements in the Ansys data base and     */
                       /* === store in the C meshing data base. Unselected,  */
                       /* === and optionally, unpicked elements are made     */
                       /* === constrained; faces of constrained elements are */
                       /* === also made constrained. Constrained faces and   */
                       /* === elements are moved to rear of face and element */
                       /* === lists.                                         */
INT FEMa_coGetDetachedVolElems (
   FEM_BOOLEAN picked, /* if TRUE and picking invoked, make unpicked         */
                       /* elements constrained                               */
   INT stat_process,   /* process to be sent to status window routines       */
   FEM_BOOLEAN *midnodes  );/* return if midnodes exist                      */

                       /*=================================================== */
                       /* === FEMa_coGetListDetachedVolElems: Get all nodes  */
                       /* === volume elements in the Ansys data base  from   */
                       /* === a specified list and store in the C meshing    */
                       /* === data base.                                     */
INT FEMa_coGetListDetachedVolElems (
   INT *a_elems,       /* (IN)  array of elements                            */
   INT num_elems,      /* (IN)  number of elements                           */
   INT stat_process,   /* (IN) process to be sent to status window routines  */
   FEM_BOOLEAN *midnodes  );/* (OUT) return if midnodes exist                */

                       /*=================================================== */
                       /* === FEMa_coGetAdjEntitiesToKP: create a list of    */
                       /* === adjacent lines and adjacent areas to the       */
                       /* === keypoint (handles allocation of arrays)        */
INT FEMa_coGetAdjEntitiesToKPs (
   INT *kp_list,       /* array of keypoint numbers                          */
   INT num_kp,         /* number of keypoints                                */
   INT *num_adjvols,   /* number of adjacent areas to keypoint               */
   INT **a_adjvols,    /* array of adjacent areas                            */
   INT *num_adjareas,  /* number of adjacent areas to keypoint               */
   INT **a_adjareas,   /* array of adjacent areas                            */
   INT *num_adjlines,  /* number of adjacent lines to keypoint               */
   INT **a_adjlines,   /* array of adjacent lines                            */
   INT *num_nodes,     /* number of nodes associated with the keypoints      */
   INT **a_nodes  );   /* array of node numbers                              */

                       /*=================================================== */
                       /* === FEMa_coGetAdjEntitiesToLines: create a list of */
                       /* === adjacent lines and adjacent areas to a list of */
                       /* === lines (handles allocation of arrays)           */
INT FEMa_coGetAdjEntitiesToLines (
   INT *line_list,     /* array of line numbers                              */
   INT num_lines,      /* number of lines                                    */
   INT *num_adjvols,   /* number of adjacent areas to keypoint               */
   INT **a_adjvols,    /* array of adjacent areas                            */
   INT *num_adjareas,  /* number of adjacent areas to keypoint               */
   INT **a_adjareas,   /* array of adjacent areas                            */
   INT *num_adjlines,  /* number of adjacent lines to keypoint               */
   INT **a_adjlines,   /* array of adjacent lines                            */
   INT *num_nodes,     /* number of nodes associated with the lines          */
   INT **a_nodes  );   /* array of node numbers                              */

                       /*=================================================== */
                       /* === FEMa_coGetAdjEntitiesToAreas: create a list of */
                       /* === adjacent lines and adjacent areas to a list of */
                       /* === areas (handles allocation of arrays)           */
INT FEMa_coGetAdjEntitiesToAreas (
   INT *line_list,     /* array of area numbers                              */
   INT num_lines,      /* number of areas                                    */
   INT *num_adjvols,   /* number of adjacent areas to keypoint               */
   INT **a_adjvols,    /* array of adjacent areas                            */
   INT *num_adjareas,  /* number of adjacent areas to area                   */
   INT **a_adjareas,   /* array of adjacent areas                            */
   INT *num_adjlines,  /* number of adjacent lines to area                   */
   INT **a_adjlines,   /* array of adjacent lines                            */
   INT *num_nodes,     /* number of nodes associated with the areas          */
   INT **a_nodes  );   /* array of node numbers                              */

                       /*=================================================== */
                       /* === FEMa_coGetAdjEntitiesToElems: create a list of */
                       /* === adjacent lines and adjacent areas to a list of */
                       /* === elements (handles allocation of arrays)        */
INT FEMa_coGetAdjEntitiesToElems (
   INT *elem_list,     /* array of element numbers                           */
   INT num_elems,      /* number of elements                                 */
   INT *num_adjvols,   /* number of adjacent areas to keypoint               */
   INT **a_adjvols,    /* array of adjacent areas                            */
   INT *num_adjareas,  /* number of adjacent areas to keypoint               */
   INT **a_adjareas,   /* array of adjacent areas                            */
   INT *num_adjlines,  /* number of adjacent lines to keypoint               */
   INT **a_adjlines,   /* array of adjacent lines                            */
   INT *num_nodes,     /* number of nodes associated with the lines          */
   INT **a_nodes  );   /* array of node numbers                              */

                       /*=================================================== */
                       /* === FEMa_coGetAdjEntitiesToNodes: create a list of */
                       /* === adjacent lines and adjacent areas to the nodes */
                       /* === (handles allocation of arrays)                 */
INT FEMa_coGetAdjEntitiesToNodes (
   INT *a_nodes,       /* array of node numbers                              */
   INT num_nodes,      /* number of nodes                                    */
   INT *num_adjvols,   /* number of adjacent areas to keypoint               */
   INT **a_adjvols,    /* array of adjacent areas                            */
   INT *num_adjareas,  /* number of adjacent areas to keypoint               */
   INT **a_adjareas,   /* array of adjacent areas                            */
   INT *num_adjlines,  /* number of adjacent lines to keypoint               */
   INT **a_adjlines  );/* array of adjacent lines                            */

                       /*=================================================== */
                       /* === FEMa_coAddAreasAdjToVols: When dealing with    */
                       /* === models with volume elements and area elements, */
                       /* === more areas need to be added to a_areas in      */
                       /* === preparation to call FEMa_coSetUpGeometry().    */
                       /* === These other areas are areas on adjacent volumes*/
                       /* === but are not adjacent to any selected entity.   */
                       /* === These other areas area added to a_areas is they*/
                       /* === are not attached to another volume that is     */
                       /* === meshed and not in a_vols.  Find those other    */
                       /* === areas.  (handles allocation of arrays)         */
INT FEMa_coAddAreasAdjToVols (
   INT num_vols,       /* number of volumes in the a_vols                    */
   INT *a_vols,        /* list of volumes                                    */
   INT *num_areas,     /* number of (modifiable) areas on volumes            */
   INT **a_areas  );   /* array of areas on the volumes whose nodes          */
                       /* are permitted to be modified                       */

                       /*=================================================== */
                       /* === FEMa_coSetUpGeometry: set up stuff for line and*/
                       /* === area evaluations on the solid.                 */
INT FEMa_coSetUpGeometry (
   INT num_areas,      /* (IN)     number of areas in the a_areas            */
   INT *a_areas,       /* (IN)     list of areas                             */
   FEM_BOOLEAN alllines,/* (IN)     If FALSE, then only lines adjacent to    */
                       /*          area_id, that are not adjacent to any     */
                       /*          other area, that  is already meshed in    */
                       /*          the native CAD database,  will be cached. */
                       /*          If TRUE, all lines defining area_id  are  */
                       /*          cached.                                   */
                       /*          This is done so that lines adjacent to    */
                       /*          previously meshed areas will not be       */
                       /*          altered by the meshing or smoothing       */
                       /*          process.  Since lines adjacent to         */
                       /*          previously meshed areas are not cached    */
                       /*          if all_lines == FALSE, none of the other  */
                       /*          projection or evaluation routines will    */
                       /*          alter the line in any way since they      */
                       /*          return an error status if an uncached line*/
                       /*          is sent to them.                          */
   INT *num_lines,     /* (OUT)    number of (modifiable) lines on areas     */
   INT **a_lines  );   /* (IN\OUT) array of lines on the areas whose nodes   */
                       /*          are permitted to be modified.  If this    */
                       /*          is sent in as null, then no lines are     */
                       /*          initialized on the areas in a_areas.      */

                       /* ================================================== */
                       /* === FEMa_coGetLines: get the list of lines         */
                       /* === used for evaluations that were initially       */
                       /* === set up in fem_cofacet_                         */
                       /* === Return: INT  EXIT_SUCCESS or EXIT_FAILURE      */
INT FEMa_coGetLines (
   INT *p_num_lines,                  /* return number of lines              */
   INT **pa_lines  );                 /* return array of lines               */

                       /* ================================================== */
                       /* === FEMa_coDeleteLines: delete the list of         */
                       /* === lines used for evaluations that were           */
                       /* === initially set up in fem_cofacet_               */
                       /* === Return: INT  EXIT_SUCCESS or EXIT_FAILURE      */
INT FEMa_coDeleteLines ( void  );

                       /* ================================================== */
                       /* === FEMa_coGetLineNodes: get the nodes of a set of */
                       /* === lines and the keypoints defining the lines.    */
                       /* === Store these nodes and the edges that join them */
                       /* === in the C meshing data base.                    */
                       /* === Return: INT  EXIT_SUCCESS or EXIT_FAILURE      */
INT FEMa_coGetLineNodes (
   INT *a_lines,       /* (IN)  list of lines.                               */
   INT num_lines  );   /* (IN)  length of a_lines                            */

#ifdef __cplusplus
}
#endif

#endif

