/*HFILE cansmpi_wrapper.h    ANSI_C                       <jrb, 03/01/2010> */

/*
 * Copyright 2003-2010 ANSYS, Inc. 
 * All Rights Reserved  
 */

#ifndef CANSMPI_WRAPPER_H
#define CANSMPI_WRAPPER_H 1

#ifdef __cplusplus
extern "C" {
#endif

#if _WIN32
#define CWMPI_EXPORT extern __declspec(dllexport)
#else
#define CWMPI_EXPORT extern
#endif

#include "ansys.h"

/*---------------------------------------------------------------------------*/
/* TYPE DEFINITIONS */
/*---------------------------------------------------------------------------*/

typedef int           CWMPI_Fint;

typedef CWMPI_Fint    CWMPI_Comm;
typedef CWMPI_Fint    CWMPI_Group;
typedef CWMPI_Fint    CWMPI_Request;
typedef CWMPI_Fint    CWMPI_Op;
typedef CWMPI_Fint    CWMPI_Datatype;
typedef CWMPI_Fint    CWMPI_Errhandler;

typedef CWMPI_Fint*   CWMPI_Status;



/*---------------------------------------------------------------------------*/
/* START OF PLATFORM-SPECIFIC DEFINITIONS */
/*---------------------------------------------------------------------------*/

#if defined (SUN_SYS)
#  define CWMPI_COMPLEX16               22
#  define CWMPI_STATUS_SIZE              5
#  define CWMPI_SOURCE                   0
#  define CWMPI_TAG                      1
#  define CWMPI_ERROR                    2
#endif

#if defined (IBM_SYS)
#  define CWMPI_COMPLEX16               49
#  define CWMPI_STATUS_SIZE             10
#  define CWMPI_SOURCE                   0
#  define CWMPI_TAG                      1
#  define CWMPI_ERROR                    2
#  define MUST_FIRST_DETACH_BUFFER
#endif

#if defined (DECAXPOSF_SYS)
#  define CWMPI_COMPLEX16               33
#  define CWMPI_STATUS_SIZE              8
#  define CWMPI_SOURCE                   0
#  define CWMPI_TAG                      1
#  define CWMPI_ERROR                    2
#endif

#if defined (HP_SYS)
#  define CWMPI_COMPLEX16               33
#  define CWMPI_STATUS_SIZE              8
#  define CWMPI_SOURCE                   0
#  define CWMPI_TAG                      1
#  define CWMPI_ERROR                    2
#endif

#if defined (PCMPI)
#  define CWMPI_COMPLEX16               33
#  define CWMPI_STATUS_SIZE              8
#  define CWMPI_SOURCE                   0
#  define CWMPI_TAG                      1
#  define CWMPI_ERROR                    2
#  define NEED_MPI_INITIALIZED
#endif

#if defined (HPMPI)
#  define CWMPI_COMPLEX16               33
#  define CWMPI_STATUS_SIZE              8
#  define CWMPI_SOURCE                   0
#  define CWMPI_TAG                      1
#  define CWMPI_ERROR                    2
#  define NEED_MPI_INITIALIZED
#endif

#if defined (INTELMPI)
#  define CWMPI_COMPLEX16       1275072546
#  define CWMPI_STATUS_SIZE              5
#  define CWMPI_SOURCE                   2
#  define CWMPI_TAG                      3
#  define CWMPI_ERROR                    4
#endif

#if defined (MSMPI)
#  define CWMPI_COMPLEX16       1275072546
#  define CWMPI_STATUS_SIZE              5
#  define CWMPI_SOURCE                   2
#  define CWMPI_TAG                      3
#  define CWMPI_ERROR                    4
#endif

#if defined (SGIMPT)
#  define CWMPI_COMPLEX16               17
#  define CWMPI_STATUS_SIZE              6
#  define CWMPI_SOURCE                   0
#  define CWMPI_TAG                      1
#  define CWMPI_ERROR                    2

/* special code to satisfy build with MPT 1.25 */
/* TODO: remove this line when MPT is upgraded */
#ifdef USE_MPI
int MPI_Status_c2f(MPI_Status*, int *);
int MPI_Status_f2c(int *, MPI_Status*);
int MPI_Errhandler_c2f(MPI_Errhandler);
MPI_Errhandler MPI_Errhandler_f2c(int);
#endif
#endif

/*---------------------------------------------------------------------------*/
/* END OF PLATFORM-SPECIFIC DEFINITIONS */
/*---------------------------------------------------------------------------*/



/*---------------------------------------------------------------------------*/
/* PRE-DEFINDED CONSTANTS for MPI_STATUS */
/*---------------------------------------------------------------------------*/

/* must be equal or larger than the maximum value for CWMPI_STATUS_SIZE above */
#define CWMPI_STATUS_SIZE_MAX           10



/*---------------------------------------------------------------------------*/
/* STUB DEFINITIONS FOR MPI DATATYPES */
/*---------------------------------------------------------------------------*/

#define CWMPI_INTEGER1_STUB            456
#define CWMPI_INTEGER2_STUB            466
#define CWMPI_INTEGER4_STUB            476
#define CWMPI_INTEGER8_STUB            486
#define CWMPI_REAL4_STUB               556
#define CWMPI_REAL8_STUB               566
#define CWMPI_COMPLEX16_STUB           567
#define CWMPI_CHARACTER_STUB           656

#define CWMPI_GARBAGE           -123456789


/*------------------------------ Prototypes --------------------------*/

/* initialization and termination routines */
CWMPI_EXPORT int CWMPI_Initialized(int *flag);
CWMPI_EXPORT int CWMPI_Init(int*, char**[]);
CWMPI_EXPORT int CWMPI_Finalize(void);
CWMPI_EXPORT int CWMPI_Abort(CWMPI_Comm, int);

/* point-to-point communication routines */
CWMPI_EXPORT int CWMPI_Send(void*, int, CWMPI_Datatype, int, int, int);
CWMPI_EXPORT int CWMPI_Bsend(void*, int, CWMPI_Datatype, int, int, CWMPI_Comm);
CWMPI_EXPORT int CWMPI_Isend(void*, int, CWMPI_Datatype, int, int, CWMPI_Comm, CWMPI_Request*);
CWMPI_EXPORT int CWMPI_Recv(void*, int, CWMPI_Datatype, int, int, CWMPI_Comm, CWMPI_Status);
CWMPI_EXPORT int CWMPI_Irecv(void*, int, CWMPI_Datatype, int, int, CWMPI_Comm, CWMPI_Request*);

/* collective communication routines */
CWMPI_EXPORT int CWMPI_Reduce(void*, void*, int, CWMPI_Datatype, CWMPI_Op, int, CWMPI_Comm);
CWMPI_EXPORT int CWMPI_Allreduce(void*, void*, int, CWMPI_Datatype, CWMPI_Op, CWMPI_Comm);
CWMPI_EXPORT int CWMPI_Scan(void*, void*, int, CWMPI_Datatype, CWMPI_Op, CWMPI_Comm);
CWMPI_EXPORT int CWMPI_Bcast(void*, int, CWMPI_Datatype, int, CWMPI_Comm);
CWMPI_EXPORT int CWMPI_Gather(void*, int, CWMPI_Datatype, void*, int, CWMPI_Datatype, int, CWMPI_Comm);
CWMPI_EXPORT int CWMPI_Gatherv(void*, int, CWMPI_Datatype, void*, int*, int*, CWMPI_Datatype, int, CWMPI_Comm);
CWMPI_EXPORT int CWMPI_Scatter(void*, int, CWMPI_Datatype, void*, int, CWMPI_Datatype, int, CWMPI_Comm);
CWMPI_EXPORT int CWMPI_Scatterv(void*, int*, int*, CWMPI_Datatype, void*, int, CWMPI_Datatype, int, CWMPI_Comm);
CWMPI_EXPORT int CWMPI_Allgather(void*, int, CWMPI_Datatype, void*, int, CWMPI_Datatype, CWMPI_Comm);
CWMPI_EXPORT int CWMPI_Allgatherv(void*, int, CWMPI_Datatype, void*, int*, int*, CWMPI_Datatype, CWMPI_Comm);
CWMPI_EXPORT int CWMPI_Alltoall(void*, int, CWMPI_Datatype, void*, int, CWMPI_Datatype, CWMPI_Comm);
CWMPI_EXPORT int CWMPI_Alltoallv(void*, int*, int*, CWMPI_Datatype, void*, int*, int*, CWMPI_Datatype, CWMPI_Comm);
CWMPI_EXPORT int CWMPI_Barrier(CWMPI_Comm comm);

/* message utility routines */
CWMPI_EXPORT int CWMPI_Iprobe(int, int, CWMPI_Comm, int*, CWMPI_Status);
CWMPI_EXPORT int CWMPI_Get_count(CWMPI_Status, CWMPI_Datatype, int*);

/* request utility routines */
CWMPI_EXPORT int CWMPI_Test(CWMPI_Request*, int*, CWMPI_Status);
CWMPI_EXPORT int CWMPI_Testsome(int, CWMPI_Request*, int*, int*, CWMPI_Status);
CWMPI_EXPORT int CWMPI_Wait(CWMPI_Request*, CWMPI_Status);
CWMPI_EXPORT int CWMPI_Waitany(int, CWMPI_Request*, int*, CWMPI_Status);
CWMPI_EXPORT int CWMPI_Waitall(int, CWMPI_Request*, CWMPI_Status);
CWMPI_EXPORT int CWMPI_Request_free(CWMPI_Request*);
CWMPI_EXPORT int CWMPI_Cancel(CWMPI_Request*);

/* communicator utility routines */
CWMPI_EXPORT int CWMPI_Comm_group(CWMPI_Comm, CWMPI_Group*);
CWMPI_EXPORT int CWMPI_Group_incl(CWMPI_Group, int, int*, CWMPI_Group*);
CWMPI_EXPORT int CWMPI_Comm_create(CWMPI_Comm, CWMPI_Group, CWMPI_Comm*);
CWMPI_EXPORT int CWMPI_Comm_dup(CWMPI_Comm, CWMPI_Comm*);
CWMPI_EXPORT int CWMPI_Comm_split(CWMPI_Comm, int, int, CWMPI_Comm*);
CWMPI_EXPORT int CWMPI_Group_translate_ranks(CWMPI_Group, int, int*, CWMPI_Group, int*);
CWMPI_EXPORT int CWMPI_Group_free(CWMPI_Group*);
CWMPI_EXPORT int CWMPI_Comm_free(CWMPI_Comm*);
CWMPI_EXPORT int CWMPI_Comm_size(CWMPI_Comm, int*);
CWMPI_EXPORT int CWMPI_Comm_rank(CWMPI_Comm, int*);

/* process topology utility routines */
CWMPI_EXPORT int CWMPI_Dims_create(int, int, int*);
CWMPI_EXPORT int CWMPI_Cart_create(CWMPI_Comm, int, int*, int*, int, CWMPI_Comm*);
CWMPI_EXPORT int CWMPI_Cartdim_get(CWMPI_Comm, int*);
CWMPI_EXPORT int CWMPI_Cart_get(CWMPI_Comm, int, int*, int*, int*);
CWMPI_EXPORT int CWMPI_Cart_rank(CWMPI_Comm, int*, int*);
CWMPI_EXPORT int CWMPI_Cart_coords(CWMPI_Comm, int, int, int*);
CWMPI_EXPORT int CWMPI_Cart_sub(CWMPI_Comm, int*, CWMPI_Comm*);

/* error handler utility routines */
CWMPI_EXPORT int CWMPI_Error_string(int, char*, int*);
CWMPI_EXPORT int CWMPI_Comm_create_errhandler(void*, CWMPI_Errhandler*);
CWMPI_EXPORT int CWMPI_Comm_set_errhandler(CWMPI_Comm, CWMPI_Errhandler);
CWMPI_EXPORT int CWMPI_Comm_get_errhandler(CWMPI_Comm, CWMPI_Errhandler*);

/* miscellaneous utility routines */
CWMPI_EXPORT int CWMPI_Buffer_attach(void*, int);
CWMPI_EXPORT int CWMPI_Buffer_detach(void*, int*);
CWMPI_EXPORT int CWMPI_Get_processor_name(char*, int*);
CWMPI_EXPORT double CWMPI_Wtime(void);
CWMPI_EXPORT double CWMPI_Wtick(void);
CWMPI_EXPORT int CWMPI_Get_parameter(int);


#ifdef __cplusplus
}
#endif

#endif /* CANSMPI_WRAPPER_H */
