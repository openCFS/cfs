/*****************************************************************************
 *                   Copyright (C) 1999 CMSoft                               *
 *                                                                           *
 *  These lines of code and declarations contain unpublished proprietary     *
 *  information of CMSoft. They may not be copied or duplicated in whole     *
 *  or part without prior authorization from CMSoft.                         *
 *                                                                           *
 *****************************************************************************/
#ifdef F_NEEDS_UNDSC
#define _FORTRAN(a) a ## _
#else
#define _FORTRAN(a) a
#endif
#ifdef PCWINNT_SYS
#define _F(a) wrap ## a
#else
#ifdef F_NEEDS_UNDSC
#define _F(a) a ## _
#else
#define _F(a) a
#endif
#endif
