#ifndef FEM_LNPUBLIC
#define FEM_LNPUBLIC

#include "FEM_cdbtypes.h"
#include "FEM_Public.h"
#include "FEM_cell.h"

class LINE_TYP : public CELL_TYP {

   private:
      KP_PTYP mobj_kp1, mobj_kp2;
      DOUBLE m_length;
      unsigned m_onseam:1;
      INT m_num_hardpoints;
      NEXTCELL_PTYP m_p_hpts;

private:
    void InitLINE(); /* only by constructor */

   public:
      LINE_TYP() { InitLINE(); };
      ~LINE_TYP() { };
      void Delete() { DeleteCell(); };
      void InitLineCell(); /* called by allocated obj pointer */
      LINE_PTYP GetNext( ) { return (LINE_PTYP)CELL_TYP::GetNext(); };
      INT SetHardPoint( const KP_PTYP obj_kp );
      INT NumHardPoints() const { return m_num_hardpoints; };
      INT SetKp( const KP_PTYP obj_kp, const INT index );
      KP_PTYP Kp( const INT index )
      {
         if ( index == 0 ) return mobj_kp1;
         else return mobj_kp2;
      };

      DOUBLE Length();

      void SetLength( const DOUBLE length) {m_length = length;};


      FEM_BOOLEAN IsHpt( INT kp_id ) const
      {
         NEXTCELL_PTYP p_hpt = m_p_hpts;
         while ( p_hpt ) {
            if ( ((KP_PTYP)(p_hpt->GetCell()))->GetId() == kp_id ) {
               return TRUE;
            }
            p_hpt = p_hpt->GetNext();
         }
         return FALSE;
      }

      INT NumAdjAreas() const { return NumAdjCells(); };
      AREA_PTYP GetAdjArea() const { return (AREA_PTYP)GetAdjCell(); };

      AREA_PTYP GetNextAdjArea( AREA_PTYP obj_area ) const
      {
         return (AREA_PTYP)GetNextAdjCell( (CELL_PTYP)obj_area );
      };

      INT VolList( VOL_PTYP **aobj_vols, INT &num_vols ) const
      {
         return List2LevelsAbove( (CELL_PTYP**)aobj_vols, num_vols );
      }

      KP_PTYP GetOppositeKp( KP_PTYP obj_kp, FEM_BOOLEAN bGiveDuplicateEndPoint = FALSE );

}; 

#endif

