
/*****************************************************************************
   This include file is used for the ANSYS cwrap_ansys.c routines and
   cwrap_amg.c routines.

*****************************************************************************/

#ifdef __cplusplus
extern "C" {
#endif

#define PP_NPROCS	0
#define PP_OFF		1
#define PP_MAXPROC	2
#define PP_NUMTHREADS	3
#define PP_THRSTATUS	4
#define PP_DEBUG	5
#define PP_NPROCEQN	10
#define PP_INITIALIZE	12
#define PP_LOCKCHECK	22
#define PP_YES		0
#define PP_NO		1
#define PP_LIMITPROC	32

typedef void (*T_fct_1)(void*);
typedef void (*T_fct_2)(void*,void*);
typedef void (*T_fct_3)(void*,void*,void*);
typedef void (*T_fct_4)(void*,void*,void*,void*);
typedef void (*T_fct_5)(void*,void*,void*,void*,void*);
typedef void (*T_fct_6)(void*,void*,void*,void*,void*,void*);
typedef void (*T_fct_7)(void*,void*,void*,void*,void*,void*,void*);

extern void      cwPpfrk1( T_fct_1, void* );
extern void      cwPpfrk2( T_fct_2, void*, void* );
extern void      cwPpfrk3( T_fct_3, void*, void*, void* );
extern void      cwPpfrk4( T_fct_4, void*, void*, void*, void* );
extern void      cwPpfrk5( T_fct_5, void*, void*, void*, void*, void* );
extern void      cwPpfrk6( T_fct_6, void*, void*, void*, void*, void*, void* );
extern void      cwPpfrk7( T_fct_7, void*, void*, void*, void*, void*, void*, void* );
extern void      cwPpresu(void);
extern void      cwPpinfo(INT*,INT*);
extern void      cwPppark(void);
extern INT       cwPpinqr(INT*);
extern INT       cwPpproc(void);
extern void      cwPprange(INT*, INT*, INT*);
extern void      cwPprangeL(LONGINTC*, LONGINTC*, LONGINTC*);
extern INT       cwPpchunk(INT*, INT*, INT*, INT*, INT*);
extern INT       cwPpchunkL(LONGINTC*, INT*, INT*, LONGINTC*, LONGINTC*);
extern INT       cwPpnext(void);
extern void      cwPpgroup(INT*, INT*, INT*, INT*);
extern void      cwPplock(INT*);
extern void      cwPpunlock(INT*);

extern INT       cPcgSlvRun(INT*,INT*,INT*,DOUBLE*,INT*,DOUBLE*);

extern void      cwnonzrodispchk(INT*, INT*, INT*, INT*, INT*);
extern INT       cput_amgmem2pcg(DOUBLE*,DOUBLE*,INT*,INT*,INT*,INT*);
extern INT       crecoverx1aftercecp(INT*,INT*,INT*,DOUBLE*,DOUBLE*);
extern INT       crecoverf2aftercecp(INT*,INT*,INT*,DOUBLE*);
extern INT       cwupdatefullheader(INT*,INT*,INT*);
extern INT       cwupdatemodeheader(INT*,INT*,INT*);
extern void      cwbiowrt_int(INT*,INT*,INT*,INT*);
extern void      cwbiowrt_dp(INT*,INT*,DOUBLE*,INT*);
extern void      cwbiord_int(INT*,INT*,INT*,INT*);
extern void      cwbiord_dp(INT*,INT*,DOUBLE*,INT*);
extern INT       cPcgKtimesU(INT*,INT*,DOUBLE*,DOUBLE*);
extern INT       cPcggetCurrVarnock(INT,INT);
extern void      cwGet_Times(DOUBLE*,DOUBLE*);
extern void      cwAxElemMult(INT*,INT*,INT*,INT*,INT*,DOUBLE*,DOUBLE*,DOUBLE*);
extern void      cwAxElemMassMult(INT*,INT*,INT*,INT*,DOUBLE*,DOUBLE*);
extern void      cwSolabt(INT,INT);
extern void      cwGetEnvVar(char*,INT*,DOUBLE*);
extern INT       cwSysexe(char*);
extern void      cwPcgstat(INT,DOUBLE,DOUBLE,INT*);
extern void      cwPcglanstat(INT,INT,INT,INT,INT*);
extern INT       cwGetOutOfCore(void);
extern INT       cwGetSingle(void);
extern INT       cwGetStep(void);
extern INT       cwGetStop(void);
extern void      cwPrintFreq(INT*,INT*,INT*,INT*,INT*,INT*,INT*,DOUBLE*,DOUBLE*,DOUBLE*);
extern void      cwWriteEigenToRSTfile(INT*,INT*,DOUBLE*,INT*,INT*,DOUBLE*,DOUBLE*);
extern INT       cwBcsStat(INT*,INT*,INT*,DOUBLE*,DOUBLE*);
extern void      cwDumpDirContents(void);
extern void      cwacc_warning(int,int);

extern void      cwPutAnsys_commond(INT*,DOUBLE*,INT*);
extern INT       cwansys_commond(INT*,DOUBLE*);
extern INT       cwintfromdp(DOUBLE*);
extern DOUBLE    cwdpfromint(INT*);
extern void      cwbiowrt_complex(INT*,INT*,DOUBLE*,DOUBLE*,DOUBLE*,INT*);
extern LONGINTC  cwLargeIntGet(INT*,INT*);
extern void      cwLargeIntPut(LONGINTC*,INT*,INT*);
extern INT       cwamg_alloc(INT*,LONGINTC*,INT*);
extern void      cwcalrigidb(INT*);
extern INT       cwamgsolver(INT*,INT*,LONGINTC*,INT*,INT*,INT*,DOUBLE*,DOUBLE*);
extern void      cwamg_deallo_pcg(void);
extern void      cwamg_coord_pcg(INT*,INT*);
extern void      cmpcAllocate(INT,INT);
extern void      cmpcDeallocate(void);

#if !defined (PTR64)
extern void      cDSPmainPCG(INT*,DOUBLE*,INT*,INT*,INT*,INT*,DOUBLE*,DOUBLE*,LONGINTC*,INT*,DOUBLE*,INT*);
#else
extern void      cDSPmainPCG(INT*,DOUBLE*,INT*,INT*,LONGINTC*,LONGINTC*,DOUBLE*,DOUBLE*,LONGINTC*,INT*,DOUBLE*,INT*);
#endif

extern void      cwGetDspSolverKeys(INT*,INT*,DOUBLE*);

#if !defined (PTR64)
extern void      cwFastSparseSolver(INT*,INT*,DOUBLE*,INT*,INT*,DOUBLE*,INT*,DOUBLE*,DOUBLE*,INT*);
#else
extern void      cwFastSparseSolver(INT*,INT*,DOUBLE*,LONGINTC*,LONGINTC*,DOUBLE*,INT*,DOUBLE*,DOUBLE*,INT*);
#endif

extern INT       cwIopiqr(INT*);

extern INT       createSymToAnsMap(INT,INT*);
extern INT       csymbolicSize(void);
extern INT       cmultiplyWithG(DOUBLE*,DOUBLE*,INT*,INT*,INT);
extern void      creleaseMemory2(void);
extern void      cwModeWriteFstacm(void);
extern INT       cwInqr_LagrangeCE(void);
extern void      cwgetRigidModeNum(INT*,DOUBLE*,INT*);
extern DOUBLE    cwgetacousticscale(void);
extern INT       cwndinqrIntNode(INT*,INT*);

#ifdef __cplusplus
}
#endif
