////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         Copyright (C) 2010 ANSYS Inc.  All Rights Reserved             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MAT_ICTimeHardening.h $
// $Revision: 1.6 $ 7.0
// $Date: 2010/04/06 20:21:11 $ March 28 2002
// $Author: srpailla $ rjayasee
//
// Decription :
//              This class implement Time Hardening Implicit Creep Model
//
////////////////////////////////////////////////////////////////////////////// 

#if !defined(MAT_ICTimeHardening_H)
#define MAT_ICTimeHardening_H

#include  "MAT_ConstitutiveFunction.h"
#include  "MAT_Creep.h"

class MAT_ICTimeHardening  : public MAT_Creep
{
public:

	MAT_ICTimeHardening();
    // Default Constructor.

    static MAT_Creep* Construct() ;

    virtual bool FunctionValue( double* pVariables, INT iNumVariables,
                                double* pInputVariables, INT iNumInputVariables, double& dCreepStrainRate ) ;
    //I pVariable
    //I-Value of Coefficients
    //I iNumVariables
    //I- Number of variables
    //I dInputVariables
    //I-Input Variables
    //I iNumInputVariables
    //I-Num Input Variables
    //I dCreepStrainRate
    //I-Calculated Value of Creep Strain Rate
    //R- Calculates the value of the Creep Strain Rate using Time Hardening 

    virtual bool FirstDerivativeOfUnsquaredError
         ( double* pVariables,INT iNumVariables,
           double* pInputVariables, INT iNumInputVariables,
           INT iVariableIndex, double& dResult ) ;
    //I pVariable
    //I-Value of Coefficients
    //I iNumVariables
    //I- Number of variables
    //I dInputVariables
    //I-Input Variables
    //I iNumInputVariables
    //I-Num Input Variables
    //I iVariableIndex
    //I-Variable w.r.t which the derivative is to be calculated
    //I dResult
    //I-Calculated value of derivative
    //R- Calculates the value of the Creep Strain using Strain Hardening          
    
    virtual void Print() ;
    // Prints the constitutive function

    virtual void EliminateTemperatureCoefficients();
    //Eliminates Temperature term and fixes it.

    virtual ~MAT_ICTimeHardening();
    //Destructor


protected:


} ;


class MAT_ICTimeHardeningFactory
{
    public:

    static MAT_ICTimeHardeningFactory* Instance() ;
    //I Pointer to Creep Factory
    //- Pointer to Singleton Instantiator

    static void Destroy() ;
    ~MAT_ICTimeHardeningFactory() ;
    // Destructor

    private:

    MAT_ICTimeHardeningFactory() ;
    // Constructor

    static MAT_ICTimeHardeningFactory* m_pInstance ;
    //Pointer to only instance of this class
} ;

#endif // !defined(MAT_ICTimeHardening_H)
