
/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 2009 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_prMesh_static.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_prMesh_static.h
 *  header file for FEM_prMesh.c
 *
 */
#ifndef FEM_PRMESH_STATIC_INCLUDE
#define FEM_PRMESH_STATIC_INCLUDE

/*------------------ Constants ---------------------------------------*/
#define NOT_KNOWN_ESIZE 0.00

/*------------------ Prototypes for static routines ------------------*/

static INT fem_prSeamLineNodeEsize     ( NODE_OBJ obj_node,
                                  DOUBLE *esize );

static INT fem_prCrtNodEdgForOneSegSeam( 
                                  INT area_id,
                                  NODE_OBJ obj_node1,
                                  NODE_OBJ obj_node2,
                                  NODE_OBJ obj_dblnode1,
                                  NODE_OBJ obj_dblnode2,
                                  DOUBLE node1_esize,
                                  DOUBLE node2_esize,
                                  DOUBLE min_param,
                                  DOUBLE max_param,
                                  SEAM_DIR uv_dir,
                                  INT orientation,
                                  INT *numbound );

static INT fem_prMeshCylSeamLine( INT area_id,
                                  EDGE_OBJ obj_xedge1,
                                  EDGE_OBJ obj_xedge2,
                                  DOUBLE min_param,
                                  DOUBLE max_param,
                                  SEAM_DIR uv_dir,
                                  INT *numbound );

static INT fem_prMeshConeSeamLine( INT area_id,
                                  EDGE_OBJ obj_xedge1,
                                  EDGE_OBJ obj_xedge2,
                                  DOUBLE min_param,
                                  DOUBLE max_param,
                                  SEAM_DIR uv_dir,
                                  INT *numbound );

static INT fem_prDuplicateCylinderLine ( INT area_id,
                                  EDGE_OBJ obj_xedge1,
                                  EDGE_OBJ obj_xedge2,
                                  EDGE_OBJ obj_1stedge1,
                                  DOUBLE min_param,
                                  DOUBLE max_param,
                                  SEAM_DIR uv_dir,
                                  INT *numbound );

static INT fem_prDuplicateConeLine     ( INT area_id,
                                  EDGE_OBJ obj_xedge1,
                                  EDGE_OBJ obj_xedge2,
                                  DOUBLE min_param,
                                  DOUBLE max_param,
                                  SEAM_DIR uv_dir,
                                  INT *numbound );


static INT fem_prSortSeam              ( EDGE_OBJ a,
                                  EDGE_OBJ b );

static INT fem_prDoesSeamHaveLine( EDGE_OBJ obj_xedge,
                                   INT *a_arealines,
                                   INT num_arealines,
                                   SEAM_DIR uv_dir,
                                   EDGE_OBJ *obj_1stedge1,
                                   FEM_BOOLEAN *seam_has_line );

static INT fem_prDuplicateNode   ( NODE_OBJ obj_node,
                                   SEAM_DIR uv_dir,
                                   DOUBLE min_param,
                                   DOUBLE max_param,
                                   NODE_OBJ *obj_newnode );

static INT fem_prMoveNonManifoldEdges   ( INT numbound,
                                   DOUBLE new_param,
                                   SEAM_DIR uv_dir,
                                   FEM_BOOLEAN *pbMoved);

static INT fem_prAdjustSeamUVs   ( INT numbound );

static INT fem_prInitMoveNode    ( void );

static INT fem_prSaveMoveNode    ( NODE_OBJ obj_node,
                                   FEM_BOOLEAN *alreadymoved );

static INT fem_prMoveNodesBack   ( SEAM_DIR uv_dir );

static INT fem_prDist3D          ( NODE_OBJ obj_node1,
                                   NODE_OBJ obj_node2,
                                   DOUBLE *dist3d );

static INT fem_prCreateTip       ( INT area_id,
                                   NODE_OBJ obj_tipnode,
                                   INT *numbound );

static INT fem_prCheckCrossPair  ( INT area_id,
                                   PERIODIC_TYPE periodic,
                                   SEAM_DIR seamDir,
                                   EDGE_OBJ *obj_xedge1,
                                   EDGE_OBJ *obj_xedge2 );

static void fem_prQuickSortDouble( DOUBLE *base,
                                   INT lo,
                                   INT hi);

static void fem_prQuickSortEdges ( EDGE_OBJ *base,
                                   INT lo,
                                   INT hi);

static void fem_prAdjustMidnodes(  INT numbound );



static DOUBLE fem_prGetNodeParam( 
	NODE_OBJ obj_node, /* the node */
	SEAM_DIR uv_dir ); 

static INT fem_prSetNodeParam( 
	NODE_OBJ obj_node, /* the node */
	SEAM_DIR uv_dir,   /* the dir */
	DOUBLE param ) ;

static INT fem_prFindClosestOppNode(
	INT area_id,
	SEAM_DIR seamDir,
	NODE_OBJ *obj_xNode,
	INT *numLoopEdges,
	NODE_OBJ *obj_oppNode) ;

static INT fem_prGetAreaParamRange( 
   INT area_id,           
   SEAM_DIR seamDir,	     
	DOUBLE *range) ;

static INT fem_prTryShiftOutOfSeam(
   INT area_id,           /* (IN)  The area to check for seamlines. */
   INT *numbound,         /* (IN/OUT)  number of boundary edges on this area. */
   SEAM_DIR seamDir,	     /* seam direction in process */
   INT *numLoop,
   INT *did) ;

static INT fem_prGetNumLayers(
   NODE_OBJ obj_node1,    /* (IN) node at parametric lesser end of seamline. */
   NODE_OBJ obj_node2,    /* (IN) node at parametric greater end of seamline. */
   DOUBLE node1_esize,    /* (IN) size of elems to put near obj_node1. */
   DOUBLE node2_esize,
	INT *numLayers,
	DOUBLE **layParams) ;

static INT fem_prCopyNode(
   NODE_OBJ obj_node,
   NODE_OBJ *obj_newnode );

static INT fem_prCreateEdges( 
	INT area_id,
	NODE_OBJ *aobj_nodes,
	INT numLayers,
	EDGE_OBJ *aobj_edges);

static INT fem_prUpdateAreaBndRec( 
	INT area_id, 
	INT numLayers, 
	NODE_OBJ *aobj_nodes, 
	EDGE_OBJ *aobj_edges ) ;

static INT fem_prEdgeReplaceNode( 
	EDGE_OBJ *edge, 
	NODE_OBJ newNode, 
	NODE_OBJ oldNode);

static INT fem_prDetermineNdivForSideArea(
	NODE_OBJ &obj_node1,
	NODE_OBJ &obj_node2,
	MODEL_PTYP &obj_model,
	AREAMSHDAT_PTYP &p_areadata,
	DOUBLE &justincaseLength,
	DOUBLE &end1_esize,
	DOUBLE &node1_esize,
	DOUBLE &end2_esize,
	DOUBLE &node2_esize,
	DOUBLE &length,
	FEM_BOOLEAN &lin_interp,
	INT &num_divs
);

static INT fem_prIsBndEdge( 
	EDGE_OBJ obj_theEdge,
	INT numBnd,
	INT &isBndEdge ) ;

static INT fem_prGetOtherDir( 
	SEAM_DIR seamDir, 
	SEAM_DIR &otherDir ) ;

static INT fem_prNeedFlipCrossEdges( 
	INT area_id,
	SEAM_DIR seamDir,
	EDGE_OBJ obj_edge1,
	EDGE_OBJ obj_edge2,
	INT &needFlip);

static INT fem_prTryFlipCrossEdges(
	EDGE_OBJ *aobj_xedges,
	INT area_id,
	SEAM_DIR uv_dir,
    INT numBndEdges );

#ifndef UG_SCENARIO
    FEM_BOOLEAN fem_prIsAreaSideArea( 
        INT anum ,
        MODEL_PTYP & obj_model,
        AREA_PTYP & obj_area,
        AREAMSHDAT_PTYP & p_areadata );
#endif
static INT fem_prShiftExternalLoop(
   INT area_id,
   DOUBLE TT,
   INT numBndEdges,
   EDGE_OBJ *aobj_bndEdges,
   INT *a_edgeDirs,
   DOUBLE &minPar,
   DOUBLE &maxPar,
	SEAM_DIR seamDir, 
   INT *linesInLoop,
   INT numLinesInLoop,
   INT &shiftDir,
   INT &shifted );
static INT fem_prShiftInternalLoops(
   INT area_id,
   DOUBLE TT,
   INT numBndEdges,
   EDGE_OBJ *aobj_bndEdges,
   INT shiftDir,
   DOUBLE minPar,
   DOUBLE maxPar,
	SEAM_DIR seamDir, 
   INT &shifted );
static INT fem_prShiftInteriorNodes(
   INT area_id,
   INT shiftDir,
   DOUBLE minPar,
   DOUBLE maxPar,
   DOUBLE TT, // period
	SEAM_DIR seamDir, 
   INT *did);
static INT fem_prIsExternalLoopEdge( 
   EDGE_OBJ obj_edge, 
   INT numLinesInLoop, 
   INT *linesInLoop );
static INT fem_prGetNumEdgeLoops(
   INT area_id,
   INT *numLoop);                              
static INT fem_prGetNumExt_edgeloop( 
   INT area_id, 
   EDGE_OBJ *aobj_allEdges, 
   INT *a_edgeDirs,
   INT numAllEdges, 
   INT *numExtEdgeloop, 
   INT *numEdgeInExtLoop,
   EDGE_OBJ *aobj_extEdges,
   INT *aiEdgeDirs);
static void fem_prMarkAllEdgeNodes( EDGE_OBJ *aobj_edges, INT numEdges, FEM_LONG flag, FEM_BOOLEAN stat );
static void fem_prMarkAllEdges( EDGE_OBJ *aobj_edges, INT numEdges, FEM_LONG flag, FEM_BOOLEAN stat );
static INT fem_prShiftExternalLoop(
   INT area_id,
   DOUBLE TT,
   INT numBndEdges,
   EDGE_OBJ *aobj_bndEdges,
   INT *a_edgeDirs,
   DOUBLE &minPar,
   DOUBLE &maxPar,
	SEAM_DIR seamDir, 
   INT &shiftDir, // which direction was the shift was conducted
   INT &shifted );
static void fem_prIsEntInArray( 
    EDGE_OBJ obj_edge, 
    EDGE_OBJ *aobj_edges, 
    INT numEdges, 
    INT *inArray );
#endif
