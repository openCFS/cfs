/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 2009 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_noGeom.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_noGeom.h
 *  header file for FEM_noGeom.c
 *
 */
/* *** mpg math array c
 FEM_array.c FEM_matrix.c FEM_MeshTable.h FEM_Public.h FEM_array.h
 FEM_array_static.h  FEM_cdbtypes.h FEM_edPublic.h FEM_elPublic.h
 FEM_errors.h FEM_external.h FEM_faPublic.h FEM_matrix.h
 FEM_matrix_static.h FEM_meshTree.h FEM_noGeom.h FEM_noPublic.h
 FEM_publicElementDefinition.h fem_Struct.h
 ansproto.h computer.h float.h globals.h mathfun.h
*/
#ifndef FEM_NOGEOM_INCLUDE
#define FEM_NOGEOM_INCLUDE

/*------- used to place new nodes with FEM_noSetLocation() -------------*/
#define ONE_THIRD 0.3333333333333333
#define TWO_THIRD 0.6666666666666667
#define ONE_HALF  0.5

/*----------------- Globally accessible function prototypes -----------------*/


#ifdef __cplusplus
extern "C" {
#endif

                             /* ============================================ */
                             /* === FEM_noSetLocation: determine the location*/
                             /* === of a node so that it lies between        */
                             /* === obj_node0 and obj_node1 at a parametric  */
                             /* === distance t between them. Project to the  */
                             /* === underlying goemetry if requested (based  */
                             /* === on geo_entity stored with obj_midnode).  */
                             /* === Update the coordinates in obj_midnode    */
                             /* ============================================ */
INT FEM_noSetLocation (
   NODE_OBJ obj_node0,       /* (IN)  node at one end of edge to be split    */
   NODE_OBJ obj_node1,       /* (IN)  node at other end of edge to be split  */
                             /*       (if obj_node0 and obj_node1 are NULL   */
                             /*       then the non-projected point stored in */
                             /*       obj_midnode is projected.              */
   NODE_OBJ obj_midnode,     /* (IN)  node created at the midpoint of edge   */
   DOUBLE ts,                /* (IN)  parametric s value of location of      */
                             /*       midnode (0<=ts<=1) used for lines and  */
                             /*       areas                                  */
   DOUBLE tt,                /* (IN)  dummy argument not used.               */
   INT project_node  );      /* (IN)  flag - project node to surface         */

                             /*==============================================*/
                             /* === FEM_noInside4N: determine if the midnode */
                             /* === lies at the average of 4 nodes           */
                             /* ===                                          */
                             /* ===                  obj_node3               */
                             /* ===                    /\                    */
                             /* ===                   /  \                   */
                             /* ===      obj_node0   /____\ obj_node2        */
                             /* ===                  \    /                  */
                             /* ===                   \  /                   */
                             /* ===                    \/                    */
                             /* ===                  obj_node1               */
                             /* ===   return     1 or 0                      */
                             /*==============================================*/
INT FEM_noInside4N (
   NODE_OBJ obj_node0,       /* (IN)  4 nodes to average to get location of  */
                             /*       obj_midnode.                           */
   NODE_OBJ obj_node1,
   NODE_OBJ obj_node2,
   NODE_OBJ obj_node3,
   NODE_OBJ obj_midnode );   /* (IN)  node created at the midpoint of edge   */

                             /*==============================================*/
                             /* === FEM_noSetLocation4N: determine the       */
                             /* === location of a node so that it lies at    */
                             /* === the average of 4 nodes.  Project to the  */
                             /* === underlying geometry if requested (based  */
                             /* === on geo_entity stored with obj_midnode).  */
                             /* === Update the coordinates in obj_midnode.   */
                             /* ===                                          */
                             /* ===                  obj_node2               */
                             /* ===         v1         /\    v3              */
                             /* ===                   /  \                   */
                             /* ===      obj_node0   /____\ obj_node1        */
                             /* ===                  \    /                  */
                             /* ===          v2       \  /    v4             */
                             /* ===                    \/                    */
                             /* ===                  obj_node3               */
                             /* ===  IF faces for a concave quad return      */
                             /* ===   EXIT_CONCAVE                           */
                             /*==============================================*/
INT FEM_noSetLocation4N (
   NODE_OBJ obj_node0,       /* (IN)  4 nodes to average to get location of  */
                             /*       obj_midnode.                           */
   NODE_OBJ obj_node1,
   NODE_OBJ obj_node2,
   NODE_OBJ obj_node3,
   NODE_OBJ obj_midnode,     /* (IN)  node created at the midpoint of edge   */
   INT project_node  );      /* (IN)  flag - project node to surface         */

                             /* ============================================ */
                             /* === FEM_noProjectToLine: project node to a   */
                             /* === line                                     */
                             /* === Return: INT  EXIT_SUCCESS, EXIT_FAILURE  */
                             /* ============================================ */
INT FEM_noProjectToLine (
   NODE_OBJ obj_node,        /* (IN) the node to project                     */
   INT line_number  );       /* (IN) the line to project to                  */
                             /* ============================================ */

                             /* ============================================ */
                             /* === FEM_noProjectToSurface: project node to  */
                             /* === a surface. (dont project to flat surf)   */
                             /* === Return: INT  EXIT_SUCCESS, EXIT_FAILURE  */
                             /* ============================================ */
INT FEM_noProjectToSurfaceII (
   NODE_OBJ obj_node,        /* (IN) the node to project                     */
   INT      no_guess,
   DOUBLE tol,               /* (IN) distance squared tolerance - maximum    */
   DOUBLE tolCheck );        /* distance the point can move without reporting*/
                             /* an EXIT_FAILURE                              */
                             /* ============================================ */

                             /* ============================================ */
                             /* === FEM_noProjectToSurfaceII: project node   */
                             /* === to surface even if flat                  */
                             /* === Return: INT  EXIT_SUCCESS, EXIT_FAILURE  */
                             /* ============================================ */
INT FEM_noProjectToSurface (
   NODE_OBJ obj_node,        /* (IN) the node to project                     */
   DOUBLE tol2  );           /* (IN) distance squared tolerance - maximum    */
                             /* distance the point can move without reporting*/
                             /* an EXIT_FAILURE                              */
                             /* ============================================ */

                             /* ============================================ */
                             /* === FEM_noMoveNodeOnFlatSurface: move a node */
                             /* === onto the original flat surface           */
                             /* ============================================ */
INT FEM_noMoveNodeOntoFlatSurface(
   NODE_OBJ obj_node );      /* (IN/OUT) node, at a new location on the      */
                             /*   oringal surface                            */

                             /* ============================================ */
                             /* === FEM_noMoveNodeOnSurface: move a node on  */
                             /* === the surface (approximation of            */
                             /* === FEM_noProjectToSurface for speed)        */
                             /* ============================================ */
INT FEM_noMoveNodeOnSurface(
   NODE_OBJ obj_node,        /* (IN) node, at new unprojected location       */
                             /*      u-v at old location                     */
   VECTOR3D *ps_old,         /* old projected location of node               */
   DOUBLE movtol,            /* don't move if less than movetol              */
   INT *p_moved );           /* return flag if node moved                    */

/*==============================================================================
 * === Function: FEM_noAveUVs
 * === Author: mls
 * === Description: Given an array of UV locations, compute the average
 * ===              of them taking into acount if the area is periodic.
 * === Return: INT  EXIT_SUCCESS or EXIT_FAILURE
 *============================================================================*/
INT FEM_noAveUVs(
   DOUBLE *a_u,    /* (IN)  array of u coords to average. */
   DOUBLE *a_v,    /* (IN)  array of v coords to average. */
   INT num,        /* (IN)  length of a_u and a_v */
   INT area,       /* (IN)  area that these coords are on. */
   DOUBLE *u,      /* (OUT) average u */
   DOUBLE *v );    /* (OUT) average v */

/*==============================================================================
 * === Function: FEM_noAve2UVs
 * === Author: mls
 * === Description: Given 2 uv coordinates compute a ratiod average of them
 * ===              taking into acount if the area is closed or not.
 * === Return: INT  EXIT_SUCCESS or EXIT_FAILURE
 *============================================================================*/
INT FEM_noAve2UVs(
   DOUBLE ua,      /* (IN)  1st point to average. */
   DOUBLE va,
   DOUBLE ub,      /* (IN)  2nd point to average. */
   DOUBLE vb,
   DOUBLE ratio,   /* (IN)  ratio to use in average. */
   INT area,       /* (IN)  area that these coords are on. */
   DOUBLE *u,      /* (OUT) average u */
   DOUBLE *v );    /* (OUT) average v */

/*==============================================================================
 * === Function: FEM_noAve2LineUVs
 * === Author: mls
 * === Description: Given 2 t coordinates compute a ratiod average of them
 * ===              taking into acount if the line is closed or not.
 * === Return: INT  EXIT_SUCCESS or EXIT_FAILURE
 *============================================================================*/
INT FEM_noAve2LineTs(
   DOUBLE t1,      /* (IN)  1st point to average. */
   DOUBLE t2,      /* (IN)  2nd point to average. */
   DOUBLE ratio,   /* (IN)  ratio to use in average. */
   INT line,       /* (IN)  area that these coords are on. */
   DOUBLE *t );    /* (OUT) average t */


DOUBLE FEM_noGetSpannedAngleBtwNodes ( 
   NODE_OBJ obj_node0,
   NODE_OBJ obj_node1,
   INT      area_id,
   INT      *piSuccess);

INT FEM_noIsSpannedAngleAroundEdgesTooLarge ( 
   NODE_OBJ obj_node,
   DOUBLE	dMaxAllowedAngle );

EDGE_OBJ FEM_noGetMaxSpannedAngleAroundEdges (
   NODE_OBJ obj_node,
   DOUBLE	*pdAngle );

#ifdef __cplusplus
}
#endif

#endif

