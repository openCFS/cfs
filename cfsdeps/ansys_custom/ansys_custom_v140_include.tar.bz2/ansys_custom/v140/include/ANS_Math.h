////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         Copyright (C) 2010 ANSYS Inc.  All Rights Reserved             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: ANS_Math.h $
// $Revision: 1.7 $ 7.0
// $Date: 2010/04/06 19:21:05 $ July 09 2003
// $Author: srpailla $ rjayasee
//
// Decription :
//
// This File defines math function with additional "exception" features
////////////////////////////////////////////////////////////////////////////

#if !defined(ANS_Math)
#define ANS_Math

#define LOG_HUGE 230.95165647996451371121637758989

#ifdef __cplusplus
extern "C"
{
#endif

/*
double ANS_POW( double dBase, double dExp ) ;
//R double
//I dBase
//I dExponent
//I-Call dBase^dExp. Throws ans_overflow, ans_illegal flags

double ANS_EXP( double dExp ) ;
//R double
//I dExponent
//I-Call e^dExp. Throws ans_overflow, ans_illegal flags

double ANS_LOG( double dVal ) ;
//R double
//I dVal
//I-Call e^dExp. Throws ans_underflow, ans_illegal flags
*/

//-----------------------------------------------------------------//
//                       FunctionName
//-----------------------------------------------------------------//
// Description:
// LOG Function
//
// Input Variables:
// variable                  - description
// dVal                        Value
//
// Input/Output Variables:
// variable                  - description
// 
//
// Output Variables:
// variable                  - description
// None; ans_overflow, ans_illegal if invalid operation
//-----------------------------------------------------------------//
inline double ANS_LOG( double dVal )
{
    if ( dVal < ANS_TINY )
    {
	#if !defined(SUN64_SYS) && !defined(LINUXIA64_SYS) && !defined(LINUXOP64_SYS) && !defined(LINUXEM64T_SYS) && !defined(SGIR8K_SYS)
        throw("ans_underflow") ;
	#endif
        return -ANS_HUGE ;
    }
    else
    {
        return log(dVal) ;
    }
}

//-----------------------------------------------------------------//
//                       FunctionName
//-----------------------------------------------------------------//
// Description:
// Power Function
//
// Input Variables:
// variable                  - description
// dBase                       Base
// dExp                        Exponent
//
// Input/Output Variables:
// variable                  - description
// dExp
//
// Output Variables:
// variable                  - description
// None
//-----------------------------------------------------------------//
inline double ANS_POW( double dBase, double dExp )
{
    // If base is negative
    if ( dBase < 0 )
    {
        dBase = (-1.0)*dBase ;
        MAT_SendMessage( MAT_USR_WARNING, "Base term is negative in Base^Exponent. Absolute Value of Base Term is used \n");
    }

    if ( dBase < ANS_TINY )
    {
        return pow(dBase,dExp) ;
    }

    if ( dExp*ANS_LOG(dBase) > LOG_HUGE )
    {
	#if !defined(SUN64_SYS) && !defined(LINUXIA64_SYS) && !defined(LINUXOP64_SYS) && !defined(LINUXEM64T_SYS) && !defined(SGIR8K_SYS)
        throw("ans_overflow") ;
	#endif
        return ANS_HUGE ;
    }
    else
    {
        return pow(dBase,dExp) ;
    }
}


//-----------------------------------------------------------------//
//                       FunctionName
//-----------------------------------------------------------------//
// Description:
// Exponential Function
//
// Input Variables:
// variable                  - description
// dExp                        Exponent
//
// Input/Output Variables:
// variable                  - description
// dExp
//
// Output Variables:
// variable                  - description
// None; ans_overflow, ans_illegal if invalid operation
//-----------------------------------------------------------------//
inline double ANS_EXP( double dExp )
{
    if ( dExp > LOG_HUGE )
    {
	#if !defined(SUN64_SYS) && !defined(LINUXIA64_SYS) && !defined(LINUXOP64_SYS) && !defined(LINUXEM64T_SYS) && !defined(SGIR8K_SYS)
        throw("ans_overflow") ;
	#endif
        return ANS_HUGE ;
    }
    else
    {
        return exp(dExp) ;
    }
}


//-----------------------------------------------------------------//
//                       FunctionName
//-----------------------------------------------------------------//
// Description:
// Hyperbolic Sine
//
// Input Variables:
// variable                  - description
// dInp                        Input
//
// Input/Output Variables:
// variable                  - description
//
// Output Variables:
// variable                  - description
// None; ans_overflow, ans_illegal if invalid operation
//-----------------------------------------------------------------//
inline double ANS_SINH( double dInp )
{
    if ( dInp > LOG_HUGE || dInp < -LOG_HUGE )
    {
	#if !defined(SUN64_SYS) && !defined(LINUXIA64_SYS) && !defined(LINUXOP64_SYS) && !defined(LINUXEM64T_SYS) && !defined(SGIR8K_SYS)
        throw("ans_overflow") ;
	#endif
        return ANS_HUGE ;
    }
    else
    {
        return sinh(dInp) ;
    }
}

//-----------------------------------------------------------------//
//                       FunctionName
//-----------------------------------------------------------------//
// Description:
// Hyperbolic Sine
//
// Input Variables:
// variable                  - description
// dInp                        Input
//
// Input/Output Variables:
// variable                  - description
//
// Output Variables:
// variable                  - description
// None; ans_overflow, ans_illegal if invalid operation
//-----------------------------------------------------------------//
inline double ANS_COSH( double dInp )
{
    if ( dInp > LOG_HUGE || dInp < -LOG_HUGE )
    {
	#if !defined(SUN64_SYS) && !defined(LINUXIA64_SYS) && !defined(LINUXOP64_SYS) && !defined(LINUXEM64T_SYS) && !defined(SGIR8K_SYS)
        throw("ans_overflow") ;
	#endif
        return ANS_HUGE ;
    }
    else
    {
        return cosh(dInp) ;
    }
}


#ifdef __cplusplus
}
#endif


#endif
