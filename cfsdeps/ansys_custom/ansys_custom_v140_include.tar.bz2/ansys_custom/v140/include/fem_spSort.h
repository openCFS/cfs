/*  fem_spSort.h */
/* 
 * *** ansys(r) copyright(c) 2009
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  fem_spSort.h
 *  Prototypes and macros for sorting range trees.
 *
 */

#ifndef FEM_SPSORT_____H
#define FEM_SPSORT_____H

                          /* ================================================ */
                          /* === FEM_spSort: Sort a range tree                */
                          /* === Return: EXIT_SUCCESS or EXIT_FAILURE         */
INT FEM_spSort (
   RANGETREE_TYP *ps_rtree  ); /* (IN/OUT) the range tree                     */

#endif

