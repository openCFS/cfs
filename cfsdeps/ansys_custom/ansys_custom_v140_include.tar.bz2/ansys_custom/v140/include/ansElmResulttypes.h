
#include "ansysdef.h"


extern  INT  cCreateAnsElmResult(void);
extern  INT  cDeleteAnsElmResult(void);
extern  INT  cInquireAnsElmResult(INT,INT,INT);
extern  INT  cPutAnsElmResult(INT,INT,INT,DOUBLE*);
extern  INT  cGetAnsElmResult(INT,INT,INT*,DOUBLE*);
extern  INT  cGetAnsElmResultPtr(INT,INT,INT*,DOUBLE**);
extern  INT  cActivateAnsElmResult(INT,INT,INT);
extern  INT  cDumpAnsElmResult(INT);


/****************************************************************
 global-level structure for ANSYS element results
 ****************************************************************/
struct ansElmResult_str {  /* Name of the structure                                        */
  INT       tag;           /* Tag for this instance of the element result structure        */
  INT       *numDef;       /* Number of defined results for each element result type       */
  INT       *maxSize;      /* Maximum number of values stored for each element result type */
};

#define ansElmResultTag(result)                (result->tag)

#define ansElmResultNumDefPtr(result)          (result->numDef)
#define ansElmResultNumDefVec(result,i)        (result->numDef[i])
#define ansElmResultMaxSizePtr(result)         (result->maxSize)
#define ansElmResultMaxSizeVec(result,i)       (result->maxSize[i])



/******************************************************************
 data-level structure for ANSYS element results
 ******************************************************************/
struct elmResultData_str {     /* Name of the structure                                     */
  char            modified;    /* Flag indicating whether this result has been modified     */
  char            internal;    /* Flag indicating whether this result is internal to object */
  INT             resultType;  /* Type of result (see ansysdef.h for possible values)       */
  char            active;      /* Flag indicating if result is active or inactive           */
  INT             numValues;   /* Number of element result values stored for this result    */
  DOUBLE         *values;      /* Array containing element result values                    */
  elmResultData  *nextResult;  /* Pointer to the next element result data structure         */
                               /* for this element.  If this pointer is NULL, then this is  */
                               /* the last stored result for this element                   */
};

#define elmResultDataModified(eData)         (eData->modified)
#define elmResultDataInternal(eData)         (eData->internal)
#define elmResultDataType(eData)             (eData->resultType)
#define elmResultDataActive(eData)           (eData->active)
#define elmResultDataNumValues(eData)        (eData->numValues)

#define elmResultDataValuesPtr(eData)        (eData->values)
#define elmResultDataValuesVec(eData,i)      (eData->values[i])

#define elmResultDataNextResultPtr(eData)    (eData->nextResult)

