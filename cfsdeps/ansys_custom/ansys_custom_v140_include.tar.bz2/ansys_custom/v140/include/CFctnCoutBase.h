/******************************************************************/
/*!
\file CFctnCoutBase.h
\brief Classe maillage light pour adomesh
\version 1.00
*/
/******************************************************************/

#ifndef _CFCTNCOUTBASE_ 
#define _CFCTNCOUTBASE_ 12


#include "cadoe.h"
#include "CCadoePortable.h"
#include "CModeleBase.h"
#include "expmdb_struct.h"
#include "CFctnCoutBase.h"

#define AVEC_ALLONGEMENT 1
#define AVEC_CISAILLEMENT 2
#define AVEC_JACOBIEN 3
#define AVEC_MISES 4

class CProgressFunctions;

class CFctnCoutBase
{
public:
	enum E_TypeFcout
	{
		FC_allongement = 1,
		FC_cisaillement = 2,
		FC_jacobien = 3,
		FC_VonMises = 4
	};

  static CFctnCoutBase* Instance();

	~CFctnCoutBase();
	void setFonctionCout ( E_TypeFcout fc ) { SET_ON ( m_eFC, fc ); };
//	bool setCout( CUpdateMesh * ,int indE, int eFC, double *vecEps = NULL );
	bool setCout( CLMeshBase * ,int indE, VEC *Epert, int eFC, double *vecEps = NULL );
	bool setCout( T_Mesh *mesh, T_Element *ele, VEC *ElePert, int eFC, double *vecEps = NULL );
//	bool setGradient( CUpdateMesh *Umesh, int indE, int eFC );
	VEC *getVecteurFctnCout () { return &m_vCoutEle; };
	unsigned int getDimVecCout () { return m_vCoutEle.dim; };
	bool isToCalculate ( T_Element *ele );
	bool isToCalculate ( CLMeshBase *Cmesh, int indE );

private :
	void CFctnCoutInit ();
	inline bool getPerturb ( int indE );
	inline bool getPerturb ( VEC *Epert );
	bool setCoutBase( CLMeshBase * ,int indE, int eFC, double *vecEps = NULL );
	bool setCoutEleIso ( CLMeshBase *Cmesh, int indE, int dim );
	bool setCoutEleIso ( T_Element *ele, int dim );
	bool setCoutEleIso ( MAT *mat_B, int dim, E_ele_type_geo type );
	bool isToCalculateBase ( E_ele_type_geo type );
	bool setCoutElePouxx ( CLMeshBase *Cmesh, int indE );
	bool setCoutElePouxx ( T_Element *ele );
	bool setCoutElePouxx ( MAT *mat_B );

	double m_dTaille;
	int m_eFC;
	VEC m_vEpsEle;
	VEC m_vPert;
	VEC m_vCoutEle;
	double veps[TAILLE_EPS];
	double vpert[60];
	double vcout[27*7];

	static CFctnCoutBase* m_instance;

protected:
	CFctnCoutBase();

};



#endif
