/*! \file CSolutionXplorer.h

  \brief This header file defines the CSolutionXplorer class.

  \author Stephane MARGUERIN &copy; CADOE

  \date 25 Mars 2002

  \version $Id: CSolutionXplorer.h,v 1.4 2009/11/13 16:13:02 jtm Exp $
*/
#ifndef __CSolutionXplorer_h__ 
#define __CSolutionXplorer_h__ 1 

#include "cadoe_map.h"
#include "cadoe_vector.h"
#include "cadoe_list.h"
#include "cadoe_string.h"

#include "CSXModel.h"
#include "CParameterMgr.h"
#include "CEvalProcess.h"
#include "ADOC_Session.h"

class CC_AnsysClient;
class CDesignSetsCache;


/*! \class CSolutionXplorer CSolutionXplorer.h
  \brief The CSolutionXplorer allows to load and evaluate a CADOE results database.

  \attention This class is defined as a pure virtual class. Because of this, it
  must be instanciated and deleted only by using the routines
  new_CSolutionXplorer() and delete_CSolutionXplorer().

  To load a results database, use the method loadModel() which return
  a non null error code if it fails. Then you can retrieve the full
  list of nodes and elements. You can also get the list of the
  available parameters with their validated range of variation. 

  These methods do not manage the memory for the calling
  application. So you need to get the number of entities and to
  allocate the associated array before to call the method to get their
  description. For instance, to retrieve the nodes array, you must
  call getNumberOfNodes(), to allocate a
  CSolutionXplorer::Nodes array, and then to call getNodes().

	\todo Manage the list of CEvalProcess objects created from the SolutionXplorer
	to be able to delete all the not-yet-deleted ones when calling delete_CSolutionXplorer().
*/
class CSolutionXplorer 
{
 public:

  //! Context type
  typedef enum {
    CNX_NONE=-1,
    CNX_SDRCVA=0,
    CNX_SDRCVALITE,
    CNX_ANSYSTAYLOR,
    CNX_ANSYSPADE,
    CNX_ANSYSROMS,
    CNX_ADOMESHONLY
  } ContextType;

  //! Analysis type
  typedef enum {
    ANL_NONE=0,					/**< default value when nothing specified */
    ANL_LINEARSTATIC,				/**< linear static analysis  */
    ANL_HARMONIC, 	                	/**<  harmonic analysis */
    ANL_NORMALMODES			        /**< normal modes analysis  */
  } AnalysisType;

  //! Study type
  typedef enum {
    STD_NONE=0,					/**< default value when nothing specified */
    STD_BASELINE,				/**< baseline or standard study on the initial model */
    STD_SENSITIVITY, 		/**< sensitivity study where the parameters are varying indepently from each other */
    STD_PARAMETRIC			/**< parametric study where all the parameters are varying in the same time */
  } StudyType;

  //
  // METHODS
  //
	
  /*! \brief Method to be used asdde the CSolutionXplorer constructor.
    \return CSolutionXplorer instance
  */
  static CSolutionXplorer * new_CSolutionXplorer( const int iNumPort = -1 );
  static CSolutionXplorer * new_CSolutionXplorer( C_AdocSession *session , const int NumPort = -1);
  /*! \brief Method to be used as the CSolutionXplorer destructor.
    \param solutionXplorer [in] Instance to delete
  */
  static void delete_CSolutionXplorer( CSolutionXplorer *solutionXplorer );

  virtual void setNodalAveragingAcrossBodies( bool ) = 0 ;
  virtual bool getNodalAveragingAcrossBodies( void ) const = 0 ;

	
  /*! \brief Returns the SolutionXplorer version number as a string.
    \return version string
  */
  virtual string getVersion(void) const =0;


  //////////////////////////////////////////////////////////////////////
  // MODEL
  //////////////////////////////////////////////////////////////////////

  /*! \brief Load a results database and initialize the SolutionXplorer. Creates
    all the canonical evalDirections in the same time.
    \param filename [in] filename of the database to load, including
    extension.
    \return 0 for success
  */
  virtual int loadModel( const WString &filename ) = 0;

  virtual void setModel( void *model ) = 0;

  virtual int getPhysics(void) = 0;

  /*! \brief Retrieve the context type of the loaded model.
    \return context type
  */
  virtual CSolutionXplorer::ContextType getContextType(void) const = 0;

  /*! \brief Retrieve the analysis type of the loaded model.
    \return analysis type
  */
  virtual CSolutionXplorer::AnalysisType getAnalysisType(void) const = 0;

  /*! \brief Retrieve the study type of the loaded model.
    \return study type
  */
  virtual CSolutionXplorer::StudyType getStudyType(void) const = 0;

  virtual void getIDEASSetNumbers( int &solset, int &boset) const = 0;

  virtual bool isModelAxisymmetric(void) const = 0;

  virtual int getNumberOfLoadCases( void ) const = 0;
  virtual int getLoadCases( vector<string> &loadCasesName ) =0;
  virtual int getLoadCases( map<string,int> &loadCasesMap ) =0;
	
  //////////////////////////////////////////////////////////////////////
  // INITIAL MESH
  //////////////////////////////////////////////////////////////////////
	
	virtual CSXModel & getCSXModel( bool postmodel = false ) = 0;
  /*! \brief Retrieve the number of nodes
    \return number of nodes
  */
  virtual long getNumberOfNodes( bool postmodel = false ) = 0;
  /*! \brief Retrieve the number of elements of the mesh.
    \return number of elements
  */
  virtual long getNumberOfElements( bool postmodel = false ) = 0;

  virtual bool isNode(int label) = 0;
  virtual bool isElement(int label) = 0;
  virtual int getMinNodeLabel(void) const = 0;
  virtual int getMaxNodeLabel(void) const = 0;
  virtual int getMinElementLabel(void) const = 0;
  virtual int getMaxElementLabel(void) const = 0;
  virtual bool isWithShell(void) const = 0;

  //////////////////////////////////////////////////////////////////////
  // FE GROUPS
  //////////////////////////////////////////////////////////////////////
	
  /*! \brief Retrieve the number of existing groups
    \return number of groups
  */
  virtual long getNumberOfFEGroups( void ) = 0;
  virtual int createFEGroups( int numGroups, const CSXGroup *groups, bool indice = true ) = 0;
  virtual const CSXGroup * getFEGroup( const string &name ) = 0;
  virtual const CSXGroup * getParameterSupport( const string &paramName ) = 0;

  //////////////////////////////////////////////////////////////////////
  // PARAMETERS
  //////////////////////////////////////////////////////////////////////

  /*! \brief retrieve the number of parameters available for evaluation
    \return number of parameters
  */
  virtual int getNumberOfParameters( void ) const = 0;
  /*! \brief Retrieve the vector of all the parameters.
    \return vector of parameters
  */
  virtual	int getParameterVector( CParameterMgr::ParamVector &pvec ) const =0;
  /*! \brief Retrieve the list of all the parameters.
    \return list of parameters
  */
  virtual int getParameterList( CParameterMgr::ParamList &plist ) const =0;
  /*! \brief Retrieve the map of all the parameters.
    \return map of parameters
  */
  virtual int getParameterMap( CParameterMgr::ParamMap &pmap ) const =0;

  /*! \brief Assign you own parameter manager. Avoid the SolutionXplorer to create its own.
    \return ParameterManager reference
  */
  virtual void setParameterManager( CParameterMgr* pmgr ) =0;

  /*! \brief Retrieve the ParameterManager used by the SolutionXplorer, for your direct calls.
    \return ParameterManager reference
  */
  virtual CParameterMgr *getParameterManager( void ) const =0;


  //////////////////////////////////////////////////////////////////////
  // CRITERIA
  //////////////////////////////////////////////////////////////////////

  CCritInfo::CritInfoVector getAvailableCriteria();

  //////////////////////////////////////////////////////////////////////
  // EVALUATION PROCESS CONTROL
  //////////////////////////////////////////////////////////////////////

  /*! \brief Method to be used as the CEvalProcess constructor.
    \param postType [in] type of post-processing task to which the
    eval process is dedicated. Needed to determine a list of available
    criteria.
    \return CEvalProcess instance
  */
  virtual CEvalProcess* new_EvalProcess( CEvalProcess::PostType postType ) = 0;
  /*! \brief Method to be used as the CEvalProcess destructor.
    \param evalProcess [in] Instance to delete    
  */
  virtual void delete_EvalProcess( CEvalProcess* evalProcess ) =0;

  virtual CEvalProcess* retrieveEvalProcess( int id ) = 0;
  
  virtual CC_AnsysClient *getAnsysDriver(void) = 0;
  virtual void setAnsysDriver(CC_AnsysClient *driver) = 0;

  virtual CC_AnsysClient *getCadoeDriver(void) = 0;
  virtual void setCadoeDriver(CC_AnsysClient *driver) = 0;

  virtual CDesignSetsCache * getCacheObject() = 0;
  virtual void resetCacheObject() = 0;
  virtual bool getCachedCriterion( const CCriterion &crit, CCriterion &cachedCrit ) = 0;
  virtual void addCachedCriterion( CCriterion &crit ) = 0;


 protected:
  CSolutionXplorer() {};		
  virtual ~CSolutionXplorer() {};
};

#endif
