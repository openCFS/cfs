/*  FEM_bgmesh.h */
/*
 * *** ansys(r) copyright(c) 2009
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_bgmesh.h
 *  header file for FEM_bgmesh.c
 *
 */
#ifndef FEM_BGMESH_INCLUDE
#define FEM_BGMESH_INCLUDE
#include "FEM_cdbtypes.h"
#include "FEM_Public.h"


#ifdef __cplusplus
extern "C" {
#endif

                             /* === FEM_bgmesh: function for setting up       */
                             /* === background mesh. Given a set of nodes     */
                             /* === it will define a delaunay                 */
                             /* === triangulation of the nodes (or subset of  */
                             /* === the nodes) and assign scalar values to    */
                             /* === each of the nodes ready for interpolation */
INT FEM_bgmesh (
   MESH_OBJ obj_mesh,        /* mesh containing edges and nodes on bdry       */
   INT anum,                 /* the area number                               */
   INT numbound,             /* total number of nodes on bdry                 */
   INT shape,                /* final shape of elems (3=tri, 4=quad)          */
   INT *p_highCurv,          /* return - flag area has high curvature         */
   INT use_mesh3d,           /* Use the 3D world coordinates for sizing       */
   INT midnode,              /* flag - elements are quadratic                 */
   INT allnodes,             /* 1 = insert all bdry nodes into bg mesh        */
   INT layermesh,            /* flag - if layer meshing                       */
   INT surfcurv,             /* do sizing for surface curvature               */
   INT flat,                 /* flag - area (anum) is flat                    */
   INT aniso );              /* flag - using anisoropic meshing               */

                             /* === FEM_bgMeshDelete: delete the background   */
                             /* === mesh                                      */
void FEM_bgMeshDelete ( void  );

                             /* === FEM_bgAvgSize: retreive the average mesh  */
                             /* === size                                      */
DOUBLE FEM_bgAvgSize ( void  );

                             /* === FEM_bgMinSize: retreive the minimum mesh  */
                             /* === size                                      */
DOUBLE FEM_bgMinSize ( void  );

                             /* === FEM_bgMaxSize: retreive the maximum mesh  */
                             /* === size                                      */
DOUBLE FEM_bgMaxSize ( void  );

                             /* === FEM_bgEstimateNumElems: estimate the total*/
                             /* === number of elements to be meshed in this   */
                             /* === area from the background mesh.            */
                             /* === Return: INT  elem_estimate                */
INT FEM_bgEstimateNumElems ( void  );

                             /* === FEM_bgIsScrewed: return fg_screwed */
INT FEM_bgIsScrewed ( void  );

                             /* === FEM_bgMaxSlopeRatio: return fg_maxSlopeRatio*/
DOUBLE FEM_bgMaxSlopeRatio ( void  );

                            /* === FEM_isBgMesh(): return fg_obj_bgmesh */
MESH_OBJ FEM_bgIsBgmesh( ); 


#ifdef __cplusplus
}
#endif


#endif
