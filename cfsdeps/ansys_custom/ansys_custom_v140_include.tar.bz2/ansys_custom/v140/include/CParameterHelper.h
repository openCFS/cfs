////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         copyright(c) 2010 SAS IP, Inc.  All rights reserved.            //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: CParameterHelper.h $
// $Revision: 1.8 $Id: CParameterHelper.h,v 1.8 2010/04/15 17:55:33 srpailla Exp $ $
// $Date: 2010/04/15 17:55:33 $
// $Author: srpailla $
//
// Decription: Helper routines for CParameter.
//
////////////////////////////////////////////////////////////////////////////
#ifndef __CParameterHelper_h__ 
#define __CParameterHelper_h__ 1 
//
//
// DO NOT INCLUDE CADOE HEADERS HERE
// in order to avoid creating dependencies between PlugIn_DS and the CADOE library.
//
//
#ifndef NO_CADOE_NAMESPACE 
namespace Cadoe { 
#endif 

  class CParameterHelper
    {
    private:
      CParameterHelper(){};
      ~CParameterHelper(){};

    public:

      // FACT <-> VAL <-> ADD conversion helpers
      static void val2fact( double valIni, double valMin, double valMax, double &factMin, double &factIni, double &factMax )
	{
	  double vmin = valMin / valIni;	
	  double vmax = valMax / valIni;
	  factIni = 1.0;
	  factMin = (vmin<vmax) ? vmin : vmax;
	  factMax = (vmin<vmax) ? vmax : vmin;
	}

      static void fact2val( double valIni, double factMin, double factMax, double &valMin, double &valMax )
	{
	  if ( valIni < 0 )
	    {
	      valMin = factMax * valIni;
	      valMax = factMin * valIni;
	    }
	  else
	    {
	      valMin = factMin * valIni;
	      valMax = factMax * valIni;
	    }
	}

      static void val2add( double valIni, double valMin, double valMax, double &addMin, double &addIni, double &addMax )
	{
	  addIni = 0.0;
	  addMin = valMin - valIni;
	  addMax = valMax - valIni;
	}

      static void add2val( double valIni, double addMin, double addMax, double &valMin, double &valMax )
	{
	  valMin = valIni + addMin;
	  valMax = valIni + addMax;
	}
    };

#ifndef NO_CADOE_NAMESPACE 
} //namespace Cadoe 
using namespace Cadoe; 
#endif 

#endif
