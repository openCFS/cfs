/*****************************************************************************
 *                   Copyright (C) 1999 CMSoft                               *
 *                                                                           *
 *  These lines of code and declarations contain unpublished proprietary     *
 *  information of CMSoft. They may not be copied or duplicated in whole     *
 *  or part without prior authorization from CMSoft.                         *
 *                                                                           *
 *****************************************************************************/
#ifndef _FS_MATH_GENERAL_H_
#define _FS_MATH_GENERAL_H_

#include <math.h>

/*
template <class A>
inline
A max(A a, A b)
{ return (a>b) ? a : b; }

template <class A>
inline
A min(A a, A b)
{ return (a<b) ? a : b; }
*/

template <class A>
inline
A abs(A a)
{ return (a>=0) ? a : -a; }

template <class A, class B>
class Accesser {
   A **a;
   B A::*obj;
 public:
   Accesser (A **_a, B A::*_obj) { a = _a; obj = _obj; }
   B operator[](int i) { return a[i]->*obj; }
};

template <class A, class B>
Accesser<A,B>
fieldAccess(A **_a, B A::*_obj) { return Accesser<A,B>(_a,_obj); }

template <class A>
void mswap (A &a, A &b) { A tmp = a; a = b; b = tmp; }

#endif
