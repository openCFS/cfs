#ifndef FEM_SPHEREPFINLFUENCESTRUCT
#define FEM_SPHEREPFINLFUENCESTRUCT
#include "FEM_cdbtypes.h"

typedef struct SPHERE_OF_INFLUENCE_TYP     *SPHERE_OF_INFLUENCE_PTYP;

typedef struct SPHERE_OF_INFLUENCE_TYP{
    DOUBLE xyz[3];
    DOUBLE size;
    DOUBLE r1;
    DOUBLE r2;
    short  iSpecial; /* -1 = boi packed sphere, 0 soi, 1 contact size, > 1 gap size */
} SPHERE_OF_INFLUENCE_TYP;





#endif


