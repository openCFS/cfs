/**
 * @file   C_ProgressBar.h
 * @author  <ftheveno@LYOFTHEVENO8>
 * @date   Mon Nov 09 11:55:35 2009
 * 
 * @brief  
 * 
 * 
 */

#ifndef _C_PROGRESS_H_
#define _C_PROGRESS_H_ 1

#include "C_ProgressEngine.h"
#include "core_time.h"


/*!
 *  \class	C_ProgressBar
 *  \brief	
 *  \author	Frederic Thevenon
 *  \version	1.0
 *  \date	2009
 *  \bug	
 *  \warning	
 *
 *  version 1.0 :       Initial Revision
 */

class C_ProgressBar : public C_ProgressEngine
{
public:
  C_ProgressBar(int iProcessId, double deltaTime) : C_ProgressEngine(iProcessId) { _deltaTime = deltaTime;}
  ~C_ProgressBar() {}
  
  void SetUp(char* cTitle, double goal, E_ProgressType Type = E_LOG10);  
  void checkAbort( void);
  void Update(int iter);
  void Update(int iter, double crit);
  void Finish( void);
  
protected:
  
  double _BaseSec, _BaseUSec, _ElapsedStart;
  double _deltaTime;
};

#endif
