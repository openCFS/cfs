
/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 2009 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_reMark.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_reMark.h
 *  Prototypes and macros for refining tetrahedral meshes.
 *
 */

#ifndef FEM_REMARK_INCLUDE
#define FEM_REMARK_INCLUDE

#include "FEM_cdbtypes.h"

#ifdef __cplusplus
extern "C" {
#endif
                            /* ============================================== */
                            /* === FEM_reMarkNodes: mark the nodes that will  */
                            /* === be involved in refinement.                 */
                            /* === Return: INT  EXIT_SUCCESS or EXIT_FAILURE  */
                            /* ============================================== */
INT FEM_reMarkNodes (
   INT *a_nodes,            /* (IN)  array of nodes to refine about           */
   INT num_nodes,           /* (IN)  number of nodes in a_nodes               */
   INT numlevels,           /* (IN)  number of levels to refine               */
   INT *num_marked  );      /* (OUT) return number of nodes marked            */

                            /* ============================================== */
                            /* === FEM_reUnMarkInverted: Loop through each    */
                            /* === element that is going to be refined and    */
                            /* === make sure that refining it will not lead   */
                            /* === to inverted elements.  If it does then     */
                            /* === unmark the nodes on the element so that we */
                            /* === don't invert any elements.                 */
                            /* === Return: INT  EXIT_SUCCESS or EXIT_FAILURE  */
                            /* ============================================== */
INT FEM_reUnMarkInverted(
   INT *num_marked  );      /* (IN/OUT) number of nodes marked                */


                            /* ============================================== */
                            /* === FEM_reUnMarkExluded:unmark all exlcuded nodes */
                            /* === Return: INT  EXIT_SUCCESS or EXIT_FAILURE  */
                            /* ============================================== */
INT FEM_reUnMarkExcluded (
   INT *a_nodes,            /* (IN)  array of nodes to exclude           */
   INT num_nodes,           /* (IN)  number of nodes in a_nodes               */
   INT *num_marked  );      /* (OUT) return number of nodes marked            */



#ifdef __cplusplus
}
#endif

#endif

