//////////////////////////////////////////////////////////////////////////// 
//          Copyright (C) 2010 ANSYS Inc.  All Rights Reserved            // 
//                                                                        // 
// This file contains proprietary software licensed from ANSYS Inc.       // 
// This header must remain in any source code despite modifications or    // 
// enhancements by any party.                                             // 
//                                                                        // 
//////////////////////////////////////////////////////////////////////////// 
// 
// $Workfile: C_RigidBody.h
// $Revision: 
// $Date: 
// $Author: 
// 
// Decription:  
// 
//////////////////////////////////////////////////////////////////////////// 

#ifndef __C_RIGIDBODY_H__ 
#define __C_RIGIDBODY_H__ 1 

#include "C_vstruct.h"
#include "C_MatSp.h"

class C_RigidBody
{
public:
  C_RigidBody(C_MatSp<double> &Kmat, int nbddl, int nbLocal, C_VecPi<int> &LocalToAns);
  virtual ~C_RigidBody();
  
  void Init();
  
  C_VSTRUCT<double> &getPhi() {return _phi;};
  int getDimPhi() {return _phi.getDim();}
  
protected:
  int _ndone;			// number of rigif modes
  double _seuil;		// seuil for a vp to be associated to rigid body
  int _nbddl;
  int _size;
  
  C_VecPi<int> &_LocalToAns;	// dim = _size
  C_VecPi<double> _diag;
  C_VSTRUCT<double> _phi;	// eigen vectors
  C_MatSp<double> &_K0;		// square matrix (_size*_size)
};

#endif
