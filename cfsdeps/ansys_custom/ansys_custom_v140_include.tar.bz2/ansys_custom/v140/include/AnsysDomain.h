#ifndef _ANSYS_DOMAIN_H_
#define _ANSYS_DOMAIN_H_

#include "cadoesys.h" 
#include "computer.h" 

#include "C_VecPi.h" 
#include "CoreDomain.h" 
#include "CoreCPUDomain.h"
#include "ThreadManager.h" 
 
#include "FullMatrix.h" 
#include "DistVector.h" 
#include "DistInfo.h" 
#include "FSolver.h" 
#include "FSInfo.h" 

#include "Communicator.h" 
#include "BlockAlloc.h" 
#include "FSConnectivity.h" 
#include "AnsysElement.h" 
#include "dds_globals.h"
#include "C_SubAnsysDomain.h"

class AnsysDomain;
class C_TimeManager;
class C_AnsysBCs;

extern int G_dofflags;

class AnsysBC
{
public:
  AnsysBC();
  ~AnsysBC();
  
  void fill(int nbddl, int dofPerNode, C_AnsysBCs *BCs);
  
  int *getBcsDof()	{ return _bcsDof;   }
  double *getValue()	{ return _value; }
  void Print();

protected:
  int _nbddl;
  int *_bcsDof;
  double *_value;
};


class AnsysDomain : public C_SubAnsysDomain, public C_AnsysSolver<C_MatSp<double> >
{ 
public:
  static bool isInstance() {return S_AnsysDomain != NULL;}
  static AnsysDomain* Instance();
  static void kill();

  static AnsysDomain *S_AnsysDomain;
  AnsysDomain(); 
  virtual ~AnsysDomain(); 
  
  bool isInitialized() {return _isInitialized;}
  void InitOptions(int *ivect, double *dvect);
  string getName() {return "     Feti      ";} 
  void addSolverStat(bool allowToSum = true);
  void PrintStats(C_TimeManager &, int iter[2],
		  double selfCpuTime, double totalCpuTime, double elapsedTime,
		  double selfMemory, double totalMemory,
		  double restartCost);
  
  C_MatSp<double> &getStiffnessMatrix(int iSub = 0) {return _solver->getStiffnessMatrix(iSub);}
  C_MatSp<double> &getMassMatrix(int iSub = 0) {return _solver->getMassMatrix(iSub);}
  C_MatSp<double> &getDampMatrix(int iSub = 0) {return _solver->getDampMatrix(iSub);}
  C_VecPi<double> &getRhs() {return _rhs;}
  C_VecPi<int> &getRemToAns(int iSub = 0) {return _solver->getRemToAns(iSub);}

  // IO
  void Write();
  void Read();
  
  // Initialize FEM
  void InitFEM();
  
  // 
  void Assembly(int *kelreq);
  
  // 
  void addInequations();
  
  // just defined Solve to be not unresolved
  void Solve(C_Vec<double> &B, C_Vec<double> &X, int nbX = 1, bool trans = false) {}
  
  // initializations
  void initInput(INT *ivect, INT len1, DOUBLE *dvect, INT len2, INT *curdof, INT numdof, char *jobName);
  void endInput();
  
  // initialization domain decomposition
  void mergeDomainsWithCE(INT *nume, INT *Order,INT *nDomain, INT *Domain,INT *nSuperDomain, INT *SuperDomainElem);
  virtual void setDomains(INT *Domain, INT nDomain, INT *SuperDomainElem, INT nSuperDomain, INT nPilot, INT *) = 0;
  void setProperty(INT *DomainProperty, INT nDomain);
  
  // assembly 
  void BeginAssm(int kfstps);
  void addStiffness(int indElem, double *zs, double *ms, double *cs, double *zsc, int *ls, int nr, int *kelfil, bool unsym);
  
  virtual FSCoreCPUPreprocessor *getCoreCpuDomain() = 0;
  
  // solve 
  void Factor();
  void solve(double *disp, int lenu, double tol, 
	     int &nbIter, int &status, double &residual,
	     double &selfCpuTime, double &totalCpuTime, double &elapsedTime,
	     double &selfMemory, double &totalMemory, int &abortFlag); 
  
  // make the core math-domains
  virtual void makeSubCores();
  
  // memory infos
  void displayMemSize(char *str);
  double getMemSize();
  double getMaxMemSize();
  
public:
  int _glNumSub;		// only defined on master
  AnsysBC *_ansysPres;
  C_VecPi<double> _rhs;
  
  int _numThreads;
  
  DofSet _probDofs; 
  int _uLength; 
  int _sumNbInternalDofs;
  int _sumNbDualDofs;
  bool _unsym;
  
  int _numDof;
  int *_domProp; 
  
  // Progress file and timing additions 
  char _longJobname[32];
  char *_jobname; 
  
  BlockAlloc _ba; 
  
  FSInfo *_fsInfo;
  FSCoreCPUPreprocessor *_fsCorePre;
  FSCoreSolver *_solver;
}; 

class AnsysDomainMaster : public AnsysDomain
{
public:
  AnsysDomainMaster() {_cpuToSub = _allSubToE = NULL; }
  ~AnsysDomainMaster() {delete _cpuToSub; delete _allSubToE;}

  FSCoreCPUPreprocessor *getCoreCpuDomain();
  void setDomains(INT *Domain, INT nDomain, INT *SuperDomainElem, INT nSuperDomain, INT, INT*);
  
protected:
  FSConnectivity *_cpuToSub;
  FSConnectivity *_allSubToE;
};

class AnsysDomainSlave : public AnsysDomain
{
public:
  AnsysDomainSlave() {}
  ~AnsysDomainSlave() {}

  FSCoreCPUPreprocessor *getCoreCpuDomain();
  void setDomains(INT *Domain, INT nDomain, INT *SuperDomainElem, INT nSuperDomain, INT, INT*);
};


#endif
