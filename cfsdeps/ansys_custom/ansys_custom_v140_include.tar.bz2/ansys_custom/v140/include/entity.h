/* entity.h                                                    kz372   */
/* 
 * *** copyright(c) 2009 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */

/*  Get/Inquire entity supEnts*/ 
INT 
CALLTYP xAnsysEntSupEnts_ ansPROTO((
     INT  *id,			/* I: Ansys entity id */
     INT  *dim,		/* I: dimension of entity */
     INT  *supEnts,		/* O: id array of geom sups */
     INT  *flag 		/* I: get/inquire */
)); 

/*  Get the keypoints of a line*/ 
void CALLTYP xAnsysLineEndPoints_ ansPROTO((
     INT  *id,		        /* line entity */
     INT  *kp1,
     INT  *kp2
));

/*  Get/Inquire subentity list for line, area, or volume
*/ 
INT 
CALLTYP xAnsysEntCells_ ansPROTO((
     INT  *id,			/* I: Ansys entity id */
     INT  *dim,		/* I: dimension of entity */
     INT  *cells,		/* O: subentity array */
     INT  *flag 		/* I: get/inquire */
));

/*  Retrieve specific parametric data for a line*/ 
void 
CALLTYP xAnsysLineParamData_ ansPROTO((
     INT  *id,			/* I: line entity */
     xREAL *data 		/* length, hotspot */
));

/*  Return number of frames for an entity*/ 
INT
CALLTYP xAnsysEntFrameSize_ ansPROTO((
     INT *ent,			/* I: entity id */
     INT *dim 			/* I: dimension of entity */
));

/*  Return largest number of frames for an entity*/
INT
CALLTYP xAnsysEntNumFrames_ ansPROTO((
     INT *ent,                 /* I: entity id */
     INT *dim                  /* I: dimension of entity */
));

/*  Return frame tree for an entity*/
INT
CALLTYP xAnsysEntFrameTree_ ansPROTO((
     INT *ent,                 /* I: entity id */
     INT *dim,                  /* I: dimension of entity */
     INT *tree,
     INT *flag
));

/*  Get a frame for an index*/ 
INT 
CALLTYP xAnsysEntFrame_ ansPROTO((
     INT  *id,			/* I: Ansys entity id */
     INT  *dim,		/* I: dimension of entity */
     INT  *index,		/* I: frame index */
     INT  *ents,		/* 0: frame entity array */
     INT  *flag 		/* I: get/inquire */
));

/*  Get area area, hot spot, minmax box and corner angle info.*/ 
INT 
CALLTYP xAnsysAreaParamData_ ansPROTO((
     INT  *id,		        /* I: area */
     xREAL *data 		/* O: param data array */
));

/*  Get volume volume, hot spot, minmax box */ 
INT 
CALLTYP xAnsysVolumeParamData_ ansPROTO((
     INT *id,	        	/* I: volume */
     xREAL *data 		/* O: param data array */
));

/*  Initialize globals for entity functions.*/ 
void
xAnsysEntityInit ();

/*  Release globals for entity functions.*/ 
void
xAnsysEntEnd ();

/*  Boolean operation */
INT  CALLTYP
xAnsysSubtract_ ansPROTO((
  INT *geoma,         /* I    First ansys id list to subtract */
  INT *dima,          /* I    Dimensions of first ansys id list */
  INT *na,             /* I    Size of the first ansys id list */
  INT *geomb,         /* I    Second ansys id list to subtract  */
  INT *dimb,          /* I    Dimensions of second ansys id list */
  INT *nb,             /* I    Size of the second ansys id list */
  INT *sepflg,         /* I    Separation flag                  */
  INT *keepflg,        /* I    Keep/delete flag                 */
  INT *geomo,          /* O    Output geometry list             */
  INT *ngeom,          /* O    Size of the output geometry list */
  INT *hp_geom        /* O    Heap handler for output geometry list */
  ));

/*  Concatenation  */
INT  CALLTYP
xAnsysConcat_ ansPROTO((
  xGEOMS geoms,              /* I: list of geoms to concatenate */
  xINT  *code               /* O: error code */
));

