/*  fem_spSearch.h */
/* 
 * *** ansys(r) copyright(c) 2009
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  fem_spSearch.h
 *  Prototypes and macros for searching for surface proximity refinement
 *
 */

#ifndef FEM_SPSEARCH_____H
#define FEM_SPSEARCH_____H

                          /* ================================================ */
                          /* === FEM_spSearchRanges: finds the intersections  */
                          /* === between a bounding box and the recatngles    */
                          /* === stored in the range tree.                    */
                          /* === Return:  EXIT_SUCCESS or EXIT_FAILURE        */
                          /* ================================================ */
INT FEM_spSearchRanges (
   RANGETREE_TYP *ps_rtree,    /* (IN)     range tree                         */
   BOUNDINGBOX_TYP *ps_bbox,   /* (IN)     query interval [low,high],         */
                               /*          low <= high                        */
   RECTANGLE_TYP ***aps_rect,  /* (OUT)    an array to store intersected      */
                               /*          rectangles.  This is allocated in  */
                               /*          this function and must be          */
                               /*          deallocated by the calling         */
                               /*          function.                          */
   INT *aps_rect_length,       /* (IN/OUT) Length of aps_rect before and      */
                               /*          after this routine.                */
   INT *num_inters  );         /* (OUT)    return number of intersections     */
                               /*          between the bounding box           */
                               /*          (rectangle) ps_bbox with the       */
                               /*          rectangles stored in the arrays of */
                               /*          ps_rtree.                          */

#endif

