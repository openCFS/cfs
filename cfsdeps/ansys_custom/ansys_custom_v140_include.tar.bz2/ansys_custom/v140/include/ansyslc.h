#ifndef __ANSYSLC_H__
#define __ANSYSLC_H__

#define ANSYSLC_OPT_APP          0x01
#define ANSYSLC_OPT_AVAIL        0x02
#define ANSYSLC_OPT_CLIENTDIR    0x03
#define ANSYSLC_OPT_HELP         0x04
#define ANSYSLC_OPT_PRODDEF      0x05
#define ANSYSLC_OPT_EXISTS       0x06
#define ANSYSLC_OPT_LICINI       0x07
#define ANSYSLC_OPT_CHECKIN      0x08
#define ANSYSLC_OPT_CHECKOUT     0x09
#define ANSYSLC_OPT_PREFSVR      0x0a
#define ANSYSLC_OPT_USELI        0x0b
#define ANSYSLC_OPT_LOG          0x0c
#define ANSYSLC_OPT_LOG_APPEND   0x0d
#define ANSYSLC_OPT_CHECKCNT     0x0e
#define ANSYSLC_OPT_ACLEOUT      0x0f
#define ANSYSLC_OPT_ACLEIN       0x10
#define ANSYSLC_OPT_SITEPREF_LIC 0x11
#define ANSYSLC_OPT_SITEPREF     0x12
#define ANSYSLC_OPT_CAPPREF      0x13
#define ANSYSLC_OPT_CAPPREF_LIC  0x14
#define ANSYSLC_OPT_CHECK        0x15
#define ANSYSLC_OPT_USAGE_FORM   0x16
#define ANSYSLC_OPT_SSL          0x17
#define ANSYSLC_OPT_SHARED       0x18
#define ANSYSLC_OPT_USAGE        0x19
#define ANSYSLC_OPT_STATUS       0x1a
#define ANSYSLC_OPT_VIEW         0x1b
#define ANSYSLC_OPT_WAIT         0x1c
#define ANSYSLC_OPT_ACADEMIC     0x1d
#define ANSYSLC_OPT_DAYSLEFT     0x1e
#define ANSYSLC_OPT_CHECKLOOP    0x1f
#define ANSYSLC_OPT_CHILDARGS    0x20
#define ANSYSLC_OPT_CHILDSTART   0x21
#define ANSYSLC_OPT_CUSTNO       0x22
#define ANSYSLC_OPT_CLIENTCON    0x23
#define ANSYSLC_OPT_ACLEEXISTS   0x24
#define ANSYSLC_OPT_TOGGLE_API   0x25
#define ANSYSLC_OPT_MSG_LOG      0x26
#define ANSYSLC_OPT_DELIM        0x27
#define ANSYSLC_OPT_CHILD_DELIM  0x28
#define ANSYSLC_OPT_OUTINFO      0x29
#define ANSYSLC_OPT_CAPLEVEL     0x2a
#define ANSYSLC_OPT_FULLEXISTS   0x2b
#define ANSYSLC_OPT_FLEXSERVER   0x2c
#define ANSYSLC_OPT_PRODUCTNAMES 0x2d
#define ANSYSLC_OPT_ENVVARS      0x2e
#define ANSYSLC_OPT_PREFFEAT     0x2f
#define ANSYSLC_OPT_CAPPREFS     0x30
#define ANSYSLC_OPT_CHECKPOINT   0x31
#define ANSYSLC_OPT_ANDCAP       0x32
#define ANSYSLC_OPT_SETENV       0x33
#define ANSYSLC_OPT_DELENV       0x34
#define ANSYSLC_OPT_SHARE_READ   0x35
#define ANSYSLC_OPT_SHARE_SAVE   0x36
#define ANSYSLC_OPT_ORCAP        0x37
#define ANSYSLC_OPT_ORCAP_STR    0x38
#define ANSYSLC_OPT_ANDCAP_STR   0x39
#define ANSYSLC_OPT_LAST_ERR     0x3a
#define ANSYSLC_OPT_LISTEXISTS   0x3b
#define ANSYSLC_OPT_FEAT2PROD    0x3c
#define ANSYSLC_OPT_FEAT2INFO    0x3d
#define ANSYSLC_OPT_PROD2FEAT    0x3e
#define ANSYSLC_OPT_PROD2INFO    0x3f
#define ANSYSLC_OPT_CHILDWAIT    0x40
#define ANSYSLC_OPT_DELIM_WAIT   0x41
#define ANSYSLC_OPT_HANG         0x42
#define ANSYSLC_OPT_PRDDEF       0x43
#define ANSYSLC_OPT_CAPDEF       0x44
#define ANSYSLC_OPT_CRASH        0x45
#define ANSYSLC_OPT_UTIL_ARGS    0x46
#define ANSYSLC_OPT_UTIL_START   0x47
#define ANSYSLC_API_FUNCTION     0x48
#define ANSYSLC_OPT_MISC         0x49
#define ANSYSLC_OPT_UTIL         0x4a
#define ANSYSLC_OPT_RESERVE      0x4b
#define ANSYSLC_OPT_RETURN_RESERVE      0x4c
#define ANSYSLC_OPT_PREFCNT      0x4d
#define ANSYSLC_OPT_USEALIVER    0x4e
#define ANSYSLC_OPT_USEVERSION   0x4f
#define ANSYSLC_OPT_SETENV_XML   0x50
#define ANSYSLC_OPT_RESID_SAVE   0x51
#define ANSYSLC_OPT_HPCCNT       0x52
#define ANSYSLC_OPT_ARG_TO_UTIL  0x53
#define ANSYSLC_OPT_ID_CONVERT   0x54
#define ANSYSLC_OPT_WRITE_DATA   0x55
#define ANSYSLC_OPT_READ_DATA    0x56
#define ANSYSLC_OPT_SVR_STATE    0x57
#define ANSYSLC_OPT_SVR_DATA     0x58
#define ANSYSLC_OPT_ACLEOUT_INT  0x59
#define ANSYSLC_OPT_ACLE_INT_APP 0x5a
#define ANSYSLC_OPT_SLOW         0x5b

#define ANSYSLC_ERR_NONE         0
#define ANSYSLC_ERR_XML          1
#define ANSYSLC_ERR_WRITE        2

#ifdef _WIN32
#  define ANSYSLC_SEP      ";"
#  define ANSYSLC_DIR_SEP  "\\"
#else
#  define ANSYSLC_SEP      ":"
#  define ANSYSLC_DIR_SEP  "/"
#endif

#define ANS_BUFSIZ_SM            64
#define ANSYSLC_MAXLINE          2048

#if defined(c_plusplus) || defined(__cplusplus)
#	define ansyslcext extern "C"
   void set_logger(ostream* pLogger);
   string ansyslc_trimall(string szBuffered);
#else
#	define ansyslcext extern
#endif

ansyslcext void ansyslc_init_longoptions(int iIsC, int argc, char *argv[]);
ansyslcext void ansyslc_usage();
ansyslcext int is_all_digit_string(const char* szStr);
ansyslcext int is_now(const char* szArg);
ansyslcext void wait_for_children(int iMaxWaitSeconds);
ansyslcext void start_child(const char* szCommand, const char* szLogFile, anslic_bool bAppendToLog, const char* szMsgFile, int iChildWait);
ansyslcext void start_util(const char* szCommand, const char* szLogFile, int iChildWait);
ansyslcext void start_children_delimited(const char* szCommand,
   const char* szChildFile,
   const char* szDelim,
   const char* szLogFile,
   anslic_bool bAppendToLog,
   const char* szMsgFile,
   int iChildWait,
   int iDelimWait);
ansyslcext int add_child_arg(int iOptId, const char* szOptArg);
ansyslcext int add_util_arg(const char* szOptArg);
ansyslcext void set_checkout_id(const char* szFeature, const char* szOutId);
ansyslcext char* get_checkout_id(const char* szFeature);
ansyslcext char* get_last_checkout_id();
ansyslcext char* get_option_arg(int iOptId);
ansyslcext const char* get_data_value(const char* szDataId);
ansyslcext const char* get_licensing_sysdir();
ansyslcext void get_env_var_setting(const char* szEnvVar);
ansyslcext void display_xml_return_value(const char* szXml);
ansyslcext int write_xml_return_value_to_file(const char* szToFile, const char* szXml);
ansyslcext void ansyslc_checkpoint(void);
ansyslcext void ansyslc_set_env(const char* szVarEqVal);
ansyslcext void ansyslc_set_env_file(const char* szXmlFile);
ansyslcext void ansyslc_unset_env(const char* szVar);
ansyslcext int ansyslc_share_read(const char* szFile, char* szSvr, char* szShare);
ansyslcext int ansyslc_share_write(const char* szFile, char* szSvr, char* szShare);
ansyslcext void api_func_c();
ansyslcext void api_func_cpp();
ansyslcext void ansyslc_notsupported(int iRevn);
ansyslcext anslic_bool ansyslc_set_ali_version(char* szVer);
ansyslcext int ansyslc_reserveid_write(const char* szFile, char* szResId);
ansyslcext void ansyslc_convert_command_ids(char* szType);
ansyslcext int write_data(const char* szFile);
ansyslcext int read_data(const char* szFile);
ansyslcext int write_bguhl_data(const char* szFile, const char* szServerData);

#endif
