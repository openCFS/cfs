/* ---------------------------------------------------------------------- */
/* ***  copyright(c) 2011 SAS IP, Inc.  All rights reserved.                                         */
/* *** ansys, inc.                                                        */
/* ---------------------------------------------------------------------- */


/*    *** Notice - This file contains ANSYS Confidential information  ***      */

#ifndef _FX_ANSYS_UTILS_H_
#define _FX_ANSYS_UTILS_H_

/* === define data types used in the ANSYS meshing Toolkit. */

#ifndef EXTERNAL_LINK
#include "computer.h"
#include "cAnsMemInterface.h"
#include "cAns_printf.h"
#endif

#if !defined(EXTERNAL_COMPILE) && !defined(EXTERNAL_LINK)

/* === header files defining types for compiling within Ansys 5.X */

#include "float.h"
#include "globals.h"
#include "header.h"
#include "sysparh.h"

#endif

#endif  /* _FX_ANSYS_UTILS_H_ */

