#ifndef __C_PARTIALASSEMBLY_H__
#define __C_PARTIALASSEMBLY_H__ 1

#include "cadoe.h"
#include "m_matrix.h"
#include "cwrap_ansys.h"
#include "nbbP.h"
#include "C_AnsysModele.h"
#include "ThreadManager.h"

class C_PartialAssembly
{
public:
  static C_PartialAssembly *Instance()
  {
    if (S_PartialAssembly == NULL)
      S_PartialAssembly = new C_PartialAssembly();
    return S_PartialAssembly;
  }
  
  static void kill()
  {
    FSThreadManager::lock(LOCKPARTASSEMB);
    if (S_PartialAssembly) delete S_PartialAssembly; S_PartialAssembly = NULL;
    FSThreadManager::unlock(LOCKPARTASSEMB);
  }
  
  int	*getActiveElems()	{return _activeElem;		}
  IVEC	*getElemsToAssemble()	
  {
    if (_elemsToAssemble == NULL)
      return NULL;
    
    if (!_indicesElems)
      {
	char fctn [] = "C_PartialAssembly::getElemsToAssemble";
	int ier(0);
	
	// convert numbers to indices
	C_AnsysModele model;
	model.initialize();
	int nbElements = model.getNbElements();
	IVEC *indicesElem = LM_iv_get(nbElements,fctn,&ier);
	
	for (int ie = 0; ie < _elemsToAssemble->dim; ie++)
	  indicesElem->ive[model.getElementIndice(_elemsToAssemble->ive[ie])] = 1;
	
	IV_FREE(_elemsToAssemble);
	_elemsToAssemble = indicesElem;
	_indicesElems = true;
      }
    return _elemsToAssemble;	
  }
  VEC	*getListResu(int id)	{return _list_resu ? _list_resu[id] : NULL;}
  IVEC	*getListElem(int id)	{return _list_elem ? _list_elem[id] : NULL;}
  
  void InitElemToAssemly(C_VecPi<int> &listElem);
  void InitElemToAssemly(IVEC *list_elem_to_derive, bool indicesElem = true, bool hasToFreeElemsToAssemble = false);
  void InitElemToAssemly(double eps, IVEC *list_elem_to_derive, T_modele *modele);
  void InitElemToAssemly(string nameComponent);
  
protected:
  C_PartialAssembly()
  { 
    char fctn [] = "C_PartialAssembly::C_PartialAssembly";
    int key = 0;
    int nb_proc = cwPpinqr(&key);
    
    _indicesElems = true;
    _activeElem = NEW_A(nb_proc,INT,fctn,MUP); 
    _list_resu = NEW_A(TAILLE_TYPE_RES,VEC*,fctn,MUP);
    _list_elem = NEW_A(TAILLE_TYPE_RES,IVEC*,fctn,MUP); 
    _elemsToAssemble = NULL;
    _hasToFreeElemsToAssemble = false;
  }
  
  ~C_PartialAssembly()
  {
    LM_FREE(_activeElem); 
    LM_FREE(_list_elem);
    LM_FREE(_list_resu);
    if (_hasToFreeElemsToAssemble)
      IV_FREE(_elemsToAssemble);
  }
  
protected:
  static C_PartialAssembly *S_PartialAssembly;	// singleton
  int	*_activeElem;				// current element to assemble in sfelem.F

  IVEC	*_elemsToAssemble;	// elements to assembly (indices or numbers: see _indicesElems)
  bool  _hasToFreeElemsToAssemble;
  
  bool	_indicesElems;
  VEC	**_list_resu;		// list of results  (DXVT only)
  IVEC  **_list_elem;		// list of elements (DXVT only)
};

#endif
