/*  FEM_CtoF.h */
/* *** Notice - This file contains ANSYS Confidential information  *** */
/*
 * *** ansys(r) copyright(c) 2009
 * *** ansys, inc.
 */
/*                                                                         sjo
 *  FEM_CtoF.h
 *  Prototypes and #defines for handling calls from
 *  C to FORTRAN and FORTRAN to C for the FEM module
 *  NOTE: This header file should only be used for internal meshing
 *        components calling other internal FORTRAN meshing components.
 *        Use FEMa_CtoF.h for general FORTRAN to C interface prototypes
 */

/* (1)-------------------------------------------------------------*/

#if defined(DSPACE_CMDB)
#define PCWINNT_SYS
#endif

#if defined (PCWINNT_SYS)
#  if !defined (SYSTEM_FLOAT_H)
#    define SYSTEM_FLOAT_H
#    include <float.h>
#  endif
#  if !defined (MAXDOUBLE)
#    define MAXDOUBLE       DBL_MAX
#  endif
#  if !defined (MAXFLOAT)
#    define MAXFLOAT        FLT_MAX
#  endif
#  if !defined (MINDOUBLE)
#    define MINDOUBLE       DBL_MIN
#  endif
#  if !defined (MINFLOAT)
#    define MINFLOAT         FLT_MIN
#  endif
#  define Use_memcpy
#  define Use_ctoftn7
#  ifndef NOSTDCALL
#      undef CALLTYP
#      define CALLTYP __stdcall
#  endif
#endif

#ifndef UNIX

#if defined(RS6000_SYS) || (defined(HP_SYS) && !defined(PROTOIZE_RUN))

/* === C functions called from FORTRAN */
#define fem_mstatupdatef_    fem_mstatupdatef
#define fem_mstatabortf_     fem_mstatabortf
#define fem_heapmax_         fem_heapmax
#define fem_rnoff_           fem_rndoff
#define fem_errorf_          fem_errorf
#define fem_getnodegeo_      fem_getnodegeo
#define fem_ioprintf_        fem_ioprintf
#define fem_trackbeginf_     fem_trackbeginf
#define fem_trackendf_       fem_trackendf
#define fem_verifycmndf_     fem_verifycmndf
#define fem_interactive_     fem_interactive

/* === FORTRAN subroutines/functions/entries called from C */

#define fem_plg_sizemem_     fem_plg_sizemem
#define fem_plg_fasttet_     fem_plg_fasttet
#define fem_plg_fillcoor_    fem_plg_fillcoor
#define fem_plg_fillelem_    fem_plg_fillelem
#define fem_plg_fchk_        fem_plg_fchk
#define sh_comp_all_         sh_comp_all
#define sh_test_all_         sh_test_all

#endif

/* (2)-------------------------------------------------------------*/

#if    defined(WATCOMC_SYS) \
    || defined(PCWINNT_SYS) || defined(WIN32) 
/* === C functions called from FORTRAN */

#define fem_mstatupdatef_    FEM_MSTATUPDATEF
#define fem_mstatabortf_     FEM_MSTATABORTF
#define fem_heapmax_         FEM_HEAPMAX
#define fem_rndoff_          FEM_RNDOFF
#define fem_errorf_          FEM_ERRORF
#define fem_getnodegeo_      FEM_GETNODEGEO
#define fem_ioprintf_        FEM_IOPRINTF
#define fem_trackbeginf_     FEM_TRACKBEGINF
#define fem_trackendf_       FEM_TRACKENDF
#define fem_verifycmndf_     FEM_VERIFYCMNDF
#define fem_interactive_     FEM_INTERACTIVE

/* === FORTRAN subroutines/functions/entries called from C */
#define fem_plg_sizemem_     FEM_PLG_SIZEMEM
#define fem_plg_fasttet_     FEM_PLG_FASTTET
#define fem_plg_fillcoor_    FEM_PLG_FILLCOOR
#define fem_plg_fillelem_    FEM_PLG_FILLELEM
#define fem_plg_fchk_        FEM_PLG_FCHK
#define sh_comp_all_         SH_COMP_ALL
#define sh_test_all_         SH_TEST_ALL
#endif

#else

#if defined(ux11)
#define fem_mstatupdatef_    fem_mstatupdatef
#define fem_mstatabortf_     fem_mstatabortf
#define fem_heapmax_         fem_heapmax
#define fem_rndoff_          fem_rndoff
#define fem_errorf_          fem_errorf
#define fem_getnodegeo_      fem_getnodegeo
#define fem_ioprintf_        fem_ioprintf
#define fem_trackbeginf_     fem_trackbeginf
#define fem_trackendf_       fem_trackendf
#define fem_verifycmndf_     fem_verifycmndf
#define fem_interactive_     fem_interactive

/* === FORTRAN subroutines/functions/entries called from C */
#define fem_plg_sizemem_     fem_plg_sizemem
#define fem_plg_fasttet_     fem_plg_fasttet
#define fem_plg_fillcoor_    fem_plg_fillcoor
#define fem_plg_fillelem_    fem_plg_fillelem
#define fem_plg_fchk_        fem_plg_fchk
#define sh_comp_all_         sh_comp_all
#define sh_test_all_         sh_test_all
#endif /* ux11 */

#endif /* Unix */

/* (3)-------------------------------------------------------------*/
#if defined(WATCOMC_SYS)

/* === C functions called from FORTRAN */

#pragma aux FEM_MSTATUPDATEF "^";
#pragma aux FEM_MSTATABORTF "^";
#pragma aux FEM_HEAPMAX "^";
#pragma aux FEM_RNDOFF "^";
#pragma aux FEM_ERRORF "^";
#pragma aux FEM_GETNODEGEO "^";
#pragma aux FEM_IOPRINTF "^";
#pragma aux FEM_TRACKBEGINF "^";
#pragma aux FEM_TRACKENDF "^";
#pragma aux FEM_VERIFYCMNDF "^";
#pragma aux FEM_INTERACTIVE "^";

/* === FORTRAN subroutines/functions/entries called from C */

#pragma aux FEM_PLG_SIZEMEM "^";
#pragma aux FEM_PLG_FASTTET "^";
#pragma aux FEM_PLG_FILLCOOR "^";
#pragma aux FEM_PLG_FILLELEM "^";
#pragma aux FEM_PLG_FCHK "^";
#pragma aux SH_COMP_ALL "^";
#pragma aux SH_TEST_ALL "^";

#endif

/* (4)-------------------------------------------------------------*/
/*
 * *** FUNCTION RETURN TYPE DECLARATION
 */

#if !defined(PCWINNT_SYS) && !defined(WIN32)

/* === C functions called from FORTRAN */

   void fem_mstatupdatef_();
   void fem_mstatabortf_();
   INT fem_heapmax_();
   INT fem_rndoff_();
   void fem_errorf_();
   INT fem_getnodegeo_();
   void fem_ioprintf_();
   void fem_trackbeginf_();
   void fem_trackendf_();
   void fem_verifycmndf_();
   INT fem_interactive_();

/* === FORTRAN subroutines/functions/entries called from C */

   void fem_plg_sizemem_();
   void fem_plg_fasttet_();
   void fem_plg_fillcoor_();
   void fem_plg_fillelem_();
   void fem_plg_fchk_();
   void sh_comp_all_();
   void sh_test_all_();

/* (5)-------------------------------------------------------------*/
#else

/* === C functions called from FORTRAN */

   void CALLTYP fem_mstatupdatef_( INT *, INT *, INT *, INT * );
   void CALLTYP fem_mstatabortf_( INT * );
   INT CALLTYP fem_heapmax_( void );
   INT CALLTYP fem_rndoff_( DOUBLE *, INT * );
   void CALLTYP fem_errorf_( INT *, INT *, INT *, DOUBLE *, INT *,
                             INT *, INT * );
   INT CALLTYP fem_getnodegeo_( INT *, INT *, INT * );
   void CALLTYP fem_ioprintf_( INT *, INT * );
   void CALLTYP fem_trackbeginf_( INT *, INT * );
   void CALLTYP fem_trackendf_( INT *, INT * );
   void CALLTYP fem_verifycmndf_( INT *, INT *, INT * );
   INT CALLTYP fem_interactive_( void );

/* === FORTRAN subroutines/functions/entries called from C */
   void CALLTYP fem_plg_sizemem_( INT *, DOUBLE *, INT *, INT *, 
                                  INT *, DOUBLE *, INT *, INT *, INT * );
   void CALLTYP fem_plg_fasttet_( INT *, INT *, INT *, INT *, INT *,
                                  DOUBLE *, INT *, INT *, INT *, 
                                  DOUBLE *, DOUBLE *, INT *, INT *,
                                  INT *, INT *, INT *, DOUBLE *,  
                                  INT *, INT *, INT *, DOUBLE *, INT *); 
   void CALLTYP fem_plg_fillcoor_(INT *, INT *, DOUBLE *, INT *, 
                                  DOUBLE *, INT * );
   void CALLTYP fem_plg_fillelem_(INT *, INT *, INT *, INT *, 
                                  DOUBLE *, INT *);
   void CALLTYP fem_plg_fchk_( INT *, INT *, INT *, INT *, DOUBLE *,
                               DOUBLE *, DOUBLE *, INT *,
                               INT *, INT *, INT *, INT *, INT *, INT *, INT *,
                               INT *, INT *, INT *, INT * );
   void CALLTYP sh_comp_all_( INT *, INT *, INT *, INT *, INT *, INT *, 
                              INT *, INT *, INT *, INT *, INT *, INT *, INT *,
                              INT *, INT *, DOUBLE *, INT *, DOUBLE *, 
                              INT *, INT *, INT *, INT *, INT *, INT *, 
                              INT *, INT *, INT *, INT *, INT *,
                              DOUBLE *, DOUBLE *, DOUBLE *, DOUBLE * );
   void CALLTYP sh_test_all_( INT *, INT *, INT *, INT *, INT *, INT *,
                              INT *, INT *, INT *, INT *, INT *,
                              INT *, INT *, INT *, INT *, INT *,
                              INT *, INT *, INT *, INT *, INT *,
                              INT *, INT *, INT *, INT *, DOUBLE *,
                              DOUBLE *, DOUBLE *, DOUBLE *, INT *,
                              INT *, INT *, INT *, INT *, DOUBLE *,
                              INT * );

#endif
