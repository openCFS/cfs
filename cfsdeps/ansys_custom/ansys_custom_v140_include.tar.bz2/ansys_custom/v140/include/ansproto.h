/* ansproto.h                                             MJR,COOP
------------------------------------------------------------------------
------- Notice - This file contains ANSYS Confidential information --------
------------------------------------------------------------------------
*/
/* 
 * *** copyright(c) 2010 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */


/*------------------------------ Description ---------------------------
\Author:	M. J. Ramsay
\Title:		Temporary definition of ansPROTO Macro
\Desc:		This file contains the definintion of the ansPROTO macro.
                It is intended to serve as a temporary patch for the mixed
                state of source code, namely some K&R and some ANSI C, 
                that necessarily exists while legacy source code is being 
                converted to ANSI standard C.

\History:	97/03/10 : mjr - initial creation

\Function(s)
 -Primary:	To supply macro for optional ANSI-C prototyping function 
                ansPROTO
 -Secondary:	none
 -External:	none	
 -Internal:	none
 -Static:	none
----------------------------------------------------------------------*/

/*------------------------------ Dependencies ------------------------*/
/* *** mpg math prototype c header */
#ifndef ansPROTO
/*
 * Check for ANSI-C compiler 
 */
#  if !defined(NO_ansPROTO) && \
     ((defined(__STDC__) && (__STDC__==1)) || defined(__cplusplus) \
      || defined(USE_ansPROTO)) 
#   define ansPROTO(args)	args
#  else
#   define ansPROTO(args) ()
#  endif

#endif




