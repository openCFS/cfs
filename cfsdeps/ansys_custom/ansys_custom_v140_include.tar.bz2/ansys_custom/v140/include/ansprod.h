/*
 * Copyright 2003-2010 ANSYS, Inc.
 * All Rights Reserved
 */
#ifndef __ANSYS_PRODUCT_H__
#define __ANSYS_PRODUCT_H__

/*
// The following #defines are included for use with the old API, are no longer needed,
// and will be dropped at a future date.
*/
#define ANSYS_CHECKOUT        1
#define ANSYS_CHECKIN         2
#define ANSYS_CHECKEXIST      3
#define ANSYS_LICENSEEXIT     4
#define ANSYS_CHECKOUT_NOEXIT 5
#define ANSYS_CHECKOUT_NODUPE 6

#define ANSYS_TEST_FEATURE   0
#define ANSYS_TEST_CHECKOUT  1

#define ANSYS_CAD_CATIA_V4   0
#define ANSYS_CAD_CATIA_V5   1
#define ANSYS_CAD_SOLIDWORKS 2
#define ANSYS_CAD_PROE       3
#define ANSYS_CAD_UG         4
#define ANSYS_CAD_IDEAS      5
#define ANSYS_CAD_SOLIDEDGE  6
#define ANSYS_CAD_PARASOLID  7
#define ANSYS_CAD_SAT        8
#define ANSYS_CAD_ONESPACE   9
#define ANSYS_CAD_AUTOCAD    10
#define ANSYS_CAD_AIACIS     11
/*
// The preceeding #defines are included for use with the old API, are no longer needed,
// and will be dropped at a future date.
*/

/*
// LM_LAST_ERRNO from FLEXnet Publisher v 10.8.5.0
*/
#define ANS_LM_LAST_ERRNO -173

#define ANS_FLEXLM_ERR_BADDATE    ANS_LM_LAST_ERRNO-1    /* Version date passed to license library was older
                                                            than internal version */
#define ANS_FLEXLM_ERR_NOFEAT     ANS_LM_LAST_ERRNO-2    /* Feature Id passed to license library was invalid */
#define ANS_FLEXLM_ERR_BORROW     ANS_LM_LAST_ERRNO-3    /* Borrowed license is already in use on system */
#define ANS_FLEXLM_ERR_TRAPPED    ANS_LM_LAST_ERRNO-4    /* Internal FLEXlm error trapped by license library */
#define ANS_FLEXLM_ERR_LICMSGS    ANS_LM_LAST_ERRNO-5    /* licmsgs.dat file could not be found */
#define ANS_FLEXLM_ERR_DISPATH    ANS_LM_LAST_ERRNO-6    /* ANSYSLMD_LICENSE_FILE not set when disabling default
                                                            license path ANS_FLEXLM_DISABLE_DEFLICPATH */
#define ANS_FLEXLM_ERR_HPC        ANS_LM_LAST_ERRNO-7    /* Internal HPC (limited, academic, etc.) feature
                                                            requested directly */
#define ANS_FLEXLM_ERR_HPCLTD     ANS_LM_LAST_ERRNO-8    /* Requested more HPC licenses than allowed HPC Limited
                                                            license */
#define ANS_FLEXLM_ERR_HPCREDUCED ANS_LM_LAST_ERRNO-9    /* [ANSYS only] Requested HPC licenses were not available,
                                                            reduced number to those available */
#define ANS_FLEXLM_ERR_MEM        ANS_LM_LAST_ERRNO-10   /* Internal licensing structure could not be allocated */
#define ANS_FLEXLM_ERR_NOPATH     ANS_LM_LAST_ERRNO-11   /* No ANSYS FLEXlm license path was found for client */
#define ANS_FLEXLM_ERR_NOAPP      ANS_LM_LAST_ERRNO-12   /* Internal ANSLIC error - App not initialized */

/*
// The following capability #defines should be used to request the capability and allow the Licensing
// Interconnect determine the user's preference or default feature to use for the capability:
//
// <next_ids><general>10206</general><icepak>10510</icepak><polyflow>10607</polyflow><ekm>10413</ekm><3rd_party>10703</3rd_party><acle>12501</acle><cad>15019</cad></next_ids>
//
// ANSYS, etc. Interconnect Capabilities:
*/
#define ANSYSLI_CAP_ANS_WB                      10001    /* ANSYS Workbench Environment */
#define ANSYSLI_CAP_MECH                        10002    /* ANSYS Mechanical (i.e. Simulation) */
#define ANSYSLI_CAP_ANS_SIM                     ANSYSLI_CAP_MECH
#define ANSYSLI_CAP_MECH_STRUCT                 10115    /* ANSYS Mechanical - Structural Analysis */
#define ANSYSLI_CAP_MECH_HARMRESP               10116    /* ANSYS Mechanical - Harmonic Response */
#define ANSYSLI_CAP_MECH_ELECTRIC               10117    /* ANSYS Mechanical - Electric */
#define ANSYSLI_CAP_MECH_MAGNEOSTATIC           10118    /* ANSYS Mechanical - Magneostatic */
#define ANSYSLI_CAP_MECH_RANDVIB                10119    /* ANSYS Mechanical - Random Vibration */
#define ANSYSLI_CAP_MECH_RESPSPEC               10120    /* ANSYS Mechanical - Response Spectrum */
#define ANSYSLI_CAP_MECH_SHAPEOPT               10121    /* ANSYS Mechanical - Shape Optimization */
#define ANSYSLI_CAP_MECH_SS_THERM               10122    /* ANSYS Mechanical - Steady-State Thermal */
#define ANSYSLI_CAP_MECH_THERMELEC              10123    /* ANSYS Mechanical - Thermal-Electric */
#define ANSYSLI_CAP_MECH_TRANSTRUCT             10124    /* ANSYS Mechanical - Transient Structural */
#define ANSYSLI_CAP_MECH_TRANSTHERM             10125    /* ANSYS Mechanical - Transient Thermal */
#define ANSYSLI_CAP_MECH_BATCHCHILD             10172    /* Mechanical APDL - Batch Child (PDS) */
#define ANSYSLI_CAP_MECH_LSDYNA                 10184    /* Mechanical PrepPost - Explicit LS-DYNA */
#define ANSYSLI_CAP_MECH_ADD_FATIGUE            10185    /* ANSYS Mechanical - Fatigue Add-on */
#define ANSYSLI_CAP_EXPLICIT_DYNAMIC            10111    /* Explicit Dynamic (ANSYS) -  AUTODYN FE Solve */
#define ANSYSLI_CAP_ANS_SOLVER                  10003    /* ANSYS Solver */
#define ANSYSLI_CAP_ANS_SOLVER_HPC              10127    /* ANSYS Solver - HPC */
#define ANSYSLI_CAP_DESIGNXPLORER               10128    /* ANSYS DesignXplorer */
#define ANSYSLI_CAP_ANS_FEM                     10069    /* ANSYS Finite Element Modeler (FEM) */
#define ANSYSLI_CAP_ANS_MESH                    10070    /* ANSYS Mesh */
#define ANSYSLI_CAP_MESH_MORPH                  10189    /* ANSYS MeshMorpher */
#define ANSYSLI_CAP_TGRID_GO_CART               10190    /* ANSYS GoCart Meshing */
#define ANSYSLI_CAP_MESH_ADDON                  10191    /* Internal mesh addon capability */
#define ANSYSLI_CAP_ANS_DM                      10018    /* ANSYS DesignModeler */
#define ANSYSLI_CAP_ANS_PM                      10052    /* ANSYS Part Manager - App Id only - Do not checkout */
#define ANSYSLI_CAP_TAS                         10068    /* TAS */
#define ANSYSLI_CAP_ANS_INFO                    10171    /* ANSINFO Utility DLL - App Id only - Do not checkout */
#define ANSYSLI_CAP_ANS_RD_PACK                 10205    /* ANSYS Robust Design Pack */

/*
// Mechanical - RBD Capabilities:
*/
#define ANSYSLI_CAP_MECH_RBD                    10186    /* ANSYS Mechanical - RBD */
#define ANSYSLI_CAP_MECH_MBD                    ANSYSLI_CAP_MECH_RBD
#define ANSYSLI_CAP_MECH_RBD_ADDON              10193    /* ANSYS Mechanical - RBD */
#define ANSYSLI_CAP_MECH_MBD_ADDON              ANSYSLI_CAP_MECH_RBD_ADDON
#define ANSYSLI_CAP_RBD_SOLVER                  10048    /* RBD Standalone Solver */
#define ANSYSLI_CAP_MBD_SOLVER                  ANSYSLI_CAP_RBD_SOLVER
#define ANSYSLI_CAP_RBD_SOLVER_DYNAMIC          10159    /* RBD Standalone Solver - Dynamics Capability */
#define ANSYSLI_CAP_MBD_SOLVER_DYNAMIC          ANSYSLI_CAP_RBD_SOLVER_DYNAMIC
#define ANSYSLI_CAP_RBD_SOLVER_KINEMATIC        10160    /* RBD Standalone Solver - Kinematic Capability */
#define ANSYSLI_CAP_MBD_SOLVER_KINEMATIC        ANSYSLI_CAP_RBD_SOLVER_KINEMATIC
#define ANSYSLI_CAP_RBD_PREP_DYNAMIC            10161    /* RBD Prep - Dynamics Capability */
#define ANSYSLI_CAP_MBD_PREP_DYNAMIC            ANSYSLI_CAP_RBD_PREP_DYNAMIC
#define ANSYSLI_CAP_RBD_PREP_KINEMATIC          10162    /* RBD Prep - Kinematic Capability */
#define ANSYSLI_CAP_MBD_PREP_KINEMATIC          ANSYSLI_CAP_RBD_PREP_KINEMATIC

/*
// Mechanical - CAE Capabilities:
*/
#define ANSYSLI_CAP_MECH_SAMCEF                 10153    /* Mechanical PrepPost - Samcef Static Sturctural */
#define ANSYSLI_CAP_CAE_SAMCEF                  10155    /* ANSYS CAE Interface for SAMCEF */

#define ANSYSLI_CAP_MECH_ABAQUS                 10154    /* Mechanical PrepPost - ABAQUS Static Structural */
#define ANSYSLI_CAP_CAE_ABAQUS                  10156    /* ANSYS CAE Interface for ABAQUS */

#define ANSYSLI_CAP_MECH_NASTRAN                10157    /* Mechanical PrepPost - NASTRAN Static Sturctural */
#define ANSYSLI_CAP_CAE_NASTRAN                 10158    /* ANSYS CAE Interface for NASTRAN */

/*
// ICEM Interconnect Capabilities:
*/
#define ANSYSLI_CAP_ICEM                              10066    /* ICEM CFD Application */
#define ANSYSLI_CAP_ICEM_AM                           10019    /* ICEM CFD Advanced Meshing */
#define ANSYSLI_CAP_ICEM_MED                          10175    /* ICEM CFD - Med */
#define ANSYSLI_CAP_ICEM_HEXAEXT                      10063    /* ICEM CFD Hexa Batch */
#define ANSYSLI_CAP_ICEM_BF_CART                      10064    /* ICEM BF-Cart Meshing */
#define ANSYSLI_CAP_ICEM_BFCART                       ANSYSLI_CAP_ICEM_BF_CART
#define ANSYSLI_CAP_ICEM_HEXCAT5                      10065    /* ICEM CFD Hex CATIA V5 */
#define ANSYSLI_CAP_ICEM_HEXA                         10067    /* ICEM CFD Hexa Mesher */
#define ANSYSLI_CAP_ICEM_GLOBAL                       10129    /* ICEM CFD - Global */
#define ANSYSLI_CAP_ICEM_MSHCRT                       10130    /* ICEM CFD - Mesh CRT */
#define ANSYSLI_CAP_ICEM_AIMSHPRT                     10131    /* ICEM CFD - AIMSHPRT */
#define ANSYSLI_CAP_ICEM_QUAD                         10132    /* ICEM CFD - Quad */
#define ANSYSLI_CAP_ICEM_TETRA                        10133    /* ICEM CFD - Tetra */
#define ANSYSLI_CAP_ICEM_PRISM                        10134    /* ICEM CFD - Prism */
#define ANSYSLI_CAP_ICEM_VIS3                         10135    /* ICEM CFD - Visual3 */
#define ANSYSLI_CAP_ICEM_OUT_ANSYS                    10136    /* ICEM CFD - ANSYS Output */
#define ANSYSLI_CAP_ICEM_OUT_NASTRAN                  10137    /* ICEM CFD - NASTRAN Output */
#define ANSYSLI_CAP_ICEM_NASTRAN                      ANSYSLI_CAP_ICEM_OUT_NASTRAN
#define ANSYSLI_CAP_ICEM_FLOWCRT                      10169    /* ANSYS ICEM CFD Cart3D Flowcart Solver */
#define ANSYSLI_CAP_ICEM_FLOWCRTP                     10170    /* ANSYS ICEM CFD Cart3D Flowcart Parallel */
#define ANSYSLI_CAP_ICEM_PROJ_MOD                     10174    /* ICEM CFD - Projection Module */
#define ANSYSLI_CAP_ICEM_HEXAX                        10176    /* ICEM CFD - HEXAX */
#define ANSYSLI_CAP_ICEM_BATMESH                      10177    /* ICEM CFD - Batch Mesher */
#define ANSYSLI_CAP_ICEM_HEXCORE                      10178    /* ICEM CFD - Hexa Core */
#define ANSYSLI_CAP_ICEM_MZ                           10179    /* ICEM CFD - MultiZone */
#define ANSYSLI_CAP_TOPSIDES                          10180    /* ANSYS TOPSIDES */
#define ANSYSLI_CAP_TOPS_NL                           10181    /* ANSYS TOPSIDES - NL */
#define ANSYSLI_CAP_PLATFORM                          10182    /* ANSYS PLATFORM */
#define ANSYSLI_CAP_PLAT_NL                           10183    /* ANSYS PLATFORM - NL */
#define ANSYSLI_CAP_ICEM_OUT_LSDYNA                   10138    /* ICEM CFD - LS-DYNA Output */
#define ANSYSLI_CAP_ICEM_OUT_ABAQUS                   10139    /* ICEM CFD - ABAQUS Output */
#define ANSYSLI_CAP_ICEM_OUT_PATRAN                   10140    /* ICEM CFD - PATRAN Output */
#define ANSYSLI_CAP_ICEM_OUT_AUTODYN                  10141    /* ICEM CFD - Output for AUTODYN */
#define ANSYSLI_CAP_ICEM_OUT_RADIOSS                  10142    /* ICEM CFD - RADIOSS */
#define ANSYSLI_CAP_ICEM_OUT_EXODUS                   10143    /* ICEM CFD - OUT_EXODUS */
#define ANSYSLI_CAP_ICEM_OUT_IDEAS                    10144    /* ICEM CFD - Output IDEAS */
#define ANSYSLI_CAP_ICEM_OUT_FLUENT                   10145    /* ICEM CFD - Output Interface for Fluent */
#define ANSYSLI_CAP_ICEM_OUT_CFX                      10146    /* ICEM CFD - Translators for CFX */
#define ANSYSLI_CAP_ICEM_OUT_STARCD                   10147    /* ICEM CFD - - STARCD */
#define ANSYSLI_CAP_ICEM_OUT_ACUSOLVE                 10148    /* ICEM CFD - Output Interface ACUSOLVE */
#define ANSYSLI_CAP_ICEM_OUT_CFD                      10149    /* ICEM CFD - Output Interface for CFD */
#define ANSYSLI_CAP_ICEM_OUT_FEA                      10150    /* ICEM CFD - Output Interface for FEA Codes */
#define ANSYSLI_CAP_ICEM_OUT_OTHER                    10151    /* ICEM CFD - Other Translators */
#define ANSYSLI_CAP_ICEM_OUT_IMPORT                   10152    /* ICEM CFD - Other Import */
#define ANSYSLI_CAP_ICEM_ADD_AM                       10188    /* ICEM CFD - Advanced Mesher Addon to ANSYS Solvers */

/*
// CFX Interconnect Capabilities:
*/
#define ANSYSLI_CAP_CFX_PRE                           10004    /* CFX Pre */
#define ANSYSLI_CAP_CFX_PRE_FULL_NOLIMIT              10024    /* CFX Pre - Full nolimit */
#define ANSYSLI_CAP_CFX_PRE_BASIC_NOLIMIT             10025    /* CFX Pre - Basic nolimit */
#define ANSYSLI_CAP_CFX_PRE_EDU                       10026    /* CFX Pre - Education (Viewer Watermark) */
#define ANSYSLI_CAP_CFX_PRE_LIMIT                     10027    /* CFX Pre - Limit (Single Component) */
#define ANSYSLI_CAP_CFX_PRE_NOTURBO_QUICK             10028    /* CFX Pre - NoTurbo Quick (Quick setup) */
#define ANSYSLI_CAP_CFX_PRE_NOTURBO                   10029    /* CFX Pre - NoTurbo */
#define ANSYSLI_CAP_CFX_TG                            10173    /* CFX TurboGrid */
#define ANSYSLI_CAP_CFX_TG_NOLIMIT                    10045    /* CFX TurboGrid - nolimit */
#define ANSYSLI_CAP_CFX_TG_EDU                        10046    /* CFX TurboGrid - Education (Viewer Watermark) */
#define ANSYSLI_CAP_TG_EDU                            ANSYSLI_CAP_CFX_TG_EDU
#define ANSYSLI_CAP_CFX_POST                          10005    /* CFX Post */
#define ANSYSLI_CAP_CFX_POST_NOLIMIT                  10030    /* CFX Post - No Limit */
#define ANSYSLI_CAP_CFX_POST_EDU                      10031    /* CFX Post - Education (Viewer Watermark) */
#define ANSYSLI_CAP_CFX_POST_LIMIT                    10032    /* CFX Post - Limit (Single Component) */
#define ANSYSLI_CAP_CFX_POST_NOTURBO                  10033    /* CFX Post - No Turbo */
#define ANSYSLI_CAP_CFX_SOLVER                        10006    /* CFX Solver */
#define ANSYSLI_CAP_CFX_SOLVER_LEAST_NOLIMIT          10007    /* CFX Solver - Lowest nolimit capability */
#define ANSYSLI_CAP_CFX_SOLVER_BASIC_LIMIT            10008    /* CFX Solver - Limited BCS */
#define ANSYSLI_CAP_CFX_SOLVER_BASIC_NOLIMIT          10009    /* CFX Solver - Unlimited BCS */
#define ANSYSLI_CAP_CFX_SOLVER_BASIC_MP_LIMIT         10010    /* CFX Solver - Limited Multiphysics */
#define ANSYSLI_CAP_CFX_SOLVER_FULL_NOLIMIT           10011    /* CFX Solver - FCS */
#define ANSYSLI_CAP_CFX_SOLVER_FULL_UNIVERSITY_LIMIT  10012    /* CFX Solver - University FCS - node limited, no parallel */
#define ANSYSLI_CAP_CFX_SOLVER_PAR_PROC               10036    /* CFX Solver - HPC */
#define ANSYSLI_CAP_CFX_SOLVER_COMBUSTION             10037    /* CFX Solver - Combustion */
#define ANSYSLI_CAP_CFX_SOLVER_MFR                    10038    /* CFX Solver - MFR */
#define ANSYSLI_CAP_CFX_SOLVER_ADVANCED_TURBULENCE    10039    /* CFX Solver - Advanced Turbulence */
#define ANSYSLI_CAP_CFX_SOLVER_TURBULENCE_TRANSITION  10040    /* CFX Solver - Turbulence Transition */
#define ANSYSLI_CAP_CFX_SOLVER_MULTIFLUID             10041    /* CFX Solver - Multifluid */
#define ANSYSLI_CAP_CFX_SOLVER_NOLIMIT                10042    /* CFX Solver - Nolimit */
#define ANSYSLI_CAP_CFX_SOLVER_PHYSICS_MODULE         10043    /* CFX Solver - Physics Module */
#define ANSYSLI_CAP_CFX_SOLVER_RADIATION              10044    /* CFX Solver - Radiation */
#define ANSYSLI_CAP_CFX_MESH                          10013    /* CFX Mesh */
#define ANSYSLI_CAP_CFX_MESHER_PAR                    10047    /* CFX Mesh - HPC */
#define ANSYSLI_CAP_CFX_BLADE_MODELLER                10071    /* CFX BladeModeler */
#define ANSYSLI_CAP_CFX_BLADE_MODELLER_NOLIMIT        10034    /* CFX BladeModeler - No Limit */
#define ANSYSLI_CAP_CFX_BLADE_MODELLER_EDU            10035    /* CFX BladeModeler - Education (Viewer Watermark) */
#define ANSYSLI_CAP_CFX_RIF                           10060    /* CFX-RIF Flamelet Library Generator */
#define ANSYSLI_CAP_VISTA_TF                          10061    /* ANSYS Vista TF */

/*
// FLUENT Interconnect Capabilities:
*/
#define ANSYSLI_CAP_FLUENT_PREPPOST             10194    /* Fluent PrepPost */
#define ANSYSLI_CAP_CFD_HPC                     10195    /* ANSYS CFD - HPC */
#define ANSYSLI_CAP_FLUENT_PREP                 10014    /* Fluent Prep */
#define ANSYSLI_CAP_FLUENT_POST                 10015    /* Fluent Post */
#define ANSYSLI_CAP_FLUENT_SOLVER               10016    /* Fluent Solver */
#define ANSYSLI_CAP_FLUENT_PARALLEL             10072    /* Fluent Parallel */
#define ANSYSLI_CAP_FLUENT_NOX                  10053    /* Fluent Nox */
#define ANSYSLI_CAP_FLUENT_CFM                  10054    /* Fluent CFM */
#define ANSYSLI_CAP_FLUENT_MHD                  10055    /* Fluent MHD */
#define ANSYSLI_CAP_FLUENT_POPBAL               10056    /* Fluent PopBal */
#define ANSYSLI_CAP_FLUENT_FCELL                10057    /* Fluent FCELL */
#define ANSYSLI_CAP_FLUENT_V2F                  10058    /* Fluent V2F */
#define ANSYSLI_CAP_FLUENT_IB                   10059    /* Fluent IB */
#define ANSYSLI_CAP_POLYFLOW_PARALLEL           10600    /* Polyflow Parallel*/
#define ANSYSLI_CAP_POLYDATA                    10601    /* Polydata */
#define ANSYSLI_CAP_POLYFLOW                    10023    /* Polyflow */
#define ANSYSLI_CAP_FLUENT_FFC                  10062    /* Fluent for CATIA V5 */

/*
// Explicit Interconnect Capabilities:
*/
#define ANSYSLI_CAP_DYNA_SOLVER                 10017    /* LS-DYNA Solver */
#define ANSYSLI_CAP_DYNA_PREPPOST               10113    /* LS-DYNA PrepPost */
#define ANSYSLI_CAP_DYNA_PARALLEL               10187    /* LS-DYNA Parallel */
#define ANSYSLI_CAP_AUTODYN_PREPPOST            10020    /* AUTODYN Explicit PrepPost */
#define ANSYSLI_CAP_AUTODYN_PARALLEL            10021    /* AUTODYN Explicit Parallel */
#define ANSYSLI_CAP_AUTODYN_FULL                10022    /* AUTODYN Explicit Solver */
#define ANSYSLI_CAP_EXPLICIT_DYNAPREP           10112    /* Workbench LS-DYNA Prep */
#define ANSYSLI_CAP_EXPLICIT_FESOLVE            10114    /* AUTODYN FE Solver */

/*
// ASAS/AQWA/FEMGV Capabilities
*/
#define ANSYSLI_CAP_ASAS                        10073   /* ANSYS ASAS - ASAS */
#define ANSYSLI_CAP_LOCO                        10074   /* ANSYS ASAS - LOCO */
#define ANSYSLI_CAP_RESPONSE                    10075   /* ANSYS ASAS - RESPONSE */
#define ANSYSLI_CAP_POST                        10076   /* ANSYS ASAS - POST */
#define ANSYSLI_CAP_WAVE                        10077   /* ANSYS ASAS - WAVE */
#define ANSYSLI_CAP_MASS                        10078   /* ANSYS ASAS - MASS */
#define ANSYSLI_CAP_FATJACK                     10079   /* ANSYS ASAS - FATJACK */
#define ANSYSLI_CAP_BEAMST                      10080   /* ANSYS ASAS - BEAMST */
#define ANSYSLI_CAP_COMPED                      10081   /* ANSYS ASAS - COMPED */
#define ANSYSLI_CAP_XTRACT                      10082   /* ANSYS ASAS - XTRACT */
#define ANSYSLI_CAP_SPLINTER                    10083   /* ANSYS ASAS - SPLINTER */
#define ANSYSLI_CAP_WINDSPEC                    10084   /* ANSYS ASAS - WINDSPEC */
#define ANSYSLI_CAP_MAXMIN                      10085   /* ANSYS ASAS - MAXMIN */
#define ANSYSLI_CAP_ASASNL                      10086   /* ANSYS ASAS - ASASNL */
#define ANSYSLI_CAP_PRENL                       10087   /* ANSYS ASAS - PRENL */
#define ANSYSLI_CAP_POSTNL                      10088   /* ANSYS ASAS - POSTNL */
#define ANSYSLI_CAP_PANEL                       10089   /* ANSYS Panel */
#define ANSYSLI_CAP_CONCRETE                    10090   /* ANSYS Concrete */
#define ANSYSLI_CAP_PREBEAM                     10091   /* ANSYS ASAS - PREBEAM */
#define ANSYSLI_CAP_ASASLINK                    10092   /* ANSYS ASAS - ASASLINK */
#define ANSYSLI_CAP_FGV_ASAS                    10093   /* ANSYS FEMGV - FGV_ASAS */
#define ANSYSLI_CAP_FEMGV                       10094   /* ANSYS FEMGV - FEMGV */
#define ANSYSLI_CAP_ASAS_VIS                    10095   /* ANSYS ASAS - ASAS-VIS */
#define ANSYSLI_CAP_HYDRODIFF                   10126   /* ANSYS AQWAWB - HYDRODIFF */ 
#define ANSYSLI_CAP_AQWALINE                    10096   /* ANSYS AQWA - AQWALINE */
#define ANSYSLI_CAP_AQWADRFT                    10097   /* ANSYS AQWA - AQWADRFT */
#define ANSYSLI_CAP_AQWAFER                     10098   /* ANSYS AQWA - AQWAFER */
#define ANSYSLI_CAP_AQWALBRM                    10099   /* ANSYS AQWA - AQWALBRM */
#define ANSYSLI_CAP_AQWANAUT                    10100   /* ANSYS AQWA - AQWANAUT */
#define ANSYSLI_CAP_AQWAWAVE                    10101   /* ANSYS AQWA - AQWAWAVE */
#define ANSYSLI_CAP_AQWAGS                      10102   /* ANSYS AQWA - AQWAGS */
#define ANSYSLI_CAP_AQWALNCH                    10103   /* ANSYS AQWA Launch */
#define ANSYSLI_CAP_AQWAFLOT                    10104   /* ANSYS AQWA Float */
#define ANSYSLI_CAP_AQWALOAD                    10105   /* ANSYS AQWA Load */
#define ANSYSLI_CAP_CD_DRIFT                    10106   /* ANSYS AQWA - CD-DRIFT */
#define ANSYSLI_CAP_CD_FER                      10107   /* ANSYS AQWA - CD-FER */
#define ANSYSLI_CAP_CD_LIBR                     10108   /* ANSYS AQWA - CD-LIBR */
#define ANSYSLI_CAP_CD_NAUT                     10109   /* ANSYS AQWA - CD-NAUT */
#define ANSYSLI_CAP_CD_AGS                      10110   /* ANSYS AQWA - CD-AGS */

/*
// EKM capability defines:
*/
#define ANSYSLI_CAP_EKM_SERVER                      10400 /* EKM Enterprise Server */
#define ANSYSLI_CAP_EKM_USER                        10401 /* EKM User */
#define ANSYSLI_CAP_EKM_NAMED_USER                  10402 /* EKM Named User */
#define ANSYSLI_CAP_EKM_WG_SERVER                   10403 /* EKM WB Server */
#define ANSYSLI_CAP_EKM_TEST_SERVER                 10404 /* EKM Test Server */
#define ANSYSLI_CAP_EKM_TEST_NAMED_USER             10405 /* EKM Test Named User */
#define ANSYSLI_CAP_EKM_TEST_USER                   10406 /* EKM Test Simultaneous User */
#define ANSYSLI_CAP_EKM_DESKTOP                     10407 /* EKM Desktop */

/*
// EKM Datalink capability defines:
*/
#define ANSYSLI_CAP_EKM_DATALINK_SERVER             10410 /* EKM Datalink Server */
#define ANSYSLI_CAP_EKM_DATALINK_USER               10411 /* EKM Datalink User */
#define ANSYSLI_CAP_EKM_DATALINK_NAMED_USER         10412 /* EKM Datalink Named User */

/*
// ICEPAK capability defines:
*/
#define ANSYSLI_CAP_ICE_PAK                        10500 /* Icepak application */
#define ANSYSLI_CAP_ICE_MESHER                     10501 /* Icepak meshing components (AutoHexa & HDM) */
#define ANSYSLI_CAP_ICE_SOLVER                     10502 /* Fluent solver when called from Icepak */
#define ANSYSLI_CAP_ICE_PARALLEL                   10503 /* Fluent solver in parallel when called from Icepak */
#define ANSYSLI_CAP_ICE_IGES                       10504 /* ICEM feature for converting IGES to tetin during CAD import */
#define ANSYSLI_CAP_ICE_TETRA                      10505 /* ICEM feature to run Tetramesher */
#define ANSYSLI_CAP_ICE_GRB                        10506 /* Artwork Gerber import feature */
#define ANSYSLI_CAP_ICE_OPT                        10507 /* Optimization module feature */
#define ANSYSLI_CAP_ICE_PRO                        10508 /* Icepro feature */
#define ANSYSLI_CAP_ICE_MAX                        10509 /* Icemax feature */
#define ANSYSLI_CAP_ICE_A_PARALLEL                 10510 /* Fluent solver in parallel when called from Academic Icepak */

/*
// Third Party capabilities for using ANSYSLI licensing:
*/
#define ANSYSLI_CAP_SPACECLAIM_CATIA_V5         10699    /* ANSYS SpaceClaim CATIA V5 Interface */
#define ANSYSLI_CAP_SPACECLAIM                  10700    /* ANSYS SpaceClaim Direct Modeler */
#define ANSYSLI_CAP_ANSYS_COMPOSITE_PRE          10701    /* ANSYS Composite Pre (ACP) */
#define ANSYSLI_CAP_ANSYS_COMPOSITE_PP          ANSYSLI_CAP_ANSYS_COMPOSITE_PRE    /* ANSYS Composite Pre (ACP) */
#define ANSYSLI_CAP_ANSYS_COMPOSITE_POST        10702    /* ANSYS Composite Post (ACP) */

#define ANSYSLI_CAP_PRESSURE_VESSEL_DESIGN      10203    /* Pressure Equipment Module - Design */
#define ANSYSLI_CAP_PRESSURE_VESSEL_LOADS       10204    /* Pressure Equipment Module - Loads */

/*
// CAD capability defines:
*/
#define ANSYSLI_CAD_CATIA_V4                    15001    /* CATIA V4 CAD Interface */
#define ANSYSLI_CAD_CATIA_V5                    15002    /* CATIA V5 CAD Interface */
#define ANSYSLI_CAD_SOLIDWORKS                  15003    /* SolidWorks CAD Interface */
#define ANSYSLI_CAD_PROE                        15004    /* ProENGINEER CAD Interface */
#define ANSYSLI_CAD_UG                          15005    /* Unigraphics CAD Interface */
#define ANSYSLI_CAD_IDEAS                       15006    /* SDRC-IDEAS CAD Interface */
#define ANSYSLI_CAD_SOLIDEDGE                   15007    /* SolidEdge CAD Interface */
#define ANSYSLI_CAD_PARASOLID                   15008    /* Parasolid CAD Interface */
#define ANSYSLI_CAD_SAT                         15009    /* SAT CAD Interface */
#define ANSYSLI_CAD_ONESPACE                    15010    /* OneSpace Designer CAD Interface */
#define ANSYSLI_CAD_AUTOCAD                     15011    /* AUTOCAD Interface */
#define ANSYSLI_CAD_AIACIS                      15012    /* AI ACIS CAD Interface */
#define ANSYSLI_CAD_INVENTOR                    15013    /* AUTODESK INVENTOR CAD Interface */
#define ANSYSLI_CAD_ICEM_AIDXF                  15014    /* ICEM CFD - AIDXF */
#define ANSYSLI_CAD_ICEM_AIIGES                 15015    /* ICEM CFD - AIIGES */
#define ANSYSLI_CAD_PDM_IMAN                    15016    /* ANSYS Interface for Team Center Engineering */
#define ANSYSLI_CAP_JT_READER                   15017    /* ANSYS JT Reader */
#define ANSYSLI_CAP_PROE_READER                 15018    /* ANSYS Pro/E Reader */

#define ANSYSLI_CAP_ANS_HPC_GPU                 10196    /* ANSYS HPC GPU */

/*
// Internal Use Capabilities:
//
//    NOTE:  These capabilities are for internal use only and should not be requested directly.
*/
#define ANSYSLI_CAP_FLUENT_A_PARALLEL           10163    /* Fluent Academic Parallel */
#define ANSYSLI_CAP_FLUENT_A_FCELL              10164    /* Fluent Academic FCELL */
#define ANSYSLI_CAP_AUTODYN_A_PARALLEL          10165    /* AUTODYN Explicit Academic Parallel */
#define ANSYSLI_CAP_CFX_A_SOLVER_PAR_PROC       10166    /* CFX Academic Solver - HPC */
#define ANSYSLI_CAP_ANS_A_SOLVER_HPC            10167    /* ANSYS Academic Solver - HPC */
#define ANSYSLI_CAP_DYNA_A_PARALLEL             10197    /* LS-DYNA Academic Parallel */
#define ANSYSLI_CAP_TGRID                       10198    /* ANSYS TGrid */
#define ANSYSLI_CAP_FLUID_DYNAMICS_1            10199    /* ANSYS Fluid Dynamics 1 */
#define ANSYSLI_CAP_FLUID_DYNAMICS_2            10200    /* ANSYS Fluid Dynamics 2 */
#define ANSYSLI_CAP_FLUID_DYNAMICS_3            10201    /* ANSYS Fluid Dynamics 3 */
#define ANSYSLI_CAP_TGRID_BATCH                 10202    /* ANSYS TGrid Batch */
#define ANSYSLI_CAP_SHARE_LOCKER                10168    /* Internal share locking capability */
#define ANSYSLI_CAP_POLYFLOW_A_PARALLEL         10602    /* Polyflow Academic - HPC */
#define ANSYSLI_CAP_POLYDATA_EXTRUSION          10603    /* Polydata Extrusion */
#define ANSYSLI_CAP_POLYDATA_BLOWMOLDING        10604    /* Polydata BlowMolding */
#define ANSYSLI_CAP_POLYFLOW_BLOWMOLDING        10605    /* Polyflow BlowMolding */
#define ANSYSLI_CAP_POLYFLOW_EXTRUSION          10606    /* Polyflow Extrusion */

/*
// ACLE defines:
*/
#define ANSYSLI_ACLE                            12500    /* Standard ACLE checkout */

/*
// The following #defines should be used to directly access specific license features:
*/
#define ANSYS_ANSYS_CODE                             0 /* ANSYS Mechanical */
#define ANSYS_EMAG_CODE                              4 /* ANSYS Emag */
#define ANSYS_FLOTRAN_CODE                           6 /* ANSYS FLOTRAN */
#define ANSYS_PREPPOST_CODE                          7 /* ANSYS PrepPost */
#define ANSYS_ANSYSUH_CODE                           8 /* ANSYS University Intermediate */
#define ANSYS_ANSYSRF_CODE                           9 /* ANSYS University Advanced */
#define ANSYS_PRF_CODE                              11 /* ANSYS Professional NLT */
#define ANSYS_PRFE3_CODE                            12 /* ANSYS Professional/Emag */
#define ANSYS_PRFFL_CODE                            13 /* ANSYS Professional/FLOTRAN */
#define ANSYS_PRFE3FL_CODE                          14 /* ANSYS Professional/Emag/FLOTRAN */
#define ANSYS_ANPR7_CODE                            15 /* ANSYS Prep7 */
#define ANSYS_ANSOL_CODE                            16 /* ANSYS Solve */
#define ANSYS_ANPST1_CODE                           17 /* ANSYS Post1 */
#define ANSYS_ANPST26_CODE                          18 /* ANSYS Post26 */
#define ANSYS_ANAUX12_CODE                          19 /* ANSYS Aux12 */
#define ANSYS_ANAUX15_CODE                          20 /* ANSYS Aux15 */
#define ANSYS_DYNA_CODE                             22 /* ANSYS LS-DYNA */
#define ANSYS_DYNAPP_CODE                           23 /* ANSYS LS-DYNA PrepPost */
#define ANSYS_STRUCT_CODE                           24 /* ANSYS Structural */
#define ANSYS_EMAGFL_CODE                           34 /* ANSYS Emag/FLOTRAN */
#define ANSYS_ANE3FL_CODE                           35 /* ANSYS Multiphysics */
#define ANSYS_ANE3_CODE                             36 /* ANSYS Mechanical/Emag */
#define ANSYS_ANFL_CODE                             37 /* ANSYS Mechanical/FLOTRAN */
#define ANSYS_ANE3FLDS_CODE                         38 /* ANSYS Multiphysics/LS-DYNA */
#define ANSYS_ANSYSDS_CODE                          39 /* ANSYS Mechanical/LS-DYNA */
#define ANSYS_ANE3DS_CODE                           40 /* ANSYS Mechanical/Emag/LS-DYNA */
#define ANSYS_ANFLDS_CODE                           41 /* ANSYS Mechanical/FLOTRAN/LS-DYNA */
#define ANSYS_ANE3FLDP_CODE                         42 /* ANSYS Multiphysics/LS-DYNA PrepPost */
#define ANSYS_ANSYSDP_CODE                          43 /* ANSYS Mechanical/LS-DYNA PrepPost */
#define ANSYS_ANE3DP_CODE                           44 /* ANSYS Mechanical/Emag/LS-DYNA PrepPost */
#define ANSYS_ANFLDP_CODE                           45 /* ANSYS Mechanical/FLOTRAN/LS-DYNA PrepPost */
#define ANSYS_STE3_CODE                             46 /* ANSYS Structural/Emag */
#define ANSYS_STFL_CODE                             47 /* ANSYS Structural/FLOTRAN */
#define ANSYS_STE3FL_CODE                           48 /* ANSYS Structural/Emag/FLOTRAN */
#define ANSYS_STRUCTDS_CODE                         49 /* ANSYS Structural/LS-DYNA */
#define ANSYS_STE3DS_CODE                           50 /* ANSYS Structural/Emag/LS-DYNA */
#define ANSYS_STFLDS_CODE                           51 /* ANSYS Structural/FLOTRAN/LS-DYNA */
#define ANSYS_STE3FLDS_CODE                         52 /* ANSYS Structural/Emag/FLOTRAN/LS-DYNA */
#define ANSYS_STRUCTDP_CODE                         53 /* ANSYS Structural/LS-DYNA PrepPost */
#define ANSYS_STE3DP_CODE                           54 /* ANSYS Structural/Emag/LS-DYNA PrepPost */
#define ANSYS_STFLDP_CODE                           55 /* ANSYS Structural/FLOTRAN/LS-DYNA PrepPost */
#define ANSYS_STE3FLDP_CODE                         56 /* ANSYS Structural/Emag/FLOTRAN/LS-DYNA PrepPost */
#define ANSYS_ANSYSED_CODE                          58 /* ANSYS Multiphysics ED Option */
#define ANSYS_ANSYSUL_CODE                          70 /* ANSYS University Introductory */
#define ANSYS_PRPOSTDY_CODE                         71 /* ANSYS PrepPost/LS-DYNA PrepPost */
#define ANSYS_CFSTRED_CODE                          72 /* CivilFEM with ANSYS Structural ED */
#define ANSYS_STRUCT2_CODE                          73 /* ANSYS Structural 2 */
#define ANSYS_STRUCT3_CODE                          74 /* ANSYS Structural 3 */
#define ANSYS_ANE3FL1_CODE                          75 /* ANSYS Multiphysics 1 */
#define ANSYS_ANE3FL2_CODE                          76 /* ANSYS Multiphysics 2 */
#define ANSYS_ANE3FL3_CODE                          77 /* ANSYS Multiphysics 3 */
#define ANSYS_DYNAPC_CODE                           78 /* ANSYS LS-DYNA PC */
#define ANSYS_LSMAT161_CODE                         79 /* LS-DYNA MAT_161 */
#define ANSYS_LSMAT162_CODE                         80 /* LS-DYNA MAT_162 */
#define ANSYS_APEI_CODE                             81 /* ANSYS Pro/ENGINEER Interface (APEI) */
#define ANSYS_CONPROE_CODE                          82 /* ANSYS Connection for Pro/ENGINEER */
#define ANSYS_CONUG_CODE                            86 /* ANSYS Connection for Unigraphics */
#define ANSYS_CONSAT_CODE                           91 /* ANSYS Connection for SAT */
#define ANSYS_STRUCT1_CODE                          92 /* ANSYS Structural 1 */
#define ANSYS_CONPARA_CODE                          94 /* ANSYS Connection for Parasolid */
#define ANSYS_CONCATIA_CODE                         97 /* ANSYS Connection for CATIA V4 */
#define ANSYS_CONCIF_CODE                           99 /* ANSYS Connection for CIF */
#define ANSYS_FPPP_CODE                            103 /* Flexpac with ANSYS PrepPost */
#define ANSYS_CFSTRU_CODE                          104 /* CivilFEM with ANSYS Structural */
#define ANSYS_CFSTR1_CODE                          105 /* CivilFEM with ANSYS Structural 1 */
#define ANSYS_CFSTR2_CODE                          114 /* CivilFEM with ANSYS Structural 2 */
#define ANSYS_ANCFX_CODE                           116 /* ANSYS Mechanical/CFX-Flo */
#define ANSYS_STCFX_CODE                           117 /* ANSYS Structural/CFX-Flo */
#define ANSYS_PRFNLS_CODE                          118 /* ANSYS Professional NLS */
#define ANSYS_CFSTRH_CODE                          119 /* CivilFEM with ANSYS Structural High */
#define ANSYS_DYSMP_CODE                           122 /* ANSYS LS-DYNA Parallel */
#define ANSYS_DYDTM_CODE                           124 /* ANSYS LS-DYNA Drop Test Module */
#define ANSYS_PERFPAR_CODE                         125 /* Parallel Performance for ANSYS */
#define ANSYS_ANSTOKEN_CODE                        126 /* ANSYS Token */
#define ANSYS_AUNIVRES_CODE                        134 /* ANSYS University Research */
#define ANSYS_MPBA_CODE                            141 /* ANSYS Multiphysics Batch */
#define ANSYS_MEBA_CODE                            142 /* ANSYS Mechanical Batch */
#define ANSYS_PRBA_CODE                            143 /* ANSYS Professional Batch */
#define ANSYS_STBA_CODE                            144 /* ANSYS Structural Batch */
#define ANSYS_DEBA_CODE                            145 /* ANSYS DesignSpace Batch */
#define ANSYS_FLBA_CODE                            146 /* ANSYS FLOTRAN Batch */
#define ANSYS_E3BA_CODE                            147 /* ANSYS Emag Batch */
#define ANSYS_ANS_RDPACK_CODE                      148 /* ANSYS Robust Design Pack */
#define ANSYS_AA_R_PF_CODE                         150 /* ANSYS Academic Research POLYFLOW */
#define ANSYS_MPBACH_CODE                          151 /* ANSYS Multiphysics Batch Child */
#define ANSYS_MEBACH_CODE                          152 /* ANSYS Mechanical Batch Child */
#define ANSYS_PRBACH_CODE                          153 /* ANSYS Professional Batch Child */
#define ANSYS_STBACH_CODE                          154 /* ANSYS Structural Batch Child */
#define ANSYS_DEBACH_CODE                          155 /* ANSYS DesignSpace Batch Child */
#define ANSYS_FLBACH_CODE                          156 /* ANSYS FLOTRAN Batch Child */
#define ANSYS_E3BACH_CODE                          157 /* ANSYS Emag Batch Child */
#define ANSYS_TEBACH_CODE                          158 /* Test Batch Child */
#define ANSYS_EMAGHF_CODE                          159 /* ANSYS Emag HF */
#define ANSYS_ACFD_CODE                            160 /* ANSYS CFD */
#define ANSYS_ACFD_SOLVER_CODE                     161 /* ANSYS CFD Solver */
#define ANSYS_ACFD_SERVER_CODE                     ANSYS_ACFD_SOLVER_CODE
#define ANSYS_ACFD_PREPPOST_CODE                   162 /* ANSYS CFD PrepPost */
#define ANSYS_ACFD_CLIENT_CODE                     ANSYS_ACFD_PREPPOST_CODE
#define ANSYS_ACFD_PAR_PROC_CODE                   163 /* ANSYS CFD HPC */
#define ANSYS_ACFD_FW_CODE                         164 /* ANSYS FloWizard */
#define ANSYS_ACFD_FW_CLIENT_CODE                  165 /* ANSYS FloWizard Client Only */
#define ANSYS_ACFD_POLYFLOW_CODE                   166 /* ANSYS POLYFLOW */
#define ANSYS_ACFD_POLYFLOW_SOLVER_CODE            167 /* ANSYS POLYFLOW Solver*/
#define ANSYS_ACFD_POLYFLOW_EXTRUSION_CODE         378 /* ANSYS POLYFLOW Extrusion */
#define ANSYS_ACFD_POLYFLOW_BLOWMOLDING_CODE       379 /* ANSYS POLYFLOW BlowMolding */
#define ANSYS_ACFD_POLYFLOW_LITE_CODE              167 /* ANSYS POLYFLOW Lite */
#define ANSYS_AA_R_HPC_CODE                        168 /* ANSYS Academic Research HPC */
#define ANSYS_AA_R_OM_CODE                         169 /* ANSYS Academic Research Offshore/Marine */
#define ANSYS_AA_R_ET_CODE                         170 /* ANSYS Academic Research Electronics Thermal */
#define ANSYS_AA_R_ME_CODE                         171 /* ANSYS Academic Research Mechanical */
#define ANSYS_AA_A_CFD_CODE                        172 /* ANSYS Academic Associate CFD */
#define ANSYS_FREQSW_CODE                          173 /* ANSYS Frequency Sweep VT */
#define ANSYS_FEMXSTR_CODE                         174 /* ANSYS DesignXplorer VT */
#define ANSYS_AA_A_CODE                            175 /* ANSYS Academic Associate */
#define ANSYS_AA_MCAD_CODE                         176 /* ANSYS Academic MCAD */
#define ANSYS_AA_R_CODE                            178 /* ANSYS Academic Research */
#define ANSYS_AA_R_CFD_CODE                        179 /* ANSYS Academic Research CFD */
#define ANSYS_AA_R_DY_CODE                         180 /* ANSYS Academic Research LS-DYNA */
#define ANSYS_AA_R_HT_CODE                         181 /* ANSYS Academic Research Electronics Thermal */
#define ANSYS_AA_ECAD_CODE                         182 /* ANSYS Academic ECAD */
#define ANSYS_AA_T_I_CODE                          183 /* ANSYS Academic Teaching Introductory */
#define ANSYS_AA_DS_CODE                           184 /* ANSYS Academic Teaching DesignSpace */
#define ANSYS_AA_T_A_CODE                          185 /* ANSYS Academic Teaching Advanced */
#define ANSYS_AA_T_ME_CODE                         186 /* ANSYS Academic Teaching Mechanical */
#define ANSYS_AA_T_CFD_CODE                        187 /* ANSYS Academic Teaching CFD */
#define ANSYS_AA_MESH_CODE                         189 /* ANSYS Academic Meshing Tools */
#define ANSYS_AA_TURBO_CODE                        190 /* ANSYS Academic CFD Turbo Tools */
#define ANSYS_AA_DY_P_CODE                         191 /* ANSYS Academic LS-DYNA Parallel */
#define ANSYS_AA_P_ME_CODE                         192 /* ANSYS Academic Mechanical HPC */
#define ANSYS_AA_P_C_CODE                          193 /* ANSYS Academic CFD HPC */
#define ANSYS_AA_R_AD_CODE                         196 /* ANSYS Academic Research AUTODYN */
#define ANSYS_AA_P_AD_CODE                         197 /* ANSYS Academic AUTODYN HPC */
#define ANSYS_DSTEST_CODE                          199 /* DesignSpace Test */
#define ANSYS_AA_A_HPC_CODE                        203 /* ANSYS Academic Associate HPC */
#define ANSYS_DFATIGUE_CODE                        204 /* Fatigue Module */
#define ANSYS_AA_FCELL_CODE                        205 /* ANSYS Academic Fuel Cell Tools */
#define ANSYS_CAETMPL_CODE                         207 /* CAE Templates */
#define ANSYS_AGPPI_CODE                           208 /* ANSYS DesignModeler */
#define ANSYS_AA_R_AQL_CODE                        209 /* ANSYS ACADEMIC AQWA - AQWALINE */
#define ANSYS_1SPACDES_CODE                        210 /* Geometry Interface for OneSpace Designer */
#define ANSYS_PIPROE_CODE                          211 /* Geometry Interface for Pro/ENGINEER */
#define ANSYS_PISOLEDG_CODE                        212 /* Geometry Interface for SolidEdge */
#define ANSYS_PIUG_CODE                            213 /* Geometry Interface for Unigraphics */
#define ANSYS_RDACIS_CODE                          214 /* Geometry Interface for SAT */
#define ANSYS_RDPARA_CODE                          215 /* Geometry Interface for Parasolid */
#define ANSYS_PISOLWOR_CODE                        216 /* Geometry Interface for SolidWorks */
#define ANSYS_PIMEDESK_CODE                        217 /* Geometry Interface for Mechanical Desktop */
#define ANSYS_PIAUTOIN_CODE                        218 /* Geometry Interface for Autodesk Inventor */
#define ANSYS_PICATIA_CODE                         219 /* Geometry Interface for CATIA V4 */
#define ANSYS_DSPI_CODE                            222 /* DesignSpace PlugIn */
#define ANSYS_CAEWBPL1_CODE                        223 /* ANSYS DesignSpace Entra */
#define ANSYS_CAEWBPL2_CODE                        224 /* ANSYS DesignSpace Advansia */
#define ANSYS_CAEWBPL3_CODE                        225 /* ANSYS DesignSpace */
#define ANSYS_CAEWBPLH_CODE                        226 /* ANSYS Workbench Platform L High */
#define ANSYS_CUSTGATE_CODE                        227 /* Customization Gateway */
#define ANSYS_COLLENG_CODE                         228 /* Collaboration Engine */
#define ANSYS_PDMIMAN_CODE                         229 /* ANSYS Interface for Team Center Engineering */
#define ANSYS_WBUNIX_CODE                          230 /* Workbench Interface for UNIX */
#define ANSYS_CONCATV5_CODE                        231 /* ANSYS Connection for CATIA V5 */
#define ANSYS_PICATV5_CODE                         233 /* Geometry Interface for CATIA V5 */
#define ANSYS_DSSTRUCT_CODE                        234 /* ANSYS DesignSpace Structural */
#define ANSYS_CAPRICATV5_CODE                      235 /* CADNexus/CAPRI CAE Gateway for CATIA V5 */
#define ANSYS_CAE4ABAQUS_CODE                      236 /* ANSYS CAE Interface for ABAQUS */
#define ANSYS_CAE4SAMCEF_CODE                      237 /* ANSYS CAE Interface for SAMCEF */
#define ANSYS_CAE4NASTRAN_CODE                     238 /* ANSYS CAE Interface for NASTRAN */
#define ANSYS_AIENVSUB_CODE                        239 /* ANSYS AI*Environment sub features */
#define ANSYS_AIENV_CODE                           241 /* ANSYS AI*Environment */
#define ANSYS_AIPICAT_CODE                         244 /* ANSYS ICEM CFD CATIA V4 Direct Interface */
#define ANSYS_AIPISW_CODE                          245 /* ANSYS ICEM CFD SolidWorks Direct Interface */
#define ANSYS_AIPIPRO_CODE                         246 /* ANSYS ICEM CFD Pro/Engineer Direct Interface */
#define ANSYS_AIPIUG_CODE                          247 /* ANSYS ICEM CFD Unigraphics Direct Interface */
#define ANSYS_AIPIIDEA_CODE                        248 /* ANSYS ICEM CFD SDRC-IDEAS Direct Interface */
#define ANSYS_AIPISE_CODE                          249 /* ANSYS ICEM CFD SolidEdge Direct Interface */
#define ANSYS_DXSTR_CODE                           250 /* DesignXplorer Structural Series Xpansion Module */
#define ANSYS_AIPIPS_CODE                          251 /* ANSYS ICEM CFD Reader for Parasolid */
#define ANSYS_DSDXM_CODE                           254 /* ANSYS DesignXplorer */
#define ANSYS_BATMESH_CODE                         257 /* ANSYS Batch Meshing Module */
#define ANSYS_BMESHSUB_CODE                        258 /* ANSYS Batch Meshing Module sub features */
#define ANSYS_AMESH_TGRID_CODE                     259 /* ANSYS TGrid */
#define ANSYS_KINEMAT_CODE                         260 /* ANSYS Kinematics */
#define ANSYS_INT4NAS_CODE                         261 /* Interface for Nastran */
#define ANSYS_AMESH_EXTENDED_CODE                  263 /* ANSYS Extended Meshing */
#define ANSYS_DYNAMICS_CODE                        264 /* ANSYS Dynamics */
#define ANSYS_WBFRAME_CODE                         265 /* ANSYS Workbench Framework */
#define ANSYS_PREQMO_CODE                          266 /* Pressure Equipment Module */
#define ANSYS_AMESH_CODE                           267 /* ANSYS Mesh */
#define ANSYS_AI_MESH_CODE                         ANSYS_AMESH_CODE /* ANSYS Mesh */
#define ANSYS_AI_ADV_MESH_CODE                     268 /* ANSYS Advanced Mesh */
#define ANSYS_AI_GATEWAY_CODE                      269 /* ANSYS Solver Gateway */
#define ANSYS_AIACIS_CODE                          271 /* ANSYS ICEM CFD ACIS to Tetin Converter */
#define ANSYS_AIAUTMDL_CODE                        272 /* ANSYS ICEM CFD Autohex Modeler */
#define ANSYS_AIAUTMSH_CODE                        273 /* ANSYS ICEM CFD Autohex Mesher */
#define ANSYS_AIDXF_CODE                           274 /* ANSYS ICEM CFD DXF to Tetin Converter */
#define ANSYS_AIGLOBAL_CODE                        275 /* ANSYS ICEM CFD Global Cartesian Mesher */
#define ANSYS_AIHEXA_CODE                          276 /* ANSYS ICEM CFD Hexa Add-on */
#define ANSYS_AIIGES_CODE                          277 /* ANSYS ICEM CFD IGES to Tetin Converter */
#define ANSYS_AIMED_CODE                           278 /* ANSYS ICEM CFD Mesh Editor */
#define ANSYS_AIOPTMSH_CODE                        279 /* ANSYS ICEM CFD Optimesh Mesh Optimizer */
#define ANSYS_AIOUTPUT_CODE                        280 /* ANSYS ICEM CFD Output Interfaces */
#define ANSYS_AIOUTANS_CODE                        281 /* ANSYS ICEM CFD to ANSYS Translator */
#define ANSYS_AIPRISM_CODE                         282 /* ANSYS ICEM CFD Prism Mesher */
#define ANSYS_AIQUAD_CODE                          283 /* ANSYS ICEM CFD Quad Mesher */
#define ANSYS_AITETRA_CODE                         284 /* ANSYS ICEM CFD Tetra Mesher */
#define ANSYS_AIVIS3_CODE                          285 /* ANSYS ICEM CFD Visual3 Visualizer */
#define ANSYS_AIOPTMPI_CODE                        286 /* ANSYS ICEM CFD Optimesh MPI version */
#define ANSYS_AIBFCART_CODE                        287 /* ANSYS ICEM CFD BF-Cart */
#define ANSYS_AI_PROJ_MOD_CODE                     288 /* ANSYS ICEM CFD Projection Module */
#define ANSYS_AIADDON_CODE                         289 /* ANSYS ICEM CFD AddOn */
#define ANSYS_ADVMESH_CODE                         301 /* ANSYS Advanced Structural Meshing Module */
#define ANSYS_PARAMESH_CODE                        302 /* ANSYS MeshMorpher */
#define ANSYS_CAD2MESH_CODE                        303 /* ANSYS CFX-Mesh */
#define ANSYS_PMESHUNI_CODE                        304 /* ANSYS MeshMorpher University */
#define ANSYS_ACFD_V2F_CODE                        305 /* V2f Module */
#define ANSYS_VTHI_CODE                            306 /* VT HI */
#define ANSYS_ACFD_FCELL_CODE                      307 /* Fuel Cell Module */
#define ANSYS_ACFD_IB_CODE                         308 /* Immersed Boundary Module */
#define ANSYS_ACFD_VISTA_TF_CODE                   309 /* ANSYS Vista TF */
#define ANSYS_ACFX2_SOLVER_CODE                    310 /* ANSYS CFX-Flo Solver */
#define ANSYS_ACFX1_SOLVER_CODE                    311 /* ANSYS CFX-Pro Solver */
#define ANSYS_ACFX2_CODE                           312 /* ANSYS CFX-Flo */
#define ANSYS_ACFD_FLO_CODE                        312 /* ANSYS CFD-Flo */
#define ANSYS_ACFD_CFX_CODE                        313 /* ANSYS CFX */
#define ANSYS_ACFX1_CODE                           313 /* ANSYS CFX-FloPro */
#define ANSYS_ACFX_TURBOPP_CODE                    314 /* ANSYS CFX-TurboPrepPost */
#define ANSYS_ACFX2_TURBO_CODE                     315 /* ANSYS CFX-TurboFlo */
#define ANSYS_ACFX1_TURBO_CODE                     316 /* ANSYS CFX-TurboPro */
#define ANSYS_ACFX3_CODE                           317 /* ANSYS CFX-EasyFlo */
#define ANSYS_ACFX_PREPPOST_CODE                   318 /* ANSYS CFX PrepPost */
#define ANSYS_ACFD_FFC_CATIA_CODE                  319 /* FLUENT for CATIA V5 */
#define ANSYS_ACFD_FFC_CATIA_CLIENT_CODE           320 /* FLUENT for CATIA V5 Client Only */
#define ANSYS_PMESHCFD_CODE                        321 /* ANSYS MeshMorpher CFD Add-on */
#define ANSYS_PMESHGEO_CODE                        322 /* ANSYS MeshMorpher Target Geometry Module */
#define ANSYS_AIOUTCFX_CODE                        323 /* ANSYS ICEM CFD Translators for CFX */
#define ANSYS_AIOUTFEA_CODE                        324 /* ANSYS ICEM CFD Translators for FEA Codes */
#define ANSYS_AIOUTCFD_CODE                        325 /* ANSYS ICEM CFD Translators for CFD Codes */
#define ANSYS_AIIC3M_CODE                          326 /* ANSYS ICEM CFD IC3M In-cylinder Flow Product */
#define ANSYS_AIIC3MSB_CODE                        327 /* ANSYS ICEM CFD Subprocess for IC3M */
#define ANSYS_AIHEXCT5_CODE                        328 /* ANSYS ICEM CFD Catia5 Hexa Mesher */
#define ANSYS_AITETCT5_CODE                        329 /* ANSYS ICEM CFD Catia5 Tetra Mesher */
#define ANSYS_AIGWCAT5_CODE                        330 /* ANSYS ICEM CFD Catia5 Mesh/Geometry Translators */
#define ANSYS_AICABIN_CODE                         331 /* ANSYS ICEM CFD Cabin Modeler */
#define ANSYS_AIMSHPRT_CODE                        332 /* ANSYS ICEM CFD Mesh Prototyper */
#define ANSYS_ACFX_FLOTRAN_UPGRADE_CODE            333 /* ANSYS CFX FLOTRAN Upgrade */
#define ANSYS_ACFX_PRE_CODE                        334 /* ANSYS CFX-5 Pre */
#define ANSYS_ACFX_SOLVER_CODE                     335 /* ANSYS CFX-5 Solver */
#define ANSYS_ACFX_NOLIMIT_CODE                    336 /* ANSYS CFX-5 Nolimit */
#define ANSYS_ACFX_PARALLEL_CODE                   337 /* ANSYS CFX-5 Parallel */
#define ANSYS_ACFX_MFR_CODE                        338 /* ANSYS CFX-5 Multiple Frames of Reference */
#define ANSYS_ACFX_MULTIPHASE_CODE                 339 /* ANSYS CFX-5 Multi-Phase Flows */
#define ANSYS_ACFX_COMBUSTION_CODE                 340 /* ANSYS CFX-5 Reacting and Combusting Species */
#define ANSYS_ACFX_RADIATION_CODE                  341 /* ANSYS CFX-5 Radiation Models */
#define ANSYS_ACFX_PAR_PROC_CODE                   342 /* ANSYS CFX Parallel Computing */
#define ANSYS_ACFX_POST_CODE                       343 /* ANSYS CFX-Post */
#define ANSYS_ACFX_ADV_PHYSICS_CODE                344 /* ANSYS CFX Solver Physics Module */
#define ANSYS_ACFD_FLUENT_CODE                     345 /* ANSYS FLUENT */
#define ANSYS_ACFD_FLUENT_SOLVER_CODE              346 /* ANSYS FLUENT Solver */
#define ANSYS_ACFD_CFX_SOLVER_CODE                 347 /* ANSYS CFX Solver */
#define ANSYS_ACFX_TURBOGRID_CODE                  348 /* ANSYS CFX-TurboGrid */
#define ANSYS_ACFD_RIF_CODE                        349 /* CFX-RIF Flamelet Library Generator */
#define ANSYS_ACFX_ANYMODULE_CODE                  350 /* ANSYS CFX-5 Anymodule */
#define ANSYS_AIEDMESH_CODE                        351 /* ANSYS ICEM CFD Mesh Editing Features in Med */
#define ANSYS_AIEDGEOM_CODE                        352 /* ANSYS ICEM CFD Geometry Editing Features in Med */
#define ANSYS_AIEDPROP_CODE                        353 /* ANSYS ICEM CFD Property Editing Features in Med */
#define ANSYS_AIOUTNAS_CODE                        354 /* ANSYS ICEM CFD Output Interface for Nastran */
#define ANSYS_AIOUTPAT_CODE                        355 /* ANSYS ICEM CFD Output Interface for Patran */
#define ANSYS_AIOUTABA_CODE                        356 /* ANSYS ICEM CFD Output Interface for Abaqus */
#define ANSYS_AIOUTDYN_CODE                        357 /* ANSYS ICEM CFD Output Interface for LS-DYNA */
#define ANSYS_AIOUTADN_CODE                        358 /* ANSYS ICEM CFD Output Interface for Autodyn */
#define ANSYS_AIOUTFLU_CODE                        359 /* ANSYS ICEM CFD Output Interface for Fluent */
#define ANSYS_AIOUTSTR_CODE                        360 /* ANSYS ICEM CFD Output Interface for Starcd */
#define ANSYS_AIOUTRSS_CODE                        361 /* ANSYS ICEM CFD Output Interface for Radioss */
#define ANSYS_AIOUTEXO_CODE                        362 /* ANSYS ICEM CFD Output Interface for Exodus */
#define ANSYS_AIOUTIDE_CODE                        363 /* ANSYS ICEM CFD Output Interface for I-DEAS */
#define ANSYS_ACFX_ADVANCED_TURBULENCE_CODE        364 /* ANSYS CFX-5 Advanced Turbulence */
#define ANSYS_ACFX_TURBULENCE_TRANSITION_CODE      365 /* ANSYS CFX-5 Turbulence Transition */
#define ANSYS_AIGUI_CODE                           366 /* ANSYS ICEM CFD GUI in Med */
#define ANSYS_AIFEAMSH_CODE                        367 /* ANSYS ICEM CFD FEA Meshing Features in Med */
#define ANSYS_AIFSI_CODE                           368 /* ANSYS ICEM CFD FSI Module for AI*Environment */
#define ANSYS_AIHEXCTE_CODE                        369 /* ANSYS ICEM CFD CATIA5 Hexa External process */
#define ANSYS_AIMSHCRT_CODE                        370 /* ANSYS ICEM CFD Cart3D Mesher */
#define ANSYS_AIFLOWCRT_CODE                       371 /* ANSYS ICEM CFD Cart3D Flowcart Solver */
#define ANSYS_AIFLOWCRTP_CODE                      372 /* ANSYS ICEM CFD Cart3D Flowcart Multiprocessor */
#define ANSYS_AIHEXCT5E_CODE                       373 /* ANSYS ICEM CFD Hexa CAA V5 Based Subfeature */
#define ANSYS_AICOMAK_CODE                         374 /* ANSYS ICEM CFD Comak */
#define ANSYS_AICFD_CODE                           375 /* ANSYS ICEM CFD Bundled Version */
#define ANSYS_AICFDSUB_CODE                        376 /* ANSYS ICEM CFD Bundled Version Subfeature */
#define ANSYS_ACFX_BLDMDLR_CODE                    377 /* ANSYS BladeModeler */
#define ANSYS_A_SPACECLAIM_CATIA_V5_CODE           418 /* ANSYS SpaceClaim CATIA V5 Interface */
#define ANSYS_A_SPACECLAIM_DIRMOD_CODE             383 /* ANSYS SpaceClaim Direct Modeler */
#define ANSYS_ACFD_MHD_CODE                        384 /* ANSYS CFD MHD */						
#define ANSYS_AHTI_TAS_CODE                        385 /* TAS */
#define ANSYS_AHTI_TRAINING_CODE                   386 /* TAS training */
#define ANSYS_AHTI_TAS_STRESS_CODE                 387 /* TASStress */
#define ANSYS_AHTI_TAS_FET_CODE                    388 /* FET Module for TAS */
#define ANSYS_AHTI_TASPCB_CODE                     389 /* TASPCB */
#define ANSYS_AHTI_CCM_WRITE_CODE                  390 /* TASPCB ccm write */
#define ANSYS_AHTI_ACCEL_EDA_CODE                  391 /* Geometry Interface for Accel EDA */
#define ANSYS_AHTI_CADENCE_ALLEGRO_CODE            392 /* Geometry Interface for Cadence Allegro */
#define ANSYS_AHTI_CADSTAR_CODE                    393 /* Geometry Interface for CADSTAR */
#define ANSYS_AHTI_DDE_CODE                        394 /* Geometry Interface for DDE */
#define ANSYS_AHTI_EDF_SCH_CODE                    395 /* Geometry Interface for EDF SCH */
#define ANSYS_AHTI_GENCAD_CODE                     396 /* Geometry Interface for Gencad */
#define ANSYS_AHTI_GENCAM_CODE                     397 /* Geometry Interface for Gencam */
#define ANSYS_AHTI_MENTOR_BOARDSTATION_CODE        398 /* Geometry Interface for Mentor Graphics Boardstation */
#define ANSYS_AHTI_MENTOR_NEUTRAL_CODE             399 /* Geometry Interface for Mentor Graphics Neutral */
#define ANSYS_AHTI_ORCAD_LAYOUT_CODE               400 /* Geometry Interface for OrCad */
#define ANSYS_AHTI_PADS_CODE                       401 /* Geometry Interface for PADS */
#define ANSYS_AHTI_PCAD_PDIF_LAYOUT_CODE           402 /* Geometry Interface for PCAD */
#define ANSYS_AHTI_PROTEL_PCB_CODE                 403 /* Geometry Interface for Protel */
#define ANSYS_AHTI_THEDA_CODE                      404 /* Geometry Interface for Theda */
#define ANSYS_AHTI_VERIBEST_VB_ASCII_CODE          405 /* Geometry Interface for Mentor Graphics Expedition */
#define ANSYS_AHTI_VERIBEST_EIF_CODE               406 /* Geometry Interface for Veribest */
#define ANSYS_AHTI_ZUKEN_CR3000_CODE               407 /* Geometry Interface for Zuken CR3000 */
#define ANSYS_AHTI_ZUKEN_CR5000_CODE               408 /* Geometry Interface for Zuken CR5000 */
#define ANSYS_AHTI_SYNOPSYS_ENCODE_CODE            409 /* Geometry Interface for Synopsys Encore */
#define ANSYS_AHTI_CADENCE_APD_CODE                410 /* Geometry Interface for Cadence APD */
#define ANSYS_AHTI_PTD_CODE                        411 /* PTD */
#define ANSYS_AHTI_TASTEC_CODE                     412 /* TASTEC */
#define ANSYS_AHTI_TAS_PULTRUSION_CODE             413 /* TAS Pultrusion */
#define ANSYS_AHTI_ZUKEN_CADSTAR_VIS_CODE          414 /* Geometry Interface for Zuken CADStar/Visula */
#define ANSYS_AHTI_TAS_SINDA3D_CODE                415 /* TAS Sinda/3D */
#define ANSYS_ANSHPC_GPU_CODE                      417 /* ANSYS HPC GPU */
#define ANSYS_ACDI_AD2DFULL_CODE                   420 /* ANSYS AUTODYN-2D */
#define ANSYS_ACDI_AD3DFULL_CODE                   421 /* ANSYS AUTODYN-3D */
#define ANSYS_ACDI_ADHPC_CODE                      422 /* ANSYS AUTODYN HPC */
#define ANSYS_A_JT_READER_CODE                     423 /* ANSYS JT Reader */
#define ANSYS_A_PROE_READER_CODE                   424 /* ANSYS Pro/E Reader */
#define ANSYS_ACDI_ADPREPPOST_CODE                 425 /* ANSYS AUTODYN PrepPost */
#define ANSYS_ACDI_ACDI_EXPLPROF_CODE              426 /* ANSYS Explicit Professional */
#define ANSYS_ACDI_ACDI_ADFESOLVE_CODE             427 /* ANSYS Explicit Professional - Explicit FE Solver */
#define ANSYS_ACDI_ACDI_LSDYNAK_CODE               428 /* ANSYS Explicit Professional - LS-DYNA .k creation */
#define ANSYS_ANSHPC_CODE                          440 /* ANSYS HPC */
#define ANSYS_ACPREPPOST_CODE                      435 /* ANSYS Composite PrepPost */
#define ANSYS_ANSHPC_PACK_CODE                     436 /* ANSYS HPC PACK*/
#define ANSYS_MECHHPC_CODE                         442 /* ANSYS Mechanical HPC */

#define ANSYS_ICE_PAK_CODE                         443 /* ANSYS IcePak */
#define ANSYS_ICE_MESHER_CODE                      444 /* ANSYS IcePak Mesher*/
#define ANSYS_ICE_SOLVER_CODE                      445 /* ANSYS IcePak Solver*/
#define ANSYS_ICE_PARALLEL_CODE                    446 /* ANSYS IcePak Parallel*/
#define ANSYS_ICE_OPT_CODE                         447 /* ANSYS IcePak Optimization Module*/
#define ANSYS_ICE_PRO_CODE                         448 /* ANSYS IcePro */
#define ANSYS_ICE_MAX_CODE                         449 /* ANSYS IceMax */							

#define ANSYS_ACDI_ASAS_CODE                       450 /* ANSYS ASAS - ASAS */
#define ANSYS_ACDI_LOCO_CODE                       452 /* ANSYS ASAS - LOCO */
#define ANSYS_ACDI_RESPONSE_CODE                   453 /* ANSYS ASAS - RESPONSE */
#define ANSYS_ACDI_POST_CODE                       454 /* ANSYS ASAS - POST */
#define ANSYS_ACDI_WAVE_CODE                       455 /* ANSYS ASAS - WAVE */
#define ANSYS_ACDI_MASS_CODE                       456 /* ANSYS ASAS - MASS */
#define ANSYS_ACDI_FATJACK_CODE                    457 /* ANSYS ASAS - FATJACK */
#define ANSYS_ACDI_BEAMST_CODE                     458 /* ANSYS ASAS - BEAMST */
#define ANSYS_ACDI_COMPED_CODE                     459 /* ANSYS ASAS - COMPED */
#define ANSYS_ACDI_XTRACT_CODE                     463 /* ANSYS ASAS - XTRACT */
#define ANSYS_ACDI_SPLINTER_CODE                   464 /* ANSYS ASAS - SPLINTER */
#define ANSYS_ACDI_WINDSPEC_CODE                   470 /* ANSYS ASAS - WINDSPEC */
#define ANSYS_ACDI_MAXMIN_CODE                     471 /* ANSYS ASAS - MAXMIN */
#define ANSYS_ACDI_ASASNL_CODE                     474 /* ANSYS ASAS - ASASNL */
#define ANSYS_ACDI_PRENL_CODE                      475 /* ANSYS ASAS - PRENL */
#define ANSYS_ACDI_POSTNL_CODE                     476 /* ANSYS ASAS - POSTNL */
#define ANSYS_ACDI_PANEL_CODE                      480 /* ANSYS Panel */
#define ANSYS_ACDI_CONCRETE_CODE                   481 /* ANSYS Concrete */
#define ANSYS_ACDI_PREBEAM_CODE                    483 /* ANSYS ASAS - PREBEAM */
#define ANSYS_ACDI_ASASLINK_CODE                   484 /* ANSYS ASAS - ASASLINK */
#define ANSYS_ACDI_FGV_ASAS_CODE                   490 /* ANSYS FEMGV - FGV_ASAS */
#define ANSYS_ACDI_FEMGV_CODE                      491 /* ANSYS FEMGV - FEMGV */
#define ANSYS_ACDI_ASAS_VIS_CODE                   493 /* ANSYS ASAS - ASAS-VIS */
#define ANSYS_ACDI_AQWALINE_CODE                   494 /* ANSYS AQWA - AQWALINE */
#define ANSYS_ACDI_AQWADRFT_CODE                   495 /* ANSYS AQWA - AQWADRFT */
#define ANSYS_ACDI_AQWAFER_CODE                    496 /* ANSYS AQWA - AQWAFER */
#define ANSYS_ACDI_AQWALBRM_CODE                   497 /* ANSYS AQWA - AQWALBRM */
#define ANSYS_ACDI_AQWANAUT_CODE                   498 /* ANSYS AQWA - AQWANAUT */
#define ANSYS_ACDI_HYDRODIFF_CODE                  499 /* ANSYS AQWA - HYDRO-DIFFRACT */
#define ANSYS_ACDI_AQWAWAVE_CODE                   502 /* ANSYS AQWA - AQWAWAVE */
#define ANSYS_ACDI_AQWAGS_CODE                     503 /* ANSYS AQWA - AQWAGS */
#define ANSYS_ACDI_AQWALNCH_CODE                   504 /* ANSYS AQWA Launch */
#define ANSYS_ACDI_AQWAFLOT_CODE                   505 /* ANSYS AQWA Float */
#define ANSYS_ACDI_AQWALOAD_CODE                   507 /* ANSYS AQWA Load */
#define ANSYS_ACDI_CD_DRIFT_CODE                   509 /* ANSYS AQWA - CD-DRIFT */
#define ANSYS_ACDI_CD_FER_CODE                     510 /* ANSYS AQWA - CD-FER */
#define ANSYS_ACDI_CD_LIBR_CODE                    511 /* ANSYS AQWA - CD-LIBR */
#define ANSYS_ACDI_CD_NAUT_CODE                    512 /* ANSYS AQWA - CD-NAUT */
#define ANSYS_ACDI_CD_AGS_CODE                     517 /* ANSYS AQWA - CD-AGS */
#define ANSYS_ACDI_TOPS_NL_CODE                    520 /* ANSYS TOPSIDES - TOPS-NL */
#define ANSYS_ACDI_TOPSIDES_CODE                   521 /* ANSYS TOPSIDES - TOPSIDES */
#define ANSYS_ACDI_PLAT_NL_CODE                    522 /* ANSYS PLATFORM - PLAT-NL */
#define ANSYS_ACDI_PLATFORM_CODE                   523 /* ANSYS PLATFORM - PLATFORM */
#define ANSYS_EKM_SERVER_CODE                      551 /* EKM Enterprise Server */
#define ANSYS_EKM_USER_CODE                        552 /* EKM User */
#define ANSYS_EKM_NAMED_USER_CODE                  553 /* EKM Named User */
#define ANSYS_EKM_WG_SERVER_CODE                   554 /* EKM WB Server */
#define ANSYS_EKM_TEST_SERVER_CODE                 555 /* EKM Test Server */
#define ANSYS_EKM_TEST_NAMED_USER_CODE             556 /* EKM Test Named User */
#define ANSYS_EKM_TEST_USER_CODE                   557 /* EKM Test Simultaneous User */
#define ANSYS_EKM_DESKTOP_CODE                     558 /* EKM Desktop */
#define ANSYS_EKM_DATALINK_SERVER_CODE             559 /* EKM Datalink Server */
#define ANSYS_EKM_DATALINK_USER_CODE               560 /* EKM Datalink User */
#define ANSYS_EKM_DATALINK_NAMED_USER_CODE         561 /* EKM Datalink Named User */

#define ANSYS_AFLUID_DYNAMICS1_CODE                570 /* ANSYS Fluid Dynamics 1 */
#define ANSYS_AFLUID_DYNAMICS2_CODE                571 /* ANSYS Fluid Dynamics 2 */
#define ANSYS_AFLUID_DYNAMICS3_CODE                572 /* ANSYS Fluid Dynamics 3 */

#define ANSYS_ANY_CODE                            9999 /* Designates that any acceptable license should be used */

#endif /* ndef __ANSYS_PRODUCT_H__ */

