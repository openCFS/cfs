/*****************************************************************************
 *                   Copyright (C) 1999 CMSoft                               *
 *                                                                           *
 *  These lines of code and declarations contain unpublished proprietary     *
 *  information of CMSoft. They may not be copied or duplicated in whole     *
 *  or part without prior authorization from CMSoft.                         *
 *                                                                           *
 *****************************************************************************/
#ifndef _FSCONNECTIVITY_H_
#define _FSCONNECTIVITY_H_

#include <stdio.h>

class Elemset;
class EqNumberer;
class FSElement;

#include "Connectivity.h"

class FSConnectivity {
        int nptr;           // size of pointer
        int numtarget;      // size of target, number of Connections
        int *pointer;       // pointer to target
        int *target;        // value of the connectivity
        float *weight;      // weights of pointer (or NULL)
  
public:
        FSConnectivity();
        FSConnectivity(Elemset *);
        FSConnectivity(int, FSElement **);
        FSConnectivity(int _size, int *_pointer, int *_target);
        FSConnectivity(int _size, int *_count);

        ~FSConnectivity();

        void Send(int iCPU);
        void Recv(int iCPU);
  
        int *operator[](int i);
        int size();
        int numNonZeroP();
        int numConnect(); // Total number of connections
        int num(int);
        int num(int, int*);
        int offset(int i) { return pointer[i]; } // Begining of ith part
        int offset(int i,int j); // returns a unique id for connection i to j
        FSConnectivity* reverse(float *w = 0, int setSize = -1); // creates t->s from s->t
        FSConnectivity* transcon( FSConnectivity* );
        FSConnectivity* collapse();
        FSConnectivity* subSection(bool *);
        FSConnectivity* unify(FSConnectivity*);
  
        void sortTargets();

        void findPseudoDiam(int *n1, int *n2, int *mask=0);
        int  rootLS(int root, int *xls, int *ls, int &w, int *mask=0);

        // Create a rooted level structure
        int *renumSloan(int *mask, int &firstNum, int *ren = 0);
        int *renumRCM(int *mask, int &firstNum, int *ren = 0);
        int *renumSloan();
        compStruct renumByComponent(int ialgo);
        int findMaxDist(int *);
        int findProfileSize( EqNumberer *eqNumber, int unroll=1);
        int *getP() { return pointer; }
        int *getT() { return target; }
	void print(int *, bool pointer, bool target, char*);
        void print(char *msg);
        void WriteMatlab(FILE *fp);
};

inline int
FSConnectivity::size() { return nptr; }

inline int
FSConnectivity::num(int n) 
   { return (n >= nptr) ? 0 : pointer[n+1] - pointer[n]; }

inline int *
FSConnectivity::operator[](int i) { return target +pointer[i] ; }

inline int
FSConnectivity::numConnect() { return numtarget; }

#endif
