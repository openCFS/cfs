/*! \file CEvalCriterion.h

  \brief This header file defines the CEvalCriterion class.

  \author Stephane MARGUERIN &copy; CADOE

  \date 20 April 2002

  \version $Id: CEvalCriterion.h,v 1.3 2009/11/13 16:13:02 jtm Exp $
 */

#ifndef __CEvalCriterion_h__ 
#define __CEvalCriterion_h__ 1 

#include <math.h>
#include "CCadoePortable.h"

/* L'optimisation !! */
#define OPT_PERCENT        534
#define OPT_UNIT           523
#define OPT_SIGMA          524


/*! \class CCritInfo
  \brief The CCritInfo class is used to describe an criterion.

  This class is used to fully describe a criterion in order for the
  calling application to present all the needed informations to the
  user and to identify the criteria to evaluate.

  Each criterion has a \p domain property that defines the evaluation domain
	(full model, a group of nodes or elements, one node or one element). 
	In case of a group domain, the property \p groupNature has to be used to 
	determine wether it is a group of nodes or a group of elements.
*/
class CCritInfo
{
 public:
  //! Criterion domain
  typedef enum {    
    CDO_NONE=0,			/**< default value */    
    CDO_MODEL,			/**< full model */
    CDO_GROUP,			/**< group of nodes or elements */
    CDO_NODE,				/**< one node */
    CDO_ELEMENT			/**< one element */
  } Domain;

  //! Layer option for results on thin shell elements
  typedef enum {
    LAY_NONE=0,				/**< default value */
    LAY_MAX=1,				/**< maximum of all the layers available */
    LAY_TOP=2,				/**< top layer */
    LAY_MIDDLE=3,			/**< middle layer */
    LAY_BOTTOM=4			/**< bottom layer */
  } Layer;

  //! not used
  typedef enum {
    CPL_NONE,
    CPL_REAL,
    CPL_IMAGINARY,
    CPL_MODULE,
    CPL_PHASE
  } ComplexComponent;

  typedef enum {
    CMP_INFERIOR=0,
    CMP_EQUAL=1,
    CMP_SUPERIOR
  } OptCompare;

	//! Components code
	typedef enum {
		COM_DEFAULT,
		COM_UX,	// displacement, reaction, perturbation 
		COM_UY,
		COM_UZ,
		COM_RX,
		COM_RY,
		COM_RZ,
		COM_MAGNU,
		COM_MAGNR,
		COM_XX, // stress, strain
		COM_YY,
		COM_ZZ,
		COM_XY,
		COM_XZ,
		COM_YZ,
		COM_S1, // principal stress
		COM_S2,
		COM_S3,
		COM_EQV, // von mises
		COM_INT, // intensity = Tresca
		COM_MSHEAR // maximum shear stress
	} Component;

  //! Criterion code.
	typedef enum {
	  CCO_NONE=0,
	  CCO_NODE_STRESS		=1,
	  CCO_NODE_STRAIN		=2,
	  CCO_NODE_DISP		=3,
	  CCO_NODE_MISES		=4,
	  CCO_NODE_TRESCA		=5,
	  CCO_NODE_REACTION		=6,
	  CCO_NODE_SPRING_REAC	=7,
	  CCO_NODE_MODE_DISP         =80,
	  CCO_NODE_MODE_ID_DISP      =84,
	  CCO_NODE_HDISP            	=107,
	  CCO_NODE_HVELO            	=110,
	  CCO_NODE_HACCE            	=111,
	  CCO_NODE_HVELO_DB          =116,
	  CCO_NODE_HACCE_DB          =117,
	  CCO_NODE_MODEU_DISP        =120,
	  CCO_NODE_TEMP              =167,
	  CCO_NODE_MSSHEAR		=142,
	  CCO_NODE_CP			=147,
	  CCO_NODE_MAX_CP		=148,
	  CCO_NODE_USER1		=8,
	  CCO_NODE_USER2		=9,
	  CCO_NODE_USER3		=10,
	  CCO_NODE_VOLT                 =168,
          CCO_NODE_TG                   =176,
	  CCO_NODE_TF                   =183,

	  CCO_ELEM_PG_STRESS		=11,
	  CCO_ELEM_PG_STRAIN		=12,
	  CCO_ELEM_PG_MISES		=13,
	  CCO_ELEM_PG_TRESCA		=14,
	  CCO_ELEM_MOY_STRESS		=15,
	  CCO_ELEM_MOY_STRAIN		=16,
	  CCO_ELEM_MOY_MISES		=17,
	  CCO_ELEM_MOY_TRESCA		=18,
	  CCO_ELEM_MASS		=19,
	  CCO_ELEM_ENER_STRAIN 	=20,
	  CCO_ELEM_SED		=21,
	  CCO_ELEM_CP			=22,
	  CCO_ELEM_MAX_CP		=23,
	  CCO_ELEM_EFFORT            =65,
	  CCO_ELEM_MAX_EFFORT        =66,
	  CCO_ELEM_MAX_STRESS        =71,
	  CCO_ELEM_MAX_STRAIN        =72,
	  CCO_ELEM_MAX_MISES         =73,
	  CCO_ELEM_MAX_TRESCA        =74,
	  CCO_ELE_MODAL_ENER         =103,
	  CCO_ELE_MODAL_ENER_ID      =106,
	  CCO_ELEM_DP                =122,
	  CCO_ELEM_MAX_DP            =123,
	  CCO_ELEM_FLUX              =131,
	  CCO_ELEM_MSSHEAR			=141,
	  CCO_ELEM_USER1		=24,
	  CCO_ELEM_USER2		=25,
	  CCO_ELEM_USER3		=26,
          CCO_ELEM_TG                   =175,
          CCO_ELEM_TF                   =182,

	  CCO_MOD_ELEM_MAXSTRESS	=27,
	  CCO_MOD_ELEM_MAXSTRAIN	=28,
	  CCO_MOD_ELEM_MAXMISES	=29,
	  CCO_MOD_ELEM_MAXTRESCA	=30,
	  CCO_MOD_ELEM_MAXTG	     =178,
	  CCO_MOD_ELEM_MAXTF	     =185,
	  CCO_MOD_NODE_MAXDISP	=31,
	  CCO_MOD_NODE_MAXSTRESS     =32,
	  CCO_MOD_NODE_MAXSTRAIN     =33,
	  CCO_MOD_NODE_MAXMISES      =34,
	  CCO_MOD_NODE_MAXTRESCA     =35,
	  CCO_MOD_NODE_MAXTG         =179,
	  CCO_MOD_NODE_MAXTF         =186,
	  CCO_MOD_MASS               =36,
	  CCO_MOD_SED                =37 ,
	  CCO_MOD_ENER_STRAIN        =38 ,
	  CCO_MOD_ELEM_MAX_ENER_STRAIN =39,
	  CCO_MOD_ELEM_MAX_CP        =40,
	  CCO_MOD_REACTION           =41,
	  CCO_MOD_NODE_SPRING_REAC   =42,
	  CCO_MOD_MODAL_ENER         =101,
	  CCO_MOD_ELEM_MAX_EFFORT    =67,
	  CCO_MOD_PARAMETER          =69,
	  CCO_MOD_SOM_REAC           =76,
	  CCO_MOD_MODE_MAXDISP       =78,
	  CCO_MOD_MODE_ID_MAXDISP    =82,
	  CCO_MOD_MODAL_ENER_ID      =104,
	  CCO_MOD_NODE_MAXHDISP     	=109,
	  CCO_MOD_NODE_MAXHVELO     	=113,
	  CCO_MOD_NODE_MAXHACCE     	=115,
	  CCO_MOD_MODEU_MAXDISP      =118,
	  CCO_MOD_ELEM_MAX_DP        =124,
	  CCO_MOD_MAX_FLUX           =133,
	  CCO_MOD_MAX_TEMP           =130,
	  CCO_MOD_NODE_MAX_MSSHEAR	=145,
	  CCO_MOD_ELEM_MAX_MSSHEAR	=146,
	  CCO_MOD_NODE_MAX_CP		=151,
	  CCO_MOD_NODE_CP		=152,
	  CCO_MOD_USER1              =43,
	  CCO_MOD_USER2              =44,
	  CCO_MOD_USER3              =45,
	  CCO_MOD_TEMP               =171,
          CCO_MOD_VOLT               =172,
	  
	  CCO_GRP_ELEM_MAXSTRESS     =46,
	  CCO_GRP_ELEM_MAXSTRAIN     =47,
	  CCO_GRP_ELEM_MAXMISES      =48,
	  CCO_GRP_ELEM_MAXTRESCA     =49,
	  CCO_GRP_ELEM_MAXTG         =180,
	  CCO_GRP_ELEM_MAXTF         =187,
	  CCO_GRP_NODE_MAXDISP       =50,
	  CCO_GRP_NODE_MAXSTRESS     =51,
	  CCO_GRP_NODE_MAXSTRAIN     =52,
	  CCO_GRP_NODE_MAXMISES      =53,
	  CCO_GRP_NODE_MAXTRESCA     =54,
	  CCO_GRP_NODE_MAXTG         =181,
	  CCO_GRP_NODE_MAXTF         =188,
	  CCO_GRP_MASS               =55,
	  CCO_GRP_SED                =56 ,
	  CCO_GRP_ENER_STRAIN        =57 ,
	  CCO_GRP_ELEM_MAX_ENER_STRAIN =58,
	  CCO_GRP_ELEM_MAX_CP        =59,
	  CCO_GRP_REACTION           =60,
	  CCO_GRP_NODE_SPRING_REAC   =61,
	  CCO_GRP_MODAL_ENER         =102,
	  CCO_GRP_ELEM_MAX_EFFORT    =68,
	  CCO_GRP_SOM_REAC           =75,
	  CCO_GRP_MODE_MAXDISP       =79,
	  CCO_GRP_MODE_ID_MAXDISP    =83,
	  CCO_GRP_MODAL_ENER_ID      =105,
	  CCO_GRP_NODE_MAXHDISP     	=108,
	  CCO_GRP_NODE_MAXHVELO     	=112,
	  CCO_GRP_NODE_MAXHACCE     	=114,
	  CCO_GRP_MODEU_MAXDISP      =119,
	  CCO_GRP_ELEM_MAX_DP        =125,
	  CCO_GRP_MAX_TEMP           =129,
	  CCO_GRP_MAX_FLUX           =132,
	  CCO_GRP_NODE_MAX_MSSHEAR	=143,
	  CCO_GRP_ELEM_MAX_MSSHEAR	=144,
	  CCO_GRP_NODE_CP						=149,
	  CCO_GRP_NODE_MAX_CP				=150,
	  CCO_GRP_USER1              =62,
	  CCO_GRP_USER2              =63,
	  CCO_GRP_USER3              =64,
	  CCO_GRP_TEMP               =169,
	  CCO_GRP_VOLT               =170,
	  CCO_NULL_COST_F            =70,
	  CCO_FREQUENCE_PROPRE       =77,
	  CCO_FREQUENCE_PROPRE_ID    =81,
	  CCO_RES_DISP_NODES	       =85,
	  CCO_RES_DEFORM_MODEL       =86,
	  CCO_RES_STRAIN_POINTS      =87,
	  CCO_RES_STRESS_POINTS      =88,
	  CCO_RES_ENERGIE	       =89,
	  CCO_RES_EFFORT_INT	       =90,
	  CCO_RES_REACTION	       =91,
	  CCO_RES_MESH_STRAIN_ELEM   =92,
	  CCO_RES_MESH_PERTURB       =93,
	  CCO_RES_SECTION_PERTURB    =94,
	  CCO_RES_MODE	             =95,
	  CCO_RES_MODE_ID	     =96,
	  CCO_RES_DEFORME_MODALE     =97,
	  CCO_RES_DEFORME_MODALE_ID  =98,
	  CCO_RES_ENERGIE_MODALE     =99,
	  CCO_RES_ENERGIE_MODALE_ID  =100,
	  CCO_RES_MODEU              =121,
	  CCO_RES_TEMPERATURE        =126,
	  CCO_RES_FLUX               =127,
	  CCO_RES_STRESS_NODES       =134,
	  CCO_RES_STRAIN_NODES       =135,
	  CCO_RES_DISP_NODES_C       =138,
	  CCO_RES_STRESS_NODES_C     =139,
	  CCO_RES_STRAIN_NODES_C     =140,
	  CCO_RES_MODE_C             =153,
	  CCO_RES_NODE_FORCE	       =154,
	  CCO_RES_GRP_NODE_MAXFORCE  =155,
	  CCO_RES_MOD_NODE_MAXFORCE  =156,
	  CCO_RES_FORCE_NODES_C      =157,
	  CCO_RES_FORCE_NODES        =158,
	  CCO_RES_REACTION_C         =159,
	  CCO_RES_MASS               =164,
	  CCO_LOAD_FACTOR            =165,
	  CCO_RES_TG                 =177,
	  CCO_RES_TF                 =184,
	  CCO_RES_VOLT               =174,
	  CCO_RES_B                  =188,
	  CCO_RES_H                  =193,
	  CCO_RES_JT                 =198,
	  CCO_RES_FMAG               =203,
	  CCO_RES_TG_NODES_C         =213,
	  CCO_RES_TF_NODES_C         =214,
	  CCO_RES_TG_NODES			 =215,
	  CCO_RES_TF_NODES			 =216
} Code;

  typedef list<CCritInfo> CritInfoList;
  typedef vector<CCritInfo> CritInfoVector;

  //! default constructor
  CCritInfo() {  _defaut = 0; };
  //! internal constructor
  CCritInfo( Code critCode );

  //! copy constructor
  CCritInfo( const CCritInfo &cinfo );
  CCritInfo& operator =( const CCritInfo &cinfo );


  virtual ~CCritInfo() { _components.clear(); }

  // comparison operator
  bool operator==( const CCritInfo &cinfo );

  /*! \brief retrieve the code which identifies the nature of the criterion.
    \return internal criterion code
  */
  Code getCode(void) const { return _code; }

  /*! \brief retrieve the name of the criterion. This name can be
    directly displayed to the user.
    \return name
  */
  string getName(void) const { return _name; }
  const char * getNameCstr(void) const { return _name.c_str(); }

  /*! \brief retrieve the domain type of the criterion
    \return domain
  */
  Domain getDomain(void) const { return _domain; }

  /*! \brief retrieve the group nature in the case of a group domain
    \return group nature
  */
  int getGroupNature(void) const { return _groupNature; }

  /*! \brief retrieve the component type which is a unique identifier
    for a set of components
    \return component type
  */
  int getComponentType(void) const { return _componentType; }

  /*! \brief retrieve the number of components which is the size of
    the array \p components
    \return number of components
  */
  int getNbComponents(void) const { return (int)_components.size(); }

  int getDefaultComponent(void) const { return _defaut; }

  /*! \brief retrieve the vector of the components. Each components is
    described by a string that can be displayed to the user. Note that
    when adding a criterion to the CEvalProcess, the component is
    identified by its position in this vector (from 0 to n).
    
    \return vector of components.
  */
  const vector<string>& getComponents(void) const { return _components; }

  /*! \brief retrieve the location of the resuls. Will be used for
    contour criterion.
  */
  int getLocation(void) const { return _location; }

  /*! \brief return true if this criterion needs a layer option to be
    selected.
    \return withLayer flag
  */
  bool getWithLayer(void) const { return _withLayer; }

	
  void setCode( Code code ) { _code=code; };
  void setName( const string &name ) { _name = name; }
  void setDomain( Domain domain ) { _domain=domain; }
  void setGroupNature( int groupNature ) { _groupNature=groupNature; }
  void setComponentType( int componentType ) {_componentType = componentType;}
  void addComponent( const string &comp ) { _components.push_back(comp); }
  void setLocation( int location ) {_location=location; }
  void setWithLayer( bool withLayer ) {_withLayer=withLayer; }

  bool isWithMaxLocation() const { return _withMaxLocation; }

 private:

	
 protected:
  Code				_code;	// criterion type
  string			_name;	// name 
  Domain			_domain;	// criterion on model, node, one element or one group
  int					_groupNature;	// groups of Nodes or Elements
  int					_componentType;	// coding of the component set available for this criterion
  vector<string>	_components;	// components list
  int			_defaut;
  int					_location;	// location of the results: at nodes, at elements, at nodes on elements
  bool				_withLayer;	// thin shell: top, bottom or middle layer must be choosen or not.
  bool				_withMaxLocation;
};




/*! \class CEvalCriterion CEvalCriterion.h
  \brief The CEvalCriterion class is used to describe an evaluation
  criterion.

  This class is used to fully describe a criterion in order for the
  calling application to present all the needed informations to the
  user and to identify the criteria to evaluate.

  Each criterion has a \p domain property that defines the evaluation domain
	(full model, a group of nodes or elements, one node or one element). 
	In case of a group domain, the property \p groupNature has to be used to 
	determine wether it is a group of nodes or a group of elements.

  \todo Manage load sets and linear combinations of load sets to be
  assigned to a criterion (internal mechanism already exists).

  \todo Add methods to define groups of nodes and elements for a group
  evaluation (internal mechanism already exists).
*/
class CCriterion : public CCritInfo
{
public:


  typedef list<CCriterion> CriterionList;

  //! default constructor
  CCriterion();
  //! constructor from a CCritInfo
  CCriterion( const CCritInfo &cinfo );

  //! copy constructor
  CCriterion( const CCriterion& crit );
  CCriterion& operator = ( const CCriterion &crit );

  //! default destructor
  ~CCriterion() { _selComponents.clear(); _loadCaseFactor.clear(); }

  //! comparison operator
  bool operator == ( const CCriterion &crit );

  /*! \brief retrieve the internal id which is the unique identifier of the criterion
    \return internal criterion code
  */
  int getId(void) const { return _id; }

  /*! \brief Select a component
    \param componentPos [in] position of the component in the array of available components. For contour, it is
    always 0.
  */
  void selectComponent( const int componentPos=0 ) { _selComponents.push_back(componentPos); }
  void selectComponent( CCritInfo::Component compCode );
  int getSelectedComponent(void) const { return _selComponents[0]; }
  vector<int> getSelectedComponents(void) const { return _selComponents; }

  /*! \brief Select a load case number (1 to n)
    \param modeLabel [in] label of the mode/eighenvalue to select, from 1 to n.
  */
  void selectLoadCase( int loadCaseLabel ) { _selLoadCase = loadCaseLabel; }
  int getSelectedLoadCase( void ) { return _selLoadCase; }
	
  /*! \brief Assigns a custom multiplication factor to a given load case, identified by its position (0 to n-1)
    \param componentPos [in] position of the component in the array of available components. For contour, it is
    always 0.
  */
  void setLoadCaseFactor( int loadCasePos=0, double factor=1.0 ) { _loadCaseFactor[loadCasePos] = factor; }
  double getLoadCaseFactor( int loadCasePos=0 );

  /*! \brief Select a mode/eighenvalue in normal mode analysis
    \param modeLabel [in] label of the mode/eighenvalue to select, from 1 to n.
  */
  void selectMode( int modeLabel ) { _selLoadCase = modeLabel; }
  int getSelectedMode( void ) { return _selLoadCase; }
	
  /*! \brief Select the layer
    \param layer [in] selected layer option. If the criterion is not layer dependent, this is ignored.
  */
  void selectLayer( Layer layer=LAY_NONE ) { _selLayer = layer; }
  Layer getSelectedLayer(void) const { return _selLayer; }

  /*! \brief Select the group of nodes or elements on which to evaluate the criterion.
    \param groupId [in] Id of the group to select. 
  */
  void selectGroup( int groupId=-1 ) { _selGroupId = groupId; }
  int getSelectedGroup(void) { return _selGroupId; }

  /*! \brief Select the group of nodes or elements on which to evaluate the criterion.
    \param name [in] name of the group to select. 
  */
  void selectGroup( const string &name ) { _selGroupName = name; }
  string getSelectedGroupName(void) { return _selGroupName; }
	
  /*! \brief Select the finite element entity on which to evaluate the criterion. If the doamin of the group is not
    element or node, this is ignored.
    \param feEntityLabel [in] entity label in the user numbering context
  */
  void selectFeEntity( int feEntityLabel=-1 ) { _selFeEntityLabel = feEntityLabel; }
  int getSelectedFeEntity(void) { return _selFeEntityLabel; }

  void setLimitation( OptCompare comp,double limit,double precision,int type_prec) { _comp = comp; _limit = limit; _precision = precision; _type_precision = (type_prec==0) ? OPT_PERCENT : OPT_UNIT; }
  void unsetLimitation() { _precision = -fabs(_precision); }
  double getPrecision() { return _precision; }
  int getTypePrecision() { return _type_precision; }
  double getLimit() { return _limit; }
  OptCompare getComp() { return _comp; }

  void setId( int id ) { _id=id; }

  void setAbsolute( bool absolute=true ) { _absolute=absolute; }
  bool getAbsolute(void) const { return _absolute; }

  void setNegative( bool negative=true ) { _negative=negative; }
  bool getNegative(void) const { return _negative; }
	
  void setSearchMinimum( bool minimum=true ) { _minimum=minimum; }
  bool getSearchMinimum(void) const { return _minimum; }

  void useNodalCS( void ) { _cs_code = -1; }
  void useGlobalCS( void ) { _cs_code = -2; }
  // void useUserCS( int label ) { _cs_code = label; }
  int getUsedCS( void ) { return _cs_code; }
	
private:
  int		_id;	// internal id
  vector<int>	_selComponents; // selected components
  Layer		_selLayer; // selected layeroption if thin shell context
  int		_selGroupId; // selected group for GROUP and MODEL domains (-1 by default for model)
  string		_selGroupName; // selected group for GROUP and MODEL domains
  int		_selFeEntityLabel; // selected fe entity label for NODE and ELEMENT domains.
  map<int,double> _loadCaseFactor; // load cases factor
  int		_selLoadCase; // selected LoadCase/Mode label

  // infos pour les criteres de type limitation (optimisation)
  OptCompare	_comp;
  double	_limit;
  double	_precision;
  int		_type_precision;
  bool		_is_limitation;
  bool		_absolute;
  bool		_negative;
  bool		_minimum;		// search for minimum instead of maximum
  int		_cs_code;		// coordinate system code (nodal, global or CS label)
};


#endif
