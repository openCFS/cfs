/* globals.h                                                       FJB,SYS
------------------------------------------------------------------------
------- Notice - This file contains ANSYS Confidential information --------
------------------------------------------------------------------------
*/
/* 
 * ***  copyright(c) 2010 SAS IP, Inc.  All rights reserved. 
 * *** ansys, inc.
 */

/*------------------------------ Description ---------------------------
\Author:	F. J. Bogden
\Title:		Global declarations and definitions
\Desc:		This file contains some global declarations and
		definitions many of which are computer(machine) dependent
		and key on the computer dependencies found in the header
		file "computer.h".  The definitions here were developed
		for both K&R and ANSI C programs.  The definitions in this
		file are -not- necessarily complete and may need to be
		updated from time to time.  The variables used are mostly
		self explanatory.
\History:	93/02/09 : fjb - initial creation
		93/08/09 : pft - merge of motif ui
		93/09/29 : yt  - add "typedef void VOID;"
		93/11/30 : yt  - restructure the error handler in ansys/xox
				 interface
		93/12/09 : yt  - add "typedef jmp_buf JMP_BUF"
		93/12/13 : yt  - move "#include <setjmp.h>" from globals.h
		93/12/14 : yt  - move "#include <setjmp.h>" back to xoxbol.h
		94/02/09 : yt  - fix shapes/XOX-related errors for ansys51
		94/02/16 : fjb - redo in form of SASI C-guidelines, added
				 ANSI-C optional prototyping function and
				 other definitions and typedefs, removed
				 CYBER support.
                94/02/25 : jas - correct spelling error
                94/03/09 : fjb - changed "typdef VOID" to "#defined VOID"
				 for non ANSI compilers.
		94/03/14 : fjb - add include "mathfun.h" and added more
				 comments.
		94/03/21 : fjb - added #define of EXIT_SUCCESS/EXIT_FAILURE
				 for non ANSI compilers.
                94/03/22 : fjb - added further #ifdef for EXIT_SUCCESS/EXIT_FAILURE
                94/03/22 : fjb - added further #ifdef for EXIT_SUCCESS/EXIT_FAILURE
		94/04/11 : jas - added typedef for PTR as long int
                94/04/13 : fjb - added #include <sys/param.h> to remove warnings.
                94/04/14 : gps - added check for systems without MAXPATHLEN
		94/04/28 : fjb - added qualifiers for <sys/param.h> and added more
                94/07/14 : jas - added UNSIGNED_INT typedef
                                 #defines for MAXPATHLEN for those without it.
                95/02/21 : jas - added DECAXPOSF to long PTR definition
                99/08/26 : jjh - added stuff for HP 64-bit version
                01/02/23 : jjh - added dependency for HP (IA64) Itanium version

\Function(s)
 -Primary:	To supply various global macros and header info
 -Secondary:	To foster portability
 -External:	none	
 -Internal:	none
 -Static:	none
 *** mpg globals.h<ansys.h LMatrix,msgdfc: machine data math header
         stdio,math,stdlib,mathfun,sys/param,ansproto
         VOID,REAL,DOUBLE,SHORT,INT,CHAR,LONG,DDOUBLE,DOUBLEFLOAT,
         PTR,LOGICAL,TRUE,FALSE,NIL,NULL,MALLOC,FREE
----------------------------------------------------------------------*/


/* Below spans entire file */
#ifndef  GLOBAL_DEFINITIONS
#  define GLOBAL_DEFINITIONS

/*------------------------------ Header files ------------------------*/
#ifndef SYSTEM_STDIO_H
#  define SYSTEM_STDIO_H
#  include <stdio.h>
#endif
#ifndef SYSTEM_STDLIB_H
#  define SYSTEM_STDLIB_H
#  include <stdlib.h>
#endif
#ifndef SYSTEM_MATH_H
#  define SYSTEM_MATH_H
#  include <math.h>
#endif
#if !defined(SYSTEM_PARAM_H) && !defined(PCWINNT_SYS)
#  define SYSTEM_PARAM_H
#  include <sys/param.h>
#endif
#ifndef MATHFUN_H
#  define MATHFUN_H
#  include "mathfun.h"
#endif

/*------------------------------ Dependencies ------------------------*/
/*
 * Check for ANSI-C compiler and set ANSYS variable ansANSI
 */
#if defined(__STDC__) || defined(USE_PROTO) || defined(DECAXPOSF_SYS)
# define ansANSI
#endif

/*
 * Define the PROTOTYPING macro and other types for ANSI-C
 */

#include "ansproto.h"


/* always define VOID as void (even K&R compilers know it) */
#if !defined (VOID)
#  define VOID void
#endif

#if !defined(ansANSI)
# if !defined(HP_SYS)
#  define const
# endif
# define volatile
# ifndef EXIT_SUCCESS
#   define EXIT_SUCCESS 0
# endif
# ifndef EXIT_FAILURE
#   define EXIT_FAILURE 1
# endif
#endif

/*
 * Define the type of floating point architecture for the entire code where :
 * SINGLEFLOAT  will generally conform to -64- bit word architectures
 * DOUBLEFLOAT  will generally conform to -32- bit word architectures
 */
#if !defined(SINGLEFLOAT) && !defined(DOUBLEFLOAT)
#   define DOUBLEFLOAT
#endif

/*
 * Use REAL, DOUBLE, SHORT, INT , CHAR, JMP_BUF, or LONG in body of the code
 * rather than direct use of type.  This will permit future ease of changes to
 * accomodate differences between machine architectures for short, int,
 * long, float, double and long double.
 * Also available is UNSIGNED_INT and sINT (implicit string length length).
 */
#ifndef UG_SCENARIO
typedef double		DDOUBLE;
#if defined (FULL_64)
typedef double		REAL;
#else
typedef float		REAL;
#endif
#ifndef MAINWIN
#ifdef DOUBLEFLOAT
  typedef double	DOUBLE;
#else
  typedef float		DOUBLE;
#endif
typedef short		SHORT;
typedef char		CHAR;
#endif
#ifndef MAINWIN 
typedef long		LONG;
#endif
#if defined (FULL_64)
typedef long            INT;
typedef long            LOGICAL;
#else
#ifndef MAINWIN
typedef int		INT;
#endif
typedef int		LOGICAL;
#endif
#endif

#ifdef WBUX_CADOE
typedef int		INT;
typedef short		SHORT;
typedef char		CHAR;
#ifdef DOUBLEFLOAT
  typedef double	DOUBLE;
#else
  typedef float		DOUBLE;
#endif
#endif

#if defined (LINUXIA64_SYS) || defined (LINUXOP64_SYS) \
  || defined (LINUXEM64T_SYS)

#if defined(PGI_COMPILER)
typedef unsigned long int  PTR;
#else
typedef unsigned __int64   PTR;
#endif

typedef unsigned long int  UNSIGNED_LONG;
typedef unsigned int       UNSIGNED_INT4;
#endif

#if defined (HP32_SYS)
typedef unsigned int       PTR;
typedef unsigned int       UNSIGNED_LONG;
typedef unsigned int       UNSIGNED_INT4;
#endif

#if defined(PCWIN64_SYS)
typedef unsigned __int64   PTR;
typedef unsigned long int  UNSIGNED_LONG;
typedef unsigned int       UNSIGNED_INT4;
#endif

#if defined (DECAXPOSF_SYS) || defined (SUN64_SYS) || defined (SOLX64_SYS)
typedef unsigned long int  PTR;
typedef unsigned long int  UNSIGNED_LONG;
typedef unsigned int       UNSIGNED_INT4;
#endif

#if defined (RS64K_SYS)
typedef unsigned long int  PTR;
typedef unsigned long int  UNSIGNED_LONG;
typedef unsigned int       UNSIGNED_INT4;
#endif

#if defined (SGIR8K_SYS) || defined (HP64_SYS) || defined (HPIA64_SYS)
typedef unsigned long int  PTR;
typedef unsigned long int  UNSIGNED_LONG;
typedef unsigned int       UNSIGNED_INT4;
#endif

/*  define SGIR4K_SYS, SOLARIS_SYS, RS6000_SYS, LINUXIA32_SYS  */
#if !defined (DECAXPOSF_SYS) && !defined (SGIR8K_SYS) \
  && !defined (HP32_SYS) && !defined (SOLX64_SYS) && !defined (SGI64_SYS) \
  && !defined (SUN64_SYS)  && !defined (RS64K_SYS) \
  && !defined (HP64_SYS) && !defined (HPIA64_SYS) \
  && !defined (PCWIN64_SYS) && !defined (LINUXIA64_SYS) \
  && !defined (LINUXOP64_SYS) && !defined (LINUXEM64T_SYS)
typedef unsigned int       PTR;
typedef unsigned long int  UNSIGNED_LONG;
typedef unsigned int       UNSIGNED_INT4;
#endif

#if defined (FULL_64)
typedef unsigned long int  UNSIGNED_INT;
#else
typedef unsigned int       UNSIGNED_INT;
#endif


/* set LONGINTC which will always match Fortran LONGINT */
#if defined(LONGINT2)

   /********** most 32 bit systems should be defined here *************/

# if defined(RS6000_SYS) || defined(LINUXIA32_SYS) || defined(SGIR4K_SYS) \
   || defined(SOLARIS_SYS)


   /* most 32-bit systems longs are only 32 bits, while they still support
      integer*8 in FORTRAN */
   typedef long long int LONGINTC;


# else

#  if defined (PCWINNT_SYS) || defined(PCWIN64_SYS)
   /* the microsoft compiler doesn't respect long long, use their type */
   typedef __int64 LONGINTC;


#  else 

   /********** most 64 bit systems should be defined here *************/

   /* most 64 bit systems can just declare this to be a long */
   typedef long int LONGINTC;
#  endif

# endif


#else
   /********** systems in this section do not support integer*8 in FORTRAN ***/
   typedef int LONGINTC;
#endif


/* sINT is for the implicit length of character strings passed from
 * Fortran to C.  This is normally 32-bits (int) but it may be 64-bits
 * on some FULL_64 platforms.
 */
typedef int                sINT;

/* apiINT is for explicitly setting the length of integers to int -
 * this is necessary where APIs are defined as int-only - 
 * this is to be used instead of int as the usage of int implies that
 * this section of code has not be upgraded to using INT
 */
typedef int                apiINT;

#ifndef NIL
# define NIL 0
#endif
#ifndef NULL
# define NULL 0
#endif
#ifndef FALSE
# define FALSE 0
#endif
/**********#ifndef F
# define F 0
#endif    *************/
#ifndef TRUE
# define TRUE 1
#endif
/**********#ifndef T
# define T 1
#endif    ************/

/*
 ***********************************************************************
 * NOTE : BELOW MALLOC/FREE NEED TO BE ALTERED FOR ANSYS USE
 ***********************************************************************
 */
#ifndef MALLOC
# define MALLOC malloc
#endif
#ifndef FREE
# define FREE free
#endif

/*
 * Handle systems without MAXPATHLEN defined
 */
#ifndef MAXPATHLEN
# if defined ( PCWINNT_SYS )
#  define MAXPATHLEN _MAX_PATH
# endif
#endif

/*
 *  set parameters for PARMSIZE (size of parameter name)
 */
#ifndef PARMSIZE
#  define PARMSIZE 32 
#endif

/*----------------------- Static Macro Definitions -------------------*/

/*--------------------- Static TypeDefs/Structures -------------------*/

/*----------------------- Variable Definitions -----------------------*/

/*------------------------- Exported Functions ------------------------*/

/*------------------------- Internal Functions ------------------------*/

/*-------------------------- Static Functions ------------------------*/

/*--------------------------------------------------------------------*/
/* Below is the endif for the whole file. */
#endif
/*---------------------------- End Of Module -------------------------*/
