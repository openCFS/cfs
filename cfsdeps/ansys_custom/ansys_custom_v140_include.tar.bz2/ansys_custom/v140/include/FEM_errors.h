
/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 2009 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_errors.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_errors.h
 *  header file for FEM_errors.c
 *
 */
/* *** mpg math array c
 FEM_array.c FEM_matrix.c FEM_MeshTable.h FEM_Public.h FEM_array.h
 FEM_array_static.h  FEM_cdbtypes.h FEM_edPublic.h FEM_elPublic.h
 FEM_errors.h FEM_external.h FEM_faPublic.h FEM_matrix.h
 FEM_matrix_static.h FEM_meshTree.h FEM_noGeom.h FEM_noPublic.h
 FEM_publicElementDefinition.h fem_Struct.h
 ansproto.h computer.h float.h globals.h mathfun.h
*/
#ifndef FEM_ERRORS_INCLUDE
#define FEM_ERRORS_INCLUDE

#ifdef __cplusplus
extern "C" {
#endif

extern FEM_BOOLEAN g_noerrors;

#ifdef __cplusplus
}
#endif

/* === Possible values for severity argument sent to FEMe_Error and
   === FEMe_String */

#ifndef DSPACE_CMDB
#define MESSAGE 0
#define NOTE    1
#define WARNING 2
#define ERROR   3
#define FATAL   4
#endif

#define FEM_MESSAGE 0
#define FEM_NOTE    1
#define FEM_WARNING 2
#define FEM_ERROR   3
#define FEM_FATAL   4

/* === subprocesses implemented in the MeshToolBox.  These identifiers are
   === sent to FEMe_Error as the subprocess argument. */

#define GENERIC          1     /* General errors that happen in all processes */
#define REFINEMENT       2     /* Errors that occur during FEM_Refinement     */
#define ANSYS_REFINEMENT 3     /* Errors that occur during FEM_Refinement     */
                               /* ANSYS specific.                             */
#define HEX_TO_TET       4     /* Errors that occur during FEM_HexToTet and   */
                               /* FEM_HexToPyr                                */
#define TET_IMPROVE      5     /* Errors that occur during FEM_TetCleanUp,    */
                               /* FEM_TryUninvertQuadTets, and                */
                               /* FEM_TryRemovePoorTets.                      */
#define CLEANUP_2D       6     /* Errors that occur during FEM_TriTopoCleanUp,*/
                               /* FEM_QuadTopoCleanUp, and                    */
                               /* FEM_QuadQualCleanUp.                        */
#define SURF_PROX        7     /* Errors that occur during surface proximity  */
                               /* refinement.                                 */
#define CHECK_TOPO       8     /* Errors that occur while checking facets for */
                               /* FVMESH                                      */
#define TRI_MESH         9     /* Errors that occur during delaunay meshing   */
                               /* which is used for out background meshing,   */
                               /* and other things.                           */
#define LAYER_MESH       10    /* Error occured during boundary layer meshing */
#define PAVING           11    /* Error occured during quad meshing.          */
#define VSWEEP           12    /* Error occured while volume sweeping.        */
#define VSWEEP_ANSYS     13    /* Error occured while volume sweeping. ANSYS  */
                               /* specific.                                   */
#define COPY_MESH        14    /* Error occured while projecting an area mesh */
                               /* from one area to another (used by sweeping) */
#define QMAP             15    /* Error occurred while quad map meshing.      */
#define AREA_MESH        16    /* Error occurred while area meshing.          */
#define CHK_FACETS       17    /* Error occurred while checking facets in     */
                               /* preparation for tet meshing.                */
#define HARD_POINTS      18    /* Error occured while inserting hardpoints as */
                               /* a post processor to meshing.                */
#define MORPH            19    /* morphing and remeshing                      */
#define SMRTSIZE         20    /* smart sizing                                */

/* ========================================================================== */
/* === error ids for subprocess GENERIC.  These identifiers are sent to 
   === FEMe_Error as the errorid argument. */
/* === Error ids commented as a "FATAL ERROR" are because of a corrupt 
   === database or programming error.  These errors should be reported as a
   === bug.  Save the input that caused the error to occur.  a_params in
   === FEMe_Error is unused for these errors. */


#define GEN_UNKNOWN_ERROR                1   /* FATAL ERROR                   */
#define GEN_OUT_OF_MEMORY                2   /* FEMe_Malloc was called and    */
                                             /* a NULL pointer was returned.  */
                                             /* a_params in FEMe_Error is     */
                                             /* unused.                       */
#define GEN_NON_NEW_NODE_IN_HASHING      3   /* FATAL ERROR                   */
#define GEN_INVALID_GEO_ENTITY           4   /* FATAL ERROR                   */
#define GEN_ERROR_STORING_ELEMS          5   /* Ansys specific                */
#define GEN_NO_ABORT_ALLOWED             6   /* Ansys specific                */
#define GEN_BAD_MESH_TYPE                7   /* FATAL ERROR                   */
#define GEN_BAD_ELEM_SHAPE               8   /* FATAL ERROR                   */
#define GEN_UNUSED_EDGE                  9   /* FATAL ERROR                   */
#define GEN_UNUSED_NODE                  10  /* FATAL ERROR                   */
#define GEN_DET_EDGE_GEO                 11  /* FATAL ERROR                   */
#define GEN_DET_FACE_GEO                 12  /* FATAL ERROR                   */
#define GEN_DET_ADJ_FACE                 13  /* FATAL ERROR                   */
#define GEN_SHAPE_CHK_FAILURE            14  /* The area or volume could not  */
                                             /* be meshed because one of the  */
                                             /* resulting elements failed     */
                                             /* shape criteria.               */
#define GEN_POOR_LINE_PARAM              15  /* Parameterization on a line    */
                                             /* appears to be poor causing an */
                                             /* error to occur. a_parmas[0]   */
                                             /* in FEMe_Error is the line     */
                                             /* number in error.              */
#define GEN_POOR_AREA_PARAM              16  /* Parameterization on a line    */
                                             /* appears to be poor causing an */
                                             /* error to occur. a_parmas[0]   */
                                             /* in FEMe_Error is the area     */
                                             /* number in error.              */
#define GEN_PROJECT_TO_AREA              17  /* FEMe_ProjectToAreaX was called*/
                                             /* and returned an error.        */
                                             /* a_params[0] in FEMe_Error is  */
                                             /* the area number of the bad    */
                                             /* projection.                   */
#define GEN_PROJECT_TO_LINE              18  /* FEMe_ProjectToLineX was called*/
                                             /* and returned an error.        */
                                             /* a_params[0] in FEMe_Error is  */
                                             /* the line number of the bad    */
                                             /* projection.                   */
#define GEN_AREA_EVALUATION              19  /* FEMe_AreaEvaluate was called  */
                                             /* and returned an error.        */
                                             /* a_params[0] in FEMe_Error is  */
                                             /* the area number of the bad    */
                                             /* evaluation.                   */
#define GEN_LINE_EVALUATION              20  /* FEMe_LineEvaluate was called  */
                                             /* and returned an error.        */
                                             /* a_params[0] in FEMe_Error is  */
                                             /* the line number of the bad    */
                                             /* evaluation.                   */
#define GEN_AREA_NORMAL                  21  /* FEMe_AreaNormal was called    */
                                             /* and returned an error.        */
                                             /* a_params[0] in FEMe_Error is  */
                                             /* the area number of the bad    */
                                             /* normal                        */
#define GEN_LINE_NORMAL                  22  /* FEMe_LineNormal was called    */
                                             /* and returned an error.        */
                                             /* a_params[0] in FEMe_Error is  */
                                             /* the line number of the bad    */
                                             /* normal                        */
#define GEN_ERROR_INIT_AREAS             23  /* FEMe_InitAreasX was called    */
                                             /* and returned an error.        */
                                             /* a_params in FEMe_Error is     */
                                             /* unused.                       */
#define GEN_ERROR_INIT_LINES             24  /* FEMe_InitLinesX was called    */
                                             /* and returned an error.        */
                                             /* a_params in FEMe_Error is     */
                                             /* unused.                       */
#define GEN_AREA_CURVATURE               25  /* FEMe_AreaCurvature was called */
                                             /* and returned an error.        */
                                             /* a_params[0] in FEMe_Error is  */
                                             /* the area number of the bad    */
                                             /* curvature.                    */
#define GEN_LINE_CURVATURE               26  /* FEMe_LineCurvature was called */
                                             /* and returned an error         */
                                             /* a_params[0] in FEMe_Error is  */
                                             /* the line number of the bad    */
                                             /* curvature.                    */
#define GEN_POOR_LINE_PARAM2             27  /* same as GEN_POOR_LINE_PARAM   */
#define GEN_POOR_AREA_PARAM2             28  /* same as GEN_POOR_AREA_PARAM   */
#define GEN_PROJECT_TO_AREA2             29  /* same as GEN_PROJECT_TO_AREA   */
#define GEN_PROJECT_TO_LINE2             30  /* same as GEN_PROJECT_TO_LINE   */
#define GEN_AREA_EVALUATION2             31  /* same as GEN_AREA_EVALUATION   */
#define GEN_LINE_EVALUATION2             32  /* same as GEN_LINE_EVALUATION   */
#define GEN_AREA_NORMAL2                 33  /* same as GEN_AREA_NORMAL       */
#define GEN_LINE_NORMAL2                 34  /* same as GEN_LINE_NORMAL       */
#define GEN_ERROR_INIT_AREAS2            35  /* same as GEN_ERROR_INIT_AREAS  */
#define GEN_ERROR_INIT_LINES2            36  /* same as GEN_ERROR_INIT_LINES  */
#define GEN_AREA_CURVATURE2              37  /* same as GEN_AREA_CURVATURE    */
#define GEN_LINE_CURVATURE2              38  /* same as GEN_LINE_CURVATURE    */
#define GEN_EDGE_TWO_MIDNODES            39  /* same as GEN_EDGE_TWO_MIDNODES */


/* ========================================================================== */
/* === error ids for subprocess REFINEMENT.  These identifiers are sent to 
   === FEMe_Error as the errorid argument. */

#define REF_DETACHED_CLEANUP         1    /* During FEM_Refinement called on a*/
                                          /* detached model, cleanup and/or   */
                                          /* smoothing was requested.         */
                                          /* Smoothing or cleanup cannot be   */
                                          /* performed on a detached area     */
                                          /* mesh.  Cleanup and smoothing can */
                                          /* be performed on a detached tet   */
                                          /* mesh.  The refinement command    */
                                          /* will continue without area mesh  */
                                          /* smoothing and cleanup.           */
#define REF_CANNOT_FIND_TRI          2    /* FATAL ERROR                      */
#define REF_ILLEGAL_VOLUME_ELEM      3    /* FATAL ERROR                      */
#define REF_UNSUPPORTED_VOLUME_ELEM  4    /* During FEM_Refinement an element */
                                          /* that cannot be refinement was    */
                                          /* encountered.  Refinement can     */
                                          /* only be applied to triangles,    */
                                          /* quadrilaterals, and tetrahedra.  */
#define REF_TWO_EDGE_RETAIN          5    /* FATAL ERROR                      */
#define REF_POOR_QUAD_SPLIT          6    /* During FEM_Refinement or a quad  */
                                          /* mesh, some quads were split into */
                                          /* 2 triangles in order to avoid    */
                                          /* poorly shaped quads.  To stop    */
                                          /* this set the FEM_Refinement      */
                                          /* argument "retain" to 1.          */
#define REF_TRANS_QUAD_IN_TRI_MESH   7    /* FATAL ERROR                      */
#define REF_TRI_IN_RETAIN_QUADS      8    /* During FEM_Refinement where      */
                                          /* retain was set to 1, a triangle  */
                                          /* was found.  quads can only be    */
                                          /* maintained in an all quad mesh.  */
                                          /* a_params[0] in FEMe_Error is the */
                                          /* id of the triangle found.        */
#define REF_REFINE_LEADS_TO_INVERT   9    /* During FEM_Refinement of a tet   */
                                          /* mesh refinement could not be done*/
                                          /* without inverting elements.  This*/
                                          /* is generally caused by starting  */
                                          /* with a mesh that is too coarse in*/
                                          /* a high curvature region.  Try    */
                                          /* remeshing the volume with smaller*/
                                          /* elements before applying         */
                                          /* refinement.  a_params[0] in      */
                                          /* FEMe_Error is the element id that*/
                                          /* would result in inverted elems.  */
#define REF_INVALID_MARKED_NODES     10   /* FATAL ERROR                      */
#define REF_INVALID_MARKED_NODES_HEX 11   /* FATAL ERROR                      */
#define REF_ELEMS_NOT_SELECTED       12   /* FATAL ERROR                      */
#define REF_CANT_RETAIN_QUADS        13   /* Quads may not be retained in     */
                                          /* refinement because area          */
                                          /* a_params[0] either contains      */
                                          /* triangles or the region selected */
                                          /* for refinement has an odd number */
                                          /* of boundary edges.  If an all    */
                                          /* quad mesh is desired, select a   */
                                          /* simpler refinement region and    */
                                          /* try again.                       */

/* ========================================================================== */
/* === error ids for subprocess HEX_TO_TET.  These identifiers are sent to 
   === FEMe_Error as the errorid argument. */

#define HTT_CANT_MAKE_PYRAMID           1  /* During FEM_HexToTet a transition*/
                                           /* pyramid could not be made       */
                                           /* leaving tets directly adjacent  */
                                           /* to quads or hexes.  This        */
                                           /* occured on the area id stored   */
                                           /* in a_params[0] in FEMe_Error    */
#define HTT_USER_ABORT                  2  /* During FEM_HexToTet a user abort*/
                                           /* was detected.  Pyramids already */
                                           /* created will remain but some    */
                                           /* tets are still directly adjacent*/
                                           /* to quads or hexes.              */
#define HTT_ERROR_IMPROVING_ELEMENTS    3  /* Error occured while improving   */
                                           /* element quality after pyramid   */
                                           /* formation; check elements       */
                                           /* carefully.                      */


/* ========================================================================== */
/* === error ids for subprocess TET_IMPROVE.  These identifiers are sent to 
   === FEMe_Error as the errorid argument. */

#define TIMP_SHELL_AREAS                1  /* ANSYS specific.                 */
#define TIMP_INTERNAL_AREAS             2  /* ANSYS specific.                 */
#define TIMP_BEAM_LINES                 3  /* ANSYS specific.                 */
#define TIMP_LESIZE_LINES               4  /* ANSYS specific.                 */
#define TIMP_DETACHED_MID_NON_MOD_BND   5  /* ANSYS specific.                 */
#define TIMP_MID_NON_MOD_BND            6  /* ANSYS specific.                 */
#define TIMP_DEGEN_TET                  7  /* A degenerate tetrahedra was     */
                                           /* found.                          */
#define TIMP_INVERTED_QUAD_P_TET        8  /* A inverted quadratic tet was    */
                                           /* detected in a P-elem mesh.      */
                                           /* Since midnodes cannot be moved  */
                                           /* in a P-elem mesh, the inverted  */
                                           /* tet remains.                    */
#define TIMP_INVERTED_QUAD_TET          9  /* An inverted quadratic tet was   */
                                           /* detected and midnodes are       */
                                           /* already moved to midpoints,     */
                                           /* inverted tet remains.           */
#define TIMP_INVERTED_QUAD_TET_MAX_ITER 10 /* An inverted quadratic tet was   */
                                           /* detected after a_params[0]      */
                                           /* iterations of midnode moves.    */
#define TIMP_MOVED_NON_MOD_BND          11 /* ANSYS specific.                 */
#define TIMP_MOVED_NON_MOD_AREAS_LINES  12 /* ANSYS specific.                 */
#define TIMP_ERROR_JACOB_LIMIT          13 /* FEMe_TetJacobianErrorLimit was  */
                                           /* called and returned an error. A */
                                           /* default value for the tet       */
                                           /* jacobian error limit will be    */
                                           /* used.                           */


/* ========================================================================== */
/* === error ids for subprocess CLEANUP_2D.  These identifiers are sent to 
   === FEMe_Error as the errorid argument. */

#define CLN_ALREADY_INITIALIZED      1  /* This is the result of a corrupt    */
                                        /* database or programming error.     */
                                        /* These errors should be reported as */
                                        /* a bug.  Save the input that caused */
                                        /* the error to occur.  a_params in   */
                                        /* FEMe_Error is unused.              */


/* ========================================================================== */
/* === error ids for subprocess CHECK_TOPO.  These identifiers are sent to 
   === FEMe_Error as the errorid argument. */

#define TOPO_GAP                 1 /* There is a gap in your facet model on   */
                                   /* the edge between nodes a_params[0] and  */
                                   /* a_params[1].                            */
#define TOPO_MORE_THAN_TWO_EDGES 2 /* There are more than two elements on the */
                                   /* edge between nodes a_params[0] and      */
                                   /* a_params[1].                            */
#define TOPO_MORE_THAN_ONE_SET   3 /* You have more than one set of area      */
                                   /* elements selected.  In the case of      */
                                   /* nested shells or multiple volumes check */
                                   /* your model carefully after this meshing */
                                   /* operation.                              */
#define TOPO_FACES_LEFT_OVER     4 /* You have area elements without tets     */
                                   /* after the meshing operation.  Check     */
                                   /* your model carefully.                   */
#define TOPO_UNKNOWN_PRE_CHECK   5 /* FATAL ERROR                             */
#define TOPO_UNKNOWN_POST_CHECK  6 /* FATAL ERROR                             */



/* ========================================================================== */
/* === error ids for subprocess TRI_MESH.  These identifiers are sent to 
   === FEMe_Error as the errorid argument. */

#define TRIM_ERROR_RECOVER           1 /* An error occured creating a         */
                                       /* delaunay mesh.  The mesher will     */
                                       /* fail.  Try different sizing on      */
                                       /* adjacent lines and then try to      */
                                       /* mesh again.                         */
#define TRIM_ERROR_CLASSIFY_BY_ANGLE 2 /* An error occured creating a delaunay*/
                                       /* mesh.  The mesher will fail.  Try   */
                                       /* different sizing on adjacent lines  */
                                       /* and then try to mesh again.         */



/* ========================================================================== */
/* === error ids for subprocess LAYER_MESH.  These identifiers are sent to 
   === FEMe_Error as the errorid argument. */

#define LAYER_INTERNAL_SIZ_ALL_LINES   1  /* Cannot determine an internal     */
                                          /* element size for area            */
                                          /* a_params[0].  Because all line   */
                                          /* on this area have layer meshing  */
                                          /* parameters defined, an explicit  */
                                          /* internal element size must be    */
                                          /* specified.                       */
                                          /* FEM_glSetFlatElemSize_C() to     */
                                          /* specify.                         */
#define LAYER_INTERNAL_SIZ             2  /* Cannot determine an internal     */
                                          /* element size for area            */
                                          /* a_params[0].  An explicit        */
                                          /* internal element size must be    */
                                          /* specified by using               */
                                          /* FEM_glSetFlatElemSize_C().       */
#define LAYER_NOT_FLAT                 3  /* Layer Meshing on area a_params[0]*/
                                          /* cannot be done.  This feature is */
                                          /* limited to planar surfaces.      */
                                          /* Layer meshing attribute on lines */
                                          /* attached to this area will be    */
                                          /* ignored                          */



/* ========================================================================== */
/* === error ids for subprocess PAVING.  These identifiers are sent to 
   === FEMe_Error as the errorid argument. */

#define PAVING_ERROR                 1  /* FATAL ERROR                        */


/* ========================================================================== */
/* === error ids for subprocess VSWEEP.  These identifiers are sent to 
   === FEMe_Error as the errorid argument. */

#define VSWEEP_UNKNOWN_ERROR              1 /* FATAL ERROR                    */
#define VSWEEP_SRC_BND_UNKNOWN_ERROR      2 /* FATAL ERROR                    */
#define VSWEEP_RIBS_UNKNOWN_ERROR         3 /* FATAL ERROR                    */
#define VSWEEP_FILL_UNKNOWN_ERROR         4 /* FATAL ERROR                    */
#define VSWEEP_MATCH_UNKNOWN_ERROR        5 /* FATAL ERROR                    */
#define VSWEEP_BAD_SOURCE                 6 /* Cannot sweep volume            */
                                            /* (a_params[0]) because the      */
                                            /* specified source area          */
                                            /* (a_params[1]) is not attached. */
#define VSWEEP_BAD_TARGET                 7 /* Cannot sweep volume           */
                                            /* (a_params[0]) because the     */
                                            /* specified target area         */
                                            /* (a_params[1]) is not attached.*/
#define VSWEEP_BAD_SOURCE_AND_TARGET      8 /* Cannot sweep volume           */
                                            /* (a_params[0]) because source  */
                                            /* area (a_params[1]) and target */
                                            /* area (a_params[2]) are        */
                                            /* adjacent.                     */
#define VSWEEP_CANT_MAP_MESH2             9 /* Cannot sweep volume           */
                                            /* (a_params[0]) because side    */
                                            /* area (a_params[1]) cannot be  */
                                            /* automatically map meshed.     */
                                            /* Map mesh it manually and      */
                                            /* then try again.               */
#define VSWEEP_DIFFERENT_LINE_DIVS        10 /* Cannot sweep volume           */
                                             /* (a_params[0]) because side    */
                                             /* line (a_params[1]) has        */
                                             /* (a_params[2]) divisisions and */
                                             /* side line (a_params[3]) has   */
                                             /* (a_params[4]) divisisions     */
#define VSWEEP_NUM_LAYERS_SPECIFIED_BAD_SOFT 11
                                             /* Specified number of NDIV is   */
                                             /* ignored because a different   */
                                             /* side line is already meshed   */
                                             /* or soft lesized with          */
                                             /* (a_params[0]) divisions.      */
#define VSWEEP_DIFFERENT_LINE_DIVS_LESIZE 12 /* Cannot sweep volume           */
                                             /* (a_params[0]) because side    */
                                             /* line (a_params[1]) has        */
                                             /* (a_params[2]) divisisions and */
                                             /* side line (a_params[3]) has   */
                                             /* (a_params[4]) divisisions     */
#define VSWEEP_LOCATE_UNKNOWN_ERROR       13 /* FATAL ERROR                   */
#define VSWEEP_MIDNODE_UNKNOWN_ERROR      14 /* FATAL ERROR                   */
#define VSWEEP_ABORT                      15 /* The use hit abort during      */
                                             /* sweeping.                     */
#define VSWEEP_BAD_TARGET_MESH            16 /* Cannot sweep volume           */
                                             /* a_params[0] because the target*/
                                             /* area mesh does not match the  */
                                             /* source area mesh.  Clear the  */
                                             /* target area and try again.    */
#define VSWEEP_SIDE_NOT_MAP_MESH_AREA     17 /* Cannot sweep volume           */
                                             /* a_params[0] because side area */
                                             /* a_params[1] is already meshed */
                                             /* with a non-mapped mesh.       */
#define VSWEEP_BAD_SOURCE_AND_TARGET2     18 /* Cannot sweep volume           */
                                             /* a_params[0] with the specified*/
                                             /* source and target areas.  Pick*/
                                             /* different ones and try again. */
#define VSWEEP_AREA_HARDPOINTS            19 /* Cannot sweep volume           */
                                             /* a_params[0] because side area */
                                             /* a_params[1] has hardpoints.   */
                                             /* delete this hardpoint and then*/
                                             /* try again.                    */
#define VSWEEP_LINE_HARDPOINTS            20 /* Cannot sweep volume           */
                                             /* a_params[0] because line      */
                                             /* a_params[1] has hardpoints.   */
                                             /* delete this hardpoint and then*/
                                             /* try again.                    */
#define VSWEEP_2ND_TRY                    21 /* The first attempt to sweep    */
                                             /* volume a_params[0] resulted   */
                                             /* in poor quality elements.     */
                                             /* Automatically sweeping again  */
                                             /* with a more precise, but      */
                                             /* slower, sweeping method.      */
#define VSWEEP_BAD_SHAPE                  22 /* Volume a_params[0] cannot be  */
                                             /* swept with the specified      */
                                             /* source and target areas       */
                                             /* because the source and/or     */
                                             /* target area is too            */
                                             /* irregularly shaped.           */
#define VSWEEP_SHAPE_CHK_FAILURE          23 /* Failed because of element     */
                                             /* shape quality is very poor.   */
#define VSWEEP_MIDNODE_STRAIGHT_AREA      24 /* A midnode on area a_params[0] */
                                             /* was straightened due to poor  */
                                             /* solid model description.      */
#define VSWEEP_MIDNODE_STRAIGHT_LINE      25 /* A midnode on line a_params[0] */
                                             /* was straightened due to poor  */
                                             /* solid model description.      */
#define VSWEEP_BAD_MIDS_AREA              26 /* A midnode on area a_params[0] */
                                             /* could not be placed due to    */
                                             /* poor solid model description. */
#define VSWEEP_BAD_MIDS_LINE              27 /* A midnode on line a_params[0] */
                                             /* could not be placed due to    */
                                             /* poor solid model description. */
#define VSWEEP_BAD_MIDS_VOLU              28 /* A midnode in volume           */
                                             /* a_params[0] could not be      */
                                             /* placed due to poor solid      */
                                             /* model description.            */
#define VSWEEP_BAD_SOURCE2                29 /* Cannot sweep volume           */
                                             /* (a_params[0]) with the        */
                                             /* specified source area         */
                                             /* (a_params[1]) because a trg   */
                                             /* cannot be determine           */
                                             /* automatically.  Specify a     */
                                             /* target area or a different    */
                                             /* source area and try again.    */
#define VSWEEP_BAD_TARGET2                30 /* Cannot sweep volume           */
                                             /* (a_params[0]) with the        */
                                             /* specified target area         */
                                             /* (a_params[1]) because a src   */
                                             /* cannot be determine           */
                                             /* automatically.  Specify a     */
                                             /* source area or a different    */
                                             /* target area and try again.    */
#define VSWEEP_SRCTRG_UNKNOWN_ERROR       31 /* FATAL ERROR                   */
#define VSWEEP_BAD_SIDE_INTERVALS         32 /* Volume a_params[0] cannot be  */
                                             /* swept because the side line   */
                                             /* division specifications are   */
                                             /* too strict.  Change           */
                                             /* EXTOPT,ESIZE,NDIV or remove   */
                                             /* LESIZEs off lines and try     */
                                             /* again.                        */
#define VSWEEP_NO_PATHS_TO_TRG            33 /* Volume a_params[0] cannot be  */
                                             /* swept.  No direct path of     */
                                             /* lines from src to trg can be  */
                                             /* found.                        */
#define VSWEEP_DIFF_DIR                   34 /* Initial attempt to sweep vol  */
                                             /* a_params[0] resulted in poor  */
                                             /* element quality.              */
                                             /* Automatically attempting to   */
                                             /* sweep in a different          */
                                             /* direction.                    */
#define VSWEEP_CANT_MESH_AREA             35 /* An error occured during       */
                                             /* sweeping while meshing        */
                                             /* a_params[0].  Mesh this area  */
                                             /* manually (AMESH or AMAP) then */
                                             /* try the command again.        */
#define VSWEEP_CANT_MAP_MESH              36 /* Cannot sweep volume           */
                                             /* (a_params[0]) because side    */
                                             /* area (a_params[1]) cannot be  */
                                             /* automatically map meshed.     */
                                             /* The reason it can't be mapped */
                                             /* is because pre-meshed or      */
                                             /* lesized lines constrain it too*/
                                             /* much.                         */
                                             /* Map mesh it manually and      */
                                             /* then try again.               */
#define VSWEEP_AXIS_BAD_ELEM              37 /* Volume a_params[0] cannot be  */
                                             /* swept because specified sweep */
                                             /* would generate pyramids and/or*/
                                             /* tets and the current volume   */
                                             /* element type does not support */
                                             /* pyramids and/or tets.         */
#define VSWEEP_AXIS_BAD_SHAPE_PREMESH     38 /* Volume a_params[0] cannot be  */
                                             /* swept about axis because      */
                                             /* sweeping quad element         */
                                             /* a_params[1] on area           */
                                             /* a_params[2] would generate    */
                                             /* invalid element connectivity. */
                                             /* Clear this area and ensuring  */
                                             /* that only 1 quad element is   */
                                             /* attached to keypoint %d.      */
#define VSWEEP_AXIS_BAD_SHAPE_AUTOMESH    39 /* Volume a_params[0] cannot be  */
                                             /* swept about axis because      */
                                             /* source area a_params[1] could */
                                             /* not be automatically meshed   */
                                             /* with a suitable mesh.  Please */
                                             /* mesh this area manually       */
                                             /* before calling the sweeper.   */
#define VSWEEP_AXIS_BAD_SHAPE_ADJMESH     40 /* Volume a_params[0] cannot be  */
                                             /* swept about axis because      */
                                             /* an invalid element shape would*/
                                             /* result near node %d because   */
                                             /* adjacent volume a_params[1]   */
                                             /* is pre-meshed.  Clear this    */
                                             /* adjacent volume and try again.*/
#define VSWEEP_AXIS_NO_PYRS               41 /* Volume a_params[0] cannot be  */
                                             /* swept about axis because      */
                                             /* pyramids would be required    */
                                             /* around the axis, but the      */
                                             /* current element type does not */
                                             /* support pyramids.             */
#define VSWEEP_NUM_LAYERS_SPECIFIED_BAD_HARD 42
                                             /* Specified number of NDIV is   */
                                             /* ignored because a different   */
                                             /* side line is already meshed   */
                                             /* or hard lesized with          */
                                             /* (a_params[0]) divisions.      */
#define VSWEEP_ELEM_ORDER_INCONSISTENT 43
															/* To obtain consistent meshes   */
															/* when two volumes are neighbur */
                                             /* to each other and to be meshed*/
															/* to different order elements,  */
															/* mesh the volume with lower    */
															/* order element first.          */
#define VSWEEP_OVERCONSTRAINED_FOR_MAPPING 44  /* the following surface(s) is overconstrained for mapped meshing.  The surface(s) will be free meshed*/
#define VSWEEP_LINE_BIAS_WARNING           45 /* two lines one with bais and one without might be a problem */


/* ========================================================================== */
/* === error ids for subprocess COPY_MESH.  These identifiers are sent to 
   === FEMe_Error as the errorid argument. */

#define COPY_MESH_UNKNOWN_ERROR         1 /* FATAL ERROR                      */
#define COPY_MESH_ALREADY_INITIALIZED   2 /* WARNING THAT FATAL ERROR MAY     */
                                          /* HAVE HAPPENED Check mesh         */
                                          /* carefully.                       */
#define COPY_MESH_DIFFERENT_AREAS       3 /* Cannot copy mesh from area       */
                                          /* a_params[0] to area a_params[1]  */
                                          /* because the shape of the two     */
                                          /* areas is too different.          */
#define COPY_MESH_TRG_HARDPOINT         4 /* Cannot copy mesh from area       */
                                          /* a_params[0] to area a_params[1]  */
                                          /* because area a_params[2] has     */
                                          /* hardpoints.                      */
#define COPY_MESH_TRG_QUALITY_FAILED    5 /* copied trg mesh failed to pass quality check.   */
                                          /* The target area a_params[0] need some help to mesh */
#define COPY_MESH_TRG_NOT_SUITABLE      6 /* The source mesh is not able to correctly copied to the target the surface */
/* ========================================================================== */
/* === error ids for subprocess QMAP.  These identifiers are sent to 
   === FEMe_Error as the errorid argument. */

#define QMAP_UNKNOWN_ERROR           1 /* FATAL_ERROR                         */
#define QMAP_CANT_PARAMETERIZE       2 /* Area a_params[0] cannot be mapped   */
                                       /* meshed with the specified bnd divs. */
#define QMAP_NOT_ENOUGH_LINES        3 /* Area a_params[0] has no enough lines*/
#define QMAP_NARROW_CHANNEL          4 /* Area a_params[0] is a narrow channel*/


/* ========================================================================== */
/* === error ids for subprocess AREA_MESH.  These identifiers are sent to 
   === FEMe_Error as the errorid argument. */

#define AMESH_UNKNOWN_ERROR          1  /* FATAL ERROR                        */
#define AMESH_TOO_COARSE             2  /* The element sizing specifications  */
                                        /* on a particular line are too coarse*/
                                        /* to produce a good mesh.  This      */
                                        /* normally only happens when meshing */
                                        /* a periodic surface.  a_params[0] is*/
                                        /* the id of the line that needs finer*/
                                        /* element sizing.  a_params[1] is the*/
                                        /* minimum number of edges that should*/
                                        /* be on this line.                   */
#define AMESH_TOO_FEW_BND_EDGES_TRI  3  /* The total number of edges on all   */
                                        /* the lines defining an area is not  */
                                        /* enough to mesh the area with tris. */
                                        /* (i.e., the boundary only has 2     */
                                        /* boundary loops when 3 is the       */
                                        /* minimum for a tri mesh.)           */
                                        /* a_params[0] is the area id that    */
                                        /* cannot be meshed.                  */
#define AMESH_TOO_FEW_BND_EDGES_QUAD 4  /* The total number of edges on all   */
                                        /* the lines defining an area is not  */
                                        /* enough to mesh the area with quad. */
                                        /* (i.e., the boundary only has 2     */
                                        /* boundary loops when 4 is the       */
                                        /* minimum for a quad mesh.)          */
                                        /* a_params[0] is the area id that    */
                                        /* cannot be meshed.                  */
#define AMESH_INTERSECTING_FRONTS    5  /* The intial fronts are intersecting */
                                        /* within a tolerance.  Change        */
                                        /* boundary divisions                 */
#define AMESH_NO_SUPPORT_TOPO        6  /* The topology of area a_params[0]   */
                                        /* is not supported by the mesher.    */
#define AMESH_NO_SIZE_INFO           7  /* Not enough sizing information is   */
                                        /* provided with area a_params[0].    */
                                        /* Specify a flat elem size in        */
                                        /* FEM_globals.h and try again.       */
#define AMESH_QUAD_FAILURE           8  /* The quad mesher failed on area     */
                                        /* a_params[0].  Change               */
                                        /* the element size parameters and    */
                                        /* try again, or use a different quad */
                                        /* mesher.                            */
#define AMESH_TRI_FAILURE            9  /* The tri mesher failed on area      */
                                        /* a_params[0].  Change the           */
                                        /* element size parameters and try    */
                                        /* again, or use a different quad     */
                                        /* mesher.                            */
#define AMESH_CLEAN_FAILURE         10  /* The initial meshing process        */
                                        /* succeeded on area a_params[0], but */
                                        /* an error occured                   */
                                        /* while post processing the mesh to  */
                                        /* improve element quality.  Change   */
                                        /* the element size parameters and    */
                                        /* try again, or turn topo cleanup    */
                                        /* off using                          */
                                        /* FEM_glSetTopoCleanInMesher().      */
#define AMESH_SPHERE_QUAD           11  /* quad mesh fail on sphere surface */


/* ========================================================================== */
/* === error ids for subprocess CHK_FACETS.  These identifiers are sent to 
   === FEMe_Error as the errorid argument. */

#define CHKF_LN_EDGE       1    /* The volume a_params[0] cannot be meshed.   */
                                /* More than 2 surface elements share a       */
                                /* common edge.  Check line a_params[1] on    */
                                /* volume a_params[2].                        */
#define CHKF_KP_EDGE       2    /* The volume a_params[0] cannot be meshed.   */
                                /* More than 2 surface elements share a       */
                                /* common edge.  Check kp a_params[1] on      */
                                /* volume a_params[2].                        */
#define CHKF_AR_EDGE       3    /* The volume a_params[0] cannot be meshed.   */
                                /* More than 2 surface elements share a       */
                                /* common edge.  Check area a_params[1] on    */
                                /* volume a_params[2].                        */
#define CHKF_VL_EDGE       4    /* The volume a_params[0] cannot be meshed.   */
                                /* More than 2 surface elements share a       */
                                /* common edge.  Check volume a_params[1] on  */
                                /* volume a_params[2].                        */
#define CHKF_GAP_LN        5    /* The volume a_params[0] cannot be meshed.   */
                                /* A gap between triangle facets was detected.*/
                                /* Check line a_params[1] on volume           */
                                /* a_params[2].                               */
#define CHKF_GAP_KP        6    /* The volume a_params[0] cannot be meshed.   */
                                /* A gap between triangle facets was detected.*/
                                /* Check kp a_params[1] on volume             */
                                /* a_params[2].                               */
#define CHKF_GAP_AR        7    /* The volume a_params[0] cannot be meshed.   */
                                /* A gap between triangle facets was detected.*/
                                /* Check area a_params[1] on volume           */
                                /* a_params[2].                               */
#define CHKF_GAP_VL        8    /* The volume a_params[0] cannot be meshed.   */
                                /* A gap between triangle facets was detected.*/
                                /* Check volume a_params[1] on volume         */
                                /* a_params[2].                               */
#define CHKF_NL_SMALL      9    /* Volume a_params[0] cannot be meshed.       */
                                /* Number of lines for cell checking is too   */
                                /* small found in facet pre-checking.         */
#define CHKF_INTRS         10   /* Volume a_params[0] cannot be meshed.       */
                                /* a_params[1] intersection(s) found between  */
                                /* triangle facets defined on the boundary    */
                                /* areas.  Try reducing the element size and  */
                                /* remeshing.                                 */
                                /* Intersections occurs near a_params[2] id   */
                                /* a_params[3].                               */
                                /*  NOTE: if a_params[2] == 1, a_params[3] is */
                                /*        a kp id. If a_params[2] == 2,       */
                                /*        a_params[3] is a line id.  If       */
                                /*        a_params[2] == 3, a_params[3] is an */
                                /*        area id.  If a_params[2] == 4,      */
                                /*        a_params[3] is a volume id.         */
#define CHKF_TOUCH         11   /* Volume a_params[0] cannot be meshed.       */
                                /* a_params[1] location(s) found where        */
                                /* non-adjacent boundary triangles touch.     */
                                /* Geometry configuration may not be valid or */
                                /* smaller element size definition may be     */
                                /* required.                                  */
                                /* Touching occurs near a_params[2] id        */
                                /* a_params[3].                               */
                                /*  NOTE: if a_params[2] == 1, a_params[3] is */
                                /*        a kp id. If a_params[2] == 2,       */
                                /*        a_params[3] is a line id.  If       */
                                /*        a_params[2] == 3, a_params[3] is an */
                                /*        area id.  If a_params[2] == 4,      */
                                /*        a_params[3] is a volume id.         */
#define CHKF_ANG_ABORT     12   /* Volume mesh aborted.  a_params[0] angles   */
                                /* less than a_params[1] degrees found in     */
                                /* triangle facets of volume a_params[2],     */
                                /* with smallest angle = a_params[3] degrees. */
                                /* A smaller element size specification may   */
                                /* give better results.                       */
#define CHKF_ANG           13   /* a_params[0] angles less than a_params[1]   */
                                /* degrees found in triangle facets of volume */
                                /* a_params[2], with smallest angle =         */
                                /* a_params[3] degrees.  Poor element quality */
                                /* or mesh failure may result.  A smaller     */
                                /* element size specification may give better */
                                /* results.                                   */

/* ========================================================================== */
/* === error ids for subprocess HARD_POINTS.  These identifiers are sent to 
   === FEMe_Error as the errorid argument. */

#define HDPOINTS_UNKNOWN_ERROR 1 /* FATAL ERROR                               */
#define HDPOINTS_CANT_INSERT   2 /* Hardpoint a_params[0] cannot be inserted  */
                                 /* into area a_params[1].  Specify a smaller */
                                 /* element size for this area then try again */
#define HDPTS_BAD_NODE_ID      3 /* */

/* ========================================================================== */
/* === error ids for subprocess MORPH.  These identifiers are sent to
   === FEMe_Error as the errorid argument. */

#define MORPH_UNKNOWN_ERROR 1    /* FATAL ERROR                               */
#define MORPH_NON_PLANAR    2    /* All selected elements must non-planar.    */
                                 /* DEMORPH command is ignored                */
#define MORPH_NON_TET_REMESH 3   /* Can't remesh non-tet elements             */
#define MORPH_NOMIXED       4    /* Can't morph a mixed tet-hex mesh          */
#define MORPH_NOAREAELEMS   5    /* no area elements detected                 */
#define MORPH_NOVOLUMEELEMS 6    /* no volume elements detected               */
#define MORPH_SHAPETESTFAIL 7    /* Can't pass the shape test                 */
#define MORPH_TRI_CREATED   8    /* triangle created                          */

/* ========================================================================== */
/* === error ids for subprocess MORPH.  These identifiers are sent to
   === FEMe_Error as the errorid argument. */

#define SMRTSIZE_UNKNOWN_ERROR 1    /* FATAL ERROR                            */
#define SMRTSIZE_MAPMESHKEY    2    /* All selected elements must non-planar. */
#define SMRTSIZE_NDIVSMARTON   3    /* ESIZE, NDIV is ignored                 */
#define SMRTSIZE_AREASTRESS    4    /* Smartsizing is not used due to stress  */
#define SMRTSIZE_SIZEDETERM    5    /* Abort during default size determination*/
#define SMRTSIZE_NOAREAS       6    /* No areas to mesh                       */
#define SMRTSIZE_ELEMAATT      7    /* Element type can't be used             */
#define SMRTSIZE_ELEMTYPEBAD   8    /* Element type bad for command           */
#define SMRTSIZE_NOFREEMESH    9    /* Element can't be free meshed           */
#define SMRTSIZE_NOVOLDEF     10    /* VMES called, but no defined volumes    */
#define SMRTSIZE_SZFCTRLEM    11    /* Problem with sizing factor in EsizeMax */
#define SMRTSIZE_NOGEOVOL     12    /* No geometric volume found              */
#define SMRTSIZE_MINDIVISIONS 13    /* Min divisions controls EsizeMax        */
#define SMRTSIZE_SMALLLINES   14    /* Possible mesh failure -> small lines   */
#define SMRTSIZE_SMALLANG1    15    /* Error #1 in small angle checking       */
#define SMRTSIZE_SMALLANG2    16    /* Error #2 in small angle checking       */
#define SMRTSIZE_SMALLANG3    17    /* Error #3 in small angle checking       */
#define SMRTSIZE_SMALLANG4    18    /* Error #4 in small angle checking       */
#define SMRTSIZE_SMALLANG5    19    /* Error #5 in small angle checking       */
#define SMRTSIZE_SMALLANG6    20    /* Error #6 in small angle checking       */
#define SMRTSIZE_SMALLANG7    21    /* Error #7 in small angle checking       */
#define SMRTSIZE_SMALLANG8    22    /* Error #8 in small angle checking       */
#define SMRTSIZE_PROJECT1     23    /* Error in projections                   */
#define SMRTSIZE_PROJECTMOVED 24    /* Projection moved point too far         */
#define SMRTSIZE_LENGTHVECTOR 25    /* Length vector found in angle checking  */
#define SMRTSIZE_LENGTHVECTOR2 26   /* Length vector 2 found in angle check   */
#define SMRTSIZE_LENGTHVECTOR3 27   /* Length vector 3 found in angle check   */
#define SMRTSIZE_LENGTHVECTOR4 28   /* Length vector 4 found in angle check   */
#define SMRTSIZE_SMALLANG9    29    /* Error #9 in small angle checking       */
#define SMRTSIZE_SMALLANG10   30    /* Error #10 in small angle checking      */
#define SMRTSIZE_PROJECT2     31    /* Error #2 in projections in LmeshSmlAng */
#define SMRTSIZE_PROJECT3     32    /* Error #3 in projections in LmehsSmlAng */
#define SMRTSIZE_SMALLANG11   33    /* Error #11 in small angle checking      */
#define SMRTSIZE_COARSEMESH   34    /* Mesh may be too coarse                 */
#define SMRTSIZE_COARSEMESH2  35    /* 1 small angle, mesh may be too coarse  */
#define SMRTSIZE_SMALLANG12   36    /* Error#12 in small angle checking       */
#define SMRTSIZE_NOAREAONLINE 37    /* No areas defines on line               */

#endif

