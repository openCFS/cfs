/* 
 *  CadoeAnsys.h -- some common definitions for the Cadoe/Ansys product
 *
 *  |Auteur: Frederic Thevenon
 *
 *  |Version: $Id: CadoeAnsys.h 478865 2011-05-30 15:11:33Z ftheveno $
 */
 
#ifndef __CADOEANSYS_H__
#define __CADOEANSYS_H__ 1
#include "cadoe_int.h"
#include "cwrap_ansys.h"
#include "globals.h"

/* matrix code */
#define MATA_CPLX 1
#define MATK_REAL 2
#define MATC_REAL 3
#define MATM_REAL 4
#define MATK_CPLX 5
#define MATH_REAL 6
#define MATG_REAL 7
#define VECg	  8
#define VECF	  9
#define VECFI	  10
#define BACK	  11
#define FORWARD	  12

/* WR Ansys Keys */

#define WR_PRINT	1
#define WR_OUTPUT	2
#define WR_MASTEROUT	4
#define WR_COLINTER	5
#define WR_COLBATCH	6
#define WR_LINEINTER	7
#define WR_LINEBATCH	8
#define WR_CHARITEM	11
#define WR_CHARDECIMAL	12
#define	WR_CHARINTEGER	13
#define WR_CHARTYPE	14
#define WR_SUPTITLE	16
#define WR_SUPSUPTITLE	17
#define WR_SUPLSITER	18
#define WR_NOTELINE	19
#define WR_SUPCOLHEADER	20
#define WR_SUPCOLMAX	21
#define WR_LISTOPT	22

/* execution status checking macros. */
#define CHKIER { if (*ier != SUCCES) { Trace(fctn);}
#define CHKIERV if (*ier != SUCCES)  { Trace(fctn); return;}
#define CHKIERS if (ier != SUCCES )  { Trace(fctn); return ECHEC;}
#define CHKIERT if (*ier != SUCCES ) { Trace(fctn); return ECHEC;}
#define CHKIERP if (*ier != SUCCES ) { Trace(fctn); return NULL;}
#define CHKIERN if (ier != SUCCES )  { Trace(fctn); return NULL;}
#define CHKIERQ if (*ier != SUCCES ) { Trace(fctn); return 0;}

#ifdef __cplusplus
#define READERR	 if (ier!=SUCCES) CADOE_THROW(E_CreadFailed);
#define WRITEERR if (ier!=SUCCES) CADOE_THROW(E_CwriteFailed);
#define BVECERR  if (ier!=SUCCES) CADOE_THROW(E_BvecError);
#define IVECERR  if (ier!=SUCCES) CADOE_THROW(E_IvecError);
#define VECERR   if (ier!=SUCCES) CADOE_THROW(E_VecError);
#define MSOERR   if (ier!=SUCCES) CADOE_THROW(E_MsoError);
#define VTAERR   if (ier!=SUCCES) CADOE_THROW(E_VtaError);
#endif

#define DB_NUMDEFINED 12
#define DB_NUMSELECTED 13
#define DB_MAXDEFINED 14
#define DB_MAXRECLENG 15
#define DB_GETNEXTRECD 16
#define DB_SELECTED 1

// ===== values for extopt
#define EXT_REDUCE	0
#define EXT_SSI		1
#define EXT_LANSYMundoc 2
#define EXT_UNSYM	3
#define EXT_DAMPED	4
#define EXT_BLOCundoc	5
#define EXT_LANB	6
#define EXT_QRDAMP	7
#define EXT_SNODE	8
#define EXT_LANPCG	9

// ===== values for SolveMethod ( As listed in soptcm.inc)

#define SV_FRONT	0
#define SV_JCG		1
#define SV_JCGOUT	2
#define SV_PCG		3
#define SV_PCGOUT	4
#define SV_ICCG		5
#define SV_ICCGOUT	6
#define SV_JCGNEW	7
#define SV_SPARSE	8
#define SV_USER		9
#define SV_AMG		10
#define SV_DOMAIN	11
#define SV_QMR          15
#define SV_MKLDSS	16

// ===== values for syspar.inc
#define LENNAM 248
#define LENEXT 8
#define LENFNM 260

// ===== values for SparseSolveMethod ( As listed in soptcm.inc)

// #define BCS_SPARSE	1
// #define DSP_SPARSE	2
// #define ISP_SPARSE	3

// ===== values for SolveCode ( As listed in soptcm.inc)

#define SV_ANSYS    0 
#define SV_CASI     1
#define SV_ITER     2 

// ===== Infos to extract from the Full Fil Header

#define FULL_UNIT	1
#define FULL_NEQN	2
#define FULL_NBCS	3
#define	FULL_NMATX	4
#define FULL_KAN	5
#define FULL_WFMAX	6
#define FULL_NNODE	7
#define FULL_NDOFNODE	8
#define FULL_NTERM	9
#define FULL_LUMPMASS	11
#define FULL_UNSYM	14
#define FULL_EXTOPT	15
#define FULL_KEYSE	16
#define FULL_NCEFULL	21

#if defined(LOWERCASENOUNDER_SYS)
#define mapVector		mapvector
#define recoverSlaveDof		recoverslavedof
#define recoverBcDof		recoverbcdof
#define pardef			pardef
#define parevl			parevl
#define arnoldiout4		arnoldiout4
#define modstr			modstr
#define mfldex			mfldex
#define resopn			resopn
#define resini			resini
#define resclo			resclo
#define SortCSRMatD		sortcsrmatd
#define SortCSRMatZ		sortcsrmatz
#define gname			gname
#define largeIntGet		largeintget
#define largeIntPut		largeintput
#define ReadFullHeader		readfullheader
#define compressFactor		compressfactor
#define InitFullHarmonicVT	initfullharmonicvt
#define FullHarmonicVT		fullharmonicvt
#define FullHarmonicVTPost	fullharmonicvtpost
#define FullHarmonicSolvePost   fullharmonicsolvepost
#define PostFullHarmonicVT	postfullharmonicvt
#define EndFullHarmonicVT	endfullharmonicvt
#define segnodall		segnodall
#define lire_nb_mode 		lire_nb_mode
#define lire_freq_mode 		lire_freq_mode
#define fx_ls_resid	       	fx_ls_resid
#define fx_nm_resid	       	fx_nm_resid
#define cadoe_bacsub	       	cadoe_bacsub
#define cadoe_getBCdispReal	cadoe_get_bcdispreal
#define svkan	               	svkan
#define svkan2	               	svkan2
#define svkan3	               	svkan3
#define svkan3_cadoe		svkan3_cadoe
#define liresol	               	liresol
#define cadoe_nb_supp_pres      cadoe_nb_supp_pres
#define cadoe_list_supp_pres    cadoe_list_supp_pres
#define cadoe_nb_cpce           cadoe_nb_cpce
#define list_cpce		list_cpce
#define cadoe_list_cpce         cadoe_list_cpce
#define next_element	        next_element   	
#define sx_next_active_elem	sx_next_active_elem    	
#define sx_next_active_elem_pp	sx_next_active_elem_pp    	
#define indice_element	       	indice_element
#define out_stress	       	out_stress
#define out_strain	       	out_strain
#define out_force	       	out_force
#define out_tg	       		out_tg
#define out_tf	       		out_tf
#define out_b	       		out_b
#define out_h	       		out_h
#define out_jt	       		out_jt
#define out_fmag	       	out_fmag
#define out_mass	       	out_mass
#define sx_out_mass_init        sx_out_mass_init
#define get_epsi               	get_epsi
#define get_is_spring           get_is_spring
#define sxopenfull		sxopenfull
#define sxopenfulln		sxopenfulln
#define sxclosefull		sxclosefull
#define sxopenfullnew           sxopenfullnew
#define sxinquirefull           sxinquirefull
#define fx_stiff_part		fx_stiff_part
#define get_xyz               	get_xyz
#define sx_update_node          sx_update_node
#define fact_kmw2m              fact_kmw2m
#define elm_is_active_for_stress elm_is_active_for_stress
#define elm_is_active_for_force elm_is_active_for_force
#define elm_is_active_for_tg    elm_is_active_for_tg
#define elm_is_active_for_tf    elm_is_active_for_tf
#define elm_is_active_for_b    elm_is_active_for_b
#define elm_is_active_for_h    elm_is_active_for_h
#define elm_is_active_for_jt    elm_is_active_for_jt
#define elm_is_active_for_fmag    elm_is_active_for_fmag
#define dwdot                   dwdot
#define expandu                 expandu
#define ndpang                  ndpang
#define ndpxyz2					ndpxyz2
#define rigidbody		rigidbody
#define dgeev 			dgeev
#define sxgetfullinfo		sxgetfullinfo
#define getmapbcstoansys	getmapbcstoansys
#define sxgetforce		sxgetforce
#define sxgetmatbcs		sxgetmatbcs
#define SxUpdateContactKey      sxupdatecontactkey
#define SxSetActiveAllElemsKey  sxsetactiveallelemskey
#define SxGetActiveAllElemsKey  sxgetactiveallelemskey
#define SxGetInLoadValue	sxgetinloadvalue
#define SxInLoadUpd		sxinloadupd
#define putcadoeubuckling	putcadoeubuckling
#define csym_ceequalupd         csym_ceequalupd
#define csym_ceunequalupd       csym_ceunequalupd
#define csym_ceEqual            csym_ceequal
#define csym_ceUnEqual          csym_ceunequal
#define csym_ceUser             csym_ceuser
#define sectim                  sectim
#define TrackBegin              trackbegin
#define TrackEnd                trackend
#define pagend                  pagend
#define rfget                   rfget
#define fget                    fget
#define forget                  forget
#define RunCommand              runcommand
#define RunMacro		runmacro
#define wrinqr			wrinqr
#define wrinfo			wrinfo
#define CreateDOFmapsPCG	createdofmapspcg
#define sfform                  sfform
#define eqfadd                  eqfadd
#define derivativeCpGtU         derivativecpgtu
#define derivativeGtU           derivativegtu
#define init_speedup            init_speedup
#define free_speedup            free_speedup
#define enrichQ                 enrichq
#define minresQ                 minresq
#define fwend                   fwend
#define fwend2                  fwend2
#define clearSolverData         clearsolverdata
#define upddsp                  upddsp
#define lnstrt                  lnstrt
#define sx_copy_cnv_crit        sx_copy_cnv_crit    
#define sx_write_mat_elem       sx_write_mat_elem    
#define getFaceId               getfaceid 
#define cnvfor                  cnvfor 
#define sxgetcforce 		sxgetcforce
#define cadoe_getBCdisp         cadoe_getbcdisp 
#define harmExpandBCS           harmexpandbcs
#define sx_put_reac		sx_put_reac
#define sx_put_key_reac		sx_put_key_reac
#define sx_reac_init		sx_reac_init

#define reset_out		reset_out
#define lanbout4		lanbout4

#define mpinqr			mpinqr
#define ndinqr			ndinqr
#define mpget			mpget
#define fx_ls_extmodl		fx_ls_extmodl
#define fx_ls_solve		fx_ls_solve
#define fx_nm_solve		fx_nm_solve
#define fx_csnm_solve		fx_csnm_solve
#define nodbac			nodbac
#define ndgang			ndgang
#define ndgcn			ndgcn
#define ndgxyz			ndgxyz
#define elebac			elebac
#define elmget			elmget
#define etyget			etyget
#define rlget			rlget
#define elmiqr			elmiqr
#define cpinqr			cpinqr
#define ceinqr			ceinqr
#define cpget			cpget
#define ceget			ceget
#define ceput			ceput
#define cpput			cpput
#define disput			disput
#define disget			disget
#define sectinqr		sectinqr
#define ParTabChek		partabchek
#define lstcmd			lstcmd
#define ShellSection		shellsection
#define GetShellSecData		getshellsecdata
#define GetBeamAsecSecData	getbeamasecsecdata 
#define GetShellLayerTh		getshelllayerth
#define GetShellLayerAngle	getshelllayerangle
#define get_cmp_iname		get_cmp_iname
#define cmpsel			cmpsel
#define cmplocDB		cmplocdb
#define cmpiqrDB		cmpiqrdb
#define cmpiqrDBL		cmpiqrdbl
#define cmpnxtDB		cmpnxtdb
#define cmpnxtDBL		cmpnxtdbl
#define get_cmp_card		get_cmp_card
#define get_cmp_type		get_cmp_type
#define ndsel			ndsel
#define elsel			elsel
#define GetNbLayers		getnblayers
#define GetSectionMatIds	getsectionmatids
#define getsumnbnodes		getsumnbnodes
#define get_nnd_cont		get_nnd_cont
#define sx_store_hice		sx_store_hice
#define bcssl4			bcssl4
#define getBcsSolverKeys	getbcssolverkeys
#define getBcsModalKeys		getbcsmodalkeys
#define dumpBcsSolverKeys	dumpbcssolverkeys
#define printFreq		printfreq
#define fastSolve		fastsolve
#define initAnsCe		initansce
#define dspini			dspini
#define stphed			stphed
#define kwget			kwget
#define kwput                   kwput
#define writematrix		writematrix
#define parloc			parloc
#define parGetArray		pargetarray
#define systim			systim
#define sysyr			sysyr
#define DSPreadheader		dspreadheader
#define SX_InitElemList		sx_initelemlist
#define SX_setElemList		sx_setelemlist
#define SX_FreeElemList		sx_freeelemlist
#define GetDistributedFullFile  getdistributedfullfile
#define GetCurrentOutPutName	getcurrentoutputname
#define switchOutput		switchoutput
#define sxtb_getFrqRange	sxtb_getfrqrange
#define SX_InitBefAssemblyComp  sx_initbefassemblycomp
#define SX_FreeUpdate		sx_freeupdate
#define elec_load_frq		elec_load_frq
#define statBegin		statbegin
#define statEnd			statend
#define solveDBobjs             solvedbobjs
#define csym_ceSwitchSector     csym_ceswitchsector
#define dumpce                  dumpce
#define setSoluFlag		setsoluflag
#define nddefv			nddefv
#define ErrorMessageProbe	errormessageprobe
#define erinfo			erinfo
#define getjobinfo		getjobinfo
#endif

#if defined(UPPERCASENOUNDER_SYS)
#define mapVector		MAPVECTOR
#define recoverSlaveDof		RECOVERSLAVEDOF
#define recoverBcDof		RECOVERBCDOF
#define pardef			PARDEF
#define parevl			PAREVL
#define arnoldiout4		ARNOLDIOUT4
#define modstr			MODSTR
#define mfldex			MFLDEX
#define resopn			RESOPN
#define resini			RESINI
#define resclo			RESCLO
#define SortCSRMatD		SORTCSRMATD
#define SortCSRMatZ		SORTCSRMATZ
#define gname			GNAME
#define largeIntGet		LARGEINTGET
#define largeIntPut		LARGEINTPUT
#define ReadFullHeader		READFULLHEADER
#define compressFactor		COMPRESSFACTOR
#define InitFullHarmonicVT	INITFULLHARMONICVT
#define FullHarmonicVT		FULLHARMONICVT
#define FullHarmonicVTPost	FULLHARMONICVTPOST
#define FullHarmonicSolvePost   FULLHARMONICSOLVEPOST
#define PostFullHarmonicVT	POSTFULLHARMONICVT
#define EndFullHarmonicVT	ENDFULLHARMONICVT
#define segnodall		SEGNODALL
#define lire_nb_mode 		LIRE_NB_MODE
#define lire_freq_mode 		LIRE_FREQ_MODE
#define fx_ls_resid	       	FX_LS_RESID
#define fx_nm_resid	       	FX_NM_RESID
#define cadoe_bacsub	       	CADOE_BACSUB
#define cadoe_getBCdispReal	CADOE_GET_BCDISPREAL
#define svkan	               	SVKAN
#define svkan2	               	SVKAN2
#define svkan3	               	SVKAN3
#define svkan3_cadoe		SVKAN3_CADOE
#define liresol	               	LIRESOL
#define cadoe_nb_supp_pres      CADOE_NB_SUPP_PRES
#define cadoe_list_supp_pres    CADOE_LIST_SUPP_PRES
#define list_cpce		LIST_CPCE
#define cadoe_nb_cpce           CADOE_NB_CPCE
#define cadoe_list_cpce         CADOE_LIST_CPCE
#define next_element	        NEXT_ELEMENT   	
#define sx_next_active_elem	SX_NEXT_ACTIVE_ELEM
#define sx_next_active_elem_pp	SX_NEXT_ACTIVE_ELEM_PP
#define indice_element	       	INDICE_ELEMENT
#define out_stress	       	OUT_STRESS
#define out_strain	       	OUT_STRAIN
#define out_force	       	OUT_FORCE
#define out_tg   	       	OUT_TG   
#define out_tf   	       	OUT_TF   
#define out_b   	       	OUT_B   
#define out_h   	       	OUT_H   
#define out_jt   	       	OUT_JT   
#define out_fmag   	       	OUT_FMAG   
#define out_mass	       	OUT_MASS
#define sx_out_mass_init        SX_OUT_MASS_INIT
#define get_epsi               	GET_EPSI
#define get_is_spring           GET_IS_SPRING
#define sxopenfull		SXOPENFULL
#define sxopenfulln		SXOPENFULLN
#define sxclosefull		SXCLOSEFULL
#define sxopenfullnew           SXOPENFULLNEW
#define sxinquirefull           SXINQUIREFULL
#define fx_stiff_part		FX_STIFF_PART
#define get_xyz               	GET_XYZ
#define sx_update_node		SX_UPDATE_NODE
#define fact_kmw2m              FACT_KMW2M
#define elm_is_active_for_stress ELM_IS_ACTIVE_FOR_STRESS
#define elm_is_active_for_force ELM_IS_ACTIVE_FOR_FORCE
#define elm_is_active_for_tg    ELM_IS_ACTIVE_FOR_TG
#define elm_is_active_for_tf    ELM_IS_ACTIVE_FOR_TF
#define elm_is_active_for_b     ELM_IS_ACTIVE_FOR_B
#define elm_is_active_for_h     ELM_IS_ACTIVE_FOR_H
#define elm_is_active_for_jt    ELM_IS_ACTIVE_FOR_JT
#define elm_is_active_for_fmag  ELM_IS_ACTIVE_FOR_FMAG
#define dwdot                   DWDOT
#define expandu                 EXPANDU
#define ndpang                  NDPANG
#define ndpxyz2		       	NDPXYZ2
#define rigidbody		RIGIDBODY
#define dgeev 			DGEEV
#define sxgetfullinfo		SXGETFULLINFO
#define getmapbcstoansys	GETMAPBCSTOANSYS
#define sxgetforce		SXGETFORCE
#define sxgetmatbcs		SXGETMATBCS
#define SxUpdateContactKey      SXUPDATECONTACTKEY
#define SxSetActiveAllElemsKey  SXSETACTIVEALLELEMSKEY
#define SxGetActiveAllElemsKey  SXGETACTIVEALLELEMSKEY
#define SxGetInLoadValue	SXGETINLOADVALUE
#define SxInLoadUpd		SXINLOADUPD
#define putcadoeubuckling	PUTCADOEUBUCKLING
#define csym_ceequalupd         CSYM_CEEQUALUPD
#define csym_ceunequalupd       CSYM_CEUNEQUALUPD
#define csym_ceEqual            CSYM_CEEQUAL
#define csym_ceUnEqual          CSYM_CEUNEQUAL
#define csym_ceUser             CSYM_CEUSER
#define sectim                  SECTIM
#define TrackBegin              TRACKBEGIN
#define TrackEnd                TRACKEND
#define pagend                  PAGEND
#define rfget                   RFGET
#define fget                    FGET
#define forget                  FORGET
#define RunCommand              RUNCOMMAND
#define RunMacro		RUNMACRO
#define wrinqr			WRINQR
#define wrinfo			WRINFO
#define CreateDOFmapsPCG	CREATEDOFMAPSPCG
#define sfform                  SFFORM
#define eqfadd                  EQFADD
#define derivativeCpGtU         DERIVATIVECPGTU
#define derivativeGtU           DERIVATIVEGTU
#define init_speedup            INIT_SPEEDUP
#define free_speedup            FREE_SPEEDUP
#define enrichQ                 ENRICHQ
#define minresQ                 MINRESQ
#define fwend                   FWEND
#define fwend2                  FWEND2
#define clearSolverData         CLEARSOLVERDATA
#define upddsp                  UPDDSP
#define lnstrt                  LNSTRT
#define sx_write_mat_elem       SX_WRITE_MAT_ELEM    
#define sx_copy_cnv_crit        SX_COPY_CNV_CRIT    
#define getFaceId               GETFACEID   
#define cnvfor                  CNVFOR 
#define sxgetcforce 		SXGETCFORCE
#define cadoe_getBCdisp 	CADOE_GETBCDISP
#define harmExpandBCS           HARMEXPANDBCS
#define sx_put_reac		SX_PUT_REAC
#define sx_put_key_reac		SX_PUT_KEY_REAC
#define sx_reac_init		SX_REAC_INIT

#define reset_out		RESET_OUT
#define lanbout4		LANBOUT4

#define mpinqr			MPINQR
#define ndinqr			NDINQR
#define mpget			MPGET
#define fx_ls_extmodl		FX_LS_EXTMODL
#define fx_ls_solve		FX_LS_SOLVE
#define fx_nm_solve		FX_NM_SOLVE
#define fx_csnm_solve		FX_CSNM_SOLVE
#define nodbac			NODBAC
#define ndgang			NDGANG
#define ndgcn			NDGCN
#define ndgxyz			NDGXYZ
#define elebac			ELEBAC
#define elmget			ELMGET
#define etyget			ETYGET
#define rlget			RLGET
#define elmiqr			ELMIQR
#define cpinqr			CPINQR
#define ceinqr			CEINQR
#define cpget			CPGET
#define ceget			CEGET
#define ceput			CEPUT
#define cpput			CPPUT
#define disput			DISPUT
#define disget			DISGET
#define sectinqr		SECTINQR
#define ParTabChek     		PARTABCHEK
#define lstcmd			LSTCMD
#define ShellSection		SHELLSECTION
#define GetShellSecData		GETSHELLSECDATA
#define GetBeamAsecSecData	GETBEAMASECSECDATA 
#define GetShellLayerTh		GETSHELLLAYERTH
#define GetShellLayerAngle	GETSHELLLAYERANGLE
#define get_cmp_iname		GET_CMP_INAME
#define cmpsel			CMPSEL
#define cmpiqrDB		CMPIQRDB
#define cmpiqrDBL		CMPIQRDBL
#define cmplocDB		CMPLOCDB
#define cmpnxtDB		CMPNXTDB
#define cmpnxtDBL		CMPNXTDBL
#define get_cmp_card		GET_CMP_CARD
#define get_cmp_type		GET_CMP_TYPE
#define ndsel			NDSEL
#define elsel	       		ELSEL
#define GetNbLayers		GETNBLAYERS
#define GetSectionMatIds	GETSECTIONMATIDS
#define getsumnbnodes		GETSUMNBNODES
#define get_nnd_cont		GET_NND_CONT
#define sx_store_hice		SX_STORE_HICE
#define bcssl4			BCSSL4
#define getBcsSolverKeys	GETBCSSOLVERKEYS
#define getBcsModalKeys		GETBCSMODALKEYS
#define dumpBcsSolverKeys	DUMPBCSSOLVERKEYS
#define printFreq		PRINTFREQ
#define fastSolve		FASTSOLVE
#define initAnsCe		INITANSCE
#define dspini			DSPINI
#define stphed			STPHED
#define kwget		 	KWGET
#define kwput                   KWPUT
#define writematrix		WRITEMATRIX
#define parloc			PARLOC
#define parGetArray		PARGETARRAY
#define systim			SYSTIM
#define sysyr			SYSYR
#define DSPreadheader		DSPREADHEADER
#define SX_InitElemList		SX_INITELEMLIST
#define SX_setElemList		SX_SETELEMLIST
#define SX_FreeElemList		SX_FREEELEMLIST
#define GetDistributedFullFile  GETDISTRIBUTEDFULLFILE
#define GetCurrentOutPutName	GETCURRENTOUTPUTNAME
#define switchOutput		SWITCHOUTPUT
#define sxtb_getFrqRange	SXTB_GETFRQRANGE
#define SX_InitBefAssemblyComp	SX_INITBEFASSEMBLYCOMP
#define SX_FreeUpdate		SX_FREEUPDATE
#define elec_load_frq		ELEC_LOAD_FRQ
#define statBegin		STATBEGIN
#define statEnd			STATEND
#define solveDBobjs             SOLVEDBOBJS
#define csym_ceSwitchSector     CSYM_CESWITCHSECTOR
#define dumpce                  DUMPCE
#define setSoluFlag		SETSOLUFLAG
#define nddefv			NDDEFV
#define ErrorMessageProbe	ERRORMESSAGEPROBE
#define erinfo			ERINFO
#define getjobinfo		GETJOBINFO
#endif

#if defined(LOWERCASEUNDER_SYS)
#define mapVector		mapvector_
#define recoverSlaveDof		recoverslavedof_
#define recoverBcDof		recoverbcdof_
#define pardef			pardef_
#define parevl			parevl_
#define arnoldiout4		arnoldiout4_
#define modstr			modstr_
#define mfldex			mfldex_
#define resopn			resopn_
#define resini			resini_
#define resclo			resclo_
#define SortCSRMatD		sortcsrmatd_
#define SortCSRMatZ		sortcsrmatz_
#define gname			gname_
#define largeIntGet		largeintget_
#define largeIntPut		largeintput_
#define ReadFullHeader		readfullheader_
#define compressFactor		compressfactor_
#define InitFullHarmonicVT	initfullharmonicvt_
#define FullHarmonicVT		fullharmonicvt_
#define FullHarmonicVTPost	fullharmonicvtpost_
#define FullHarmonicSolvePost   fullharmonicsolvepost_
#define PostFullHarmonicVT	postfullharmonicvt_
#define EndFullHarmonicVT	endfullharmonicvt_
#define segnodall		segnodall_
#define lire_nb_mode 		lire_nb_mode_
#define lire_freq_mode 		lire_freq_mode_
#define fx_ls_resid		fx_ls_resid_
#define fx_nm_resid		fx_nm_resid_
#define cadoe_bacsub		cadoe_bacsub_
#define cadoe_getBCdispReal	cadoe_getbcdispreal_
#define svkan		        svkan_
#define svkan2		        svkan2_
#define svkan3		        svkan3_
#define svkan3_cadoe		svkan3_cadoe_
#define liresol		        liresol_
#define cadoe_nb_supp_pres	cadoe_nb_supp_pres_
#define cadoe_list_supp_pres	cadoe_list_supp_pres_
#define list_cpce	        list_cpce_
#define cadoe_nb_cpce	        cadoe_nb_cpce_
#define cadoe_list_cpce	        cadoe_list_cpce_
#define next_element            next_element_
#define sx_next_active_elem	sx_next_active_elem_
#define sx_next_active_elem_pp	sx_next_active_elem_pp_
#define indice_element	       	indice_element_
#define out_stress		out_stress_
#define out_strain		out_strain_
#define out_force		out_force_
#define out_tg   		out_tg_
#define out_tf   		out_tf_
#define out_b   		out_b_
#define out_h   		out_h_
#define out_jt   		out_jt_
#define out_fmag   		out_fmag_
#define out_mass		out_mass_
#define sx_out_mass_init        sx_out_mass_init_
#define get_epsi                get_epsi_
#define get_is_spring           get_is_spring_
#define sxopenfull		sxopenfull_
#define sxopenfulln		sxopenfulln_
#define sxclosefull		sxclosefull_
#define sxopenfullnew           sxopenfullnew_
#define sxinquirefull           sxinquirefull_
#define fx_stiff_part		fx_stiff_part_
#define get_xyz                 get_xyz_
#define sx_update_node		sx_update_node_
#define fact_kmw2m              fact_kmw2m_
#define elm_is_active_for_stress elm_is_active_for_stress_
#define elm_is_active_for_force elm_is_active_for_force_
#define elm_is_active_for_tg    elm_is_active_for_tg_
#define elm_is_active_for_tf    elm_is_active_for_tf_
#define elm_is_active_for_b     elm_is_active_for_b_
#define elm_is_active_for_h     elm_is_active_for_h_
#define elm_is_active_for_jt    elm_is_active_for_jt_
#define elm_is_active_for_fmag  elm_is_active_for_fmag_
#define dwdot                   dwdot_
#define expandu                 expandu_
#define ndpang                  ndpang_
#define ndpxyz2	       		ndpxyz2_
#define rigidbody		rigidbody_
#define dgeev 			dgeev_
#define sxgetfullinfo		sxgetfullinfo_
#define getmapbcstoansys	getmapbcstoansys_
#define sxgetforce		sxgetforce_
#define sxgetmatbcs		sxgetmatbcs_
#define SxUpdateContactKey      sxupdatecontactkey_
#define SxSetActiveAllElemsKey  sxsetactiveallelemskey_
#define SxGetActiveAllElemsKey  sxgetactiveallelemskey_
#define SxGetInLoadValue	sxgetinloadvalue_
#define SxInLoadUpd		sxinloadupd_
#define putcadoeubuckling	putcadoeubuckling_
#define csym_ceequalupd         csym_ceequalupd_
#define csym_ceunequalupd       csym_ceunequalupd_
#define csym_ceEqual            csym_ceequal_
#define csym_ceUnEqual          csym_ceunequal_
#define csym_ceUser             csym_ceuser_
#define sectim                  sectim_
#define TrackBegin              trackbegin_
#define TrackEnd                trackend_
#define pagend                  pagend_
#define rfget                   rfget_
#define fget                    fget_
#define forget                  forget_
#define RunCommand              runcommand_
#define RunMacro		runmacro_
#define wrinqr			wrinqr_
#define wrinfo			wrinfo_
#define CreateDOFmapsPCG	createdofmapspcg_
#define sfform                  sfform_
#define eqfadd                  eqfadd_
#define derivativeCpGtU         derivativecpgtu_
#define derivativeGtU           derivativegtu_
#define init_speedup            init_speedup_
#define free_speedup            free_speedup_
#define enrichQ                 enrichq_
#define minresQ                 minresq_
#define fwend                   fwend_
#define fwend2                  fwend2_
#define clearSolverData         clearsolverdata_
#define upddsp                  upddsp_
#define lnstrt                  lnstrt_
#define sx_write_mat_elem       sx_write_mat_elem_   
#define sx_copy_cnv_crit        sx_copy_cnv_crit_    
#define getFaceId               getfaceid_ 
#define cnvfor                  cnvfor_
#define sxgetcforce 		sxgetcforce_
#define cadoe_getBCdisp 	cadoe_getbcdisp_
#define harmExpandBCS           harmexpandbcs_
#define sx_put_reac		sx_put_reac_
#define sx_put_key_reac		sx_put_key_reac_
#define sx_reac_init		sx_reac_init_

#define	reset_out		reset_out_
#define lanbout4		lanbout4_

#define mpinqr			mpinqr_
#define ndinqr			ndinqr_
#define mpget			mpget_
#define fx_ls_extmodl		fx_ls_extmodl_
#define fx_ls_solve		fx_ls_solve_
#define fx_nm_solve		fx_nm_solve_
#define fx_csnm_solve		fx_csnm_solve_
#define nodbac			nodbac_
#define ndgang			ndgang_
#define ndgcn			ndgcn_
#define ndgxyz			ndgxyz_
#define elebac			elebac_
#define elmget			elmget_
#define etyget			etyget_
#define rlget			rlget_
#define elmiqr			elmiqr_
#define cpinqr			cpinqr_
#define ceinqr			ceinqr_
#define cpget			cpget_
#define ceget			ceget_
#define ceput			ceput_
#define cpput			cpput_
#define disput			disput_
#define disget			disget_
#define sectinqr		sectinqr_
#define ParTabChek		partabchek_
#define lstcmd			lstcmd_
#define ShellSection		shellsection_
#define GetShellSecData		getshellsecdata_
#define GetBeamAsecSecData	getbeamasecsecdata_
#define GetShellLayerTh		getshelllayerth_
#define GetShellLayerAngle	getshelllayerangle_
#define get_cmp_iname		get_cmp_iname_
#define cmpsel			cmpsel_
#define cmplocDB		cmplocdb_
#define cmpiqrDB		cmpiqrdb_
#define cmpiqrDBL		cmpiqrdbl_
#define cmpnxtDB		cmpnxtdb_
#define cmpnxtDBL		cmpnxtdbl_
#define get_cmp_card		get_cmp_card_
#define get_cmp_type		get_cmp_type_
#define ndsel			ndsel_
#define elsel			elsel_
#define GetNbLayers		getnblayers_
#define GetSectionMatIds	getsectionmatids_
#define getsumnbnodes		getsumnbnodes_
#define get_nnd_cont		get_nnd_cont_
#define sx_store_hice		sx_store_hice_
#define bcssl4			bcssl4_
#define getBcsSolverKeys	getbcssolverkeys_
#define getBcsModalKeys		getbcsmodalkeys_
#define dumpBcsSolverKeys	dumpbcssolverkeys_
#define printFreq		printfreq_
#define fastSolve		fastsolve_
#define	initAnsCe		initansce_
#define dspini			dspini_
#define stphed			stphed_
#define kwget			kwget_
#define kwput                   kwput_
#define writematrix		writematrix_
#define parloc			parloc_
#define parGetArray		pargetarray_
#define systim			systim_
#define sysyr			sysyr_
#define DSPreadheader		dspreadheader_
#define SX_InitElemList		sx_initelemlist_ 
#define SX_setElemList		sx_setelemlist_
#define SX_FreeElemList		sx_freeelemlist_ 
#define GetDistributedFullFile	getdistributedfullfile_
#define GetCurrentOutPutName	getcurrentoutputname_
#define switchOutput		switchoutput_
#define sxtb_getFrqRange	sxtb_getfrqrange_
#define SX_InitBefAssemblyComp	sx_initbefassemblycomp_
#define SX_FreeUpdate		sx_freeupdate_
#define elec_load_frq		elec_load_frq_
#define statBegin		statbegin_
#define statEnd			statend_
#define solveDBobjs             solvedbobjs_
#define csym_ceSwitchSector     csym_ceswitchsector_
#define dumpce                  dumpce_
#define setSoluFlag		setsoluflag_
#define nddefv			nddefv_
#define ErrorMessageProbe	errormessageprobe_
#define erinfo			erinfo_
#define getjobinfo		getjobinfo_
#endif

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

  void	cwTrackBegin( char*);
  void	cwTrackEnd( char*);

  SUBROUTINE mapVector( INT *nVect, INT *inVecLeng, INT *outVecLeng, INT *invMapFlag, INT *mapVect, INT *cmplxFlag,
			double *dInVect, double *dOutVect, complex16_t *cxInVect, complex16_t *cxOutVect);

  SUBROUTINE recoverSlaveDof( INT *nload, INT *nceused, INT *neqnOnFile, INT *cmplxFlag, INT *SlaveDofs, 
			      DOUBLE *smallg, DOUBLE *smallgImg, DOUBLE *dAdrFull, complex16_t *cAdrFull);

  SUBROUTINE recoverBcDof( INT *nload, INT *neqnOnFile, INT *cmplxFlag, INT *BCdofs, DOUBLE *dAdrBC, 
			   complex16_t *cAdrBC, DOUBLE *dAdrFull, complex16_t *cAdrFull);

  SUBROUTINE pardef( FCHAR(cNameIn), INT *ctype, INT *nval, DOUBLE *subc, DOUBLE *valuein, 
		     INT *kerr, FCHAR(string) FCHARL(name_len) FCHARL(string_len));

  SUBROUTINE parevl( FCHAR(name), INT *nDim, DOUBLE *subc, INT *lvl, 
 		     DOUBLE *val, FCHAR(chValue), INT *kerr FCHARL(name_len) FCHARL(chValue_len));

  SUBROUTINE arnoldiout4( int *cmplxFlag, Hyper *RPhi, double *dFreqs, complex16_t *cFreqs, int *NModes,
			  int *LRKey, int *lumpmslocal, double *MassVectFULL, int *FullToBcs, int *FullToAns, 
			  double *DiagScale, int *BCSscl, double *massScaleFactor);

  SUBROUTINE modstr();
  SUBROUTINE mfldex( FCHAR(fext) FCHARL(fext_len));
  SUBROUTINE resopn( FCHAR(fext), INT * FCHARL(fext_len));
  SUBROUTINE resini( INT *);
  SUBROUTINE resclo();

  SUBROUTINE SortCSRMatD( int *nEqn, int *nbz, int *unsym, Hyper *Rows, int *ColNum, double *Vals);
  SUBROUTINE SortCSRMatZ( int *nEqn, int *nbz, int *unsym, Hyper *Rows, int *ColNum, complex16_t *Vals);

  SUBROUTINE	gname ( char *fullnm, char *LocName, int *kext);
  Hyper FUNCTION largeIntGet( int *, int *);
  SUBROUTINE largeIntPut( Hyper *, int *, int *);
  SUBROUTINE ReadFullHeader( INT *matid, INT *what, INT *I_info, Hyper *L_info);
  DOUBLE FUNCTION compressFactor(void);
  INT FUNCTION InitFullHarmonicVT( Hyper *VTSession);
  INT FUNCTION FullHarmonicVT( Hyper *VTSession);
  INT FUNCTION FullHarmonicVTPost( Hyper *VTSession, DOUBLE *freq, DOUBLE *solution);
  INT FUNCTION FullHarmonicSolvePost(DOUBLE *freq);
  INT FUNCTION PostFullHarmonicVT( Hyper *VTSession);
  INT FUNCTION EndFullHarmonicVT( Hyper *VTSession);
  SUBROUTINE fx_ls_extmodl( INT *ier );
  SUBROUTINE fx_nm_solve( INT *ier, INT *nb_ddl, INT *restrt_f, INT *where_f,
			  INT *kdone_f);
  SUBROUTINE lire_nb_mode( INT *nb_mode );
  SUBROUTINE lire_freq_mode( DOUBLE*, DOUBLE*, INT*, INT *, INT *);
  SUBROUTINE fx_ls_resid( DOUBLE*, DOUBLE*, DOUBLE*, INT*, INT*, INT*);
  SUBROUTINE fx_nm_resid( DOUBLE*, DOUBLE*, DOUBLE* , INT*);
  SUBROUTINE cadoe_bacsub( INT*, DOUBLE*, DOUBLE*, INT *, INT *, INT *, INT *);
  SUBROUTINE cadoe_getBCdispReal(INT *nb_ddl, DOUBLE *X);
  SUBROUTINE svkan(INT *restrt);
  SUBROUTINE svkan2( INT *restrt, INT *where, INT *kdone, INT *ier);
  SUBROUTINE svkan3( INT *restrt);
  SUBROUTINE svkan3_cadoe(INT *restrt, INT *cadoe_pass);
  SUBROUTINE liresol(DOUBLE *U);
  SUBROUTINE cadoe_nb_supp_pres(INT *nb_supp, INT *nb_pres);
  SUBROUTINE cadoe_list_supp_pres(INT *list_supp, INT *list_pres, 
				  DOUBLE *val_pres);
  SUBROUTINE list_cpce(INT *list_cpce);
  SUBROUTINE cadoe_nb_cpce(INT *nb_cpce);
  SUBROUTINE cadoe_list_cpce(INT *list_cpce);
  SUBROUTINE next_element(INT *elord, INT *is_parallel);
  SUBROUTINE sx_next_active_elem( INT *elord);
  SUBROUTINE sx_next_active_elem_pp( INT *elord, INT *is_parallel);
  SUBROUTINE indice_element( INT *elemNo, INT *indice, INT *ier);
  SUBROUTINE out_stress(INT *indice, DOUBLE *stress);
  SUBROUTINE out_strain(INT *indice, DOUBLE *strain);
  SUBROUTINE out_force(INT *indice, DOUBLE *force);
  SUBROUTINE out_tg(INT *indice, DOUBLE *tg);
  SUBROUTINE out_tf(INT *indice, DOUBLE *tf);
  SUBROUTINE out_b(INT *indice, DOUBLE *b);
  SUBROUTINE out_h(INT *indice, DOUBLE *h);
  SUBROUTINE out_jt(INT *indice, DOUBLE *jt);
  SUBROUTINE out_fmag(INT *indice, DOUBLE *fmag);
  SUBROUTINE out_mass(INT *indice, DOUBLE *mass);
  SUBROUTINE sx_out_mass_init(INT *numero, DOUBLE *mass);
  SUBROUTINE get_epsi( DOUBLE *epsi);
  SUBROUTINE get_is_spring( INT *indice, INT *is_spring);
  SUBROUTINE get_xyz( INT *indice, INT *nb_noeud, DOUBLE *xyz_el);
  SUBROUTINE sx_update_node( INT *num, DOUBLE *xyz_node);
  SUBROUTINE fact_kmw2m( DOUBLE *lambda0, INT *restrt, INT *where, 
			 INT *kdone, INT *ier);
  INT FUNCTION elm_is_active_for_stress(INT *indice);
  INT FUNCTION elm_is_active_for_force(INT *indice);
  INT FUNCTION elm_is_active_for_tg(INT *indice);
  INT FUNCTION elm_is_active_for_tf(INT *indice);
  INT FUNCTION elm_is_active_for_b(INT *indice);
  INT FUNCTION elm_is_active_for_h(INT *indice);
  INT FUNCTION elm_is_active_for_jt(INT *indice);
  INT FUNCTION elm_is_active_for_fmag(INT *indice);
  SUBROUTINE sxopenfull(void);
  SUBROUTINE sxopenfulln( FCHAR(name) FCHARL(name_len));
  SUBROUTINE sxclosefull(void);
  SUBROUTINE sxopenfullnew(void);
  INT FUNCTION  sxinquirefull(void);
  
  SUBROUTINE fx_stiff_part( DOUBLE *U, DOUBLE *KU, DOUBLE *F, INT *FORCE_CALL,
			    INT *KEY_TO_FORCECALU, INT *KELREQ, INT*IER);
  DOUBLE FUNCTION dwdot( INT*, DOUBLE*, INT*, DOUBLE*, INT*, DOUBLE*, INT* );
  double FNM_dwdot( VEC*, VEC*, T_statut* );
  SUBROUTINE expandu(DOUBLE *disp, INT *no_of_disp);
  SUBROUTINE ndpang( INT *numnode , DOUBLE *angles );
  SUBROUTINE ndpxyz2( INT *numnode, DOUBLE *xyz );
  SUBROUTINE rigidbody(INT*, DOUBLE*, INT*);
  SUBROUTINE dgeev(FCHAR(c1), FCHAR(c2), INT*, DOUBLE*, INT*, DOUBLE*, DOUBLE*, DOUBLE*, INT*, DOUBLE*, INT*, DOUBLE*, INT*, INT* FCHARL(c1_len) FCHARL(c2_len) );

  SUBROUTINE sxgetfullinfo( INT *Matrix, INT * nbddl, INT *nbcs, INT *ncefull, INT *ntrmMat, INT *unsym);
  SUBROUTINE getmapbcstoansys( INT *FULLtoBCSdof, INT *BCStoANSdof, INT *FULLtoANSdof);
  SUBROUTINE sxgetforce( INT *full2bcs, DOUBLE *fullvalues, DOUBLE *bcsvalues, INT *ier);
  SUBROUTINE sxgetcforce( INT *full2bcs, complex16_t *fullvalues, complex16_t *bcsvalues, INT *ier);
  SUBROUTINE sxgetmatbcs( INT *matid, INT *full2bcs, INT *rowslength, INT *colnum, DOUBLE *values, INT *ier);
  SUBROUTINE SxUpdateContactKey( INT *key );
  SUBROUTINE SxSetActiveAllElemsKey( INT *key );
  SUBROUTINE SxGetActiveAllElemsKey( INT *key );
  DOUBLE FUNCTION SxGetInLoadValue( INT*, INT* );
  SUBROUTINE SxInLoadUpd( INT*, INT*, DOUBLE* );
  SUBROUTINE putcadoeubuckling(DOUBLE *disp);
  SUBROUTINE csym_ceequalupd(DOUBLE *, T_statut * );
  SUBROUTINE csym_ceunequalupd(DOUBLE *, T_statut * );
  SUBROUTINE csym_ceEqual(INT *hrmIndex,INT *nperSector,INT *ncestart,LOGICAL *first,LOGICAL *useAngle,DOUBLE *angle,INT *nnewce,INT *kerr);
  SUBROUTINE csym_ceUnEqual(INT *hrmIndex,INT *nperSector,INT *ncestart,LOGICAL *lFirst,LOGICAL *useAngle,DOUBLE *angle,INT *nnewce,INT *kerr);
  SUBROUTINE csym_ceUser(INT *hrmIndex,INT *nperSector,INT *ncestart,LOGICAL *first,LOGICAL *useAngle,DOUBLE *angle,INT *nnewce,INT *kerr);
  SUBROUTINE sectim(DOUBLE * );
  SUBROUTINE TrackBegin(FCHAR(c1) FCHARL(c1_len) );
  SUBROUTINE TrackEnd(FCHAR(c1) FCHARL(c1_len) );

  SUBROUTINE pagend(INT*, INT*, INT*, INT*, INT*, INT*, DOUBLE*);
  INT FUNCTION rfget(INT*, INT*, INT*, DOUBLE*);
  DOUBLE FUNCTION fget(INT*, INT*, INT*);
  INT FUNCTION forget(INT*, INT*, DOUBLE*);
  INT FUNCTION RunCommand( INT*, FCHAR(c1) FCHARL(c1_len) );
  SUBROUTINE RunMacro( FCHAR(c1) FCHARL(c1_len) );
  INT FUNCTION wrinqr( INT* );
  SUBROUTINE wrinfo( INT*, INT* );
  SUBROUTINE CreateDOFmapsPCG(INT *,INT *,INT *,INT *,INT *,INT *,INT *,INT *,INT *);
  SUBROUTINE sfform(INT*, INT*, DOUBLE*);
  SUBROUTINE eqfadd(DOUBLE*);
  SUBROUTINE derivativeCpGtU(INT*, DOUBLE*);
  SUBROUTINE derivativeGtU(DOUBLE*);
  SUBROUTINE init_speedup(long*, INT*, INT*);
  SUBROUTINE free_speedup(long*, INT*);
  SUBROUTINE enrichQ(long*, INT*, DOUBLE*, DOUBLE*, DOUBLE*, 
		     DOUBLE*, INT*, INT*);
  SUBROUTINE minresQ(long*, INT*, INT*, DOUBLE*, DOUBLE*, 
		     INT*, INT*, INT*, INT*,
		     INT*, DOUBLE*, INT*, DOUBLE*, INT*, INT*,
		     INT*, INT*, INT*);
  SUBROUTINE fwend();
  SUBROUTINE fwend2();
  SUBROUTINE clearSolverData(void);
  SUBROUTINE upddsp(DOUBLE*, INT*);
  SUBROUTINE lnstrt(INT*, INT*);
  SUBROUTINE sx_write_mat_elem(INT*, INT*, DOUBLE*);
  SUBROUTINE sx_copy_cnv_crit(DOUBLE*, DOUBLE*); 
  SUBROUTINE getFaceId( INT *iele, INT *iface, INT *nb_comp );
  SUBROUTINE cnvfor(DOUBLE *, DOUBLE *, DOUBLE *, INT *, INT *);
  SUBROUTINE cadoe_getBCdisp(INT *nb_ddl, T_complex *X );
  SUBROUTINE harmExpandBCS(INT *cmplxFlag,T_complex *Uvect,INT *nload,
             INT *uLeng,INT *FULLtoBCSdof,INT *FULLtoANSdof);
  SUBROUTINE sx_put_reac(INT*,INT*,INT*,INT*,INT*,DOUBLE*,DOUBLE*);
  SUBROUTINE sx_put_key_reac(INT*, INT*, INT*);
  SUBROUTINE sx_reac_init();

  SUBROUTINE reset_out(void);
  SUBROUTINE lanbout4(INT *, DOUBLE *, INT *, DOUBLE *, INT *, INT *, INT *, DOUBLE *, DOUBLE *, DOUBLE *, INT *, DOUBLE *, INT *, INT *, INT *);
  
  SUBROUTINE segnodall( INT*, INT*, INT*);
  INT FUNCTION ndinqr( INT*, INT *);
  INT FUNCTION elmiqr( INT*, INT* );
  INT FUNCTION nodbac( INT* );
  INT FUNCTION ndgang( INT*, DOUBLE* );
  INT FUNCTION ndgcn ( INT*, DOUBLE* );
  INT FUNCTION ndgxyz( INT*, DOUBLE* );
  INT FUNCTION elebac( INT* );
  INT FUNCTION elmget( INT*, INT*, INT* );
  INT FUNCTION etyget( INT*, INT* );
  SUBROUTINE rlget( INT*, DOUBLE* );
  INT FUNCTION mpget( INT*, INT*, DOUBLE*, DOUBLE* );
  INT FUNCTION mpinqr( INT*, INT*, INT* );
  INT FUNCTION cpinqr(INT*, INT*);
  INT FUNCTION ceinqr(INT*, INT*);
  INT FUNCTION cpget(INT*, INT*);
  INT FUNCTION ceget(INT*, INT*, DOUBLE*);
  SUBROUTINE ceput(INT*, INT*, INT*, DOUBLE*);
  SUBROUTINE cpput(INT*, INT*, INT*);
  SUBROUTINE disput( INT*, INT*, DOUBLE*);
  INT FUNCTION disget( INT*, INT*, DOUBLE*);
  INT FUNCTION sectinqr( INT*, INT*);
  INT FUNCTION lstcmd( INT* );
  INT FUNCTION ParTabChek (DOUBLE *);
  SUBROUTINE ShellSection(INT *);
  SUBROUTINE GetShellSecData(INT*, INT* ,INT*, INT*, INT*, INT*, INT*, INT*, DOUBLE*,  DOUBLE*, DOUBLE*, DOUBLE*, DOUBLE*, DOUBLE*, DOUBLE*, DOUBLE*, INT*, DOUBLE*);
  SUBROUTINE GetBeamAsecSecData(INT *, DOUBLE *);
  SUBROUTINE GetShellLayerTh(INT*, INT*, INT*, DOUBLE*);
  SUBROUTINE GetShellLayerAngle(INT*,INT*, INT*, DOUBLE*);
  SUBROUTINE get_cmp_iname(INT*, INT*);
  SUBROUTINE cmpsel(FCHAR(toto1), FCHAR(toto2) FCHARL(toto1_len) FCHARL(toto2_len) );
  INT FUNCTION cmplocDB(FCHAR(toto1) FCHARL(toto1_len));
  INT FUNCTION cmpiqrDB(INT*, INT*);
  LONGINTC FUNCTION cmpiqrDBL(INT*, INT*);
  SUBROUTINE cmpnxtDB(INT*, INT*, INT*, INT*);
  SUBROUTINE cmpnxtDBL(INT*, LONGINTC*,INT*,INT*);
  SUBROUTINE get_cmp_card (INT*);
  SUBROUTINE get_cmp_type (FCHAR(toto), INT* FCHARL(toto_len));
  SUBROUTINE ndsel(INT*, INT*);
  SUBROUTINE elsel(INT*, INT*);
  SUBROUTINE GetNbLayers(INT*, INT*);
  SUBROUTINE GetSectionMatIds(INT*, INT*, INT*, INT*, INT*);
  SUBROUTINE getsumnbnodes( INT* );
  SUBROUTINE get_nnd_cont (INT*, INT*, INT*);
  SUBROUTINE sx_store_hice(INT*);
  SUBROUTINE bcssl4(INT*, DOUBLE*, INT*, INT*, INT*, DOUBLE*, DOUBLE*, INT*);
  SUBROUTINE getBcsSolverKeys(INT*, INT*, DOUBLE*);
  SUBROUTINE getBcsModalKeys(INT*, INT*, DOUBLE*, INT*, INT*, DOUBLE*, INT *);
  SUBROUTINE dumpBcsSolverKeys( INT*, DOUBLE*);
  SUBROUTINE solveDBobjs(INT *flag, INT *fromP7);
  SUBROUTINE csym_ceSwitchSector(INT *hisolve, INT *step);
  SUBROUTINE dumpce();
  SUBROUTINE setSoluFlag(INT*, INT*);
  SUBROUTINE nddefv(INT*, INT*);
  SUBROUTINE ErrorMessageProbe(INT*);
  SUBROUTINE erinfo(INT*, INT*);
  
  SUBROUTINE getjobinfo( FCHAR(Cinqr), FCHAR(JobName), INT *JobNameLen FCHARL( Cinqr_len) FCHARL( JobName_len));

  SUBROUTINE printFreq( INT *nfound, INT *numModesReq, INT *extoptlocal, INT *vibKey, INT *HFkey,
			INT *cmplxFlag, INT *freqRangeKey, DOUBLE *freqRange, DOUBLE *dEigenVals,
			complex16_t *cxEigenVals);

  SUBROUTINE fastSolve(INT*, INT*, DOUBLE*,
		       INT*, DOUBLE*, INT*, INT*, DOUBLE*, 
		       INT*, INT*, INT*);
  INT FUNCTION initAnsCe();
  SUBROUTINE dspini(DOUBLE *, INT*);
  SUBROUTINE stphed( INT *ff);

  INT FUNCTION kwget( char *, int *);
  SUBROUTINE   kwput( char *, int *);

  SUBROUTINE writematrix( FCHAR(c1), int *, int *, int *, int *, int *, int *,
			  int *, int *, Hyper *, Hyper *, int *, double **, 
			  double ** FCHARL(c1_len));

  INT FUNCTION parloc( FCHAR(c1) FCHARL(c1_len));
  INT FUNCTION parGetArray ( FCHAR(c1), DOUBLE **, INT * FCHARL(c1_len));

  SUBROUTINE systim( INT *, INT *, INT *);
  SUBROUTINE sysyr( INT *, INT *, INT *);
  SUBROUTINE DSPreadheader(INT*);
  
  void erhandlerc(char *,INT,INT,char *,DOUBLE dpVec[], INT, char *, INT);
  INT GetDistributedFullFile();
  
  SUBROUTINE SX_InitBefAssembly(double eps, IVEC *list_elem_to_derive, int *ier); 
  SUBROUTINE SX_InitBefAssemblyComp(FCHAR(cCompName) FCHARL(cCompName_len));
  SUBROUTINE SX_FreeUpdate();
  
  //change the output file
  SUBROUTINE GetCurrentOutPutName(FCHAR(c1),INT *len1,FCHAR(c2),INT *len2 FCHARL(c1_len)FCHARL(c2_len));
  SUBROUTINE switchOutput(FCHAR(outputFile),FCHAR(outputExt) FCHARL(outputFile_len)FCHARL(outputExt_len));

  INT FUNCTION elec_load_frq();
  SUBROUTINE statBegin(INT *);
  SUBROUTINE statEnd(INT *);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#ifdef __cplusplus

inline void statBegin(INT sect) {statBegin(&sect);};
inline void statEnd(INT sect) {statEnd(&sect);};
 
inline void ReadFullHeaderC( int IdMat, int what, int &Info) {
  Hyper L_dummy;
  ReadFullHeader( &IdMat, &what, &Info, &L_dummy);
}

inline void ReadFullHeaderC( int IdMat, int what, Hyper &Info) {
  int I_dummy;
  ReadFullHeader( &IdMat, &what, &I_dummy, &Info);
}

inline int RunCommandC( char *command)
{
  int cmd_len = (int)(strlen(command));
  return RunCommand( &cmd_len, CCHAR(command) CCHARL(cmd_len) );
}

inline int RunCommandC( string &Command)
{
  char *cmd = (char *)(char *)Command.c_str();
  return RunCommandC( cmd);
}

inline void RunMacroC( char *command)
{
  int cmd_len = (int)(strlen(command));
  // if cmd_len > 128 -> ERROR !!
  RunMacro( CCHAR(command) CCHARL(cmd_len) );
}

inline bool StartPP(void)			// Activate parallel processing
{
  int	pp_nprocs( PP_NPROCS), ppoff( PP_OFF), ppyes( PP_YES);

  if ( cwPpinqr( &pp_nprocs) == 1)
    return false;
 
  if ( cwPpinqr( &ppoff) == 1) {
    cwPpinfo(&ppoff, &ppyes);
    cwPpresu();
    return true;
  }

  return false;
}

inline void StopPP( void)			// De-activate parallel processing
{
  int	ppoff( PP_OFF), ppno( PP_NO);

  cwPppark();
  cwPpinfo(&ppoff,&ppno);  
}

int GetAPDLParameterValue( char *InName, double &val);
int GetAPDLParameterValue( char *InName, string &str);

int DefAPDLParameter( char *InName, double val, bool ToDelete = false);
int DefAPDLParameter( string &InName, double val, bool ToDelete = false);

inline void TmapVector( int nVect, int inVecLeng, int outVecLeng, int invMapFlag, int *mapVect, double *InVect, double *OutVect)
{
  int		cmplxFlag(0);
  complex16_t	*cDumIn(NULL), *cDumOut(NULL);  
  mapVector( &nVect, &inVecLeng, &outVecLeng, &invMapFlag, mapVect, &cmplxFlag, InVect, OutVect, cDumIn, cDumOut);
}

inline void TmapVector( int nVect, int inVecLeng, int outVecLeng, int invMapFlag, int *mapVect, complex16_t *InVect, complex16_t *OutVect)
{
  int		cmplxFlag(1);
  double	*dDumIn(NULL), *dDumOut(NULL);  
  mapVector( &nVect, &inVecLeng, &outVecLeng, &invMapFlag, mapVect, &cmplxFlag, dDumIn, dDumOut, InVect, OutVect);
}

inline void TrecoverSlaveDof( int nload, int nceused, int neqnOnFile, int *SlaveDofs, double *smallg,
			      double *smallgImg, double *AdrFull)
{
  int		cmplxFlag(0);
  complex16_t	*cDum(NULL);
  recoverSlaveDof( &nload, &nceused, &neqnOnFile, &cmplxFlag, SlaveDofs, smallg, smallgImg, AdrFull, cDum);
}

inline void TrecoverSlaveDof( int nload, int nceused, int neqnOnFile, int *SlaveDofs, double *smallg,
			      double *smallgImg, complex16_t *AdrFull)
{
  int		cmplxFlag(1);
  double	*dDum(NULL);
  recoverSlaveDof( &nload, &nceused, &neqnOnFile, &cmplxFlag, SlaveDofs, smallg, smallgImg, dDum, AdrFull);
}

inline void TrecoverBcDof( int nload, int neqnOnFile, int *BCdofs, double *AdrBC, double *AdrFull)
{
  int		cmplxFlag(0);
  complex16_t	*cDum(NULL);
  recoverBcDof( &nload, &neqnOnFile, &cmplxFlag, BCdofs, AdrBC, cDum, AdrFull, cDum);
}

inline void TrecoverBcDof( int nload, int neqnOnFile, int *BCdofs, complex16_t *AdrBC, complex16_t *AdrFull)
{
  int		cmplxFlag(1);
  double	*dDum(NULL);
  recoverBcDof( &nload, &neqnOnFile, &cmplxFlag, BCdofs, dDum, AdrBC, dDum, AdrFull);
}

string	ForStringToCppString( char *cName, INT length);
void	CppStringToForString( char *CppName, INT length, char *FName);

#endif

#endif


