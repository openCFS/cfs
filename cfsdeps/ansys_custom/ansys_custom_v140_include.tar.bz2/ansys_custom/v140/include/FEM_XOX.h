
/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 2009 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_XOX.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_XOX.h
 *  header file for FEM_XOX.c
 *
 */
#ifndef FEM_XOX_H
#define FEM_XOX_H

/* ---- global variables for xox reparameterization ---- */
#define EXIT_PARAM_FAILURE -1000

#ifdef __cplusplus
extern "C" {
#endif

extern FEM_BOOLEAN g_keepXoxPara;
                 /* === FEM_xxInit: initialize a single area.  Create a 2D  */
                 /* === parameterization from the 3D facets of a XOX        */
                 /* === microtopology surface.  Can be called multiple      */
                 /* === times to cache any number of surfaces               */
INT FEM_xxInit(
   INT anum,             /* (IN) area to be initialized                     */
   MESH_OBJ obj_mesh,    /* (IN) 3D surface facets approximating surface    */
   INT param_method,     /* (IN) 1 = surface projection parameterization    */
                         /*      2 = Floater parameterization               */
                         /*      3 = Use existing U-V parameterization      */
   INT flat );           /* (IN) flag - area is flat                        */

                 /* === FEM_xxKill: kill all memory allocated for xox       */
                 /* === data structures                                     */
void FEM_xxKill( );

                 /* === FEM_xxKill: kill memory allocated for one xox       */
                 /* === data structure                                      */
void FEM_xxKillOne( 
   INT anum,                        /* (IN) area to delete                  */
   INT keepmesh );                  /* (IN) flag - don't delete mesh        */

                 /* === FEM_xxGetNodes: retrieve the nodelist for the       */
                 /* === tesselation of the area                             */
INT FEM_xxGetNodes(
   INT anum,                        /* (IN) the area                        */
   NODELIST_OBJ *p_obj_nlist );     /* (OUT) the node list                  */

                 /* === FEM_xxSetCurrent: Set the current area for          */
                 /* === subsequent evaluations                              */
INT FEM_xxSetCurrent( 
   INT anum );           /* (IN) area number to set as current              */

                 /* === FEM_xxIsInitialized: Return whether area has been   */
                 /* === initialized                                         */
INT FEM_xxIsInitialized(
   INT anum );

                 /* === FEM_xxEval: given 2D coord in paramertic space of   */
                 /* === surface, evaluate the 3D location                   */
INT FEM_xxEval(
   DOUBLE u,
   DOUBLE v,             /* (IN) known parametric coordinates               */
   VECTOR3D *ps_xyz );   /* (OUT) interpolated 3D location                  */

                 /* === FEM_xxSlope: given 2D coord in paramertic space of  */
                 /* === surface, evaluate the 3D tangent vectors            */
INT FEM_xxSlope(
   DOUBLE u,
   DOUBLE v,             /* (IN) known parametric coordinates               */
   VECTOR3D *ps_du,      /* (OUT) interpolated u tangent vector             */
   VECTOR3D *ps_dv );    /* (OUT) interpolated v tangent vector             */

                 /* === FEM_xxCurv: given 2D coord in paramertic space of   */
                 /* === surface, approximate the max surface curvature      */
INT FEM_xxCurv(
   DOUBLE u,
   DOUBLE v,             /* (IN) known parametric coordinates               */
   DOUBLE *p_curv );     /* (OUT) approximated surface curvature            */

                 /* === FEM_xxSlopeandCurv: given 2D parameters             */
                 /* === define slope vects and max surface curvature        */
INT FEM_xxSlopeandCurv(
   DOUBLE u,
   DOUBLE v,             /* (IN) known parametric coordinates               */
   VECTOR3D *ps_du,
   VECTOR3D *ps_dv,      /* (OUT) slope vectors                             */
   DOUBLE *p_curv );     /* (OUT) approximated surface curvature            */


                 /* === FEM_xxXYZandSlope: given 2D coord in parametric     */
                 /* === space of surface, evaluate the 3D location and      */
                 /* === tangent vectors                                     */
INT FEM_xxXYZandSlope(
   DOUBLE u,
   DOUBLE v,             /* (IN) known parametric coordinates               */
   VECTOR3D *ps_xyz,     /* (OUT) interpolated 3D location                  */
   VECTOR3D *ps_du,      /* (OUT) interpolated u tangent vector             */
   VECTOR3D *ps_dv );    /* (OUT) interpolated v tangent vector             */

                 /* === FEM_xxProject: project a 3D point to the surface    */
INT FEM_xxProject(
   INT guess,            /* (IN) flag - 0 = do not use u,v as guess         */
                         /*             1 = use u,v as initial guess        */
   DOUBLE *p_u,          /* (IN) initial u-v guess (OUT) final u-v location */
   DOUBLE *p_v,
   VECTOR3D *ps_xyz);    /* (IN) point to project (OUT) projected 3D        */
                         /* location on smooth surface                      */

                 /* === FEM_xxProject2: project a 3D point to the surface   */
                 /* === (method #2)                                         */
INT FEM_xxProject2(
   DOUBLE *p_u,          /* (IN) initial u-v guess (OUT) final u-v location */
   DOUBLE *p_v,
   VECTOR3D *ps_xyz);    /* (IN) point to project (OUT) projected 3D        */
                         /* location on smooth surface                      */


                 /* === FEM_xxInterpMethod: return interpolation method     */
                 /* === 0 = natural neighbor, 1 = Linear                    */
INT FEM_xxInterpMethod();

                 /* === FEM_xxBounds: Get the bounds of the uv space for the*/
                 /* === current area                                        */
INT FEM_xxBounds(
   DOUBLE *a_uvbounds );


#ifdef __cplusplus
}
#endif

#endif
