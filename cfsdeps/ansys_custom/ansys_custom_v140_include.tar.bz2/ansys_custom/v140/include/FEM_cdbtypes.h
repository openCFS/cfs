/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 2009 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_cdbtypes.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_cdbtypes.h
 *
 */
/* *** mpg math array c
 FEM_array.c FEM_matrix.c FEM_MeshTable.h FEM_Public.h FEM_array.h
 FEM_array_static.h  FEM_cdbtypes.h FEM_edPublic.h FEM_elPublic.h
 FEM_errors.h FEM_external.h FEM_faPublic.h FEM_matrix.h
 FEM_matrix_static.h FEM_meshTree.h FEM_noGeom.h FEM_noPublic.h
 FEM_publicElementDefinition.h fem_Struct.h
 ansproto.h computer.h float.h globals.h mathfun.h
*/

#ifndef CDBTYPES__H
#define CDBTYPES__H

#if defined (DSPACE_CMDB)
#ifndef EXTERNAL_COMPILE
# define EXTERNAL_COMPILE
#endif
#endif

/* === define data types used in the ANSYS meshing Toolkit. */

#ifndef EXTERNAL_LINK
#include "computer.h"
#endif

#if !defined(EXTERNAL_COMPILE) && !defined(EXTERNAL_LINK)

/* === header files defining types for compiling within Ansys 5.X */

#include "float.h"
#include "globals.h"

#define FEM_INT       INT
#define FEM_LOGICAL   LOGICAL
#define FEM_DOUBLE    DOUBLE
#define FEM_DDOUBLE   DDOUBLE
#define FEM_LONG      LONG
#define FEM_CHAR      CHAR
#define FEM_SHORT     SHORT
#define FEM_BOOLEAN   BOOLEAN

#else

#include "float.h"

/* === define types for compiling outside of Ansys 5.X */

typedef int           INT;
typedef int       FEM_INT;
typedef int           LOGICAL;
typedef int       FEM_LOGICAL;
typedef double        DOUBLE;
typedef double    FEM_DOUBLE;
typedef double        DDOUBLE;
typedef double    FEM_DDOUBLE;
typedef int       FEM_LONG;
//#ifndef MAINWIN
//typedef FEM_LONG  int;
//#endif
typedef char          CHAR;
typedef char      FEM_CHAR;
typedef short         SHORT;
typedef short     FEM_SHORT;

#if !defined ANSYSDSPACE_CMDB
#if !defined _INC_WINDOWS
typedef INT           BOOLEAN;
#endif
#endif

typedef INT       FEM_BOOLEAN;

/* === define constants used in the ANSYS meshing Toolkit. */

#ifndef TRUE
# define TRUE 1
#endif

#ifndef FALSE
# define FALSE 0
#endif

/* === define macros used in the ANSYS meshing Toolkit. */

#ifndef UG_SCENARIO
#ifndef MIN
# define MIN( a, b ) (((a)>(b))?(b):(a))
#endif

#ifndef ABS
# define ABS( a ) (((a)<0)?(-(a)):(a))
#endif
#endif

#ifndef PI
# define PI 3.14159265358
#endif

#endif

#ifndef FEM_CPP_EXTERN
#ifdef __cplusplus
#define FEM_CPP_EXTERN extern "C"
#else
#define FEM_CPP_EXTERN
#endif
#endif

#if defined(linux) && defined(MAINWIN)
#define HUGE_VAL HUGE
#endif 

/* ========================================================================= */
/* ========================================================================= */
/* ========================================================================= */
/* ========== Datatype definitions ========================================= */
/* ========================================================================= */
/* ========================================================================= */
/* ========================================================================= */

                          /* =============================================== */
                          /* === GEOTYPE:                                    */
                          /* =============================================== */
typedef enum { FEM_AT_KEYPOINT=1,
               FEM_ON_LINE=2,
               FEM_ON_AREA=3,
               FEM_IN_VOLUME=4,
               FEM_NO_GEO=5 } FEM_GEOTYPE;

                          /* =============================================== */
                          /* === AREAELEM_SHAPE: value sent to area mesher   */
                          /* === to specify desired element shape and also   */
                          /* === the return value from FEM_GetAreaElem       */
                          /* === specifying what type of element is being    */
                          /* === returned.                                   */
                          /* =============================================== */
typedef enum { FEM_TRI_SHAPE=1,                /* a triangle shaped element  */
               FEM_TRI_SHAPE_DEGEN_QUAD=2,     /* a triangle shaped element  */
                                               /*   that is really a quad    */
                                               /*   that was degenerated into*/
                                               /*   a triangle.              */
               FEM_QUAD_SHAPE=3}AREAELEM_SHAPE;/* a quadrilateral shaped     */
                                               /*   element.                 */

                          /* =============================================== */
                          /* === MESHTYPE: value sent to area mesher to      */
                          /* === specify whether to do free or map meshing.  */
                          /* =============================================== */
typedef enum { FEM_FREE_MESH=0,
               FEM_MAP_MESH=1,
               FEM_MAP_OR_FREE_MESH=2 } MESHTYPE;

typedef enum { WRITE_JOURNAL = 1,
               READ_JOURNAL = 2,
               NO_JOURNAL = 3 } JOURNAL_WRITE_TYPE;

#endif

