
/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 2009 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_mesh.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_mesh.h
 *  header file for FEM_mesh.c
 *
 */
#ifndef FEM_MESH_INCLUDE
#define FEM_MESH_INCLUDE

/*----------------- Globally accessible function prototypes -----------------*/

#include "FEM_periodic.h"


#ifdef __cplusplus
extern "C" {
#endif


                       /* ================================================== */
                       /* === FEM_meMeshAreas:  Mesh areas with either quads */
                       /* === or tris.  This is the same as FEM_MeshAreas    */
                       /* === except it takes the "command" argument.  This  */
                       /* === should be called when meshing psuedo elements  */
                       /* === with "command" == 3.                           */
                       /* === Return: INT EXIT_SUCCESS or EXIT_FAILURE       */
                       /* ================================================== */
INT FEM_meMeshAreas (
   INT num_areas,       /* (IN)  number of areas to mesh.                     */
   INT *a_areas,        /* (IN)  ids of areas to mesh.                        */
   INT shape,           /* (IN)  3 for tris, 4 for quads.                     */
   INT mshkey,          /* (IN)  0 = Use free Mesher Always.                  */
                        /*       1 = Use Map Mesher Always.                   */
                        /*       2 = Use Map Mesher if possible, and if       */
                        /*           not, use the free mesher.                */
   INT command,         /* (IN)  2 for area meshing, 3 for volume meshing     */
   FEM_BOOLEAN midnodes,/* (IN)  TRUE if midnodes are to be added to edges    */
                        /*       on this area.  Midnodes will be added to     */
                        /*       all new edges created by this mesh           */
                        /*       operation.  Midnodes will not be added to    */
                        /*       pre-existing  boundary edges created from    */
                        /*       meshing an adjacent area with linears        */
                        /*       elements, or on line edges retrieved from    */
                        /*       the native CAD database.                     */
   FEM_BOOLEAN project_mids,
                        /* (IN)  TRUE if midnodes should be projected to      */
                        /*       the geometry.  FALSE if midnodes should      */
                        /*       be linear interpolation of corner nodes.     */
                        /*       Ignored if midnodes == FALSE.                */
   INT smrt,            /* (IN)  smrt size level to use while meshing the     */
                        /*       areas in a_areas.  Possible values           */
                        /*       include:                                     */
                        /*           0:    do not do smart sizing.            */
                        /*           1:    create finest possible mesh.       */
                        /*           2:                                       */
                        /*           .                                        */
                        /*           .     varying degrees of coarseness.     */
                        /*           .                                        */
                        /*           9:                                       */
                        /*           10:   create coarest possible mesh.      */
   FEM_BOOLEAN do_progress,/* (IN)  TRUE if progress bar is to be used.       */
   INT stat_process,    /* (IN)  process identifier to be sent to progress    */
                        /*       bar. If do_progress && stat_process == 0,    */
                        /*       then processes from general amesh will be    */
                        /*       used.                                        */
   INT a_ivalues[3] );  /* (IN)  ivalues array to be sent to progress bar.    */
                        /* ================================================== */

                       /* ================================================== */
                       /* === FEM_meMeshAreaBnd: mesh the boundary of an     */
                       /* === and/or extract any existing boundary intervals */
                       /* === from the native data base                      */
                       /* === Return: INT EXIT_SUCCESS or EXIT_FAILURE       */
                       /* ================================================== */
INT FEM_meMeshAreaBnd ( 
   INT *a_areas,       /* (IN) array of areas to mesh                        */
   INT num_areas,      /* (IN) number of areas to mesh                       */
   FEM_BOOLEAN midnodes,/* (IN)  TRUE if midnodes are to be added to edges   */
                       /*       on this area.  Midnodes will be added to     */
                       /*       all new edges created by this mesh           */
                       /*       operation.  Midnodes will not be added to    */
                       /*       pre-existing  boundary edges created from    */
                       /*       meshing an adjacent area with linears        */
                       /*       elements, or on line edges retrieved from    */
                       /*       the native CAD database.                     */
   FEM_BOOLEAN project );/* (IN)  TRUE if midnodes should be projected to    */
                       /*       the geometry.  FALSE if midnodes should      */
                       /*       be linear interpolation of corner nodes.     */
                       /*       Ignored if midnodes == FALSE.                */


                       /* ================================================== */
                       /* === FEM_meOrientAreaEdges: Orient all the edges on */
                       /* === an area boundary to be in the counterclockwise */
                       /* === direction.  Also put all edges on the boundary */
                       /* === of this area at the front of the edge list.    */
                       /* === Return: INT EXIT_SUCCESS or EXIT_FAILURE       */
                       /* ================================================== */
INT FEM_meOrientAreaEdges (
   INT area_id,        /* (IN)  the area to orient.                          */
   PERIODIC_TYPE *periodic,/* (OUT) whether a surface is periodic or not.    */
   INT *num_bound  );  /* (OUT) number of edges on boundary.                 */



                       /* ================================================== */
                       /* === FEM_meMeshVols:  Mesh volumes with tets.       */
                       /* === Return: INT EXIT_SUCCESS or EXIT_FAILURE       */
                       /* ================================================== */
INT FEM_meMeshVols(
   INT num_vols,        /* (IN)  number of volumes to mesh.                   */
   INT *a_vols,         /* (IN)  ids of volumes to mesh.                      */
   FEM_BOOLEAN midnodes,/* (IN)  TRUE if midnodes are to be added to edges    */
                        /*       on this vol.  Midnodes will be added to      */
                        /*       all new edges created by this mesh           */
                        /*       operation.  Midnodes will not be added to    */
                        /*       pre-existing  boundary edges created from    */
                        /*       meshing an adjacent area with linears        */
                        /*       elements, or on line edges retrieved from    */
                        /*       the native CAD database.                     */
   FEM_BOOLEAN project_mids,
                        /* (IN)  TRUE if midnodes should be projected to      */
                        /*       the geometry.  FALSE if midnodes should      */
                        /*       be linear interpolation of corner nodes.     */
                        /*       Ignored if midnodes == FALSE.                */
   INT smrt );          /* (IN)  smrt size level to use while meshing the     */
                        /*       volumes in a_vols.  Possible values          */
                        /*       include:                                     */
                        /*           0:    do not do smart sizing.            */
                        /*           1:    create finest possible mesh.       */
                        /*           2:                                       */
                        /*           .                                        */
                        /*           .     varying degrees of coarseness.     */
                        /*           .                                        */
                        /*           9:                                       */
                        /*           10:   create coarest possible mesh.      */
                        /* ================================================== */


                        /* ================================================== */
                        /* === FEM_meMeshKp: given a single kp number, mesh   */
                        /* === it.                                            */
                        /* === Return: INT EXIT_SUCCESS or EXIT_FAILURE       */
                        /* ================================================== */
INT FEM_meMeshKp(
   INT kp_id,             /* (IN)  kp to mesh.                                */
   NODE_OBJ *obj_kpnode );/* (OUT) node put on kp_id.                         */
                        /* ================================================== */

                        /* ================================================== */
                        /* === FEM_meGetIntNodeLocs: A line needs to be       */
                        /* === meshed.  Given the number of divisions and a   */
                        /* === spacing ratio, determine the locations of the  */
                        /* === interior nodes.  Also get the ids for the new  */
                        /* === nodes.                                         */
                        /* === Return: INT EXIT_SUCCESS or EXIT_FAILURE       */
                        /* ================================================== */
INT FEM_meGetIntNodeLocs(
   INT line_id,         /* (IN)  id of line nodes will be on.                 */
   INT num_divs,        /* (IN)  number of divisions to put on line.          */
   DOUBLE space_ratio,  /* (IN)  spacing ratio for new nodes.                 */
   FEM_BOOLEAN midnodes,/* (IN)  TRUE if line needs midnodes.                 */
   FEM_BOOLEAN project_mids,/* (IN)  TRUE if midnodes need to be projected.   */
   INT kp1,             /* (IN)  id of kp1 on this line.                      */
   INT kp2,             /* (IN)  id of kp2 on this line.                      */
   DOUBLE *a_line_t,    /* (OUT) parametric location of new nodes.            */
   DOUBLE *a_xyz,       /* (OUT) 3d location of new nodes.                    */
   INT *a_ids );        /* (OUT) ids of new nodes.                            */

 
INT FEM_meMeshLineWOKps(
   INT line_num,        /* (IN) the line to mesh                              */
   INT num_divs,        /* (IN) number of element edges on the line.          */
   DOUBLE *a_line_t,    /* (IN) parametric location of interior nodes on line */
                        /*      a_line_t must be 0.0 and is used for the node */
                        /*      at the start (where t = 0.0 on the line)      */
   DOUBLE *a_xyz,       /* (IN) xyz locations of interior nodes on line       */
                        /*      a_xyz is used for the node at the start       */
                        /*      (where t = 0.0 on the line)                   */
   INT *a_ids,          /* (IN) ids of new nodes on line. a_ids is used for   */
                        /*      the node at the start (where t = 0.0 on the   */
                        /*      line)                                         */
   FEM_BOOLEAN midnodes,/* (IN) TRUE if a_xyz has midnode locations also.     */
   FEM_BOOLEAN native,  /* (IN) TRUE if the node is in the native database    */
                        /*      (i.e.ansys db)                                */
   NODE_OBJ **aobj_nodes,
   INT *numNodes );


                        /* ================================================== */
                        /* === FEM_meMeshArea:  Given an area id, mesh it.    */
                        /* === Return: INT EXIT_SUCCESS or EXIT_FAILURE       */
                        /* ================================================== */
INT FEM_meMeshArea(
   INT area_id,         /* (IN) the area to mesh                              */
   INT shape,           /* (IN) 3 = triangles, 4 = quad/tri                   */
   INT mshkey,          /* (IN) 1 = Use free Mesher Always.                   */
                        /*      2 = Use Map Mesher Always.                    */
                        /*      3 = Use Map Mesher if possible, and if        */
                        /*          not, use the free mesher.                 */
   INT midnodes,        /* (IN) 1 = midnodes on edges                         */
   INT project,         /* (IN) TRUE if midnodes should be projected to       */
                        /*      the geometry.                                 */
   INT degen_quad,      /* (IN) flag - elements are degenerate quads          */
   INT command,         /* (IN) 2 if area meshing, 3 if volume meshing        */
   INT *piWasMapped  ); /* (OUT) was the area map meshed */


                       /* ================================================== */
                       /* === FEM_meMapMeshAreas:  map mesh some areas*/
                       /* === Return: INT EXIT_SUCCESS or EXIT_FAILURE       */
                       /* ================================================== */
INT FEM_meMapMeshAreas (
   INT num_areas,       /* (IN)  number of areas to mesh.                     */
   INT *a_areas,        /* (IN)  ids of areas to mesh.                        */
   FEM_BOOLEAN midnodes,/* (IN)  TRUE if midnodes are to be added to edges    */
                        /*       on this area.  Midnodes will be added to     */
                        /*       all new edges created by this mesh           */
                        /*       operation.  Midnodes will not be added to    */
                        /*       pre-existing  boundary edges created from    */
                        /*       meshing an adjacent area with linears        */
                        /*       elements, or on line edges retrieved from    */
                        /*       the native CAD database.                     */
   FEM_BOOLEAN project_mids,
                        /* (IN)  TRUE if midnodes should be projected to      */
                        /*       the geometry.  FALSE if midnodes should      */
                        /*       be linear interpolation of corner nodes.     */
                        /*       Ignored if midnodes == FALSE.                */
   INT shape,
                        /* (IN)  shape of map mesh along with split types     */
                        /*       0 = quad                                     */
                        /*       1 = tri auto split                           */
                        /*       2 = tri split at i                           */
                        /*       3 = tri split at j                           */
   FEM_BOOLEAN do_progress,/* (IN)  TRUE if progress bar is to be used.       */
   INT stat_process,    /* (IN)  process identifier to be sent to progress    */
                        /*       bar. If do_progress && stat_process == 0,    */
                        /*       then processes from general amesh will be    */
                        /*       used.                                        */
   INT a_ivalues[3] );  /* (IN)  ivalues array to be sent to progress bar.    */


                       /* ================================================== */
                       /* === FEM_meQMorphAreas:  Mesh areas with  quads */
                       /* === from existing  tris.                    */
                       /* === Return: INT EXIT_SUCCESS or EXIT_FAILURE       */
                       /* ================================================== */
INT FEM_meQMorphAreas (
   INT num_areas,       /* (IN)  number of areas to mesh.                     */
   INT *a_areas,        /* (IN)  ids of areas to mesh.                        */
   FEM_BOOLEAN bForceQuads, /* (IN) force all quads instead of quad/tri */
   FEM_BOOLEAN midnodes,/* (IN)  TRUE if midnodes are to be added to edges    */
                        /*       on this area.  Midnodes will be added to     */
                        /*       all new edges created by this mesh           */
                        /*       operation.  Midnodes will not be added to    */
                        /*       pre-existing  boundary edges created from    */
                        /*       meshing an adjacent area with linears        */
                        /*       elements, or on line edges retrieved from    */
                        /*       the native CAD database.                     */
   FEM_BOOLEAN project_mids,
                        /* (IN)  TRUE if midnodes should be projected to      */
                        /*       the geometry.  FALSE if midnodes should      */
                        /*       be linear interpolation of corner nodes.     */
                        /*       Ignored if midnodes == FALSE.                */
   FEM_BOOLEAN do_progress,/* (IN)  TRUE if progress bar is to be used.       */
   INT stat_process,    /* (IN)  process identifier to be sent to progress    */
                        /*       bar. If do_progress && stat_process == 0,    */
                        /*       then processes from general amesh will be    */
                        /*       used.                                        */
   INT a_ivalues[3] );  /* (IN)  ivalues array to be sent to progress bar.    */


                        /* ================================================== */
                        /* === FEM_meMeshArea:  Given a volume id, mesh it.    */
                        /* === Return: INT EXIT_SUCCESS or EXIT_FAILURE       */
                        /* ================================================== */
INT   FEM_meMeshVolume ( 
   INT vol_id,
   INT midnodes,
   INT project,
   INT *a_areas,           /* (IN) list of areas on the boundary.  If NULL, */
                                   /*      then fem_meMeshVolumes will have to calc */
                                   /*      determine these for itself.              */
   INT num_areas,          /* (IN) length of a_areas                        */
   INT fromBrutForceRef );

INT FEM_meMeshLine(
   INT line_num,        /* (IN)  the line to mesh */
   INT num_divs,        /* (IN)  number of element edges on the line. */
   DOUBLE *a_line_t,    /* (IN)  parametric location of interior nodes on line*/
   DOUBLE *a_xyz,       /* (IN)  xyz locations of interior nodes on line */
   INT *a_ids,          /* (IN)  ids of new nodes on line */
   NODE_OBJ obj_kpnode1,/* (IN)  node on kp1 */
   NODE_OBJ obj_kpnode2,/* (IN)  node on kp2 */
   FEM_BOOLEAN midnodes,/* (IN)  TRUE if a_xyz has midnode locations also. */
   FEM_BOOLEAN native,  /* (IN)  TRUE if the node is in the native database */
   NODE_OBJ **aobj_nodes_out,
   INT *numNodes ) ;

INT FEM_meGetAreaLines(
   INT area,
   INT *num_lines,                        
   INT **a_lines, 
   INT **a_dirs);

INT FEM_meGetLoopNodes( INT area_id, NODE_OBJ *apcLoopNodes[], INT aiNumLoopNodes[], INT  aiNumLinesInloops[] ); 


#ifdef __cplusplus
}
#endif

#endif

