/* ANSI_C ax.h - ANSYS Geometry Interface: general */

/*--------------------------------------------------------------------------*/
/* ansys(r) copyright(c) 2009 */
/* ansys, inc.                */
/*--------------------------------------------------------------------------*/

#ifndef __AX_H__  /* Include this file only once! */
#define __AX_H__ 

#ifdef __cplusplus
extern "C" {
#endif

/*--------------------------------------------------------------------------*/

/* The Interface's abstract data type (ADT) */

typedef int  ax_ENTITY;

/*--------------------------------------------------------------------------*/

/* The Interface's elementary types */

typedef double        ax_REAL;
typedef int           ax_INDEX;
typedef int           ax_DEGREE;
typedef int           ax_BIT;
typedef unsigned int ax_FLAGS;
typedef int           ax_FORM;

/*--------------------------------------------------------------------------*/

/* Exported constants */

#ifndef  NULL
# define NULL ((void*) 0)
#endif

extern const char *ax_DEFAULT;
extern const ax_ENTITY ax_NO_ENTITY;

#define ax_NEGATIVE ((ax_BIT) 0)
#define ax_POSITIVE ((ax_BIT) 1)

/*--------------------------------------------------------------------------*/

/* Flag constants (powers of 2) */

#define ax_2D 1
#define ax_POLYNOMIAL 2
#define ax_CLOSED 4
#define ax_U_CLOSED 8
#define ax_V_CLOSED 16
#define ax_PERIODIC 32
#define ax_U_PERIODIC 64
#define ax_V_PERIODIC 128

/*--------------------------------------------------------------------------*/

/* Flag macros */

#define ax_flag_set(FLAGS,F)    FLAGS |=  (F)
#define ax_flag_clear(FLAGS,F)  FLAGS &= ~(F)
#define ax_flag(FLAGS,F)      ((FLAGS &   (F)) != 0)

/*--------------------------------------------------------------------------*/

/* Form constants */

#define ax_PLANE_FORM       22001
#define ax_CYLINDRICAL_FORM 22002
#define ax_CONICAL_FORM     22003
#define ax_SPHERICAL_FORM   22004
#define ax_TOROIDAL_FORM    22005
#define ax_REVOLUTION_FORM  22006
#define ax_RULED_FORM       22007
#define ax_QUADRIC_FORM     22008

#define ax_LINE_FORM       21001
#define ax_CIRCULAR_FORM   21002
#define ax_ELLIPTICAL_FORM 21003
#define ax_PARABOLIC_FORM  21004
#define ax_HYPERBOLIC_FORM 21005

#define ax_DISCONT 23001
#define ax_CONT    23002
#define ax_CONT1   23003
#define ax_CONT2   24004

/*--------------------------------------------------------------------------*/

/* Error constants */

#define ax_NOT_YET          450000
#define ax_INTERNAL_ERROR   450001
#define ax_WRITE_ERROR      450008
#define ax_READ_ERROR       450009
#define ax_INVALID_ESCAPE   450011  /* context-> the offending string */
#define ax_EMPTY_NODE       450012  /* context-> "[%d]" of offending entity */
#define ax_INCOMPLETE_NODE  450013  /* context-> "[%d]" of offending entity */
#define ax_INVALID_NODE     450014  /* context-> "[%d]" of offending entity */
#define ax_WEIGHT_CONFLICT  450015  /* context-> "[%d]" of offending entity */
#define ax_INVALID_CURVE_BD 450016  /* context-> "[%d] and/or [%d]" */

/*--------------------------------------------------------------------------*/

/* Prototypes to general functions */

void ax_set_environment (const char *name);
void ax_set_rc_filename (const char *name);

void ax_initialize (const char *option_string);
void ax_terminate  (void);

void  ax_preamble (const char *text);
void  ax_note (const char *text);
void  ax_reorient_brep (void);

void ax_process (void);
void ax_validate (void);

void ax_set_model (const char *model_name);

ax_ENTITY ax_entity (const char *label);

/*--------------------------------------------------------------------------*/

/* Error handling (ax_error.c) */

typedef struct ax_error_rec
{
  int   code;
  const char *message;
  const char *fpoint;

  /* for internal debugging only... */
  const char *fname  ;          /* file name where error was occured */
  int         lnum;             /* corresponding line number */
  const void *more_context;     /* NULL or a pointer to error-specific
                                   context information (see ax.h) */
} ax_ERROR;

int   ax_error (int i);
const ax_ERROR* ax_error_struct (int i);
void  ax_error_clear (void);

/*--------------------------------------------------------------------------*/

/* Saving and printing (af.c) */

void af_save (const char *path);
void af_save_entity (ax_ENTITY entity, void *generic, void *app_data);

/*--------------------------------------------------------------------------*/

/* ...and loading (af_load.c) */

void af_load (const char *path);
void af_load_entity (ax_ENTITY entity, void *generic, void *app_data);

/*--------------------------------------------------------------------------*/

/* auxiliary */

ax_INDEX *ax_zero_index_array (ax_INDEX n);

const char *ax_get_version (void);
const char *ax_get_filebase (void);
int         ax_get_debug_level (void);

/*--------------------------------------------------------------------------*/

#if defined(__cplusplus)
}
#endif

#endif  /* #ifdef __AX_H__ */
