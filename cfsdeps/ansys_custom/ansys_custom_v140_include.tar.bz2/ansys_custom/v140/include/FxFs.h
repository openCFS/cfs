/*! \mainpage Frequency Sweep API.
 * 
 * Described Below the prototype we will need to fill for the Frequency Sweep Application.
 *
 *  |Auteur: Frederic Thevenon
 *
 *  |Version: $Id: FxFs.h 145002 2009-11-13 16:20:27Z jtm $
 */
#ifndef __FXFS_h__
#define __FXFS_h__ 1


#include <math.h>
#include "computer.h"
#include "globals.h"
#include "sysparh.h"
#include "erreur.h"
#include "CadoeAnsys.h"
#include "SxSparse.h"

/**
 * Global Variables
 */
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

extern int              G_type_analysis;

extern VSTRUCT		*BDer;

extern int		G_AOrder;

extern T_booleen	G_K_variable,
			G_M_variable,
			G_C_variable,
                        G_H_variable;

/**
 * G_nbrhs :	Number of RHS
 */
extern int	G_nbrhs;
/**
 * G_nbdof :	Number of dof
 */
extern int	G_nbdof;
/**
 * G_nbcsdof :	Number of bcs dof
 */
extern int	G_nbcsdof;
/**
 * G_nbel :	Number of elements
 */
extern int	G_nbel;
/**
 * G_k :	Current Wave Number
 */
extern double	G_k;
/**
 * G_dk :	Variation of the Wave number
 */
extern double	G_dk;

#ifdef __cplusplus
}
#endif /* __cplusplus */



/*! \def CELERITY
  \brief light velocity \f$c\f$
*/
#define CELERITY1 299792458
#define CELERITY 300000000

/*! \def PI
*/
#define DPPI 3.14159265358979323846

/*! \def FS_SQUARE(x)
  \brief Computes \f$x^2\f$
*/
#define FS_SQUARE(x) ((x)*(x))

#define VISCOUS     0
#define HYSTERETIC  1

#define CONF_CENTRALE		0.51E0
#define SIZE_TAB_FORTRAN	25
#define AFF_FUNCNAME		/* printf( "|%s : \n", fctn); */

#define TRAIT_ANSYS		"\n______________________________________________________________________\n"

/* ===================================================================== */
/* For systems needing lower case names without an underscore at the end */
/* ===================================================================== */
#if defined(LOWERCASENOUNDER_SYS)

#endif
#if defined(UPPERCASENOUNDER_SYS)
#define resolv		RESOLV
#define buildmat        BUILDMAT
#define buildrhs        BUILDRHS
#define dscal           DSCAL
#define fx_fs_freq      FX_FS_FREQ
#define fx_fs_eval      FX_FS_EVAL
#define fx_fs_end       FX_FS_END
#define fx_fs_verif     FX_FS_VERIF
#define fx_fs_interp    FX_FS_INTERP
#define fx_fs_solve     FX_FS_SOLVE
#define fx_fs_writec    FX_FS_WRITEC
#define fx_fs_readc     FX_FS_READC
#define fxgetjcgtrm     FXGETJCGTRM
#define fxgetmat0       FXGETMAT0
#define fxgetmat0bcs    FXGETMAT0BCS
#define sx_read_full0   SX_READ_FULL0
#define sx_read_full0_bcs SX_READ_FULL0_BCS
#define fxgetmat1       FXGETMAT1
#define fxgetmat1bcs    FXGETMAT1BCS
#define fxprodavcplx    FXPRODAVCPLX
#define fxmocmataxpy 	FXMOCMATAXPY
#define fxmocmataxpybcs FXMOCMATAXPYBCS
#endif
#if defined(LOWERCASEUNDER_SYS)
#define resolv		resolv_
#define buildmat        buildmat_
#define buildrhs        buildrhs_
#define dscal           dscal_
#define fx_fs_freq      fx_fs_freq_
#define fx_fs_eval      fx_fs_eval_
#define fx_fs_end	fx_fs_end_
#define fx_fs_verif	fx_fs_verif_
#define fx_fs_interp    fx_fs_interp_
#define fx_fs_solve     fx_fs_solve_
#define fx_fs_writec    fx_fs_writec_
#define fx_fs_readc     fx_fs_readc_
#define fxgetjcgtrm     fxgetjcgtrm_
#define fxgetmat0       fxgetmat0_
#define fxgetmat0bcs    fxgetmat0bcs_
#define sx_read_full0   sx_read_full0_
#define sx_read_full0_bcs   sx_read_full0_bcs_
#define fxgetmat1       fxgetmat1_
#define fxgetmat1bcs    fxgetmat1bcs_
#define fxprodavcplx    fxprodavcplx_
#define fxmocmataxpy 	fxmocmataxpy_ 
#define fxmocmataxpybcs fxmocmataxpybcs_
#endif

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

  SUBROUTINE resolv( INT *nbdof, INT *nbrhs, T_complex *, T_complex *, INT *ier);
  SUBROUTINE buildmat(DOUBLE *frequency, INT *ier);
  SUBROUTINE buildrhs( DOUBLE *freq, INT *nbrhs, T_complex *values, INT *ier);
  SUBROUTINE fx_fs_freq( INT *numfreq, DOUBLE *valfreq, INT *ier);
  SUBROUTINE fx_fs_eval( DOUBLE *freq, DOUBLE *solution, T_statut *ier);
  SUBROUTINE fx_fs_interp( DOUBLE *valfreq, T_booleen *encore, INT *ier );
  SUBROUTINE fx_fs_solve( INT*, INT* );
  SUBROUTINE fx_fs_end(void);
  SUBROUTINE fx_fs_verif( DOUBLE *freq, DOUBLE *solexacte);
  SUBROUTINE fxgetmat0 ( INT *matid, INT *matnum, DOUBLE *mat, DOUBLE *valk, INT *ier );
  SUBROUTINE fxgetmat0bcs ( INT *matid, INT *matnum, DOUBLE *mat, DOUBLE *valk, INT *FULLtoBCS,  INT *ier );
  SUBROUTINE sx_read_full0 ( INT *matid, INT *matnum, DOUBLE *mat, DOUBLE *valk, INT *ier );
  SUBROUTINE sx_read_full0_bcs ( INT *matid, INT *matnum, DOUBLE *mat, DOUBLE *valk, INT *FULLtoBCS,  INT *ier );
  SUBROUTINE fxgetmat1 ( INT *matid, INT *matnum, INT *ordre, INT *scale, DOUBLE *coef, DOUBLE *mat, INT *ier );
  SUBROUTINE fxgetmat1bcs ( INT *matid, INT *matnum, INT *ordre, INT *scale, DOUBLE *coef, DOUBLE *mat, INT *FULLtoBCS, INT *ier );
  SUBROUTINE fxmocmataxpy ( INT *matid, INT *matnum, INT *ordre, DOUBLE *coef, DOUBLE *mat, INT *ier );
  SUBROUTINE fxmocmataxpybcs ( INT *matid, INT *matnum, INT *ordre, DOUBLE *coef, DOUBLE *mat, INT *FULLtoBCS, INT *ier );
  SUBROUTINE fxgetjcgtrm( INT*, INT*, INT* );
  SUBROUTINE fxprodavcplx( INT *IdMat, INT *nbdof, INT *nbv, INT *of, T_complex *v, T_complex *av, INT *ofe, INT *ier);
  /* BLAS SYMBOLS : */
  SUBROUTINE dscal( INT *, DOUBLE *, DOUBLE *, INT *);
  
  extern void bidon(void);
  extern double FreqToK( double );
  extern double KToFreq( double );
  extern PAR *FX_init( char *name, int *ier);
  extern ZVEC* FX_GetB( int irhs, int of, int op, ZVEC *vecB);
  extern void FX_CompDerA( PAR *, VEC *, int *, int *, T_complex *, T_complex *, int *);
  extern ZVEC* FX_CompB( PAR *par, VEC *delta_param, int irhs, ZVEC *vecB, int *ier);
  extern ZVEC *FX_Resol( ZVEC *, ZVEC *, int * );
  extern ZVEC *FX_ProdAX( int, int, ZVEC*, ZVEC* );
  extern ZVEC *FX_IntProdAX( int IdMat, int of, ZVEC *in, ZVEC *out,
			     int *ier);
  extern void FX_AffRange( PARAM *param, double *inf, double *sup);
  extern T_statut FX_detruire_matrices(void);
  
  extern ADOC_DRCT *FX_AllocDrct( PAR *par, int o1, int o2, ADOC_DRCT *Q, int *ier);
  extern void FX_Factor( int *ier);
  
  extern void Fx_fsadoc_free(void);
  extern void Fx_intadoc_free(void);
  extern IntegerAdr Fx_TryLoadMatrix( T_m_ooc *mat, char *name, int *ier);
  extern VEC* SxGetTmpVec(); 
  extern void SxProdAvCplx( int IdMat, int nbv, int of, T_complex *in, T_complex *out, T_statut *ier );
 
#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif
