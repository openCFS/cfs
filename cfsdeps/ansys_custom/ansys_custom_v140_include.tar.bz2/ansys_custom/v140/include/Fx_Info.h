/*******************************************************************************
 *
 *   fx_Info.h  --- Retrieve and Set some FOTRAN common variables
 *               
 * 
 * |Module:  
 *
 * |Description: 
 *
 * |Includes:	
 *        
 * |Auteur: Jean-Daniel Beley
 *
 * |Creation: Mars 2002
 *
 * |Version: $Id: Fx_Info.h 465729 2011-04-08 12:38:34Z ftheveno $
 *
 * |Copyright:	Copyright(c)  2002
 *
 ********************************************************************************/
#ifndef __FX_INFO_H__
#define __FX_INFO_H__ 1

#include "computer.h"
#include "globals.h"
#include "sysparh.h"

/* ===================================================================== */
/* For systems needing lower case names without an underscore at the end */
/* ===================================================================== */
#if defined(LOWERCASENOUNDER_SYS)
#define fx_getinfo   fx_getinfo
#define fx_setinfo   fx_setinfo
#endif
#if defined(UPPERCASENOUNDER_SYS)
#define fx_getinfo   FX_GETINFO
#define fx_setinfo   FX_SETINFO
#endif
#if defined(LOWERCASEUNDER_SYS)
#define fx_getinfo   fx_getinfo_
#define fx_setinfo   fx_setinfo_
#endif

typedef enum {
  E_I_LENBAC = 1,
  E_I_NUME = 2,
  E_I_LENU= 3,
  E_I_NEQN= 4,
  E_I_ANTYPE= 5,
  E_I_NUMDOF= 6,
  E_I_NRKEY= 7,
  E_I_LDSTEP= 8,
  E_I_CADOE_ANTYPE = 9,
  E_D_TINY= 10,
  E_D_HUGE= 11,
  E_D_FRQBEG= 12,
  E_D_FRQEND= 13,
  E_I_STRUCURAL= 14,
  E_I_THERMAL= 15,
  E_I_ELECTRIC= 16,
  E_I_EMAG= 17,
  E_I_CFD= 18,
  E_I_M_VARIABLE= 19,
  E_I_C_VARIABLE= 20,
  E_I_K_VARIABLE= 21,
  E_I_NSUBST = 22,
  E_I_HARMONIC_INDEX = 23,
  E_D_HARMONIC_ANGLE = 24,
  E_I_DEBUG_KEY = 25,
  E_I_CADOE_PASS_INPUT = 26,
  E_I_SSTIF = 27,
  E_I_CADOE_OPEN_ESAV = 28,
  E_I_CADOE_OPEN_EMAT = 29,
  E_I_CADOE_FREQ_MIN = 30,
  E_I_ACCEL_EXIST = 31,
  E_I_HRMSXTYPE = 32,
  E_I_SOLVEMETHOD = 33,
  E_I_CADOE_APPR_TYPE = 34,
  E_I_SXFPOSTASSEMBLY = 35,
  E_I_CADOE_K_PART = 36,
  E_I_NUMITER = 37,
  E_I_NUMSUBSTEP = 38,
  E_I_FXSHIT = 39,
  E_I_SXNL_KPART = 40,
  E_I_SXNL_DERIVKT = 41,
  E_I_SXNL_CHECKCNV = 42,
  E_I_SXNL_EXPANDU = 43,
  E_I_SXNL_CONTACT = 44,
  E_I_KPLUPD = 45,
  E_I_KUPHVR = 46,
  E_I_KUPSVR = 47,
  E_I_SXNL_LS = 48,
  E_I_KFSTIT = 49,
  E_I_HIUNMATCH = 50,
  E_I_IEQITR = 51,
  E_I_STNMAX = 52,
  E_I_SXFNBCALLSFFORM = 53,
  E_I_SXNL_EX = 55,
  E_I_KFSTPS = 56,
  E_D_PRDFCT = 57,
  E_I_LSLOOP = 58,
  E_I_SXNL_CDM = 59,
  E_I_ANCONT = 60,
  E_I_MODEXT = 61,
  E_I_SXNL_BACSUB = 62,
  E_I_SXNL_UPDDSP = 63,
  E_I_SXNL_ELEM = 64,
  E_I_CHKNLE = 65,
  E_I_DCNVGD = 66,
  E_I_ECNVGD = 67,
  E_I_FCNVGD = 68,
  E_I_SXNL_ITER = 69,
  E_I_SXNL_VERIFCNV = 70,
  E_I_SXNL_MINRESQ = 71,
  E_I_SXNL_KREFRM = 72,
  E_I_SXNL_DFDX = 73,
  E_I_FRDSUP = 74,
  E_I_SXNL_REST = 75,
  E_I_VTC_CONTACT = 76,
  E_I_VTC_SKIPCONTACT = 77,
  E_I_VTC_SETG = 78,
  E_I_VTC_RESOL = 79,
  E_I_KREFRM = 80,
  E_I_CPFLAG = 81,
  E_I_CEFLAG = 82,
  E_I_CADOE_FREQ_MAX = 83,
  E_I_VTC_WRTDISPRST = 84,
  E_I_MODEXP = 85,
  E_I_VTHI_UPDATE = 86,
  E_I_NEQITR = 87,
  E_I_VTC_METHOD = 88,
  E_I_NLGEOM = 89,
  E_I_NUMINTKEYS = 90,
  E_I_NUMDPKEYS = 91,
  E_I_SPARSESOLVEMETHOD = 92,
  E_I_NROPT = 93,
  E_D_TIMVAL = 94,
  E_D_TIMEND = 95,
  E_D_RVRSD = 96,
  E_I_VTHI_CS_HIBIT = 97,
  E_I_SOLVECODE = 98,
  E_I_NRUNSYM = 99,
  E_I_LUMPM =100,
  E_I_KEYSYNCHRO = 101,
  E_D_FREQ_VAL = 102,
  E_D_FRQVAL_PML = 103,
  E_I_KEY_CADOE_PML = 104,
  E_I_ASSEMB_MAT = 105,
  E_I_CADOE_FRQSWP_VT = 106,
  E_I_KEYDMPR = 107,
  E_I_STROUT = 108,
  E_I_NEWFS = 109,
  E_I_NOPORT = 110,
  E_I_NOASSEMB = 111,
  E_I_OMEGA2TOLAMBDA = 112,
  E_I_FULL2VT = 113,
  E_D_OMEGA2 = 114,
  E_D_FULLFP = 115,
  E_I_PARTIALASSEMB = 116,
  E_I_SXTB = 117,
  E_I_SXBODYFORCETABLE = 118,
  E_I_HFMETH = 119,
  E_I_LRMODES = 120,
  E_D_LFACTO = 121,
  E_D_LFACTN = 122,
  E_I_CS_USERNMAP = 123,
  E_I_PERTURBKEY = 124,
  E_I_PERTRBMTXKEY = 125,
  E_I_PERTURBSTAGE = 126,
  E_I_CADOE_UPDATE = 127,
  E_I_CEBASE = 128,
  E_I_CESTART = 129,
  E_I_CADOE_FRQSWP_POST = 130,
  E_I_FREQ_COMPUTED_VT = 131,
  E_I_KEYACOUS = 132

} E_info_fx;

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

SUBROUTINE fx_getinfo( E_info_fx*, int*, double * );
SUBROUTINE fx_setinfo( E_info_fx*, int*, double * );

#ifdef __cplusplus

inline int GetCommonFortranVal_I( E_info_fx Id)
{ int I_info; double Dp_info; fx_getinfo( &Id, &I_info, &Dp_info); return I_info;}

inline void SetCommonFortranVal_I( E_info_fx Id, int I_info)
{ double Dp_info; fx_setinfo( &Id, &I_info, &Dp_info);}

inline double GetCommonFortranVal_D( E_info_fx Id)
{ int I_info; double Dp_info; fx_getinfo( &Id, &I_info, &Dp_info); return Dp_info;}

inline void SetCommonFortranVal_D( E_info_fx Id, double Dp_info)
{ int I_info; fx_setinfo( &Id, &I_info, &Dp_info);}

#endif /* __cplusplus */

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif
