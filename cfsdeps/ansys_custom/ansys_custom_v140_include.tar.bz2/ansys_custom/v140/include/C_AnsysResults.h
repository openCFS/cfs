/*******************************************************************************
 *
 *   C_AnsysResults.h - 
 *               
 * 
 * |Module:  DXVT
 *
 * |Description: 
 *
 * |Includes:	
 *        
 * |Auteur: Emmanuel DELOR
 *
 * |Creation: Feb 2005
 *
 * |Version:
 *
 * |Historique:
 *
 * |Copyright:	copyright(c) 2011 SAS IP, Inc.  All rights reserved.
 *
 *
 ******************************************************************************/


#ifndef __C_ANSYSRESULTS_DEJA_INCLUS__
#define __C_ANSYSRESULTS_DEJA_INCLUS__ 1

#include "sx_adr_res.h"
#include "sx_element.h"


class C_PrimaryResult : public C_adr_bloc_res
{
public:
  C_PrimaryResult(const string nom = "dummy") : C_adr_bloc_res(nom) {};
  virtual ~C_PrimaryResult(){};

  virtual int	fillResults(VEC *VecToFill, VEC *U, VEC *reac, bool fromAnsys);
};

class C_SecondaryResult : public C_adr_bloc_res
{
 public:
  C_SecondaryResult(const string nom = "dummy") : C_adr_bloc_res(nom) 
    {
      list_elem = NULL;
      valeurs = NULL;
      _isSecondaryResult = true;
      ndata = 0;
    };
  virtual ~C_SecondaryResult() {
    if (list_elem) IV_FREE(list_elem);
    if (valeurs) V_FREE(valeurs);
  };
  
  virtual int  	fillResults(VEC *, VEC *, VEC *, bool);
  virtual int   readFromAnsys(VEC *);
  
  virtual IVEC	*getListElem() {return list_elem;}
  virtual VEC	*getValeurs() {return valeurs;}
  virtual inline int   getSizeByEntity(T_modele *modele, int i) {return -1;};
  
  virtual int	allocate();
  virtual int   buildListElem(T_modele *modele);
  virtual int	fillListElemToDerive(IVEC *list_elem_to_derive, int ie);
  
protected:
  IVEC *list_elem;			// list_elem.cpp
  VEC  *valeurs;			// sx_update.cpp
  int  ndata;				// from panavg.F
};

class C_SecondaryResultElem : public C_SecondaryResult
{
 public:
  C_SecondaryResultElem(const string nom = "dummy"): C_SecondaryResult(nom) {};
  virtual ~C_SecondaryResultElem() {};
};

class C_SecondaryResultNode : public C_SecondaryResult
{
 public:
  C_SecondaryResultNode(const string nom = "dummy") : C_SecondaryResult(nom) {};
  virtual ~C_SecondaryResultNode() {};
};

class C_Result_U : public C_PrimaryResult
{
 public:
  C_Result_U(const string nom = "Displacment") : C_PrimaryResult(nom) {};
  ~C_Result_U() {};
};

class C_Result_T : public C_PrimaryResult
{
 public: 
  C_Result_T(const string nom = "Temperature") : C_PrimaryResult(nom) {}; 
  ~C_Result_T() {};
};

class C_Result_V : public C_PrimaryResult
{
public: 
  C_Result_V(const string nom = "Volt") : C_PrimaryResult(nom) {}; 
  ~C_Result_V() {};
};

class C_Result_MP : public C_PrimaryResult
{
public: 
  C_Result_MP(const string nom = "Magnetic Potentiel") : C_PrimaryResult(nom) {}; 
  ~C_Result_MP() {}
};

class C_Result_M : public C_SecondaryResultElem
{
 public:
  C_Result_M(const string nom = "Masse") : C_SecondaryResultElem(nom) {};
  ~C_Result_M() {};
  inline int   getSizeByEntity(T_modele *modele, int i) {return 1;}
  int   readFromAnsys(VEC *);
};

class C_Result_S : public C_SecondaryResultElem
{
 public:
  C_Result_S(const string nom = "Stress") : C_SecondaryResultElem(nom) {};
  ~C_Result_S() {};
  inline int	getSizeByEntity(T_modele *modele, int i) 
  {
	  //return modele->element[i]->nb_sig;
	  T_statut ier=SUCCES;
	  return ELE_compter(modele->element[i], nature, &ier);
  }
  int   readFromAnsys(VEC *);
};

class C_Result_R : public C_SecondaryResultNode
{
 public:  
  C_Result_R(const string nom = "Reaction") : C_SecondaryResultNode(nom) {};
  ~C_Result_R() {};
  int   buildListElem(T_modele *modele);
  int   fillListElemToDerive(IVEC *list_elem_to_derive, int ie);
  int	fillResults(VEC *VecToFill, VEC *U, VEC *Reac, bool fromAnsys);
  int   readFromAnsys(VEC *);
};

class C_Result_TG : public C_SecondaryResultElem
{
 public:
  C_Result_TG(const string nom = "TG") : C_SecondaryResultElem(nom) {ndata = 11;};
  ~C_Result_TG() {};
  inline int   getSizeByEntity(T_modele *modele, int i) {int ier(0); return ELE_compter(modele->element[i], nature, &ier);}
};

class C_Result_TF : public C_SecondaryResultElem
{
 public:
  C_Result_TF(const string nom = "TF") : C_SecondaryResultElem(nom) {ndata = 12;};
  ~C_Result_TF() {};
  inline int   getSizeByEntity(T_modele *modele, int i) {int ier(0); return ELE_compter(modele->element[i], nature, &ier);}
};

class C_Result_B : public C_SecondaryResultElem
{
 public:
  C_Result_B(const string nom = "B") : C_SecondaryResultElem(nom) {ndata = 14;};
  ~C_Result_B() {}
  inline int   getSizeByEntity(T_modele *modele, int i) {int ier(0); return ELE_compter(modele->element[i], nature, &ier);}
};

class C_Result_H : public C_SecondaryResultElem
{
 public: 
  C_Result_H(const string nom = "H") : C_SecondaryResultElem(nom) {ndata = 13;};
  ~C_Result_H() {};
  inline int   getSizeByEntity(T_modele *modele, int i) {int ier(0); return ELE_compter(modele->element[i], nature, &ier);}
};

class C_Result_JT : public C_SecondaryResultElem
{
 public:
  C_Result_JT(const string nom = "JT") : C_SecondaryResultElem(nom) {ndata = 17;}; 
  ~C_Result_JT() {};
  inline int   getSizeByEntity(T_modele *modele, int i) {int ier(0); return ELE_compter(modele->element[i], nature, &ier);}
};

class C_Result_FMAG : public C_SecondaryResultElem
{
 public:
  C_Result_FMAG(const string nom = "FMAG") : C_SecondaryResultElem(nom) {ndata = 15;};
  ~C_Result_FMAG() {};
  inline int   getSizeByEntity(T_modele *modele, int i) {int ier(0); return ELE_compter(modele->element[i], nature, &ier);}
};


class C_AnsysResults : public C_adr_res
{
public:
  C_AnsysResults();
  C_AnsysResults(C_adr_res *adr_res);
  ~C_AnsysResults();
  
  void		release();
  C_adr_bloc_res *new_C_adr_bloc_res(E_resultat_parametre);
  int		buildListElem(T_modele *modele);
  int		buildListElemPres(T_modele *modele);
  int		listElemRes(T_modele *modele, int *nb_elem);
  int		listElemResMm(T_modele *modele, int *nb_elem);
  int		listElemPresRes(T_modele *modele, int *nb_elem);
  int		listElemPresParam(T_modele *modele, int *nb_elem);
  int		listElemPresParamRes(T_modele *modele, int *nb_elem);
  int		listElemParam(T_modele *modele, int *nb_elem);
  int		listElemParamRes(T_modele *modele, int *nb_elem);
  int		listElemParamResMm(T_modele *modele, int *nb_elem);
  int		listElemParamK(T_modele *modele, int nb_elem_max_interp);
  int		listElemParamB(T_modele *modele, int *nb_elem_to_derive);
  int           listElemParamHiCe( T_modele *modele, int *nb_elem);
  
  IVEC *list_elem_to_derive;
  IVEC *list_elem_pres;
};

#endif //  __C_ANSYSRESULTS_DEJA_INCLUS__
