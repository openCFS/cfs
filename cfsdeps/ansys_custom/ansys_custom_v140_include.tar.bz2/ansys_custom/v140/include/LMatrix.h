/*HFILE LMatrix.h                                             mpg jdb */
/* CADOE */
/*****************************************************************************
 *
 *   Lmatrix.h
 *              
 * 
 * |Module: LF EMAG - L matrix calculation
 *
 * |Description: 
 *
 * |Author: Jean-Daniel Beley (jdb)
 *
 * |Creation Date: February 2005 - (jdb) - original creation
 *                 May      2006 - (mpg) - add messages 
 *          
 * |Version: $Id: LMatrix.h 443717 2010-12-30 13:45:48Z dc $
 *
 * |Copyright:	Copyright(c) ANSYS 2005
 *
 ****************************************************************************/
#ifndef __LMATRIX_H__
#define __LMATRIX_H__ 1

#include "cadoe.h"
#include "cadoe_string.h"
#include "computer.h"
#include "globals.h"
#include "sysparh.h"
#include "msgdfc.h"

#if defined(LOWERCASENOUNDER_SYS)
#define MgIncAddRhs mgincaddrhs
#define MgIncFree mgincfree
#define MgIncInitializeIterator  mgincinitializeiterator
#define MgIncAddEnergy mgincaddenergy
#define MgIncZeroEnergy mginczeroenergy
#define MgIncGetIndex mgincgetindex
#define MgIncIncIndex mgincincindex
#define OutputResult outputresult
#define MgIncSolve mgincsolve
#define setdisp setdisp
#define MgIncGetNbRHS mgincgetnbrhs
#define MgIncGetEnergy mgincgetenergy
#define printdisp printdisp
#define MgIncReadRHS mgincreadrhs
#endif

#if defined(UPPERCASENOUNDER_SYS)
#define MgIncAddRhs MGINCADDRHS
#define MgIncFree MGINCFREE
#define MgIncInitializeIterator MGINCINITIALIZEITERATOR
#define MgIncAddEnergy MGINCADDENERGY
#define MgIncZeroEnergy MGINCZEROENERGY
#define MgIncGetIndex MGINCGETINDEX
#define MgIncIncIndex MGINCINCINDEX
#define OutputResult OUTPUTRESULT
#define MgIncSolve MGINCSOLVE
#define setdisp SETDISP
#define MgIncGetNbRHS MGINCGETNBRHS
#define MgIncGetEnergy MGINCGETENERGY
#define printdisp PRINTDISP
#define MgIncReadRHS MGINCREADRHS
#endif

#if defined(LOWERCASEUNDER_SYS)
#define MgIncAddRhs mgincaddrhs_
#define MgIncFree mgincfree_
#define MgIncInitializeIterator mgincinitializeiterator_
#define MgIncAddEnergy mgincaddenergy_
#define MgIncZeroEnergy mginczeroenergy_
#define MgIncGetIndex mgincgetindex_
#define MgIncIncIndex mgincincindex_
#define OutputResult outputresult_
#define MgIncSolve mgincsolve_
#define setdisp setdisp_
#define MgIncGetNbRHS mgincgetnbrhs_
#define MgIncGetEnergy mgincgetenergy_
#define printdisp printdisp_
#define MgIncReadRHS mgincreadrhs_
#endif

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

  SUBROUTINE MgIncAddRhs( DOUBLE *force, INT *lenu, INT *ier );
  SUBROUTINE MgIncInitializeIterator(void);
  SUBROUTINE MgIncFree(void);
  SUBROUTINE MgIncAddEnergy( DOUBLE *e1, DOUBLE *e2 );
  SUBROUTINE MgIncZeroEnergy();
  SUBROUTINE MgIncGetIndex( INT *index, INT *iret );
  INT FUNCTION OutputResult( INT *outputflag);
  SUBROUTINE MgIncSolve( DOUBLE *Sol, DOUBLE *dSol, INT *lenu, INT *nrkey, INT *ier );
  SUBROUTINE MgIncGetEnergy( INT*, DOUBLE*, DOUBLE* );
  SUBROUTINE MgIncReadRHS( INT*, DOUBLE *);
  
#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __LMATRIX_H__ */
