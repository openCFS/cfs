#ifndef __CINTEGRATION__
#define __CINTEGRATION__ 11011

#include "cadoe.h"
#include "cadoe_map.h"

#include <stdarg.h>
#include "expmdb_struct.h"
#include "CLMeshBase.h"

typedef map< int, T_Integration * > MapInteg;

/**************/
class Cintegration
{
public:

  static Cintegration* Instance();

  ~Cintegration();

  bool getTabIntegration ( int, int, int, T_Integration** );
  void deleteTabIntegration ( );
	MAT *getMatB ( CLMeshBase *Cmesh, int indE, bool *ier );
	MAT *getMatB ( T_Element *element, bool *ier );
	bool setMatB ( CLMeshBase *Cmesh, int indE );
	bool setMatB ( T_Element *element );
	bool dimMatB ( unsigned int n, unsigned int m );
	void setJacobien ( bool withJac ) { m_bWithJacobien = withJac; };
	T_Integration *getIntegration () { return m_pIntegration; };
	int getNbLigneMatB ( T_Element *ele, int *nb_point );
	int getNbLigneMatB ( CLMeshBase *Cmesh, int indE, int *nb_point );

private:
	bool initialiserVec ();
	bool setMatB ( );
	int  getNbLigneMatB ( int *nb_point );
	bool calculerBiso ( int dim, int nb_sig, bool cisaillement );
	bool calculerBcoqueiso ( int dim, int nb_sig, bool cisaillement );
	bool calculerBpyra ( bool cisaillement, bool sous_integre );
	bool calculBpou2( );
	bool calculBpou3( );
	bool calculBspring ( );
	bool setNodesXYZ ( CLMeshBase *Cmesh, int indE );
	bool setNodesXYZ ( T_Element * );
	void calculXYZlocal ( MAT *mat_R );
	bool dimJac ( unsigned int nbPoint );

  MapInteg m_mTabIntegration;
	MAT *m_matB;
	MAT *m_Rloc;
	MAT *m_mloc;
	MAT *m_R;
	VEC *m_vInter;
	VEC *m_vLoc;
	VEC *m_vEps;
	VEC *m_vJac;
	double **m_pNodesXYZ;
	int *m_pNodes;
	int m_iIndEle;
	bool m_bInitialized;
	bool m_bWithJacobien;
  T_Integration *m_pIntegration;
	T_Element m_Element;
	static Cintegration* m_instance;

 protected:
	Cintegration();
};


/**************/






#endif
