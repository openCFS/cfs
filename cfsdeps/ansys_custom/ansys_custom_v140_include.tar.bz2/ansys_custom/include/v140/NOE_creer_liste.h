/* NOE_creer_liste.h CADOE  */
/*
 * NOE_creer_liste.h
 *
 * $Id: NOE_creer_liste.h,v 1.4 2009/11/13 16:13:03 jtm Exp $
 *   
 * HISTORY
 *   
 *   06/28/00 10:47 <       Brian Jantzen> Rel:ms8m1    SCCA:74542  Delta:81.3
 *   
 *   06/21/00 16:30 <       Brian Jantzen> Rel:ms8m1    SCCA:74307  Delta:81.2
 */

#ifndef __noecreerlisteh__
#define __noecreerlisteh__ 1

#ifndef __expmdbstructh__
#include "expmdb_struct.h"
#endif

/*#ifdef __cplusplus
extern "C" {
#endif*/

extern T_Noeud **NOE_creer_liste( int, T_Noeud **, int * );
extern T_Noeud **NOE_creer_vecteur ( int, int * );
extern T_Noeud *NOE_allouer_memoire ( T_statut *ier );

/*#ifdef __cplusplus
}
#endif*/

#endif
