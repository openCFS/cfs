/*
 *    author/date: yu-hua ting/06-12-94
 *
 *    primary function:
 *
 *        error code definition
 *
 *    secondary function:
 *
 *        none
 *
 *    routines included:
 *
 *        none
 *
 *    history
 *
 *        none
 *
 *    comments:
 *
 *        none
 *
 *    notice- these routines contain sasi confidential information ***
 *
 */
/* 
 * *** copyright(c) 2011 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */


/*
 *    last digit = 1 - shapes error 
 *               = 2 - ansys  error
 *               = 3 - ansys/shapes interface error 
 */


#define SHAPES_VALID_MERGE                                                                    0
#define SHAPES_INTERSECTION_IS_EMPTY                                                          1
#define SHAPES_VALID_OVERLAP                                                                  2
 
#define SHAPES_NO_ENOUGH_MEMORY                                                               XE_BadMem   
#define SHAPES_NON_MANIFOLD_GEOMETRY                                                          999900
#define ANSYS_COMPOSITE_VOLUME                                                                999902
#define ANSYS_COMPOSITE_AREA                                                                  999912
#define ANSYS_COMPOSITE_LINE                                                                  999922
 
#define SHAPES_COMPOSITE_VOLUME                                                               999931
#define SHAPES_COMPOSITE_AREA                                                                 999941
#define SHAPES_COMPOSITE_LINE                                                                 999951

#define SHAPES_OPERATION_FAIL                                                                 999961

#define DEGENERACY_DETECTED_BY_SHAPES_IN_BOOLEAN                                              999091
 
#define SHAPES_SHELL_HAVING_1_XSUBAREA                                                        999101
#define SHAPES_SHELL_HAVING_LESS_THAN_1_XSUBAREA                                              999111
#define SHAPES_LOOP_HAVING_2_XSUBLINES                                                        999121
#define SHAPES_LOOP_HAVING_1_XSUBLINE                                                         999131
#define SHAPES_LOOP_HAVING_LESS_THAN_1_XSUBLINE                                               999141
 
#define ANSYS_SHELL_HAVING_1_AREA                                                             999002
#define ANSYS_SHELL_HAVING_1_SUBAREA                                                          999012

#define ANSYS_SHELL_HAVING_LESS_THAN_1_AREA                                                   999022
#define ANSYS_SHELL_HAVING_LESS_THAN_1_SUBAREA                                                999032

#define ANSYS_LOOP_HAVING_2_LINES                                                             999042
#define ANSYS_LOOP_HAVING_2_SUBLINES                                                          999052

#define ANSYS_LOOP_HAVING_1_LINE                                                              999062
#define ANSYS_LOOP_HAVING_1_SUBLINE                                                           999072

#define ANSYS_LOOP_HAVING_LESS_THAN_1_LINE                                                    999082
#define ANSYS_LOOP_HAVING_LESS_THAN_1_SUBLINE                                                 999092

#define ANSYS_POINTS_ARE_COLINEAR                                                             999142
 
#define ANSYS_DUPLICATE_SUBLINES_ALREADY_EXIST                                                999202
#define ANSYS_DUPLICATE_SUBAREAS_ALREADY_EXIST                                                999212
#define ANSYS_DUPLICATE_SUBVOLUMES_ALREADY_EXIST                                              999222

#define ANSYS_DUPLICATE_SUBLINES_WITH_DIFFERENT_GEOMETRIES                                    999232
#define ANSYS_DUPLICATE_SUBAREAS_WITH_DIFFERENT_GEOMETRIES                                    999242
#define ANSYS_DUPLICATE_SUBVOLUMES_WITH_DIFFERENT_GEOMETRIES                                  999252
#define SCALING_FACTOR_IS_NOT_POSITIVE                                                        999262


#define NOT_VALID_ANSYS_ENTITY_TYPE                                                           999272
#define ANSYS_FRAMES_NOT_FOUND                                                                999282
#define SHAPES_FRAMES_NOT_FOUND                                                               999281

 
#define INPUT_GEOMETRIES_ARE_DISJOINTED                                                       999888
#define ALL_CUT_GEOMETRIES_ARE_DISJOINTED_WITH_CUTTING_GEOMETRY                               999777
#define CUTTING_AREAS_ARE_DISJOINTED                                                          999666
 
#define NO_ENOUGH_MEMORY                                                                      988888
#define XOX_NO_ENOUGH_MEMORY                                                                  988881
#define ANSYS_NO_ENOUGH_MEMORY                                                                988882
#define XAX_NO_ENOUGH_MEMORY                                                                  988883
#define ATT_NO_ENOUGH_MEMORY                                                                  988884

 
#define CAN_NOT_FREE_MEMORY                                                                   977777
#define XOX_CAN_NOT_FREE_MEMORY                                                               977771
#define ANSYS_CAN_NOT_FREE_MEMORY                                                             977772
#define XAX_CAN_NOT_FREE_MEMORY                                                               977773

#define GEOMETRY_IS_EMPTY                                                                     966666
 
#define GEOMETRIES_DO_NOT_OVERLAP                                                             955555
#define GEOMETRIES_DO_NOT_MERGE                                                               944444
 
#define NOT_YET_IMPLEMENTED                                                                   933333
 
#define ERROR_CODE_STACK_IS_FULL                                                              933302
#define ERROR_CODE_STACK_IS_EMPTY                                                             933312
 
#define DEGENERACY_DETECTED_IN_BOOLEAN                                                        922212
#define NON_MANIFOLD_GEOMETRY                                                                 922222

#define HEAP_DOES_NOT_HAVE_CORRECT_MEMORY_ALIGNMENTS                                          911112
 
#define SHAPES_SYSTEM_ERROR                                                                   900001
#define ANSYS_SYSTEM_ERROR                                                                    900002
#define INTERFACE_SYSTEM_ERROR                                                                900003
 

#define NO_FREE_HEAP_TAG                                                                      910003
#define NO_ENOUGH_MINIMUM_MEMORY                                                              910013
#define CAN_NOT_INITIALIZE_MEMORY_NODE_STORAGE_POOL                                           910023
#define CAN_NOT_ALLOCATE_INITIAL_HEAP                                                         910033
#define DID_NOT_FREE_ALL_THE_MEMORY                                                           910043
#define USE_SEPARATED_BOOK_KEEPING_SPACE                                                      910053

#define NUMBER_OF_ENDPOINTS_NOT_EQUAL_2                                                       910063
#define XOX_DATA_LENGTH_IS_TOO_SMALL                                                          910073

#define ANSYS_VOLUME_ALREADY_CONVERTED                                                        910103
#define ANSYS_SUBVOLUME_ALREADY_CONVERTED                                                     910113
#define ANSYS_SHELL_ALREADY_CONVERTED                                                         910123
#define ANSYS_AREA_ALREADY_CONVERTED                                                          910133
#define ANSYS_SUBAREA_ALREADY_CONVERTED                                                       910143
#define ANSYS_LOOP_ALREADY_CONVERTED                                                          910153
#define ANSYS_LINE_ALREADY_CONVERTED                                                          910163
#define ANSYS_SUBLINE_ALREADY_CONVERTED                                                       910173
#define ANSYS_POINT_ALREADY_CONVERTED                                                         910183

#define SHAPES_XSUBVOLUME_ALREADY_CONVERTED                                                   910193
#define SHAPES_XSHELL_ALREADY_CONVERTED                                                       910203
#define SHAPES_XSUBAREA_ALREADY_CONVERTED                                                     910213
#define SHAPES_XLOOP_ALREADY_CONVERTED                                                        910223
#define SHAPES_XSUBLINE_ALREADY_CONVERTED                                                     910233
#define SHAPES_XPOINT_ALREADY_CONVERTED                                                       910243

#define NUMBER_OF_GEOM_ATTRIBUTES_GRATER_THAN_0                                               910303
#define NUMBER_OF_GEOM_ATTR_LISTS_GREATER_THAN_0                                              910313
#define GEOM_ATTR_PTR_EQUAL_TO_NULL_ADDRESS                                                   910323
#define GEOM_ATTR_LIST_PTR_EQUAL_TO_NULL_ADDRESS                                              910333
#define GEOM_ATTRIBUTE_DOS_NOT_EXIST                                                          910343

#define LIST_SIZE_NOT_EQUAL_ZERO                                                              911001


#define ERROR_IN_xStartLog_xax_IN_xoxopn_FILE_xbexport                                        100003
#define ERROR_IN_xInitHeap_xax_IN_xoxopn_FILE_xbexport                                        100013
#define NO_ENOUGH_MEMORY_1_IN_xoxopn_FILE_xbexport                                            100023
#define NO_ENOUGH_MEMORY_2_IN_xoxopn_FILE_xbexport                                            100033
#define ERROR_IN_xInitShapes_xox_IN_xoxopn_FILE_xbexport                                      100043
#define ERROR_IN_xShapesSetStatusPrintMode_xax_IN_xoxopn_FILE_xbexport                        100053
#define ERROR_IN_xShapesSetWarnMode_xax_IN_xoxopn_FILE_xbexport                               100063
#define ERROR_IN_xStartShapesLog_xox_IN_xoxopn_FILE_xbexport                                  100073
#define ERROR_IN_xBooleanTolerancesSet_xax_IN_xoxopn_FILE_xbexport                            100083
#define ERROR_IN_xLoopSplittingModeSet_xax_IN_xoxopn_FILE_xbexport                            100093
#define ERROR_IN_xoxSetErrorHandler_xox_IN_xoxopn_FILE_xbexport                               100103 
#define ERROR_IN_xUserIdsSet_xax_IN_xoxopn_FILE_xbexport                                      100113 
#define ERROR_IN_xGeomAttrHandlersSet_xax_IN_xoxopn_FILE_xbexport                             100123
#define ERROR_IN_xShapesGraphicsInit_xax_IN_xoxopn_FILE_xbexport                              100133

#define CAN_NOT_FREE_MEMORY_1_IN_xoxcls_FILE_xbexport                                         100143
#define CAN_NOT_FREE_MEMORY_2_IN_xoxcls_FILE_xbexport                                         100153
#define ERROR_IN_xaxDbaseFree_IN_xoxcls_FILE_xbexport                                         100163  
#define ERROR_IN_xShapesGraphicsClose_xax_IN_xoxcls_FILE_xbexport                             100173
#define ERROR_IN_xFreeAnsysMemory_xox_IN_xoxcls_FILE_xbexport                                 100183
#define ERROR_IN_xEndShapesLog_xox_IN_xoxcls_FILE_xbexport                                    100193
#define ERROR_IN_xSetTols_xox_IN_xoxcls_FILE_xbexport                                         100203
#define ERROR_IN_xClearError_xox_IN_xoxcls_FILE_xbexport                                      100213
#define ERROR_IN_xDisconnectShapes_xox_IN_xoxcls_FILE_xbexport                                100223
#define ERROR_IN_xEndLog_xax_IN_xoxcls_FILE_xbexport                                          100233
#define ERROR_IN_xCloseHeap_xax_xoxcls_FILE_xbexport                                          100243

#define ERROR_IN_xtkpc_IN_xconvt_FILE_xbexport                                                100253
#define ERROR_IN_xtlsc_IN_xconvt_FILE_xbexport                                                100263
#define ERROR_IN_xtarc_IN_xconvt_FILE_xbexport                                                100273
#define ERROR_IN_xtvuc_IN_xconvt_FILE_xbexport                                                100283
#define ERROR_IN_xtptc_IN_xconvt_FILE_xbexport                                                100293
#define ERROR_IN_xtslc_IN_xconvt_FILE_xbexport                                                100303
#define ERROR_IN_xtsac_IN_xconvt_FILE_xbexport                                                100313
#define ERROR_IN_xtsvc_IN_xconvt_FILE_xbexport                                                100323
#define ERROR_IN_xGmDetectNonManifold_xox_IN_xconvt_FILE_xbexport                             100333
#define ERROR_IN_xfptc_IN_xconvt_FILE_xbexport                                                100343
#define ERROR_IN_xfslc_IN_xconvt_FILE_xbexport                                                100353
#define ERROR_IN_xfarc_IN_xconvt_FILE_xbexport                                                100363
#define ERROR_IN_xfsvc_IN_xconvt_FILE_xbexport                                                100373

#define ERROR_IN_xtxy_wpplan_IN_xconvt_wp_FILE_xbexport                                       100383
#define ERROR_IN_xtxy_wpplan                                                                  100388
#define ERROR_IN_xtxy_wpplan_IN_trans                                                         100393
#define ERROR_IN_xUserIdSet_xax_IN_xtxy_wplane                                                100394

#define ERROR_IN_xGmCopy_xox_1_IN_xhalfspaces_FILE_xbexport                                   100395
#define ERROR_IN_xGmNewHalfspace_xox_IN_xhalfspaces_FILE_xbexport                             100396
#define ERROR_IN_xGmCopy_xox_2_IN_xhalfspaces_FILE_xbexport                                   100397
#define ERROR_IN_xGmComplement_xox_IN_xhalfspaces_FILE_xbexport                               100398
#define ERROR_IN_xNullGeomP_xox_1_IN_xsubc_sepo_FILE_xbexport                                 100399
#define ERROR_IN_xGmFindCellGeoms_xox_1_IN_xsubc_sepo_FILE_xbexport                           100400
#define ERROR_IN_xIntListGetLength_xox_1_IN_xsubc_sepo_FILE_xbexport                          100401
#define NO_ENOUGH_MEMORY_1_IN_xsubc_sepo_FILE_xbexport                                        100402
#define ERROR_IN_xCopyIntList_xax_1_IN_xsubc_sepo_FILE_xbexport                               100403
#define ERROR_IN_xIntListDelete_1_xox_IN_xsubc_sepo_FILE_xbexport                             100404
#define ERROR_IN_xhalfspaces_IN_xsubc_sepo_FILE_xbexport                                      100405
#define ERROR_IN_xsewnc_IN_xsubc_sepo_FILE_xbexport                                           100406
#define ERROR_IN_xdiffn_1_IN_xsubc_sepo_FILE_xbexport                                         100407
#define ERROR_IN_xdiffn_2_IN_xsubc_sepo_FILE_xbexport                                         100408
#define ERROR_IN_xgrpc_1_IN_xsubc_sepo_FILE_xbexport                                          100409
#define ERROR_IN_xaddss_IN_xsubc_sepo_FILE_xbexport                                           100410
#define ERROR_IN_xdiffn_3_IN_xsubc_sepo_FILE_xbexport                                         100411
#define ERROR_IN_xdiffn_4_IN_xsubc_sepo_FILE_xbexport                                         100412
#define ERROR_IN_xgrpc_2_IN_xsubc_sepo_FILE_xbexport                                          100413
#define ERROR_IN_xdiffn_5_IN_xsubc_sepo_FILE_xbexport                                         100414
#define ERROR_IN_xdiffn_6_IN_xsubc_sepo_FILE_xbexport                                         100415
#define ERROR_IN_xgrpc_3_IN_xsubc_sepo_FILE_xbexport                                          100416
#define ERROR_IN_xGmClassify_xax_IN_xsubc_sepo_FILE_xbexport                                  100417
#define ERROR_IN_xIntListGetNth_xox_1_IN_xsubc_sepo_FILE_xbexport                             100418
#define ERROR_IN_xNullGeomP_xox_2_IN_xsubc_sepo_FILE_xbexport                                 100419
#define ERROR_IN_xIntListGetNth_xox_2_IN_xsubc_sepo_FILE_xbexport                             100420
#define ERROR_IN_xNullGeomP_xox_3_IN_xsubc_sepo_FILE_xbexport                                 100421
#define ERROR_IN_xIntListDelete_xox_2_IN_xsubc_sepo_FILE_xbexport                             100422
#define ERROR_IN_xgrpc_4_IN_xsubc_sepo_FILE_xbexport                                          100423
#define ERROR_IN_xgrpc_5_IN_xsubc_sepo_FILE_xbexport                                          100424
#define ERROR_IN_xGmCopySupCtrldCells_xox_IN_xsubc_sepo_FILE_xbexport                         100425
#define ERROR_IN_xGmFindCellGeoms_xox_2_IN_xsubc_sepo_FILE_xbexport                           100426
#define ERROR_IN_xGmFindCellGeoms_xox_3_IN_xsubc_sepo_FILE_xbexport                           100427
#define ERROR_IN_xIntListGetLength_xox_2_IN_xsubc_sepo_FILE_xbexport                          100428
#define ERROR_IN_xIntListGetLength_xox_3_IN_xsubc_sepo_FILE_xbexport                          100429
#define NO_ENOUGH_MEMORY_2_IN_xsubc_sepo_FILE_xbexport                                        100430
#define ERROR_IN_xCopyIntList_xax_2_IN_xsubc_sepo_FILE_xbexport                               100431
#define ERROR_IN_xCopyIntList_xax_3_IN_xsubc_sepo_FILE_xbexport                               100432
#define ERROR_IN_xIntListDelete_xox_3_IN_xsubc_sepo_FILE_xbexport                             100433
#define ERROR_IN_xIntListDelete_xox_4_IN_xsubc_sepo_FILE_xbexport                             100434
#define ERROR_IN_xgrpc_6_IN_xsubc_sepo_FILE_xbexport                                          100435
#define CAN_NOT_FREE_MEMORY_1_IN_xsubc_sepo_FILE_xbexport                                     100436
#define CAN_NOT_FREE_MEMORY_2_IN_xsubc_sepo_FILE_xbexport                                     100437
#define ERROR_IN_xsubc_sepo_1_IN_xsubc_sepo_FILE_xbexport                                     100438
#define ERROR_IN_xsubc_sepo_2_IN_xsubc_sepo_FILE_xbexport                                     100439
#define NO_ENOUGH_MEMORY_1_IN_xcomp_conn_FILE_xbexport                                        100440
#define NO_ENOUGH_MEMORY_2_IN_xcomp_conn_FILE_xbexport                                        100441
#define ERROR_IN_xGmFindKSkeleton_xox_IN_xcomp_conn_FILE_xbexport                             100442
#define ERROR_IN_xIntListGetLength_xox_IN_xcomp_conn_FILE_xbexport                            100443
#define NO_ENOUGH_MEMORY_3_IN_xcomp_conn_FILE_xbexport                                        100444
#define ERROR_IN_xCopyIntList_xax_IN_xcomp_conn_FILE_xbexport                                 100445
#define ERROR_IN_xIntListDelete_xox_IN_xcomp_conn_FILE_xbexport                               100446
#define CAN_NOT_FREE_MEMORY_1_IN_xcomp_conn_FILE_xbexport                                     100447
#define ERROR_IN_xsewnc_IN_xcomp_conn_FILE_xbexport                                           100448
#define ERROR_IN_xGmFindCellGeoms_xox_IN_xngeom_FILE_xbexport                                 100449
#define ERROR_IN_xIntListGetLength_xox_IN_xngeom_FILE_xbexport                                100450
#define ERROR_IN_xIntListDelete_xox_IN_xngeom_FILE_xbexport                                   100451
#define ERROR_IN_xGmFindCellGeoms_xox_IN_xgeoms_FILE_xbexport                                 100452
#define ERROR_IN_xIntListGetLength_xox_IN_xgeoms_FILE_xbexport                                100453
#define ERROR_IN_xCopyIntList_xax_IN_xgeoms_FILE_xbexport                                     100463
#define ERROR_IN_xGmGetDim_xox_1_IN_xgeoms_FILE_xbexport                                      100473
#define ERROR_IN_xGmGetDim_xox_2_IN_xgeoms_FILE_xbexport                                      100483

#define ERROR_IN_xGmClassify_xax_IN_xclafy_FILE_xbexport                                      100503
#define ERROR_IN_xIntListGetNth_xox_1_IN_xclafy_FILE_xbexport                                 100513
#define ERROR_IN_xIntListGetNth_xox_2_IN_xclafy_FILE_xbexport                                 100523
#define ERROR_IN_xgrpc_IN_xdiffn_FILE_xbexport                                                100533
#define ERROR_IN_xGmCopy_xox_1_IN_xdiffn_FILE_xbexport                                        100543
#define ERROR_IN_xGmCopy_xox_2_IN_xdiffn_FILE_xbexport                                        100553
#define ERROR_IN_xGmSubtract_xox_IN_xdiffn_FILE_xbexport                                      100563
#define ERROR_IN_xNullGeomP_xox_IN_xdiffn_FILE_xbexport                                       100572

#define ERROR_IN_xGmGetDim_xox_IN_xsubc_FILE_xbexport                                         100573
#define ERROR_IN_xGmFindCellGeoms_xox_IN_xsubc_FILE_xbexport                                  100574
#define ERROR_IN_xIntListGetLength_xox_IN_xsubc_FILE_xbexport                                 100575
#define ERROR_IN_xCopyIntList_xax_IN_xsubc_FILE_xbexport                                      100576
#define ERROR_IN_xcomp_conn_IN_xsubc_FILE_xbexport                                            100577
#define ERROR_IN_xsubc_sepo_3_IN_xsubc_FILE_xbexport                                          100578
#define ERROR_IN_xaddss_2_IN_xsubc_FILE_xbexport                                              100579
#define ERROR_IN_xgrpc_5_IN_xsubc_FILE_xbexport                                               100580
#define ERROR_IN_xgrpc_1_IN_xsubc_FILE_xbexport                                               100583
#define ERROR_IN_xgrpc_2_IN_xsubc_FILE_xbexport                                               100593
#define ERROR_IN_xgrpc_3_IN_xsubc_FILE_xbexport                                               100603
#define ERROR_IN_xsewnc_1_IN_xsubc_FILE_xbexport                                              100613
#define ERROR_IN_xsewnc_2_IN_xsubc_FILE_xbexport                                              100623
#define ERROR_IN_xsewnc_3_IN_xsubc_FILE_xbexport                                              100633
#define ERROR_IN_xdiffn_1_IN_xsubc_FILE_xbexport                                              100643
#define ERROR_IN_xaddss_1_IN_xsubc_FILE_xbexport                                              100653
#define ERROR_IN_xdiffn_2_IN_xsubc_FILE_xbexport                                              100663
#define ERROR_IN_xdiffn_3_IN_xsubc_FILE_xbexport                                              100673
#define ERROR_IN_xdiffn_4_IN_xsubc_FILE_xbexport                                              100683
#define NO_ENOUGH_MEMORY_1_IN_xsubc_FILE_xbexport                                             100684
#define NO_ENOUGH_MEMORY_2_IN_xsubc_FILE_xbexport                                             100685
#define ERROR_IN_xgrpc_4_IN_xsubc_FILE_xbexport                                               100686
#define CAN_NOT_FREE_MEMORY_1_IN_xsubc_FILE_xbexport                                          100687
#define CAN_NOT_FREE_MEMORY_2_IN_xsubc_FILE_xbexport                                          100688
#define ERROR_IN_xsubc_sepo_1_IN_xsubc_FILE_xbexport                                          100689
#define ERROR_IN_xsubc_sepo_2_IN_xsubc_FILE_xbexport                                          100690
#define ERROR_IN_xIntersectingGeomsP_xox_IN_xintst_FILE_xbexport                              100693
#define ERROR_IN_xgrpc_IN_xintss_FILE_xbexport                                                100703
#define ERROR_IN_xGmIntersect_xax_IN_xintss_FILE_xbexport                                     100713
#define ERROR_IN_xgrpc_IN_xintsp_FILE_xbexport                                                100723
#define ERROR_IN_xGmIntersect_xax_IN_xintsp_FILE_xbexport                                     100733
#define ERROR_IN_xIntListPush_xox_IN_xintsp_FILE_xbexport                                     100743
#define ERROR_IN_xGmGroup_xox_IN_xintsp_FILE_xbexport                                         100753
#define ERROR_IN_xNullGeomP_xox_IN_xintsp_FILE_xbexport                                       100763
#define ERROR_IN_xIntListDelete_xox_IN_xintsp_FILE_xbexport                                   100773
#define ERROR_IN_xgrpc_IN_xaddss_FILE_xbexport                                                100783
#define ERROR_IN_xGmGetDim_xox_1_IN_xaddss_FILE_xbexport                                      100793
#define ERROR_IN_xGmGetDim_xox_2_IN_xaddss_FILE_xbexport                                      100803 
#define ERROR_IN_xGmUnionMerge_xax_IN_xaddss_FILE_xbexport                                    100813
#define ERROR_IN_xGmUnion_xax_IN_xaddss_FILE_xbexport                                         100823
#define ERROR_IN_xgrpc_IN_xmerss_FILE_xbexport                                                100833
#define ERROR_IN_xGmUnionMerge_xax_IN_xmerss_FILE_xbexport                                    100843
#define ERROR_IN_xgrpc_IN_xovers_FILE_xbexport                                                100853
#define ERROR_IN_xGmOverlap_xax_IN_xovers_FILE_xbexport                                       100863
#define ERROR_IN_xGmUnionMerge_xax_IN_xovers_FILE_xbexport                                    100873

#define ERROR_IN_xGmSimplify_xox_IN_xgsimp_FILE_xbexport                                      100883

#define ERROR_IN_xGmCopy_xox_1_IN_xcutc_FILE_xbexport                                         100893
#define ERROR_IN_xGmNewHalfspace_xox_IN_xcutc_FILE_xbexport                                   100903
#define ERROR_IN_xGmCopy_xox_2_IN_xcutc_FILE_xbexport                                         100913
#define ERROR_IN_xGmCopy_xox_3_IN_xcutc_FILE_xbexport                                         100923
#define ERROR_IN_xGmClassify_xox_IN_xcutc_FILE_xbexport                                       100933
#define ERROR_IN_xIntListGetNth_xox_1_IN_xcutc_FILE_xbexport                                  100943
#define ERROR_IN_xIntListGetNth_xox_2_IN_xcutc_FILE_xbexport                                  100953
#define ERROR_IN_xIntListDelete_xox_IN_xcutc_FILE_xbexport                                    100963
#define ERROR_IN_xNullGeomP_xox_IN_xcutc_FILE_xbexport                                        100973
#define ERROR_IN_xFreeId_xox_1_IN_xcutc_FILE_xbexport                                         100983
#define ERROR_IN_xFreeId_xox_2_IN_xcutc_FILE_xbexport                                         100993

#define ERROR_IN_xGmFindKSkeleton_xox_IN_xdstpg_FILE_xbexport                                 101003
#define NO_ZERO_SUB_GEOMS_IN_xdstpg_FILE_xbexport                                             101013
#define ERROR_IN_xIntListGetNth_xox_IN_xdstpg_FILE_xbexport                                   101023
#define ERROR_IN_xptcog_IN_xdstpg_FILE_xbexport                                               101033

#define ERROR_IN_xGmFindMinVertForPnt_xox_IN_xdstpg_FILE_xbexport                             101043
#define ERROR_IN_xVertexCoords_xox_IN_xdstpg_FILE_xbexport                                    101053
#define ERROR_IN_xPointGeom_xox_IN_xdstpg_FILE_xbexport                                       101063

#define ERROR_IN_xptcog_IN_xevalg_FILE_xbexport                                               101083
#define ERROR_IN_xCellFindPrmsRng_xox_IN_xevalg_FILE_xbexport                                 101093
#define ERROR_IN_xCellEvalPnt_xox_1_IN_xevalg_FILE_xbexport                                   101103
#define ERROR_IN_xPointGeom_xox_1_IN_xevalg_FILE_xbexport                                     101113
#define ERROR_IN_xGmCopy_xox_2_IN_xevalg_FILE_xbexport                                        101123
#define ERROR_IN_xCellEvalPnt_xox_2_IN_xevalg_FILE_xbexport                                   101133
#define ERROR_IN_xPointGeom_xox_2_IN_xevalg_FILE_xbexport                                     101143

#define ERROR_IN_xGmCopy_xox_IN_xsewnc_FILE_xbexport                                          101153
#define ERROR_IN_xIntListPush_xox_IN_xsewnc_FILE_xbexport                                     101163
#define ERROR_IN_xSewnGeom_xox_IN_xsewnc_FILE_xbexport                                        101173
#define ERROR_IN_xIntListDelete_xox_IN_xsewnc_FILE_xbexport                                   101183
#define ERROR_IN_xGmCopy_xox_IN_xgrpc_FILE_xbexport                                           101193
#define ERROR_IN_xIntListPush_xox_IN_xgrpc_FILE_xbexport                                      101203
#define ERROR_IN_xGmGroup_xox_IN_xgrpc_FILE_xbexport                                          101213
#define ERROR_IN_xIntListDelete_xox_IN_xgrpc_FILE_xbexport                                    101223

#define ERROR_IN_xGmGetDim_xox_IN_xnseam_FILE_xbexport                                        101233
#define ERROR_IN_xGmFindKSeams_xox_1_IN_xnseam_FILE_xbexport                                  101243
#define ERROR_IN_xIntListGetLength_xox_1_IN_xnseam_FILE_xbexport                              101253
#define ERROR_IN_xGmFindKSeams_xox_2_IN_xnseam_FILE_xbexport                                  101263
#define ERROR_IN_xIntListGetLength_xox_2_IN_xnseam_FILE_xbexport                              101273 
#define ERROR_IN_xGmFindKSeams_xox_3_IN_xnseam_FILE_xbexport                                  101283
#define ERROR_IN_xIntListGetLength_xox_3_IN_xnseam_FILE_xbexport                              101293 

#define ERROR_IN_xGmGetDim_xox_IN_xnsub_FILE_xbexport                                         101313
#define ERROR_IN_xGmFindKSkeleton_xox_1_IN_xnsub_FILE_xbexport                                101323
#define ERROR_IN_xIntListGetLength_xox_1_IN_xnsub_FILE_xbexport                               101333
#define ERROR_IN_xGmFindKSkeleton_xox_2_IN_xnsub_FILE_xbexport                                101343
#define ERROR_IN_xIntListGetLength_xox_2_IN_xnsub_FILE_xbexport                               101353
#define ERROR_IN_xGmFindKSkeleton_xox_3_IN_xnsub_FILE_xbexport                                101363
#define ERROR_IN_xIntListGetLength_xox_3_IN_xnsub_FILE_xbexport                               101373

#define ERROR_IN_xGmFindCellGeoms_xox_IN_xfiltr_FILE_xbexport                                 101403
#define ERROR_IN_xIntListGetLength_xox_IN_xfiltr_FILE_xbexport                                101413
#define ERROR_IN_xIntListGetNth_xox_1_IN_xfiltr_FILE_xbexport                                 101423
#define ERROR_IN_xGmGetDim_xox_IN_xfiltr_FILE_xbexport                                        101433
#define ERROR_IN_xGmCopy_xox_1_IN_xfiltr_FILE_xbexport                                        101443
#define ERROR_IN_xIntListPush_xox_IN_xfiltr_FILE_xbexport                                     101453
#define ERROR_IN_xIntListGetNth_xox_2_IN_xfiltr_FILE_xbexport                                 101463
#define ERROR_IN_xSewnGeom_xox_IN_xfiltr_FILE_xbexport                                        101473
#define ERROR_IN_xIntListDelete_xox_1_IN_xfiltr_FILE_xbexport                                 101483
#define ERROR_IN_xIntListDelete_xox_2_IN_xfiltr_FILE_xbexport                                 101493

#define ERROR_IN_stkilc_IN_ahpini_FILE_xbexport                                               101603
#define ERROR_IN_xInitHeap_att_IN_ahpini_FILE_xbexport                                        101613
#define ERROR_IN_xCloseHeap_att_IN_ahpcls_FILE_xbexport                                       101623

#define ERROR_IN_xGmFindCellGeoms_xox_IN_xvusvq_FILE_xbshape                                  200001
#define ERROR_IN_xIntListGetLength_xox_IN_xvusvq_FILE_xbshape                                 200011
#define ERROR_IN_xIntListDelete_xox_IN_xvusvq_FILE_xbshape                                    200021
#define ERROR_IN_xGmFindCellGeoms_xox_IN_xvusvg_FILE_xbshape                                  200031
#define ERROR_IN_xCopyIntList_xax_IN_xvusvg_FILE_xbshape                                      200041
#define ERROR_IN_xIntListDelete_xox_IN_xvusvg_FILE_xbshape                                    200051
#define ERROR_IN_xNumGeomFrames_xox_IN_xvushq_FILE_xbshape                                    200061
#define NO_ENOUGH_MEMORY_1_IN_xvushg_FILE_xbshape                                             200071
#define ERROR_IN_xGeomFrameTreeA_xox_IN_xvushg_FILE_xbshape                                   200081
#define ERROR_IN_xNumGeomFrames_xox_IN_xsvshq_FILE_xbshape                                    200091
#define NO_ENOUGH_MEMORY_1_IN_xsvshg_FILE_xbshape                                             200101
#define ERROR_IN_xGeomFrameTreeA_xox_IN_xsvshg_FILE_xbshape                                   200111
#define ERROR_IN_xNumFrameComponents_xox_IN_xshsaq_FILE_xbshape                               200121
#define SHAPES_SHELL_HAVING_1_XSUBAREA_IN_xshsaq_FILE_xbshape                                 200131
#define SHAPES_SHELL_HAVING_LESS_THAN_1_XSUBAREA_IN_xshsaq_FILE_xbshape                       200141
#define ERROR_IN_xFrameComponentsA_xox_IN_xshsag_FILE_xbshape                                 200151
#define NO_ENOUGH_MEMORY_1_IN_xshsag_FILE_xbshape                                             200161
#define ERROR_IN_xFrameComponentOrientsA_xox_IN_xshsag_FILE_xbshape                           200171
#define ERROR_IN_xGmFindCellGeoms_xox_IN_xarsaq_FILE_xbshape                                  200181
#define ERROR_IN_xIntListGetLength_xox_IN_xarsaq_FILE_xbshape                                 200191
#define ERROR_IN_xIntListDelete_xox_IN_xarsaq_FILE_xbshape                                    200201
#define ERROR_IN_xGmFindCellGeoms_xox_IN_xarsag_FILE_xbshape                                  200211
#define ERROR_IN_xCopyIntList_xax_IN_xarsag_FILE_xbshape                                      200221
#define ERROR_IN_xIntListDelete_xox_IN_xarsag_FILE_xbshape                                    200231
#define ERROR_IN_xNumGeomFrames_xox_IN_xarlpq_FILE_xbshape                                    200241
#define NO_ENOUGH_MEMORY_1_IN_xarlpg_FILE_xbshape                                             200251
#define ERROR_IN_xGeomFrameTreeA_xox_IN_xarlpg_FILE_xbshape                                   200261
#define ERROR_IN_xNumGeomFrames_xox_IN_xsalpq_FILE_xbshape                                    200271
#define NO_ENOUGH_MEMORY_1_IN_xsalpg_FILE_xbshape                                             200281
#define ERROR_IN_xGeomFrameTreeA_xox_IN_xsalpg_FILE_xbshape                                   200291
#define ERROR_IN_xNumFrameComponents_xox_IN_xlpslq_FILE_xbshape                               200301
#define NO_ENOUGH_MEMORY_1_IN_xlpslg_FILE_xbshape                                             200311
#define ERROR_IN_xFrameComponentOrientsA_xox_IN_xlpslg_FILE_xbshape                           200321
#define ERROR_IN_xFrameComponentsA_xox_IN_xlpslg_FILE_xbshape                                 200331
#define ERROR_IN_xslptt_1_IN_xlpslg_FILE_xbshape                                              200341
#define ERROR_IN_xslptt_2_IN_xlpslg_FILE_xbshape                                              200351
#define ERROR_IN_xslptg_IN_xlpslg_FILE_xbshape                                                200361
#define SHAPES_NON_MANIFOLD_GEOMETRY_IN_xlpslg_FILE_xbshape                                   200371
#define SHAPES_LOOP_HAVING_2_XSUBLINES_IN_xlpslg_FILE_xbshape                                 200381
#define SHAPES_LOOP_HAVING_1_XSUBLINE_IN_xlpslg_FILE_xbshape                                  200391
#define SHAPES_LOOP_HAVING_LESS_THAN_1_XSUBLINE_IN_xlpslg_FILE_xbshape                        200401
#define ERROR_IN_xNumFrameComponents_xox_IN_xlpchk_FILE_xbshape                               200411
#define SHAPES_LOOP_HAVING_LESS_THAN_1_XSUBLINE_IN_xlpchk_FILE_xbshape                        200421
#define NO_ENOUGH_MEMORY_1_IN_xlpchk_FILE_xbshape                                             200431
#define ERROR_IN_xlpslg_IN_xlpchk_FILE_xbshape                                                200441
#define ERROR_IN_xslptg_IN_xlpchk_FILE_xbshape                                                200451
#define ERROR_IN_xGmFindCellGeoms_xox_IN_xlsslq_FILE_xbshape                                  200461
#define ERROR_IN_xIntListGetLength_xox_IN_xlsslq_FILE_xbshape                                 200471
#define ERROR_IN_xIntListDelete_xox_IN_xlsslq_FILE_xbshape                                    200481
#define ERROR_IN_xGmFindCellGeoms_xox_IN_xlsslg_FILE_xbshape                                  200491
#define ERROR_IN_xCopyIntList_xax_IN_xlsslg_FILE_xbshape                                      200501
#define ERROR_IN_xIntListDelete_xox_IN_xlsslg_FILE_xbshape                                    200511
#define ERROR_IN_xGmFindSubGeoms_xox_IN_xslptt_FILE_xbshape                                   200521
#define ERROR_IN_xIntListGetLength_xox_1_IN_xslptt_FILE_xbshape                               200531
#define NUMBER_OF_ENDPOINTS_NOT_EQUAL_2_IN_xslptt_FILE_xbshape                                200541
#define ERROR_IN_xIntListGetNth_xox_1_IN_xslptt_FILE_xbshape                                  200551
#define ERROR_IN_xIntListGetNth_xox_2_IN_xslptt_FILE_xbshape                                  200561
#define ERROR_IN_xSubGeomOrientations_xox_IN_xslptt_FILE_xbshape                              200571
#define ERROR_IN_xIntListGetLength_xox_3_IN_xslptt_FILE_xbshape                               200581
#define ERROR_IN_xIntListGetLength_xox_4_IN_xslptt_FILE_xbshape                               200591
#define ERROR_IN_xIntListGetNth_xox_3_IN_xslptt_FILE_xbshape                                  200601
#define ERROR_IN_xIntListGetNth_xox_4_IN_xslptt_FILE_xbshape                                  200611
#define ERROR_IN_xIntListDelete_1_xox_IN_xslptt_FILE_xbshape                                  200621
#define ERROR_IN_xIntListDelete_2_xox_IN_xslptt_FILE_xbshape                                  200631
#define ERROR_IN_xslptt_IN_xslptg_FILE_xbshape                                                200641
#define ERROR_IN_xAnsysNsurFromGeom_xox_IN_xsasuq_FILE_xbshape                                200651
#define OLD_GEOMETRY_IN_xsasuq_FILE_xbshape                                                   200661
#define ERROR_IN_xAnsysSurFromGeom_xox_IN_xsasug_FILE_xbshape                                 200671
#define OLD_GEOMETRY_IN_xsasug_FILE_xbshape                                                   200681
#define XOX_DATA_LENGTH_IS_TOO_SMALL_IN_xslcuq_FILE_xbshape                                   200691
#define ERROR_IN_xAnsysNcurFromGeom_xox_IN_xslcuq_FILE_xbshape                                200701
#define OLD_GEOMETRY_IN_xslcuq_FILE_xbshape                                                   200711
#define XOX_DATA_LENGTH_IS_TOO_SMALL_IN_xslcug_FILE_xbshape                                   200721
#define ERROR_IN_xAnsysCurFromGeom_xox_IN_xslcug_FILE_xbshape                                 200731
#define OLD_GEOMETRY_IN_xslcug_FILE_xbshape                                                   200741
#define ERROR_IN_xVertexForParams_xox_IN_xptcog_FILE_xbshape                                  200751
#define ERROR_IN_xVertexCoords_IN_xptcog_FILE_xbshape                                         200761
#define ERROR_IN_xFreeId_xox_IN_xptcog_FILE_xbshape                                           200771
#define ERROR_IN_xPointGeom_IN_xptcr_FILE_xbshape                                             200781
#define ERROR_IN_xUserIdSet_xax_IN_xptcr_FILE_xbshape                                         200791
#define ERROR_IN_xGeomAttrCellSet_xax_IN_xptcr_FILE_xbshape                                   200801
#define ERROR_IN_xNurbGeomCurve_xax_IN_xtrmsl_FILE_xbshape                                    200811
#define ERROR_IN_xMakeFrameA_xox_1_IN_xtrmsl_FILE_xbshape                                     200821
#define ERROR_IN_xMakeFrameA_xox_2_IN_xtrmsl_FILE_xbshape                                     200831
#define ERROR_IN_xReplaceGeomFramesA_xox_IN_xtrmsl_FILE_xbshape                               200841
#define ERROR_IN_xUserIdSet_xax_IN_xtrmsl_FILE_xbshape                                        200851
#define ERROR_IN_xGeomAttrCellSet_xax_IN_xtrmsl_FILE_xbshape                                  200861
#define ERROR_IN_xGmCopy_xox_IN_xsewls_FILE_xbshape                                           200871
#define ERROR_IN_xInvertGeomOrientation_xox_IN_xsewls_FILE_xbshape                            200881
#define ERROR_IN_xIntListPush_xox_IN_xsewls_FILE_xbshape                                      200891
#define SEWING_WHEN_USING_FRAME_TREE_INPUT_IN_xsewls_FILE_xbshape                             200901
#define ERROR_IN_xSewnGeom_xox_IN_xsewls_FILE_xbshape                                         200911
#define ERROR_IN_xIntListDelete_xox_IN_xsewls_FILE_xbshape                                    200921
#define NO_ENOUGH_MEMORY_1_IN_xsewlp_FILE_xbshape                                             200931
#define ERROR_IN_xMakeFrameA_xox_IN_xsewlp_FILE_xbshape                                       200941
#define ERROR_IN_xNurbGeomSurface_xax_IN_xtrmsa_FILE_xbshape                                  200951
#define NO_ENOUGH_MEMORY_1_IN_xtrmsa_FILE_xbshape                                             200961
#define ERROR_IN_xReplaceGeomFramesA_xox_IN_xtrmsa_FILE_xbshape                               200971
#define ERROR_IN_xUserIdSet_xax_IN_xtrmsa_FILE_xbshape                                        200981
#define ERROR_IN_xGeomAttrCellSet_xax_IN_xtrmsa_FILE_xbshape                                  200991
#define ERROR_IN_xGmCopy_xox_IN_xsewar_FILE_xbshape                                           201001
#define ERROR_IN_xInvertGeomOrientation_xox_IN_xsewar_FILE_xbshape                            201011
#define ERROR_IN_xIntListPush_xox_IN_xsewar_FILE_xbshape                                      201021
#define SEWING_WHEN_USING_FRAME_TREE_INPUT_IN_xsewar_FILE_xbshape                             201031
#define ERROR_IN_xSewnGeom_xox_IN_xsewar_FILE_xbshape                                         201041
#define ERROR_IN_xIntListDelete_xox_IN_xsewar_FILE_xbshape                                    201051

#define NO_ENOUGH_MEMORY_1_IN_xsewsh_FILE_xbshape                                             201081
#define ERROR_IN_xMakeFrameA_xox_IN_xsewsh_FILE_xbshape                                       201091
#define NO_ENOUGH_MEMORY_1_IN_xtrmsv_FILE_xbshape                                             201101
#define ERROR_IN_xReplaceGeomFramesA_xox_IN_xtrmsv_FILE_xbshape                               201111
#define ERROR_IN_xUserIdSet_xax_IN_xtrmsv_FILE_xbshape                                        201121
#define ERROR_IN_xGeomAttrCellSet_xax_IN_xtrmsv_FILE_xbshape                                  201131
#define SEWING_WHEN_USING_FRAME_TREE_INPUT_IN_xsewvu_FILE_xbshape                             201141
#define ERROR_IN_xGmCopy_xox_IN_xsewvu_FILE_xbshape                                           201151
#define ERROR_IN_xInvertGeomOrientation_xox_IN_xsewvu_FILE_xbshape                            201161
#define ERROR_IN_xIntListPush_xox_IN_xsewvu_FILE_xbshape                                      201171
#define ERROR_IN_xSewnGeom_xox_IN_xsewvu_FILE_xbshape                                         201181
#define ERROR_IN_xIntListDelete_xox_IN_xsewvu_FILE_xbshape                                    201191
#define CAN_NOT_FREE_MEMORY_1_IN_xvushg_FILE_xbshape                                          201201
#define CAN_NOT_FREE_MEMORY_1_IN_xsvshg_FILE_xbshape                                          201211
#define CAN_NOT_FREE_MEMORY_1_IN_xshsag_FILE_xbshape                                          201221
#define CAN_NOT_FREE_MEMORY_1_IN_xarlpg_FILE_xbshape                                          201231
#define CAN_NOT_FREE_MEMORY_1_IN_xsalpg_FILE_xbshape                                          201241
#define CAN_NOT_FREE_MEMORY_1_IN_xlpslg_FILE_xbshape                                          201251
#define CAN_NOT_FREE_MEMORY_1_IN_xlpchk_FILE_xbshape                                          201261
#define CAN_NOT_FREE_MEMORY_1_IN_xsewlp_FILE_xbshape                                          201271
#define CAN_NOT_FREE_MEMORY_1_IN_xtrmsa_FILE_xbshape                                          201281
#define CAN_NOT_FREE_MEMORY_1_IN_xsewsh_FILE_xbshape                                          201291
#define CAN_NOT_FREE_MEMORY_1_IN_xtrmsv_FILE_xbshape                                          201301
#define ERROR_IN_xPreImageFrame_IN_FILE_xbshape                                               201311
#define ERROR_IN_xReplaceFrames_FILE_xbshape                                                  201321

#define ERROR_IN_vlviqr_IN_vusvq_FILE_xbansys                                                 300102
#define ANSYS_COMPOSITE_VOLUME_IN_vusvq_FILE_xbansys                                          300112

#define ERROR_IN_vlvget_IN_vusvg_FILE_xbansys                                                 300202

#define ERROR_IN_vlaiqr_IN_svshq_FILE_xbansys                                                 300302
#define ERROR_IN_svaiqr_IN_svshq_FILE_xbansys                                                 300312

#define ERROR_IN_vlgtre_IN_svshg_FILE_xbansys                                                 300402
#define ERROR_IN_svgtre_IN_svshg_FILE_xbansys                                                 300412

#define ERROR_IN_vlaiqr_IN_shsaq_FILE_xbansys                                                 300502
#define ANSYS_SHELL_HAVING_1_AREA_IN_shsaq_FILE_xbansys                                       300512
#define ANSYS_SHELL_HAVING_1_SUBAREA_IN_shsaq_FILE_xbansys                                    300522
#define ANSYS_SHELL_HAVING_LESS_THAN_1_AREA_IN_shsaq_FILE_xbansys                             300532
#define ANSYS_SHELL_HAVING_LESS_THAN_1_SUBAREA_IN_shsaq_FILE_xbansys                          300542
#define ERROR_IN_svaiqr_IN_shsaq_FILE_xbansys                                                 300552

#define ERROR_IN_vlaget_IN_shsag_FILE_xbansys                                                 300602
#define ERROR_IN_svagto_IN_shsag_FILE_xbansys                                                 300612

#define ERROR_IN_araiqr_IN_arsaq_FILE_xbansys                                                 300702
#define ANSYS_COMPOSITE_AREA_IN_arsaq_FILE_xbansys                                            300712

#define ERROR_IN_araget_IN_arsag_FILE_xbansys                                                 300802

#define ERROR_IN_arliqr_IN_salpq_FILE_xbansys                                                 300902
#define ERROR_IN_saliqr_IN_salpq_FILE_xbansys                                                 300912

#define ERROR_IN_argtre_IN_salpg_FILE_xbansys                                                 301002
#define ERROR_IN_sagtre_IN_salpg_FILE_xbansys                                                 301012

#define ERROR_IN_arliqr_IN_lpslq_FILE_xbansys                                                 301102
#define ANSYS_LOOP_HAVING_2_LINES_IN_lpslq_FILE_xbansys                                       301112
#define ANSYS_LOOP_HAVING_2_SUBLINES_IN_lpslq_FILE_xbansys                                    301122
#define ANSYS_LOOP_HAVING_1_LINE_IN_lpslq_FILE_xbansys                                        301132
#define ANSYS_LOOP_HAVING_1_SUBLINE_IN_lpslq_FILE_xbansys                                     301142
#define ANSYS_LOOP_HAVING_LESS_THAN_1_LINE_IN_lpslq_FILE_xbansys                              301152
#define ANSYS_LOOP_HAVING_LESS_THAN_1_SUBLINE_IN_lpslq_FILE_xbansys                           301162
#define ERROR_IN_saliqr_IN_lpslq_FILE_xbansys                                                 301172

#define ERROR_IN_arlgt2_IN_lpslg_FILE_xbansys                                                 301202
#define ERROR_IN_salgto_IN_lpslg_FILE_xbansys                                                 301212

#define ERROR_IN_lsliqr_IN_lsslq_FILE_xbansys                                                 301302
#define ANSYS_COMPOSITE_LINE_IN_lsslq_FILE_xbansys                                            301312

#define ERROR_IN_lsglsl_IN_lsslg_FILE_xbansys                                                 301402

#define ERROR_IN_slgpts_IN_slptg_FILE_xbansys                                                 301502

#define ERROR_IN_sainqr_IN_sasuq_FILE_xbansys                                                 301602
#define ERROR_IN_nsrget_IN_sasuq_FILE_xbansys                                                 301612

#define ERROR_IN_supgt2_IN_sasug_FILE_xbansys                                                 301702

#define ERROR_IN_slgcvn_IN_slcuq_FILE_xbansys                                                 301802
#define ERROR_IN_ncrget_IN_slcuq_FILE_xbansys                                                 301812

#define ERROR_IN_cvpgt2_IN_slcug_FILE_xbansys                                                 301902

#define ERROR_IN_svlvol_IN_vusva_FILE_xbansys                                                 302002

#define ERROR_IN_sarare_IN_arsaa_FILE_xbansys                                                 302102

#define ERROR_IN_slslsg_IN_lssla_FILE_xbansys                                                 302202

#define ERROR_IN_kpinqr_IN_kpptq_FILE_xbansys                                                 302302

#define ERROR_IN_ptggx2_IN_ptcog_FILE_xbansys                                                 302402


#define NO_ENOUGH_MEMORY_IN_sewsh_FILE_xbansys                                                302502
#define CAN_NOT_FREE_MEMORY_IN_sewsh_FILE_xbansys                                             302512


#define ERROR_IN_putare_IN_sewar_FILE_xbansys                                                 302602


#define NO_ENOUGH_MEMORY_IN_sewlp_FILE_xbansys                                                302702
#define CAN_NOT_FREE_MEMORY_IN_sewlp_FILE_xbansys                                             302712

#define ERROR_IN_slptg_1_IN_sewls_FILE_xbansys                                                302802
#define ERROR_IN_slptg_2_IN_sewls_FILE_xbansys                                                302812
#define ERROR_IN_ptskpt_IN_sewls_FILE_xbansys                                                 302822
#define ERROR_IN_volpls_IN_sewls_FILE_xbansys                                                 302832


#define NO_ENOUGH_MEMORY_IN_trmsv_FILE_xbansys                                                302902
#define CAN_NOT_FREE_MEMORY_IN_trmsv_FILE_xbansys                                             302912
#define ERROR_IN_entdup_IN_trmsv_FILE_xbansys                                                 302922
#define ERROR_IN_xaxDbaseDeleteFrameTree_1_IN_trmsv_FILE_xbansys                              302932
#define ERROR_IN_xaxDbaseDeleteFrameTree_2_IN_trmsv_FILE_xbansys                              302942
#define ANSYS_DUPLICATE_SUBVOLUMES_ALREADY_EXIST_IN_trmsv_FILE_xbansys                        302952
#define ANSYS_DUPLICATE_SUBVOLUMES_WITH_DIFFERENT_GEOMETRIES_IN_trmsv_FILE_xbansys            302962


#define SCALING_FACTOR_IS_NOT_POSITIVE_IN_trmsa_FILE_xbansys                                  303002
#define NO_ENOUGH_MEMORY_IN_trmsa_FILE_xbansys                                                303012
#define CAN_NOT_FREE_MEMORY_IN_trmsa_FILE_xbansys                                             303022
#define ERROR_IN_entdup_IN_trmsa_FILE_xbansys                                                 303032
#define ERROR_IN_xaxDbaseDeleteFrameTree_1_IN_trmsa_FILE_xbansys                              303042
#define ERROR_IN_xaxDbaseDeleteFrameTree_2_IN_trmsa_FILE_xbansys                              303042
#define ANSYS_DUPLICATE_SUBAREAS_ALREADY_EXIST_IN_trmsa_FILE_xbansys                          303052
#define ANSYS_DUPLICATE_SUBAREAS_WITH_DIFFERENT_GEOMETRIES_IN_trmsa_FILE_xbansys              303062


#define SCALING_FACTOR_IS_NOT_POSITIVE_IN_trmsl_FILE_xbansys                                  303102
#define ERROR_IN_ptcog_1_IN_trmsl_FILE_xbansys                                                303112
#define ERROR_IN_ptcog_2_IN_trmsl_FILE_xbansys                                                303122
#define ERROR_IN_sccutp_IN_trmsl_FILE_xbansys                                                 303132
#define ERROR_IN_putsl2_IN_trmsl_FILE_xbansys                                                 303142
#define ERROR_IN_entdup_IN_trmsl_FILE_xbansys                                                 303152
#define ANSYS_DUPLICATE_SUBLINES_ALREADY_EXIST_IN_trmsl_FILE_xbansys                          303162
#define ANSYS_DUPLICATE_SUBLINES_WITH_DIFFERENT_GEOMETRIES_IN_trmsl_FILE_xbansys              303172
#define NO_ENOUGH_MEMORY_IN_trmsl_FILE_xbansys                                                303182
#define CAN_NOT_FREE_MEMORY_IN_trmsl_FILE_xbansys                                             303192


#define SCALING_FACTOR_IS_NOT_POSITIVE_IN_ptcr_FILE_xbansys                                   303202
#define ERROR_IN_ptskpt_IN_ptkp_FILE_xbansys                                                  303302

#define ERROR_IN_vusvq_IN_xtvuc_FILE_xbconv                                                   400003
#define NO_ENOUGH_MEMORY_1_IN_xtvuc_FILE_xbconv                                               400013
#define ERROR_IN_vusvg_IN_xtvuc_FILE_xbconv                                                   400023
#define ERROR_IN_xtsvc_IN_xtvuc_FILE_xbconv                                                   400033
#define ERROR_IN_xsewvu_IN_xtvuc_FILE_xbconv                                                  400043
#define ANSYS_VOLUME_ALREADY_CONVERTED_IN_xtvuc_FILE_xbconv                                   400053
#define ERROR_IN_xaxDbaseInsert_IN_xtvuc_FILE_xbconv                                          400063
#define ERROR_IN_svshq_IN_xtsvc_FILE_xbconv                                                   400073
#define NO_ENOUGH_MEMORY_1_IN_xtsvc_FILE_xbconv                                               400083
#define ERROR_IN_svshg_IN_xtsvc_FILE_xbconv                                                   400093
#define ERROR_IN_xtshc_IN_xtsvc_FILE_xbconv                                                   400103
#define ERROR_IN_xtrmsv_IN_xtsvc_FILE_xbconv                                                  400113
#define ANSYS_SUBVOLUME_ALREADY_CONVERTED_IN_xtsvc_FILE_xbconv                                400133
#define ERROR_IN_xaxDbaseInsert_IN_xtsvc_FILE_xbconv                                          400143
#define ERROR_IN_shsaq_IN_xtshc_FILE_xbconv                                                   400153
#define NO_ENOUGH_MEMORY_1_IN_xtshc_FILE_xbconv                                               400163
#define ERROR_IN_shsag_IN_xtshc_FILE_xbconv                                                   400173
#define ERROR_IN_xtsac_IN_xtshc_FILE_xbconv                                                   400183
#define ERROR_IN_xsewsh_IN_xtshc_FILE_xbconv                                                  400193
#define ERROR_IN_xUserIdSet_xax_IN_xtshc_FILE_xbconv                                          400203
#define ANSYS_SHELL_ALREADY_CONVERTED_IN_xtshc_FILE_xbconv                                    400213
#define ERROR_IN_xaxDbaseInsert_IN_xtshc_FILE_xbconv                                          400223
#define ERROR_IN_arsaq_IN_xtarc_FILE_xbconv                                                   400233
#define NO_ENOUGH_MEMORY_1_IN_xtarc_FILE_xbconv                                               400243
#define ERROR_IN_arsag_IN_xtarc_FILE_xbconv                                                   400253
#define ERROR_IN_xtsac_IN_xtarc_FILE_xbconv                                                   400263
#define ERROR_IN_xsewar_IN_xtarc_FILE_xbconv                                                  400273
#define ANSYS_AREA_ALREADY_CONVERTED_IN_xtarc_FILE_xbconv                                     400283
#define ERROR_IN_xaxDbaseInsert_IN_xtarc_FILE_xbconv                                          400293
#define ERROR_IN_salpq_IN_xtsac_FILE_xbconv                                                   400303
#define NO_ENOUGH_MEMORY_1_IN_xtsac_FILE_xbconv                                               400313
#define ERROR_IN_salpg_IN_xtsac_FILE_xbconv                                                   400323
#define ERROR_IN_xtlpc_IN_xtsac_FILE_xbconv                                                   400333
#define ERROR_IN_sasuq_IN_xtsac_FILE_xbconv                                                   400343
#define NO_ENOUGH_MEMORY_2_IN_xtsac_FILE_xbconv                                               400353
#define ERROR_IN_sasug_IN_xtsac_FILE_xbconv                                                   400363
#define ERROR_IN_xtrmsa_IN_xtsac_FILE_xbconv                                                  400373
#define ANSYS_SUBAREA_ALREADY_CONVERTED_IN_xtsac_FILE_xbconv                                  400393
#define ERROR_IN_xaxDbaseInsert_IN_xtsac_FILE_xbconv                                          400403
#define ERROR_IN_lpslq_IN_xtlpc_FILE_xbconv                                                   400413
#define NO_ENOUGH_MEMORY_1_IN_xtlpc_FILE_xbconv                                               400423
#define ERROR_IN_lpslg_IN_xtlpc_FILE_xbconv                                                   400433
#define ERROR_IN_xtslc_IN_xtlpc_FILE_xbconv                                                   400443
#define ERROR_IN_xsewlp_IN_xtlpc_FILE_xbconv                                                  400453
#define ERROR_IN_xUserIdSet_xax_IN_xtlpc_FILE_xbconv                                          400463
#define ANSYS_LOOP_ALREADY_CONVERTED_IN_xtlpc_FILE_xbconv                                     400473
#define ERROR_IN_xaxDbaseInsert_IN_xtlpc_FILE_xbconv                                          400483
#define ERROR_IN_lsslq_IN_xtlsc_FILE_xbconv                                                   400493
#define NO_ENOUGH_MEMORY_1_IN_xtlsc_FILE_xbconv                                               400503
#define ERROR_IN_lsslg_IN_xtlsc_FILE_xbconv                                                   400513
#define ERROR_IN_xtslc_IN_xtlsc_FILE_xbconv                                                   400523
#define ERROR_IN_xsewls_IN_xtlsc_FILE_xbconv                                                  400533
#define ANSYS_LINE_ALREADY_CONVERTED_IN_xtlsc_FILE_xbconv                                     400543
#define ERROR_IN_xaxDbaseInsert_IN_xtlsc_FILE_xbconv                                          400553
#define ERROR_IN_slptg_IN_xtslc_FILE_xbconv                                                   400563
#define ERROR_IN_xtptc_IN_xtslc_FILE_xbconv                                                   400573
#define ERROR_IN_slcuq_IN_xtslc_FILE_xbconv                                                   400583
#define NO_ENOUGH_MEMORY_1_IN_xtslc_FILE_xbconv                                               400593
#define ERROR_IN_slcug_IN_xtslc_FILE_xbconv                                                   400603
#define ERROR_IN_xtrmsl_IN_xtslc_FILE_xbconv                                                  400613
#define ANSYS_SUBLINE_ALREADY_CONVERTED_IN_xtslc_FILE_xbconv                                  400633
#define ERROR_IN_xaxDbaseInsert_IN_xtslc_FILE_xbconv                                          400643
#define NO_ENOUGH_MEMORY_1_IN_xtkpc_FILE_xbconv                                               400653
#define ERROR_IN_kpptq_IN_xtkpc_FILE_xbconv                                                   400663
#define ERROR_IN_xtptc_IN_xtkpc_FILE_xbconv                                                   400673
#define ERROR_IN_ptcog_IN_xtptc_FILE_xbconv                                                   400683
#define ERROR_IN_xptcr_IN_xtptc_FILE_xbconv                                                   400693
#define ANSYS_POINT_ALREADY_CONVERTED_IN_xtptc_FILE_xbconv                                    400713
#define ERROR_IN_xaxDbaseInsert_IN_xtptc_FILE_xbconv                                          400723
#define ERROR_IN_xBasicGeomManifoldCheck_xax_IN_xfsvc_FILE_xbconv                             400733
#define SHAPES_NON_MANIFOLD_GEOMETRY_IN_xfsvc_FILE_xbconv                                     400743
#define ERROR_IN_xUserIdGet_xax_IN_xfsvc_FILE_xbconv                                          400753
#define ERROR_IN_xsvshq_IN_xfsvc_FILE_xbconv                                                  400763
#define NO_ENOUGH_MEMORY_1_IN_xfsvc_FILE_xbconv                                               400773
#define ERROR_IN_xsvshg_IN_xfsvc_FILE_xbconv                                                  400783
#define ERROR_IN_xfshc_IN_xfsvc_FILE_xbconv                                                   400793
#define ERROR_IN_trmsv_IN_xfsvc_FILE_xbconv                                                   400803
#define SHAPES_XSUBVOLUME_ALREADY_CONVERTED_IN_xfsvc_FILE_xbconv                              400813
#define ERROR_IN_xaxDbaseInsert_IN_xfsvc_FILE_xbconv                                          400823
#define ERROR_IN_xshsaq_IN_xfshc_FILE_xbconv                                                  400833
#define NO_ENOUGH_MEMORY_1_IN_xfshc_FILE_xbconv                                               400843
#define ERROR_IN_xshsag_IN_xfshc_FILE_xbconv                                                  400853
#define ERROR_IN_xfsac_IN_xfshc_FILE_xbconv                                                   400863
#define ERROR_IN_sewsh_IN_xfshc_FILE_xbconv                                                   400873
#define SHAPES_XSHELL_ALREADY_CONVERTED_IN_xfshc_FILE_xbconv                                  400883
#define ERROR_IN_xaxDbaseInsert_IN_xfshc_FILE_xbconv                                          400893
#define ERROR_IN_xBasicGeomManifoldCheck_xax_IN_xfsac_FILE_xbconv                             400903
#define SHAPES_NON_MANIFOLD_GEOMETRY_IN_xfsac_FILE_xbconv                                     400913
#define ERROR_IN_xUserIdGet_xax_IN_xfsac_FILE_xbconv                                          400923
#define ERROR_IN_xsalpq_IN_xfsac_FILE_xbconv                                                  400933
#define NO_ENOUGH_MEMORY_1_IN_xfsac_FILE_xbconv                                               400943
#define ERROR_IN_xsalpg_IN_xfsac_FILE_xbconv                                                  400953
#define ERROR_IN_xflpc_IN_xfsac_FILE_xbconv                                                   400963
#define ERROR_IN_sasuq_IN_xfsac_FILE_xbconv                                                   400973
#define ERROR_IN_xsasuq_IN_xfsac_FILE_xbconv                                                  400983
#define NO_ENOUGH_MEMORY_2_IN_xfsac_FILE_xbconv                                               400993
#define ERROR_IN_sasug_IN_xfsac_FILE_xbconv                                                   401003
#define ERROR_IN_xsasug_IN_xfsac_FILE_xbconv                                                  401013
#define ERROR_IN_trmsa_IN_xfsac_FILE_xbconv                                                   401023
#define ERROR_IN_entgt1_IN_xfsac_FILE_xbconv                                                  401033
#define SHAPES_XSUBAREA_ALREADY_CONVERTED_IN_xfsac_FILE_xbconv                                401043
#define ERROR_IN_xaxDbaseInsert_IN_xfsac_FILE_xbconv                                          401053
#define ERROR_IN_xlpslq_IN_xflpc_FILE_xbconv                                                  401063
#define NO_ENOUGH_MEMORY_1_IN_xflpc_FILE_xbconv                                               401073
#define ERROR_IN_xlpslg_IN_xflpc_FILE_xbconv                                                  401083
#define ERROR_IN_xfslc_IN_xflpc_FILE_xbconv                                                   401093
#define ERROR_IN_sewlp_IN_xflpc_FILE_xbconv                                                   401103
#define SHAPES_XLOOP_ALREADY_CONVERTED_IN_xflpc_FILE_xbconv                                   401113
#define ERROR_IN_xaxDbaseInsert_IN_xflpc_FILE_xbconv                                          401123
#define ERROR_IN_xUserIdGet_xax_IN_xfslc_FILE_xbconv                                          401133
#define ERROR_IN_xslptg_IN_xfslc_FILE_xbconv                                                  401143
#define ERROR_IN_xfptc_IN_xfslc_FILE_xbconv                                                   401153
#define ERROR_IN_slcuq_IN_xfslc_FILE_xbconv                                                   401163
#define ERROR_IN_xslcuq_IN_xfslc_FILE_xbconv                                                  401173
#define NO_ENOUGH_MEMORY_1_IN_xfslc_FILE_xbconv                                               401183
#define ERROR_IN_slcug_IN_xfslc_FILE_xbconv                                                   401193
#define ERROR_IN_xslcug_IN_xfslc_FILE_xbconv                                                  401203
#define ERROR_IN_trmsl_IN_xfslc_FILE_xbconv                                                   401213
#define ERROR_IN_entgt1_IN_xfslc_FILE_xbconv                                                  401223
#define SHAPES_XSUBLINE_ALREADY_CONVERTED_IN_xfslc_FILE_xbconv                                401233
#define ERROR_IN_xaxDbaseInsert_IN_xfslc_FILE_xbconv                                          401243
#define ERROR_IN_xUserIdGet_xax_IN_xfptc_FILE_xbconv                                          401253
#define ERROR_IN_xptcog_IN_xfptc_FILE_xbconv                                                  401263
#define ERROR_IN_ptcr_IN_xfptc_FILE_xbconv                                                    401273
#define SHAPES_XPOINT_ALREADY_CONVERTED_IN_xfptc_FILE_xbconv                                  401283
#define ERROR_IN_xaxDbaseInsert_IN_xfptc_FILE_xbconv                                          401293


#define CAN_NOT_FREE_MEMORY_1_IN_xtvuc_FILE_xbconv                                            401303
#define CAN_NOT_FREE_MEMORY_1_IN_xtsvc_FILE_xbconv                                            401313
#define CAN_NOT_FREE_MEMORY_1_IN_xtshc_FILE_xbconv                                            401323
#define CAN_NOT_FREE_MEMORY_1_IN_xtarc_FILE_xbconv                                            401333
#define CAN_NOT_FREE_MEMORY_1_IN_xtsac_FILE_xbconv                                            401343
#define CAN_NOT_FREE_MEMORY_2_IN_xtsac_FILE_xbconv                                            401353
#define CAN_NOT_FREE_MEMORY_1_IN_xtlpc_FILE_xbconv                                            401363
#define CAN_NOT_FREE_MEMORY_1_IN_xtlsc_FILE_xbconv                                            401373
#define CAN_NOT_FREE_MEMORY_1_IN_xtslc_FILE_xbconv                                            401383
#define CAN_NOT_FREE_MEMORY_1_IN_xtkpc_FILE_xbconv                                            401393
#define CAN_NOT_FREE_MEMORY_1_IN_xfsvc_FILE_xbconv                                            401403
#define CAN_NOT_FREE_MEMORY_1_IN_xfshc_FILE_xbconv                                            401413
#define CAN_NOT_FREE_MEMORY_1_IN_xfsac_FILE_xbconv                                            401423
#define CAN_NOT_FREE_MEMORY_2_IN_xfsac_FILE_xbconv                                            401433
#define CAN_NOT_FREE_MEMORY_1_IN_xflpc_FILE_xbconv                                            401443
#define CAN_NOT_FREE_MEMORY_1_IN_xfslc_FILE_xbconv                                            401453
#define ERROR_IN_xNurbGeomSurface_xax_IN_FILE_xbconv                                          401463
#define ERROR_IN_xNurbGeomCurve_xax_IN_FILE_xbconv                                            401473
#define ERROR_IN_xPreImageFrame_IN_xtlpc_IN_FILE_xbconv                                       401483
#define ERROR_IN_xReplaceFrames_IN_xtlpc_IN_FILE_xbconv                                       401493
#define ERROR_IN_xPreImageFrame_IN_xtslc_IN_FILE_xbconv                                       401503
#define ERROR_IN_xReplaceFrames_IN_xtslc_IN_FILE_xbconv                                       401513


#define ERROR_IN_xaxDbaseTreeNodeFree_1_IN_xaxDbaseTreeNodeFree_FILE_xbdbase                  500003   
#define ERROR_IN_xaxDbaseTreeNodeFree_2_IN_xaxDbaseTreeNodeFree_FILE_xbdbase                  500013
#define CAN_NOT_FREE_MEMORY_IN_xaxDbaseTreeNodeFree_FILE_xbdbase                              500023

#define ERROR_IN_xaxDbaseTreeNodeFree_1_IN_xaxDbaseFree_FILE_xbdbase                          500033
#define ERROR_IN_xaxDbaseTreeNodeFree_2_IN_xaxDbaseFree_FILE_xbdbase                          500043     
#define ERROR_IN_xaxDbaseTreeNodeFree_3_IN_xaxDbaseFree_FILE_xbdbase                          500053     
#define ERROR_IN_xaxDbaseTreeNodeFree_4_IN_xaxDbaseFree_FILE_xbdbase                          500063
#define ERROR_IN_xaxDbaseTreeNodeFree_5_IN_xaxDbaseFree_FILE_xbdbase                          500073
#define ERROR_IN_xaxDbaseTreeNodeFree_6_IN_xaxDbaseFree_FILE_xbdbase                          500083
#define ERROR_IN_xaxDbaseTreeNodeFree_7_IN_xaxDbaseFree_FILE_xbdbase                          500093
#define ERROR_IN_xaxDbaseTreeNodeFree_8_IN_xaxDbaseFree_FILE_xbdbase                          500103
#define ERROR_IN_xaxDbaseTreeNodeFree_9_IN_xaxDbaseFree_FILE_xbdbase                          500113
#define ERROR_IN_xaxDbaseTreeNodeFree_10_IN_xaxDbaseFree_FILE_xbdbase                         500123
#define ERROR_IN_xaxDbaseTreeNodeFree_11_IN_xaxDbaseFree_FILE_xbdbase                         500133
#define ERROR_IN_xaxDbaseTreeNodeFree_12_IN_xaxDbaseFree_FILE_xbdbase                         500143
#define ERROR_IN_xaxDbaseTreeNodeFree_13_IN_xaxDbaseFree_FILE_xbdbase                         500153
#define ERROR_IN_xaxDbaseTreeNodeFree_14_IN_xaxDbaseFree_FILE_xbdbase                         500163
#define ERROR_IN_xaxDbaseTreeNodeFree_15_IN_xaxDbaseFree_FILE_xbdbase                         500173
#define ERROR_IN_xaxDbaseTreeNodeFree_16_IN_xaxDbaseFree_FILE_xbdbase                         500183
#define ERROR_IN_xaxDbaseTreeNodeFree_17_IN_xaxDbaseFree_FILE_xbdbase                         500193
#define ERROR_IN_xaxDbaseTreeNodeFree_18_IN_xaxDbaseFree_FILE_xbdbase                         500203

#define ENTITY_EXIST_IN_xaxDbaseInsertTree_FILE_xbdbase                                       500303 
#define NO_ENOUGH_MEMORY_IN_xaxDbaseInsertTree_FILE_xbdbase                                   500313

#define ERROR_IN_xaxDbaseInsertTree_1_IN_xaxDbaseInsert_FILE_xbdbase                          500403
#define ERROR_IN_xaxDbaseInsertTree_2_IN_xaxDbaseInsert_FILE_xbdbase                          500413
#define ERROR_IN_xaxDbaseInsertTree_3_IN_xaxDbaseInsert_FILE_xbdbase                          500423
#define ERROR_IN_xaxDbaseInsertTree_4_IN_xaxDbaseInsert_FILE_xbdbase                          500433
#define ERROR_IN_xaxDbaseInsertTree_5_IN_xaxDbaseInsert_FILE_xbdbase                          500443
#define ERROR_IN_xaxDbaseInsertTree_6_IN_xaxDbaseInsert_FILE_xbdbase                          500453
#define ERROR_IN_xaxDbaseInsertTree_7_IN_xaxDbaseInsert_FILE_xbdbase                          500463
#define ERROR_IN_xaxDbaseInsertTree_8_IN_xaxDbaseInsert_FILE_xbdbase                          500473
#define ERROR_IN_xaxDbaseInsertTree_9_IN_xaxDbaseInsert_FILE_xbdbase                          500483
#define ERROR_IN_xaxDbaseInsertTree_10_IN_xaxDbaseInsert_FILE_xbdbase                         500493
#define ERROR_IN_xaxDbaseInsertTree_11_IN_xaxDbaseInsert_FILE_xbdbase                         500503
#define ERROR_IN_xaxDbaseInsertTree_12_IN_xaxDbaseInsert_FILE_xbdbase                         500513
#define ERROR_IN_xaxDbaseInsertTree_13_IN_xaxDbaseInsert_FILE_xbdbase                         500523
#define ERROR_IN_xaxDbaseInsertTree_14_IN_xaxDbaseInsert_FILE_xbdbase                         500533
#define ERROR_IN_xaxDbaseInsertTree_15_IN_xaxDbaseInsert_FILE_xbdbase                         500543
#define ERROR_IN_xaxDbaseInsertTree_16_IN_xaxDbaseInsert_FILE_xbdbase                         500553
#define ERROR_IN_xaxDbaseInsertTree_17_IN_xaxDbaseInsert_FILE_xbdbase                         500563
#define ERROR_IN_xaxDbaseInsertTree_18_IN_xaxDbaseInsert_FILE_xbdbase                         500573
#define ENTITY_EXIST_IN_xaxDbaseInsert_FILE_xbdbase                                           500583

#define ERROR_IN_xaxDbaseTreeNodeFree_1_IN_xaxDbaseDeleteEntity_FILE_xbdbase                  500603
#define ERROR_IN_xaxDbaseTreeNodeFree_2_IN_xaxDbaseDeleteEntity_FILE_xbdbase                  500613
#define ERROR_IN_xaxDbaseTreeNodeFree_3_IN_xaxDbaseDeleteEntity_FILE_xbdbase                  500623
  
#define ERROR_IN_xaxDbaseDeleteEntity_1_IN_xaxDbaseDeleteEntityPair_FILE_xbdbase              500703  
#define ERROR_IN_xaxDbaseDeleteEntity_2_IN_xaxDbaseDeleteEntityPair_FILE_xbdbase              500713 
#define ERROR_IN_xaxDbaseDeleteEntity_3_IN_xaxDbaseDeleteEntityPair_FILE_xbdbase              500723
#define ERROR_IN_xaxDbaseDeleteEntity_4_IN_xaxDbaseDeleteEntityPair_FILE_xbdbase              500733
#define ERROR_IN_xaxDbaseDeleteEntity_5_IN_xaxDbaseDeleteEntityPair_FILE_xbdbase              500743
#define ERROR_IN_xaxDbaseDeleteEntity_6_IN_xaxDbaseDeleteEntityPair_FILE_xbdbase              500753
#define ERROR_IN_xaxDbaseDeleteEntity_7_IN_xaxDbaseDeleteEntityPair_FILE_xbdbase              500763
#define ERROR_IN_xaxDbaseDeleteEntity_8_IN_xaxDbaseDeleteEntityPair_FILE_xbdbase              500773
#define ERROR_IN_xaxDbaseDeleteEntity_9_IN_xaxDbaseDeleteEntityPair_FILE_xbdbase              500783
#define ERROR_IN_xaxDbaseDeleteEntity_10_IN_xaxDbaseDeleteEntityPair_FILE_xbdbase             500793
#define ERROR_IN_xaxDbaseDeleteEntity_11_IN_xaxDbaseDeleteEntityPair_FILE_xbdbase             500803
#define ERROR_IN_xaxDbaseDeleteEntity_12_IN_xaxDbaseDeleteEntityPair_FILE_xbdbase             500813
#define ERROR_IN_xaxDbaseDeleteEntity_13_IN_xaxDbaseDeleteEntityPair_FILE_xbdbase             500823
#define ERROR_IN_xaxDbaseDeleteEntity_14_IN_xaxDbaseDeleteEntityPair_FILE_xbdbase             500833
#define ERROR_IN_xaxDbaseDeleteEntity_15_IN_xaxDbaseDeleteEntityPair_FILE_xbdbase             500843
#define ERROR_IN_xaxDbaseDeleteEntity_16_IN_xaxDbaseDeleteEntityPair_FILE_xbdbase             500853
#define ERROR_IN_xaxDbaseDeleteEntity_17_IN_xaxDbaseDeleteEntityPair_FILE_xbdbase             500863
#define ERROR_IN_xaxDbaseDeleteEntity_18_IN_xaxDbaseDeleteEntityPair_FILE_xbdbase             500873

#define NOT_VALID_ANSYS_ENTITY_TYPE_IN_xaxDbaseDeleteFrameTree_FILE_xbdbase                   500903
#define ANSYS_FRAMES_NOT_FOUND_IN_xaxDbaseDeleteFrameTree_FILE_xbdbase                        500913
#define SHAPES_FRAMES_NOT_FOUND_IN_xaxDbaseDeleteFrameTree_FILE_xbdbase                       500923
#define ERROR_IN_xaxDbaseDeleteEntityPair_IN_xaxDbaseDeleteFrameTree_FILE_xbdbase             500933

#define ERROR_IN_xGmCopy_xox_1_IN_xGmIntersect_xax_FILE_xbbool                                600001
#define ERROR_IN_xGmCopy_xox_2_IN_xGmIntersect_xax_FILE_xbbool                                600011
#define ERROR_IN_xGmIntersect_xox_IN_xGmIntersect_xax_FILE_xbbool                             600021
#define ERROR_IN_xNullGeomP_xox_IN_xGmIntersect_xax_FILE_xbbool                               600031
#define ERROR_IN_xGmCopy_xox_1_IN_xGmUnion_xax_FILE_xbbool                                    600041
#define ERROR_IN_xGmCopy_xox_2_IN_xGmUnion_xax_FILE_xbbool                                    600051
#define ERROR_IN_xGmUnion_xox_IN_xGmUnion_xax_FILE_xbbool                                     600061
#define ERROR_IN_xGmCopy_xox_1_IN_xGmUnionMerge_xax_FILE_xbbool                               600101
#define ERROR_IN_xGmCopy_xox_2_IN_xGmUnionMerge_xax_FILE_xbbool                               600111
#define ERROR_IN_xGmUnionMerge_xox_IN_xGmUnionMerge_xax_FILE_xbbool                           600121
#define ERROR_IN_xGmGetDim_xox_1_IN_xGmOverlap_xax_FILE_xbbool                                600131
#define ERROR_IN_xGmGetDim_xox_2_IN_xGmOverlap_xax_FILE_xbbool                                600141
#define ERROR_IN_xGmCopy_xox_1_IN_xGmOverlap_xax_FILE_xbbool                                  600151
#define ERROR_IN_xGmCopy_xox_2_IN_xGmOverlap_xax_FILE_xbbool                                  600161
#define ERROR_IN_xGmClassify_xox_IN_xGmOverlap_xax_FILE_xbbool                                600171
#define ERROR_IN_xIntListGetNth_xox_1_IN_xGmOverlap_xax_FILE_xbbool                           600181
#define ERROR_IN_xIntListGetNth_xox_2_IN_xGmOverlap_xax_FILE_xbbool                           600191
#define ERROR_IN_xIntListGetNth_xox_3_IN_xGmOverlap_xax_FILE_xbbool                           600201
#define ERROR_IN_xIntListPush_xox_1_IN_xGmOverlap_xax_FILE_xbbool                             600211
#define ERROR_IN_xIntListPush_xox_2_IN_xGmOverlap_xax_FILE_xbbool                             600221
#define ERROR_IN_xIntListPush_xox_3_IN_xGmOverlap_xax_FILE_xbbool                             600231
#define ERROR_IN_xIntListDelete_xox_1_IN_xGmOverlap_xax_FILE_xbbool                           600241
#define ERROR_IN_xNullGeomP_xox_IN_xGmOverlap_xax_FILE_xbbool                                 600251
#define ERROR_IN_xGmGetDim_xox_3_IN_xGmOverlap_xax_FILE_xbbool                                600261
#define ERROR_IN_xSewnGeom_xox_IN_xGmOverlap_xax_FILE_xbbool                                  600271
#define ERROR_IN_xIntListDelete_xox_2_IN_xGmOverlap_xax_FILE_xbbool                           600281

#define ERROR_IN_xGmCopy_xox_1_IN_xGmClassify_xax_FILE_xbbool                                 600301
#define ERROR_IN_xGmCopy_xox_2_IN_xGmClassify_xax_FILE_xbbool                                 600311
#define ERROR_IN_xGmClassify_xox_IN_xGmClassify_xax_FILE_xbbool                               600321

#define SCALING_FACTOR_IS_NOT_POSITIVE_IN_xDivideUnderlyingCurve_xax_FILE_xbnurbs             600401
#define NO_ENOUGH_MEMORY_IN_xDivideUnderlyingCurve_xax_FILE_xbnurbs                           600411
#define ERROR_IN_scspl_IN_xDivideUnderlyingCurve_xax_FILE_xbnurbs                             600421
#define ERROR_IN_scsl_1_IN_xDivideUnderlyingCurve_xax_FILE_xbnurbs                            600431
#define ERROR_IN_xNurbGeomCurve_xox_1_IN_xDivideUnderlyingCurve_xax_FILE_xbnurbs              600441
#define ERROR_IN_xUserIdSet_xax_1_IN_xDivideUnderlyingCurve_xax_FILE_xbnurbs                  600451
#define ERROR_IN_xGeomAttrCellSet_xax_1_IN_xDivideUnderlyingCurve_xax_FILE_xbnurbs            600461
#define ERROR_IN_xDivideUnderlyingCurve_xax_IN_xDivideUnderlyingCurve_xax_FILE_xbnurbs        600471
#define ERROR_IN_scsl_2_IN_xDivideUnderlyingCurve_xax_FILE_xbnurbs                            600481
#define ERROR_IN_xNurbGeomCurve_xox_2_IN_xDivideUnderlyingCurve_xax_FILE_xbnurbs              600491
#define ERROR_IN_xUserIdSet_xax_2_IN_xDivideUnderlyingCurve_xax_FILE_xbnurbs                  600501
#define ERROR_IN_xGeomAttrCellSet_xax_2_IN_xDivideUnderlyingCurve_xax_FILE_xbnurbs            600511
#define CAN_NOT_FREE_MEMORY_IN_xDivideUnderlyingCurve_xax_FILE_xbnurbs                        600521

#define SCALING_FACTOR_IS_NOT_POSITIVE_IN_xDivideUnderlyingSurface_xax_FILE_xbnurbs           600601
#define NO_ENOUGH_MEMORY_1_IN_xDivideUnderlyingSurface_xax_FILE_xbnurbs                       600611
#define ERROR_IN_ssspl_IN_xDivideUnderlyingSurface_xax_FILE_xbnurbs                           600621
#define ERROR_IN_sssar_1_IN_xDivideUnderlyingSurface_xax_FILE_xbnurbs                         600631
#define ERROR_IN_xNurbGeomSurface_xox_1_IN_xDivideUnderlyingSurface_xax_FILE_xbnurbs          600641
#define ERROR_IN_xUserIdSet_xax_1_IN_xDivideUnderlyingSurface_xax_FILE_xbnurbs                600651
#define ERROR_IN_xGeomAttrCellSet_xax_1_IN_xDivideUnderlyingSurface_xax_FILE_xbnurbs          600661
#define ERROR_IN_xDivideUnderlyingSurface_xax_1_IN_xDivideUnderlyingSurface_xax_FILE_xbnurbs  600671
#define ERROR_IN_xDivideUnderlyingSurface_xax_2_IN_xDivideUnderlyingSurface_xax_FILE_xbnurbs  600681
#define ERROR_IN_xDivideUnderlyingSurface_xax_3_IN_xDivideUnderlyingSurface_xax_FILE_xbnurbs  600691
#define ERROR_IN_sssar_2_IN_xDivideUnderlyingSurface_xax_FILE_xbnurbs                         600701
#define ERROR_IN_xNurbGeomSurface_xox_2_IN_xDivideUnderlyingSurface_xax_FILE_xbnurbs          600711
#define ERROR_IN_xUserIdSet_xax_2_IN_xDivideUnderlyingSurface_xax_FILE_xbnurbs                600721
#define ERROR_IN_xGeomAttrCellSet_xax_2_IN_xDivideUnderlyingSurface_xax_FILE_xbnurbs          600731
#define ERROR_IN_sssar_3_IN_xDivideUnderlyingSurface_xax_FILE_xbnurbs                         600741
#define ERROR_IN_xNurbGeomSurface_xox_3_IN_xDivideUnderlyingSurface_xax_FILE_xbnurbs          600751
#define ERROR_IN_xUserIdSet_xax_3_IN_xDivideUnderlyingSurface_xax_FILE_xbnurbs                600761
#define ERROR_IN_xGeomAttrCellSet_xax_3_IN_xDivideUnderlyingSurface_xax_FILE_xbnurbs          600771
#define ERROR_IN_sssar_4_IN_xDivideUnderlyingSurface_xax_FILE_xbnurbs                         600781
#define ERROR_IN_xNurbGeomSurface_xox_4_IN_xDivideUnderlyingSurface_xax_FILE_xbnurbs          600791
#define ERROR_IN_xUserIdSet_xax_4_IN_xDivideUnderlyingSurface_xax_FILE_xbnurbs                600801
#define ERROR_IN_xGeomAttrCellSet_xax_4_IN_xDivideUnderlyingSurface_xax_FILE_xbnurbs          600811
#define CAN_NOT_FREE_MEMORY_1_IN_xDivideUnderlyingSurface_xax_FILE_xbnurbs                    600821
#define NO_ENOUGH_MEMORY_2_IN_xDivideUnderlyingSurface_xax_FILE_xbnurbs                       600831
#define ERROR_IN_ssspu_IN_xDivideUnderlyingSurface_xax_FILE_xbnurbs                           600841
#define ERROR_IN_sssar_5_IN_xDivideUnderlyingSurface_xax_FILE_xbnurbs                         600851
#define ERROR_IN_xNurbGeomSurface_xox_5_IN_xDivideUnderlyingSurface_xax_FILE_xbnurbs          600861
#define ERROR_IN_xUserIdSet_xax_5_IN_xDivideUnderlyingSurface_xax_FILE_xbnurbs                600871
#define ERROR_IN_xGeomAttrCellSet_xax_5_IN_xDivideUnderlyingSurface_xax_FILE_xbnurbs          600881
#define ERROR_IN_xDivideUnderlyingSurface_xax_4_IN_xDivideUnderlyingSurface_xax_FILE_xbnurbs  600891
#define ERROR_IN_sssar_6_IN_xDivideUnderlyingSurface_xax_FILE_xbnurbs                         600901
#define ERROR_IN_xNurbGeomSurface_xox_6_IN_xDivideUnderlyingSurface_xax_FILE_xbnurbs          600911
#define ERROR_IN_xUserIdSet_xax_6_IN_xDivideUnderlyingSurface_xax_FILE_xbnurbs                600921
#define ERROR_IN_xGeomAttrCellSet_xax_6_IN_xDivideUnderlyingSurface_xax_FILE_xbnurbs          600931
#define CAN_NOT_FREE_MEMORY_2_IN_xDivideUnderlyingSurface_xax_FILE_xbnurbs                    600941
#define NO_ENOUGH_MEMORY_3_IN_xDivideUnderlyingSurface_xax_FILE_xbnurbs                       600951
#define ERROR_IN_ssspv_IN_xDivideUnderlyingSurface_xax_FILE_xbnurbs                           600961
#define ERROR_IN_sssar_7_IN_xDivideUnderlyingSurface_xax_FILE_xbnurbs                         600971
#define ERROR_IN_xNurbGeomSurface_xox_7_IN_xDivideUnderlyingSurface_xax_FILE_xbnurbs          600981
#define ERROR_IN_xUserIdSet_xax_7_IN_xDivideUnderlyingSurface_xax_FILE_xbnurbs                600991
#define ERROR_IN_xGeomAttrCellSet_xax_7_IN_xDivideUnderlyingSurface_xax_FILE_xbnurbs          601001
#define ERROR_IN_xDivideUnderlyingSurface_xax_5_IN_xDivideUnderlyingSurface_xax_FILE_xbnurbs  601011
#define ERROR_IN_sssar_8_IN_xDivideUnderlyingSurface_xax_FILE_xbnurbs                         601021
#define ERROR_IN_xNurbGeomSurface_xox_8_IN_xDivideUnderlyingSurface_xax_FILE_xbnurbs          601031
#define ERROR_IN_xUserIdSet_xax_8_IN_xDivideUnderlyingSurface_xax_FILE_xbnurbs                601041
#define ERROR_IN_xGeomAttrCellSet_xax_8_IN_xDivideUnderlyingSurface_xax_FILE_xbnurbs          601051
#define CAN_NOT_FREE_MEMORY_3_IN_xDivideUnderlyingSurface_xax_FILE_xbnurbs                    601061


#define ERROR_IN_entgt1_IN_xNurbGeomCurve_xax_FILE_xbnurbs                                    601081
#define NO_ENOUGH_MEMORY_IN_xNurbGeomCurve_xax_FILE_xbnurbs                                   601091
#define ERROR_IN_xBadDividedKnotLocations_xax_IN_xNurbGeomCurve_xax_FILE_xbnurbs              601101
#define BAD_DIVIDED_KNOT_LOCATIONS_IN_xNurbGeomCurve_xax_FILE_xbnurbs                         601111
#define ERROR_IN_xDivideUnderlyingCurve_xax_IN_xNurbGeomCurve_xax_FILE_xbnurbs                601121
#define SUBLINE_DIVIDING_TABLE_OVERFLOW_xax_IN_xNurbGeomCurve_xax_FILE_xbnurbs                601131
#define ERROR_IN_xsewnc_IN_xNurbGeomCurve_xax_FILE_xbnurbs                                    601141
#define CAN_NOT_FREE_MEMORY_IN_xNurbGeomCurve_xax_FILE_xbnurbs                                601151
#define ERROR_IN_xNurbGeomCurve_xox_IN_xNurbGeomCurve_xax_FILE_xbnurbs                        601161
#define ERROR_IN_entgt1_IN_xNurbGeomSurface_xax_FILE_xbnurbs                                  601171

#define NO_ENOUGH_MEMORY_IN_xNurbGeomSurface_xax_FILE_xbnurbs                                 601181
#define ERROR_IN_xBadDividedKnotLocations_xax_1_IN_xNurbGeomSurface_xax_FILE_xbnurbs          601191
#define BAD_DIVIDED_U_KNOT_LOCATIONS_IN_xNurbGeomSurface_xax_FILE_xbnurbs                     601201
#define ERROR_IN_xBadDividedKnotLocations_xax_2_IN_xNurbGeomSurface_xax_FILE_xbnurbs          601211
#define BAD_DIVIDED_V_KNOT_LOCATIONS_IN_xNurbGeomSurface_xax_FILE_xbnurbs                     601221
#define ERROR_IN_xDivideUnderlyingSurface_xax_IN_xNurbGeomSurface_xax_FILE_xbnurbs            601231
#define SUBAREA_DIVIDING_TABLE_OVERFLOW_xax_IN_xNurbGeomSurface_xax_FILE_xbnurbs              601241
#define ERROR_IN_xsewnc_IN_xNurbGeomSurface_xax_FILE_xbnurbs                                  601251
#define CAN_NOT_FREE_MEMORY_IN_xNurbGeomSurface_xax_FILE_xbnurbs                              601261
#define ERROR_IN_xNurbGeomSurface_xox_IN_xNurbGeomSurface_xax_FILE_xbnurbs                    601271

#define ERROR_IN_fopen_1_IN_xShapesSetStatusPrintMode_xax_FILE_xbsetup                        601281
#define ERROR_IN_fopen_2_IN_xShapesSetStatusPrintMode_xax_FILE_xbsetup                        601291
#define ERROR_IN_xShapesSetStatusPrintMode_xox_IN_xShapesSetStatusPrintMode_xax_FILE_xbsetup  601301
#define ERROR_IN_xShapesSetWarnMode_xox_IN_xShapesSetWarnMode_xax_FILE_xbsetup                601311

#define ERROR_IN_fopen_IN_xStartLog_xax_FILE_xbsetup                                          601331
#define ERROR_IN_fclose_IN_xStartLog_xax_FILE_xbsetup                                         601341
#define ERROR_IN_xGetTols_xox_IN_xBooleanTolerancesSet_xax_FILE_xbsetup                       601351
#define ERROR_IN_xSetTols_xox_IN_xBooleanTolerancesSet_xax_FILE_xbsetup                       601361
#define ERROR_IN_xCurveSplitModeSet_xox_IN_xLoopSplittingMode_xax_FILE_xbsetup                601371
#define ERROR_IN_xPropagateUserIds_xox_IN_xUserIdsSet_xax_FILE_xbsetup                        601381
#define ERROR_IN_xGenerateDefaultUserIds_xox_IN_xUserIdsSet_xax_FILE_xbsetup                  601391

#define ERROR_IN_xIntListGetNth_xox_IN_xCopyIntList_xax_FILE_xbutil                           601401
#define ERROR_IN_xIntListFromArrayCopy_xox_IN_xCopyIntList_xax_FILE_xbutil                    601411 
#define GEOMETRY_DIMENSION_NOT_CORRECT_IN_xBasicGeomManifoldCheck_xax_FILE_xbutil             601421
#define ERROR_IN_xGmFindKSkeleton_xox_1_IN_xBasicGeomManifoldCheck_xax_FILE_xbutil            601431
#define ERROR_IN_xIntListGetLength_xox_1_IN_xBasicGeomManifoldCheck_xax_FILE_xbutil           601441
#define ERROR_IN_xIntListGetNth_xox_1_IN_xBasicGeomManifoldCheck_xax_FILE_xbutil              601451
#define ERROR_IN_xGmFindKSkeleton_xox_2_IN_xBasicGeomManifoldCheck_xax_FILE_xbutil            601461
#define ERROR_IN_xIntListGetLength_xox_2_IN_xBasicGeomManifoldCheck_xax_FILE_xbutil           601471
#define ERROR_IN_xIntListGetNth_xox_2_IN_xBasicGeomManifoldCheck_xax_FILE_xbutil              601481
#define ERROR_IN_xIntListPush_xox_IN_xBasicGeomManifoldCheck_xax_FILE_xbutil                  601491
#define ERROR_IN_xIntListDelete_xox_1_IN_xBasicGeomManifoldCheck_xax_FILE_xbutil              601501
#define NO_ENOUGH_MEMORY_IN_xBasicGeomManifoldCheck_xax_FILE_xbutil                           601511
#define ERROR_IN_xCopyIntList_xax_IN_xBasicGeomManifoldCheck_xax_FILE_xbutil                  601521
#define ERROR_IN_xIntListDelete_xox_2_IN_xBasicGeomManifoldCheck_xax_FILE_xbutil              601531
#define CAN_NOT_FREE_MEMORY_IN_xBasicGeomManifoldCheck_xax_FILE_xbutil                        601541
#define ERROR_IN_xIntListDelete_xox_3_IN_xBasicGeomManifoldCheck_xax_FILE_xbutil              601551


#define ERROR_IN_xAttrSpecNew_xox_IN_xGeomAttrHandlersSet_xax_FILE_xbattr                     601611 
#define ERROR_IN_xAttrSpecSetHndlr_xox_1_IN_xGeomAttrHandlersSet_xax_FILE_xbattr              601621
#define ERROR_IN_xAttrSpecSetHndlr_xox_2_IN_xGeomAttrHandlersSet_xax_FILE_xbattr              601631
#define ERROR_IN_xAttrSpecSetHndlr_xox_3_IN_xGeomAttrHandlersSet_xax_FILE_xbattr              601641
#define ERROR_IN_xAttrSpecSetHndlr_xox_4_IN_xGeomAttrHandlersSet_xax_FILE_xbattr              601651
#define ERROR_IN_xAttrSpecSetHndlr_xox_5_IN_xGeomAttrHandlersSet_xax_FILE_xbattr              601661
#define ERROR_IN_xAttrSpecSetHndlr_xox_6_IN_xGeomAttrHandlersSet_xax_FILE_xbattr              601671
#define ERROR_IN_xAttrSpecSetHndlr_xox_7_IN_xGeomAttrHandlersSet_xax_FILE_xbattr              601681
#define ERROR_IN_xAttrSpecSetHndlr_xox_8_IN_xGeomAttrHandlersSet_xax_FILE_xbattr              601691
#define ERROR_IN_xAttrSpecSetHndlr_xox_9_IN_xGeomAttrHandlersSet_xax_FILE_xbattr              601701
#define ERROR_IN_xAttrSpecSetHndlr_xox_10_IN_xGeomAttrHandlersSet_xax_FILE_xbattr             601711
#define ERROR_IN_xAttrSpecSetHndlr_xox_11_IN_xGeomAttrHandlersSet_xax_FILE_xbattr             601721

#define NO_ENOUGH_MEMORY_1_IN_xGeomAttrCellSet_xax_FILE_xbattr                                601931
#define ERROR_IN_xCellGetAttr_xox_IN_xGeomAttrCellSet_xax_FILE_xbattr                         601941
#define ERROR_IN_xAttrNew_xox_IN_xGeomAttrCellSet_xax_FILE_xbattr                             601951
#define NO_ENOUGH_MEMORY_2_IN_xGeomAttrCellSet_xax_FILE_xbattr                                601961
#define ERROR_IN_xAttrSetPtrVal_xox_IN_xGeomAttrCellSet_xax_FILE_xbattr                       601971
#define ERROR_IN_xCellSetAttr_xox_IN_xGeomAttrCellSet_xax_FILE_xbattr                         601981
#define ERROR_IN_xAttrGetPtrVal_xox_IN_xGeomAttrCellSet_xax_FILE_xbattr                       601991

#define ERROR_IN_xCellGetAttr_xox_IN_xGeomAttrCellGetPtr_xax_FILE_xbattr                      602001
#define ERROR_IN_xAttrGetPtrVal_xox_IN_xGeomAttrCellGetPtr_xax_FILE_xbattr                    602011

#define ERROR_IN_xGeomAttrListDelete_xax_IN_xGeomAttrListDelete_xax_FILE_xbattr               602111
#define CAN_NOT_FREE_MEMORY_1_IN_xGeomAttrListDelete_xax_FILE_xbattr                          602121
#define CAN_NOT_FREE_MEMORY_2_IN_xGeomAttrListDelete_xax_FILE_xbattr                          602131

#define ERROR_IN_xCellToId_xox_IN_xGeomAttrCellNewHndlr_xax_FILE_xbattr                       602211
#define ERROR_IN_xGmGetDim_xox_IN_xGeomAttrCellNewHndlr_xax_FILE_xbattr                       602221

#define ERROR_IN_xCellToId_xox_1_IN_xGeomAttrCellCopyHndlr_xax_FILE_xbattr                    602301
#define ERROR_IN_xCellToId_xox_2_IN_xGeomAttrCellCopyHndlr_xax_FILE_xbattr                    602311
#define ERROR_IN_xGmGetDim_xox_IN_xGeomAttrCellCopyHndlr_xax_FILE_xbattr                      602321
#define ERROR_IN_xCellGetAttr_xox_IN_xGeomAttrCellCopyHndlr_xax_FILE_xbattr                   602331
#define ERROR_IN_xAttrGetPtrVal_xox_1_IN_xGeomAttrCellCopyHndlr_xax_FILE_xbattr               602341
#define ERROR_IN_xAttrNew_xox_IN_xGeomAttrCopyHndlr_xax_FILE_xbattr                           602351
#define ERROR_IN_xAttrSetPtrVal_xox_IN_xGeomAttrCellCopyHndlr_xax_FILE_xbattr                 602361
#define ERROR_IN_xCellSetAttr_xox_IN_xGeomAttrCellCopyHndlr_xax_FILE_xbattr                   602371
#define ERROR_IN_xAttrGetPtrVal_xox_2_IN_xGeomAttrCellCopyHndlr_xax_FILE_xbattr               602381
#define NO_ENOUGH_MEMORY_IN_xGeomAttrCellCopyHndlr_xax_FILE_xbattr                            602391

#define ERROR_IN_xCellToId_xox_IN_xGeomAttrCellDeleteHndlr_xax_FILE_xbattr                    602411
#define ERROR_IN_xGmGetDim_xox_IN_xGeomAttrCellDeleteHndlr_xax_FILE_xbattr                    602421
#define ERROR_IN_xAttrGetPtrVal_xox_IN_xGeomAttrCellDeleteHndlr_xax_FILE_xbattr               602431     
#define ERROR_IN_xGeomAttrListDelete_xax_IN_xGeomAttrCellDeleteHndlr_xax_FILE_xbattr          602441

#define ERROR_IN_xCellToId_xox_IN_xGeomAttrCellDissocHndlr_xax_FILE_xbattr                    602551
#define ERROR_IN_xGmGetDim_xox_IN_xGeomAttrCellDissocHndlr_xax_FILE_xbattr                    602561
#define ERROR_IN_xAttrGetPtrVal_xox_IN_xGeomAttrCellDissocHndlr_xax_FILE_xbattr               602571
#define ERROR_IN_xGeomAttrListDelete_xax_IN_xGeomAttrCellDissocHndlr_xax_FILE_xbattr          602581

#define ERROR_IN_xCellToId_xox_1_IN_xGeomAttrCellSplitHndlr_xax_FILE_xbattr                   602611
#define ERROR_IN_xGmGetDim_xox_1_IN_xGeomAttrCellSplitHndlr_xax_FILE_xbattr                   602621
#define ERROR_IN_xCellToId_xox_2_IN_xGeomAttrCellSplitHndlr_xax_FILE_xbattr                   602631
#define ERROR_IN_xGmGetDim_xox_2_IN_xGeomAttrCellSplitHndlr_xax_FILE_xbattr                   602641
#define UNKNOWN_GEOMETRY_TYPE_IN_xGeomAttrCellSplitHndlr_xax_FILE_xbattr                      602651
#define UNKNOWN_OPERATION_TYPE_IN_xGeomAttrCellSplitHndlr_xax_FILE_xbattr                     602661
#define ERROR_IN_xAttrGetPtrVal_xox_1_IN_xGeomAttrCellSplitHndlr_xax_FILE_xbattr              602671
#define ERROR_IN_xCellGetAttr_xox_IN_xGeomAttrCellSplitHndlr_xax_FILE_xbattr                  602681
#define NO_ENOUGH_MEMORY_1_IN_xGeomAttrCellSplitHndlr_xax_FILE_xbattr                         602691
#define ERROR_IN_xAttrNew_xox_IN_xGeomAttrCellSplitHndlr_xax_FILE_xbattr                      602701
#define NO_ENOUGH_MEMORY_2_IN_xGeomAttrCellSplitHndlr_xax_FILE_xbattr                         602711
#define ERROR_IN_xAttrSetPtrVal_xox_IN_xGeomAttrCellSplitHndlr_xax_FILE_xbattr                602721
#define ERROR_IN_xCellSetAttr_xox_IN_xGeomAttrCellSplitHndlr_xax_FILE_xbattr                  602731
#define ERROR_IN_xAttrGetPtrVal_xox_2_IN_xGeomAttrCellSplitHndlr_xax_FILE_xbattr              602741

#define ERROR_IN_xCellToId_xox_1_IN_xGeomAttrCellImbedHndlr_xax_FILE_xbattr                   602801
#define ERROR_IN_xGmGetDim_xox_1_IN_xGeomAttrCellImbedHndlr_xax_FILE_xbattr                   602811
#define ERROR_IN_xCellToId_xox_2_IN_xGeomAttrCellImbedHndlr_xax_FILE_xbattr                   602821
#define ERROR_IN_xGmGetDim_xox_2_IN_xGeomAttrCellImbedHndlr_xax_FILE_xbattr                   602831
#define ERROR_IN_xCellToId_xox_3_IN_xGeomAttrCellImbedHndlr_xax_FILE_xbattr                   602841
#define ERROR_IN_xGmGetDim_xox_3_IN_xGeomAttrCellImbedHndlr_xax_FILE_xbattr                   602851

#define UNKNOWN_GEOMETRY_TYPE_IN_xGeomAttrCellImbedHndlr_xax_FILE_xbattr                      602861
#define UNKNOWN_OPERATION_TYPE_IN_xGeomAttrCellImbedHndlr_xax_FILE_xbattr                     602871
#define ERROR_IN_xAttrGetPtrVal_xox_1_IN_xGeomAttrCellImbedHndlr_xax_FILE_xbattr              602881
#define ERROR_IN_xAttrGetPtrVal_xox_2_IN_xGeomAttrCellImbedHndlr_xax_FILE_xbattr              602891
#define ERROR_IN_xCellGetAttr_xox_3_IN_xGeomAttrCellImbedHndlr_xax_FILE_xbattr                602901
#define NO_ENOUGH_MEMORY_1_IN_xGeomAttrCellImbedHndlr_xax_FILE_xbattr                         602911
#define ERROR_IN_xAttrNew_xox_IN_xGeomAttrCellImbedHndlr_xax_FILE_xbattr                      602921
#define NO_ENOUGH_MEMORY_2_IN_xGeomAttrCellImbedHndlr_xax_FILE_xbattr                         602931
#define ERROR_IN_xAttrSetPtrVal_xox_IN_xGeomAttrCellImbedHndlr_xax_FILE_xbattr                602941
#define ERROR_IN_xCellSetAttr_xox_IN_xGeomAttrCellImbedHndlr_xax_FILE_xbattr                  602951

#define ERROR_IN_xCellToId_xox_1_IN_xGeomAttrCellMergeHndlr_xax_FILE_xbattr                   603001
#define ERROR_IN_xGmGetDim_xox_1_IN_xGeomAttrCellMergeHndlr_xax_FILE_xbattr                   603011
#define ERROR_IN_xCellToId_xox_2_IN_xGeomAttrCellMergeHndlr_xax_FILE_xbattr                   603021
#define ERROR_IN_xGmGetDim_xox_2_IN_xGeomAttrCellMergeHndlr_xax_FILE_xbattr                   603031
#define ERROR_IN_xCellToId_xox_3_IN_xGeomAttrCellMergeHndlr_xax_FILE_xbattr                   603041
#define ERROR_IN_xGmGetDim_xox_3_IN_xGeomAttrCellMergeHndlr_xax_FILE_xbattr                   603051
#define UNKNOWN_GEOMETRY_TYPE_IN_xGeomAttrCellMergeHndlr_xax_FILE_xbattr                      603061
#define UNKNOWN_OPERATION_TYPE_IN_xGeomAttrCellMergeHndlr_xax_FILE_xbattr                     603071
#define ERROR_IN_xAttrGetPtrVal_xox_1_IN_xGeomAttrCellMergeHndlr_xax_FILE_xbattr              603081
#define ERROR_IN_xAttrGetPtrVal_xox_2_IN_xGeomAttrCellMergeHndlr_xax_FILE_xbattr              603091
#define ERROR_IN_xCellGetAttr_xox_IN_xGeomAttrCellMergeHndlr_xax_FILE_xbattr                  603101
#define ERROR_IN_xAttrGetPtrVal_xox_3_IN_xGeomAttrCellMergeHndlr_xax_FILE_xbattr              603111
#define NO_ENOUGH_MEMORY_1_IN_xGeomAttrCellMergeHndlr_xax_FILE_xbattr                         603121
#define NO_ENOUGH_MEMORY_2_IN_xGeomAttrCellMergeHndlr_xax_FILE_xbattr                         603131
#define ERROR_IN_xAttrSetPtrVal_xox_IN_xGeomAttrCellMergeHndlr_xax_FILE_xbattr                603141

#define LIST_SIZE_NOT_EQUAL_ZERO_IN_xIntListNew_xox_FILE_xxlist                               700001
#define ERROR_IN_xIntListNew_IN_xIntListNew_xox_FILE_xxlist                                   700011
#define ERROR_IN_xIntList_IN_xIntListFromArrayCopy_xox_FILE_xxlist                            700021
#define ERROR_IN_xIntListFromArrayCopy_IN_xIntListFromArrayCopy_xox_FILE_xxlist               700031
#define ERROR_IN_xFreeIntList_IN_xIntListDelete_xox_FILE_xxlist                               700041
#define ERROR_IN_xIntListDelete_IN_xIntListDelete_xox_FILE_xxlist                             700051
#define ERROR_IN_xIntListLength_IN_xIntListGetLength_xox_FILE_xxlist                          700061
#define ERROR_IN_xIntListGetLength_IN_xIntListGetLength_xox_FILE_xxlist                       700071
#define ERROR_IN_xIntListElement_IN_xIntListGetNth_xox_FILE_xxlist                            700081
#define ERROR_IN_xIntListGetNth_IN_xIntListGetNth_xox_FILE_xxlist                             700091
#define ERROR_IN_xSetIntListElement_IN_xIntListSetNth_xox_FILE_xxlist                         700101
#define ERROR_IN_xIntListSetNth_IN_xIntListSetNth_xox_FILE_xxlist                             700111
#define ERROR_IN_xPushIntListElement_IN_xIntListPush_xox_FILE_xxlist                          700121
#define ERROR_IN_xIntListPush_IN_xIntListPush_xox_FILE_xxlist                                 700131
#define ERROR_IN_xListNew_IN_xListNew_xox_FILE_xxlist                                         700141
#define ERROR_IN_xListFromArrayCopy_IN_xListFromArrayCopy_xox_FILE_xxlist                     700151
#define ERROR_IN_xListDelete_IN_xListDelete_xox_FILE_xxlist                                   700161
#define ERROR_IN_xListGetLength_IN_xListGetLength_xox_FILE_xxlist                             700171
#define ERROR_IN_xListGetNth_IN_xListGetNth_xox_FILE_xxlist                                   700181
#define ERROR_IN_xListSetNth_IN_xListSetNth_xox_FILE_xxlist                                   700191
#define ERROR_IN_xListPush_IN_xListPush_xox_FILE_xxlist                                       700201

#define ERROR_IN_xVertexForParams_IN_xVertexForParams_xox_FILE_xxvert                         701001
#define ERROR_IN_xVertexCoords_IN_xVertexCoords_xox_FILE_xxvert                               701011
#define ERROR_IN_xGmFromId_xox_IN_xGmFindMinVertForPnt_xox_FILE_xxvert                        701021
#define ERROR_IN_xGmFindMinVertForPnt_IN_xGmFindMinVertForPnt_xox_FILE_xxvert                 701031
#define ERROR_IN_xVertToId_xox_IN_xGmFindMinVertForPnt_xox_FILE_xxvert                        701041

#define ERROR_IN_xGmFromId_IN_xGmFromId_xox_FILE_xxconv                                       702001
#define ERROR_IN_xGmToId_IN_xGmToId_xox_FILE_xxconv                                           702011
#define ERROR_IN_xListNew_xox_IN_xListGmFromId_xox_FILE_xxconv                                702021
#define ERROR_IN_xIntListGetLength_xox_IN_xListGmFromId_xox_FILE_xxconv                       702031
#define ERROR_IN_xIntListGetNth_xox_IN_xListGmFromId_xox_FILE_xxconv                          702041
#define ERROR_IN_xGmFromId_xox_IN_xListGmFromId_xox_FILE_xxconv                               702051
#define ERROR_IN_xListPush_xox_IN_xListGmFromId_xox_FILE_xxconv                               702061 
#define ERROR_IN_xIntListNew_xox_IN_xListGmToId_xox_FILE_xxconv                               702071
#define ERROR_IN_xListGetLength_xox_IN_xListGmToId_xox_FILE_xxconv                            702081
#define ERROR_IN_xListGetNth_xox_IN_xListGmToId_xox_FILE_xxconv                               702091
#define ERROR_IN_xGmToId_xox_IN_xListGmToId_xox_FILE_xxconv                                   702101
#define ERROR_IN_xIntListPush_xox_IN_xListGmToId_xox_FILE_xxconv                              702111 
#define ERROR_IN_xFrameFromId_IN_xFrameFromId_xox_FILE_xxconv                                 702121
#define ERROR_IN_xFrameToId_IN_xFrameToId_xox_FILE_xxconv                                     702131
#define ERROR_IN_xGrpToGm_IN_xGrpToGm_xox_FILE_xxconv                                         702141
#define ERROR_IN_xGmToGrp_IN_xGmToGrp_xox_FILE_xxconv                                         702151
#define ERROR_IN_xCellToGm_IN_xCellToGm_xox_FILE_xxconv                                       702161
#define ERROR_IN_xGmToCell_IN_xGmToCell_xox_FILE_xxconv                                       702171
#define ERROR_IN_xCellToGm_xox_IN_xCellToId_xox_FILE_xxconv                                   702181
#define ERROR_IN_xGmToId_xox_IN_xCellToId_xox_FILE_xxconv                                     702191
#define ERROR_IN_xGmFromId_xox_IN_xCellFromId_xox_FILE_xxconv                                 702201
#define ERROR_IN_xGmToCell_xox_IN_xCellFromId_xox_FILE_xxconv                                 702211
#define ERROR_IN_xVertFromId_IN_xVertFromId_xox_FILE_xxconv                                   702221
#define ERROR_IN_xVertToId_IN_xVertToId_xox_FILE_xxconv                                       702231
#define ERROR_IN_xBrgForPId_IN_xBrgForPId_xox_FILE_xxconv                                     702232
#define ERROR_IN_xBrgGetPId_IN_xBrgGetPId_xox_FILE_xxconv                                     702233

#define ERROR_IN_xGeomDimension_IN_xGmGetDim_xox_FILE_xxquery                                 703001
#define ERROR_IN_xGmFromId_xox_1_IN_xGmGetDim_xox_FILE_xxquery                                703011
#define ERROR_IN_xGmGetDim_IN_xGmGetDim_xox_FILE_xxquery                                      703021 
#define ERROR_IN_xGeomP_IN_xGeomP_xox_FILE_xxquery                                            703031
#define ERROR_IN_xNullGeomP_IN_xNullGeomP_xox_FILE_xxquery                                    703041
#define ERROR_IN_xIntListNew_xox_IN_xGmFindCellGeoms_xox_FILE_xxquery                         703051
#define ERROR_IN_xBasicGeoms_IN_xGmFindCellGeoms_xox_FILE_xxquery                             703061
#define ERROR_IN_xGmFromId_xox_IN_xGmFindCellGeoms_xox_FILE_xxquery                           703071
#define ERROR_IN_xListNew_xox_IN_xGmFindCellGeoms_xox_FILE_xxquery                            703081
#define ERROR_IN_xGmFindCellGeoms_IN_xGmFindCellGeoms_xox_FILE_xxquery                        703091 
#define ERROR_IN_xListGmToId_xox_IN_xGmFindCellGeoms_xox_FILE_xxquery                         703101 
#define ERROR_IN_xGmFromId_xox_IN_xGmDetectNonManifold_xox_FILE_xxquery                       703111
#define ERROR_IN_xGmDetectNonManifold_IN_xGmDetectNonManifold_xox_FILE_xxquery                703121

#define ERROR_IN_xCellFromId_xox_IN_xCellFindPrmsRng_xox_FILE_xxquery                         703131
#define ERROR_IN_xCellFindPrmsRng_IN_xCellFindPrmsRng_xox_FILE_xxquery                        703141
#define ERROR_IN_xRngIsInf_IN_xCellFindPrmsRng_xox_FILE_xxquery                               703151
#define UNBOUNDED_PARAMETER_SPACE_IN_xCellFindPrmsRng_xox_FILE_xxquery                        703161

#define ERROR_IN_xCellFromId_xox_IN_xCellEvalPnt_xox_FILE_xxquery                             703171
#define ERROR_IN_xCellEvalPnt_IN_xCellEvalPnt_xox_FILE_xxquery                                703181

#define ERROR_IN_xGmFromId_xox_1_IN_xCellPairGetBrg_xox_FILE_xxquery                          703182
#define ERROR_IN_xGmFromId_xox_2_IN_xCellPairGetBrg_xox_FILE_xxquery                          703183
#define ERROR_IN_xBrgGetPId_xox_IN_xCellPairGetBrg_xox_FILE_xxquery                           703184
#define ERROR_IN_xBrgForPId_xox_IN_xBrgGetOrien_xox_FILE_xxquery                              703185
#define ERROR_IN_xSetUserId_IN_xSetUserId_xox_FILE_xxuserid                                   704001
#define ERROR_IN_xIntListNew_xox_IN_xUserIds_xox_FILE_xxuserid                                704011
#define ERROR_IN_xUserIds_IN_xUserIds_xox_FILE_xxuserid                                       704021
#define ERROR_IN_xSetUserId_xox_IN_xUserIdSet_xax_FILE_xxuserid                               704031
#define ERROR_IN_xUserIds_xox_IN_xUserIdQuery_xax_FILE_xxuserid                               704041
#define ERROR_IN_xIntListGetLength_xox_IN_xUserIdQuery_xax_FILE_xxuserid                      704051
#define ERROR_IN_xIntListDelete_xox_IN_xUserIdQuery_xax_FILE_xxuserid                         704061
#define ERROR_IN_xUserIds_xox_IN_xUserIdGet_xax_FILE_xxuserid                                 704071
#define ERROR_IN_xIntListGetLength_xox_IN_xUserIdGet_xax_FILE_xxuserid                        704081
#define ERROR_IN_xIntListGetNth_xox_1_IN_xUserIdGet_xax_FILE_xxuserid                         704091
#define ERROR_IN_xIntListGetNth_xox_2_IN_xUserIdGet_xax_FILE_xxuserid                         704101
#define ERROR_IN_xGeomP_IN_xUserIdGet_xax_FILE_xxuserid                                       704111
#define ERROR_IN_xGmGetDim_xox_IN_xUserIdGet_xax_FILE_xxuserid                                704121
#define INVALID_ANSYS_ENTITY_NUMBER_IN_xUserIdGet_xax_FILE_xxuserid                           704131
#define ERROR_IN_xIntListDelete_xox_IN_xUserIdGet_xax_FILE_xxuserid                           704141

#define ERROR_IN_xUserIds_xox_IN_xUserIdPrint_xax_FILE_xxuserid                               704151
#define ERROR_IN_xIntListGetLength_xox_IN_xUserIdPrint_xax_FILE_xxuserid                      704161
#define ERROR_IN_xIntListGetNth_xox_1_IN_xUserIdPrint_xax_FILE_xxuserid                       704171
#define ERROR_IN_xIntListGetNth_xox_2_IN_xUserIdPrint_xax_FILE_xxuserid                       704181
#define ERROR_IN_xGeomP_IN_xUserIdPrint_xax_FILE_xxuserid                                     704191
#define ERROR_IN_xGmGetDim_xox_IN_xUserIdPrint_xax_FILE_xxuserid                              704201
#define INVALID_ANSYS_ENTITY_NUMBER_IN_xUserIdPrint_xax_FILE_xxuserid                         704211
#define ERROR_IN_xIntListDelete_xox_IN_xUserIdPrint_xax_FILE_xxuserid                         704221

#define ERROR_IN_xSubGeomOrientations_IN_xSubGeomOrientations_xox_FILE_xxorien                705001
#define ERROR_IN_xInvertGeomOrientation_IN_xInvertGeomOrientation_xox_FILE_xxorien            705011
#define ERROR_IN_xUserIdGet_xax_IN_xInvertGeomOrientation_FILE_xxorien                        705021
#define ERROR_IN_xUserIdSet_xax_IN_xInvertGeomOrientation_FILE_xxorien                        705041
#define ERROR_IN_xGeomAttrCellGetPtr_xax_IN_xInvertGeomOrientation_FILE_xxorien               705051
#define ERROR_IN_xGeomAttrCellSet_xax_IN_xInvertGeomOrientation_FILE_xxorien                  705061

#define ERROR_IN_xAnsysNcurFromGeom_IN_xAnsysNcurFromGeom_xox_FILE_xxnurbs                    706001
#define ERROR_IN_xAnsysCurFromGeom_IN_xAnsysCurFromGeom_xox_FILE_xxnurbs                      706011
#define ERROR_IN_xAnsysNsurFromGeom_IN_xAnsysNsurFromGeom_xox_FILE_xxnurbs                    706021
#define ERROR_IN_xAnsysSurFromGeom_IN_xAnsysSurFromGeom_xox_FILE_xxnurbs                      706031
#define ERROR_IN_xGeomFromAnsysCurve_IN_xNurbGeomCurve_xox_FILE_xxnurbs                       706041
#define ERROR_IN_xGeomFromAnsysSurface_IN_xNurbGeomSurface_xox_FILE_xxnurbs                   706051

#define ERROR_IN_xNumGeomFrames_IN_xNumGeomFrames_xox_FILE_xxframe                            707001
#define ERROR_IN_xGeomFrameTreeA_IN_xGeomFrameTreeA_xox_FILE_xxframe                          707011
#define ERROR_IN_xNumFrameComponents_IN_xNumFrameComponents_xox_FILE_xxframe                  707021
#define ERROR_IN_xFrameComponentsA_IN_xFrameComponentsA_xox_FILE_xxframe                      707031
#define ERROR_IN_xFrameComponentOrientsA_IN_xFrameComponentOrientsA_xox_FILE_xxframe          707041
#define ERROR_IN_xTrimGeomFramesA_IN_xReplaceGeomFramesA_xox_FILE_xxframe                     707051
#define ERROR_IN_xReplaceGeomFramesA_IN_xReplaceGeomFramesA_xox_FILE_xxframe                  707061
#define ERROR_IN_xMakeFrameA_IN_xMakeFrameA_xox_FILE_xxframe                                  707071


#define ERROR_IN_xIntListNew_xox_IN_xGmFindSubGeoms_xox_FILE_xxbound                          708001
#define ERROR_IN_xSubGeoms_IN_xGmFindSubGeoms_xox_FILE_xxbound                                708011
#define ERROR_IN_xGmFromId_xox_IN_xGmFindSubGeoms_xox_FILE_xxbound                            708021
#define ERROR_IN_xListNew_xox_IN_xGmFindSubGeoms_xox_FILE_xxbound                             708031
#define ERROR_IN_xGmFindSubGeoms_IN_xGmFindSubGeoms_xox_FILE_xxbound                          708041 
#define ERROR_IN_xListGmToId_xox_IN_xGmFindSubGeoms_xox_FILE_xxbound                          708051 
#define ERROR_IN_xIntListNew_xox_IN_xGmFindKSkeleton_xox_FILE_xxbound                         708061
#define ERROR_IN_xKSubGeoms_IN_xGmFindKSkeleton_xox_FILE_xxbound                              708071
#define ERROR_IN_xGmFromId_xox_IN_xGmFindKSkeleton_xox_FILE_xxbound                           708081
#define ERROR_IN_xListNew_xox_IN_xGmFindKSkeleton_xox_FILE_xxbound                            708091
#define ERROR_IN_xGmFindKSkeleton_IN_xGmFindKSkeleton_xox_FILE_xxbound                        708101 
#define ERROR_IN_xListGmToId_xox_IN_xGmFindKSkeleton_xox_FILE_xxbound                         708111 
#define ERROR_IN_xIntListNew_xox_IN_xGmFindKSeams_xox_FILE_xxbound                            708121
#define ERROR_IN_xKSeamGeoms_IN_xGmFindKSeams_xox_FILE_xxbound                                708131
#define ERROR_IN_xGmFromId_xox_IN_xGmFindKSeams_xox_FILE_xxbound                              708141
#define ERROR_IN_xListNew_xox_IN_xGmFindKSeams_xox_FILE_xxbound                               708151
#define ERROR_IN_xGmFindKSeams_IN_xGmFindKSeams_xox_FILE_xxbound                              708161 
#define ERROR_IN_xListGmToId_xox_IN_xGmFindKSeams_xox_FILE_xxbound                            708171 

#define ERROR_IN_xIntListNew_xox_IN_xGmClassify_xox_FILE_xxbool                               709001
#define ERROR_IN_xClassifyGeoms_IN_xGmClassify_xox_FILE_xxbool                                709011
#define ERROR_IN_xGmFromId_xox_1_IN_xGmClassify_xox_FILE_xxbool                               709021
#define ERROR_IN_xGmFromId_xox_2_IN_xGmClassify_xox_FILE_xxbool                               709031
#define ERROR_IN_xGmClassify_IN_xGmClassify_xox_FILE_xxbool                                   709041 
#define ERROR_IN_xGmToId_xox_IN_xGmClassify_xox_FILE_xxbool                                   709051
#define ERROR_IN_xIntListPush_xox_IN_xGmClassify_xox_FILE_xxbool                              709061 
#define ERROR_IN_xUnionGeom_IN_xGmUnion_xox_FILE_xxbool                                       709071
#define ERROR_IN_xGmFromId_xox_1_IN_xGmUnion_xox_FILE_xxbool                                  709081
#define ERROR_IN_xGmFromId_xox_2_IN_xGmUnion_xox_FILE_xxbool                                  709091
#define ERROR_IN_xGmUnion_IN_xGmUnion_xox_FILE_xxbool                                         709101 
#define ERROR_IN_xGmToId_xox_IN_xGmUnion_xox_FILE_xxbool                                      709111
#define ERROR_IN_xDifferenceGeom_IN_xGmSubtract_xox_FILE_xxbool                               709121
#define ERROR_IN_xGmFromId_xox_1_IN_xGmSubtract_xox_FILE_xxbool                               709131
#define ERROR_IN_xGmFromId_xox_2_IN_xGmSubtract_xox_FILE_xxbool                               709141
#define ERROR_IN_xGmSubtract_IN_xGmSubtract_xox_FILE_xxbool                                   709151 
#define ERROR_IN_xGmToId_xox_IN_xGmSubtract_xox_FILE_xxbool                                   709161
#define ERROR_IN_xIntersectionGeom_IN_xGmIntersect_xox_FILE_xxbool                            709171
#define ERROR_IN_xGmFromId_xox_1_IN_xGmIntersect_xox_FILE_xxbool                              709181
#define ERROR_IN_xGmFromId_xox_2_IN_xGmIntersect_xox_FILE_xxbool                              709191
#define ERROR_IN_xGmIntersect_IN_xGmIntersect_xox_FILE_xxbool                                 709201 
#define ERROR_IN_xGmToId_xox_IN_xGmIntersect_xox_FILE_xxbool                                  709211
#define ERROR_IN_xUnionMergeGeom_IN_xGmUnionMerge_xox_FILE_xxbool                             709221
#define FLAG_VALUE_GREATER_THAN_3_1_IN_xGmUnionMerge_xox_FILE_xxbool                          709231
#define ERROR_IN_xGmFromId_xox_1_IN_xGmUnionMerge_xox_FILE_xxbool                             709241
#define ERROR_IN_xGmFromId_xox_2_IN_xGmUnionMerge_xox_FILE_xxbool                             709251
#define ERROR_IN_xGmUnionMerge_IN_xGmUnionMerge_xox_FILE_xxbool                               709261 
#define ERROR_IN_xGmToId_xox_IN_xGmUnionMerge_xox_FILE_xxbool                                 709271
#define FLAG_VALUE_GREATER_THAN_3_2_IN_xGmUnionMerge_xox_FILE_xxbool                          709281
#define ERROR_IN_xIntersectingGeomsP_IN_xIntersectingGeomsP_xox_FILE_xxbool                   709291
#define ERROR_IN_xGmFromId_xox_IN_xGmSimplify_xox_FILE_xxbool                                 709301
#define ERROR_IN_xGmSimplify_IN_xGmSimplify_xox_FILE_xxbool                                   709311
#define ERROR_IN_xGmToId_xox_IN_xGmSimplify_xox_FILE_xxbool                                   709321

#define ERROR_IN_xComplementHalfspaceGeom_IN_xGmComplement_xox_FILE_xxgeom                    709961
#define ERROR_IN_xGmFromId_xox_IN_xGmComplement_xox_FILE_xxgeom                               709971
#define ERROR_IN_xGmComplement_IN_xGmComplement_xox_FILE_xxgeom                               709981
#define ERROR_IN_xGmToId_xox_IN_xGmComplement_xox_FILE_xxgeom                                 709991
#define ERROR_IN_xPointGeom_IN_xPointGeom_xox_FILE_xxgeom                                     710001
#define ERROR_IN_xCopyGeom_IN_xGmCopy_xox_FILE_xxgeom                                         710011
#define ERROR_IN_xGmFromId_xox_IN_xGmCopy_xox_FILE_xxgeom                                     710021
#define ERROR_IN_xGmCopy_IN_xGmCopy_xox_FILE_xxgeom                                           710031 
#define ERROR_IN_xGmToId_xox_IN_xGmCopy_xox_FILE_xxgeom                                       710041
#define ERROR_IN_xIntListGetLength_xox_IN_xSewnGeom_xox_FILE_xxgeom                           710051
#define ERROR_IN_xIntListGetNth_xox_IN_xSewnGeom_xox_FILE_xxgeom                              710061
#define ERROR_IN_xSewnGeom_IN_xSewnGeom_xox_FILE_xxgeom                                       710071
#define ERROR_IN_xHalfspaceGeom_IN_xGmNewHalfspace_xox_FILE_xxgeom                            710081
#define ERROR_IN_xGmFromId_xox_IN_xGmNewHalfspace_xox_FILE_xxgeom                             710091
#define ERROR_IN_xGmNewHalfspace_IN_xGmNewHalfspace_xox_FILE_xxgeom                           710101 
#define ERROR_IN_xGmToId_xox_IN_xGmNewHalfspace_xox_FILE_xxgeom                               710111
#define ERROR_IN_xListGmFromId_xox_IN_xGmGroup_xox_FILE_xxgeom                                710121
#define ERROR_IN_xGrpNew_IN_xGmGroup_xox_FILE_xxgeom                                          710131
#define ERROR_IN_xGrpToGm_xox_IN_xGmGroup_xox_FILE_xxgeom                                     710141
#define ERROR_IN_xGmToId_xox_IN_xGmGroup_xox_FILE_xxgeom                                      710151
#define ERROR_IN_xGmFromId_xox_IN_xGmCopySupCtrldCells_xox_FILE_xxgeom                        710152
#define ERROR_IN_xGmCopySupCtrldCells_IN_xGmCopySupCtrldCells_xox_FILE_xxgeom                 710153
#define ERROR_IN_xGmToId_xox_IN_xGmCopySupCtrldCells_xox_FILE_xxgeom                          710154
#define ERROR_IN_xInitShapes_IN_xInitShapes_xox_FILE_xxsetup                                  710161
#define ERROR_IN_xDisconnectShapes_IN_xDisconnectShapes_xox_FILE_xxsetup                      710171
#define ERROR_IN_xShapesSetStatusPrintMode_IN_xShapesSetStatusPrintMode_xox_FILE_xxsetup      710181
#define ERROR_IN_xShapesSetWarnMode_IN_xShapesSetWarnMode_xox_FILE_xxsetup                    710191
#define ERROR_IN_xStartShapesLog_IN_xStartShapesLog_xox_FILE_xxsetup                          710201
#define ERROR_IN_xEndShapesLog_IN_xEndShapesLog_xox_FILE_xxsetup                              710211
#define ERROR_IN_xFreeId_IN_xFreeId_xox_FILE_xxsetup                                          710221
#define ERROR_IN_xGetTols_IN_xGetTols_xox_FILE_xxsetup                                        710231
#define ERROR_IN_xSetTols_IN_xSetTols_xox_FILE_xxsetup                                        710241
#define ERROR_IN_xCurveSplitModeSet_IN_xCurveSplitModeSet_xox_FILE_xxsetup                    710251
#define ERROR_IN_xGenerateDefaultUserIds_IN_xGenerateDefaultUserIds_xox_FILE_xxsetup          710261
#define ERROR_IN_xPropagateUserIds_IN_xPropagateUserIds_xox_FILE_xxsetup                      710271
#define ERROR_IN_xoxSetErrorHandler_IN_xoxSetErrorHandler_xox_FILE_xxsetup                    710281
#define ERROR_IN_xClearError_IN_xClearError_xox_FILE_xxsetup                                  710291
#define ERROR_IN_xFreeAnsysMemory_IN_xFreeAnsysMemory_xox_FILE_xxsetup                        710301

#define ERROR_IN_xAttrSpecNew_IN_xAttrSpecNew_xox_FILE_xxattr                                 710311 
#define ERROR_IN_xAttrSpecSetHndlr_IN_xAttrSpecSetHndlr_xox_FILE_xxattr                       710321 
#define ERROR_IN_xAttrSpecDelete_IN_xAttrSpecDelete_xox_FILE_xxattr                           710331 
#define ERROR_IN_xAttrNew_IN_xAttrNew_xox_FILE_xxattr                                         710341 
#define ERROR_IN_xAttrCopy_IN_xAttrCopy_xox_FILE_xxattr                                       710351 
#define ERROR_IN_xAttrDelete_IN_xAttrDelete_xox_FILE_xxattr                                   710361 
#define ERROR_IN_xAttrSetPtrVal_IN_xAttrSetPtrVal_xox_FILE_xxattr                             710371 
#define ERROR_IN_xAttrSetIntVal_IN_xAttrSetIntVal_xox_FILE_xxattr                             710381 
#define ERROR_IN_xAttrSetRealVal_IN_xAttrSetRealVal_xox_FILE_xxattr                           710391 
#define ERROR_IN_xAttrGetPtrVal_IN_xAttrGetPtrVal_xox_FILE_xxattr                             710401 
#define ERROR_IN_xAttrGetIntVal_IN_xAttrGetIntVal_xox_FILE_xxattr                             710411 
#define ERROR_IN_xAttrGetRealVal_IN_xAttrGetRealVal_xox_FILE_xxattr                           710421 
#define ERROR_IN_xCellFromId_xox_IN_xCellSetAttr_xox_FILE_xxattr                              710431
#define ERROR_IN_xCellSetAttr_IN_xCellSetAttr_xox_FILE_xxattr                                 710441 
#define ERROR_IN_xCellFromId_xox_IN_xCellGetAttr_xox_FILE_xxattr                              710451
#define ERROR_IN_xCellGetAttr_IN_xCellGetAttr_xox_FILE_xxattr                                 710461 
#define ERROR_IN_xCellFromId_xox_IN_xCellRemoveAttr_xox_FILE_xxattr                           710471
#define ERROR_IN_xCellRemoveAttr_IN_xCellRemoveAttr_xox_FILE_xxattr                           710481 
#define ERROR_IN_xFrameFromId_xox_IN_xFrameSetAttr_xox_FILE_xxattr                            710491
#define ERROR_IN_xFrameSetAttr_IN_xFrameSetAttr_xox_FILE_xxattr                               710521
#define ERROR_IN_xFrameFromId_xox_IN_xFrameGetAttr_xox_FILE_xxattr                            710531
#define ERROR_IN_xFrameGetAttr_IN_xFrameGetAttr_xox_FILE_xxattr                               710541
#define ERROR_IN_xFrameFromId_xox_IN_xFrameRemoveAttr_xox_FILE_xxattr                         710551
#define ERROR_IN_xFrameRemoveAttr_IN_xFrameRemoveAttr_xox_FILE_xxattr                         710561
#define ERROR_IN_xsubc_ig53_FROM_xgrpc_1                                                      710711
#define ERROR_IN_xsubc_ig53_FROM_xgrpc_2                                                      710712
#define ERROR_IN_xsubc_ig53_FROM_xgrpc_3                                                      710713
#define ERROR_IN_xsubc_ig53_FROM_subtract                                                     710714
#define ERROR_IN_xconvt_ig53                                                                  710715

#define  ERROR_IN_xGeomPolygonsToTol           710611
#define  ERROR_IN_SETTING_TOLERANCE_SELECTION  710613
#define  SCALING_FACTOR_IS_NOT_POSITIVE_IN_xfacet_FILE_xfacet 710612 

#define ERROR_IN_xGmNewNurb_IN_xGmNewNurbSurf_xox_FILE_xxgeom 720011
#define ERROR_IN_xGmToId_xox_IN_xGmNewNurbSurf_xox_FILE_xxgeom 720021
#define ERROR_IN_xGmNewNurbSurf_xox_IN_xNurbGeomSurface_xox_FILE_xxnurbs 720031


#define ERROR_IN_xBasicGeomManifoldCheck_xax_IN_xx_to_sv_FILE_xx_toansys                     800000
#define SHAPES_NON_MANIFOLD_GEOMETRY_IN_xx_to_sv_FILE_xx_toansys                             800001
#define ERROR_IN_xsvshq_IN_xx_to_sv_FILE_xx_toansys                                          800002
#define NO_ENOUGH_MEMORY_IN_xx_to_sv_FILE_xx_toansys                                         800003
#define ERROR_IN_xsvshg_IN_xx_to_sv_FILE_xx_toansys                                          800004
#define ERROR_IN_xx_to_sh_IN_xx_to_sv_FILE_xx_toansys                                        800005
#define ERROR_IN_trmsv_IN_xx_to_sv_FILE_xx_toansys                                           800006
#define SHAPES_XSUBVOLUME_ALREADY_CONVERTED_IN_xx_to_sv_FILE_xx_toansys                      800007
#define ERROR_IN_xaxDbaseInsert_IN_xx_to_sv_FILE_xx_toansys                                  800008
#define CAN_NOT_FREE_MEMORY_IN_xx_to_sv_FILE_xx_toansys                                      800009
#define ERROR_IN_xshsaq_IN_xx_to_sh_FILE_xx_toansys                                          800010
#define NO_ENOUGH_MEMORY_IN_xx_to_sh_FILE_xx_toansys                                         800011
#define ERROR_IN_xshsag_IN_xx_to_sh_FILE_xx_toansys                                          800012
#define ERROR_IN_xx_to_sa_IN_xx_to_sh_FILE_xx_toansys                                        800013
#define ERROR_IN_sewsh_IN_xx_to_sh_FILE_xx_toansys                                           800014
#define ERROR_IN_xaxDbaseInsert_IN_xx_to_sh_FILE_xx_toansys                                  800015
#define CAN_NOT_FREE_MEMORY_IN_xx_to_sh_FILE_xx_toansys                                      800016
#define ERROR_IN_xBasicGeomManifoldCheck_xax_IN_xx_to_sa_FILE_xx_toansys                     800017
#define SHAPES_NON_MANIFOLD_GEOMETRY_IN_xx_to_sa_FILE_xx_toansys                             800018
#define ERROR_IN_xsalpq_IN_xx_to_sa_FILE_xx_toansys                                          800019
#define NO_ENOUGH_MEMORY_1_IN_xx_to_sa_FILE_xx_toansys                                       800020
#define ERROR_IN_xsalpg_IN_xx_to_sa_FILE_xx_toansys                                          800021
#define ERROR_IN_xx_to_lp_IN_xx_to_sa_FILE_xx_toansys                                        800022
#define ERROR_IN_xsasuq_IN_xx_to_sa_FILE_xx_toansys                                          800023
#define NO_ENOUGH_MEMORY_2_IN_xx_to_sa_FILE_xx_toansys                                       800024
#define ERROR_IN_xsasug_IN_xx_to_sa_FILE_xx_toansys                                          800025
#define ERROR_IN_trmsa_IN_xx_to_sa_FILE_xx_toansys                                           800026
#define SHAPES_XSUBAREA_ALREADY_CONVERTED_IN_xx_to_sa_FILE_xx_toansys                        800027
#define ERROR_IN_xaxDbaseInsert_IN_xx_to_sa_FILE_xx_toansys                                  800028
#define CAN_NOT_FREE_MEMORY_1_IN_xx_to_sa_FILE_xx_toansys                                    800029
#define CAN_NOT_FREE_MEMORY_2_IN_xx_to_sa_FILE_xx_toansys                                    800030
#define ERROR_IN_xlpslq_IN_xx_to_lp_FILE_xx_toansys                                          800031
#define NO_ENOUGH_MEMORY_IN_xx_to_lp_FILE_xx_toansys                                         800032
#define ERROR_IN_xlpslg_IN_xx_to_lp_FILE_xx_toansys                                          800033
#define ERROR_IN_xx_to_sl_IN_xx_to_lp_FILE_xx_toansys                                        800034
#define ERROR_IN_sewlp_IN_xx_to_lp_FILE_xx_toansys                                           800035
#define SHAPES_XLOOP_ALREADY_CONVERTED_IN_xx_to_lp_FILE_xx_toansys                           800036
#define ERROR_IN_xaxDbaseInsert_IN_xx_to_lp_FILE_xx_toansys                                  800037
#define CAN_NOT_FREE_MEMORY_IN_xx_to_lp_FILE_xx_toansys                                      800038
#define ERROR_IN_xslptg_IN_xx_to_sl_FILE_xx_toansys                                          800039
#define ERROR_IN_xx_to_pt_IN_xx_to_sl_FILE_xx_toansys                                        800040
#define ERROR_IN_xslcuq_IN_xx_to_sl_FILE_xx_toansys                                           800041
#define NO_ENOUGH_MEMORY_IN_xx_to_sl_FILE_xx_toansys                                         800042
#define ERROR_IN_xslcug_IN_xx_to_sl_FILE_xx_toansys                                           800043
#define ERROR_IN_trmsl_IN_xx_to_sl_FILE_xx_toansys                                           800044
#define SHAPES_XSUBLINE_ALREADY_CONVERTED_IN_xx_to_sl_FILE_xx_toansys                        800045
#define ERROR_IN_xaxDbaseInsert_IN_xx_to_sl_FILE_xx_toansys                                  800046
#define CAN_NOT_FREE_MEMORY_IN_xx_to_sl_FILE_xx_toansys                                      800047
#define ERROR_IN_xptcog_IN_xx_to_pt_FILE_xx_toansys                                           800048
#define ERROR_IN_ptcr_IN_xx_to_pt_FILE_xx_toansys                                             800049
#define SHAPES_XPOINT_ALREADY_CONVERTED_IN_xx_to_pt_FILE_xx_toansys                          800050
#define ERROR_IN_xaxDbaseInsert_IN_xx_to_pt_FILE_xx_toansys                                  800051
#define ERROR_IN_xGmToId_xox_IN_xx_toansys_geom_FILE_xbexport                                800052
#define ERROR_IN_xGmFindCellGeoms_xox_IN_xx_toansys_geom_FILE_xbexport                       800053
#define ERROR_IN_xIntListGetLength_xox_IN_xx_toansys_geom_FILE_xbexport                      800054
#define NO_ENOUGH_MEMORY_IN_xx_toansys_geom_FILE_xbexport                                    800055
#define ERROR_IN_xCopyIntList_xax_IN_xx_toansys_geom_FILE_xbexport                           800056
#define ERROR_IN_xIntListDelete_xox_IN_xx_toansys_geom_FILE_xbexport                         800057
#define ERROR_IN_xGmGetDim_xox_IN_xx_toansys_geom_FILE_xbexport                              800058
#define ERROR_IN_xx_to_pt_IN_xx_toansys_geom_FILE_xbexport                                   800059
#define ERROR_IN_xx_to_sl_IN_xx_toansys_geom_FILE_xbexport                                   800060
#define ERROR_IN_xx_to_sa_IN_xx_toansys_geom_FILE_xbexport                                   800061
#define ERROR_IN_xx_to_sv_IN_xx_toansys_geom_FILE_xbexport                                   800062
#define ERROR_IN_entatt_IN_xx_toansys_geom_FILE_xbexport                                     800063
