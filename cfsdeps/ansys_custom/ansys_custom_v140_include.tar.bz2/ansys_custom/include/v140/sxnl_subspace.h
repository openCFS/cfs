//////////////////////////////////////////////////////////////////////////// 
//                                                                        // 
//          Copyright (C) 2010 ANSYS Inc.  All Rights Reserved            // 
//                                                                        // 
// This file contains proprietary software licensed from ANSYS Inc.       // 
// This header must remain in any source code despite modifications or    // 
// enhancements by any party.                                             // 
//                                                                        // 
//////////////////////////////////////////////////////////////////////////// 
// 
// $Workfile: sxnl_speedup.h $ 
// $Revision: 148162 $Id:  
// $Date: 2010-04-21 11:44:16 -0400 (Wed, 21 Apr 2010) $ 
// $Author: eedelor $ Emmanuel Delor / Michel Rochette 
// 
// Decription:  
// 
//////////////////////////////////////////////////////////////////////////// 
 
  
#ifndef __SXNL_SUBSPACE_H__ 
#define __SXNL_SUBSPACE_H__ 1 

#include <stdio.h>  
#include <stdlib.h>  
#include "computer.h"  
#include "globals.h"  
#include "sysparh.h"  
#include "cadoe.h"  
#include "cadoesys.h"  
#include "adoc.h"  
#include "cadoe_vector.h" 
#include "C_MessageTool.h"  
#include "C_VecP.h"
#include "C_vstruct.h"

class C_ItfSpeedUp;
class C_AnsysModele;

class C_Subspace
{
public:
  C_Subspace(C_ItfSpeedUp *itfSpeedUp, C_AnsysModele *model)
  {
    _maxDimQ = _nbRun = 0; 
    _bDofInd = _bDofIndVerif = NULL; 
    _Q = NULL; 
    
    _DofMaxFext = -1; 
    _MaxFext = 0.; 
    _DofMaxReac = -1;
    _MaxReac = 0.;
    
    _itfSpeedUp = itfSpeedUp;
    _model = model;
  };
  
  ~C_Subspace() 
  {
    BV_FREE(_bDofInd); 
    BV_FREE(_bDofIndVerif);
    if (_Q) delete _Q;
  };
  
  int allocate(int dimVector);
  int addVector(C_VecP<double> &Uvect, int &addVector, bool allowToAdd = true);
  int resize(int dim);
  int projInBasis(C_VecPi<double> &coefs, int dimReduceQ, C_VecPi<double> &solInd);
  void UbcsToUMDofs(C_Vec<double> &Uans, C_Vec<double> &Upart);
  void UbcsToUVDofs(C_Vec<double> &Uans, C_Vec<double> &Upart);

  void setModel(C_AnsysModele *model) {_model = model;}
  
  BVEC *getMDOFsBcs() {return _bDofInd;};
  BVEC *getVDOFsBcs() {return _bDofIndVerif;};
  
  int getDofMaxFext() {return _DofMaxFext;}
  int getDofMaxReac() {return _DofMaxReac;}
  
  int getNbPartialBcs() {return (_bDofInd == NULL ? 0 : LM_bv_nb_on(_bDofInd));};
  int getNbRun() {return _nbRun;};
  C_VSTRUCT<double> *getQ() {return _Q;};
  int getDimQ() {return (_Q == NULL ? 0 : _Q->getDim());};
  
  int ElemToAssemblyMDOFs(IVEC *listElem, C_VecPi<int> &listConnectedMDOFs);
  int ElemToAssemblyVDOFs(IVEC *listElem, C_VecPi<int> &listConnectedVDOFs);
  
  int restoreForce(C_VecPi<double> &Force, BVEC *bDof);
  int restoreForceMDOFs(C_VecPi<double> &Force);
  int restoreForceVDOFs(C_VecPi<double> &Force);
  
  // methods to add and remove MDOFs
  int addNonZero(C_VecPi<double> &Uind, bool addToMDOFs = true);
  void addMaxBcs(C_VecPi<double> &);
  int addMaxUincr(C_VecPi<double> &Uincr, double *val, bool addToMDOFs = true); 
  int addMaxFext(C_VecPi<double> &Fext, bool addToMDOFs = true);
  int addMaxResidu(C_VecPi<double> &Fint, C_VecPi<double> &Fext, 
		   double valU, C_VecPi<double> &Uincr, bool addToMDOFs = true); 
  int addMaxResiduContact(C_VecPi<double> &Fint, C_VecPi<double> &Uincr, 
			  vector <C_VecPi<int> *> &regions, bool addToMDOFs = true);
  int addMaxReac(C_VecPi<double> &Fnr);
  int addMaxResiduFromContactZone(C_VecPi<double> &Uincr, C_VecPi<double> &Fnr, bool addToMDOFs = true);
  
  int delMinUincr(C_VecPi<double> &Uincr, bool addToMDOFs = true);
  int delMinFext(C_VecPi<double> &Fext, bool addToMDOFs = true); 
  int delMinResidu(C_VecPi<double> &Fint, C_VecPi<double> &Fext, bool addToMDOFs = true);

  int updateMDOFsWithOptions();
  
  double MemSize();
  virtual int Write (FILE *fp);
  virtual int Read (FILE *fp);

  int PrintDofs(bool master, bool verif);
  int FillSummary(string &message);
  
protected: 
  C_ItfSpeedUp *_itfSpeedUp;
  C_AnsysModele *_model;
  
  static const int INCREMENT_DIMQ = 20; // increment of subspace
  int _maxDimQ;
  int _nbRun;
  
  // working vectors  
  C_VecPi<double> _UInd;	// displacement vector (in BCS space) 
  C_VecPi<double> _resInd;	// residual vector (in BCS space) 
  
  int _DofMaxFext;		// BCS dof where external forces are maximum 
  double _MaxFext;		// maximum value of external forces 
  int _DofMaxReac;
  double _MaxReac;
  
  int _eltMaxLoad;		// numero of element where external forces are maximum 
  
  BVEC *_bDofInd;		// masters dofs list in BCS space 
  BVEC *_bDofIndVerif;		// verif dofs list in BCS space 
  
  C_VSTRUCT<double> *_Q;
};

#endif 
