/*
 *    author/date: yu-hua ting/05-04-94
 *
 *    primary function:
 *
 *         Header for "heap memory management" routines for  Ansys/Shapes Interface
 *         and attribute handler
 *
 *    secondary function:
 *
 *        none
 *
 *    routines included:
 *
 *
 *    history
 *
 *        none
 *
 *    comments:
 *
 *        i).  The heap memory management has the alignment according to the
 *             size of the data type "double" in integer words
 *
 *    Notice - This file contains ANSYS Confidential information ***
 *
 */
/* 
 * *** copyright(c) 2011 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */






/****************************************************************************
 *    Initialize the heap memory management for Ansys/Shapes Interface      *
 *                                                                          *
 ****************************************************************************/

      extern INT xInitHeap_xax ansPROTO((
             INT *heap_tag,   /*   O - heap tag                                     */
             INT     *iretp));/*   O - error code
                               *       == 0 - no error
                               *       != 0 - error                                 */



/****************************************************************************
 *    Close the heap memory management for Ansys/Shapes Interface           *
 *                                                                          *
 *    Return error_code  == 0 - ok                                          *
 *                       != 0 - error                                       *
 *                                                                          *
 ****************************************************************************/

      extern VOID xCloseHeap_xax ansPROTO((
      INT     *iretp));      /*   O - error code
                              *       == 0 - no error
                              *       != 0 - error                                 */

              


/****************************************************************************
 *    Initialize the heap memory management for attribute Handler           *
 *                                                                          *
 ****************************************************************************/

      extern INT xInitHeap_att ansPROTO((
             INT *heap_tag,         /* I/O - heap tag                                     */
             INT     *iretp));      /*   O - error code
                                     *       == 0 - no error
                                     *       != 0 - error                                 */



/****************************************************************************
 *    Close the heap memory management for attribute handler                *
 *                                                                          *
 *    Return error_code  == 0 - ok                                          *
 *                       != 0 - error                                       *
 *                                                                          *
 ****************************************************************************/

      extern VOID xCloseHeap_att ansPROTO((
             INT     *iretp));      /*   O - error code
                                     *       == 0 - no error
                                     *       != 0 - error                                 */


/****************************************************************************
 *    Allocate a heap memory in bytes for Shapes/XOX                        *
 ****************************************************************************/
 
 

      extern xaxADDR ualloc ansPROTO((
             INT num_bytes));    /* I   number of bytes of the heap memory to be
                                  *     allocated                                  */


/****************************************************************************
 *    Free a heap memory with a given virtual memory address for            *
 *    Shapes/XOX                                                            *
 ****************************************************************************/

      extern xaxADDR ufree ansPROTO((
             xaxADDR virtual_memory_address));



/****************************************************************************
 *    Allocate a heap memory in bytes for ANsys/Shapes interface            *
 ****************************************************************************/
 
 

      extern xaxADDR xMalloc_xax ansPROTO((
             INT num_bytes));    /* I   number of bytes of the heap memory to be
                                  *     allocated                                  */


/****************************************************************************
 *    Free a heap memory with a given virtual memory address for            *
 *    Ansys/Shapes interface                                                *
 ****************************************************************************/

      extern xaxADDR xFree_xax ansPROTO((
             xaxADDR virtual_memory_address));






/****************************************************************************
 *    Allocate a heap memory in bytes from the attribute heap memory        *
 *    for the attribute handler                                             *
 ****************************************************************************/


      extern xaxADDR xMalloc_atta ansPROTO((
             INT num_bytes));    /* I   number of bytes of the heap memory to be
                                  *     allocated                                  */
 

 
/****************************************************************************
 *    Free a heap memory with a given virtual memory address from the       *
 *    attribute heap memory for attribute handler                           *
 ****************************************************************************/
 
 
      extern xaxADDR xFree_atta ansPROTO((
             xaxADDR virtual_memory_address));
 

 


/****************************************************************************
 *    Allocate a heap memory in bytes from the Ansys/Shapes Interface       *
 *    heap memory for the attribute handler                                 *
 ****************************************************************************/
 
/* the _attb versions are no longer being called, and the malloc function 
   contains a reference to stkcom.inc, which was gutted at 5.5. */
 
/*      extern xaxADDR xMalloc_attb ansPROTO((
             INT num_bytes)); */ /* I   number of bytes of the heap memory to be
                                  *     allocated                                  */
 

/****************************************************************************
 *    Free a heap memory with a given virtual memory address from           *
 *    Ansys/Shapes Interface heap memory for attribute handler              *
 ****************************************************************************/
  
 
 
/*      extern xaxADDR xFree_attb ansPROTO((
             xaxADDR virtual_memory_address)); */
 

 
 
/****************************************************************************
 *    Allocate a heap memory in bytes for the attribute handler             *
 ****************************************************************************/
 
 
      extern xaxADDR xMalloc_att ansPROTO((
             INT num_bytes));    /* I   number of bytes of the heap memory to be
                                  *     allocated                                  */
 
 
/****************************************************************************
 *    Free a heap memory with a given virtual memory address                *
 *    for attribute handler                                                 *
 ****************************************************************************/
 
 
 
      extern xaxADDR xFree_att ansPROTO((
             xaxADDR virtual_memory_address));
 

