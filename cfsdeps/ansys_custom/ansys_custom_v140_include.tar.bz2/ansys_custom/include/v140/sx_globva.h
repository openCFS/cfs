/* CADOE */
/****************************************************************************
 *  globva.h - global variables
 * 
 * |Module: nbbva
 *
 * |Description: global variables - declarations dans readmodel.c
 *
 * |Includes:	
 *        
 * |Auteur: Jean-Daniel Beley
 *
 * |Creation: Mai 1999
 *
 * |Version: $Id: sx_globva.h,v 1.6 2010/04/16 20:11:12 srpailla Exp $
 *
 * |Copyright:	copyright(c) 2010 SAS IP, Inc.  All rights reserved.
 *
 ******************************************************************************/
#include "sx_CADOE_solver.h"
#ifndef __GLOBVA_H_DEJA_INCLUS__
#define __GLOBVA_H_DEJA_INCLUS__ 1

#ifdef __cplusplus
extern "C" {
#endif


/* 
 * Variables globales - Declarations a faire dans readmodel.c
 */

extern T_booleen G_frequence_reelle;
extern double G_hi_angle0, G_hi_dangle, G_hi_angleupd;

extern T_prop_elem *G_prop_elem_freq;

extern int  G_pade;
extern int  G_mode_reprise;

extern FILE *G_log;

/* Va Lite variables */
extern T_booleen G_etude_est_ppm;

extern int G_restrt;

extern VEC* G_Up;
extern VEC* G_U0;

extern int G_nb_ddl;



extern void STATIC_SetModele( T_modele *modele );
extern T_modele *STATIC_GetModele(void);

extern void STATIC_SetPar( PAR *par);
extern PAR *STATIC_GetPar(void);

extern void STATIC_SetParUtilisateur( PAR *par_utilisateur);
extern PAR *STATIC_GetParUtilisateur(void);

#ifdef __cplusplus
}
#endif

#endif				/* __GLOBVA_H_DEJA_INCLUS__ */




