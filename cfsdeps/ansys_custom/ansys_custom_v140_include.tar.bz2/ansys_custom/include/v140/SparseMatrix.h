/*****************************************************************************
 *                   Copyright (C) 1999 CMSoft                               *
 *                                                                           *
 *  These lines of code and declarations contain unpublished proprietary     *
 *  information of CMSoft. They may not be copied or duplicated in whole     *
 *  or part without prior authorization from CMSoft.                         *
 *                                                                           *
 *****************************************************************************/

#ifndef FS_SPARSE_MATRIX_H_
#define FS_SPARSE_MATRIX_H_

#include <stdio.h>

class FSVector;
class FSFullMatrix;
class FSConnectivity;
class FullSquareMatrix;
class DofSetArray;
class ConstrainedDSA;
class FSOperator;

class SMV {
  public:
    FSOperator &M;
  const FSVector &v;
  SMV(FSOperator &_M, const FSVector &_v) : M(_M), v(_v) {}
};

class FSOperator {
   public:
        virtual double MemSize()                            =0;
        virtual double diag(int n)                          =0;
        virtual void   add(FullSquareMatrix &kel, int *dofs)=0;
        virtual void   add(FSFullMatrix &kel, int *dofs)    =0;
        virtual void   zeroAll()                            =0;
        virtual int    dim()                                =0;
        virtual void mult(const double* rhs, double* result)=0;

        virtual void multSubtract(double*, double* ) 
        { printf("multSubtract Error\n"); }
        virtual void multSub(double* , double* ) 
        { printf("multSub Error\n"); }
        virtual void multDiag(double* , double* ) 
        { printf("multDiag Error\n"); } 
        virtual void transposeMultAdd(double* , double* ) 
        { printf("transposeMultAdd\n"); }
        SMV operator * (const FSVector &x) { return SMV(*this,x); }
};

class FSSparseData {
 protected:
  int *_unconstrNum;   // unconstrained dof numbering, size = neq
  int *_constrndNum;   // constrained dof numbering
  int *_xunonz;        // column pointers, size = numConstrained+1
  int *_rowu;          // row numbers,     size = xunonz[numConstrained]
  int _numConstrained; // number of constrained dofs
  int _numUncon;       // number of unconstrained dofs
  int _neq;            // number of total dofs
  bool _ownUnconstrNum, _ownConstrndNum;
  
 public:
  // Constructors for Rectangular Sparse Matrices
  FSSparseData(FSConnectivity *con, DofSetArray *dsa, ConstrainedDSA *cdsa);
  FSSparseData(FSConnectivity *con, DofSetArray *dsa, int *glBMap, int *glIMap);

  // Constructors for Square Sparse Matrices
  FSSparseData(DofSetArray *dsa, ConstrainedDSA *cdsa, FSConnectivity *con);
  FSSparseData(DofSetArray *dsa, FSConnectivity *con, int* rowcolnum);
  FSSparseData(int nr, int nc, int *_xunonz, int *_rowu);
  FSSparseData();
  virtual ~FSSparseData();

  int* Nz()	{return _xunonz;}
  int* ColNum() {return _rowu;}
  
  virtual double MemSize();
};

#endif
