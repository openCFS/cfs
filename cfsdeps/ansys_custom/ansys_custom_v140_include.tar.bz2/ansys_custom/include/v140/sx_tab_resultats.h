/* CADOE */
/**
 *  tab_resultats.h
 *
 *  Definition de la table des resultats dipsonibles pour tracer de courbes et iso.
 *
 *   
 **/

/* $Id: sx_tab_resultats.h,v 1.3 2009/11/13 16:13:04 jtm Exp $ */

/* protection contre lecture multiple */
#include "sx_cons_solver.h"
#include "sx_CADOE_solver.h"

#ifndef __TABRESULTATS_H__ 
#define __TABRESULTATS_H__ 1





/* 
 * 18 juillet 2003 (steph) - Les tables ne sont desormais incluses QUE dans slvcom/tab_crit.c. 
 * Utiliser les fonctions d'acces TCR de tab_crit.c / postTraitement.h
 */


#ifdef INCLUDED_FROM_TAB_CRIT_C  /* Les tables ne sont incluses QUE dans slvcom/tab_crit.c. Utiliser les fonctions d'acces. */

static T_tableau_resultat S_thermal_results[] = 
{
  {NODE_TEMP,	E_CLASS_NODE,	0,		E_NO_COMPONENT,		E_NO_POINT, FAUX,
   -1,   	7449,		STAT_ADOC,	7450/*Temp Node %d*/,	E_NUMERO_NOEUD, 0},
  {GRP_TEMP,	E_CLASS_GRP,	0,		E_NO_COMPONENT,		E_NO_POINT, FAUX,
   -1,   	7449,		STAT_ADOC,	7453/*Max Temp on %s*/,	E_NOMDUGROUPE, 0},
  {MOD_TEMP,	E_CLASS_MOD,		0,	E_NO_COMPONENT,		E_NO_POINT, FAUX,
   -1,		7449,		STAT_ADOC,	7455/*Max Temp */,	E_PASDECHAMP, 0},
  
  {NODE_TG,	E_CLASS_NODE,	0,		E_TG_COMPONENT,		E_NO_POINT, FAUX,
   -1,   	7464/*"Max Temperature Gradient (N) "*/,	STAT_ADOC,	7459/*"Temperature Gradient (N) of Node %d"*/,E_NUMERO_NOEUD, 0},
  {ELEM_TG,	E_CLASS_ELEM,	0,		E_TG_COMPONENT,		E_NO_POINT, FAUX,
   -1,		7462/*"Max Temperature Gradient"*/,	STAT_ADOC,	7460/*"Temperature Gradient of Element %d"*/,E_NUMERO_ELEMENT, 0},
  {MOD_ELEM_MAXTG,	E_CLASS_MOD,	0,     	E_TG_COMPONENT,		E_NO_POINT, FAUX,
   -1,		7462/*"Max Temperature Gradient"*/,	STAT_ADOC,	7462/*"Max Temperature Gradient"*/,	E_PASDECHAMP, 0},
  {GRP_ELEM_MAXTG,	E_CLASS_GRP,	0,      E_TG_COMPONENT,		E_NO_POINT, FAUX,
   ELEMENTS,	7462/*"Max Temperature Gradient"*/,	STAT_ADOC,	7463/*"Max Temperature Gradient on %s"*/,	E_PASDECHAMP, 0},
  {MOD_NODE_MAXTG,	E_CLASS_MOD,	0,      E_TG_COMPONENT,		E_NO_POINT, FAUX,
   -1,		7464/*"Max Temperature Gradient (N)"*/,	STAT_ADOC,	7464/*"Max Temperature Gradient (N)"*/,	E_PASDECHAMP, 0},
  {GRP_NODE_MAXTG,	E_CLASS_GRP,	0,     	E_TG_COMPONENT,		E_NO_POINT, FAUX,
   NOEUDS,	7464/*"Max Temperature Gradient (N)"*/,	STAT_ADOC,	7465/*"Max Temperature Gradient (N) on %s"*/,	E_PASDECHAMP, 0},
  
  {NODE_TF,	E_CLASS_NODE,	0,		E_TF_COMPONENT,		E_NO_POINT, FAUX,
   -1,   	7471/*"Max Heat Flux (N)"*/,		STAT_ADOC,	7467/*"Heat Flux (N) of Node %d"*/,E_NUMERO_NOEUD, 0},
  {ELEM_TF,	E_CLASS_ELEM,	0,		E_TF_COMPONENT,		E_NO_POINT, FAUX,
   -1,		7469/*"Max Heat Flux"*/,		STAT_ADOC,	7468/*"Heat Flux of Element %d"*/,E_NUMERO_ELEMENT, 0},
  {MOD_ELEM_MAXTF,	E_CLASS_MOD,	0,     	E_TF_COMPONENT,		E_NO_POINT, FAUX,
   -1,		7469/*"Max Heat Flux"*/,		STAT_ADOC,	7469/*"Max Heat Flux"*/,	E_PASDECHAMP, 0},
  {GRP_ELEM_MAXTF,	E_CLASS_GRP,	0,      E_TF_COMPONENT,		E_NO_POINT, FAUX,
   ELEMENTS,	7469/*"Max Heat Flux"*/,		STAT_ADOC,	7470/*"Max Heat Flux on %s"*/,	E_PASDECHAMP, 0},
  {MOD_NODE_MAXTF,	E_CLASS_MOD,	0,      E_TF_COMPONENT,		E_NO_POINT, FAUX,
   -1,		7471/*"Max Heat Flux (N)"*/,		STAT_ADOC,	7471/*"Max Heat Flux (N)"*/,	E_PASDECHAMP, 0},
  {GRP_NODE_MAXTF,	E_CLASS_GRP,	0,     	E_TF_COMPONENT,		E_NO_POINT, FAUX,
   NOEUDS,	7471/*"Max Heat Flux (N)"*/,		STAT_ADOC,	7472/*"Max Heat Flux (N) on %s"*/,	E_PASDECHAMP, 0},
  
  {ELEM_MASS,	E_CLASS_ELEM,	0,		E_NO_COMPONENT,		E_NO_POINT, FAUX,
   -1,		7162/*"Mass"*/,	STAT_ADOC,	7163/*"Mass of Element %d"*/,E_NUMERO_ELEMENT, 0},
  {MOD_MASS,	E_CLASS_MOD,	0,		E_NO_COMPONENT,		E_NO_POINT, FAUX,
   -1,		7162/*"Mass"*/,	STAT_ADOC,	7187/*"Model Mass"*/,E_PASDECHAMP, 0},
  {GRP_MASS,	E_CLASS_GRP,	0,		E_NO_COMPONENT,		E_NO_POINT, FAUX,
   ELEMENTS,	7162/*"Mass"*/,	STAT_ADOC,	7204/*"Mass of %s"*/,E_NOMDUGROUPE, 0},
  
  {RES_TEMPERATURE,	E_CLASS_GRP_CTR,	 0,	E_ALL_COMPONENTS,		E_NO_POINT, FAUX,
   -1,			7449/*"Temperature"*/,		STAT_ADOC_CONTOUR,		7449/*"Temperature"*/, E_PASDECHAMP, 0},
  
  {RES_TF,		E_CLASS_GRP_CTR,	 0,	E_ALL_COMPONENTS,		E_NO_POINT, FAUX,
   -1,			7466/*"Heat Flux"*/,		STAT_ADOC_CONTOUR,		7466/*"Heat Flux"*/, E_PASDECHAMP, 0},
  
  {RES_TG,		E_CLASS_GRP_CTR,	 0,	E_ALL_COMPONENTS,		E_NO_POINT, FAUX,
   -1,		    	7458/*"Temperature Gradient"*/,	STAT_ADOC_CONTOUR,		7458/*"Temperature Gradient"*/, E_PASDECHAMP, 0},
  {RES_TF_NOEUD,	E_CLASS_GRP_CTR,	 0,	E_ALL_COMPONENTS,		E_NO_POINT, FAUX,
   -1,			7478/*"Heat Flux (N)"*/,	STAT_ADOC_CONTOUR,		7478/*"Heat Flux (N)"*/, E_PASDECHAMP, 0},
  {RES_TG_NOEUD,	E_CLASS_GRP_CTR,	 0,	E_ALL_COMPONENTS,		E_NO_POINT, FAUX,
   -1,		    	7477/*"Temperature Gradient (N)"*/,	STAT_ADOC_CONTOUR,	747/*"Temperature Gradient (N)"*/, E_PASDECHAMP, 0},
  {RES_TF_NOEUD_C,	E_CLASS_GRP_CTR,	 0,	E_TF_COMPONENT,			E_NO_POINT, FAUX,
   -1,			7478/*"Heat Flux (N)"*/,    	STAT_ADOC_CONTOUR,		7478/*"Heat Flux (N)"*/, E_PASDECHAMP, 0},  
  
  {RES_TG_NOEUD_C,	E_CLASS_GRP_CTR,	 0,	E_TG_COMPONENT,			E_NO_POINT, FAUX,
   -1,			7477/*"Temperature Gradient (N)"*/,	STAT_ADOC_CONTOUR,	7477/*"Temperature Gradient (N)"*/, E_PASDECHAMP, 0},

  {RES_MESH_PERTURB,	E_CLASS_GRP_CTR,	 0,	E_ALL_COMPONENTS,		E_NO_POINT, FAUX,
   -1,			7230/*"Geometry"*/,		STAT_DYN_BDM_CONTOUR,		7230/*"Geometry"*/, E_PASDECHAMP, 0},
  
  {RES_MASSE,   	E_CLASS_GRP_CTR,	 0,	E_ALL_COMPONENTS,		E_NO_POINT, FAUX,
   -1,			7445/*"Mass at elements"*/,	STAT_ADOC_CONTOUR,		7445/*"Mass at elements"*/, E_PASDECHAMP, 0}
  

};

static T_tableau_resultat S_electric_results[] = 
{
  {NODE_VOLT,	E_CLASS_NODE,	0,		E_NO_COMPONENT,		E_NO_POINT, VRAI,
   -1,   	7451,		STAT_ADOC,	7452,E_NUMERO_NOEUD, 0},
  {GRP_VOLT,	E_CLASS_GRP,	0,		E_NO_COMPONENT,		E_NO_POINT, VRAI,
   -1,   	7451,		STAT_ADOC,	7454,E_NOMDUGROUPE, 0},
  {MOD_VOLT,	E_CLASS_MOD,		0,	E_DISP_COMPONENT,	E_NO_POINT, FAUX,
   -1,		7451,		STAT_ADOC,	7456,E_PASDECHAMP, 0},
  {ELEM_MASS,	E_CLASS_ELEM,	0,		E_NO_COMPONENT,		E_NO_POINT, FAUX,
   -1,		7162/*"Mass"*/,	STAT_ADOC,	7163/*"Mass of Element %d"*/,E_NUMERO_ELEMENT, 0},
  {MOD_MASS,	E_CLASS_MOD,	0,		E_NO_COMPONENT,		E_NO_POINT, FAUX,
   -1,		7162/*"Mass"*/,	STAT_ADOC,	7187/*"Model Mass"*/,E_PASDECHAMP, 0},
  {GRP_MASS,	E_CLASS_GRP,	0,		E_NO_COMPONENT,		E_NO_POINT, FAUX,
   ELEMENTS,	7162/*"Mass"*/,	STAT_ADOC,	7204/*"Mass of %s"*/,E_NOMDUGROUPE, 0},


  {RES_VOLT,		E_CLASS_GRP_CTR,	 0,	E_ALL_COMPONENTS,		E_NO_POINT, FAUX,
   -1,			7451/*"Volt"*/,			STAT_ADOC_CONTOUR,	7451/*"Volt"*/, E_PASDECHAMP, 0},
  {RES_MESH_PERTURB,	E_CLASS_GRP_CTR,	 0,	E_ALL_COMPONENTS,		E_NO_POINT, FAUX,
   -1,			7230/*"Geometry"*/,		STAT_DYN_BDM_CONTOUR,	7230/*"Geometry"*/, E_PASDECHAMP, 0},
  {RES_MASSE,   	E_CLASS_GRP_CTR,	 0,	E_ALL_COMPONENTS,		E_NO_POINT, FAUX,
   -1,			7445/*"Mass at elements"*/,	STAT_ADOC_CONTOUR,	7445/*"Mass at elements"*/, E_PASDECHAMP, 0}

};

static T_tableau_resultat S_magnetic_results[] = 
{
  {NOD_AZ,	E_CLASS_NODE,	0,		E_NO_COMPONENT,		E_NO_POINT, VRAI,
   -1,   	7451,		STAT_ADOC,	7452,E_NUMERO_NOEUD, 0},
  {GRP_AZ,	E_CLASS_GRP,	0,		E_NO_COMPONENT,		E_NO_POINT, VRAI,
   -1,   	7451,		STAT_ADOC,	7454,E_NOMDUGROUPE, 0},
  {MOD_AZ,	E_CLASS_MOD,		0,	E_DISP_COMPONENT,	E_NO_POINT, FAUX,
   -1,		7451,		STAT_ADOC,	7456,E_PASDECHAMP, 0},
  {ELEM_MASS,	E_CLASS_ELEM,	0,		E_NO_COMPONENT,		E_NO_POINT, FAUX,
   -1,		7162/*"Mass"*/,	STAT_ADOC,	7163/*"Mass of Element %d"*/,E_NUMERO_ELEMENT, 0},
  {MOD_MASS,	E_CLASS_MOD,	0,		E_NO_COMPONENT,		E_NO_POINT, FAUX,
   -1,		7162/*"Mass"*/,	STAT_ADOC,	7187/*"Model Mass"*/,E_PASDECHAMP, 0},
  {GRP_MASS,	E_CLASS_GRP,	0,		E_NO_COMPONENT,		E_NO_POINT, FAUX,
   ELEMENTS,	7162/*"Mass"*/,	STAT_ADOC,	7204/*"Mass of %s"*/,E_NOMDUGROUPE, 0},


  {RES_AZ,		E_CLASS_GRP_CTR,	 0,	E_ALL_COMPONENTS,		E_NO_POINT, FAUX,
   -1,			7451/*"Volt"*/,			STAT_ADOC_CONTOUR,	7451/*"Volt"*/, E_PASDECHAMP, 0},
  {RES_MESH_PERTURB,	E_CLASS_GRP_CTR,	 0,	E_ALL_COMPONENTS,		E_NO_POINT, FAUX,
   -1,			7230/*"Geometry"*/,		STAT_DYN_BDM_CONTOUR,	7230/*"Geometry"*/, E_PASDECHAMP, 0},
  {RES_MASSE,   	E_CLASS_GRP_CTR,	 0,	E_ALL_COMPONENTS,		E_NO_POINT, FAUX,
   -1,			7445/*"Mass at elements"*/,	STAT_ADOC_CONTOUR,	7445/*"Mass at elements"*/, E_PASDECHAMP, 0}

};

/*static T_tableau_resultat S_magnetic_results[] = 
{
};*/
/* table des criteres */
static T_tableau_resultat S_tableau_resultat[] = 
{
  {NODE_STRESS,		E_CLASS_NODE,	0,		E_STRAIN_COMPONENT,	E_NO_POINT, VRAI,
   -1,   		7130/*"Stress"*/,		STAT_ADOC,		7131/*"Stress Node %d"*/,E_NUMERO_NOEUD, 0},

  {NODE_STRAIN,		E_CLASS_NODE,	0,		E_STRAIN_COMPONENT,	E_NO_POINT, VRAI,
   -1,			7132/*"Strain"*/,		STAT_ADOC,		7133/*"Strain Node %d"*/,E_NUMERO_NOEUD, 0},

  {NODE_DISP,		E_CLASS_NODE,	0,		E_DISP_COMPONENT,	E_NO_POINT, FAUX,
   -1,			7134/*"Displacement"*/,		STAT_ADOC,		7135/*"Disp. Node %d"*/,E_NUMERO_NOEUD, 0},

  {NODE_MISES,		E_CLASS_NODE,	0,		E_NO_COMPONENT,		E_NO_POINT, VRAI,
   -1,			7136/*"VonMises"*/,		STAT_ADOC,		7137/*"VonMises Node %d"*/,E_NUMERO_NOEUD, 0},

  {NODE_TRESCA,		E_CLASS_NODE,	0,		E_NO_COMPONENT,		E_NO_POINT, VRAI,
   -1,			7138/*"Tresca"*/,		STAT_ADOC,		7139/*"Tresca Stress Node %d"*/,E_NUMERO_NOEUD, 0},

  {NODE_REACTION,	E_CLASS_NODE,	0,		E_REACTION_COMPONENT,	E_NO_POINT, FAUX,
   -1,			7140/*"Reaction"*/,		STAT_ADOC,		7141/*"Reaction Node %d"*/,E_NUMERO_NOEUD, 0},

  {NODE_SPRING_REAC,	E_CLASS_NODE,	0,		E_REACTION_COMPONENT,	E_NO_POINT, FAUX,
   -1,			7142/*"Spring Reaction"*/,	INDISPONIBLE,		7142/*""*/,E_PASDECHAMP, 0},

  {NODE_FORCE,		E_CLASS_NODE,	0,		E_FORCE_COMPONENT,	E_NO_POINT, VRAI,
   -1,			7435/*"Force"*/,		STAT_ADOC,		7436/*"Force Node %d"*/,E_NUMERO_NOEUD, 0},

  {NODE_MODE_DISP,	E_CLASS_NODE,	 0,		E_DISP_COMPONENT,		E_MODE, FAUX,
   -1,			7218/*"Mode"*/,			DYNA_BUCK_ADOC,		7220/*"Disp mode %d on node %d"*/,E_NUMODE_NOEUD, 0},

  {NODE_MODEU_DISP,	E_CLASS_NODE,	 0,		E_DISP_COMPONENT,		E_MODE, FAUX,
   -1,			7377/*"Mode (Unit Disp.)"*/,	DYNA_BUCK_ADOC,		7383/*"Disp mode (ud) %d on node %d"*/,E_NUMODE_NOEUD, 0},

  {NODE_MSSHEAR,	E_CLASS_NODE,	0,		E_NO_COMPONENT,		E_NO_POINT, VRAI,
   -1,			7423/*"Max Shear Stress"*/,	STAT_ADOC,		7426/*"Max Shear Stress Node %d"*/,E_NUMERO_NOEUD, 0},

  {NODE_CP,		E_CLASS_NODE,	0,		E_CP_COMPONENT,		E_POINT, VRAI,
   -1,			7168/*"Principal stress"*/,	STAT_ADOC,		7169/*"Principal Stress Node %d"*/,E_NUMERO_NOEUD, 0},

  {NODE_MAX_CP,		E_CLASS_NODE,	0,		E_NO_COMPONENT,		E_POINT, VRAI,
   -1,			7170/*"Max Principal stress"*/,	STAT_ADOC,		7430/*"Max Principal Stress Node %d"*/,E_NUMERO_NOEUD, 0},

  {NODE_USER1,		E_CLASS_NODE,	0,		E_NO_COMPONENT,		E_NO_POINT, FAUX,
   -1,			7143/*"Node User 1"*/,		INDISPONIBLE,		7143/*""*/,E_PASDECHAMP, 0},

  {NODE_USER2,		E_CLASS_NODE,	0,		E_NO_COMPONENT,		E_NO_POINT, FAUX,
   -1,			7144/*"Node User 2"*/,		INDISPONIBLE,		7144/*""*/,E_PASDECHAMP, 0},

  {NODE_USER3,		E_CLASS_NODE,	0,		E_NO_COMPONENT,		E_NO_POINT, FAUX,
   -1,			7145/*"Node User 3"*/,		INDISPONIBLE,		7145/*""*/,E_PASDECHAMP, 0},

  {ELEM_PG_STRESS,   	E_CLASS_ELEM,	0,		E_STRAIN_COMPONENT,	E_POINT, VRAI,
   -1,			7146/*"Stress"*/,		STAT_ADOC,		7147/*"Stress Element %d"*/,  E_NUMERO_ELEMENT, 0},

  {ELEM_PG_STRAIN,	E_CLASS_ELEM,	0,		E_STRAIN_COMPONENT,	E_POINT, VRAI,
   -1,			7148/*"Strain"*/,		STAT_ADOC,		7149/*"Strain Element %d"*/,E_NUMERO_ELEMENT, 0},

  {ELEM_PG_MISES,	E_CLASS_ELEM,	0,		E_NO_COMPONENT,		E_POINT, VRAI,
   -1,			7150/*"VonMises"*/,		STAT_ADOC,		7151/*"VonMises Stress Element %d"*/,E_NUMERO_ELEMENT, 0},

  {ELEM_PG_TRESCA,	E_CLASS_ELEM,	0,		E_NO_COMPONENT,		E_POINT, VRAI,
   -1,			7152/*"Tresca"*/,		STAT_ADOC,		7153/*"Tresca Stress Element %d"*/,E_NUMERO_ELEMENT, 0},

  {ELEM_PG_FORCE,	E_CLASS_ELEM,	0,		E_STRAIN_COMPONENT,	E_POINT, VRAI,
   -1,			7439/*"Force"*/,		STAT_ADOC,		7440/*"Force Element %d"*/,E_NUMERO_ELEMENT, 0},

  {ELEM_MOY_STRESS,	E_CLASS_ELEM,	0,		E_STRAIN_COMPONENT,	E_NO_POINT, VRAI,
   -1,			7154/*"Average stress"*/,	STAT_ADOC,		7155/*"Average Stress Element %d"*/,E_NUMERO_ELEMENT, 0},

  {ELEM_MOY_STRAIN,	E_CLASS_ELEM,	0,		E_STRAIN_COMPONENT,	E_NO_POINT, VRAI,
   -1,			7156/*"Average strain"*/,	STAT_ADOC,		7157/*"Average Strain Element %d"*/,E_NUMERO_ELEMENT, 0},

  {ELEM_MOY_MISES,	E_CLASS_ELEM,	0,		E_NO_COMPONENT,		E_NO_POINT, VRAI,
   -1,			7158/*"Average VonMises"*/,	STAT_ADOC,		7159/*"Average VonMises Stress Element %d"*/,E_NUMERO_ELEMENT, 0},

  {ELEM_MOY_TRESCA,	E_CLASS_ELEM,	0,		E_NO_COMPONENT,		E_NO_POINT, VRAI,
   -1,			7160/*"Average Tresca"*/,	STAT_ADOC,		7161/*"Average Tresca Stress Element %d"*/,E_NUMERO_ELEMENT, 0},

  {ELEM_MASS,		E_CLASS_ELEM,	0,		E_NO_COMPONENT,		E_NO_POINT, FAUX,
   -1,			7162/*"Mass"*/,			STAT_ADOC,		7163/*"Mass of Element %d"*/,E_NUMERO_ELEMENT, 0},

  {ELEM_ENER_STRAIN,	E_CLASS_ELEM,	0,		E_NO_COMPONENT,		E_NO_POINT, VRAI,
   -1,			7164/*"Strain Energy"*/,	STAT_ADOC,		7165/*"Strain Energy Element %d"*/,E_NUMERO_ELEMENT, 0},

  {ELEM_SED,		E_CLASS_ELEM,	0,		E_NO_COMPONENT,		E_NO_POINT, FAUX,
   -1,			7166/*"Strain Energy Density"*/,INDISPONIBLE,		7167/*"Strain Energy Density Element %d"*/,E_NUMERO_ELEMENT, 0},

  {ELEM_CP,		E_CLASS_ELEM,	0,		E_CP_COMPONENT,		E_POINT, VRAI,
   -1,			7168/*"Principal stress"*/,	STAT_ADOC,		7169/*"Principal Stress Element %d"*/,E_NUMERO_ELEMENT, 0},

  {ELEM_MAX_CP,		E_CLASS_ELEM,	0,		E_NO_COMPONENT,		E_NO_POINT, VRAI,
   -1,			7170/*"Max principal stress"*/,	STAT_ADOC,		7171/*"Max Principal Stress Element %d"*/,E_NUMERO_ELEMENT, 0},

  {ELE_MODAL_ENER,	E_CLASS_ELEM,	0,		E_NO_COMPONENT,		E_MODE, FAUX,
   -1,			7222/*"Energy"*/,		DYNA_BUCK_ADOC,		7224/*"Energy mode %d element %d"*/,E_NUMODE_ELEMENT, 0},

  {ELEM_DP,		E_CLASS_ELEM,	0,		E_CP_COMPONENT,		E_POINT, VRAI,
   -1,			7407/*"Principal strain"*/,	STAT_ADOC,		7408/*"Principal Strain Element %d"*/,E_NUMERO_ELEMENT, 0},

  {ELEM_MAX_DP,		E_CLASS_ELEM,	0,		E_NO_COMPONENT,		E_NO_POINT, VRAI,
   -1,			7409/*"Max principal strain"*/,	STAT_ADOC,		7410/*"Max Principal Strain Element %d"*/,E_NUMERO_ELEMENT, 0},

  {ELEM_MSSHEAR,	E_CLASS_ELEM,	0,		E_NO_COMPONENT,		E_NO_POINT, VRAI,
   -1,			7423/*"Max Shear Stress"*/,	STAT_ADOC,		7424/*"Max Shear Stress Element %d"*/,E_NUMERO_ELEMENT, 0},

  {ELEM_USER1,		E_CLASS_ELEM,	0,		E_NO_COMPONENT,		E_NO_POINT, FAUX,
   -1,			7175/*"Element User 1"*/,	INDISPONIBLE,		7175/*""*/,E_PASDECHAMP, 0},

  {ELEM_USER2,		E_CLASS_ELEM,	0,		E_NO_COMPONENT,		E_NO_POINT, FAUX,
   -1,			7176/*"Element User 2"*/,	INDISPONIBLE,		7176/*""*/,E_PASDECHAMP, 0},

  {ELEM_USER3,		E_CLASS_ELEM,	0,		E_NO_COMPONENT,		E_NO_POINT, FAUX,
   -1,			7177/*"Element User 3"*/,	INDISPONIBLE,		7177/*""*/,E_PASDECHAMP, 0},

  {MOD_ELEM_MAXSTRESS,	E_CLASS_MOD,	0,		E_STRAIN_COMPONENT,	E_NO_POINT, VRAI,
   -1,			7178/*"Max Stress"*/,		STAT_ADOC,		7178/*"Max Stress"*/,E_PASDECHAMP, 0},

  {MOD_ELEM_MAXSTRAIN,	E_CLASS_MOD,	0,		E_STRAIN_COMPONENT,	E_NO_POINT, VRAI,
   -1,			7179/*"Max Strain"*/,		STAT_ADOC,		7179/*"Max Strain"*/,E_PASDECHAMP, 0},

  {MOD_ELEM_MAXMISES,	E_CLASS_MOD,	0,		E_NO_COMPONENT,		E_NO_POINT, VRAI,
   -1,			7180/*"Max VonMises Stress"*/,	STAT_ADOC,		7180/*"Max VonMises"*/,E_PASDECHAMP, 0},

  {MOD_ELEM_MAXTRESCA,	E_CLASS_MOD,	0,		E_NO_COMPONENT,		E_NO_POINT, VRAI,
   -1,			7181/*"Max Tresca"*/,		STAT_ADOC,		7181/*"Max Tresca"*/,E_PASDECHAMP, 0},
  
  {MOD_ELEM_MAXFORCE,	E_CLASS_MOD,	0,		E_FORCE_COMPONENT,	E_NO_POINT, VRAI,
   -1,			7443/*"Max Element Force"*/,	STAT_ADOC,		7443/*"Max Element Force."*/,E_PASDECHAMP, 0},

  {MOD_NODE_MAXDISP,	E_CLASS_MOD,	0,		E_DISP_COMPONENT,	E_NO_POINT, FAUX,
   -1,			7182/*"Max Displacement"*/,	STAT_ADOC,		7182/*"Max Disp."*/,E_PASDECHAMP, 0},

  {MOD_NODE_MAXFORCE,	E_CLASS_MOD,	0,		E_FORCE_COMPONENT,	E_NO_POINT, VRAI,
   -1,			7437/*"Max Element Force (N)"*/,INDISPONIBLE,	        7437/*"Max Element Force (N)"*/,E_PASDECHAMP, 0},

  {MOD_NODE_MAXSTRESS,	E_CLASS_MOD,	0,		E_STRAIN_COMPONENT,	E_NO_POINT, VRAI,
   -1,			7183/*"Max Stress (N)"*/,	STAT_ADOC,		7183/*"Max Stress (N)"*/,E_PASDECHAMP, 0},

  {MOD_NODE_MAXSTRAIN,	E_CLASS_MOD,	0,		E_STRAIN_COMPONENT,	E_NO_POINT, VRAI,
   -1,			7184/*"Max Strain (N)"*/,	STAT_ADOC,		7184/*"Max Strain (N)"*/,E_PASDECHAMP, 0},

  {MOD_NODE_MAXMISES,	E_CLASS_MOD,	0,		E_NO_COMPONENT,		E_NO_POINT, VRAI,
   -1,			7185/*"Max VonMises (N)"*/,	STAT_ADOC,		7185/*"Max VonMises (N)"*/,E_PASDECHAMP, 0},

  {MOD_NODE_MAXTRESCA,	E_CLASS_MOD,	0,		E_NO_COMPONENT,		E_NO_POINT, VRAI,
   -1,			7186/*"Max Tresca (N)"*/,	STAT_ADOC,		7186/*"Max Tresca (N)"*/,E_PASDECHAMP, 0},

  {MOD_MASS,		E_CLASS_MOD,	0,		E_NO_COMPONENT,		E_NO_POINT, FAUX,
   -1,			7162/*"Mass"*/,			STAT_ADOC,		7187/*"Model Mass"*/,E_PASDECHAMP, 0},

  {MOD_SED,		E_CLASS_MOD,	0,		E_NO_COMPONENT,		E_NO_POINT, FAUX,
   -1,			7166/*"Strain energy density"*/,INDISPONIBLE,		7166/*"Strain Energy Density"*/,E_PASDECHAMP, 0},

  {MOD_ENER_STRAIN,	E_CLASS_MOD,	0,		E_NO_COMPONENT,		E_NO_POINT, FAUX,
   -1,			7164/*"Strain energy"*/,	STAT_ADOC,		7164/*"Strain Energy"*/,E_PASDECHAMP, 0},

  {MOD_ELEM_MAX_ENER_STRAIN,	E_CLASS_MOD,	0,	E_NO_COMPONENT,		E_NO_POINT, FAUX,
   -1,			7188/*"Max strain energy"*/,	INDISPONIBLE,		7188/*"Max Strain Energy"*/, E_PASDECHAMP, 0},

  {MOD_ELEM_MAX_CP,	E_CLASS_MOD,	0,		E_NO_COMPONENT,		E_NO_POINT, VRAI,
   -1,			7170/*"Max principal stress"*/,	STAT_ADOC,		7170/*"Max Principal Stress"*/, E_PASDECHAMP, 0},

  {MOD_REACTION,	E_CLASS_MOD,	0,		E_REACTION_COMPONENT,	E_NO_POINT, FAUX,
   -1,			7189/*"Max Reaction"*/,		STAT_ADOC,		7189/*"Max Reaction"*/, E_PASDECHAMP, 0},

  {MOD_SOM_REAC,	E_CLASS_MOD,	0,		E_REACTION_COMPONENT,	E_NO_POINT, FAUX,
   -1,			7190/*"Total Reaction"*/,	INDISPONIBLE,		7190/*"Total Reaction"*/, E_PASDECHAMP, 0},

  {MOD_ELEM_MAX_EFFORT,	E_CLASS_MOD,	0,		E_FORCE_COMPONENT,	E_NO_POINT, FAUX,
   -1,			7174/*"Max element force"*/,	STAT_ADOC,		7174/*"Max Element Force"*/, E_PASDECHAMP, 0},

  {FREQUENCE_PROPRE,    E_CLASS_MOD,       0,           E_NO_COMPONENT,           E_MODE, FAUX,
   -1,                  7214/*"Frequency"*/,           	DYNA_ADOC,	       	7380/*"Frequency %s"*/,E_NOMDUMODE, 0},

  {LOAD_FACTOR,         E_CLASS_MOD,       0,           E_NO_COMPONENT,           E_MODE, FAUX,
   -1,                  7446/*"Load Multiplier"*/,      BUCK_ADOC,	       	7447/*"Load Multiplier %s"*/,E_NOMDUMODE, 0},

  {MOD_MODE_MAXDISP,	E_CLASS_MOD,	 0,		E_DISP_COMPONENT,		E_MODE, FAUX,
   -1,			7218/*"Mode"*/,			DYNA_BUCK_ADOC,		7219/*"Max Disp. Mode %d"*/,E_NUMERODUMODE, 0},

  {MOD_MODEU_MAXDISP,	E_CLASS_MOD,	 0,		E_DISP_COMPONENT,		E_MODE, FAUX,
   -1,			7377/*"Mode"*/,			DYNA_BUCK_ADOC,		7381/*"Max Disp. Mode %d"*/,E_NUMERODUMODE, 0},

  {MOD_MODAL_ENER,	E_CLASS_MOD,	 0,		E_NO_COMPONENT,		E_MODE, FAUX,
   -1,			7222/*"Energy"*/,		DYNA_BUCK_ADOC,	   	7223/*"Energy mode %d"*/,E_NOMDUMODE, 0},

  {MOD_ELEM_MAX_DP,	E_CLASS_MOD,	0,		E_NO_COMPONENT,		E_NO_POINT, VRAI,
   -1,			7411/*"Max principal strain"*/,	STAT_ADOC,		7411/*"Max Principal Strain"*/, E_PASDECHAMP, 0},

  {MOD_NODE_MAX_MSSHEAR,	E_CLASS_MOD,	0,		E_NO_COMPONENT,		E_NO_POINT, VRAI,
   -1,		7427/*"Max of Max Shear Stress (N)"*/,STAT_ADOC,		7427/*"Max of Max Shear Stress (N)"*/,E_PASDECHAMP, 0},

  {MOD_ELEM_MAX_MSSHEAR,	E_CLASS_MOD,	0,		E_NO_COMPONENT,		E_NO_POINT, VRAI,
   -1,		7425/*"Max of Max Shear Stress"*/,	STAT_ADOC,		7425/*"Max of Max Shear Stress"*/,E_PASDECHAMP, 0},

  {MOD_NODE_MAX_CP,	E_CLASS_MOD,	0,		E_NO_COMPONENT,		E_NO_POINT, VRAI,
   -1,		7433/*"Max of Max Principal Stress (N)"*/,	STAT_ADOC,		7433/*"Max of Max Principal Stress (N)"*/,E_PASDECHAMP, 0},

  {MOD_NODE_CP,	E_CLASS_MOD,	0,		E_CP_COMPONENT,		E_NO_POINT, VRAI,
   -1,		7431/*"Max Principal Stress (N)"*/,	STAT_ADOC,		7431/*"Max Principal Stress (N)"*/,E_PASDECHAMP, 0},

  {MOD_USER1,		E_CLASS_MOD,	0,		E_NO_COMPONENT,		E_NO_POINT, FAUX,
   -1,			7191/*"Model User 1"*/,		INDISPONIBLE,		7191/*""*/,E_PASDECHAMP, 0},

  {MOD_USER2,		E_CLASS_MOD,	0,		E_NO_COMPONENT,		E_NO_POINT, FAUX,
   -1,			7192/*"Model User 2"*/,		INDISPONIBLE,		7192/*""*/,E_PASDECHAMP, 0},

  {MOD_USER3,		E_CLASS_MOD,	0,		E_NO_COMPONENT,		E_NO_POINT, FAUX,
   -1,			7193/*"Model User 3"*/,		INDISPONIBLE,		7193/*""*/,E_PASDECHAMP, 0},

  {GRP_ELEM_MAXSTRESS,	E_CLASS_GRP,	0,		E_STRAIN_COMPONENT,	E_NO_POINT, VRAI,
   ELEMENTS,		7178/*"Max Stress"*/,		STAT_ADOC,		7194/*"Max Stress on %s"*/,E_NOMDUGROUPE, 0},

  {GRP_ELEM_MAXSTRAIN,	E_CLASS_GRP,	0,		E_STRAIN_COMPONENT,	E_NO_POINT, VRAI,
   ELEMENTS,		7179/*"Max Strain"*/,		STAT_ADOC,		7195/*"Max Strain  on %s"*/,E_NOMDUGROUPE, 0},

  {GRP_ELEM_MAXFORCE,	E_CLASS_GRP,	0,		E_FORCE_COMPONENT,	E_NO_POINT, VRAI,
   ELEMENTS,		7178/*"Max Element Force"*/,	STAT_ADOC,	  	7194/*"Max Element Force on %s"*/,E_NOMDUGROUPE, 0},

  {GRP_ELEM_MAXSTRAIN,	E_CLASS_GRP,	0,		E_STRAIN_COMPONENT,	E_NO_POINT, VRAI,
   ELEMENTS,		7179/*"Max Strain"*/,		STAT_ADOC,		7195/*"Max Strain  on %s"*/,E_NOMDUGROUPE, 0},

  {GRP_ELEM_MAXMISES,	E_CLASS_GRP,	0,		E_NO_COMPONENT,		E_NO_POINT, VRAI,
   ELEMENTS,		7180/*"Max VonMises Stress"*/,	STAT_ADOC,		7196/*"Max VonMises  on %s"*/,E_NOMDUGROUPE, 0},

  {GRP_ELEM_MAXTRESCA,	E_CLASS_GRP,	0,		E_NO_COMPONENT,		E_NO_POINT, VRAI,
   ELEMENTS,		7181/*"Max Tresca"*/,		STAT_ADOC,		7197/*"Max Tresca  on %s"*/,E_NOMDUGROUPE, 0},

  {GRP_NODE_MAXDISP,	E_CLASS_GRP,	0,		E_DISP_COMPONENT,	E_NO_POINT, FAUX,
   NOEUDS,		7182/*"Max Displacement"*/,	STAT_ADOC,		7198/*"Max Disp. on %s"*/,E_NOMDUGROUPE, 0},

  {GRP_NODE_MAXSTRESS,	E_CLASS_GRP,	0,		E_STRAIN_COMPONENT,	E_NO_POINT, VRAI,
   NOEUDS,		7183/*"Max Stress (N)"*/,	STAT_ADOC,		7199/*"Max Stress (N) on %s"*/,E_NOMDUGROUPE, 0},

  {GRP_NODE_MAXSTRAIN,	E_CLASS_GRP,	0,		E_STRAIN_COMPONENT,	E_NO_POINT, VRAI,
   NOEUDS,		7184/*"Max Strain (N)"*/,	STAT_ADOC,		7200/*"Max Strain (N) on %s"*/,E_NOMDUGROUPE, 0},

  {GRP_NODE_MAXFORCE,	E_CLASS_GRP,	0,		E_FORCE_COMPONENT,	E_NO_POINT, VRAI,
   NOEUDS,		7184/*"Max Element Force (N)"*/,STAT_ADOC,		7200/*"Max Element Force (N) on %s"*/,E_NOMDUGROUPE, 0},

  {GRP_NODE_MAXMISES,	E_CLASS_GRP,	0,		E_NO_COMPONENT,		E_NO_POINT, VRAI,
   NOEUDS,		7201/*"Max VonMises Stress (N)"*/,STAT_ADOC,		7202/*"Max VonMises (N) on %s"*/,E_NOMDUGROUPE, 0},

  {GRP_NODE_MAXTRESCA,	E_CLASS_GRP,	0,		E_NO_COMPONENT,		E_NO_POINT, VRAI,
   NOEUDS,		7186/*"Max Tresca (N)"*/,	STAT_ADOC,		7203/*"Max Tresca (N) on %s"*/,E_NOMDUGROUPE, 0},

  {GRP_MASS,		E_CLASS_GRP,	0,		E_NO_COMPONENT,		E_NO_POINT, FAUX,
   ELEMENTS,		7162/*"Mass"*/,			STAT_ADOC,		7204/*"Mass of %s"*/,E_NOMDUGROUPE, 0},

  {GRP_SED,		E_CLASS_GRP,	0,		E_NO_COMPONENT,		E_NO_POINT, FAUX,
   ELEMENTS,		7166/*"Strain energy density"*/,INDISPONIBLE,		7205/*"Strain Energy Density on %s"*/,E_NOMDUGROUPE, 0},

  {GRP_ENER_STRAIN,	E_CLASS_GRP,	0,		E_NO_COMPONENT,		E_NO_POINT, FAUX,
   ELEMENTS,		7164/*"Strain energy"*/,	STAT_ADOC,		7206/*"Strain Energy on %s"*/,E_NOMDUGROUPE, 0},

  {GRP_ELEM_MAX_ENER_STRAIN,	E_CLASS_GRP,	0,	E_NO_COMPONENT,		E_NO_POINT, FAUX,
   ELEMENTS,		7188/*"Max strain energy"*/,	INDISPONIBLE,		7188/*"Max strain energy"*/,E_PASDECHAMP, 0},

  {GRP_ELEM_MAX_CP,	E_CLASS_GRP,	0,		E_NO_COMPONENT,		E_NO_POINT, VRAI,
   ELEMENTS,		7170/*"Max principal stress"*/,	STAT_ADOC,		7207/*"Max Principal Stress on %s"*/,E_NOMDUGROUPE, 0},

  {GRP_REACTION,	E_CLASS_GRP,	0,		E_REACTION_COMPONENT,	E_NO_POINT, FAUX,
   NOEUDS,		7189/*"Max Reaction"*/,		STAT_ADOC,		7208/*"Max Reaction on %s"*/,E_NOMDUGROUPE, 0},

  {GRP_SOM_REAC,	E_CLASS_GRP,	0,		E_REACTION_COMPONENT,	E_NO_POINT, FAUX,
   NOEUDS,		7190/*"Total Reaction"*/,	INDISPONIBLE,		7209/*"Total Reaction on %s"*/,E_NOMDUGROUPE, 0},

  {GRP_ELEM_MAX_EFFORT,	E_CLASS_GRP,	0,		E_FORCE_COMPONENT,	E_NO_POINT, FAUX,
   ELEMENTS,		7174/*"Max element force"*/,	STAT_ADOC,		7210/*"Max Element Force on %s"*/,E_NOMDUGROUPE, 0},

  {GRP_MODE_MAXDISP,	E_CLASS_GRP,	 0,		E_DISP_COMPONENT,		E_MODE, FAUX,
   NOEUDS,		7218/*"Mode"*/,			DYNA_BUCK_ADOC,		7266/*"Max Disp mode %d on %s"*/, E_NUMODE_GROUPE, 0},

  {GRP_MODEU_MAXDISP,	E_CLASS_GRP,	 0,		E_DISP_COMPONENT,		E_MODE, FAUX,
   NOEUDS,		7377/*"Mode"*/,			DYNA_BUCK_ADOC,		7382/*"Max Disp mode %d on %s"*/, E_NUMODE_GROUPE, 0},

  {GRP_MODAL_ENER,	E_CLASS_GRP,	 0,		E_NO_COMPONENT,		E_MODE, FAUX,
   ELEMENTS,		7222/*"Energy"*/,		DYNA_BUCK_ADOC,		7269/*"Energy mode %d on %s"*/, E_NUMODE_GROUPE, 0},

  {GRP_ELEM_MAX_DP,	E_CLASS_GRP,	0,		E_NO_COMPONENT,		E_NO_POINT, VRAI,
   ELEMENTS,		7411/*"Max principal strain"*/,	STAT_ADOC,		7412/*"Max Principal Strain on %s"*/,E_NOMDUGROUPE, 0},

  {GRP_NODE_MAX_MSSHEAR,	E_CLASS_GRP,	0,		E_NO_COMPONENT,		E_NO_POINT, VRAI,
   NOEUDS,		7427/*"Max of Max Stress Shear (N)"*/,STAT_ADOC,		7428/*"Max of Max Stress Shear (N) on %s"*/,E_NOMDUGROUPE, 0},

  {GRP_ELEM_MAX_MSSHEAR,	E_CLASS_GRP,	0,		E_NO_COMPONENT,		E_NO_POINT, VRAI,
   ELEMENTS,		7425/*"Max of Max Stress Shear "*/,	STAT_ADOC,		7429/*"Max of Max Stress Shear on %s"*/,E_NOMDUGROUPE, 0},

  {GRP_NODE_CP,	E_CLASS_GRP,	0,		E_CP_COMPONENT,		E_NO_POINT, VRAI,
   NOEUDS,		7433/*"Max of Max Principal Stress (N)"*/,	STAT_ADOC,		7434/*"Max of Max Principal Stress (N) on %s"*/,E_NOMDUGROUPE, 0},

  {GRP_NODE_MAX_CP,	E_CLASS_GRP,	0,		E_NO_COMPONENT,		E_NO_POINT, VRAI,
   NOEUDS,		7431/*"Max Principal Stress (N)"*/,	STAT_ADOC,		7432/*"Max Principal Stress (N) on %s"*/,E_NOMDUGROUPE, 0},

  {GRP_USER1,		E_CLASS_GRP,	0,		E_NO_COMPONENT,		E_NO_POINT, FAUX,
   -1,			7211/*"Group User 1"*/,		INDISPONIBLE,		7211/*""*/,E_PASDECHAMP, 0},

  {GRP_USER2,		E_CLASS_GRP,	0,		E_NO_COMPONENT,		E_NO_POINT, FAUX,
   -1,			7212/*"Group User 2"*/,		INDISPONIBLE,		7212/*""*/,E_PASDECHAMP, 0},

  {GRP_USER3,		E_CLASS_GRP,	 0,		E_NO_COMPONENT,   	E_NO_POINT, FAUX,
   -1,			7213/*"Group User 3"*/,		INDISPONIBLE,		7213/*""*/,E_PASDECHAMP, 0},

  /* 
   * criteres disponibles en contour seulement
   */
  {RES_DISP_NODES,	E_CLASS_GRP_CTR,	 0,		E_ALL_COMPONENTS,		E_NO_POINT, FAUX,
   -1,			7134/*"Displacement"*/,		STAT_ADOC_CONTOUR,	7134/*"Displacement"*/, E_PASDECHAMP, 0},

  {RES_DISP_NODES_C,	E_CLASS_GRP_CTR,	 0,		E_DISP_COMPONENT,		E_NO_POINT, FAUX,
   -1,			7134/*"Displacement"*/,		STAT_ADOC_CONTOUR,	7134/*"Displacement"*/, E_PASDECHAMP, 0},

  {RES_DEFORM_MODEL,	E_CLASS_GRP_CTR,	 0,		E_ALL_COMPONENTS,		E_NO_POINT, FAUX,
   -1,			7226/*"Deformed model"*/,	STAT_BDM_ADOC_CONTOUR,	7226/*"Deformed model"*/, E_PASDECHAMP, 0},

  {RES_STRAIN_POINTS,	E_CLASS_GRP_CTR,	 0,		E_ALL_COMPONENTS,		E_NO_POINT, FAUX,
   -1,			7227/*"Strain at elements"*/,	STAT_ADOC_CONTOUR,	7227/*"Strain at elements"*/, E_PASDECHAMP, 0},

  {RES_STRESS_POINTS,	E_CLASS_GRP_CTR,	 0,		E_ALL_COMPONENTS,		E_NO_POINT, FAUX,
   -1,			7228/*"Stress at elements"*/,	STAT_ADOC_CONTOUR,	7228/*"Stress at elements"*/, E_PASDECHAMP, 0},

  {RES_ENERGIE,		E_CLASS_GRP_CTR,	 0,		E_ALL_COMPONENTS,		E_NO_POINT, FAUX,
   -1,			7164/*"Strain energy"*/,	STAT_ADOC_CONTOUR,	7164/*"Strain energy"*/, E_PASDECHAMP, 0},

  {RES_EFFORT_INT,	E_CLASS_GRP_CTR,	 0,		E_ALL_COMPONENTS,		E_NO_POINT, FAUX,
   -1,			7229/*"Force at elements"*/,	STAT_ADOC_CONTOUR,	7229/*"Force at elements"*/, E_PASDECHAMP, 0},

  {RES_REACTION,	E_CLASS_GRP_CTR,	 0,		E_ALL_COMPONENTS,		E_NO_POINT, FAUX,
   -1,			7140/*"Reaction"*/,		STAT_ADOC_CONTOUR,	7140/*"Reaction"*/, E_PASDECHAMP, 0},

  {RES_REACTION_C,	E_CLASS_GRP_CTR,	 0,		E_REACTION_COMPONENT, 	E_NO_POINT, FAUX,
   -1,			7140/*"Reaction"*/,		STAT_ADOC_CONTOUR,   	7140/*"Reaction"*/, E_PASDECHAMP, 0},

  {RES_MESH_PERTURB,	E_CLASS_GRP_CTR,	 0,		E_ALL_COMPONENTS,		E_NO_POINT, FAUX,
   -1,			7230/*"Geometry"*/,		STAT_DYN_BDM_CONTOUR,	7230/*"Geometry"*/, E_PASDECHAMP, 0},

  {RES_SECTION_PERTURB,	E_CLASS_GRP_CTR,	 0,		E_ALL_COMPONENTS,		E_NO_POINT, FAUX,
   -1,			7231/*"Section geometry"*/,	INDISPONIBLE,		7231/*"Section geometry"*/, E_PASDECHAMP, 0},

  {RES_MODE,		E_CLASS_GRP_CTR,	 0,		E_ALL_COMPONENTS,		E_MODE, FAUX,
   -1,			7232/*"Modal shape"*/,		DYNA_BUCK_ADOC_CONTOUR,	7233/*"Mode Shape %d"*/,E_NUMERODUMODE, 0},

  {RES_MODE_C,		E_CLASS_GRP_CTR,	 0,		E_DISP_COMPONENT,		E_MODE, FAUX,
   -1,			7232/*"Modal shape"*/,		DYNA_BUCK_ADOC_CONTOUR,	7233/*"Mode Shape %d"*/,E_NUMERODUMODE, 0},

  {RES_MODEU,		E_CLASS_GRP_CTR,	 0,		E_ALL_COMPONENTS,		E_MODE, FAUX,
   -1,			7379/*"Modal shape"*/,		DYNA_BUCK_ADOC_CONTOUR,	7384/*"Mode Shape %d"*/,E_NUMERODUMODE, 0},

  {RES_DEFORME_MODALE,	E_CLASS_GRP_CTR,	 0,		E_ALL_COMPONENTS,		E_MODE, FAUX,
   -1,			7236/*"Modal deformed model"*/,	DYNA_BDM_ADOC_CONTOUR,	7237/*"Modal deformed model %d"*/,E_NUMERODUMODE, 0},

  {RES_ENERGIE_MODALE,	E_CLASS_GRP_CTR,	 0,		E_ALL_COMPONENTS,		E_MODE, FAUX,
   -1,			7240/*"Modal energy"*/,		DYNA_BUCK_ADOC_CONTOUR,	7241/*"Modal energy %d"*/,E_NUMERODUMODE, 0},

  {RES_STRESS_NODES,	E_CLASS_GRP_CTR,	 0,		E_ALL_COMPONENTS,		E_NO_POINT, FAUX,
   -1,			7421/*"Stress at nodes"*/,	STAT_ADOC_CONTOUR,	7421/*"Stress at nodes"*/, E_PASDECHAMP, 0},

  {RES_STRESS_NODES_C,	E_CLASS_GRP_CTR,	 0,		E_STRESS_EQ_COMPONENT,	E_NO_POINT, VRAI,
   -1,			7421/*"Stress at nodes"*/,	STAT_ADOC_CONTOUR,	7421/*"Stress at nodes"*/, E_PASDECHAMP, 0},

  {RES_STRAIN_NODES,	E_CLASS_GRP_CTR,	 0,		E_ALL_COMPONENTS,		E_NO_POINT, FAUX,
   -1,			7422/*"Strain at nodes"*/,	STAT_ADOC_CONTOUR,	7422/*"Strain at nodes"*/, E_PASDECHAMP, 0},

  {RES_STRAIN_NODES_C,	E_CLASS_GRP_CTR,	 0,		E_STRESS_EQ_COMPONENT,	E_NO_POINT, VRAI,
   -1,			7422/*"Strain at nodes"*/,	STAT_ADOC_CONTOUR,	7422/*"Strain at nodes"*/, E_PASDECHAMP, 0},

  {RES_FORCE_NODES,     E_CLASS_GRP_CTR,	 0,		E_ALL_COMPONENTS,		E_NO_POINT, FAUX,
   -1,			7438/*"Internal Forces at nodes"*/,INDISPONIBLE,	7438/*"Internal Forces at nodes"*/, E_PASDECHAMP, 0},
  
  {RES_FORCE_NODES_C,  	E_CLASS_GRP_CTR,	 0,		E_STRESS_EQ_COMPONENT, 	E_NO_POINT, FAUX,
   -1,			7438/*"Internal Forces at nodes"*/,INDISPONIBLE,	7438/*"Internal Forces at nodes"*/, E_PASDECHAMP, 0},

  {RES_MASSE,   	E_CLASS_GRP_CTR,	 0,		E_ALL_COMPONENTS,		E_NO_POINT, FAUX,
   -1,			7445/*"Mass at elements"*/,	 STAT_ADOC_CONTOUR,	7445/*"Mass at elements"*/, E_PASDECHAMP, 0}
}; 


static const int S_taille_tableau_resultat=TAILLE_TBL(S_tableau_resultat);




/* table des composantes */
static T_menu_comp S_tab_comp[] =
{
  { E_NO_COMPONENT,		COMP_SCALAR,		1,	7329 },
  { E_DISP_COMPONENT,		UX,			0,	7330 },
  { E_DISP_COMPONENT,		UY,			0,	7331 },
  { E_DISP_COMPONENT,		UZ,			0,	7332 },
  { E_DISP_COMPONENT,		RX,			0,	7333 },
  { E_DISP_COMPONENT,		RY,			0,	7334 },
  { E_DISP_COMPONENT,		RZ,			0,	7335 },
  { E_DISP_COMPONENT,		NORME_TRANSLATION,	1,	7336 },
  { E_DISP_COMPONENT,		NORME_ROTATION,		0,	7337 },
  { E_REACTION_COMPONENT,	UX,			0,	7333 },
  { E_REACTION_COMPONENT,	UY,			0,	7334 },
  { E_REACTION_COMPONENT,	UZ,			0,	7335 },
  { E_REACTION_COMPONENT,	RX,			0,	7338 },
  { E_REACTION_COMPONENT,	RY,			0,	7339 },
  { E_REACTION_COMPONENT,	RZ,			0,	7340 },
  { E_REACTION_COMPONENT,	NORME_TRANSLATION,	1,	7341 },
  { E_REACTION_COMPONENT,	NORME_ROTATION,		0,	7342 },
  { E_FORCE_COMPONENT,		UX,			0,	7343 },
  { E_FORCE_COMPONENT,		UY,			0,	7344 },
  { E_FORCE_COMPONENT,		UZ,			0,	7345 },
  { E_FORCE_COMPONENT,		RX,			0,	7346 },
  { E_FORCE_COMPONENT,		RY,			0,	7347 },
  { E_FORCE_COMPONENT,		RZ,			0,	7348 },
  { E_FORCE_COMPONENT,		NORME_TRANSLATION,	1,	7341 },
  { E_FORCE_COMPONENT,		NORME_ROTATION,		0,	7342 },
  { E_CP_COMPONENT,		UX,			1,	7349 },
  { E_CP_COMPONENT,		UY,			0,	7350 },
  { E_CP_COMPONENT,		UZ,			0,	7351 },
  { E_STRAIN_COMPONENT,		UX,			1,	7352 },
  { E_STRAIN_COMPONENT,		UY,			0,	7353 },
  { E_STRAIN_COMPONENT,		UZ,			0,	7354 },
  { E_STRAIN_COMPONENT,		RX,			0,	7355 },
  { E_STRAIN_COMPONENT,		RZ,			0,	7356 },
  { E_STRAIN_COMPONENT,		RY,			0,	7357 },
  { E_STRESS_EQ_COMPONENT,	UX,			0,	7352 },
  { E_STRESS_EQ_COMPONENT,	UY,			0,	7353 },
  { E_STRESS_EQ_COMPONENT,	UZ,			0,	7354 },
  { E_STRESS_EQ_COMPONENT,	RX,			0,	7355 },
  { E_STRESS_EQ_COMPONENT,	RZ,			0,	7356 },
  { E_STRESS_EQ_COMPONENT,	RY,			0,	7357 },
  { E_STRESS_EQ_COMPONENT,	EQ_CP_UX,		0,	7349 },
  { E_STRESS_EQ_COMPONENT,	EQ_CP_UY,		0,	7350 },
  { E_STRESS_EQ_COMPONENT,	EQ_CP_UZ,		0,	7351 },
  { E_STRESS_EQ_COMPONENT,	EQ_VONMISES,		1,	7136 },
  { E_STRESS_EQ_COMPONENT,	EQ_TRESCA,		0,	7138 },
  { E_STRESS_EQ_COMPONENT,	EQ_MSSHEAR,		0,	7423 },
  { E_ALL_COMPONENTS,		COMP_SCALAR,		1,	7391 },
  { E_TG_COMPONENT,		UX,			0,	7473 },
  { E_TG_COMPONENT,		UY,			0,	7474 },
  { E_TG_COMPONENT,		UZ,			0,	7475 },
  { E_TG_COMPONENT,		NORME_TRANSLATION,	1,	7476 },
  { E_TF_COMPONENT,		UX,			0,	7473 },
  { E_TF_COMPONENT,		UY,			0,	7474 },
  { E_TF_COMPONENT,		UZ,			0,	7475 },
  { E_TF_COMPONENT,		NORME_TRANSLATION,	1,	7476 },
};
static int S_taille_tab_comp=TAILLE_TBL(S_tab_comp);

static T_menu_comp S_tab_peau[] =
{
  /* non utilise           	code choix_peau		default          nom */
  { E_NO_COMPONENT,		LAYER_NONE,		0,              7359}, /* None */
  { E_NO_COMPONENT,		LAYER_MAX, 		0,              7360}, /* Max */
  { E_NO_COMPONENT,		LAYER_TOP,		0,              7361}, /* Top */
  { E_NO_COMPONENT,		LAYER_MIDDLE,		0,              7362}, /* Middle */
  { E_NO_COMPONENT,		LAYER_BOTTOM,		0,              7363}  /* Bottom */
};
static const int S_taille_tab_peau=TAILLE_TBL(S_tab_peau);

static T_menu_comp S_tab_zcomp[] = 
{ 
  /* non utilise		code choix_zcomp	defaut		libelle */
  { E_NO_COMPONENT,		COMPO_RE,		0,		7364}, 
  { E_NO_COMPONENT,		COMPO_IM,		0, 		7365}, 
  { E_NO_COMPONENT,		COMPO_MO,		0, 		7366},
  { E_NO_COMPONENT,		COMPO_PH,		0, 		7367}
}; 
static const int S_taille_tab_zcomp = TAILLE_TBL(S_tab_zcomp);

#endif /* INCLUDED_FROM_TAB_CRIT_C */

#endif
