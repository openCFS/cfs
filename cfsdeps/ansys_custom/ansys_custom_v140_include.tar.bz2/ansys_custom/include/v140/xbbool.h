
/*
 *    author/date: yu-hua ting/02-24-94
 *
 *    primary function:
 *
 *      Header for the Interface to SHAPES "Boolean" routines
 *
 *    secondary function:
 *
 *        none
 *
 *    routines included:
 *
 *
 *    history
 *
 *        none
 *
 *    comments:
 *
 *        none
 *
 *    Notice - This file contains ANSYS Confidential information ***
 *
 */
/* 
 * *** copyright(c) 2011 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */


/*****************************************************************************
 *                                                                           *
 *    Boolean operations in SHAPES                                           *
 *                                                                           *
 *****************************************************************************/

/*
 *    Find the intersection of 2 geoms
 */
      extern xGEOM_ID xGmIntersect_xax ansPROTO((
             xGEOM_ID gm_id1,     /* I    geom number of the 1st geom               */ 
             xGEOM_ID gm_id2,     /* I    geom number of the 2nd geom               */
             xINT simplifymode,   /* I    simplification code which specifies how
                                          much merging is desired on the output
                                          results.
                                          == 0 - no simplification done.
                                          == xcGM_SIMPLIFY_SPACE - remove any
                                             removable boundaries between cells
                                             defining regions in modeling space
                                             (i.e. solids).                         
                                          == xcGM_SIMPLIFY_EQ_MAP - remove any
                                             removable boundaries between cells
                                             that are defined on the same map       
                                          == xcGM_SIMPLIFY_ALL    - perform the
                                             above 2 and additional tries to merge
                                             cells that are defined on maps that
                                             cover the same point set even though
                                             they are parametrically not the same.
                                             For example, differently parametrized
                                             but overlapping planes are merged      */
             INT iopt[2],         /* I    option
                                   *      == DESTROY_INPUT_GEOMS or
                                          == DO_NOT_DESTROY_INPUT_GEOMS              */
             xTAG tag,            /* I    heap tag                                  */
             INT *iretp));        /*   O  error code   
                                   *      == 0 - no error
                                   *      == GEOMETRY_IS_EMPTY
                                   *      otherwise - error                          */


/*
 *    Find the union of 2 geoms
 */
      extern xGEOM_ID xGmUnion_xax ansPROTO((
             xGEOM_ID gm_id1,     /* I    geom number of the 1st geom               */ 
             xGEOM_ID gm_id2,     /* I    geom number of the 2nd geom               */
             xINT simplifymode,   /* I    simplification code which specifies how
                                          much merging is desired on the output
                                          results.
                                          == 0 - no simplification done.
                                          == xcGM_SIMPLIFY_SPACE - remove any
                                             removable boundaries between cells
                                             defining regions in modeling space
                                             (i.e. solids).                         
                                          == xcGM_SIMPLIFY_EQ_MAP - remove any
                                             removable boundaries between cells
                                             that are defined on the same map       
                                          == xcGM_SIMPLIFY_ALL    - perform the
                                             above 2 and additional tries to merge
                                             cells that are defined on maps that
                                             cover the same point set even though
                                             they are parametrically not the same.
                                             For example, differently parametrized
                                             but overlapping planes are merged      */
             INT iopt[2],         /* I    option
                                   *      == DESTROY_INPUT_GEOMS or
                                          == DO_NOT_DESTROY_INPUT_GEOMS              */
             xTAG tag,            /* I    heap tag                                  */
             INT *iretp));        /*   O  error code   
                                   *      == 0 - no error
                                   *      == GEOMETRY_IS_EMPTY
                                   *      otherwise - error                          */

/*
 *    Find the merge of 2 geoms
 */
      extern xGEOM_ID xGmUnionMerge_xax ansPROTO((
             xGEOM_ID gm_id1,     /* I    geom number of the 1st geom               */ 
             xGEOM_ID gm_id2,     /* I    geom number of the 2nd geom               */
             xINT *flag,          /*   O  flag
                                   *      == 0 - SHAPES_VALID_MERGE
                                   *      == 1 - SHAPES_INTERSECTION_IS_EMPTY
                                   *      == 2 - SHAPES_VALID_OVERLAP
                                   *      == 3 - valid output
                                   *      >  3 - error                               */
             INT iopt[2],         /* I    option
                                   *      == DESTROY_INPUT_GEOMS or
                                          == DO_NOT_DESTROY_INPUT_GEOMS              */
             xTAG tag,            /* I    heap tag                                  */
             INT *iretp));        /*   O  error code   
                                   *      == 0 - no error
                                   *      == GEOMETRY_IS_EMPTY
                                   *      otherwise - error                          */


/*
 *    Find the overlap of 2 gm_ids
 *   (the resulting gm_id of this is the same as the resulting gm_id of "union"
 *    except the shared faces will not be removed in 3-D case)
 */
      extern xGEOM_ID xGmOverlap_xax ansPROTO((
             INT gm_id1,          /* I    gm_id number of the 1st gm_id                */
             INT gm_id2,          /* I    gm_id number of the 2nd gm_id                */
             INT *flag,           /*   O  flag                          
                                   *      == 1 - SHAPES_INTERSECTION_IS_EMPTY
                                   *      == 2 - SHAPES_VALID_OVERLAP
                                   *      == 3 - valid output
                                   *      >  3 - error                               */
             INT iopt[2],         /* I    option
                                   *      == DESTROY_INPUT_GEOMS or
                                          == DO_NOT_DESTROY_INPUT_GEOMS              */
             xTAG tag,            /* I    heap tag                                  */
             INT *iretp));        /*   O  error code  
                                   *      == 0 - no error 
                                   *      != 0 - error                               */

/*
 *    geometrically classify 
 */
      extern xINT_LIST xGmClassify_xax ansPROTO((
             xGEOM_ID gm_id1,     /* I    geom number of the 1st geom               */ 
             xGEOM_ID gm_id2,     /* I    geom number of the 2nd geom               */
             xINT code1,          /* I    code for requested results on gm_id1.
                                          It can be the bitwise OR of xcGM_CLSFY_IN,
                                          xcGM_CLSFY_ON, and xcGM_CLSFY_OUT values.
                                          The 3 values control the computation of 
                                          the part of gm_id1 in gm_id2, inside of 
                                          gm_id2, on the boundary of gm_id2, and 
                                          outside of gm_id2                         */
             xINT code2,          /* I    code for requested results on gm_id2.
                                          It can be the bitwise OR of xcGM_CLSFY_IN, 
                                          xcGM_CLSFY_ON, and xcGM_CLSFY_OUT values.
                                          The 3 values control the computation of 
                                          the part of gm_id2 in gm_id1, inside of  
                                          gm_id1, on the boundary of gm_id1, and 
                                          outside of gm_id1                         */
             xINT simplifymode,   /* I    simplification code which specifies how
                                          much merging is desired on the output
                                          results.
                                                 == 0 - no simplification done.
                                          == xcGM_SIMPLIFY_SPACE - remove any
                                             removable boundaries between cells
                                             defining regions in modeling space
                                             (i.e. solids).                         
                                          == xcGM_SIMPLIFY_EQ_MAP - remove any
                                             removable boundaries between cells
                                             that are defined on the same map       
                                          == xcGM_SIMPLIFY_ALL    - perform the
                                             above 2 and additional tries to merge
                                             cells that are defined on maps that
                                             cover the same point set even though
                                             they are parametrically not the same.
                                             For example, differently parametrized
                                             but overlapping planes are merged      */
             INT iopt[2],         /* I    option
                                   *      == DESTROY_INPUT_GEOMS or
                                          == DO_NOT_DESTROY_INPUT_GEOMS              */
             xTAG tag,            /* I    heap tag                                  */
             INT *iretp));        /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                               */
