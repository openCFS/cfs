/* CADOE */
/**
 *	extnbb.h -- Fonctions d'interface nbb /va
 *  
 * |Version: $Id: sx_extnbb.h,v 1.3 2009/11/13 16:13:03 jtm Exp $
 *
 *   
 * HISTORY
 *   
 *   09/25/00 10:39 <       Brian Jantzen> Rel:ms8m1    SCCA:79107  Delta:81.2
 *   
 *   02/28/00 07:49 <       Brian Jantzen> Rel:ms8      SCCA:69955  Delta:8.4
 *   
 *   01/31/00 15:39 <       Brian Jantzen> Rel:ms8      SCCA:67206  Delta:8.3
 *   
 *   01/05/00 14:54 <        Marc Gadbois> Rel:ms8      SCCA:64687  Delta:8.2
 *   
 **/


#ifndef __EXTNBB_X_DEJA_INCLUS__
#define __EXTNBB_X_DEJA_INCLUS__ 1


#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */


#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif	 /* __EXTNBB_X_DEJA_INCLUS__ */
