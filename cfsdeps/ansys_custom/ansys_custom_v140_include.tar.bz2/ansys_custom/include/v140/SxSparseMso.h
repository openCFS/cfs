/**
 * @file   SxSparseMso.h
 * @author 
 * @date   Thu Jan 13 11:10:17 2005
 * 
 * @brief  
 * 
 * 
 */

#ifndef __SXSPARSEMSO_H__
#define __SXSPARSEMSO_H__ 1

#include "cadoe_map.h"
#include "SxSparse.h"
#include "SxSparseLso.h"

#include "ansMPIComm.h"

#ifndef __cplusplus
#error "SxSparseMso.h must only be included by C++ files"
#endif

#include "C_MatSp.h"

class FSConnectivity;

/*!
 * \class	T_mso
 *  \brief	This object define a Sparse Matrix.
 *		
 *  \author	JDB-FT
 *  \version	1.0
 *  \date	2003-2005
 *  \bug	
 *  \warning	
 *
 *  \version 1.0 :       Initial Revision
 *
 *  \remark :	
 */

class T_mso : public C_OocMatrix 
{
public:

  virtual     char *AffType() const { return (char *)"T_mso Type";}

  // ===== Constructors, Destructor
  
  //@{
  T_mso( int nb_fic, int nb_ddls, int numero, char *basename,
	 char **dirs, int *ier);
  virtual ~T_mso( void);
  //@}

  double    Norme( void);
  double    NormDist( int GlbNbcs = 0,int *locBcsToGlbBcs = NULL, bool maplocGlb = false);

  void      PrintNorme( C_CadoeMessage &Msg, char *title);
  void      PrintNormDist( C_CadoeMessage &Msg, char *title,int GlbNbcs,int *locBcsToGlbBcs, bool maplocGlb);
  
  // ===== Methods to access to Matrix Data
  double	GetVal( int iRow, int jCol);

  //@{
  virtual bool	IsCompact( void) { return (hash != NULL);}
  virtual int	Print( FILE *fout=stdout, int line=-1);
  virtual int	Print( char *nameFile, int ilig=-1, bool append=false) { return SUCCES;}
  int		WriteMatlab( FILE *);
  //@}

  int		BuildCompactRowTable( void);

  int		ExportAsFullMatrix( C_MatMGe<double> &FullMatrix); 

  void		FilterValues( double treshold = 1.E-16);

  // Methods to manage internal buffers

  //@{
  int		AllocateBuffers( int NbProcs=0);
  int		ConnectToCurrentBuffer( T_lso_buffer *buffer, int iproc = 0);
  void		DisconnectCurrentBuffer( int iproc);
  int		WriteBuffer( T_lso_buffer *buffer);

  int		GetBufferForANewLine( T_lso *line, T_booleen alloc);

  int		Overwrite( void);
  //@}

  // Methods to manage lines

  //@{
  int		ReadLine( T_lso *line);
  int		WriteLine( T_lso *line);
  int		UpdateLine( T_lso *line, bool free);

  inline void	AddRowIdx( int &iRow, C_Set<BCSINT> &Idx)
  {
    register int	ii, *Ind;
    BCSINT		nzL; 

    T_lso *lig = this->GetRow( iRow, &ii);
    if ( (nzL = lig->length) > 0)
      {
	if (!lig->buffer->charge) this->ReadLine( lig);
	for( ii=0, Ind=lig->indices; ii<nzL; ii++, Ind++) Idx.insert(*Ind + 1);
      }
    if( !this->InCore()) lig->Flush( 0, FAUX);
  }

  template <typename T2> T2	GetRowIdxT( int &iRow, T2 *JRow)
    {
      register	int ii;
    
      if ( !this->InCore() && _curline && _curline->irow != iRow) _curline->Flush( 0, FAUX);

      _curline = this->GetRow( iRow, &ii);
      T2	 nzL = _curline->length;
    
      if ( nzL > 0) {
	if (!_curline->buffer->charge) this->ReadLine( _curline);
      
	register int *Ind = _curline->indices;
	for( ii=0; ii<nzL; ii++) { JRow[ii] = *Ind++ + 1;}
      }
    
      return nzL;
    }

  virtual int	GetRowIdx( int &iRow, int *iCol) { return GetRowIdxT( iRow, iCol);}
  virtual Hyper	GetRowIdx( int &iRow, Hyper *iCol) { return GetRowIdxT( iRow, iCol);}

  inline double *GetRowValues( int &iRow) { return _curline->valeurs;}
  //@}


  // Methods to perform Matrix-Vectors or Matrix-Dense-Matrix operations

  template <typename T> int T_MM_Mlt( int nbv, T *vin, T_booleen add, T *vout,T coef = (T)1,bool trans=false);
  template <typename T> void TMM_Mlt_Pll( INT *nbv_in, T *vin, T *vout,T coef, bool trans=false);
  template <typename T> void TMv_Mlt_Pll( T *vin, T *vout,  T coef, bool trans=false);

  template <typename T> int
  Mv( T alpha, C_Vec<T> &x, T beta, C_Vec<T> &y, char trans = 'N')
  {
    if ( beta != (T)0 && beta != (T)1) return ECHEC;

    T_booleen	add = (beta == 1);
    bool	btrans(trans != 'N');

    return T_MM_Mlt<T>( 1, x.Adr(), add, y.Adr(), alpha, btrans);
  }

  virtual int	Mv( double alpha, C_Vec<double> &x, double beta, C_Vec<double> &y, char trans = 'N')
  { return T_mso::Mv<double>( alpha, x, beta, y, trans);}

  virtual int	MM( char TransA, char TransB, double alpha, C_Mat<double> &A,
		    C_Mat<double> &B,  double beta){ CADOE_THROW(E_MethodNotDefined);}

  
  int		QtAQ( int nbv, double *vin, double *temp, C_MatMSym<double> &QtAQ);
  void		QtAQ_Pll( int nbv, double *vin, double *temp, int *ier);

  void		operator*=( double coef);
  void		Axpy( T_mso &Mat, double coef = 1);
  template <typename T> void toMatSp(C_MatSp<T> &);
  
  int			_NbThreads;///< Number of threads ( = number of current buffers)
  vector<T_lso_buffer *> currents; ///< Current active buffers ( one for each proc)
  T_lso			*_curline;	///< Current Line we use (handle with Care !!!)
};

#if defined(LOWERCASENOUNDER_SYS)

#endif
#if defined(UPPERCASENOUNDER_SYS)
#define msoaddline 	MSOADDLINE
#define msoaddlinebcs	MSOADDLINEBCS
#define msoend          MSOEND
#endif
#if defined(LOWERCASEUNDER_SYS)
#define msoaddline 	msoaddline_
#define msoaddlinebcs	msoaddlinebcs_
#define msoend          msoend_
#endif

template <typename T> inline void MyScal( unsigned int n, T &a, T *x, int& incx)
{
  if ( incx == 1) for( int ii=0; ii<n; ii++) x[ii] *= a;
  else
    exit(0);

  return;
}

inline void MyScal( unsigned int n, complex16_t &a, complex16_t *x, int& incx)
{
  if (incx != 1) exit(0);

  if (a.imag() == 0.)
    {
      register double *xr = (double *)x; n*=2;
      register double ar = a.real();
      while (n>0) { *xr *= ar; xr++; n--;}
    }
  else
    for( int ii=0; ii<n; ii++) x[ii] *= a;

  return;
}

template <typename T> inline T_statut 
T_MSO_prod_ax_d( T_mso *mat, T *vin, T_booleen add, T *vout, T coef=1, bool trans=false)
{
  char		fctn[] = "MSO_prod_ax_d";			CADOE_TRACE(fctn);
  T_statut	ier;
  register int	i_one(1);
  int nz_diag;

  if( mat->IsCompact() != true) 
    { ier = mat->BuildCompactRowTable();				CHKIERS;}
  
  if (!add) __gzero__( vout, mat->nb_ddl);
  
  if ( mat->length == 0)
    return SUCCES;

  if (!mat->unsym) trans = false;	// ===== If Mat is Sym, trans has no effect
  
  ier = mat->AllocateBuffers(1);					CHKIERS;

  C_VecPi<T>	Vtmp( mat->_MaxLength+1);
  T		*VAdr = Vtmp.Adr();
  
  for( int irow=0; irow<mat->nnz_rows; irow++)
    {
      T_lso *lig = mat->rows[irow];
      
      if (!lig->buffer->charge) { ier = mat->ReadLine( lig);		CHKIERS;}
      int len = lig->length;
      
      if (trans)	// ===== and implictly mat->unsym == true.
	{
	  Vtmp.Zero();
	  
	  axpy( len, vin[lig->irow], lig->valeurs, i_one, Vtmp.Adr(), i_one);
	  if ( coef != 1) Vtmp *= coef;
	  lig->IndFillGlobalVectors2( Vtmp.Adr(), vout);
	}
      else
	{
	  if ( mat->unsym)
	    {
	      lig->IndExtractLocalVector( vin, VAdr);
	      if ( coef != 1) MyScal( lig->length, coef, VAdr, i_one);	  
	      lig->MvMltUns( VAdr, vout);
	    }
	  else
	    {
	      lig->IndExtractLocalVectorSym( vin, VAdr);
	      nz_diag = (irow == lig->indices[0]);
	      if ( coef != 1) MyScal( lig->length+(1-nz_diag), coef, VAdr, i_one);
	      lig->MvMlt( VAdr, vout); 
	    }
	}

      if( !mat->in_core ) lig->Flush( 0, FAUX );
    }

  return SUCCES;
}

template <typename T> inline T_statut 
T_MSO_prod_axm_d( T_mso *mat, int nbv, T *vin, T_booleen add, T *vout, T coef=1,
		  bool trans=false)
{
  char		fctn[] = "MSO_prod_axm_d";	CADOE_TRACE_X( fctn, cwTrackBegin, cwTrackEnd);
  T_statut	ier;
  register int	one(1);

  if ( nbv == 1)
    return T_MSO_prod_ax_d( mat, vin, add, vout, coef, trans);

  if( mat->IsCompact() != true) 
    {ier = mat->BuildCompactRowTable();					CHKIERS;}
  
  if (!mat->unsym) trans=false;

  int taille_vec = mat->nb_ddl;
  int taille_tot = taille_vec * nbv; 

  if (!add) __gzero__( vout, taille_tot);
  
  if ( mat->length == 0) return SUCCES;

  ier = mat->AllocateBuffers(1);					CHKIERS;

  C_VecPi<T> Vtmp1( nbv*(mat->_MaxLength+1)), Vtmp2( nbv*(mat->_MaxLength+1));
  
  T_lso	**ligc = mat->rows;
  T *coef0, *adr;

  for( int irow=0; irow<mat->nnz_rows; irow++, ligc++)
    {
      T_lso *lig = *ligc;
      if (!lig->buffer->charge) { ier = mat->ReadLine( lig);		CHKIERS;}

      int len = lig->length;
      
      if ( trans)
	{
	  Vtmp1.Zero();
	  coef0 = vin + lig->irow;
	  adr = Vtmp1.Adr();
	  for( int iv=0; iv<nbv; iv++,coef0+=taille_vec,adr+=len)
	    axpy(len,*coef0,lig->valeurs,one,adr,one);

	  // if ( coef != 1) Vtmp1 *= coef;
	  if ( coef != 1) MyScal( nbv*len, coef, Vtmp1.Adr(), one);

	  lig->IndFillGlobalVectors2( Vtmp1.Adr(), nbv,taille_vec, vout);
	}
      else
	{
	  if ( mat->unsym)
	    {
	      lig->IndExtractLocalVector( nbv, taille_vec, vin, Vtmp1.Adr());
	      if ( coef != 1) MyScal( nbv*len, coef, Vtmp1.Adr(), one);	  
	      lig->MmMltUns( nbv, Vtmp1.Adr(), Vtmp2.Adr());
	      lig->IndFillGlobalVectorsUns( Vtmp2.Adr(), nbv, taille_vec, vout);
	    }
	  else
	    {
	      /*
	      Vtmp2.Zero();
	      lig->IndExtractLocalVectorSym( nbv, taille_vec,coef, vin, Vtmp1.Adr());
	      lig->MmMlt( nbv, Vtmp1.Adr(), Vtmp2.Adr());
	      lig->IndFillGlobalVectors( Vtmp2.Adr(), nbv, taille_vec, vout);
	      */
	      for( int iv=0; iv<nbv; iv++)
		{
		  lig->IndExtractLocalVectorSym( vin+iv*taille_vec, Vtmp1.Adr());
		  int nz_diag = (irow == lig->indices[0]);
		  if ( coef != 1) MyScal( lig->length + (1-nz_diag), coef, Vtmp1.Adr(), one);
		  lig->MvMlt( Vtmp1.Adr(), vout + iv*taille_vec); 
		}
	    }
	}
      
      if( !mat->in_core ) lig->Flush( 0, FAUX );
    }

  return SUCCES;
}

extern "C" {

void		MSO_free(void);

T_mso	*MSO_create_from_moc( T_m_ooc *moc, T_booleen del, int order, T_statut *ier );

T_mso   *moc2mso( T_m_ooc *moc, int order, char *basename,char **dirs, T_statut *ier);

SUBROUTINE msoaddline( INT *numat, INT *line, INT *len, INT *ddls, DOUBLE *valeurs, INT *cl,
		       INT *diag, DOUBLE *vdiag, INT *iret);
SUBROUTINE msoaddlinebcs( INT *numat, INT *line, INT *len, INT *ddls, DOUBLE *valeurs, INT *diag,
			  DOUBLE *vdiag, INT *FULLtoBCS, INT *iret);
SUBROUTINE msoend( INT *numat, INT *ier);
  
T_mso *MSO_extraire_sous_matrice( int nb_fic, char *basename, char **dirs, T_mso *min, T_mso *madr, 
				  T_booleen scale, double factor, T_mso *mout, T_statut *ier);
T_mso* MSO_combine_simple( int nb_fic, char *basename, char **dirs, double a1, T_mso *m1,
			   double a2, T_mso *m2, int overwrite, T_statut *ier  );
T_mso* MSO_difference( int nb_fic, char *basename, char **dirs, T_mso *m1, T_mso *m2, 
		       double seuil, int overwrite, T_statut *ier  );
T_mso* MSO_combine( int nb_fic, char *basename, char **dirs, double a1, T_mso *m1, 
		    double a2, T_mso *m2, double seuil, int overwrite, int creer_are,
		    T_statut *ier  );
T_statut MSO_line_axpy( T_mso* mat, int line, int len, int *ddls, double coef, 
			double *valeurs, T_booleen diag, double vdiag  );

T_statut MSO_dxtax( T_mso *mat, int nbv, double *vin, double *temp, 
		    double *vtav, bool Lower=true);
T_statut MSO_prod_axm_d( T_mso *mat, int nbv, int type, void *vin, T_booleen add, void *vout );
T_statut MSO_prod_axm_d_trans( T_mso *mat, int nbv, int type, void *vin, T_booleen add, void *vout );
T_statut MSO_prod_axm_parallel( T_mso *mat, int nbv, int type, void *vin, T_booleen add, void *vout );

T_statut MSO_prod_ax_d( T_mso *mat, int type, void *vin, T_booleen add, void *vout);
T_statut MSO_prod_ax_d_trans( T_mso *mat, int type, void *vin, T_booleen add, void *vout);

T_statut MSO_prod_mm_support( T_mso *matparam, T_mso *matK0, BVEC *DdlActive, int nbv, double *vin, double *vout);
T_statut MSO_prod_mv_support( T_mso *matparam, T_mso *matK0, BVEC *DdlActive, double *vin, double *vout);
T_statut MSO_prod_mv_support_part( T_mso *matparam, BVEC *bDdlActive, IVEC *iDdlActive, double *vin, double *vout);
T_statut MSO_prod_mv_support_multi( T_mso **matparam, T_mso *matK0, int nbmat, BVEC *DdlActive, double *vin, double *vout);

SUBROUTINE MSO_prod_axm_pll( void *mat_in, INT *nbv_in, INT *type_in, void *vin, void *vout, INT *ier );

void	FX_BuildLisKMF( PAR *par, VEC *vparam, IVEC *FULLtoBCSdof, int nbcs, 
			VEC *TabEps, int oK, int oM, int oB, T_mso **KDer, 
			T_mso **MDer, VSTRUCT **BDer, int *ier);

int   cadoeFillMatrix();
int   sx_FullToCadoeMat(INT line, INT len, INT *ddls, DOUBLE *valeurs, DOUBLE diag);
int   sx_FullToCadoeRhs(INT len, DOUBLE *valeurs);
}	// extern "C"

T_statut MSO_prod_ax_d_support( T_mso *mat, C_VecPi<int> &, IVEC *NumDofBcs, T_booleen
				QNodal, C_VSTRUCT<double> &QN, C_MatMGe<double> &KQ);

void    cadoe_set_matrix(T_mso *mat, double *rhs, C_VecPi<int> &);

T_mso   *MOC_derive_sinus2( T_m_ooc *coef, char *name, double angle, double dangle, int ordre, T_statut *ier );

T_lso *LSO_read( T_mso*, int, T_lso*, T_statut* );

void	MatSpToMso( C_MatSp<double> &MatSp, T_mso &Mat, T_booleen scale = false, double coef = 1.);

void	MSODispatch(T_mso *, FSConnectivity *, C_MatMGe<int> &, T_mso *);

#endif // __SXSPARSEMSO_H__
