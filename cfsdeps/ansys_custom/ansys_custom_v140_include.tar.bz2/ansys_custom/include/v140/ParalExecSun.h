#ifndef _FS_PARAL_EXEC_H_
#define _FS_PARAL_EXEC_H_

/*****************************************************************************
 *                   Copyright (C) 1999 CMSoft                               *
 *                                                                           *
 *  These lines of code and declarations contain unpublished proprietary     *
 *  information of CMSoft. They may not be copied or duplicated in whole     *
 *  or part without prior authorization from CMSoft.                         *
 *                                                                           *
 *****************************************************************************/

// Here is a weird bug of Visual C++
#ifndef PCWINNT_SYS

template <class DT, class A>
void paralExec(DT n, A *, void(A::*fct)(int));

template <class DT, class A, class Arg1, class PArg1>
void paralExec(DT n, A *a, void(A::*fct)(int, Arg1), PArg1 arg1);

template <class DT, class A,
          class Arg1,  class Arg2,
          class PArg1, class PArg2>
void paralExec(DT n, A *, void(A::*fct)(int, Arg1, Arg2),  PArg1, PArg2);

template <class DT, class A,
          class Arg1,  class Arg2,  class Arg3,
          class PArg1, class PArg2, class PArg3>
void paralExec(DT n, A *a, void(A::*fct)(int, Arg1, Arg2, Arg3),
                PArg1 arg1, PArg2 arg2, PArg3 arg3);

template <class DT, class A>
void paralApply(DT n, A **a, void(A::*fct)());

template <class DT, class A, class Arg1, class PArg1>
void paralApply(DT n, A **a, void(A::*fct)(Arg1), PArg1 arg1);

template <class DT, class A, 
          class Arg1,  class Arg2, 
          class PArg1, class PArg2>
void paralApply(DT n, A **a, void(A::*fct)(Arg1, Arg2),PArg1 arg1,PArg2 arg2);

template <class DT, class A, 
          class Arg1,  class Arg2,  class Arg3, 
          class PArg1, class PArg2, class PArg3>
void paralApply(DT n, A **a, void(A::*fct)(Arg1, Arg2, Arg3), 
                PArg1 arg1, PArg2 arg2, PArg3 arg3);

template <class DT, class A, 
          class Arg1,  class Arg2,  class Arg3,  class Arg4,
          class PArg1, class PArg2, class PArg3, class PArg4>
void paralApply(DT n, A **a, void(A::*fct)(Arg1,  Arg2,  Arg3, Arg4),
                     PArg1 arg1, PArg2 arg2, PArg3 arg3, PArg4 arg4);

template <class DT, class A,
          class Arg1, class Arg2,  class Arg3,  class Arg4,  class Arg5, 
          class PArg1,class PArg2, class PArg3, class PArg4, class PArg5>
void paralApply(DT n, A **a, void(A::*fct)(Arg1, Arg2, Arg3, Arg4, Arg5),
                PArg1 arg1, PArg2 arg2, PArg3 arg3, PArg4 arg4, PArg5 arg5);

template <class DT, class A,
          class Arg1, class Arg2, class Arg3, class Arg4, class Arg5, class Arg6,
          class PArg1,class PArg2,class PArg3,class PArg4,class PArg5,class PArg6>
void paralApply(DT n, A **a, void(A::*fct)(Arg1,Arg2,Arg3,Arg4,Arg5,Arg6),
             PArg1 arg1, PArg2 arg2, PArg3 arg3, PArg4 arg4, PArg5 arg5,PArg6 arg6);


template <class DT, class R, class A,
          class Arg1, class Arg2,
          class PArg1,class PArg2>
R paralSum(DT n, R initVal, A **a, R (A::*fct)(Arg1,Arg2), 
                 PArg1 arg1, PArg2);
#endif

#ifdef _TEMPLATE_FIX_
#include <Threads.d/ParalExec.cpp>
#endif

#endif
