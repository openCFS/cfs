/*******************************************************************************
 *
 *   SxUpdateRange.h  --- Update parameters status in the SX COMMAND database
 * 
 * |Module:  
 *
 * |Description: 
 *
 * |Includes:	
 *        
 * |Auteur: Stephane MARGUERIN
 *
 * |Creation: Juillet 2002
 *
 * |Version: $Id: SxUpdateRange.h 145002 2009-11-13 16:20:27Z jtm $
 *
 * |Copyright:	Copyright(c)  2002
 *
 ********************************************************************************/
#ifndef __SXUPDATERANGE_H__
#define __SXUPDATERANGE_H__ 1

#ifdef __cplusplus
#include "ANS_StandardIncludes.h"
#else
#include "computer.h"
#include "globals.h"
#endif

#include "sx_CADOE_solver.h"

#ifdef __cplusplus
extern "C" {
#endif

extern int SxUpdateRange( T_modele* );

#ifdef __cplusplus
}
#endif

#endif /* __SXUPDATERANGE_H__ */
