/*
 *    author/date: yu-hua ting/02-08-94
 *
 *    primary function:
 *
 *      Header for the " error handler" routines in the Ansys/Shapes Interface
 *
 *    secondary function:
 *
 *        none
 *
 *    routines included:
 *
 *
 *    history
 *
 *        none
 *
 *    comments:
 *
 *        none
 *
 *    Notice - This file contains ANSYS Confidential information ***
 *
 */
/* 
 * *** copyright(c) 2011 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */


 

/****************************************************************************
 *    Push an error code into the error code stack used for tracing         *
 *    the calling chain when error occur                                 *
 *   (error code stack is from 0 to error_code_stack_size - 1)              *
 ****************************************************************************/

      extern INT xPushErrorCallingChainStk_xax ansPROTO((
             INT error_code));  



 
/**************************************************************************** 
 *    Pop an error code from the top of the error code stack used for       *
 *    tracing the calling chain when error occur                         *
 *   (error code stack is from 0 to error_code_stack_size - 1)              *
 ****************************************************************************/ 


      extern INT xPopErrorCallingChainStk_xax ansPROTO((void));

  
/**************************************************************************** 
 *    Clear the error code stack used for tracing the calling chain when * 
 *    error occur and reinitialize the error code stack top pointer         *
 *   (error code stack is from 0 to error_code_stack_size - 1)              * 
 ****************************************************************************/ 
 

 
      extern VOID xClearErrorCallingChainStk_xax ansPROTO((void));

/****************************************************************************
 *    Error Handler                                                         *
 ****************************************************************************/

      extern VOID xErrorHandler_xax ansPROTO((
             INT *iretp,
             xaxERROR error_code_detected,
             INT error_code_push,
             INT error_type_request)); 

 
/****************************************************************************
 *    Signal Handler for catching operating system errors inside Shapes     *
 ****************************************************************************/
 

#if !defined(SOLARIS_SYS) && !defined(RS64K_SYS)

      extern INT xSignalErrorHandler_xax ansPROTO((
             INT sigNum));
#else
      extern VOID xSignalErrorHandler_xax ansPROTO((
             INT sigNum));
#endif




 
 
/****************************************************************************
 *    Set the global Error Code                                             *
 ****************************************************************************/
 
    extern INT  xGlobalErrorSet_xax ansPROTO((
           INT error_code,
           INT iopt));
 
 
/****************************************************************************
 *    Set the global XOX Error Code                                         *
 ****************************************************************************/
 
    extern INT  xGlobalXoxErrorSet_xax ansPROTO((
           INT error_code,
           INT iopt));
 
 

 
/****************************************************************************
 *    Set the global Ansys Error Code                                       *
 ****************************************************************************/
 
    extern INT  xGlobalAnsysErrorSet_xax ansPROTO((
           INT error_code,
           INT iopt));
 

 
/****************************************************************************
 *    Set the global Ansys/Shapes Interface Error Code                      *
 ****************************************************************************/
 
    extern INT  xGlobalXaxErrorSet_xax ansPROTO((
           INT error_code,
           INT iopt));
 
/****************************************************************************
 *    Set the global Warning Code                                             *
 ****************************************************************************/
 
    extern INT  xGlobalWarningSet_xax ansPROTO((
           INT warning_code,
           INT iopt));

/****************************************************************************
 *    Set the global XOX Warning Code                                         *
 ****************************************************************************/
 
    extern INT  xGlobalXoxWarningSet_xax ansPROTO((
           INT warning_code,
           INT iopt));
 
 

 
/****************************************************************************
 *    Set the global Ansys Warning Code                                       *
 ****************************************************************************/
 
    extern INT  xGlobalAnsysWarningSet_xax ansPROTO((
           INT warning_code,
           INT iopt));
 

 
/****************************************************************************
 *    Set the global Ansys/Shapes Interface Warning Code                      *
 ****************************************************************************/
 
    extern INT  xGlobalXaxWarningSet_xax ansPROTO((
           INT warning_code,
           INT iopt));



/****************************************************************************
 *    Collect the global error Code                                         *
 ****************************************************************************/
 
    extern INT  xGlobalErrorCollect_xax ansPROTO((
         INT *error_code));

 
/****************************************************************************
 *    Clear all the global error Codes                                      *
 ****************************************************************************/


    extern INT  xGlobalErrorWarningClear_xax ansPROTO((
           INT  itype));  /* == ERROR_AND_WARNING_CODES
                           * == ERROR_CODES
                           * == WARNING_CODES              */
 
