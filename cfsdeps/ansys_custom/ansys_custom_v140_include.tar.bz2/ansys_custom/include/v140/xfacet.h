/* 
 * *** copyright(c) 2011 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */

#if !defined(include_xoxbolh)
#define include_xoxbolh 1
#include "xoxbol.h"
#endif

#define  DATABASE	0
#define  STACK		1

/* Fortran callable C routines   */

#if defined(RS6000_SYS) || defined(HP32_SYS)
#define xfacet_ xfacet
#define xtess_  xtess

#endif

#if defined(WATCOMC_SYS) \
    || defined(PCWINNT_SYS)
#define xfacet_ XFACET
#define xtess_  XTESS

#endif

/************************************************************************
****
 *    Call XOX tessellation routine to get facets for a
 *    given geometry
 *
   *
 ************************************************************************
****/

      extern VOID CALLTYP xfacet_ ansPROTO((
        INT *ansys_geom,  /*I ANSYS geomtry         */
        INT *geom,        /* I XOX geometry          */
        DOUBLE *pointTol, /* I point tolerance to refine polygons to */
        DOUBLE *angularTol, /* I angular tolerance to refine polygons to
*/
        INT *code,        /* I determine usage of pointTol and angular to
lerance
                           *    == 0 No tolerance needs be met
                           *    == 1 Use only pointTol
                           *    == 2 Use only angularTol
                           *    == 3 Use both tolerance values
                           *    == 4 Use either of the tolerances  */
        INT *flag,        /* I  flag for saving the result
                           *    == 0 database
                           *    == 1 stack    */
        INT *iwor,        /* I  integer record           */
        INT *dwor,        /* I  double precision record  */
        INT *numel,       /* O  numbers of elements      */
        INT *plen,        /* O  numbers of points        */
        INT *elemsRec,    /* O  elements record          */
        INT *pointsRec,   /* O  points  record           */
        INT *normalsRec,  /* O  normals record           */
        INT *iretp));     /* O  error code
                           *    == 0 - no error
                           *    == !0- error        */


/************************************************************************
****
 *    Call XOX tessellation routine right after Boolern
 *    operation to get facets for a given geometry
 *
   *
 ************************************************************************
****/

      extern VOID CALLTYP xtess_ ansPROTO((
         INT ansys_geom[],     /* I ANSYS geometry array    */
         INT xgeom[],          /* I Xox geomtry array         */
         INT gdims[],          /* I Geometry dimensions of entities */
         INT *n,                /* I number of entities              */
         INT *iretp));          /* O  error code
                           *    == 0 - no error
                           *    otherwise - error
                         */
