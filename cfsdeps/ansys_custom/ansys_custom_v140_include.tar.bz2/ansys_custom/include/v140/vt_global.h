////////////////////////////////////////////////////////////////////////////
//                                                                        //
//          copyright(c) 2011 SAS IP, Inc.  All rights reserved.            //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: vt_global.h $
// $Revision: 458428 $Id: 
// $Date: 2011-03-08 09:16:14 -0500 (Tue, 08 Mar 2011) $
// $Author: ajkang $
//
// Decription: 
//
////////////////////////////////////////////////////////////////////////////


#ifndef __VT_GLOBAL__
#define __VT_GLOBAL__ 1

#include "C_AnsysModele.h"

extern C_AnsysModele *G_AnsysModele;

#endif
