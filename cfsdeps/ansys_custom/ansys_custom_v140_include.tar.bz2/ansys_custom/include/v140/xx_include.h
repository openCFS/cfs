/* ********************************** */
/* *** copyright(c) 2011 SAS IP, Inc.  All rights reserved. *** */
/* *** ansys, inc.                *** */
/* ********************************** */

/* *** NOTE ***
 *
 * This file is no longer used (since ANSYS55 beta).
 * It has been removed.
 */

int xx_util__DUMMY (void);
