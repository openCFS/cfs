/*
 *    author/date: yu-hua ting/11-25-93
 *
 *    primary function:
 *
 *       Header for the conversion routines between ANSYS topologies and          
 *       SHAPES topologies                                        
 *
 *    secondary function:
 *
 *        none
 *
 *    routines included:
 *
 *
 *    history
 *
 *        none
 *
 *    comments:
 *
 *    Notice - This file contains ANSYS Confidential information ***
 *
 */
/* 
 * *** copyright(c) 2011 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */

/*****************************************************************************
 *                                                                           *
 *    convert ANSYS entities to SHAPES geoms                                 *
 *                                                                           *
 *****************************************************************************/

/*   
 *    convert ANSYS volumes to SHAPES 3-geoms (xvolumes)
 *    (we are converting volumes abs(vun[i]) to xvolumes xvun[i])
 */
      extern VOID xtvuc ansPROTO((
             INT vun[],           /* I    volume numbers of ANSYS volumes          */
             INT *np,             /* I    pointer to the number of ANSYS volumes   */
             INT xvun[],          /*   O  geom numbers of SHAPES 3-geoms, 
                                   *      xvun[i] == geom number of the 3-geom
                                   *      corresponding to the volume abs(vun[i])  */
             INT *iretp));        /*   O  pointer to the error code                */

/* 
 *    convert ANSYS subvolumes to SHAPES 3-geoms (xsubvolumes)
 *    (we are converting subvolumes abs(svn[i]) to xvolumes xsvn[i])
 */
      extern VOID xtsvc ansPROTO((
             INT svn[],           /* I    subvolume numbers of ANSYS subvolumes      */
             INT *np,             /* I    pointer to the number of ANSYS subvolumes  */
             INT xsvn[],          /*   O  geom numbers of SHAPES 3-geoms        
                                   *      xsvn[i] == geom number of the 3-geom
                                   *      corresponding to the subvolume abs(svn[i]) */
             INT *iretp));        /*   O  pointer to the error code                  */

/*   
 *    convert ANSYS shell tree to SHAPES 2-geom tree (xshell tree)
 *
 *    (we are converting shells -shn[i] to xshells xshn[i], because 
 *     in ANSYS all normals of shells point to the outside of a
 *     subvolume, but in SHAPES they point to the inside)
 */
      extern VOID xtshc ansPROTO((
             INT *svnp,           /* I    subvolume number of an ANSYS subvolume     */
             INT shn[],           /* I    shell numbers of ANSYS shell tree of the 
                                   *      subvolume                                  */
             INT *np,             /* I    pointer to the number of shells in the
                                   *      shell tree                                 */
             INT xshn[],          /*   O  geom numbers of SHAPES 2-geoms             
                                   *      xshn[i] == geom number of the 2-geom
                                   *      corresponding to the shell abs(shn[i])     */
             INT *iretp));        /*   O  pointer to the error code                  */


/*   
 *    convert ANSYS areas to SHAPES 2-geoms (xareas)
 *    (we are converting areas abs(arn[i]) to xareas xarn[i])
 */
      extern VOID xtarc ansPROTO((
             INT arn[],           /* I    area numbers of ANSYS areas            */
             INT *np,             /* I    pointer to the number of ANSYS areas   */
             INT xarn[],          /*   O  geom numbers of SHAPES 2-geoms         */
             INT *iretp));        /*   O  pointer to the error code              */

/*   
 *    convert ANSYS subareas to SHAPES 2-geoms (xsubareas)
 *    (we are converting subareas abs(san[i]) to xsubareas xsan[i])
 */
      extern VOID xtsac ansPROTO((
             INT san[],           /* I    subarea numbers of ANSYS subareas       */
             INT *np,             /* I    pointer to the number of ANSYS subareas */
             INT xsan[],          /*   O  geom numbers of SHAPES 2-geoms          */
             INT *iretp));        /*   O  pointer to the error code               */

/*   
 *    convert ANSYS loop tree to SHAPES 1-geom tree (xloop tree)
 *    (we are converting loops lpn[i] to xloops xlpn[i])
 */
      extern VOID xtlpc ansPROTO((
             INT *sanp,           /* I    subarea number of an ANSYS subarea         */
             INT lpn[],           /* I    loop numbers of ANSYS loop tree of the 
                                   *      subarea                                    */
             INT *np,             /* I    pointer to the number of loops in the
                                   *      loop tree                                  */
             INT xlpn[],          /*   O  geom numbers of SHAPES 1-geoms             */
             INT *discon_curve,
	     INT *iretp));        /*   O  pointer to the error code                  */




/*   
 *    convert ANSYS lines to SHAPES 1-geoms (xlines)
 *    (we are converting lines abs(lsn[i]) to xlines xlsn[i])
 */
      extern VOID xtlsc ansPROTO((
             INT lsn[],           /* I    line numbers of ANSYS lines            */
             INT *np,             /* I    pointer to the number of ANSYS lines   */
             INT xlsn[],          /*   O  geom numbers of SHAPES 1-geoms         */
	     INT *iretp));        /*   O  pointer to the error code              */


/*   
 *    convert ANSYS sublines to SHAPES 1-geoms (xsublines)
 *    (we are converting sublines abs(sln[i]) to xsublines xsln[i])
 */
      extern VOID xtslc ansPROTO((
             INT sln[],           /* I    subline numbers of ANSYS sublines     */
             INT *np,             /* I    pointer to the number of ANSYS sublines */
             INT xsln[],          /*   O  geom numbers of SHAPES l-geoms         */
	     INT *iretp));        /*   O  pointer to the error code              */


/*   
 *    convert ANSYS keykeypoints to SHAPES 0-geoms (xkeypoints)
 */
      extern VOID xtkpc ansPROTO((
             INT kpn[],           /* I    keypoint numbers of ANSYS keypoints      */
             INT *np,             /* I    pointer to the number of keypoints       */
             INT xkpn[],          /*   O  geom numbers of SHAPES 0-geoms           */
             INT *iretp));        /*   O  pointer to the error code                */


/*   
 *    convert ANSYS points to SHAPES 0-geoms (xpoints)
 */
      extern VOID xtptc ansPROTO((
             INT ptn[],           /* I    point numbers of ANSYS point             */
             INT *np,             /* I    pointer to the number of points          */
             INT xptn[],          /*   O  geom numbers of SHAPES 0-geoms           */
             INT *iretp));        /*   O  pointer to the error code                */



/*****************************************************************************
 *                                                                           *
 *    convert SHAPES geoms to ANSYS entities                                 *
 *                                                                           *
 *****************************************************************************/



/*   
 *    convert ANSYS subvolumes from SHAPES 3-geoms (xsubvolumes)
 *    (we are converting xsubvolumes xsvn[i] to subvolumes svn[i])
 */
      extern VOID xfsvc ansPROTO((
             INT xsvn[],          /* I    geom numbers of SHAPES 3-geoms              */
             INT *xnp,            /* I    pointer to the number of SHAPES 3-geoms     */
             INT svn[],           /*   O  subvolume numbers of ANSYS subvolumes        
                                   *      svn[i] == subvolume number of the subvolume
                                   *      corresponding to the 3-geom xsvn[i]         */
             INT *iretp));        /*   O  pointer to the error code                   */


/*   
 *    convert ANSYS shell tree from SHAPES 2-geom tree (xshell tree)
 *    (we are converting xshells -xshn[i] to shells shn[i])
 */
      extern VOID xfshc ansPROTO((
             INT *xsvnp,          /* I    geom number of a xsubvolume (or xvolume)   */
             INT xshn[],          /* I    geom numbers of SHAPES xshell tree of the 
                                   *      xsubvolume (or xvolume) corresponding to 
                                   *      subvolume (or volume) *svnp                */
             INT *xnp,            /* I    pointer to the number of xshells in the
                                   *      xshell tree                                */
             INT *svnp,           /* I    subvolume (or volume) number of an ANSYS 
                                   *      subvolume (or volume)                      */
             INT shn[],           /*   O  shell numbers of ANSYS shells
                                   *      shn[i] == shell number of the shell 
                                   *      corresponding to the xshell xshn[i]        */
             INT *ientyp,         /* I    == ANSYS_VOLUME or
                                   *      == ANSYS_SUBVOLUME                         */
             INT *iretp));        /*   O  pointer to the error code                  */




/*   
 *    convert ANSYS subareas from SHAPES 2-geoms (xsubareas)
 */
      extern VOID xfsac ansPROTO((
             INT xsan[],          /* I    geom numbers of SHAPES 2-geoms          */
             INT *xnp,            /* I    pointer to the number of SHAPES 2-geoms */
             INT san[],           /*   O  subarea numbers of ANSYS subareas       */
             INT *iretp));        /*   O  pointer to the error code               */


/*   
 *    convert ANSYS loop tree from SHAPES 1-geom tree (xloop tree)
 */
      extern VOID xflpc ansPROTO((
             INT *xsanp,          /* I    geom number of a xsubarea (or xarea)   */
             INT xlpn[],          /* I    geom numbers of SHAPES xloop tree      */
             INT *xnp,            /* I    pointer to the number of xloops in the
                                   *      xloop tree                             */
             INT *sanp,           /* I    subarea (area) number of an ANSYS 
                                   *      subarea (area)                         */
             INT lpn[],           /*   O  loop numbers of ANSYS loops            */
             INT *ientyp,         /* I    == ANSYS_AREA or
                                   *      == ANSYS_SUBAREA                       */
             INT *iretp));        /*   O  pointer to the error code              */


/*   
 *    convert ANSYS sublines from SHAPES 1-geoms (xsublines)
 */
      extern VOID xfslc ansPROTO((
             INT xsln[],          /* I    geom numbers of SHAPES xsublines          */
             INT *xnp,            /* I    pointer to the number of SHAPES xsublines */
             INT sln[],           /*   O  subline numbers of ANSYS sublines         */
             INT *iretp));        /*   O  pointer to the error code                 */




/*   
 *    convert ANSYS points from SHAPES 0-geoms
 */
      extern VOID xfptc ansPROTO((
             INT xptn[],          /* I    geom numbers of SHAPES xpoints            */
             INT *xnp,            /* I    pointer to the number of xpoints          */
             INT ptn[],           /*   O  point numbers of ANSYS points             */
             INT *iretp));        /*   O  pointer to the error code                 */
