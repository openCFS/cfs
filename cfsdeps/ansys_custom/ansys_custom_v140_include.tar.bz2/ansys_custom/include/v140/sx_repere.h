/* repere.h CADOE */
/**
 *	repere.h --
 *   
 **/

#ifdef CADOE_ANSYS
#include "computer.h"
#include "globals.h"
#include "sysparh.h"
#endif

#include "sx_CADOE_solver.h"
#ifndef __REPERE_X_DEJA_INCLUS__
#define __REPERE_X_DEJA_INCLUS__ 1


#if defined(LOWERCASENOUNDER_SYS)
#endif

#if defined(UPPERCASENOUNDER_SYS)
#define ele_geteul ELE_GETEUL
#endif

#if defined(LOWERCASEUNDER_SYS)
#define ele_geteul ele_geteul_
#endif

/* 
 * Gestion des reperes 
 */
#ifdef __cplusplus
extern "C" {
#endif

extern T_repere *REP_rechercher_repere_num( int , T_modele *, T_statut *  );

#ifdef MAINWIN
#define INT int
#define DOUBLE double
#endif 

#ifdef CADOE_ANSYS
SUBROUTINE ele_geteul( INT *label, DOUBLE *eul);
#endif


#ifdef MAINWIN
#undef INT 
#undef DOUBLE 
#endif 
#ifdef __cplusplus
}
#endif

#endif   /* __REPERE_X_DEJA_INCLUS__ */
