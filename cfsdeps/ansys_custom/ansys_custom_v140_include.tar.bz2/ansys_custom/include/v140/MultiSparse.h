#ifndef _MULTI_SPARSE_H_
#define _MULTI_SPARSE_H_

#include "SparseMatrix.h"
#include "C_vstruct.h"
#include "C_MatSp.h"

class RectSparse;
class MultiSparse  
{
  RectSparse *_Krc;
  RectSparse *_Kcr;
  RectSparse *_coarseSparse;
  RectSparse *_ceK;
  
public:
  MultiSparse();
  ~MultiSparse();
  
  void setKrc(RectSparse *mat)	{_Krc = mat;		}
  void setKcr(RectSparse *mat)	{_Kcr = mat;		}
  void setCoarseSparse(RectSparse *mat) {_coarseSparse = mat;}
  void setCeK(RectSparse *mat)	{_ceK = mat;		}

  RectSparse *getKrc()		{return _Krc;		}
  RectSparse *getKcr()		{return _Kcr;		}
  RectSparse *getCoarseSparse() {return _coarseSparse;	}
  RectSparse *getCeK()		{return _ceK;		}
  
  void multIdentity(FSFullMatrix &res);
  void transposeMultIdentity(C_VSTRUCT<double> &res);
  void transposeMultIdentity(C_MatSp<double> &res);
  void multSub(double *, double *);
  void transposeMultSub(double *, double *);
};

#endif
