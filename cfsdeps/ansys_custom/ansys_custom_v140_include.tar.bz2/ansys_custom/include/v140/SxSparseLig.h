
/**
 * @file   SxSparseLig.h
 * @author Frederic Thevenon
 * @date   Fri Jun 09 10:40:46 2006
 * 
 * @brief  
 */

#ifndef __SXSPARSELIG_H__
#define __SXSPARSELIG_H__ 1

#ifndef __cplusplus
#error "SxSparseLig.h must only be included by C++ files"
#endif

#include "SxSparseLso.h"


static int		incr_1 = 1;
static int		*adrincr = &incr_1;

/* Buffer for multiple rows */

class T_line_buffer : public T_lso_buffer
{
public :

  T_line_buffer( int in_order, int size, T_booleen alloc)
    : T_lso_buffer( size, alloc) { order = in_order;}
  virtual ~T_line_buffer() {};
  
  // ===== Members

  int order;
};

/*!
 * \class	T_ligne
 *  \brief	This object define an line object for T_m_ooc matrices
 *		
 *  \author	FT - JDB
 *  \version	1.0
 *  \date	2003-2005
 *  \bug	
 *  \warning	
 *
 *  \version 1.0 :       Initial Revision
 *
 *  \remark :	
 *
 *  \todo :
 */

class T_ligne : public T_lso
{
public :

  T_ligne( int iirow = 0, int iindex = 0, int ilength = 0, int iordre = 0,
	   bool isuppressed = false)
  : T_lso( iirow, iindex, ilength, isuppressed)
  {
    ordre = iordre;
    ptr_ordre = NULL;
  }

  T_ligne( T_ligne &lin);
  virtual ~T_ligne(void) { Release();}

  virtual inline void Release( void) { if ( ptr_ordre) LM_FREE( ptr_ordre);}

  virtual int	Flush( int fic, bool write);
  virtual int	Write( int fic);

  int		    Compact( double seuil, bool compact_buffer, 
			      IVEC *&compact, IVEC *&compact_iptr);
  inline int	GetOrder( void) const { return ordre;}
  inline void	SetOrder( int order) { ordre = order;}
  
  /* template functions used for the paralell product */
  template <typename T> inline void IndExtractLocalVector( int od, T *vin, T *vecloc);
  template <typename T> inline void IndExtractLocalVectorSym( int od, T *vin, T *vecloc);
  template <typename T> inline void MvMltLocal( int order, T *vi, T *vo);
  template <typename T> inline void MvMltUns( int order, T *vi, T *vo);
  template <typename T> inline void IndFillGlobalVectors( int order, T *vecloc, T *vout);
  template <typename T> inline void IndFillGlobalVectors(int order, T *vecloc, int nbv, int sizev, T *vout);
  template <typename T> inline void IndFillGlobalVectors2( int order, T *vecloc, int nbv, int sizev, T *vout);
  template <typename T> inline void	MvMlt( int order, T *vi, T *vo);
  template <typename T> inline void IndExtractLocalVector2( int od, int nbv, int sizev, T coef, T *vin, T *vecloc);
  template <typename T> inline void IndExtractLocalVector2Sym( int od, int nbv, int sizev, T coef, T *vin, T *vecloc);
  template <typename T> inline void MmMltUns( int order, int nbv, T *viloc, T *voloc);
  template <typename T> inline void MmMlt( int order, int nbv, T *vi, T *vo);

  // ===== Members

  unsigned int		ordre:4;
  int *			ptr_ordre;
};


template <typename T> void
T_ligne::IndExtractLocalVector2(int od, int nbv, int sizev,T coef, T *vin, T *vecloc)
{
  int  prem = ptr_ordre[od];
  int  dern = ptr_ordre[od+1];
  int  len = dern - prem;
  
  T	*ptrvecloc = vecloc;  
  int	*pos = indices+prem;
  
  for( int jd=0; jd<len; jd++, pos++, ptrvecloc+=nbv){
      int i2 = *pos;
      
      for( int iv=0; iv<nbv; iv++)
	    ptrvecloc[iv] = vin[iv*sizev + i2]*coef;
  }
}

template <typename T> void
T_ligne::IndExtractLocalVector( int od, T *vin, T *vecloc)
{
  int  prem = ptr_ordre[od];
  int  dern = ptr_ordre[od+1];
  int  linelength = dern - prem;
  int *pos = indices+prem, iv;
    
  T	  *ptrvecloc = vecloc;
  
  for( iv=0; iv<linelength; iv++, pos++)
        ptrvecloc[iv] = vin[*pos];
}

template <typename T> void
T_ligne::IndExtractLocalVector2Sym(int od, int nbv, int sizev,T coef, T *vin, T *vecloc)
{
  register int  prem = ptr_ordre[od];
  register int  dern = ptr_ordre[od+1];
  register int	iv, jd;
  
  register T	*ptrvecloc = vecloc;  
  register int	*pos = indices+prem;
    
  for( iv=0; iv<nbv; iv++)
    vecloc[iv] = vin[irow + iv * sizev] * coef;

  int nz_diag=(irow == *pos);
  if(nz_diag){ pos++;}

  for( jd=prem + nz_diag; jd<dern; jd++, pos++, ptrvecloc+=nbv){
    for( iv=0; iv<nbv; iv++)
      vecloc[iv + ((1-nz_diag+jd-prem) * nbv)] = vin[iv * sizev + *pos] * coef;
  }
}

template <typename T> void
T_ligne::IndExtractLocalVectorSym( int od, T *vin, T *vecloc)
{
  int  prem = ptr_ordre[od];
  int  dern = ptr_ordre[od+1];
  int  linelength = dern - prem;
  int *pos = indices+prem, iv;
    
  vecloc[0] = vin[irow];
  
  if (irow == *pos){prem++;pos++;}
  
  for( iv=prem; iv<dern; iv++, pos++)
        vecloc[iv-prem+1] = vin[*pos];
  
}

template <typename T> void
T_ligne::MvMltLocal( int order, T *vi, T *vo)
{
  int			prem = ptr_ordre[order];
  int			dern = ptr_ordre[order+1];
  register int *pos = indices+prem;
  register int  nz_diag = (*pos == irow);
  register int  len = dern - prem;
  
  T *pvi = vi;
  T *pvo = vo;

  //diagonal terme
  if (nz_diag){
     vo[0] += valeurs[prem] * *pvi;
     prem++;
  }
  pvi++;
  pvo++;
  for (register int jd=prem; jd <dern; jd++,pvo++,pvi++){
     //upper triangle
     vo[0] += valeurs[jd] * *pvi;
        
     //lower triangle
     *pvo += valeurs[jd] * vi[0];
  }

  return;  
}

template <typename T> void
T_ligne::MvMlt( int order, T *vi, T *vo)
{
  register int	prem = ptr_ordre[order];
  register int	dern = ptr_ordre[order+1];
  register int   len = dern - prem;
  register int *pos = indices+prem;
  T *pvi = vi;
  int  nz_diag = (*pos == irow);
  
  //diagonal terme
  if (nz_diag){
     vo[irow] += valeurs[prem] * *pvi;
     //Msg_interne("coef[%i ; %i] = %e ",irow,prem,valeurs[prem]);
     pos++; prem++;
  }
  pvi++;
  
  for (register int jd=prem; jd <dern; jd++,pos++,pvi++){
     //Msg_interne("coef[%i ; %i] = %e ",irow,jd,valeurs[jd]); 
     //upper triangle
     vo[irow] += valeurs[jd] * *pvi;
        
     //lower triangle
     vo[*pos] += valeurs[jd] * vi[0];
  }

  return;
}

template <typename T> void
T_ligne::MvMltUns(int order, T *vi, T *vo)
{ 
  int	prem = ptr_ordre[order];
  int	dern = ptr_ordre[order+1];
  int   len = dern - prem;
  
  vo[irow] += dot( len, valeurs+prem, *adrincr, vi, *adrincr);
  
  return;  
}

template <typename T> void
T_ligne::IndFillGlobalVectors( int order, T *vecloc, T *vout)
{
  int   prem = ptr_ordre[order];
  int   dern = ptr_ordre[order+1];
  register int  *pos = indices+prem;
  register T    *pvec = vecloc;

  vout[irow] += *pvec;
  pvec++; 
  
  if (*pos == irow) {pos++; prem++;}
  
  for( int jd=prem; jd<dern; jd++, pos++, pvec++)
     vout[*pos] += *pvec;

  return;
}

template <typename T> void
T_ligne::IndFillGlobalVectors(int order, T *vecloc, int nbv, int sizev, T *vout)
{
  int   prem = ptr_ordre[order];
  int   dern = ptr_ordre[order+1];
  register int  *pos = indices+prem;
  register T    *pvec = vecloc;

  for( int iv=0; iv<nbv; iv++, pvec++)
	     vout[irow + iv * sizev] += *pvec;

  if (*pos == irow) {pos++; prem++;}

  for( int jd=prem; jd<dern; jd++, pos++){
      T	*ptrout = vout + *pos;
	  for( int iv=0; iv<nbv; iv++, ptrout+=sizev, pvec++)
	    *ptrout += *pvec;
  }
}

template <typename T> void
T_ligne::IndFillGlobalVectors2( int order, T *vecloc, int nbv, int sizev, T *vout)
{
  int   prem = ptr_ordre[order];
  int   dern = ptr_ordre[order+1];
  int   length = dern - prem;
  int *pos = indices+prem;
  
  for( int iv=0; iv<nbv; iv++, vecloc++) vout[irow + iv * sizev] += *vecloc;
    
  int nz_diag = (*pos == irow);
  if (nz_diag == 1) length--;

  for( int iv=0; iv<nbv; iv++, vout += sizev)	// vout is a copy of the calling ptr
    {
      pos = indices + prem + nz_diag;
      for( int jd=0; jd<length; jd++, pos++, vecloc++)
	    *(vout + *pos) += *vecloc;
    }
}

template <typename T> inline void 
T_ligne::MmMltUns( int order, int nbv, T *viloc, T *voloc)
{
  int   prem = ptr_ordre[order];
  int   dern = ptr_ordre[order+1];
  int   len = dern - prem;
  
  static char nt = 'N';
  static T t_un = 1, t_zero = 0;

  gemv( nt, nbv, len, t_un, viloc, nbv, valeurs+prem, 1, t_zero, voloc, 1);
}


template <typename T> inline void
T_ligne::MmMlt(int order, int nbv, T *vi, T *vo)
{ 
  register int   prem = ptr_ordre[order];
  register int   dern = ptr_ordre[order+1];
    
  register int i,j;

  int *pos = indices + prem;
  register double *vm = valeurs + prem;
  register int nz_diag = (*pos == irow); 
  register T *pvi=vi;

  if (nz_diag){
  	for(i=0;i<nbv;i++,pvi++) vo[i] += *vm * *pvi;
    vm++;
  }else 
      pvi += nbv;

  for(j=prem+nz_diag;j<dern;j++,vm++)
  for(i=0;i<nbv;i++,pvi++){
     vo[i] += *vm * *pvi;
     vo[(1-nz_diag+j-prem)*nbv + i] += *vm * vi[i];
  }
  

  return;  
}




#endif // __SXSPARSELIG_H__
