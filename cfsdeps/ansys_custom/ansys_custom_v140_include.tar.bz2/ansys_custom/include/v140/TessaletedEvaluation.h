#ifndef __TESSALETED_H_DEJA_INCLUS__
#define __TESSALETED_H_DEJA_INCLUS__ 1

#include "cadoe.h"
#include "cadoe_vector.h"
#include "CEvalProcess.h"
#include "CDirection.h"
#include "m_matrix.h"
#include "liste_chainee.h"
#include "C_CadoeMessage.h"

class C_QResu;
class C_NNode;
class C_NCell;
class C_Tess;
class C_TessStats;

class C_QResu
{
public:
  C_QResu( int n );
  ~C_QResu();
	
  double *	_val;
};

class C_NNode
{
public:
  C_NNode( int n );
  ~C_NNode();

  void SetCoord( const double *coord ) { 	memcpy( _coord, coord, _dim*sizeof(double) ); }
  T_statut Eval( C_Tess *tess );

  int		_idx2;
  int		_dim;
  double*	_coord; // coordinates in the root cell, using range [0.0 - 1.0]
  C_QResu *	_val;
};

class C_NCell
{
public:
  C_NCell( int nbp, int level, C_Tess *tess );
  ~C_NCell();

  static int NNE_index( int dim, int nb, int *idx );
  static int NCE_2n( int nbp );
  static int NCE_3n( int nbp );
  static void decod_coord3( int idx, int nbp, int *coord );

  int GetLevel( void ) const { return _level; }
  int GetNumPoints( void ) const { return _nbp; }

  void DuplicatePoints( IVEC *ptss, IVEC *ptsb, int ipar, int dip );
  C_NCell * FindCell( const double *coord, double *local_coord, T_statut *ier );
  bool IsPointInCell( const double *coord );
  C_QResu * EvaluateCenter( void );
  C_QResu * InterpolateCenter( void  );
  C_QResu * EvaluateError( void  );
  T_statut ProcessPoint( const double *vpar, C_QResu **resu );
  bool IsACorner( const double *vpar ) const;
  T_statut InterpolatePoint( const double *vpar, C_QResu **resu );
  T_statut Divide( void );
  T_statut EvalCorner( int iCorner );
  // convert a coord from local [-1;1] space to the global [0;1] space
  double Local2Global( double local, int ip ) const
  { return 0.5*( (1.+local)*(_vmax[ip]-_vmin[ip]) ) + _vmin[ip]; }
  // convert a coord from global [0;1] space to the local [-1;1] space
  double Global2Local( double global, int i ) const
  { return (-1.+2.*(global-_vmin[i])/(_vmax[i]-_vmin[i])); }
  //{ 	return 1. - (2*global - _vmin[ip]) / (_vmax[ip]-_vmin[ip]); }
  void DetermineTestNode( void );

  int		_level;
  unsigned int	_nbp:8;
  unsigned int	_accurate:1;
  unsigned int	_lockeddivide:1;
  C_NNode **	_corner;
  double *	_vmin;
  double *	_vmax;
  C_NNode *	_testNode;
  C_NCell **	_children;
private:
  // preferred test value of the cell center in [-1;1]
  double PrefTestValue(void) const { return -0.05; }

  C_Tess *	_tess;
};

class C_TessStats
{
public:
  C_TessStats() {Reset();}
  ~C_TessStats() {};

  void Reset( void ) { memset(_data, 0, 6*sizeof(int)); }
  void Print( void ) const;

  void IncrementNumCell(void) {_data[0]+=1;}
  void IncrementNumEval(void) {_data[1]+=1;}
  void IncrementNumInterp(void) {_data[2]+=1;}
  void IncrementNumNodes(void) {_data[3]+=1;}
  void IncrementNumReusedNodes(void) {_data[4]+=1;}
  void IncrementNumLockedDivide(void) {_data[5]+=1;}

  int GetNumCell(void) const { return _data[0]; }
  int GetNumEval(void) const { return _data[1]; }
  int GetNumInterp(void) const { return _data[2]; }
  int GetNumNodes(void) const { return _data[3]; }
  int GetNumReusedNodes(void) const { return _data[4]; }
  int GetNumLockedDivide(void) const { return _data[5]; }

private:
  int	_data[6];
};

class C_Tess
{
public:
  C_Tess();
  ~C_Tess();
	
  static double n_function( double *x ) { return x[0]+3.*x[1]*x[1]+9.*x[2]; }

  int GetNumCorner(void) const { return _numCorner; }
	
  T_statut Create(CEvalTool*, vector<CDirection*>, T_ltete *lcrit, double accuracy=0.01, bool regularGrid=false, int *numPointsPerAxe=NULL );

  T_statut SetReferenceValue( int ic, double val );
  T_statut EvaluateDesignSet( CDesignSet &, const double* );
  T_statut CalculateQResu( const double *vpar, C_QResu **resu );
  double ShapeFunction( const double* nc, int inode );
  T_statut FormCornerCoordinates( void );	
  void PrintStats( void ) { _stats->Print(); }
	
public:
  VEC *			_erreur;
  int			_nbres;
  T_liste *		_nodes;
  double		_divide_limit;	// cell size under which we do not divide any more - switch to standard evaluation
  VEC *			_step_min;
  int			_nbv;
  bool			_regularGrid; // allows some optimizations in the cell division operation
  int *			_numPointsPerAxe; // if _regularGrid, number of points per axe 

  C_TessStats		*_stats; // store and print some statistics

private:
  C_NCell *		_root;

  double		_factor;
  MAT *			_corner_coordinates;
  double		_rel_accuracy;
  T_ltete*		_lcrit;
  CEvalTool *		_process;
  vector<CDirection*> 	_vdir;
  int             	_numCorner;
};


#endif /* __TESSALETED_H_DEJA_INCLUS__ */
