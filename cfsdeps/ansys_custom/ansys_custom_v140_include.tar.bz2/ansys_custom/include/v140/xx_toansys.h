/*
 *    author/date: yu-hua ting/05-07-1997
 *
 *    primary function:
 *
 *       Header for the conversion routines from SHAPES topologies
 *       to ANSYS topologies        
 *
 *    secondary function:
 *
 *        none
 *
 *    routines included:
 *
 *
 *    history
 *
 *        none
 *
 *    comments:
 *
 *    Notice - This file contains ANSYS Confidential information ***
 *
 */
/* 
 * *** copyright(c) 2011 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */



/*****************************************************************************
 *                                                                           *
 *    convert SHAPES geoms to ANSYS entities                                 *
 *                                                                           *
 *****************************************************************************/


      extern VOID xx_toansys_init ansPROTO((
             INT *iretp));        /*   O  pointer to the error code                   */

      extern VOID xx_toansys_term ansPROTO((
             INT *iretp));        /*   O  pointer to the error code                   */




/*   
 *    convert ANSYS subvolumes from SHAPES 3-geoms (xsubvolumes)
 *    (we are converting xsubvolumes xsvn[i] to subvolumes svn[i])
 */
      extern VOID xx_to_sv ansPROTO((
             INT xsvn[],          /* I    geom numbers of SHAPES 3-geoms              */
             INT xnp,             /* I    pointer to the number of SHAPES 3-geoms     */
             INT svn[],           /*   O  subvolume numbers of ANSYS subvolumes        
                                   *      svn[i] == subvolume number of the subvolume
                                   *      corresponding to the 3-geom xsvn[i]         */
             INT *iretp));        /*   O  pointer to the error code                   */


/*   
 *    convert ANSYS shell tree from SHAPES 2-geom tree (xshell tree)
 *    (we are converting xshells -xshn[i] to shells shn[i])
 */
      extern VOID xx_to_sh ansPROTO((
             INT *xsvnp,          /* I    geom number of a xsubvolume (or xvolume)   */
             INT xshn[],          /* I    geom numbers of SHAPES xshell tree of the 
                                   *      xsubvolume (or xvolume) corresponding to 
                                   *      subvolume (or volume) *svnp                */
             INT xnp,             /* I    pointer to the number of xshells in the
                                   *      xshell tree                                */
             INT *svnp,           /* I    subvolume (or volume) number of an ANSYS 
                                   *      subvolume (or volume)                      */
             INT shn[],           /*   O  shell numbers of ANSYS shells
                                   *      shn[i] == shell number of the shell 
                                   *      corresponding to the xshell xshn[i]        */
             INT *ientyp,         /* I    == ANSYS_VOLUME or
                                   *      == ANSYS_SUBVOLUME                         */
             INT *iretp));        /*   O  pointer to the error code                  */




/*   
 *    convert ANSYS subareas from SHAPES 2-geoms (xsubareas)
 */
      extern VOID xx_to_sa ansPROTO((
             INT xsan[],          /* I    geom numbers of SHAPES 2-geoms          */
             INT xnp,             /* I    pointer to the number of SHAPES 2-geoms */
             INT san[],           /*   O  subarea numbers of ANSYS subareas       */
             INT *iretp));        /*   O  pointer to the error code               */


/*   
 *    convert ANSYS loop tree from SHAPES 1-geom tree (xloop tree)
 */
      extern VOID xx_to_lp ansPROTO((
             INT *xsanp,          /* I    geom number of a xsubarea (or xarea)   */
             INT xlpn[],          /* I    geom numbers of SHAPES xloop tree      */
             INT xnp,             /* I    pointer to the number of xloops in the
                                   *      xloop tree                             */
             INT *sanp,           /* I    subarea (area) number of an ANSYS 
                                   *      subarea (area)                         */
             INT lpn[],           /*   O  loop numbers of ANSYS loops            */
             INT *ientyp,         /* I    == ANSYS_AREA or
                                   *      == ANSYS_SUBAREA                       */
             INT *iretp));        /*   O  pointer to the error code              */


/*   
 *    convert ANSYS sublines from SHAPES 1-geoms (xsublines)
 */
      extern VOID xx_to_sl ansPROTO((
             INT xsln[],          /* I    geom numbers of SHAPES xsublines          */
             INT xnp,             /* I    pointer to the number of SHAPES xsublines */
             INT sln[],           /*   O  subline numbers of ANSYS sublines         */
             INT *iretp));        /*   O  pointer to the error code                 */




/*   
 *    convert ANSYS points from SHAPES 0-geoms
 */
      extern VOID xx_to_pt ansPROTO((
             INT xptn[],          /* I    geom numbers of SHAPES xpoints            */
             INT xnp,             /* I    pointer to the number of xpoints          */
             INT ptn[],           /*   O  point numbers of ANSYS points             */
             INT *iretp));        /*   O  pointer to the error code                 */
