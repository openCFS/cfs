/*******************************************************************************
 *
 *   SxWriteParam.h  --- Write/update parameter records in the CADOE database
 *               
 * 
 * |Module:  
 *
 * |Description: 
 *
 * |Includes:	
 *        
 * |Auteur: Stephane MARGUERIN
 *
 * |Creation: Juillet 2002
 *
 * |Version: $Id: SxWriteParam.h 145002 2009-11-13 16:20:27Z jtm $
 *
 * |Copyright:	Copyright(c)  2002
 *
 ********************************************************************************/
#ifndef __SXWRITEPARAM_H__
#define __SXWRITEPARAM_H__ 1

#include "sx_cons_solver.h"
#include "sx_CADOE_solver.h"

extern int SxWriteParam( T_modele* );

#endif /* __SXWRITEPARAM_H__ */
