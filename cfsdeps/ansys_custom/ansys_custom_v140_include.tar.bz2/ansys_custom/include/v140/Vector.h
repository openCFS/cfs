/*****************************************************************************
 *                   Copyright (C) 1999 CMSoft                               *
 *                                                                           *
 *  These lines of code and declarations contain unpublished proprietary     *
 *  information of CMSoft. They may not be copied or duplicated in whole     *
 *  or part without prior authorization from CMSoft.                         *
 *                                                                           *
 *****************************************************************************/

#ifndef _FS_VECTOR_H_
#define _FS_VECTOR_H_

class SMV;
class FSCommunicator;

class FSVector {
protected:
   int   len;  // vector length
   double *d;  // vector elements
  public:

   FSVector() { len = 0; d = 0; }
   FSVector(int length); 
   FSVector(const FSVector &v);
   FSVector(const FSVector &v, double initialValue);
   FSVector(int length, double initialValue);
   FSVector(double  *v, int length);
   FSVector(const SMV &smv);

   ~FSVector();

   int size() const     { return len; }
   double* data() const { return d;   }
   void zero() { *this = 0.0; }

   void copy(const FSVector &v);
   void copy(const double *v);
   void copy(const double  value);

   double   operator * (const FSVector &);
   double   operator ^ (const FSVector &);
   FSVector operator / (const FSVector &);
   FSVector operator + (const FSVector &);
   FSVector operator - (const FSVector &);
   double &operator[] (int i) const;

   FSVector &operator=(const FSVector &);   // v2 = v1
   FSVector &operator=(const double c);     // v1 = 0.0
   FSVector &operator=(const double *data); // v1 = data

   void operator*=(const double c);         // v =  c*v
   void operator+=(const FSVector &v2);     // v += v2
   void operator-=(const FSVector &v2);     // v -= v2
   void operator/=(const FSVector &v2);     // v /= v2

   FSVector &operator =(const SMV &smv);
   FSVector &operator-=(const SMV &smv);

   void linAdd(double alpha, FSVector &v);
   void linAdd(double alpha, const FSVector &, double beta, const FSVector &);
   void linC( double c, const FSVector &v );
   void linC( const FSVector &v, double c );
   void linC( const FSVector & , double , const FSVector & );
   void linC( double, const FSVector &, double, const FSVector &);
   void swap( FSVector &);
   void mapTo(int *map, FSVector &v);
   void mapFrom(int *map, FSVector &v);

   void print(char *msg = "");
   void mult(FSVector &v);
   void diff(FSVector &v1, FSVector &v2);
   double Nrm2();

   void sum(FSCommunicator *);

   friend FSVector operator * (const double c,const FSVector &);
};

inline double &
FSVector::operator[] (int i) const { return d[i]; }

inline
FSVector::FSVector(int l)           // Constructor
{ 
   len = l;
   if(len)
     d   = new double[len];
   else
     d = 0;
}

inline
FSVector::FSVector(const FSVector &v, double val)
{
 len = v.len;
 if(len)
   d   = new double[len];
 else
   d = 0;
 copy(val);
}

inline
FSVector::~FSVector()
{
 if(d) delete [] d;
}

class StackFSVector : public FSVector {
  public:
    StackFSVector(double *data, int length);
    ~StackFSVector() { d=0; }
    StackFSVector &operator =(const SMV &smv);
    StackFSVector &operator-=(const SMV &smv);
};

inline
StackFSVector::StackFSVector(double *ptr, int length)
{
  len = length;
  d   = ptr;
}

#endif
