////////////////////////////////////////////////////////////////////////////
//                                                                        //
//          Copyright (C) 2010 ANSYS Inc.  All Rights Reserved            //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: sxnl_tools.h $
// $Revision: 147818 $Id: 
// $Date: 2010-04-06 16:47:28 -0400 (Tue, 06 Apr 2010) $
// $Author: srpailla $ Emmanuel Delor
//
// Decription: 
//
////////////////////////////////////////////////////////////////////////////

#ifndef __SXNL_TOOLS_H__ 
#define __SXNL_TOOLS_H__ 1 

#include <stdio.h>  
#include <stdlib.h>  
#include "computer.h"  
#include "globals.h"  
#include "sysparh.h"  
#include "cadoe.h"  
#include "C_VecPi.h"
#include "CadoeAnsys.h"

typedef enum
{
  E_STAT_TOTAL=1,
  E_STAT_PREP7=2, 
  E_STAT_SOLUTION=3,		// solvcl.F
  E_STAT_POST1=4,
  E_STAT_CHECK=5, 
  E_STAT_OBJECTS=6, 
  E_STAT_FORM=7,		// sfform.F
  E_STAT_SOLVE=8,		// bacsub.F
  E_STAT_OUTPUT=9,		// OutputResult
  E_STAT_COMBINE=10,
  E_STAT_LINESEARCH=11,		// linesearch.F
  E_STAT_CONTACT=12,
  E_STAT_CONVERGENCE=13,     
  E_STAT_GATHER=14, 
  E_STAT_ASSEMBLE=15, 
  E_STAT_PRECOND=16,
  E_STAT_AMULTX=17, 
  E_STAT_PCSOLVE=18,
  E_STAT_INPUTK=19, 
  E_STAT_ORDERK=20, 
  E_STAT_FACTORK=21,
  E_STAT_SOLVEK=22,

  E_STAT_SPUP_RUN=40,
  
  E_STAT_MINRESQ,
  E_STAT_CALCUL_DFDX,
  E_STAT_VERIF_CNV,
  E_STAT_INIT_ESAV,
  E_STAT_UPDATE_ESAV,
  E_STAT_PROJ_IN_BASIS,
  E_STAT_LINESEARCH_PARTIAL,
  E_STAT_DEFINE_MODEL,
  
  E_STAT_ENRICHQ,
  E_STAT_COMPUTE_EX,

  E_STAT_VTC_SOLVE,  
  E_STAT_VTC_READKMAT,
  E_STAT_VTC_FASTSOLVE,
  E_STAT_VTC_FACTOR,
  E_STAT_VTC_BACSUB,
  E_STAT_VTC_Gmat,
  E_STAT_VTC_PARTASSEMBLY,
  E_STAT_VTC_QG,
  E_STAT_VTC_QU,
  E_STAT_VTC_GtU,
  E_STAT_VTC_KinvF,
  E_STAT_VTC_GtKinvF,
  E_STAT_VTC_Gels,
  E_STAT_VTC_QULags,
  
  E_STAT_RIGID_BUILDBODIES, 
  E_STAT_RIGID_INIT,
  E_STAT_RIGID_REMOVERIGIDBODIES,
  
  E_STAT_DIM
} E_STAT;

class C_NLTime
{
 public:
  C_NLTime(E_STAT routine) {_routine = routine; reset();}
  ~C_NLTime() {};
  void Start();
  void End();
  void reset();
  
  void getTimeFromStart(double &cpu, double &elapsed);
  int getNbCalls() {return _nbCalls;}
  double getCpuTotal() {return _cpuTotal;}
  double getElapsedTotal() {return _elapsedTotal;}
  
  void Fillsummary(string &sMessage);
  
  int Write(FILE *fp);
  int Read(FILE *fp);
  
  void operator += (C_NLTime &);
  void operator -= (C_NLTime &);
  
protected:
  E_STAT _routine;
  int _nbCalls;
  double _cpuBegin;
  double _elapsedBeginSec;
  double _elapsedBeginUSec;
  double _cpuTotal;
  double _elapsedTotal;
};

class C_TimeProfiling
{
public:
  C_TimeProfiling();
  ~C_TimeProfiling();
  
  C_NLTime *getTimer(int section) {return _timer[section];}
  
  void statBegin(int);
  void statEnd(int);
  void FillSummary(string &, int);
  void reset();
  
  int Write(FILE *fp);
  int Read(FILE *fp);
  
  void operator += (C_TimeProfiling &);
  void operator -= (C_TimeProfiling &);
  
protected:
  C_NLTime **_timer;
};

//----------------------------------------------------------------- 
class C_InfoVectorQ 
//----------------------------------------------------------------- 
{ 
public: 
  C_InfoVectorQ() {_loadstep = _substep = _iter = _ivector = _masterDofs[0] = _masterDofs[1] = 0; _rest = 0.;}
  C_InfoVectorQ(int loadstep, int substep, int iter, int ivector, int masterDofs[2], double rest) 
  { 
    _loadstep = loadstep; 
    _substep = substep; 
    _ivector = ivector; 
    _iter = iter;
    _masterDofs[0] = masterDofs[0];
    _masterDofs[1] = masterDofs[1];
    _rest = rest;
  } 
  ~C_InfoVectorQ() {};
  
  int getLoadStep() {return _loadstep;};
  int getSubstep() {return _substep;};
  int getIVector() {return _ivector;};
  int getIter() {return _iter;};
  C_VecPi<double> &getCoefs() {return _coefs;};
  int* getMasterDofs() {return _masterDofs;};
  
  int Write (FILE *fp) {
    char fctn [] = "C_InfoVectorQ::Write";	CADOE_TRACE(fctn);
    T_statut ier(0);
    ier = BF_fwrite_int(fp, &_loadstep, 1);	CHKIERS;
    ier = BF_fwrite_int(fp, &_substep, 1);	CHKIERS;
    ier = BF_fwrite_int(fp, &_iter, 1);		CHKIERS;
    ier = BF_fwrite_int(fp, &_ivector, 1);	CHKIERS;
    ier = BF_fwrite_int(fp, _masterDofs, 2);	CHKIERS;
    ier = BF_fwrite_double(fp, &_rest, 1);	CHKIERS;
    ier = _coefs.Write(fp);			CHKIERS;
    return SUCCES;
  };
  int Read (FILE *fp) {
    char fctn [] = "C_InfoVectorQ::Read";	CADOE_TRACE(fctn);
    T_statut ier(0);
    ier = BF_fread_int(fp, &_loadstep, 1);	CHKIERS;
    ier = BF_fread_int(fp, &_substep, 1);	CHKIERS;
    ier = BF_fread_int(fp, &_iter, 1);		CHKIERS;
    ier = BF_fread_int(fp, &_ivector, 1);	CHKIERS;
    ier = BF_fread_int(fp, _masterDofs, 2);	CHKIERS;
    ier = BF_fread_double(fp, &_rest, 1);	CHKIERS;
    ier = _coefs.Read(fp);			CHKIERS;
    return SUCCES;
  };
  
protected: 
  int _loadstep;		// load step
  int _substep;			// substep
  int _iter;			// iteration
  int _ivector;			// indice of the vector in listUincrGlobal
  int _masterDofs [2];		// master DOFs for this vector
  double _rest;			// rest of vector after projection on the subspace
  C_VecPi<double> _coefs;
}; 

//----------------------------------------------------------------- 
class C_IvectorComp
//----------------------------------------------------------------- 
  : public binary_function<C_InfoVectorQ*, C_InfoVectorQ*, bool>
{
public:
  bool operator() (C_InfoVectorQ *x, C_InfoVectorQ *y) const
  {
    return x->getIVector() < y->getIVector();
  }
};

#endif 
