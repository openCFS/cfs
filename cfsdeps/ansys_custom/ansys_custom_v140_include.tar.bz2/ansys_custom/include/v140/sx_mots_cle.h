/* CADOE */
/*
 *  mots_cle.h -- champs du fichier .dat pour lecture / ecriture
 *
 * |Version: $Id: sx_mots_cle.h,v 1.3 2009/11/13 16:13:04 jtm Exp $
 *
 *   
 * HISTORY
 *   
 *   09/25/00 10:39 <       Brian Jantzen> Rel:ms8m1    SCCA:79107  Delta:81.2
 *   
 *   01/13/00 11:31 <        Marc Gadbois> Rel:ms8      SCCA:65669  Delta:8.6
 *   
 *   12/16/99 21:07 <         James Silva> Rel:ms8      SCCA:63720  Delta:8.5
 *   
 *   11/18/99 02:26 <         James Silva> Rel:ms8      SCCA:61479  Delta:8.4
 *   
 *   11/05/99 16:52 <         James Silva> Rel:ms8      SCCA:60240  Delta:8.3
 *   
 *   09/30/99 17:38 <         James Silva> Rel:ms8      SCCA:56512  Delta:8.2
 */


/* Format de fichier selon Specification ADOFEM 1.0 du 01-08-96 */

#ifndef __MOTSCLES__
#define __MOTSCLES__ 1

#define MTCL_VERSION		"|FormatVersion:"

#define VMTCL_YES		"yes"
#define VMTCL_NO		"no"

#define MTCL_STUDYTYPE		"|StudyType:"
#define VMTCL_STANDARD		"Standard___"
#define VMTCL_SENSITIVITY	"Sensitivity"
#define VMTCL_PARAMETRIC  	"Parametric_"
#define MTCL_ETUDE 		"|ProblemName:"
#define MTCL_FORMULATION 	"|Formulation:"
#define MTCL_ANALYSIS 		"|Analysis:"
#define VMTCL_STATIC   		"Static__"
#define VMTCL_HARMONIC 		"Harmonic"
#define VMTCL_MODAL    		"Modal___"
#define MTCL_DISPLACEMENT 	"|Displacement:"
#define MTCL_STRAIN 		"|Strain:"
#define MTCL_AVSTRAIN 		"|AveragedStrain:"
#define MTCL_STRESS 		"|Stress:"
#define MTCL_AVSTRESS 		"|AveragedStress:"
#define MTCL_ENERGY 		"|Energy:"
#define MTCL_REACTION 		"|Reaction:"
#define MTCL_INTFORCES 		"|InternalForces:"
#define MTCL_MASSE 		"|Mass:"
#define MTCL_MAXPOLSIZE 	"|MaxPolynomialSize:"
#define MTCL_ACCURACY 		"|Accuracy:"
#define MTCL_MAXORDER 		"|MaxDerivationOrder:"
#define MTCL_GOAL 		"|Goal:"
#define MTCL_LIMI 		"|Limitations:"
#define MTCL_METH 		"|Method:"
#define MTCL_PARA 		"|Parameters:"
#define MTCL_OPT_PT_INIT 	"|StartingPoint:"
#define MTCL_OPT_PNI     	"|InitialPenality:"
#define MTCL_OPT_PNMAX   	"|PenalityMax:"
#define MTCL_OPT_PNCOEF  	"|PenalityCoef:"
#define MTCL_OPT_PREC_PAR	"|ParametersPrecision:"
#define MTCL_OPT_STEPCOEF	"|FirstStepCoef:"
#define MTCL_OPT_PRECCOUT	"|CostPrecision:"
#define MTCL_OPT_AFFICH  	"|AffichageEcran:"
#define MTCL_OPT_IMPRIM  	"|ConvergenceCurves:"
#define MTCL_OPT_RESULT  	"|Results:"
#define MTCL_BLOCKSIZE 		"|Blocksize:"
#define MTCL_FREQUENCY 		"|Frequency:"
#define MTCL_SOLVERDIR 		"|SolverScratchDir:"

#endif /* __MOTSCLES__ */










