/* MOD_preparer_msh.h CADOE  */
/*
 * MOD_preparer_msh.h
 *
 * $Id: MOD_preparer_msh.h,v 1.5 2009/11/13 16:13:02 jtm Exp $
 *   
 * HISTORY
 *   
 *   06/21/00 16:30 <       Brian Jantzen> Rel:ms8m1    SCCA:74307  Delta:81.2
 */

#ifndef __modpreparermsh__
#define __modpreparermshh__ 1

/*#ifdef __cplusplus
extern "C" {
#endif*/

extern T_statut MOD_preparer_msh( T_Modele * );
extern T_statut MOD_preparer_donnees_msh( T_Mesh * );
extern int      MOD_get_dimension_element ( T_Element **, int, int *, T_statut * );
/*extern T_statut	MOD_connecter_noeud_element ( T_Mesh *mesh, int * );*/
  extern T_statut	MOD_connection_noeud_element ( int nb_element, T_Element **element );
  extern void	MSH_set_noeud_primaire ( T_Mesh *mesh );
  extern T_statut MOD_connection_noeud_element_from_liste ( T_liste *lele );
  extern double MOD_eval_taille_maillage ( T_Mesh *mesh );

/*#ifdef __cplusplus
}
#endif*/

#endif
