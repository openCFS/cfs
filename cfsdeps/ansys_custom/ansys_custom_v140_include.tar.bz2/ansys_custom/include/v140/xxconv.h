
/*
 *    author/date: yu-hua ting/04-02-94
 *
 *    primary function:
 *
 *
 *      Header for the Interface to SHAPES "conversion among 
 *      different geometry identifiers" routines
 *
 *    secondary function:
 *
 *        none
 *
 *    routines included:
 *
 *
 *    history
 *
 *        none
 *
 *    comments:
 *
 *        none
 *
 *    Notice - This file contains ANSYS Confidential information ***
 *
 */
/* 
 * *** copyright(c) 2011 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */

/****************************************************************************
 *    create a geom from a geom_id                                          *
 ****************************************************************************/


      extern xGEOM xGmFromId_xox ansPROTO((
             xGEOM_ID gm_id,      /* I    geom_id                                   */ 
             INT *iretp));        /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                              */


/****************************************************************************
 *    convert a geom to a geom_id                                           *
 ****************************************************************************/


      extern xGEOM_ID xGmToId_xox ansPROTO((
             xGEOM gm,           /* I    geom                                       */ 
             INT *iretp));       /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                              */

/****************************************************************************
 *    create a geom list from a geom_id list                                *
 ****************************************************************************/


      extern xLIST xListGmFromId_xox ansPROTO((
             xINT_LIST gm_id_list,/* I    list of geom_ids                          */ 
             xTAG tag,            /* I    heap tag                                  */
             INT *iretp));        /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                              */


/****************************************************************************
 *    convert a geom list to a geom_id list                                *
 ****************************************************************************/


      extern xINT_LIST xListGmToId_xox ansPROTO((
             xLIST gm_list,      /* I    list of geoms                              */ 
             xTAG tag,            /* I    heap tag                                  */
             INT *iretp));       /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                              */



/****************************************************************************
 *    create a frame from a frame_id                                          *
 ****************************************************************************/


      extern xFRAME xFrameFromId_xox ansPROTO((
             xFRAME_ID frame_id,  /* I    frame_id                                   */ 
             INT *iretp));        /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                              */


/****************************************************************************
 *    convert a frame to a frame_id                                           *
 ****************************************************************************/


      extern xFRAME_ID xFrameToId_xox ansPROTO((
             xFRAME frame,        /* I    frame                                      */ 
             INT *iretp));        /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                               */





/****************************************************************************
 *    create a geom from a group                                          *
 ****************************************************************************/


      extern xGEOM xGrpToGm_xox ansPROTO((
             xGROUP group,        /* I    group                                     */ 
             INT *iretp));        /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                              */



/****************************************************************************
 *    convert a geom to a group                                           *
 ****************************************************************************/


      extern xGROUP xGmToGrp_xox ansPROTO((
             xGEOM gm,            /* I    geom                                      */ 
             INT *iretp));        /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                               */






/****************************************************************************
 *    create a geom from a cell                                          *
 ****************************************************************************/


      extern xGEOM xCellToGm_xox ansPROTO((
             xCELL cell,        /* I    cell                                     */ 
             INT *iretp));      /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                              */




/****************************************************************************
 *    convert a geom to a cell                                           *
 ****************************************************************************/


      extern xCELL xGmToCell_xox ansPROTO((
             xGEOM gm,            /* I    geom                                      */ 
             INT *iretp));        /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                               */






/****************************************************************************
 *    create a geom id from a cell                                          *
 ****************************************************************************/


      extern xGEOM_ID xCellToId_xox ansPROTO((
             xCELL cell,        /* I    cell                                        */ 
             INT *iretp));        /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                              */


/****************************************************************************
 *    convert a geom id to a cell                                           *
 ****************************************************************************/


      extern xCELL xCellFromId_xox ansPROTO((
             xGEOM_ID gm_id,      /* I    geom                                      */ 
             INT *iretp));        /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                               */



/****************************************************************************
 *    create a vertex from a vertex_id                                          *
 ****************************************************************************/


      extern xVERT xVertFromId_xox ansPROTO((
             xVERTEX_ID vert_id,  /* I    vertex_id                                 */ 
             INT *iretp));        /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                              */


/****************************************************************************
 *    convert a vertex to a vertex_id                                           *
 ****************************************************************************/


      extern xVERTEX_ID xVertToId_xox ansPROTO((
             xVERT vert,          /* I    vertex                                     */ 
             INT *iretp));        /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                               */




/****************************************************************************
 *    get a bridge from a bridge id                                         *
 ****************************************************************************/


      extern xBRIDGE xBrgForPId_xox ansPROTO((
             xINT brg_id,         /* I    a bridge id                               */
             INT *iretp));        /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                              */


/****************************************************************************
 *    get a bridge id of a bridge                                           *
 ****************************************************************************/


      extern xINT xBrgGetPId_xox ansPROTO((
             xBRIDGE brg,         /* I    brgex                                     */ 
             INT *iretp));        /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                              */



