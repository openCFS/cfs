/* ---------------------------------------------------------------------- */
/* *** copyright(c) 2011 SAS IP, Inc.  All rights reserved.                                         */
/* *** ansys, inc.                                                        */
/* ---------------------------------------------------------------------- */


/*
* Author/date: Stefan Reh 09/09/99
* Primary function:
*    Header file for Probabilistic Design System
*/

#ifndef _PDS_C_TYPES_
#define _PDS_C_TYPES_

#include "pds_constants.h"

/* Deta structure for input random variables */
typedef union DistribParams{
    
struct 
{
   double  Mean;
   double  Std_Dev;
}Gaussian;

struct 
{
   double  Mean;
   double  Std_Dev;
   double  Min;
   double  Max;
}TrunGau;

struct 
{
   double    Mean;
   double    Std_Dev;
}Lognormal1;

struct 
{
   double    Mean;
   double    Std_Dev;
}Lognormal2;

struct 
{
   double    Low_Bound;
   double    Most_Likely_Point;
   double    High_Bound;
}Triangular;

struct 
{
   double    Low_Bound;
   double    High_Bound;
}Uniform;

struct 
{
   double    Exponent;
   double    Char_Value;
   double    Offset;
}Weibull;

struct 
{
   double    Decay_Value;
   double    Initial_Value;
}Exponential;

struct 
{
   double    Power_Value;
   double    Decay_Value;
}Gamma;

struct  
{
   double    Power_P;
   double    Power_Q;
   double    Low_Bound;
   double    High_Bound;
}Beta;

struct 
{
   double    Parm[PDS_DISTRIBUTIONPARAMS];
}General;

}DistribParms;


/* Data structure for random input variables */
typedef struct PDS_RvData
{
   char                   Rv_Name[PDS_PARMSIZE];
   double                 Current_value;
   int                    DistributionType;
   int                    NumParms;
   DistribParms           DisParms;
}PDS_RvData;



/* Data structure for input correlation coefficients */
typedef struct PDS_CorrPair
{
    int     low;
    int     high;
    double  coef;
}PDS_CorrPair;


/* Data structure for random output parameters */
typedef struct PDS_RpData
{
    char    Rp_Name[PDS_PARMSIZE];
    double  Current_value;
}PDS_RpData;


/* Data structure for the design of experiment levels of individual input variables for CCD */
typedef struct PDS_CCDLevels
{
    int     iValType;                    /* key indicating if levels are defined by 0=probabilty or 1=value      */
    int     iLvlOpt;                     /* key indicating if levels are 0=equidistant or 1=user-defined         */
    int     iLvlDefined[RSM_CCD_LEVELS]; /* flag if a level has been defined in the PDDOEL command (0=NO, 1=YES) */
    double  dLvlVals   [RSM_CCD_LEVELS]; /* the values for the levels as given by the user                       */
}PDS_CCDLevels;


/* Data structure for the design of experiment levels of individual input variables for BBM */
typedef struct PDS_BBMLevels
{
    int     iValType;                    /* key indicating if levels are defined by 0=probabilty or 1=value      */
    int     iLvlOpt;                     /* key indicating if levels are 0=equidistant or 1=user-defined         */
    int     iLvlDefined[RSM_BBM_LEVELS]; /* flag if a level has been defined in the PDDOEL command (0=NO, 1=YES) */
    double  dLvlVals   [RSM_BBM_LEVELS]; /* the values for the levels as given by the user                       */
}PDS_BBMLevels;


/* Data structure for the data in the results files */
typedef struct PDS_ResultsFileData
{
    /* Results file data */
    int     Loaded;
    int     NumSamples;
    int     *IterNum;
    int     *CyclNum;
    int     *LoopNum;
    int     *FailIdx;
    double  *InputSamples;
    double  *OutputSamples;

    /* Statistics of the results file data */
    double  *Mean;
    double  *Stdev;
    double  *Skew;
    double  *Kurt;
    double  *Min;
    double  *Max;
    
    /* results of the last PDPROB/PDPINV commands */
    double  *PdprobMed;
    double  *PdprobLow;
    double  *PdprobUpp;
    double  *PdpinvMed;
    double  *PdpinvLow;
    double  *PdpinvUpp;

    /* Correlation coefficients between the results data */
    double  *LinCorrCoef;
    double  *RnkCorrCoef;


}PDS_ResultsFileData;



/* Data structure for response sufaces */
typedef struct RS_PostSample
{
    /* Information about the structure of the data */
    int     Done;
    int     NumRSOut;
    int     *Idx2Rp;

    /* Post-processing samples */
    int     NumSamples;
    double  *InputSamples;
    double  *OutputSamples;
    
    /* Statistics of Post-samples */
    double  *Mean;
    double  *Stdev;
    double  *Skew;
    double  *Kurt;
    double  *Min;
    double  *Max;
    
    /* results of the last PDPROB/PDPINV commands */
    double  *PdprobMed;
    double  *PdprobLow;
    double  *PdprobUpp;
    double  *PdpinvMed;
    double  *PdpinvLow;
    double  *PdpinvUpp;

    /* Correlation coefficients between the results data */
    double  *LinCorrCoef;
    double  *RnkCorrCoef;

}RS_PostSample;

/* structure used for the Monte Carlo setting options for multiple probabilistic analyses */
typedef struct McsOptions
{
    int     VROpt;
    int     IntervalOpt;
    int     AutoStopOpt;
    double  AccMean;
    double  AccStdev;
    int     CheckFreq;
    int     SeedOption;
    long    iseed;
    long    lseed;
}McsOptions;

/* structure used for the Monte Carlo setting options for multiple probabilistic analyses */
typedef struct  RsmOptions
{
    int                ImportantRVOpt;
    int                num_imp;
    double             imp_value;
    PDS_CCDLevels      *CCDLevels;
    PDS_BBMLevels      *BBMLevels;
    int                rsm_loops;
}RsmOptions;

/* structure used for multiple probabilistic analyses */
typedef struct PDS_SoluSet
{
    char        SoluLab[PDS_SOLULABLENGTH];
    char        results_file_name[PDS_FILENAMELENGTH+1+PDS_EXTENSIONLENGTH]; /* file name + "_" + solution label + "." + extension */
    int         pds_method;
    int         num_iter;
    int         max_iter;
    int         num_cycl;
    int         max_cycl;
    int         num_loop;
    int         max_loop;
    int         num_tot_fail;
    int         max_tot_fail;
    int         num_cycl_fail;
    int         max_cycl_fail;
    int         parallel_option;

    McsOptions  McsOpts;
    RsmOptions  RsmOpts;
}PDS_SoluSet;


/* structure used for user's setting */
    
typedef struct PDS_UserSettings
{
            /*PDMETHOD*/
    int     pds_method;

            /* PDDMCS, PDLHS */
    int     num_sim;
    int     num_rep;
    int     VROpt;
    int     IntervalOpt;
    int     AutoStopOpt;
    double  AccMean;
    double  AccStdev;
    int     CheckFreq;
    int     SeedOption;
    long    iseed;
    long    lseed;
    
            /* PDBBM, PDCCD */
    double  ccd_plevels[RSM_CCD_LEVELS];
    double  bbm_plevels[RSM_BBM_LEVELS];
    int     ImportantRVOpt;
    int     num_imp;
    double  imp_value;
    int     rsm_loops;

            /*PDUSER*/
    char    user_samp_filename[PDS_FILEWITHDIRECTORY];
                
            /*PDEXE*/
    char    SoluLab[PDS_SOLULABLENGTH];
    int     max_cycl_fail;
    int     max_tot_fail;
    int     SampFileOpt;
    char    SampleCopyFilename[PDS_FILENAMELENGTH+1+PDS_EXTENSIONLENGTH];
                
            /*PDPAR*/
    int     parallel_option;

}PDS_UserSettings;

#endif /* _PDS_C_TYPES_ */

