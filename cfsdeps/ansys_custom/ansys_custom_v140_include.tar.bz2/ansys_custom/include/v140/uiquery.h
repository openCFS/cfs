/* 
 * *** copyright(c) 2011 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */
#ifndef QUERY_DEFS
#define QUERY_DEFS
#define MENU_TYPE   1001
#define MENU_LEVEL  1002
#define PANEL_STATUS 1003
#define DTABLE_STATUS 1004
#define MENU_VISIBLE 1005
#define MENU_ACTIVE 1006
#endif
