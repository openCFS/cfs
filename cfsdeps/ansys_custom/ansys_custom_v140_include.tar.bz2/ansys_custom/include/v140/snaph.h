/* 
 * *** copyright(c) 2011 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */
struct snap_struct {
     int     num;
     Widget  shell;
     Widget  swidget;
     Pixmap  snap_pix;
     int     height;
     int     width;
     Boolean snapover;
     char    name[81];
    };
