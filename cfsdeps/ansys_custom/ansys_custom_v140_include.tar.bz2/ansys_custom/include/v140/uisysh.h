/* ********************************** */
/* *** copyright(c) 2010 SAS IP, Inc.  All rights reserved. *** */
/* *** ansys, inc.                *** */
/* ********************************** */

/***********************************************/
/******  include file used for ui routines *****/
/***********************************************/

#if defined(RS6000_SYS) || defined(HP32_SYS)
    /*  c routines called from fortran  */
#define canscleardbcb_     canscleardbcb
#define cansabbrcb_     cansabbrcb
#define cansfinishcb_     cansfinishcb
#define cansmnrfshcb_     cansmnrfshcb
#define canscursorcb_     canscursorcb
#define fanseuidlcommand_     fanseuidlcommand
#define cfield_     cfield
#define cline_      cline
#define copen_      copen
#define cclose_     cclose
#define clcpth_     clcpth
#define cpanld_     cpanld
#define cpanup_     cpanup
#define cpanst_     cpanst
#define cpuinfo_    cpuinfo
#define cpuiqr_     cpuiqr
#define cstkp1_     cstkp1
#define ttabld_     ttabld
#define ttabup_     ttabup
#define ttabst_     ttabst
#define dtabld_     dtabld
#define dtabup_     dtabup
#define dtabst_     dtabst
#define custld_     custld
#define custup_     custup
#define custst_     custst
#define rconld_     rconld
#define rconup_     rconup
#define rconst_     rconst
#define cread_      cread
#define cwrite_     cwrite
#define cpstac_     cpstac
#define apromp_     apromp
#define kpromp_     kpromp
#define cprompt_    cprompt
#define pminit_     pminit
#define mnoptc_     mnoptc
#define mnopto_     mnopto
#define mnmenc_     mnmenc
#define mnmeno_     mnmeno
#define uiiqr_      uiiqr
#define uiinf_      uiinf
#define mnrm_       mnrm
#define pickst_     pickst
#define xb_output_errors_ xb_output_errors
#define query_pickst_     query_pickst
#define get_rst_files_    get_rst_files
#define qexit_picker_  qexit_picker
#define lpickst_    lpickst
#define rpickst_    rpickst
#define gr_undraw_picker_  gr_undraw_picker
#define mpick_get_  mpick_get
#define pickiqr_    pickiqr
#define lpickiqr_   lpickiqr
#define uiloop_     uiloop
#define graphic_colors_ graphic_colors
#define dynamicpromptc_ dynamicpromptc
#define uw_create_  uw_create
#define uw_destroy_ uw_destroy
#define uw_clear_   uw_clear
#define uw_title_   uw_title
#define uw_color_   uw_color
#define uw_tone_    uw_tone
#define uw_move_    uw_move
#define uw_line_    uw_line
#define uw_area_    uw_area
#define uw_text_    uw_text
#define uw_point_   uw_point
#define uw_lsize_   uw_lsize
#define uw_tsize_   uw_tsize
#define uw_norm_    uw_norm
#define uw_xor_     uw_xor
#define uw_flush_   uw_flush
#define uw_save_    uw_save
#define uw_strt_    uw_strt
#define uw_pick_    uw_pick
#define uw_posit_   uw_posit
#define uw_inqr_    uw_inqr
#define uw_itodp_   uw_itodp
#define uw_dptoi_   uw_dptoi
#define fontpanel_  fontpanel
#define cmappanel_  cmappanel
#define cmapevnt_   cmapevnt
#define gr_anim_inqr_ gr_anim_inqr
#define pixpan_     pixpan
#define sx_eval_load_f2c_ sx_eval_load_f2c
#define editfilec_  editfilec
#define uiprstc_    uiprstc
#define setui_colors_ setui_colors
#define uicmap_     uicmap
#define logo_image_ logo_image
#define logo_zini_  logo_zini
#define logo_zget_  logo_zget
#define gr_tbar_rnew_ gr_tbar_rnew
#define dispatch_events_ dispatch_events
#define abflush_    abflush
#define abinqr_     abinqr
#define abmanage_   abmanage
#define abmap_      abmap
#define abunmap_    abunmap
#define abupdate_   abupdate
#define nlistcvrt_  nlistcvrt
#define performraytrace_ performraytrace
#define set_ray_values_  set_ray_values
#define set_dyn_btn_ordr_ set_dyn_btn_ordr
#define setcflgsfromftn_ setcflgsfromftn
#define getcflgsfromftn_ getcflgsfromftn
#define snd_rtrace_fnme_ snd_rtrace_fnme
#define nt_avi_stuff_ nt_avi_stuff
#define ui_prompt_  ui_prompt
#define uikill_     uikill
#define viewev_     viewev
#define erflsh_     erflsh
#define errpop_     errpop
#define mempop_     mempop
#define dlgdbg_     dlgdbg
#define vfypop_     vfypop
#define vfypopall_  vfypopall
#define askpop_     askpop
#define grcurs_     grcurs
#define setsoftcursor_   setsoftcursor
#define gtxdef_     gtxdef
#define xtbegn_     xtbegn
#define xtstat_     xtstat
#define workst_     workst
#define work_done_  work_done
#define work_stat_  work_stat
#define ps_start_   ps_start
#define ps_end_     ps_end
#define ps_getclr_  ps_getclr
#define makelistf_  makelistf
#define toolev_     toolev
#define exit_granule_ exit_granule
#define helpfree_ helpfree
#define uijobnam_   uijobnam
#define menu_collapse_ menu_collapse
#define psopntiff_  psopntiff
#define pswritifln_ pswritifln
#define pstifclose_ pstifclose
#define psopnjpeg_  psopnjpeg
#define pswrtjpeg_  pswrtjpeg
#define psclojpeg_  psclojpeg
#define psverjpeg_  psverjpeg
#define psopn_png_  psopn_png
#define pswrt_png_  pswrt_png
#define psclo_png_  psclo_png
#define psver_png_  psver_png
#define psopn_gif_  psopn_gif
#define pswrt_gif_  pswrt_gif
#define psclo_gif_  psclo_gif
#define gr_tnam_info_ gr_tnam_info
#define gr_imag_rset_ gr_imag_rset
#define fram_imag_  fram_imag
#define txtr_imag_33_ txtr_imag_33
#define txtr_inqr_33_ txtr_inqr_33
#define get_back_rgb_ get_back_rgb
#define xstart_     xstart
#define pkdata_     pkdata
#define query_pkdata_     query_pkdata
#define anno3d_pkdata_     anno3d_pkdata
#define anno3d_prompt_     anno3d_prompt
#define anno3d_window_     anno3d_window
#define anno3d_exit_f_     anno3d_exit_f
#define rpkdata_    rpkdata
#define nonui_misc_ nonui_misc
#define nonui_help_ nonui_help
#define nonui_pick_ nonui_pick
#define ui_misc_    ui_misc
#define ui_set_xywh_    ui_set_xywh
#define ui_help_    ui_help
#define ui_image_   ui_image
#define ui_splash_  ui_splash
#define help_stack_ help_stack
#define showhelpfile_ showhelpfile
#define reset_colors_ reset_colors
#define point_add_    point_add
#define point_remove_ point_remove
#define gr_flush_   gr_flush
#define gr_resize_  gr_resize
#define gr_wnsize_  gr_wnsize
#define usrlib_ usrlib
#define ext_push_ ext_push
#define ext_pop_ ext_pop
#define shrset_ shrset
#define ansfat_ ansfat
#define dptochc_    dptochc
#define cansapiinit_ cansapiinit
#define fbuttonsetparam_ fbuttonsetparam
    /*  fortran routines called from c  */
#define gr_inqr_alload_ gr_inqr_alload
#define gr_inqr_esfload_  gr_inqr_esfload
#define gr_inqr_ndload_ gr_inqr_ndload
#define gr_node_xyz_ gr_node_xyz
#define gr_elem_xyz_ gr_elem_xyz
#define absetupc_  absetupc
#define abchekc_  abchekc
#define abfinish_  abfinish
#define sx_eval_xfer_f_    sx_eval_xfer_f
#define ptdraw_facet_bgn_ ptdraw_facet_bgn
#define ptdraw_facet_lst_ ptdraw_facet_lst
#define ptdraw_facet_plt_ ptdraw_facet_plt
#define ptdraw_facet_end_ ptdraw_facet_end
#define getelmshp_ getelmshp
#define cpardef_  cpardef
#define qpicksel_ qpicksel
#define lsgpar_ lsgpar
#define argpar_ argpar
#define vlgpar_ vlgpar
#define anglen_ anglen
#define anglek_ anglek
#define cargst_ cargst
#define expand_ expand
#define epkmax_ epkmax
#define dynamicprompt_ dynamicprompt
#define mncb_   mncb
#define csyscb_ csyscb
#define quitcb_ quitcb
#define pickcb_ pickcb
#define ftiqr_  ftiqr
#define fpiqr_  fpiqr
#define anptdraw_ anptdraw
#define ptdraw_ ptdraw
#define rsdraw_ rsdraw
#define rsconv_ rsconv
#define rsplotit_ rsplotit
#define ctoout_ ctoout
#define findwn_ findwn
#define mninit_ mninit
#define grphst_ grphst
#define d2visl_ d2visl
#define getgrn_ getgrn
#define icmdan_ icmdan
#define icmdan_grn_ icmdan_grn
#define idxpth_ idxpth
#define anoinf_ anoinf
#define anoinq_ anoinq
#define wjobinqr_ wjobinqr
#define systim_ systim
#define sysyr_  sysyr
#define abrtst_ abrtst
#define inqdsp_ inqdsp
#define anocmd_ anocmd
#define anorun_ anorun
#define anoatr_ anoatr
#define anoend_ anoend
#define anonam_ anonam
#define picent_ picent
#define qry_picent_ qry_picent
#define mnrfsh_ mnrfsh
#define picloc_ picloc
#define picres_ picres
#define xyzset_ xyzset
#define cpset_  cpset
#define cmdbld_ cmdbld
#define cpval_  cpval
#define cphlp_  cphlp
#define cstkpr_ cstkpr
#define cllbck_ cllbck
#define d2icv_  d2icv
#define icnvzz_ icnvzz
#define d2xor_  d2xor
#define d2gclr_ d2gclr
#define d2norm_ d2norm
#define d2save_ d2save
#define d2move_ d2move
#define d2draw_ d2draw
#define d2wind_ d2wind
#define d2conv_ d2conv
#define d2conv_them_ d2conv_them
#define convzz_ convzz
#define d2strt_ d2strt
#define d2rset_ d2rset
#define d2dseg_ d2dseg
#define getwhr_ getwhr
#define grinfo_ grinfo
#define grinqr_ grinqr
#define slsevl_ slsevl
#define gr_tbar_inqr_ gr_tbar_inqr
#define kwcont_ kwcont
#define d3rot_  d3rot
#define d3rot_them_ d3rot_them
#define d3rot_zlis_ d3rot_zlis
#define d3urot_ d3urot
#define anorot_ anorot
#define wpxinq_ wpxinq
#define wpinqr_ wpinqr
#define wpinfo_ wpinfo
#define wpshow_ wpshow
#define stkpxp_ stkpxp
#define stkpop_ stkpop
#define cmdprc_ cmdprc
#define mnprc_  mnprc
#define trnpic_ trnpic
#define trnpkr_ trnpkr
#define gscpar_ gscpar
#define gtabbr_ gtabbr
#define d2info_ d2info
#define dynsetcntr_ dynsetcntr
#define d2inqr_ d2inqr
#define setfnt_ setfnt
#define gr_back_info_ gr_back_info
#define gr_back_inqr_ gr_back_inqr
#define undocb_ undocb
#define ans_cmap_ ans_cmap
#define ans_d2updt_ ans_d2updt
#define d2rgb_  d2rgb
#define d2char_ d2char
#define uilocl_ uilocl
#define wplocl_ wplocl
#define wpconv_ wpconv
#define d2rfsh_ d2rfsh
#define d3rfsh_ d3rfsh
#define d3area_ d3area
#define wrxdef_ wrxdef
#define wp2glo_ wp2glo
#define plotit_ plotit
#define expown_ expown
#define pswrit_ pswrit
#define pswrtf_ pswrtf
#define jpeg_inqr_ jpeg_inqr
#define psjpeg_ psjpeg
#define ps_png_ ps_png
#define ps_gif_ ps_gif
#define uilist_ uilist
#define rubrpk_ rubrpk
#define rbdone_ rbdone
#define srubpk_ srubpk
#define erubpk_ erubpk
#define mcinqr_ mcinqr
#define mcinfo_ mcinfo
#define d3dbuf_ d3dbuf
#define uiinqr_ uiinqr
#define uiinfo_ uiinfo
#define evalc_  evalc
#define parevc_  parevc
#define uixstk_  uixstk
#define heapdscfree_  heapdscfree
#define heapdscaddr_  heapdscaddr
#define heapgetaddr_  heapgetaddr
#define pkanno_  pkanno
#define pkentg_  pkentg
#define pkentr_  pkentr
#define ls_loop_  ls_loop
#define ar_shel_  ar_shel
#define zoomsc_  zoomsc
#define gettit_  gettit
#define psfnam_ psfnam
#define utlrev_ utlrev
#define utlmle_ utlmle
#define wtitlset_ wtitlset
#define wrinqr_ wrinqr
#define syflsh_ syflsh
#define prdiqr_ prdiqr
#define ptdraw_them_ ptdraw_them
#define ptdraw_comp_ ptdraw_comp
#define ptdraw_facet_ ptdraw_facet
#define plot_them_  plot_them
#define meshtool_keys_ meshtool_keys
#define parreturn_ parreturn
#define statusreturn_ statusreturn
#define modinqr_ modinqr
#define modinfo_ modinfo
#define anszzz_ anszzz
#define ansgui_ ansgui
#define ansend_ ansend
#define ender_ ender
#define d2zo33_ d2zo33
#define d2cv33_ d2cv33
#define d2cv33_them_ d2cv33_them
#define htmlgui_ htmlgui
#define anspartyp_ anspartyp
#define dimln3d_  dimln3d
#define an3dlin_  an3dlin
#define an3dspool_  an3dspool
#define qry_csys_  qry_csys
#define gtinitcnd_ gtinitcnd
#define gr_inqr_bdyld_ gr_inqr_bdyld
#define gtfrce_   gtfrce
#define gtcnst_   gtcnst
#define getnod_   getnod
#define getkp2_   getkp2
#define elmgct_   elmgct
#define anglin3d_ anglin3d
#define anno3d_ixy2view_ anno3d_ixy2view
#define anno3d_xy2view_ anno3d_xy2view
#endif


#if defined(WATCOMC_SYS) \
    || defined(PCWINNT_SYS)
    /*  c routines called from fortran  */
#define canscleardbcb_     CANSCLEARDBCB
#define cansabbrcb_     CANSABBRCB
#define cansfinishcb_     CANSFINISHCB
#define cansmnrfshcb_     CANSMNRFSHCB
#define canscursorcb_     CANSCURSORCB
#define fanseuidlcommand_     FANSEUIDLCOMMAND
#define cfield_     CFIELD
#define cline_      CLINE
#define copen_      COPEN
#define cclose_     CCLOSE
#define clcpth_     CLCPTH
#define cpanld_     CPANLD
#define cpanup_     CPANUP
#define cpanst_     CPANST
#define cpuinfo_    CPUINFO
#define cpuiqr_     CPUIQR
#define cstkp1_     CSTKP1
#define ttabld_     TTABLD
#define ttabup_     TTABUP
#define ttabst_     TTABST
#define dtabld_     DTABLD
#define dtabup_     DTABUP
#define dtabst_     DTABST
#define custld_     CUSTLD
#define custup_     CUSTUP
#define custst_     CUSTST
#define rconld_     RCONLD
#define rconup_     RCONUP
#define rconst_     RCONST
#define cread_      CREAD
#define cwrite_     CWRITE
#define apromp_     APROMP
#define kpromp_     KPROMP
#define cprompt_    CPROMPT
#define pminit_     PMINIT
#define mnoptc_     MNOPTC
#define mnopto_     MNOPTO
#define mnmenc_     MNMENC
#define mnmeno_     MNMENO
#define uiiqr_      UIIQR
#define uiinf_      UIINF
#define mnrm_       MNRM
#define pickst_     PICKST
#define xb_output_errors_ XB_OUTPUT_ERRORS
#define query_pickst_     QUERY_PICKST
#define get_rst_files_    GET_RST_FILES
#define qexit_picker_  QEXIT_PICKER
#define lpickst_    LPICKST
#define rpickst_    RPICKST
#define gr_undraw_picker_  GR_UNDRAW_PICKER
#define mpick_get_  MPICK_GET
#define pickiqr_    PICKIQR
#define lpickiqr_   LPICKIQR
#define uiloop_     UILOOP
#define graphic_colors_ GRAPHIC_COLORS
#define dynamicpromptc_ DYNAMICPROMPTC
#define uw_create_  UW_CREATE
#define uw_destroy_ UW_DESTROY
#define uw_clear_   UW_CLEAR
#define uw_title_   UW_TITLE
#define uw_color_   UW_COLOR
#define uw_tone_    UW_TONE
#define uw_move_    UW_MOVE
#define uw_line_    UW_LINE
#define uw_area_    UW_AREA
#define uw_text_    UW_TEXT
#define uw_point_   UW_POINT
#define uw_lsize_   UW_LSIZE
#define uw_tsize_   UW_TSIZE
#define uw_norm_    UW_NORM
#define uw_xor_     UW_XOR
#define uw_flush_   UW_FLUSH
#define uw_save_    UW_SAVE
#define uw_strt_    UW_STRT
#define uw_pick_    UW_PICK
#define uw_posit_   UW_POSIT
#define uw_inqr_    UW_INQR
#define uw_itodp_   UW_ITODP
#define uw_dptoi_   UW_DPTOI
#define fontpanel_  FONTPANEL
#define cmappanel_  CMAPPANEL
#define cmapevnt_   CMAPEVNT
#define gr_anim_inqr_ GR_ANIM_INQR
#define pixpan_     PIXPAN
#define sx_eval_load_f2c_ SX_EVAL_LOAD_F2C
#define editfilec_  EDITFILEC
#define uiprstc_    UIPRSTC
#define setui_colors_ SETUI_COLORS
#define uicmap_     UICMAP
#define logo_image_ LOGO_IMAGE
#define logo_zini_  LOGO_ZINI
#define logo_zget_  LOGO_ZGET
#define gr_tbar_rnew_ GR_TBAR_RNEW
#define dispatch_events_ DISPATCH_EVENTS
#define abflush_    ABFLUSH
#define abinqr_     ABINQR
#define abmanage_   ABMANAGE
#define abmap_      ABMAP
#define abunmap_    ABUNMAP
#define abupdate_   ABUPDATE
#define nlistcvrt_  NLISTCVRT
#define performraytrace_ PERFORMRAYTRACE
#define set_ray_values_  SET_RAY_VALUES
#define set_dyn_btn_ordr_ SET_DYN_BTN_ORDR
#define setcflgsfromftn_ SETCFLGSFROMFTN
#define getcflgsfromftn_ GETCFLGSFROMFTN
#define snd_rtrace_fnme_ SND_RTRACE_FNME
#define nt_avi_stuff_ NT_AVI_STUFF
#define ui_prompt_  UI_PROMPT
#define uikill_     UIKILL
#define viewev_     VIEWEV
#define erflsh_     ERFLSH
#define errpop_     ERRPOP
#define mempop_     MEMPOP
#define dlgdbg_     DLGDBG
#define vfypop_     VFYPOP
#define vfypopall_  VFYPOPALL
#define askpop_     ASKPOP
#define grcurs_     GRCURS
#define setsoftcursor_   SETSOFTCURSOR
#define gtxdef_     GTXDEF
#define xtbegn_     XTBEGN
#define xtstat_     XTSTAT
#define workst_     WORKST
#define work_done_  WORK_DONE
#define work_stat_  WORK_STAT
#define ps_start_   PS_START
#define ps_end_     PS_END
#define ps_getclr_  PS_GETCLR
#define makelistf_  MAKELISTF
#define toolev_     TOOLEV
#define exit_granule_ EXIT_GRANULE
#define helpfree_ HELPFREE
#define uijobnam_   UIJOBNAM
#define menu_collapse_ MENU_COLLAPSE
#define psopntiff_  PSOPNTIFF
#define pswritifln_ PSWRITIFLN
#define pstifclose_ PSTIFCLOSE
#define psopnjpeg_  PSOPNJPEG
#define pswrtjpeg_  PSWRTJPEG
#define psclojpeg_  PSCLOJPEG
#define psverjpeg_  PSVERJPEG
#define psopn_png_  PSOPN_PNG
#define pswrt_png_  PSWRT_PNG
#define psclo_png_  PSCLO_PNG
#define psver_png_  PSVER_PNG
#define psopn_gif_  PSOPN_GIF
#define pswrt_gif_  PSWRT_GIF
#define psclo_gif_  PSCLO_GIF
#define gr_tnam_info_ GR_TNAM_INFO
#define gr_imag_rset_ GR_IMAG_RSET
#define fram_imag_  FRAM_IMAG
#define txtr_imag_33_ TXTR_IMAG_33
#define txtr_inqr_33_ TXTR_INQR_33
#define get_back_rgb_ GET_BACK_RGB
#define xstart_     XSTART
#define pkdata_     PKDATA
#define query_pkdata_ QUERY_PKDATA
#define anno3d_pkdata_ ANNO3D_PKDATA
#define anno3d_prompt_ ANNO3D_PROMPT
#define anno3d_window_ ANNO3D_WINDOW
#define anno3d_exit_f_ ANNO3D_EXIT_F
#define rpkdata_    RPKDATA
#define nonui_misc_ NONUI_MISC
#define nonui_help_ NONUI_HELP
#define nonui_pick_ NONUI_PICK
#define ui_misc_    UI_MISC
#define ui_set_xywh_ UI_SET_XYWH
#define ui_help_    UI_HELP
#define ui_image_   UI_IMAGE
#define ui_splash_  UI_SPLASH
#define help_stack_ HELP_STACK
#define showhelpfile_ SHOWHELPFILE
#define reset_colors_ RESET_COLORS
#define point_add_    POINT_ADD
#define point_remove_ POINT_REMOVE
#define playbackanimation_ PLAYBACKANIMATION
#define write_modal_avi_   WRITE_MODAL_AVI
#define bat_done_   BAT_DONE
#define prorun_     PRORUN
#define cdfxrun_     CDFXRUN
#define gr_flush_   GR_FLUSH
#define gr_resize_  GR_RESIZE
#define gr_wnsize_  GR_WNSIZE
#define mes_atherr_ MES_ATHERR
#define loadxx_     LOADXX
#define nt_messagebox_  NT_MESSAGEBOX
#define foriswinnt_ FORISWINNT
#define pctiffend_   PCTIFFEND
#define pstiffclose_ PSTIFFCLOSE
#define pctiffsetup_ PCTIFFSETUP
#define pctiffgclr_  PCTIFFGCLR
#define getansdir_ GETANSDIR
#define usrlib_ USRLIB
#define ext_push_ EXT_PUSH
#define ext_pop_ EXT_POP
#define shrset_ SHRSET
#define ispcmeta_ ISPCMETA
#define isprntr_ ISPRNTR
#define ansfat_ ANSFAT
#define dptochc_    DPTOCHC
#define cansapiinit_ CANSAPIINIT
#define fbuttonsetparam_ FBUTTONSETPARAM
    /*  fortran routines called from c  */
#define gr_inqr_esfload_ GR_INQR_ESFLOAD
#define gr_inqr_alload_ GR_INQR_ALLOAD
#define gr_inqr_ndload_ GR_INQR_NDLOAD
#define gr_node_xyz_  GR_NODE_XYZ 
#define gr_elem_xyz_  GR_ELEM_XYZ 
#define getelmshp_  GETELMSHP
#define absetupc_   ABSETUPC
#define abchekc_    ABCHEKC
#define abfinish_   ABFINISH
#define sx_eval_xfer_f_   SX_EVAL_XFER_F
#define ptdraw_facet_bgn_ PTDRAW_FACET_BGN
#define ptdraw_facet_lst_ PTDRAW_FACET_LST
#define ptdraw_facet_plt_ PTDRAW_FACET_PLT
#define ptdraw_facet_end_ PTDRAW_FACET_END
#define cpardef_    CPARDEF  
#define qpicksel_   QPICKSEL
#define lsgpar_     LSGPAR
#define argpar_     ARGPAR
#define vlgpar_     VLGPAR
#define anglen_     ANGLEN
#define anglek_     ANGLEK
#define cargst_     CARGST
#define expand_     EXPAND
#define epkmax_     EPKMAX
#define dynamicprompt_ DYNAMICPROMPT
#define mncb_       MNCB
#define csyscb_     CSYSCB
#define quitcb_     QUITCB
#define pickcb_     PICKCB
#define ftiqr_      FTIQR
#define fpiqr_      FPIQR
#define anptdraw_   ANPTDRAW
#define ptdraw_     PTDRAW
#define rsdraw_     RSDRAW
#define rsconv_     RSCONV
#define rsplotit_   RSPLOTIT
#define ctoout_     CTOOUT
#define findwn_     FINDWN
#define mninit_     MNINIT
#define grphst_     GRPHST
#define d2visl_     D2VISL
#define getgrn_     GETGRN
#define icmdan_     ICMDAN
#define icmdan_grn_ ICMDAN_GRN
#define idxpth_     IDXPTH
#define anoinf_     ANOINF
#define anoinq_     ANOINQ
#define wjobinqr_   WJOBINQR
#define systim_     SYSTIM
#define sysyr_      SYSYR
#define abrtst_     ABRTST
#define inqdsp_     INQDSP
#define anocmd_     ANOCMD
#define anorun_     ANORUN
#define anoatr_     ANOATR
#define anoend_     ANOEND
#define anonam_     ANONAM
#define picent_     PICENT
#define qry_picent_ QRY_PICENT
#define picloc_     PICLOC
#define picres_     PICRES
#define xyzset_     XYZSET
#define cpset_      CPSET
#define cmdbld_     CMDBLD
#define cpval_      CPVAL
#define cphlp_      CPHLP
#define cstkpr_     CSTKPR
#define cllbck_     CLLBCK
#define d2icv_      D2ICV
#define icnvzz_     ICNVZZ
#define d2xor_      D2XOR
#define d2gclr_     D2GCLR
#define d2norm_     D2NORM
#define d2move_     D2MOVE
#define d2draw_     D2DRAW
#define d2wind_     D2WIND
#define d2conv_     D2CONV
#define d2conv_them_ D2CONV_THEM
#define convzz_     CONVZZ
#define d2strt_     D2STRT
#define d2rset_     D2RSET
#define d2dseg_     D2DSEG
#define d2clut_     D2CLUT
#define getwhr_     GETWHR
#define grinfo_     GRINFO
#define grinqr_     GRINQR
#define slsevl_     SLSEVL
#define gr_tbar_inqr_ GR_TBAR_INQR
#define kwcont_     KWCONT
#define d3rot_      D3ROT
#define d3rot_them_ D3ROT_THEM
#define d3rot_zlis_ D3ROT_ZLIS
#define d3urot_     D3UROT
#define anorot_     ANOROT
#define wpxinq_     WPXINQ
#define wpinqr_     WPINQR
#define wpinfo_     WPINFO
#define wpshow_     WPSHOW
#define stkpxp_     STKPXP
#define stkpop_     STKPOP
#define cmdprc_     CMDPRC
#define mnprc_      MNPRC
#define mnrfsh_     MNRFSH
#define trnpic_     TRNPIC
#define trnpkr_     TRNPKR
#define gscpar_     GSCPAR
#define gtabbr_     GTABBR
#define d2info_     D2INFO
#define dynsetcntr_ DYNSETCNTR
#define d2inqr_     D2INQR
#define setfnt_     SETFNT
#define gr_back_info_ GR_BACK_INFO
#define gr_back_inqr_ GR_BACK_INQR
#define undocb_     UNDOCB
#define ans_cmap_   ANS_CMAP
#define ans_d2updt_ ANS_D2UPDT
#define d2rgb_      D2RGB
#define d2char_     D2CHAR
#define uilocl_     UILOCL
#define wplocl_     WPLOCL
#define wpconv_     WPCONV
#define d2rfsh_     D2RFSH
#define d3rfsh_     D3RFSH
#define d3area_     D3AREA
#define wrxdef_     WRXDEF
#define wp2glo_     WP2GLO
#define plotit_     PLOTIT
#define expown_     EXPOWN
#define pswrit_     PSWRIT
#define pswrtf_     PSWRTF
#define jpeg_inqr_  JPEG_INQR
#define psjpeg_     PSJPEG
#define ps_png_     PS_PNG
#define ps_gif_     PS_GIF
#define uilist_     UILIST
#define rubrpk_     RUBRPK
#define rbdone_     RBDONE
#define srubpk_     SRUBPK
#define erubpk_     ERUBPK
#define mcinqr_     MCINQR
#define mcinfo_     MCINFO
#define d3dbuf_     D3DBUF
#define uiinqr_     UIINQR
#define uiinfo_     UIINFO
#define evalc_      EVALC
#define parevc_     PAREVC
#define uixstk_     UIXSTK
#define heapdscfree_     HEAPDSCFREE
#define heapdscaddr_     HEAPDSCADDR
#define heapgetaddr_     HEAPGETADDR
#define pkanno_     PKANNO
#define pkentg_     PKENTG
#define pkentr_     PKENTR
#define ls_loop_    LS_LOOP
#define ar_shel_    AR_SHEL
#define zoomsc_     ZOOMSC
#define gettit_     GETTIT
#define psfnam_     PSFNAM
#define utlrev_     UTLREV
#define utlmle_     UTLMLE
#define wtitlset_   WTITLSET
#define mainan_     MAINAN
#define menusb_     MENUSB
#define sizezz_     SIZEZZ
#define d2spec_     D2SPEC
#define d2save_     D2SAVE
#define getntdrvn_        GETNTDRVN                        
#define uicmds_     UICMDS
#define ui_misc_    UI_MISC
#define ui_set_xywh_    UI_SET_XYWH
#define ui_help_    UI_HELP
#define ui_image_   UI_IMAGE
#define ui_splash_  UI_SPLASH
#define wrinqr_     WRINQR
#define syflsh_     SYFLSH
#define prdiqr_     PRDIQR
#define d2lugl_     D2LUGL
#define ptdraw_them_ PTDRAW_THEM
#define ptdraw_comp_ PTDRAW_COMP
#define ptdraw_facet_ PTDRAW_FACET
#define plot_them_  PLOT_THEM
#define meshtool_keys_ MESHTOOL_KEYS
#define parreturn_  PARRETURN
#define statusreturn_ STATUSRETURN
#define modinqr_ MODINQR
#define modinfo_ MODINFO
#define anszzz_ ANSZZZ
#define ansgui_ ANSGUI
#define htmlgui_ htmlgui
#define anspartyp_ ANSPARTYP
#define ansend_ ANSEND
#define ender_ ENDER
#define d2zo33_ D2ZO33
#define d2cv33_ D2CV33
#define d2cv33_them_ D2CV33_THEM
#define nt_grtypesav_  NT_GRTYPESAV
#define nt_grtyperes_  NT_GRTYPERES
#define dimln3d_  DIMLN3D
#define an3dlin_  AN3DLIN
#define an3dspool_  AN3DSPOOL
#define qry_csys_ QRY_CSYS
#define gtinitcnd_ GTINITCND
#define gr_inqr_bdyld_ GR_INQR_BDYLD
#define gtfrce_   GTFRCE
#define gtcnst_   GTCNST
#define getnod_   GETNOD
#define getkp2_   GETKP2
#define elmgct_   ELMGCT
#define anglin3d_ ANGLIN3D
#define anno3d_ixy2view_ ANNO3D_IXY2VIEW
#define anno3d_xy2view_ ANNO3D_XY2VIEW
#endif

#if defined(WATCOMC_SYS)
    /*  c routines called from fortran  */
#pragma aux CANSCLEARDBCB "^";
#pragma aux CFIELD "^";
#pragma aux CLINE "^";
#pragma aux COPEN "^";
#pragma aux CCLOSE "^";
#pragma aux CLCPTH "^";
#pragma aux CPANLD "^";
#pragma aux CPANUP "^";
#pragma aux CPANST "^";
#pragma aux CPUINFO "^";
#pragma aux CSTKP1 "^";
#pragma aux TTABLD "^";
#pragma aux TTABUP "^";
#pragma aux TTABST "^";
#pragma aux DTABLD "^";
#pragma aux DTABUP "^";
#pragma aux DTABST "^";
#pragma aux CUSTLD "^";
#pragma aux CUSTUP "^";
#pragma aux CUSTST "^";
#pragma aux RCONLD "^";
#pragma aux RCONUP "^";
#pragma aux RCONST "^";
#pragma aux CREAD "^";
#pragma aux CWRITE "^";
#pragma aux APROMP "^";
#pragma aux KPROMP "^";
#pragma aux CPROMPT "^";
#pragma aux PMINIT "^";
#pragma aux MNOPTC "^";
#pragma aux MNMENO "^";
#pragma aux MNOPTC "^";
#pragma aux MNMENO "^";
#pragma aux UIIQR "^";
#pragma aux UIINF "^";
#pragma aux MNRM "^";
#pragma aux PICKST "^";
#pragma aux QUERY_PICKST "^";
#pragma aux GET_RST_FILES "^";
#pragma aux LPICKST "^";
#pragma aux RPICKST "^";
#pragma aux GR_UNDRAW_PICKER "^";
#pragma aux MPICK_GET "^";
#pragma aux UILOOP "^";
#pragma aux GRAPHIC_COLORS "^";
#pragma aux DYNAMICPROMPTC "^";
#pragma aux UW_CREATE "^";
#pragma aux UW_DESTROY "^";
#pragma aux UW_CLEAR "^";
#pragma aux UW_TITLE "^";
#pragma aux UW_COLOR "^";
#pragma aux UW_TONE "^";
#pragma aux UW_MOVE "^";
#pragma aux UW_LINE "^";
#pragma aux UW_AREA "^";
#pragma aux UW_TEXT "^";
#pragma aux UW_POINT "^";
#pragma aux UW_LSIZE "^";
#pragma aux UW_TSIZE "^";
#pragma aux UW_NORM "^";
#pragma aux UW_XOR "^";
#pragma aux UW_FLUSH "^";
#pragma aux UW_SAVE "^";
#pragma aux UW_STRT "^";
#pragma aux UW_PICK "^";
#pragma aux UW_POSIT "^";
#pragma aux UW_INQR "^";
#pragma aux UW_ITODP "^";
#pragma aux UW_DPTOI "^";
#pragma aux FONTPANEL "^";
#pragma aux CMAPPANEL "^";
#pragma aux CMAPEVNT  "^";
#pragma aux GR_ANIM_INQR "^";
#pragma aux PIXPAN "^";
#pragma aux SX_EVAL_LOAD_F2C "^";
#pragma aux EDITFILEC "^";
#pragma aux UIPRSTC   "^";
#pragma aux SETUI_COLORS "^";
#pragma aux UICMAP "^";
#pragma aux LOGO_IMAGE "^";
#pragma aux LOGO_ZINI "^";
#pragma aux LOGO_ZGET "^";
#pragma aux GR_TBAR_RNEW "^";
#pragma aux DISPATCH_EVENTS "^";
#pragma aux ABFLUSH "^";
#pragma aux ABINQR "^";
#pragma aux ABMANAGE "^";
#pragma aux ABMAP "^";
#pragma aux ABUNMAP "^";
#pragma aux ABUPDATE "^";
#pragma aux PERFORMRAYTRACE "^";
#pragma aux SET_RAY_VALUES  "^";
#pragma aux SET_DYN_BTN_ORDR "^";
#pragma aux SETCFLGSFROMFTN  "^";
#pragma aux GETCFLGSFROMFTN  "^";
#pragma aux NT_AVI_STUFF "^";
#pragma aux UI_PROMPT "^";
#pragma aux UIKILL "^";
#pragma aux VIEWEV "^";
#pragma aux ERFLSH "^";
#pragma aux ERRPOP "^";
#pragma aux MEMPOP "^";
#pragma aux DLGDBG "^";
#pragma aux VFYPOP "^";
#pragma aux VFYPOPALL "^";
#pragma aux ASKPOP "^";
#pragma aux GRCURS "^";
#pragma aux SETSOFTCURSOR "^";
#pragma aux GTXDEF "^";
#pragma aux XTBEGN "^";
#pragma aux WORKST "^";
#pragma aux WORK_DONE "^";
#pragma aux WORK_STAT "^";
#pragma aux PS_START "^";
#pragma aux PS_END "^";
#pragma aux PS_GETCLR "^";
#pragma aux MAKELISTF "^";
#pragma aux TOOLEV "^";
#pragma aux EXIT_GRANULE "^";
#pragma aux HELPFREE "^";
#pragma aux UIJOBNAM "^";
#pragma aux MENU_COLLAPSE "^";
#pragma aux PSOPNTIFF "^";
#pragma aux PSWRITIFLN  "^";
#pragma aux PSTIFCLOSE  "^";
#pragma aux PSOPNJPEG "^";
#pragma aux PSWRTJPEG "^";
#pragma aux PSCLOJPEG "^";
#pragma aux PSVERJPEG "^";
#pragma aux PSOPN_PNG "^";
#pragma aux PSWRT_PNG "^";
#pragma aux PSCLO_PNG "^";
#pragma aux PSVER_PNG "^";
#pragma aux PSOPN_GIF "^";
#pragma aux PSWRT_GIF "^";
#pragma aux PSCLO_GIF "^";
#pragma aux GR_TNAM_INFO "^";
#pragma aux FRAM_IMAG "^";
#pragma aux TXTR_IMAG_33 "^";
#pragma aux TXTR_INQR_33 "^";
#pragma aux GET_BACK_RGB "^";
#pragma aux XSTART "^";
#pragma aux PKDATA "^";
#pragma aux QUERY_PKDATA "^";
#pragma aux ANNO3D_PKDATA "^";
#pragma aux ANNO3D_PROMPT "^";
#pragma aux ANNO3D_WINDOW "^";
#pragma aux ANNO3D_EXIT_F "^";
#pragma aux RPKDATA "^";
#pragma aux NONUI_MISC "^";
#pragma aux NONUI_HELP "^";
#pragma aux NONUI_PICK "^";
#pragma aux UI_MISC "^";
#pragma aux UI_HELP "^";
#pragma aux UI_IMAGE "^";
#pragma aux UI_SPLASH "^";
#pragma aux HELP_STACK "^";
#pragma aux SHOWHELPFILE "^";
#pragma aux RESET_COLORS "^";
#pragma aux POINT_ADD "^";
#pragma aux POINT_REMOVE "^";
#pragma aux GR_FLUSH  "^";
#pragma aux GR_RESIZE "^";
#pragma aux MES_ATHERR "^";
#pragma aux PCTIFFSETUP "^";
#pragma aux PCTIFFGCLR "^";
#pragma aux PCTIFFEND "^";
#pragma aux USRLIB "^";
#pragma aux EXT_PUSH "^";
#pragma aux EXT_POP "^";
#pragma aux SHRSET "^";
#pragma aux ANSFAT "^";
#pragma aux ISPCMETA  "^";
#pragma aux DPTOCHC "^";
#pragma aux CANSAPIINIT "^";
    /*  fortran routines called from c  */
#pragma aux GR_EFACE_XYZ  "^";
#pragma aux GR_INQR_ALLOAD "^";
#pragma aux GR_INQR_ESFLOAD "^";
#pragma aux GR_INQR_NDLOAD  "^";
#pragma aux GR_NODE_XYZ  "^";
#pragma aux CARGST "^";
#pragma aux EXPAND "^";
#pragma aux EPKMAX "^";
#pragma aux DYNAMICPROMPT "^";
#pragma aux MNCB "^";
#pragma aux CSYSCB "^";
#pragma aux QUITCB "^";
#pragma aux PICKCB "^";
#pragma aux FTIQR "^";
#pragma aux FPIQR "^";
#pragma aux ANPTDRAW "^";
#pragma aux PTDRAW "^";
#pragma aux RSDRAW "^";
#pragma aux RSCONV "^";
#pragma aux RSPLOTIT "^";
#pragma aux CTOOUT "^";
#pragma aux FINDWN "^";
#pragma aux MNINIT "^";
#pragma aux GRPHST "^";
#pragma aux D2VISL "^";
#pragma aux GETGRN "^";
#pragma aux ICMDAN "^";
#pragma aux ICMDAN_GRN "^";
#pragma aux IDXPTH "^";
#pragma aux MNRFSH "^";
#pragma aux ANOINF "^";
#pragma aux ANOINQ "^";
#pragma aux WJOBINQR "^";
#pragma aux SYSTIM "^";
#pragma aux SYSYR  "^";
#pragma aux ABRTST "^";
#pragma aux INQDSP "^";
#pragma aux ANOCMD "^";
#pragma aux ANORUN "^";
#pragma aux ANOATR "^";
#pragma aux ANOEND "^";
#pragma aux PICENT "^";
#pragma aux PICLOC "^";
#pragma aux PICRES "^";
#pragma aux XYZSET "^";
#pragma aux CPSET  "^";
#pragma aux CMDBLD "^";
#pragma aux CPVAL  "^";
#pragma aux CPHLP  "^";
#pragma aux CSTKPR "^";
#pragma aux CLLBCK "^";
#pragma aux D2ICV  "^";
#pragma aux D2XOR  "^";
#pragma aux D2GCLR "^";
#pragma aux D2NORM "^";
#pragma aux D2MOVE "^";
#pragma aux D2DRAW "^";
#pragma aux D2WIND "^";
#pragma aux D2CONV "^";
#pragma aux D2CONV_THEM "^";
#pragma aux D2STRT "^";
#pragma aux D2RSET "^";
#pragma aux D2DSEG "^";
#pragma aux GETWHR "^";
#pragma aux GRINFO "^";
#pragma aux GRINQR "^";
#pragma aux GR_TBAR_INQR "^";
#pragma aux KWCONT "^";
#pragma aux D3ROT  "^";
#pragma aux D3ROT_THEM "^";
#pragma aux D3ROT_ZLIS "^";
#pragma aux D3UROT "^";
#pragma aux ANOROT "^";
#pragma aux WPXINQ "^";
#pragma aux WPINQR "^";
#pragma aux WPINFO "^";
#pragma aux WPSHOW "^";
#pragma aux STKPXP "^";
#pragma aux STKPOP "^";
#pragma aux CMDPRC "^";
#pragma aux MNPRC "^";
#pragma aux TRNPIC "^";
#pragma aux TRNPKR "^";
#pragma aux GSCPAR "^";
#pragma aux GTABBR "^";
#pragma aux D2INFO "^";
#pragma aux D2INQR "^";
#pragma aux SETFNT "^";
#pragma aux GR_BACK_INFO "^";
#pragma aux GR_BACK_INQR "^";
#pragma aux UNDOCB "^";
#pragma aux ANS_CMAP "^";
#pragma aux ANS_D2UPDT "^";
#pragma aux D2RGB  "^";
#pragma aux D2CHAR "^";
#pragma aux UILOCL "^";
#pragma aux WPLOCL "^";
#pragma aux WPCONV "^";
#pragma aux D2RFSH "^";
#pragma aux D3RFSH "^";
#pragma aux D3AREA "^";
#pragma aux WRXDEF "^";
#pragma aux WP2GLO "^";
#pragma aux PLOTIT "^";
#pragma aux EXPOWN "^";
#pragma aux PSWRIT "^";
#pragma aux PSWRTF "^";
#pragma aux JPEG_INQR "^";
#pragma aux PSJPEG "^";
#pragma aux PS_PNG "^";
#pragma aux PS_GIF "^";
#pragma aux UILIST "^";
#pragma aux RUBRPK "^";
#pragma aux RBDONE "^";
#pragma aux SRUBPK "^";
#pragma aux ERUBPK "^";
#pragma aux MCINQR "^";
#pragma aux MCINFO "^";
#pragma aux D3DBUF "^";
#pragma aux UIINQR "^";
#pragma aux UIINFO "^";
#pragma aux EVALC "^";
#pragma aux PAREVC "^";
#pragma aux UIXSTK "^";
#pragma aux HEAPDSCFREE "^";
#pragma aux HEAPDSCADDR "^";
#pragma aux HEAPGETADDR "^";
#pragma aux PKANNO "^";
#pragma aux PKENTG "^";
#pragma aux PKENTR "^";
#pragma aux LS_LOOP "^";
#pragma aux AR_SHEL "^";
#pragma aux ZOOMSC "^";
#pragma aux GETTIT "^";
#pragma aux ANONAM "^";
#pragma aux PSFNAM "^";
#pragma aux UTLREV "^";
#pragma aux UTLMLE "^";
#pragma aux WTITLSET "^";
#pragma aux WRINQR "^";
#pragma aux SYFLSH "^";
#pragma aux D2SAVE "^";
#pragma aux prdiqr "^";
#pragma aux PTDRAW_THEM "^";
#pragma aux PTDRAW_COMP "^";
#pragma aux PTDRAW_FACET "^";
#pragma aux PLOT_THEM "^";
#pragma aux MESHTOOL_KEYS "^";
#pragma aux HTMLGUI "^";
#pragma aux ANSPARTYP "^";
#pragma aux DIMLN3D "^";
#pragma aux AN3DLIN "^";
#pragma aux AN3DSPOOL "^";
#pragma aux GETNOD  "^";
#pragma aux GETKP2  "^";
#pragma aux ELMGCT "^";
#pragma aux ANGLIN3D "^";
#pragma aux  ANNO3D_IXY2VIEW "^";
#pragma aux  ANNO3D_XY2VIEW "^";

#endif


/*       FUNCTION RETURN TYPE DECLARATION       */


#if !defined(PCWINNT_SYS)
/*  C routines called from FORTRAN  */
   INT  copen_(INT *unit, CHAR *fname, INT *form, INT len1);
   INT  cread_ (INT *unit, INT *loc, CHAR *buffer, INT *bsize, INT len1);
   INT  cwrite_(INT *unit, INT *loc, CHAR *buffer, INT *bsize, INT len1);
   INT  cclose_(INT *unit);
   INT  cfield_(INT *unit, INT *loc, CHAR *type, CHAR *string, INT *dblen,
                INT len1, INT len2);
   INT  cline_(INT *unit, INT *loc, CHAR *string, INT len1);
   INT  lpickiqr_(INT *Key);
   INT  pickiqr_(INT *Key);
   INT  uiiqr_();
   INT  cpuiqr_(INT *key);
   INT  dlgdbg_();
   void cprompt_(INT *key_apply);
   void ttabld_(INT *_kary, double *data_orig, double *data_mod, INT *_iorgnx, INT *_iorgny, INT *_iorgnz, INT *_maxx, INT *_maxy, INT *_maxz, INT *ititle, INT *_sflag, INT *_lflag, INT *irowlab, INT *icollab, INT *iplnlab);
   void dtabld_(INT *_kary, double *data_orig, double *data_mod, INT *_iorgnx, INT *_iorgny, INT *_iorgnz, INT *_maxx, INT *_maxy, INT *_maxz, INT *ititle, INT *_sflag, INT *_lflag, INT *irowlab, INT *icollab);
   void exit_granule_(void);
   void helpfree_(void);
   void canscleardbcb_(void);
   void cansabbrcb_(void);
   void cansfinishcb_(void);
   void cansmnrfshcb_(void);
   void canscursorcb_(void);
   void uijobnam_();
   void grcurs_(INT *key);
   void setsoftcursor_(INT *key);
   void grxdef_(INT *imenu, INT *key, INT *iw, INT *ih, INT *ix, INT *iy);
   void xtbegn_(void);
   void xtstat_(void);
   void dynamicpromptc_(INT *n, INT iara[]);
   INT  uw_create_(double *x, double *y, double *w, double *h);
   void uw_destroy_(INT *Hnd);
   void uw_clear_(INT *Hnd, INT *iaclr);
   void uw_title_(INT *Hnd, INT *title);
   void uw_color_(INT *Hnd, INT *kyagt, INT *iclr);
   void uw_tone_(INT *Hnd, INT *volume);
   void uw_move_(INT *Hnd, double *x, double *y);
   void uw_line_(INT *Hnd, double *x, double *y);
   void uw_area_(INT *Hnd, INT *nc, double (*xy)[2]);
   void uw_text_(INT *Hnd, double *x, double *y, INT *text);
   void uw_poINT_(INT *Hnd, double *x, double *y);
   void uw_lsize_(INT *Hnd, INT *width, INT *style);
   void uw_tsize_(INT *Hnd, INT *size);
   void uw_norm_(INT *Hnd, INT *percent);
   void uw_xor_(INT *Hnd, INT *mode);
   void uw_flush_(INT *Hnd);
   void uw_save_(INT *Hnd);
   void uw_strt_(INT *Hnd);
   void uw_pick_(INT *Hnd, double *x, double *y, INT *ib);
   void uw_posit_(INT *Hnd, double *x, double *y, INT *ib);
   INT  uw_inqr_(INT *Hnd, INT *type);
   void uw_itodp_(INT *Hnd, INT *ix, INT *iy, double *x, double *y);
   void uw_dptoi_(INT *Hnd, double *x, double *y, INT *ix, INT *iy);
   void fontpanel_();
   void cmappanel_();
   void cmapevnt_();
   INT  gr_anim_inqr_(INT *);
   void pixpan_();
   void sx_eval_load_f2c_(INT *,INT *,INT *,INT *,LONG *,LONG *,LONG *);
   void editfilec_();
   void uiprstc_();
   void setui_colors_();
   void uicmap_();
   INT  logo_image_();
   INT  logo_zini_();
   void logo_zget_();
   void gr_tbar_rnew_(INT *,INT *,INT *,INT *,INT *,INT *, INT [], INT *, INT *);
   void dispatch_events_(void);
   void abflush_(void);
   void abinqr_(INT *iop, INT *ival);
   void abmanage_(INT *icmp, INT *iman);
   void abmap_(void);
   void abunmap_(INT *technique);
   void abupdate_(INT *icmp, INT *ival);
   void nlistcvrt_(double*);
   void performraytrace_(void);
   void set_ray_values_(INT* , double*);
   void set_dyn_btn_ordr_(INT*);
   void setcflgsfromftn_(INT* , INT*);
   INT  getcflgsfromftn_(INT*);
   void snd_rtrace_fnme_(INT*, INT*);
   void nt_avi_stuff_(INT *, INT *, double *);
   void xb_output_errors_(void);
   void lpickst_(INT *igdesc, INT *iprom, INT *numreq, INT *nmn, DOUBLE *xyz, INT *nReturn, INT *kyrub, INT *kapl, INT *ihlp);
   void rpickst_(INT *igdesc, INT *iprom, INT *ihlp, INT *listloc);
   void pickst_(INT *igdesc, INT *iprom, INT *numreq, INT *nmn, INT *listloc, INT *nReturn, INT *dup, INT *krub, INT *korder, INT *kapl, INT *ihlp);
   void query_pickst_( INT *numreq, INT *nmn, INT *listloc, INT *nReturn, INT *dup, INT *krub, INT *korder, INT *kapl, INT *nselitms, INT *inprp7 , INT *icsys);
    INT get_rst_files_( INT *nmrry, INT *lngrry);
   void qexit_picker_(void);
   void gr_undraw_picker_(void);
   void mpick_get_(INT *n, INT *iidata);
   void vfypop_(INT *num_lines, INT *idata, INT *kgo);
   void vfypopall_(INT *num_lines, INT *idata, INT *kgo);
   void viewev_(void);
   void work_done_();
   void workst_();
   void clcpth_();
   void point_add_(INT *entadd);
   void point_remove_(INT *entrem);
   void erflsh_(void);
   void gr_flush_(void);
   void gr_resize_(INT *nn);
   void gr_wnsize_(INT []);
   void usrlib_(INT *ivect, INT *n, INT *err_return);
   INT ext_push_(char * str, INT len);
   INT ext_pop_(char *str, INT len);
   INT shrset_(void);
   void ansfat_(INT *);
   void dptochc(double*,char**,INT*);
   void cansapiinit_(void);
   void fbuttonsetparam_(INT*);
   void anno3d_pkdata_(INT*, INT*, INT*, double*, INT*);
   void anno3d_prompt_(INT*);
   INT  anno3d_window_(void);
   void anno3d_exit_f_(void);
   void psopnjpeg_(INT *, INT *, INT *, INT *, INT *);
   void pswrtjpeg_(INT *);
   void psclojpeg_(void);
   void psverjpeg_(INT *, INT *);
   void psopn_png_(INT *, INT *, INT *, INT *, INT *);
   void pswrt_png_(INT *);
   void psclo_png_(void);
   void psver_png_(INT *, INT *);
   void psopn_gif_(INT *, INT *, INT *, INT *, INT *);
   void pswrt_gif_(INT *);
   void psclo_gif_(void);
   void gr_tnam_info_( INT *, INT [], INT *);
   void gr_imag_rset_(void);
   void fram_imag_(double *, double *, double *, double *);
   INT  txtr_imag_33_( INT *, double *, double *);
   void txtr_inqr_33_( INT *, INT *, INT *);
   void get_back_rgb_( INT *, INT *, INT *, INT *, INT *);
/*  FORTRAN routines called from C  */
   INT   gr_inqr_alload_(INT *,INT *, INT *,double *,INT *, INT*,double *);
   INT   gr_inqr_esfload_(INT *,INT *,double *,double *,INT *,INT *,double *,INT *);
   INT   gr_inqr_ndload_(INT *, INT *,INT *,double *,INT *);
   void  gr_node_xyz_(INT *, double *,INT *,INT *);
   INT   gr_elem_xyz_(INT *, double *);
   INT   getelmshp_(INT *, double *);
   void  absetupc_(INT*,INT*,INT*,INT*);
   void  abchekc_(INT*,INT*,INT*,INT*);
   void  abfinish_(INT*);
   void  sx_eval_xfer_f_(INT*,INT*,double*,INT*,LONG*,LONG*,LONG*);
   void  ptdraw_facet_bgn_(INT*,INT*,INT*,double*);
   void  ptdraw_facet_lst_(INT*,
                           INT*,INT*,INT*,
                           INT*,INT*,double*,
                                INT*,float*,
                           INT*,INT*,INT*);
   void  ptdraw_facet_plt_(INT*,INT*,INT*,double*,INT*,INT*,INT*);
   void  ptdraw_facet_end_(void);
   void  cpardef_(INT *, INT *,INT* , double *,double *,INT *,char *);
   INT   qpicksel_(INT *,INT* , INT*);
   INT   lsgpar_(INT *, INT *, INT *, DOUBLE *);
   INT   argpar_(INT *, INT *, INT *, double *);
   INT   vlgpar_(INT *, INT *, INT *, double *);
   double  anglen_(INT *, INT *, INT *);
   double  anglek_(INT *, INT *, INT *);
   INT    elmgct_( INT *,  double*);
   void   an3dlin_( double * ,INT *,  double*, INT*, INT* , INT*);
   void   an3dspool_( double * ,INT *,  double*, INT*, INT* , INT*,INT*,INT*);
   void   qry_csys_(INT *,INT*);
   void   gtinitcnd_( INT * , INT * ,double * , INT* , INT*);
   INT    gr_inqr_bdyld_( INT * , INT *, INT* , double*, INT*, INT*);
   void   gtfrce_( INT * , INT *, INT * , double * ,INT* , INT*);
   void   gtcnst_( INT * , INT * , INT * , double * , INT* , INT*, INT*, INT*);
   void   dimln3d_( double* ,INT*);
   void   anglin3d_(double*,INT*,double*);
   void   anno3d_ixy2view_();
   void   anno3d_xy2view_();
   void   getnod_(INT* , double*,INT*,INT*);
   void   getkp2_(INT* , double* ,INT*,double*,INT* ,INT*);
   void cargst_(INT *, INT *);
   INT  mcinqr_();
   INT  mcinfo_();
   INT  wpinqr_();
   void wpinfo_();
   double wpxinq_();
   INT  anoinq_();
   void wjobinqr_();
   void systim_();
   void sysyr_();
   void abrtst_();
   INT  inqdsp_();
   void  slsevl_();
   INT  gr_tbar_inqr_();
   INT  grinfo_();
   INT  grinqr_();
   INT  kwcont_();
   INT  rbdone_();
   INT  uiinqr_();
   void anoend_();
   void anoinf_();
   void anocmd_();
   void anorun_();
   void anonam_();
   void cllbck_();
   void cmdbld_();
   void cmdprc_();
   void cphlp_();
   void cpset_();
   void cpval_();
   void d2conv_();
   void d2conv_them_();
   void convzz_();
   void d2strt_();
   void d2rset_();
   void d2dseg_();
   void d2draw_();
   void d2gclr_();
   void d2norm_();
   void d2icv_();
   void icnvzz_();
   void d2inqr_();
   void setfnt_();
   void gr_back_info_(INT *, INT *);
   INT  gr_back_inqr_(INT *);
   void undocb_();
   void ans_cmap_();
   void ans_d2updt_();
   void d2rgb_();
   void d2char_();
   void d2info_();
   void dynsetcntr_();
   void d2move_();
   void d2rfsh_();
   void d2visl_();
   void d2wind_();
   void d2xor_();
   void d3dbuf_();
   void d3rfsh_();
   void d3area_();
   void d3rot_();
   void d3rot_them_();
   void d3rot_zlis_();
   void d3urot_();
   void anorot_();
   void epkmax_();
   void erubpk_();
   void evalc_();
   void expown_();
   void findwn_();
   void ftiqr_();
   void getgrn_();
   void gettit_();
   void getwhr_();
   void grphst_();
   void gscpar_();
   void gtabbr_();
   void icmdan_();
   void icmdan_grn_();
   void idxpth_();
   void dynamicprompt_();
   void mncb_();
   void mninit_();
   void parevc_();
   void picent_();
   void qry_picent_();
   void picloc_();
   void picres_();
   void pkanno_();
   void pkentg_();
   void pkentr_();
   void ls_loop_();
   void ar_shel_();
   void plotit_();
   void pswrit_();
   void pswrtf_();
   INT  jpeg_inqr_();
   void psjpeg_();
   void ps_png_();
   void ps_gif_();
   void anptdraw_();
   void ptdraw_();
   void rsdraw_();
   void rsconv_();
   void rsplotit_();
   void ctoout_();
   void rubrpk_();
   void srubpk_();
   void stkpop_();
   void stkpxp_();
   void trnpic_();
   void trnpkr_();
   void uiinfo_();
   void uilist_();
   void uilocl_();
   void wplocl_();
   void wpconv_();
   void uixstk_();
   void heapdscfree_();
   void  heapdscaddr_();
   void  heapgetaddr_();
   void wp2glo_();
   void wpshow_();
   void wrxdef_();
   void xyzset_();
   void zoomsc_();
   void psfnam_();
   void utlrev_();
   INT  utlmle_();
   void d2save_();
   void wtitlset_();
   INT wrinqr_();
   INT syflsh_();
   INT prdiqr_();
   void ptdraw_them_();
   void ptdraw_comp_();
   void ptdraw_facet_();
   void plot_them_();
   void meshtool_keys_();
   void mnrfsh_();
   void parreturn_();
   void statusreturn_();
   INT modinqr_();
   INT modinfo_();
   void anszzz_();
   void ansgui_();
   void htmlgui_(INT *, INT *);
   INT anspartyp_(INT *, INT *);
   void ansend_();
   void ender_();
   void d2zo33_(INT *, INT *, INT *);
   void d2cv33_(double *, double *, INT *, INT *);
   void d2cv33_them_(INT *, double *, INT *);
#else
/*  C routines called from FORTRAN  */
   void CALLTYP ansfat_( INT *);
   INT  CALLTYP lpickiqr_( INT * );
   INT  CALLTYP pickiqr_( INT * );
   INT  CALLTYP uiiqr_( INT * );
   void CALLTYP cprompt_( INT * );
   INT  CALLTYP cpuiqr_( INT * );
   void CALLTYP exit_granule_( void );
   void CALLTYP helpfree_( void );
   void CALLTYP canscleardbcb( void );
   void CALLTYP cansabbrcb( void );
   void CALLTYP cansfinishcb( void );
   void CALLTYP cansmnrfshcb( void );
   void CALLTYP canscursorcb( void );
   void CALLTYP uijobnam_( void );
   void CALLTYP grcurs_( INT * );
   void CALLTYP setsoftcursor_( INT * );
   void CALLTYP grxdef_( INT *imenu, INT *key, INT *iw, INT *ih, INT *ix, INT *iy);
   void CALLTYP xtbegn_( void  );
   void CALLTYP xtstat_( void  );
   void CALLTYP xb_output_errors_( void );
   void CALLTYP rpickst_( INT *, INT *, INT *, INT * );
   void CALLTYP lpickst_( INT *, INT *, INT *, INT *, double *,
                          INT *, INT *, INT * , INT *);
   void CALLTYP pickst_( INT *, INT *, INT *, INT *, INT *, INT *,
                         INT *, INT *, INT *, INT *, INT * );
   void CALLTYP query_pickst_( INT *, INT *, INT *, INT *, INT *, INT *,
                               INT *, INT *, INT * , INT * , INT *);
   INT  CALLTYP get_rst_files_( INT *, INT * );
   void CALLTYP qexit_picker_(void);
   void CALLTYP gr_undraw_picker_( void );
   void CALLTYP vfypop_( INT *, INT [], INT * );
   void CALLTYP vfypopall_( INT *, INT [], INT * );
   void CALLTYP viewev_( void );
   void CALLTYP work_done_( void );
   void CALLTYP workst_( void );
   void CALLTYP clcpth_( INT [], INT [], INT *, INT * );
   void CALLTYP toolev_( void );
   void CALLTYP makelistf_( INT *, INT [], INT *, INT [], INT * );
   HWND CALLTYP cpanst_( INT [], INT [], INT * ,INT * );
   void CALLTYP pminit_( INT *, INT *, INT * );
   INT CALLTYP custst_(INT[], INT*, INT[], INT*, INT[], INT*, INT[],
                       INT[], INT*, INT*, INT*, INT[], INT*, INT*, INT[],
                       INT[], INT*, INT*, INT*, INT[], INT*, INT*, INT[],
                       INT[], INT*, INT*, INT*, INT[], INT*, INT*, INT[]);
   INT CALLTYP custld_(INT*, INT*, INT[], INT[], INT[], INT*);
   INT CALLTYP custup_(VOID);
   HANDLE CALLTYP rconst_(void);
   INT CALLTYP rconld_(INT*, INT*, INT[], INT*, INT*, INT[], INT[], INT[]);
   INT CALLTYP rconup_(void);
   void CALLTYP playbackanimation_( void );
   void CALLTYP write_modal_avi_( void );
   void CALLTYP point_add_( INT * );
   void CALLTYP point_remove_( INT * );
   void CALLTYP cpuinfo_( INT*, INT* );
   void CALLTYP mpick_get_( INT*, INT* );
   void CALLTYP reset_colors_( void );
   void CALLTYP erflsh_( void );
   void CALLTYP showhelpfile_(INT[]);
   void CALLTYP query_pkdata_( INT*, INT*, INT*, DOUBLE*, INT*,INT*,INT*, INT*);
   void CALLTYP anno3d_pkdata_(INT*, INT*, INT*, DOUBLE*, INT*);
   void CALLTYP anno3d_prompt_(INT*);
   INT  CALLTYP anno3d_window_(void);
   void CALLTYP anno3d_exit_f_(void);
   void CALLTYP rpkdata_( INT*, INT*, INT*, DOUBLE*, DOUBLE* );
   void CALLTYP ui_misc_( INT* );
   void CALLTYP ui_set_xywh_( INT*, INT*, INT*, INT*);
   void CALLTYP ui_help_(INT*, INT[]);
   void CALLTYP ui_image_(INT*, INT*, INT[]);
   void CALLTYP ui_splash_( void );
   void CALLTYP gr_flush_( void );
   void CALLTYP gr_resize_( INT * );
   void CALLTYP gr_wnsize_( INT [] );
   void CALLTYP mes_atherr_( INT[], INT[], INT[], INT[], INT*, INT*, INT*, INT *);
   void CALLTYP loadxx_( INT *, double (*)[256] );
   void CALLTYP nt_messagebox_ (INT *);
   INT  CALLTYP foriswinnt_( void );
   void CALLTYP dynamicpromptc_(INT *n, INT iara[]);
   INT  CALLTYP uw_create_(DOUBLE*,DOUBLE*,DOUBLE*,DOUBLE*);
   void CALLTYP uw_destroy_(INT*);
   void CALLTYP uw_clear_(INT*,INT*);
   void CALLTYP uw_title_(INT*,INT[]);
   void CALLTYP uw_color_(INT*,INT*,INT*);
   void CALLTYP uw_tone_(INT*,INT*);
   void CALLTYP uw_move_(INT*,DOUBLE*,DOUBLE*);
   void CALLTYP uw_line_(INT*,DOUBLE*,DOUBLE*);
   void CALLTYP uw_area_(INT*,INT*,DOUBLE[][2]);
   void CALLTYP uw_text_(INT*,DOUBLE*,DOUBLE*,INT[]);
   void CALLTYP uw_point_(INT*,DOUBLE*,DOUBLE*);
   void CALLTYP uw_lsize_(INT*,INT*,INT*);
   void CALLTYP uw_tsize_(INT*,INT*);
   void CALLTYP uw_norm_(INT*,INT*);
   void CALLTYP uw_xor_(INT*,INT*);
   void CALLTYP uw_flush_(INT*);
   void CALLTYP uw_save_(INT*);
   void CALLTYP uw_strt_(INT*);
   void CALLTYP uw_pick_(INT*,DOUBLE*,DOUBLE*,INT*);
   void CALLTYP uw_posit_(INT*,DOUBLE*,DOUBLE*,INT*);
   INT  CALLTYP uw_inqr_(INT*,INT*);
   void CALLTYP uw_itodp_(INT*,INT*,INT*,DOUBLE*,DOUBLE*);
   void CALLTYP uw_dptoi_(INT*,DOUBLE*,DOUBLE*,INT*,INT*);
   void CALLTYP fontpanel_(INT*);
   void CALLTYP cmappanel_(INT*,INT*);
   void CALLTYP cmapevnt_(INT*);
   INT  CALLTYP gr_anim_inqr_(INT *);
   void CALLTYP pixpan_(void);
   void CALLTYP sx_eval_load_f2c_(INT *,INT *,INT *,INT *,LONG *,LONG *,LONG *);
   void CALLTYP editfilec_(INT[],INT*);
   void CALLTYP uiprstc_(void);
   void CALLTYP setui_colors_(INT [16][3]);
   void CALLTYP uicmap_(INT*,INT*,DOUBLE*,DOUBLE*,DOUBLE*);
   INT  CALLTYP logo_image_ ( DOUBLE*, DOUBLE* );
   INT  CALLTYP logo_zini_ ( INT *, INT * );
   void CALLTYP logo_zget_ ( INT * );
   void CALLTYP gr_tbar_rnew_(INT *,INT *,INT *,INT *,INT *,INT *, INT [], INT *, INT *);
   void CALLTYP dispatch_events_( void );
   void CALLTYP abflush_( void );
   void CALLTYP abinqr_( INT *, INT * );
   void CALLTYP abmanage_( INT *, INT * );
   void CALLTYP abmap_( void );
   void CALLTYP abunmap_( INT * );
   void CALLTYP abupdate_( INT *, INT * );
   void CALLTYP nlistcvrt_(double*);
   void CALLTYP performraytrace_(void);
   void CALLTYP set_ray_values_(INT* , double*);
   void CALLTYP set_dyn_btn_ordr_(INT*);
   void CALLTYP setcflgsfromftn_(INT* , INT*);
   INT  CALLTYP getcflgsfromftn_(INT*);
   void CALLTYP snd_rtrce_fnme_(INT* , INT*);
   void CALLTYP nt_avi_stuff_(INT *, INT *, double *);
   void CALLTYP psopntiff_ (INT *, INT *, INT *, INT *, INT *);
   void CALLTYP pswritifln_ (INT *);
   void CALLTYP pstifclose_ (void);
   void CALLTYP pctiffsetup_ (INT *, INT *);
   void CALLTYP pctiffgclr_ (INT *,INT *,INT *,INT *,INT *);
   void CALLTYP pctiffend_ (void);
   void CALLTYP psopnjpeg_ (INT *, INT *, INT *, INT *, INT *);
   void CALLTYP pswrtjpeg_ (INT *);
   void CALLTYP psclojpeg_ (void);
   void CALLTYP psverjpeg_ (INT *, INT *);
   void CALLTYP psopn_png_ (INT *, INT *, INT *, INT *, INT *);
   void CALLTYP pswrt_png_ (INT *);
   void CALLTYP psclo_png_ (void);
   void CALLTYP psver_png_ (INT *, INT *);
   void CALLTYP psopn_gif_ (INT *, INT *, INT *, INT *, INT *);
   void CALLTYP pswrt_gif_ (INT *);
   void CALLTYP psclo_gif_ (void);
   void CALLTYP gr_tnam_info_(INT *, INT [], INT *);
   void CALLTYP gr_imag_rset_(void);
   void CALLTYP fram_imag_(double *, double *, double *, double *);
   INT  CALLTYP txtr_imag_33_( INT *, double *, double *);
   void CALLTYP txtr_inqr_33_( INT *, INT *, INT *);
   void CALLTYP get_back_rgb_( INT *, INT *, INT *, INT *,INT *);
   void CALLTYP getansdir_( INT[], INT *);
   void CALLTYP usrlib_(INT*, INT*, INT*); /* cwa */
   INT CALLTYP ext_push_(char *str, INT len);
   INT CALLTYP ext_pop_(char *str, INT len);
   INT CALLTYP shrset_( void );
   INT CALLTYP ispcmeta_( void );
   INT CALLTYP isprntr_( void );
   void CALLTYP dptochc(double*,char**,INT*);
   void CALLTYP cansapiinit_( void );
   void CALLTYP fbuttonsetparam_(INT*);
   INT CALLTYP copen_(INT *unit, CHAR *fname, INT len1, INT *form);
   INT CALLTYP cread_ (INT *unit, INT *loc, CHAR *buffer, INT len1, INT *bsize);
   INT CALLTYP cwrite_(INT *unit, INT *loc, CHAR *buffer, INT len1, INT *bsize);
   INT CALLTYP cfield_(INT *unit, INT *loc,
                       CHAR *type, INT len1, CHAR *string, INT len2,
                       INT *dblen);
   INT CALLTYP cline_(INT *unit, INT *loc, CHAR *string, INT len1);
   void CALLTYP canscleardbcb_(void);
   void CALLTYP cansabbrcb_(void);
   void CALLTYP cansfinishcb_(void);
   void CALLTYP cansmnrfshcb_(void);
   void CALLTYP canscursorcb_(void);

/*  FORTRAN routines called from C  */
   extern INT  CALLTYP gr_inqr_alload_( INT *,INT *,INT *, double*,INT *,INT *,double *);
   extern INT  CALLTYP gr_inqr_esfload_(INT *,INT *,double *,double *,INT *,INT *,double *,INT *);
   extern INT  CALLTYP gr_inqr_ndload_(INT *,INT *,INT *,double *,INT *);
   extern void CALLTYP gr_node_xyz_(INT *,double *, INT *, INT *);
   extern INT  CALLTYP gr_elem_xyz_(INT *,double *);
   extern INT  CALLTYP getelmshp_( INT *, double*);
   extern void CALLTYP absetupc_(INT*, INT*, INT*, INT*);
   extern void CALLTYP abchekc_(INT*, INT*, INT*, INT*);
   extern void CALLTYP abfinish_(INT*);
   extern void CALLTYP sx_eval_xfer_f_(INT*,INT*,double*,INT*,LONG*,LONG*,LONG*);
   extern void CALLTYP ptdraw_facet_bgn_(INT*,INT*,INT*,double*);
   extern void CALLTYP ptdraw_facet_lst_(INT*,
                                         INT*,INT*,INT*,
                                         INT*,INT*,float*,
                                              INT*,float*,
                                         INT*,INT*,INT*);
   extern void CALLTYP ptdraw_facet_plt_(INT*,INT*,INT*,double*,INT*,INT*,INT*);
   extern void CALLTYP ptdraw_facet_end_(void);
   extern void CALLTYP cpardef_( INT *, INT *, INT *, double * , double * , INT *, char *, INT *);
   extern INT  CALLTYP qpicksel_( INT *, INT* , INT*);
   extern INT  CALLTYP lsgpar_( INT *, INT * , INT *, DOUBLE*);
   extern INT  CALLTYP argpar_( INT *, INT * , INT *, double*);
   extern INT  CALLTYP vlgpar_( INT *, INT * , INT *, double*);
   extern INT   CALLTYP elmgct_( INT *,  double*);
   extern void  CALLTYP an3dlin_( double * ,INT *,  double*, INT*, INT* , INT*);
   extern void  CALLTYP an3dspool_( double * ,INT *,  double*, INT*, INT* , INT*, INT*, INT*);
   extern void  CALLTYP qry_csys_(INT* , INT*);
   extern void  CALLTYP  gtinitcnd_( INT * , INT * ,double * , INT* , INT*);
   extern INT   CALLTYP  gr_inqr_bdyld_( INT * , INT * ,INT * , double *, INT*, INT*);
   extern void  CALLTYP  gtfrce_( INT * , INT *, INT * , double * ,INT* , INT*);
   extern void  CALLTYP  gtcnst_( INT * , INT * , INT * , double * , INT* , INT*, INT*, INT*);
   extern void  CALLTYP dimln3d_( double* ,INT*);
   extern void  CALLTYP anglin3d_(double*,INT*,double*);
   extern void  CALLTYP anno3d_ixy2view_(INT *, INT *, INT *, double *);
   extern void  CALLTYP anno3d_xy2view_(INT *, double *, double *);
   extern void  CALLTYP getnod_(INT* , double*,INT*,INT*);
   extern void  CALLTYP getkp2_(INT* , double* ,INT*,double*,INT* ,INT*);
   extern double  CALLTYP anglen_( INT *, INT * , INT *);
   extern double  CALLTYP anglek_( INT *, INT * , INT *);
   extern void CALLTYP cargst_( INT *, INT * );
   extern INT  CALLTYP mcinqr_( INT * );
   extern INT  CALLTYP mcinfo_( INT *, INT * );
   extern INT  CALLTYP wpinqr_( INT * );
   extern void CALLTYP wpinfo_( INT *, INT * );
   extern double CALLTYP wpxinq_( INT * );
   extern INT  CALLTYP anoinq_( INT * );
   extern void CALLTYP wjobinqr_( INT [], INT * );
   extern void CALLTYP systim_( INT *, INT *, INT * );
   extern void CALLTYP sysyr_( INT *, INT *, INT * );
   extern void CALLTYP abrtst_( void );
   extern INT  CALLTYP inqdsp_( void );
   extern void CALLTYP slsevl_( INT * , double *, double *);
   extern INT  CALLTYP gr_tbar_inqr_( INT * );
   extern INT  CALLTYP grinfo_( INT *, INT * );
   extern INT  CALLTYP grinqr_( INT * );
   extern INT  CALLTYP kwcont_( INT [], INT *, INT [], INT * );
   extern INT  CALLTYP rbdone_( INT *, INT *, double * );
   extern INT  CALLTYP uiinqr_( INT * );
   extern void CALLTYP anoend_( void );
   extern void CALLTYP anoinf_( INT *, INT * );
   extern void CALLTYP anocmd_(INT *, double *, INT *, INT *);
   extern void CALLTYP anorun_(INT *, INT *, INT *, double *, INT *);
   extern void CALLTYP anonam_( INT *, INT *);
   extern void CALLTYP cllbck_( void );
   extern void CALLTYP cmdbld_( void );
   extern void CALLTYP cphlp_( INT *, INT * );
   extern void CALLTYP cpset_( INT *, INT *, INT [], INT * );
   extern void CALLTYP cpval_( INT *, INT [], INT *, INT * );
   extern void CALLTYP d2conv_( double *, double *, INT *, INT * );
   extern void CALLTYP d2conv_them_( INT *, double *, INT * );
   extern void CALLTYP convzz_( double *, double *, INT *, INT * );
   extern void CALLTYP d2strt_( void );
   extern void CALLTYP d2rset_( void );
   extern void CALLTYP d2dseg_( void );
   extern void CALLTYP d2draw_( double *, double * );
   extern void CALLTYP d2gclr_( INT * );
   extern void CALLTYP d2norm_( INT * );
   extern void CALLTYP d2icv_( INT *, INT *, double *, double * );
   extern void CALLTYP icnvzz_( INT *, INT *, double *, double * );
   extern void CALLTYP d2inqr_( INT *, INT * );
   extern void CALLTYP setfnt_( INT *, INT[8][65] );
   extern void CALLTYP gr_back_info_( INT *, INT * );
   extern INT  CALLTYP gr_back_inqr_( INT * );
   extern void CALLTYP undocb_( INT[], INT *, INT * );
   extern void CALLTYP ans_cmap_(INT *, INT*, INT *);
   extern void CALLTYP ans_d2updt_(INT *, INT *);
   extern void CALLTYP d2rgb_(INT *, double *, double *, double *);
   extern void CALLTYP d2char_(double *, double *);
   extern void CALLTYP d2info_( INT *, INT * );
   extern void CALLTYP dynsetcntr_( double *, double *, double *);
   extern void CALLTYP d2move_( double *, double * );
   extern void CALLTYP d2rfsh_( INT *, INT *, INT *, INT * );
   extern void CALLTYP d2xor_( INT *, INT * );
   extern void CALLTYP d2clut_( void );
   extern void CALLTYP d3dbuf_( INT *, INT * );
   extern void CALLTYP d3rfsh_( INT *, INT * );
   extern void CALLTYP d3area_( double [][3],INT *,double [][3],INT *,INT *);
   extern void CALLTYP d3rot_( double [], double [] );
   extern void CALLTYP d3rot_them_( INT *, double *, double * );
   extern void CALLTYP d3rot_zlis_( INT *, INT *, double [][3], double [] );
   extern void CALLTYP d3urot_( double [], double [] );
   extern void CALLTYP anorot_();
   extern void CALLTYP epkmax_( INT *, INT * );
   extern void CALLTYP erubpk_( INT *, INT *, double *, INT * );
   extern void CALLTYP evalc_( INT*, INT *, INT [], INT *, double [], INT * );
   extern void CALLTYP expown_( INT *, INT *,  INT *, INT * );
   extern void CALLTYP findwn_( INT [], INT * );
   extern void CALLTYP ftiqr_( INT *, INT *, INT [], INT *, INT *, INT [],
                               INT [], INT [], INT [] );
   extern void CALLTYP getgrn_( INT [] );
   extern void CALLTYP gettit_( INT [] );
   extern void CALLTYP getwhr_( INT [] );
   extern void CALLTYP grphst_( void );
   extern void CALLTYP gscpar_( INT *, INT *, INT *, INT [] );
   extern void CALLTYP gtabbr_( INT *, INT *, INT [], INT *, INT [] );
   extern void CALLTYP icmdan_( INT *, INT [] );
   extern void CALLTYP icmdan_grn_( INT *, INT [] );
   extern void CALLTYP idxpth_( INT *, INT [], INT * );
   extern void CALLTYP dynamicprompt_( INT *, INT []);
   extern void CALLTYP mncb_( INT *, INT *, INT * );
   extern void CALLTYP mninit_( INT *, INT * );
   extern void CALLTYP picent_( INT [], INT *, INT [], INT *, INT *, INT *,
                                INT *, INT *, INT *, INT *, INT *, INT [] );
   extern void CALLTYP qry_picent_( INT *);
   extern void CALLTYP picloc_( INT [], INT [], INT *, INT *, INT*, double *,
                                INT *, INT *, INT [] );
   extern void CALLTYP picres_( INT [], INT [], INT [], INT [] );
   extern void CALLTYP pkanno_( INT *, INT *, INT * );
   extern void CALLTYP pkentg_( INT *, INT *, INT * );
   extern void CALLTYP pkentr_( INT *, INT * );
   extern void CALLTYP ls_loop_( INT *, INT *, INT * );
   extern void CALLTYP ar_shel_( INT *, INT *, INT * );
   extern void CALLTYP plotit_( INT *, INT *, INT * );
   extern void CALLTYP anptdraw_( double *, INT * );
   extern void CALLTYP ptdraw_( double *, INT * );
   extern void CALLTYP rsdraw_( double *, INT *, INT *, INT * );
   extern void CALLTYP rsconv_( double *, INT *, INT * );
   extern void CALLTYP rsplotit_( double *, INT *, INT * );
   extern void CALLTYP ctoout_( INT [], INT * );
   extern void CALLTYP rubrpk_( INT *, INT *, double *, INT * );
   extern void CALLTYP srubpk_( INT *, INT *, double *, INT * );
   extern void CALLTYP trnpic_( INT *, double [], double [], INT * );
   extern void CALLTYP trnpkr_( INT *, double [], INT *, double [], double [], INT * );
   extern void CALLTYP uiinfo_( INT *, INT * );
   extern void CALLTYP uilist_( INT * );
   extern void CALLTYP uilocl_( INT *, INT *, double *, INT * );
   extern void CALLTYP wplocl_( INT *, INT *, INT *, double *, INT *, INT * );
   extern void CALLTYP wpconv_( INT *, INT *, double *, double * );
   extern void CALLTYP uixstk_( INT * );
   extern void CALLTYP wp2glo_( double [], double [] );
   extern void CALLTYP wpshow_( INT * );
   extern void CALLTYP xyzset_( INT *, INT *, double * );
   extern void CALLTYP zoomsc_( INT *, double *, double *, double *, double * );
   extern void CALLTYP utlrev_( INT [], INT * );
   extern INT  CALLTYP utlmle_( INT * );
   extern INT  CALLTYP mainan_( INT*, char*, INT );
   extern void CALLTYP menusb_( INT*, char*, INT );
   extern void CALLTYP sizezz_( INT * );
   extern void CALLTYP d2spec_( void );
   extern void CALLTYP d2save_( void );
   extern void CALLTYP getntdrvn_( INT *, INT [] );
   extern void CALLTYP uicmds_( INT *, INT [], INT * );
   extern INT  CALLTYP wrinqr_( INT * );
   extern void CALLTYP syflsh_( INT * );
   extern INT  CALLTYP prdiqr_( INT * );
   extern void CALLTYP mnrfsh_(void);
   extern void CALLTYP d2lugl_( void );
   extern void CALLTYP ptdraw_them_(INT *, INT *, double *, INT * );
   extern void CALLTYP ptdraw_comp_(INT *, INT *, INT *, double *, INT *, INT *);
   extern void CALLTYP ptdraw_facet_(INT *, INT *, INT *, double *,
                                     INT *, INT *, INT *);
   extern void CALLTYP plot_them_( INT *, INT *, INT *, INT *, INT * );
   extern void CALLTYP pswrit_( INT *, INT *, INT *, INT *, INT *,
                                INT * ,INT *, INT *, INT *, INT *);
   extern void CALLTYP pswrtf_( INT *, INT *, INT *, INT *, INT * ,INT *,INT *);
   extern void CALLTYP psfnam_( INT *, INT *, INT *);
   extern INT  CALLTYP jpeg_inqr_(INT *);
   extern void CALLTYP psjpeg_( INT *, INT *, INT *, INT *, INT * ,INT *,INT *);
   extern void CALLTYP ps_png_( INT *, INT *, INT *, INT *, INT * ,INT *,INT *);
   extern void CALLTYP ps_gif_( INT *, INT *, INT *, INT *, INT * ,INT *,INT *);
   extern void CALLTYP meshtool_keys_(INT *, INT *, INT *, INT *, INT *, INT *);
   extern void CALLTYP parreturn_( double * );
   extern void CALLTYP statusreturn_( double * );
   extern INT CALLTYP modinqr_( INT * );
   extern INT CALLTYP modinfo_( INT *, INT * );
   extern void CALLTYP anszzz_( INT * );
   extern void CALLTYP ansgui_( INT *, INT *, INT * );
   extern void CALLTYP htmlgui_( INT *, INT * );
   extern INT CALLTYP anspartyp_( INT *, INT * );
   extern void CALLTYP ansend_( void );
   extern void CALLTYP ender_( void );
   extern void CALLTYP d2zo33_( INT *, INT *, INT * );
   extern void CALLTYP d2cv33_( double *, double *, INT *, INT * );
   extern void CALLTYP d2cv33_them_( INT *, double *, INT * );
   extern INT  CALLTYP nt_grtypesav_( INT *);
   extern void CALLTYP nt_grtyperes_( INT *);
#endif
