/* ---------------------------------------------------------------------- */
/* *** copyright(c) 2010 SAS IP, Inc.  All rights reserved.                                         */
/* *** ansys, inc.                                                        */
/* ---------------------------------------------------------------------- */


/*    *** Notice - This file contains ANSYS Confidential information  ***      */

#ifndef _SX_ANSYS_UTILS_H_
#define _SX_ANSYS_UTILS_H_  1

/* === define data types used in the ANSYS meshing Toolkit. */

#ifndef EXTERNAL_LINK
#include "computer.h"
#include "cAnsMemInterface.h"
#include "cAns_printf.h"
#endif

#if !defined(EXTERNAL_COMPILE) && !defined(EXTERNAL_LINK)

/* === header files defining types for compiling within Ansys 5.X */

#include "float.h"
#include "globals.h"
#include "header.h"
#include "sysparh.h"

#endif


#ifdef __cplusplus
extern "C" {
#endif

extern void SX_error(char *cFile, int msg_id, int level, char* msg, double dpvec[], int dplen, char *cvar, int cvpnum);
extern void SX_ProgressBarInit( int iProcessId, char *cTitle, int iMask );
extern void SX_ProgressBarUpdate( int iProcessId, char *cTitle, int iPercentDone );
extern int  SX_ProgressBarCheckAbort( void );
extern void SX_ProgressBarFinish( int iProcessId );

extern void *SX_malloc(size_t n, long int iLine, char *cFile);
extern void SX_free(void *p, long int iLine, char *cFile);

extern int  SX_leftstrlen ( char *cString );
extern void SX_IQuickSort ( int iNumData, int *iInputData, int *iSortedData );
extern void SX_IQuickRank(int iNumData, int *iInputData, int *iRankVec);


#ifdef __cplusplus
}
#endif

#define Sx_malloc(n)                SX_malloc(n, __LINE__, __FILE__)
#define Sx_free(n)                  SX_free(n, __LINE__, __FILE__)

#endif  /* _SX_ANSYS_UTILS_H_ */
