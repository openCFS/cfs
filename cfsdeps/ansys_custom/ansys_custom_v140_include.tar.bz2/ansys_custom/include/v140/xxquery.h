

/*
 *    author/date: yu-hua ting/04-02-94
 *
 *    primary function:
 *
 *      Header for the Interface to SHAPES "Query" routines
 *
 *    secondary function:
 *
 *        none
 *
 *    routines included:
 *
 *
 *    history
 *
 *        none
 *
 *    comments:
 *
 *        none
 *
 *    Notice - This file contains ANSYS Confidential information ***
 *
 */
/* 
 * *** copyright(c) 2011 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */


/*
 *    query a geom for its dimension 
 */
      extern xINT xGmGetDim_xox ansPROTO((
             xGEOM_ID gm_id,      /* I    geom number of a geom                      */ 
             INT *iretp));        /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                               */


/*
 *    to determine if a geom is a valid geom or not
 */
      extern xINT xGeomP_xox ansPROTO((
             xGEOM_ID gm_id,      /* I    geom number of a geom                      */ 
             INT *iretp));        /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                               */

      

      


/*
 *    to determine if a geom is a null geom or not
 */
      extern xINT xNullGeomP_xox ansPROTO((
             xGEOM_ID gm_id,      /* I    geom number of a geom                      */ 
             INT *iretp));        /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                               */

/*
 *    query a cell geom list for a geom
 */
      extern xINT_LIST xGmFindCellGeoms_xox ansPROTO((
             xGEOM_ID gm_id,      /* I    geom number of a geom                      */ 
             INT *iretp));        /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                               */

/*
 *    query the non-manifold structure for a geom.
 *    returns != 0, if a non-manifold structure detected
 *            == 0, otherwise   
 */
      extern xINT xGmDetectNonManifold_xox ansPROTO((
             xGEOM_ID gm_id,      /* I    geom number of a geom                      */ 
             INT *iretp));        /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                               */


/*
 *    query  a cell for its range in parameter space of its map
 */
      extern VOID xCellFindPrmsRng_xox ansPROTO((
             xGEOM_ID gm_id,      /* I    geom number of a cell                      */ 
             DOUBLE range[],      /*   O  range of the parameter space of the cell   */
             INT *iretp));        /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                               */


/*
 *    evaluate point on underlying map for a parameter value
 */
      extern VOID xCellEvalPnt_xox ansPROTO((
             xGEOM_ID gm_id,      /* I    geom number of a cell                       */
             DOUBLE params[],     /* I    parameter to evaluate at                    */
             DOUBLE coord[],      /*   O  resulting coordinates in the geometry space */
             INT *iretp));        /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                                */

      

/*
 *    query a bridge for a pair of (sub_cell,sup_cell)
 */
      extern xINT xCellPairGetBrg_xox ansPROTO((
             xGEOM_ID gm_id_sub,  /* I    geom number of a sub_cell                  */
             xGEOM_ID gm_id_sup,  /* I    geom number of a sup_cell                  */
             INT *iretp));        /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                               */

/*
 *    query the relative orientation for a bridge
 */
      extern xINT xBrgGetOrien_xox ansPROTO((
             xINT brg_id,         /* I    a bridge id                                */
             INT *iretp));        /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                               */

