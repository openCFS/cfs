/* CADOE */
/**
 *	pel.h -- fonctions de l'objet propriete elementaire
 *   
 * HISTORY
 *   
 *   02/15/00 13:10 <       Brian Jantzen> Rel:ms8      SCCA:68558  Delta:8.3
 *   
 *   09/30/99 17:38 <         James Silva> Rel:ms8      SCCA:56512  Delta:8.2
 **/

#include "sx_CADOE_solver.h"
#ifndef __PEL_X_DEJA_INCLUS__
#define __PEL_X_DEJA_INCLUS__ 1

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

extern T_statut PEL_creer_prop_elem_entiere (int, int, T_prop_elem **);
extern T_statut PEL_creer_prop_elem_reelle (int, double, T_prop_elem **);
extern T_statut PEL_rechercher_elements( int, T_prop_elem*, T_modele*, IVEC** );
extern T_statut PEL_allouer_derivee( T_prop_elem * );

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif	 
