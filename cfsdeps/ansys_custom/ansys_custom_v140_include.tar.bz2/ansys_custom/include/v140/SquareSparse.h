/*****************************************************************************
 *                   Copyright (C) 1999 CMSoft                               *
 *                                                                           *
 *  These lines of code and declarations contain unpublished proprietary     *
 *  information of CMSoft. They may not be copied or duplicated in whole     *
 *  or part without prior authorization from CMSoft.                         *
 *                                                                           *
 *****************************************************************************/

#ifndef _SQUARE_SPARSE_MATRIX_H_
#define _SQUARE_SPARSE_MATRIX_H_

#include "SparseMatrix.h"

class FSSquareSparse : public FSSparseData, public FSOperator 
{
protected:
  double *_data;
  
public:
  FSSquareSparse(FSConnectivity *, DofSetArray *, ConstrainedDSA *c_dsa);
  FSSquareSparse(FSConnectivity *, DofSetArray *, int* rcn);
  ~FSSquareSparse();
  
  void mult(const double *rhs, double *result); // matrix-vector multiply
  void transposeMult(double *rhs, double *result);
  void multDiag(double *x, double *b);
  
  double diag( int dof ); // returns diagonal value of row dof in matrix
  void add(FullSquareMatrix &kel, int *dofs);
  void add(FSFullMatrix &kel, int *dofs);
  void zeroAll();
  void print();
  void WriteMatlab(FILE *fp);
  
  int  dim()      { return _numUncon;         }
  int  size()     { return _xunonz[_numUncon]; }
  int  row(int i) { return _unconstrNum[i];   }
  int  col(int i) { return _unconstrNum[i];   }
  
  double MemSize();
};

#endif
