/*******************************************************************************
 *
 *   SxSparse.h  --- Matrice Out Of Core
 *               
 * 
 * |Module:  
 *
 * |Description: 
 *
 * |Includes:	
 *        
 * |Auteur: Jean-Daniel Beley - Frederic Thevenon
 *
 * |Creation: Mars 2002
 *
 * |Version: $Id: SxSparse.h 478778 2011-05-29 21:05:42Z ftheveno $
 *
 * |Copyright:	Copyright(c)  2002
 *
 ********************************************************************************/
#ifndef __SXSPARSE_H__
#define __SXSPARSE_H__ 1

#ifdef __cplusplus

#include "SxSparseLig.h"
#include "sx_utilit.h"
#include "csparse.h"
#include "C_MatSp.h"
#include "BoeingItf.h"

#if defined (WINNT) || defined(WIN32)
#define Scratch_Files_Mode		(_O_RDWR|_O_CREAT|_O_TRUNC|_O_BINARY)
#define Scratch_Files_Read_Mode		(_O_RDWR|_O_BINARY)
#else
#define Scratch_Files_Mode		(O_RDWR|O_CREAT|O_TRUNC)
#define Scratch_Files_Read_Mode		(O_RDWR)
#endif

#define SEPARATEUR "==============================================\n"

typedef int (*T_fct_m2v)(int, int, int, int);

/*!
 * \class	C_OocMatrix
 *  \brief	This object define an High Level Sparse Matrix.
 *		
 *  \author	FT - JDB
 *  \version	1.0
 *  \date	2003-2005
 *  \bug	
 *  \warning	
 *
 *  \version 1.0 :       Initial Revision
 *
 *  \remark :	
 *
 *  \todo :
 *	- Create a High Level line Object C_Line, above the T_Ligne and T_lso
 *	- Put the row table as a C_Line array in the C_OocMatrix
 *	- Put the map of the nnz lines in the C_OocMatrix, to replace the hash table
 *	- Do the same thing for the Line Buffers
 *	- Create all the required virtual methods in the C_oocMatrix Object
 *	- modified the members to be protected ones, once the job is finished
 *	- Modify the code to use constructors/destructors, instead of LSO_alloc,
 *	  LIG_alloc, MSO_allouer, ...., and free functions
 *
 *	- Correctly compute the MemSize() value
 */

class C_OocMatrix : public C_SparseMat<double>
{
public :
  virtual     char *AffType() const { return (char *)"C_OocMatrix Type";}

  C_OocMatrix( int nb_fic, int nb_ddls, int numero, char *basename,
	       char **dirs, int *ier);
  virtual ~C_OocMatrix();

  // Methods to manage internal files

  //@{
  int		OpenFiles( int mode);
  int		OpenNewFiles( void) { return OpenFiles( Scratch_Files_Mode);}
  int		OpenScratchFiles( char *basename, char **dirs);
  int		CloseFiles( void);
  int		DeleteFiles( void);

  void		LoadInMemory( int *ier);
  //@}

  // Methods inherited from C_Mat level
  //@{
  int		MemSize(void)		const { return 0;}
  int		InCore(void)		{ return (in_core == 1);}

  virtual int	Mv( double alpha, C_Vec<double> &x, double beta, C_Vec<double> &y, char trans = 'N')
                  { CADOE_THROW(E_MethodNotDefined);}
  virtual int	MM( char TransA, char TransB, double alpha, C_Mat<double> &A,
		    C_Mat<double> &B,  double beta){ CADOE_THROW(E_MethodNotDefined);}
  //@}

  // Methods to acces to internal data

  //@{
  void		    setInCore(void);
  int		    Size( void)  { return 0;} // ===== Size in bytes ( to be developped)
  double	    Norm( void);
  double	    InfNrm(void)		const { return _InfNrm;}
  inline int	GetNum( void)		const { return numero;}
  inline int	GetNbFiles( void)	const { return nb_fic;}
  bool          Sym( void)		{ return ( unsym == 0);}
  Hyper		    NbVal( void)		{ return this->length;}
  int		    MaxLength( void)	{ return _MaxLength;}

  // ===== These 2 Methods are to be deleted soon ->

  bool          IsUnSym( void)		const { return ( unsym == 1);}
  int		    GetMaxLength( void)	const { return _MaxLength;}


  virtual int	BuildCompactRowTable( void);
  virtual bool	IsCompact( void)  { return (hash != NULL);}
  virtual int	Print( FILE *fout=stdout, int line=-1);
  virtual int	Print( char *nameFile, int ilig=-1, bool append=false) { return SUCCES;}

  virtual int	ReadLine( T_lso *line) = 0;
  virtual T_lso *GetRow( int idof, int *ir);
  T_lso		*EmptyLine( void) { return _EmptyLine;}
  virtual int	SplitRows( int nb_procs, int iproc, int *start, int *end, T_booleen *compact);

  virtual BCSINT GetRowIdx( int &iRow, BCSINT *JRow) {return 0;}

///! relative treshold, wrt the InfNrm of the matrix
  virtual void	FilterValues( double treshold = 1.E-16) { return;}
  //@}


  int nb_ddl;			/* Number of degrees of freedom */
  int nnz_rows;  		/* Actual number of rows in compact format */
  int numero;			///< Matrix id

  // ===== Members for OutOfCore Management

  int *fic;			/* scratch files */
  char **noms;			/* Names of the scratch files */
  int nb_fic;			/* Number of files */

  int	in_core;	/* 1 if the matrix is purely in-core */
  int	unsym;		/* 1 if the matrix is unsymmetric */
  int	length;			/* Total number of terms of the matrix */
  Hyper max_size;		/* Maximum in memory size */
  Hyper current_size;		/* Current in memory size */
  int	buffer_size;		/* Buffer size */

  // ===== Members for Norms Computations

  double norme;			/* Norm of the matrix */
  double _InfNrm;		///! Infinite norm
  double seuil;			/* Treshold for small terms */
  C_VecPi<double> vinorme;		/* Vector used for the norm */
  C_VecPi<double> vonorme;		/* A * Vinorme */

  int nb_buf, max_nb_buf;	/* Number of buffers */

  // ===== Members for lines

  map< int, T_lso *>	*hash;	///< Hash table from dof to pointer in the "rows" array
  T_lso			       **rows;	///< rows pointer

  // ===== Members for buffers

  T_lso_buffer		**buffers; ///< Array of All Buffers

  T_lso		*_EmptyLine;
};

struct T_adr_rel
{
  C_OocMatrix	*mat_ref;
  int		nb_ddl;
  int		**index;
};

/* Out-of-core sparse matrix taylor expansion */

class T_m_ooc : public C_OocMatrix
{
public :
  
  T_m_ooc( int in_nb_fic, int in_nb_ddls, int in_numero, char *basename,
	   char **dirs, int *ier);
  virtual ~T_m_ooc();
  
  double	GetVal( int iRow, int jCol) { CADOE_THROW(E_MethodNotDefined); return 0.;}
  //T_ligne *GetRow( int idof, int *ir);
  inline T_ligne *GetRow( int idof, int *ir)
  { return (T_ligne *) C_OocMatrix::GetRow( idof, ir);}

  int	Print( FILE *fout=stdout, int line=-1);
  int	Print( char *nameFile, int ilig=-1, bool append=false) { return SUCCES;}
  
  int	WriteBuffer( T_line_buffer *buffer);
  
  int	ReadLine( T_lso *line);
  int	ReadLineMP( T_ligne *line);
  int	WriteLine( T_lso *line);
  
  int	AllocateBuffers( int NbProcs=1);
  int	BuildCompactRowTable( void);

  int		ConnectToCurrentBuffer( T_line_buffer *buffer, int iproc = 0);
  void		DisconnectCurrentBuffer( int iproc);
  int       WriteBuffer( T_lso_buffer *buffer);

  int       GetBufferForANewLine( T_ligne *line, T_booleen alloc);
  //int       GetBufferForANewLine2( T_ligne *line, T_booleen alloc);

  template <typename T> void toMatSp(int order,C_MatSp<T> &matSp);
  
  double NormDist(int order, int GlbNbcs, int *locBcsToGlbBcs,bool maplocGlb = false);  //version distributed of the norme  
  double Norme( int dporder, int aorder);    //somme coefficients of the matrice

  void   PrintNorme( C_CadoeMessage &Msg, char *title, int dporder, int aorder);
  void   PrintNormDist( C_CadoeMessage &Msg, char *title, int order, int GlbNbcs, int *locBcsToGlbBcs, bool maplocGlb);

// Methods to perform Matrix-Vectors or Matrix-Dense-Matrix operations

  template <typename T> int T_MM_Mlt( int nbv, T *vin, T_booleen add, T *vout, int dporder, int aorder, T coef = (T)1,bool trans=false);

  void MM_Mlt_Bridge( int nbv, double *vin, double *vout, int dporder, double coef,int *ier);
  void MM_Mlt_Bridge( int nbv, complex16_t *vin, complex16_t *vout, int dporder, complex16_t coef,int *ier);

  template <typename T> void TMM_Mlt_Pll( INT *nbv_in, T *vin, T *vout, INT *dporder, T coef,  INT *ier);
  template <typename T> void TMv_Mlt_Pll( T *vin, T *vout, INT *dporder, T coef,INT *ier);

  virtual int Mv( double alpha, C_Vec<double> &x, double beta, C_Vec<double> &y, char trans = 'N')
  { return this->T_MM_Mlt( 1, x.Adr(), false, y.Adr(), 0, 1, alpha);}


  int		             _NbThreads;///< Number of threads ( = number of current buffers)
  int			          ordre_max;///< maximum order of all rows
  T_adr_rel		         *adr_rel;	///< Relative index
  T_line_buffer		     *current;	///< Current buffer
  vector<T_line_buffer *> currents; ///< Current active buffers ( one for each proc)

};

template <typename T> inline T_statut 
T_MOC_prod_ax_d( T_m_ooc *mat,int order, T *vin, T_booleen add, T *vout, T coef=1,
		 bool trans=false)
{
  char		fctn[] = "T_MOC_prod_ax_d";			CADOE_TRACE(fctn);
  T_statut	ier;
  register int	i_one(1);
  
  if( mat->IsCompact() != true) 
    { ier = mat->BuildCompactRowTable();				CHKIERS;}
  
  if (!add) __gzero__( vout, mat->nb_ddl);
  
  if ( mat->length == 0)
    return SUCCES;

  if (!mat->unsym) trans=false;	// ===== If Mat is Sym, trans has no effect
  
  ier = mat->AllocateBuffers();						CHKIERS;

  C_VecPi<T>	Vtmp( mat->MaxLength()+1);
  T		*VAdr = Vtmp.Adr();
  
  for( int irow=0; irow<mat->nnz_rows; irow++)
    {
      T_ligne *lig = dynamic_cast<T_ligne *>(mat->rows[irow]);

      if (!lig->buffer->charge) { ier = mat->ReadLineMP( lig);		CHKIERS;}
      int prem = lig->ptr_ordre[order];
      int dern = lig->ptr_ordre[order+1];
      int len = dern - prem;
      int *pos=lig->indices+prem;
      int nz_diag=(lig->irow==*pos);
      if (trans)
	{
	  // ===== and implictly mat->unsym == true. In not, we consider btrans = false

	  Vtmp.Zero();
	  
	  axpy( len, vin[lig->irow], lig->valeurs, i_one, Vtmp.Adr(), i_one);
	  if ( coef != 1) Vtmp *= coef;
	  lig->IndFillGlobalVectors(order, Vtmp.Adr(), vout);
	}
      else
	{
    if ( mat->unsym){
        lig->IndExtractLocalVector(order, vin, VAdr);
	    if ( coef != 1)MyScal( len, coef, VAdr, i_one);
	    lig->MvMltUns(order, VAdr, vout);
    }else{
        lig->IndExtractLocalVectorSym(order, vin, VAdr);
	    if ( coef != 1)MyScal( len+(1-nz_diag), coef, VAdr, i_one);
        lig->MvMlt(order, VAdr, vout); 
    }
	}

      if( !mat->in_core ) lig->Flush( 0, FAUX );
    }

  return SUCCES;
}


template <typename T> inline T_statut 
T_MOC_prod_axm_d( T_m_ooc *mat,int order, int nbv, T *vin, T_booleen add, T *vout, T coef=1,
		  bool trans=false)
{
  char		fctn[] = "MOC_prod_axm_d";			CADOE_TRACE(fctn);
  T_statut	ier;
 
  ier = SUCCES;
  
  if ( nbv == 1)
    return T_MOC_prod_ax_d( mat,order, vin, add, vout, coef, trans);
  
  if( mat->IsCompact() != true) 
    {ier = mat->BuildCompactRowTable();					CHKIERS;}
  
  if (!mat->unsym) trans=false;
  
  int taille_vec = mat->nb_ddl;
  int taille_tot = taille_vec * nbv; 

  if (!add) __gzero__( vout, taille_tot);
  
  if ( mat->length == 0) return SUCCES;

  ier = mat->AllocateBuffers();						CHKIERS;

  T		*Ulocal = new T[nbv*(mat->MaxLength()+1)];
  T_lso	**ligc = mat->rows;

  if ( mat->unsym)
	{
	  T	*AUlocal = new T[nbv];
	  T	t_un = 1, t_zero = 0;
	  char	notrans = 'N';

	  /* Loop over the lines */
	  for( int irow=0; irow<mat->nnz_rows; irow++, ligc++)
	    {
	      T_ligne *lig = dynamic_cast<T_ligne *>(mat->rows[irow]);
	      
	      if (!lig->buffer->charge) { ier = mat->ReadLineMP( lig);	CHKIERS;}

          int prem = lig->ptr_ordre[order];
          int dern = lig->ptr_ordre[order+1];
          int len = dern - prem;

	      lig->IndExtractLocalVector2(order, nbv, mat->nb_ddl,coef, vin, Ulocal);

	      gemv( notrans, nbv, len, t_un, Ulocal, nbv, lig->valeurs+prem, 1,
		    t_zero, AUlocal, 1);

	      for( int iv=0; iv<nbv; iv++)
            vout[lig->irow + iv*mat->nb_ddl] += AUlocal[iv];
	      
	      if( !mat->InCore()) lig->Flush( 0, FAUX);
	    }

	  delete []AUlocal;
  }
  else
  {
    T	*AUlocal = new T[nbv*(mat->MaxLength()+1)];
      
      /* Loop over the lines */
      for( int irow=0; irow<mat->nnz_rows; irow++, ligc++)
	{
	  T_ligne *lig = dynamic_cast<T_ligne *>(mat->rows[irow]);
      
          if (!lig->buffer->charge)	{ ier = mat->ReadLineMP( lig);	CHKIERS;}
      
	  lig->IndExtractLocalVector2Sym(order, nbv, mat->nb_ddl, coef, vin, Ulocal);
      
	  MEM_ZERO( AUlocal, (nbv*(mat->MaxLength()+1))*sizeof(T));
	  lig->MmMlt(order, nbv, Ulocal, AUlocal);
		  
	  lig->IndFillGlobalVectors(order, AUlocal, nbv, mat->nb_ddl, vout);
	  
	  if( !mat->InCore()) lig->Flush( 0, FAUX);
        }
  
      delete []AUlocal;
    }
      
   delete []Ulocal;

  return SUCCES;
}

#if defined(LOWERCASENOUNDER_SYS)

#endif
#if defined(UPPERCASENOUNDER_SYS)
#define mocsetmapnum	MOCSETMAPNUM
#define mocaddline 	MOCADDLINE
#define mocaddlinebcs 	MOCADDLINEBCS
#define msoaddline 	MSOADDLINE
#define msoaddlinebcs	MSOADDLINEBCS
#define mocaddlinens 	MOCADDLINENS
#define mocaddspline 	MOCADDSPLINE
#define mocaddsplinebcs	MOCADDSPLINEBCS
#define moclineaxpy 	MOCLINEAXPY
#define mocend          MOCEND
#define msoend          MSOEND
#define moclineaxpybcs  MOCLINEAXPYBCS
#endif
#if defined(LOWERCASEUNDER_SYS)
#define mocsetmapnum	mocsetmapnum_
#define mocaddline 	mocaddline_
#define mocaddlinebcs 	mocaddlinebcs_
#define msoaddline 	msoaddline_
#define msoaddlinebcs	msoaddlinebcs_
#define mocaddlinens 	mocaddlinens_
#define mocaddspline 	mocaddspline_
#define mocaddsplinebcs	mocaddsplinebcs_
#define moclineaxpy 	moclineaxpy_ 
#define mocend          mocend_
#define msoend          msoend_
#define moclineaxpybcs  moclineaxpybcs_
#endif

extern "C" {

  /* ===== Fonctions de sx_operators.c                                            */

  extern void FX_BuildAppOp( PAR *par, VEC *vparam, VEC *TabEps, int oK, int oM, int oB,
                           T_DerCsp **KDer, T_DerCsp **MDer, VSTRUCT **BDer, int *ier);
  extern void FX_BuildAppOpBcs( PAR *par, VEC *vparam, IVEC *FULLtoBCSdof, int nbcs,
                              VEC *TabEps, int oK, int oM, int oB, T_DerCsp **KDer,
                              T_DerCsp **MDer, VSTRUCT **BDer, int *ier);
  extern CSPMAT * FX_ReadMatPart(int matrice,VEC*,int *ier);
  extern CSPMAT * FX_ReadMatPartBcs(int matrice, IVEC *FULLtoBCSdof,int nbcs, int *ier);


  /* Matrix Create / Delete functions */
  extern void MOC_free(void);

  /* Add Lines in the matrix */

  T_ligne *LIG_read( T_m_ooc*, int, T_ligne*, T_statut*);
  T_ligne *LIG_read1( T_m_ooc*, int, T_ligne*, T_statut*);

  SUBROUTINE mocaddline( INT *numat, INT *line, INT *len, INT *ddls, DOUBLE *valeurs, INT *cl, INT *diag, DOUBLE *vdiag, INT *iret );
  SUBROUTINE mocaddlinebcs( INT *numat, INT *line, INT *len, INT *ddls, DOUBLE *valeurs, INT *diag, DOUBLE *vdiag, INT *FULLtoBCS, INT *iret );
  SUBROUTINE mocaddspline( INT *numat, INT *line, INT *len, INT *ddls, INT *ordre, INT *scale, DOUBLE *coef, DOUBLE *valeurs, INT *diag, DOUBLE *vdiag, INT *iret );
  SUBROUTINE mocaddsplinebcs( INT *numat, INT *line, INT *len, INT *ddls, INT *ordre, INT *scale, DOUBLE *coef, DOUBLE *valeurs, INT *diag, DOUBLE *vdiag, INT *FULLtoBCS, INT *iret );
  SUBROUTINE mocend( INT *numat, INT *ier );
  SUBROUTINE moclineaxpybcs( INT *numat, INT *line, INT *len, INT *ddls, INT *ordre, DOUBLE *coef, 
			     DOUBLE *valeurs, INT *diag, DOUBLE *vdiag, INT *FULLtoBCS, INT *ier );

  /* Matrix Algebra */
  extern T_m_ooc* MOC_extraire_sous_matrice( int nb_fic, char *basename, char **dirs, T_m_ooc *min, T_m_ooc *madr, int ordre, T_booleen scale, double factor, T_m_ooc *mout, T_statut *ier  );
  extern T_m_ooc* MOC_combine( int nb_fic, char *basename, char **dirs, double a1, T_m_ooc *m1, double a2, T_m_ooc *m2, double seuil, int overwrite, int creer_adr, T_statut *ier  );
  extern T_m_ooc* MOC_combine_simple( int nb_fic, char *basename, char **dirs, double a1, T_m_ooc *m1, double a2, T_m_ooc *m2, int overwrite, T_statut *ier  );
  extern void MOC_interpol( T_m_ooc *mat, int ordre, double var_relat, double *tabval, T_statut *ier);
  extern T_statut MOC_combine_simple_ordre( T_m_ooc *m1, double a2, T_m_ooc *m2, int ordre );
  extern T_m_ooc* MOC_difference( int nb_fic, char *basename, char **dirs, T_m_ooc *m1, T_m_ooc *m2, 
				  double seuil, int overwrite, T_statut *ier  );
  extern T_statut MOC_decaler_ordre( T_m_ooc *moc, int os, int oc );
  extern T_statut MOC_ResizeOrder( T_m_ooc *moc, int ordre);
  extern void MOC_LoadInMemory( T_m_ooc *mat, int *ier);
  extern T_statut MOC_interpol_sinus( T_m_ooc *mat, int ordre, double var_relat, double *tabval );
  extern T_m_ooc *MOC_update_sinus ( T_m_ooc*, T_m_ooc*, double, T_statut* );
  extern T_m_ooc *MOC_derive_sinus( T_m_ooc *coef, T_m_ooc *in, char *name, double angle, double dangle, int ordre, T_statut *ier );
  extern T_statut MOC_insert_order( T_m_ooc *moc, T_m_ooc *insert, int om, int oi );
  extern T_statut MOC_apply_cl( T_m_ooc *mat, IVEC *sup_pres_dep );
  
  extern CSPMAT *MOC_2Csp( T_m_ooc *K0Part, int *ier);

  SUBROUTINE moclineaxpy( INT *numat, INT *line, INT *len, INT *ddls, INT *ordre, DOUBLE *valeurs, DOUBLE *coef, INT *diag, DOUBLE *vdiag, INT *iret );
  
  /* Matrix / Vector product */
  extern T_statut MOC_dxtax( T_m_ooc *mat, int nbv, int order, double *vin, double *vtav );
  extern T_statut MOC_prod_ax_d( T_m_ooc *moc, int nbv, int dporder, int aorder, int type, void *vin,  T_booleen add, void *vout );
  extern T_statut MOC_prod_axm_d( T_m_ooc *mat, int nbv, int dporder, int aorder, int type, void *vin, T_booleen add, void *vout, T_fct_m2v fctm2v);


  extern int fct_m2v_default( int size_vector, int nbv, int order, int vecnum );
  
  /* Misc. Services */
  SUBROUTINE mocsetmapnum( INT *line, INT *numddl, INT *ier);
}

void	MatSpToMoc( C_MatSp<double> &MatSp, T_m_ooc &Mat, T_booleen scale = false, double coef = 1.);
void	MatSpToMocVar( C_MatSp<double> &MatSp, T_m_ooc &Mat, int iKVal, T_booleen scale = false, double coef = 1.);

#endif /* __cplusplus */

#endif
