/* MOD_numnoe.h CADOE  */
/*
 *  MOD_numnoe.h -
 *
 *  $Id: MOD_numnoe.h,v 1.4 2009/11/13 16:13:02 jtm Exp $
 *   
 * HISTORY
 *   
 *   06/28/00 10:47 <       Brian Jantzen> Rel:ms8m1    SCCA:74542  Delta:81.3
 *   
 *   06/21/00 16:30 <       Brian Jantzen> Rel:ms8m1    SCCA:74307  Delta:81.2
 */
#ifndef __modnumnoeh__
#define __modnumnoeh__ 1

#ifndef __expmdbstructh__
#include "expmdb_struct.h"
#endif

#ifndef __CADOE_H__
#include "cadoe.h"
#endif

/*#ifdef __cplusplus
extern "C" {
#endif*/

extern IVEC *MOD_construit_numnoe( int, T_Noeud **, T_statut * );
extern IVEC *MOD_construit_numele( int, T_Element **, T_statut * );

  extern T_Htable	*MOD_construit_tablenoe( int, T_Noeud **, T_statut * );
  extern T_Htable	*MOD_construit_tableele( int, T_Element **, T_statut * );
  extern T_Noeud	*MOD_GetNode( T_Mesh *, int );

/*#ifdef __cplusplus
}
#endif*/


#endif
