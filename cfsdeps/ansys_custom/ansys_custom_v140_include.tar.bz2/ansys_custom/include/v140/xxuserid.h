/*
 *    author/date: yu-hua ting/01-10-94
 *
 *    primary function:
 *
 *      Headers for the Interface to SHAPES "userids" routines
 *
 *    secondary function:
 *
 *        none
 *
 *    routines included:
 *
 *
 *    history
 *
 *        none
 *
 *    comments:
 *
 *        1). direct interface with Shapes/xox 2.0 will be added later
 *
 *    Notice - This file contains ANSYS Confidential information ***
 *
 */

/* 
 * *** copyright(c) 2011 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */



/*
 *    associate user_id to a basic geom or frame
 */
      extern VOID xSetUserId_xox ansPROTO((
             xGEOM_ID geom,       /* I    basic geom or frame                   */
             INT userid,          /* I    userid to be associated to the basic  
                                   *      geom or frame                         */
             INT *iretp));        /*   O  pointer to an error code
                                   *      == 0 - no error
                                   *      != 0 - error                          */

/*
 *    get the user_id list for a basic geom or frame
 */
      extern xINT_LIST xUserIds_xox ansPROTO((
             xGEOM_ID geom,       /* I    basic geom or frame                   */
             INT *iretp));        /*   O  pointer to an error code
                                   *      == 0 - no error
                                   *      != 0 - error                          */


/*
 *    associate user_ids to  basic geoms or frames
 */
      extern VOID xUserIdSet_xax ansPROTO((
             xGEOM_ID geoms[],    /* I    basic geoms or frames                   */
             INT userids[],       /* I    userids to be associated to the basic  
                                   *      geoms or frames                         */
             INT *np,             /* I    number of basic geoms or frames         */
             INT *iretp));        /*   O  pointer to an error code
                                   *      == 0 - no error
                                   *      != 0 - error                            */

/*
 *    get the numbers of user_ids associated to basic geoms or frames
 */
      extern VOID xUserIdQuery_xax ansPROTO((
             xGEOM_ID geoms[],    /* I    basic geoms or frames                   */
             INT nuserids[],      /*   O  numbers of userids associated with  
                                   *      the basic geoms or frames               */
             INT *np,             /* I    number of basic geoms or frames         */
             INT *iretp));        /*   O  pointer to an error code
                                   *      == 0 - no error
                                   *      != 0 - error                            */

/*
 *    get the 1st user_ids pairs associated with basic geoms or frames
 *    (*iretp > 0 - error
 *           < 0 - the list of user_ids pairs is empty
 */
      extern VOID xUserIdGet_xax ansPROTO((
             xGEOM_ID geoms[],    /* I    basic geoms or frames                   */
             INT userids[],       /*   O  1st userids associated with the basic 
                                   *      geoms or frames                         */
             INT states[],        /*   O  states of the userids                   */
             INT *np,             /* I    number of basic geoms or frames         */
             INT *iretp));          /*   O  pointer to an error code
                                   *      == 0 - no error
                                   *      != 0 - error                            */


/*
 *    print user_ids pairs associated with a basic geom
 */
      extern VOID xUserIdPrint_xax ansPROTO((
             xGEOM_ID geom));    /* I    a basic geom                            */

