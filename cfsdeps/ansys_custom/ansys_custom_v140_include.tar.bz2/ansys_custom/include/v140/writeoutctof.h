/* ---------------------------------------------------------------------- */
/* *** copyright(c) 2010 SAS IP, Inc.  All rights reserved. */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */

#if !defined (__WRITEOUTCTOF_H__)
#define __WRITEOUTCTOF_H__ 1

#include "ansys.h"

/* (1)----------------------------------------------------------------*/
#if defined(RS6000_SYS) || defined(HP32_SYS) || defined (RS64K_SYS)

#define writeout_              writeout

#endif


/* (2)----------------------------------------------------------------*/
#if defined(PCWINNT_SYS)

#define writeout_              WRITEOUT

#endif


/* (4)----------------------------------------------------------------*/

#if defined (PCWINNT_SYS)
#ifdef ARGTRAIL
VOID CALLTYP writeout_(CHAR *msg, INT *msgLen, INT *force, INT *iott, INT msgLeng);
#else
VOID CALLTYP writeout_(CHAR *msg, INT msgLeng, INT *msgLen, INT *force, INT *iott);
#endif
#else
VOID CALLTYP writeout_(CHAR *msg, INT *msgLen, INT *force, INT *iott, INT msgLeng);
#endif

#endif
