
/*****************************************************************************

    ***  this is the definition of MPI TAG parameters for C  ***

  *** copyright(c) 2011 SAS IP, Inc.  All rights reserved.
  *** ansys, inc.

*****************************************************************************/


/* FE data tags: 100-1900 */
#define NODE_TAG       100
#define ELEM_TAG       200
#define ETYPE_TAG      300
#define MP_TAG         400
#define TB_TAG         500
#define REAL_TAG       600
#define SECT_TAG       700
#define CE_TAG         800
#define CP_TAG         900
#define CSYS_TAG      1000
#define DBC_TAG       1100
#define FBC_TAG       1200
#define ESURFBC_TAG   1300
#define EBODYBC_TAG   1400
#define NBODYBC_TAG   1500
#define RDSP_TAG      1600
#define RFOR_TAG      1700
#define BDRYELM_TAG   1800

/* global/local and common tags: 2000-2900 */
#define GLOBAL_TAG    2000
#define LOCAL_TAG     2100
#define COMMON_TAG    2200
#define COMMAND_TAG   2300
#define ERROR_TAG     2400
#define FILE_TAG      2500
#define TRACK_TAG     2600

/* interface exchange tags: 3000-3900 */
#define SUB_INFO_TAG  3000

/* assemble/gather/scatter tags: 4000-4900 */
#define GATHR_TAG     4000
#define SCATT_TAG     4100
#define GATHR2_TAG    4200
#define SCATT2_TAG    4300
#define ASSEM_TAG     4400

/* temporary work tags: 5000-5900 */
#define WORK1_TAG     5000
#define WORK2_TAG     5100

/* solver tags: 6000-7900 */
#define SETARR_TAG    6000
#define INTF_VEC_TAG  6100
#define PREC_VEC_TAG  6200
#define CPCE_TAG      6300
#define ELEMDIAG_TAG  6400
#define PRECOND_TAG   6500
#define UVEC_TAG      6600
#define DSP_TAG       6700
#define PARMETIS_TAG  6800
#define DDS_TAG       6900
#define DFF_TAG       7000
#define FDEIGEN_TAG   7100
#define FREQSWT_TAG   7200
#define ITFSOLVER_TAG 7300

/* combine file tags: 8000-8900 */
#define RESU_TAG      8000
#define INIS_TAG      8100
#define ESAV_TAG      8200
#define MLV_TAG       8300
#define EMAT_TAG      8400
#define DSUB_TAG      8500

/* chaparral tags: 9000-10900 */
#define CHAP_TAG   9000

/* feature tags: 11000-14900 */
#define NLDIAG_TAG   11000

