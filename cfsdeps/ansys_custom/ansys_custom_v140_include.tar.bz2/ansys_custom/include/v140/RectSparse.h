/*****************************************************************************
 *                   Copyright (C) 1999 CMSoft                               *
 *                                                                           *
 *  These lines of code and declarations contain unpublished proprietary     *
 *  information of CMSoft. They may not be copied or duplicated in whole     *
 *  or part without prior authorization from CMSoft.                         *
 *                                                                           *
 *****************************************************************************/

#ifndef _RECTANGULAR_SPARSE_H_
#define _RECTANGULAR_SPARSE_H_

#include "SparseMatrix.h"
#include "C_MatSp.h"

class RectSparse : public FSSparseData, public FSOperator 
{
  double *_data;
  
  public:
    RectSparse(FSConnectivity *con, DofSetArray *dsa, ConstrainedDSA *c_dsa);
    RectSparse(FSConnectivity *con, DofSetArray *dsa, ConstrainedDSA *c_dsa,
         ConstrainedDSA *cc_dsa);
    RectSparse(FSConnectivity *con, DofSetArray *dsa, int *glbmap, int *glimap);
    RectSparse(int nrow, int ncol, int *ptr, int *col, double *val);
    RectSparse(DofSetArray *anydsa,
        int ncol, int *len, int **nodes, int **dofs, double **Coefs);
    ~RectSparse();
    
    double MemSize();

    void add(FullSquareMatrix &kel, int *dofs);
    void add(FSFullMatrix &kel, int *dofs);
    void zeroAll();
    
    void mult(const double *rhs, double *result);
    void multSubstract(double *rhs, double *result);
    void multSub(double *rhs, double *result);
    void transposeMultAdd(double *rhs, double *result);
    void transposeMultSub(double *rhs, double *result);
    void multIdentity(FSFullMatrix &res);
    void transposeMultIdentity(FSFullMatrix &res);
    void Axpy(RectSparse &mat, double coef);
    void toMatSp(C_MatSp<double> &);
    void print(char *msg);
    void WriteMatlab(FILE *fp);
  
    double diag(int) { return 0.0;                     }
    int  row(int i)  { return _unconstrNum[i];         }
    int  col(int i)  { return _constrndNum[i];         }
    int  dim()       { return _neq;                    }
    int size()       { return _xunonz[_numConstrained]; }
    int numRow()     { return _numConstrained;         }
    int numCol()     { return _numUncon;	       }
    double* Adr()    { return _data;			}
};

#endif
