/* ------------------------------------------------------------------- */
/* *** copyright(c) 2011 SAS IP, Inc.  All rights reserved. */
/* *** ansys, inc.                */
/* ------------------------------------------------------------------- */

/*  MECH_CtoF.h             MECH_CtoF.h                          azs   */
/*                                                                     */
/* *** Notice - This file contains ANSYS Confidential information  *** */
/*
 * The original copy of this file is FEMa_CtoF.h (sjo) Please refere to it for 
 * more detailes.                                                      
 *  MECH_CtoF.h
 *  Prototypes and #defines for handling calls from
 *  C to FORTRAN and FORTRAN to C for the FEM module
 *
 *  To call FORTRAN from C:
 *  1.  A total of 5 entries into this file should be made under the
 *      headings "FORTRAN subroutines called from C".  Search for these
 *      headings and follow the pattern.
 *  2.  To call FORTRAN from C use an underscore at the end of the name
 *      All lower case is required!
 *      ie.           ffunc_(args);
 *  3.  Do not use the underscore in the FORTRAN definition of the function
 *      ie.           subroutine ffunc(arg1,arg2)
 *  4.  Pass the addresses of data to the FORTRAN subroutine i.e.
 *                    INT arg1;
 *                    DOUBLE arg2;
 *                    ffunc_(&arg1, &arg2);
 *  5.  Include this file in the C file that calls the FORTRAN. i.e.
 *                #include "FEMa_CtoF.h"
 *
 *  To call C from FORTRAN:
 *  1.  A C function callable from FORTRAN should be named with an
 *      underscore after the last letter.  All lower case is required!
 *       .ie cfunc_
 *  2.  The function definition should have the type and the #define
 *      CALLTYP preceding the function name. i.e.
 *               INT CALLTYP cfunc_ (args)
 *      CALLTYP is defined in computers.h - so do a #include "FEM_cdbtypes.h"
 *      since FEM_cdbtypes.h includes computers.h
 *  3.  Argument lists should use K&R standard rather than including
 *      types in the argument list (ANSI standard).  i.e.
 *               INT CALLTYP cfunc_ (arg1, arg2)
 *                   INT *arg1;
 *                   DOUBLE *arg2;
 *  4.  Arguments to the C function should be received as addresses and
 *      then dereferenced before being used.  i.e.
 *               INT CALLTYP cfunc_ (arg1, arg2)
 *                   INT *arg1;
 *                   DOUBLE *arg2;
 *               {
 *                   *arg1 = 1;  *arg2 = 1.0;
 *               }
 *  4.  A total of 5 entries into this file should be made under the
 *      headings "C functions called from FORTRAN".  Search for these
 *      headings and follow the pattern.
 *  5.  This file should be included in the C file where the function
 *      is located.  i.e.
 *               #include "FEMa_CtoF.h"
 *  6.  To call C from FORTRAN do not use the underscore i.e.
 *               call cfunc(arg1,arg2)
 *  7.  An extern definition should be included in the calling FORTRAN
 *      subroutine as well as the return type (if any).  i.e.
 *               extern cfunc
 *               integer cfunc
 *
 */

/* (1)-------------------------------------------------------------*/
#if defined(RS6000_SYS) || (defined(HP_SYS) && !defined(PROTOIZE_RUN))


/* === C functions called from FORTRAN */

#define domain_graph_           domain_graph
#define err_warn_scan_          err_warn_scan
#define mat_dp_form_cap_        mat_dp_form_cap
#define mat_drucker_form_       mat_drucker_form
#define mat_dp_ideal3d_         mat_dp_ideal3d
#define mat_anand_3d_           mat_anand_3d
/* === FORTRAN subroutines called from C */
#define prinst_                 prinst
#define cnlpropbufrd_           cnlpropbufrd
#define pstev3_                 pstev3
#define matsigdev_              matsigdev
#define vmult_                  vmult
#define vamb1_                  vamb1
#define vapb1_                  vapb1
#define vmove_                  vmove              
#define matinv_                 matinv
#endif

/* (2)-------------------------------------------------------------*/

#if defined(WATCOMC_SYS) \
    || defined(PCWINNT_SYS)
/* === C functions called from FORTRAN */
 
#define domain_graph_           DOMAIN_GRAPH
#define err_warn_scan_          ERR_WARN_SCAN
#define mat_dp_form_cap_        MAT_DP_FORM_CAP
#define mat_drucker_form_       MAT_DRUCKER_FORM
#define mat_dp_ideal3d_         MAT_DP_IDEAL3D
#define mat_anand_3d_           MAT_ANAND_3D
/* === FORTRAN subroutines called from C */
#define prinst_                 PRINST
#define cnlpropbufrd_           CNLPROPBUFRD
#define pstev3_                 PSTEV3
#define matsigdev_              MATSIGDEV
#define vmult_                  VMULT 
#define vamb1_                  VAMB1
#define vapb1_                  VAPB1
#define vmove_                  VMOVE
#define matinv_                 MATINV
#endif

/* (3)-------------------------------------------------------------*/
#if defined(WATCOMC_SYS)

/* === C functions called from FORTRAN */

/* === FORTRAN subroutines called from C */
#pragma aux PRINST "^";
#pragma aux CNLPROPBUFRD "^";
#pragma aux PSTEV3 "^";
#pragma aux MATSIGDEV "^";
#pragma aux VMULT "^";
#pragma aux VAMB1 "^";
#pragma aux VAPB1 "^";
#pragma aux VMOVE "^";
#pragma aux MATINV "^";
#endif

/* (4)-------------------------------------------------------------*/
/*
 * *** FUNCTION RETURN TYPE DECLARATION
 */

#if !defined(PCWINNT_SYS)

/* === C functions called from FORTRAN */

 int domain_graph() ;
 int err_warn_scan() ;
 int mat_dp_form_cap() ;
 int mat_drucker_form() ;
 int mat_dp_ideal3d() ;
 int mat_anand_3d() ;
/* === FORTRAN subroutines called from C */
 void prinst_();
 void cnlpropbufrd_();
 void pstev3_();
 void matsigdev_();
 void vmult_();
 void vamb1_();
 void vapb1_();
 void vmove_();
 void matinv_();
 /* (5)-------------------------------------------------------------*/
#else

/* === C functions called from FORTRAN */

 int CALLTYP domain_graph_(   INT * ,  
			      INT * , 
			      INT * , 
			      INT * 
			      ) ;
 int CALLTYP err_warn_scan_(  INT * ,  
			      INT * 
			      ) ;
 int CALLTYP mat_dp_form_cap_(
			      INT *, 
			      DOUBLE * ,
			      DOUBLE * 
			      ) ;
 int CALLTYP mat_drucker_form_(
			      INT *, 
			      DOUBLE * ,
			      DOUBLE * 
			      ) ;
 int CALLTYP mat_dp_ideal3d_( 
			      INT *, 
                              INT *,
			      DOUBLE * ,
			      INT *, 
			      INT *, 
			      INT *,
			      INT *,
			      INT *,
			      INT *,
			      INT *,
			      INT *,
			      INT *, 
			      INT *, 
			      INT *, 
			      DOUBLE * ,
			      DOUBLE * ,
			      DOUBLE * ,
			      DOUBLE * ,
			      DOUBLE * ,
			      DOUBLE * ,
			      DOUBLE * ,
			      DOUBLE * ,
			      DOUBLE * ,
			      DOUBLE * ,
			      DOUBLE * ,
			      DOUBLE * ,
			      DOUBLE * ,
			      DOUBLE * 
			      ) ;

 int CALLTYP mat_anand_3d_( 
			   INT *, 
			   INT *, 
			   INT *, 
			   INT *,
			   INT *,
			   INT *,
			   INT *,
			   INT *,
			   INT *, 
			   INT *, 
			   INT *, 
			   INT *, 
			   DOUBLE * ,
			   DOUBLE * ,
			   DOUBLE * ,
			   DOUBLE * ,
			   DOUBLE * ,
			   INT *, 
			   DOUBLE * ,
			   DOUBLE * ,
			   DOUBLE * ,
			   DOUBLE * ,
			   DOUBLE * ,
			   DOUBLE * ,
			   DOUBLE * ,
			   DOUBLE * ,
			   DOUBLE * ,
			   DOUBLE * ,
			   DOUBLE * ,
			   DOUBLE * ,
			   DOUBLE * ,
			   DOUBLE * ,
			   DOUBLE * ,
			   DOUBLE * ,
			   DOUBLE * ,
			   DOUBLE * ,
			   DOUBLE * ,
			   DOUBLE * ,
			   DOUBLE * ,
			   DOUBLE * ,
			   DOUBLE * ,
			   DOUBLE * ,
			   DOUBLE * 
			   ) ;

/* === FORTRAN subroutines called from C */
 void CALLTYP prinst_(        
                              DOUBLE* 
			      );
 void CALLTYP cnlpropbufrd_(  
			      INT*  ,  
			      INT*  , 
			      DOUBLE* 
			      ) ;
 void CALLTYP pstev3_(        
		              INT *  ,  
			      INT *  , 
			      DOUBLE * , 
			      DOUBLE * 
			      ) ;
 void CALLTYP matsigdev_(     
			      INT *  ,  
			      INT *  ,  
			      INT *  , 
			      DOUBLE * , 
			      DOUBLE * , 
			      DOUBLE * , 
			      DOUBLE *  
			      ) ;
 void CALLTYP vmult_(
			      DOUBLE * ,
			      DOUBLE * ,
			      INT *  ,  
			      INT *  
			      );
 void CALLTYP vamb1_(
			      DOUBLE * ,
			      DOUBLE * ,
			      INT *   
			      );
 void CALLTYP vapb1_(
			      DOUBLE * ,
			      DOUBLE * ,
			      INT *  
				  );
 void CALLTYP vmove_(
			      DOUBLE * ,
			      DOUBLE * ,
			      INT *  
			      ) ;

 void CALLTYP matinv_(
		              INT * , 
		              DOUBLE * ,
		              DOUBLE * 
		              ) ;
#endif



