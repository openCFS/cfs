/*******************************************************************************
 *
 *   sx_matk.h  --- Structures and prototypes for matk_MSO.c and matk.c
 *               
 * 
 * |Module:  
 *
 * |Description: 
 *
 * |Includes:	
 *        
 * |Auteur: Jerome Margat
 *
 * |Creation: December 2003
 *
 * |Version: $Id: sx_matk.h 145002 2009-11-13 16:20:27Z jtm $
 *
 * |Copyright:	Copyright(c)  2002
 *
 ********************************************************************************/

#ifndef __SX_MATK_H
#define __SX_MATK_H

#include "SxSparse.h"

struct __list_mat;
typedef struct __list_mat T_list_mat;

struct __list_mat {
  int nb_mat;
  T_mso   **mat;
  VEC     **rhs;
};

#ifdef __cplusplus
extern "C" {
#endif

extern T_list_mat* LISTMAT_allouer(int* ier);
extern int  LISTMAT_addMat(PAR* par,T_list_mat* listmat,VEC* vec_param,double* coef,IVEC* elems,T_statut LIBERE_DER_MODELE, int* ier);
extern void LISTMAT_free(T_list_mat* listmat, int *ier);
extern void LISTMAT_mv_mlt(T_list_mat* listmat,int num_mat,int nbv,double* vin,double* vout,int* ier);

#ifdef __cplusplus
}
#endif

#endif /* __MATK_H */
