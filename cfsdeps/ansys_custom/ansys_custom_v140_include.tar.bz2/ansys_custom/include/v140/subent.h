/*        subent.h                       kz372        */
/* 
 * *** copyright(c) 2011 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */

/*  get global xyz coordinates*/ 
INT 
CALLTYP xAnsysSubEntXYZ_ ansPROTO((
     xINT *geom,		/* I: ANSYS point */
     xREAL *xyz 		/* O: coordinate array */
));

/*  Get/Inquire list of keypoints, lines, areas, or volumes for a cell.*/ 
INT 
CALLTYP xAnsysSubEntEnts_ ansPROTO((
     xINT *geom,		/* I: point, subline, subarea, or subvolume */
     INT  *ents,		/* O: id array */
     INT  *flag 		/* I: get/inquire */
));

/*  Get/Inquire area for a surface.*/ 
INT 
CALLTYP xAnsysSubEntSurface_ ansPROTO((
     xINT *geom		/* I: point, subline, subarea, or subvolume */
));

/*  Get/Inquire supCells list for point, subline,or subarea*/ 
INT 
CALLTYP xAnsysSESupCells_ ansPROTO((
     xINT  *geom,		/* I: point, subline, or subarea */
     INT   *ents,		/* O: supCell array */
     INT   *flag 		/* I: get/inquire */
));

/*  Get/Inquire curve and surface list*/ 
INT 
CALLTYP xAnsysSubEntCurveSurfaceMaps_ ansPROTO((
     xINT *geom,		/* I: subline */
     INT  *maps,		/* O: map pair array */
     INT  *flag 		/* I: get/inquire */
));

/*  Return the 0D cells for a subline*/ 
INT 
CALLTYP xAnsysSubEntEndPoints_ ansPROTO((
     xINT *geom,		/* subline */
     INT *pts 			/* array of points */
));

/*  Retrieve specific parameter subline data*/ 
INT 
CALLTYP xAnsysSubEntSubLineData_ ansPROTO((
     xINT  *geom,		/* I: subline */
     xREAL  *data 		/* O: param data array */
));

/*  Returns number of frames for a cell.*/ 
INT
CALLTYP xAnsySubEntFrameSize_ ansPROTO((
     xINT *geom,		/* I: subentity */
     INT *dim 			/* I: Dimension of subentity */
));

/*  Returns number of frames for a cell.*/
INT
CALLTYP xAnsysSubEntNumFrames_ ansPROTO((
     xINT *geom,              /* I: subentity */
     INT *dim                   /* I: Dimension of subentity */
));

/*  Get/Inquire the frame tree for a subarea or subvolume*/ 
INT 
CALLTYP xAnsysSEFrameTree_ ansPROTO((
     xINT *geom,		/* I: subarea or subvolume */
     INT  *tree,		/* O: frame tree array */
     INT  *flag 		/* I: get/inquire */
));

/*  Get/Inquire cells of loop or shell*/ 
INT 
CALLTYP xAnsysSEFrameCells_ ansPROTO((
	xINT *geom,		/* I: subarea or subvolume */
	INT  *index,		/* I: index into frame tree */
	INT  *geoms,		/* O: frame cell array */
	INT  *flag 		/* I: get/inquire */
));

/*  Retrieve specific parametric data for a subarea.*/ 
INT 
CALLTYP xAnsysSubEntSubAreaData_ ansPROTO((
     xINT *geom,		/* subarea */
     xREAL *data, 		/* parametric data array */
     INT   *length 		/* array length  */
));

/*  Return the size of array needed for tessellated nodes.*/ 
INT 
CALLTYP xAnsysSubEntNumNodes_ ansPROTO((
     xINT *geom,		/* subline or subarea */
     INT  *size 		/* number of tessellated nodes */
));

/*  Return the array of tessellated nodes.*/ 
INT 
CALLTYP xAnsysSubEntNodes_ ansPROTO((
     xINT *geom,		/* I: subline or subarea*/
     xREAL *nodes 		/* O: node array */
));

/*  Get/Inquire the elements for a subentity*/ 
INT 
CALLTYP xAnsysSubEntElements_ ansPROTO((
     xINT *geom,		/* I: subline or subarea */
     INT  *elements,		/* O: indexed element array */
     INT  *flag 		/* I: get/inquire */
));

/*  Initialize Globals */ 
void
xAnsysSubEntInit ();

/*  Release globals*/ 
void
xAnsysSubEntEnd ();
