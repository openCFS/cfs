/*
 * *** copyright(c) 2011 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */
#ifndef __MESSAGE_MSG__
#define __MESSAGE_MSG__


#define  WHITE_SPACE            1     /* %STRING: ' 	'  */

#define  LINE_FEED              2    /* %STRING: ' ' */

#define  UI_INFORMATION         10    /* %STRING: 'Information' */ 

#define  UI_NOTE                11    /* %STRING: 'Note' */ 

#define  UI_WARNING             12    /* %STRING: 'Warning' */ 

#define  UI_ERROR               13    /* %STRING: 'Error' */ 

#define  UI_FATAL_ERROR         14    /* %STRING: 'Fatal_Error' */ 

#define  UI_CLOSE               15    /* %STRING: 'Close' */ 

#define  UI_PROCEED             16    /* %STRING: 'Proceed' */ 

#define  STD_NOTE               21    /* %STRING: '%/ *** NOTE ***                            CP=%C:1   TIME= %C:2' */

#define  STD_SUPP_NOTE          22    /* %STRING: '%/ *** NOTE ***      SUPPRESSED MESSAGE    CP=%C:1   TIME= %C:2' */

#define  STD_WARNING            23    /* %STRING: '%/ *** WARNING ***                         CP=%C:1   TIME= %C:2' */

#define  STD_SUPP_WARNING       24    /* %STRING: '%/ *** WARNING ***   SUPPRESSED MESSAGE    CP=%C:1   TIME= %C:2' */

#define  STD_ERROR              25    /* %STRING: '%/ *** ERROR ***                           CP=%C:1   TIME= %C:2' */

#define  STD_SUPP_ERROR         26    /* %STRING: '%/ *** ERROR ***     SUPPRESSED MESSAGE    CP=%C:1   TIME= %C:2' */

#define  STD_FATAL_ERROR        27    /* %STRING: '%/ *** FATAL ***                           CP=%C:1   TIME= %C:2' */

#define  STD_SUPP_FATAL_ERROR   28    /* %STRING: ' %/ *** FATAL ***     SUPPRESSED MESSAGE    CP=%C:1   TIME= %C:2' */


#define  AnsErr2004     4    /* %STRING: 'Number of displayed messages exceeds
user specified maximum of %I:1%/ Use the /NERR command to increase the number of messages %/ ANSYS run terminated by this error '*/ 

#define  AnsErr2002     5    /* %STRING: 'Error messages discontinued after %I:1 messages were displayed. %/ More may exist. See ( %C:2 ) for suppressed messages.' */
 
#define  AnsErr2005     6    /* %STRING: 'The above error is non-recoverable by ANSYS %/ ANSYS run terminated by the indicated error. %/ Current data base saved if possible' */


#endif /* __MESSAGE_MSG__ */
