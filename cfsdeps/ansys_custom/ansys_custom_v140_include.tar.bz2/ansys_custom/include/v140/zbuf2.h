/*CFILE zbuf2.h     ANSI_C                                  ph,system
------------------------------------------------------------------------
------- Notice - This file contains ANSYS Confidential information 
------------------------------------------------------------------------
*/
/* 
 * *** copyright(c) 2011 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */
/* zbuf2.h: definitions for integer polygon scan converter */

#ifndef POLY_HDR
#define POLY_HDR

#include <computer.h>
#include <math.h>

/* we want Int32 to be a 32 bit integer whether hardware is 16 bit, 32 bit,
 * or 64 bit
 *
 * the following will do this on 32 bit and most 64 bit machines
 */

typedef int Int32;			/* 32 bit signed integer type */
typedef unsigned int Uint32;	/* 32 bit unsigned integer type */

/* use Int32 when 32 bit integers are required (e.g. in most of our
 * fixed point calculations), but int when 16 bit is acceptable */

#define POLY_NMAX 10		/* max #sides to a polygon; change if needed */
/*
 * if an n-gon is clipped against a 3-D box, you could get an (n+6)gon,
 * so POLY_NMAX=10 is thus appropriate if input polygons are triangles or quads
 */

/* # fractional bits in 32 bit fixed point formats */
#define POLY_SHIFT 15

#define MODULO 4294967296.

/*
 * We want POLY_SHIFT>=log2(width in pixels) to avoid accumulated
 * roundoff error in z in the inner loop,
 * so for 700x700 pixel pictures, we'd need POLY_SHIFT>=10,
 * and to generate 4096x4096 pictures, we'd need POLY_SHIFT>=12.
 * But we also want POLY_SHIFT<=17 to leave room for 15 integer bits of z.
 */

#define POLY_SCALE (1<<POLY_SHIFT)
#define POLY_FFMAX ((1<<30)/POLY_SCALE-1.)

/* convert fixed point to integer */
#define POLY_FLOOR(x) ((x)>>POLY_SHIFT)
#define POLY_ROUND(x) (((x)+(POLY_SCALE>>1)) >> POLY_SHIFT)

/* find fractional part of fixed point number */
#define POLY_FRAC(x) ((x) & (POLY_SCALE-1))

/* convert fixed point to floating point */
#define POLY_FLOAT(x) ((double)(x)/POLY_SCALE)

/* convert integer to fixed point */
#define POLY_IFIX(x) ((x)<<POLY_SHIFT)

/* convert floating point to fixed point with rounding */
#define POLY_FFIX(x) floor((x)*POLY_SCALE+.5)

/* convert floating point to fixed point mod 2^32 */
#define POLY_MOD(x) (Uint32)(x-floor(x/MODULO)*MODULO)

/*
 * note that the following doesn't work (on SGI's, at least) because
 * fmod returns negative numbers for negative x!
 * #define POLY_MOD(x) (Uint32)fmod(x, 4294967296.)
 */

typedef struct {		/* A POLYGON VERTEX */
    Int32 x, y, z;		/* screen space position, fixed point */
    Int32 inten;		/* monochromatic intensity, fixed (GOURAUD) */
    double nx, ny, nz;		/* normal vector, floating point (for PHONG) */
    Int32 e;			/* error decision variable
				 * (distance from edge, for scan conv) */
    char drawedge;		/* draw edge from this vert to next? (bool) */
} Poly_vert;

/*
 * Only a subset of the above vertex parameters are used at any time:
 *   for FLAT: x, y, z
 *   for GOURAUD: x, y, z, inten
 *   for PHONG: x, y, z, nx, ny, nz
 * and the e and drawedge parameters are also used, sometimes.
 *
 * We keep the normal vector in doubles because of the sqrt we'll need to do.
 */


typedef enum {FLAT, GOURAUD, PHONG} Poly_type;

typedef struct {		/* A POLYGON */
    int n;			/* number of sides */
    Poly_type type;		/* FLAT|GOURAUD|PHONG */
    Poly_vert vert[POLY_NMAX];	/* vertices */
} Poly;

typedef struct {		/* WINDOW: A 2-D SCREEN RECTANGLE */
    int x0, y0;			/* xmin and ymin */
    int x1, y1;			/* xmax and ymax (inclusive) */
    int dx, dy;			/* width and height */
} Poly_window;



typedef struct {INT x, y, z;} Xyzi;	/* point with fixed point xyz */

#endif
