/*
 *    author date: gregory sharpe 5-7-92
 *
 *    primary function:
 *
 *        divide the supported unix platforms into two groups
 *        
 *        BSD complient:
 *          DECSTATION
 *          SUN3
 *          SUN
 *       
 *        SYSTEM V complient:
 *          HP
 *          SGI_SYS
 *          RS6000
 *
 *    secondary function:
 *
 *        none
 *
 *    routines included:
 *
 *        none
 *
 *    history
 *
 *        none
 *
 *    comments:
 *
 *        none
 *
 *    Notice - This file contains ANSYS Confidential information ***
 *
 */
/* 
 * *** copyright(c) 2011 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */



/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
       BSD COMPLIENT OPERATING SYSTEMS
*/
#if defined (BSD) && defined (SYSV)
#undef BSD
#undef SYSV
#undef GOTOS
#endif
#if defined (BSD) || defined (SYSV)
#define GOTOS
#endif
#ifndef GOTOS
#ifdef DECSTATION
#define BSD   
#endif
/*       
       SYSTEM V COMPLIENT OPERATING SYSTEMS
*/
#ifdef HP_SYS
#define SYSV  
#endif
#ifdef SGI_SYS
#define SYSV  
#endif
#ifdef RS6000_SYS
#define SYSV  
#endif
#endif
