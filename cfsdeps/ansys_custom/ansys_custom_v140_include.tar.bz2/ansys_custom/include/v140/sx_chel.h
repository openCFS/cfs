/* CADOE */
/**
 *	champ_el.h -- constantes attachees aux objets champ_elementaire
 *
 * |Version: $Id: sx_chel.h,v 1.3 2009/11/13 16:13:03 jtm Exp $
 *   
 * HISTORY
 *   
 *   06/28/00 08:51 <       Brian Jantzen> Rel:ms8m1    SCCA:74542  Delta:81.2
 *   
 *   02/15/00 13:10 <       Brian Jantzen> Rel:ms8      SCCA:68558  Delta:8.3
 *   
 *   09/30/99 17:38 <         James Silva> Rel:ms8      SCCA:56512  Delta:8.2
 **/

#include "sx_CADOE_solver.h"

#ifndef __CHEL_X_DEJA_INCLUS__
#define __CHEL_X_DEJA_INCLUS__ 1


#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */


extern T_statut CHE_creer_champ_elementaire (int , T_champ_elem **);
extern T_statut CHE_detruire(T_champ_elem *);
extern T_statut CHE_part_2_glob(double *rot, T_champ_elem *champ_elem);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif   /* __CHEL_X_DEJA_INCLUS__ */


