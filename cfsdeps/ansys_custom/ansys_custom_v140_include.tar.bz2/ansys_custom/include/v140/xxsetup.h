
/*
 *    author/date: yu-hua ting/03-01-94
 *
 *    primary function:
 *
 *      Header for the Interface to SHAPES "set up" routines
 *
 *    secondary function:
 *
 *        none
 *
 *    routines included:
 *
 *
 *    history
 *
 *        none
 *
 *    comments:
 *
 *        none
 *
 *    Notice - This file contains ANSYS Confidential information ***
 *
 */

/* 
 * *** copyright(c) 2011 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */

 
/****************************************************************************
 *    Initialize the Shapes/XOX process                                     *
 ****************************************************************************/
 
 
      extern VOID xInitShapes_xox ansPROTO((
             INT  *iretp));     /*   O  error code
                                 *      == 0 - no error
                                 *      != 0 - error                               */


 
/****************************************************************************
 *    Disconnect the Shapes/XOX process                                     *
 ****************************************************************************/
 
 
      extern VOID xDisconnectShapes_xox ansPROTO((
             INT  *iretp));     /*   O  error code
                                 *      == 0 - no error
                                 *      != 0 - error                               */

 
 
/****************************************************************************
 *    Set the Shapes/xox print mode                                         *
 ****************************************************************************/

 
      extern VOID xShapesSetStatusPrintMode_xox ansPROTO((
             xINT level,        /* I    verbosity of output
                                 *      == xcSTATUS_PRINT_MIN - prints out information about
                                 *                              the code, the descriptions and
                                 *                              the function generating the 
                                 *                              status. This is the default.
                                 *      == xcSTATUS_PRINT_DEBUG - prints out verbose information
                                 *                              for each object. Where possible,
                                 *                              prints out interpretation of 
                                 *                              auxiliary data associated with 
                                 *                              the objects                     */
             xINT numElements,  /* I    depth of stack to print. This determines the depth of
                                 *      of the status stack that is printed. Setting this to 0
                                 *      essentially turns off printing. A negative value implies
                                 *      that the entire stack will be printed                   */
             FILE *errFilep,    /* I    file pointer to errFile to which output about errors
                                 *      should be directed. If errFILE == NULL, no errors are
                                 *      printed.                                                */
             FILE *warnFilep,   /* I    file pointer to warnFile to which output about warnings  
                                 *      should be directed. If warnFILE == NULL, no warnings are 
                                 *      printed.                                                */
             INT  *iretp));      /*   O  error code
                                 *      == 0 - no error
                                 *      != 0 - error                                            */

 
/****************************************************************************
 *    Set the Shapes/xox warning mode                                       *
 ****************************************************************************/

 
      extern VOID xShapesSetWarnMode_xox ansPROTO((
             xINT mode,         /* I    warning generation mode.
                                 *      != 0 - it enables the generation of warnings.
                                 *             This is the default                 
                                 *      == 0 - warnings will be suppressed until a
                                 *             subsequent call to this function to
                                 *             enable warning.                       */
             INT  *iretp));     /*   O  error code
                                 *      == 0 - no error
                                 *      != 0 - error                                 */


 
/****************************************************************************
 *    Start Shapes Log facility                                             *
 ****************************************************************************/
 
 
      extern VOID xStartShapesLog_xox ansPROTO((
             xCHAR *filename,   /* I    Shapes LOG file name                       */
             INT  *iretp));     /*   O  error code
                                 *      == 0 - no error
                                 *      != 0 - error                               */
 



/****************************************************************************
 *    End Shapes Log facility                                               *
 ****************************************************************************/


      extern VOID xEndShapesLog_xox ansPROTO((
             INT  *iretp));     /*   O  error code
                                 *      == 0 - no error
                                 *      != 0 - error                               */



 
/**************************************************************************** 
 *    Free an identifier                                                    * 
 ****************************************************************************/ 
 
 
      extern VOID xFreeId_xox ansPROTO((
             INT  id,
             INT  *iretp));     /*   O  error code 
                                 *      == 0 - no error 
                                 *      != 0 - error                               */ 

 
/****************************************************************************
 *    Get the default boolean default tolerances                            *
 ****************************************************************************/
 
 
      extern VOID xGetTols_xox ansPROTO((
             xREAL tolerances[4], /*   O                                             */
             INT  *iretp));       /*   O  error code
                                   *      == 0 - no error
                                   *      != 0 - error                               */

 
/****************************************************************************
 *    Set the default boolean default tolerances                            *
 ****************************************************************************/
 
 
      extern VOID xSetTols_xox ansPROTO((
             xREAL tolerances[4], /* I                                             */
             INT  *iretp));       /*   O  error code
                                   *      == 0 - no error
                                   *      != 0 - error                             */
 

 
/****************************************************************************
 *    Set the mode for curve splitting                                      *
 ****************************************************************************/
 
 
      extern VOID xCurveSplitModeSet_xox ansPROTO((
             INT loop_splitting, /* I                                             */
             INT  *iretp));       /*   O  error code
                                   *      == 0 - no error
                                   *      != 0 - error                             */
 

 
/****************************************************************************
 *    Set the mode for Generating Default UserId                            *
 ****************************************************************************/
 
 
      extern VOID xGenerateDefaultUserIds_xox ansPROTO((
             INT mode, /* I                                             */
             INT  *iretp));       /*   O  error code
                                   *      == 0 - no error
                                   *      != 0 - error                             */
 
 

 
/****************************************************************************
 *    Set the mode for Propagating Default UserId                           *
 ****************************************************************************/
 
 
      extern VOID xPropagateUserIds_xox ansPROTO((
             INT mode, /* I                                             */
             INT  *iretp));       /*   O  error code
                                   *      == 0 - no error
                                   *      != 0 - error                             */
 
/****************************************************************************
 *    Set up the Error Handler                                              *
 ****************************************************************************/
 
 
      extern VOID xoxSetErrorHandler_xox ansPROTO((
             xINT_FUNC userErrorHandler, /* I                                      */
             INT  *iretp));       /*   O  error code
                                   *      == 0 - no error
                                   *      != 0 - error                             */



/****************************************************************************
 *    Clear XOX global error code                                           *
 ****************************************************************************/


      extern VOID xClearError_xox ansPROTO((
             INT  *iretp));       /*   O  error code
                                   *      == 0 - no error
                                   *      != 0 - error                             */

 



/****************************************************************************
 *    ? ? Free Ansys stack memory used by XOX                                   *
 ****************************************************************************/


      extern VOID xFreeAnsysMemory_xox ansPROTO((
             INT  *iretp));       /*   O  error code
                                   *      == 0 - no error
                                   *      != 0 - error                             */
 
