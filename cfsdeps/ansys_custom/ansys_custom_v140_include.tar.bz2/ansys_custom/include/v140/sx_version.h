/* CADOE */
/*
 *  sx_version.h
 *
 *  |Version: $Id: sx_version.h,v 1.3 2009/11/13 16:13:04 jtm Exp $
 *   
 * HISTORY
 *   
 *   11/22/00 12:18 <        Marc Gadbois> Rel:ms9      SCCA:83109  Delta:9.3
 *   
 *   09/25/00 10:39 <       Brian Jantzen> Rel:ms8m1    SCCA:79107  Delta:81.2
 *   
 *   09/30/99 17:38 <         James Silva> Rel:ms8      SCCA:56512  Delta:8.2
 */

#ifndef __SX_VERSIONH__
#define __SX_VERSIONH__ 1 /* protection contre lecture multiple */

#include "cadoe_version.h"

#endif
