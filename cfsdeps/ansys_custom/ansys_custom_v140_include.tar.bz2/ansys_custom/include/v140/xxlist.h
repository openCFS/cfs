
/*
 *    author/date: yu-hua ting/10-22-93
 *
 *    primary function:
 *
 *      Header for the Interface to SHAPES "List" routines
 *
 *    secondary function:
 *
 *        none
 *
 *    routines included:
 *
 *
 *    history
 *
 *        none
 *
 *    comments:
 *
 *        none
 *
 *    Notice - This file contains ANSYS Confidential information ***
 *
 */
/* 
 * *** copyright(c) 2011 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */

 
/****************************************************************************
 *    Create an empty integer list                                          *
 ****************************************************************************/
 
 
      extern xINT_LIST xIntListNew_xox ansPROTO((
             xINT   size,       /* I    initial array size. This can be any
                                        arbitrary size since the list array expand
                                        as required                                */
             xTAG    tag,       /* I    heap-specifier                             */
             INT  *iretp));     /*   O  error code
                                 *      == 0 - no error
                                 *      != 0 - error                               */


/****************************************************************************
 *    Create an integer list which is a copy from an array of integers      *
 ****************************************************************************/

  
      extern xINT_LIST xIntListFromArrayCopy_xox ansPROTO((
             xINT   *iarray,
             xINT    length,
             xTAG       tag,
             INT     *iretp));


/****************************************************************************
 *    Delete an integer list                                                *
 ****************************************************************************/


      extern xVOID xIntListDelete_xox ansPROTO((
             xINT_LIST list,
             INT      *iretp));   



/****************************************************************************
 *    Get the length of an integer list                                     *
 ****************************************************************************/


      extern xINT xIntListGetLength_xox ansPROTO((
             xINT_LIST list,
             INT     *iretp));    



/****************************************************************************
 *    Retrieve an element of the list                                       *
 ****************************************************************************/


      extern xINT xIntListGetNth_xox ansPROTO((
             xINT_LIST list,
             xINT         n,
             INT     *iretp));

 
/****************************************************************************
 *    Modify an element of the list                                         *
 ****************************************************************************/
 
 
      extern xINT_LIST xIntListSetNth_xox ansPROTO((
             xINT_LIST list,   
             xINT         n, 
             xINT     value,
             INT     *iretp)); 
 
 
/****************************************************************************
 *    Push an element to the beginning of a list                            *
 ****************************************************************************/
 
 
      extern xINT_LIST xIntListPush_xox ansPROTO((
             xINT_LIST list,
             xINT   element,
             INT     *iretp));  
 



 
/****************************************************************************
 *    Create an empty pointer list                                          *
 ****************************************************************************/
 
 
      extern xLIST xListNew_xox ansPROTO((
             xINT   size,       /* I    initial array size. This can be any
                                        arbitrary size since the list array expand
                                        as required                                */
             xTAG    tag,       /* I    heap-specifier                             */
             INT  *iretp));     /*   O  error code
                                 *      == 0 - no error
                                 *      != 0 - error                               */


/****************************************************************************
 *    Create a pointer list which is a copy from an array of pointers      *
 ****************************************************************************/

  
      extern xLIST xListFromArrayCopy_xox ansPROTO((
             xADDR   *iarray,
             xINT    length,
             xTAG       tag,
             INT     *iretp));


/****************************************************************************
 *    Delete a pointer list                                                *
 ****************************************************************************/


      extern xVOID xListDelete_xox ansPROTO((
             xLIST list,
             INT      *iretp));   



/****************************************************************************
 *    Get the length of a pointer list                                     *
 ****************************************************************************/


      extern xINT xListGetLength_xox ansPROTO((
             xLIST list,
             INT     *iretp));    



/****************************************************************************
 *    Retrieve an element of the list                                       *
 ****************************************************************************/


      extern xADDR xListGetNth_xox ansPROTO((
             xLIST list,
             xINT         n,
             INT     *iretp));

 
/****************************************************************************
 *    Modify an element of the list                                         *
 ****************************************************************************/
 
 
      extern xLIST xListSetNth_xox ansPROTO((
             xLIST list,   
             xINT         n, 
             xADDR     value,
             INT     *iretp)); 
 
 
/****************************************************************************
 *    Push an element to the beginning of a list                            *
 ****************************************************************************/
 
 
      extern xLIST xListPush_xox ansPROTO((
             xLIST list,
             xADDR element,
             INT     *iretp));  
 


