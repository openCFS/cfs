/* CADOE */
/*
 *  objetu.h	--  definitions rapportees a l'objet etude
 *   
 */
#ifndef __objetu_h__
#define __objetu_h__ 1

#include "sx_CADOE_solver.h"

inline void 
OBE_set_on( T_obj_etude *objetu, E_resultat_parametre irp )
{
  objetu->tab_a_calculer[irp] = VRAI;
}
inline void 
OBE_set_off( T_obj_etude *objetu, E_resultat_parametre irp )
{
  objetu->tab_a_calculer[irp] = FAUX;
}
inline T_booleen
OBE_is_on( T_obj_etude *objetu, E_resultat_parametre irp )
{
  return objetu->tab_a_calculer[irp];
}
inline T_booleen
OBE_is_off( T_obj_etude *objetu, E_resultat_parametre irp )
{
  return (objetu->tab_a_calculer[irp])? FAUX : VRAI;
}

extern T_statut OBE_allouer( T_obj_etude ** );
extern void OBE_liberer( T_obj_etude ** );
extern void OBE_zero_a_calculer( T_obj_etude* );
extern void OBE_init_a_calculer( T_obj_etude*, E_type_analyse, E_formulation );
extern T_statut OBE_write( T_obj_etude*, char* );
extern T_obj_etude* OBE_read( const _TCHAR*, T_statut* );
extern void OBE_options_defaut( T_obj_etude * );

#ifdef __cplusplus
extern "C" {
#endif

extern void cbf_obe_info( void *pobjetu, T_statut *ier );
extern T_statut         write_cbf_study( FILE *, T_obj_etude * );
extern void*            read_cbf_study( FILE *, void **, T_statut *);

  
#ifdef __cplusplus
}
#endif


#endif
