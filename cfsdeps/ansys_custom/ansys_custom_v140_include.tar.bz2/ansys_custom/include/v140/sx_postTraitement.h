/* CADOE */
/******************************************************************************* *
 *   postTraitement.h  --
 *               
 * 
 * |Module:  NBBVA
 *
 * |Description:  Constantes et fonctions de post-traitement
 *
 * |Includes:	
 *        
 * |Auteur: 
 *
 * |Creation: 1996
 *
 * |Version: $Id: sx_postTraitement.h,v 1.6 2010/04/16 20:11:12 srpailla Exp $
 *
 * |Historique:
 *
 * |Copyright:	copyright(c) 2010 SAS IP, Inc.  All rights reserved.
 *
 *
 *   
 ******************************************************************************/

#ifndef __POSTTR_H_DEJA_INCLUS__
#define __POSTTR_H_DEJA_INCLUS__ 1

#include "sx_cons_solver.h"
#include "sx_CADOE_solver.h"
#include "lmb.h"
#include "adoc.h"

#ifdef __cplusplus

#include "ADOC_Session.h"

extern VEC *FEM_exploiter_adoc( C_AdocSession *, char*, T_modele*, PAR*, PAR*, void*,
				BVEC*, VEC*, int*, double*, IVEC*, VEC *, VSTRUCT *,
				int*);

/*******************************************************************************
 *
 * |Fonction:  corrige_tenseur
 *
 * |Statut: public
 *
 * |Appel:
 *       corrige_tenseur( double*  champ_elem, T_booleen deformation, double* tenseur, T_modele *modele );
 *
 * |Arguments:
 *  
 *
 * |Retour:
 *  
 *
 * |Description: Correction des deformation afin de suprimer le facteur 2 present jusqu'ici dans les calculs
 *   Correction de l'ordre des composantes
 *
 ******************************************************************************/
inline void
corrige_tenseur( double *champ_elem, T_booleen deformation, double *tenseur, T_modele *modele )
{
  /* tenseur[0]=champ_elem[0];  XX */
  /* tenseur[1]=champ_elem[1];  YY */
  /* tenseur[2]=champ_elem[2];  ZZ */
  /* tenseur[3]=champ_elem[3];  XY */
  
  MEMCOPY( champ_elem, tenseur, 4, double);
  
  tenseur[4]=champ_elem[5]; /* XZ */
  tenseur[5]=champ_elem[4]; /* YZ */
  
  /*  if (deformation)
      {
      tenseur[0]=champ_elem[0];
      tenseur[1]=champ_elem[2];
      tenseur[2]=champ_elem[5];
      tenseur[3]=champ_elem[1]/2;
      tenseur[4]=champ_elem[3]/2;
      tenseur[5]=champ_elem[4]/2;
      }
      else 
      {*/
  /*    }*/
  
  return;
}
  
extern T_statut LCR_calculer( T_liste*, T_modele*, PAR*, VEC*, VEC*, T_res_cas_charge** );
  
extern "C" {

#else /* __cplusplus */

#error "This file must be included by C++ source files"

#endif

  extern VEC *FEM_exploiter_polynome( char*, T_modele*, PAR*, PAR*, void*, IVEC*, VEC*, int*, double*, IVEC*, VEC *, VSTRUCT *, int*);
  extern int FEM_init_exploitation( T_modele*, int , BVEC*, IVEC**, VEC **, VSTRUCT **);
  extern double FEM_exploiter_precision( int );

  extern double Mises( E_mode_analyse, double*, int );
  extern double Tresca( E_mode_analyse, double*, int );
  extern double Max_Stress_Shear( E_mode_analyse, double*, int );
  extern double ext_composante( E_mode_analyse, double *, int );
  extern double ext_composante_tenseur( E_mode_analyse, double *, int );
  extern double ext_composante_torseur( E_mode_analyse, double *, int );
  extern double ext_composante_vecteur( E_mode_analyse, double *, int );

  extern double Max_Cont_Princ( E_mode_analyse, double *, int);
  extern double Cont_Princ_comp( E_mode_analyse, double *, int);
  extern double PST_calculer_critere(T_critere *, VEC *, int *);
  extern T_booleen CRI_est_admissible( T_critere*, double );
  extern T_statut PST_maj_utile( T_critere* );
  extern void CRI_afficher( T_critere*, PAR*, FILE*, T_booleen );
  extern int indice_tableau_resultat( int );
  extern T_statut CRI_transformer( T_critere*, T_modele*, T_res_cas_charge * );
  extern T_statut RCC_liberer( T_res_cas_charge**, T_modele *, int nb_mod_char );
  extern T_statut RCC_allouer( T_res_cas_charge *, T_groupe *, int  );
  extern T_statut CRI_extraire_resultat( T_critere *, T_modele *, VEC *, T_res_cas_charge * );
  extern T_statut CRI_allouer_critere( T_critere **critere );
  extern T_statut LCR_tab_indice( T_liste *, T_modele *, BVEC ** );
  extern T_statut LCR_mappe_liste_critere( T_liste *  );
  extern T_statut LCR_mappe_liste_res( T_liste *  );
  extern T_statut CRI_calculer ( T_critere *, T_res_cas_charge *, PAR* );
  extern void CRI_afficher_critere( T_critere*, FILE*, T_booleen );
  extern T_booleen CRI_identifie( T_critere* );
  extern IVEC *lire_contraintes(int* );
  extern IVEC *lire_ddls( int* );
  extern IVEC *lire_reactions( int* );
  extern IVEC *lire_forces( int* );
  extern IVEC *lire_cp( int* );
  extern IVEC *lire_all_components( int* );
  extern IVEC *lire_zddls( T_modele* );
  extern void* CRI_read( FILE*, void**, T_modele*, T_statut* );
  extern T_statut CRI_write( FILE*, T_critere* );
  extern T_statut LCR_write( char*, char*, T_liste* );
  extern T_critere*   CRI_copier( T_critere *, T_statut * );
  extern void         CRI_free( void* );
  extern T_booleen    CRI_cmp( void*, void* );
  extern T_statut LCR_read( T_modele*, char*, T_liste** );
  extern T_statut LCR_extraire( T_liste *, T_modele *, PAR *, VEC *, VEC *, T_res_cas_charge ** );
  extern void LCR_afficher( T_liste *lcr, FILE *fic, T_booleen avec_limite );
  /* fonctions d'acces aux tables de crit.h */
  extern T_booleen TCR_rec_nature_resultat( E_resultat_parametre resultat, T_resnat *resnat );
  extern T_booleen TCR_rec_methode_base_crit( E_critere critere, T_methode *methode );
  extern T_booleen TCR_rec_scal_func( E_math_scal scalarisation, T_fct_compo *fct_compo );
  extern T_booleen TCR_rec_mappe_critere( int crit_ext, T_mapcrit *mapcrit);
  extern T_booleen TCR_transformation_disponible( int transformation );
  extern T_booleen TCR_rec_transformation( E_critere critere, T_modele *modele, T_trans_base *transbase );
  extern T_booleen TCR_rec_resultat( int critere, E_formulation, T_tableau_resultat *res );
  extern T_booleen TCR_rec_ieme_resultat( int ieme, E_formulation, T_tableau_resultat *res );
  extern T_booleen TCR_rec_peau( int peau, T_menu_comp *tabpeau );
  extern T_booleen TCR_rec_comp_defaut( E_component_type type, T_menu_comp *tabcomp );
  extern T_booleen TCR_rec_ieme_comp_type( E_component_type type, int ieme, T_menu_comp *tabcomp );
  extern T_booleen TCR_rec_zcomp( int zcomp, T_menu_comp *tabzcomp );

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif	 /* __POSTTR_H_DEJA_INCLUS__ */
