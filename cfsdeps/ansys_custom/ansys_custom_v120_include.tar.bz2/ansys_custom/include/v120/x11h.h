/* 
 * *** copyright(c) 2009 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */

/***********************************************/
/******  include file used for x11 driver  *****/
/***********************************************/

#if defined(RS6000_SYS) || defined(HP32_SYS)
    /*  c routines called from fortran  */
#define rlslowzz_ rlslowzz
#define rlfastzz_ rlfastzz
#define qlfastzz_ qlfastzz
#define boxzz_  boxzz
#define ldmpzz_ ldmpzz
#define aclrzz_ aclrzz
#define beepzz_ beepzz
#define cmapzz_ cmapzz
#define dmodzz_ dmodzz
#define drwlns_ drwlns
#define drwply_ drwply
#define drwpt_ drwpt 
#define drwtxt_ drwtxt
#define dumpzz_ dumpzz
#define eraszz_ eraszz
#define flshzz_ flshzz
#define gclrzz_ gclrzz
#define gcstuf_ gcstuf
#define getxcl_ getxcl
#define getzzz_ getzzz
#define gtpkzz_ gtpkzz
#define gtwnxy_ gtwnxy
#define killit_ killit
#define loadzz_ loadzz
#define opndis_ opndis
#define opnwin_ opnwin
#define pkpxzz_ pkpxzz
#define popzz_ popzz 
#define pushzz_ pushzz
#define savezz_ savezz 
#define segzz_ segzz 
#define setwzz_ setwzz 
#define setlnz_ setlnz
#define marksz_ marksz
#define strtzz_ strtzz
#define tclrzz_ tclrzz
#define tsizzz_ tsizzz
#define windzz_ windzz
#define visgzz_ visgzz
#define settzz_ settzz
#define fontzz_ fontzz  
#define charzz_ charzz  
#define lgwhzz_ lgwhzz  
#define txtmagzz_ txtmagzz  
#define txtr_imag_zz_ txtr_imag_zz  
#define logowhzz_ logowhzz  
#define antypezz_ antypezz  
#define fntiqrzz_ fntiqrzz  
    /*  fortran routines called from c  */
#define refrsh_ refrsh
#define sizezz_ sizezz
#endif


#if defined(WATCOMC_SYS) \
    || defined(PCWINNT_SYS)
    /*  c routines called from fortran  */
#define rlslowzz_ RLSLOWZZ
#define rlfastzz_ RLFASTZZ
#define qlfastzz_ QLFASTZZ
#define boxzz_  BOXZZ
#define ldmpzz_ LDMPZZ
#define aclrzz_ ACLRZZ
#define beepzz_ BEEPZZ
#define cmapzz_ CMAPZZ
#define dmodzz_ DMODZZ
#define drwlns_ DRWLNS
#define drwply_ DRWPLY
#define drwpt_ DRWPT 
#define drwtxt_ DRWTXT
#define dumpzz_ DUMPZZ
#define eraszz_ ERASZZ
#define flshzz_ FLSHZZ
#define gclrzz_ GCLRZZ
#define gcstuf_ GCSTUF
#define getxcl_ GETXCL
#define getzzz_ GETZZZ
#define gtpkzz_ GTPKZZ
#define gtwnxy_ GTWNXY
#define killit_ KILLIT
#define loadzz_ LOADZZ
#define opndis_ OPNDIS
#define opnwin_ OPNWIN
#define pkpxzz_ PKPXZZ
#define popzz_ POPZZ 
#define pushzz_ PUSHZZ
#define savezz_ SAVEZZ
#define segzz_ SEGZZ 
#define setwzz_ SETWZZ
#define setlnz_ SETLNZ
#define marksz_ MARKSZ
#define strtzz_ STRTZZ
#define tclrzz_ TCLRZZ
#define tsizzz_ TSIZZZ
#define windzz_ WINDZZ
#define visgzz_ VISGZZ
#define settzz_ SETTZZ
#define fontzz_ FONTZZ
#define charzz_ CHARZZ
#define lgwhzz_ LGWHZZ
#define txtmagzz_ TXTMAGZZ
#define txtr_imag_zz_ TXTR_IMAG_ZZ
#define logowhzz_ LOGOWHZZ
#define antypezz_ ANTYPEZZ
#define fntiqrzz_ FNTIQRZZ
    /*  fortran routines called from c  */
#define refrsh_ REFRSH
#define sizezz_ SIZEZZ
#endif


#if defined(WATCOMC_SYS) 
#pragma aux RLSLOWZZ "^";
#pragma aux RLFASTZZ "^";
#pragma aux QLFASTZZ "^";
#pragma aux BOXZZ  "^";
#pragma aux LDMPZZ "^";
#pragma aux ACLRZZ "^";
#pragma aux BEEPZZ "^";
#pragma aux CMAPZZ "^";
#pragma aux DMODZZ "^";
#pragma aux DRWLNS "^";
#pragma aux DRWPLY "^";
#pragma aux DRWPT  "^";
#pragma aux DRWTXT "^";
#pragma aux DUMPZZ "^";
#pragma aux ERASZZ "^";
#pragma aux FLSHZZ "^";
#pragma aux GCLRZZ "^";
#pragma aux GCSTUF "^";
#pragma aux GETXCL "^";
#pragma aux GETZZZ "^";
#pragma aux GTPKZZ "^";
#pragma aux GTWNXY "^";
#pragma aux KILLIT "^";
#pragma aux LOADZZ "^";
#pragma aux OPNDIS "^";
#pragma aux OPNWIN "^";
#pragma aux PKPXZZ "^";
#pragma aux POPZZ  "^";
#pragma aux PUSHZZ "^";
#pragma aux SAVEZZ "^";
#pragma aux SEGZZ  "^";
#pragma aux SETWZZ "^";
#pragma aux SETLNZ "^";
#pragma aux MARKSZ "^";
#pragma aux STRTZZ "^";
#pragma aux TCLRZZ "^";
#pragma aux TSIZZZ "^";
#pragma aux VISGZZ "^";
#pragma aux WINDZZ "^";
#pragma aux REFRSH "^";
#pragma aux SIZEZZ "^";
#pragma aux SETTZZ "^";
#pragma aux FONTZZ "^";
#pragma aux CHARZZ "^";
#pragma aux LGWHZZ "^";
#pragma aux TXTMAGZZ "^";
#pragma aux TXTR_IMAG_ZZ "^";
#pragma aux LOGOWHZZ "^";
#pragma aux ANTYPEZZ "^";
#pragma aux FNTIQRZZ "^";
#endif

/*      FUNCTION RETURN TYPE DECLARATION     */

#if !defined(PCWINNT_SYS)
/*  FORTRAN routine called from C  */
  void sizezz_();
#else
   extern void CALLTYP sizezz_( INT * );
#endif
