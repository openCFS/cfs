////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         Copyright (C) 2009 ANSYS Inc.  All Rights Reserved             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MAT_ICExponentialForm.h $
// $Revision: 1.3.2.1 $ 7.0
// $Date: 2009/04/13 14:09:59 $ March 28 2002
// $Author: jtm $ rjayasee
//
// Decription :
//              This class implement Exponential Form Implicit Creep Model
// This is for secondary creep.
////////////////////////////////////////////////////////////////////////////// 

#if !defined(MAT_ICExponentialForm_H)
#define MAT_ICExponentialForm_H

#include  "MAT_ConstitutiveFunction.h"
#include  "MAT_Creep.h"

class MAT_ICExponentialForm  : public MAT_Creep
{
public:

	MAT_ICExponentialForm();
    // Default Constructor.

    static MAT_Creep* Construct() ;

    virtual bool FunctionValue( double* pVariables, INT iNumVariables,
                                double* pInputVariables, INT iNumInputVariables, double& dCreepStrainRate ) ;
    //I pVariable
    //I-Value of Coefficients
    //I iNumVariables
    //I- Number of variables
    //I dInputVariables
    //I-Input Variables
    //I iNumInputVariables
    //I-Num Input Variables
    //I dCreepStrainRate
    //I-Calculated Value of Creep Strain Rate
    //R- Calculates the value of the Creep Strain Rate 

    virtual bool FirstDerivativeOfUnsquaredError
         ( double* pVariables,INT iNumVariables,
           double* pInputVariables, INT iNumInputVariables,
           INT iVariableIndex, double& dResult ) ;
    //I pVariable
    //I-Value of Coefficients
    //I iNumVariables
    //I- Number of variables
    //I dInputVariables
    //I-Input Variables
    //I iNumInputVariables
    //I-Num Input Variables
    //I iVariableIndex
    //I-Variable w.r.t which the derivative is to be calculated
    //I dResult
    //I-Calculated value of derivative
    //R- Calculates the value of the Creep Strain Rate 
               
    virtual void Print() ;
    // Prints the constitutive function

    virtual ~MAT_ICExponentialForm();
    //Destructor

    virtual void EliminateTemperatureCoefficients();
    //Elimnates Temperature term and fixes it.

protected:



} ;


class MAT_ICExponentialFormFactory
{
    public:

    static MAT_ICExponentialFormFactory* Instance() ;
    //I Pointer to Creep Factory
    //- Pointer to Singleton Instantiator

    static void Destroy() ;
    ~MAT_ICExponentialFormFactory() ;
    // Destructor

    private:

    MAT_ICExponentialFormFactory() ;
    // Constructor

    static MAT_ICExponentialFormFactory* m_pInstance ;
    //Pointer to only instance of this class
} ;

#endif // !defined(MAT_ICExponentialForm_H)
