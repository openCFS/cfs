/*HFILE msgdfc.h                                             mpg
------------------------------------------------------------------------
------- Notice - This file contains ANSYS Confidential information
------------------------------------------------------------------------
*/

/*------------------------------ Description ---------------------------
\Author:        Miklos Gyimesi, Ph.D. (mpg)
\Title:         fortran <-> c message header
\Desc:          This is header for msgdfc.cpp for fortran <-> messagfe passing
\History:       06/05/10 - mpg: Initial creation.

\Function(s)
 -Primary:      Provide interface to fortran msg routines from c
 ----------------------------------------------------------------------*/

/*------------------------------ Header files ------------------------*/

#include "ansys.h"
#include "syssys.h"
#include "computer.h"
#include "globals.h"
#include "cAns_printf.h"
#include "sysparh.h"
#include "cwrap_ansys.h"

/*
#include <iostream>
#include <string>
#include "string.h"
#include <string.h>
#include <ctype.h>
#include <stdio.h>
#include "stdio.h"
//#include "nbbP.h"
*/

/*---------------------------- Start Of Module -------------------------*/

#ifndef __MSGDFC_H__
#define __MSGDFC_H__ 1

#if defined(LOWERCASENOUNDER_SYS)
#define msgdc1 msgdc1
#define msgdc2 msgdc2
#define msgdc3 msgdc3
#define msgdc4 msgdc4
#define msgdc5 msgdc5
#define msgdc6 msgdc6
#define msgc msgc
#define msgf msgf
#define msgct msgct
#define msgci msgci
#define msgcr msgcr
#define msgciv msgciv
#define msgcrv msgcrv
#define msgcrmf msgcrmd
#define msgcrtf msgcrtd
#define msgcrmc msgcrmc
#define msgcrtc msgcrtc
#define str2iv str2iv
#define msgdget msgdget
#endif

#if defined(UPPERCASENOUNDER_SYS)
#define msgdc1 MSGDC1
#define msgdc2 MSGDC2
#define msgdc3 MSGDC3
#define msgdc4 MSGDC4
#define msgdc5 MSGDC5
#define msgdc6 MSGDC6
#define msgc MSGC
#define msgf MSGF
#define msgct MSGCT
#define msgci MSGCI
#define msgcr MSGCR
#define msgciv MSGCIV
#define msgcrv MSGCRV
#define msgcrmf MSGCRMF
#define msgcrtf MSGCRTF
#define msgcrmc MSGCRMC
#define msgcrtc MSGCRTC
#define str2iv STR2IV
#define msgdget MSGDGET
#endif

#if defined(LOWERCASEUNDER_SYS)
#define msgdc1 msgdc1_
#define msgdc2 msgdc2_
#define msgdc3 msgdc3_
#define msgdc4 msgdc4_
#define msgdc5 msgdc5_
#define msgdc6 msgdc6_
#define msgc msgc_
#define msgf msgf_
#define msgct msgct_
#define msgci msgci_
#define msgcr msgcr_
#define msgciv msgciv_
#define msgcrv msgcrv_
#define msgcrmf msgcrmf_
#define msgcrtf msgcrtf_
#define msgcrmc msgcrmc_
#define msgcrtc msgcrtc_
#define str2iv str2iv_
#define msgdget msgdget_
#endif

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

  SUBROUTINE msgdc1 (void);
  SUBROUTINE msgdc2 (INT * i, DOUBLE * d);
  SUBROUTINE msgdc3 (INT * i, DOUBLE * d);
  SUBROUTINE msgdc4 (INT * i, DOUBLE * d);
  SUBROUTINE msgdc5 (INT * i, INT * iv);
  SUBROUTINE msgdc6 (INT * n, INT * m, DOUBLE * dv);

  SUBROUTINE msgct (char * ch);
  SUBROUTINE msgci (char * ch, INT * ii);
  SUBROUTINE msgcr (char * ch, DOUBLE * dd);
  SUBROUTINE msgciv (char * ch, INT * ii, INT * nn);
  SUBROUTINE msgcrv (char * ch, DOUBLE * dd, INT * nn);
  SUBROUTINE msgcrmf (char * ch, DOUBLE * dd, INT * nn, INT * mm);
  SUBROUTINE msgcrtf (char * ch, DOUBLE * dd, INT * nn, INT * mm);
  SUBROUTINE msgcrmc (char * ch, DOUBLE * dd, INT * nn, INT * mm);
  SUBROUTINE msgcrtc (char * ch, DOUBLE * dd, INT * nn, INT * mm);
  SUBROUTINE msgc (INT * key, char * msg
                 , INT * ii, DOUBLE * dd, INT * nn, INT * mm);

  SUBROUTINE msgf (INT * key, INT * imsg, INT * lmsg
                 , INT * ii, DOUBLE * dd, INT * nn, INT * mm);

  SUBROUTINE str2iv (char * ch, INT * iv);
  INT FUNCTION msgdget (void);
#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __MSGDFC_H__ */
