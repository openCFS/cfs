////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         Copyright (C) 2009 ANSYS Inc.  All Rights Reserved             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MAT_API.h $
// $Revision: 1.3.2.1 $ 7.0
// $Date: 2009/04/13 14:09:59 $ March 28 2002
// $Author: jtm $ rjayasee/jlo
//
// Decription :
// This is the C++ Entry point for the Material Subsystem
// This class defines the API for the whole material subsystem  or
// component. This provides handles to the material data and the tools
// to generate or manipulate them. This is primarily a C++ API.  Maybe
// a COM wrapper can be build with this. This is to be investigated. But
// this is not an issue for now.
// This class also has a pointer to the Material Database. The material
// database is currently stored here as there is no C++ database yet. If
// there is another location. We should be able to launch an API or multiple
// APIs for each database. API/Components are generally assumed to be
// stateless. To be researched further.
////////////////////////////////////////////////////////////////////////////

#if !defined(MAT_API_H)
#define MAT_API_H

#if defined(WBCURVEFIT)
#include "ANS_StandardIncludes.h"
#endif

class MAT_ExperimentalData ;
class MAT_ExperimentalDataFormat ;
class MAT_ExperimentalDataSet ;
class MAT_ConstitutiveModel ;
class MAT_ConstitutiveFunction ;
struct MAT_CFAttribute ;
 
//Mechanism to Create Cases.
struct MAT_CFDefinition
{
    MAT_CFDefinition() ;
    // Constructor

    ~MAT_CFDefinition() ;
    // Destructor

    bool AddAttribute( ANS_String const& oAttributeName, ANS_String const& oAttributeValue ) ;
    //R success or failure of the function
    //I oAttributeName
    //I-Name of the Attribute
    //I oAttributeValue
    //I-String Value of the Attribute
    //- Adds the Attribute with this name

    bool GetAttributeValue( ANS_String const& oAttributeName, ANS_String& oAttributeValue ) ;
    //R success or failure of the function
    //I oAttributeName
    //I-Name of the Attribute
    //O oAttributeValue
    //O-String Value of the Attribute
    //- Gets the value of an attribute with this name
    
    void DeleteAttribute( ANS_String const& oAttributeName ) ;
    //R void
    //I oAttributeName
    //I-Name of the Attribute
    //- Removes and Delete the Attribute with this name

    vector<MAT_CFAttribute*> m_pCFAttributes ;
} ;

enum MAT_AttributeType
{
    MAT_Unknown = -1,
    MAT_Integer = 0,
    MAT_Real = 1,
    MAT_String = 2
} ;

enum MAT_ExperimentType
{
    EXP_UNKNOWN = -1,
    EXP_UNIAXIAL = 1,
    EXP_BIAXIAL = 2,
    EXP_SHEAR = 3,
    EXP_VOLUMETRIC = 4,
    EXP_SIMPLESHEAR = 5,
    EXP_SIMPLESHEAR_SHEARSTRESS = 6,
    EXP_SIMPLESHEAR_TRANSVERSESTRESS = 7,
    EXP_SHEARMODULUSVSTIME = 8,
    EXP_BULKMODULUSVSTIME = 9,
    EXP_CREEP = 10
} ;

class MAT_AttributeTypeInfo
{
        map<ANS_String,MAT_AttributeType> m_oAttribTypeMap ;

    public:

        void AddAttributeType(ANS_String oAttribName, MAT_AttributeType oAttribType) ;
        //Add an AttributeType to the List

        bool GetAttributeType(ANS_String oAttribName, MAT_AttributeType& oAttribType) const ;
        //Gets the attribute type
} ;


struct MAT_CombinationCFDefinition
{
    MAT_CombinationCFDefinition() ;
    // Constructor

    ~MAT_CombinationCFDefinition() ;
    // Destructor

    void Clear() ;
    // Reset/Clears all Data

    vector<MAT_CFDefinition*> m_oCFDefinitionVector ;
    //Private Data

    ANS_String m_oName ;
    ANS_String m_oType ;

    bool m_bActive ;
} ;

class MAT_Api  
{
    public:

        static MAT_Api* Instance() ;
        //R-MAT_Api*
        //R-Pointer to the only Material API object
        //F-Static Constructor
        //F-Returns a pointer to the only existing MAT_Api object

        static void Destroy() ;
        // Destroys the singleton object

        void GetMaterialIDList( vector<INT>& oMatIDList ) ;
        //R void
        //O oMatIDList
        //O-Vector of Material ID List
        //- This function returns a vector of material id list

        bool ConstructConstitutiveModel
            ( INT iMatID,
              MAT_ConstitutiveModel *& pConstModel ) ;
        //R-bool
        //R-Status. If the oMat already exists it returns false.
        //R-*** Warning/Error in this code. It always return true  ***
        //R-*** Even when the material already exists ***
        //I-iMatID
        //I-The new material id to tbe constructed
        //O-pConstModel
        //O-The constructed Constitutive Model
        //- This adds a constitutive model to the material database

        bool GetConstitutiveModel
            ( INT iMatID,
              MAT_ConstitutiveModel *& pConstModel ) ;
        //R-bool
        //R-Status. If the oMat already exists it returns false.
        //R-*** Warning/Error in this code. It always return true  ***
        //R-*** Even when the material already exists ***
        //I-iMatID
        //I-The new material id to tbe constructed
        //O-pConstModel
        //O-The constructed Constitutive Model
        //- This gets a constitutive model from the material database

        bool PrintConstitutiveModel ( INT iMatID ) ;
        //R-bool
        //R-false if the material does not exist
        //I-iMatID
        //I-Material ID/ Constitutive Model ID
        //- Print ConstitutiveModel Data

        //************************* Experimental Data Functionality ************************

        bool AddExperimentalData
            ( INT iMatID,
              ANS_String oFileName,
              MAT_ExperimentalDataFormat* pExpDataFormat ) ;
        //R-Status
        //R-false if the oConsFuncName does not exist(**fix this**)
        //R-false if the oFileName does not exist
        //I-iMatID
        //I-Constitutive Model ID
        //I-oFileName
        //I-Name of the File to read this from
        //I-pExpDataFormat
        //I-Pointer to the ExperimetalData Format to be used to read this
        //I-data
        //F-This function add an experimental data file to the Model
        //- Currently implemented to space delimited file. Can be extended
        //- easily.*** Need to add this to the parameter list ***

        bool ConstructExperimentalDataFormat
            ( ANS_String const& oExpName,
              vector<ANS_String*> const& oExpVarNames,
              MAT_ExperimentalDataFormat *& pExpDataFormat ) ;
        //R bool
        //I oExpName
        //I-Name of the Experiment
        //I oExpVarNames
        //I-Variable Names of the X-Y-Z... data
        //O pExpDataFormat
        //O-The constructed experimental data format object pointer
        //- Construct Experimental Data Format

        void GetExtendedExperimentName( INT iMatID,
                                        ANS_String pConsFuncName,
                                        ANS_String pShortName,
                                        ANS_String& pExtName ) ;
        //R void
        //I iMatId
        //I-Material ID List
        //I oConsFuncName
        //I-Name of the Constitutive Function
        //I pShortName
        //I pExtName
        //- Full Detailed Name of the Experiment

        bool GetSlashAttributesFromFile
            ( ANS_String oFileName,
              vector<MAT_CFAttribute*>& oAttributeList ) ;
        //R bool
        //R-false If file does not exist,
        //I oFileName
        //I-Name of the File
        //O oAttributeList
        //O-Attribute List
        //- Gets a list of Attributes from a text file
        
        INT AddExperimentalData( INT iMatId, ANS_String oExpType ) ;
        //I INT
        //I-iIndex of Experiment
        //I iMatId
        //I-Material Id
        //I oExpType
        //I-Experiment Type
        //I-Creates an Experimental Data

        bool AddExperimentalDataPoint( INT iMatId, INT iExpIndex, vector<double> oPoint ) ;
        //I INT
        //I iMatId
        //I-Material Id
        //I iExpIndex
        //I-Index of Experiment ( 0 to N-1 )
        //I oPoint
        //I-Point Data
        //- Adds a Point to an Experiment

        bool SetExperimentalDataColumnNames( INT iMatId, INT iExpIndex, vector<ANS_String> oColNames ) ;
        //I INT
        //I iMatId
        //I-Material Id
        //I iExpIndex
        //I-Index of Experiment ( 0 to N-1 )
        //I oColNames
        //I-Column Names
        //- Sets Column Names

        bool SetExperimentalDataAttribute( INT iMatId, INT iExpIndex,
                                           ANS_String oAttribName,
                                           ANS_String oAttribVal ) ;
        //I INT
        //I iMatId
        //I-Material Id
        //I iExpIndex
        //I-Index of Experiment ( 0 to N-1 )
        //I oAttribName
        //I-Attribute Name
        //I oAttribVal
        //I-Attribute Val
        //- Sets an experimental data attribute

        bool SetExperimentalDataAttribute( INT iMatId, INT iExpIndex,
                                           ANS_String oAttribName,
                                           double oAttribVal ) ;
        //I INT
        //I iMatId
        //I-Material Id
        //I iExpIndex
        //I-Index of Experiment ( 0 to N-1 )
        //I oAttribName
        //I-Attribute Name
        //I oAttribVal
        //I-Attribute Val
        //- Sets an experimental data attribute

        bool SetExperimentalDataAttribute( INT iMatId, INT iExpIndex,
                                           ANS_String oAttribName,
                                           INT oAttribVal ) ;
        //I INT
        //I iMatId
        //I-Material Id
        //I iExpIndex
        //I-Index of Experiment ( 0 to N-1 )
        //I oAttribName
        //I-Attribute Name
        //I oAttribVal
        //I-Attribute Val
        //- Sets an experimental data attribute

        bool GetExperimentalDataAttribute( INT iMatId, INT iExpIndex,
                                           ANS_String oAttribName,
                                           ANS_String& oAttribVal ) ;
        //I INT
        //I iMatId
        //I-Material Id
        //I iExpIndex
        //I-Index of Experiment ( 0 to N-1 )
        //I oAttribName
        //I-Attribute Name
        //I oAttribVal
        //I-Attribute Val
        //- Gets an experimental data attribute

        bool GetExperimentalDataAttribute( INT iMatId, INT iExpIndex,
                                           ANS_String oAttribName,
                                           double& oAttribVal ) ;
        //I INT
        //I iMatId
        //I-Material Id
        //I iExpIndex
        //I-Index of Experiment ( 0 to N-1 )
        //I oAttribName
        //I-Attribute Name
        //I oAttribVal
        //I-Attribute Val
        //- Gets an experimental data attribute

        bool GetExperimentalDataAttribute( INT iMatId, INT iExpIndex,
                                           ANS_String oAttribName,
                                           INT& oAttribVal ) ;
        //I INT
        //I iMatId
        //I-Material Id
        //I iExpIndex
        //I-Index of Experiment ( 0 to N-1 )
        //I oAttribName
        //I-Attribute Name
        //I oAttribVal
        //I-Attribute Val
        //- Gets an experimental data attribute

        bool GetExperimentNameList( INT iMatID,
                                    vector<ANS_String const*>& oExpNameList ) ;
        //R bool
        //I iMatId
        //I-Material ID
        //I oConsFuncName
        //I-Name of the Constitutive Function
        //O oExpNameList
        //O-List of Experiment Names
        //- This function returns a list of experiment names given
        //- a Material Id and a Constitutive Function Name

        bool GetNumberOfExperimentalDataPoints( INT iMatID,
                                                INT iExpID,
                                                INT& iNumPoints ) ;
        //R bool
        //R-false if such an entity does not exist
        //I iMatId
        //I-Material ID
        //I oConsFuncName
        //I-Name of the Constitutive Function
        //I iExpID
        //I-ID of the Experiment
        //O iNumPoints
        //O- Number of Points
        //- Returns the number of points in the experimental data
       
        bool GetExperimentalDataPoint( INT iMatID,
                                       INT iExpID,
                                       INT iPointId,
                                       vector<double> const*& oPoint ) ;
        //R bool
        //I iMatId
        //I-Material ID List
        //I oConsFuncName
        //I-Name of the Constitutive Function
        //I iExpID
        //I-ID of the Experiment
        //O oExpNameList
        //O-List of Experiment Names
        //- This function returns a list of experiment names given
        //- a Material Id and a Constitutive Function Name

        //************************* END Experimental Data Functionality ************************

        ANS_String const * GetConstitutiveFunctionType( INT iMatID, ANS_String const& oCFName ) ;
        //R ANS_String*
        //R-Type of the Constitutive Function
        //I iMatID
        //I-Material ID
        //I oCFName
        //I-Constitutive Function Name
        //- This function return the Constitutive Function Name

        bool GetConstitutiveFunctionNameList( INT iMatID,
                                              vector<ANS_String const*>& oConsFuncNameList ) ;
        //R bool
        //I iMatId
        //I-Material ID
        //O oConsFuncNameList
        //O-List of Constitutive Function Names
        //- This function returns a list of constitutive function names

        bool CalculateFittedExperimentalDataPoint( INT iMatID,
                                                   ANS_String oConsFuncName,
                                                   INT iExpID,
                                                   INT iPointId,
                                                   vector<double>& oPoint ) ;
        //R bool
        //I iMatId
        //I-Material ID List
        //I oConsFuncName
        //I-Name of the Constitutive Function
        //I iExpID
        //I-ID of the Experiment
        //O oExpNameList
        //O-List of Experiment Names
        //- This function returns a list of experiment names given
        //- a Material Id and a Constitutive Function Name

        bool CalculateFittedExperimentalDataPoint( INT iMatId,
                                                   ANS_String const& oConsFuncName,
                                                   ANS_String const& oExperimentType,
                                                   vector<MAT_CFAttribute*> const& oParamVector,
                                                   double& oCalculatedValue ) ;
        //R Status of Function
        //I iMatId
        //I-Material ID
        //I oConsFuncName
        //I-Name of the Constitutive Function
        //I oExperimentType
        //I-Type of Experiment
        //I oParamVector
        //I-Vector of Parameters
        //O oCalculateValue
        //O-Value of Fitted Data
        //- Calculated Fitted Data Given Input

        bool GetResidual( INT iMatID,
                          ANS_String oConsFuncName,
                          double& dResidual ) ;
        //R bool
        //I iMatId
        //I-Material ID List
        //I oConsFuncName
        //I-Name of the Constitutive Function
        //O dResidual
        //O-Calculated Residual
        //- This function returns the calculated residual
        //- a Material Id and a Constitutive Function Name


        bool AddConstitutiveFunction
            ( INT iMatID,
              ANS_String const& oFunctionName,
              vector<MAT_CFAttribute*>const& pAttributeVector,
              MAT_ConstitutiveFunction*& pConsFunc) ;
        //R bool
        //R-true if this was completed successfully
        //I iMatID
        //I-The constitutive function name to be constructed
        //I oConsFuncName
        //I-Constitutive Function Name
        //I pConsFunc
        //I-Pointer to the cons function constructed
        //- Constructs a Constitutive Function given a name and 
        //- within the Material Model

        bool SetConstitutiveFunctionData
            ( INT iMatID,
              ANS_String const& oConsFuncName,
              ANS_String const& oParameterName,
              double const& oParameterDataVector ) ;
        //R bool
        //R-true if success. Fails if the MaterialID or the
        //R-function type does not exist.
        //I iMatID
        //I-ID of the Material Model
        //I oConsFuncName
        //I-Constitutive Function Name
        //I oParameterName
        //I-Parameter Names for the Constitutive Function
        //I oParameterData
        //I-corresponding(w.r.t to oParameterNameList) Parameter Data 
        //I-for the ConstitiveFunction
        //- Set the Constitutive Function Data Directly

        bool SetConstitutiveFunctionData
            ( INT iMatID,
              ANS_String const& oConsFuncName,
              ANS_String const& oParameterName,
              ANS_String const& oParameterData ) ;
        //R bool
        //R-true if success. Fails if the MaterialID or the
        //R-function type does not exist.
        //I iMatID
        //I-ID of the Material Model
        //I oConsFuncName
        //I-Constitutive Function Name
        //I oParameterName
        //I-Parameter Names for the Constitutive Function
        //I oParameterData
        //I-corresponding(w.r.t to oParameterNameList) Parameter Data 
        //I-for the ConstitiveFunction
        //- Set the Constitutive Function Data Directly
        //- This is not coefficient data like tref and active

        bool SetConstitutiveFunctionData
            ( INT iMatID,
              ANS_String const& oConsFuncName,
              vector<ANS_String> const& oParameterNameVector,
              vector<double> const& oParameterDataVector ) ;
        //R-bool
        //R-true if success. Fails if the MaterialID or the
        //R-function type does not exist.
        //I-iMatID
        //I-ID of the Material Model
        //I-oConsFuncName
        //I-Constitutive Function Name
        //I-oParameterNameVector
        //I-Vector of Parameter Names for the Constitutive Function
        //I-oParameterDataVector
        //I-Vector of corresponding(w.r.t to oParameterNameList Parameter Data 
        //I-for the ConstitiveFunction
        //- Sets All Constitutive Function Data Directly in one GO. Cleans out all
        //- old data(Warning).

        bool SetConstitutiveFunctionCoefficientFixedFlag
            ( INT iMatID,
              ANS_String const& oConsFuncName,
              INT iCoeffIndex,
              bool bCoeffFixedFlag ) ;
        //R-bool
        //R-true if success. Fails if the MaterialID or the
        //R-function type does not exist.
        //I-iMatID
        //I-ID of the Material Model
        //I-oConsFuncName
        //I-Constitutive Function Name
        //I iCoeffIndex
        //I-Index of the Coeff
        //I bCoeffFixed
        //I-If the coeff is fixed use bool true else use bool false
        //- Function to Set if the Coeff is Fixed

        bool GetConstitutiveFunctionCoefficientFixedFlag
            ( INT iMatID,
              ANS_String const& oConsFuncName,
              INT iCoeffIndex,
              bool& bCoeffFixedFlag ) ;
        //R-bool
        //R-true if success. Fails if the MaterialID or the
        //R-function type does not exist.
        //I-iMatID
        //I-ID of the Material Model
        //I-oConsFuncName
        //I-Constitutive Function Name
        //I iCoeffIndex
        //I-Index of the Coeff
        //O bCoeffFixed
        //O-If the coeff is fixed use bool true else use bool false
        //- Function to Get if the Coeff is Fixed

        
        bool DeleteConstitutiveModel
            ( INT iMatID ) ;
        //R-bool
        //R-Status. If the iMatId does not exist it returns false.
        //I-iMatID
        //I-The material id to be deleted
        //- This deletes a constitutive model from the material database

        bool DeleteConstitutiveFunction
            ( INT iMatID,
              ANS_String const& oFunctionName ) ;
        //R bool
        //R-true if this was completed successfully
        //I iMatID
        //I-The constitutive function name to be constructed
        //I oConsFuncName
        //I-Constitutive Function Name
        //- Deletes a Constitutive Function given a name and 
        //- within the Material Model

        bool DeleteCoefficients
            ( INT iMatID,
              ANS_String const& oFunctionName ) ;
        //R bool
        //R-true if this was completed successfully
        //I iMatID
        //I-The constitutive function name to be constructed
        //I oConsFuncName
        //I-Constitutive Function Name
        //- Deletes a Constitutive Function's coefficients at par temp
        
        bool DeleteExperimentalData
            ( INT iMatID,
              INT iExpDataId ) ;
        //R bool
        //I iMatID
        //I-Material ID
        //I oConsFuncName
        //I-Constitutive Function Name
        //I iExpDataId
        //I Experimental Data Id 0-N-1
        //- Deletes the nth Experimental Data Object from the list

        MAT_ExperimentType StringToExperimentType( ANS_String const& oExpName ) const ;
        //R oExpType
        //I oExpName
        //I-Name of Experiment
        //- Converts a ExperimentName to Enum

        bool GenerateMaterialParameters
            ( INT iMatID,
              ANS_String oConsFuncName,
              vector<MAT_CFAttribute*> const& oAttributeList ) ;
        //R-bool
        //R-IF the MaterialID or the oConsFuncName or requred Exp does 
        //R-not exist, this function returns false
        //I-iMatID
        //I-ConstitutiveModel ID
        //I-oConsFunName
        //I-Name of the Constitutive Function(eq mooney...)
        //I oAttributeList
        //- List of necessary Attributes like initial value,
        //- number of iterations, convergence criteria....
        //F-Generated Material Parameters from Experimental Data
        
        bool GetConstitutiveFunctionData
            ( INT iMatID,
              ANS_String const& oConsFuncName,
              vector<ANS_String> & oParameterNameVector,
              vector<double> & oParameterDataVector ) ;
        //R-bool
        //R-IF the MaterialID or the oConsFuncName or requred Exp does 
        //R-not exist, this function returns false
        //I-iMatID
        //I-ConstitutiveModel ID
        //I-oConsFuncName
        //I-Name of the Constitutive Function(eq mooney...)
        //O-oParameterNameVector
        //O-Vector of Parameter Names
        //O-oParameterDataVector
        //O-Vector of Parameter Values
        //- Returns the data in a Constitutive Function/Given Mat ID

        bool GetConstitutiveFunctionParameter
            ( INT iMatID,
              ANS_String const& oConsFuncName,
              ANS_String oParameterName,
              double& dParamValue ) ;
        //R-bool
        //R-IF the MaterialID or the oConsFuncName or requred Exp does 
        //R-not exist, this function returns false
        //I-iMatID
        //I-ConstitutiveModel ID
        //I-oConsFuncName
        //I-Name of the Constitutive Function(eq mooney...)
        //O-oParameterName
        //O-Parameter Name
        //O-dParamValue
        //O-Double Parameter Value
        //- Returns the data in a Constitutive Function/Given Mat ID(Double)
        
        bool GetConstitutiveFunctionParameter
            ( INT iMatID,
              ANS_String const& oConsFuncName,
              ANS_String oParameterName,
              INT& dParamValue ) ;
        //R-bool
        //R-IF the MaterialID or the oConsFuncName or requred Exp does 
        //R-not exist, this function returns false
        //I-iMatID
        //I-ConstitutiveModel ID
        //I-oConsFuncName
        //I-Name of the Constitutive Function(eq mooney...)
        //O-oParameterName
        //O-Parameter Name
        //O-dParamValue
        //O-Integer of Parameter
        //- Returns the data in a Constitutive Function/Given Mat ID(Integer)

        bool GetConstitutiveFunctionParameter
            ( INT iMatID,
              ANS_String const& oConsFuncName,
              ANS_String oParameterName,
              ANS_String& dParamValue ) ;
        //R-bool
        //R-IF the MaterialID or the oConsFuncName or requred Exp does 
        //R-not exist, this function returns false
        //I-iMatID
        //I-ConstitutiveModel ID
        //I-oConsFuncName
        //I-Name of the Constitutive Function(eq mooney...)
        //O-oParameterName
        //O-Parameter Name
        //O-dParamValue
        //O-Vector of Parameter
        //- Returns the data in a Constitutive Function/Given Mat ID



        bool SetAttributeValue( vector<MAT_CFAttribute*>& oAttributeList,
                                ANS_String const& oAttrName,
                                ANS_String const& oAttrValue ) ;
        //R bool
        //R-True of false
        //IO oAttributeList
        //IO-List of Attributes
        //I oAttrName
        //I-Name of the Attribute
        //I oAttrValue
        //I-Value of the Attribute
        //- Get the String Value of an attribute

        bool SetAttributeValue( vector<MAT_CFAttribute*>& oAttributeList,
                                ANS_String const& oAttrName,
                                double const& oAttrValue ) ;
        //R bool
        //R-True of false
        //IO oAttributeList
        //IO-List of Attributes
        //I oAttrName
        //I-Name of the Attribute
        //I oAttrValue
        //I-Value of the Attribute
        //- Get the Real/Double Value of an attribute

        bool SetAttributeValue( vector<MAT_CFAttribute*>& oAttributeList,
                                ANS_String const& oAttrName,
                                INT const& oAttrValue ) ;
        //R bool
        //R-True of false
        //IO oAttributeList
        //IO-List of Attributes
        //I oAttrName
        //I-Name of the Attribute
        //I oAttrValue
        //I-Value of the Attribute
        //- Get the Integer Value of an attribute

        bool GetAttributeValue( vector<MAT_CFAttribute*> const& oAttributeList,
                                ANS_String oAttrName,
                                ANS_String& oAttrValue ) ;
        //R bool
        //R-true / false
        //I oAttributeList
        //I-Vector of Attributes
        //I oAttrName
        //I-Name of the Attribute
        //O oAttrValue
        //O-Value of the Attribute
        //- Get the String Value of an attribute

        bool GetAttributeValue( vector<MAT_CFAttribute*> const& oAttributeList,
                                ANS_String oAttrName,
                                INT& oAttrValue ) ;
        //R bool
        //R-true / false
        //I oAttributeList
        //I-Vector of Attributes
        //I oAttrName
        //I-Name of the Attribute
        //O oAttrValue
        //O-Value of the Attribute
        //- Get the Integer Value of an attribute

        bool GetAttributeValue( vector<MAT_CFAttribute*> const& oAttributeList,
                                ANS_String oAttrName,
                                double& oAttrValue ) ;
        //R bool
        //R-true / false
        //I oAttributeList
        //I-Vector of Attributes
        //I oAttrName
        //I-Name of the Attribute
        //O oAttrValue
        //O-Value of the Attribute
        //- Get the real(as in real numbers) Value of an attribute

        bool GetUserAttributeType(ANS_String oName, MAT_AttributeType& oType) const ;
        //R bool
        //I oName
        //I-Name of attribute
        //- Returns if this is a valid user attribute

        void AddUserAttributeType(ANS_String oName, MAT_AttributeType oType) ;
        //R bool
        //I oName
        //I-Name of attribute
        //- Returns if this is a valid user attribute

        void DeleteAttribute( MAT_CFAttribute*& pAttr ) ;
        //- Deletes an attribute

        MAT_CFAttribute* RemoveAttribute( vector<MAT_CFAttribute*>& oAttributeList,
                                          ANS_String const& oAttrName ) ;
        //R Pointer to Attribute
        //IO oAttributeList
        //IO-List of Attributes
        //I oAttrName
        //I-Name of the Attribute
        //- Removes an attribute from a list

        bool SplitSimpleShearData( MAT_ExperimentalData const& oExpData,
                                   vector<MAT_ExperimentalData*>& oExpDataPtrVector ) ;
        //R Status of function
        //I oExpData
        //I-Input Simple Shear ExperimentalData
        //O oExpDataPtrVector
        //O-Vector of Experimental Data Points
        //- Splits an Experimental Data of type "sshe" into two "sshe-transverse" and "sshe-shear"

        bool ProcessExperimentalDataSetForSimpleShear( MAT_ExperimentalDataSet* pEDataSet ) ;
        //R Status
        //I pEDataSet
        //I-Experimental Data Set
        //- Process ExpDataSet to generate two exp data for shear stress and transverse stress

        bool CleanUpExperimentalDataSetForSimpleShear( MAT_ExperimentalDataSet* pEDataSet ) ;
        //R Status
        //I pEDataSet
        //I-Experimental Data Set
        //- Process ExpDataSet to generate two exp data for shear stress and transverse stress

        MAT_CombinationCFDefinition m_oCFDefinitionData ;

        ~MAT_Api();
        // Destructor


    private:

        map<INT,MAT_ConstitutiveModel*> m_oMaterialDatabase ;
        // Inmemory database for all materials

        static MAT_Api* m_pInstance ;
        // Singleton. Pointer for singleton implementation

        MAT_AttributeTypeInfo m_oUserAttributeInfo ;

   	    MAT_Api();
        // Default constructor

        void InitializeValidUserAttributes() ;
        //R
        //- Initialzes all valid user attributes for curvefitting

};



#endif // !defined(MAT_API_H)
