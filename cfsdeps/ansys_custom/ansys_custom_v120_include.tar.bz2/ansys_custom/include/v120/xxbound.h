

/*
 *    author/date: yu-hua ting/10-22-93
 *
 *    primary function:
 *
 *      Header for the Interface to SHAPES "boundary" routines
 *
 *    secondary function:
 *
 *        none
 *
 *    routines included:
 *
 *
 *    history
 *
 *        none
 *
 *    comments:
 *
 *        none
 *
 *    Notice - This file contains ANSYS Confidential information ***
 *
 */

/*
 * *** copyright(c) 2009 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */

/*
 *    get subgeoms for a geom 
 */
      extern xINT_LIST xGmFindSubGeoms_xox ansPROTO((
             xGEOM_ID gm_id,      /* I    geom number of a geom                      */ 
             INT *iretp));        /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                               */



/*
 *    get k-dimensional subgeoms for a geom 
 */
      extern xINT_LIST xGmFindKSkeleton_xox ansPROTO((
             xGEOM_ID gm_id,      /* I    geom number of a geom                      */ 
             xINT       dim,      /* I    dimension of the subgeoms                 */
             INT *iretp));        /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                               */


/*
 *    get k-dimensional seams for a geom 
 */
      extern xINT_LIST xGmFindKSeams_xox ansPROTO((
             xGEOM_ID gm_id,      /* I    geom number of a geom                      */ 
             xINT       dim,      /* I    dimension of the subgeoms                 */
             INT *iretp));        /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                               */
