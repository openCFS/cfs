
/*
 *    author/date: yu-hua ting/02-18-94
 *
 *    primary function:
 *
 *      Header for the "typedef" definitions in the Ansys/Shapes Interface
 *
 *    secondary function:
 *
 *        none
 *
 *    routines included:
 *
 *        none
 *
 *    history
 *
 *        none
 *
 *    comments:
 *
 *        none
 *
 *    notice- these routines contain sasi confidential information ***
 *
 */
/* 
 * *** copyright(c) 2009 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */



#if defined(ansANSI)
typedef void          *xaxADDR,*xaxERROR;
#else
typedef char          *xaxADDR,*xaxERROR;
#endif


#define NULL_ADDRESS  (xaxERROR) (0)
 
#define ERROR_EXIST   (xaxERROR) (0)



/****************************************************************************
 *  typedefs used in Ansys/Interface database                               *
 ****************************************************************************/


      typedef struct {
          INT v1;
          INT v2;
      } xaxKEY;

      typedef struct xdb_node *xaxTREE_PTR;

      typedef struct xdb_node {  /* tree node */
          xaxKEY num;               /* ANSYS or SHAPES entity number  */
          xaxTREE_PTR link;          /* link to the corresponding node */
          xaxTREE_PTR left;          /* left child                     */
          xaxTREE_PTR right;         /* right child                    */
      } xaxTREE_NODE;          


      typedef jmp_buf JMP_BUF;


/******************************************************************************
 *  typedefs used in geometry attribute handlers                              *
 *                                                                            *
 *  - geometry_type : SHAPES_POINT                                            *
 *                                                                            * 
 *      - operation_type : IDENTITY_COPY_OF_ANSYS_POINT                       * 
 *                                                                            * 
 *         source_type         == ANSYS_SOURCE                                * 
 *         num_of_attr_lists   == 0                                           *
 *         geometry_identifier == Ansys point number                          * 
 *                                                                            *
 *      - operation_type : IDENTITY_COPY_OF_SHAPES_POINT                      *
 *                                                                            *
 *         source_type         == SHAPES_SOURCE                               *
 *        (created from blending, interpolation, approximation or other       *
 *         operations inside Shapes                                     )     *
 *                                                                            *
 *         num_of_attr_lists   == 0                                           *
 *         geometry_identifier == Shapes geom_id                              *
 *                                                                            *
 *      - operation_type : IDENTITY_COPY_OF_POINT_FROM_FILE                   *
 *                                                                            *
 *         source_type         == FILE_SOURCE                                 *
 *         num_of_attr_lists   == 0                                           *
 *         geometry_identifier == foreign geom_id                             *
 *                                                                            *
 *      - operation_type : IDENTITY_LINK_OF_SHAPES_POINT                      *
 *                                                                            *
 *         source_type         == SHAPES_SOURCE                               *
 *         num_of_attr_lists   == 1                                           *
 *         geometry_identifier == shapes geom_id                              *
 *                                                                            *
 *      - operation_type : TRIMMING_POINT                                     *
 *                                                                            *
 *         source_type         == SHAPES_SOURCE                               *
 *         num_of_attr_lists   == 1                                           *
 *                                                                            *
 *      - operation_type : MERGING_POINT_WITH_POINT                           *
 *                                                                            *
 *         source_type         == SHAPES_SOURCE                               *
 *         num_of_attr_lists   == 2                                           *
 *                                                                            *
 *      - operation_type : INTERSECTION_POINT_OF_POINT_AND_POINT              * 
 *                                                                            * 
 *         source_type         == SHAPES_SOURCE                               * 
 *         num_of_attr_lists   == 2                                           *
 *                                                                            * 
 *      - operation_type : INTERSECTION_POINT_OF_POINT_AND_SUBLINE            *
 *                                                                            *
 *         source_type         == SHAPES_SOURCE                               *
 *         num_of_attr_lists   == 2                                           *
 *                                                                            *
 *      - operation_type : INTERSECTION_POINT_OF_POINT_AND_SUBAREA            * 
 *                                                                            * 
 *         source_type         == SHAPES_SOURCE                               * 
 *         num_of_attr_lists   == 2                                           *
 *                                                                            * 
 *      - operation_type : INTERSECTION_POINT_OF_POINT_AND_SUBVOLUME          * 
 *                                                                            * 
 *         source_type         == SHAPES_SOURCE                               * 
 *         num_of_attr_lists   == 2                                           *
 *                                                                            *
 *      - operation_type : INTERSECTION_POINT_OF_SUBLINE_AND_SUBLINE          *
 *                                                                            *
 *         source_type         == SHAPES_SOURCE                               *
 *         num_of_attr_lists   == 2                                           *
 *                                                                            *
 *      - operation_type : INTERSECTION_POINT_OF_SUBLINE_AND_SUBAREA          * 
 *                                                                            * 
 *         source_type         == SHAPES_SOURCE                               * 
 *         num_of_attr_lists   == 2                                           *
 *                                                                            * 
 *      - operation_type : INTERSECTION_POINT_OF_SUBLINE_AND_SUBVOLUME        * 
 *                                                                            * 
 *         source_type         == SHAPES_SOURCE                               * 
 *         num_of_attr_lists   == 2                                           *
 *                                                                            *
 *      - operation_type : INTERSECTION_POINT_OF_SUBAREA_AND_SUBAREA          * 
 *                                                                            * 
 *         source_type         == SHAPES_SOURCE                               * 
 *         num_of_attr_lists   == 2                                           *
 *                                                                            * 
 *      - operation_type : INTERSECTION_POINT_OF_SUBAREA_AND_SUBVOLUME        * 
 *                                                                            * 
 *         source_type         == SHAPES_SOURCE                               * 
 *         num_of_attr_lists   == 2                                           *
 *                                                                            *
 *      - operation_type : INTERSECTION_POINT_OF_SUBVOLUME_AND_SUBVOLUME      * 
 *                                                                            * 
 *         source_type         == SHAPES_SOURCE                               * 
 *         num_of_attr_lists   == 2                                           *
 *                                                                            *
 *  - geometry_type : SHAPES_SUBLINE                                          *
 *                                                                            * 
 *      - operation_type : IDENTITY_COPY_OF_ANSYS_SUBLINE                     * 
 *                                                                            * 
 *         source_type         == ANSYS_SOURCE                                * 
 *         num_of_attr_lists   == 0                                           *
 *         geometry_identifier == Ansys subline number                        * 
 *                                                                            *
 *      - operation_type : IDENTITY_COPY_OF_SHAPES_SUBLINE                    *
 *                                                                            *
 *         source_type         == SHAPES_SOURCE                               *
 *        (created from blending, interpolation, approximation or other       *
 *         operations inside Shapes                                     )     *
 *                                                                            *
 *         num_of_attr_lists   == 0                                           *
 *         geometry_identifier == Shapes geom_id                              *
 *                                                                            *
 *      - operation_type : IDENTITY_COPY_OF_SUBLINE_FROM_FILE                 *
 *                                                                            *
 *         source_type         == FILE_SOURCE                                 *
 *         num_of_attr_lists   == 0                                           *
 *         geometry_identifier == foreign geom_id                             *
 *                                                                            *
 *      - operation_type : IDENTITY_LINK_OF_SHAPES_SUBLINE                    *
 *                                                                            *
 *         source_type         == SHAPES_SOURCE                               *
 *         num_of_attr_lists   == 1                                           *
 *         geometry_identifier == shapes geom_id                              *
 *                                                                            *
 *      - operation_type : TRIMMING_SUBLINE                                   *
 *                                                                            *
 *         source_type         == SHAPES_SOURCE                               *
 *         num_of_attr_lists   == 1                                           *
 *                                                                            *
 *      - operation_type : MERGING_SUBLINE_WITH_SUBLINE                       * 
 *                                                                            * 
 *         source_type         == SHAPES_SOURCE                               * 
 *         num_of_attr_lists   == 2                                           *
 *                                                                            * 
 *      - operation_type : INTERSECTION_SUBLINE_OF_SUBLINE_AND_SUBLINE        *
 *                                                                            *
 *         source_type         == SHAPES_SOURCE                               *
 *         num_of_attr_lists   == 2                                           *
 *                                                                            *
 *      - operation_type : INTERSECTION_SUBLINE_OF_SUBLINE_AND_SUBAREA        * 
 *                                                                            * 
 *         source_type         == SHAPES_SOURCE                               * 
 *         num_of_attr_lists   == 2                                           *
 *                                                                            * 
 *      - operation_type : INTERSECTION_SUBLINE_OF_SUBLINE_AND_SUBVOLUME      * 
 *                                                                            * 
 *         source_type         == SHAPES_SOURCE                               * 
 *         num_of_attr_lists   == 2                                           *
 *                                                                            *
 *      - operation_type : INTERSECTION_SUBLINE_OF_SUBAREA_AND_SUBAREA        * 
 *                                                                            * 
 *         source_type         == SHAPES_SOURCE                               * 
 *         num_of_attr_lists   == 2                                           *
 *                                                                            * 
 *      - operation_type : INTERSECTION_SUBLINE_OF_SUBAREA_AND_SUBVOLUME      * 
 *                                                                            * 
 *         source_type         == SHAPES_SOURCE                               * 
 *         num_of_attr_lists   == 2                                           *
 *                                                                            *
 *      - operation_type : INTERSECTION_SUBLINE_OF_SUBVOLUME_AND_SUBVOLUME      * 
 *                                                                            * 
 *         source_type         == SHAPES_SOURCE                               * 
 *         num_of_attr_lists   == 2                                           *
 *                                                                            *
 *                                                                            *
 *  - geometry_type : SHAPES_SUBAREA                                          *
 *                                                                            * 
 *      - operation_type : IDENTITY_COPY_OF_ANSYS_SUBAREA                     * 
 *                                                                            * 
 *         source_type         == ANSYS_SOURCE                                * 
 *         num_of_attr_lists   == 0                                           *
 *         geometry_identifier == Ansys subarea number                        * 
 *                                                                            *
 *      - operation_type : IDENTITY_COPY_OF_SHAPES_SUBAREA                    *
 *                                                                            *
 *         source_type         == SHAPES_SOURCE                               *
 *        (created from blending, interpolation, approximation or other       *
 *         operations inside Shapes                                     )     *
 *                                                                            *
 *         num_of_attr_lists   == 0                                           *
 *         geometry_identifier == Shapes geom_id                              *
 *                                                                            *
 *      - operation_type : IDENTITY_COPY_OF_SUBAREA_FROM_FILE                 *
 *                                                                            *
 *         source_type         == FILE_SOURCE                                 *
 *         num_of_attr_lists   == 0                                           *
 *         geometry_identifier == foreign geom_id                             *
 *                                                                            *
 *      - operation_type : IDENTITY_LINK_OF_SHAPES_SUBAREA                    *
 *                                                                            *
 *         source_type         == SHAPES_SOURCE                               *
 *         num_of_attr_lists   == 1                                           *
 *         geometry_identifier == shapes geom_id                              *
 *                                                                            *
 *      - operation_type : TRIMMING_SUBAREA                                   *
 *                                                                            *
 *         source_type         == SHAPES_SOURCE                               *
 *         num_of_attr_lists   == 1                                           *
 *                                                                            *
 *      - operation_type : MERGING_SUBAREA_WITH_SUBAREA                       * 
 *                                                                            * 
 *         source_type         == SHAPES_SOURCE                               * 
 *         num_of_attr_lists   == 2                                           *
 *                                                                            * 
 *      - operation_type : INTERSECTION_SUBAREA_OF_SUBAREA_AND_SUBAREA        * 
 *                                                                            * 
 *         source_type         == SHAPES_SOURCE                               * 
 *         num_of_attr_lists   == 2                                           *
 *                                                                            * 
 *      - operation_type : INTERSECTION_SUBAREA_OF_SUBAREA_AND_SUBVOLUME      * 
 *                                                                            * 
 *         source_type         == SHAPES_SOURCE                               * 
 *         num_of_attr_lists   == 2                                           *
 *                                                                            *
 *      - operation_type : INTERSECTION_SUBAREA_OF_SUBVOLUME_AND_SUBVOLUME    * 
 *                                                                            * 
 *         source_type         == SHAPES_SOURCE                               * 
 *         num_of_attr_lists   == 2                                           *
 *                                                                            *
 *                                                                            *
 *  - geometry_type : SHAPES_SUBVOLUME                                        *
 *                                                                            * 
 *      - operation_type : IDENTITY_COPY_OF_ANSYS_SUBVOLUME                   * 
 *                                                                            * 
 *         source_type         == ANSYS_SOURCE                                * 
 *         num_of_attr_lists   == 0                                           *
 *         geometry_identifier == Ansys subvolume number                      * 
 *                                                                            *
 *      - operation_type : IDENTITY_COPY_OF_SHAPES_SUBVOLUME                  *
 *                                                                            *
 *         source_type         == SHAPES_SOURCE                               *
 *        (created from blending, interpolation, approximation or other       *
 *         operations inside Shapes                                     )     *
 *                                                                            *
 *         num_of_attr_lists   == 0                                           *
 *         geometry_identifier == Shapes geom_id                              *
 *                                                                            *
 *      - operation_type : IDENTITY_COPY_OF_SUBVOLUME_FROM_FILE               *
 *                                                                            *
 *         source_type         == FILE_SOURCE                                 *
 *         num_of_attr_lists   == 0                                           *
 *         geometry_identifier == foreign geom_id                             *
 *                                                                            *
 *      - operation_type : IDENTITY_LINK_OF_SHAPES_SUBVOLUME                  *
 *                                                                            *
 *         source_type         == SHAPES_SOURCE                               *
 *         num_of_attr_lists   == 1                                           *
 *         geometry_identifier == shapes geom_id                              *
 *                                                                            *
 *                                                                            *
 *      - operation_type : TRIMMING_SUBVOLUME                                 *
 *                                                                            *
 *         source_type         == SHAPES_SOURCE                               *
 *         num_of_attr_lists   == 1                                           *
 *                                                                            *
 *      - operation_type : MERGING_SUBVOLUME_WITH_SUBVOLUME                   * 
 *                                                                            * 
 *         source_type         == SHAPES_SOURCE                               * 
 *         num_of_attr_lists   == 2                                           *
 *                                                                            * 
 *      - operation_type : INTERSECTION_SUBVOLUME_OF_SUBVOLUME_AND_SUBVOLUME  *
 *                                                                            *
 *         source_type         == SHAPES_SOURCE                               *
 *         num_of_attr_lists   == 2                                           *
 *                                                                            *
 ******************************************************************************/



      typedef struct {        /* geometry attribute                           */

          INT shapes_geometry_identifier;   /* shapes gm_id                                     */
          INT geometry_type;                /* type of geometry attribute                       */
          INT operation_type;               /* operation type                                   */
          INT source_type;                  /* source of geometry attribute                     */
          INT geometry_identifier[MAX_NUM_OF_GEOMETRY_IDENTIFIERS]; 
                                            /* geometry identifier                              */
 
      } xaxGEOM_ATTR;
 
 
      typedef struct xgm_attr_node *xaxGEOM_ATTR_PTR;
      typedef struct xgm_attr_list_node *xaxGEOM_ATTR_LIST_PTR;
 

      typedef struct xgm_attr_node {        /* geometry attribute node                          */

          INT num_of_geom_attr_list_node_link;
                                            /* number of geom_attr_list_nodes linked below this
                                               node                                             */
          INT num_of_geom_attr_node_link;   /* number of geom_attr_nodes linked below this node
                                               and including itself                             */

          xaxGEOM_ATTR_PTR next;            /* pointer of the next attribute node               */
          xaxGEOM_ATTR_PTR previous;        /* pointer of the previous attribute node           */
          
          xaxGEOM_ATTR geom_attr;           /* geometry attribute                               */

          INT num_of_attr_lists;            /* number of attribute lists                        */

          xaxGEOM_ATTR_LIST_PTR attr_lists[MAX_NUM_OF_GEOM_ATTR_LISTS];
                                            /* attribute lists                                  */

      } xaxGEOM_ATTR_NODE;

 
      typedef struct xgm_attr_list_node {   /* geometry attribute list node                     */


          INT shapes_geometry_identifier;   /* Shapes gm_id                                     */
          INT geom_attr_tree_height;        /* estimated height of the geom_attr tree           */

          INT num_of_geom_attr_list_node_link;
                                            /* number of geom_attr_list_nodes linked below this 
                                               node including itself                            */
          INT num_of_geom_attr_node_link;   /* number of geom_attr_nodes linked below this node */   
 
          INT reference_count;              /* reference count                                  */
          INT length;                       /* length of the geometry attribute list            */

          xaxGEOM_ATTR_PTR head;            /* head pointer of the list                         */ 
          xaxGEOM_ATTR_PTR tail;            /* tail pointer of the list                         */     

      } xaxGEOM_ATTR_LIST_NODE;
 
 

