/* CADOE */
/**
 *	adrel.h -- constantes attachees aux objets adressage de l'element
 *
 *  |Version: $Id: sx_adrel.h,v 1.1.6.1 2009/04/13 14:10:00 jtm Exp $
 *   
 * HISTORY
 *   
 *   09/25/00 10:39 <       Brian Jantzen> Rel:ms8m1    SCCA:79107  Delta:81.2
 *   
 *   02/15/00 12:22 <       Brian Jantzen> Rel:ms8      SCCA:68558  Delta:8.3
 *   
 *   09/30/99 17:38 <         James Silva> Rel:ms8      SCCA:56512  Delta:8.2
 **/
#include "sx_CADOE_solver.h"
#ifndef __ADREL_X_DEJA_INCLUS__
#define __ADREL_X_DEJA_INCLUS__ 1

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

extern T_statut ADE_creer_adressage_element (int, int, int, T_adr_elem **);
extern T_statut ADE_cre_tab_adressage_element (void);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif	 /* __ADREL_X_DEJA_INCLUS__ */
