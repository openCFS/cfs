/* CADOE */
/*******************************************************************************
 *
 *   elempar.h -- 
 *              
 * 
 * |Module: SLVCOM
 *
 * |Description: 
 *
 * |Includes:	
 *        
 * |Auteur: Stephane Marguerin
 *
 * |Creation: Fevrier 2004
 *
 * |Version: $Id: sx_elempar.h,v 1.4.2.1 2009/04/13 14:10:00 jtm Exp $
 *
 * |Copyright:	copyright(c) 2009 SAS IP, Inc.  All rights reserved.
 *
 ******************************************************************************/
#ifndef __ELEMPAR_H_DEJA_INCLUS__
#define __ELEMPAR_H_DEJA_INCLUS__ 1

#include "cadoe.h"
#include "cadoe_string.h"
#include "sx_cons_solver.h"
#include "sx_CADOE_solver.h"
#include "CParameter.h"
#include "CParameterMgr.h"

#ifdef __cplusplus

  class C_ParamData
  {
  public:
    C_ParamData(PAR * par, const _TCHAR * filename, T_statut * ier);
    ~C_ParamData();  
    
    void initialize();
    T_statut buildConnectivity(T_modele *modele);
    T_statut buildSupportElem(T_modele *modele);

    T_propriete *     getPropriete(int ivparam) {return (T_propriete*) _par2prop[ivparam];}
    T_propriete *     getPropriete(const string& paramName);

    T_cond_lim_elem * getCondLimElem(int ivparam) {return (T_cond_lim_elem*) _par2prop[ivparam];}
    T_cond_lim_elem * getCondLimElem(const string& paramName);

    CParameter*       getCParameter(int ivparam) {return _cparameters[ivparam];}
    CParameter*       getCParameter(const string& paramName);

    BVEC *            getSupportElem(int ivparam) {return _supportElem[ivparam];}
    BVEC *            getSupportElem(const string& paramName);  

    CParameter::PhysicalType getPhysicalType(int ivparam);
    CParameter::PhysicalType getPhysicalType(const string& paramName);

    int getNbParTotal() { return _numParam;}

    int getNbParPhys() { return _numParPhys; }
    int getNbParLoad() { return _numParLoad; }
    int getNbParBool() { return _numParBool; }
    int getNbParNum()  { return _numParNum;  }
    int getNbParMat()  { return _numParMat;  }
    int getNbParRel()  { return _numParRel;  }
    int getNbParHi()   { return _numParHi;   }
    int getNbParShape(){ return _numParShape;}

    void allocate(PAR * par, T_statut * ier);

  private:
    int getIndexParam( const string &paramName ) const;
    
    WString _filename;
    bool _parFreqExists;
    CParameterMgr::ParamVector _pvec;
    
    void** _par2prop;
    BVEC** _supportElem;
    CParameter** _cparameters;

    int _numParam;

    int _numParPhys;
    int _numParLoad;
    int _numParBool;
    int _numParNum;
    int _numParMat;
    int _numParRel;
    int _numParHi;
    int _numParShape;

  };
#endif

#endif
