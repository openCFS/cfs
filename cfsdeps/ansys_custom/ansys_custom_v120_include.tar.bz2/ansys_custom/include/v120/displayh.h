/* 
 * *** copyright(c) 2009 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */
#if defined(PCWINNT_SYS)
    /*  fortran routines called from c  */
void CALLTYP disply_(char [], int, char [], int);
void CALLTYP dispmn_(char [], int, char [], int, int *, char [], int);
#endif

#if defined(PCWINNT_SYS)
    /*  c routines called from fortran  */
void CALLTYP write_mbox_(int*, char*, int);
void CALLTYP nt_dspmsgc_(int*, int [], int*);
#endif

    /*  fortran routines called from c  */
void CALLTYP pgetpsc_(int*, int* , double* , double* , int* , int* , int*);
void CALLTYP sysend_( void );
void CALLTYP xstart_( void );

#define MAXFILENAMELEN  100
