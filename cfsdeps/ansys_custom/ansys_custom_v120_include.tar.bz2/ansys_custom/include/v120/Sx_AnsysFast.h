/**
 * @file   Sx_AnsysFast.h
 * @author Frederic Thevenon		frederic.thevenon@ansys.com
 * @date   Wed May  5 14:56:21 2004
 * 
 * @brief  Class for Parameterization of Ansys with the Fast Method
 * 
 * 
 */

#ifndef __SX_ANSYSFAST_H__
#define __SX_ANSYSFAST_H__ 1

#include "Sx_ItfAnsys.h"
#include "C_AlgoPcg.h"
#include "C_ParamFast.h"

static int S_numero = 1;

class C_adr_bloc_res;

/*********************************************************************************
 *! \class	C_ConfigFastAnsys
 *  \brief	Class Ansys for Fast Configuration.
 *  \author	
 *  \version	1.0
 *  \date	2004-2005
 *  \bug
 *  \warning
 *
 *  version 1.0 :       Initial Revision ( Ansys 9.0)
 */

class C_ConfigFastAnsys
  : public C_ConfigFast<double>, public C_ConfigPcgT<double>
{
public:
  C_ConfigFastAnsys( C_VecP<double> *vparam) : C_ConfigFast<double>(vparam)
    { m_iNumero = S_numero; S_numero++; m_MatK = NULL; m_Rhs = new C_VecMsp<double>();}

  virtual ~C_ConfigFastAnsys();
  
  T_mso		*getMat(void)	    { return m_MatK;}
  C_VecMsp<double> &getRhs(int num) { return *m_Rhs;}
  BVEC		*getParAdrBcs(void) { return m_ParAdrBcs;};
  
  void		setMat(T_mso*mat){ m_MatK = mat;};
  void 		setParAdrBcs(BVEC *bParAdr) {m_ParAdrBcs = bParAdr;};
  inline void	setDofToZero( int idof) { _DofsToZero.insert(idof);}
  
  int		bSameProfil(C_ConfigFastAnsys * config);
  int		iGetNumero() 	{ return m_iNumero; };
    
  C_ConfigPcg::E_Status StoppingCriteria( double Threshold, int LimitNumIter);

  int		InitPcg( C_VecP<double> *Xk, C_VecP<double> *Rk, C_VecP<double> *Zk,
			 C_VecP<double> *Pk, C_VecP<double> *R0 = NULL,
			 C_VecP<double> *A0Pk = NULL);
  
 private:
  T_mso			*m_MatK;
  C_VecMsp<double>	*m_Rhs;
  int			m_iNumero;
  BVEC			*m_ParAdrBcs;
  set<int>		_DofsToZero;	// ===== For Booleans parameters
};

/*********************************************************************************
 *! \class	C_ItfAnsysFast
 *  \brief	Class Ansys for Fast Parameterization.
 *  \author	
 *  \date	2004-2005
 *  \bug
 *  \warning
 *
 *  \version 0.1 :       Initial Revision ( Ansys 9.0)
 *  \version 0.2 :       Revision For Ansys 10.0 First Preview
 *  
 *  This defines all functions that the Fast algorithm need to Run.
 */

class C_ItfAnsysFast
  : public C_ItfAnsys<double>, public C_ItfParamFast<double>, public C_ItfPcg<double>
{
public :
  
  virtual int	GetDebugScope(void) { return E_SCOPE_ITFPARAMFAST;}
  
  virtual const char *Version() const		{ return "1.0";}
  
  C_ItfAnsysFast( const string &nom, PAR *par = NULL);
  virtual ~C_ItfAnsysFast();
  
  virtual int	Write( FILE *fb);
  virtual int	Read( FILE *fb);
  
  virtual int	InitSolver( int &NbRhs, C_VecP<double> &InitDep, C_VecP<double> 
			    &InitLoad, C_VecP<double> &InitResults, 
			    C_VecP<int> *&Ind2Nod, int &nbDofByNode, C_VecPi<int> &NeededLoadedDofs, 
			    BVEC *&dofMaxResSecInit);
  
  virtual int   buildRegionsResInit(C_adr_bloc_res *, VEC *, BVEC *&);
  
  virtual int	InitParam( const string &Name, int &NbPts, C_VecPi<int>
			   &ParamAdr, C_VecP<double> &InitResults, BVEC *&ParResAdr);
  
  virtual IVEC *GetParamEFSupp( string &Name);
  
  virtual C_ConfigFast<double> *CreateConfig( C_VecP<double> *vparam);
  
  virtual int	MltMatVect( vector<C_ConfigPcg *> &LisConfig, C_VSTRUCT<double> &Vin, C_VSTRUCT<double> &Vout);
  virtual int	MltMatVect( C_ConfigPcg *Config, C_VecP<double> &Vin, C_VecP<double> &Vout);

  virtual int	MltMatVect( C_ConfigFast<double> *Config, int nbv, C_VSTRUCT<double> &Vin, C_VSTRUCT<double> &Vout, int IdMat=0);
  virtual int	MltMatVect( C_ConfigFast<double> *Config, C_VecP<double> &Vin, C_VecP<double> &Vout)
    { return this->MltMatVect ( dynamic_cast<C_ConfigPcg *>(Config), Vin, Vout);}
  
  virtual int	Resol( vector<C_ConfigPcg *> &LisConfig, C_VSTRUCT<double> &B, C_VSTRUCT<double> &X);

  virtual int	SolveUpd( C_CfgVar<double> &Vparam, C_VecP<double> *Xi, C_VecP<double> *RES);

  virtual int SolToRes( C_ConfigFast<double> *Config, C_VecP<double> &Sol, C_VecP<double> &Res);
  virtual int SolToResPost( C_VecP<double> &Unod, C_CfgVar<double> &Vparam, C_VecP<double> &ResPartiel);
  
  virtual int SetDofsToAssembly( BVEC *bDdl);
  
  virtual int SetDofsAdrResToAssembly(C_VecP<int> &resToEval, BVEC **bDofsToAssembly, bool putListElemToZero = true);
  
  virtual int VerifConfig( C_CfgVar<double> &Vparam, BVEC *ddls, C_VSTRUCT<double> &Q,
			   C_MatMGe<double> &KQ, C_VecP<double> &Fu);

  virtual int IndToNod( C_VecP<double> &VInd, C_VecP<double> &VNod, bool ApplyAllBC = false)
  { return C_ItfAnsys<double>::IndToNod( VInd, VNod, ApplyAllBC);}
  
  /** 
   * Method for Partial Assembly of operators K and F
   * 
   * @param list_elem	List of elements to assembly
   * @param vparam	Current variation of the parameters
   * @param Kmat	Partial K Matrix
   * 
   * @return		SUCCES/ECHEC
   *
   * @remark		At the end of this call , the Partial Load vector F 
   *			is stored in the _VtmpBcs member of this class
   */

  T_statut ReadMatKAndRhs( IVEC *list_elem, VEC *vparam, T_mso *Kmat, 
			   T_mso *Mmat = NULL);
  
  virtual int GetNumGrpStress();
  
  set<int>	*NodesToSuppress( VEC *vparam, BVEC *ActivesElements);

  C_VSTRUCT<double>	*getPcgSolBase( void) { return _PcgSolBase;}
  void			setPcgSolBase( C_VSTRUCT<double> *Q) { _PcgSolBase = Q;}
  
protected :

  int		_NbPtsByPar;	/**< Default Value for the number of converged
				     solutions for each parameter		*/
  
  map< string, int> _KOrder;	/**< K Order for each parameter			*/
  map< string, int> _FOrder;	/**< F Order for each parameter			*/
  map< string, BVEC*> _ParAdr;	/**< Ddls concerned for each parameter	       	*/
  map< string, IVEC*> _ParEFSupp;/**< Element finite support		       	*/
  map< string, BVEC*> _ParRes;	/**< Intersection between Parameter support and resultats */
  
  C_VSTRUCT<double>	*_PcgSolBase;
};

class C_ItfAnsysFastNm
  : public C_ItfAnsysFast
{
public :

  virtual int	GetDebugScope(void) { return E_SCOPE_ITFPARAMFAST;}
  
  virtual const char *Version() const		{ return "1.0";}
  
  C_ItfAnsysFastNm( const string &nom, PAR *par = NULL) : C_ItfAnsysFast( nom, par){};
  virtual ~C_ItfAnsysFastNm(){};
  
  virtual int	InitSolver( int &NbRhs, C_VecP<double> &InitDep, C_VecP<double> 
			    &InitLoad, C_VecP<double> &InitResults, 
			    C_VecP<int> *&Ind2Nod, int &nbDofByNode, C_VecPi<int> &NeededLoadedDofs,
			    BVEC *&dofMaxResSecInit);

  virtual int	MltMatVect( C_ConfigFast<double> *Config, int nbv, 
			    C_VSTRUCT<double> &Vin, C_VSTRUCT<double> &Kout,
			    int IdMat);
  
  virtual int VerifConfig( map< string, double> &Vparam, BVEC *ddls,
			   C_VSTRUCT<double> &Q, C_MatMGe<double> &KQ, C_MatMGe<double> &MQ);
  
protected :
  C_VecPi<double>	_Eigenvalues;
  C_VSTRUCT<double>	_Eigenvectors;
  T_mso			*_MatM0;	//*< Initial M matrix
};
  
extern void SetItfAnsysFast( C_ItfAnsysFast *Itf);

#endif /* __SX_ANSYSSOLVERFAST_H__ */

