/* CADOE */
/**
 *   strutil.h
 *   
 * HISTORY
 *   
 *   10/13/99 15:37 <         James Silva> Rel:ms8      SCCA:57374  Delta:8.4
 *   
 *   10/05/99 17:19 <         James Silva> Rel:ms8      SCCA:56915  Delta:8.3
 *   
 *   09/30/99 17:38 <         James Silva> Rel:ms8      SCCA:56512  Delta:8.2
 **/

#ifndef __strutil_h__ 
#define __strutil_h__ 1 


#include "cadoe.h"


#ifdef __cplusplus
extern "C" {
#endif

extern void SupSpace ( char* );
extern char* SupPrefix ( char*, char* );

extern char *STR_build_filename(char*,...);
extern void STR_conv_path( char* );
extern void STR_del_end_slash( char* );

#ifdef __cplusplus
}
#endif


#endif 
