/*****************************************************************************
 *                   Copyright (C) 1999 CMSoft                               *
 *                                                                           *
 *  These lines of code and declarations contain unpublished proprietary     *
 *  information of CMSoft. They may not be copied or duplicated in whole     *
 *  or part without prior authorization from CMSoft.                         *
 *                                                                           *
 *****************************************************************************/
#ifndef _FS_DIST_INFO_H_
#define _FS_DIST_INFO_H_

#include "General.h"
#include "CoreDomain.h"

class FSDistInfo {
public:
   int totLen;
   int numSub;
   int *subs;
   int *subLen;
   FSDistInfo(int i, Accesser<FSSubPreprocessor, int>, int *);
   ~FSDistInfo();
   int totalLen() { return totLen; }
};


#endif
