/* ---------------------------------------------------------------------- */
/* *** copyright(c) 2009 SAS IP, Inc.  All rights reserved.                                         */
/* *** ansys, inc.                                                        */
/* ---------------------------------------------------------------------- */


/*
* Author/date: Stefan Reh 09/09/99
* Primary function:
*    Header file for Response Surface Methods
*/

#ifndef _RS_C_TYPES_
#define _RS_C_TYPES_

#include "rs_constants.h"


/* structure used for storing the goodness of fits based on regression coeffcients */
typedef struct RS_RegCoefGOF
{
    double  dCoefStdev;             /* standard deviation of coefficient */
    double  dCoefProbZero;          /* probability value that coefficient is zero */
    double  dVIF;                   /* variance inflation factor */
}RS_RegCoefGOF;


/* structure used for storing the sample-based goodness of fit measures */
typedef struct RS_SampleGOF
{
    double  dHatMtxDiag;            /* hat matrix value diagonal (based on "as is" regression model) */
    double  dStudRes;               /* studentized residuals */
    double  dStudDelRes;            /* studentized deleted residuals */
    double  dCooksDist;             /* Cook's distance */
    int     iStudResError;          /* error key to indicate if the studentize residuals exists */
}RS_SampleGOF;


/* structure used for storing the scalar goodness of fit measures */
typedef struct RS_ScalarGOF
{
    double    dSSE;                              /*  error sum of squares  */
    double    dSSEAdj;                           /*  error sum of squares adjusted by the degrees of freedom */
    double    dErrorVariance;                    /*  error sum of squares in the transformed space adjusted
                                                     by the number of degrees of freedom */
    double    dR2;                               /*  Coefficient of Determination */ 
    double    dR2Adj;                            /*  coefficient of determination adjusted by the degrees of 
                                                     freedom */
    double    dConstVarStat;                     /*  t-statistic of the constant variance test */
    double    dConstVarProb;                     /*  probability of the constant variance test */
    int       iConstVarMaxIdx;                   /*  index pointing to the variable leading 
                                                     to the  maximum t-statistic of the
                                                     constant variance test */
    double    dMaxStudRes;                        /* Maximum studentized residual */
    double    dMaxStudDelRes;                     /* Maximum studentized deleted residual */
    double    dMaxStudDelResProb;                 /* Probability value of the maximum studentized deleted residual */
    double    dMaxResAbs;                         /* maximum absoluite residual */ 
    double    dMaxResRel;                         /* maximum relative residual */ 
    double    dMaxCooksDist;                      /* maximum value of the Cook's distance */
    double    dMaxCooksProb;                      /* probability value of maximum Cook's distance */

    double    dAndDarlStat;                       /* Anderson Darling Statistic */
    double    dAndDarlStatNormCorr;               /* Anderson Darling Statistic corrected for Normal distribution*/
    double    dAndDarlProb;                       /* probability for Anderson-Darlin test statistic */

    double    dMaxCoefProb;                       /* maximum probability value that coefficient is zero */

    /* full model parameters */
    /* --------------------- */
    double    dMaxHatMtxFullModel;                /* Maximum leverage of the full model */
    int       iMaxHatMtxLocation;                 /* Location of the maximum leverage point */
    double    dMaxVIFFullModel;                   /* Maximum VIF of full model */
    int       iMaxVIFLocation;                    /* Location of the maximum VIF */
}RS_ScalarGOF;


/* Data structure for response surfaces */
typedef struct RS_ResponseSurface
{
    /* General information about solution index */
    char    Label[RS_SOLULABLENGTH];
    int     SoluIdx;

    /* The specifications of the response surfaces are all arrays   */
    /* for the individual response parameters, i.e. every response  */
    /* parameter could have a different response surface fitted for */
    /* it.                                                          */

    /* Information about the output parameters that have been fitted */
    int     NumRSOut;
    int     *Idx2Rp;

    /* Regression Model Input */
    int     *RegMod;
    int     *YTrans;
    double  *YTrVal;
    int     *XFilt;
    double  *XFiltConf;
    int     *XTrans;

    /* Regression Model Result */
    double  **dScaleSlopes;
    double  **dScaleIntercepts;
    double  *YPower;
    int     *NumTerms;
    int     **Idx2Terms;
    double  **Coefs;
    double  **XPowers;

    /* Covariance matrix of the regression coefficients */
    double  ***dCoefCovarMtx;
    int     *iCoefCovarNumDims;

    /* array of model parameter based goodness of fits */
    RS_RegCoefGOF   **RegCoefGOFs;

    /* array of sample based goodness of fits */
    RS_SampleGOF    **SampleGOFs;

    /* array of scalar goodness of fits */
    RS_ScalarGOF    **ScalarGOFs;

}RS_ResponseSurface;

#endif /* _RS_C_TYPES_ */

