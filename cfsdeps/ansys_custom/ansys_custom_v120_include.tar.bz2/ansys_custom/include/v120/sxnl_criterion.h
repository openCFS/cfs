//////////////////////////////////////////////////////////////////////////// 
//                                                                        // 
//          Copyright (C) 2009 ANSYS Inc.  All Rights Reserved            // 
//                                                                        // 
// This file contains proprietary software licensed from ANSYS Inc.       // 
// This header must remain in any source code despite modifications or    // 
// enhancements by any party.                                             // 
//                                                                        // 
//////////////////////////////////////////////////////////////////////////// 
// 
// $Workfile: sxnl_criterion.h $ 
// $Revision: 1.4.2.1 $Id:  
// $Date: 2009/04/10 15:33:26 $ 
// $Author: jtm $ Emmanuel Delor
// 
// Decription:  
// 
//////////////////////////////////////////////////////////////////////////// 
 
  
#ifndef __SXNL_CRITERION_H__ 
#define __SXNL_CRITERION_H__ 1 
 
#include <stdio.h>  
#include <stdlib.h>   
#include "cadoe.h" 
#include "CadoeAnsys.h"
#include "bf.h"

class C_TimeCriterion
{
public:
  C_TimeCriterion() {_time = -1; _crit = -1;}
  C_TimeCriterion(double time, double crit) {_time = time; _crit = crit;}
  ~C_TimeCriterion() {}
  
  double getTime() {return _time;}
  double getCrit() {return _crit;}
  
  int Read(FILE *fp) 
  {
    char fctn [] = "C_TimeCriterion::Read";		CADOE_TRACE(fctn);
    T_statut ier (0);
    ier = BF_fread_double(fp, &_time, 1);		CHKIERS;
    ier = BF_fread_double(fp, &_crit, 1);		CHKIERS;
    return SUCCES;
  }
  int Write(FILE *fp) 
  { 
    char fctn [] = "C_TimeCriterion::Write";		CADOE_TRACE(fctn);
    T_statut ier (0);
    ier = BF_fwrite_double(fp, &_time, 1);		CHKIERS;
    ier = BF_fwrite_double(fp, &_crit, 1);		CHKIERS;
    return SUCCES;
  }
  
protected:
  double _time;
  double _crit;
};


#endif
