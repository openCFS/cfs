/*! \file CFD_struct.h
  \brief Declaration des structures CFD

  \author Gilles Venet 
  \date  Octobre 2003

 * |Copyright:        copyright(c) 2009 SAS IP, Inc.  All rights reserved.
 */
#ifndef __lightstructbaseh__ 
#define __lightstructbaseh__ 1 

#ifdef __cplusplus
#include "cadoe_iostream.h"
#endif
#include <math.h>

/* Pour rechercher les erreurs IEEE */
#ifdef DEBUGIEEE
#include <sunmath.h>
#endif

#include "cadoe.h"
#include "cbf.h"
#include "liste_chainee.h"
#include "m_matrix.h"

#include "constantes_adomesh.h"
#include "MOD_Table.h"

/*#ifdef __cplusplus
extern "C" {
#endif*/

/* Variables globales de configuration */
extern int affiche_interne;
extern double precision;
extern double taille;
extern FILE      *G_mda;
extern FILE      *G_daa;
extern int       num_dbg;
//extern int       num_uv_dbg;

struct __Lnoeud;
struct __Lelement;

typedef struct __Lnoeud		T_Lnoeud;
typedef struct __Lelement	T_Lelement;	
//typedef	map<int, double>	map_Int_Double;  �a ne compile pas sous UNIX


struct __Lnoeud
{
  T_booleen bounding;
  double pmin[3];
  double pmax[3];
  IVEC		*numero;
  IVEC		*indice;
  VEC		*xyz;
  map<int,int*> *tableno;
};


struct __Lelement
{
	IVEC		*numero;
	IVEC		*indice;
	IVEC		*data;					/* type1, nb_noeud1, type2, ...							*/
	int		**noeud;					/* numero des noeuds									*/
	map<int,int*> *  tableno;
	map<int, double> * Epaisseurs;		/* les �paisseurs de �l�ments coques s'il y en a		*/
	map<int, int> * Materiaux;			/* les materiaux s'il y en a							*/
};


/*#ifdef __cplusplus
}
#endif*/

#endif

