/* CADOE */
/*
 *   
 * HISTORY
 *   
 *   11/22/00 12:18 <        Marc Gadbois> Rel:ms9      SCCA:83109  Delta:9.3
 *   
 *   09/25/00 10:39 <       Brian Jantzen> Rel:ms8m1    SCCA:79107  Delta:81.2
 *   
 *   02/15/00 13:10 <       Brian Jantzen> Rel:ms8      SCCA:68558  Delta:8.6
 *   
 *   11/18/99 02:26 <         James Silva> Rel:ms8      SCCA:61479  Delta:8.5
 *   
 *   10/11/99 15:00 <         James Silva> Rel:ms8      SCCA:57374  Delta:8.4
 *   
 *   10/05/99 17:19 <         James Silva> Rel:ms8      SCCA:56915  Delta:8.3
 *   
 *   09/30/99 17:38 <         James Silva> Rel:ms8      SCCA:56512  Delta:8.2
*/
#include "sx_CADOE_solver.h"
#ifndef __INTERF_X__
#define __INTERF_X__ 1

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

extern PAR *ITF_lire_rng( const _TCHAR *nom_etude, int *err );
extern PAR *ITF_lire_rng_utilisateur( const _TCHAR *nom_etude, int *err );
extern PAR *ITF_creer_rng_auto( T_modele *modele, const _TCHAR *nom_etude, int *err );
extern PAR *ITF_creer_rng_auto_uti( T_modele *modele, const _TCHAR *nom_etude, int *err );
extern PAR *ITF_post_lire_rng( const _TCHAR *nom_etude, int *err );
extern PAR *ITF_post_lire_rng_utilisateur( const _TCHAR *nom_etude, int *err );
extern T_element** ITF_creer_liste_elements( int, int* );
extern T_noeud** ITF_creer_liste_noeuds( int, int* );
extern T_statut ITF_lire_etude( const _TCHAR *, T_modele *, PAR * );
extern T_statut ITF_lire_base_modale( char *, T_modele * );
extern T_statut ITF_ecrire_base_modale( char *, T_modele *);
extern T_statut ITF_read_adomesh_model( const _TCHAR *,  T_modele **, E_solveur );
extern T_statut RNG_write(T_liste *, char* );
extern T_statut RNG_result( char* );
extern T_statut ITF_write_model( const _TCHAR *, T_modele * );
extern T_statut ITF_read_all_opt( char *nom_fic, int code, T_liste **liste, T_modele * );
extern T_statut ITF_lire_optimisation( char *nom_fic, char *nom_opt, T_modele *modele, PAR *par, T_optim **optim );
extern T_statut ITF_desactiver_optimisation( char *nom_fic, char *nom_opt);
extern T_statut get_check_point( VEC **vec_param );
extern T_statut get_check_point_next( VEC **vec_param, int );
extern int      get_nb_parametres( int ie );
extern T_statut ITF_load_rc( E_solveur solveur, int code_langue );
extern void     ITF_unload_rc( void );
extern T_statut ITF_create_bodies( const _TCHAR *filename, T_modele *modele );
extern T_statut ITF_write_bodies( T_modele *modele );
extern void NOE_copier(T_noeud *src, T_noeud *cib, T_statut *ier);
extern T_element * ELE_copier(T_element *src, T_statut *ier);
#ifdef __cplusplus
}
#endif /* __cplusplus */

extern T_statut ITF_read_model( const _TCHAR *,  T_modele ** );

#endif
