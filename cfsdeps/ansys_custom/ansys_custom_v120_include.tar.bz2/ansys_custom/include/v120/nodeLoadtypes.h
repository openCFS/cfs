
#include "ansysdef.h"

/****************************************************************
 data-level structure for ANSYS nodal loads
 ****************************************************************/
struct nodeLoad_str {                 /* Name of the structure                                      */
  dispData  *disp;                    /* Pointer to the first specified displacement on this node   */
  veloData  *velo;                    /* Pointer to the first specified velocity on this node       */
  acclData  *accl;                    /* Pointer to the first specified acceleration on this node   */
  forceData *force;                   /* Pointer to the first specified force on this node          */
                                      /* If either the disp or force pointer is NULL that means     */
                                      /* this node has no displacements or forces (or both)         */
  char bodyTypes[MAXBODYLOADTYPE+1];  /* Array to flag nodal body load types for this node          */
                                      /* i.e., if bodyTypes[BODYLOAD_TEMP] = FALSE then no temps    */
                                      /*       if bodyTypes[BODYLOAD_TEMP] = TRUE  then temps exist */
                                      /* NOTE: we allocate 1 extra since we start at 1 and not 0    */
  nodeBodyLoadData *bodyLoad;         /* Pointer to the first body load on this node. If this       */
                                      /* pointer is NULL then this node has no body loads           */
};

#define nodeLoadDispPtr(nload)             (nload->disp)
#define nodeLoadVeloPtr(nload)             (nload->velo)
#define nodeLoadAcclPtr(nload)             (nload->accl)
#define nodeLoadForcePtr(nload)            (nload->force)

#define nodeLoadBodyTypesPtr(nload)        (nload->bodyTypes)
#define nodeLoadBodyTypesVec(nload,i)      (nload->bodyTypes[i])

#define nodeLoadBodyLoadPtr(nload)         (nload->bodyLoad)

