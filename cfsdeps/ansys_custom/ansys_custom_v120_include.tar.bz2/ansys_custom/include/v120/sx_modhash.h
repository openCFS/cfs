/* CADOE */
/**
 *	modhash.h -- Functions of the Nodes and elements has tables
 *   
 **/

#ifndef __MODHASH_X_DEJA_INCLUS__
#define __MODHASH_X_DEJA_INCLUS__ 1


#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

T_Htable * MOD_build_hash_nodes( int, T_noeud **, T_statut * );
T_Htable * MOD_build_hash_elements( int, T_element **, int * );
T_noeud * MOD_get_node( T_modele *, int );
T_element *MOD_get_element( T_modele *, int );
T_groupe *MOD_get_groupe( T_modele *, int );

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif   /* __MODHASH_X_DEJA_INCLUS__*/

