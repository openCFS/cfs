/* ---------------------------------------------------------------------- */
/* *** copyright(c) 2009 SAS IP, Inc.  All rights reserved.                                         */
/* *** ansys, inc.                                                        */
/* ---------------------------------------------------------------------- */


/*
 *    author/date: Stefan Reh 7-16-98
 *
 *    primary function:
 *
 *        header for "C and Fortran interface"
 *
 *    Notice - This file contains ANSYS Confidential information ***
 *
 */

#ifndef _PDS_CTOF_TYPES_
#define _PDS_CTOF_TYPES_


#if defined(RS6000_SYS) || defined(HP32_SYS)

/* C Functions called from FORTRAN */

#define put_random_input_parameter_     put_random_input_parameter
#define put_random_output_parameter_    put_random_output_parameter
#define delete_random_parameter_        delete_random_parameter
#define process_rv_graph_               process_rv_graph
#define rv_inquiry_                     rv_inquiry
#define process_rv_doe_levels_          process_rv_doe_levels
#define nodal_path_correlations_        nodal_path_correlations
#define element_path_correlations_      element_path_correlations
#define put_correlation_coefficient_    put_correlation_coefficient
#define delete_correlation_coefficient_ delete_correlation_coefficient
#define get_sample_                     get_sample   
#define put_response_                   put_response
#define par_update_                     par_update
#define process_sample_history_         process_sample_history
#define process_post_histogram_         process_post_histogram
#define process_post_cdf_               process_post_cdf
#define process_post_prob_              process_post_prob
#define process_post_pinv_              process_post_pinv
#define process_correlation_table_      process_correlation_table
#define process_sensitivities_          process_sensitivities
#define process_scatter_plot_           process_scatter_plot
#define generate_sample_file_           generate_sample_file

#define process_regression_             process_regression
#define print_regression_               print_regression
#define plot_regression_                plot_regression
#define process_samples_on_rs_          process_samples_on_rs

#define pds_mdlsave_                    pds_mdlsave
#define pds_mdlfree_                    pds_mdlfree
#define pds_mdlresume_                  pds_mdlresume
#define pds_status_                     pds_status
#define pds_clear_                      pds_clear
#define pds_close_                      pds_close
#define put_pds_method_                 put_pds_method
#define put_dmcs_options_               put_dmcs_options
#define put_lhs_options_                put_lhs_options
#define put_bbm_options_                put_bbm_options
#define put_ccd_options_                put_ccd_options
#define put_pduser_options_             put_pduser_options
#define put_run_options_                put_run_options
#define pds_undoc_debug_                pds_undoc_debug
#define pdtest_                         pdtest
#define put_report_option_              put_report_option
#define get_report_option_              get_report_option
#define create_report_assoc_files_      create_report_assoc_files

/* The following routines are used for ANSYS *GET command */
#define pds_get_pds_open_               pds_get_pds_open
#define pds_get_anal_name_              pds_get_anal_name
#define pds_get_saveresu_name_          pds_get_saveresu_name
#define pds_get_method_name_            pds_get_method_name
#define pds_get_num_rv_                 pds_get_num_rv
#define pds_get_rv_name_                pds_get_rv_name
#define pds_get_rv_value_               pds_get_rv_value
#define pds_get_rv_par_                 pds_get_rv_par
#define pds_get_rv_dis_name_            pds_get_rv_dis_name
#define pds_get_sys_num_rv_             pds_get_sys_num_rv
#define pds_get_sys_rv_name_            pds_get_sys_rv_name
#define pds_get_sys_rv_value_           pds_get_sys_rv_value
#define pds_get_corr_                   pds_get_corr
#define pds_get_num_rp_                 pds_get_num_rp
#define pds_get_rp_name_                pds_get_rp_name
#define pds_get_rp_value_               pds_get_rp_value
#define pds_get_ccd_defa_               pds_get_ccd_defa
#define pds_get_bbm_defa_               pds_get_bbm_defa
#define pds_get_ccd_lopt_               pds_get_ccd_lopt
#define pds_get_bbm_lopt_               pds_get_bbm_lopt
#define pds_get_ccd_vtyp_               pds_get_ccd_vtyp
#define pds_get_bbm_vtyp_               pds_get_bbm_vtyp
#define pds_get_ccd_ldef_               pds_get_ccd_ldef
#define pds_get_bbm_ldef_               pds_get_bbm_ldef
#define pds_get_ccd_lval_               pds_get_ccd_lval
#define pds_get_bbm_lval_               pds_get_bbm_lval
#define pds_get_num_corcoef_            pds_get_num_corcoef
#define pds_get_output_index_           pds_get_output_index
#define pds_get_mean_                   pds_get_mean
#define pds_get_stdv_                   pds_get_stdv
#define pds_get_skew_                   pds_get_skew        
#define pds_get_kurt_                   pds_get_kurt
#define pds_get_max_                    pds_get_max
#define pds_get_min_                    pds_get_min 
#define pds_get_linear_cc_              pds_get_linear_cc
#define pds_get_rank_cc_                pds_get_rank_cc
#define pds_get_num_resultsets_         pds_get_num_resultsets
#define pds_get_num_mcs_resultsets_     pds_get_num_mcs_resultsets
#define pds_get_num_rsm_resultsets_     pds_get_num_rsm_resultsets
#define pds_get_num_solusets_           pds_get_num_solusets
#define pds_get_num_mcs_solusets_       pds_get_num_mcs_solusets
#define pds_get_num_rsm_solusets_       pds_get_num_rsm_solusets
#define pds_get_user_nfail_             pds_get_user_nfail
#define pds_get_user_nmcs_              pds_get_user_nmcs
#define pds_get_user_nrsm_              pds_get_user_nrsm
#define pds_get_num_samples_in_file_    pds_get_num_samples_in_file
#define pds_get_rsm_plevels_            pds_get_rsm_plevels
#define pds_get_mcs_autostop_           pds_get_mcs_autostop
#define pds_get_iseed_                  pds_get_iseed
#define pds_get_rsm_options_            pds_get_rsm_options
#define pds_get_run_parallel_option_    pds_get_run_parallel_option
#define pds_get_resultset_label_        pds_get_resultset_label
#define pds_get_soluset_label_          pds_get_soluset_label
#define pds_get_nsim_                   pds_get_nsim
#define pds_get_nrep_                   pds_get_nrep
#define pds_get_num_rssets_             pds_get_num_rssets
#define pds_get_rsst_label_             pds_get_rsst_label
#define pds_get_rsst_xsol_              pds_get_rsst_xsol
#define pds_get_rsst_nfrp_              pds_get_rsst_nfrp
#define pds_get_rsur_xfrp_              pds_get_rsur_xfrp
#define pds_get_rsur_rmod_              pds_get_rsur_rmod
#define pds_get_rsur_ytty_              pds_get_rsur_ytty
#define pds_get_rsur_ytvl_              pds_get_rsur_ytvl
#define pds_get_rsur_filt_              pds_get_rsur_filt
#define pds_get_rsur_conf_              pds_get_rsur_conf
#define pds_get_rseq_ybox_              pds_get_rseq_ybox
#define pds_get_rseq_ntrm_              pds_get_rseq_ntrm
#define pds_get_rseq_ttyp_              pds_get_rseq_ttyp
#define pds_get_rseq_rv1_               pds_get_rseq_rv1
#define pds_get_rseq_rv2_               pds_get_rseq_rv2
#define pds_get_rseq_coef_              pds_get_rseq_coef
#define pds_get_rseq_slop_              pds_get_rseq_slop
#define pds_get_rseq_icpt_              pds_get_rseq_icpt
#define pds_get_rsac_sse_               pds_get_rsac_sse
#define pds_get_rsac_ssadj_             pds_get_rsac_ssadj
#define pds_get_rsac_r2_                pds_get_rsac_r2
#define pds_get_rsac_r2adj_             pds_get_rsac_r2adj
#define pds_get_rsac_rsabs_             pds_get_rsac_rsabs
#define pds_get_rsac_rsrel_             pds_get_rsac_rsrel
#define pds_get_rsac_cvstat_            pds_get_rsac_cvstat
#define pds_get_rsac_cvprob_            pds_get_rsac_cvprob
#define pds_get_rsac_cvmxidx_           pds_get_rsac_cvmxidx
/* Fortran routines called from C */
/*
#define pdfio_                  pdfio
*/
#define set_loop_abort_                 set_loop_abort
#define get_loop_abort_                 get_loop_abort

#endif

#if defined(WATCOMC_SYS) \
    || defined(PCWINNT_SYS)

/* C functions called from FORTRAN */

#define put_random_input_parameter_     PUT_RANDOM_INPUT_PARAMETER
#define put_random_output_parameter_    PUT_RANDOM_OUTPUT_PARAMETER 
#define delete_random_parameter_        DELETE_RANDOM_PARAMETER
#define process_rv_graph_               PROCESS_RV_GRAPH
#define rv_inquiry_                     RV_INQUIRY      
#define process_rv_doe_levels_          PROCESS_RV_DOE_LEVELS
#define nodal_path_correlations_        NODAL_PATH_CORRELATIONS     
#define element_path_correlations_      ELEMENT_PATH_CORRELATIONS       
#define put_correlation_coefficient_    PUT_CORRELATION_COEFFICIENT 
#define delete_correlation_coefficient_ DELETE_CORRELATION_COEFFICIENT
#define get_sample_                     GET_SAMPLE  
#define put_response_                   PUT_RESPONSE
#define par_update_                     PAR_UPDATE
#define process_sample_history_         PROCESS_SAMPLE_HISTORY
#define process_post_histogram_         PROCESS_POST_HISTOGRAM
#define process_post_cdf_               PROCESS_POST_CDF 
#define process_post_pinv_              PROCESS_POST_PINV
#define process_post_prob_              PROCESS_POST_PROB
#define process_correlation_table_      PROCESS_CORRELATION_TABLE 
#define process_sensitivities_          PROCESS_SENSITIVITIES
#define process_scatter_plot_           PROCESS_SCATTER_PLOT
#define generate_sample_file_           GENERATE_SAMPLE_FILE

#define process_regression_             PROCESS_REGRESSION
#define print_regression_               PRINT_REGRESSION
#define plot_regression_                PLOT_REGRESSION
#define process_samples_on_rs_          PROCESS_SAMPLES_ON_RS

#define pds_mdlsave_                    PDS_MDLSAVE 
#define pds_mdlfree_                    PDS_MDLFREE
#define pds_mdlresume_                  PDS_MDLRESUME 
#define pds_status_                     PDS_STATUS
#define pds_clear_                      PDS_CLEAR
#define pds_close_                      PDS_CLOSE
#define put_pds_method_                 PUT_PDS_METHOD
#define put_dmcs_options_               PUT_DMCS_OPTIONS
#define put_lhs_options_                PUT_LHS_OPTIONS
#define put_bbm_options_                PUT_BBM_OPTIONS
#define put_ccd_options_                PUT_CCD_OPTIONS
#define put_pduser_options_             PUT_PDUSER_OPTIONS
#define put_run_options_                PUT_RUN_OPTIONS
#define pds_undoc_debug_                PDS_UNDOC_DEBUG
#define pdtest_                         PDTEST
#define put_report_option_              PUT_REPORT_OPTION
#define get_report_option_              GET_REPORT_OPTION
#define create_report_assoc_files_      CREATE_REPORT_ASSOC_FILES

/* The following routines are used for ANSYS *GET command */
#define pds_get_pds_open_               PDS_GET_PDS_OPEN
#define pds_get_anal_name_              PDS_GET_ANAL_NAME
#define pds_get_saveresu_name_          PDS_GET_SAVERESU_NAME
#define pds_get_method_name_            PDS_GET_METHOD_NAME
#define pds_get_rv_name_                PDS_GET_RV_NAME
#define pds_get_rv_value_               PDS_GET_RV_VALUE
#define pds_get_rv_par_                 PDS_GET_RV_PAR 
#define pds_get_rv_dis_name_            PDS_GET_RV_DIS_NAME 
#define pds_get_sys_num_rv_             PDS_GET_SYS_NUM_RV
#define pds_get_sys_rv_name_            PDS_GET_SYS_RV_NAME
#define pds_get_sys_rv_value_           PDS_GET_SYS_RV_VALUE
#define pds_get_corr_                   PDS_GET_CORR
#define pds_get_rp_name_                PDS_GET_RP_NAME
#define pds_get_rp_value_               PDS_GET_RP_VALUE
#define pds_get_ccd_defa_               PDS_GET_CCD_DEFA
#define pds_get_bbm_defa_               PDS_GET_BBM_DEFA
#define pds_get_ccd_lopt_               PDS_GET_CCD_LOPT
#define pds_get_bbm_lopt_               PDS_GET_BBM_LOPT
#define pds_get_ccd_vtyp_               PDS_GET_CCD_VTYP
#define pds_get_bbm_vtyp_               PDS_GET_BBM_VTYP
#define pds_get_ccd_ldef_               PDS_GET_CCD_LDEF
#define pds_get_bbm_ldef_               PDS_GET_BBM_LDEF
#define pds_get_ccd_lval_               PDS_GET_CCD_LVAL
#define pds_get_bbm_lval_               PDS_GET_BBM_LVAL
#define pds_get_num_rv_                 PDS_GET_NUM_RV
#define pds_get_num_rp_                 PDS_GET_NUM_RP
#define pds_get_num_corcoef_            PDS_GET_NUM_CORCOEF
#define pds_get_output_index_           PDS_GET_OUTPUT_INDEX
#define pds_get_mean_                   PDS_GET_MEAN
#define pds_get_stdv_                   PDS_GET_STDV
#define pds_get_skew_                   PDS_GET_SKEW
#define pds_get_kurt_                   PDS_GET_KURT
#define pds_get_max_                    PDS_GET_MAX
#define pds_get_min_                    PDS_GET_MIN
#define pds_get_linear_cc_              PDS_GET_LINEAR_CC
#define pds_get_rank_cc_                PDS_GET_RANK_CC
#define pds_get_num_resultsets_         PDS_GET_NUM_RESULTSETS
#define pds_get_num_mcs_resultsets_     PDS_GET_NUM_MCS_RESULTSETS
#define pds_get_num_rsm_resultsets_     PDS_GET_NUM_RSM_RESULTSETS
#define pds_get_num_solusets_           PDS_GET_NUM_SOLUSETS
#define pds_get_num_mcs_solusets_       PDS_GET_NUM_MCS_SOLUSETS
#define pds_get_num_rsm_solusets_       PDS_GET_NUM_RSM_SOLUSETS
#define pds_get_user_nfail_             PDS_GET_USER_NFAIL
#define pds_get_user_nmcs_              PDS_GET_USER_NMCS
#define pds_get_user_nrsm_              PDS_GET_USER_NRSM
#define pds_get_num_samples_in_file_    PDS_GET_NUM_SAMPLES_IN_FILE
#define pds_get_rsm_plevels_            PDS_GET_RSM_PLEVELS
#define pds_get_mcs_autostop_           PDS_GET_MCS_AUTOSTOP
#define pds_get_iseed_                  PDS_GET_ISEED
#define pds_get_rsm_options_            PDS_GET_RSM_OPTIONS
#define pds_get_nsim_                   PDS_GET_NSIM
#define pds_get_nrep_                   PDS_GET_NREP
#define pds_get_coefficient_num_        PDS_GET_COEFFICIENT_NUM
#define pds_get_rsm_coefficient_        PDS_GET_RSM_COEFFICIENT
#define pds_get_run_parallel_option_    PDS_GET_RUN_PARALLEL_OPTION
#define pds_get_resultset_label_        PDS_GET_RESULTSET_LABEL
#define pds_get_soluset_label_          PDS_GET_SOLUSET_LABEL
#define pds_get_num_rssets_             PDS_GET_NUM_RSSETS
#define pds_get_rsst_label_             PDS_GET_RSST_LABEL
#define pds_get_rsst_xsol_              PDS_GET_RSST_XSOL
#define pds_get_rsst_nfrp_              PDS_GET_RSST_NFRP
#define pds_get_rsur_xfrp_              PDS_GET_RSUR_XFRP
#define pds_get_rsur_rmod_              PDS_GET_RSUR_RMOD
#define pds_get_rsur_ytty_              PDS_GET_RSUR_YTTY
#define pds_get_rsur_ytvl_              PDS_GET_RSUR_YTVL
#define pds_get_rsur_filt_              PDS_GET_RSUR_FILT
#define pds_get_rsur_conf_              PDS_GET_RSUR_CONF
#define pds_get_rseq_ybox_              PDS_GET_RSEQ_YBOX
#define pds_get_rseq_ntrm_              PDS_GET_RSEQ_NTRM
#define pds_get_rseq_ttyp_              PDS_GET_RSEQ_TTYP
#define pds_get_rseq_rv1_               PDS_GET_RSEQ_RV1
#define pds_get_rseq_rv2_               PDS_GET_RSEQ_RV2
#define pds_get_rseq_coef_              PDS_GET_RSEQ_COEF
#define pds_get_rseq_slop_              PDS_GET_RSEQ_SLOP
#define pds_get_rseq_icpt_              PDS_GET_RSEQ_ICPT
#define pds_get_rsac_sse_               PDS_GET_RSAC_SSE
#define pds_get_rsac_ssadj_             PDS_GET_RSAC_SSADJ
#define pds_get_rsac_r2_                PDS_GET_RSAC_R2
#define pds_get_rsac_r2adj_             PDS_GET_RSAC_R2ADJ
#define pds_get_rsac_rsabs_             PDS_GET_RSAC_RSABS
#define pds_get_rsac_rsrel_             PDS_GET_RSAC_RSREL
#define pds_get_rsac_cvstat_            PDS_GET_RSAC_CVSTAT
#define pds_get_rsac_cvprob_            PDS_GET_RSAC_CVPROB
#define pds_get_rsac_cvmxidx_           PDS_GET_RSAC_CVMXIDX

/* Fortran routines called from C */
/*
#define pdfio_                          PDFIO
*/
#define set_loop_abort_                 SET_LOOP_ABORT
#define get_loop_abort_                 GET_LOOP_ABORT
#endif

#if defined(WATCOMC_SYS)

/* C Functions called from FORTRAN */

#pragma aux PDS_PUT_ANAL_NAME "^";
#pragma aux PUT_RANDOM_INPUT_PARAMETER "^";
#pragma aux PUT_RANDOM_OUTPUT_PARAMETER "^";
#pragma aux DELETE_RANDOM_PARAMETER "^";
#pragma aux PROCESS_RV_GRAPH "^";
#pragma aux RV_INQUIRY "^";
#pragma aux PROCESS_RV_DOE_LEVELS "^";
#pragma aux NODAL_PATH_CORRELATIONS "^";
#pragma aux ELEMENT_PATH_CORRELATIONS "^";
#pragma aux PUT_CORRELATION_COEFFICIENT "^";
#pragma aux DELETE_CORRELATION_COEFFICIENT "^";
#pragma aux GET_SAMPLE "^";
#pragma aux PUT_RESPONSE "^";
#pragma aux PAR_UPDATE "^";
#pragma aux PROCESS_SAMPLE_HISTORY "^";
#pragma aux PROCESS_POST_HISTOGRAM "^";
#pragma aux PROCESS_POST_CDF "^";
#pragma aux PROCESS_POST_PROB "^";
#pragma aux PROCESS_POST_PINV "^";
#pragma aux PROCESS_CORRELATION_TABLE "^";
#pragma aux PROCESS_SENSITIVITIES "^";
#pragma aux PROCESS_SCATTER_PLOT "^";
#pragma aux GENERATE_SAMPLE_FILE "^";

#pragma aux PROCESS_REGRESSION "^";
#pragma aux PRINT_REGRESSION "^";
#pragma aux PLOT_REGRESSION "^";
#pragma aux PROCESS_SAMPLES_ON_RS "^";
#pragma aux PROCESS_WRITE_RS_DATA "^";

#pragma aux PDS_MDLSAVE "^";
#pragma aux PDS_MDLFREE "^";
#pragma aux PDS_SAVE "^";
#pragma aux PDS_MDLRESUME "^";
#pragma aux PDS_RESUME "^";
#pragma aux PDS_STATUS "^";
#pragma aux PDS_CLEAR "^";
#pragma aux PUT_PDS_METHOD "^";
#pragma aux PUT_DMCS_OPTIONS "^";
#pragma aux PUT_LHS_OPTIONS "^";
#pragma aux PUT_BBM_OPTIONS "^";
#pragma aux PUT_CCD_OPTIONS "^";
#pragma aux PUT_PDUSER_OPTIONS "^";
#pragma aux PUT_RUN_OPTIONS "^";
#pragma aux PDS_GET_ISEED "^";
#pragma aux PDS_UNDOC_DEBUG "^";
#pragma aux PDTEST "^";
#pragma aux PUT_REPORT_OPTION "^";
#pragma aux GET_REPORT_OPTION "^";
#pragma aux CREATE_REPORT_ASSOC_FILES "^";

/* The following routines are used for ANSYS *GET command */
#pragma aux PDS_GET_PDS_OPEN "^";
#pragma aux PDS_GET_ANAL_NAME "^";
#pragma aux PDS_GET_SAVERESU_NAME "^";
#pragma aux PDS_GET_METHOD_NAME "^";
#pragma aux PDS_GET_RV_NAME "^";
#pragma aux PDS_GET_RV_VALUE "^";
#pragma aux PDS_GET_RV_PAR "^";
#pragma aux PDS_GET_RV_DIS_NAME "^";
#pragma aux PDS_GET_SYS_NUM_RV "^";
#pragma aux PDS_GET_SYS_RV_NAME "^";
#pragma aux PDS_GET_SYS_RV_VALUE "^";
#pragma aux PDS_GET_CORR "^";
#pragma aux PDS_GET_RP_NAME "^";
#pragma aux PDS_GET_RP_VALUE "^";
#pragma aux PDS_GET_CCD_DEFA "^";
#pragma aux PDS_GET_BBM_DEFA "^";
#pragma aux PDS_GET_CCD_LOPT "^";
#pragma aux PDS_GET_BBM_LOPT "^";
#pragma aux PDS_GET_CCD_VTYP "^";
#pragma aux PDS_GET_BBM_VTYP "^";
#pragma aux PDS_GET_CCD_LDEF "^";
#pragma aux PDS_GET_BBM_LDEF "^";
#pragma aux PDS_GET_CCD_LVAL "^";
#pragma aux PDS_GET_BBM_LVAL "^";
#pragma aux PDS_GET_NUM_RV "^";
#pragma aux PDS_GET_NUM_RP "^";
#pragma aux PDS_GET_NUM_CORCOEF "^";
#pragma aux PDS_GET_OUTPUT_INDEX "^";
#pragma aux PDS_GET_MEAN "^";
#pragma aux PDS_GET_STDV "^";
#pragma aux PDS_GET_SKEW "^";
#pragma aux PDS_GET_KURT "^";
#pragma aux PDS_GET_MAX "^";
#pragma aux PDS_GET_MIN "^";
#pragma aux PDS_GET_LINEAR_CC "^";
#pragma aux PDS_GET_RANK_CC "^";
#pragma aux PDS_GET_NUM_RESULTSETS "^";
#pragma aux PDS_GET_NUM_MCS_RESULTSETS "^";
#pragma aux PDS_GET_NUM_RSM_RESULTSETS "^";
#pragma aux PDS_GET_NUM_SOLUSETS "^";
#pragma aux PDS_GET_NUM_MCS_SOLUSETS "^";
#pragma aux PDS_GET_NUM_RSM_SOLUSETS "^";
#pragma aux PDS_GET_USER_NFAIL "^";
#pragma aux PDS_GET_USER_NMCS "^";
#pragma aux PDS_GET_USER_NRSM "^";
#pragma aux PDS_GET_NUM_SAMPLES_IN_FILE "^";
#pragma aux PDS_GET_RSM_PLEVELS "^";
#pragma aux PDS_GET_MCS_AUTOSTOP "^";
#pragma aux PDS_GET_RSM_OPTIONS "^";
#pragma aux PDS_GET_NSIM "^";
#pragma aux PDS_GET_NSTAT "^";
#define aux PDS_GET_RUN_PARALLEL_OPTION "^";
#pragma aux PDS_GET_RESULTSET_LABEL "^";
#pragma aux PDS_GET_SOLUSET_LABEL "^";
#pragma aux PDS_GET_NUM_RSSETS "^";
#pragma aux PDS_GET_RSST_LABEL "^";
#pragma aux PDS_GET_RSST_XSOL "^";
#pragma aux PDS_GET_RSST_NFRP "^";
#pragma aux PDS_GET_RSUR_XFRP "^";
#pragma aux PDS_GET_RSUR_RMOD "^";
#pragma aux PDS_GET_RSUR_YTTY "^";
#pragma aux PDS_GET_RSUR_YTVL "^";
#pragma aux PDS_GET_RSUR_FILT "^";
#pragma aux PDS_GET_RSUR_CONF "^";
#pragma aux PDS_GET_RSEQ_YBOX "^";
#pragma aux PDS_GET_RSEQ_NTRM "^";
#pragma aux PDS_GET_RSEQ_TTYP "^";
#pragma aux PDS_GET_RSEQ_RV1 "^";
#pragma aux PDS_GET_RSEQ_RV2 "^";
#pragma aux PDS_GET_RSEQ_COEF "^";
#pragma aux PDS_GET_RSEQ_SLOP "^";
#pragma aux PDS_GET_RSEQ_ICPT "^";
#pragma aux PDS_GET_RSAC_SSE "^";
#pragma aux PDS_GET_RSAC_SSADJ "^";
#pragma aux PDS_GET_RSAC_R2 "^";
#pragma aux PDS_GET_RSAC_R2ADJ "^";
#pragma aux PDS_GET_RSAC_RSABS "^";
#pragma aux PDS_GET_RSAC_RSREL "^";
#pragma aux PDS_GET_RSAC_CVSTAT "^";
#pragma aux PDS_GET_RSAC_CVPROB "^";
#pragma aux PDS_GET_RSAC_CVMXIDX "^";

/* Fortran routines called from C */
/*
#pragma aux PDFIO "^";
*/
#pragma aux SET_LOOP_ABORT "^";
#pragma aux GET_LOOP_ABORT "^";
#endif

/* Function return type declaration */

#if !defined(PCWINNT_SYS)

/* C Functions called from FORTRAN */

INT  put_random_input_parameter_();
INT  put_random_output_parameter_();
INT  delete_random_parameter_();
INT  process_rv_graph_();
INT  rv_inquiry_();
INT  process_rv_doe_levels_();
INT  nodal_path_correlations_();
INT  element_path_correlations_();
INT  put_correlation_coefficient_();
INT  delete_correlation_coefficient_();
INT  put_pds_method_();
INT  put_dmcs_options_();
INT  put_lhs_options_();
INT  put_bbm_options_();
INT  put_ccd_options_();
INT  put_pduser_options_();
INT  put_run_options_();
INT  put_response_();
INT  par_update_();
INT  process_sample_history_();
INT  process_post_histogram_();
INT  process_post_cdf_();
INT  process_post_prob_();
INT  process_post_pinv_();
INT  process_correlation_table_();
INT  process_sensitivities_();
INT  process_scatter_plot_();
INT  generate_sample_file_();

INT  process_regression_();
INT  print_regression_();
INT  plot_regression_();
INT  process_samples_on_rs_();

INT  pds_mdlresume_();
INT  pds_mdlsave_();
void pds_mdlfree_();
INT  create_report_assoc_files_();

void get_sample_();
void pds_status_();
void pds_clear_();
void pds_close_();
void pds_undoc_debug_();
void pdtest_();
void put_report_option_();
void get_report_option_();

/* The following routines are used for ANSYS *GET command */
INT  pds_get_pds_open_();
void pds_get_anal_name_();
void pds_get_saveresu_name_();
INT  pds_get_method_name_();
INT  pds_get_rv_name_();
INT  pds_get_rv_value_();
INT  pds_get_rv_par_();
INT  pds_get_rv_dis_name_();
void pds_get_sys_num_rv_();
INT  pds_get_sys_rv_name_();
INT  pds_get_sys_rv_value_();
INT  pds_get_corr_();
INT  pds_get_rp_name_();
INT  pds_get_rp_value_();
INT  pds_get_ccd_defa_();
INT  pds_get_bbm_defa_();
INT  pds_get_ccd_lopt_();
INT  pds_get_bbm_lopt_();
INT  pds_get_ccd_vtyp_();
INT  pds_get_bbm_vtyp_();
INT  pds_get_ccd_ldef_();
INT  pds_get_bbm_ldef_();
INT  pds_get_ccd_lval_();
INT  pds_get_bbm_lval_();
INT  pds_get_output_index_();
INT  pds_get_mean_();                   
INT  pds_get_stdv_();       
INT  pds_get_skew_();   
INT  pds_get_kurt_();
INT  pds_get_max_();    
INT  pds_get_min_();
INT  pds_get_linear_cc_();  
INT  pds_get_rank_cc_();    
INT  pds_get_nsim_();
INT  pds_get_nrep_();
void pds_get_num_resultsets_();
void pds_get_num_mcs_resultsets_();
void pds_get_num_rsm_resultsets_();
void pds_get_num_solusets_();
void pds_get_num_mcs_solusets_();
void pds_get_num_rsm_solusets_();
INT  pds_get_user_nfail_();
INT  pds_get_user_nmcs_();
INT  pds_get_user_nrsm_();
INT  pds_get_num_samples_in_file_();
INT  pds_get_rsm_plevels_();
INT  pds_get_mcs_autostop_();
INT  pds_get_iseed_();
INT  pds_get_rsm_options_();
INT  pds_get_run_parallel_option_();
INT  pds_get_resultset_label_();
INT  pds_get_soluset_label_();
void pds_get_num_rssets_();
INT  pds_get_rsst_label_();
INT  pds_get_rsst_xsol_();
INT  pds_get_rsst_nfrp_();
INT  pds_get_rsur_xfrp_();
INT  pds_get_rsur_rmod_();
INT  pds_get_rsur_ytty_();
INT  pds_get_rsur_ytvl_();
INT  pds_get_rsur_filt_();
INT  pds_get_rsur_conf_();
INT  pds_get_rseq_ybox_();
INT  pds_get_rseq_ntrm_();
INT  pds_get_rseq_ttyp_();
INT  pds_get_rseq_rv1_();
INT  pds_get_rseq_rv2_();
INT  pds_get_rseq_coef_();
INT  pds_get_rseq_slop_();
INT  pds_get_rseq_icpt_();
INT  pds_get_rsac_sse_();
INT  pds_get_rsac_ssadj_();
INT  pds_get_rsac_r2_();
INT  pds_get_rsac_r2adj_();
INT  pds_get_rsac_rsabs_();
INT  pds_get_rsac_rsrel_();
INT  pds_get_rsac_cvstat_();
INT  pds_get_rsac_cvprob_();
INT  pds_get_rsac_cvmxidx_();

void pds_get_num_rv_();
void pds_get_num_rp_();
void pds_get_num_corcoef_();
 
/* Fortran routines called from C */
/*
void pdfio_();
*/
void set_loop_abort_();
INT  get_loop_abort_();


#else

/* C Functions called from FORTRAN */
INT  CALLTYP put_random_input_parameter_( INT*, DOUBLE*, INT*, DOUBLE* );
INT  CALLTYP put_random_output_parameter_( INT*, DOUBLE* );
INT  CALLTYP delete_random_parameter_(INT* );
INT  CALLTYP process_rv_graph_(INT*, DOUBLE*, DOUBLE*, INT*);
INT  CALLTYP rv_inquiry_(INT*, INT*, INT*, DOUBLE*, DOUBLE*);
INT  CALLTYP process_rv_doe_levels_(INT*, INT*, INT*, INT*, INT*, DOUBLE*);
INT  CALLTYP nodal_path_correlations_( INT*, INT*, INT*, DOUBLE*, INT*, INT*, INT*, INT*, DOUBLE *, DOUBLE* );
INT  CALLTYP element_path_correlations_( INT*, INT*, DOUBLE*, INT*, INT*, INT*, DOUBLE*, DOUBLE* );
INT  CALLTYP put_correlation_coefficient_(INT*, INT*, DOUBLE*);
INT  CALLTYP delete_correlation_coefficient_(INT*, INT*);
INT  CALLTYP put_pds_method_( INT*, INT* );
INT  CALLTYP put_dmcs_options_( INT*, INT*, INT*, DOUBLE*, DOUBLE*, INT*, INT*);
INT  CALLTYP put_lhs_options_( INT*, INT*, INT*, INT*, INT*, DOUBLE*, DOUBLE*, INT*, INT*);
INT  CALLTYP put_ccd_options_( INT*, DOUBLE* );
INT  CALLTYP put_bbm_options_( INT*, DOUBLE* );
INT  CALLTYP put_pduser_options_( INT*, INT* );
INT  CALLTYP put_run_options_(INT*, INT*, INT*, INT*, INT*, INT*, INT*, INT*);
INT  CALLTYP put_response_(INT*, INT*, DOUBLE*, DOUBLE*, INT*);
INT  CALLTYP par_update_( INT*, INT*, INT*, INT*, INT* );
INT  CALLTYP process_sample_history_(INT*, INT*, INT*, DOUBLE*);
INT  CALLTYP process_post_histogram_(INT*, INT*, INT*, INT*);
INT  CALLTYP process_post_cdf_(INT*, INT*, INT*, DOUBLE*, INT*);
INT  CALLTYP process_post_prob_(INT*, INT*, INT*, DOUBLE*, INT*, DOUBLE*);
INT  CALLTYP process_post_pinv_(INT*, INT*, DOUBLE*, INT*, DOUBLE*);
INT  CALLTYP process_correlation_table_(INT*, INT*, INT*, INT*, INT*, DOUBLE*, INT*);
INT  CALLTYP process_sensitivities_(INT*, INT*, INT*, INT*, DOUBLE*);
INT  CALLTYP process_scatter_plot_(INT*, INT*, INT*, INT*, INT*, INT*);
INT  CALLTYP generate_sample_file_( );

INT  CALLTYP process_regression_( INT*, INT*, INT*, INT*, INT*, DOUBLE*, INT*, DOUBLE*, INT*, DOUBLE* );
INT  CALLTYP print_regression_( INT*, INT*, INT*, DOUBLE* );
INT  CALLTYP plot_regression_( INT*, INT*, INT*, INT*, INT*, INT*, DOUBLE*, DOUBLE*);
INT  CALLTYP process_samples_on_rs_(INT*,INT*,INT*);

INT  CALLTYP pds_mdlresume_();
INT  CALLTYP pds_mdlsave_();
INT  CALLTYP create_report_assoc_files_( );

void CALLTYP pds_mdlfree_();
void CALLTYP get_sample_( );
void CALLTYP pds_status_();
void CALLTYP pds_clear_(INT* );
void CALLTYP pds_close_( );
void CALLTYP pds_undoc_debug_(INT*);
void CALLTYP pdtest_();
void CALLTYP put_report_option_(INT*, INT*, INT*, INT*, INT*, INT*, INT*, INT*, DOUBLE*);
void CALLTYP get_report_option_(INT*, INT*, INT*, INT*, INT*, INT*, INT*, INT*, DOUBLE*);

/* The following routines are used for ANSYS *GET command */
INT  CALLTYP pds_get_pds_open_( );
void CALLTYP pds_get_anal_name_(INT*, INT*, INT*, INT*, INT*, INT*);
void CALLTYP pds_get_saveresu_name_(INT*, INT*, INT*, INT*, INT*, INT*);
INT  CALLTYP pds_get_method_name_(INT*, INT*, INT*, INT*, INT*);
INT  CALLTYP pds_get_rv_name_( INT*, INT*, INT* );
INT  CALLTYP pds_get_rv_value_( INT*, DOUBLE* );
INT  CALLTYP pds_get_rv_par_(INT*, INT*, DOUBLE*);
INT  CALLTYP pds_get_rv_dis_name_(INT*, INT*, INT*);
void CALLTYP pds_get_sys_num_rv_( INT* );
INT  CALLTYP pds_get_sys_rv_name_( INT*, INT*, INT* );
INT  CALLTYP pds_get_sys_rv_value_( INT*, DOUBLE* );
INT  CALLTYP pds_get_corr_(INT*, INT*, DOUBLE*);                    
INT  CALLTYP pds_get_rp_name_(INT*, INT*, INT*);
INT  CALLTYP pds_get_rp_value_(INT*, DOUBLE*);
INT  CALLTYP pds_get_ccd_defa_(INT*, DOUBLE*);
INT  CALLTYP pds_get_bbm_defa_(INT*, DOUBLE*);
INT  CALLTYP pds_get_ccd_lopt_(INT*, INT*, INT*, INT*);
INT  CALLTYP pds_get_bbm_lopt_(INT*, INT*, INT*, INT*);
INT  CALLTYP pds_get_ccd_vtyp_(INT*, INT*, INT*, INT*);
INT  CALLTYP pds_get_bbm_vtyp_(INT*, INT*, INT*, INT*);
INT  CALLTYP pds_get_ccd_ldef_(INT*, INT*, INT*, INT*);
INT  CALLTYP pds_get_bbm_ldef_(INT*, INT*, INT*, INT*);
INT  CALLTYP pds_get_ccd_lval_(INT*, INT*, INT*, DOUBLE*);
INT  CALLTYP pds_get_bbm_lval_(INT*, INT*, INT*, DOUBLE*);
INT  CALLTYP pds_get_output_index_(INT*, INT*, INT*);
INT  CALLTYP pds_get_mean_(INT*, INT*, INT*, DOUBLE*);                  
INT  CALLTYP pds_get_stdv_(INT*, INT*, INT*, DOUBLE*);  
INT  CALLTYP pds_get_skew_(INT*, INT*, INT*, DOUBLE*);
INT  CALLTYP pds_get_kurt_(INT*, INT*, INT*, DOUBLE*);
INT  CALLTYP pds_get_max_(INT*, INT*, INT*, DOUBLE*);   
INT  CALLTYP pds_get_min_(INT*, INT*, INT*, DOUBLE*);
INT  CALLTYP pds_get_linear_cc_(INT*, INT*, INT*, INT*, DOUBLE*);   
INT  CALLTYP pds_get_rank_cc_(INT*, INT*, INT*, INT*, DOUBLE*); 
INT  CALLTYP pds_get_nsim_(INT*, INT*);
INT  CALLTYP pds_get_nrep_(INT*, INT*);
void CALLTYP pds_get_num_resultsets_(INT*);
void CALLTYP pds_get_num_mcs_resultsets_(INT*);
void CALLTYP pds_get_num_rsm_resultsets_(INT*);
void CALLTYP pds_get_num_solusets_(INT*);
void CALLTYP pds_get_num_mcs_solusets_(INT*);
void CALLTYP pds_get_num_rsm_solusets_(INT*);
INT  CALLTYP pds_get_user_nfail_( INT* );
INT  CALLTYP pds_get_user_nmcs_( INT* );
INT  CALLTYP pds_get_user_nrsm_( INT* );
INT  CALLTYP pds_get_num_samples_in_file_( INT* );
INT  CALLTYP pds_get_rsm_plevels_(INT*, INT*, DOUBLE*);
INT  CALLTYP pds_get_mcs_autostop_ (INT*, INT*, DOUBLE*, DOUBLE*, INT*);
INT  CALLTYP pds_get_iseed_(INT*, INT*);
INT  CALLTYP pds_get_rsm_options_ (INT*, DOUBLE*, INT*);
INT  CALLTYP pds_get_run_parallel_option_( INT* ); 
INT  CALLTYP pds_get_resultset_label_ (INT*, INT*, INT*, INT*);
INT  CALLTYP pds_get_soluset_label_ (INT*, INT*, INT*, INT*);
void CALLTYP pds_get_num_rssets_(INT*);
INT  CALLTYP pds_get_rsst_label_ (INT*, INT*, INT*);
INT  CALLTYP pds_get_rsst_xsol_ (INT*, INT*);
INT  CALLTYP pds_get_rsst_nfrp_ (INT*, INT*);
INT  CALLTYP pds_get_rsur_xfrp_ (INT*, INT*, INT*);
INT  CALLTYP pds_get_rsur_rmod_ (INT*, INT*, INT*, INT*);
INT  CALLTYP pds_get_rsur_ytty_  (INT*, INT*, INT*, INT*);
INT  CALLTYP pds_get_rsur_ytvl_  (INT*, INT*, DOUBLE*);
INT  CALLTYP pds_get_rsur_filt_  (INT*, INT*, INT*, INT*);
INT  CALLTYP pds_get_rsur_conf_  (INT*, INT*, DOUBLE*);
INT  CALLTYP pds_get_rseq_ybox_  (INT*, INT*, DOUBLE*);
INT  CALLTYP pds_get_rseq_ntrm_  (INT*, INT*, INT*);
INT  CALLTYP pds_get_rseq_ttyp_  (INT*, INT*, INT*, INT*);
INT  CALLTYP pds_get_rseq_rv1_   (INT*, INT*, INT*, INT*);
INT  CALLTYP pds_get_rseq_rv2_   (INT*, INT*, INT*, INT*);
INT  CALLTYP pds_get_rseq_coef_  (INT*, INT*, INT*, DOUBLE*);
INT  CALLTYP pds_get_rseq_slop_  (INT*, INT*, INT*, DOUBLE*);
INT  CALLTYP pds_get_rseq_icpt_  (INT*, INT*, INT*, DOUBLE*);
INT  CALLTYP pds_get_rsac_sse_     (INT*, INT*, DOUBLE*);
INT  CALLTYP pds_get_rsac_ssadj_   (INT*, INT*, DOUBLE*);
INT  CALLTYP pds_get_rsac_r2_      (INT*, INT*, DOUBLE*);
INT  CALLTYP pds_get_rsac_r2adj_   (INT*, INT*, DOUBLE*);
INT  CALLTYP pds_get_rsac_rsabs_   (INT*, INT*, DOUBLE*);
INT  CALLTYP pds_get_rsac_rsrel_   (INT*, INT*, DOUBLE*);
INT  CALLTYP pds_get_rsac_cvstat_  (INT*, INT*, DOUBLE*);
INT  CALLTYP pds_get_rsac_cvprob_  (INT*, INT*, DOUBLE*);
INT  CALLTYP pds_get_rsac_cvmxidx_ (INT*, INT*, INT*);

void CALLTYP pds_get_num_rv_(INT*);
void CALLTYP pds_get_num_rp_(INT*);
void CALLTYP pds_get_num_corcoef_(INT*);

/* Fortran routines called from C */ 
/*
void CALLTYP pdfio_(DOUBLE*, INT*, INT*, DOUBLE*, DOUBLE*, INT*);
*/
void CALLTYP set_loop_abort_(INT*);
INT  CALLTYP get_loop_abort_( );

#endif


/* THIS IS THE NEW WAY OF DEFINING FORTRAN TO C AND C TO FORTRAN PROTOTYPES */
/* THIS IS THE NEW WAY OF DEFINING FORTRAN TO C AND C TO FORTRAN PROTOTYPES */
/* THIS IS THE NEW WAY OF DEFINING FORTRAN TO C AND C TO FORTRAN PROTOTYPES */
/* THIS IS THE NEW WAY OF DEFINING FORTRAN TO C AND C TO FORTRAN PROTOTYPES */
/* THIS IS THE NEW WAY OF DEFINING FORTRAN TO C AND C TO FORTRAN PROTOTYPES */


/* ===================================================================== */
/* For systems needing lower case names without an underscore at the end */
/* ===================================================================== */
#if defined(LOWERCASENOUNDER_SYS)

/* C functions called from FORTRAN */
/* ------------------------------- */
#define pds_put_anal_name                 pds_put_anal_name
#define pds_resume                        pds_resume
#define pds_save                          pds_save
#define process_write_rs_data             process_write_rs_data


/* FORTRAN functions called from C */
/* ------------------------------- */
/*
#define C2F_Test                    c2f_test
*/

#endif


/* ===================================================================== */
/* For systems needing upper case names without an underscore at the end */
/* ===================================================================== */
#if defined(UPPERCASENOUNDER_SYS)

/* C functions called from FORTRAN */
/* ------------------------------- */
#define pds_put_anal_name                 PDS_PUT_ANAL_NAME
#define pds_resume                        PDS_RESUME
#define pds_save                          PDS_SAVE
#define process_write_rs_data             PROCESS_WRITE_RS_DATA


/* FORTRAN functions called from C */
/* ------------------------------- */
/*
#define C2F_Test                    C2F_TEST
*/

#endif


/* ================================================================== */
/* For systems needing upper case names with an underscore at the end */
/* ================================================================== */
#if defined(LOWERCASEUNDER_SYS)

/* C functions called from FORTRAN */
/* ------------------------------- */
#define pds_put_anal_name                 pds_put_anal_name_
#define pds_resume                        pds_resume_
#define pds_save                          pds_save_
#define process_write_rs_data             process_write_rs_data_


/* FORTRAN functions called from C */
/* ------------------------------- */
/*
#define C2F_Test                    c2f_test_
*/

#endif



/* ===================== */
/* Prototype definitions */
/* ===================== */

INT FUNCTION  pds_put_anal_name    ( FCHAR( cFileName ), FCHAR( cExtName ), FCHAR( cDirName ) FCHARL( cFileName_len ) FCHARL( cExtName_len ) FCHARL( cDirName_len ) );
INT FUNCTION  pds_resume           ( FCHAR( cFileName ), FCHAR( cExtName ), FCHAR( cDirName ) FCHARL( cFileName_len ) FCHARL( cExtName_len ) FCHARL( cDirName_len ) );
INT FUNCTION  pds_save             ( FCHAR( cFileName ), FCHAR( cExtName ), FCHAR( cDirName ) FCHARL( cFileName_len ) FCHARL( cExtName_len ) FCHARL( cDirName_len ) );
INT FUNCTION  process_write_rs_data( FCHAR( cRSSetLabIn ), FCHAR( cParmNameIn ), INT *iSortFlag, FCHAR( cFullFileNameIn ) FCHARL( cRSSetLabIn_len ) FCHARL( cParmNameIn_len ) FCHARL( cFullFileNameIn_len ) );

/* FORTRAN functions called from C */
/* ------------------------------- */
/*
INT FUNCTION  C2F_Test( );
*/


/* C function call from FOTRAN   (using new style) */

#if defined(UPPERCASENOUNDER_SYS)
#define trendline_fit TRENDLINE_FIT 
#endif

#if defined(LOWERCASENOUNDER_SYS)
#define trendline_fit trendline_fit 
#endif

#if defined(LOWERCASEUNDER_SYS)
#define trendline_fit trendline_fit_
#endif

INT FUNCTION trendline_fit(DOUBLE*, DOUBLE*, DOUBLE*, INT*, 
                           DOUBLE*, INT*, INT*, INT*,
                           DOUBLE*, DOUBLE*, DOUBLE*);

#endif /* _PDS_CTOF_TYPES_ */
