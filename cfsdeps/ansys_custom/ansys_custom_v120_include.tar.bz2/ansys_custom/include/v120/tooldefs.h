/* 
 * *** copyright(c) 2009 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */
#ifndef _TOOLDEFS_H
#define _TOOLDEFS_H

#include "StandardH.h"
#include "ErrCatalog.h"
#include "sysparh.h"

#define	MAX_MNEMONIC_SIZE 	64  	/* max mnemonic size */
#define 	MAX_INCLINE_LEN 	75		/* max length of include file (.msg files) line  */
#define 	MAX_BUF_SIZE		1024 	/* max buffer size */ 

#define 	START_ID			257       
				/* starting id for xtrnlize utility */

#define 	MAXIMUM_IDS  		1024*40 
			/* max array size while sorting message ids */

#define 	MAX_HASH_SIZE    	512	/* Hash Table Size */

#define		ANSYSHOME			"ANSHOME"
#define 	FUNCT_NAME			"ANSERR"
#define 	MAX_ANSCALL_SIZE 	MAX_ERROR_SIZE + 256 	/* maxsz of Anserr */
#define		DB_REC_SIZ			sizeof(DB_REC)
#define 	INCL_FILE_HEADER	"/*%%ENUMERATION_STARTS*/"
#define 	INCL_FILE_TRAILOR	"/*%%ENUMERATION_ENDS*/"
#define 	AMBIGIOUS  			"TO_BE_ASSIGNED"

/*
 * Structure to be used for reading a record from string.dat
 * The Message String is read in a seperate variable:-
 */

typedef struct
   {
   int  MsgStrLen ;							/* Length of Message String*/
   char	TxtId [ MAX_MNEMONIC_SIZE ];		/* Text Mesg Id         */
   INT	NumId ;								/* Numerical Mesg ID    */
   char	InclSrcName[ MAX_FILENAME_SIZE ];	/* Include file name    */
   }  FILE_DB_REC;

/*
 * The following structure is used to read/modify records in the FILE_DB_REC.
 * This structure also contains Message String as a field:-
 */

typedef struct
   {
   char	*MsgStr;							/* Message string 		*/
   char	TxtId [ MAX_MNEMONIC_SIZE ];		/* Text Mesg Id         */
   INT	NumId ;								/* Numerical Mesg ID    */
   char	InclSrcName[ MAX_FILENAME_SIZE ];	/* Include file name    */
   }  DB_REC;




#endif 
