#ifndef _RESIZE_ARRAY_H_
#define _RESIZE_ARRAY_H_
#include "DomainDec.h"


template <class Type> class ResizeArray {
   Type *d;
   Type init_v;
   INT  csize;  // current size
 public:
   ResizeArray(Type i, INT ini_size=16);
   ~ResizeArray();
   Type &operator[] (INT i);
   void resize(INT ns);
   INT max_size() { return csize; }
   Type *operator + (INT i); //dangerous operator to use with caution.
    // It will not check that the returned poINTer is not used beyond
    // the existing values
   Type *data() const { return d; }
   Type *yield(); // When we want to keep the array and remove the resizing
};

template <class Type>
inline
Type &ResizeArray<Type>::operator[](INT i) {
 if(i >= csize)
    resize(i);
 return d[i];
}

template <class Type>
inline
Type *ResizeArray<Type>::operator+(INT i) {
  if(i >= csize)
    resize(i);
 return d+i;
}


template <class Type>
ResizeArray<Type>::ResizeArray(Type iv, INT is) {
  init_v = iv;
  csize  = is;
  d = new Type[csize];

  INT i;
  for(i=0; i < csize; ++i)
    d[i] = init_v;
}

template <class Type>
void
ResizeArray<Type>::resize(INT ns)
{
     INT nsize = (3*csize)/2;
     if(ns >= nsize) nsize=ns+1;
     Type *nd = new Type[nsize];
     INT j;
     for(j=0; j < csize; ++j)
        nd[j] = d[j];
     for(; j <nsize; ++j)
       nd[j] = init_v;
     delete[]d;
     csize=nsize;
     d=nd;
}

template <class Type>
ResizeArray<Type>::~ResizeArray()
{
 if(d)
  delete[]d;
}

template  <class Type>
Type *
ResizeArray<Type>::yield()
{
 Type *old = d;
 d = (Type *)0;
 return old;
}
#endif
