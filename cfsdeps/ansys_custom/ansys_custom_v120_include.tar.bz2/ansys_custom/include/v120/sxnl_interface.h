////////////////////////////////////////////////////////////////////////////
//                                                                        //
//          copyright(c) 2009 SAS IP, Inc.  All rights reserved.            //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: sxnl_interface.h $
// $Revision: 1.8.2.1 $Id: 
// $Date: 2009/04/10 15:33:26 $
// $Author: jtm $
//
// Decription: 
//
////////////////////////////////////////////////////////////////////////////


#ifndef __SXNL_INTERFACE__
#define __SXNL_INTERFACE__ 1

#if defined(LOWERCASENOUNDER_SYS)
#define eosave			eosave
#define OsavRestore		osavrestore
#define saveEsav		saveesav
#define restoreEsav		restoreesav
#define getgrtrvalue		getgrtrvalue
#define PredictDisp		predictdisp
#define lsstr			lsstr
#define lsend			lsend
#define DomainOrder		domainorder
#define slvstr			slvstr
#define slvend			slvend
#define doff			doff
#define fnodgt			fnodgt
#define nlinqr			nlinqr
#define lsfor			lsfor
#define cnvnle			cnvnle
#define modicnvtol		modicnvtol
#define sxnl_lineSearch		sxnl_linesearch
#define sxnl_writeVec		sxnl_writevec
#define sxnl_readVec		sxnl_readvec
#endif

#if defined(UPPERCASENOUNDER_SYS)
#define eosave			EOSAVE
#define OsavRestore		OSAVRESTORE
#define saveEsav		SAVEESAV
#define restoreEsav		RESTOREESAV
#define getgrtrvalue		GETGRTRVALUE
#define PredictDisp		PREDICTDISP
#define lsstr			LSSTR
#define lsend			LSEND
#define DomainOrder		DOMAINORDER
#define slvstr			SLVSTR
#define slvend			SLVEND
#define doff			DOFF
#define fnodgt			FNODGT
#define nlinqr			NLINQR
#define lsfor			LSFOR
#define cnvnle			CNVNLE
#define modicnvtol		MODICNVTOL
#define sxnl_lineSearch		SXNL_LINESEARCH
#define sxnl_writeVec		SXNL_WRITEVEC
#define sxnl_readVec		SXNL_READVEC
#endif

#if defined(LOWERCASEUNDER_SYS)
#define eosave			eosave_
#define OsavRestore		osavrestore_
#define saveEsav		saveesav_
#define restoreEsav		restoreesav_
#define getgrtrvalue		getgrtrvalue_
#define PredictDisp		predictdisp_
#define lsstr			lsstr_
#define lsend			lsend_
#define DomainOrder		domainorder_
#define slvstr			slvstr_
#define slvend			slvend_
#define doff			doff_
#define fnodgt			fnodgt_
#define nlinqr			nlinqr_
#define lsfor			lsfor_
#define cnvnle			cnvnle_
#define modicnvtol		modicnvtol_
#define sxnl_lineSearch		sxnl_linesearch_
#define sxnl_writeVec		sxnl_writevec_
#define sxnl_readVec		sxnl_readvec_
#endif

extern "C"
{
  SUBROUTINE eosave();
  SUBROUTINE OsavRestore();
  SUBROUTINE saveEsav(char *nameFile, int *unit);
  SUBROUTINE restoreEsav(char *nameFile, int *unit);
  SUBROUTINE getgrtrvalue(int*, double*);
  INT FUNCTION PredictDisp(int *kpvinb, int *kcut);
  SUBROUTINE lsstr();
  SUBROUTINE lsend();
  SUBROUTINE DomainOrder(int *);
  SUBROUTINE slvstr(int *);
  SUBROUTINE slvend();
  SUBROUTINE doff(int *, int *, double *, double *);
  INT FUNCTION fnodgt(int*, int*, double*);
  INT FUNCTION nlinqr(int *, int*, int*);
  SUBROUTINE lsfor(double*, double*, double*, double *, double*);
  SUBROUTINE cnvnle(int *);
  SUBROUTINE modicnvtol();
  INT sxnl_lineSearch(INT*,INT*,INT*,DOUBLE*,DOUBLE*);
  SUBROUTINE sxnl_writeVec(double *vec, int *dim, FCHAR(file) FCHARL(file_len));
  SUBROUTINE sxnl_readVec (double *vec, int *dim, FCHAR(file) FCHARL(file_len));
  
  INT  cPcgEnd(INT *keepSemiFiles, INT *PCSFileFlag);
  int sxnl_buildAnsToBcs(int nbddl, int *nbcs, int *nfull, int *ansToBcs, int *bcsToAns, int *fullToBcs, int *fullToAns);
  int sxnl_init();
  int sxnl_free();
};

void sxnl_writeVecC(double *vec, int dim, char *nameFile);
int sxnl_readVecC(double *vec, int dim, char *nameFile);

extern FILE *G_fp;

#endif
