#ifndef _CORE_CPU_DOMAIN_H_
#define _CORE_CPU_DOMAIN_H_

/*****************************************************************************
 *                   Copyright (C) 1999 CMSoft                               *
 *                                                                           *
 *  These lines of code and declarations contain unpublished proprietary     *
 *  information of CMSoft. They may not be copied or duplicated in whole     *
 *  or part without prior authorization from CMSoft.                         *
 *                                                                           *
 *****************************************************************************/

#include <fstream>

class FSElement;
class FSCoordSet;
class FSConnectivity;
class FSSubDTopo;
class DofSetArray;
class DofSet;
template <class T> class FSCommPattern;
class BCond;
class FSFullMatrix;
class FSSubDomCore;
class FSDistInfo;
class FSCoreSolver;
class FSDistVector;
class FSVector;
class FSAssembledSolver;
class EqNumberer;
class FSInfo;
class ConstrainedDSA;
class StackFSFullMatrix;
class FSSubPreprocessor;
class C_Gmat;
class FSRbm;

#include "C_ContactPair.h"
#include "FSConnectivity.h"
#include "C_Gmat.h"

class FSCoreCPUPreprocessor 
{
protected:
  int _glNumSub;		// total number of sub-domains over all CPUs
  int _localNumSub;		// number of sub-domains for this CPU
  
  string _jobname;
  int _glNumEle, _glNumNodes;	// of the whole model
  int _numEle, _numNodes;	// of this CPU
  FSElement **_allElements;	// of this CPU (_numEle)
  FSCoordSet *_allNodes;	// of this CPU (_numNodes)
  FSConnectivity *_subToElem, *_subToNode;	// local subs because local numbering
  FSConnectivity *_nodeToSub, *_subToSub;	// global subs, global numbering
  FSConnectivity *_subToNodeT, *_subToNodeC;
  FSConnectivity *_allSubToElem;

  DofSetArray *_gdsa;
  ConstrainedDSA *_gcdsa;
  
  int *_isElemUnsym;		// size = nbElements
  multimap<int,int> _pairsDual;	// pairs of neighbour domains <subI,subJ> where subI<subJ
  
  // contact pairs
  C_ContactPairMgr *_cPairs;
  int _nbLagPairs;
  int _nbPenPairs;
  
  int *_elemToSub;
  FSConnectivity *_cpuToSub;  
  FSSubPreprocessor **_subPreproc;
  FSSubDomCore **_subCore;
  C_SubContactLagMgr _subContactLagMgr;
  int *_isContactQuadElem;
  int *_singularDom;
  
  int _dim;

  FSInfo *_fsInfo; 
  FSSubDTopo *_subDTopo;
  FSCommPattern<double> *_interPat;

  int *_subToComp;
  FSRbm *_rbms;
  
  int _nCoarse;		// 
  DofSet *_crnDofs;	// 
  
  int *_cpLen, **_cpNode, *_cpDofs;
  int *_ceLen, **_ceNode, **_ceDofs;
  double **_ceCoefs, *_ceRHS;
  
  C_Gcpce *_Gcpce;		// treat CP/CEs as LMPCs
  int _numCELMPC;
  int _numCPLMPC;
  
  C_Gcpce *_GLMPC;		// all others LMPC
  
  int _nCrn;		// Number of corners nodes
 
  void makeAllConnect();
  FSConnectivity *makeSubComList(int glSubNum, int &numNeighb, int *&neighbSubs);
  
  int _nRotNodes;
  int *_rotNodes;
  double (*_nodeRot)[3];
  
  void makeSubICore(int iSub);
  void makeMaps(int iSub);
  void allocateKrrMatrices(int iSub);
  void allocateKrrSolvers(int iSub);
  void makeElemToSub(FSConnectivity *subToE);
  FSConnectivity *updateConnec(FSConnectivity *subToE);
  void makeSubToNode(FSConnectivity *&subToNode);
  virtual void makeContactConnect(FSConnectivity *nodeToSub);
  void makeDualPairs();

public:
  FSCoreCPUPreprocessor();
  virtual ~FSCoreCPUPreprocessor();
  void markUnsymElems();
  virtual void makeRbms(int nbc, BCond *bcs) = 0;
  void renumToLocal();
  void makeDSAs();
  void makeDofComm();
  void setNonLinearities();
  void updatePenaltyElements();
  int getNbGlobDomains()	{return _glNumSub;	}
  int getNbLocDomains()		{return _localNumSub;	}
  string getJobname()		{return _jobname;	}
  C_ContactPairMgr *getcPairs() {return _cPairs;}
  C_SubContactLagMgr &getSubContactLagMgr() {return _subContactLagMgr;}
  C_CouplingMat *getGcpce() {return _Gcpce;}
  C_CouplingMat *getGLMPC() {return _GLMPC;}
  
  void Print();
  void PrintSubDomains();
  void PutStats();
  
  virtual void makeSubProcessors() = 0;
  void setBCs(int nbc, BCond *bc);
  
  // corner selection routine
  void selectCorners(FSCommPattern<int> &cpat);
  void buildSubP(int iSub);
  void buildSubLMPC(int iSub);
  void makeSubCores(DofSet gds);
  void initMatrices(bool);
  virtual void addStiffnesses(int indElem, double *zs, int *ls, int nr, bool unsym);
  
  void setNodeRot(int nr, int *nd, double (*rv)[3])
  { _nRotNodes = nr; _rotNodes = nd; _nodeRot = rv; }
  
  FSDistInfo boundDistInfo();
  FSDistInfo internalDistInfo();
  int cornerInfo();
  FSCoreSolver *getSolver(C_TimeManager &tm);
  
  FSAssembledSolver *makeKccStar();
  void setNodes(FSCoordSet *nodes) { _allNodes = nodes;}
  int localRep(int);
  void setDim(int d) { _dim = d; }
  
  // treat CEs as LMPCs
  void setCEsLMPC(C_Gcpce *Gcpce,
		  int numCE, int *ceLen, int **ceNode, int **ceDofs, double **ceCoefs, double *ceRHS,
		  int numCP, int *cpLen, int **cpNode, int *cpDofs);
  
  // treat CEs of pilot nodes as LMPCs
  void setLMPCs(C_Gcpce *GLMPCs);
  
  friend class FSCoreSolver;
};

class FSSlaveDomainPreprocessor : public FSCoreCPUPreprocessor
{
public:
  FSSlaveDomainPreprocessor(int glNumNodes, int glNumEle, string jobname,
			    int nele, int nnode, FSElement **elem,
			    FSInfo *fsInformation);
  
  ~FSSlaveDomainPreprocessor();
  
  void receiveAll();
  void makeBasicConnect();
  void makeSubProcessors();
  void makeRbms(int nbc, BCond *bcs);
  void makeCommList(FSConnectivity *subToNode, FSConnectivity *nodeToSub,
		    FSConnectivity *subToNodeT, FSConnectivity *subToNodeC); 
};

class FSMasterDomainPreprocessor : public FSCoreCPUPreprocessor
{ 
public:
  FSMasterDomainPreprocessor(int glNumNodes, int glNumEle, string jobname, 
			     int nele, int nnode, FSElement **elem,
			     FSInfo *fsInformation,
			     FSConnectivity *subToE,
			     FSConnectivity *cpuToSub);
  
  ~FSMasterDomainPreprocessor();
  
  FSConnectivity *makeSubComList(int glSubNum, FSConnectivity *subToNode, FSConnectivity *nodeToSub,
				 int &numNeighb, int *&neighbSubs);
  void sendAll();
  void makeBasicConnect();
  void makeSubProcessors();
  void makeRbms(int nbc, BCond *bcs);
  void makeCommList(FSConnectivity *subToNode, FSConnectivity *nodeToSub, 
		    FSConnectivity *subToNodeT, FSConnectivity *subToNodeC,
		    FSConnectivity *subTogNode, FSConnectivity *gnodeToSub);
public:
  FSConnectivity *_subTogNode;
};


#endif
