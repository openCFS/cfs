/*   max.h                          kz372 */
/* 
 * *** copyright(c) 2009 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */

/*  Get maximum number of entities associated with subentity.*/ 
INT
CALLTYP xAnsysSubEntIdMax_ ansPROTO((
     INT  *dim 		/* I: dimension of subentities to inquire */
));

/*  Return max number of supcells in database*/ 
INT
CALLTYP xAnsysSubEntSupCellMax_ ansPROTO((
     INT *dim 			/* I: dimension of subent */
));

/*  Find maximum number of cells of dimension dim.*/ 
INT
CALLTYP xAnsysSubEntMax_ ansPROTO((
     INT  *dim 		/* I: dimension of subentities to inquire */
));

/*  Find max number of subentities associated with an entity.*/ 
INT
CALLTYP xAnsysEntCellMax_ ansPROTO((
     INT *dim 			/* I: dimension of entities to inquire */
));

/*  Find max number of sup entities for an entity of _dim.*/ 
INT
CALLTYP xAnsysEntSupEntMax_ ansPROTO((
     INT *dim 			/* I: dimension of entities to inquire */
));

/*  Return max size of parameter record.*/ 
INT
CALLTYP xAnsysMapParamMax_ ansPROTO((
     INT  *dim 		/* I: dimension of maps to inquire */
));

/*  Find max number of cells sharing a map of _dim*/ 
INT
CALLTYP xAnsysMapCellMax_ ansPROTO((
     INT  *dim 		/* I: dimension of maps to inquire */
));
