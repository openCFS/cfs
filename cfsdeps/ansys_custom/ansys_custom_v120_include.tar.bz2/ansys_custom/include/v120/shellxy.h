/*HFILE shellxy.h	MENU                    	   gps,system
------------------------------------------------------------------------
------- Notice - This file contains ANSYS Confidential information --------
------------------------------------------------------------------------
*/
/* 
 * *** copyright(c) 2009 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */

/*------------------------------ Description ---------------------------
\Author:	Greg Sharpe
\Title:		C-file shellxy
\Desc:		Macro definitions for screen position of UI windows
\History:	94/03/28 - gps: Initial creation

\Function(s) 
 -Primary:	Macro definitions for screen position of UI windows
 -Secondary:	none
 -External:	none
 -Internal:	none
 -Static:	none
----------------------------------------------------------------------*/
/*----------------------- Static Macro Definitions -------------------*/
#ifndef SHELLXY_H
#define SHELLXY_H

#define NUMBER_OF_SHELLS 10
#define DIALOG_SHELL 1
#define LISTER_SHELL 2
#define CUSTOM_SHELL 3
#define RCON_SHELL   4
#endif

/*---------------------------- End Of Module -------------------------*/
