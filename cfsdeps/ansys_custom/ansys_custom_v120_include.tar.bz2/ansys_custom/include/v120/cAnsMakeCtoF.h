/* ---------------------------------------------------------------------- */
/* *** copyright(c) 2009 SAS IP, Inc.  All rights reserved. */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  AnsMemCtoF.h */
#if !defined(__ANSMEMCTOF_H__)
#define __ANSMEMCTOF_H__ 1

#include "ansys.h"


/* (1)----------------------------------------------------------------*/
#if defined(LOWERCASENOUNDER_SYS)

/*
 *   The pattern for these platforms is the lowercased version of the name
 */

#define parloc_                   parloc
#define pardel_                   pardel
#define pardimc_                  pardimc
#define parPutArrayc_             parputarrayc

#endif


/* (2)----------------------------------------------------------------*/
#if defined(UPPERCASENOUNDER_SYS)

/*
 *   The pattern for these platforms is the uppercased version of the name
 */

#define parloc_                   PARLOC
#define pardel_                   PARDEL
#define pardimc_                  PARDIMC
#define parPutArrayc_             PARPUTARRAYC

#endif


/* (3)----------------------------------------------------------------*/
#if defined(LOWERCASEUNDER_SYS)

/*
 *   The pattern for these platforms is the lowercased version of the name 
 *   followed by an underscore
 */

#define parloc_              parloc_
#define pardel_              pardel_
#define pardimc_             pardimc_
#define parPutArrayc_        parputarrayc_

#endif


/* (4)----------------------------------------------------------------*/

/*
 *   This section is for definition of prototypes.  Each prototype 
 *   should be ANSI compliant and specify the types of each parameter 
 *   as well as the return type.
 */

INT FUNCTION parloc_(FCHAR(cname) FCHARL(cname_len));
SUBROUTINE pardel_(INT *ntab);
SUBROUTINE pardimc_(FCHAR(cName), FCHAR(labl4), INT *nxyz, FCHAR(cLabl1), FCHAR(cLabl2), FCHAR(cLabl3) FCHARL(cName_len) FCHARL(labl4_len) FCHARL(cLabl1_len) FCHARL(cLabl2_len) FCHARL(cLabl3_len));
INT FUNCTION parPutArrayc_(INT *p, double *arrload, INT *narrload, INT *nxyz);


#endif

