/* version_adomesh.h CADOE doeinc */
/*
 *  version_adomesh.h
 *
 *  |Version: $Id: version_adomesh.h,v 1.5.4.1 2009/04/13 14:10:00 jtm Exp $
 *   
 */

#ifndef __VERSIONADOMESHH__
#define __VERSIONADOMESHH__ 1 /* protection contre lecture multiple */



/* Include ADOMESH definissant le numero de version ADOMESH et I-DEAS associe */


#define NOM_ADOGEOM		"ADOGEOM"
#define VERSION_ADOGEOM		"6.2"  /* 6.1->6.2 pour l integration des liens */

#define NOM_ADOMESH		"ADOMESH"
#define VERSION_ADOMESH		"6.2"   /* 6.1->6.2 pour l integration des liens */
#define INT_VERSION_ADOMESH 	7
#define INT_VERSION_POLYNODES  6   /* version pour l'objet polynome des noeuds */
#define INT_VERSION_SECTIONS 6   /* version pour l'objet section des boites englobantes */
#define INT_VERSION_REPERES 6
#define INT_VERSION_PROPELE 6		/* version differente en 12.0 pour les proprietes des elements car on a rajoute les IDs des epaisseurs */

#ifndef VERSION_IDEAS
#define VERSION_IDEAS   "9"
#endif


#endif /* __VERSIONADOMESHH__ */



