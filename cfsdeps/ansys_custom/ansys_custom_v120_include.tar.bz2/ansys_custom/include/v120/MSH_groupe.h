/**
 *  MSH_groupe.h -- constantes attachees aux objets groupe
 * $Id: MSH_groupe.h,v 1.2.6.1 2009/04/13 14:09:59 jtm Exp $
 **/


#ifndef __MSH_GROUPEH__
#define __MSH_GROUPEH__ 1

/* 
 * Gestion des groupes 
 */ 
/* Nature du groupe : Ces constantes doivent etre identiques a oa_FEM_NODES et oa_FEM FELEM */
#define NOEUDS 7
#define ELEMENTS       8   /* gpe de shell  */
#define FACES 9
#define EDGES 10
#define VERTEX 11
#define ELEMENTS_VOL  12  
#define FACET         13    /* gpe de fa7 */
#define GRP_INCONNU       14

/* Nature des valeurs a extraire */
#define INDICE 1
#define NUMERO 2

/* Fin de groupe */
#define PLUSDELEMENT -1


typedef enum 
{
	GRP_TYPE_INCONNU   = 14,
	GRP_TYPE_FACETTE   = 13,
	GRP_TYPE_COQUE     = 8,
	GRP_TYPE_VOLUMIQUE = 12,
	GRP_TYPE_ELE1D     = 15,
	GRP_TYPE_NOEUD     = 7
} E_GRP_TYPE;




 /* __cplusplus */



/*#ifdef __cplusplus
extern "C" {
#endif*/

  extern T_statut GPE_inserer_element( T_Groupe*, int );
  extern T_statut GPE_initialiser_iterateur( T_Groupe* );
  extern int GPE_suivant( T_Groupe*, int );
  extern T_statut GPE_verifier( T_Groupe* );
  extern void GPE_afficher( T_Groupe* );
  extern void GPE_afficher_groupe( T_Groupe * );
  extern T_statut GPE_boutput( FILE*, T_Groupe* );
  extern T_Groupe *GPE_binput( FILE*, T_statut* );
  extern T_statut GPE_foutput( FILE*, T_Groupe* );
  extern int GPE_taille( T_Groupe* );
  extern void GPE_free( T_Groupe* );
  extern int GPE_rechercher_groupe( char*, T_Modele *, int * );
  extern int GPE_nombre_elements(T_Groupe *, T_Mesh *, T_statut * );
  extern T_booleen GPE_element_existe( T_Groupe*, int );
  extern T_statut GPE_supprimer_element( T_Groupe*, int );

  extern T_Groupe *GPE_allouer ( T_Mesh*, E_GRP_stock, int, int, T_statut * );
  extern int  GPE_initialiser_mesh ( T_Groupe *, T_Mesh *, int, int);
  extern void GPE_liberer_groupe ( T_Groupe **groupe );
  extern T_Groupe *GPE_allouer_mesh ( T_Mesh*, int, int, int, T_statut * );

/*#ifdef __cplusplus
}
#endif*/

#endif   /* __groupeh__ */



