/*
 *    author/date: yu-hua ting/01-28-94
 *
 *    primary function:
 *
 *
 *      Header for the Interface to Ansys/Shapes Interface "attributes" routines
 *
 *    secondary function:
 *
 *        none
 *
 *    routines included:
 *
 *
 *    history
 *
 *        none
 *
 *    comments:
 *
 *        none
 *
 *    notice- these routines contain sasi confidential information ***
 *
 */
/* 
 * *** copyright(c) 2009 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */



/*
 *    set the geometry attribute handlers
 */
      extern VOID xGeomAttrHandlersSet_xax ansPROTO((
             xTAG   tag,          /* I    heap specifier                               */
             INT *iretp));        /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                                 */

/*
 *    Set a geometry attribute for a basic geom (i.e., a cell)
 */
      extern VOID xGeomAttrCellSet_xax ansPROTO((
             xGEOM_ID gm_id,         /* I    a geom id                     */
             xaxGEOM_ATTR geom_attr, /* I    a geometry attribute          */
             xTAG tag,               /* I    heap specifier                */
             INT *iretp));           /*   O  pointer to an error code
                                      *      == 0 - no error
                                      *      != 0 - error                  */
      

/*
 *    Get the pointer to the geometry attribute for a basic geom (i.e., a cell)
 */
      extern INT xGeomAttrCellGetPtr_xax ansPROTO((
             xGEOM_ID gm_id,                            /* I    a geom id                           */
             xaxGEOM_ATTR *geom_attr,                   /*   O  a geometry attribute                */
             xaxGEOM_ATTR_LIST_PTR *geom_attr_list_ptr, /*   O  pointer to a xaxGEOM_ATTR_LIST_NODE */
             INT *geom_attr_mem_size,                   /*   O  memory size in integers needed to  
                                                         *      store a geometry attribute          */
             INT *iretp));                              /*   O  pointer to an error code
                                                         *      == 0 - no error
                                                         *      != 0 - error                        */


/*
 *    Get the geometry attribute for a basic geom (i.e., a cell)
 */
      INT xGeomAttrCellGet_xax ansPROTO((
             xaxGEOM_ATTR_LIST_PTR geom_attr_list_ptr,  /* I    pointer to a xaxGEOM_ATTR_LIST_NODE */
             INT geom_attr_array[],                     /*   O  array containing the geometry
                                                         *      information                         */
             INT *geom_attr_array_size,                 /*   O  actual size of geom_attr_array used */
             INT iopt,                                  /* I    option                              */
             INT *iretp));                              /*   O  pointer to an error code
                                                         *      == 0 - no error
                                                         *      != 0 - error                        */


/*
 *    Delete a geometry attribute list
 */
      extern VOID xGeomAttrListDelete_xax ansPROTO((
             xaxGEOM_ATTR_LIST_PTR geom_attr_list_ptr, /* I    pointer to a xaxGEOM_ATTR_LIST_NODE */
             INT *iretp));                             /*   O  pointer to an error code
                                                        *      == 0 - no error
                                                        *      != 0 - error                        */


/*
 *    geometry attribute handler for cell create operation
 */
      extern VOID xGeomAttrCellNewHndlr_xax ansPROTO((
             xCELL new_cell));            /* I    new cell                   */


/*
 *    geometry attribute handler for cell copy operation
 */
      extern VOID xGeomAttrCellCopyHndlr_xax ansPROTO((
             xCELL source_cell,              /* I    source cell                   */
             xATTR source_attr,              /* I    attribute from source cell    */
             xCELL target_cell,              /* I    target cell                   */
             xCP_ENV cpenv));                /* I    environment for copy          */ 

/*
 *    geometry attribute handler for cell delete operation
 */
      extern VOID xGeomAttrCellDeleteHndlr_xax ansPROTO((
             xCELL cell,     /* I    cell to be deleted                   */
             xATTR attr));   /* I    attribute for the cell to be deleted */

      


/*
 *    geometry attribute handler for cell dissociate operation
 */
      extern VOID xGeomAttrCellDissocHndlr_xax ansPROTO((
             xCELL cell,     /* I    cell to be dissociated                   */
             xATTR attr));    /* I    attribute for the cell to be dissociated */
      


      


/*
 *    geometry attribute handler for cell split operation
 */
      extern VOID xGeomAttrCellSplitHndlr_xax ansPROTO((
             xCELL source_cell,   /* I    cell that is split               */            
             xATTR source_attr,   /* I    attribute of source_cell         */
             xCELL target_cell)); /* I    new cell resulting from split    */   


/*
 *    geometry attribute handler for cell imbed operation
 */
      extern VOID xGeomAttrCellImbedHndlr_xax ansPROTO((
             xCELL cell1,             
             xATTR attr1,
             xCELL cell2, 
             xATTR attr2,
             xCELL target_cell));
      



/*
 *    geometry attribute handler for cell merge operation
 */
      extern VOID xGeomAttrCellMergeHndlr_xax ansPROTO((
             xCELL source_cell1,             
             xATTR source_attr1,
             xCELL source_cell2, 
             xATTR source_attr2,
             xCELL boundary_cell));



/*
 *    geometry attribute handler for frame create operation
 */
      extern VOID xGeomAttrFrameNewHndlr_xax ansPROTO((
             xFRAME new_frame));              /* I    new frame                   */

/*
 *    geometry attribute handler for frame copy operation
 */
      extern VOID xGeomAttrFrameCopyHndlr_xax ansPROTO((
             xFRAME source_frame,            /* I    source frame                   */
             xATTR source_attr,              /* I    attribute from source frame    */
             xFRAME target_frame,            /* I    target frame                   */
             xCP_ENV cpenv));                /* I    environment for copy          */ 


/*
 *    geometry attribute handler for frame delete operation
 */
      extern VOID xGeomAttrFrameDeleteHndlr_xax ansPROTO((
             xFRAME frame,     /* I    frame to be deleted                   */
             xATTR attr));     /* I    attribute for the frame to be deleted */
      


/*
 *    geometry attribute handler for frame dissociate operation
 */
      extern VOID xGeomAttrFrameDissocHndlr_xax ansPROTO((
             xFRAME frame,     /* I    frame to be dissociated                   */
             xATTR attr));     /* I    attribute for the frame to be dissociated */
      


      
