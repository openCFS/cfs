#ifndef _ANSYS_DOMAIN_H_
#define _ANSYS_DOMAIN_H_

#include "cadoesys.h" 
#include "computer.h" 

#include "C_VecPi.h" 
#include "CoreDomain.h" 
#include "CoreCPUDomain.h"
#include "ThreadManager.h" 
 
#include "FullMatrix.h" 
#include "DistVector.h" 
#include "DistInfo.h" 
#include "FSolver.h" 
#include "FSInfo.h" 

#include "Communicator.h" 
#include "BlockAlloc.h" 
#include "FSConnectivity.h" 
#include "AnsysElement.h" 
#include "dds_globals.h"
#include "C_SubAnsysDomain.h"

class AnsysDomain;
class C_TimeManager;

extern int G_dofflags;
extern AnsysDomain *G_AnsysDomain;

class AnsysBC
{
public:
  AnsysBC();
  ~AnsysBC();
  
  void fill(int nbddl, int dofPerNode, int nDBC, BCond *dBC);
  
  int *getBcsDof()	{ return _bcsDof;   }
  double *getValue()	{ return _value; }
  void Print();

protected:
  int _nbddl;
  int *_bcsDof;
  double *_value;
};

class AnsysDomain : public C_SubAnsysDomain, public C_AnsysSolver<C_MatSp<double> >
{ 
public: 
  AnsysDomain(); 
  virtual ~AnsysDomain(); 
  
  string getName() {return "     Feti      ";} 
  void PutStats(bool allowToSum = true);
  void PrintStats(int iter,
		  double selfCpuTime, double totalCpuTime, double elapsedTime,
		  double selfMemory, double totalMemory);
  
  // IO
  void Write();
  void Read();
  
  // just defined Solve to be not unresolved
  void Solve(C_Vec<double> &B, C_Vec<double> &X, int nbX, bool inverseK = false, bool isRigidBodies = false) {}
  
  // initializations
  void initInput(INT *ivect, INT len1, DOUBLE *dvect, INT len2, INT *curdof, INT numdof, char *jobName);
  void endInput();
  
  // initialization domain decomposition
  virtual void setDomains(INT *Domain, INT nDomain, INT *SuperDomainElem, INT nSuperDomain) = 0;
  void setProperty(INT *DomainProperty, INT nDomain);
  
  FSConnectivity *removeContactElements(FSConnectivity *subToE);
  
  // assembly 
  void BeginAssm(int kfstps);
  void addStiffness(int indElem, double *zs, double *zsc, int *ls, int nr, bool unsym);
  
  virtual FSCoreCPUPreprocessor *getCoreCpuDomain() = 0;
  
  // solve 
  void InitSolve();
  void solve(double *disp, int *lenu, int *nbIter, int *status, double *residual,
	     double *selfCpuTime, double *totalCpuTime, double *elapsedTime,
	     double *selfMemory, double *totalMemory); 
  
  // send/recv settings
  void dispatchGlobal(); 
  void receiveGlobal(); 
  
  // make the core math-domains
  virtual void makeSubCores();
  
  // memory infos
  double getMemSize();
  double getMaxMemSize();
  
public:
  bool _isInitialized;
  
  AnsysBC *_ansysPres;
  C_VecPi<double> _rhs;
  
  int _numThreads;
  
  DofSet _probDofs; 
  int _uLength; 
  int _sumNbInternalDofs;
  int _sumNbDualDofs;
  bool _unsym;
  
  int *_domProp; 
  
  // Progress file and timing additions 
  char _longJobname[32];
  char *_jobname; 
  
  BlockAlloc _ba; 

  FSInfo *_fsInfo;
  FSCoreCPUPreprocessor *_fsCorePre;
  FSCoreSolver *_solver;
}; 

class AnsysDomainMaster : public AnsysDomain
{
public:
  AnsysDomainMaster() {_cpuToSub = NULL;}
  ~AnsysDomainMaster() {delete _cpuToSub; delete _allSubToE;}

  FSCoreCPUPreprocessor *getCoreCpuDomain();
  void setDomains(INT *Domain, INT nDomain, INT *SuperDomainElem, INT nSuperDomain);
  
protected:
  FSConnectivity *_cpuToSub;
  FSConnectivity *_allSubToE;
};

class AnsysDomainSlave : public AnsysDomain
{
public:
  AnsysDomainSlave() {}
  ~AnsysDomainSlave() {}

  FSCoreCPUPreprocessor *getCoreCpuDomain();
  void setDomains(INT *Domain, INT nDomain, INT *SuperDomainElem, INT nSuperDomain);
};


#endif
