
/*
 *    author/date: yu-hua ting/07-11-94
 *
 *    primary function:
 *
 *      Header for the "symbol" definitions in the Ansys/Shapes Interface
 *
 *    secondary function:
 *
 *        none
 *
 *    routines included:
 *
 *
 *    history
 *
 *        none
 *
 *    comments:
 *
 *        none
 *
 *    notice- these routines contain sasi confidential information ***
 *
 */
/* 
 * *** copyright(c) 2009 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */

 
#if !defined(NO_ERROR_REQUEST)
#define NO_ERROR_REQUEST          0
#endif
 
 
#if !defined(XOX_ERROR_REQUEST)
#define XOX_ERROR_REQUEST         1
#endif
 
 
#if !defined(ANSYS_ERROR_REQUEST)
#define ANSYS_ERROR_REQUEST       2
#endif
 
 
#if !defined(XAX_ERROR_REQUEST)
#define XAX_ERROR_REQUEST         3
#endif




#if !defined(ERROR_AND_WARNING_CODES)
#define ERROR_AND_WARNING_CODES       0
#endif
 
 
#if !defined(ERROR_CODES)
#define ERROR_CODES                   1
#endif
 
 
#if !defined(WARNING_CODES)
#define WARNING_CODES                 2
#endif
 

 
#if !defined(STACK_BOTTOM_ELEMENT)
#define STACK_BOTTOM_ELEMENT          0
#endif

#if !defined(STACK_TOP_ELEMENT) 
#define STACK_TOP_ELEMENT             1
#endif
 

 
 
#define USE_xCurveSplitModeSet   1



/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

#if !defined(NIL)
#define NIL 0
#endif


/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/


#if !defined(XAX_NULL_PTR) 
#define XAX_NULL_PTR NULL
#endif
 
#if !defined(XAX_NULL)
#define XAX_NULL NULL
#endif
 
#if !defined(XOX_NULL_PTR)
#define XOX_NULL_PTR NULL
#endif
 
#if !defined(XOX_NULL)
#define XOX_NULL NULL
#endif


/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/


#if !defined(NULL)
#define NULL        0
#endif

#if !defined(XOX_NON_NULL)
#define XOX_NON_NULL    1
#endif

  
#if !defined(XOX_NIL) 
#define XOX_NIL XOX_NULL
#endif 


#if !defined(XOX_NON_NIL)
#define XOX_NON_NIL    1
#endif


/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

#define XAX_GRAPHICS 1


#ifdef XAX_GRAPHICS
#include "xoxgraph.h"
#endif


/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/


#if !defined(SHELL_TREE)
#define SHELL_TREE                   1
#endif

#if !defined(SHELL_LIST)
#define SHELL_LIST                   0
#endif

#if !defined(LOOP_TREE)
#define LOOP_TREE                    1
#endif

#if !defined(LOOP_LIST)
#define LOOP_LIST                    0
#endif

#if !defined(FROM_LIST)
#define FROM_LIST                    0
#endif

#if !defined(TO_LIST)
#define TO_LIST                      1
#endif


#if !defined(DESTROY_INPUT_GEOMS)
#define DESTROY_INPUT_GEOMS          1
#endif

#if !defined(DO_NOT_DESTROY_INPUT_GEOMS)
#define DO_NOT_DESTROY_INPUT_GEOMS   0
#endif


/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

 
#ifdef USE_xCurveSplitModeSet 
  
#define SHAPES_SPLIT_LOOPS_OF_1_OR_2_LINES        xcCURVE_SPLIT_SINGLE | xcCURVE_SPLIT_DOUBLE

#else

#define xCurveSplitModeSet                        xSetUniqueEndPoints
#define xcCURVE_SPLIT_NONE                        XOX_Off
#define xcCURVE_SPLIT_SINGLE                      1  
#define xcCURVE_SPLIT_DOUBLE                      2
#define SHAPES_SPLIT_LOOPS_OF_1_OR_2_LINES        XOX_On
 
#endif


/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

#if !defined(SHAPES_DO_NOT_SPLIT_LOOPS)
#define SHAPES_DO_NOT_SPLIT_LOOPS                 xcCURVE_SPLIT_NONE
#endif
 
#if !defined(SHAPES_SPLIT_LOOPS_OF_1_LINE)
#define SHAPES_SPLIT_LOOPS_OF_1_LINE              xcCURVE_SPLIT_SINGLE
#endif

 
#if !defined(SHAPES_SPLIT_LOOPS_OF_2_LINES)
#define SHAPES_SPLIT_LOOPS_OF_2_LINES             xcCURVE_SPLIT_DOUBLE
#endif 

#if !defined(ANSYS_KEYPOINT)
#define ANSYS_KEYPOINT        1
#endif

#if !defined(ANSYS_LINE)
#define ANSYS_LINE            2
#endif

#if !defined(ANSYS_AREA)
#define ANSYS_AREA            3
#endif

#if !defined(ANSYS_VOLUME)
#define ANSYS_VOLUME          4
#endif

#if !defined(ANSYS_POINT)
#define ANSYS_POINT           5
#endif

#if !defined(ANSYS_SUBLINE)
#define ANSYS_SUBLINE         6
#endif

#if !defined(ANSYS_LOOP)
#define ANSYS_LOOP            7
#endif

#if !defined(ANSYS_SUBAREA)
#define ANSYS_SUBAREA         8
#endif

#if !defined(ANSYS_SHELL)
#define ANSYS_SHELL           9
#endif

#if !defined(ANSYS_SUBVOLUME)
#define ANSYS_SUBVOLUME       10
#endif



#if !defined(SHAPES_KEYPOINT)
#define SHAPES_KEYPOINT        11
#endif

#if !defined(SHAPES_LINE)
#define SHAPES_LINE            12
#endif

#if !defined(SHAPES_AREA)
#define SHAPES_AREA            13
#endif

#if !defined(SHAPES_VOLUME)
#define SHAPES_VOLUME          14
#endif

#if !defined(SHAPES_POINT)
#define SHAPES_POINT           15
#endif

#if !defined(SHAPES_SUBLINE)
#define SHAPES_SUBLINE         16
#endif

#if !defined(SHAPES_LOOP)
#define SHAPES_LOOP            17
#endif

#if !defined(SHAPES_SUBAREA)
#define SHAPES_SUBAREA         18
#endif

#if !defined(SHAPES_SHELL)
#define SHAPES_SHELL           19
#endif

#if !defined(SHAPES_SUBVOLUME)
#define SHAPES_SUBVOLUME       20
#endif

 
#if !defined(ANSYS_LOOP_TREE)
#define ANSYS_LOOP_TREE        21
#endif
 
 
#if !defined(ANSYS_SHELL_TREE)
#define ANSYS_SHELL_TREE       22
#endif
 
 
#if !defined(SHAPES_LOOP_TREE)
#define SHAPES_LOOP_TREE       23
#endif
 
 
#if !defined(SHAPES_SHELL_TREE)
#define SHAPES_SHELL_TREE      24
#endif
 
#if !defined(SHAPES_WP_XY)
#define SHAPES_WP_XY           25
#endif
 

#if !defined(FROM_FRAME_TREE)
#define FROM_FRAME_TREE         0
#endif

#if !defined(TO_FRAME_TREE)
#define TO_FRAME_TREE           1
#endif

#if !defined(FROM_SHAPES_ORIENTATIONS)
#define FROM_SHAPES_ORIENTATIONS 0
#endif

#if !defined(TO_SHAPES_ORIENTATIONS)
#define TO_SHAPES_ORIENTATIONS   1
#endif


#if !defined(FROM_ANSYS_SUBENTITIES)
#define FROM_ANSYS_SUBENTITIES   0
#endif

#if !defined(FROM_ANSYS_ENTITIES)
#define FROM_ANSYS_ENTITIES      1
#endif

#if !defined(TO_ANSYS_SUBENTITIES)
#define TO_ANSYS_SUBENTITIES     2
#endif


/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

#define EQUAL_TO      0
#define LESS_THAN     1
#define GREATER_THAN  2

#define NONE        0
#define LEFT_CHILD  1
#define RIGHT_CHILD 2
      
#define LENGTH_INFO           2

#define ENTITY_EXIST     -1


/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/


#define NUMBER_OF_SUBVOLUMES_INFO   2
#define NUMBER_OF_SHELLS_INFO       1
#define NUMBER_OF_SUBAREAS_INFO     2 
#define NUMBER_OF_LOOPS_INFO        1 
#define NUMBER_OF_SUBLINES_INFO     2
#define ATTACHED_SURFACE_INFO      -1
#define NEXT_VOLUME_NUMBER_INFO    16
#define NEXT_AREA_NUMBER_INFO      16
#define NEXT_LINE_NUMBER_INFO      16

#define NEXT_SUBVOLUME_NUMBER_INFO 16
#define NEXT_SUBAREA_NUMBER_INFO   16
#define NEXT_SUBLINE_NUMBER_INFO   16
#define NEXT_POINT_NUMBER_INFO   16

#define NEXT_SHELL_NUMBER_INFO     16
#define NEXT_LOOP_NUMBER_INFO      16

#define GLOBAL_CARTESIAN_COORDINATE_SYSTEM 0

#define ORIENTATION_INFO_IS_USED     1
#define ORIENTATION_INFO_IS_NOT_USED 0
#define INTERSECT                    1
#define DO_NOT_INTERSECT             0

#define TOPOLOGY_ENTITY              0
#define GEOMETRY_ENTITY              1

#define OLD_GEOMETRY                 0
#define NEW_GEOMETRY                 111111

#define TRANSLATION_THEN_SCALING     1
#define SCALING_THEN_TRANSLATION     2



/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/



#if !defined(XOX_DATA_LENGTH)
#define XOX_DATA_LENGTH  400
#endif
 

/*
 * XHEAP_ZERO_BYTE is used in xheap_malloc for initializing allocated memory
 * to zeros
 */


#if !defined(XHEAP_ZERO_BYTE)
#define XHEAP_ZERO_BYTE '\0'
#endif


/*
 * XHEAP_WRITTEN_INTEGER is used in xheap_malloc for initializing allocated memory
 * to the given integer
 */


#if !defined(XHEAP_WRITTEN_INTEGER)
#define XHEAP_WRITTEN_INTEGER 77777
#endif



/*
 * define the dynamic memory routines used in Ansys/Shapes Interface codes
 * by using the heap memory routines
 */


/*
 * #define xax_malloc(num_bytes) xheap_malloc(num_bytes,0,1) 
 * #define xax_free(virtual_memory_address) xheap_free(virtual_memory_address,1) 
 */
 
#if !defined(TRUE)
#define TRUE        1
#endif

#if !defined(FALSE)
#define FALSE       0
#endif


#if !defined(ON)
#define ON        1
#endif

#if !defined(OFF)
#define OFF       0
#endif




#define XHEAP_NODE_SIZE              5
#define PREVIOUS_NODE                1
#define NEXT_NODE                    2
#define MOFFSET                      3
#define MSIZE                        4
#define MAPPL_ID                     0

#define HEAD_SEARCH                  0
#define TAIL_SEARCH                  1
#define HEAD_SEARCH_AND_COMBINE      2
#define TAIL_SEARCH_AND_COMBINE      3

#define POSITIVE_DIRECTION           1
#define NEGATIVE_DIRECTION          -1


#define PLANE                        1

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/


#define MAX_NUM_OF_HEAPS                    10
#define HEAP_NOT_USED                        0
#define HEAP_USED                            1

#define ANSYS_SHAPES_HEAP_TAG               XOX_NULL


#define FORCE_TO                             1
#define NOT_FORCE_TO                         0

/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/


#define DIVIDE_ALONG_U_KNOT_LOCATION                        1
#define DIVIDE_ALONG_V_KNOT_LOCATION                        2
#define DIVIDE_ALONG_U_AND_V_KNOT_LOCATION                  3

#define SHAPES_BASIC_GEOM                                   1
#define SHAPES_COMPOSITE_GEOM                               2

/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

#define MAX_NUM_OF_GEOMETRY_IDENTIFIERS                     2
#define MAX_NUM_OF_GEOM_ATTR_LISTS                          2

#define UNKNOWN_GEOMETRY_TYPE                              -1
#define UNKNOWN_SOURCE                                     -2
#define UNKNOWN_OPERATION_TYPE                             -3

#define ANSYS_SOURCE                                        1
#define SHAPES_SOURCE                                       2
#define FILE_SOURCE                                         3
  
#define IDENTITY_COPY_OF_ANSYS_POINT                        -89999990
#define IDENTITY_COPY_OF_SHAPES_POINT                       -88888880
#define IDENTITY_COPY_OF_POINT_FROM_FILE                    -87777770

#define IDENTITY_COPY_OF_ANSYS_SUBLINE                      -89999991
#define IDENTITY_COPY_OF_SHAPES_SUBLINE                     -88888881
#define IDENTITY_COPY_OF_SUBLINE_FROM_FILE                  -87777771

#define IDENTITY_COPY_OF_ANSYS_SUBAREA                      -89999992
#define IDENTITY_COPY_OF_SHAPES_SUBAREA                     -88888882
#define IDENTITY_COPY_OF_SUBAREA_FROM_FILE                  -87777772
#define IDENTITY_COPY_OF_ANSYS_WP_XY                        -86666662
 
#define IDENTITY_COPY_OF_ANSYS_SUBVOLUME                    -89999993
#define IDENTITY_COPY_OF_SHAPES_SUBVOLUME                   -88888883
#define IDENTITY_COPY_OF_SUBVOLUME_FROM_FILE                -87777773

#define IDENTITY_COPY_OPERATION_MAX_NUMBER                  -80000000

#define IDENTITY_LINK_OF_ANSYS_POINT                        -79999990
#define IDENTITY_LINK_OF_SHAPES_POINT                       -78888880
#define IDENTITY_LINK_OF_POINT_FROM_FILE                    -77777770
 
#define IDENTITY_LINK_OF_ANSYS_SUBLINE                      -79999991
#define IDENTITY_LINK_OF_SHAPES_SUBLINE                     -78888881
#define IDENTITY_LINK_OF_SUBLINE_FROM_FILE                  -77777771
 
#define IDENTITY_LINK_OF_ANSYS_SUBAREA                      -79999992
#define IDENTITY_LINK_OF_SHAPES_SUBAREA                     -78888882
#define IDENTITY_LINK_OF_SUBAREA_FROM_FILE                  -77777772
 
#define IDENTITY_LINK_OF_ANSYS_SUBVOLUME                    -79999993
#define IDENTITY_LINK_OF_SHAPES_SUBVOLUME                   -78888883
#define IDENTITY_LINK_OF_SUBVOLUME_FROM_FILE                -77777773

#define IDENTITY_LINK_OPERATION_MAX_NUMBER                  -70000000

#define TRIMMING_POINT                                      -69999990
#define TRIMMING_SUBLINE                                    -69999991
#define TRIMMING_SUBAREA                                    -69999992
#define TRIMMING_SUBVOLUME                                  -69999993

#define TRIMMING_OPERATION_MAX_NUMBER                       -60000000

#define INTERSECTION_POINT_OF_POINT_AND_POINT               -59999000
#define INTERSECTION_POINT_OF_POINT_AND_SUBLINE             -59999010
#define INTERSECTION_POINT_OF_POINT_AND_SUBAREA             -59999020
#define INTERSECTION_POINT_OF_POINT_AND_SUBVOLUME           -59999030
#define INTERSECTION_POINT_OF_SUBLINE_AND_SUBLINE           -59999110
#define INTERSECTION_POINT_OF_SUBLINE_AND_SUBAREA           -59999120
#define INTERSECTION_POINT_OF_SUBLINE_AND_SUBVOLUME         -59999130
#define INTERSECTION_POINT_OF_SUBAREA_AND_SUBAREA           -59999220
#define INTERSECTION_POINT_OF_SUBAREA_AND_SUBVOLUME         -59999230
#define INTERSECTION_POINT_OF_SUBVOLUME_AND_SUBVOLUME       -59999330

#define INTERSECTION_SUBLINE_OF_SUBLINE_AND_SUBLINE         -58888111
#define INTERSECTION_SUBLINE_OF_SUBLINE_AND_SUBAREA         -58888121
#define INTERSECTION_SUBLINE_OF_SUBLINE_AND_SUBVOLUME       -58888131
#define INTERSECTION_SUBLINE_OF_SUBAREA_AND_SUBAREA         -58888221
#define INTERSECTION_SUBLINE_OF_SUBAREA_AND_SUBVOLUME       -58888231
#define INTERSECTION_SUBLINE_OF_SUBVOLUME_AND_SUBVOLUME     -58888331

#define INTERSECTION_SUBAREA_OF_SUBAREA_AND_SUBAREA         -57777222
#define INTERSECTION_SUBAREA_OF_SUBAREA_AND_SUBVOLUME       -57777232
#define INTERSECTION_SUBAREA_OF_SUBVOLUME_AND_SUBVOLUME     -57777332

#define INTERSECTION_SUBVOLUME_OF_SUBVOLUME_AND_SUBVOLUME   -56666333
 

#define INTERSECTION_OPERATION_MAX_NUMBER                   -50000000

#define MERGING_POINT_WITH_POINT                            -49999990
#define MERGING_SUBLINE_WITH_SUBLINE                        -49999991
#define MERGING_SUBAREA_WITH_SUBAREA                        -49999992
#define MERGING_SUBVOLUME_WITH_SUBVOLUME                    -49999993

#define BOLCMI_COMMON                                        1
#define HEAPCM_COMMON                                        2
#define BERRCM_COMMON                                        3 

/*
 * Definitions of Macro functions
 */

#define Collect_Global_Error_mac \
      xGlobalErrorCollect_xax(iretp);\
/*
      xGlobalErrorWarningClear_xax(ERROR_AND_WARNING_CODES);
 */
/*
#define Collect_Global_Error_And_Close_Heap_Memory_etc_mac \
      if (boolean_heap_is_on == TRUE)\
         {\
          xCloseHeap_xax(iretp);\
          if (*iretp != 0)\
             {\
              error_code = ERROR_IN_xCloseHeap_xax_xoxcls_FILE_xbexport;\
              xErrorHandler_xax(iretp,ERROR_EXIST ,error_code,NO_ERROR_REQUEST);\
             }\
         }\
      bolcmi_.xox_open_flag = 0;\
      xGlobalErrorCollect_xax(iretp);\
      xGlobalErrorWarningClear_xax(ERROR_AND_WARNING_CODES);\
      if (signal_handler_is_on != 0)\
         {\
          xSignalHandlerReSet_xax();\
         }\
 */
