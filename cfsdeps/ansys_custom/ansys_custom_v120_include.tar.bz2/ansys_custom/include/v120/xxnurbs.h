

/*
 *    author/date: yu-hua ting/10-29-93
 *
 *    primary function:
 *
 *      Header for the Interface to SHAPES "nurbs" routines
 *
 *    secondary function:
 *
 *        none
 *
 *    routines included:
 *
 *
 *    history
 *
 *        none
 *
 *    comments:
 *
 *        1). direct interface with Shapes/xox 2.0 will be added later
 *
 *    Notice - This file contains ANSYS Confidential information ***
 *
 */

/* 
 * *** copyright(c) 2009 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */


/*
 *    get the "ncur" for a 1-geom
 */
      extern VOID xAnsysNcurFromGeom_xox ansPROTO((
             xGEOM_ID gm_id,      /* I    geom number of a geom                      */ 
             xINT ncur[],         /*   O                                             */
             INT *iretp));        /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                               */




/*
 *    get the "cur" for a 1-geom
 */
      extern VOID xAnsysCurFromGeom_xox ansPROTO((
             xGEOM_ID gm_id,      /* I    geom number of a geom                      */ 
             DOUBLE cur[],        /*   O                                             */
             INT *iretp));        /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                               */


/*
 *    get the "nsur" for a 2-geom
 */
      extern VOID xAnsysNsurFromGeom_xox ansPROTO((
             xGEOM_ID gm_id,      /* I    geom number of a geom                      */ 
             xINT nsur[],         /*   O                                             */
             INT *iretp));        /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                               */




/*
 *    get the "sur" for a 2-geom
 */
      extern VOID xAnsysSurFromGeom_xox ansPROTO((
             xGEOM_ID gm_id,      /* I    geom number of a geom                      */ 
             DOUBLE sur[],        /*   O                                             */
             INT *iretp));        /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                               */
       

/*   
 *    create a 3-D nurbs curve in SHAPES (for ANSYS)
 */
      extern xGEOM_ID xNurbGeomCurve_xox ansPROTO((
             INT sln,
	     DOUBLE cur[],        /* I    cur of a nurbs curve                    */
             INT ncur[],          /* I    ncur of the nurbs curve                 */
             INT *iretp));        /*   O  pointer to the error code  
                                   *      == 0 - no error
                                   *      != 0 - error                            */

/*   
 *    create a 3-D nurbs surface in SHAPES (for ANSYS)
 */
      extern xGEOM_ID xNurbGeomSurface_xox ansPROTO((
             INT san,
	     DOUBLE sur[],        /* I    sur of a nurbs surface                  */
             INT nsur[],          /* I    nsur of the nurbs surface               */
             INT *iretp));        /*   O  pointer to the error code  
                                   *      == 0 - no error
                                   *      != 0 - error                            */
