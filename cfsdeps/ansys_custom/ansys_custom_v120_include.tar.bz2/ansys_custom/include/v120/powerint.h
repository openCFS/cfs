/* powerint.h CADOE  */
/*
 *   
 * HISTORY
 *   
 *   06/21/00 16:30 <       Brian Jantzen> Rel:ms8m1    SCCA:74307  Delta:81.2
*/
#ifndef __MSH_powerinth__
#define __MSH_powerinth__ 1



/*#ifdef __cplusplus
extern "C" {
#endif*/

extern double MSH_powerint( double, int);

/*#ifdef __cplusplus
}
#endif*/

#endif
