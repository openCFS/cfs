#ifndef _MULTI_SPARSE_H_
#define _MULTI_SPARSE_H_

#include "SparseMatrix.h"
class RectSparse;
class MultiSparse  {
    int nsp;
    RectSparse **sp;
  public:
    MultiSparse(int _nsp) { nsp = _nsp; 
      sp = new RectSparse *[nsp];
      for (int i = 0; i < nsp; ++i)
	sp[i] = 0;
    }
    void setMat(int i, RectSparse *m);
    RectSparse *getMat(int i);
    void multIdentity(FSFullMatrix &res);
    void multSub(double *, double *);
    void transposeMultSub(double *, double *);
};

#endif
