//////////////////////////////////////////////////////////////////////////// 
//                                                                        // 
//          Copyright (C) 2009 ANSYS Inc.  All Rights Reserved            // 
//                                                                        // 
// This file contains proprietary software licensed from ANSYS Inc.       // 
// This header must remain in any source code despite modifications or    // 
// enhancements by any party.                                             // 
//                                                                        // 
//////////////////////////////////////////////////////////////////////////// 
// 
// $Workfile: sxnl_speedup.h $ 
// $Revision: 1.13.2.1 $Id:  
// $Date: 2009/04/10 15:33:27 $ 
// $Author: jtm $ Emmanuel Delor / Michel Rochette 
// 
// Decription:  
// 
//////////////////////////////////////////////////////////////////////////// 
 
  
#ifndef __SXNL_SPEEDUP_H__ 
#define __SXNL_SPEEDUP_H__ 1 
 
#include <stdio.h>  
#include <stdlib.h>  
#include "computer.h"  
#include "globals.h"  
#include "sysparh.h"  
#include "cadoe.h"  
#include "cadoesys.h"  
#include "adoc.h"  
#include "cadoe_vector.h" 
#include "C_Entity.h"
#include "ADOC_Session.h"
#include "C_VecP.h"
#include "C_vstruct.h" 
#include "C_MessageTool.h"   
#include "C_AnsysModele.h" 
#include "sxnl_esav.h" 
#include "sxnl_tools.h"
#include "sxnl_subspace.h"
#include "sxnl_interface.h" 

#define CHKIERNL if (ier != SUCCES) {Trace(fctn); setSolveStatus(E_SOLVE_STATUS_FAILURE); return ECHEC;} 
 
class C_optiHist;
class C_TimeCriterion;
class C_TimeProfiling;
class C_ItfContact;

//----------------------------------------------------------------- 
class C_ItfSpeedUp: public C_Entity
//----------------------------------------------------------------- 
{ 
public:    
 
  typedef enum { 
    E_SOLVE_STATUS_RUNNING = 0, 
    E_SOLVE_STATUS_FAILURE, 
    E_SOLVE_STATUS_OK 
  } E_SOLVE_STATUS; 
 
  C_ItfSpeedUp( const string &nom);  
  virtual ~C_ItfSpeedUp();  

  virtual int TypeCBF() const		{ return 78;}
  virtual int	GetDebugScope(void) { return E_SCOPE_ITFSPEEDUPFAST;}  
  virtual const char *Version() const		{ return "1.6";}  
  void setAdocSession (C_AdocSession *adocSession) {_adocSession = adocSession;} 
   
  void setSolveStatus(E_SOLVE_STATUS status) {_solveStatus = status;}; 
  E_SOLVE_STATUS getSolveStatus() {return _solveStatus;} 
  void addNbSolveDone(int loadstep);
  bool subspaceExist(int loadstep);
  int defineSubspace(int loadstep);
  
  virtual int Write (FILE *fb);  
  virtual int Read (FILE *fb);  

  IVEC *getListElemContact() {return _listElemContact;}

  void setModel(C_AnsysModele* model) {_model = model;}
  void setItfContact(C_ItfContact *itfContact) {_itfContact = itfContact;}
  
  C_AnsysModele* getModel(int loadstep);
  C_Subspace* getSubspace(int loadstep);
  
  C_AnsysModele* getModel() {return _model;};
  C_Subspace* getSubspace() {return _subspace;};

  void getCriterion(double timval, double &crit);
  
  void setIsolatedVars(INT *isolatedVars) {_isolatedVars = isolatedVars;}
  INT* getIsolatedVars() {return _isolatedVars;}
  
  virtual int initialize(); 
  int initializeOptions();
  
  virtual int allocateNbddl();
  virtual int allocateNbcs(bool forceToAllocate = false);
  bool isInitialized() {return _isInitialized;}  
  bool isExtraShape() {return _isUex;}
  
  int buildContactRegion();
  
  int doOptimization(bool &optimize);
  
  int defineCurrentModel(int loadstep, int substep);
  
  int minresQ(C_VecPi<double> &Uprev, C_VecPi<double> &Ulocal, C_VecPi<double> &Uinc,    
	      C_VecPi<double> &URotEP, C_VecPi<double> &Fnr, C_VecPi<double> &Ftotal,   
	      int *kelreq, int *lsloop, int *kfstps, int *kfstit,
	      bool &isConverged);  
  
  int sxnl_minresQ_reduceSubspace(int dimReduceQ, bool newSubstep, int ieqitr, int nbIterMax,
				  C_VecPi<double> &Uprev, C_VecPi<double> &Uinci, C_VecPi<double> &Uincn,
				  C_VecPi<double> &Fnr, C_VecPi<double> &Ftotal,
				  int *kelreq,
				  bool &isConverged);
  
  C_AnsysModele* getAnsysModel(int loadstep, int substep);
  C_Subspace* getSubspace(int loadstep, int substep);
  
  int findStatusCv(C_optiHist *_histOpti, int nbIter, int nbIterMax,
		   bool isCvMDOFs,bool isCvMDOFsF, bool isCvVDOFs);
  
  int enrichQ0(C_VecPi<double> &Uprev, C_VecPi<double> &Fnr, C_VecPi<double> &Ftotal);// TO REMOVE
  
  int enrichQ(C_VecPi<double> &Uprev, C_VecPi<double> &Ulocal, C_VecPi<double> &Uincr, // TO REMOVE
	      C_VecPi<double> &Fnr, C_VecPi<double> &Ftotal);  
  
  int addSolutionQ(C_VecPi<double> &Uprev, C_VecPi<double> &Uincr, C_VecPi<double> &Uincn,
		   C_VecPi<double> &Fnr, C_VecPi<double> &Ftotal);
  int removeUinci(int isubst);
  
  int getduex(int elem, double *duexi, double *duexn, int nbex);
  int putduexi(int elem, double *duexi, int nbex);
  
  int setElemExToAssembly(IVEC *listElem);
  
  int PartialAssembly(IVEC *listElem, C_Vec<double> &Uprev, C_Vec<double> &Fint, C_Vec<double> &Fext, bool freePCGMemory, bool debug, bool onlySfform = false);  
  int setErrorCode(int errorCode);
  
  int printConditioning(C_MatMGe<double> &matA); 
  
  int calcul_F(int *kelreq, int *kelreq_mat,  
	       int dimReduceQ,
	       C_MatMGe<double> *dFdX,
	       C_VecPi<double> &Uprev,
	       C_VecPi<double> &Ftotal, C_VecPi<double> &Fnr, 
	       C_VecPi<double> &res_part,  
	       bool debug = true); 
  
  int projInBasis(C_VecPi<double> &coefs, 
		  int dimReduceQ, C_VecPi<double> &solInd) ;
  
  int setDeltaUinci(double *);
  int setSumUinci(double *);
  
  int lsadju(double lspar, double lsparo, double &dincmx, int &dofimx, bool applyPreviousUinc); 
  int lineSearch(double &dincmx); 
  int restoreForceLs(double *vec);
  
  int computeResidualMDofs(C_VecPi<double> &Fnr, C_VecPi<double> &Ftotal, double &residual);
  int computeEnergy(C_VecPi<double> &dU, C_VecPi<double> &Fnr, C_VecPi<double> &Ftotal, double &energy, double &residu); 
  int traceEnergy(int dimReduceQ, int substep, int ieqitr, C_VecPi<double> &coefMin, C_VecPi<double> &coefMax, int nbPts); 
  int isLocalMinimum(int dimReduceQ, C_VecPi<double> &Uprev, C_VecPi<double> &Uinci, bool &isLocalMinimum); 
   
  int updateDisplacement(C_VecPi<double> &deltaUbcs, double con, double &dincmx); 
  
  int checkConv(C_Vec<double> &disp, C_Vec<double> &Fnr, C_Vec<double> &Ftotal, bool MDOFs, bool &isConvergedF, bool &isConvergedE); 
 
  int checkConditioning(C_VecPi<double> &UInci,C_VecPi<double> &Uprev,double norm_init, double norm, int &outConditioning); 
   
  int verif_cnv(int *kelreq, int *kelreq_mat, 
		C_VecPi<double> &Uinc, C_VecPi<double> &Uprev,   
		C_VecPi<double> &Ftotal, C_VecPi<double> &Fnr,  
		bool &isConverged);  

  int buildVerifDofsAsComponent(bool &isComponentDefined);
  int buildVerifDofs(C_VecPi<double> &Fext); 
   
  int checkVerifCnv(int *kelreq, int *kelreq_mat,  
                    C_VecPi<double> &Uinc, C_VecPi<double> &Uprev,  
		    C_VecPi<double> &Ftotal, C_VecPi<double> &Fnr);  
    
  int verifGradient(int *kelreq, int *kelreq_mat,  
		    C_MatMGe<double> &dFdX, int dimReduceQ,
		    C_VecPi<double> &Uprev, C_VecPi<double> &Uinc, 
		    C_VecPi<double> &Fnr, C_VecPi<double> &Ftotal,  
		    IVEC *part_to_dof, C_VecPi<double> &res_part, 
		    int nbIter);  
 
  int gradientFiniteDiff(int *kelreq, int *kelreq_mat,  
			 C_MatMGe<double> &dFdX, int dimReduceQ,
			 C_VecPi<double> &Uprev, C_VecPi<double> &Uinc, 
			 IVEC *partToDof); 
 
  int buildPartElem(int &nbDofPartElem, IVEC *part_to_dof);  
  
  int resizeStructures(int dimReduceQ, int &nb_partial,
		       C_VecPi<double> &res_part, C_VecPi<double> &res_part_app, C_VecPi<double> &res_part_init, C_VecPi<double> &res_part_var,  
		       C_MatMGe<double> &dFdX); 
   
  void getOptiUinci(DOUBLE *Uinci);
  
  int elementToBcsDof(C_VecPi<int> &elems, C_VecPi<int> &dofBcs);
  
  int outputCnvfor(char *cnvlab, double cnvval, double crit, double timval); 
  
  int updateStatusConv(int *kreturn); 
  
  int write_contact();
  int writeUex();
   
  double MemSize(); 
   
  void AffStdout(int verbosityLevel, string &message, bool addToTrace = true); 
  void AffStdout(int verbosityLevel, const char *chaine, ...); 
   
  int FillSummary(string &message, bool beginProcess);  
  int PrintSummary(bool beginProcess); 
  int printAllU(); 
  int DisplayResults(C_VecPi<double> &Uprev); 
  
  void statBegin(int section);
  void statEnd(int section);
  
  static int fillSxOptions(); 
  static int getSxOptionInt(const char *nameOption); 
  static double getSxOptionDbl(const char *nameOption); 
  static void setSxOptionInt(const char *nameOption, int valueOption); 
  static void setSxOptionDbl(const char *nameOption, double valueOption); 
  
protected: 
  char _rsxFileName [CADOE_NAMESIZE];  // name of the rsx file
  C_AdocSession *_adocSession;	// ADOC Session 
  int  _buildDate;		// build date 
  bool _isInitialized;		// is this object initialized? 
  bool _isModelDefined;		// is the model defined? 
  bool _isAllocatedNbddl;	// is this object allocated?
  bool _isAllocatedNbcs;	// is this object allocated?
  int  _nnzFextDofs;		// number of non zero external forces 
  E_SOLVE_STATUS _solveStatus;	// solve status 
  int  _loadstep;		// current loadstep (from svkan.F)
  int  _substep;		// current substep (from svkan.F) 
  bool _historic;		// have we to manage esav files? 
  int  _kupsvr;			// from svkan.F
  int  _nbVectorsAddSubstep;	// number of vectors added to the subspace for the current substep
  double _cnvval;		// residual norm on verif dofs (from cnvfor.F) 
  double _crit;			// criterion convergence (from cnvfor.F) 
  double _timval;		// time
  bool _debugWriteMatElemEx;
  
  bool _optimizeCurrentLoadStep;// do we optimize current loadstep?
  bool _optimizeCurrentSubstep;	// do we optimize current substep?
  
  // variables used during partial assembly
  int  _errorCode;		// Error Code from sfform.F
  
  // isolated variables
  INT *_isolatedVars;
  
  // element list
  IVEC *_listElemMDOFs;		// elements list to assembly for master DOFs
  C_VecPi<int> _listConnectedMDOFs;// DOFs connected to MDOFs
  
  IVEC *_listElemVDOFs;		// element list to assembly for verif DOFs
  IVEC *_listElemContact;	// contact element list 
  vector <C_VecPi<int> *> _dofBcsContactRegions;
  
  // working vectors  
  C_VecPi<double> _UInd;	// displacement vector (in BCS space) 
  C_VecPi<double> _UNod;	// displacement vector (in nodal space) 
  C_VecPi<double> _resInd;	// residual vector (in BCS space) 
  C_VecPi<double> _resNod; 	// residual vector (in nodal space) 
  C_VecPi<double> _Ftotal;	// external forces 
  C_VecPi<double> _Fnr;		// internal forces  
  C_VecPi<double> _traceNormUprev;// evolution of Uprev norm in substep convergence
  
  // save vectors at the beginning of minresQ
  C_VecPi<double> _saveUprev;	// Uprev at the beginning of minresQ 
  C_VecPi<double> _saveUinci;	// Uinci at the beginning of minresQ 
  C_VecPi<double> _saveUincn;	// Uincn at the beginning of minresQ 
  C_VecPi<double> _saveUvelo;	// Uvelo at the beginning of minresQ
  C_VecPi<double> _saveUacel;	// Uavec et the beginning of minresQ
  C_VecPi<double> _saveUexn;	// Uexn at the beginning of minresQ 
  C_VecPi<double> _saveSumUinci;
  C_VecPi<double> _saveURotEP;
  
  // save vectors at the optimum in minresQ
  C_VecPi<double> _optiUprev;	// Uprev at the optimum in minresQ 
  C_VecPi<double> _optiUinci;	// Uinci at the optimum in minresQ 
  C_VecPi<double> _optiUincn;	// Uincn at the optimum in minresQ 
  C_VecPi<double> _optiUvelo;	// Uvelo at the optimum in minresQ
  C_VecPi<double> _optiUacel;	// Uavec et the optimum in minresQ
  C_VecPi<double> _optiUexn;	// Uexn at the optimum in minresQ 
  C_VecPi<double> _optiSumUinci;// sum of Uinci over minresQ for the optimum
  C_VecPi<double> _optiURotEP;
  
  C_VecPi<double> _sumUinci;	// sum of Uinci over minresQ (Uinci+Uexi)
  C_VecPi<double> _lastUinci;
  
  // for extra shapes
  bool _isUex;			// extra shapes?
  bool _isExInitialized;
  int _sizeValUex;		// size of extra shapes vector
  int _sizePartValEx;
  C_VecPi<int> _listElemEx;    	// _listElemEx[ie] == -1 : element indice @ie has no extra shape
                                // _listElemEx[ie] <> -1 : indice of extra shapes of element indice @ie in _valUex
  C_VecPi<double> _Uexi;	// duexi
  C_VecPi<double> _Uexn;	// sum of duexi over substep
  
  // fortran memory
  C_VecPi<double> _linkFtotal;	// link to Ftotal in ANSYS memory 
  C_VecPi<double> _linkFnr;    	// link to Fnr in ANSYS memory 
  
  // Displacement vectors from svkan.F
  C_VecPi<double> _Uprev;     	// ULocal from svkan.F (= Utotal) 
  C_VecPi<double> _Uinci;     	// link to UInci in ANSYS memory 
  C_VecPi<double> _Uincn;     	// link to Uincn in ANSYS memory 
  C_VecPi<double> _Uvelo;	// link to Uvelo in ANSYS memory
  C_VecPi<double> _Uacel;	// link to Uacel in ANSYS memory
  C_VecPi<double> _URotEP;	// link to URotEP in ANSYS memory
  
  // set of models and subspaces
  vector<C_AnsysModele *> _models;// set of models 
  vector<C_Subspace *> _subspaces;// set of subspaces
  
  C_AnsysModele *_model;	// ansys model
  C_Subspace *_subspace;       	// current subspace 
  C_ItfContact *_itfContact;
  
  map <int,int> _mapLoadstepSubspace;	// _mapLoadstepSubspace[loadstep] = indice of subspace in @_subspaces
  map <int,int> _mapSubspaceModel;	// _mapSubspaceModel[subspace] = indice of model in @_subspaces
  
  // convergence criteria associted to time
  vector <C_TimeCriterion *> _setTimeCriterion;
  
  // for contact
  BVEC *_CurrentContact; 
  int _nb_contact;
  
  // members needed during optimization algorithm
  C_MatMGe<double> _matA;	// _matA = dFdX' * dFdX 
  C_VecPi<double> _vecB;	// _vecB = dFdX * residu 
  C_VecPi<double> _dX;		// _matA * _dX = _vecB 
  C_VecP<int> _perm;		// temporary vector for solving _matA * _dX = _vecB 
  
  // time profiling
  C_TimeProfiling _localTimeProfile;	// current loadstep
  C_TimeProfiling _globalTimeProfile;	// current run (sum of loadsteps)
  
  // members for display, debug and timimg 
  C_CadoeMessage *_messageDebug1; 
  C_CadoeMessage *_messageDebug2; 
}; 


 
#endif 
