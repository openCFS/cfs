////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         copyright(c) 2009 SAS IP, Inc.  All rights reserved.             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: ANS_StandardIncludes.h $
// $Revision: 1.5.2.1 $ 7.0
// $Date: 2009/04/13 14:09:58 $ March 28 2002
// $Author: jtm $ rjayasee/jlo
//
// Decription :
//  This file has all the standard include for porting and uniformity 
//  purposes
//
////////////////////////////////////////////////////////////////////////////

#if !defined(ANS_STANDARDINCLUDES_H)
#define ANS_STANDARDINCLUDES_H

#ifdef _WIN32
    #pragma warning( disable : 4786)
#endif
#ifdef _WINNT 
    #pragma warning( disable : 4786)
#endif
// Old iostream library.
// Hp seems to lag behind on this so include fstream.h instead of fstream
#ifdef MAINWIN
#include <windows.h>
#endif 

#include "computer.h"
#include <string.h>
#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <new.h>

#ifdef NT_SYS
  #define strcasecmp	_stricmp
  #define strncasecmp	_strnicmp
#endif

#ifndef ANS_HUGE
#define ANS_HUGE pow(2.0,100)
#endif
#ifndef ANS_TINY
#define ANS_TINY pow(2.0,-100)
#endif

#if defined (SGI_SYS)
    #pragma set woff 1681,1681
    #pragma set woff 1682,1682
#endif

#if defined (WBCURVEFIT)
   #if defined (_STANDARD_C_PLUS_PLUS) || defined (ANS_NEWCPPLIBS)
       #if defined (ux11) && defined (MAINWIN) && !defined(_HP_NAMESPACE_STD)
          #include <fstream>
       #else
          #include <fstream>
          #include <iostream>
       #endif
   #else
      #include <fstream>
   #endif
#else
   #if defined (_STANDARD_C_PLUS_PLUS) || defined (ANS_NEWCPPLIBS)
      #include <fstream>
      #include <iostream>
   #else
      #include <fstream.h>
   #endif
#endif

#include <map>
#include <string>
#include <vector>
#include <set>

#ifndef RWSTD_NO_NAMESPACE
using namespace std ;
#endif

typedef basic_string<char> ANS_String;

#if defined (HP_SYS) || defined(HPIA64_SYS) || defined(HP32_SYS) && !defined(MAINWIN)
    typedef int INT ;
    typedef double DOUBLE ;
    typedef char CHAR ;
#else
    #include "ansys.h"
#endif 

#if defined (PCWINNT_SYS)
    #ifdef CURVEFIT_EXPORTS
    #define CURVEFIT_API __declspec(dllexport)
    #else
    #define CURVEFIT_API __declspec(dllimport)
    #endif
#else
    #define CURVEFIT_API 
#endif


/* set LONGINTC which will always match Fortran LONGINT */
#if defined(LONGINT2)

   /********** most 32 bit systems should be defined here *************/

# if defined(RS6000_SYS) || defined(LINUXIA32_SYS) || defined(SGIR4K_SYS) \
   || defined(SOLARIS_SYS)


   /* most 32-bit systems longs are only 32 bits, while they still support
      integer*8 in FORTRAN */
   typedef long long int LONGINTC;


# else

#  if defined (PCWINNT_SYS) || defined(PCWIN64_SYS)
   /* the microsoft compiler doesn't respect long long, use their type */
   typedef __int64 LONGINTC;


#  else 

   /********** most 64 bit systems should be defined here *************/

   /* most 64 bit systems can just declare this to be a long */
   typedef long int LONGINTC;
#  endif

# endif


#else
   /********** systems in this section do not support integer*8 in FORTRAN ***/
   typedef int LONGINTC;
#endif

#if defined (WBCURVEFIT)
#undef const
#endif


#endif

