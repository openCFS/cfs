/* CADOE */
/**
 *  tab_prop.h
 *
 *  Definition de la table des proprietes elementaires exploitees par NBBVA
 *
 **/

/* $Id: sx_tab_prop.h,v 1.2.2.1 2009/04/13 14:10:00 jtm Exp $ */

#ifndef __TABPROPRIETES_H__ 
#define __TABPROPRIETES_H__ 1
#include "sx_CADOE_solver.h"
#include "CParameter.h"

typedef struct {
  int propriete;		/* code adofem de la propriete elementaire */
  E_type_propriete classe;	/* classe de propriete: materiau, physique */
  int nom;			/* code MSG_get() du libelle propriete */
  CParameter::Type parametre;	/* type de parametre si propriete parametrable */
  void *item;			/* string correspondante */
}  T_tableau_propriete;



extern T_tableau_propriete *G_tab_prop;
extern const int G_tab_prop_dim;

#ifdef __cplusplus
extern "C" {
#endif

extern int TPR_nombre_prop_classe( E_type_propriete );
extern int TPR_nombre_param_prop_classe( E_type_propriete );
extern int TPR_indice_ieme_prop_classe( int, E_type_propriete );
extern int TPR_indice_prop_classe( int, E_type_propriete );

extern T_statut TPR_creer_tab_prop(void);

#ifdef __cplusplus
}
#endif

#endif


