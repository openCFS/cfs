#ifndef __SX_EQUIVALENT_H__
#define __SX_EQUIVALENT_H__ 1

#include "cadoe.h"

enum E_stress_components { kSx=0, kSy=1, kSz=2, kSxy=3, kSyz=4, kSzx=5};
enum E_principal_components { kS1=0, kS2=1, kS3=2 };

class C_GlobMinAbsNeg
{
public:
  static void compute( double equiv_elem, int numero, double *equiv, double *equiv_min, int *numsupport)
  {
    double abs_equiv_elem = CADOE_ABS(equiv_elem);

    /* MAX */
    if( abs_equiv_elem > CADOE_ABS(*equiv)) *equiv = equiv_elem;

    /* MIN */
    if( abs_equiv_elem < CADOE_ABS(*equiv_min) )
      {
	*numsupport = numero;
	*equiv_min = equiv_elem;
      }
  }
private:
  C_GlobMinAbsNeg(){};
  ~C_GlobMinAbsNeg(){};
};

class C_GlobMinAbs
{
public:
  static void compute( double equiv_elem, int numero, double *equiv, double *equiv_min, int *numsupport)
  {
    double abs_equiv_elem = CADOE_ABS(equiv_elem);

    /* MAX */
    if( abs_equiv_elem > CADOE_ABS(*equiv)) *equiv = abs_equiv_elem;

    /* MIN */
    if( abs_equiv_elem < CADOE_ABS(*equiv_min) )
      {
	*numsupport = numero;
	*equiv_min = abs_equiv_elem;
      }
  }
private:
  C_GlobMinAbs(){};
  ~C_GlobMinAbs(){};
};

class C_GlobMaxAbsNeg
{
public:
  static void compute( double equiv_elem, int numero, double *equiv, double *equiv_min, int *numsupport)
  {
    double abs_equiv_elem = CADOE_ABS(equiv_elem);

    /* MAX */
    if( abs_equiv_elem > CADOE_ABS(*equiv))
      {
	*numsupport = numero;
	*equiv = equiv_elem;
      }

    /* MIN */
    if( abs_equiv_elem < CADOE_ABS(*equiv_min) ) *equiv_min = equiv_elem;
  }
private:
  C_GlobMaxAbsNeg(){};
  ~C_GlobMaxAbsNeg(){};
};

class C_GlobMaxAbs
{
public:
  static void compute( double equiv_elem, int numero, double *equiv, double *equiv_min, int *numsupport)
  {
    double abs_equiv_elem = CADOE_ABS(equiv_elem);

    /* MAX */
    if( abs_equiv_elem > CADOE_ABS(*equiv))
      {
	*numsupport = numero;
	*equiv = abs_equiv_elem;
      }

    /* MIN */
    if( abs_equiv_elem < CADOE_ABS(*equiv_min) ) *equiv_min = abs_equiv_elem;
  }
private:
  C_GlobMaxAbs(){};
  ~C_GlobMaxAbs(){};
};

class C_GlobMin
{
public:
  static void compute( double equiv_elem, int numero, double *equiv, double *equiv_min, int *numsupport)
  {
    /* MAX */
    if( equiv_elem  > *equiv  ) *equiv = equiv_elem;

    /* MIN */
    if( equiv_elem < *equiv_min )
      {
	*numsupport = numero;
	*equiv_min = equiv_elem;
      }
  }
private:
  C_GlobMin(){};
  ~C_GlobMin(){};
};

class C_GlobMax
{
public:
  static void compute( double equiv_elem, int numero, double *equiv, double *equiv_min, int *numsupport)
  {
    /* MAX */
    if( equiv_elem  > *equiv  ) 
      {
	*numsupport = numero;
	*equiv = equiv_elem;
      }

    /* MIN */
    if( equiv_elem < *equiv_min ) *equiv_min = equiv_elem;
  }
private:
  C_GlobMax(){};
  ~C_GlobMax(){};
};

class C_EquivVonMises
{
public:
  static double compute ( E_mode_analyse mode_analyse, double *sigma, int composante )
  {
    double sigvm;
    double xx_moins_yy, yy_moins_zz, zz_moins_xx;

    xx_moins_yy = sigma[kSx] - sigma[kSy];
    yy_moins_zz = sigma[kSy] - sigma[kSz];
    zz_moins_xx = sigma[kSz] - sigma[kSx];

    sigvm=sqrt( (xx_moins_yy*xx_moins_yy+yy_moins_zz*yy_moins_zz+zz_moins_xx*zz_moins_xx
		 +6*(sigma[kSxy]*sigma[kSxy]+sigma[kSzx]*sigma[kSzx]+sigma[kSyz]*sigma[kSyz]) )*0.5);

    return sigvm;
  }
private:
  C_EquivVonMises(){};
  ~C_EquivVonMises(){};
};

class C_EquivPrincipalStress
{
public:
  static void compute ( double *components, double *principals )
  {
    static const double dp1o3 = 1./3.;
    static const double dp1o27 = 1./27.;
    static const double dp2o27 = 2./27.;

    static const double dpcon1 = 2.0*M_PI/3.0;
    static const double dpcon2 = 4.0*M_PI/3.0;

    int i;
    double smax, invsmax;
    double sx, sy, sz, sxy, syz, szx;
    double ppp2, sxy2, syz2, szx2;
    double vabs;
    double con1, con2;

    /* we build the symetric matrix */

    /* initialize output */
    principals[0] = principals[1] = principals[2] = 0.0;

    /* find max component */
    smax = 0.0;
    for (i=0; i<6; i++) 
      {
	vabs = CADOE_ABS(components[i]);
	smax = MAX(smax, vabs);
      }

    /* check for zero components */
    if (smax <= 1.0e-20) return;

    /* normalize components */
    invsmax = 1./smax;
    sx = components[kSx]*invsmax;
    sy = components[kSy]*invsmax;
    sz = components[kSz]*invsmax;
    sxy = components[kSxy]*invsmax;
    syz = components[kSyz]*invsmax;
    szx = components[kSzx]*invsmax;

    /* zero insignificant components */
    if (CADOE_ABS(sx) < 1.0e-8) sx = 0.0;
    if (CADOE_ABS(sy) < 1.0e-8) sy = 0.0;
    if (CADOE_ABS(sz) < 1.0e-8) sz = 0.0;
    if (CADOE_ABS(sxy) < 1.0e-8) sxy = 0.0;
    if (CADOE_ABS(syz) < 1.0e-8) syz = 0.0;
    if (CADOE_ABS(szx) < 1.0e-8) szx = 0.0;

    if (syz == 0.0 && szx == 0.0)
      {
	double sxmoinssy = sx-sy;      
	/* process case when syz and szx are both zero (2d case) */
	con1 = 0.5*(sx + sy);
	con2 = sqrt(0.25*(sxmoinssy)*(sxmoinssy) + sxy*sxy);
	principals[kS1] = sz;
	principals[kS2] = con1 - con2;
	if (CADOE_ABS(principals[kS2]) < 1.0e-9) principals[kS2] = 0.0;
	principals[kS3] = con1 + con2;
      }
    else
      {
	/* process case when stresses are 3d */
	double ppp, qqq, rrr, aaa, bbb, con, phi;

	ppp = -(sx + sy + sz);
	sxy2 = sxy*sxy;
	syz2 = syz*syz;
	szx2 = szx*szx;
	qqq = sx*sy + sy*sz + sz*sx - sxy2 - syz2 - szx2;
	rrr = -(sx*sy*sz - sx*syz2 - sy*szx2 - sz*sxy2 + 2.0*sxy*syz*szx);

	ppp2 = ppp*ppp;
	aaa = qqq - dp1o3*ppp2;
	bbb = ppp*( dp2o27*ppp2 - dp1o3*qqq ) + rrr;

	con = -dp1o27*aaa*aaa*aaa;
	con1 = 1.0;
	if (con  != 0.0) con1 = (-bbb*0.5)/sqrt(CADOE_ABS(con));
	if (con1 < -1.0) con1 = -1.0;
	else if (con1 >  1.0) con1 =  1.0;
	phi = acos(con1);
	con = 2.0*sqrt(CADOE_ABS(-dp1o3*aaa));
	con1 = -dp1o3*ppp;
	con2 =  dp1o3*phi;
	principals[kS1] = con1 + con*cos(con2);
	principals[kS2] = con1 + con*cos(con2 + dpcon1);
	principals[kS3] = con1 + con*cos(con2 + dpcon2);
      }

    /* scale up the principals */
    principals[0] *= smax;
    principals[1] *= smax;
    principals[2] *= smax;

    /*sx_sortDescendingOrder(principals);*/

    if ( principals[0] < principals[1] )
      {
	con1=principals[0]; principals[0]=principals[1]; principals[1]=con1;
      }
    if ( principals[0] < principals[2] )
      {
	con1=principals[0]; principals[0]=principals[2]; principals[2]=con1;
      }
    if ( principals[1] < principals[2] )
      {
	con1=principals[1]; principals[1]=principals[2]; principals[2]=con1;
      }

    return;
  }
private:
  C_EquivPrincipalStress(){};
  ~C_EquivPrincipalStress(){};
};

class C_EquivMaxPrincipalStress
{
public:
  static double compute ( E_mode_analyse mode_analyse, double *sigma, int composante )
  {
    double valp[3];  
    C_EquivPrincipalStress::compute( sigma, valp);
    return(valp[0]);
  }
private:
  C_EquivMaxPrincipalStress(){};
  ~C_EquivMaxPrincipalStress(){};
};

class C_EquivCompPrincipalStress
{
public:
  static double compute ( E_mode_analyse mode_analyse, double *sigma, int composante )
  {
    double valp[3];
    C_EquivPrincipalStress::compute( sigma, valp );
    return(valp[composante]);
  }
private:
  C_EquivCompPrincipalStress(){};
  ~C_EquivCompPrincipalStress(){};
};

class C_EquivTresca
{
public:
  static double compute ( E_mode_analyse mode_analyse, double *sigma, int composante )
  {
    double sigtr=0.;
    double valp[3];

    C_EquivPrincipalStress::compute( sigma, valp);

    /* sigtr = max(|valp[0]-valp[1]|, |valp[0]-valp[2]|, |valp[1]-valp[2]|) */
    /* and valp[0] > valp[1] > valp[2] */
    /* => sigtr = |valp[0]-valp[2]| */
    sigtr = CADOE_ABS(valp[0] - valp[2]);
    return sigtr;
  }
private:
  C_EquivTresca(){};
  ~C_EquivTresca(){};
};

class C_EquivMaxStressShear
{
public:
  static double compute ( E_mode_analyse mode_analyse, double *sigma, int composante )
  {
    double resultat;
    double valp[3];

    C_EquivPrincipalStress::compute( sigma, valp);
    resultat = ( valp[0] - valp[2] ) /2.0;
    return resultat;
  }
private:
  C_EquivMaxStressShear(){};
  ~C_EquivMaxStressShear(){};
};

class C_EquivIdentComponent
{
public:
  static double compute ( E_mode_analyse mode_analyse, double *vecteur, int composante )
  {
    return vecteur[composante];
  }
private:
  C_EquivIdentComponent(){};
  ~C_EquivIdentComponent(){};
};

class C_EquivVectorComponent
{
public:
  static double compute ( E_mode_analyse mode_analyse, double *vecteur, int composante )
  {
    double resultat;

    switch(composante) 
      {
      case NORME_TRANSLATION :
	resultat = vecteur[0]*vecteur[0];
	resultat += vecteur[1]*vecteur[1];
	resultat += vecteur[2]*vecteur[2];
	return sqrt(resultat);
      case NORME_ROTATION :
	resultat = vecteur[3]*vecteur[3];
	resultat += vecteur[4]*vecteur[4];
	resultat += vecteur[5]*vecteur[5];
	return sqrt(resultat);
      case NORME_INF_TRANSLATION :
      case NORME_INF_ROTATION :
      case EQ_CP_UX:
      case EQ_CP_UY:
      case EQ_CP_UZ:
      case EQ_VONMISES:
      case EQ_TRESCA:
      case EQ_MSSHEAR:
	return 0.;
      default :
	return vecteur[composante];
      }
  }
private:
  C_EquivVectorComponent(){};
  ~C_EquivVectorComponent(){};
};

class C_EquivTensorComponent
{
public:
  static double compute ( E_mode_analyse mode_analyse, double *tenseur, int composante )
  {
    return tenseur[composante];
  }
private:
  C_EquivTensorComponent(){};
  ~C_EquivTensorComponent(){};
};

class C_EquivTorqueComponent
{
public:
  static double compute ( E_mode_analyse mode_analyse, double *torseur, int composante )
  {
    int i;
    double resultat;
    double abs_val;

    switch(composante) 
      {
      case NORME_TRANSLATION :
	resultat = torseur[0]*torseur[0];
	resultat += torseur[1]*torseur[1];
	resultat += torseur[2]*torseur[2];
	return sqrt(resultat);
      case NORME_ROTATION :
	resultat = torseur[3]*torseur[3];
	resultat += torseur[4]*torseur[4];
	resultat += torseur[5]*torseur[5];
	return sqrt(resultat);
      case NORME_INF_TRANSLATION :
	resultat = -CADOEBIG;
	for ( i = 0; i < 3; i++ ) 
	  {
	    abs_val = CADOE_ABS(torseur[i]);
	    if ( abs_val > resultat)
	      resultat = abs_val;
	  }
	return resultat;
      case NORME_INF_ROTATION :
	resultat = -CADOEBIG;
	for ( i = 0; i < 3; i++ ) 
	  {
	    abs_val = CADOE_ABS(torseur[3+i]);
	    if ( abs_val > resultat)
	      resultat = abs_val;
	  }
	return resultat;
      case EQ_CP_UX:
      case EQ_CP_UY:
      case EQ_CP_UZ:
      case EQ_VONMISES:
      case EQ_TRESCA:
      case EQ_MSSHEAR:
	return 0.;
      default :
	return torseur[composante];
      }
  }
private:
  C_EquivTorqueComponent(){};
  ~C_EquivTorqueComponent(){};
};

// class C_ExtractEquivalent<T1,T2>
// T1 = scalarizant (ex: C_EquivVonMises)
// T2 = globalisant (ex: C_GlobMaxAbs)
template <typename T1, typename T2> class C_ExtractEquivalent
{
public:
  C_ExtractEquivalent(){};
  ~C_ExtractEquivalent(){};

  static T_statut GRP_tenseur_el( T_critere *critere, T_champ_local *chl_tenseur );
  static T_statut GRP_tenseur_no( T_critere *critere, T_champ_global *chg_tenseur );
};

#endif
