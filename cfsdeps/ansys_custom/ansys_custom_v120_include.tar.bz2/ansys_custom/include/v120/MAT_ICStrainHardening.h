////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         Copyright (C) 2009 ANSYS Inc.  All Rights Reserved             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MAT_ICStrainHardening.h $
// $Revision: 1.3.2.1 $ 7.0
// $Date: 2009/04/13 14:09:59 $ March 28 2002
// $Author: jtm $ rjayasee
//
// Decription :
//              This class implement Strain Hardening Implicit Creep Models
//
////////////////////////////////////////////////////////////////////////////// 

#if !defined(MAT_ICStrainHardening_H)
#define MAT_ICStrainHardening_H

#include  "MAT_ConstitutiveFunction.h"
#include  "MAT_Creep.h"

class MAT_ICStrainHardening  : public MAT_Creep
{
public:

	MAT_ICStrainHardening();
    // Default Constructor.

    static MAT_Creep* Construct() ;

    virtual bool FunctionValue( double* pVariables, INT iNumVariables,
                                double* pInputVariables, INT iNumInputVariables, double& dCreepStrain ) ;
    //I pVariable
    //I-Value of Coefficients
    //I iNumVariables
    //I- Number of variables
    //I dInputVariables
    //I-Input Variables
    //I iNumInputVariables
    //I-Num Input Variables
    //I dCreepStrain
    //I-Calculated Value of Creep Strain
    //R- Calculates the value of the Creep Strain Rate using Strain Hardering 

    virtual bool FirstDerivativeOfUnsquaredError
                 ( double* pVariables,INT iNumVariables,
                   double* pInputVariables, INT iNumInputVariables,
                   INT iVariableIndex, double& dResult ) ;
    //I pVariable
    //I-Value of Coefficients
    //I iNumVariables
    //I- Number of variables
    //I dInputVariables
    //I-Input Variables
    //I iNumInputVariables
    //I-Num Input Variables
    //I dCreepStrain
    //I-Calculated Value of Creep Strain
    //I iVariableIndex
    //I-Variable w.r.t which the derivative is to be calculated
    //R- Calculates the value of the Creep Strain using Strain Hardening
          
    
    virtual void Print() ;
    // Prints the constitutive function

    virtual void EliminateTemperatureCoefficients();
    //Eliminates Temperature term and fixes it.

    virtual ~MAT_ICStrainHardening();
    //Destructor

protected:


} ;


class MAT_ICStrainHardeningFactory
{
    public:

    static MAT_ICStrainHardeningFactory* Instance() ;
    //I Pointer to Creep Factory
    //- Pointer to Singleton Instantiator

    static void Destroy() ;
    ~MAT_ICStrainHardeningFactory() ;
    // Destructor

    private:

    MAT_ICStrainHardeningFactory() ;
    // Constructor

    static MAT_ICStrainHardeningFactory* m_pInstance ;
    //Pointer to only instance of this class
} ;

#endif // !defined(MAT_ICStrainHardening_H)
