////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         Copyright (C) 2009 ANSYS Inc.  All Rights Reserved             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MAT_FieldVariableCollection.h $
// $Revision: 1.3.2.1 $ 7.0
// $Date: 2009/04/13 14:09:59 $ March 28 2002
// $Author: jtm $ rjayasee/jlo
//
// Decription :
//
//	This is just an array of Field Variables
////////////////////////////////////////////////////////////////////////////// 

#if !defined(MAT_FieldVariableCollection_H)
#define MAT_FieldVariableCollection_H

#include "ANS_StandardIncludes.h"

typedef INT MAT_FieldVariable ;

typedef map<MAT_FieldVariable,double> MAT_FieldVarDoubleMap   ;

class MAT_FieldVariableCollection  
{
public:

	MAT_FieldVariableCollection();
    // Default Constructor.

	MAT_FieldVariableCollection(MAT_FieldVariableCollection const& pOrig);
    // Copy Constructor.

    ~MAT_FieldVariableCollection();
    //Destructor

    static INT GetMaxNumberOfVariables()
    {
        return 10 ;
    }

    bool AddVariable(MAT_FieldVariable oVariable, double const& dValue) ;
    //R status
    //I oVariable
    //I Variable to tbe added.
    //I dValue
    //I Value of Variable
    //- Appends a Variable

    bool GetVariable(MAT_FieldVariable oVariable, double& dValue) const;
    //R status
    //I oVariable
    //I Variable to tbe added.
    //I dValue
    //I Value of Variable
    //- Appends a Variable

    bool RemoveVariable(MAT_FieldVariable oVariable) ;
    //R status
    //I oVariable
    //I-Value of Variable
    //Removes the Last added coefficient

    bool RemoveAllVariables() ;
    //R status
    //Removes all Variables

    INT GetNumberOfVariables() const { return m_oFieldVariableMap.size(); } ;
    //R INT
    //- Gets the Number of Field Variable

    static bool Compare(MAT_FieldVariableCollection const& oOb1, MAT_FieldVariableCollection const& oOb2 );
    //Return the status oOb1 < oOb2

    bool operator==(MAT_FieldVariableCollection const& oOb2 ) const;

    MAT_FieldVariableCollection& operator=(MAT_FieldVariableCollection const& oOb2 );
    //Equality operator

    void Print() const;
    //Print Function

private:

	MAT_FieldVarDoubleMap m_oFieldVariableMap ;
    // List of Constitutive Model data
} ;



class MAT_FieldVariableCollectionPtrCmp
{
public:
    MAT_FieldVariableCollectionPtrCmp() {} ;
    //Constructor

    bool operator() (MAT_FieldVariableCollection oOb1, MAT_FieldVariableCollection oOb2 ) const;
    //Comparison Operator
} ;

#endif // !defined(MAT_FieldVariableCollection_H)

