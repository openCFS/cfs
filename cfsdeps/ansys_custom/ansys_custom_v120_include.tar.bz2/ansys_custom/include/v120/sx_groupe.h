/* CADOE */
/**
 *	groupe.h -- Fonctions de l'objet groupe
 *   
 * HISTORY
 *   
 *   02/15/00 13:10 <       Brian Jantzen> Rel:ms8      SCCA:68558  Delta:8.4
 *   
 *   01/31/00 15:39 <       Brian Jantzen> Rel:ms8      SCCA:67206  Delta:8.3
 *   
 *   09/30/99 17:38 <         James Silva> Rel:ms8      SCCA:56512  Delta:8.2
 **/

#include "sx_CADOE_solver.h"
#ifndef __GROUPE_X_DEJA_INCLUS__
#define __GROUPE_X_DEJA_INCLUS__ 1

#include "cadoe_vector.h"

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

  extern T_groupe *GRP_allouer( T_modele*, E_nature_groupe, int, int* );
  extern T_statut GRP_initialiser( T_groupe *, T_modele *, E_nature_groupe, int );
  extern T_groupe* GRP_fusion( T_modele * modele, T_liste * grps, T_statut * ier);
  extern T_statut GRP_inserer_element( T_modele*, T_groupe*, int,  E_extract_groupe );
  extern T_statut GRP_initialiser_iterateur( T_groupe* );
  extern int GRP_suivant( T_modele*, T_groupe*, E_extract_groupe );
  extern T_statut GRP_verifier( T_modele*, T_groupe* );
  extern T_statut GRP_indicage(T_modele *, char *);
  extern T_statut GRP_rechercher_groupe( const char*, T_modele*, T_statut* );
  extern int GRP_nombre_elements( T_groupe*, T_modele*, T_statut* );
  extern T_statut GRP_detruire( T_groupe**);
  extern void GRP_free( T_groupe*);
  extern T_groupe* GRP_noeud_2_elem_2_noeud( T_groupe*, T_modele*, T_statut* );
  extern T_groupe* GRP_elem_2_noeud( T_groupe*, T_modele*, T_statut* );
  extern T_groupe* GRP_noeud_2_elem( T_groupe*, T_modele*, T_statut* );
  extern T_statut GRP_tab_indice( T_groupe*, int, T_modele*, IVEC*, IVEC **, int*, int*, T_booleen * );
  extern T_statut GRP_creer_groupe_1( T_modele*, E_nature_groupe, int, T_groupe** );
  extern T_booleen GRP_est_dans_groupe( T_groupe*, int );
  extern int GRP_ou_dans_groupe( T_groupe*, int );
  extern int GRP_max_elts( T_modele *modele, E_nature_groupe nature );
  extern T_statut GRP_extraire_res( T_groupe*, T_modele*, E_resultat_parametre, VEC*, T_res_cas_charge* );
  extern T_statut GRP_extr_equivalent_tenseur_el( T_critere *critere, T_champ_local *chl_tenseur, T_fct_compo fct_compo );
  extern T_statut GRP_extr_equivalent_tenseur_no( T_critere *critere, T_champ_global *chg_tenseur, T_fct_compo fct_compo );
  extern T_statut GRP_extr_force( T_critere *critere, T_champ_local *chg_tenseur, T_fct_compo fct_compo );
  extern T_statut GRP_extr_equivalent_vecteur_el( T_critere *, T_champ_local *, T_fct_compo );
  extern T_statut GRP_extr_equivalent_vecteur_no( T_critere *, T_champ_global *, T_fct_compo );
  extern double GRP_somme_chl_scalaire( T_modele *, T_groupe *, T_champ_local *, T_statut * );
  extern double GRP_extr_equivalent_torseur_no( T_modele *, T_groupe *, T_champ_local *, IVEC *, int , int , T_fct_compo, T_booleen, T_booleen , int * , int * );
  extern T_statut GRP_max_deplacement( T_critere *critere, T_champ_global *u );
  extern T_statut GRP_max_perturbation( T_critere *critere, VEC *pert );
  extern T_statut GRP_max_scalaire( T_critere *critere, T_champ_global *u );
  extern T_statut GRP_boutput( FILE *fichier, T_groupe *groupe );
  extern T_groupe *GRP_binput_81( FILE *fichier, T_statut *ier );
  extern T_groupe *GRP_binput( FILE *fichier, T_statut *ier );
  extern T_groupe *GRP_creer( T_modele *modele, E_nature_groupe nature, int num_elem, int *labels );
  extern T_groupe *GRP_creer_stl( T_modele *modele, E_nature_groupe nature, int num_elem, vector<int> labels );
  extern T_statut GRP_replace_pel( T_groupe *grp, T_modele *modele, E_type_propriete type, T_prop_elem *pel, T_prop_elem **pelc, T_propriete **prop );
  extern T_statut GRP_set_on( T_modele *modele, T_groupe *groupe, E_resultat_parametre resultat );
  extern T_groupe* GRP_copier(T_groupe* groupe,T_statut* ier);
  extern void	  GRP_print(T_modele * modele, T_groupe * grp);
#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif   /* __GROUPE_X_DEJA_INCLUS__*/

