/*
 *    author/date: yu-hua ting/02-18-94
 *
 *    primary function:
 *
 *
 *      Headers for the Interface to SHAPES "attributes" routines
 *
 *    secondary function:
 *
 *        none
 *
 *    routines included:
 *
 *
 *    history
 *
 *        none
 *
 *    comments:
 *
 *        none
 *
 *    Notice - This file contains ANSYS Confidential information ***
 *
 */

/* 
 * *** copyright(c) 2009 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */



/*
 *    Construct a new attribute type specifier
 */
      extern xATTR_SPEC xAttrSpecNew_xox ansPROTO((
             xCHAR *stringid,     /* I    attribute type specifier descriptive string  */ 
             xTAG   tag,          /* I    heap specifier                               */
             INT *iretp));        /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                                 */

      

/*
 *    modify an attribute type specifier with a new attribute handler
 *    (old_attr_type_spec and new_attr_type_spec are the same actually
 *     from Lyle Fischer, 12/06/93                                      )
 */
      extern xATTR_SPEC xAttrSpecSetHndlr_xox ansPROTO((
             xATTR_SPEC old_attr_type_spec,  /* I    old attribute type specifier  */ 
             xINT funcid,                    /* I    identifier for function       */
             xVOID_FUNC func,                /* I    customized function           */
             INT *iretp));                   /*   O  error code   
                                              *      == 0 - no error
                                              *      != 0 - error                  */

/*
 *    delete an attribute type specifier
 */
      extern xVOID xAttrSpecDelete_xox ansPROTO((
             xATTR_SPEC attr_type_spec,  /* I    attribute type specifier */ 
             INT *iretp));               /*   O  error code   
                                          *      == 0 - no error
                                          *      != 0 - error             */


/*
 *    Construct a new attribute of a specified type
 */
      extern xATTR xAttrNew_xox ansPROTO((
             xATTR_SPEC attr_type_spec,  /* I    attribute type specifier  */ 
             xTAG   tag,                 /* I    heap specifier            */
             INT *iretp));               /*   O  error code   
                                          *      == 0 - no error
                                          *      != 0 - error              */

/*
 *    copy an attribute instance 
 */
      extern xATTR xAttrCopy_xox ansPROTO((
             xATTR source_attr,          /* I    source attribute          */ 
             xTAG   tag,                 /* I    heap specifier            */
             INT *iretp));               /*   O  error code   
                                          *      == 0 - no error
                                          *      != 0 - error              */
             



/*
 *    delete an attribute 
 */
      extern xVOID xAttrDelete_xox ansPROTO((
             xATTR attr,                 /* I    an attribute             */
             INT *iretp));               /*   O  error code   
                                          *      == 0 - no error
                                          *      != 0 - error             */

/*
 *    set the pointer value from an attribute
 *    (old_attr and new_attr are the same actually
 *     from Lyle Fischer, 12/06/93                                      )
 */

      extern xATTR xAttrSetPtrVal_xox ansPROTO((
             xATTR old_attr,      /* I    old attribute                                */ 
             xPTR  val,           /* I    value to be assigned to old_attr             */
             INT *iretp));        /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                                 */

/*
 *    set the integer value from an attribute
 *    (old_attr and new_attr are the same actually
 *     from Lyle Fischer, 12/06/93                                      )
 */

      extern xATTR xAttrSetIntVal_xox ansPROTO((
             xATTR old_attr,      /* I    old attribute                                */ 
             xINT  val,           /* I    value to be assigned to old_attr             */
             INT *iretp));        /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                                 */

/*
 *    set the real value from an attribute
 *    (old_attr and new_attr are the same actually
 *     from Lyle Fischer, 12/06/93                                      )
 */

      extern xATTR xAttrSetRealVal_xox ansPROTO((
             xATTR old_attr,      /* I    old attribute                                */ 
             xREAL val,           /* I    value to be assigned to old_attr             */
             INT *iretp));        /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                                 */

/*
 *    get the pointer value from an attribute
 */

      extern xPTR xAttrGetPtrVal_xox ansPROTO((
             xATTR attr,          /* I    an attribute                                */ 
             INT *iretp));        /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                                */
      

/*
 *    get the integer value from an attribute
 */

      extern xINT xAttrGetIntVal_xox ansPROTO((
             xATTR attr,          /* I    an attribute                                */ 
             INT *iretp));        /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                                */
      

/*
 *    get the real value from an attribute
 */

      extern xREAL xAttrGetRealVal_xox ansPROTO((
             xATTR attr,          /* I    an attribute                                */ 
             INT *iretp));        /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                                */

      
      

/*
 *    set an attribute for a cell
 */
      extern xVOID xCellSetAttr_xox ansPROTO((
             xGEOM_ID gm_id,             /* I    a cell (basic geom)      */
             xATTR attr,                 /* I    an attribute             */ 
             INT *iretp));               /*   O  error code   
                                          *      == 0 - no error
                                          *      != 0 - error             */

/*
 *    query cell for attribute of specified type
 */
      extern xATTR xCellGetAttr_xox ansPROTO((
             xGEOM_ID gm_id,             /* I    a cell (basic geom)      */
             xATTR_SPEC attr_type_spec,  /* I    attribute type specifier */ 
             INT *iretp));               /*   O  error code   
                                          *      == 0 - no error
                                          *      != 0 - error             */
      

/*
 *    remove an attribute for a cell
 */
      extern xVOID xCellRemoveAttr_xox ansPROTO((
             xGEOM_ID gm_id,             /* I    a cell (basic geom)          */
             xATTR_SPEC attr_type_spec,  /* I    an attribute type specifier  */ 
             INT *iretp));               /*   O  error code   
                                          *      == 0 - no error
                                          *      != 0 - error                 */

      

      

/*
 *    set an attribute for a frame
 */
      extern xVOID xFrameSetAttr_xox ansPROTO((
             xFRAME_ID frame_id,         /* I    a frame                  */
             xATTR attr,                 /* I    an attribute             */ 
             INT *iretp));               /*   O  error code   
                                          *      == 0 - no error
                                          *      != 0 - error             */

/*
 *    query frame for attribute of specified type
 */
      extern xATTR xFrameGetAttr_xox ansPROTO((
             xFRAME_ID frame_id,         /* I    a frame                  */
             xATTR_SPEC attr_type_spec,  /* I    attribute type specifier */ 
             INT *iretp));               /*   O  error code   
                                          *      == 0 - no error
                                          *      != 0 - error             */
      
      

/*
 *    remove an attribute for a frame
 */
      extern xVOID xFrameRemoveAttr_xox ansPROTO((
             xFRAME_ID frame_id,             /* I    a frame (basic geom)          */
             xATTR_SPEC attr_type_spec,  /* I    an attribute type specifier  */ 
             INT *iretp));               /*   O  error code   
                                          *      == 0 - no error
                                          *      != 0 - error                 */

      

