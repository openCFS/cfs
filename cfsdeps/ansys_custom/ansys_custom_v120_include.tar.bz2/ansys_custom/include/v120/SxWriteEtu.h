/*******************************************************************************
 *
 *   SxWriteEtu.cpp  --- Write/update T_obj_etude in the CADOE database
 *               
 * 
 * |Module:  
 *
 * |Description: 
 *
 * |Includes:	SxWriteEtu.h
 *        
 * |Auteur: Stephane GARREAU
 *
 * |Creation: Juillet 2002
 *
 * |Version: $Id: SxWriteEtu.h,v 1.1.4.1 2009/04/10 15:33:13 jtm Exp $
 *
 * |Copyright:	Copyright(c)  2002
 *
 ********************************************************************************/
#ifndef __SXWRITEETU_H__
#define __SXWRITEETU_H__ 1


#ifdef __cplusplus
extern "C" {
#endif

int
SxWriteEtu( T_modele *modele );

#ifdef __cplusplus
}
#endif

#endif /* __SXWRITEPARAM_H__ */
