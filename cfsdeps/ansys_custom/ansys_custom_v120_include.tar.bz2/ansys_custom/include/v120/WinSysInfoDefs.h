/*HFILE WinSysInfoDefs.h                                           elp
------------------------------------------------------------------------
------- Notice - This file contains ANSYS Confidential information
------------------------------------------------------------------------
*/

/*
 *  This file contains symbolic definitions for windows system information function WinSysInfo
 *
 *   CAUTION WHEN EDITING THIS FILE!!!
 *
 *   THIS FILE HAS A TWIN FILE NAMED fWinSysInfoDefs.inc, AND ALL DEFINITIONS
 *   MUST REMAIN IN SYNC FOR THE MANAGER TO WORK PROPERLY!!!
 */


#define WIN_TOTAL_PHYSICAL           1 //Total amount of physical memory in bytes
#define WIN_TOTAL_VIRTUAL            2 //Total amount of virtual memory in bytes
#define WIN_TOTAL_COMMIT             4 //Total amount of memory committed by system
#define WIN_TOTAL_PAGEFILE           8 //Limit for committed memory in bytes ( physical + page file )
#define WIN_TOTAL_KERNEL            16 //Total paged and non-paged kernel pool memory in bytes
#define WIN_PAGED_KERNEL            32 //Total paged kernel memory in bytes
#define WIN_NONPAGED_KERNEL         64 //Total non-paged kernel memory in bytes
#define WIN_AVAIL_PHYSICAL         128 //Available amount of physical memory in bytes
#define WIN_AVAIL_VIRTUAL          256 //Available amount of virtual memory in bytes
#define WIN_AVAIL_EXTENDED_VIRTUAL 512 //Available amount of extended virtual memory in bytes
#define WIN_AVAIL_COMMIT          1024 //Available amount of system committed memory in bytes
#define WIN_AVAIL_PAGEFILE        2048 //Total amount of available committed memory in bytes
#define WIN_SYSTEM_CACHE          4096 //Size of system cache memory in bytes
#define WIN_PAGE_SIZE             8192 //Size of pages in bytes
#define WIN_HANDLE_COUNT         16384 //Total number of open handles
#define WIN_THREAD_COUNT         32768 //Total number of threads
#define WIN_PROCESS_COUNT        65536 //Total number of processes
#define WIN_LIMIT_COMMIT        131072 //Physical memory plus page file size in byte
#define WIN_PERCENT_USED        262144 //Percentage of memory in use
