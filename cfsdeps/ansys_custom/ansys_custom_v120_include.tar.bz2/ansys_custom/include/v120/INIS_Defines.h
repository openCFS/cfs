/* sid 60.9 copy of INIS_Defines.h last changed by rjayasee on 2006/06/07 20:16:11 */
/* ---------------------------------------------------------------------- */
/* *** copyright(c) 2009 SAS IP, Inc.  All rights reserved. */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */

#include "ansys.h"

#if !defined(INIS_DEFINES_H)
#define INIS_DEFINES_H

/* Data Format */
#define INIS_DATAFORMAT            102
#define INIS_DATAFORMATVER101      101     

/* Header Information */
#define INIS_HEADERSIZE      10
#define INIS_DATAHEAD        6

/*Data Types*/
#define    LUNKNOWN       0
#define    LSTRAIN_T      1
#define    LSTRESS_T      2
#define    LSTRAINTH_T    3
#define    LSTRAINPL_T    4
#define    LEQPL_T        5
#define    LSTRAINCR_T    6
#define    LEQCR_T        7
#define    LISTRESS       8
#define    LBACKSTRES_T   9
#define    LSTATEV_T     10
#define    LEQSW_T       11
#define    LSTRAIN_DEAD  12
#define    LCOORDS_T     13
#define    LMISC_T       14
#define    LISTRAIN_T    15      
#define    LDEFGRAD_T    19
#define    LRESIST_T     20
#define    LMISP_RZMK    21
#define    LROTMATRIX    22
#define    LTHMSVAR_T    23
#define    LFLUSVAR_T    24
#define    LELWK         25
#define    LPLWK         26
#define    LCRWK         27
#define    LEPTO_T       28
#define    LPPRES_T      29
#define    LVOID_T       30
#define    LCSYS         31

#define INIS_UNKNOWN     0
#define INIS_MAXDATATYPES 31

/*Data Source*/
#define INIS_DSFROMFILE     1
#define INIS_DSFROMCOMMAND  2

/* Header Positions*/
#define INI_RECORDSIZEPOS 0
#define INI_DATAFORMATPOS 1    
#define INI_HEADERSIZEPOS 2
#define INI_ISMATBASEDPOS 3
#define INI_DATASOURCEPOS 8

#include "elempr.h"

const int MAT_NumMaterialRecords = 20 ;

#define NCOMPN 52

#define EL_MAT          1
#define EL_TYPE         2
#define EL_REAL         3
#define EL_SECT         4
#define EL_CSYS         5
#define EL_DEAD         6
#define EL_SOLID        7
#define EL_SHAPE        8
#define EL_OBJOPTIONS   9
#define EL_PEXCLUDE     10
#define EL_DIM          10

/*
#define INIS_NEW(x,y) (x*)cAnsMemAlloc(sizeof(x)*y,0,__FILE__,__LINE__)
#define INIS_DELETE(x) cAnsMemFree((x),__FILE__,__LINE__)
*/

#define INIS_MALLOC(x)  ANS_TagMemManagerMalloc((x),__FILE__,__LINE__)
#define INIS_FREE(x)  ANS_TagMemManagerFree((x),__FILE__,__LINE__)

#define INIS_NEW(x,y) (x*)ANS_TagMemManagerMalloc(sizeof(x)*y,__FILE__,__LINE__)
#define INIS_DELETE(x) ANS_TagMemManagerFree((x),__FILE__,__LINE__)


#endif
