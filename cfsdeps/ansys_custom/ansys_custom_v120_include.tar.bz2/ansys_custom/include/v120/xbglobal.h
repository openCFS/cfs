/*
 *    author/date: yu-hua ting/04-23-94
 *
 *    primary function:
 *
 *        header for the "global variables" definitions in the Ansys/Shapes Interface
 *
 *    secondary function:
 *
 *        none
 *
 *    routines included:
 *
 *        none
 *
 *    history
 *
 *        none
 *
 *    comments:
 *
 *        none
 *
 *    notice- these routines contain sasi confidential information ***
 *
 */
/* 
 * *** copyright(c) 2009 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */

/****************************************************************************
 *                                                                          *
 *                 Heap memory space layout                                 *
 *                                                                          *
 *                                                                          *
 *         starting offset 1    -> | <- source memory[0]                    *
 *                                 |                                        *
 *                                 |                                        *
 *                                 |                                        *
 *                                 |                                        *
 * beginning of the heap memory -> | <- top_ptr                             *
 *                                 |                                        *
 *                                 |                                        *
 *                                 | <- positive_ptr (move down)            *
 *                                 |                                        *
 *                                 |                                        *
 *                                 | <- negative_ptr (move up)              *
 *                                 |                                        *
 *                                 |                                        *
 *                                 |                                        *
 * beginning of the memory nodes ->| <- heap_nodes[MAX_NUM_OF_HEAPS]                *
 *                                 |                                        *
 *                                 |                                        *
 *                                 |                                        *
 * end of the heap memory       -> |                                        *
 *                                                                          *
 *                                                                          *
 ****************************************************************************/

#define DYNCOM_LENGTH 6

#if defined(RS6000_SYS) || defined(HP32_SYS) 

/*
 *    Fortran common blocks
 */

#define dyncom_ dyncom
/*#define stkcom_ stkcom*/  /* stkcom has been gutted at 5.5!! */
#define bolcmi_ bolcmi
#define bolcmd_ bolcmd
#define heapcm_ heapcm
#define berrcm_ berrcm
#define attrcm_ attrcm


#endif


/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/


#if defined(WATCOMC_SYS) \
    || defined(PCWINNT_SYS)

/*
 *    Fortran common blocks
 */

#define dyncom_ DYNCOM
/*#define stkcom_ STKCOM*/
#define bolcmi_ BOLCMI
#define bolcmd_ BOLCMD
#define heapcm_ HEAPCM
#define berrcm_ BERRCM
#define attrcm_ ATTRCM
 
#endif


      extern struct dyncom_type {
          PTR ansys_memory[DYNCOM_LENGTH];
      } CALLTYP dyncom_;

/*      extern struct stkcom_type {

          INT padding_begin_stkcom[39],
              ansys_stack_top,
              ansys_stack_bottom,
              ansys_stack_length,
              ansys_stack_positive,
              ansys_stack_negative;
 
      } CALLTYP stkcom_;
*/
 
 
      extern struct bolcmi_type {
        

        INT   shapes_release_20,

              boolean_memory_facility_is_on,
              timing_facility_is_on,
              shapes_log_facility_is_on,
              xax_log_facility_is_on, 

              ansys_allow_1_line_loops,
              ansys_allow_2_lines_loops,
              ansys_allow_1_area_shells,
              shapes_allow_1_line_loops,
              shapes_allow_2_lines_loops,
              shapes_allow_1_area_shells,
              shapes_split_1_line_loops,
              shapes_split_2_line_loops,
              shapes_split_1_area_shells,

              check_duplicate_sublines,
              check_duplicate_subareas,
              check_duplicate_subvolumes,

              shapes_detect_degeneracy,

              non_manifold_check_in_boolean,
              non_manifold_check_post_boolean,
              ansys_detect_non_manifolds,
              non_manifold_check_xsubarea,
              non_manifold_check_xsubvolume,

              print_scaling_information,
              default_scale_ansys_geometries,
              scale_ansys_geometries_on_line,
              scale_ansys_geometries,
              translate_ansys_geometries,

              change_boolean_tolerances,
              use_default_boolean_tolerances,

              do_not_copy_result_geom,
              do_not_perform_booleans,
              use_xgmoverlap_xax,
              separate_shapes_output_geoms,
              divide_underlying_geometry,
              set_shapes_to_ansys_link_null,

              new_attribute_info_is_available,
              mark_new_intersection_curve,

              point_attr_scratch_virtual,
              subline_attr_scratch_virtual,
              subarea_attr_scratch_virtual,
              subvolume_attr_scratch_virtual,

              point_attr_scratch_rec_size,
              subline_attr_scratch_rec_size,
              subarea_attr_scratch_rec_size,
              subvolume_attr_scratch_rec_size,

              subarea_dividing_table_max_size,
              subline_dividing_table_max_size,

	      xox_open_flag,
	      boolean_tol_relax,
              shapes_ansys_entity_numbering,
              simplify_geoms_for_addition,
              iges_pre_image,
              reuse_geoms_in_subtract_sepo,
              xadjust_tolerance,
              api_xx_debug,
	      padding_bolcmi[200];
      } CALLTYP bolcmi_;
 
      extern struct bolcmd_type {
      
        DOUBLE   scaling_lower_limit,
                 scaling_upper_limit,
                 center_ansys_geometries[3],
                 center_dist_ansys_geometries,
                 size_ansys_geometries[3],
                 max_size_ansys_geometries,
                 minimum_point_distance,
                 translation_ansys_geometries[3],
                 scaling_factor_ansys_geometries,

                 ansys_point_tolerance, 
                 ansys_problem_size,
                 ansys_approximation_tolerance,
                 ansys_knot_tolerance,
                 ansys_angle_tolerance,
 
		 padding_bolcmd[150],
		 pre_image_tolerance,
		 spare[29];
      } CALLTYP bolcmd_;
 

      extern struct heapcm_type {

        INT   boolean_heap_is_on,
              boolean_heap_tag,
              boolean_heap_max_num_nodes,
              boolean_heap_initial_size,

              attribute_heap_is_on,
              attribute_heap_tag,
              attribute_heap_max_num_nodes,
              attribute_heap_initial_size,
              attribute_heap_size, 

              attribute_memory_facility_is_on,

              attribute_stack_top,
              attribute_stack_bottom,
              attribute_stack_positive,
              attribute_stack_negative,

              xax_memory_id,
              att_memory_id,
              xox_memory_id,


              reset_ansys_address_alignments,
              check_malloc_address_alignments, 

              max_num_of_heaps,
              num_of_free_heaps,
              heap_in_use[MAX_NUM_OF_HEAPS],
              xheap_no_free_call[MAX_NUM_OF_HEAPS],
              xheap_check_memory_lists[MAX_NUM_OF_HEAPS],
              xheap_debug[MAX_NUM_OF_HEAPS],
              xheap_memory_facility_is_on[MAX_NUM_OF_HEAPS],
              xheap_memory_debug_pattern,
              xheap_debug_set_memory_header,
              xheap_debug_set_memory_malloc,
              xheap_debug_set_memory_free,
              xheap_debug_set_memory_pattern,
              xheap_debug_set_memory_sizes;

      } CALLTYP heapcm_;
 

      extern struct berrcm_type {

        INT   signal_handler_is_on,
              non_local_jumps_is_on,

              error_code_stack_size,
              error_code_stack_top,
              error_code_stack[100],

              global_warning_code,
              global_xox_warning_code,
              global_ansys_warning_code,
              global_xax_warning_code,

              global_error_code,
              global_xox_error_code,
              global_ansys_error_code,
              global_xax_error_code,

              shapes_print_error_messages,
              shapes_print_verbosity_level,
              shapes_print_stack_depth,
              shapes_warning_generation_mode,

              print_error_code_stack_element;

      } CALLTYP berrcm_;
 

 
      extern struct attrcm_type {
        

        INT   attribute_handler_is_on,
              userid_is_on,
              attribute_handler_debug_is_on,

              handler_for_cell_new_is_on,
              handler_for_cell_copy_is_on, 
              handler_for_cell_delete_is_on, 
              handler_for_cell_dissoc_is_on, 
              handler_for_cell_split_is_on, 
              handler_for_cell_imbed_is_on, 
              handler_for_cell_merge_is_on, 
              handler_for_frame_new_is_on, 
              handler_for_frame_copy_is_on, 
              handler_for_frame_delete_is_on, 
              handler_for_frame_dissoc_is_on;


      } CALLTYP attrcm_;

     
      static DOUBLE xox_time_begin1[XOX_DATA_LENGTH];
      static DOUBLE xox_time_end1[XOX_DATA_LENGTH]; 
      static DOUBLE xox_time_data1[XOX_DATA_LENGTH]; 
      static DOUBLE xox_time_begin2[XOX_DATA_LENGTH]; 
      static DOUBLE xox_time_end2[XOX_DATA_LENGTH]; 
      static DOUBLE xox_time_data2[XOX_DATA_LENGTH];  
 
      static INT xox_mem_begin1[XOX_DATA_LENGTH]; 
      static INT xox_mem_end1[XOX_DATA_LENGTH]; 
      static INT xox_mem_data1[XOX_DATA_LENGTH];  
      static INT xox_mem_begin2[XOX_DATA_LENGTH];  
      static INT xox_mem_end2[XOX_DATA_LENGTH];  
      static INT xox_mem_data2[XOX_DATA_LENGTH];   
 
      static INT xox_data_index;

      static DOUBLE shapes_default_tolerances[4];
      static DOUBLE shapes_current_tolerances[4];

      static INT shapes_release_20;

      static INT boolean_memory_facility_is_on;
      static INT timing_facility_is_on;
      static INT shapes_log_facility_is_on;
      static INT xax_log_facility_is_on;

      static INT ansys_allow_1_line_loops;
      static INT ansys_allow_2_lines_loops;
      static INT ansys_allow_1_area_shells;
      static INT shapes_allow_1_line_loops;
      static INT shapes_allow_2_lines_loops;
      static INT shapes_allow_1_area_shells;
      static INT shapes_split_1_line_loops;
      static INT shapes_split_2_line_loops;
      static INT shapes_split_1_area_shells;

      static INT check_duplicate_sublines;
      static INT check_duplicate_subareas;
      static INT check_duplicate_subvolumes;

      static INT shapes_detect_degeneracy;

      static INT non_manifold_check_in_boolean;
      static INT non_manifold_check_post_boolean;
      static INT ansys_detect_non_manifolds;
      static INT non_manifold_check_xsubarea;
      static INT non_manifold_check_xsubvolume;

      static INT print_scaling_information;
      static INT default_scale_ansys_geometries;
      static INT scale_ansys_geometries_on_line;
      static INT scale_ansys_geometries;
      static INT translate_ansys_geometries;

      static INT change_boolean_tolerances;
      static INT use_default_boolean_tolerances;

      static INT do_not_copy_result_geom;
      static INT do_not_perform_booleans;

      static INT use_xgmoverlap_xax;
      static INT separate_shapes_output_geoms;
      static INT divide_underlying_geometry;
      static INT set_shapes_to_ansys_link_null;

      static xGEOM_ID converting_shapes_geom_id;

      static INT new_attribute_info_is_available;
      static INT mark_new_intersection_curve;

      static INT point_attr_scratch_virtual;
      static INT subline_attr_scratch_virtual;
      static INT subarea_attr_scratch_virtual;
      static INT subvolume_attr_scratch_virtual;

      static INT point_attr_scratch_rec_size;
      static INT subline_attr_scratch_rec_size;
      static INT subarea_attr_scratch_rec_size;
      static INT subvolume_attr_scratch_rec_size;

      static xATTR_SPEC geom_attr_type_spec;
/* This jmp_buf causes an _iob linker error on Win64.  It isn't used anywhere.*/
#ifndef PCWIN64_SYS
      static JMP_BUF geom_attr_hndlr_long_jump_env;
#endif
      static INT attribute_handler_is_on;
      static INT userid_is_on;
      static INT attribute_handler_debug_is_on;

      static INT handler_for_cell_new_is_on;
      static INT handler_for_cell_copy_is_on; 
      static INT handler_for_cell_delete_is_on; 
      static INT handler_for_cell_dissoc_is_on; 
      static INT handler_for_cell_split_is_on; 
      static INT handler_for_cell_imbed_is_on; 
      static INT handler_for_cell_merge_is_on; 
      static INT handler_for_frame_new_is_on; 
      static INT handler_for_frame_copy_is_on; 
      static INT handler_for_frame_delete_is_on; 
      static INT handler_for_frame_dissoc_is_on;


      static INT num_of_call_cell_new_hndlr;
      static INT num_of_call_cell_copy_hndlr;
      static INT num_of_call_cell_delete_hndlr;
      static INT num_of_call_cell_dissoc_hndlr;
      static INT num_of_call_cell_split_hndlr;
      static INT num_of_call_cell_imbed_hndlr;
      static INT num_of_call_cell_merge_hndlr;

      static INT num_of_call_frame_new_hndlr;
      static INT num_of_call_frame_copy_hndlr;
      static INT num_of_call_frame_delete_hndlr;
      static INT num_of_call_frame_dissoc_hndlr;

      static DOUBLE    scaling_lower_limit;
      static DOUBLE    scaling_upper_limit;
      static DOUBLE    center_ansys_geometries[3];
      static DOUBLE    center_dist_ansys_geometries;
      static DOUBLE    size_ansys_geometries[3];
      static DOUBLE    max_size_ansys_geometries;
      static DOUBLE    minimum_point_distance;
      static DOUBLE    translation_ansys_geometries[3];
      static DOUBLE    scaling_factor_ansys_geometries;

      static DOUBLE    ansys_point_tolerance;
      static DOUBLE    ansys_problem_size;
      static DOUBLE    ansys_approximation_tolerance;
      static DOUBLE    ansys_knot_tolerance;
      static DOUBLE    ansys_angle_tolerance;

      static DOUBLE    shape_boolean_tolerances[4];

      static INT       boolean_heap_is_on;
      static INT       boolean_heap_tag;
      static INT       boolean_heap_max_num_nodes;
      static INT       boolean_heap_initial_size;

      static INT       attribute_heap_is_on;
      static INT       attribute_heap_tag;
      static INT       attribute_heap_max_num_nodes;
      static INT       attribute_heap_initial_size;
      static INT       attribute_heap_size;

      static INT       xax_memory_id;
      static INT       att_memory_id;
      static INT       xox_memory_id;

      static INT  signal_handler_is_on;
      static INT  non_local_jumps_is_on;


      static INT global_warning_code;
      static INT global_xox_warning_code;
      static INT global_ansys_warning_code;
      static INT global_xax_warning_code;

      static INT global_error_code;
      static INT global_xox_error_code;
      static INT global_ansys_error_code;
      static INT global_xax_error_code;

      static INT shapes_print_error_messages;
     
      static INT shapes_print_verbosity_level;
      static INT shapes_print_stack_depth;
      static INT shapes_warning_generation_mode;

      static INT print_error_code_stack_element;

      static INT do_not_check_duplicates_ansys;
      static INT do_not_check_duplicates_shapes;

      static xSTATUS xox_error_status;
 
      static INT xheap_method[MAX_NUM_OF_HEAPS];

      static INT xheap_initial_heap_size[MAX_NUM_OF_HEAPS];
      static INT xheap_num_bytes_in_int_word[MAX_NUM_OF_HEAPS];
      static INT xheap_num_ints_in_double_word[MAX_NUM_OF_HEAPS];
      static INT xheap_alignment_in_bytes[MAX_NUM_OF_HEAPS];
 
      static xaxADDR xheap_source_address[MAX_NUM_OF_HEAPS];
      static xaxADDR xheap_start_address[MAX_NUM_OF_HEAPS];
      static xaxADDR xheap_end_address[MAX_NUM_OF_HEAPS];
      static INT xheap_growing_direction[MAX_NUM_OF_HEAPS];
      static INT xheap_source_memory_size[MAX_NUM_OF_HEAPS];
      static INT xheap_size[MAX_NUM_OF_HEAPS];
      static INT xheap_initial_heap_offset[MAX_NUM_OF_HEAPS];

      static INT xheap_top[MAX_NUM_OF_HEAPS];
      static INT xheap_bottom[MAX_NUM_OF_HEAPS];

      static INT xheap_positive[MAX_NUM_OF_HEAPS];
      static INT xheap_negative[MAX_NUM_OF_HEAPS]; 

      static INT xheap_maximum_num_nodes[MAX_NUM_OF_HEAPS]; 
 

 

      static INT *xheap_nodes[MAX_NUM_OF_HEAPS];
      static INT xheap_num_nodes[MAX_NUM_OF_HEAPS];
      static INT xheap_head_nodep[MAX_NUM_OF_HEAPS];


      static INT xheap_free_memory_list_size[MAX_NUM_OF_HEAPS];
      static INT xheap_free_memory_list_headp[MAX_NUM_OF_HEAPS];
      static INT xheap_free_memory_list_tailp[MAX_NUM_OF_HEAPS];
      static INT xheap_free_memory_size[MAX_NUM_OF_HEAPS];
      static INT xheap_free_memory_total_size;
      static INT xheap_free_memory_max_size;

      static INT xheap_used_memory_list_size[MAX_NUM_OF_HEAPS];
      static INT xheap_used_memory_list_headp[MAX_NUM_OF_HEAPS];
      static INT xheap_used_memory_list_tailp[MAX_NUM_OF_HEAPS];
      
      static INT xheap_used_memory_size[MAX_NUM_OF_HEAPS];
      static INT xheap_active_used_memory_size[MAX_NUM_OF_HEAPS];
      static INT xheap_num_active_used_nodes[MAX_NUM_OF_HEAPS]; 

      static INT xheap_num_malloc_call[MAX_NUM_OF_HEAPS]; 
      static INT xheap_num_free_call[MAX_NUM_OF_HEAPS]; 
      static INT xheap_debug[MAX_NUM_OF_HEAPS];

      static struct {
         unsigned int set_memory_header  : 1;
         unsigned int set_memory_malloc  : 1;
         unsigned int set_memory_free    : 1;
         unsigned int set_memory_pattern : 1;
         unsigned int set_memory_sizes   : 1;
      } xheap_debug_option;

      static INT xheap_memory_debug_pattern;

      static INT xheap_debug_set_memory_header;
      static INT xheap_debug_set_memory_malloc;
      static INT xheap_debug_set_memory_free;
      static INT xheap_debug_set_memory_pattern;
      static INT xheap_debug_set_memory_sizes;


/*
 *    headers to ANSYS topological entity trees
 */
      static xaxTREE_PTR xtree_volumes;  
      static INT xtree_nvu;    
      static xaxTREE_PTR xtree_subvolumes; 
      static INT xtree_nsv;       
      static xaxTREE_PTR xtree_shells;   
      static INT xtree_nsh;   
      static xaxTREE_PTR xtree_areas;  
      static INT xtree_nar;  
      static xaxTREE_PTR xtree_subareas;  
      static INT xtree_nsa;  
      static xaxTREE_PTR xtree_loops; 
      static INT xtree_nlp;  
      static xaxTREE_PTR xtree_lines;  
      static INT xtree_nls;   
      static xaxTREE_PTR xtree_sublines; 
      static INT xtree_nsl;   
      static xaxTREE_PTR xtree_points; 
      static INT xtree_npt; 
/*
 *    headers to SHAPES topological entity trees
 */
      static xaxTREE_PTR xtree_xvolumes;  
      static INT xtree_xnvu;  
      static xaxTREE_PTR xtree_xsubvolumes; 
      static INT xtree_xnsv; 
      static xaxTREE_PTR xtree_xshells;   
      static INT xtree_xnsh;   
      static xaxTREE_PTR xtree_xareas;  
      static INT xtree_xnar;  
      static xaxTREE_PTR xtree_xsubareas;  
      static INT xtree_xnsa;     
      static xaxTREE_PTR xtree_xloops; 
      static INT xtree_xnlp;  
      static xaxTREE_PTR xtree_xlines; 
      static INT xtree_xnls;   
      static xaxTREE_PTR xtree_xsublines; 
      static INT xtree_xnsl;   
      static xaxTREE_PTR xtree_xpoints; 
      static INT xtree_xnpt;   

      static FILE *ansys_shapes_interface_log_fp; 
      static xCHAR *xox_error_message;
      static INT xox_error_message_length;

      static INT *subarea_dividing_child_table; 
      static INT *subarea_dividing_parent_table; 
      static INT  subarea_dividing_table_max_size;
      static INT  subarea_dividing_table_size; 

      static INT *subline_dividing_child_table; 
      static INT *subline_dividing_parent_table; 
      static INT  subline_dividing_table_max_size; 
      static INT  subline_dividing_table_size;  

      static INT  reuse_geoms_in_subtract_sepo;
      static INT  use_only_v2_as_the_search_key;

      xLONG xoxwindow;

      extern INT xvDetectNonManifoldP;
      extern xCHAR *xStatusGetFuncName();
      static INT api_xx_debug;
