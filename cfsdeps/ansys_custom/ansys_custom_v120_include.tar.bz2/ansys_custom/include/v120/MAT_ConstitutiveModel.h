////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         Copyright (C) 2009 ANSYS Inc.  All Rights Reserved             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MAT_ConstitutiveModel.h $
// $Revision: 1.3.2.1 $ 7.0
// $Date: 2009/04/13 14:09:59 $ March 28 2002
// $Author: jtm $ rjayasee/jlo
//
// Decription :
//
//	This class captures the Constitutive Model abstraction.
//  Each Constitutive Model can consist of multiple Constitutive Functions
//  like mooney, arruda boyce, linear elastic .... 
//  This corresponds to the MaterialModel in the MaterialGUI. MatID 1 ...
////////////////////////////////////////////////////////////////////////////// 

#if !defined(MAT_CONSTITUTIVEMODEL_H)
#define MAT_CONSTITUTIVEMODEL_H

#include "MAT_ExperimentalDataFormat.h"
#include "MAT_ExperimentalDataSet.h"

class MAT_ConstitutiveFunction ;

class MAT_ConstitutiveModel  
{
public:

	MAT_ConstitutiveModel();
    //Default constructor

    virtual ~MAT_ConstitutiveModel();
    //Destructor


    //*** Reconsider the Interface
    //*** Use a function to get the ConsFunction by ID. 0 - Max

	bool AddConstitutiveFunction( MAT_ConstitutiveFunction* cFuncPtr) ;
    //R-bool
    //R-false if the bad input like NULL ptr
    //I-Constitutive function pointer
    //R-Add a const function to the cons model

    MAT_ConstitutiveFunction* GetConstitutiveFunction( ANS_String const& oFName ) ;
    //R-MAT_ConstitutiveFunction*
    //R-NULL if none exists
    //I-name of the constitutive function.
    //R-Returns a Ptr to the Cons Function with the given name

    bool DeleteConstitutiveFunction( ANS_String const& oFName ) ;
    //R-bool
    //R-false if none exists
    //I-name of the constitutive function.
    //R-Deletes the Cons Function with the given name

    bool DeleteExperimentalData( INT iExpDataId ) ;
    //R-bool
    //I oFunctionName
    //I-Constitutive Function Name
    //I iExpDataId
    //I-Experimental Data ID
    //- Deletes an experimental Data object given a function name and an id

    void GetConstitutiveFunctionNameList( vector<const ANS_String*>& oConsFuncNameList ) ;
    //R void
    //O-oConsFuncNameList
    //O-Vector of Constitutive Function Names
    //- Returns a List of Constitutive Function Names

    bool GetExperimentalDataSet( MAT_ExperimentalDataSet *& pEDataSet ) ;
    //R-false if one does not exist
    //O-pEDataSet
    //O-Pointer to ExpData Set object
    //R-Gets a pointer to the experimental data set
    //R-ExperimentalData objects can be added to this

    void Print() ;
    // Prints All Data

private:

    vector<MAT_ConstitutiveFunction*> m_oConstitutiveModelVector ;
    //Contains a List of Constitutive Functions

    MAT_ExperimentalDataSet m_oExpDataSet ;
    // Can be empty

};

#endif // !defined(MAT_CONSTITUTIVEMODEL_H)
