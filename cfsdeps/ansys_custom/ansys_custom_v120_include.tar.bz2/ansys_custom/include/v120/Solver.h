/*****************************************************************************
 *                   Copyright (C) 1999 CMSoft                               *
 *                                                                           *
 *  These lines of code and declarations contain unpublished proprietary     *
 *  information of CMSoft. They may not be copied or duplicated in whole     *
 *  or part without prior authorization from CMSoft.                         *
 *                                                                           *
 *****************************************************************************/

#ifndef ASSEMBLED_SOLVER_H_
#define ASSEMBLED_SOLVER_H_

class FSVector;
class FSFullMatrix;
class FullSquareMatrix;
class FSRbm;

#include "GenSolver.h"

class FSAssembledSolver 
{
public:
  FSAssembledSolver(){}
  virtual ~FSAssembledSolver(){}
  
  // Returns the rigid body modes
  virtual FSRbm* getRBMs()=0;
  virtual int  numRBM()=0;
  
  // Returns the number of equations
  virtual int neqs()=0;
  
  // Overwrite the rhs vector with the solution
  virtual void solve(double *rhs)=0; 
  
  virtual void solve(double *rhs, double *solution)=0;
  virtual void solve(FSVector &rhs, FSVector &solution)=0;
  
  // Multiple rhs solve functions
  virtual void solve(int nRHS, double **RHS) = 0;  
  
  virtual void solve(FSFullMatrix &);
  
  virtual void factor()=0;
  virtual void parallelFactor() { factor(); }
  
  // Functions to assemble the solver
  virtual void add(FullSquareMatrix &kel, int *dofs) =0;
  virtual void add(FSFullMatrix &kel, int *dofs) =0;
  virtual void add(FSFullMatrix &knd, int fRow, int fCol)=0;
  
  // Find the diagonal
  virtual double diag(int dof)=0;
};

class NillSolver : public FSAssembledSolver {
  public:
   FSRbm* getRBMs() {return 0;}
   int  numRBM() { return 0; }
   int neqs() { return 0; }
};


#endif
