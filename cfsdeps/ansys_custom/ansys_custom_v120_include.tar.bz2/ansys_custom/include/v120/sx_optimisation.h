/* CADOE */
/**
 *	optimisation.h -- Fonctions de l'optimisation
 *   
 **/


#ifndef __OPTIMISATION_X_DEJA_INCLUS__
#define __OPTIMISATION_X_DEJA_INCLUS__ 1

#include "sx_CADOE_solver.h"
#include "ADOC_Session.h"

/*  extern int G_mise_a_jour_utile; */
/*  extern T_booleen G_sig_sortie; */

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/* Definition des fonctions en rapport avec initialisation du process */  
  /* extern T_statut OPT_lancer_optimisation(char*, char*, T_modele*,PAR*); (inutile) */
#ifdef __cplusplus
extern T_statut OPT_lancer_monte_carlo( C_AdocSession *, PAR *, PAR*, T_optim* );
extern T_statut OPT_lancer_gauss(  C_AdocSession *,PAR *, PAR*, T_optim* );

/* Definition des fonctions en rapport avec le Lagrangien augmente */
extern T_statut OPT_calcul_der_critere( C_AdocSession *,PAR * ,PAR*,T_optim *, int , int , int , double , VEC *, VEC *, MAT *,IVEC *, IVEC*, VEC *, VSTRUCT *);
extern int OPT_lancer_lagr_augm(C_AdocSession *,PAR *,PAR*,T_optim *); 

/* Definition des fonctions en rapport avec la methode de Monte-Carlo */
extern T_statut OPT_evaluer_point( C_AdocSession *,T_modele *,PAR *, PAR*, T_optim *, VEC *, VEC **, int *, IVEC*, VEC *, VSTRUCT *);
#endif

extern T_booleen OPT_point_est_admissible( T_optim*, VEC* );

/* */
extern void paruser2int( VEC *user_vec_param, VEC **vec_param, PAR*, PAR* );



/* Fonction qui prend la main en cas d'interruption */
extern void signal_sortie();

extern void* OPT_read( FILE *, void **, T_statut * );
extern T_statut OPT_write( FILE *, T_optim * );
extern void OPT_free( T_optim ** );

extern void* ROPT_read( FILE *vaf, void **vopt, T_statut *ier);
extern T_statut ROPT_write( FILE *vaf, T_res_optim *ropt);
extern void ROPT_liberer( T_res_optim *ropt);
extern T_res_optim* ROPT_allouer(void);

extern T_statut OPT_file_result( T_optim *opt, PAR *par_utilisateur, VEC *vec_param, int nb_shots, 
		 VEC *vec_contraintes, double meilleur_cout, float temps_cpu,
		 float temps_elapsed, E_OPT_status status);
extern T_statut OPT_file_gauss(  T_optim *opt, PAR *par_utilisateur, int nb_shots, 
		 VEC *moy, double fail, float temps_cpu,
		 float temps_elapsed, VEC **vp, MAT *cst );

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif	 /* __OPTIMISATION_X_DEJA_INCLUS__ */

