#ifndef _CORE_DOMAIN_H_
#define _CORE_DOMAIN_H_

/*****************************************************************************
 *                   Copyright (C) 1999 CMSoft                               *
 *                                                                           *
 *  These lines of code and declarations contain unpublished proprietary     *
 *  information of CMSoft. They may not be copied or duplicated in whole     *
 *  or part without prior authorization from CMSoft.                         *
 *                                                                           *
 *****************************************************************************/


#define MAXNUMDOFSPERELEM 500	  // TODO: what value??

#include <fstream>

class FSElement;
class FSCoordSet;
class FSConnectivity;
class FSSubDTopo;
class FSCommunicator;
class DofSetArray;
class DofSet;
template <class T> class FSCommPattern;
class BCond;
class FSSubDomCore;
class FSInfo;
class ConstrainedDSA;
class FSCommunicator;
class RectSparse;
class FSSubCornerHandler;

#include "cadoe_vector.h"
#include "FSConnectivity.h"
#include "Connectivity.h"
#include "C_ContactPair.h"
#include "C_Gmat.h"

class FSSubPreprocessor 
{
  int _glNumSub;		// total number of subdomains of the CPU
  int _glSubNum;		// the number of this subdomain in global numbering
  
  int _numNeighb, _numNeighbC;	// number of subdomains sharing at least one node with the current subdomain
  int *_neighbSubs;// global numbers of the neighbors
  int _nMasterEdges;
  int *_edgeNums;
  int *_sendID;			// send chanel numbers
  int *_recID;			// receive chanel numbers
  
  // node to node connectivity. ALWAYS in local numbering
  FSConnectivity *_nodeToNode;	// list of nodes of neighbour elements
  
  DofSetArray *_dsa;		// DOF set array
  ConstrainedDSA *_cdsa;	// Constrained DOF set array
  ConstrainedDSA *_ccdsa;	// Corner Constrained DOF set array
  
  // Additional corner information
  int _firstMasterCorner;
  int _numCorners;		// Number of corner nodes
  int (*_cornerNums)[2];	// list of corner nodes

  compStruct _cs;		// ??
  
  int _numSharedNode;		
  FSConnectivity *_sharedNodes;
  
  int _numSharedDofs;
  int _numSharedDofsC;
  int _sumSharedDofs;		// _numSharedDofs+_sumSharedDofs
  FSConnectivity *_sharedDofs;	// _numNeighb+_numNeighbC
  
  FSConnectivity *_nodeToSub;
  FSConnectivity *_subToNodeT;
  FSConnectivity *_subToNodeC;

  C_SubContactLagMgr &_subContactLagMgr;
  vector<C_CommTargetContact *> _listCommTargetContact;

  
  int _numInternalDofs;		// _ccdsa->size();
  
  int _glNumNodes;		// Total number of nodes iof the CPU
  int *_glToLocal;		// global to local node (dim = _glNumNodes)
  int _localNumNodes;		// Number of nodes of this domain
  int *_localNodes;		// local to global node (dim = _localNumNodes)
  int *_weightC;		// multiplicity of target/contact nodes
  int *_dofMulti;		// 
  int *_nodeMulti;		// multiplicity of each local node
  int _numElems;		// Number of elements of this domain
  
  FSElement **_elements;	// Nodes are 1st in global and then (after reNum) in local numbering
  FSCoordSet *_nodes;		// 
  
  // add CP/CEs to coarse problem
  int _numCE, *_glCENum, *_ceLen, **_ceNode, **_ceDofs;
  double **_ceCoefs, *_ceRHS;
  int _numCP;
  int *_glCPNum, *_cpNode;
  int *_cpDofs;
  
  // treat CP/CEs as LMPCs
  C_Gcpce *_Gcpce;
  int _numCEsLMPC;		
  
  // other Lagrange multipliers
  C_Gcpce *_GLMPC;
  int _numLMPC; 
  
  RectSparse *_coarseSparse;

  // Dirichlet boundary conditions
  int _nDBC;
  BCond *_dBC;
  
  // FS Information
  FSInfo *_fsInfo;

  int _nRotNodes;
  int *_rotNodes;
  double (*_nodeRot)[3];

public:
  FSSubPreprocessor(int subNum, int glNS,
		    int nEle, FSElement **ele, C_SubContactLagMgr &subContactLagMgr, 
		    C_Gcpce *Gcpce, FSInfo *fsInformation);
  ~FSSubPreprocessor();
  
  // have each subdomain create its comm table based on global connectivity
  // they also copy a pointer to the list of nodes of this sub
  void receiveComList(FSConnectivity *, FSConnectivity *, FSConnectivity *, FSConnectivity *);
  void setCommList(FSConnectivity *,  FSConnectivity *, 
		   FSConnectivity *, FSConnectivity *,
		   FSConnectivity *, int, int*);
  void makeContactCommList();
  void getCommIDs(FSSubDTopo *);
  void setDBC(int nbc, BCond *bc) 
  { 
    _nDBC = nbc; 
    _dBC = bc; 
  }
  void setLMPCs(C_Gcpce *GLMPC) 
  {
    _GLMPC = GLMPC;
    _numLMPC = (_GLMPC == NULL ? 0 : _GLMPC->getNbEqs());
  }
  void buildConnect();
  void buildDSAs();
  void getDofs(FSElement *, int *);
  void getDofs(int iElem, int *);
  FSConnectivity *getNodeToNode() {return _nodeToNode;}
  
  int subNum() { return _glSubNum; }
  
  void renumElemToLocal(int iElem);
  void renumAllToLocal();
  void makeDSAs();
  void setNodes(FSCoordSet *nds) { _nodes = nds; }

  void setNodeRot(int nr, int *nd, double (*rv)[3])
  { _nRotNodes = nr; _rotNodes = nd; _nodeRot = rv; }
  // This routine sets the corners. The first number in the array is the
  // local node number, the second is the global corner node number
  void setCorners(int fMaster, int nC, int (*)[2]);
  void countEdges(int *);
  void sendEdgeNums(FSCommPattern<int> *, int *);
  void getEdgeNums(FSCommPattern<int> *);
  
  // communication pattern related routines
  void setICommSize(FSCommPattern<int> *pt);
  void setDualCommSize(FSCommPattern<double> *pt);

  void sendSharedDofsets(FSCommPattern<int> *);
  void receiveSharedDofsets(FSCommPattern<int> *,
			    DofSet *crnDofs, int firstCP);
  
  void receiveNodeRot(FSCommunicator *communicator);

  FSSubDomCore *getSubCore();
  void makeLoad(DofSetArray *, double *, double *);
  void makeSLoad(int *offset, int *df, double *gF, double *locF);
  void makeAnsysLoad(double *gF, int dofPerNode, DofSet, double *locF);
  void unifyAnsysSol(double *gU, int dofPerNode, DofSet, double *locU);
     
  FSSubCornerHandler *getCornerHandler();
  void setCE(int n, int *glNum, int *len, int **nd, 
	     int **dofs, double **coefs, double *rhs) {
    _numCE = n;
    _glCENum = glNum;
    _ceLen = len;
    _ceNode = nd;
    _ceDofs = dofs;
    _ceCoefs = coefs;
    _ceRHS = rhs;
  }
  void setCP(int n, int *glNum, int *nd, int *dofs) {
    _numCP = n;
    _glCPNum = glNum;
    _cpNode = nd;
    _cpDofs = dofs;
  }
		
  friend class FSCoreCPUPreprocessor;
  friend class FSSlaveDomainPreprocessor;
  friend class FSSubDomCore;
};

#endif
