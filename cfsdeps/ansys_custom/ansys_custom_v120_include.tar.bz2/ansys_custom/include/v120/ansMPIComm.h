/*HFILE ansMPIComm.h                       ANSI_C                           sam
------------------------------------------------------------------------
------- Notice - This file contains ANSYS Confidential information
------------------------------------------------------------------------
*/

/*------------------------------ Description ---------------------------

\Author:    Sam Murgie

\Title:     Standard MPI C Header

\Desc:      Include standard MPI C header
            Also provides prototypes for ansMPIComm.c


            Currently contains the following MPI functions:

                   cansMPI_Init
                   cansMPI_BufferAttach
                   cansMPI_Finalize
                   cansMPI_Abort
                   cansMPI_ISend
                   cansMPI_CSend
                   cansMPI_DSend
                   cansMPI_IBufSend
                   cansMPI_DBufSend
                   cansMPI_IRecv
                   cansMPI_CRecv
                   cansMPI_DRecv
                   cansMPI_Immed_ISend
                   cansMPI_Immed_DSend
                   cansMPI_Immed_IRecv
                   cansMPI_Immed_DRecv
                   cansMPI_Bcast
                   cansMPI_ISum
                   cansMPI_DSum
                   cansMPI_IMax
                   cansMPI_IMin
                   cansMPI_DMax
                   cansMPI_DMin
                   cansMPI_Reduce
                   cansMPI_AllReduce
                   cansMPI_Probe
                   cansMPI_ProbeAny
                   cansMPI_Test
                   cansMPI_Wait
                   cansMPI_WaitAny
		   cansMPI_WaitAll
                   cansMPI_Request_Free
                   cansMPI_Synch
                   cansMPI_GetProcName
                   cansMPI_Inquire
                   cansMPI_Setup
                   cansMPI_disableCMPI

\History:   Created 5/1/03 (dc): Combined dpcg MPIComm.h and c_ampi_lib.h

\Function(s)
 -Primary:      Include standard MPI C header
 -Secondary:    Prototypes for cansMPICommm.c
 -External:     none
 -Internal:     none
 -Static:       thisCPU, numCPU

----------------------------------------------------------------------*/

#ifndef __ANSMPICOMM_H__
#define __ANSMPICOMM_H__ 1

/*------------------------------ Header files ------------------------*/

#ifdef USE_MPI
#ifdef RS6000_SYS
#  include "/usr/lpp/ppe.poe/include/mpi.h"
#else
#  include <mpi.h>
#endif
#endif

/*-------------------------------- Globals ---------------------------*/

#ifdef __cplusplus
  extern "C" {
#endif /* __cplusplus */

extern INT  numCPU;
extern INT  thisCPU;
extern INT  world;

extern INT  ANSMPI_MAX;
extern INT  ANSMPI_MIN;
extern INT  ANSMPI_SUM;
extern INT  ANSMPI_MAXLOC;
extern INT  ANSMPI_MINLOC;
extern INT  ANSMPI_BITAND;
extern INT  ANSMPI_BITOR;

extern INT  ANSMPI_INTEGER;
extern INT  ANSMPI_LONGINT;
extern INT  ANSMPI_DOUBLE;
extern INT  ANSMPI_CHARACTER;

extern INT  ANSMPI_REQUEST_NULL;
extern INT  ANSMPI_WORLD;

/*------------------------------ Prototypes --------------------------*/

void     cansMPI_Init(VOID);
void     cansMPI_BufferAttach(VOID);
void     cansMPI_Finalize(VOID);
void     cansMPI_Abort(VOID);

void     cansMPI_ISend(INT, INT, INT*, INT);
void     cansMPI_CSend(INT, INT, CHAR*, INT);
void     cansMPI_DSend(INT, INT, DOUBLE*, INT);
void     cansMPI_IBufSend(INT, INT, INT*, INT);
void     cansMPI_DBufSend(INT, INT, DOUBLE*, INT);

void     cansMPI_IRecv(INT, INT, INT*, INT*);
void     cansMPI_CRecv(INT, INT, CHAR*, INT*);
void     cansMPI_DRecv(INT, INT, DOUBLE*, INT*);

void     cansMPI_Immed_ISend(INT, INT, INT*, INT, PTR*);
void     cansMPI_Immed_DSend(INT, INT, DOUBLE*, INT, PTR*);

void     cansMPI_Immed_IRecv(INT, INT, INT*, INT, PTR*);
void     cansMPI_Immed_DRecv(INT, INT, DOUBLE*, INT, PTR*);

void     cansMPI_Bcast(void*, INT, INT, INT, INT);

void     cansMPI_ISum(INT, INT*);
void     cansMPI_DSum(INT, DOUBLE*);
void     cansMPI_IMax(INT, INT*);
void     cansMPI_IMin(INT, INT*);
void     cansMPI_DMax(INT, DOUBLE*);
void     cansMPI_DMin(INT, DOUBLE*);
void     cansMPI_Reduce(void*, void*, INT, INT, INT, INT, INT);
void     cansMPI_AllReduce(void*, void*, INT, INT, INT, INT);

INT      cansMPI_Probe(INT, INT);
INT      cansMPI_ProbeAny(INT*, INT);
INT      cansMPI_Test(PTR*);
void     cansMPI_Wait(PTR*);
INT      cansMPI_WaitAny(INT, PTR*);
void     cansMPI_WaitAll(INT, PTR*);
void     cansMPI_Request_Free(PTR*);
void     cansMPI_Synch(VOID);
void     cansMPI_GetProcName(char*, INT*);

INT      cansMPI_Inquire(INT);
PTR      cansMPI_GetParameter(INT);
void     cansMPI_Setup(INT, INT);
INT      cansMPI_disableCMPI(INT);

#ifdef __cplusplus
}
#endif /* __cplusplus */

/*--------------------------End of Prototypes ------------------------*/

/*---------------------------- End Of Module -------------------------*/

#endif
