/*
 *    author/date: yu-hua ting/12-03-93
 *
 *    primary function:
 *
 *                                                                   
 *         Header for "Database" routines which manipulate the database  
 *         which stores the topological entity pairs of ANSYS topologies 
 *         and SHAPES topologies for Ansys/Shapes Interface                                     
 *                                                               
 *
 *    secondary function:
 *
 *        none
 *
 *    routines included:
 *
 *
 *    history
 *
 *        none
 *
 *    comments:
 *
 *        none
 *
 *    Notice - This file contains ANSYS Confidential information ***
 *
 */
/* 
 * *** copyright(c) 2009 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */





/****************************************************************************
 *                                                                          *
 *    routines which manipulate the database which stores                   *
 *    the topological entity paira of ANSYS topologies and                  *
 *    SHAPES topologies                                                     *
 *                                                                          *
 ****************************************************************************/




/****************************************************************************
 *    Initialize the database                                               *
 ****************************************************************************/


      extern VOID xaxDbaseInit ansPROTO(());


/****************************************************************************
 *    Allocate memory for a tree node                                       *
 ****************************************************************************/


      extern xaxTREE_PTR xaxDbaseTreeNodeAlloc ansPROTO(());



/****************************************************************************
 *    Free the memory for a topological entity tree                         *
 ****************************************************************************/


      extern VOID xaxDbaseTreeNodeFree ansPROTO((
             xaxTREE_PTR xptr,
             INT     *iretp));

/****************************************************************************
 *    Free the memory for the database                                      *
 ****************************************************************************/

      extern VOID xaxDbaseFree ansPROTO((
             INT *iretp));

/****************************************************************************
 *    Compare 2 entity keys                                                 *
 ****************************************************************************/


      extern INT xaxDbaseKeyComp ansPROTO((
             xaxKEY *key1,
             xaxKEY *key2));

/****************************************************************************
 *    Search an entity in a topological entity tree                         *
 ****************************************************************************/

 
      extern VOID xaxDbaseSearchTree ansPROTO((
             xaxTREE_PTR *root,
             xaxKEY *num,
             xaxTREE_PTR *ptrc,
             xaxTREE_PTR *ptrf,
             INT *chtyp,
             INT *found)); 

 

/****************************************************************************
 *    Search a topological entity in the database                           *
 ****************************************************************************/


      extern VOID xaxDbaseSearch ansPROTO((
             xaxKEY *num, 
             INT entype,     
             xaxTREE_PTR *ptrc,  
             xaxTREE_PTR *ptrf,  
             INT *chtyp,  
             INT *found));
 

/****************************************************************************
 *    Insert a topological entity into a topological entity tree            *
 ****************************************************************************/


      extern VOID xaxDbaseInsertTree ansPROTO((
             xaxTREE_PTR *root, 
             xaxKEY *num,  
             xaxTREE_PTR *ptrc,  
             xaxTREE_PTR *ptrf,  
             INT *chtyp,  
             INT *iretp));


/****************************************************************************
 *    Insert a topological entity pair into the database                    *
 ****************************************************************************/


      extern VOID xaxDbaseInsert ansPROTO((
             INT entype, 
             xaxKEY *num, 
             xaxTREE_PTR *ptrc,  
             xaxTREE_PTR *ptrf,
             INT *chtyp,   
             xaxKEY *xnum,  
             xaxTREE_PTR *xptrc, 
             xaxTREE_PTR *xptrf, 
             INT *xchtyp,  
             INT *iretp)); 

 

/****************************************************************************
 *    Get the leftmost neighbor of a tree node in a binary tree             *
 ****************************************************************************/


      extern VOID xaxDbaseLeftMostNbr ansPROTO((
             xaxTREE_PTR *ptr, 
             xaxTREE_PTR *ptrl, 
             xaxTREE_PTR *ptrlf,
             INT *chtyp));   
 

/****************************************************************************
 *    Get the rightmost neighbor of a tree node in a binary tree            *
 ****************************************************************************/



      extern VOID xaxDbaseRightMostNbr ansPROTO((
             xaxTREE_PTR *ptr,
             xaxTREE_PTR *ptrr,
             xaxTREE_PTR *ptrrf,
             INT *chtyp)); 

 

/****************************************************************************
 *    Delete a topological entity from a topological entity tree            *
 ****************************************************************************/


      extern VOID xaxDbaseDeleteEntity ansPROTO((
             xaxTREE_PTR *root,
             xaxTREE_PTR *ptrc,
             xaxTREE_PTR *ptrf,
             INT *chtyp,
             INT *iretp));

 

/****************************************************************************
 *    Delete a topological entity pair from the database                    *
 ****************************************************************************/


      extern VOID xaxDbaseDeleteEntityPair ansPROTO((
             INT entype,    
             xaxTREE_PTR *ptrc,  
             xaxTREE_PTR *ptrf,  
             INT *chtyp, 
             xaxTREE_PTR *xptrc,   
             xaxTREE_PTR *xptrf,
             INT *xchtyp, 
             INT *iretp));


 

/****************************************************************************
 *    Delete the frame tree (loop tree, or shell tree) of an                *
 *    Ansys subentity (subarea, or subvolume)                               *
 ****************************************************************************/


      extern VOID xaxDbaseDeleteFrameTree ansPROTO((
             INT entyp,
             INT *sentn,    
             INT fmtree[],  
             INT *np,      
             INT *iretp));   
