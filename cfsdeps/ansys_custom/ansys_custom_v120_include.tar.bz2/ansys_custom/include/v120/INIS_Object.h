////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         copyright(c) 2009 SAS IP, Inc.  All rights reserved.             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: INIS_Object.h $
// $Revision: 1.5.2.1 $ 7.0
// $Date: 2009/04/10 15:33:12 $ October 04 2005
// $Author: jtm $ rjayasee
//
// Decription :
// Base Class for all initial state classes
//
////////////////////////////////////////////////////////////////////////////

#include "ANS_StandardIncludes.h"
#include "ANS_TagMemManager.h"
#include "INIS_Defines.h"

#ifndef INIS_OBJECT_H
#define INIS_OBJECT_H

class INIS_Object
{
    public:

    INIS_Object() {};
    //Constructor

    ~INIS_Object() {};
    //Destructor

    void * operator new(size_t iMemSize )
    {
        return INIS_MALLOC(iMemSize) ;
    }

    void * operator new[]( size_t iSize )
    {
        return INIS_MALLOC(iSize) ;
    }

    void operator delete(void * pMemPtr)
    {
            INIS_FREE(pMemPtr) ;
    }

    void operator delete[](void * pMemPtr )
    {
            INIS_FREE(pMemPtr) ;
    }

} ;

#endif
