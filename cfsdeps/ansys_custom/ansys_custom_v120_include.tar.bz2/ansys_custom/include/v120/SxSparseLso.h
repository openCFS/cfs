/**
 * @file   SxSparseLso.h
 * @author Frederic Thevenon
 * @date   Tue Feb 15 09:09:24 2005
 * 
 * @brief  
 * 
 * 
 */

#ifndef __SXSPARSELSO_H__
#define __SXSPARSELSO_H__ 1

#ifndef __cplusplus
#error "SxSparseLso.h must only be included by C++ files"
#endif

#define CHKIERM(ptr, ret)  \
if( !ptr) { CADOE_MSG(E_NoAvailableMemory,E_ERROR,E_PUBLIC); return (ret);}

#define CHKIERME(ptr)	CHKIERM( ptr, ECHEC)
#define CHKIERMN(ptr)	CHKIERM( ptr, NULL)

#define CHKIERMV(ptr) \
if( !ptr) { CADOE_MSG(E_NoAvailableMemory,E_ERROR,E_PUBLIC); return;}

#include "CadoeAnsys.h"
#include "blas_ansys.h"
#include "C_vstruct.h"


static char		notrans[2] = "N";
static int		notrans_len=2;
static double		d_un = 1., d_zero = 0.;
// static complex16_t	z_un = 1, z_zero = 0;
static int		inc_1 = 1;
static int		*adrinc = &inc_1;

/*!
 * \class	T_lso_buffer
 *  \brief	This object define a buffer of lines of the Sparse Matrix.
 *		
 *  \author	JDB-FT
 *  \version	1.0
 *  \date	2003-2005
 *  \bug	
 *  \warning	
 *
 *  \version 1.0 :       Initial Revision
 *
 *  \remark :	
 */


class T_lso_buffer
{
public :

  T_lso_buffer( int size, T_booleen alloc);
  virtual ~T_lso_buffer(void);

  int	Resize( int new_dim);
  
  virtual int	Write( int fic);
  virtual void	Print( FILE *fic);
  
  // ===== Members

  int dim, max_dim;
  Hyper adr_deb;
  int charge:2;
  int modified:2;
  int tampon:2;
  int label;
  double *values;
  int *index;
  int first_line, last_line;
  int first_nnz_line, last_nnz_line;
};

/*!
 * \class	T_lso
 *  \brief	This object define a line of the Sparse Symetric Matrix.
 *		
 *  \author	JDB-FT
 *  \version	1.0
 *  \date	2003-2005
 *  \bug	
 *  \warning	Only for symmetric matrices. The first term of the line
 *		must be the diagonal term.
 *
 *  \version 1.0 :       Initial Revision
 *
 *  \remark :	
 */

class T_lso
{
public:
  
  T_lso( int iirow = 0, int iindex = 0, int ilength = 0, bool isuppressed = false)
  {
    irow = iirow;
    index = iindex;
    length = ilength;
    suppressed = isuppressed;
    tampon = 0;
    indices = NULL;
    valeurs = NULL;
    buffer = NULL;
  }
  T_lso( T_lso &lin);

  virtual ~T_lso(void) { Release();}
  
  virtual inline void	Release( void)
  {
    if( !buffer && length>0) {
      if ( valeurs) LM_FREE(valeurs);
      if ( indices) LM_FREE(indices);
    }
  }
  
  virtual int	Flush( int fic, bool write);
  virtual int	Write( int fic);
  virtual int	Merge( T_lso *l2, IVEC *&tmpcol, VEC *&tmpv1, VEC *&tmpv2);

  int			Compact( double seuil, bool compact_buffer, IVEC *&compact);
  virtual inline int	GetOrder( void) const { return 0;}
  virtual inline void	SetOrder( int order) { return;}

  // inline virtual int FillValues( int &len, double &diag, int *cols, double *vals)

  /** 
   * Reorder terms of the line by sorting in column index ascending order
   * 
   * @param perm	temporary vector
   * @param tmpv1	temporary vector
   * 
   * @return		SUCCES/ECHEC
   */

  inline virtual int Reorder( PERM *&perm, VEC *&tmpv1);
  
  //@{
  // Methods to extract from global vectors values related to the current line

  inline void IndExtractLocalVector( int nbv, bool OnlyDiag, C_VSTRUCT<double>
				     &vin, double *vecloc);
  template <typename T> 
    inline void IndExtractLocalVector( int nbv, int sizev, T *vin, T *vecloc);

  inline void IndExtractLocalVector( int nbv, bool OnlyDiag, double **vin,
				     double *vecloc);

  template <typename T>
    inline void IndExtractLocalVector( T *vin, T *vecloc);

  template <typename T>
    inline void IndExtractLocalVectorSym( T *vin, T *vecloc);

  template <typename T> 
    inline void IndExtractLocalVectorSym(int nbv, int sizev,T coef, T *vin, T *vecloc);

  //@}

  //@{
  // Methods to Fill values from local to global vectors

  template <typename T> 
    inline void IndFillGlobalVectors( T *vecloc, int nbv, int sizev, T *vout);
  template <typename T> 
    inline void IndFillGlobalVectors2( T *vecloc, int nbv, int sizev, T *vout);
  
  template <typename T>
    inline void IndFillGlobalVectors( T *vecloc, T *vout);

  template <typename T>
    inline void IndFillGlobalVectorsUns( T *vecloc, int nbv, int sizev, T *vout);
  //@}
  
  inline void ExtractNodalIdx( C_VecPi<int> &BCStoANSdof, IVEC *NumDofBcs,
			       int *NodalIdx, int *OutIdx);
  inline void ExtractNodalIdx( IVEC *NumDofBcs, int *OutIdx);
  inline void NodExtractLocalVector( int nbv, int *NodalIdx, bool OnlyDiag,
				     C_VSTRUCT<double> &vin, double *vecloc);

  /** 
   * Product of a line by a set of vectors. The values of the input vectors
   * have been compacted before this operation. Output values are also stored 
   * in a compact format ( only required dofs).
   * 
   * @param MltPart	This line correpond to an active dof ?
   * @param OutIdx	Mapping between column numbers of the line and column 
   *			numbers in the output matrix ( coud be -1 if non active)
   * @param nbv		Number of input vectors
   * @param vecloc	Compact input values
   * @param vo		Compact output values
   */

  inline void MltSupport( bool &MltPart, int *OutIdx, int &nbv, double *vecloc,
			  C_MatMGe<double> &vo);
  
  template <typename T> inline void MvMlt( T *vi, T *vo);
  template <typename T> inline void MvMltUns( T *vi, T *vo);

  // ===== Input Vector is local, Output Vector is Local

  template <typename T> inline void MvMltLocal( T *vi, T *vo);

  inline void MmMlt( int nbv, double *vi, double **vo);
  template <typename T> inline void MmMlt( int nbv, T *vi, T *vo);
  template <typename T> inline void MmMltUns( int nbv, int size, T *viloc, T *vo);
  template <typename T> inline void MmMltUns( int nbv, T *viloc, T *voloc);

  // ===== Members ( Public for existing C functions)

  unsigned int irow;
  unsigned int index;
  unsigned int length;
  unsigned int suppressed:1;
  unsigned int tampon:1;
  int *indices;
  double *valeurs;
  T_lso_buffer *buffer;
};

int
T_lso::Reorder( PERM *&perm, VEC *&tmpv1)
{
  char	fctn[] = "T_lso::Reorder";
  int	j, ier(0);
  bool	NeedToReorder = false;
  
  for( j=1; j<length; j++)
    if ( indices[j] < indices[j-1])
      {
	NeedToReorder = true;
	break;
      }
  
  if (NeedToReorder)
    {
      IVEC dum;
      
      perm = LM_px_resize( perm, length, fctn, &ier);		CHKIERS;
      dum.dim = dum.max_dim = length;
      dum.ive = indices;
      (void)LM_iv_sort( &dum, perm, fctn, &ier);		CHKIERS;
      
      tmpv1 = LM_v_resize( tmpv1, length, fctn, &ier);		CHKIERS;
      
      for(j=0;j<length;j++)
	tmpv1->ve[j] = valeurs[perm->pe[j]];
      
      MEMCOPY( tmpv1->ve, valeurs, length, double);
    }
  
  return SUCCES;
}

void
T_lso::IndExtractLocalVector( int nbv, bool OnlyDiag, C_VSTRUCT<double> 
			      &vin, double *vecloc)
{
  vin.GetRow( irow, vecloc);
  
  if ( OnlyDiag) return;
  
  double	*ptrvecloc = vecloc + nbv;  
  int		*pos = indices+1;
  
  for( int jd=1; jd<length; jd++, pos++, ptrvecloc += nbv)
    vin.GetRow( *pos, ptrvecloc);
}

template <typename T> void
T_lso::IndExtractLocalVector( int nbv, int sizev, T*vin, T *vecloc)
{
  T	*ptrvecloc = vecloc;  
  int	*pos = indices;
  
  for( int jd=0; jd<length; jd++, pos++, ptrvecloc+=nbv)
    {
      int i2 = *pos;
      
      for( int iv=0; iv<nbv; iv++)
	ptrvecloc[iv] = vin[iv*sizev + i2];
    }
}

void
T_lso::IndExtractLocalVector( int nbv, bool OnlyDiag, double **vin,
			      double *vecloc)
{
  int	iv;
  
  for( iv=0; iv<nbv; iv++)
    vecloc[iv] = vin[iv][irow];
  
  if ( OnlyDiag) return;
  
  double	*ptrvecloc = vecloc + nbv;
  int		*pos = indices+1;
  
  for( int jd=1; jd<length; jd++, pos++, ptrvecloc+=nbv)
    {
      int	i2 = *pos;
	
      for( iv=0; iv<nbv; iv++)
	ptrvecloc[iv] = vin[iv][i2];
    }
}

template <typename T> void
T_lso::IndExtractLocalVector( T *vin, T *vecloc)
{
  int	*pos = indices;    
  for( int jd=0; jd<length; jd++, pos++)
    vecloc[jd] = vin[*pos];
}

template <typename T> void
T_lso::IndExtractLocalVectorSym( T *vin, T *vecloc)
{
  int prem(0);
  register int	*pos = indices, iv; 
  
  vecloc[0] = vin[irow];

  if (irow == *pos){prem++;pos++;}
  
  for( iv=prem; iv<length; iv++, pos++)
    vecloc[iv-prem+1] = vin[*pos];
}

template <typename T> void
T_lso::IndExtractLocalVectorSym(int nbv, int sizev,T coef, T *vin, T *vecloc)
{
  register int iv,jd;
  
  register T	*ptrvecloc = vecloc;  
  register int	*pos = indices;
    
  for(iv=0; iv<nbv; iv++)
      vecloc[iv] = vin[irow + iv * sizev] * coef;

  int nz_diag=(irow == *pos);
  if(nz_diag){ pos++;}

  for( int jd=0 + nz_diag; jd<length; jd++, pos++, ptrvecloc+=nbv){
      for( int iv=0; iv<nbv; iv++)
          vecloc[iv + ((1-nz_diag+jd) * nbv)] = vin[iv * sizev + *pos] * coef;
  }
}

template <typename T> void
T_lso::IndFillGlobalVectors( T *vecloc, int nbv, int sizev, T *vout)
{
  int	*pos = indices;
  
  for( int jd=0; jd<length; jd++, pos++)
    {
      T	*ptrout = vout + *pos;
	
      for( int iv=0; iv<nbv; iv++, ptrout+=sizev, vecloc++)
	*ptrout += *vecloc;
    }
}
template <typename T> void
T_lso::IndFillGlobalVectors2( T *vecloc, int nbv, int sizev, T *vout)
{
  for( int iv=0; iv<nbv; iv++, vout += sizev)	// vout is a copy of the calling ptr
    {
      int *pos = indices;
      for( int jd=0; jd<length; jd++, pos++, vecloc++)
	*(vout + *pos) += *vecloc;
    }
}

template <typename T> void
T_lso::IndFillGlobalVectors( T *vecloc, T *vout)
{
  int prem(0);
  register int *pos = indices;
  register T *pvec = vecloc;
    
  vout[irow] += *pvec;
  pvec++;

  if(irow == *pos){pos++;prem++;}
  
  for( int jd=prem; jd<length; jd++, pos++, pvec++)
    vout[*pos] += *pvec;
}

template <typename T> void
T_lso::IndFillGlobalVectorsUns( T *vecloc, int nbv, int sizev, T *vout)
{
  vout += irow;
  
  for( int jd=0; jd<nbv; jd++, vout += sizev)
    *vout = vecloc[jd];
}

void
T_lso::ExtractNodalIdx( C_VecPi<int> &BCStoANSdof, IVEC *NumDofBcs,
			int *NodalIdx, int *OutIdx)
{
  register int *pos = indices;
  
  for( int jd=0; jd<length; jd++, pos++) {
    NodalIdx[jd] = BCStoANSdof[*pos]-1;
    OutIdx[jd] = NumDofBcs->ive[*pos];
  }
}

void
T_lso::ExtractNodalIdx( IVEC *NumDofBcs, int *OutIdx)
{
  register int *pos = indices;
  
  for( int jd=0; jd<length; jd++, pos++) OutIdx[jd] = NumDofBcs->ive[*pos];
}

void
T_lso::NodExtractLocalVector( int nbv, int *NodalIdx, bool OnlyDiag,
			      C_VSTRUCT<double> &vin, double *vecloc)
{
  (void)vin.GetRow( *NodalIdx, vecloc);
  
  if ( OnlyDiag) return;

  NodalIdx++;
    
  double *ptrvecloc = vecloc + nbv;  
    
  for( int jd=1; jd<length; jd++, NodalIdx++, ptrvecloc += nbv)
    (void)vin.GetRow( *NodalIdx, ptrvecloc);
}

void
T_lso::MltSupport( bool &MltPart, int *OutIdx, int &nbv, double *vecloc,
		   C_MatMGe<double> &vo)
{
  register double *vm = valeurs+1;
  register double *vout = vo.Adr();
  register int *NumOut = OutIdx+1;
    
  for( int jd=1; jd<length; jd++, vm++, NumOut++)	// Lower triangle
    if ( *NumOut != -1)
      daxpy( &nbv, vm, vecloc, adrinc, vout + nbv*(*NumOut), adrinc);
    
  if ( MltPart) return;
    
  int len = (int)length;			// Upper triangle
  dgemv( CCHAR(notrans), &nbv, &len, &d_un, vecloc, &nbv, valeurs, adrinc,
	 &d_un, vout + nbv*OutIdx[0], adrinc CCHARL(notrans_len));
    
  return;
}

template <typename T> void
T_lso::MvMlt( T *vi, T *vo)
{
  int prem(0);
  register int *pos = indices;
  register T *pvi = vi;
  int  nz_diag = (*pos == irow);
  if (nz_diag){
     vo[irow] += valeurs[prem] * *pvi;
     pos++; prem++;
  }
  pvi++;
  
  for (register int jd=prem; jd <length; jd++,pos++,pvi++){
      
     //upper triangle
     vo[irow] += valeurs[jd] * *pvi;
        
     //lower triangle
     vo[*pos] += valeurs[jd] * vi[0];
  }


  return;  
}

template <typename T> void
T_lso::MvMltUns( T *vi, T *vo)
{
  int len = (int)length;
  vo[irow] += dot( len, valeurs, *adrinc, vi, *adrinc);
  
  return;  
}

template <typename T> void T_lso::MvMltLocal( T *vi, T *vo)
{
  register int  nz_diag = (*indices == irow);
  int prem(0);
  register T *pvi = vi;
  register T *pvo = vo;

  //diagonal terme
  if (nz_diag){
     vo[0] += valeurs[prem] * *pvi;
     prem++; 
  }
  pvi++;
  pvo++;
  for (register int jd=prem; jd <length; jd++,pvo++,pvi++){
     //upper triangle
     vo[0] += valeurs[jd] * *pvi;
        
     //lower triangle
     *pvo += valeurs[jd] * vi[0];
  }

  return;  
}

inline void
T_lso::MmMlt( int nbv, double *vi, double **vo)
{
  register int iv;
    
  // ===== Traitement du terme diagonal
    
  register double *vm = valeurs;
  for( iv=0; iv<nbv; iv++) vo[iv][irow] += (*vm) * vi[iv];
  vm++;
    
  register int *pos = indices + 1;
  register double *ptrvi = vi + nbv;

  for( int jd=1; jd<length; jd++,pos++,vm++,ptrvi+=nbv)
    {
      register double term = (*vm);
	
      for( iv=0; iv<nbv; iv++)
	{
	  vo[iv][irow] += term * ptrvi[iv];	// Upper triangle
	  vo[iv][*pos] += term * vi[iv];	// Lower triangle
	}
    }
    
  return;  
}

template <> inline void
T_lso::MmMlt( int nbv, double *vi, double *vo)
{
  int len = (int)length;
    
  // ===== Traitement du terme diagonal
    
  dgemv( CCHAR(notrans), &nbv, &len, &d_un, vi, &nbv, valeurs, adrinc,
	 &d_zero, vo, adrinc CCHARL(notrans_len));
  
  register double *vm = valeurs + 1; len--;
  dger( &nbv, &len, &d_un, vi, adrinc, vm, adrinc, vo+nbv, &nbv);
    
  return;  
}

template <> inline void
T_lso::MmMlt( int nbv, complex16_t *vi, complex16_t *vo)
{
  int len = (int)length;
  
  register int i,j;

  // ===== Traitement du terme diagonal
    
  double		*vm = valeurs;
  register complex16_t	*PtrVi = vi;

  for( j=0; j<len; j++, PtrVi += nbv, vm++)
    {
      double temp = *vm;
      if ( temp != 0.)
	{
	  for( i=0; i<nbv; i++)
	    vo[i] += temp*PtrVi[i];

	  if (j == 0) continue;

	  register complex16_t	*PtrVo = vo + j*nbv;

	  for( i=0; i<nbv; i++)
	    PtrVo[i] += vi[i]*temp;
	}
    }

  /*  
  for( j=0; j<len; j++, PtrVi += nbv, vm++)
    {
      double temp = *vm;
      if ( temp != 0.)
	{
	  for( i=0; i<nbv; i++)
	    vo[i] += temp*PtrVi[i];
	}
    }

  vm = valeurs + 1; len--;
  for( j=0; j<len; j++, vm++)
    {
      double temp = *vm;
      if ( temp != 0.)
	{
	  register complex16_t	*PtrVo = vo + (j+1)*nbv;

	  for( i=0; i<nbv; i++)
	    PtrVo[i] += vi[i]*temp;
	}
    }
  */
  
  return;  
}

template <typename T> inline void
T_lso::MmMltUns( int nbv, int size, T *viloc, T *vo)
{
  int len = (int)length;
  register int i, iv;

  for( i=0; i<len; i++)
    {
      double val = valeurs[i];
      T	*PtrVo = vo + irow;

      if ( val != 0.)
	for( iv=0; iv<nbv; iv++, PtrVo += size)
	  *PtrVo += val*viloc[iv];

      viloc += nbv;
    }
}

template <typename T> inline void 
T_lso::MmMltUns( int nbv, T *viloc, T *voloc)
{
  int len = (int)length;

  static char nt = 'N';
  static T t_un = 1, t_zero = 0;

  gemv( nt, nbv, len, t_un, viloc, nbv, valeurs, 1, t_zero, voloc, 1);
}

#endif // __SXSPARSELSO_H__
