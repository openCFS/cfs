
/*
////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         copyright(c) 2009 SAS IP, Inc.  All rights reserved.             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MAT_TBMetaDataQueryEngine.h $
// $Revision: 1.10.2.1 $ 7.0
// $Date: 2009/04/10 15:33:12 $ Feb 9 2005
// $Author: jtm $ rjayasee
//
// Decription :
//
//	Query Information about TB Material Data
//
//////////////////////////////////////////////////////////////////////////////
*/

#if !defined(MAT_TBMetaDataQueryEngine_H)
#define MAT_TBMetaDataQueryEngine_H

#include "ANS_StandardIncludes.h"
#include "FLD_Defines.h"

class MAT_TbOptMetaData
{
    public:

    MAT_TbOptMetaData()
    {
        m_oTbOptName = "" ;
        for ( INT iI = 0; iI < FLD_TBHEADERSZ; iI++ ) m_iTbHead[iI] = 0 ;
    }

    ANS_String m_oTbOptName ;
	ANS_String m_oTbOptPrintName ;
    INT m_iTbHead[FLD_TBHEADERSZ] ;
} ;

typedef map<INT,MAT_TbOptMetaData*> MAT_TbOptMetaDataMap;
typedef MAT_TbOptMetaDataMap::iterator MAT_TbOptMetaDataMapIter ;

class MAT_TbTypeMetaData
{
    public:

    MAT_TbTypeMetaData()
    {
        m_oTbOptData = NULL ;
        m_iTbType = 0 ;
		m_iDefTbOpt = 1 ;
    }

    ~MAT_TbTypeMetaData()
    {
        if ( m_oTbOptData != NULL ) delete m_oTbOptData ;
        m_oTbOptData = NULL ;
        m_iTbType = 0 ;
    }

    INT m_iTbType ;
    //Tb Type

	INT m_iDefTbOpt ;
	//Default TB Opt

    MAT_TbOptMetaDataMap* m_oTbOptData ;
    //Information about available Tb Opts
} ;



typedef map<ANS_String,MAT_TbTypeMetaData*> MAT_TbMetaDataStringMap;
typedef MAT_TbMetaDataStringMap::iterator MAT_TbMetaDataStringMapIter ;
typedef MAT_TbMetaDataStringMap::value_type MAT_TbMetaDataStringMapVT ;

class MAT_TBMetaDataQueryEngine
{
    public:

        static MAT_TBMetaDataQueryEngine* Instance() ;
        //Singleton

        static void Destroy() ;
        //Singleton

        // INT GetTbOpt( ANS_String& oClassOfMat, ANS_String& oTbOptName ) const;

        INT GetTbType( ANS_String& oClassOfMat ) const;
        //R TBTYP
        //I oClassOfMat
        //I Class of Material
        //- Return the TBTYP integer associated with this class

        ANS_String GetTbName( INT iTbTyp ) const;
        //R TBTYP String
        //I iTbTyp
        //I Class of Material
        //- Return the TBTYP string associated with the integer

        ANS_String GetTbOptName( ANS_String& oClassOfMat, INT& iTbOpt) const;
        //R String
        //I oClassOfMat
        //I iTbOpt
        //- Return the string associated with the tbopt

        ANS_String GetTbOptPrintName( ANS_String& oClassOfMat, INT& iTbOpt) const;
        //R String
        //I oClassOfMat
        //I iTbOpt
        //- Return the string used for printing associated with the tbopt

		INT GetTbOpt( ANS_String oClassOfMat, ANS_String oTbOpt ) const ;
        //I Integer Equivalent of TBOPT string
        //R String
        //I oClassOfMat
        //I iTbOpt
        //- Return the string associated with the tbopt

        ANS_String GetTbOptMetaData( ANS_String oClassOfMat, INT iTbOpt,
                                     INT* pTbHead ) const;
        //R String
        //I oClassOfMat
        //- Class of Material
        //I iTbOpt
        //- Tb Option
        //O pTbHead
        //O-TB Properties
        //- Return the string associated with the tbopt and its properties

        INT GetOrderGivenNumCoeffs( ANS_String oClassOfMat, INT iTbOpt, INT iNumCoeffs) const;
        //R String
        //I oClassOfMat
        //I iTbOpt
        //- Return the order associated with the tbopt


        bool IsSupportedClass( ANS_String oClassName) ;
        //R
        //I oClassName
        //I-Name of the class of materials
        //- Is supported class of materials

    protected:

        MAT_TBMetaDataQueryEngine();
        //Constructor

        ~MAT_TBMetaDataQueryEngine();
        //Destructor

        void Initialize() ;
        //Initializing Classes

        bool AddNewMaterialClass(ANS_String oClass, INT iTbTyp ) ;
        //R Result
        //I oClassName
        //I iTbTyp
        //I-Integer associated with this Name

        bool AddTbOptForMaterialClass(ANS_String oClass, INT iTbOpt, 
                                      ANS_String oTbOptName, 
									  ANS_String oTbOptPrintName = "" ,
									  INT* pTbHead = NULL ) ;
        //R Result
        //I oClassName
        //I-Class of Material
        //I iTbOpt
        //I-Id of tbopt
        //I oTbOptName
        //I-String Attached to the TbOpt

        static MAT_TBMetaDataQueryEngine* m_pMAT_TBMetaDataQueryEngine ;
        //Static object

        MAT_TbMetaDataStringMap* m_pMaterialMetaData ;
} ;

#endif
