/* CADOE */
/**
 *	adr_res.h
 *
 *  |Version: $Id: sx_adr_res.h,v 1.1.6.1 2009/04/13 14:10:00 jtm Exp $
 *   
 * HISTORY
 *   
 *   09/25/00 10:39 <       Brian Jantzen> Rel:ms8m1    SCCA:79107  Delta:81.2
 *   
 *   02/15/00 12:22 <       Brian Jantzen> Rel:ms8      SCCA:68558  Delta:8.3
 *   
 *   09/30/99 17:38 <         James Silva> Rel:ms8      SCCA:56512  Delta:8.2
 **/


#ifndef __ADR_RES_X_DEJA_INCLUS__
#define __ADR_RES_X_DEJA_INCLUS__ 1

#include "sx_CADOE_solver.h"
#include "sx_element.h"
#include "C_VecP.h"

#ifdef __cplusplus

class C_adr_bloc_res{
 public:
  C_adr_bloc_res(const string nom = "dummy") 
    {
      name = nom;
      nature = (E_resultat_parametre) 0;
      dim = 0;
      cas_charge = 0;
      support = NULL;
      taille = NULL;
      position = NULL;
      _isSecondaryResult = false;
    };
  virtual ~C_adr_bloc_res() {
    if( taille ) IV_FREE(taille);
    if( position ) IV_FREE(position);
    // we don't free support, done in C_adr_res destructor
  };
  
  int		get_pos_bloc() {return position->ive[0];};
  int		cpt_res() {return dim;}
  
  virtual IVEC	*getListElem() {return NULL;}
  virtual VEC	*getValeurs() {return NULL;}
  virtual const char  *getName() {return name.c_str();}
  T_statut	affNorm();
  bool		isSecondaryResult() {return _isSecondaryResult;};
  
  int		fillResults(C_VecP<double>&VecToFill, VEC *U, VEC *reac, bool fromRstFile);
  virtual int	fillResults(VEC *VecToFill, VEC *U, VEC *reac, bool fromRstFile) {return ECHEC;}
  virtual int   readFromAnsys(VEC *) {return ECHEC;};
  
  virtual int allocate() {return SUCCES;};
  virtual int buildListElem(T_modele *modele) {return SUCCES;};
  virtual int fillListElemToDerive(IVEC *list_elem_to_derive, int ie) {return SUCCES;};

public:
  E_resultat_parametre nature;		// Result type
  IntegerAdr dim;			// length of the group
  int cas_charge;			// load set
  T_groupe *support;			// Group of nodes or elements
  IVEC *taille;				// Size per node or element
  IVEC *position;			// Location in the result vector
  bool _isSecondaryResult;
  string name;
};

class C_adr_res{
 public:
  C_adr_res();
  C_adr_res(T_modele *);
  virtual ~C_adr_res();
  
  virtual void 	release();
  virtual C_adr_bloc_res *new_C_adr_bloc_res(E_resultat_parametre);
  void		assign(C_adr_res*);
  int		getNbBlocRes() {return nb_bloc_res;}
  C_adr_bloc_res *getBlocRes(int ib) {return bloc_res[ib];}
  IntegerAdr	getDim() {return dim;};
  int		getCptRes( E_resultat_parametre );
  int		getPosBloc( E_resultat_parametre );
  IntegerAdr	getTailleBloc( E_resultat_parametre );
  C_adr_bloc_res *getBlocByNature( E_resultat_parametre );
  int		sizeOfSecondaryResults();
  int		sizeOfPrimaryResults();
  C_adr_bloc_res* getPrimaryResult();
  
public :
  int nb_bloc_res;		// Nombre de blocs de resultats
  int taille_type_res;		// TAILLE_TYPE_RES au moment de la creation de l'adr_res (pour compatibilite versions)
  IntegerAdr dim;		// length of the group
  T_modele *modele;		// Associtated model
  C_adr_bloc_res **bloc_res; 	// Adressage des differents blocs
  IVEC *adresse_bloc;           // adresses dans le tableau RES par nature et par cas de charge
};

C_adr_res* ADR_allouer( T_modele *modele, T_statut *ier );
T_statut ADR_creer_adressage_RES( T_modele*, IVEC* , int*, C_adr_res**, int );
T_statut ADR_ecrire( T_modele *modele, C_adr_res *adr_res );
T_statut ADB_creer_adressage_bloc( T_modele*, T_groupe*, T_groupe*, E_resultat_parametre, IntegerAdr*, C_adr_bloc_res** );
IntegerAdr ADR_adresse_bloc( C_adr_res*, E_resultat_parametre, int );
IntegerAdr ADR_taille_bloc( C_adr_res*, E_resultat_parametre );
int ADR_indice_bloc( C_adr_res*, E_resultat_parametre, int );
void ADR_liberer( C_adr_res ** );
T_statut ADB_bloc_boutput(  FILE *fichier, C_adr_bloc_res *adrbloc);
C_adr_bloc_res *ADB_bloc_binput( FILE *fichier, C_adr_res *adr_res, T_statut *ier);
T_statut ADR_boutput(  FILE *fichier, C_adr_res *adrres);
C_adr_res *ADR_binput( FILE *fichier, void**, T_statut *ier);
int ADR_cpt_res( C_adr_res *adrres, E_resultat_parametre eRes );
int ADR_get_pos_bloc( C_adr_res *adrres, E_resultat_parametre eRes );
C_adr_bloc_res *ADR_get_bloc_by_nature( C_adr_res *adrres, E_resultat_parametre eRes );

#endif

#endif	 /* __ADR_RES_X_DEJA_INCLUS__ */
