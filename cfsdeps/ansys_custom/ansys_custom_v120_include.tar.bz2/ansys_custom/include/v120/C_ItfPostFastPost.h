/*******************************************************************************
 *
 *   C_ItfPostFastPost.h -- Interface post - solver
 *              
 * |Module: SolutionXplorer
 *
 * |Description: this class defines the methods used by ADOC to evaluate the solution.
 *               A socket connection is created with the solver and data can be 
 *               send and received.
 *        
 * |Auteur: Emmanuel DELOR
 *
 * |Creation: juin 2004
 *
 * |Version: 
 *
 * |Copyright:	copyright(c) 2009 SAS IP, Inc.  All rights reserved.
 *
 *   
 ******************************************************************************/

#ifndef __C_ItfPostFastPost_h__ 
#define __C_ItfPostFastPost_h__ 

#include "CC_Ansys.h"
#include "C_ParamFast.h"

class C_ItfPostFastPost
  : public C_ItfPostFast<double>
{
public:
  
  typedef enum {
    E_COMM_UNKNOWN = 0,
    E_COMM_RECV = 1,
    E_COMM_SEND = 2,
    E_COMM_SENDANDRECV = 3,
  } CommunicationMode;
  
  C_ItfPostFastPost( const char *objname, C_AdocSession *Session = NULL,
		     const _TCHAR * cFileName = NULL /* file.rsx */,
		     const _TCHAR * cJobName = NULL /* file.db */);
  ~C_ItfPostFastPost();
  
  void	   setCommunicationMode(CommunicationMode mode) {m_CommunicationMode = mode;}
  CommunicationMode getCommunicationMode() {return m_CommunicationMode;};
  
  T_statut initializeConnection(const int iNumPort = -1, CC_AnsysClient *customAnsys=NULL, CC_AnsysClient *customCadoe=NULL );
  bool     isConnected() {return m_isConnected;};
  T_statut initEvaluate(const BVEC *tab_indice);
  T_statut evalUtilde( C_VecP<double> &vparam, const BVEC *tab_indice, C_VecP<double> &solProj) {return ECHEC;}
  T_statut evalUtilde( C_VecP<double> &vparam, const IVEC *tab_indice, C_VecP<double> &solProj) {return ECHEC;}
  T_statut endEvaluate();

  T_statut sendVecParam(C_VecP<double> &vparam);
  T_statut evalSol( C_VecP<double> &vparam, const BVEC *tabindice, C_VecP<double> &Sol);
  T_statut receiveSolution(C_VecP<double> &Sol);
  
  T_statut sendOptionInteger( const char *intitule, int ival);
  T_statut sendOptionDouble( const char *intitule, double dbval);
  T_statut sendOptions( const map<string,string> &options );
  T_statut sendOption( const char *optionName, const char *optionValue );
  
 private:
  _TCHAR		m_cFileName[CADOE_FILENAMEMAX];	/* rsx file */
  _TCHAR		m_cJobName[CADOE_NAMESIZE];	/* job name (.db file) */
  _TCHAR		m_cDirName[SX_DIRNAMESIZE];
  char 			m_cCommand[SX_COMMANDSIZE];
  bool                  m_isConnected;
  CommunicationMode    	m_CommunicationMode;
  
  CC_AnsysClient *m_pCadoe; // cadoe protocol client
  bool bCustomCadoeClient; // true means that m_pCadoe is an external pointer not to delete!
  CC_AnsysClient *m_pAnsys; // standard ANSYS commands protocol client
  bool bCustomAnsysClient; // true means that m_pAnsys is an external pointer not to delete!
};

#endif
