/*****************************************************************************
 *                   Copyright (C) 1999 CMSoft                               *
 *                                                                           *
 *  These lines of code and declarations contain unpublished proprietary     *
 *  information of CMSoft. They may not be copied or duplicated in whole     *
 *  or part without prior authorization from CMSoft.                         *
 *                                                                           *
 *****************************************************************************/
#ifndef _FS_FSOLVER_H_
#define _FS_FSOLVER_H_

#include "FSVector.h"
#include "DistInfo.h"
#include "DistVector.h"
#include "FullSquareMatrix.h"
#include "C_SolverDirect.h"
// #include "C_SubStructBcsEngine.h"
#include "C_MatSp.h"
#include "C_MatMGe.h"
#include "C_vstruct.h"
#include "FSInfo.h"
#include "FSConnectivity.h"
#include "C_Gmat.h"
#include "C_SolverIter.h"

class FSAssembledSolver;
class FSOperator;
class FSVector;
class FSFullMatrix;
class FSRbm;
class FSFullSquareAssmblMat;
class RectSparse;
class MultiSparse;
class DofSet;
class FSCoordSet;
class FSSkyMatrix;

template<class T>
class FSCommPattern;
class DofSetArray;
class ConstrainedDSA;
class FSCoreCPUPreprocessor;
class OrthoSet;
class KrylovSet;
class FSSubPreprocessor;
class FSSubDTopo;
class EqNumberer;
class FSInfo;
class C_Gmat;
class C_CElement;
class C_CommTargetContact;
class C_SubContactLagMgr;

class FSDualNorm
{
public:
  FSDualNorm(multimap<int,int> &pairs, vector <C_ContactPair *> &cPairs);
  FSDualNorm(FSDualNorm &);
  ~FSDualNorm();
  
  void fillDualNorm(int subI, int subJ, double norm) ;
  void fillDualCNorm(C_ContactPair *cPair, double norm);
  void fillDualRNorm(double norm);
  void fillDualSNorm(double norm);
  void Print();
  
  void CsvInit(FILE *fp);
  void CsvAppend(FILE *fp);
  
  FSDualNorm& operator = (FSDualNorm &dualNorm);
  FSDualNorm& operator /= (FSDualNorm &dualNorm);
  
protected:
  // perfect interfaces
  multimap<int,int> &_pairs;
  double *_normDual;
  
  // contact interfaces (only Pure Lagrange ones)
  vector <C_ContactPair *> _cPairs;
  double *_normDualC;		// norm of contact pairs
  double _normDualR;		// norm external coupling equations
  double _normDualS;		// norm internal coupling equations
};

class C_CsvFile
{
public:
  C_CsvFile(string nameFile, bool append)
  {
    _fp = fopen(nameFile.c_str(),(append ? "a" : "w"));
  }
  
  ~C_CsvFile()
  {
    if (_fp) fclose(_fp);
  }
  
  void Init(FSDualNorm &drStar)
  {
    fprintf(_fp, "%s\t%s\t%s\t%s\t%s\t", "iter", "errRes", "errDual", "ur", "uc");
    drStar.CsvInit(_fp);
    fprintf(_fp, "\n");
    Append(-1,0.,0.,drStar,0.,0.);
  }
  
  void Append(int iter, double errRes, double errDual, FSDualNorm &dualErr, double normUr, double normUc)
  {
    fprintf(_fp, "%d\t%e\t%e\t%e\t%e\t", iter, errRes, errDual, normUr, normUc);
    dualErr.CsvAppend(_fp);
    fprintf(_fp, "\n");
    fflush(_fp);
  }
  
protected:
  FILE *_fp;
};

/*****************************************************************************
   The FSSubDomCore is the class that keeps the core SubDomain data that
   are necessary for the Feti algorithm. It contains:
      kSolver -> the solver capable of applying K^-1 to a vector defined
      over all of the subdomain DOFs.

   the preconditionner data:
     Kbb -> the preconditionner operator works only on boundary DOFs

*****************************************************************************/
class FSSubDomCore
{
  int _glSubNum;
  FSInfo *_fsInfo;
  
  bool _isFactorized;
  
  DofSetArray *_dsa;
  ConstrainedDSA *_cdsa;
  ConstrainedDSA *_ccdsa;
  RectSparse *_coarseSparse;
  
  int *_localNodes;
  int _isDirichlet;
  
  bool _isLinear;		// is the math-domain linear?
  bool _isPenalty;		// is there penalty in this domain?
  bool _unsym;			// is the math-domain non-symmetric?
  bool _singular;		// true if contain MPC184, MASS21, ...

  // solvers for Krr
  C_MatSp<double> _KrrSp;
  C_AnsysSolver <C_MatSp<double> > *_KrrSolver;
  FSSkyMatrix *_KrrSolverSky;
  FSSkyMatrix *_KiiSolverSky;
  
  // iterative solver for Krr
  C_MatSp<double> _KrrDiag;
  C_ItfSolverIter<C_MatSp<double> > *_itfSolverIter;
  C_AnsysBoeing<C_MatSp<double> > *_preCondIter;
  
  // the operator between corner and remainder
  RectSparse *_Krc;
  MultiSparse *_Krcs;

  // dual dual stiffness
  FSOperator  *_Kbb;
  
  // _KiiSolver and _Kib are defined only for Dirichlet preconditioner
  C_MatSp<double> _KiiSp;
  C_AnsysSolver <C_MatSp<double> > *_KiiSolver;
  FSOperator *_Kib;
  
  // Matrices associated with the coarse problem
  FSFullMatrix *_Krrm1Krc;
  
  C_MatMGe<double> _BrKrrm1Krc;
  C_MatSp<double> _Br;
  C_MatSp<double> _BrBrtDualC;
  C_MatSp<double> _BrBrtDualR;
  C_MatSp<double> _BrBrtDualS;
  
  // coarse problem
  FSFullSquareAssmblMat *_Kcc;
  FSFullSquareAssmblMat *_KccStar;
  
  int _halfOffset;		// half interface offset for this sub
  int _masterDualOffset;
  
  int _fCorner;
  int _numCorners;		// Number of corner nodes
  int (*_cornerNums)[2];	// List of corner nodes (first indice is local, second is global)
  int _nMasterEdges;
  int *_edgeNums;
       
  int _nInternalDofs;		// Number of internal dofs with a weight=1 (DOFS which are not corner, not boundary, not imposed), (RemDOFs with weight==1), _internalDofs[]
  int _nDual;			// Number of dual variables
  int _nDualC;			// Number of contact variables
  int _nDualR;			// Number of linear relations (CP/CEs)
  int _nDualS;			// Number of linear relations (CP/CEs)
  int _nCoarseDofs;		// cdsa->size() - ccdsa->size() + _coarseSparse->numConstrained + CEs;
  int _nRemDofs;		// ccdsa->size()

  int _nbBoundC;                // number of remainer DOFs which belong to contact/target nodes
  int *_globalBoundaryMap;
  int *_globalInternalMap;
  
  // number of neighboring subdomains
  int _numNeighb, _numNeighbC; 
  int *_neighbSubs;
  int *_sendID, *_recID;
  
  int *_dofMulti;
  FSConnectivity *_dualDofs;	// contain the interface & contact lagrangians
  vector<C_CommTargetContact *> &_listCommTargetContact;
  C_Gcpce *_Gcpce;
  C_Gcpce *_GLMPC;
  
  double *_dualWeight;
  double *_dualScale;
  int *_weightC;		// multiplicity of contact/target nodes (dim=_nRemDofs)
  
  // boundK is the assembled stiffness diagonal of the boundary
  double *_boundK;

  // unique list of dofs on the interface
  int _numBDofs;		// RemDOFs with weight>1,  _boundaryDofs[]

  // passage from dual dof to boundary dof
  int *_dualToBound; 
  int *_internalDofs;		// List of internal DOFs
  int *_boundaryDofs;		// List of boundary DOFs
       
  int *_cornerMap;
  int *_glCDofs;
       
  int *_AnsToRem;
  int *_LagToDual;
  
  double *_cData;

  FSCommPattern<double> *_singleBoundPat, *_singleBoundPatC;
  
  FSCommPattern<double> *_gPat;

public:
  void addDualToIntern(double *, double *);
  void scatterInternToDual(double *, double *);
  void scatterInternToDualCRS(double *, double *);
  void dispatchDual(double *);
  void dispatchDualCRS(double *);
  void subNeighbDual(double *, double *);
  void subNeighbDualCRS(double *, double *);
  double vdot(double *, double *);
  double vdot2(double *, double *);
  void PrintCommData();
  
  FSSubDomCore(FSSubPreprocessor *,
	       FSConnectivity *nodeToNode, DofSetArray *dsa,
	       ConstrainedDSA *cdsa,
	       ConstrainedDSA *ccdsa, FSConnectivity *sharedDofs);
  ~FSSubDomCore();
  
  void setPat(FSCommPattern<double> *pat);
  
  // this function returns how many coarse nodes are controlled by this
  // sub and then puts into totalCNodes the total number of corner nodes
  // know to this sub. This array is global subdomain numbering.
  int nCoarseNodes(int *totalCNodes);
  void getCoarseConnect(int *cPtr, int *cTg, int firstCE, int *glCrn);

  bool isLinear()	{ return _isLinear;	}
  bool isUnsym()        { return _unsym;	}
  int  localLen()	{ return _nRemDofs;	}
  int  dualLen()       	{ return _nDual;       	}
  int  boundLen()	{ return _numBDofs;	}
  int  glNumber()	{ return _glSubNum;	}
  int  numNeighbor()	{ return _numNeighb;	}
  int  neighbSubNum(int i){ return _neighbSubs[i]; }
  
  void initSolve();
  void endSolve();
  
  void setNonLinear(bool isLinear)	{_isLinear = isLinear;}
  void markPenalty()			{_isPenalty = true; _isLinear = false;}
  void setUnsym(bool unsym)		{_unsym = unsym;}
  void setSingular(bool singular)	{_singular = singular;}
  void initMatrices(bool,FSConnectivity*);
  void profileStiffMatrix(C_MatSp<double> &KrrSp, FSConnectivity *nodeToNode, DofSetArray *dsa, int *map = NULL);
  void profileStiffMatrix(C_MatSp<double> &KrrSp, FSConnectivity *nodeToNode, ConstrainedDSA *ccdsa);
  void addContactMatrix(double *kel, int *ls, int nr);
  void addStiffMatrix(FSFullMatrix *kel, int *dofs, int *ls, bool unsym);
  void Factor(bool, int *); 
  void dumpMatrices(); 
  void freeMatrices();
  
  int getNnzKrr() {return _KrrSp.getNnz();}
  
  void setLMPCs(C_Gcpce *GLMPC)
  {
    _GLMPC = GLMPC;
    _nDualS = (_GLMPC ? _GLMPC->getNbEqs() : 0);
  }
  
  void Init(FSConnectivity *nodeToNode);
  void makeMaps(FSConnectivity *nodeToNode);
  void allocateKrr(FSConnectivity *nodeToNode);
  void applyKplus(double *f, double *p, double *du, double *fp);
  void computeCoarsLoad(double *f);

  void applyBrBrtm1(double *dual);
  void applyBrBrtm1C(double *dual);
  void applyBrBrtm1R(double *dual, C_AnsysSolver<C_MatSp<double> >*BrBrtm1);
  void applyBrBrtm1S(double *dual, C_AnsysSolver<C_MatSp<double> >*BrBrtm1);
  void precondition(double *w, double *p, FSInfo::Preconditioner precond, double *dU, double *dF);
  void errExact(double *ur, double *uc, double *lambda, double *fr);
  
  // Routines to compute Primal Residual
  void sendDF(double *dF);
  double gatherAndDotDF(double *dF);
       
  // Routines to build the 'k scaling'
  void sendKDiag();
  void makeKScale(int keep = 0);

  void setHalfOffset(int halfOffset) { _halfOffset = halfOffset; }
  void setMasterDualOffset(int masterDualOffset) {_masterDualOffset = masterDualOffset;}
  void extractHalfInterface(double *s, double *hs);
  void extract2HalfInterfaces(double *s, double *hs, double *t, double *ht);
  void scatterHalfInterf(double *hs, double *buffer);
  void rebuildInterf(double *v);
  int halfInterfaceLength();
  int masterDualLen();
  int *getCornerDofs(int *nd = 0) 
  { 
    if (nd) *nd = _nCoarseDofs;
    return _glCDofs; 
  }
  FullSquareMatrix *getKccStar() { return _KccStar; }
  double *getCornerData() { return _cData; }
  void makeKccStar(DofSetArray *, int firstCENode);
  
  void getBrBrtC(C_MatSp<double> &, C_SubContactLag *);
  void getBrBrtR(C_MatSp<double> &);
  void getBrBrtS(C_MatSp<double> &);
  
  void lambdaToUr(double *fr, double *lambda, double *uc, double *ur, double *rb);
  void makeFc(double *fr, double *l);
  void multKrc(double *fr, double *uc);
  void extractRc(DofSet gds, int dofPerNode, double *rbm, double *uc);
  void ansToUr(int dofPerNode, DofSet, double *gU, double *ur);
  void ansToUc(int dofPerNode, DofSet, double *gF, double *cF, int *coarseMaster);
  void ansToLambda(int dofPerNode, DofSet gds, double *ur, double *uc, double *ans, double *dual);
  void lambdaToAns(int nbDofPerNode, double *lambda, double *ans);
  void makeAnsysLoad(int dofsPerNode, DofSet, double *gF, 
		     double *locF, double *cF, int *coarseMaster);
  void unifyAnsysSol(DofSet, double *gU, 
		     double *ur, double *uc, double *dual, int *coarseMaster);
  
  void buildBrKrrm1Krc();
  void multBrKrrm1Krc(double *);
  
  void buildMapping(DofSet gds);
  void zeroBr();
  void computeMultiplicity1(int iAns, int nbEq, int *cols, int *mark);
  void computeMultiplicity2(int iCE, int nbEq, int *cols, int *mark);
  void fillStructureBr1(int iAns, int nbEq, int *cols, int *mark);
  void fillStructureBr2(int iCE, int nbEq, int *cols, int *mark);
  void endFillStructureBr();
  void fillValuesBr1(int iAns, int nbEq, int *cols, double *vals, int *mark);
  void fillValuesBr2(int iCE, int nbEq, int *cols, double *vals, int *mark);
  void endFillValuesBr();  
  void fillg01(int iAns, double g0, double *g0r);
  void fillg02(int iCE, double g0, double *g0r);
  
  void DualNrm2(double *dual, bool displayMax);
  void DualNrm2Bis(double *dual, FSDualNorm *dualNorm);

  double getSolverMemSize();
  double getMemSize();
  void PutStats();
  
  friend class FSCoreCPUPreprocessor;
};

class FSCoreSolver
{
public:
  typedef enum
    {
      E_PRECOND_NOT_DEFINED = 0,
      E_DOUBLE,
      E_LEFT,
      E_RIGHT
    } E_PRECOND;

  FSCoreSolver(FSCoreCPUPreprocessor *, FSInfo *fsInformation, C_TimeManager &);
  ~FSCoreSolver();
  
  // IO
  void Write(FILE *);
  void Read(FILE *);
  
  // solver for symmetric problem
  void pcg(FSDistVector &fr, FSVector &fc, FSDistVector &g0r, 
	   FSDistVector &ur, FSVector &uc, FSDistVector &dual,
	   int uLength, int dofPerNode, DofSet &ds, int maxIter);
  
  // solver for un-symmetric problem
  void gmres(FSDistVector &fr, FSVector &fc, FSDistVector &g0r, 
	     FSDistVector &ur, FSVector &uc, FSDistVector &dual,
	     int uLength, int dofPerNode, DofSet &ds, int maxIter);
  
  void Factor(bool firstTime);
  void makeCoarse(bool firstTime);
  void PrintScalability();
  void makeProjector(int uLength, int dofPerNode, DofSet &ds);
  int  cornerInfo() { return _glCSize; }
  void dispatchDual(FSDistVector &dual);
  void dispatchDualCRS(FSDistVector &dual);
  void subNeighbDual(FSDistVector &yb, FSDistVector &g0);
  
  void ansToUr(int dofPerNode, DofSet &ds, double *ans, FSDistVector &ur);
  void ansToUc(int dofPerNode, DofSet &ds, double *ans, FSVector &uc);
  void ansToLambda(int dofPerNode, DofSet &ds, FSDistVector &ur, FSVector &uc, double *ans, FSDistVector &dual);
  void lambdaToAns(int nbDofPerNode, FSDistVector &lambda, double *ans);
  void lambdaToUr(FSDistVector &, FSDistVector &, FSVector &, FSDistVector &);
  void errExact(FSDistVector &ur, FSVector &uc, FSDistVector &lambda, FSDistVector &fr, FSVector &fc);
  void makeLoad(double *gF, int dofPerNode, DofSet &ds,
		FSDistVector &fr, FSVector &fc);
  void unifySol(double *gU, int dofPerNode, DofSet &ds,
		FSDistVector &ur, FSVector &uc, FSDistVector &rb); 
  void addInequations(C_CouplingMat *Gmat, C_CouplingMat *Gcpce, C_CouplingMat *GLMPC, FSDistVector &g0r);
  void checkGtUmg0(FSDistVector &ur, FSDistVector &g0r, FSDistVector &diff);
  void DualNrm2(FSDistVector &dual, string message, bool displayMax = false);
  void DualNrm2(FSDistVector &dual, FSDualNorm &dualNorm);
  void PrintDualNrm2(FSDistVector &dual, string message, FSDualNorm &dualNorm);
  double DualInnerProduct(FSDistVector &dual1, FSDistVector &dual2);
  double getSolverMemSize();
  double getMemSize();
  void PutStats();
  
protected:
  int _numCPU, _cpuNum;		// number of CPUs solving this and rank of this CPU
  int _nsub;			// number of sub-domain of this CPU
  int _glNumSub;		// total number of sub-domains over all CPUs
  FSSubDomCore **_sd;
  
  bool _isLinear;		// all Krr matrices linear ?
  bool _unsym;			// all Krr matrices symmetric ?
  int _totalIter;		// total number of iterations
  
  FSDistInfo _internInfo;
  FSDistInfo _boundInfo;
  FSSubDTopo *_topo;
  FSCoreCPUPreprocessor *_preProc;
  C_TimeManager &_timeManager;
  FSRbm *_rbms;
  int *_subToComp;
  
  multimap<int,OrthoSet *> _loadToOSets;
  vector <OrthoSet *> _oSets;
  double *_vphi;
  
  KrylovSet *_kSet;
  
  FSAssembledSolver *_KccStarSolver;
  C_AnsysSolver<C_MatSp<double> > *_KccStarSolverSp;
  C_MatSp<double> _KccStarSp;

  C_AnsysSolver <C_MatSp<double> > *_BrBrtSolverR;
  C_AnsysSolver <C_MatSp<double> > *_BrBrtSolverS;
  
  int _dimPhi; 
  C_MatMGe<double> _PhiC;	// RBMs on coarse DOFs
  FSDistVector **_PhiR;		// RBMs on rem DOFs
  C_MatMGe<double> _BrPhiRtBrPhiR;
  FSDistVector **_BrPhiR;
  C_AnsysSolver<C_MatMGe<double> > *_BrPhiRtBrPhiRSolver;
  
  DofSetArray *_coarseDSA;

  int _nCrn;
  int *_crnNum;
      
  int *_coarseMaster;
  int _glCSize;
  int _halfSize;
  int _masterDualLen;
  
  int _maxIter;
  FSInfo *_fsInfo;
  
  // Orthogonalization methods for PCG
  void Ortho_ortho(OrthoSet *, const FSDistVector &, FSDistVector &, double * = NULL);
  void Ortho_ortho2(vector <OrthoSet *> &oSets, const FSDistVector &, FSDistVector &);
  void Ortho_add(OrthoSet *, const FSDistVector &, const FSDistVector &, double);
  void Ortho_minimize(vector <OrthoSet *> &oSets, const FSDistVector &, FSDistVector &);
  void Ortho_precond(vector <OrthoSet *> &oSets, const FSDistVector &, FSDistVector &);
  
  // Orthogonalization methods for Gmres
  void Krylov_ortho(const FSDistVector &, FSDistVector &, double &normInit, double &normEnd, double *scal = NULL);
  void Krylov_add(const FSDistVector &);
  void Krylov_Mv(double *alpha, FSDistVector &p);
  
  // solve the coarse problem
  void solveCoarse(FSVector &);

  // matrix-vector product 
  double applyFI(FSDistVector &, FSVector &,     FSDistVector &,
		 FSDistVector &, FSDistVector &, FSVector &, FSDistVector &);
  double applyFI(FSDistVector &, FSDistVector &, 
		 FSDistVector &, FSDistVector &, FSVector &, FSDistVector &);
  
  // preconditionning  
  void makeKScaling();
  void applyBrBrtm1(FSDistVector &ub);
  double preconditionAndDispatch(FSDistVector &, FSDistVector &, FSDistVector &,
				 FSDistVector &, FSDistVector &, E_PRECOND type = E_DOUBLE);
  
  // RBMs
  void computeLambda0(FSDistVector &fr, FSVector &fc, FSDistVector &lambda0, C_Vec<double> &e);
  void applyProjector(FSDistVector &);
  void addRbmsToDisp(FSDistVector &fr_tmp, FSDistVector &fr, FSVector &fc, C_Vec<double> &e,
		     FSDistVector &ur, FSVector &uc, FSDistVector &dur, FSVector &duc,
		     FSDistVector &lambda, FSDistVector &g0rzero,
		     FSDistVector &drStar, FSDistVector &rb, FSDistVector &drb);
  void checkGtLambdamE(FSDistVector &lambda, C_Vec<double> &e);
  void freeProjector();
  
  // operators
  void assembleFcStar(FSVector &);
  void applyKplus(FSDistVector &, FSDistVector &, 
		  FSDistVector &, FSDistVector &);
  void multKrc(FSDistVector &, FSVector &);
  void multBrKrrm1Krc(FSDistVector &);
  void makeKccStar(DofSetArray *, int firstCENode);
  void makeFc(FSDistVector &fr, FSDistVector &lambda);
  
  void computeRk(FSDistVector &drStar, FSDistVector &lambda, FSDistVector &rk);
};
#endif
