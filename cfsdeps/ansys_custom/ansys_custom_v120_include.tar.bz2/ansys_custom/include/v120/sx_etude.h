/* CADOE */
/*
 *  etude.h	--  definitions rapportees a l'objet etude
 *   
 * HISTORY
 *   
 *   09/25/00 10:39 <       Brian Jantzen> Rel:ms8m1    SCCA:79107  Delta:81.2
 *   
 *   03/02/00 15:46 <       Brian Jantzen> Rel:ms8      SCCA:70204  Delta:8.3
 *   
 *   09/30/99 17:38 <         James Silva> Rel:ms8      SCCA:56512  Delta:8.2
 */
#ifndef __etudeh__
#define __etudeh__ 1

#include <sys/types.h>
/*#include <Xm/Xm.h>*/
#include "adoc.h"
#include "liste_chainee.h"
#include "parametre.h"
#include "cbf.h"
#include "sx_objetu.h"
/*  #include "GuiDonnees.h" */

/* 
 * Statut etude 
 */
typedef enum {
  ETU_OK,		/* rien de particulier */
  ETU_NON_ALLOUEE,	/* pas de donnees; pour init au lancement de Xadofem */
  ETU_NOUVELLE,		/* on a rien sur elle */
  ETU_MEME,		/* c'est la meme */
  ETU_DETRUITE,		/* etude qui vient d'etre detruite */
  ETU_FORCE		/* pour forcer la lecture */
} E_statut_etude;




/*
 * Version database ADOFEM
 */
#define ETU_NO_VERSION "unknown"



/*
 * Flag traitement adoc pour ETU_update
 */
typedef enum {
  ETU_TRAIT_ADOC,	/* fais les traitements sur le fichier adoc */
  ETU_TRAIT_PAS_ADOC    /* ne fais pas ... */
} E_trait_adoc;  

#define PRE	1
#define POST 	2


/*
 * Description des fichiers de la database ADOFEM
 *
 * Attention a ce que le tableau des extensions soit dans le meme ordre que les
 * constantes de E_code_fichier.
 */
typedef enum {
  FICHIER_DAT,
  FICHIER_DAB,
  FICHIER_ETU,
  FICHIER_GRP,
  FICHIER_DAM,
  FICHIER_ADOC,
  FICHIER_MOD,
  FICHIER_MDB,
  FICHIER_RPT,
  FICHIER_RNG
} E_code_fichier;


struct __etude;
struct __fichier_adofem;

typedef struct __etude T_etude;
typedef struct __fichier_adofem T_fichier;

struct __fichier_adofem {
  E_code_fichier code;	/* code du fichier */
  char extension[8];	/* extension du fichier */
  T_booleen existe;	/* flag fichier existe */
  T_booleen lecture;	/* flag permission lecture */
  T_booleen ecriture;	/* flag permission ecriture */
  time_t last_modif;	/* derniere date de modification */
  T_booleen modifie;	/* signale que le fichier a ete modifie depuis la derniere lecture */
};

struct __etude {
  char *dir;			/* curdir/nom_etude */
  char nom[41];		/* nom_etude */
  E_statut_etude statut;	/* infos diverses */

  char nom_part[80];		/* rempli uniquement en mode I-DEAS */
  int type_adomesh;		/* type de probleme pour adomesh */
  T_modele *modele;		/* modele solveur lu par ITF_lire_modele() */
  T_liste *load_name;		/* liste des noms des loadset */
  double freq;			/* frequence centrale en modal */

  T_liste *lpar;		/* liste des parametres homogene */
  int nb_param;			/* longueur de lpar moins la frequence */
  T_liste *lpar_pph;		/* liste des par phys disponibles selon modele .dat */

  PAR *par;			/* par interne */
  PAR *par_u;			/* par utilisateur */

  T_fichier *fic;			/* description du fichier de l'etude  */

  unsigned int poly_charge:1;	/* signale que le polynome est deja charge */
  unsigned int forme_param:1;	/* etude parametree en forme */
  unsigned int binaire:1;	/* fichier maillage binaire */
  unsigned int adoc_parametre:1;/* le fichier adoc est parametre (opposition a adoc calcul standard) */

  T_obj_etude *objetu;
};


#ifdef __cplusplus
extern "C" {
#endif
extern T_etude *G_etude;

/* Etude.c */
extern void		ETU_options_defaut( T_etude * );
extern T_booleen	ETU_cmp( T_etude *, T_etude * );
extern T_statut 	ETU_allouer( T_etude ** );
extern void 		ETU_liberer( T_etude** );
extern void		ETU_free_names( T_etude** );
extern void		ETU_free_fichier( T_etude** );
extern void		ETU_free_lpar( T_etude** );
extern void		ETU_free_lpar_optim( T_etude** );
extern void		ETU_free_modele( T_etude** );
extern void		ETU_free_objets_par( T_etude** );
extern T_booleen 	ETU_record_exist( T_etude *, int );
extern T_fichier*	ETU_cherche_fichier( T_etude *, E_code_fichier );
extern char*		ETU_nom_fichier( T_etude *, E_code_fichier );
extern void             ETU_set_on( T_etude *, E_resultat_parametre );
extern void             ETU_set_off( T_etude *, E_resultat_parametre );
extern T_booleen        ETU_is_on( T_etude *, E_resultat_parametre );
extern T_booleen        ETU_is_off( T_etude *, E_resultat_parametre );
extern void             ETU_zero_a_calculer( T_etude * );
extern void             ETU_init_a_calculer( T_etude *, E_type_analyse );

/* UpdateStudy.c */
/*extern T_statut 	ETU_update( T_etude**, E_trait_adoc, int );
extern T_statut 	ETU_create( char*, T_etude** );
extern T_statut 	ETU_charger_poly( Widget, T_etude* );
extern T_statut		ETU_liberer_poly(void);
*/

extern int ETU_nb_file(void);

#ifdef __cplusplus
}
#endif


#endif
