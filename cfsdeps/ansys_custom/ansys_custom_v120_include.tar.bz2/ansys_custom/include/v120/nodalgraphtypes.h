
#include "ansysdef.h"


/*****************************************
 Nodal Graph Structure

 This stucture stores the nodal graph
 *****************************************/
struct nodal_graph_str {     /* Name of the structure                                  */
  INT       tag;             /* Tag for this instance of the nodal graph structure     */
  INT       *nzVec;          /* Number of non-zeroes for each node                     */
  INT       **indexVec;      /* Total number of displacements (zero and non-zero)      */
};

#define ngTag(ng)                  (ng->tag)
#define ngNumNonZerosVec(ng)       (ng->nzVec)
#define ngIndexVecPtr(ng)          (ng->indexVec)

#define ngNumNonZeros(ng,c)        (ng->nzVec[c])

#define ngIndexVec(ng,c)           (ng->indexVec[c])
#define ngIndex(ng,c,i)            (ng->indexVec[c][i])

