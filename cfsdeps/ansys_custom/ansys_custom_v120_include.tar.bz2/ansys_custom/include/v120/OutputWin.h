/*
 * *** copyright(c) 2009 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */
extern int  fBatch;

void FortranToOutputWin ( const void *buffer, unsigned bytes );
void CToOutputWin( char * inputBuf, int numChars );

