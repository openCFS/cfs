/*
 * maillage.h
 *
 * $Id: maillage.h,v 1.2.6.1 2009/04/13 14:10:00 jtm Exp $
 *   
 * HISTORY
 *   
 *   06/22/00 16:11 <       Brian Jantzen> Rel:ms8m1    SCCA:74307  Delta:81.2
 */

#ifndef __maillageh__
#define __maillageh__ 1

/*#ifdef __cplusplus
extern "C" {
#endif*/

extern void MOD_get_caracteristiques_fem( T_Modele * );
extern T_statut MOD_OI_recupere_noeuds( T_Modele * );
extern T_statut MOD_OI_recupere_elements( T_Modele * );

#ifdef __cplusplus
}
#endif

#endif
