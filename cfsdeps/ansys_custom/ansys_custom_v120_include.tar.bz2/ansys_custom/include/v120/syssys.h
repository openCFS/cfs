/***********************************************/
/******  include file used miscellaneous routines *****/
/***********************************************/
/* 
 * *** copyright(c) 2009 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */

#if defined(RS6000_SYS) || defined(HP32_SYS)
    /*  C routines called from Fortran  */
#define aclose_   aclose
#define adelet_   adelet
#define aunlink_  aunlink
#define aisdir_   aisdir
#define allocm_   allocm
#define allocate_  allocate
#define anamez_   anamez
#define ansext_   ansext
#define aopen_    aopen
#define aposit_   aposit
#define apositdirect_   apositdirect
#define aread_    aread
#define atoint_   atoint
#define awrite_   awrite
#define asyn_open_     asyn_open
#define asyn_close_    asyn_close
#define asyn_read_     asyn_read
#define asyn_write_    asyn_write
#define asyn_complete_ asyn_complete
#define asyn_status_   asyn_status
#define bint_     bint
#define blinc_    blinc
#define blnshd_   blnshd
#define bmove_    bmove
#define cgrin_    cgrin
#define cgrin2_   cgrin2
#define cgrout_   cgrout
#define csleep_   csleep
#define dptimes_  dptimes
#define dsstatus_ dsstatus
#define epstif_   epstif
#define exinc4_   exinc4
#define field_    field
#define fndloc_   fndloc
#define getloc_   getloc
#define heap_resize_   heap_resize
#define iinit_    iinit   /* 2 */
#define ilastc_   ilastc
#define ilastc4_   ilastc4
#define imtch_    imtch
#define inexc4_   inexc4
#define imove_    imove   /* 3 */
#define izero_    izero   /* 4 */
#define lcomp_    lcomp
#define linit_    linit   /* 5 */
#define l8init_   l8init
#define l8loc_    l8loc
#define lmove_    lmove   /* 6 */
#define l8move_   l8move
#define l32move_  l32move
#define loccmd_   loccmd  /* 7 */
#define loccmdb_  loccmdb
#define longdiv_  longdiv
#define longsub_  longsub
#define longadd_  longadd
#define longmult_ longmult
#define longmax_  longmax
#define longmod_  longmod
#define lparmloc_ lparmloc
#define mkepsi_   mkepsi
#define nxtnum_   nxtnum
#define pack_     pack    /* 8 */
#define packupcase_	packupcase
#define pathname_ pathname
    /*  parallel library  */
#define ppinit_   ppinit
#define ppresu_   ppresu
#define ppfrk0_   ppfrk0
#define ppfrk1_   ppfrk1
#define ppfrk2_   ppfrk2
#define ppfrk3_   ppfrk3
#define ppfrk4_   ppfrk4
#define ppfrk5_   ppfrk5
#define ppfrk6_   ppfrk6
#define ppfrk7_   ppfrk7
#define ppfrk8_   ppfrk8
#define ppfrk9_   ppfrk9
#define ppfrk10_  ppfrk10
#define ppfrk11_  ppfrk11
#define ppfrk12_  ppfrk12
#define ppfrk13_  ppfrk13
#define ppfrk14_  ppfrk14
#define ppfrk15_  ppfrk15
#define ppproc_   ppproc
#define ppnext_   ppnext
#define pprset_   pprset
#define pplock_   pplock
#define ppunlock_ ppunlock
#define lockst_   lockst
#define lockcl_   lockcl
#define ppinqr_   ppinqr
#define ppinfo_   ppinfo
#define pppark_   pppark
#define ppfini_   ppfini
#define pprange_  pprange
#define ppchunk_  ppchunk
#define pprangel_ pprangel
#define ppchunkl_ ppchunkl

#define ptrdiff_  ptrdiff
#define resset_   resset
#define sapcb1_   sapcb1  /* 9 */
#define savset_   savset
#define sdott_    sdott  /* 10 */
#define strpbl_   strpbl
#define syscwd_   syscwd
#define sysgetcwd_ sysgetcwd
#define tifcrt_   tifcrt
#define unpack_   unpack /* 11 */
#define upcase_   upcase /* 12 */
#define uplabl_   uplabl
#define vamax_    vamax  /* 13 */
#define vamb_     vamb   /* 14 */
#define vamb1_    vamb1  /* 15 */
#define vapb_     vapb   /* 16 */
#define vapb1_    vapb1  /* 17 */
#define vapcb_    vapcb  /* 18 */
#define vapcb1_   vapcb1 /* 19 */
#define vapvb1_   vapvb1 /* 20 */
#define vatb_     vatb   /* 21 */
#define vatb1_    vatb1  /* 22 */
#define vdot_     vdot   /* 23 */
#define viacb1_   viacb1 /* 24 */
#define viamax_   viamax /* 25 */
#define viamb_    viamb  /* 26 */
#define viapb_    viapb  /* 28 */
#define viapb1_   viapb1 /* 29 */
#define viapcb_   viapcb /* 30 */
#define vidot_    vidot  /* 31 */
#define viinit_   viinit /* 32 */
#define vimove_   vimove /* 33 */
#define vimul1_   vimul1 /* 34 */
#define vimult_   vimult /* 35 */
#define vinit_    vinit  /* 36 */
#define visum_    visum  /* 38 */
#define vizero_   vizero /* 39 */
#define vmax_     vmax   /* 40 */
#define vmove_    vmove  /* 41 */
#define vmult_    vmult  /* 42 */
#define vmult1_   vmult1 /* 43 */
#define vsum_     vsum   /* 44 */
#define vzero_    vzero  /* 45 */
#define works_    works
#define unbufr_   unbufr
#define username_ username
#define setlang_  setlang
#define opnerrdb_ opnerrdb
#define inqerrdb_ inqerrdb
#define fnam_idx_ fnam_idx
#define dash_vee_ dash_vee
#define sysdyna_  sysdyna
#define ntsysdyna_ ntsysdyna
#define fileinquirec_ fileinquirec
#define sysabt_ sysabt
#define abrtst_ abrtst
#define sigoff_ sigoff
#define cpuconf_ cpuconf
#define getthiscpu_ getthiscpu
#define sync_       sync
#define glbisum_    glbisum
#define get_times_  get_times


    /*  Fortran routines called from C  */
/* example
#define routne_ routne
*/
#endif


#if defined(PCWINNT_SYS)
    /*  C routines called from Fortran  */
#define aclose_   ACLOSE
#define adelet_   ADELET
#define aunlink_  AUNLINK
#define aisdir_   AISDIR
#define allocm_   ALLOCM
#define allocate_  ALLOCATE
#define anamez_   ANAMEZ
#define sysexec_   SYSEXEC
#define ansext_   ANSEXT
#define aopen_    AOPEN
#define aposit_   APOSIT
#define apositdirect_   APOSITDIRECT
#define aread_    AREAD
#define atoint_   ATOINT
#define awrite_   AWRITE
#define awritec_  AWRITEC
#define asyn_open_     ASYN_OPEN
#define asyn_close_    ASYN_CLOSE
#define asyn_read_     ASYN_READ
#define asyn_write_    ASYN_WRITE
#define asyn_complete_ ASYN_COMPLETE
#define asyn_status_   ASYN_STATUS
#define bint_     BINT
#define blinc_    BLINC
#define blnshd_   BLNSHD
#define bmove_    BMOVE
#define cgrin_    CGRIN
#define cgrin2_   CGRIN2
#define cgrout_   CGROUT
#define csleep_   CSLEEP
#define dptimes_  DPTIMES
#define dsstatus_ DSSTATUS
#define epstif_   EPSTIF
#define exinc4_   EXINC4
#define field_    FIELD
#define fndloc_   FNDLOC
#define getloc_   GETLOC
#define iinit_    IINIT   /* 2 */
#define ilastc_   ILASTC
#define ilastc4_   ILASTC4
#define imtch_    IMTCH
#define inexc4_   INEXC4
#define imove_    IMOVE   /* 3 */
#define izero_    IZERO   /* 4 */
#define lcomp_    LCOMP
#define linit_    LINIT   /* 5 */
#define l8init_   L8INIT
#define l8loc_    L8LOC
#define lmove_    LMOVE   /* 6 */
#define l8move_   L8MOVE
#define l32move_  L32MOVE
#define loccmd_   LOCCMD  /* 7 */
#define loccmdb_  LOCCMDB
#define longdiv_  LONGDIV
#define longsub_  LONGSUB
#define longadd_  LONGADD
#define longmult_ LONGMULT
#define longmax_  LONGMAX
#define longmod_  LONGMOD
#define lparmloc_ LPARMLOC
#define mkepsi_   MKEPSI
#define nxtnum_   NXTNUM
#define pack_     PACK    /* 8 */
#define packupcase_	PACKUPCASE
#define pathname_ PATHNAME
    /*  parallel library  */
#define ppinit_   PPINIT
#define ppresu_   PPRESU
#define ppfrk0_   PPFRK0
#define ppfrk1_   PPFRK1
#define ppfrk2_   PPFRK2
#define ppfrk3_   PPFRK3
#define ppfrk4_   PPFRK4
#define ppfrk5_   PPFRK5
#define ppfrk6_   PPFRK6
#define ppfrk7_   PPFRK7
#define ppfrk8_   PPFRK8
#define ppfrk9_   PPFRK9
#define ppfrk10_  PPFRK10
#define ppfrk11_  PPFRK11
#define ppfrk12_  PPFRK12
#define ppfrk13_  PPFRK13
#define ppfrk14_  PPFRK14
#define ppfrk15_  PPFRK15
#define ppproc_   PPPROC
#define ppnext_   PPNEXT
#define pprset_   PPRSET
#define pplock_   PPLOCK
#define ppunlock_ PPUNLOCK
#define lockst_   LOCKST
#define lockcl_   LOCKCL
#define ppinqr_   PPINQR
#define ppinfo_   PPINFO
#define pppark_   PPPARK
#define ppfini_   PPFINI
#define pprange_  PPRANGE
#define pprangel_ PPRANGEL
#define ppchunk_  PPCHUNK
#define ppchunkl_ PPCHUNKL

#define ptrdiff_  PTRDIFF
#define resset_   RESSET
#define sapcb1_   SAPCB1  /* 9 */
#define savset_   SAVSET
#define sdott_    SDOTT  /* 10 */
#define strpbl_   STRPBL
#define syscwd_   SYSCWD
#define sysgetcwd_ SYSGETCWD
#define tifcrt_   TIFCRT
#define unpack_   UNPACK /* 11 */
#define upcase_   UPCASE /* 12 */
#define uplabl_   UPLABL
#define vamax_    VAMAX  /* 13 */
#define vamb_     VAMB   /* 14 */
#define vamb1_    VAMB1  /* 15 */
#define vapb_     VAPB   /* 16 */
#define vapb1_    VAPB1  /* 17 */
#define vapcb_    VAPCB  /* 18 */
#define vapcb1_   VAPCB1 /* 19 */
#define vapvb1_   VAPVB1 /* 20 */
#define vatb_     VATB   /* 21 */
#define vatb1_    VATB1  /* 22 */
#define vdot_     VDOT   /* 23 */
#define viacb1_   VIACB1 /* 24 */
#define viamax_   VIAMAX /* 25 */
#define viamb_    VIAMB  /* 26 */
#define viapb_    VIAPB  /* 28 */
#define viapb1_   VIAPB1 /* 29 */
#define viapcb_   VIAPCB /* 30 */
#define vidot_    VIDOT  /* 31 */
#define viinit_   VIINIT /* 32 */
#define vimove_   VIMOVE /* 33 */
#define vimul1_   VIMUL1 /* 34 */
#define vimult_   VIMULT /* 35 */
#define vinit_    VINIT  /* 36 */
#define visum_    VISUM  /* 38 */
#define vizero_   VIZERO /* 39 */
#define vmax_     VMAX   /* 40 */
#define vmove_    VMOVE  /* 41 */
#define vmult_    VMULT  /* 42 */
#define vmult1_   VMULT1 /* 43 */
#define vsum_     VSUM   /* 44 */
#define vzero_    VZERO  /* 45 */
#define works_    WORKS
#define unbufr_   UNBUFR
#define username_ USERNAME 
#define setlang_  SETLANG
#define opnerrdb_ OPNERRDB
#define inqerrdb_ INQERRDB
#define fnam_idx_ FNAM_IDX
#define dash_vee_ DASH_VEE
#define chtodpc_   CHTODPC
#define sysdyna_   SYSDYNA
#define ntsysdyna_ NTSYSDYNA
#define upid_      UPID
#define getthiscpu_ GETTHISCPU
#define sync_       SYNC
#define glbisum_    GLBISUM
#define get_times_  GET_TIMES
#define FAnsExpandEnvStr_ FANSEXPANDENVSTR


    /*  Fortran routines called from C  */
/* example
#define routne_     ROUTNE
*/
#endif


/*       FUNCTION RETURN TYPE DECLARATION       */


#if defined(PCWINNT_SYS)  && defined(FORTRAN)

/*  C routines called from FORTRAN  */
   void CALLTYP aclose_();
   void CALLTYP adelet_();
   void CALLTYP aunlink_(INT *, INT []);
   void CALLTYP anamez_();
   INT  CALLTYP sysexec_();
   void CALLTYP aopen_(char [], INT, long INT *, long INT *, long INT *,
                        long INT *);
   void CALLTYP aposit_();
   void CALLTYP apositdirect_();
   void CALLTYP aread_();
   void CALLTYP awrite_();
   void CALLTYP chtodpc_( char [], INT *, double * );
   void CALLTYP ntsysdyna_( INT *, char, INT );
   SUBROUTINE FAnsExpandEnvStr_( char* , char*, INT ,INT);
#endif

#if defined(PCWINNT_SYS)
/*  FORTRAN routines called from C  */
   void CALLTYP get_times_ (double *, double *);
#endif
