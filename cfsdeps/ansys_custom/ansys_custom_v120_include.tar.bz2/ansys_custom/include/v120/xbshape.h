
/*
 *    author/date: yu-hua ting/02-22-94
 *
 *    primary function:
 *
 *      Header for the Interface to SHAPES "Geom" routines 
 *
 *    secondary function:
 *
 *        none
 *
 *    routines included:
 *
 *
 *    history
 *
 *        none
 *
 *    comments:
 *
 *        none
 *
 *    Notice - This file contains ANSYS Confidential information ***
 *
 */


/* 
 * *** copyright(c) 2009 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */



/*   
 *    get the number of xsubvolumes in the xsubvolume list of a xvolume
 */
      extern VOID xvusvq ansPROTO((
      INT *xvunp,          /* I    pointer to the geom number of a xvolume     */
      INT *xnsvp,          /*   O  pointer to the number of xsubvolume in the
                            *      xsubvolume list of the xvolume              */
      INT *iretp));        /*   O  pointer to the error code         
                            *      == 0 - no error
                            *      != 0 - error                                */

/*   
 *    get the xsubvolume list of a xvolume
 */
      extern VOID xvusvg ansPROTO((
             INT *xvunp,          /* I    pointer to the geom number of a xvolume     */
             INT *xnsvp,          /* I    pointer to the number of xsubvolume in the
                                   *      xsubvolume list of the xvolume              */
             INT xsvn[],          /*   O  xsubvolume list of the volume               */
             INT *iretp));        /*   O  pointer to the error code              
                                   *      == 0 - no error
                                   *      != 0 - error                                */


/*   
 *    get the number of xshells in the xshell tree of a xvolume
 */
      extern VOID xvushq ansPROTO((
             INT *xvunp,          /* I    pointer to the geom number of a xvolume  */
             INT *xnshp,          /*   O  pointer to the number of xshells in the
                                   *      xshell tree of the xvolume               */
             INT *iretp));        /*   O  pointer to the error code              
                                   *      == 0 - no error
                                   *      != 0 - error                             */

/*   
 *    get the xshell tree of a xvolume
 */
      extern VOID xvushg ansPROTO((
             INT *xvunp,          /* I    pointer to the geom number of a xvolume  */
             INT *xnshp,          /* I    pointer to the number of xshells in the
                                   *      xshell tree of the xvolume               */
             INT xshn[],          /*   O  xshell tree of the xvolume               */
             INT orient[],        /*   O  orientations of the xshells in the xshell
                                   *      tree of the xvolume                      */
             INT *iretp));        /*   O  pointer to the error code              
                                   *      == 0 - no error
                                   *      != 0 - error                             */


/*   
 *    get the number of xshells in the xshell tree of a xsubvolume
 */
      extern VOID xsvshq ansPROTO((
             INT *xsvnp,          /* I    pointer to the geom number of a xsubvolume  */
             INT *xnshp,          /*   O  pointer to the number of xshells in the
                                   *      xshell tree of the xsubvolume               */
             INT *iretp));        /*   O  pointer to the error code
                                   *      == 0 - no error
                                   *      != 0 - error                                */

/*   
 *    get the xshell tree of a xsubvolume
 */
      extern VOID xsvshg ansPROTO((
             INT *xsvnp,          /* I    pointer to the geom number of a xsubvolume  */
             INT *xnshp,          /* I    pointer to the number of xshells in the
                                   *      xshell tree of the xsubvolume               */
             INT xshn[],          /*   O  xshell tree of the xsubvolume               */
             INT orient[],        /*   O  orientations of the xshells in the xshell
                                   *      tree of the xsubvolume                      */
             INT *iretp));        /*   O  pointer to the error code              
                                   *      == 0 - no error
                                   *      != 0 - error                                */

/*   
 *    get the number of xsubareas in the xsubarea list of a xshell
 */
      extern VOID xshsaq ansPROTO((
             INT *xsvnp,          /* I    pointer to the geom number of a xsubvolume 
                                   *      (or xvolume)                                */
             INT *xshnp,          /* I    pointer to the geom number of a xshell      */
             INT *xnsap,          /*   O  pointer to the number of xsubareas of the
                                   *      xsubarea list of the xshell                 */
             INT *iretp));        /*   O  pointer to the error code
                                   *      == 0 - no error
                                   *      != 0 - error                                */

/*   
 *    get the xsubarea list of a xshell
 */
      extern VOID xshsag ansPROTO((
             INT *xsvnp,          /* I    pointer to the geom number of a xsubvolume 
                                   *      (or xvolume)                                */
             INT *xshnp,          /* I    pointer to the geom number of a xshell      */
             INT *xnsap,          /* I    pointer to the number of xsubareas of the
                                   *      xsubarea list of the xshell                 */
             INT xsan[],          /*   O  xsubarea list of the xshell                 */
             INT orient[],        /*   O  orientations of the xsubareas in the xshell
                                   *      of the xsubvolume (or xvolume)              */
             INT *iretp));        /*   O  pointer to the error code
                                   *      == 0 - no error
                                   *      != 0 - error                                */


/*   
 *    get the number of xsubareas in the xsubarea list of a xarea
 */
      extern VOID xarsaq ansPROTO((
             INT *xarnp,          /* I    pointer to the geom number of a xarea       */
             INT *xnsap,          /*   O  pointer to the number of xsubarea in the
                                   *      xsubarea list of the xarea                  */
             INT *iretp));        /*   O  pointer to the error code         
                                   *      == 0 - no error
                                   *      != 0 - error                                */

/*   
 *    get the xsubarea list of a xarea
 */
      extern VOID xarsag ansPROTO((
             INT *xarnp,          /* I    pointer to the geom number of a xarea       */
             INT *xnsap,          /* I    pointer to the number of xsubarea in the
                                   *      xsubarea list of the xarea                  */
             INT xsan[],          /*   O  xsubarea list of the xarea                  */
             INT *iretp));        /*   O  pointer to the error code              
                                   *      == 0 - no error
                                   *      != 0 - error                                */


/*   
 *    get the number of xloops in the xloop tree of a xarea
 */
      extern VOID xarlpq ansPROTO((
             INT *xarnp,          /* I    pointer to the geom number of a xarea    */
             INT *xnlpp,          /*   O  pointer to the number of xloops in the
                                   *      xloop tree of the xarea                  */
             INT *iretp));        /*   O  pointer to the error code         
                                   *      == 0 - no error
                                   *      != 0 - error                             */

/*   
 *    get the xloop tree of a xarea
 */
      extern VOID xarlpg ansPROTO((
             INT *xarnp,          /* I    pointer to the geom number of a xarea    */
             INT *xnlpp,          /* I    pointer to the number of xloops in the   */
             INT xlpn[],          /*   O  xloop tree of the xarea                  */
             INT orient[],        /*   O  orientations of the xloops in the xloop
                                   *      tree of the xarea                        */
             INT *iretp));        /*   O  pointer to the error code         
                                   *      == 0 - no error
                                   *      != 0 - error                             */



/*   
 *    get the number of xloops in the xloop tree of a xsubarea
 */
      extern VOID xsalpq ansPROTO((
             INT *xsanp,          /* I    pointer to the geom number of a xsubarea    */
             INT *xnlpp,          /*   O  pointer to the number of xloops in the
                                   *      xloop tree of the xsubarea                  */
             INT *iretp));        /*   O  pointer to the error code         
                                   *      == 0 - no error
                                   *      != 0 - error                                */

/*   
 *    get the xloop tree of a xsubarea
 */
      extern VOID xsalpg ansPROTO((
             INT *xsanp,          /* I    pointer to the geom number of a xsubarea    */
             INT *xnlpp,          /* I    pointer to the number of xloops in the
                                   *      xloop tree of the xsubarea                  */
             INT xlpn[],          /*   O  xloop tree of the xsubarea                  */
             INT orient[],        /*   O  orientations of the xloops in the xloop
                                   *      tree of the xsubarea                      */
             INT *iretp));        /*   O  pointer to the error code         
                                   *      == 0 - no error
                                   *      != 0 - error                                */



/*   
 *    get the number of xsublines in the xsubline list of a xloop
 */
      extern VOID xlpslq ansPROTO((
             INT *xsanp,          /* I    pointer to the geom number of a xsubarea 
                                   *      (or xarea)                                  */
             INT *xlpnp,          /* I    pointer to the geom number of a xloop       */
             INT *xnslp,          /*   O  pointer to the number of xsublines of the
                                   *      xsubline list of the xloop                  */
             INT *iretp));        /*   O  pointer to the error code         
                                   *      == 0 - no error
                                   *      != 0 - error                                */

/*   
 *    get the xsubline list of a xloop
 */
      extern VOID xlpslg ansPROTO((
             INT *xsanp,          /* I    pointer to the geom number of a xsubarea 
                                   *      (or xarea)                                  */
             INT *xlpnp,          /* I    pointer to the geom number of a xloop       */
             INT *xnslp,          /* I    pointer to the number of xsublines of the
                                   *      xsubline list of the xloop                  */
             INT xsln[],          /*   O  xsubline list of the loop                   */
             INT orient[],        /*   O  orientations of the xsublines in the xloop
                                   *      of the xsubarea (or xarea)                  */
             INT *invert,         /*   O  == 1 - if xsubline list has been 
                                   *                inverted
             			   *      == 0 - otherwise                            */
             INT *iretp));        /*   O  pointer to the error code         
                                   *      == 0 - no error
                                   *      != 0 - error                                */

/*   
 *    check the xloop conditions
 */
      extern VOID xlpchk ansPROTO((
             INT *xsanp,          /* I    pointer to the geom number of a xsubarea 
                                   *      (or xarea)                                          */
             INT *xlpnp,          /* I    pointer to the geom number of a xloop               */
             INT *xnslp,          /*    O pointer to the number of xsublines of the
                                   *      xsubline list of the xloop                          */
             INT iopts[],         /* I    iopts[0]  != 0 - check if the loop contains
                                   *                       any duplicated sublines    
                                   *                == 0 - do not check if the loop
                                   *                       contains any duplicated sublines
                                   *      iopts[1]  != 0 - check if the loop is a valid
                                   *                       closed loop
                                   *                == 0 - do not check if the loop is
                                   *                       a valid closed loop                */      
             INT checks[],        /*    O checks[0] != 0 - the loop contains duplicated 
                                   *                       sublines          
                                   *                == 0 - the loop does not contain any
                                   *                       duplicated sublines 
                                   *      checks[1] != 0 - the loop is not a valid closed 
                                   *                       loop 
                                   *                == 0 - the loop is a valid closed loop    */
             INT *iretp));        /*   O  pointer to the error code
                                   *      == 0 - no error
                                   *      == SHAPES_LOOP_HAVING_LESS_THAN_1_XSUBLINE,
                                   *      != 0 - error                                        */

/*   
 *    get the number of xsublines in the xsubline list of a xline
 */
      extern VOID xlsslq ansPROTO((
             INT *xlsnp,          /* I    pointer to the geom number of a xline       */
             INT *xnslp,          /*   O  pointer to the number of xsubline in the
                                   *      xsubline list of the xline                  */
             INT *iretp));        /*   O  pointer to the error code         
                                   *      == 0 - no error
                                   *      != 0 - error                                */
/*   
 *    get the xsubline list of a xline
 */
      extern VOID xlsslg ansPROTO((
             INT *xlsnp,          /* I    pointer to the geom number of a xline       */
             INT *xnslp,          /* I    pointer to the number of xsublines of the 
                                   *      xsubline list of the xline                  */ 
             INT xsln[],          /*   O  xsubline list of the xline                  */
             INT *iretp));        /*   O  pointer to the error code              
                                   *      == 0 - no error
                                   *      != 0 - error                                */

/*
 *    get the topology end points of a xsubline
 */
      extern VOID xslptt ansPROTO((
             INT *xslnp,          /* I    pointer to geom number of a xsubline */
             INT xptn[],          /*   O  end points of the  xsubline          */  
             INT *iretp));        /*   O  pointer to the error code            */
       
       
/*
 *    get the geometry end points of a xsubline
 */
      extern VOID xslptg ansPROTO((
             INT *xslnp,          /* I    pointer to geom number of a xsubline */
             INT xptn[],          /*   O  end points of the  xsubline          */ 
             INT *iretp));        /*   O  pointer to the error code            */

/*
 *    get the nsur of the 3-D nurbs surface of a xsubarea
 */
      extern VOID xsasuq ansPROTO((
             INT *xsanp,          /* I    pointer to the geom number of a xsubarea    */
             INT nsur[],          /*   O  nsur of the nurbs surface of the xsubarea   */
             INT *geom_type,      /* I    == 0 - OLD_GEOMETRY
                                   *      == 1 - NEW_GEOMETRY                         */
             INT *iretp));        /*   O  pointer to the error code                   */

/*
 *    get the sur of the 3-D nurbs surface of a xsubarea
 */
      extern VOID xsasug ansPROTO((
             INT *xsanp,          /* I    pointer to the geom number of a xsubarea    */
             DOUBLE sur[],        /*   O  sur of the nurbs surface of the subarea     */
             INT *geom_type,      /* I    == 0 - OLD_GEOMETRY
                                   *      == 1 - NEW_GEOMETRY                         */
             INT *iretp));        /*   O  pointer to the error code                   */


/*
 *    get the ncur of the 3-D nurbs curve of a xsubline
 */
      extern VOID xslcuq ansPROTO((
             INT *xslnp,          /* I    pointer to the geom number of a xsubline */
             INT ncur[],          /*   O  ncur of the nurbs curve of the xsubline  */
             INT *geom_type,      /* I    == 0 - OLD_GEOMETRY
                                   *      == 1 - NEW_GEOMETRY                      */
             INT *iretp));        /*   O  pointer to the error code                */

/*
 *    get the cur of the 3-D nurbs curve of a xsubline
 */
      extern VOID xslcug ansPROTO((
             INT *xslnp,          /* I    pointer to the geom number of a xsubline */
             DOUBLE cur[],        /*   O  cur of the nurbs curve of the xsubline   */
             INT *geom_type,      /* I    == 0 - OLD_GEOMETRY
                                   *      == 1 - NEW_GEOMETRY                      */
             INT *iretp));        /*   O  pointer to the error code                */

/*
 *    get the 3-D point coordinates of a xpoint
 */
      extern VOID xptcog ansPROTO((
             INT *xptnp,          /* I    pointer to the geom number of a xpoint   */
             DOUBLE cor[],        /*   O  3-D coordinates of the point             */
             INT *iretp));        /*   O  pointer to the error code                */
       



/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 +                                                                    +
 +        SHAPES interface for ANSYS FORTRAN routines                 +
 +                                                                    +
 +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/



/*   
 *    create a 3-D point in SHAPES 
 */
      extern VOID xptcr ansPROTO((
             INT ptn,
             DOUBLE xyz[],        /* I    XYZ coordinates of a 3-D point         */
             INT *xptn,           /*   O  geom number of the 3-D point           */
             INT *iretp));         /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                           */
       

/*   
 *    create a 3-D trimming nurbs curve in SHAPES 
 */
      extern VOID xtrmsl ansPROTO((
             INT sln,             /* I    ansys subline number                    */
             DOUBLE cur[],        /* I    cur of a nurbs curve                    */
             INT ncur[],          /* I    ncur of the nurbs curve                 */
             INT xptn[],          /* I    geom numbers of the end points          */
             INT *xsln,           /*   O  geom number of the trimming nurbs curve 
                                   *      created */
             INT *iopt,           /* I    option
                                   *      == DESTROY_INPUT_GEOMS (== 1) or
                                          == DO_NOT_DESTROY_INPUT_GEOMS (== 0)    */
             INT *iretp));         /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                             */


/*
 *   create preimage, bridges and frames for a set of subcells on a superce;;
 */

      extern xFRAME xPreImageFrame ansPROTO((
	     xGEOM_ID gm[],
	     INT  sub_ansys[],
	     xCELL supcell,
	     INT  sup_ansys,
	     INT   length,
	     INT   orient[],
	     INT   *iretp));

      extern xGEOM_ID xReplaceFrames ansPROTO((
	     xCELL supcell,
	     xFRAME oFrame,
	     xFRAMES iFrames,
	     INT  userid,
	     INT  *iretp));


/*   
 *    sew a set of 3-D trimming nurbs curves and create a new trimming
 *    curve in SHAPES 
 */
      extern VOID xsewls ansPROTO((
             INT xsln[],          /* I    geom numbers of trimming nurbs curves   */
             INT orient[],        /* I    orientations of trimming nurbs curves
                                   *      orient[i] ==  1, if  xsln[i] is used
                                   *                == -1, if -xsln[i] is used    */
             INT *nsl,            /* I    number of trimming nurbs curve          */
             INT *xlsn,           /*   O  geom number of the new trimming curve 
                                   *      created                                 */
             INT *oopt,           /* I    option of orientations
                                   *      == ORIENTATION_INFO_IS_USED or
                                   *      == ORIENTATION_INFO_IS_NOT_USED         */   
             INT *iopt,           /* I    option of destroying input geoms
                                   *      == DESTROY_INPUT_GEOMS or
                                   *      == DO_NOT_DESTROY_INPUT_GEOMS           */
             INT *iretp));         /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                            */



/*   
 *    sew a set of 3-D trimming nurbs curves and create a loop
 */
      extern VOID xsewlp ansPROTO((
             INT xsln[],          /* I    geom numbers of trimming nurbs curves   */
             INT orient[],        /* I    orientations of trimming nurbs curves
                                   *      orient[i] ==  1, if  xsln[i] is used
                                   *                == -1, if -xsln[i] is used    */
             INT *nsl,            /* I    number of trimming nurbs curve          */
             INT *xlpn,           /*   O  geom number of the loop created         */
             INT *oopt,           /* I    option of orientations
                                   *      == ORIENTATION_INFO_IS_USED or
                                   *      == ORIENTATION_INFO_IS_NOT_USED         */   
             INT *iopt,           /* I    option of destroying input geoms
                                   *      == DESTROY_INPUT_GEOMS or
                                   *      == DO_NOT_DESTROY_INPUT_GEOMS           */
             INT *iretp));         /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                            */


/*   
 *    create a 3-D trimming nurbs surface in SHAPES
 */
      extern VOID xtrmsa ansPROTO((
             INT san,             /* I    ansys subarea number                    */
             DOUBLE sur[],        /* I    sur of a nurbs surface                  */
             INT nsur[],          /* I    nsur of the nurbs surface               */
             INT xlpn[],          /* I    loop tree or loop list                  */
             INT orient[],        /* I    orientations of trimming nurbs curves
                                   *      orient[i] ==  1, if  xlpn[i] is used
                                   *                == -1, if -xlpn[i] is used    */
             INT *nlp,            /* I    number of loops                         */
             INT *xsan,           /*   O  geom number of the trimming nurbs 
                                   *      surface created                         */
             INT *oopt,           /* I    option of orientations
                                   *      == ORIENTATION_INFO_IS_USED or
                                   *      == ORIENTATION_INFO_IS_NOT_USED         */   
             INT *iopt,           /* I    option
                                   *      == DESTROY_INPUT_GEOMS or
                                          == DO_NOT_DESTROY_INPUT_GEOMS           */
             INT *iretp));         /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                            */


/*   
 *    sew a set of 3-D trimming nurbs surfaces and create a new trimming
 *    surface in SHAPES 
 */
      extern VOID xsewar ansPROTO((
             INT xsan[],          /* I    geom numbers of trimming nurbs surfaces   */
             INT orient[],        /* I    orientations of trimming nurbs curves
                                   *      orient[i] ==  1, if  xsan[i] is used
                                   *                == -1, if -xsan[i] is used      */
             INT *nsa,            /* I    number of trimming nurbs surface          */
             INT *xarn,           /*   O  geom number of the new trimming surface 
                                   *      created                                   */
             INT *oopt,           /* I    option of orientations
                                   *      == ORIENTATION_INFO_IS_USED or
                                   *      == ORIENTATION_INFO_IS_NOT_USED           */   
             INT *iopt,           /* I    option
                                   *      == DESTROY_INPUT_GEOMS or
                                          == DO_NOT_DESTROY_INPUT_GEOMS             */
             INT *iretp));         /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                              */
       
/*   
 *    sew a set of 3-D trimming nurbs surfaces and create a shell
 */
      extern VOID xsewsh ansPROTO((
             INT xsan[],          /* I    geom numbers of trimming nurbs surfaces   */
             INT orient[],        /* I    orientations of trimming nurbs curves
                                   *      orient[i] ==  1, if  xsan[i] is used
                                   *                == -1, if -xsan[i] is used      */
             INT *nsa,            /* I    number of trimming nurbs surface          */
             INT *xshn,           /*   O  geom number of the shell created          */
             INT *oopt,           /* I    option of orientations
                                   *      == ORIENTATION_INFO_IS_USED or
                                   *      == ORIENTATION_INFO_IS_NOT_USED           */   
             INT *iopt,           /* I    option
                                   *      == DESTROY_INPUT_GEOMS or
                                          == DO_NOT_DESTROY_INPUT_GEOMS             */
             INT *iretp));         /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                              */




/*   
 *    create a 3-D solid in SHAPES by shells
 */
      extern VOID xtrmsv ansPROTO((
             INT svn,             /* I    ansys subvolume number                   */
             INT xshn[],          /* I    geom numbers of the shells               */
             INT orient[],        /* I    orientations of trimming nurbs curves
                                   *      orient[i] ==  1, if  xshn[i] is used
                                   *                == -1, if -xshn[i] is used     */
             INT *nsh,            /* I    number of shells                         */
             INT *xsvn,           /*   O  geom number of the solid created         */
             INT *oopt,           /* I    option of orientations
                                   *      == ORIENTATION_INFO_IS_USED or
                                   *      == ORIENTATION_INFO_IS_NOT_USED          */   
             INT *iopt,           /* I    option
                                   *      == DESTROY_INPUT_GEOMS or
                                   *      == DO_NOT_DESTROY_INPUT_GEOMS            */
             INT *iretp));         /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                             */


/*   
 *    sew a set of 3-D nurbs solids and create a new solid in SHAPES      
 */
      extern VOID xsewvu ansPROTO((
             INT xsvn[],          /* I    geom numbers of nurbs solids            */
             INT orient[],        /* I    orientations of trimming nurbs curves
                                   *      orient[i] ==  1, if  xsvn[i] is used
                                   *                == -1, if -xsvn[i] is used    */
             INT *nsv,            /* I    number of nurbs solid                   */
             INT *xvun,           /*   O  geom number of the new solid created    */
             INT *oopt,           /* I    option of orientations
                                   *      == ORIENTATION_INFO_IS_USED or
                                   *      == ORIENTATION_INFO_IS_NOT_USED         */   
             INT *iopt,           /* I    option
                                   *      == DESTROY_INPUT_GEOMS or
                                   *      == DO_NOT_DESTROY_INPUT_GEOMS           */
             INT *iretp));         /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                            */




