/* CADOE */
/**
 *	chlocal.h -- constantes attachees aux objets de type CHAMP_LOCAL
 *   
 **/

#include "sx_cons_solver.h"
#include "sx_CADOE_solver.h"
#ifndef __CHLOCAL_X_DEJA_INCLUS__
#define __CHLOCAL_X_DEJA_INCLUS__ 1

#ifndef __cplusplus
#error "This file must be included by C++ source files"
#endif

/**
 * |Fonction: CHE_ext_tens_layer
 *
 * |Statut: public
 *
 * |Appel: ier = CHE_ext_tens_layer( champ_elem, ind_noe_elem, ipeau)
 *
 * |Arguments:
 *  champ_elem 		T_champ_elem*	E	champ_elem dans lequel on recherche les valeurs pour ipeau
 *  ind_noe_elem	int		E	indice du noeud support dans l'element
 *  ipeau		int		E	indice de peau (0-bottom a n-top)
 *
 * |Retour:
 *  ptrval		double*		pointeur sur la premiere valeur de la peau ipeau
 *
 * |Description:
 *  Retourne un pointeur sur la premiere valeur de la peau ipeau dans un champ elementaire, de maniere independante
 *  du contexte solveur. gere de maniere transparente l'organisation des valeurs dans un champ elementaires.
 *
 **/
inline double*
CHE_ext_layer( T_champ_elem *champ_elem, int ind_noe_elem, int ind_peau, int nb_comp)
{
  return champ_elem->ve + (ind_peau*champ_elem->element->nb_noeud + ind_noe_elem)*nb_comp;
}

extern T_statut CHL_creer_champ_local (int , int , T_champ_local **, double*valeurs=NULL);
extern T_statut CHL_deformation_groupe (T_champ_global*, T_groupe*, VEC*, int , T_champ_global*, T_champ_local**);
extern T_statut CHL_moyenne_tenseur(T_groupe*, T_champ_local*, T_champ_local**);
extern T_statut CHL_detruire(T_champ_local*);
extern T_statut CHL_effort_groupe (T_champ_global*, T_groupe*, int , T_champ_global*, T_champ_local**);
extern T_statut CHL_allouer( T_groupe*, E_resultat_parametre, T_champ_local**, double*valeurs=NULL );
extern T_statut CHL_stress_2_strain_grp(T_champ_local*, int, T_groupe*, T_champ_local**);
extern T_statut CHL_strain_2_stress_grp(T_champ_local*, int, T_groupe*, T_champ_local**);
extern T_statut CHL_energie_deformation_groupe( T_champ_local*, T_champ_local*, T_groupe*, T_champ_local** );
extern T_statut CHL_part_2_glob(T_modele* , T_champ_local *);
extern T_statut CHL_masse_groupe (T_modele*, T_groupe*, T_champ_local**);
extern T_statut CHL_moy_2_pg(T_champ_local*, T_champ_local** );
extern T_statut CHL_moy_2_noe_elem(T_groupe*, T_champ_local*, T_champ_local** );
extern T_statut CHL_moyenner( T_modele *modele, T_champ_local *chl );
extern T_statut CHE_moyenner( T_champ_elem *che );

#endif	 /* __CHLOCAL_X_DEJA_INCLUS__ */
