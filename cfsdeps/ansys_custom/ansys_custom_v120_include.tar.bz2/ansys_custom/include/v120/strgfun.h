/* strgfun.h							FJB,SYS
------------------------------------------------------------------------
------- Notice - This file contains ANSYS Confidential information --------
------------------------------------------------------------------------
*/
/* 
 * *** copyright(c) 2009 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */

/*------------------------------ Description ---------------------------
\Author:        F. J. Bogden
\Title:		String Functions header file
\Desc:		This file contains the computer(machine) dependent string
		copying functions header information.
\History:	94/03/15 : fjb - initial creation
\Function(s)
 -Primary:      To supply ANSI-C style prototyping
 -Secondary:    To foster portability
 -External:     none
 -Internal:     none
 -Static:       none
----------------------------------------------------------------------*/

/*------------------------------ Header files ------------------------*/

/*------------------------------ Dependencies ------------------------*/

/*----------------------- Static Macro Definitions -------------------*/

/*--------------------- Static TypeDefs/Structures -------------------*/

/*----------------------- Variable Definitions -----------------------*/

/*------------------------- Exported Functions ------------------------*/

extern VOID BZERO ansPROTO (( CHAR *b, int len ));
extern VOID BCOPY ansPROTO (( CHAR *b1, CHAR *b2, int len ));

#if defined(Use_memmove)
#if defined(IBM)
extern VOID memmove ansPROTO (( CHAR *b2, CHAR *b1, int len ));
#endif
#endif

/*------------------------- Internal Functions ------------------------*/

/*-------------------------- Static Functions ------------------------*/

/*---------------------------- End Of Module -------------------------*/

