/* 
 * *** copyright(c) 2009 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */
/*          **********  DEFINITIONS FOR HEAP MANAGER  **********  */
          
#define HEAP_BYTE       0       
#define HEAP_INTEGER    1    
#define HEAP_REAL       2
#define HEAP_DOUBLE     3     
#define HEAP_COMPLEX    4
#define HEAP_FIXED     16     
#define HEAP_DISCARD   32   
#define HEAP_DISCARDED 64

