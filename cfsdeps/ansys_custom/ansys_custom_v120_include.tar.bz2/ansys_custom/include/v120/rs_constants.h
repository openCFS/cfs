/* ---------------------------------------------------------------------- */
/* *** copyright(c) 2009 SAS IP, Inc.  All rights reserved.                                         */
/* *** ansys, inc.                                                        */
/* ---------------------------------------------------------------------- */

/*CFILE pds_constants.h            ANSI_C
* File name: rs_constants.h
* Author/date: Stefan Reh  02/18/2000
* Primary function:
*    Define constants for Response Surface Methods
*/

#ifndef  _RS_CONSTANTS_H_
#define  _RS_CONSTANTS_H_

#include "globals.h"

#ifndef EXIT_SUCCESS
#define EXIT_SUCCESS                 0
#endif
#ifndef EXIT_FAILURE
#define EXIT_FAILURE                 1 
#endif
#ifndef RS_SOLULABLENGTH
#define RS_SOLULABLENGTH             (PARMSIZE+1)
#endif

enum RS_Regression_Models
{
    RS_MOD_NONE = 0, RS_MOD_LIN, RS_MOD_QUAD, RS_MOD_QUAX
};

enum RS_Y_Transformations
{
    RS_YTR_NONE = 0, RS_YTR_EXP,
    RS_YTR_LOGA, RS_YTR_LOGN, RS_YTR_LOG10,
    RS_YTR_SQRT, RS_YTR_POW,
    RS_YTR_BOX, RS_YTR_LBOX
};

enum RS_X_Transformations
{
    RS_XTR_NONE = 0, RS_XTR_VBOX, RS_XTR_TBOX
};

enum RS_X_Filterings
{
    RS_XFILT_NONE = 0, RS_XFILT_FSR
};


#endif  /* _RS_CONSTANTS_H_ */
