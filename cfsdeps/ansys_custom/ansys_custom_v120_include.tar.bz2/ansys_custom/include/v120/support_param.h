/*******************************************************************************
 *
 *   support_param.h
 *
 *
 * |Module: ADOMESH
 *
 * |Description:
 *
 * |Includes:
 *
 * |Auteur: Lionel Tomaso
 *
 * |Creation: April 2004
 *
 * |Copyright:  copyright(c) 2009 SAS IP, Inc.  All rights reserved.
 *
 *
 ******************************************************************************/

#ifndef __supportparamh__
#define __supportparamh__ 1

/*#ifdef __cplusplus
extern "C" {
#endif*/


/*#ifdef __cplusplus
}
#endif*/

#endif

