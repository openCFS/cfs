////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         copyright(c) 2009 SAS IP, Inc.  All rights reserved.             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: ELM_Api.h $
// $Revision: 1.5.2.1 $ 7.0
// $Date: 2009/04/10 15:33:08 $ March 28 2002
// $Author: jtm $ rjayasee
//
// Description :
//          C Wrappers/Macro to make C calls to Fortan Element Routines
////////////////////////////////////////////////////////////////////////////

#if !defined(ELM_Api_H)
#define ELM_Api_H

#include "ANS_StandardIncludes.h"
// #include "AnsMemCToF.h"

#if defined(LOWERCASENOUNDER_SYS)

/*
 *   The pattern for these platforms is the lowercased version of the name
 */

#define ElmGet               elmget
#define EtyGet               etyget
#define ElIntPt              elintpt
#define Get_ElmPar           get_elmpar
#define svgidx               svgidx
#define svrget               svrget
#define svrput               svrput
#define elmatlennew          elmatlennew
#define dfmRIPidxC           dfmripidxc
#define nlpropkwordBuf       nlpropkwordbuf
#define GetAnsETypePtr       getansetypeptr
#define MAT_WriteCacheToDB   mat_writecachetodb
#define GetSecIntgr          getsecintgr
#define ppproc               ppproc
#define ppinqr               ppinqr
#define PrintcfAnsMemTable   printcfansmemtable
#endif


/* (2)----------------------------------------------------------------*/
#if defined(UPPERCASENOUNDER_SYS)

/*
 *   The pattern for these platforms is the uppercased version of the name
 */

#define ElmGet               ELMGET
#define EtyGet               ETYGET
#define ElIntPt              ELINTPT
#define Get_ElmPar           GET_ELMPAR
#define svgidx               SVGIDX
#define svrget               SVRGET
#define svrput               SVRPUT
#define elmatlennew          ELMATLENNEW
#define dfmRIPidxC           DFMRIPIDXC
#define nlpropkwordBuf       NLPROPKWORDBUF
#define GetAnsETypePtr       GETANSETYPEPTR
#define MAT_WriteCacheToDB   MAT_WRITECACHETODB
#define GetSecIntgr          GETSECINTGR
#define ppproc               PPPROC
#define ppinqr               PPINQR
#define PrintcfAnsMemTable   PRINTCFANSMEMTABLE
#endif


/* (3)----------------------------------------------------------------*/
#if defined(LOWERCASEUNDER_SYS)

/*
 *   The pattern for these platforms is the lowercased version of the name 
 *   followed by an underscore
 */

#define ElmGet               elmget_
#define EtyGet               etyget_
#define ElIntPt              elintpt_
#define Get_ElmPar           get_elmpar_
#define svgidx               svgidx_
#define svrget               svrget_
#define svrput               svrput_
#define elmatlennew          elmatlennew_
#define dfmRIPidxC           dfmripidxc_
#define nlpropkwordBuf       nlpropkwordbuf_
#define GetAnsETypePtr       getansetypeptr_
#define MAT_WriteCacheToDB   mat_writecachetodb_
#define GetSecIntgr          getsecintgr_
#define ppproc               ppproc_
#define ppinqr               ppinqr_
#define PrintcfAnsMemTable   printcfansmemtable_
#endif


/* (4)----------------------------------------------------------------*/

/*
 *   This section is for definition of prototypes.  Each prototype 
 *   should be ANSI compliant and specify the types of each parameter 
 *   as well as the return type.
 */
#ifdef __cplusplus
extern "C"
{
#endif

INT FUNCTION ElmGet(INT*,INT*,INT*) ;
INT FUNCTION EtyGet(INT*,INT*) ;
INT FUNCTION ElIntPt(INT*,INT*,INT*) ;
SUBROUTINE Get_ElmPar(INT*,INT*) ;
SUBROUTINE svgidx(LONGINTC*,INT*) ;
SUBROUTINE svrget(INT*,INT*,INT*,DOUBLE*) ;
SUBROUTINE svrput(INT*,INT*,INT*,DOUBLE*) ;
SUBROUTINE elmatlennew(INT*,INT*,INT*,LONGINTC*,INT*,INT*,INT*,INT*,INT*, INT*) ;
SUBROUTINE dfmRIPidxC(INT*,INT*,INT*,INT*,INT*,INT*,INT*,LONGINTC*) ;
SUBROUTINE nlpropkwordBuf(INT*,LONGINTC*) ;
INT FUNCTION GetAnsETypePtr( INT*,INT*,INT**) ;
SUBROUTINE MAT_WriteCacheToDB(INT*,INT*,INT*,DOUBLE*,DOUBLE*,INT*) ;
INT FUNCTION GetSecIntgr(INT*, INT*) ;
INT FUNCTION ppproc() ;
INT FUNCTION ppinqr(INT*) ;
SUBROUTINE PrintcfAnsMemTable(void) ;

#ifdef __cplusplus
}
#endif

#endif

