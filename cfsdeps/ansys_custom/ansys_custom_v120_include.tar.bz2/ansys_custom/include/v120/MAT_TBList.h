
/*
////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         copyright(c) 2009 SAS IP, Inc.  All rights reserved.             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MAT_TBList.h $
// $Revision: 1.5.2.1 $ 7.0
// $Date: 2009/04/10 15:33:12 $ Feb 9 2005
// $Author: jtm $ rjayasee
//
// Decription :
//
//	C Entry point from Ansys to the Curve Fitting Code. This has all the
//  Command Parsing code
//////////////////////////////////////////////////////////////////////////////
*/

/*  tbfit.h */
#if !defined(MAT_TBList__1)
#define MAT_TBList__1
#define MAT_TBList_Get__1


/* (1)----------------------------------------------------------------*/
#if defined(LOWERCASENOUNDER_SYS)

/*
 *   The pattern for these platforms is the lowercased version of the name
 */

#define MAT_TBList          mat_tblist
#define MAT_TBCompList mat_tbcomplist
#endif


/* (2)----------------------------------------------------------------*/
#if defined(UPPERCASENOUNDER_SYS)

/*
 *   The pattern for these platforms is the uppercased version of the name
 */

#define MAT_TBList          MAT_TBLIST
#define MAT_TBCompList      MAT_TBCOMPLIST

#endif


/* (3)----------------------------------------------------------------*/
#if defined(LOWERCASEUNDER_SYS)

/*
 *   The pattern for these platforms is the lowercased version of the name 
 *   followed by an underscore
 */

#define MAT_TBList          mat_tblist_
#define MAT_TBCompList mat_tbcomplist_


#endif


/* (4)----------------------------------------------------------------*/

/*
 *   This section is for definition of prototypes.  Each prototype 
 *   should be ANSI compliant and specify the types of each parameter 
 *   as well as the return type.
 */
#ifdef __cplusplus
extern "C"
{
#endif

INT FUNCTION MAT_TBList(INT* pMatId, DOUBLE* pTBData) ;
INT FUNCTION MAT_TBCompList(INT* pMatId, DOUBLE* pTBData) ;

#ifdef __cplusplus
}

#endif

void MAT_SaveTBRowColInfo( DOUBLE oTbParams[4]) ;
void MAT_SetTBRowColInfo( DOUBLE oTbParams[4]) ;
void MAT_SetSplCaseTBRowColInfo(DOUBLE oTbParams[3]) ;
bool MAT_CheckForEndOfData( DOUBLE* pDoubleVec, INT iNCol ) ;

#endif
