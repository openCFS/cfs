/**** Copyright XOX Corporation - 1989, 1990, 1991, 1992, 1993  All rights 
      reserved *****/
/* This work contains valuable, confidential, and proprietary information.
Disclosure, use, or reproduction without the written authorization of 
XOX CORPORATION is prohibited */
#ifndef lint

#endif


#ifndef X_GEOMETRY_HEADER_FILE
#define X_GEOMETRY_HEADER_FILE

#if defined(__cplusplus) || defined(__STDC__)
#ifndef __XOX_PROTOTYPES__
#define __XOX_PROTOTYPES__
#endif
#endif

#if defined(__cplusplus)
extern "C" {
#endif

#ifndef LIB_XOX_DEFS_HEADER
#define LIB_XOX_DEFS_HEADER

#ifndef T
#define T 1
#endif

#ifndef NIL
#define NIL 0
#endif

#ifndef NULL
#define NULL 0
#endif

typedef xINT xGEOM_ID, xVERTEX_ID, xFACET_ID, xFRAME_ID, xRIB_ID;

#ifndef xcXOX_REV2

typedef xINT xGEOM, xVERTEX, xFACET, xFRAME;

typedef struct _xINTLIST  {
  xUINT  size    : 16;          
  xUINT  in_use  : 16;          
  xINT *elements;               
  char *heap;      
} xINT_LIST_ST, *xINT_LIST;

#ifndef X_REAL_DEFINED
typedef double xREAL;
#define X_REAL_DEFINED
#endif

typedef xINT (*xINT_FUNC) ();

#endif


#define XOX_Default      -1
#define XOX_In       0x0001
#define XOX_On       0x0002
#define XOX_Out      0x0004
#define XOX_Off      0x0008

#define XOX_FERROR 	-1.0
#define XOX_ERROR 	-1

#define XC_ON        XOX_On
#define XC_OFF       XOX_Off



#define XC_BLENDED   4
#define XC_DEFINED   3
#define XC_MODIFIED  2
#define XC_GENERATED 0
#define XC_COPY      1



#define XC_NEW XC_GENERATED 
#define XC_SAME XC_DEFINED 



#define xcCURVE_SPLIT_NONE    0
#define xcCURVE_SPLIT_SINGLE  1
#define xcCURVE_SPLIT_DOUBLE  2



typedef struct {
  xREAL real;      
  xREAL virt;   
  xREAL profile;   
} *utTIMER, utTIMER_ST;



#define utTimerReal(timer)     ((timer)->real)
#define utTimerVirtual(timer)  ((timer)->virt)
#define utTimerProf(timer)     ((timer)->profile)

#define utSetTimerReal(timer, val)     ((timer)->real    = (val))
#define utSetTimerVirtual(timer,val)   ((timer)->virt    = (val))
#define utSetTimerProf(timer,val)      ((timer)->profile = (val))



typedef struct _xVECTOR {
  xINT length;
  xREAL array[1];		    
} xVECTOR_ST, *xVECTOR;


typedef struct _xMATRIX {	
  short rowCount, columnCount;
  xREAL array[1];		    
} xMATRIX_ST, *xMATRIX;
  



#endif



#define XT_Assembly          1
#define XT_RnCube            2
#define XT_Sewn              3
#define XT_Imbedded          4
#define XT_Intersection      5
#define XT_Boundary          6
#define XT_Map               7
#define XT_Nurb              8
#define XT_Bezier            9
#define XT_TranslationSweep 10
#define XT_In               13
#define XT_Out              14
#define XT_On               15
#define XT_Offset           16
#define XT_Halfspace        17
#define XT_Difference       18
#define XT_Blend            19
#define XT_Skin             20
#define XT_RevolutionSweep  24
#define XT_Null             27
#define XT_Union            28
#define XT_Cylinder         30
#define XT_Sphere           31
#define XT_Box              32
#define XT_Sheet            33
#define XT_Cone             34
#define XT_Line             35
#define XT_Circle           36
#define XT_Disc             37
#define XT_CappedCylinder   39
#define XT_CappedCone       40
#define XT_Point            41
#define XT_TangentialSweep  42
#define XT_CompositeBezier  43
#define XT_Approximate      45




#define XE_CoreError           -200
#define XE_NoErr                0   
#define XE_BadMem              -1   
#define XE_BadGm               -2   
#define XE_NullErr             -3   
#define XE_GmTrnSDimNE         -4   
#define XE_Pnt1Pnt2DimNE       -5   
#define XE_GmTrnLstLenNE       -6   
#define XE_GmGmSDimNE          -7   
#define XE_GmGmDimNE           -8   
#define XE_GmVecDimNE          -9   
#define XE_BadGmForBGm        -10   
#define XE_BadSbGmForSpGm     -11   
#define XE_BadSbGm            -12   
#define XE_BadLt              -13   
#define XE_BadVrt             -14   
#define XE_BadFct             -15   
#define XE_CntParGm           -16   
#define XE_CntCmpCrdsFor0D    -17   
#define XE_GmNInAsm           -18   
#define XE_GmDimNEGmSDim_1    -19   
#define XE_GmDimNE1           -20   
#define XE_PrfNClsd           -21   
#define XE_CntFndStPnt        -22   
#define XE_ParNeed1dGm        -23   
#define XE_SystemError        -24   
#define XE_GeNDis             -25   
#define XE_BadHSpc            -26   
#define XE_VecSDimLT0         -27   
#define XE_CntOpenFp          -28   
#define XE_BadSize            -29   
#define XE_NullObj            -30   
#define XE_DimMisMatch        -31   
#define XE_BadSubscript       -32   
#define XE_TypeBounds	-33	
#define XE_BadGE    -34		
#define XE_BadGEAtt -35	
#define XE_ImbedDim     -36	
#define XE_TransPathDim -37	
#define XE_ListLength   -38	
#define XE_BadType  -39		
#define XE_VtNotOnGm      -40	
#define XE_BadOffsetAmt   -41	
#define XE_BadGraphWin    -42	
#define XE_NoVtFcts       -43	
#define XE_Degenerate     -44	
#define XE_NotSmooth      -45	
#define XE_NoConvergence  -46	
#define XE_Internal       -47	
#define XE_AppxDim        -48	
#define XE_VtGmMismatch   -49	
#define XE_NoParams	  -50	
#define XE_BadSbSpDim     -51	
#define XE_NegativeVolume -52	
#define XE_BadFrame       -53	




#define FN_xCloseSocket                        0
#define FN_xCircleGeom                         1
#define FN_xLineGeom                           2
#define FN_xArcGeom                            3
#define FN_xCylinderGeom                       4
#define FN_xBoxGeom                            5
#define FN_xConeGeom                           6
#define FN_xDiscGeom                           7
#define FN_xSheetGeom                          8
#define FN_xCappedCylinderGeom                 9

#define FN_xSphereGeom                        10
#define FN_xClassifyGeoms                     11
#define FN_xSewnGeom                          12
#define FN_xGeomSpaceDimension                13
#define FN_xGeomDimension                     14
#define FN_xIntersectionGeom                  15
#define FN_xDifferenceGeom                    16
#define FN_xUnionGeom                         17
#define FN_xInvertGeomOrientation             18
#define FN_xHalfspaceGeom                     19

#define FN_xImbedGeom                         20
#define FN_xSolidGeom                         21
#define FN_xCopyGeom                          22
#define FN_xRotateGeom                        23
#define FN_xXRotateGeom                       24
#define FN_xYRotateGeom                       25
#define FN_xZRotateGeom                       26
#define FN_xTranslateGeom                     27
#define FN_xTransformGeom                     28

#define FN_xDisplayGeom                       29

#define FN_xClearGraphicsWindow               30
#define FN_xDisplayGraphicsWindow             31
#define FN_xCreateGraphicsWindow              32
#define FN_xConformWindow                     33
#define FN_xUpdateWindow                      34
#define FN_xNormalAtVertex                    36
#define FN_xBasicGeomP                        37
#define FN_xBoundaryGeom                      38

#define FN_xRootGeom                          41
#define FN_xVertexGeoms                       42
#define FN_xVertexCoords                      43
#define FN_xVertexForParams                   44
#define FN_xRegularizedIntersectionGeom       45
#define FN_xRevolutionSweepGeom               46
#define FN_xGeomVolume                        47
#define FN_xGeomCenterOfMass                  48
#define FN_xErrorMessage                      49

#define FN_xMinDistBetweenGeoms               51
#define FN_xBezierGeom                        52
#define FN_xNurbGeom                          53
#define FN_xVertexOnGeom                      54
#define FN_xVertexDimension                   55
#define FN_xVertexTangentSpace                56
#define FN_xVertexParams                      57
#define FN_xVertexGeomCoords                  58
#define FN_xGeomFacets                        59

#define FN_xFacetVertices                     60
#define FN_xGeomType                          61
#define FN_xDefGeoms                          63
#define FN_xNthIntParam                       64
#define FN_xNthRealParam                      65
#define FN_xIntersectingGeomsP                66
#define FN_xSubGeomP                          67
#define FN_xGeomMinMaxBox                     69

#define FN_xOrientGeom                        70
#define FN_xRnCubeGeom                        71
#define FN_xScaleGeom                         72
#define FN_xInitShapes                        73
#define FN_xParameterizeCurve                 74
#define FN_xAssemblyGeom                      75
#define FN_xTranslationSweepGeom              77
#define FN_xDefaultRefinement                 78
#define FN_xSetDefaultRefinement              79

#define FN_xDefaultCulling                    80
#define FN_xSetDefaultCulling                 81
#define FN_xDefaultPaintOption                82
#define FN_xSetDefaultPaintOption             83
#define FN_xDefaultColor                      84
#define FN_xSetDefaultColor                   85
#define FN_xDefaultBfColor                    86
#define FN_xSetDefaultBfColor                 87
#define FN_xGERefinement                      88
#define FN_xSetGERefinement                   89

#define FN_xGECulling                         90
#define FN_xSetGECulling                      91
#define FN_xGEPaintOption                     92
#define FN_xSetGEPaintOption                  93
#define FN_xGEColor                           94
#define FN_xSetGEColor                        95
#define FN_xGEBfColor                         96
#define FN_xSetGEBfColor                      97
#define FN_xOffsetGeom                        98

#define FN_xBlendGeom                        100
#define FN_xSubGeoms                         101
#define FN_xSupGeoms                         102
#define FN_xKBoundaryGeoms                   103
#define FN_xBasicGeoms                       104
#define FN_xSeamGeoms                        105
#define FN_xSkinnedGeom                      106
#define FN_xVertexFacets                     107
#define FN_xCappedConeGeom                   108
#define FN_xActivateGE                       109

#define FN_xFlashGE                          110
#define FN_xComplementHalfspace              111
#define FN_xFreeId                           112
#define FN_xKSubGeoms                        114
#define FN_xPointGeom                        115
#define FN_xTangentialSweepGeom              116
#define FN_xInterpolatedControlPointsCubic   117
#define FN_xCompositeBezierGeom              118
#define FN_xSkinFromGeoms                    119

#define FN_xSaveGeom                         121
#define FN_xRestoreGeom                      122
#define FN_xApproximateGeom                  123
#define FN_xNullGeomP                        124

#define FN_xVector                           131
#define FN_xFreeVector                       132
#define FN_xCopyVector                       133
#define FN_xVectorLength                     134
#define FN_xVectorArray                      135
#define FN_xVectorElement                    136
#define FN_xSetVectorElement                 137
#define FN_xMatrix                           138
#define FN_xFreeMatrix                       139

#define FN_xCopyMatrix                       140
#define FN_xMatrixRowRank                    141
#define FN_xMatrixColumnRank                 142
#define FN_xMatrixArray                      143
#define FN_xMatrixElement                    144
#define FN_xSetMatrixElement                 145
#define FN_xIntList                          146
#define FN_xFreeIntList                      147
#define FN_xCopyIntList                      148
#define FN_xPushIntListElement               149
#define FN_xPopIntListElement                150

#define FN_xIntListLength                    151
#define FN_xIntListElement                   152
#define FN_xSetIntListElement                153
#define FN_xIntListArray                     154
#define FN_xDisconnectGeoms                  155
#define FN_xGeomP                            156
#define FN_xReplaceSubGeoms                  158

#define FN_xGeomParamsRange                  160
#define FN_xGeomTypeString                   161
#define FN_xKSupGeoms                        162
#define FN_xKSeamGeoms                       163
#define FN_xFacetedMinDist                   164
#define FN_xGeometryVersion                  165
#define FN_xgPostGeom                        166
#define FN_xgUnpostGeom                      167
#define FN_xInterpolatedData                 168
#define FN_xSubGeomOrientations              169

#define FN_xSplineStructure                  170
#define FN_xSystemErrorHandler               171
#define FN_xCoreErrorHandler                 172
#define FN_xGetTimeValues                    174
#define FN_xGetResourceValues                175
#define FN_xFunctionName                     176
#define FN_xErrorDescription                 177
#define FN_xApproximateGeomNurbStructure     178
#define FN_xNumGeomFrames                    179

#define FN_xGeomFrameTree                    180
#define FN_NumFrameComponents                181
#define FN_xFrameComponents                  182
#define FN_xNumFrameComponentOrients         183
#define FN_xFrameComponentOrients            184
#define FN_xSetGeomUserId                    185
#define FN_xResetGeomUserId                  186
#define FN_xGeomUserIds                      187
#define FN_xSetDefaultIdTracking             188
#define FN_xSubGeomsAndOrientations          189

#define FN_xMemoryAllocation                 190
#define FN_xPrimitiveGeomType                191

#define FN_xReplaceGeomFrames                193
#define FN_xMakeFrame                        194
#define FN_xSetDefaultIdGen                  195
#define FN_xUnionMergeGeom                   196
#define FN_xStartShapesLog                   198
#define FN_xEndShapesLog                     199
#define FN_xTrimGeomToBoundaries             200
#define FN_xTrimGeomToFillet                 201
#define FN_xGeomFacetsToTol                  202
#define FN_xGeomPolygonsToTol                203
#define FN_xReleaseGeomFacets                204
#define FN_xIntersectionGeomN                205
#define FN_xGeomFacetsByEdgeLength           206
#define FN_xGeomPolygonsByEdgeLength         207

#define LAST_FUNC_NAME                       207






extern xGEOM_ID xPointGeom(
#ifdef __XOX_PROTOTYPES__
  xREAL ptCoords[],
  xINT   spaceDim
#endif
  		       );

extern xGEOM_ID xLineGeom(
#ifdef __XOX_PROTOTYPES__
  xREAL begPoint[],
  xREAL endPoint[],
  xINT   spaceDim
#endif
		      );

extern xGEOM_ID xArcGeom(
#ifdef __XOX_PROTOTYPES__
  xREAL radius,
  xREAL begAngle,
  xREAL endAngle
#endif
		     );

extern xGEOM_ID xCircleGeom(
#ifdef __XOX_PROTOTYPES__
  xREAL radius
#endif
			 );

extern xGEOM_ID xSheetGeom(
#ifdef __XOX_PROTOTYPES__
  xREAL length,
  xREAL width
#endif
		       );

extern xGEOM_ID xRnCubeGeom(
#ifdef __XOX_PROTOTYPES__
  xREAL interval[],
  xINT   dimension
#endif
			);

extern xGEOM_ID xDiscGeom(
#ifdef __XOX_PROTOTYPES__
  xREAL radius
#endif
		      );

extern xGEOM_ID xCylinderGeom(
#ifdef __XOX_PROTOTYPES__
  xREAL radius,
  xREAL height  
#endif
			  );

extern xGEOM_ID xConeGeom(
#ifdef __XOX_PROTOTYPES__
  xREAL radius,
  xREAL height  
#endif
		      );

extern xGEOM_ID xSphereGeom(
#ifdef __XOX_PROTOTYPES__
  xREAL radius
#endif
		        );

extern xGEOM_ID xBoxGeom(
#ifdef __XOX_PROTOTYPES__
  xREAL length,
  xREAL width,
  xREAL height
#endif
		     );

extern xGEOM_ID xCappedConeGeom(
#ifdef __XOX_PROTOTYPES__
  xREAL radius,
  xREAL height  
#endif
			    );

extern xGEOM_ID xCappedCylinderGeom(
#ifdef __XOX_PROTOTYPES__
  xREAL radius,
  xREAL height  
#endif
			         );




extern xGEOM_ID xBezierGeom(
#ifdef __XOX_PROTOTYPES__
  xINT   dimension, 
  xINT   degrees[],
  xREAL controlPoints[], 
  xINT   spaceDimension,
  xINT   rational, 
  xINT   scaled, 
  xREAL domainIntervals[],
  xGEOM_ID domain 
#endif
			);

extern xGEOM_ID xNurbGeom(
#ifdef __XOX_PROTOTYPES__
  xINT   dimension,
  xINT   degrees[],
  xREAL knots[],
  xINT   knotNums[],
  xREAL cntrlPts[],
  xINT   spaceDimension,
  xINT   rational,
  xINT   scaled,
  xREAL domainIntervals[],
  xINT   domainGeom
#endif
		      );

extern xGEOM_ID xCompositeBezierGeom(
#ifdef __XOX_PROTOTYPES__
  xINT   dimension,
  xINT   degrees[],
  xREAL cntrlPts[],
  xINT   numsPatches[],
  xINT   spaceDimension,
  xINT   rational,
  xINT   scaled,
  xREAL domainIntervals[],
  xGEOM_ID domainGeom
#endif
		                 );


typedef struct _xNURB_DATA {   
  xINT spaceDim;
  xINT dim;  
  
  xINT rational;    
  xINT degrees[2];
  
  xREAL *knots;
  xINT knotNums[2];
  
  xREAL *controlPoints;
  xINT controlPointNums[2];  
} *xNURB_DATA, xNURB_DATA_ST; 


#define XOX_GridData 1
#define XOX_Irregular 2

#define XOX_Patches 1
#define XOX_UserDefined 2


typedef struct _xINTERPOLATION_DATA {
  xINT interpolType;
  xINT spaceDim;
  xINT dim;  
  xINT degrees[2];
  
  xREAL *points;       
  xREAL *params;      
  xREAL *derivatives; 

  xINT numLines;
  xINT numPointsPerLine;
  
  xREAL *knots;
  xINT knotNums[2]; 
  
  xINT knotOption[2];
  
  xINT *xDerivGrid; 
    xINT *yDerivGrid; 
  xINT *xyDerivGrid;  
  
} *xINTERPOLATION_DATA, xINTERPOLATION_DATA_ST;

extern xNURB_DATA xInterpolatedData(
#ifdef __XOX_PROTOTYPES__
  xINTERPOLATION_DATA inputData
#endif
				    );

extern xREAL * xInterpolatedControlPointsCubic(
#ifdef __XOX_PROTOTYPES__
  xREAL pointsAndDerivs[],
  xREAL controlPoints[]
#endif
					       );


extern xNURB_DATA xNurbStructure(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID nurbGeom
#endif
				 );


extern xNURB_DATA xApproximateGeomNurbStructure(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom,
  xREAL distTol,
  xINT   codes[]
#endif
						);




extern xGEOM_ID xBoundaryGeom(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom
#endif
			  );

extern xGEOM_ID xHalfspaceGeom(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom
#endif
			   );

extern xGEOM_ID xComplementHalfspaceGeom(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom
#endif
			  	     );

extern xGEOM_ID xReplaceSubGeoms(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom,
  xINT_LIST newSubs,
  xINT_LIST orient
#endif
			     );

extern xGEOM_ID xTranslationSweepGeom(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID sweptGeom,
  xGEOM_ID pathGeom,
  xINT   scaleFunc
#endif
			          );

extern xGEOM_ID xRevolutionSweepGeom(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID sweptGeom,
  xREAL angle,
  xREAL begPoint[],
  xREAL endPoint[],
  xINT   spaceDim,
  xINT   scaleFunc
#endif
			   	 );

extern xGEOM_ID xTangentialSweepGeom(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID   sweptGeom,
  xGEOM_ID   pathGeom,
  xREAL *refPoint,
  xINT   spaceDim,
  xINT   scaleFunc
#endif
			   	 );


#define XOX_C1 1
#define XOX_C2 0

extern xGEOM_ID xSkinGeomFromPoints(
#ifdef __XOX_PROTOTYPES__
  xREAL profilePoints[],
  xINT   numProfiles,
  xINT   numProfilePoints,
  xINT   spaceDim,
  xINT   degrees[],
  xREAL profileParameters[],
  xREAL profileLocations[],
  xINT   shapeOption[]

#endif
                                );

extern xGEOM_ID xSkinGeomFromGeoms(
#ifdef __XOX_PROTOTYPES__
  xINT_LIST profilesGeoms,
  xINT   degrees[],
  xREAL refPoints[],
  xINT   spaceDim, 
  xINT   shapeOption[]
#endif
                               );


#define XOX_C1Patches 1

extern xGEOM_ID xApproximateGeom(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom,
  xREAL disTol,
  xINT   type
#endif
                             );
                 
extern xGEOM_ID xOffsetGeom(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom,
  xREAL offsetDist,
  xGEOM_ID refGeom
#endif
                        );

#define XOX_ConstantRadius 1
#define XOX_ConstantOffset 0

extern xGEOM_ID xRoundEdgesGeom(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom,
  xINT_LIST edges,
  xREAL offsetDist[],
  xINT   degree,
  xINT   trim,
  xINT   offsetType
#endif
                            );




extern xINT xGeomDimension(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom
#endif
                         );

extern xINT xGeomSpaceDimension(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom
#endif
                              );

extern xREAL *xGeomMinMaxBox(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom,
  xREAL minMax[]
#endif
                            );

extern xREAL *xGeomParamsRange(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom,
  xREAL params[]
#endif
                              );

extern xINT xGeomP(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom
#endif
                 );

extern xINT xNullGeomP(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom
#endif
                     );

extern xINT_LIST xBasicGeoms(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom
#endif
                            );

extern xINT xBasicGeomP(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom
#endif
                      );




extern xVERTEX_ID xVertexOnGeom(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom,
  xREAL point[],
  xINT   spaceDim,
  xREAL searchDist
#endif
                            );

extern xVERTEX_ID xVertexForParams(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom,
  xREAL params[],
  xINT   domainDim
#endif
                               );

extern xREAL *xVertexParams(
#ifdef __XOX_PROTOTYPES__
  xVERTEX_ID vertex,
  xGEOM_ID  geom,
  xREAL params[]
#endif
                           );

extern xREAL *xVertexCoords(
#ifdef __XOX_PROTOTYPES__
  xVERTEX_ID vertex,
  xREAL coords[]
#endif
                           );

extern xINT_LIST xGeomFacets(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom
#endif
                            );


#ifndef xsFACETS_ANGULAR_TOL
#define xcFACETS_ANGULAR_TOL    0x0001
#define xcFACETS_POINT_TOL      0x0002
#define xcFACETS_BOTH           0x0004
#define xcFACETS_EITHER         0x0008
#endif

xINT
xGeomsSetFacetTol(
#ifdef __XOX_PROTOTYPES__
  xINT_LIST geoms,
  xREAL pointTol,
  xREAL angularTol,
  xINT code
#endif
		   );


xINT_LIST
xGeomFacetsToTol(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom,
  xREAL pointTol,
  xREAL angularTol,
  xINT code
#endif
		 );


xINT
xGeomPolygonsToTol(
#ifdef __XOX_PROTOTYPES__
  xINT geomId,
  xREAL pointTol,
  xREAL angularTol,
  xINT code,
  xINT **retIndices,
  xINT *retFctCt,
  xREAL **retCoords,
  xINT *retCoordsCt,
  xREAL **retNormals
#endif
		   );

xINT_LIST
xGeomFacetsByEdgeLength(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom,
  xREAL edgeLength
#endif
		 );


xINT
xGeomPolygonsByEdgeLength(
#ifdef __XOX_PROTOTYPES__
  xINT geomId,
  xREAL edgeLen,
  xINT **retIndices,
  xINT *retFctCt,
  xREAL **retCoords,
  xINT *retCoordsCt,
  xREAL **retNormals
#endif
		   );

xINT
xReleaseGeomFacets(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom
#endif
		   );

extern xINT_LIST xFacetVertices(
#ifdef __XOX_PROTOTYPES__
  xFACET_ID facet
#endif
                               );

extern xINT_LIST xVertexFacets(
#ifdef __XOX_PROTOTYPES__
  xFACET_ID facet,
  xGEOM_ID geom
#endif
                              );





extern xREAL *xGeomTangentSpace(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom,
  xVERTEX_ID vertex,
  xREAL tangentSpace[]
#endif
                               );

extern xREAL *xGeomNormal(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom,
  xVERTEX_ID vertex,
  xGEOM_ID relGeom,
  xREAL normal[]  
#endif
			  );

extern xGEOM_ID xInvertGeomOrientation(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom
#endif
                                   );

extern xGEOM_ID xOrientGeom(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom,
  xGEOM_ID relGeom
#endif
                        );

extern xINT_LIST xSubGeomOrientations(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom
#endif
                               	     );




extern xINT_LIST xSubGeoms(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom
#endif
                          );

extern xINT_LIST xKSubGeoms(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom,
  xINT   dimension
#endif
                           );


extern xINT_LIST xBoundaryGeoms(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom
#endif
                               );

extern xINT_LIST xKBoundaryGeoms(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom,
  xINT   dimension
#endif
                                );

extern xINT_LIST xSeamGeoms(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom
#endif
                           );

extern xINT_LIST xKSeamGeoms(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom,
  xINT   dimension
#endif
                            );


extern xINT_LIST xSupGeoms(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom
#endif
                          );

extern xINT_LIST xKSupGeoms(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom,
  xINT   dimension
#endif
                           );

extern xINT xSubGeomP(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID subGeom,
  xGEOM_ID supGeom
#endif
                    );




extern xINT_LIST xClassifyGeoms(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom1,
  xGEOM_ID geom2,
  xINT   exp1,
  xINT   exp2
#endif
                               );

extern xGEOM_ID xIntersectionGeom(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom1,
  xGEOM_ID geom2
#endif
                               );

extern xGEOM_ID xIntersectionGeomN(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom1,
  xGEOM_ID geom2
#endif
                               );

extern xGEOM_ID xDifferenceGeom(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom1,
  xGEOM_ID geom2
#endif
                            );

extern xGEOM_ID xUnionGeom(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom1,
  xGEOM_ID geom2
#endif
                       );

extern xGEOM_ID xUnionMergeGeom(
#ifdef __XOX_PROTOTYPES__			     
  xGEOM_ID geom1,
  xGEOM_ID geom2,
  xINT  *flag
#endif
			     );

extern xINT xIntersectingGeomsP(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom1,
  xGEOM_ID geom2,
  xREAL tol
#endif
                              );

extern xGEOM_ID xRegularizedIntersectionGeom(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom1,
  xGEOM_ID geom2
#endif
					  );





extern xREAL xGeomVolume(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom
#endif
                        );

extern xREAL *xGeomCenterOfMass(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom,
  xREAL center[]
#endif
                               );

extern xREAL xGeomsFacetedMinDist(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom1,
  xGEOM_ID geom2,
  xREAL minTol,
  xREAL maxTol,
  xVERTEX_ID *vert1,
  xVERTEX_ID *vert2
#endif
                                 );




extern xGEOM_ID xAssemblyGeom(
#ifdef __XOX_PROTOTYPES__
  xINT_LIST geomList,
  xINT_LIST transList
#endif
                          );

extern xGEOM_ID xSewnGeom(
#ifdef __XOX_PROTOTYPES__
  xINT_LIST geomList
#endif
                      );





xFRAME_ID xMakeFrame(
#ifdef __XOX_PROTOTYPES__
  xINT_LIST basicGeoms,
  xINT_LIST orients
#endif
                 );


xGEOM_ID xReplaceGeomFrames(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom,
  xINT_LIST frameTree,
  xINT naturalBoundsP
#endif
                        );


xGEOM_ID xReplaceGeomFramesA(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom,
  xGEOM_ID *frameTree,
  xINT  numFrames,
  xINT naturalBoundsP
#endif
			);

 
xGEOM_ID xTrimGeomFramesA(
#ifdef __XOX_PROTOTYPES__
     xGEOM_ID  geomId,   		
     xGEOM_ID *frameTree,		
     xINT      numFrames 		
#endif
                    );


xINT_LIST xGeomFrameTree(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom
#endif
                        );


xINT_LIST xFrameComponents(
#ifdef __XOX_PROTOTYPES__
  xFRAME_ID frame
#endif
                          );


xINT_LIST xFrameComponentOrientations(
#ifdef __XOX_PROTOTYPES__
  xFRAME_ID frame
#endif
                                     );




extern xGEOM_ID xParameterizeCurve(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom,
  xREAL startVal,
  xREAL endVal,
  xREAL startPt[],
  xINT   spaceDim
#endif
                               );

extern xINT xGeomType(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom
#endif
                    );

extern char *xGeomTypeString(
#ifdef __XOX_PROTOTYPES__
  xINT   code
#endif
                            );

extern xINT_LIST xDefGeoms(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom
#endif
                          );

extern xGEOM_ID xRootGeom(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom
#endif
		      );

extern xGEOM_ID xCopyGeom(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom
#endif
		      );

extern xGEOM_ID xImbedGeom(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom,
  xINT   spaceDim
#endif
		       );

extern xGEOM_ID xScaleGeom(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom,
  xREAL scale[],  
  xINT   spaceDim
#endif
			);

extern xGEOM_ID xRotateGeom(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom,
  xREAL angle,
  xREAL begPoint[],
  xREAL endPoint[],
  xINT   spaceDim
#endif
			);

extern xGEOM_ID xXRotateGeom(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom,
  xREAL angle
#endif
			 );

extern xGEOM_ID xYRotateGeom(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom,
  xREAL angle
#endif
			 );

extern xGEOM_ID xZRotateGeom(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom,
  xREAL angle
#endif
			 );

extern xGEOM_ID xTranslateGeom(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom,
  xREAL vector[],  
  xINT   spaceDim
#endif
			   );

extern xGEOM_ID xTransformGeom(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom,
  xREAL matrix[],  
  xINT   numRows,
  xINT   numCols
#endif
			   );

extern xINT xSaveGeom(
#ifdef __XOX_PROTOTYPES__
  xGEOM_ID geom,
  char *fileName
#endif
		    );

extern xGEOM_ID xRestoreGeom(
#ifdef __XOX_PROTOTYPES__
  char *fileName
#endif
			 );

extern xINT xFreeId(
#ifdef __XOX_PROTOTYPES__
  xINT  id
#endif
                  );





extern xINT xSetUserId(
#ifdef __XOX_PROTOTYPES__
  xINT   object,
  xINT   userId
#endif
		      );

xINT_LIST xUserIds(
#ifdef __XOX_PROTOTYPES__
  xINT object
#endif
        	  );


xINT xGenerateDefaultUserIds(
#ifdef __XOX_PROTOTYPES__
  xINT mode
#endif
                           );


xINT xPropagateUserIds(
#ifdef __XOX_PROTOTYPES__
  xINT mode
#endif
        	     );




extern xINT xInitShapes(
#ifdef __XOX_PROTOTYPES__
  void
#endif
		      );

extern xINT xDisconnectShapes(
#ifdef __XOX_PROTOTYPES__
  void
#endif
		            );

extern xINT xStartShapesLog(
#ifdef __XOX_PROTOTYPES__
  char *filename
#endif
		          );

extern xINT xEndShapesLog(
#ifdef __XOX_PROTOTYPES__
  void
#endif
		        );

extern xINT xDisconnectShapes(
#ifdef __XOX_PROTOTYPES__
  void
#endif
		            );





extern xINT xClearError(
#ifdef __XOX_PROTOTYPES__
  void
#endif
		      );

extern xINT xFunctionNumber(
#ifdef __XOX_PROTOTYPES__
  void
#endif
		          );

extern char *xFunctionName(
#ifdef __XOX_PROTOTYPES__
  xINT funcNum
#endif
		          );

extern xINT xErrorNumber(
#ifdef __XOX_PROTOTYPES__
  void
#endif
		       );

extern char *xErrorDescription(
#ifdef __XOX_PROTOTYPES__
  xINT errNum
#endif
		              );

#if !defined(VAX)
extern xINT xSetErrorHandler(
#ifdef __XOX_PROTOTYPES__
  xINT_FUNC userErrorHandler
#endif
			    );
#endif

extern xINT xoxSetErrorHandler(
#ifdef __XOX_PROTOTYPES__
  xINT_FUNC userErrorHandler
#endif
			    );




extern xINT_LIST xIntList(
#ifdef __XOX_PROTOTYPES__
  xINT  size,
  xINT  array[]
#endif
		         );

extern xINT xFreeIntList(
#ifdef __XOX_PROTOTYPES__
  xINT_LIST list
#endif
                       );

extern xINT_LIST xCopyIntList(
#ifdef __XOX_PROTOTYPES__
  xINT_LIST fromList,
  xINT_LIST toList
#endif
                             );

extern xINT xIntListLength(
#ifdef __XOX_PROTOTYPES__
  xINT_LIST list
#endif
                         );

extern xINT_LIST xPushIntListElement(
#ifdef __XOX_PROTOTYPES__
  xINT element,
  xINT_LIST list
#endif
                                    );

extern xINT xPopIntListElement(
#ifdef __XOX_PROTOTYPES__
  xINT_LIST list
#endif
                             );

extern xINT xIntListElement(
#ifdef __XOX_PROTOTYPES__
  xINT_LIST list,
  xINT  position
#endif
                          );

extern xINT xSetIntListElement(
#ifdef __XOX_PROTOTYPES__
  xINT_LIST list,
  xINT  position,
  xINT  value
#endif
                             );

extern xINT_LIST xInsertIntListElement(
#ifdef __XOX_PROTOTYPES__
  xINT_LIST list,
  xINT element
#endif
                                       );		

extern xINT *xIntListArray(
#ifdef __XOX_PROTOTYPES__
  xINT_LIST list
#endif
                                       );		






extern char *xGeometryVersion(
#ifdef __XOX_PROTOTYPES__
  void
#endif
		             );

extern char *xGraphicsVersion(
#ifdef __XOX_PROTOTYPES__
  void
#endif
		             );

extern char *xLibraryVersion(
#ifdef __XOX_PROTOTYPES__
  void
#endif
		            );



extern xINT xUniqueEndPointsP(
#ifdef __XOX_PROTOTYPES__
  void
#endif
);

extern xINT xSetUniqueEndPoints(
#ifdef __XOX_PROTOTYPES__
  xINT value
#endif
);



typedef xINT xRIB;
extern xINT xAddConstantOffsetRib(
#ifdef __XOX_PROTOTYPES__
   xGEOM_ID subGm,
   xGEOM_ID supGm,
   xRIB_ID  rib,
   xREAL offAmt				 
#endif
);				 

extern xINT xAddVariableOffsetRib(
#ifdef __XOX_PROTOTYPES__
   xGEOM_ID subGm,
   xGEOM_ID supGm,
   xRIB_ID  rib,
   xREAL offAmt1,
   xREAL offAmt2				 
#endif
);

extern xINT xAddConstantRadiusRib(
#ifdef __XOX_PROTOTYPES__
   xGEOM_ID edgeGeom,
   xRIB_ID  rib,
   xREAL radius
#endif
);

extern xINT  xAddVariableRadiusRib(
#ifdef __XOX_PROTOTYPES__
   xGEOM_ID edgeGeom,
   xRIB_ID  rib,
   xREAL xoxrd1,
   xREAL xoxrd2
#endif
);

extern xINT xProcessRib(
#ifdef __XOX_PROTOTYPES__
   xRIB_ID rib
#endif
);

extern xRIB_ID xRibForGeom(
#ifdef __XOX_PROTOTYPES__
   xGEOM_ID geom
#endif
);

extern xINT xRibForGeomP(
#ifdef __XOX_PROTOTYPES__
   xGEOM_ID geom
#endif
);

extern xGEOM_ID xGeomForRib(
#ifdef __XOX_PROTOTYPES__
   xRIB_ID rib
#endif
);

extern xINT xRoundAllRibEdges(
#ifdef __XOX_PROTOTYPES__
   xRIB_ID rib, 
   xREAL radius
#endif
);

extern xGEOM_ID xRoundRibEdges(
#ifdef __XOX_PROTOTYPES__
   xRIB_ID rib, 
   xGEOM_ID edges[], 
   xREAL radii[],
   xINT numEdges			       
#endif
);

extern xINT xEnableMitreAtCorner(
#ifdef __XOX_PROTOTYPES__
   xGEOM_ID zeroDGeom,
   xRIB_ID rib
#endif
);

extern xINT xDisableMitreAtCorner(
#ifdef __XOX_PROTOTYPES__
   xGEOM_ID zeroDGeom,
   xRIB_ID rib
#endif
);

extern xINT xAddChamferWidthRib(
#ifdef __XOX_PROTOTYPES__
   xGEOM_ID edgeGeom,
   xRIB_ID  rib,
   xREAL width
#endif
);

extern xINT xDeleteRib(
#ifdef __XOX_PROTOTYPES__
   xGEOM_ID edgeGm,
   xRIB_ID  rib
#endif
);

extern xINT xDeleteAllRibEdges(
#ifdef __XOX_PROTOTYPES__
   xRIB_ID  rib
#endif
);




#define XOX_PSShade         1
#define XOX_GouraudShade    2
#define XOX_PhongShade      3
#define XOX_FlatShade       4
#define XOX_Mesh            5
#define XOX_MeshShade       6
#define XOX_Boundary        7
#define XOX_BoundaryShade   8
#define XOX_HiddenMesh      9
#define XOX_HiddenBoundary  10

#ifdef xcXOX_REV2



 
xGEOM				
xGmFromId xmP((
     xGEOM_ID geomId 		
));
 
xGEOM_ID			
xGmToId xmP((
     xGEOM geom 		
));
 
xVERT				
xVertFromId xmP((
     xVERTEX_ID vertId 		
));
 
xVERTEX_ID			
xVertToId xmP((
     xVERT vert 		
));
 
xFRAME				
xFrameFromId xmP((
     xFRAME_ID frameId 		
));
 
xFRAME_ID			
xFrameToId xmP((
     xFRAME frame 		
));
 
xFACET				
xFacetFromId xmP((
     xFACET_ID facetId 		
));
 
xFACET_ID			
xFacetToId xmP((
     xFACET facet 		
));


#endif


#if defined(__cplusplus)
}
#endif

#if defined(__XOX_PROTOTYPES__)
#undef __XOX_PROTOTYPES__
#endif

#endif

