#ifndef _MULTI_FRONT_H_
#define _MULTI_FRONT_H_
#define NOTMPL

#if !defined(NEW_STL) || defined(HP32_SYS) || defined (HP64_SYS) || defined (HPIA64_SYS)
#include <map>
#if !defined(HP32_SYS) && !defined (HP64_SYS) && !defined (HPIA64_SYS)
using namespace std;
#endif
#else
a1
#include <map.h>
a2
#endif

#include "Element.h"
#include "Connectivity.h"

struct PrioState { 
   INT prio;
   INT time;
   bool operator < (const PrioState &o) const
     { return(prio < o.prio || (prio == o.prio && time < o.time)); }
};

struct NodeWeight {
    INT subd;
    INT weight;
    INT rotWeight;
    INT mark;
    NodeWeight() { subd = -1; weight = 0; rotWeight = 0; mark = -1;}
};

class Decomposition;

class BoundList {
    INT maxIndex;
    INT nObj;
    INT *listIndex;
    INT *list;
 public:
    BoundList(INT size);
    ~BoundList();
    void add(INT n);
    void remove(INT n);
    void reset();
    INT size() { return nObj; }
    INT operator[](INT i) { return list[i]; }
    bool isPresent(INT i) { return listIndex[i] >= 0; }
};

class OrderList {
    INT begin, end, length;
    INT infBegin, infEnd;
    INT midBegin, midEnd;
    INT *listIndex;
    INT *list;
    INT *infList;
    INT *midList;
  public:
    OrderList(INT s);
    ~OrderList();
    INT pop();
//    void remove(INT n);
    void add(INT n, INT p);
    void addInfinity(INT n);
    INT popInfinity();
    void clear();
    bool empty() { return begin == end && infBegin == infEnd; }
};

struct ARInfo {
    double ncgx, ncgy, ncgz;
    double nxs, nys, nzs;
    INT nNd;
};

double cwdrand();

// The simulated anealing rule
class SARule {
        double ee[1000];
  public:
        SARule();
        bool accept(double v, double T) {
// uncomment the following line to suppres the SA
        return v < 0;
          if(v < 0) return true;
          INT index = INT(200*v/T);
          if(index >= 1000) return false;
          return ee[index] > cwdrand();

        }
};

double balFct(double bal, double invbal, INT nEle);

class MultiFront {
        Elemset *elems;
	CoordSet *nds;
        double (*elemCG)[3];
	Connectivity *nToE;
	Connectivity *eToN;
        bool *elemHasRot;
        INT *assignedSubD;
        INT *flag; // for flagging a single visit of nodes or elements
        INT *nodeMask, *boundNode, *boundIndex;
	INT numBoundNodes;
	INT count;
        INT tag;
        INT numEle;
        INT time;
        INT desiredNSub;
        float currEWeight;

        INT *elemID;
        INT checkElemID;

#ifdef NOTMPL
	OrderList prio;
#else
        // priority of elements in subdomains
        map<INT,PrioState> lastPrio;
        // now sorted per priority
        map<PrioState, INT> prio;
#endif
        // data structure for node weights:
        NodeWeight *nw;
        INT *nSubPerNode;
        INT *elemPerSub;

        double arCoef, boundCoef, elemCoef;

        ARInfo * arInfo;

        double add(ARInfo &, INT node);
        double remove(ARInfo &, INT node);
        void rebuildInfo(Decomposition *dec);
        void remapAll(INT *subRemap);
        INT getEventTag() { return tag++; }
        void addNodesToSub(INT, INT, INT *);
        void addElemToSub(INT, INT, INT);
        void updateElement(INT, INT);
        void initDec(INT);
	void addBoundNode(INT);
	void removeBoundNode(INT);
        double findBestDelta(INT elem, INT &sub, ARInfo &res, ARInfo &cur);
        double buildARInfo(Decomposition *);
/*      double balFct(double bal, double invbal, INT nEle); */
        Decomposition *optimize(Decomposition *);
        Decomposition *improveDec(Decomposition *);
	Decomposition *checkComponents(Decomposition *dec);
	
	INT numSubForNode(INT node);
  public:
        MultiFront(Elemset *eSet, CoordSet *nds = 0);
        Decomposition * decompose(INT nsub, INT CPUs, Elemset *contactSet, INT *elemID, INT numCPU, INT nsubContact, INT optDecomp,  Connectivity *disCntEtoN);
        // Weight of a node in a subdomain
        INT weight(INT sub, INT node);
        INT rotWeight(INT sub, INT node);
        INT incrWeight(INT, INT, INT rMode=0);
        INT decWeight(INT, INT, INT rMode=0);
        INT numConnectedSub(INT node);
        // Total weight of a node
        INT weight(INT);
        Connectivity *getNToE() { return nToE; }
	void memEstimate(Decomposition *, INT dofsPerNode, double me[5]);
        INT bestSubFor(INT nNd, INT *nd) ;
};

#define MAX_DOMAINS    400000      /* from DomainCom.inc */

class Smooth {

        Elemset *elems;
        CoordSet *nds;

        Connectivity* cpuToSub;
        Connectivity* cpuToEles;
        Connectivity* subToEles;
        Connectivity* elesToNode;
        Connectivity* nodeToEles;
        Connectivity* cpuToNode;
        Connectivity* nodeToCpu;
        Connectivity* elesToSub; 
        Connectivity* elesToEles; 

        INT nnd, nel, numCPU, numSub; 
    
        INT debuglvl;
        INT evOutput;
        INT *flag; 
        INT *boundNode, *boundIndex;
        INT numIntfNodes;
        INT tag;
        NodeWeight *nw;
        bool *elemHasRot;
        INT *nCpuPerNode;
        INT *elemPerCpu;
        INT *elemPerSub;
        INT *assignedCpuD;
        INT *assignedSubD;
        double arCoef, boundCoef, elemCoef;
        double dc1, dc2, dc3;
        double deltaBound, deltaAR, deltaBal;
        ARInfo * arInfo;

        double (*elemCG)[3];

        INT getEventTag() { return tag++; }

        void rebuildInfo();
        void addBoundNode(INT);
        void removeBoundNode(INT);
        double buildARInfo(ARInfo *);
        double add(ARInfo&, INT);
        double remove(ARInfo &, INT);
        double findBestDelta(INT, INT &, ARInfo &, ARInfo &, ARInfo *, INT&);

  public:

        INT *newEorder;
        INT *newCpuPtr;
        INT *subDomainPtr;
 
        Smooth(Elemset*, CoordSet*, Connectivity *, Connectivity *, Connectivity *, INT);
        INT incrWeight(INT, INT, INT, INT);
        INT decWeight(INT, INT, INT);
        INT rotWeight(INT , INT);
        INT weight(INT, INT);
        INT weight(INT);
        void go(INT *);
};

#endif

