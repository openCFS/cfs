#ifndef __C_GMAT_H__
#define __C_GMAT_H__ 1

#include "C_VecPi.h"
#include "C_MatSp.h"
#include "vtc_equation.h"
#include "vtc_element.h"

class C_AnsysModele;

class C_ElemEquations
{
public:
  C_ElemEquations(C_AnsysModele *model);
  ~C_ElemEquations();
  
  // access routines 
  int getNbElements()			{return _nbElements;	}
  C_CElement *getElement(int ie)	{return _elements[ie];	}
  
  // add zs of a contact element
  void setGelem(int numero, int *ls, double *zs, double *zsc, int nr);
  
  // to fill a sparse matrix
  void fillNnzRows();
  void fillGmat();

  // print method
  void Print();
  
protected:
  int			_nbElements;
  C_CElement		**_elements;	// dim = number of elements
};

// coupling matrice between DOFs
class C_CouplingMat
{
public:

  static int            S_nbCEs;
  
  typedef enum {
    E_CE_USER = 0,	// external CEs
    E_CE_INTERNAL,	// internal CEs
    E_CONTACT,		// CEs from contact elements
    E_MPC		// CEs from MPC elements
  } E_TYPE;
  
  C_CouplingMat(E_TYPE type, bool distributed);
  virtual ~C_CouplingMat() {}
  
  int getNbEqs() {return _nbEqs;}
  
  C_MatSp<double>	&getG()			{return _Gmat;		}
  C_VecP<double>	&getg0()		{return _g0;		}
  C_VecPi<int>		&getLagToAns()		{return _LagToAns;	}
  C_VecPi<double>	&getLambdaScale()	{return _lambdaScale;	}
    
  // normalize the equations
  void Normalize(int typenrm = 2);
  
  // scale G and g0
  void SMlt(double coef);

  // display error of ||Gt*U-g0|| / ||g0||
  void checkGtUmg0(C_Vec<double> &uAns, string message);
  
  // print CEs
  virtual void createCEs();
  
protected:
  E_TYPE		_type;
  int			_nbEqs, _nbddl;
  C_MatSp<double>	_Gmat;
  C_VecP<double>	_g0;
  bool			_distributed;
  
  C_VecPi<int>		_LagToAns;
  C_VecPi<double>	_lambdaScale;
};

// coupling matrice which comes from elements siffness
class C_Gelem : public C_CouplingMat
{
public:
  C_Gelem(E_TYPE type, bool distributed);
  ~C_Gelem();

  C_VecPi<int>		&getAnsToLag()		{return _AnsToLag;	}
  
  // build _AnsToLag
  void InitMapping(C_AnsysModele *model);
  
  // fill the matrix
  void buildGmatAndg0(C_ElemEquations *elemEqs);
  
  // apply mapping
  void AnsToLag(C_Vec<double> &uAns, C_Vec<double> &uLag);
  
  // print CEs
  void createCEs();
  
protected:
  C_VecPi<int>		_AnsToLag;
};

// coupling matrice which comes from CPCEs
class C_Gcpce : public C_CouplingMat
{
public:
  C_Gcpce(E_TYPE type, bool distributed);
  ~C_Gcpce();
  
  // fill the matrix
  void buildGmatAndg0(C_ElemEquations *elemEqs, int numCE, bool *ceInternal, int *ceLen, int **ceNodes, int **ceDofs, double **ceCoefs, double *ceRHS,
		      int numCP = 0, int *cpLen = NULL, int **cpNodes = NULL, int *cpDofs = NULL);
  
  // print CEs
  void createCEs();
  
  C_Vec<double>		&getSumGtU()		{return _sumGtU;	}
  
  void Zero();
  void Send(double *dual);
  void Recv(double *dual);
 
protected:
  int			_nbInternalCEsMPC;
  C_VecPi<double>	_sumGtU;
};

extern C_ElemEquations *G_ElemEqs;
extern C_Gelem         *G_Gmat;

#endif
