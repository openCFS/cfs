/*******************************************************************************
 *
 *   C_AnsysModele.h - 
 *               
 * 
 * |Module:  API with Ansys Modele
 *
 * |Description: 
 *
 * |Includes:	
 *        
 * |Auteur: Emmanuel DELOR
 *
 * |Creation: July 2005
 *
 * |Version:
 *
 * |Historique:
 *
 * |Copyright:	copyright(c) 2009 SAS IP, Inc.  All rights reserved.
 *
 *
 ******************************************************************************/


#ifndef __C_ANSYSMODELE_ 
#define __C_ANSYSMODELE_ 1

#include "cadoe.h"
#include "cadoesys.h"
#include "bf.h"
#include "C_MessageTool.h" 
#include "ansysdef.h"
#include "elempr.h"
#include "Fx_Info.h"
#include "C_VecP.h"
#include "C_VecPi.h"
#include "CadoeAnsys.h"

#define CADOE_NAMESIZE 249	// redefine it to not include sx_cons_solver.h

#if defined(LOWERCASENOUNDER_SYS)
#define SortComp		sortcomp
#define dofc                    dofc
#define dofiqr			dofiqr
#define dnodgt			dnodgt
#define sxnl_isResult		sxnl_isresult
#define C_AnsysModeleInit	c_ansysmodeleinit
#define C_AnsysModeleInitDisp	c_ansysmodeleinitdisp
#define C_AnsysModeleSendI	c_ansysmodelesendi
#define C_AnsysModeleSendD	c_ansysmodelesendd
#define applyBCToUfull		applybctoufull
#endif

#if defined(UPPERCASENOUNDER_SYS)
#define Sortcomp		SORTCOMP
#define dofc                    DOFC
#define dofiqr			DOFIQR
#define dnodgt			DNODGT
#define sxnl_isResult		SXNL_ISRESULT
#define C_AnsysModeleInit	C_ANSYSMODELEINIT
#define C_AnsysModeleInitDisp	C_ANSYSMODELEINITDISP
#define C_AnsysModeleSendI	C_ANSYSMODELESENDI
#define C_AnsysModeleSendD	C_ANSYSMODELESENDD
#define applyBCToUfull		APPLYBCTOUFULL
#endif

#if defined(LOWERCASEUNDER_SYS)
#define SortComp                sortcomp_
#define dofc                    dofc_
#define dofiqr			dofiqr_
#define dnodgt			dnodgt_
#define sxnl_isResult		sxnl_isresult_
#define C_AnsysModeleInit	c_ansysmodeleinit_
#define C_AnsysModeleInitDisp	c_ansysmodeleinitdisp_
#define C_AnsysModeleSendI	c_ansysmodelesendi_
#define C_AnsysModeleSendD	c_ansysmodelesendd_
#define applyBCToUfull		applybctoufull_
#endif

extern "C" {
  SUBROUTINE SortComp (int*, int*);
  INT  cGetAnsElmExt2IntListPtr(INT**);
  INT FUNCTION dofc(int*, int*, double*, double*);
  SUBROUTINE dofiqr(int*, int*, int*);
  INT FUNCTION dnodgt(int*, int*, double*);
  INT FUNCTION sxnl_isResult(int *result);
  SUBROUTINE C_AnsysModeleInit();
  SUBROUTINE C_AnsysModeleInitDisp();
  SUBROUTINE C_AnsysModeleSendI(int *, int *);
  SUBROUTINE C_AnsysModeleSendD(int *, double *);
  SUBROUTINE applyBCToUfull(double *, int *);
}


class C_ConstraintEquation
{
 public:
  C_ConstraintEquation();
  C_ConstraintEquation(int id, bool internal = false);
  virtual ~C_ConstraintEquation() {};
  
  typedef enum {
    E_TYPE_CP = 0,
    E_TYPE_CE
  } E_TYPE;
  
  virtual void Resize(int size);
  virtual void Get(int flag) = 0;
  virtual void Put(int flag) = 0;
  virtual int Read(FILE *fp);
  virtual int Write(FILE *fp);
  int getId() {return _id;}
  int getType() {return _type;}
  int getSize() {return _size;}
  
 public:
  int	_id;	// identifiant 1 <= _id <= nbCE
  bool _internal;
  E_TYPE _type;
  int	_size;
  C_VecPi<int> _dofList;
};

class C_CP : public C_ConstraintEquation
{
 public:
  C_CP(int id, bool internal = false);
  C_CP(int id, int size, int *dofList, bool internal = false);
  ~C_CP() {};
  
  static C_VecPi<int> *S_dofBuffer;
  
  void FillSummary(string &message);
  void Get(int flag);
  void Put(int flag);
};

class C_CE : public C_ConstraintEquation
{
 public: 
  C_CE(int id, bool internal = false);
  C_CE(int id, int size, int *dofList, double *coefList, bool internal = false);
  ~C_CE() {};
  
  virtual void Resize(int size);
  
  bool isInternal() {return _internal;}
  
  void saveCnst() {_cnst = _coefsList[_size];};
  void setCnstZero() {_coefsList[_size] = 0.;};
  void restoreCnst() {_coefsList[_size] = _cnst;};

  void Get(int flag);
  void Put(int flag);
  
  int Read(FILE *fp);
  int Write(FILE *fp);

  void Print(FILE *fp);
  void FillSummary(string &message);
  
  static C_VecPi<int> *S_dofBuffer;
  static C_VecPi<double> *S_coefsBuffer;
  
 protected:
  C_VecP<double>  _coefsList; 
  double _cnst;
};

class C_ConnecCrit
{
public: 
  C_ConnecCrit() {};
  virtual ~C_ConnecCrit() {};
  
  virtual bool isActive(int indice) = 0;
  virtual int findElemNeighBour(int elem, C_VecPi<int> &neighBourList) = 0;
};

class C_PropValCrit
{
public: 
  C_PropValCrit() {};
  virtual ~C_PropValCrit() {};
  
  virtual int getVal(int indice) = 0;
};

class C_PropActCrit
{
public: 
  C_PropActCrit() {};
  virtual ~C_PropActCrit() {};
  
  virtual bool isActive(int indice) = 0;
};

class C_Body;
class C_BodyElem;

class C_AnsysModele
{
public:
  // constructor 
  C_AnsysModele();
  
  // destructor
  virtual ~C_AnsysModele();
  
  // get the version of the object 
  const char	*Version() const { return (char *)"7";}
  
  int getNbElements() {return _nbElements;}
  int getNbNodes() {return _nbNodes;}
  int getNbDofPerNode() {return _nbDofPerNode;}
  int getStructural() {return _structural;}
  int getContact() {return _contact;}
  int isContactElements() {return _isContactElements;}
  int isContactElement(int numNode) 
  {
    int typeGeometrique = getTypeGeometrique(numNode);
    return (typeGeometrique == 12 || (typeGeometrique >= 169 && typeGeometrique <= 178));
  }
  int getNbddl() {return _nbddl;};
  int getNbcs() {return _nbcs;}
  int getNrkey() {return _nrkey;}
  int* getContactDOFMarker() {return _ContactDOFMarker;}
  string &getLogFileName() {return _logFileName;}
  
  C_VecPi<int> &getFullToBcs() {return _FullToBcs;}
  C_VecPi<int> &getFullToAns() {return _FullToAns;}
  C_VecPi<int> &getBcsToAns() {return _BcsToAns;}
  C_VecPi<int> &getAnsToBcs() {return _AnsToBcs;}
  
  C_VecPi<int> &getListPres() {return _listPres;}
  C_VecPi<double> &getValPres() {return _valPres;}
  C_VecPi<double> &getHugeUinci() {return _hugeUinci;};

  C_VecPi<double> &getUprev() {return _Uprev;}
  C_VecPi<double> &getUinci() {return _Uinci;}
  C_VecPi<double> &getUincn() {return _Uincn;}
  C_VecPi<double> &getUvelo() {return _Uvelo;}
  C_VecPi<double> &getUacel() {return _Uacel;}
  C_VecPi<double> &getURotEP() {return _URotEP;}
  
  C_VecPi<double> &getFnr() {return _linkFnr;}
  C_VecPi<double> &getFtotal() {return _linkFtotal;}
  
  set <C_CP* > &getCP() {return _listCP;}
  set <C_CE* > &getCE() {return _listCE;}
  
  // getNodeCoordinates
  int getNodeCoordinates(int numero, double *xyz) {return ndgxyz(&numero,xyz);}
  
  // apply prescribed on UDisp
  void applyPres(C_Vec<double> &UDisp);
  
  // apply BC (from FULL file) to Ufull
  void applyBCtoUfull(C_Vec<double> &Ufull);
  
  // read CPCE in FULL file
  virtual void readCpCeFromFullFile();
  
  // build connectivity between nodes and elements
  virtual void buildConnectivity();
  
  // initialize object 
  virtual void initialize();

  // Copy Fortran Adress
  virtual void copyFortranAdress(C_AnsysModele *model);
  
  // initialize mapping tables (BCS <-> ANS <-> FULL)
  virtual void InitMapping(bool forceToRead = false);

  // to pass fortran adresses
  void SendFortranI(int request, int *value);
  void SendFortranD(int request, double *value);
  
  // set pointers to fortran memory
  virtual void InitFortran();
  
  // set pointers to fortran memory
  virtual void InitDisp();
  
  // same bounadry conditions between two models ?
  bool isSameBC(C_AnsysModele *model);
  
  bool isInternalNode(int numero);
  
  // is there internal nodes ?
  bool internalNodes();
  
  // get and set fortran variables
  static void fxSetInfoInt(E_info_fx eInfoFx, int ival) {double ddum; fx_setinfo(&eInfoFx,&ival,&ddum);}; 
  static void fxSetInfoDbl(E_info_fx eInfoFx, double dval) {int idum; fx_setinfo(&eInfoFx,&idum,&dval);}; 
  static void fxGetInfoInt(E_info_fx eInfoFx, int &ival) {double ddum; fx_getinfo(&eInfoFx,&ival,&ddum);}; 
  static void fxGetInfoDbl(E_info_fx eInfoFx, double &dval) {int idum; fx_getinfo(&eInfoFx,&idum,&dval);}; 
  
  // BCS space <-> Nodal space
  void BcsToAns(C_Vec<double> &VInd, C_Vec <double> &VNod, bool zeroVNod = true);
  void BcsToAnsExp(C_Vec<double> &VInd, C_Vec<double> &VNod, bool ApplyAllBC);
  void AnsToBcs(C_Vec<double> &VNod, C_Vec<double> &VInd);
  void BcsToFull(C_Vec<double> &Ubcs, C_Vec<double> &Ufull, bool zeroUfull = true);
  void FullToAns(C_Vec<double> &Ufull, C_Vec<double> &Uans, bool zeroUans = true);
  
  // manage HUGE values
  void fillHuge(C_Vec<double> &UDisp);
  void restoreHuge(C_Vec<double> &UDisp);
  void zeroHuge(C_Vec<double> &UDisp);
  
  // apply contribution of slaves DOFs to master DOFs
  void cDerivativeCpGtU(C_Vec<double> &Uprev);
  void cDerivativeGtU(C_Vec<double> &Uprev);
  
  // statistics
  static void cStatBegin(int section);
  static void cStatEnd(int section);
  
  // assembly elements
  void cSfform(C_Vec<double> &Uprev);
  
  // write FULL file
  void cFastSolve(int nbrhs, C_Vec<double> &Uinci, C_Vec<double> &Ftotal);
  
  // get number of contact DOFs
  int getNbDofContact();
  
  // internal <-> external representation 
  inline int getNodeIndice (int numero) {return _Forward[numero-1]-1;}
  inline int getNodeNumero (int indice) {return _Back[indice];};
  inline int getElementIndice (int numero) {return _elmListOut[numero]-1;}
  inline int getElementNumero (int indice) {return _Order[indice];}
  inline int getPremInc (int numero) {return getNodeIndice(numero) * _nbDofPerNode;};
  
  // get distance between two nodes
  double getDistNodes(int node1, int node2);
  
  // get nodes (labels) of an element (label)
  int elementToNodes(int numElem, int numNodes[NNMAX+1]) 
  {
    int elmdat[EL_DIM+1];
    int nbNodes = elmget(&numElem,elmdat,numNodes); 
    /* SortComp(&nbNodes,numNodes);*/
    return nbNodes;
  };
  
  // get elements (indices) of nodes (indice) 
  int nodeToElements(int indNode, int *&indElems) {indElems = &(_connecInv[_pConInv[indNode]]); return(_pConInv[indNode+1]-_pConInv[indNode]);}
  
  // element -> nodes -> elements
  void elemToNodesToElem(int numElem, int *listElemToAssembly);
    
  // get the list of BCS dofs associated to nodes of a list of elements
  int elementToBcsDof(C_VecPi<int> &elems, C_VecPi<int> &dofBcs);
  
  // get the list of BCS dofs associated to a list of nodes
  void nodeToBcsDof(C_VecPi<int> &nodes, C_VecPi<int> &dofBcs);
  
  // get the list of element associated to a list of nodes
  void NodeToElem(BVEC *nodes, BVEC *elems);  
  
  // build region with a critere on the connectivity
  void buildRegion(int nbEntities, C_ConnecCrit &critere, vector <C_BodyElem *> &regions);

  // build boundary
  void buildBoundary(int nbMaxEntities, C_VecPi<int> &entities, C_ConnecCrit &critere, C_VecPi<int> &boundary);
  
  // build region 
  void buildRegionValCrit(int nbEntities, C_PropValCrit &critere, vector <C_Body *> &regions);
  
  // build body with a criteria
  void buildBody(int nbEntities, C_PropActCrit &critere, C_Body &body);

  // find neighbour elements
  int findElemNeighBour(int indElem, C_VecPi<int> &neighBourList);

  // fill internal to user mapping
  void fillIntToUser(C_Vec<int> &IntToUser);
  
  // compute the elements to assembly to get correct forces on DOF in bDofInd
  void ElemToAssembly(BVEC *bDofInd, BVEC *bDofNod, IVEC *listElem, BVEC *bNodes, bool addAllNodesCPCE = false);
  
  // compute the elements to assembly to be able to update correctly the displacement
  void ElemToAssemblyBC(IVEC *listElem);
  
  // get type of an element (label)
  int getTypeGeometrique(int numElem){
    int ielc[IELCSZ+1], elmdat[EL_DIM+1], nodes[NNMAX+1];;
    int etype;
    elmget(&numElem,elmdat,nodes);
    etype = elmdat[1];		// EL_TYPE=2
    etyget(&etype,ielc);
    return ielc[1];		// JETYP=2 in echprm.inc
  }
  
  int isUnsymElement(int nrunsym, int numElem) {
    int ielc[IELCSZ+1], elmdat[EL_DIM+1], nodes[NNMAX+1];
    int etype;
    elmget(&numElem,elmdat,nodes);
    etype = elmdat[1];		// EL_TYPE=2
    etyget(&etype,ielc);
    if (ielc[55] == 0 || (ielc[55] == 2 && nrunsym == 0)) // MTSYM=56
      return false;
    else
      return true;
  }
  
  int getElemIelc(int numElem, int idx)	// idx in fortran numerotation
  {
    int ielc[IELCSZ+1], elmdat[EL_DIM+1], nodes[NNMAX+1];
    int etype;
    elmget(&numElem,elmdat,nodes);
    etype = elmdat[1];		// EL_TYPE=2
    etyget(&etype,ielc);
    return ielc[idx-1];
  }
  
  int getReal(int numElem){
    int elmdat[EL_DIM+1], nodes[NNMAX+1];
    elmget(&numElem,elmdat,nodes);
    return elmdat[2];
  }
  
  // get ith keyoptof an element (label)
  int getKeyopt(int numElem, int keyopt){
    int ielc[IELCSZ+1], elmdat[EL_DIM+1], nodes[NNMAX+1];
    int etype;
    elmget(&numElem,elmdat,nodes);
    etype = elmdat[1];		// EL_TYPE=2
    etyget(&etype,ielc);
    return ielc[1+keyopt];	
  }
  
  // management of CP, CE and prescribed
  void getPrescribed();
  void zeroG0();
  void restoreG0();
  
  // add CP/CE
  void addCP(C_CP *cp);
  void addCE(C_CE *ce);
  
  // IO
  virtual int Write (FILE *fp);
  virtual int Read (FILE *fp);
  
  double MemSize();
  
  void printUAns(C_Vec<double> &Uprev, string message, string fileName = "");
  void printUAns(C_Vec<double> &Uprev, C_Vec<double> &Uinci, C_Vec<double> &Uincn, string fileName = "");
  void printDNSOL(C_Vec<double> &UAns, string fileName = "", bool absVal = false);

  void printUAns(C_Vec<double> &Uprev, string message, FILE *fp);
  void printUAns(C_Vec<double> &Uprev, C_Vec<double> &Uinci, C_Vec<double> &Uincn, FILE *fp);
  void printDNSOL(C_Vec<double> &UAns, FILE *fp, bool absVal = false);

  void printUAns(C_Vec<double> &Uprev, C_Vec<int> &indicesNodes, FILE *fp);
  
  void printCPCE();
  void FillSummary(string &message);
  
protected:
  C_VecPi<int> _pConInv;
  C_VecPi<int> _connecInv;

  int _id;
  int _nbElements;	// nombre d'elements
  int _nbNodes;		// nombre de noeuds 
  int _nbDofPerNode;
  bool _structural;
  int _contact;
  int _isContactElements;
  int _nrkey;
  int _nbcs;
  int _nbddl;

  C_VecPi<int> _FullToBcs;
  C_VecPi<int> _FullToAns;
  C_VecPi<int> _BcsToAns;
  C_VecPi<int> _AnsToBcs;
  
public:
  INT *_Forward;	// external to internal node representation
  INT *_Back;		// internal to external node representation
  INT *_Order;		// internal to external element representation
  
  INT *_First;
  INT *_Last;
  INT *_DofBits;
  
  int *_curdof;
  int *_ContactDOFMarker;
  
  int *_elmListOut;	// external to internal element representation
  
  static double S_precU;

protected:
  // fortran memory
  C_VecPi<double> _linkFtotal;	// link to Ftotal in ANSYS memory 
  C_VecPi<double> _linkFnr;    	// link to Fnr in ANSYS memory 
  
  // Displacement vectors from svkan.F
  C_VecPi<double> _Uprev;     	// ULocal from svkan.F (= Utotal) 
  C_VecPi<double> _Uinci;     	// link to UInci in ANSYS memory 
  C_VecPi<double> _Uincn;     	// link to Uincn in ANSYS memory 
  C_VecPi<double> _Uvelo;	// link to Uvelo in ANSYS memory
  C_VecPi<double> _Uacel;	// link to Uacel in ANSYS memory
  C_VecPi<double> _URotEP;	// link to URotEP in ANSYS memory
  
  int _maxSizeCP;
  set <C_CP* > _listCP;
  int _maxSizeCE;
  set <C_CE* > _listCE;
  
  C_VecPi<int> _listPres;
  C_VecPi<double> _valPres;
  C_VecPi<double> _hugeUinci;
  
  typedef enum
    {
      E_PTRST = 1,
      E_PTRTH = 2,
      E_PTREL = 3,
      E_PTRMAG = 4,
      E_PTRFL = 5
    } E_TYPE_RESULT;

  string _logFileName;		// link to file.sxlog
};

C_AnsysModele * GLOB_GetAnsysModele();
C_AnsysModele *GLOB_GetCopyModel();

#endif 
