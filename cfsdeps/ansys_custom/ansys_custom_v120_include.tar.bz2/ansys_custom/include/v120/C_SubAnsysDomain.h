#ifndef _C_SUBANSYSDOMAIN_H_
#define _C_SUBANSYSDOMAIN_H_

#include "cadoesys.h" 
#include "computer.h" 

#include "FSConnectivity.h" 
#include "AnsysBin.h" 
#include "AnsysElement.h" 
#include "BlockAlloc.h"
#include "FSElement.h"
#include "dds_globals.h"

class C_SubAnsysDomain  
{ 
public: 
  C_SubAnsysDomain(); 
  virtual ~C_SubAnsysDomain(); 
  
  void Init(INT *ivect, INT len1, DOUBLE *dvect, INT len2);
  void setDomains(INT *Domain, INT *Order, INT nDomain);
  void setNodes(DOUBLE *Wrk, INT len);
  void setElem(INT *idump);
  void setRotate(INT *NodeRot, DOUBLE *Nrot, INT num_nrot);
  void setCP(INT *, INT *, INT *Work, INT len);
  void setCE(INT *, INT*, INT*, INT *Work, INT *Work2, DOUBLE *dWork, INT nTerms);
  void setBCs(INT *BcNode, INT *BcDof, DOUBLE *Value, INT numberbc);
  void setForces(INT *BcNode, INT *BcDof, DOUBLE *Value, INT numberfc);
  
  void releaseFEM();
  void releaseBCs();
  
  virtual void Print();
  
protected:  
  int _glNumSub;       	// total number of CPU
  int _localNumSub;    	// current CPU
  
  int _numNodes;	// number of nodes
  int _numEle;		// number of elements
  int _numDof;		// number of DOFs
  int _numRot;		// number of 
  
  double (*_coord)[3]; 
  FSElement **_elements; 
  FSCoordSet *_allNodes; 
  
  int *_dofs;
  
  // rotate nodes
  int *_rotatenode; 
  double (*_rotateval)[3]; 
  
  // BCs
  int _nDBC; 
  BCond *_dBC; 
  
  // Forces
  int _nNBC; 
  BCond *_nBC; 
  
  // CPs
  int _numCP, _numCPmax; 
  int *_cpLen, **_cpNodes, *_cpDofs; 
  
  // CEs
  int _numCE, _numCEmax; 
  bool *_ceIsInternal;
  int *_ceLen, **_ceNode, **_ceDofs; 
  double **_ceCoefs, *_ceRHS;
  
  // allocation
  BlockAlloc _ba; 
};

#endif
