/*HFILE sysutil.h	                                      sam,system
------------------------------------------------------------------------
------- Notice - This file contains ANSYS Confidential information --------
------------------------------------------------------------------------
*/
/* 
 * *** copyright(c) 2009 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */

/*------------------------------ Description ---------------------------
\Author:	Sam Murgie
\Title:		sysutil.h (Header file for sysutil.c)
\Desc:		header file for sysutil.c and for those files that 
		reference modules within sysutil.c.
\History:	94/04/26 - sam: Initial creation

\Function(s) 
 -Primary:	To supply pneumonic static definitions of return values
		to the functions in sysutil.c to be used by referencing
		files.
 -Secondary:	none
 -External:	none
 -Internal:	none
 -Static:	none

----------------------------------------------------------------------*/
#ifndef SYSUTIL_H
#  define SYSUTIL_H


/* ------------  return values for sysciqr  ------------------------- */

#define FILE_EXISTS          0
#define FILE_DOES_NOT_EXIST 11

/* ------------  return values for syscopy  ------------------------- */

#define UNABLE_TO_OPEN_TO   21
#define UNABLE_TO_OPEN_FROM 22


/* ------------  return values for syscopy  ------------------------- */

/*                 as returned by library call getenv                 */



/*--------------------------------------------------------------------*/

/* Below is the endif for the whole file. */ 
#endif



/*---------------------------- End Of Module -------------------------*/
