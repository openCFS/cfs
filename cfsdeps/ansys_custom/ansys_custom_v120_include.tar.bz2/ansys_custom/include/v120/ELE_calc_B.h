/* ELE_calc_B.h CADOE  */
/*
 * ELE_calc_B.h
 *
 * $Id: ELE_calc_B.h,v 1.2.6.1 2009/04/13 14:09:59 jtm Exp $
 *   
 * HISTORY
 *   
 *   06/28/00 10:47 <       Brian Jantzen> Rel:ms8m1    SCCA:74542  Delta:81.3
 *   
 *   06/21/00 16:30 <       Brian Jantzen> Rel:ms8m1    SCCA:74307  Delta:81.2
 */

#ifndef __elecalcbh__
#define __elecalcbh__ 1

/*#ifdef __cplusplus
extern "C" {
#endif*/

#ifndef __listechaineeh__
#include "liste_chainee.h"
#endif

#ifndef __expmdbstructh__
#include "expmdb_struct.h"
#endif

#define AVEC_ALLONGEMENT 1
#define AVEC_CISAILLEMENT 2
#define AVEC_JACOBIEN 3
#define AVEC_MISES 4

extern void		MATB_save_on ( void );
extern T_statut		MATB_save_off ( void );
extern T_booleen	MATB_is_on ( void );
extern MAT 		*MATB_get_mat ( void );
extern void   MATB_free_S_mat_B ( );
extern void   MATB_liberer_memoire ( MAT **mat_B );
extern void   MATB_statut_memoire ( const char *nom );


extern void 		ELE_orienter_element(int,T_Element **);
extern double		ELE_get_orientation ( T_Element *ele, T_booleen avec_pert );

extern double		ELE_calculer_max_defo( T_Element*, int*, T_statut* );
extern MAT*		ELE_rechercher_B( T_Element*, T_statut* );
extern T_statut		ELE_calculer_B( T_Element*, MAT ** );
extern T_booleen	is_a_calculer ( T_Element *);
extern MAT		*ELE_calculer_gradient( T_Element *, VEC *, T_statut * );
extern VEC		*ELE_calculer_cout( T_Element *, VEC *, T_statut * );
extern double		ELE_calculer_max_cout(T_Element *, int *, T_statut *);

/*#ifdef __cplusplus
}
#endif*/

#endif
