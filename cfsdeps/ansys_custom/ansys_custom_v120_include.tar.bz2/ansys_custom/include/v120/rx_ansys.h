/* ANSI_C rx_ansys.h - Interface to epm's R/X for ANSYS */

/*--------------------------------------------------------------------------*/
/* ansys(r) copyright(c) 2009 */
/* ansys, inc.                */
/*--------------------------------------------------------------------------*/

#ifndef __RX_ANSYS_H__  /* Include this file only once! */
#define __RX_ANSYS_H__ 

#ifdef __cplusplus
extern "C" {
#endif

/*--------------------------------------------------------------------------*/

/* For additional code check use -D__lint or -DDEVELOPMENT */
/* NOTE: -D__lint *might* invalidate the code in some system #include files! */
  
#if (defined(__lint) || defined(DEVELOPMENT)) && !defined(rx_lint)
# define rx_lint
#endif

/*--------------------------------------------------------------------------*/

/* rx_iCONST() to avoid compiler warnings about constant conditionals */

#ifdef rx_lint
  int rx_iCONST (int id);
#else
# define rx_iCONST  /*relax*/
#endif

/*--------------------------------------------------------------------------*/

/* ANSI C library headers */

/* necessary for this file.. */
#include <stdio.h>  

/* more often used than not... */
#include <ctype.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

/*--------------------------------------------------------------------------*/

/* Is it UNIX or Windows? */

#if defined(WIN32) || defined(_WIN32) \
  || defined(_M_ALPHA) || defined(decaxpnt_sys) \
  || defined(PCWINNT_SYS)
# define rx_Windows

#else
# define rx_Unix
#endif

/*--------------------------------------------------------------------------*/

/* MAXPATHLEN, MAXINT, MAXLONG */

#ifdef rx_Unix

# include <values.h>
# include <sys/param.h>

#else /* rx_Windows */

# include <limits.h>
# define MAXPATHLEN _MAX_PATH

# define BITSPERBYTE  CHAR_BIT  /* cf. Windows' limits.h & Unix's values.h */
# define BITS(type)  (BITSPERBYTE * (int) sizeof(type))
# define HIBITI  (1 << (BITS(int) - 1))
# define HIBITL  (1L << (BITS(int) - 1))
# define MAXINT  (~HIBITI)
# define MAXLONG  (~HIBITL)

#endif

#ifndef  MAXPATHLEN
# define MAXPATHLEN 64  /* ANSYS hack, just in case */
#endif

/*--------------------------------------------------------------------------*/

/* ltable_iCONST() to avoid compiler warnings about constant conditionals */

#ifdef rx_lint
  int rx_iCONST (int id);
#else
# define rx_iCONST  /*relax*/
#endif
  
/*--------------------------------------------------------------------------*/

/* Assertions and aborts */

#ifdef  assert
# undef assert
#endif

# define assert(EXPR)  if (rx_iCONST (! (EXPR))) rx_abort_with (rx_assstr)
extern char rx_assstr[];

/* rx_abort_with() is called whenever a (nonrecoverable) runtime error
   is encountered.  Can be redefined, but it better aborts execution! */

#define rx_abort_with(MSG)  rx_abort (rx_abfrmt, __FILE__, __LINE__, MSG)

extern char rx_abfrmt[];
void rx_abort (const char *frmt, ...);
void rx_error (const char *frmt, ...);

/*--------------------------------------------------------------------------*/

/* Human-readable logical operators */

#ifndef LINUX_ACIS
#define and    &&
#define or     ||
#define not    !
#define mod    %
#endif
/*--------------------------------------------------------------------------*/

/* In-line if, also human-readable */

#define If(COND,THEN,ELSE)  ((COND) ? (THEN) : (ELSE))

/*--------------------------------------------------------------------------*/

/* Silence cc warnings by marking intentionally unused funtion parameters... */
/* USAGE:  Unused (p1 and p2 and p3)*/
     
#define Unused(PARAM)  (void) (0 and (PARAM))

/*--------------------------------------------------------------------------*/

/* Nicer loop constructs. */

#define   upfor(I,S,E)  for (I = (S); I <= (E); I++)
#define downfor(I,S,E)  for (I = (S); I >= (E); I--)
#define until(Q)        while (not (Q));

/*--------------------------------------------------------------------------*/

/* The admittedly weird "DoMacro { ... } EndMacro" construct is intended to be
   used inside macro definitions... in order to allow semicolons after macro
   invocations.
   NOTE: I'm sorta hoping that the compiler will optimize the 'if (1)' away! */

#define DoMacro   if (rx_iCONST (1))
#define EndMacro  else {;}

/*--------------------------------------------------------------------------*/

/* Some useful macros. -- WARNING: They might evaluate arguments twice! */

#define Odd(X)  ((X) % 2 == 1)

/* NOTE:
   The proper def of "Even" would be "#define even(X)  (! Odd (X))";
   note the subtile difference to "((X) % 2 == 0)" wrt portability! */

#define Sign(X)  (((X) > 0) ? 1 : (((X) < 0) ? -1 : 0))
#define Abs(X)   (((X) >= 0) ? X : -(X))

#define Min(X,Y)  (((X) < (Y)) ? (X) : (Y))
#define Max(X,Y)  (((X) > (Y)) ? (X) : (Y))

#define Square(X)  ((X) * (X))

#define power2(EXP)    (1L << (EXP))  /* like a function, returning: int */
#define bitsof(TYPE)   (BITS (TYPE))  /* like a function, returning: int  */

/*--------------------------------------------------------------------------*/

/* Common string buffer & simple (temporary!) formatting */

#define rx_BUFLEN 1024
extern char rx_buf[];

char *rx_fmt (const char *frmt, ...);

/*--------------------------------------------------------------------------*/

/* Basic parsing */

int rx_getline (FILE *file, char buffer[], int len);
int rx_getfile (FILE *file, char buffer[], int len);
int rx_tokenize (char string[], char *token[], int maximum);

/*--------------------------------------------------------------------------*/

/* "Convenience" string comparisons */

int rx_match (const char string[], const char pattern[]);
int rx_match_p (const char string[], const char pattern[]);
int rx_match_n (const char string[], const char pattern[], int n);

/*--------------------------------------------------------------------------*/

/* File utilities */

char *rx_strip_path  (const char path[]);
int   rx_file_exists (const char path[]);

int   rx_access (const char path[], const char mode_str[]);
void  rx_putenv (const char *string);
char *rx_getenv (const char *string);

/*--------------------------------------------------------------------------*/

/* rx_print.c - print file, stdout and secondary */

void rx_print (const char *fmt, ...);
void rx_print_space (void);
void rx_print_file (FILE *f);
int  rx_print_output (int q);
void rx_print_flush (void);

/*--------------------------------------------------------------------------*/

#if defined(__cplusplus)
}
#endif

#endif  /* #ifdef __AFRX_ANSYS_H__ */
