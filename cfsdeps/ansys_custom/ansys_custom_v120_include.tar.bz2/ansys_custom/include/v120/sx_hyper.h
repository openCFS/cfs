/* CADOE */
/*
 *  hyper.h	--  definition des structures HYPERMATRIX et BLOCK pour ADOC
 * 
 *  Une hypermatrix correspond a une direction de derivation.
 *  Un block correspond a un ordre de derivation par rapport a une direction
 *   
 * HISTORY
 *   
 *   09/25/00 10:39 <       Brian Jantzen> Rel:ms8m1    SCCA:79107  Delta:81.2
 *   
 *   02/15/00 13:10 <       Brian Jantzen> Rel:ms8      SCCA:68558  Delta:8.4
 *   
 *   11/18/99 02:26 <         James Silva> Rel:ms8      SCCA:61479  Delta:8.3
 *   
 *   09/30/99 17:38 <         James Silva> Rel:ms8      SCCA:56512  Delta:8.2
 */
#include "sx_CADOE_solver.h"
#ifndef _hyperh__
#define __hyperh__ 1

typedef struct __STRUCT_HPM  STRUCT_HPM;
typedef struct __STRUCT_BLK  STRUCT_BLK;

struct __STRUCT_HPM
{
  int numero;       /* Numero associe a l'hypermatrix       */
  int logname;      /* Nom logique associe a l'hypermatrix  */
  int nb_row;       /* Nombre de lignes                     */
  int nb_col;       /* Nombre de colonnne(s)                */
};

struct __STRUCT_BLK
{
  int numero;       /* Numero associe a l'hypermatrix relative au block       */  
  int *logname;     /* Nom logique associe a l'hypermatrix relative au block  */
  int start_row;    /* Numero de la premiere ligne                            */
  int nb_row;       /* Nombre de ligne(s)                                     */
  int start_col;    /* Numero de la premiere colonnne                         */
  int nb_col;       /* Nombre de colonne(s)                                   */
  VEC *vect;        /* Allocation dynamique associee                          */
};

extern Integer *S_ihmbuf;

#endif
