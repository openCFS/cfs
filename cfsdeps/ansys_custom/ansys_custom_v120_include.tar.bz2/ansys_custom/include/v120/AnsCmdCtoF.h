/* ---------------------------------------------------------------------- */
/* *** copyright(c) 2009 SAS IP, Inc.  All rights reserved. */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  AnsCmdCtoF.h */
#if !defined(__ANSCMDCTOF_H__)
#define __ANSCMDCTOF_H__ 1

#include "ansys.h"

#ifdef MAINWIN
#define DOUBLE double
#define CHAR char
#endif

#ifdef MAINWIN
#define INT int
#endif

#if defined (HP_SYS) || defined(HPIA64_SYS) || defined(HP32_SYS) 
    #define const const
#endif 

/* (1)----------------------------------------------------------------*/
#if defined(LOWERCASENOUNDER_SYS)

/*
 *   The pattern for these platforms is the lowercased version of the name
 */

#define DpInFun               dpinfun
#define IntInFun              intinfun
#define Ch128InFunForC        ch128infunforc
#define ParGetArray           pargetarray
#define ParStore              parstore
#define ChToDp                chtodp
#define MAT_ErHandler         mat_erhandler
#define ANS_Plot2DNCurves     ans_plot2dncurves
#define ListWindowStart       listwindowstart
#define ListWindowEnd         listwindowend
#define NlPut                 nlput
#define NlInqr                nlinqr
#define MpInqr                mpinqr
#define NlDel                 nldel
#define TbHdUp                tbhdup
#define GetMaterialMaxTableSize getmaterialmaxtablesize
#define SetMaterialMaxTableSize setmaterialmaxtablesize
#define IOPIqr                  iopiqr
#define ANS_GetAxisScaleType    ans_getaxisscaletype
#define ANS_SetAxisScaleType    ans_setaxisscaletype
#define istressput              istressput
#define istressget              istressget
#define istressdel              istressdel
#define istressiqr              istressiqr
#define EtyGet                  etyget
#define ElIntPt                 elintpt
#define ElmIqr                  elmiqr
#define ElmGet                  elmget
#define ElSelV                  elselv
#define GetSecIntgr             getsecintgr
#define ElemIntgPtsShp          elemintgptsshp
#define GetShellLayerNIntPts    getshelllayernintpts
#define GetSecIntgrReinf        getsecintgrreinf
#define PPInqr                  ppinqr
#define INIS_SetWriteStressFlag inis_setwritestressflag
#define GetLoadStep             getloadstep
#endif


/* (2)----------------------------------------------------------------*/
#if defined(UPPERCASENOUNDER_SYS)

/*
 *   The pattern for these platforms is the uppercased version of the name
 */

#define DpInFun               DPINFUN
#define IntInFun              INTINFUN
#define Ch128InFunForC        CH128INFUNFORC
#define ParGetArray           PARGETARRAY
#define ParStore              PARSTORE
#define ChToDp                CHTODP
#define MAT_ErHandler         MAT_ERHANDLER
#define ANS_Plot2DNCurves     ANS_PLOT2DNCURVES
#define ListWindowStart       LISTWINDOWSTART
#define ListWindowEnd         LISTWINDOWEND
#define NlPut                 NLPUT
#define NlInqr                NLINQR
#define MpInqr                MPINQR
#define NlDel                 NLDEL
#define TbHdUp                TBHDUP
#define GetMaterialMaxTableSize GETMATERIALMAXTABLESIZE
#define SetMaterialMaxTableSize SETMATERIALMAXTABLESIZE
#define IOPIqr                  IOPIQR
#define ANS_GetAxisScaleType    ANS_GETAXISSCALETYPE
#define ANS_SetAxisScaleType    ANS_SETAXISSCALETYPE
#define istressput              ISTRESSPUT
#define istressget              ISTRESSGET
#define istressdel              ISTRESSDEL
#define istressiqr              ISTRESSIQR
#define EtyGet                  ETYGET
#define ElIntPt                 ELINTPT
#define ElmIqr                  ELMIQR
#define ElSelV                  ELSELV
#define GetSecIntgr             GETSECINTGR
#define ElmGet                  ELMGET
#define ElemIntgPtsShp          ELEMINTGPTSSHP
#define GetShellLayerNIntPts    GETSHELLLAYERNINTPTS
#define GetSecIntgrReinf        GETSECINTGRREINF
#define PPInqr                  PPINQR
#define INIS_SetWriteStressFlag INIS_SETWRITESTRESSFLAG
#define GetLoadStep             GETLOADSTEP
#endif


/* (3)----------------------------------------------------------------*/
#if defined(LOWERCASEUNDER_SYS)

/*
 *   The pattern for these platforms is the lowercased version of the name 
 *   followed by an underscore
 */

#define DpInFun               dpinfun_
#define IntInFun              intinfun_
#define Ch128InFunForC        ch128infunforc_
#define ParGetArray           pargetarray_
#define ParStore              parstore_
#define ChToDp                chtodp_
#define MAT_ErHandler         mat_erhandler_
#define ANS_Plot2DNCurves     ans_plot2dncurves_
#define ListWindowStart       listwindowstart_
#define ListWindowEnd         listwindowend_
#define NlPut                 nlput_
#define NlInqr                nlinqr_
#define MpInqr                mpinqr_
#define NlDel                 nldel_
#define TbHdUp                tbhdup_
#define GetMaterialMaxTableSize getmaterialmaxtablesize_
#define SetMaterialMaxTableSize setmaterialmaxtablesize_
#define IOPIqr                  iopiqr_
#define ANS_GetAxisScaleType    ans_getaxisscaletype_
#define ANS_SetAxisScaleType    ans_setaxisscaletype_
#define istressput              istressput_
#define istressget              istressget_
#define istressdel              istressdel_
#define istressiqr              istressiqr_
#define EtyGet                  etyget_
#define ElIntPt                 elintpt_
#define ElmIqr                  elmiqr_
#define ElSelV                  elselv_
#define GetSecIntgr             getsecintgr_
#define ElmGet                  elmget_
#define ElemIntgPtsShp          elemintgptsshp_
#define GetShellLayerNIntPts    getshelllayernintpts_
#define GetSecIntgrReinf        getsecintgrreinf_
#define PPInqr                  ppinqr_
#define INIS_SetWriteStressFlag inis_setwritestressflag_
#define GetLoadStep             getloadstep_
#endif


/* (4)----------------------------------------------------------------*/

/*
 *   This section is for definition of prototypes.  Each prototype 
 *   should be ANSI compliant and specify the types of each parameter 
 *   as well as the return type.
 */
#ifdef __cplusplus
extern "C"
{
#endif

DOUBLE FUNCTION DpInFun(INT*);
INT FUNCTION IntInFun(INT*);
SUBROUTINE Ch128InFunForC ( INT*, INT*, FCHAR(str) FCHARL(str_len)) ; 
INT FUNCTION Ch128InFunInC( INT, CHAR* ) ;
INT FUNCTION ParStore ( INT*, INT*, DOUBLE*, FCHAR(str1), FCHAR(str2), INT* FCHARL(str1_len) FCHARL(str2_len)) ; 
SUBROUTINE ChToDp ( FCHAR(str), DOUBLE* FCHARL(str_len) ) ;
SUBROUTINE MAT_ErHandler( FCHAR(fname), INT*, INT*, FCHAR(emsg) FCHARL(fname_len) FCHARL(emsg_len) ) ;
INT FUNCTION ANS_Plot2DNCurves( FCHAR(str1), FCHAR(str2), FCHAR(str3), FCHAR(str4), 
                       INT*, DOUBLE*, DOUBLE*, INT* , INT*
                       FCHARL(str1_len) FCHARL(str2_len) FCHARL(str3_len) FCHARL(str4_len)) ;
SUBROUTINE ListWindowStart ( FCHAR(str) FCHARL(str_len) ) ;
SUBROUTINE ListWindowEnd ( INT* ) ;
SUBROUTINE NlPut(INT*, INT*, INT*, DOUBLE*) ;
INT FUNCTION NlInqr(INT*, INT*, INT*) ;
SUBROUTINE NlDel(INT*, INT*) ;
INT FUNCTION MpInqr(INT*,INT*,INT*) ;
SUBROUTINE TbHdUp( INT* , DOUBLE* ) ;
INT FUNCTION GetMaterialMaxTableSize() ;
SUBROUTINE SetMaterialMaxTableSize( INT* ) ;
INT FUNCTION IOPIqr( INT* ) ;
SUBROUTINE ANS_GetAxisScaleType( INT*, INT* ) ;
SUBROUTINE ANS_SetAxisScaleType( INT*, INT* ) ;
SUBROUTINE istressput(INT*,INT*,DOUBLE*);
INT FUNCTION istressget(INT*,DOUBLE*);
INT FUNCTION istressiqr(INT*,INT*) ;
SUBROUTINE istressdel(INT*) ;
INT FUNCTION EtyGet(INT*,INT*) ;
INT FUNCTION ElmIqr(INT*,INT*) ;
INT FUNCTION ElSelV(INT*,INT*,INT*,INT*) ;
INT FUNCTION GetSecIntgr(INT*,INT*) ;
INT FUNCTION ElmGet(INT*,INT*,INT*) ;
INT FUNCTION ElemIntgPtsShp(INT*,INT*,INT*,INT*,INT*);
SUBROUTINE GetShellLayerNIntPts(INT*,INT*,INT*) ;
INT GetSecIntgrReinf(INT*,INT*) ;
INT FUNCTION PPInqr(INT* pQuery);
SUBROUTINE INIS_SetWriteStressFlag(INT*);
INT FUNCTION GetLoadStep();
#ifdef __cplusplus
}
#endif

#endif

