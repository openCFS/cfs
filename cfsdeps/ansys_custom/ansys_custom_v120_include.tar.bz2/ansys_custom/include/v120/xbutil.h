
/*
 *    author/date: yu-hua ting/10-29-93
 *
 *    primary function:
 *
 *    Header for the "utility" routines in the Ansys/Shapes Interface
 *
 *    secondary function:
 *
 *        none
 *
 *    routines included:
 *
 *
 *    history
 *
 *        none
 *
 *    comments:
 *
 *        none
 *
 *    Notice - This file contains ANSYS Confidential information ***
 *
 */
/* 
 * *** copyright(c) 2009 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */


 
/****************************************************************************
 *    Sort an array of integers (bubble sort)                               *
 ****************************************************************************/

      extern VOID xSortIntArray_xax ansPROTO((
             INT iarray[],
             INT length));



/****************************************************************************
 *    Sort an array of integers (bubble sort)                               *
 ****************************************************************************/

      extern VOID xSortIntArray_1_xax ansPROTO((
             INT iarray[],        /* I    an array of integers                       */
             INT ipositions[],    /*    O sorted positions of the array of integers  */
             INT length));        /* I    length of the list                         */

 

/****************************************************************************
 *    Compute the transitive closure of a relation                          *
 ****************************************************************************/

      extern VOID xTransitiveClosure_xax ansPROTO((
             INT irelation[],     /* I/O  a relation                                 */
             INT n));             /* I    "irelation" is a n x n matrix of 0s and 1s */
 
  
/**************************************************************************** 
 *    Invert an integer array                                                *
 ****************************************************************************/
  
      extern VOID xInvertIntArray ansPROTO((
             INT iarray[],
             INT length));
 


/****************************************************************************
 *    return TRUE , if each element of a sorted array occurs exactly twice  *
 *           FALSE, otherwise                                               *
 ****************************************************************************/


      extern INT xTwiceSortIntArray_xax ansPROTO((
             INT iarray[],
             INT length)); 



/****************************************************************************
 *    Copy an integer list in SHAPES to (from) an array of integers         *
 ****************************************************************************/
 
 
      extern VOID xCopyIntList_xax ansPROTO((
             xINT_LIST list,
             INT   iarray[],
             INT     length,
             INT       iopt,
             xTAG       tag,
             INT     *iretp)); 





/****************************************************************************
 *    convert SHAPES orientations to (from) ANSYS orientations              *
 ****************************************************************************/

      extern VOID xConvertOrientations_xax ansPROTO((
             INT shapes_orientations[],  /* I/O  SHAPES orientations              */
             INT ansys_orientations[],   /* I/O  ANSYS orientations               */
             INT num_orientations,       /* I    number of orientations           */
             INT iopt));                 /* I    option
                                          *      == FROM_SHAPES_ORIENTATIONS or
                                          *      == TO_SHAPES_ORIENTATIONS        */


/****************************************************************************
 *    convert a frame tree of SHAPES to (from) a shell tree or loop tree    *
 *    of ANSYS                                                              *
 ****************************************************************************/

      extern VOID xConvertFrameTree_xax ansPROTO((
             xGEOM_ID shapes_tree[], /* I    a frame tree of SHAPES                  */
             INT ansys_tree[],    /*   O  a shell tree or loop tree of ANSYS      */
             INT num_frames,      /* I    number of frames in the frame tree, both
                                   *      the arrays shapes_tree, and ansys_tree
                                   *      are of size == 2*num_frames             */
             INT iopt));          /* I    option
                                   *      == FROM_FRAME_TREE or
                                   *      == TO_FRAME_TREE                        */


  

/****************************************************************************
 *    detect the duplicates in an integer array                             *
 *    == FALSE - no duplicates                                              *
 *    == TRUE  - duplicates exist                                           *
 ****************************************************************************/

      extern INT xDetectDuplicateIntArray_xax ansPROTO((
             INT ia[],
             INT n));
 
/****************************************************************************
 *    copy an integer array to another integer array                        *
 ****************************************************************************/

      extern VOID xCopyIntArray_xax ansPROTO((
             INT ia[],
             INT ib[],
             INT n));


 
/****************************************************************************
 *    Compute the orientation signs of ANSYS entities                       *
 ****************************************************************************/
 
      extern VOID xEntityOrientSign_xax ansPROTO((
             INT entnum[],        /* I    ANSYS entity numbers                     */
             INT *nentp,          /* I    pointer to the number of ANSYS entities  */
             INT *flipp,          /* I    pointer to the flag for flipping the 
                                   *      orientation signs
                                   *      == TRUE or FALSE                         */
             INT orient[]));      /*   O  orientation signs of ANSYS entities      */

/****************************************************************************
 *    orient the ANSYS entities according to orientation                    *
 ****************************************************************************/


      extern VOID xEntityOrient_xax ansPROTO((
             INT entnm[],         /* I    ANSYS entity numbers                      */
             INT *nentp,          /* I    pointer to the number of ANSYS entities   */
             INT orient[],        /* I    orientation signs of ANSYS entities       */
             INT oentnm[]));      /*   O  entity numbers of oriented ANSYS entities */




/**************************************************************************************
 *    check a basic geom for manifold condition                                       *
 *                                                                                    *
 *    return FALSE, if the basic geom is not a manifold                               *
 *           TRUE , otherwise                                                         *
 *                                                                                    *
 *    2-geom : make sure that each end point of the xsublines of the subline list of  *
 *             the 2-geom occurs exactly twice in the endpoints of xsublines          *
 *             (this is a necessary condition for a manifold xsubarea)                *
 *                                                                                    *
 *    3-geom : make sure that each xsubline of the xsubareas of the subarea list of   *
 *             the 3-geom occurs exactly twice in the xsublines of xsubareas          *
 *             (this is a necessary condition for a closed manifold xsubvolume)       *
 **************************************************************************************/


      extern INT xBasicGeomManifoldCheck_xax ansPROTO((
             INT geom,            /* I    geom number of a basic geom                         */
             INT dimension,       /* I    geometry dimension of the basic geom                */
             INT *iretp));        /*   O  pointer to the error code
                                   *      == 0 - no error
                                   *      != 0 - error                                        */

/*
 *    print a sub_array of an array of DOUBLE precision reals
 */
      extern VOID uwdpc ansPROTO((
             DOUBLE a[],
             INT n1,
             INT n2));

 
/*
 *    print a sub_array of an array of integers
 */
      extern VOID uwintc ansPROTO((
             INT a[],
             INT n1,
             INT n2));

