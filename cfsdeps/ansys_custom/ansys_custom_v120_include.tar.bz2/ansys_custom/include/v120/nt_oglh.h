/* 
 * *** copyright(c) 2009 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */

   void d2clxx( int );
   void d2clrc( int, GLdouble *, GLdouble *, GLdouble * );
   void d3linx( double *, int, int, int * );
   void d3tfan_linx( int, double *, int * );
   void d3tri_linx( int, double *, int * );
   void d3rfxx( void );
   void silcrs( double [], double [], double [] );
   void silnrm( double [], double [] );
   void silxfm( int, double [], double [], double, double [], double, int,
                int, double [], double, int, int, double [], double,
                double [], double, double, int );

   void silsiz( int * );
   void silwin( double, double, double, double );
   void expoxx( int, int, int, int );
   int  opnwxx( int *, int * );
   BOOL bSetDCPixelFormat( HDC );
   void killxx( void );
   void gl_expose( HWND, RECT * );
   void gl_resize( HWND );
   void xxinfo( int, long );
   long xxinqr( int );
   void gtwnxx( int *, int *, int *, int * );
   void gl_dump_expose( void );
   void font_stuf( int, int *, int *, int *, int *, int *, int * );
   void gl_qqfonts( void );
   int CALLBACK enumFontNamesGL(LPENUMLOGFONT, LPNEWTEXTMETRIC, int, LPARAM);
   void d2patn( void );
   void gl_copy( void );
   void gl_getimg( void );

