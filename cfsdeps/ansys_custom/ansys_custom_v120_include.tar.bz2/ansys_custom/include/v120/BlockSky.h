#ifndef _BLOCK_SKY_H_
#define _BLOCK_SKY_H_ 1

/*****************************************************************************
 *                   Copyright (C) 1999 CMSoft                               *
 *                                                                           *
 *  These lines of code and declarations contain unpublished proprietary     *
 *  information of CMSoft. They may not be copied or duplicated in whole     *
 *  or part without prior authorization from CMSoft.                         *
 *                                                                           *
 *****************************************************************************/

#include "commun.h"
#include "C_MatMGe.h"
#include "C_MatCSR.h"

class Connectivity;
class EqNumberer;
class DofSetArray;
class FullM;
class AssembledFullM;
class FSVector;
class FSFullMatrix;
class FSRbm;

#include <stdio.h>
#include "Solver.h"
#include "SparseMatrix.h"
#include "Communicator.h"

class BlockSky : public FSAssembledSolver {
  int nBlocks;   // number of blocks or supernodes
  int *blWeight; // multiplicity of each supernode
  int *blHeight; // height of each supernodal rectangle
  int *blTop; // begining of each supernodal rectangle
  int *firstDof;
  int *lastCol;
  int *dlp; // diagonal location pointer (non-FORTRAN style)
  int *rowColNum;
  int maxBlockSize; // maximum area of a block
  double *invDiag;
  int *perm;

  double tol;

  int neq;
  int nzem;
protected:
  double *skyA;
#ifdef sgi
  void pFactor(int iThread, int numThread, barrier_t *b, 
	       double *ltmp, double *invDiag, double *origDiag);
#endif
public:
  BlockSky();
  BlockSky(FSConnectivity *nodeToNode, EqNumberer *eqnums, double tol);
  BlockSky(FSConnectivity *nodeToNode, DofSetArray *eqnums, double tol);
  BlockSky(FSConnectivity *nodeToNode, DofSetArray *dsa, double tol, int *glInternalMap);
  ~BlockSky();
  
  double *data() {return skyA;}
  void factor();
  void unify(FSCommunicator *comm);
  void parallelFactor();
  void solve(double *f);
  void solve(FSVector &f);
  void solve(int numRHS, double **RHS);
  void solve(double *rhs, double *sol);
  void solve(FSVector &rhs, FSVector &sol);
  // assembly
  void add(FullSquareMatrix &, int *dofs);
  //void add(AssembledFullM &, int *dofs);
  void add(FSFullMatrix &, int rowStart, int colStart);
  //void addBoeing(int, const int *, const int *, const double *, int *);
  void add(FSFullMatrix &kel, int *dofs);

  void print(char *msg);
  void WriteMatlab(FILE *fp);

  void toMatMGe(C_MatMGe<double> &fullMat);
  void toMatSp(C_MatSp<double> &csrMat);
  
  int neqs() { return neq; }
  double getSolutionTime() { return 0.0; }
#ifdef PCWINNT_SYS
  long size() { return dlp[neq-1]; }
#else
  long long size() { return dlp[neq-1]; }
#endif
  double diag(int i) { return skyA[dlp[i]]; }
  void zeroAll();
  void clean_up();
  int dim()    { return neq;  }
  int numRBM() { return nzem; }
  FSRbm* getRBMs() {return NULL;}
};

#endif
