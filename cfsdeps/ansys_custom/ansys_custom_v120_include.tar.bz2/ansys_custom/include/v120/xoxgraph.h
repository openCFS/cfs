/**** Copyright XOX Corporation - 1989, 1990, 1991, 1992, 1993  All rights 
      reserved *****/
/* This work contains valuable, confidential, and proprietary information.
Disclosure, use, or reproduction without the written authorization of 
XOX CORPORATION is prohibited */
#ifndef X_GR_INTERFACE_H
#define X_GR_INTERFACE_H

#ifndef lint

#endif









#define XGE_BadWindow     -500	
#define XGE_OSError       -501	
#define XGE_BadArray      -502	
#define XGE_BadColorError -503	
#define XGE_XError        -504  

#define XOX_Erase              0
#define XOX_Draw               1
		       

#define xcGR_PS_SHADE          1
#define xcGR_GOURAUD_SHADE     2
#define xcGR_PHONG_SHADE       3
#define xcGR_FLAT_SHADE        4
#define xcGR_MESH              5
#define xcGR_MESH_SHADE        6
#define xcGR_BOUNDARY          7
#define xcGR_BOUNDARY_SHADE    8
#define xcGR_HIDDEN_MESH       9
#define xcGR_HIDDEN_BOUNDARY  10


#define xcGR_DEFAULT          -1
#define xcGR_ON                2
#define xcGR_OFF               1

#define xInitGraphics grInit


typedef xINT xGE;
typedef xINT xWINDOW;




#if defined(__cplusplus)
extern "C" {
#endif

 
xINT 
xGraphicsInit xmP((void));		  


 
xINT 
xGraphicsEnd xmP((void));		  


 
xGE		  
xGmToGE xmP((
     xGEOM geom	     
));



 
xREAL 
xgWindowAmbience xmP((
     xWINDOW window 
));

 
xREAL
xgSetWindowAmbience xmP((
     xWINDOW window,
     xREAL ambience 
));

 
xREAL 
xgWindowZClipDepth xmP((
     xWINDOW window 
));

 
xREAL 
xgSetWindowZClipDepth xmP((
     xWINDOW window,
     xREAL zClip 
));

 
xREAL
xgWindowDepthCueing xmP((
     xWINDOW window 
));

 
xREAL
xgSetWindowDepthCueing xmP((
     xWINDOW window,
     xREAL depthCueing 
));

 
xREAL *
xgWindowBeginEye xmP((
     xWINDOW win,
     xREAL *vec 
));

 
xREAL *
xgSetWindowBeginEye xmP((
     xWINDOW window,
     xREAL *vector 
));

 
xREAL *
xgWindowEndEye xmP((
     xWINDOW win,
     xREAL *vec 
));

 
xREAL *
xgSetWindowEndEye xmP((
     xWINDOW window,
     xREAL *vector 
));

 
xREAL *
xgWindowLightVector xmP((
     xWINDOW win,
     xREAL *vec 
));

 
xREAL * 
xgSetWindowLightVector xmP((
     xWINDOW window,
     xREAL *vector 
));

 
xREAL *
xgWindowUpVector xmP((
     xWINDOW win,
     xREAL *vec 
));

 
xREAL *
xgSetWindowUpVector xmP((
     xWINDOW window,
     xREAL *vector 
));

 
xINT 
xgWindowView xmP((
     xWINDOW window 
));

 
xINT 
xgSetWindowView xmP((
     xWINDOW window,
     xINT type 
));

 
xREAL *
xgWindowViewbox xmP((
     xWINDOW window,
     xREAL *minMax 
));

 
xREAL *
xgSetWindowViewbox xmP((
     xWINDOW window,
     xREAL minMax[] 
));

 
xCHAR *
xgWindowColor xmP((
     xWINDOW window 
));

 
xCHAR *
xgSetWindowColor xmP((
     xWINDOW window,
     xCHAR *color 
));

 
xINT 
xgWindowViewPlane xmP((
     xWINDOW window 
));

 
xINT 
xgSetWindowViewPlane xmP((
     xWINDOW window,
     xINT viewPlane 
));

 
xINT
xgDisplayGE xmP((
     xINT geom,
     xINT window 
));



xCHAR *
xgGEColor xmP((
     xINT ge
));

 
xCHAR *
xgSetGEColor xmP((
     xINT ge,
     xCHAR *color 
));

 
xCHAR *
xgGEBfColor xmP((
     xINT ge 
));

 
xCHAR *
xgSetGEBfColor xmP((
     xINT ge,
     xCHAR *color 
));

 
xINT
xgGEPaintOption xmP((
     xINT ge 
));

 
xINT
xgSetGEPaintOption xmP((
     xINT ge,
     xINT retVal 
));

 
xINT
xgGECulling xmP((
     xINT ge 
));

 
xINT
xgSetGECulling xmP((
     xINT ge,
     xINT retVal 
));

 
xINT
xgGERefinement xmP((
     xINT ge 
));

 
xINT
xgSetGERefinement xmP((
     xINT ge,
     xINT retVal 
));

 
xINT
xgPostGE xmP((
     xINT geom,
     xINT window 
));

 
xINT
xgUnpostGE xmP((
     xINT geom,
     xINT window 
));

 
xCHAR *
xgDefaultGEColor xmP((
));

 
xCHAR *
xgSetDefaultGEColor xmP((
     xCHAR *newColor 
));

 
xCHAR *
xgDefaultGEBfColor xmP((
));

 
xCHAR *
xgSetDefaultGEBfColor xmP((
     xCHAR *newColor 
));

 
xBOOL
xgDefaultGECulling xmP((
));

 
xBOOL
xgSetDefaultGECulling xmP((
     xBOOL newValue 
));

 
xINT
xgDefaultGERefinement xmP((
));

 
xINT
xgSetDefaultGERefinement xmP((
     xINT newValue 
));

 
xINT
xgDefaultGEPaintOption xmP((
));

 
xINT
xgSetDefaultGEPaintOption xmP((
     xINT newValue 
));



 
xWINDOW
xgWindow xmP((
     xINT xOrigin,
     xINT yOrigin,
     xINT width,
     xINT height,
     xCHAR backgroundColor[],
     xCHAR foregroundColor[] 
));

 
xWINDOW 
xgInitializeWindow xmP((
     xWINDOW win,
     xINT x,
     xINT y,
     xINT wid,
     xINT ht,
     xCHAR *color 
));

 
xINT 
xgResizeWindow xmP((
     xWINDOW window,
     xINT xOrigin,
     xINT yOrigin,
     xINT width,
     xINT height 
));

 
xINT 
xgWindowP xmP((
     xWINDOW win 
));


xINT 
xgDisplayWindow xmP((
     xWINDOW window 
));


xINT 
xgClearWindow xmP((
     xWINDOW window 
));

 
xINT 
xgDestroyWindow xmP((
     xWINDOW window 
));

 
xINT 
xgPanWindow xmP((
     xWINDOW window,
     xINT x,
     xINT y 
));

 
xINT
xgUpdateWindow xmP((
     xINT window 
));

 
xINT
xgConformWindow xmP((
     xINT window 
));

 
xINT 
xgZoomWindow xmP((
     xWINDOW window,
     xINT boxCorner1[],
     xINT boxCorner2[] 
));

 
xINT 
xgResetWindowPanZoom xmP((
     xWINDOW window 
));

 
xINT 
xgDisplayPolyline xmP((
     xREAL *points,
     xINT numPts,
     xINT dim,
     xWINDOW window,
     xREAL *mtx,
     xINT rowRank,
     xINT colRank,
     xCHAR *color,
     xINT pixOp,
     xREAL zValue 
));

#if defined(__cplusplus)
}
#endif

#endif


