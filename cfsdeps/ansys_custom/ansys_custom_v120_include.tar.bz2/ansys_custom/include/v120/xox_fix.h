/* xox_fix.h                                                    kz372   */
/* 
 * *** copyright(c) 2009 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */

/* Read in and Automatic cleanup of an IGES file. */
INT
CALLTYP xAnsysAutoIges_ ansPROTO((
     xINT *file_label,
     xREAL  *partSize,	
     xINT *flag,
     xINT *tess_flag,
     xINT *solid_flag,
     xINT *deleteSmallArea,
     xINT *removeBlankEntities
));

INT
CALLTYP xAnsysIgesGms_ ansPROTO((
     xINT *file_label,
     xREAL  *partSize,	
     xINT *flag,
     xINT *tess_flag,
     xINT *deleteSmallArea,
     xINT *removeBlankEntities
));

/*  Weld point to point     */
INT 
CALLTYP xAnsysPointWeld_ ansPROTO((
     xINT *kp1,
     xINT *kp2,
     xREAL *dist
     ));

/*  Force weld surfaces     */
INT 
CALLTYP xAnsysForceWeld_ ansPROTO((
     xINT *curves,
     xINT *len,
     xREAL *sew_tol
     ));

/*  Weld ansys surfaces     */ 
INT 
CALLTYP xAnsysWeld_ ansPROTO((
     xINT  *surface,	        /* I: Ansys entity id */
     xINT  *len,
     xINT  *dim,	        /* I: dimension of entity */
     xREAL  *sewTol,		/* I: sewing tolerance */
     xINT  *flag 		/* I: tolerance flag
				 *   *flag == 0  Use default tolerance
				 *         == 1  Use user-defined tolerance
				 */
				 
)); 

/*  Unweld ansys surfaces     */ 
INT 
CALLTYP xAnsysUnWeld_ ansPROTO((
     xINT  *surface,	        /* I: Ansys entity id */
     xINT  *len,
     xINT  *dim  	        /* I: dimension of entity */
));

/* Check isolated entities   */
INT 
CALLTYP xAnsysChkIsoEnt_ ansPROTO((
     xINT  *dim,
     xINT  *flag,    /* I == 1 Inquire the size of the list
		     * == 0 Get the list               */
     xINT  *entity,  /* O: isolated entity array           */
     xINT  *len     /* O: size of the array               */
));

/* Check unsewn entities   */
INT 
CALLTYP xAnsysChkUnsewEnt_ ansPROTO((
     xINT  *dim,
     xINT  *flag,    /* I == 1 Inquire the size of the list
		     * == 0 Get the list               */
     xINT  *entity,  /* O: isolated entity array           */
     xINT  *len      /* O: size of the array               */
));

/* Make webs and "snap" curves onto surfaces where gaps exist */
INT
CALLTYP xAnsysWebify_ ansPROTO((
     xINT *entity,
     xINT *dim,
     xINT *len,
     xINT *tol_flag,
     xREAL *ptTol,
     xREAL *angTol,
     xREAL *edgeLen,
     xINT *code
));

/* Make solids from a list of sewn surfaces */
INT
CALLTYP xAnsysSolids_ ansPROTO((
     xINT *surfaces,
     xINT *len,
     xINT *volumes
));

/* Make a curve from two points. */
INT
CALLTYP xAnsysCurFromPts_ ansPROTO((
     xINT *points,
     xINT *len
));

/* Make a surface from a set of boundary curves. */
INT
CALLTYP xAnsysSurFromBnd_ ansPROTO((
     xINT *curves,
     xINT *len,
     xINT *connect_flag,
     xINT *newSurfaces
));

/* Unsew entities   */
INT 
CALLTYP xAnsysUnSewEnts_ ansPROTO((
     xINT *ids,
     xINT *len,
     xINT *dim
));

/*  Set match tolerance */
INT
CALLTYP xAnsysSetMatchTol_ ansPROTO((
     xREAL  *matchTol
));

/* Get a set of unwelded surfaces/curves/points      */
INT
CALLTYP xAnsysGetLimits_ ansPROTO((
     xINT  *flag,
     xINT  *dim,
     xINT  *entities
));


/*  Find seam lines */
INT
CALLTYP xAnsysGetSeamEdg_ ansPROTO((
     xINT   *curves
));

/*  Find unmatched lines by given tolerance */
INT
CALLTYP xAnsysGetUnMatch_ ansPROTO((
     xINT   *curves
));

/*  Find matched lines by given tolerance */
INT
CALLTYP xAnsysGetMatch_ ansPROTO((
     xINT   *curves
));

/* Impose the matches    */
extern VOID
CALLTYP xAnsysImposeMatch_ ansPROTO((
     xINT   *result
));

/* Get entity map type  */
INT
CALLTYP xAnsysEntityType_ ansPROTO((
     INT *id,
     INT *dim
));

/* Save XOX sew tolerance */
VOID
CALLTYP xAnsysSaveTol_ ansPROTO((
    xREAL *tolArray,
    xINT  *surMiss
));

/* Resume XOX sew tolerance */
VOID
CALLTYP xAnsysResumeTol_ ansPROTO((
    xREAL *tolArray,
    xINT  *surMiss
));

/* Tessilation functions -- jx*/
VOID
CALLTYP xAnsysSetTessTol_ ansPROTO((
 xINT *fineLevel
));

VOID
CALLTYP xAnsysTessRefine_ ansPROTO((
));

