////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         Copyright (C) 2009 ANSYS Inc.  All Rights Reserved             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MAT_HyperElasticLinearFit.h $
// $Revision: 1.3.2.1 $ 7.0
// $Date: 2009/04/13 14:09:59 $ March 28 2002
// $Author: jtm $ rjayasee
//
// Decription :
//
//	This class captures the Material Model abstraction for the MooneyRivline
//  model
//////////////////////////////////////////////////////////////////////////////

#if !defined( MAT_HyperElasticLinearFit_H )
#define MAT_HyperElasticLinearFit_H


#include "MAT_ConstitutiveFunction.h"

class MAT_ExperimentalDataSet ;

class MAT_HyperElasticLinearFit : public MAT_ConstitutiveFunction
{

public:

    MAT_HyperElasticLinearFit();
    //Constructor

    virtual bool GenerateMaterialParameters() = 0;
    //R-bool
    //F-Function that Generates the Material Parameters given
    //F-some experimental data

    virtual bool AssembleLeastSquaresMatrix
            ( MAT_ExperimentalDataSet* pDataSet) ;
    //R-bool
    //I-pDataSet
    //I-Pointer to a ExpDataSet
    //F-Assemble the matrix to be solved for the parameters

    virtual bool SolveLeastSquaresMatrix() ;
    //R-bool
    //R-false if det or zero. Or if the only av data is shear data.
    //F-Inverts the Matrix to solve for the parameters

    virtual bool CalculateFittedExperimentalDataPoint
                    ( double* pCoeffs,
                      INT iNumCoeffs,
                      ANS_String oExpName,
                      vector<double>& oPoint ) ;
    //R bool
    //R-false is such a point or an experiment does not exist
    //I pCoeffs
    //I-Coefficient Values
    //I iNumCoeffs
    //I-Number of Coefficients
    //I oExpName
    //I-Experiment Name
    //I oPoint
    //I Calulated Value of Experiment Point
    //- Returns the Fitted Experimental Data Point

    virtual bool CalculateFittedExperimentalDataPoint
                     ( ANS_String const& oExperimentType,
                       vector<MAT_CFAttribute*> const& oParamVector,
                       double& oCalculatedValue ) ;
    //R Status of Function
    //I oExperimentType
    //I-Type of Experiment
    //I oParamVector
    //I-Vector of Parameters
    //O oCalculateValue
    //O-Value of Fitted Data
    //- Calculated Fitted Data Given Input

     virtual bool FillLHSAndRHSMatrix( ANS_String const& pExpName, ANS_Point const* pPoint,
                                       double** pLHSMatrix, double** pRHSMatrix ) 
     {
         return false ;
     }
     //R bool
     //I pExpName
     //I-Experiment Name
     //I pPoint
     //I Data Point
     //O pLHSMatrix
     //O LHS Matrix
     //O pRHS Matrix
     //O RHS Matrix
     //- Fills up LHS and RHS Matrix for a given point/experimental data

     virtual void Print() ;
    //F-Print

     virtual INT GetNumberOfCoeffs() ;
     //R-bool
     //I-iOrder
     //I-Number of Coeffs
     //F-Set the Number of Coeffs
     //F-This is calculated from the polynomial order

  	 virtual ~MAT_HyperElasticLinearFit();
     //F-Destructor

protected:

    double** m_pLHSMatrix ;
    INT m_pNumRowsLHSMatrix ;
    INT m_pNumColsLHSMatrix ;

    double** m_pRHSMatrix ;
    INT m_pNumRowsRHSMatrix ;
    INT m_pNumColsRHSMatrix ;

    void CleanUpLHSAndRHSMatrix() ;
    // Deletes proctected memory

};

#endif // !defined(MAT_MOONEYRIVLIN_H)
