/*****************************************************************************
 *                   Copyright (C) 1999 CMSoft                               *
 *                                                                           *
 *  These lines of code and declarations contain unpublished proprietary     *
 *  information of CMSoft. They may not be copied or duplicated in whole     *
 *  or part without prior authorization from CMSoft.                         *
 *                                                                           *
 *****************************************************************************/

#ifndef _FS_INFO_H_
#define _FS_INFO_H_

// maxiter = maximum number of FETI iterations
// maxorth = maximum number of reorthogonalization directions
// tol     = global tolerance

// Preconditioners:
// precond = 0       no preconditioner
// precond = 1       lumped            (default)
// precond = 2       dirichlet

// Projectors:
// nonLocalQ = 0	basic projector		(default)
// nonLocalQ = 1	Q(preconditioner type)  projector

// Scaling Methods:
// scaling = 0		tscaling (topology)
// scaling = 1		kscaling (stiffness)	(default)

// FETI Version:
// version = 0		FETI 1			(default)
// version = 1		FETI 2

// verbose
// verbose = 0         (default)
// verbose = 1         lots of screen output

// How often to print the error during iterations
// printNumber =  n     every n iterations

// rcvNodes indicates whether slave should expect nodes or not

class FSInfo {
  public:
    FSInfo();

    int    _maxiter;
    int    _maxorth;
    double _tol;
    int    _nonLocalQ;
    int    _verbose;
    int    _iterused; // number of iterations done in FETI solution
    int    _stagnated; // 0 - didn't stagnate 1 - stagnated
    double _final_residual; // final residual reached
    double _skyTol; // skyline tolerance to be used, default 1.0E-6
    double _contactSkyTol; // skyline tolerance to be used for contact subdomains
    double _bcsScale;		// to scale the size of the BCS workspace
    enum Preconditioner { noPrec, lumped, dirichlet } _precond;
    enum Scaling { tscaling, kscaling }               _scaling;
    enum Version { feti1, feti2 }                     _version;
    E_SOLVER					      _KrrSolver;
    E_SOLVER					      _coarseSolver;
    enum CpceMethod {coarse, lmpc}		      _cpceMethod;
};

#endif
