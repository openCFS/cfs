/*******************************************************************************
 *
 *   C_AdocDriver.h -- 
 *
 * |Module: slvcom
 *
 * |Description: 
 *
 * |Auteur: Emmanuel DELOR
 *
 * |Creation: October 2004
 *
 *
 * |Copyright:	copyright(c) 2009 SAS IP, Inc.  All rights reserved.
 *
 *
 ******************************************************************************/
#ifndef ___C_AdocDriver_h__ 
#define ___C_AdocDriver_h__ 1

#include "cadoe.h"
#include "cadoe_map.h"
#include "cadoe_string.h"
#include "adoc.h"
#include "sx_CADOE_solver.h"
#include "ADOC_Session.h"
#include "ADOC_FctApp.h"

class C_AdocDriver
{
private :
  PAR *_par;
  T_modele *_modele;
  
  C_AdocFctApp<double>	*_FctApp;
  C_AdocSession *_AdocSession;
  
  int _premPar;
  int _dimSolution;
  string _resToEvaluate;
  BVEC *_tab_indice;
  VEC *_solution;
  double *_PtrVec;
  
  // initialisation du tab_indice
  T_statut setTabIndice(BVEC *tab_indice);
  
public :
  
  C_AdocDriver(C_AdocSession *Session, PAR *par, T_modele *modele);
  ~C_AdocDriver();
  
  T_statut initEvaluate(BVEC *tab_indice, VEC *&res, VSTRUCT *lesmodes);
  T_statut evaluate(VEC * vparam, int *convergence = NULL, double *precision = NULL, VSTRUCT *lesmodes = NULL);
  T_statut endEvaluate();
  
  void	setOptionI( const char *intitule, int ival)
  { if ( _AdocSession ) _AdocSession->SetOptionI( intitule, ival ); }

  void	setOptionDbl( const char *intitule, double ival)
  { if ( _AdocSession ) _AdocSession->SetOptionDbl( intitule, ival ); }

  void	setOptions( map< string, string> &Opts);

  void  setOption( const string &Name, const string &Value )
  { if ( _AdocSession ) _AdocSession->SetOption( Name, Value); }

};

#endif
