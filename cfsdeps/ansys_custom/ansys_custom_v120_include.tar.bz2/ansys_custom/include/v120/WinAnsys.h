/*-------------------------------------------------------------*\
 |   WINANSYS.H - Include file for WINANSYS.C                  |
\*-------------------------------------------------------------*/
/*
 * *** copyright(c) 2009 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */
/*------------------------------------------------------------------------*\
 |                    Program define's                                    |
\*------------------------------------------------------------------------*/

/* Product Name Environment variable */
#include "sysparh.h"

/* Graphics window event handler flags */
#define VIEW_HANDLER      1
#define PICK_EVENT        2
#define LPICK_EVENT       4
#define SPICK_EVENT       8
#define WORK_EVENT        16
#define ANNO_EVENT        32
#define MPICK_EVENT       64      // 5.2
#define RPICK_EVENT      128     // 5.2
#define DYNAMIC_WP_EVENT 256 // 5.2
#define CMAP_EVENT       512 // 5.5
#define PIX_EVENT         1024  // 5.5
#define QUERY_PICK_EVENT  2048  // 5.5
#define GR_PICK_EVENT     4096  // 5.6
#define GR_LPICK_EVENT    8192  // 5.6
#define GR_KEY_EVENT      16384 // 6.1

/* Command window event handler flags */
#define CPB_EXIT       1

/* Command entered Callback flags */
#define GETCMDCB       1
#define CPRMCB         2
#define PICK_CONTROL   4
#define LPICK_CONTROL  8
#define SPICK_CONTROL 16
#define QUERY_PICK_CONTROL 32
#define ANNO3D_CONTROL     64
#define GR_PICK_CONTROL    128 // 5.6
#define GR_LPICK_CONTROL   256 // 5.6


#define MAXFILENAMELEN  SYS_PATH_MAX

/* control identifiers */
#define IDC_ANSCMDSTATIC  1
#define IDC_ANSCMDEDIT    2
#define IDC_ANSCMDLISTBOX 3
#define IDC_MENUBUTTON1   1
#define IDC_MENUBUTTON2   2
#define IDC_MENUBUTTON3   3
#define IDC_MENUBUTTON4   4
#define IDC_MENUBUTTON5   5
#define IDC_MENUBUTTON6   6
#define IDC_MENUBUTTON7   7
#define IDC_MENUBUTTON8   8
#define IDC_LISTEREDIT    1
#define IDC_COMBOWHAT         101
#define IDC_COMBOHOW          102
#define IDC_RBFROMFULL        103
#define IDC_RBRESELECT        104
#define IDC_RBALSOSELE        105
#define IDC_RBUNSELECT        106
#define IDC_SELEALLENT        107
#define IDC_INVERTENT         108
#define IDC_SELENONEENT       109
#define IDC_REPLOT            110
#define IDC_RBNODES           111
#define IDC_RBNODESALL        112
#define IDC_RBELEMENTS        113
#define IDC_RBKEYPOINTS       114
#define IDC_RBKEYPOINTSALL    115
#define IDC_RBLINES           116
#define IDC_RBLINESALL        117
#define IDC_RBLINESINTERIOR   118
#define IDC_RBAREAS           119
#define IDC_RBAREASALL        120
#define IDC_RBAREASINTERIOR   121
#define IDC_RBVOLUMES         122
#define IDC_RBVOLUMESALL      123
#define IDC_RBVOLUMESINTERIOR 124
#define IDC_RBXCOORD          125
#define IDC_RBYCOORD          126
#define IDC_RBZCOORD          127
#define IDC_BYLOC_EDIT        128
#define IDC_RBMASTERNODENUM   129
#define IDC_RBCOUPLEDSETNUM   130
#define IDC_RBCONSTRAINTEQNUM 131
#define IDC_RBTHXYROTANGLE    132
#define IDC_RBTHYZROTANGLE    133
#define IDC_RBTHZXROTANGLE    134
#define IDC_RBMATERIALNUM     135
#define IDC_RBELEMENTTYPENUM  136
#define IDC_RBREALSETNUM      137
#define IDC_RBELEMCSNUM       138
#define IDC_RBNUMDIVISIONS    139
#define IDC_RBSPACINGRATIO    140
#define IDC_RBSECTIONIDNUM    141
#define IDC_RBLAYERNUM        142
#define IDC_BYATR_EDIT        143
#define IDC_BYNAM_EDIT        144
#define IDC_BYADJ_EDIT        145
#define IDC_RBBYLENGTH        146
#define IDC_RBBYRAD           147
#define IDC_BYLNRD_EDIT       148
#define IDC_SELEBELOENT       149
#define IDC_PLOT_ENTITY       150
#define IDC_RBLSDYNAPARTID    151


/* Window word values for Lister child edit windows */
#define GWL_HWNDEDIT    0
#define GWL_LISTNUM     4
#define CBWNDEXTRA      8

#define PM_EDITRETURN     WM_USER
#define PM_CLIENTMESSAGE  WM_USER+1
#define ENTERNOTIFY       WM_USER+2
#define LEAVENOTIFY       WM_USER+3

#ifdef WIN32
#define GET_WM_COMMAND_CMD(wp, lp)      HIWORD(wp)
#define GET_WM_COMMAND_HWND(wp, lp)     (HWND)(lp)
#define GET_WM_MDIACTIVATE_FACTIVATE(hwnd, wp, lp)  (lp == (LONG)hwnd)
#else
#define GET_WM_COMMAND_CMD(wp, lp)      HIWORD(lp)
#define GET_WM_COMMAND_HWND(wp, lp)     (HWND)LOWORD(lp)
#define GET_WM_MDIACTIVATE_FACTIVATE(hwnd, wp, lp)  (BOOL)(wp)
#endif

/****************************************************************************
*                                                                           *
*                             LOADSTRING CONSTANTS                          *
*                                                                           *
****************************************************************************/




/*------------------------------------------------------------------------*\
 |                    Prototyping Statements                              |
\*------------------------------------------------------------------------*/

//nt_WinAnsys.c
BOOL InitApplication( HANDLE );
BOOL InitInstance( HANDLE, int );
LRESULT CALLBACK MainWndProc( HWND, UINT, WPARAM, LPARAM );
BOOL CALLBACK AboutDlgProc( HWND, UINT, WPARAM, LPARAM );
LRESULT CALLBACK SideMenuWndProc( HWND, UINT, WPARAM, LPARAM );
LRESULT CALLBACK ListerWndProc( HWND, UINT, WPARAM, LPARAM );
LRESULT CALLBACK GranuleDialogProc( HWND, UINT, WPARAM, LPARAM );
VOID CommandHandler( HWND, WPARAM, LPARAM );
VOID ListerWindow( char *, char *, int, int * );
VOID ReadAnsFile( HWND, char *, int * );
VOID MakePopupWindows( HWND );
VOID GetNetAddress( HWND );
BOOL TermInstance( HANDLE );
int  MsgLoop( HANDLE hInstance );
BOOL IsBatchRun( LPSTR );
BOOL IsCmdOptSet( LPSTR, LPSTR, LPSTR, BOOL );
BOOL Is3D( LPSTR );
BOOL IsProRun (LPSTR );
BOOL IsDSRun (LPSTR );
BOOL IsWinNT (VOID);
BOOL CheckEnvAndReg (CHAR *);
VOID ShowSplash ( VOID );

// AnsCmdWnd.c
LRESULT CALLBACK AnsCmdWndProc( HWND, UINT, WPARAM, LPARAM );
LRESULT CALLBACK AnsCmdEditProc( HWND, UINT, WPARAM, LPARAM );
VOID MakeAnsCmdChildren( HWND );
void WhichCmdEnteredCallback( void );

// GetcmdCB.c
void GetcmdCB( UINT );

// CmdWindow.c
void ui_promptc( char [] );
void cmd_text( char [] );
void cmd_history( char [] );
void cmd_hist2( char [] );
void CmdActivateCB( void );

// Menu_File.c
void Menu_File( HMENU );
void filecb( HWND, WPARAM );
void filesubcb( HWND, WPARAM );
void FileHelpCB( char * );
void ListDialogAcceptCB( OPENFILENAME );
BOOL APIENTRY ResumeDBHookProc( HWND, UINT, WPARAM, LPARAM );
BOOL APIENTRY SaveAsDBHookProc( HWND, UINT, WPARAM, LPARAM );
BOOL APIENTRY SwitchToFileHookProc( HWND, UINT, WPARAM, LPARAM );
BOOL APIENTRY ListFileHookProc( HWND, UINT, WPARAM, LPARAM );
BOOL APIENTRY ReadInputFromHookProc( HWND, UINT, WPARAM, LPARAM );
BOOL APIENTRY CopyHookProc( HWND, UINT, WPARAM, LPARAM );
BOOL APIENTRY RenameHookProc( HWND, UINT, WPARAM, LPARAM );
BOOL APIENTRY DeleteHookProc( HWND, UINT, WPARAM, LPARAM );
BOOL APIENTRY WriteDBLogHookProc( HWND, UINT, WPARAM, LPARAM );
BOOL APIENTRY FileImportSatHookProc( HWND, UINT, WPARAM, LPARAM );
BOOL APIENTRY FileImportCatiaHookProc( HWND, UINT, WPARAM, LPARAM );
BOOL APIENTRY FileImportParaHookProc( HWND, UINT, WPARAM, LPARAM );
BOOL APIENTRY FileImportProeHookProc( HWND, UINT, WPARAM, LPARAM );
BOOL APIENTRY FileImportUgHookProc( HWND, UINT, WPARAM, LPARAM );
BOOL APIENTRY FileImportStepHookProc( HWND, UINT, WPARAM, LPARAM );
void ReadCB( void *, char * );
void DialogButtonAcceptCB( void *, char * );
void CopyRenameCB( void *, char * );
void read_path( char *, char *, char *, char *, int * );
void input_output_file( char *, char *, int );
void hook_to_ansys( char * );
void get_title( char * );
void get_where( char * );
void char_convert( int [], char * );
void proceed_selection( WPARAM );
BOOL CALLBACK ChangeTitleDlgProc( HWND, UINT, WPARAM, LPARAM );
void ChangeTitleCB( HWND );
void BeginCB( WPARAM );
int  check_begin_level( HWND, WPARAM, void (*f)(WPARAM) );
BOOL DoIHaveBlanks( LPTSTR );

// Menu_Edit.c
void Menu_Edit( HMENU );
void Menu_EditCB( int );

// Menu_Pick.c
void Menu_Pick( HMENU );
void pick_controlCB( int );
void process_pick_textbox(void);
void pick_panel( HWND );
void pickpanCB( HWND, int );
void pickpanBTN( HWND , int, HWND *, int *, int *, int, int, int );
void manage_input( HWND, int );
int  manage_attach( void );
int  manage_attrib( void );
LRESULT CALLBACK SelectEntWndProc( HWND, UINT, WPARAM, LPARAM );
void manage_how( HWND, int );
void EnableSelectEnt( HWND, BOOL );
void DestroySelectEntChildren( HWND );

// MakeList.c
void MakeList( char [], char [], int * );
void outlistCB( HWND );
void savefCB( HWND , char * );
void WriteAnsFile( HWND, char * );
void PrintText(HWND hwnd);

// Menu_List.c
void Menu_List( HMENU );
void menulistCB( int );
void statusCB( int );
void keypointCB( int );
void elementCB( int );
void propertyCB( int );
void loadCB( int );
void list_resultCB( int );
void entityCB( int );
void otherCB( int );
void filelistCB( HWND, WPARAM );
void BinaryCB( WPARAM );

// Menu_Plot.c
void Menu_Plot( HMENU );
void plotCB( int );
void plot_resultCB( int );
void specified_entityCB( int );
void ComponentCB( int );

// Menu_View.c
void Menu_View( HMENU );
void menu_viewCB( int );
void view_settingsCB( int );
void Best_QualityCB( int );
void rot_centerCB( int );
void textureCB( int );
void styleCB( int );
void erase_optionsCB( int );
void window_controlsCB( int );
void font_controlsCB( int );
void animateCB( int );
void redirect_plotsCB( int );
void annotate_optionsCB (WPARAM);

// Menu_Work.c
void Menu_Work( HMENU );
void workplnCB( int );
void wpview_panel( void );
BOOL CALLBACK OffsetWPDlgProc( HWND, UINT, WPARAM, LPARAM );
BOOL DrawTheButton( LPDRAWITEMSTRUCT );
LRESULT CALLBACK OWPOffsetsEditProc( HWND, UINT, WPARAM, LPARAM );
LRESULT CALLBACK OWPAnglesEditProc( HWND, UINT, WPARAM, LPARAM );
BOOL wpviewCB( HWND, WPARAM, LPARAM, int );
void wpview_xyz( HWND );
void wpset_panel( void );
BOOL CALLBACK WPSettingsDlgProc( HWND, UINT, WPARAM, LPARAM );
BOOL wpsetCB( HWND, WPARAM, LPARAM );
void wpset_reset( HWND );

// work_plane.c
void work_event( struct mouseGraph * );

// Menu_Parm.c
void Menu_Parm( HMENU );
void parmCB( HWND, int );
void scalar_panel( HWND );
BOOL CALLBACK ScalarParmDlgProc( HWND, UINT, WPARAM, LPARAM );
void load_scalars( HWND );
void scparmCB( HWND, int );
void array_parameterCB( int );
void array_operationCB( int );
void bc_functionsCB( int );
LRESULT CALLBACK ScalarParmEditProc( HWND, UINT, WPARAM, LPARAM );

// Menu_Macro.c
void Menu_Macro( HMENU );
void macroCB( HWND, WPARAM, int );
void macro_searchCB( WPARAM );

// Menu_Help.c
void Menu_Help( HMENU );
void menuhelpCB( int );

// CreateHelp.c
void CreateHelp( int );

// uiloop.c
void closeui_handler( void );

// HelpWnd.c
BOOL CALLBACK navigateHistory( HWND, UINT, WPARAM, LPARAM );
BOOL CALLBACK navigateWordsearch( HWND, UINT, WPARAM, LPARAM );
LRESULT CALLBACK HelpWndProc( HWND, UINT, WPARAM, LPARAM );
void initHelpEng( void );
HWND MakePopupHlpWin( HWND, RECT *, DWORD, char * );
BOOL CALLBACK relatedArticles( HWND, UINT, WPARAM, LPARAM );
BOOL CALLBACK navigateHelpOn( HWND, UINT, WPARAM, LPARAM );
LRESULT CALLBACK HelpOnEditProc( HWND, UINT, WPARAM, LPARAM );


// MenuWindow.c
void Menu_Sense( BOOL );
BOOL Menu_Hidden( void );
void Menu_Lower( void );
void Menu_Raise( void );
void close_handler( HWND );
void MenuWindowo( void );
void MenuWindowc( void );

void Menu_Res( void );
char *asc_to_chr( int *, char *, int );

// ToolbarWnd.c
LRESULT CALLBACK ToolbarWndProc( HWND, UINT, WPARAM, LPARAM );
void load_toolst( HWND );
void toolstCB( HWND, int );
void load_toolpl( HWND );
void tool_update( void );
void toolplCB( WPARAM );
void tool_handler( WPARAM );
BOOL CALLBACK EditAbbrDlgProc( HWND, UINT, WPARAM, LPARAM );
LRESULT CALLBACK EditAbbrEditProc( HWND, UINT, WPARAM, LPARAM );

// Menu_Setup.c
void MenuC_togCB( WPARAM );
void Menu_Setup( HMENU );

// mb_shade.c
void mb_shade_cb( HMENU );
void mb_shade( int, BOOL, int, BOOL );
void mb_shade_init( void );
void mb_shade_config(int , HMENU, int [], int );
void mb_shade_addcb( HMENU [], int );

void dp_to_str( double, char * );
void sspack( int [], char [], int );
void kbdfoc( int, int );
void Change_Sense( int, BOOL );
void MenuBar( void );
int  NumMenuItems( HMENU, int [], int );

// ErrWindow.c
void errmsg( INT *, char [] );
void verifyCB( int );
BOOL CALLBACK AskPopDlgProc( HWND, UINT, WPARAM, LPARAM );
BOOL CALLBACK ModelessMBDlgProc( HWND, UINT, WPARAM, LPARAM );
BOOL CALLBACK ModelessMBDlgProc2( HWND, UINT, WPARAM, LPARAM );
BOOL CALLBACK DbgPopDlgProc( HWND, UINT, WPARAM, LPARAM );
BOOL  CALLBACK VfyPopAllDlgProc ( HWND, UINT, WPARAM, LPARAM );

// chview_panel.c
void chview_panel( void );
BOOL CALLBACK PanZoomRotDlgProc( HWND, UINT, WPARAM, LPARAM );
void chviewCB( HWND, WPARAM, LPARAM, int );
void view_handler( struct mouseGraph * );
void view_zoom( int , int, int, int );
void view_local( int, int, int, int );
void zoom_rbr( INT );

// gr_animate.c
BOOL CALLBACK AnimateDlgProc( HWND, UINT, WPARAM, LPARAM );
void AnimateDlgCB( HWND, WPARAM, LPARAM, int );


// DlgBoxPos.c
void DlgBoxPos( HWND, char * );

// grcurs.c
void pkcurs( int );
int GetAnsCursor( void );

// GraphWnd.c
LRESULT CALLBACK GraphWndProc( HWND, UINT, WPARAM, LPARAM );
void WhichGraphWndEventHandler( struct mouseGraph *, WPARAM wParam);

// Graph3DWnd.c
LRESULT CALLBACK Graph3DWndProc( HWND, UINT, WPARAM, LPARAM );

// cprompt.c
void cpb_exit( struct mouseGraph * );
void cpterm( int* );
void epromp( int, int [], int, int, int, int, int, int,
            int [], int, int [], int [] );
void xpromp( int, int [], int, int, int, int [], int, int [] );
void cprmCB( void );
void exit_picker( void );

// pick.c
BOOL CALLBACK PickDlgProc( HWND, UINT, WPARAM, LPARAM );
void pick_show( INT );
void pick_apply( void );
void pick_accept( void );
void pick_cancel( void );
void pick_exit( int );
INT  pick_near( INT [], INT *, INT * );
INT  pick_nodup( INT [], INT *, INT [] );
INT  pick_list( INT [], INT *, INT [] );
void pick_event( struct mouseGraph * );
void pick_popup( HWND );
BOOL pick_control(  HWND, int  );
void pick_ok( void );
void rect_select( void );
void rect_draw( INT );
void rect_add( void );
void rect_remove( INT [] );
BOOL rect_check( INT [] );
void poly_select( void );
void poly_draw( INT );
void poly_add( void );
void poly_remove( INT [] );
BOOL poly_check( INT [] );
void circle_select( void );
void circle_draw( INT );
void circle_add( void );
void circle_remove( INT [] );
BOOL circle_check( INT [], INT );
void point_add( INT );
void point_remove( INT );
void loop_select( void );
INT  list_check( INT );
INT  sel_check( INT );
void ent_zero( INT );
void pt_add( INT, INT );
void pt_remove( INT [], INT, INT );
void transform(INT, DOUBLE *, INT * );
void plot_entity( int, int );
void pick_rubberband( INT, INT );
void checkdup_pick( void );
void checkdup_unpick( void );
void select_dup( void );
BOOL CALLBACK MultiEntDlgProc( HWND, UINT, WPARAM, LPARAM );
void dup_pickCB( int );
// query_pick.c
BOOL CALLBACK QryPickDlgProc( HWND, UINT, WPARAM, LPARAM );
void query_pick_show( INT );
void process_query_textbox( void );
void query_pick_apply( void );
void query_pick_accept( void );
void query_pick_cancel( void );
void query_pick_exit( int );
INT  query_pick_near( INT [], INT *, INT * );
INT  query_pick_nodup( INT [], INT *, INT [] );
INT  query_pick_list( INT [], INT *, INT [] );
void query_pick_event( struct mouseGraph * );
void query_pick_popup( HWND );
BOOL query_pick_control(  HWND, int  );
void query_pick_ok( void );
void query_rect_select( void );
void query_rect_draw( INT );
void query_rect_add( void );
void query_rect_remove( INT [] );
BOOL query_rect_check( INT [] );
void query_poly_select( void );
void query_poly_draw( INT );
void query_poly_add( void );
void query_poly_remove( INT [] );
BOOL query_poly_check( INT [] );
void query_circle_select( void );
void query_circle_draw( INT );
void query_circle_add( void );
void query_circle_remove( INT [] );
BOOL query_circle_check( INT [], INT );
void query_point_add( INT * );
void query_point_remove( INT * );
void query_loop_select( void );
INT  query_list_check( INT );
INT  query_sel_check( INT );
void query_ent_zero( INT );
void query_pt_add( INT, INT );
void query_pt_remove( INT [], INT, INT );
void query_transform( INT, DOUBLE *, INT * );
void query_plot_entity( int, int );
void query_pick_rubberband( INT, INT );
void query_checkdup_pick( void );
void query_checkdup_unpick( void );
void query_select_dup( void );
BOOL CALLBACK QRYMultiEntDlgProc( HWND, UINT, WPARAM, LPARAM );
void query_dup_pickCB( int );


// lpick.c
BOOL CALLBACK LPickDlgProc( HWND, UINT, WPARAM, LPARAM );
void lpick_apply( void );
void process_lpick_textbox(void);
void lpick_accept( void );
void lpick_cancel( void );
void lpick_exit( int );
void lpick_event( struct mouseGraph * );
void lpick_popup( HWND );
void geom_label( DOUBLE [], DOUBLE [] );
BOOL lpick_control(  HWND, int  );
void lpick_show( INT *, DOUBLE *, INT * );
INT  lpick_list( INT [], INT *, DOUBLE * );
void lpt_add( DOUBLE [] );
void lpt_remove( INT );
void world_scr( DOUBLE [], INT [] );
void scr_wp( INT [], DOUBLE [], DOUBLE [], INT * );
void lpick_rubberband( INT, INT, DOUBLE *, INT );
void lpick_ok( void );
void  lpick_viewev( void );

// spick.c
void spickst( INT *, INT *, INT *, INT *, DOUBLE *, INT *, INT *, INT *, INT * );
BOOL CALLBACK SPickDlgProc( HWND, UINT, WPARAM, LPARAM );
void spick_apply( void );
void spick_accept( void );
void spick_cancel( void );
void spick_exit ( int );
void spick_event( struct mouseGraph * );
void spick_popup( HWND );
void scrn_label( DOUBLE [] );
BOOL spick_control( HWND , int );
void spick_show( INT, DOUBLE *, INT );
INT  spick_list( INT [], INT *, DOUBLE * );
void spt_add( DOUBLE [] );
void spt_remove( INT );
void scrn_draw( DOUBLE [], INT );
void spick_rubberband( INT, INT, DOUBLE *, INT );

// dtable.c
LRESULT CALLBACK DtableProc( HWND, UINT, WPARAM, LPARAM );
void ArrangeControls( HWND );
void ArrangeTable( HWND );
void CALLTYP dtabup_( int [] );
void set_rc_bgcolor( int, int, HBRUSH );
void change_select( BOOL );
void row_buttonCB ( LPARAM, void*, void* );
static void TraverseCells( HWND, WPARAM, void*, void* );
INT  word_count( char* );
INT  blank_compress( char*,char*,INT );
void ViewCB ( HWND, WPARAM, void* );
void column_buttonCB( LPARAM, void*, void* );
void set_rc_value( int, int, int, double );
void copy_rc_value( int, int, int, int, int );
void EditCB ( HWND, WPARAM, void* );
void dsense( int, BOOL );
void copy_buttonCB ( HWND, int, void* );
void unselect_buttonCB( HWND, int, void* );
void init_changeCB ( LPARAM, void*, void* );
void focus_changeCB ( LPARAM, void*, void* );
void zplane_buttonCB ( LPARAM, void*, void* );
void dtfilecb (HWND, int, void* );
void heapdscfree_(int[]);

// Prototypes for AnsGrn.c

INT  custuiqr( INT );
void custuinfo (INT, INT );
void exit_cust( void );
void custsenseCB( HANDLE, WPARAM, LPARAM );
void custfree( void );
void pcmd( INT );
void make_command( INT*, INT, INT );
void custgranCB( HANDLE, WPARAM, LPARAM );
void custcanCB( HANDLE, WPARAM, LPARAM );
void custhelpCB( void );
LRESULT CALLBACK CustomClassProc( HWND, UINT, WPARAM, LPARAM );


// Prototypes for RcPan.c

INT rcuiqr( INT );
void rcuinfo( INT, INT );
void rcsenseCB( HANDLE, WPARAM, LPARAM );
void rcfree( void );
void rcgranCB( HANDLE, WPARAM, LPARAM );
void rcfuncCB( HANDLE, WPARAM, LPARAM );
void rcon_helpCB( void );
void rcon_closeCB( HANDLE, WPARAM, LPARAM );
void exit_rcon( void );
LRESULT CALLBACK RealConstantsProc( HWND, UINT, WPARAM, LPARAM );
LRESULT CALLBACK MaterialConstantsProc( HWND, UINT, WPARAM, LPARAM );

// ConPan.c
HWND make_text( HWND, char*, INT, INT );
HWND cpcolorCB( HWND, long, long );
void get_ent( INT, INT, char* );
void cancelCB( HWND, PVOID, PVOID );
void cpclbCB( HWND, PVOID, PVOID );
void cpexitCB( HWND, PVOID, PVOID );
void cphelpCB( void );
void cpapplyCB( HWND, PVOID, PVOID );
void okCB( HWND, struct field_struct *, PVOID );
void filterCB( HWND, INT *, WPARAM );
void SizeEnumProc( HWND, INT );
void clear_matrix( void );
void clear_trailing_blanks( char* );
int  chr_to_asc( char *, int *, int );
SIZE CalculateWindowSize( HWND );
//INT cpuiqr( INT );
void MakeFileBox( HWND, char * );
void FileBoxHandler( HWND, WPARAM, LPARAM );

// Menu_Anno.c
LRESULT CALLBACK AnnotationProc( HWND, UINT, WPARAM, LPARAM);
void annoCB( HANDLE, WPARAM, LPARAM );
void anno_manage( int );
void anno_event( struct mouseGraph *, WPARAM );
HANDLE annoBTN( HANDLE, int );
void   exit_anno( void );
void SetMetrics( HANDLE, INT, INT, INT, INT );
HBRUSH MakeSolidBrush( HDC, HPALETTE, COLORREF );
void MakeColorBitmap(HWND, LPDRAWITEMSTRUCT);
void anno_panel( void );

// Menu_Anno3d.c
LRESULT CALLBACK Annotation3dProc( HWND, UINT, WPARAM, LPARAM);
void   anno3d_cb( HANDLE, WPARAM, LPARAM );
void   anno3d_manage( int );
void   anno3d_event( struct mouseGraph *, WPARAM );
HANDLE anno3d_btn( HANDLE, int );
void   anno3d_exit( void );
void   anno3d_metrics( HANDLE, INT, INT, INT, INT );
void   anno3d_panel( void );
void   anno3d_control( void );

// Beam Tool
LRESULT CALLBACK BeamToolProc( HWND, UINT, WPARAM, LPARAM);
void BeamCB( HANDLE, WPARAM, LPARAM );
void beam_manage( void );
void beam_process( void );
void beam_popdown( void );
void SetMetrics( HANDLE, INT, INT, INT, INT );
void beam_panel( void );

// GraphicHCopy.c
void PrintANSYSHardCopy( HWND );
void PrintHardcopy( void );
BOOL CALLBACK abortproc( HDC, int );
LRESULT CALLBACK abortprintproc( HWND, UINT, WPARAM, LPARAM );
void PrintDIB( void );
void ReverseBlackAndWhite( LPVOID, LONG, LONG, WORD );

// HelpCopy.c
void PrintANSYSHelp(HWND, HDC, INT, INT);
void PrintHelpWindow(HDC, INT, INT, INT);
LRESULT CALLBACK HelpCopyWndProc(HWND, UINT, WPARAM, LPARAM);
void CopyWindow(void);

// SnapShot Window nt_snapshot.c
LRESULT APIENTRY SnapShotProc(HWND, UINT, WPARAM, LPARAM);
INT WriteBMPFile(HWND, LPSTR, PBITMAPINFO);
HBITMAP GetBMPFile( HWND, char [] );
void PrintSnap(HWND);
void PrintSnapshot(HWND);
int MakeSnap(HWND, WPARAM);

//MPicker Window  nt_mpick.c
LRESULT CALLBACK MPickProc( HWND, UINT, WPARAM, LPARAM );
void mpickst( INT *, INT *, INT *, INT *, INT *, INT *, INT * );

// nt_rpick.c
HWND    rpick_popup(void);
void    rpick_control( LPARAM, WPARAM );
void    rpick_apply(void);
void    rpick_accept(void);
void    rpick_cancel(void);
void    rpick_exit(int);
void    rtransform(INT, DOUBLE *, INT *);
void    rpick_event(struct mouseGraph *event);
void    rpick_loop(void);
void    checkrdup_pick(void);
void    checkrdup_unpick(void);
void    select_rdup(void);
INT     rlist_check(int);
void    rdup_pickCB(int);

// HelpCB.c
void Hlp_CB( int );
void HelpPagePopCB( int );
void HelpOnCB( HWND, int );

//nt_ExitMessage.c
extern void ExitMessage( void );

//nt_mpick.c
/*  Internal routines  */
HANDLE  mpick_popup( void );
void    mpick_control(LPARAM, WPARAM);
void    mpick_show(INT *, DOUBLE [5][3], INT * );
void    mpick_event(struct mouseGraph *event);
void    mpick_ok(void);
void    mpick_apply(void);
void    mpick_accept(void);
void    mpick_cancel(void);
void    mpick_exit(INT);
void    mpick_rubberband(INT, DOUBLE[5][3], INT );
void    mpick_world_scr(DOUBLE *, INT *);
void    mpick_scr_wp(INT *, DOUBLE *, DOUBLE *, INT *);
void    mpick_geom_label(DOUBLE *, DOUBLE *);
void    mpt_add(DOUBLE *, DOUBLE *);
void    mpt_remove(INT);
void    mpick_manage_text(void);
void    mpick_chxy_to_parm(char *, double *, int *);
void    mpick_wp_to_parm(INT, DOUBLE *, DOUBLE *);
void    mpick_parm_to_wp(INT, DOUBLE[2], DOUBLE[2]);
void    mpick_xy_2_rth(double, double, double *, double *);
void    mpick_rth_2_xy(double, double, double *, double *);
void    mpick_parm_changed(void);
void    mpick_motion( INT, DOUBLE *, DOUBLE * );
void    mpick_set_xywpof(void);
INT     mpick_list(INT *, INT *, DOUBLE[5][3]);
BOOL CALLBACK ChildEnumProc(HWND, LPARAM);
HANDLE CreateText(HANDLE, INT, INT, INT, INT, INT);
HANDLE MakeLabel (HANDLE, LPSTR,INT, INT, INT, INT);

// change_color.c
BOOL CALLBACK ListTheWindowsProc( HWND, LPARAM );

// OutputWin.c
VOID CreateOutputWindow( VOID );
VOID CreateBatchWindow( VOID );

// mesh_panel.c
void mesh_panel( void );
void mesh_popdown( void );
BOOL CALLBACK MeshControlProc( HWND, UINT, WPARAM, LPARAM );
void meshCB( HWND, WPARAM, LPARAM, int );

// miscellaneous
void wpview_handler ( struct mouseGraph * );
void cmap_picker ( struct mouseGraph * );
void pix_picker  ( struct mouseGraph * );
