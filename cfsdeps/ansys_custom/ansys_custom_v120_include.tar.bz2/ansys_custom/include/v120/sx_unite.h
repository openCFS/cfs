/* CADOE */
/*
 * unite.h -- prototypes des focntions des gestion des unites
 *   
 * HISTORY
 *   
 *   02/15/00 13:10 <       Brian Jantzen> Rel:ms8      SCCA:68558  Delta:8.3
 *   
 *   09/30/99 17:38 <         James Silva> Rel:ms8      SCCA:56512  Delta:8.2
 */
#include "sx_CADOE_solver.h"
#ifndef __UNITEH__
#define __UNITEH__ 1

/* #include "struct.h"   */

#ifdef OPENIDEAS
#include <oicinc/OI_Convert.hxx>
#else
/*
 *  Gestion des unites, types de grandeurs 
 *
 *  AJOUT D'UNE GRANDEUR:
 *  
 *  A faire obligatoirement en respectant l'ordre
 *  de la table unit_option dans unites.c
 *
 */
typedef enum {
  UNI_NONE,
  UNI_LONGUEUR,
  UNI_POIDS,
  UNI_RAIDEUR,
  UNI_FORCE,
  UNI_FORCE_PER_LENGTH,
  UNI_FORCE_PER_AREA,
  UNI_TEMPERATURE,
  UNI_INV_TEMPERATURE,
  UNI_ACCELERATION,
  UNI_TRAVAIL,
  UNI_FLUX,
  UNI_CP,		/* chaleur specifique a pression constante */
  UNI_CONDUCTIBILITE,
  UNI_MASSE_VOL,
  UNI_COEF_CONV,	/* coefficient de convection */
  UNI_CT,		/* coefficient de transfert convectif */
  UNI_ENTHALPIE,
  UNI_CHALEUR,
  UNI_COUPLE,
  UNI_AREA,
  UNI_MOMENT_INERTIE,
  UNI_COUPLE_PER_LENGTH,
  UNI_FORCE_PER_LENGTH_AXI
} E_grandeur_unite;
#endif
extern T_statut UNI_convertir( int , int , double *, double * );

#endif
