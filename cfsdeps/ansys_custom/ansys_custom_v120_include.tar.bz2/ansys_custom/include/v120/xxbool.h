
/*
 *    author/date: yu-hua ting/06-12-94
 *
 *    primary function:
 *
 *      Header for the Interface to SHAPES "Boolean" routines
 *
 *    secondary function:
 *
 *        none
 *
 *    routines included:
 *
 *
 *    history
 *
 *        none
 *
 *    comments:
 *
 *        none
 *
 *    Notice - This file contains ANSYS Confidential information ***
 *
 */

/* 
 * *** copyright(c) 2009 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */

/*****************************************************************************
 *                                                                           *
 *    Boolean operations in SHAPES                                           *
 *                                                                           *
 *****************************************************************************/


/*
 *    geometrically classify 
 */
      extern xINT_LIST xGmClassify_xox ansPROTO((
             xGEOM_ID gm_id1,     /* I    geom number of the 1st geom               */ 
             xGEOM_ID gm_id2,     /* I    geom number of the 2nd geom               */
             xINT code1,          /* I    code for requested results on gm_id1.
                                          It can be the bitwise OR of xcGM_CLSFY_IN,
                                          xcGM_CLSFY_ON, and xcGM_CLSFY_OUT values.
                                          The 3 values control the computation of 
                                          the part of gm_id1 in gm_id2, inside of 
                                          gm_id2, on the boundary of gm_id2, and 
                                          outside of gm_id2                         */
             xINT code2,          /* I    code for requested results on gm_id2.
                                          It can be the bitwise OR of xcGM_CLSFY_IN, 
                                          xcGM_CLSFY_ON, and xcGM_CLSFY_OUT values.
                                          The 3 values control the computation of 
                                          the part of gm_id2 in gm_id1, inside of  
                                          gm_id1, on the boundary of gm_id1, and 
                                          outside of gm_id1                         */
             xINT simplifymode,   /* I    simplification code which specifies how
                                          much merging is desired on the output
                                          results.
                                          == 0 - no simplification done.
                                          == xcGM_SIMPLIFY_SPACE - remove any
                                             removable boundaries between cells
                                             defining regions in modeling space
                                             (i.e. solids).                         
                                          == xcGM_SIMPLIFY_EQ_MAP - remove any
                                             removable boundaries between cells
                                             that are defined on the same map       
                                          == xcGM_SIMPLIFY_ALL    - perform the
                                             above 2 and additional tries to merge
                                             cells that are defined on maps that
                                             cover the same point set even though
                                             they are parametrically not the same.
                                             For example, differently parametrized
                                             but overlapping planes are merged      */
             xTAG tag,            /* I    heap tag                                  */
             INT *iretp));        /*   O  error code   
                                   *      == 0 - no error
                            *      != 0 - error                               */

/*
 *    geometrically union
 */
      extern xGEOM_ID xGmUnion_xox ansPROTO((
             xGEOM_ID gm_id1,     /* I    geom number of the 1st geom               */ 
             xGEOM_ID gm_id2,     /* I    geom number of the 2nd geom               */
             xINT simplifymode,   /* I    simplification code which specifies how
                                          much merging is desired on the output
                                          results.
                                          == 0 - no simplification done.
                                          == xcGM_SIMPLIFY_SPACE - remove any
                                             removable boundaries between cells
                                             defining regions in modeling space
                                             (i.e. solids).                         
                                          == xcGM_SIMPLIFY_EQ_MAP - remove any
                                             removable boundaries between cells
                                             that are defined on the same map       
                                          == xcGM_SIMPLIFY_ALL    - perform the
                                             above 2 and additional tries to merge
                                             cells that are defined on maps that
                                             cover the same point set even though
                                             they are parametrically not the same.
                                             For example, differently parametrized
                                             but overlapping planes are merged      */
             xTAG tag,            /* I    heap tag                                  */
             INT *iretp));        /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                               */
       

/*
 *    geometrically subtract
 */
      extern xGEOM_ID xGmSubtract_xox ansPROTO((
             xGEOM_ID gm_id1,     /* I    geom number of the 1st geom               */ 
             xGEOM_ID gm_id2,     /* I    geom number of the 2nd geom               */
             xINT simplifymode,   /* I    simplification code which specifies how
                                          much merging is desired on the output
                                          results.
                                          == 0 - no simplification done.
                                          == xcGM_SIMPLIFY_SPACE - remove any
                                             removable boundaries between cells
                                             defining regions in modeling space
                                             (i.e. solids).                         
                                          == xcGM_SIMPLIFY_EQ_MAP - remove any
                                             removable boundaries between cells
                                             that are defined on the same map       
                                          == xcGM_SIMPLIFY_ALL    - perform the
                                             above 2 and additional tries to merge
                                             cells that are defined on maps that
                                             cover the same point set even though
                                             they are parametrically not the same.
                                             For example, differently parametrized
                                             but overlapping planes are merged      */
             xTAG tag,            /* I    heap tag                                  */
             INT *iretp));        /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                               */


/*
 *    geometrically intersection
 */
      extern xGEOM_ID xGmIntersect_xox ansPROTO((
             xGEOM_ID gm_id1,     /* I    geom number of the 1st geom               */ 
             xGEOM_ID gm_id2,     /* I    geom number of the 2nd geom               */
             xINT simplifymode,   /* I    simplification code which specifies how
                                          much merging is desired on the output
                                          results.
                                          == 0 - no simplification done.
                                          == xcGM_SIMPLIFY_SPACE - remove any
                                             removable boundaries between cells
                                             defining regions in modeling space
                                             (i.e. solids).                         
                                          == xcGM_SIMPLIFY_EQ_MAP - remove any
                                             removable boundaries between cells
                                             that are defined on the same map       
                                          == xcGM_SIMPLIFY_ALL    - perform the
                                             above 2 and additional tries to merge
                                             cells that are defined on maps that
                                             cover the same point set even though
                                             they are parametrically not the same.
                                             For example, differently parametrized
                                             but overlapping planes are merged      */
             xTAG tag,            /* I    heap tag                                  */
             INT *iretp));        /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                               */

/*
 *    geometryically union merge
 */
      extern xGEOM_ID xGmUnionMerge_xox ansPROTO((
             xGEOM_ID gm_id1,     /* I    geom number of the 1st geom               */ 
             xGEOM_ID gm_id2,     /* I    geom number of the 2nd geom               */
             xINT *flag,
             xTAG tag,            /* I    heap tag                                  */
             INT *iretp));        /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                               */

/*
 *    intersection test
 */
      extern xINT xIntersectingGeomsP_xox ansPROTO((
             xGEOM_ID gm_id1,     /* I    geom number of the 1st geom               */ 
             xGEOM_ID gm_id2,     /* I    geom number of the 2nd geom               */
             DOUBLE tol,          /* I    tolerance                                 */
             INT *iretp));        /*   O  error code   
                                   *      == 0 - no error
                                   *      != 0 - error                               */


 
/*
 *    simplify a geom by removing common faces
 */
      extern xGEOM_ID xGmSimplify_xox ansPROTO((
             xGEOM_ID gm_id,      /* I    geom number of the geom to be simpilfied  */
             xINT mode,           /* I    simplification code which specifies how
                                          much merging is desired on the output
                                          results.
                                          == 0 - no simplification done.
                                          == xcGM_SIMPLIFY_SPACE - remove any
                                             removable boundaries between cells
                                             defining regions in modeling space
                                             (i.e. solids).                         
                                          == xcGM_SIMPLIFY_EQ_MAP - remove any
                                             removable boundaries between cells
                                             that are defined on the same map       
                                          == xcGM_SIMPLIFY_ALL    - perform the
                                             above 2 and additional tries to merge
                                             cells that are defined on maps that
                                             cover the same point set even though
                                             they are parametrically not the same.
                                             For example, differently parametrized
                                             but overlapping planes are merged      */
             xTAG tag,            /* I    heap tag                                  */
             INT *iretp));        /*   O  error code
                                   *      == 0 - no error
                                   *      != 0 - error                               */
 

