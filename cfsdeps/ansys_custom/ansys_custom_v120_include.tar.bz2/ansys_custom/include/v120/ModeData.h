#ifndef _MODES_H_
#define _MODES_H_
#include "DomainDec.h"


// Structure to contain Mode Data
// i.e. number of modes, number of nodes, 
// array of frequencies, and matrix of mode shapes.

struct ModeData {
  INT numModes;
  INT numNodes;
  double *frequencies;
  double (**modes)[6];
};

#endif
