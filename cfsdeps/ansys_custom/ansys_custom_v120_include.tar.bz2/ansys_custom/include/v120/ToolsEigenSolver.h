/**
 * @file   ToolsEigenSolver.h
 * @author Frederic Thevenon
 * @date   Thu Sep 15 18:17:11 2005
 * 
 * @brief  
 * 
 * 
 */

#ifndef __TOOLSEIGENSOLVER_I__
#define __TOOLSEIGENSOLVER_I__

#include "C_VecP.h"
#include "C_VecPi.h"
#include "BoeingItf.h"

#define NB_DOFS_MAX_FOR_INCORE	300000
#define EV_DPSMAL			1.E-24

typedef enum {
  NORM_2,
  NORM_INF,
  NORM_MASS
} E_Normalization;

typedef enum {
  GRAM_SCHMIDT,
  HOUSEHOLDER,
  INC_HOUSEHOLDER
} E_OrthoMethod;

extern int CompResidualR( complex16_t &Freq, C_VecP<double> &Vp, double &NrmVec, double &NrmRes, 
			  DOUBLE *Work, BCSINT *Lwork, C_VecP<double> &v1, C_VecP<double> &v2);

extern int CompResidualZ( complex16_t &Freq, C_VecP<double> &Vp, C_VecP<double> &Vp_im,
			  double &NrmVec, double &NrmRes, DOUBLE *Work, BCSINT *Lwork, 
			  C_VecP<double> &v1, C_VecP<double> &v2);

extern int CheckForStability( int VerboseMode, double StabCoef, int NbFreq, int nbcs, int nbloc, 
			      double &fmin, double &fmax, C_VecPi<complex16_t> &SortedEvalues, 
			      C_VecPi<complex16_t> &PreviousValues, C_VecPi<int> &ConvergedValues, 
			      VEC *VecToSort, int &NbAccFreqInRange, bool &MustStop);


class C_LapackForGNHEP
{
public :
  
  C_LapackForGNHEP(void) {};
  ~C_LapackForGNHEP(void) {};

  int	Init( int MaxDim, bool Jobvl, bool Jobvr);  
  int	Run( int &Dim, double *matA, double *matB, 
	     int lda=-1, int ldb=-1);
  int	GetResults( int &NbAskedEv, double fmin, double fmax,
		    C_VecPi<complex16_t> &Eval, C_VecPi<double> &Evec);

protected :
  int			_MaxDim, _CurDim;
  char			_jobvl, _jobvr;
  C_VecPi<double>	_Work;
  int			_lWork;

  C_VecPi<double>	_EigenVectors;
};

extern int MatrixVectorProduct( char mat, INT nbvec, INT nbcs, DOUBLE *X,
				DOUBLE *MX, DOUBLE *Work, BCSINT *Lwork);


template <typename T1, class TOperator> int
NormalizeEigenVector( TOperator &Mat, C_VecPi<T1> &Evec, C_VecPi<T1> &Vtmp)
{
  char		fctn[] = "NormalizeEigenVector";		CADOE_TRACE(fctn);
  static T1	un(1), zero(0);
  
  int ier = Vtmp.Resize( Evec.Dim());					CHKIERS;
  ier = Mat.Mv( un, Evec, zero, Vtmp);					CHKIERS;

  T1 coef = Evec*Vtmp;

  if ( cadoe_dabs( coef) < EV_DPSMAL)
    coef = (T1)1;

  coef = sqrt(coef);
  coef = un/coef;
  
  Evec *= coef;

  return SUCCES;
}

template < typename T, class TOperator> int
LoopToMNormalize( C_VecPi<complex16_t> &Eval, C_VecPi<T> &Evec, TOperator &Mat)
{
  char		fctn[] = "NormalizeEigenVector";		CADOE_TRACE(fctn);
  int		NbEv = Eval.Dim(), Size = Mat.NbLig(), ier;
  C_VecPi<T>	Vtmp( Size);
  
  for( int iv=0; iv<NbEv; iv++)
    {
      C_VecPi<T> Phi( Size, Evec.Adr( iv*Size));
      ier = NormalizeEigenVector<T, TOperator >( Mat, Phi, Vtmp);	CHKIERS;
    }

  return SUCCES;
}

template <> int LoopToMNormalize( C_VecPi<complex16_t> &Eval, C_VecPi<double> &Evec,
				  C_MatMGe<double> &Mat);

#endif	// __TOOLSEIGENSOLVER_I__
