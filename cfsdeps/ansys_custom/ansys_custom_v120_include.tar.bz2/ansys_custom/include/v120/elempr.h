
/* ---------------------------------------------------------------------- */
/* *** copyright(c) 2009 SAS IP, Inc.  All rights reserved. */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*elempr.h                                                              tpp jas
*/
#ifndef ELEMPR_H
#define ELEMPR_H

/*
  --- element parameter include deck
      Note: any changes made to parameters in this file must also be made 
      to the FORTRAN include file elempr.inc
*/

/* --- maximum nodes size (h elements) (currently set by plane273) */
#define NNMAX 108

/* --- maximum row size (h elements) (currently set by conta174) */
#define NSMAX 480

/* --- maximum row size (p elements) */
#define NSPMAX 576

/* --- maximum number of BFE loads (currently set by shell91, 181, and solid191) */
#define NBFEMAX 1024

/* --- maximum dimension of elmdat array */
#define ELATTLEN 11

/* --- maximum number of nodal stresses (currently the largest element result possible) */
/* --- this value used to be hardcoded in pagend                                        */
#define MAXENS 50000

#endif
