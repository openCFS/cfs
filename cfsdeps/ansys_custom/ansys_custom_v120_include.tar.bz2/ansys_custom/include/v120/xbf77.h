/*
 *    author/date: yu-hua ting/04-22-94
 *
 *    primary function:
 *
 *        header for "C callable Fortran routines" in the Ansys/Shapes interface 
 *
 *    secondary function:
 *
 *        none
 *
 *    routines included:
 *
 *        none
 *
 *    history
 *
 *        none
 *
 *    comments:
 *
 *        none
 *
 *    Notice - This file contains ANSYS Confidential information ***
 *
 */
/* 
 * *** copyright(c) 2009 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */



#if defined(RS6000_SYS) || defined(HP32_SYS) 
#define rdinqr_ rdinqr
#define cmdver_cint_ cmdver_cint
#define izero_ izero
#define iges_absetup_ iges_absetup
#define merge_absetup_ merge_absetup
#define iges_abchek_  iges_abchek
#define abloop1_  abloop1
#define abfinish_ abfinish
#define lsgrphdelete_  lsgrphdelete
#define argrphdelete_  argrphdelete
#define xox_mem_allc_ xox_mem_allc
#define xox_mem_deal_ xox_mem_deal
#define axoxsizeresp_ axoxsizeresp
#define axoxloadvm_ axoxloadvm
#define axoxalloc_ axoxalloc
#define axoxmemerr_ axoxmemerr
#define axoxcompbuff_ axoxcompbuff
#define axoxsimpsave_ axoxsimpsave
#define entatt_ entatt
#define ernmem_ ernmem
#define axoxsyserr_ axoxsyserr
#define araget_ araget
#define araiqr_ araiqr
#define araplt_ araplt
#define argtre_ argtre
#define arinqr_ arinqr
#define arlgt2_ arlgt2
#define arliqr_ arliqr
#define arlnew_ arlnew
#define arlput_ arlput
#define arnew_  arnew
#define arvadd_ arvadd
#define cvpget_ cvpget
#define cvpgt2_ cvpgt2
#define entdup_ entdup
#define entgt1_ entgt1
#define entmax_ entmax
#define entplt_ entplt
#define errc1d_ errc1d
#define grinqr_ grinqr
#define kpnew_  kpnew
#define kpinqr_ kpinqr
#define kptplt_ kptplt
#define lsaadd_ lsaadd
#define lsglsl_ lsglsl
#define lsgplt_ lsgplt
#define lsinqr_ lsinqr
#define lsliqr_ lsliqr
#define lsnew_  lsnew
#define lspkpt_ lspkpt
#define mskiqr_ mskiqr
#define nbdiqr_ nbdiqr
#define ncrget_ ncrget
#define nsrget_ nsrget
#define ptggx2_ ptggx2
#define ptggxy_ ptggxy
#define ptinqr_ ptinqr
#define ptnew_  ptnew
#define ptpxy2_ ptpxy2
#define ptpxyz_ ptpxyz
#define ptskpt_ ptskpt
#define ptssel_ ptssel
#define putare_ putare
#define putlsl_ putlsl
#define putsa2_ putsa2
#define putsa_  putsa
#define putsl2_ putsl2
#define putslc_ putslc
#define putsv_  putsv
#define putvlv_ putvlv
#define saeexp_ saeexp
#define saeiqr_ saeiqr
#define saeput_ saeput
#define saesel_ saesel
#define sagpar_ sagpar
#define sagtre_ sagtre
#define sainqr_ sainqr
#define sainqr_ sainqr
#define salgto_ salgto
#define saliqr_ saliqr
#define salnew_ salnew
#define salput_ salput
#define sanexp_ sanexp
#define sanput_ sanput
#define sansel_ sansel
#define sappar_ sappar
#define sarare_ sarare
#define sarnew_ sarnew
#define sarput_ sarput
#define sasel_  sasel
#define savadd_ savadd
#define sccutp_ sccutp
#define scpar_  scpar
#define scrdef_ scrdef
#define scrdel_ scrdel
#define scrdlr_ scrdlr
#define screv_ screv
#define scrgtx_ scrgtx
#define scriqr_ scriqr
#define scrnxt_ scrnxt
#define scrptx_ scrptx
#define scsl_   scsl
#define scspl_  scspl
#define entchk_ entchk
#define imtch_  imtch
#define sectim_ sectim
#define slaadd_ slaadd
#define slgcvn_ slgcvn
#define slgpts_ slgpts
#define slinqr_ slinqr
#define slsel_  slsel
#define slslsg_ slslsg
#define slsnew_ slsnew
#define slsput_ slsput
#define sspar_  sspar
#define ssrvu_ ssrvu
#define ssrvv_ ssrvv
#define sssar_  sssar
#define ssspl_  ssspl
#define ssspu_  ssspu
#define ssspv_  ssspv
#define supget_ supget
#define supgt2_ supgt2
#define svagto_ svagto
#define svaiqr_ svaiqr
#define svanew_ svanew
#define svaput_ svaput
#define svgtre_ svgtre
#define svinqr_ svinqr
#define svlnew_ svlnew
#define svlvol_ svlvol
#define svsel_  svsel
#define tes_    tes
#define timget_ timget
#define uwdp_   uwdp
#define uwint_  uwint
#define vapb1_  vapb1
#define vapb_   vapb
#define vlaget_ vlaget
#define vlaiqr_ vlaiqr
#define vlanew_ vlanew
#define vlaput_ vlaput
#define vlgtre_ vlgtre
#define vlinqr_ vlinqr
#define vlnew_  vlnew
#define vlvget_ vlvget
#define vlviqr_ vlviqr
#define vmove_  vmove
#define vmult1_ vmult1
#define vmult_  vmult
#define volpls_ volpls
#define volplt_ volplt
#define volshl_ volshl
#define sllunq_ sllunq
#define saaunq_ saaunq
#define checkmsh_ checkmsh
#define kpput_  kpput
#define lsput_  lsput
#define arput_  arput
#define vlput_  vlput
#define xoxvldel_  xoxvldel
#define xoxardel_  xoxardel
#define xoxlsdel_  xoxlsdel
#define xoxkpdel_  xoxkpdel
#define lsppar_    lsppar
#define lsgpar_    lsgpar
#define lsgevl_	   lsgevl
#define arcpar_    arcpar
#define lshtsp_    lshtsp
#define arppar_    arppar
#define vlppar_    vlppar
#define sizeadd_   sizeadd
#define axoxdbopen_ axoxdbopen
#define axoxput_ axoxput
#define axoxcharput_ axoxcharput
#define axoxrealput_ axoxrealput
#define axoxget_ axoxget
#define axoxcharget_ axoxcharget
#define axoxrealget_ axoxrealget
#define axoxdtleng_ axoxdtleng
#endif


#if defined(WATCOMC_SYS) \
    || defined(PCWINNT_SYS)

#define rdinqr_ RDINQR
#define cmdver_cint_ CMDVER_CINT
#define izero_ IZERO
#define iges_absetup_ IGES_ABSETUP
#define merge_absetup_ MERGE_ABSETUP
#define iges_abchek_  IGES_ABCHEK
#define abloop1_  ABLOOP1
#define abfinish_ ABFINISH
#define lsgrphdelete_  LSGRPHDELETE
#define argrphdelete_  ARGRPHDELETE
#define xox_mem_allc_ XOX_MEM_ALLC
#define xox_mem_deal_ XOX_MEM_DEAL
#define axoxsizeresp_ AXOXSIZERESP
#define axoxloadvm_ AXOXLOADVM
#define axoxalloc_ AXOXALLOC
#define axoxmemerr_ AXOXMEMERR
#define axoxcompbuff_ AXOXCOMPBUFF
#define axoxsimpsave_ AXOXSIMPSAVE
#define entatt_ ENTATT
#define ernmem_ ERNMEM
#define axoxsyserr_ AXOXSYSERR
#define araget_ ARAGET
#define araiqr_ ARAIQR
#define araplt_ ARAPLT
#define argtre_ ARGTRE
#define arinqr_ ARINQR
#define arlgt2_ ARLGT2
#define arliqr_ ARLIQR
#define arlnew_ ARLNEW
#define arlput_ ARLPUT
#define arnew_  ARNEW
#define arvadd_ ARVADD
#define cvpget_ CVPGET
#define cvpgt2_ CVPGT2
#define entdup_ ENTDUP
#define entgt1_ ENTGT1
#define entmax_ ENTMAX
#define entplt_ ENTPLT
#define errc1d_ ERRC1D 
#define grinqr_ GRINQR
#define kpnew_  KPNEW
#define kpinqr_ KPINQR
#define kptplt_ KPTPLT
#define lsaadd_ LSAADD
#define lsglsl_ LSGLSL
#define lsgplt_ LSGPLT
#define lsinqr_ LSINQR
#define lsliqr_ LSLIQR
#define lsnew_  LSNEW
#define lspkpt_ LSPKPT
#define mskiqr_ MSKIQR
#define nbdiqr_ NBDIQR
#define ncrget_ NCRGET
#define nsrget_ NSRGET
#define ptggx2_ PTGGX2 
#define ptggxy_ PTGGXY
#define ptinqr_ PTINQR
#define ptnew_  PTNEW
#define ptpxy2_ PTPXY2
#define ptpxyz_ PTPXYZ
#define ptskpt_ PTSKPT
#define ptssel_ PTSSEL 
#define putare_ PUTARE
#define putlsl_ PUTLSL
#define putsa2_ PUTSA2
#define putsa_  PUTSA
#define putsl2_ PUTSL2
#define putslc_ PUTSLC
#define putsv_  PUTSV
#define putvlv_ PUTVLV
#define saeexp_ SAEEXP
#define saeiqr_ SAEIQR
#define saeput_ SAEPUT
#define saesel_ SAESEL
#define sagpar_ SAGPAR
#define sagtre_ SAGTRE
#define sainqr_ SAINQR
#define sainqr_ SAINQR
#define salgto_ SALGTO
#define saliqr_ SALIQR
#define salnew_ SALNEW
#define salput_ SALPUT
#define sanexp_ SANEXP
#define sanput_ SANPUT
#define sansel_ SANSEL
#define sappar_ SAPPAR
#define sarare_ SARARE
#define sarnew_ SARNEW
#define sarput_ SARPUT
#define sasel_  SASEL 
#define savadd_ SAVADD
#define sccutp_ SCCUTP
#define scpar_  SCPAR 
#define scrdef_ SCRDEF
#define scrdel_ SCRDEL
#define scrdlr_ SCRDLR
#define screv_ SCREV
#define scrgtx_ SCRGTX
#define scriqr_ SCRIQR
#define scrnxt_ SCRNXT 
#define scrptx_ SCRPTX
#define scsl_   SCSL 
#define scspl_  SCSPL
#define entchk_ ENTCHK
#define imtch_  IMTCH 
#define sectim_ SECTIM
#define slaadd_ SLAADD
#define slgcvn_ SLGCVN
#define slgpts_ SLGPTS
#define slinqr_ SLINQR
#define slsel_  SLSEL 
#define slslsg_ SLSLSG
#define slsnew_ SLSNEW
#define slsput_ SLSPUT
#define sspar_  SSPAR
#define ssrvu_ SSRVU
#define ssrvv_ SSRVV
#define sssar_  SSSAR
#define ssspl_  SSSPL
#define ssspu_  SSSPU
#define ssspv_  SSSPV
#define supget_ SUPGET
#define supgt2_ SUPGT2
#define svagto_ SVAGTO
#define svaiqr_ SVAIQR
#define svanew_ SVANEW
#define svaput_ SVAPUT
#define svgtre_ SVGTRE
#define svinqr_ SVINQR
#define svlnew_ SVLNEW
#define svlvol_ SVLVOL
#define svsel_  SVSEL 
#define tes_    TES
#define timget_ TIMGET
#define uwdp_   UWDP
#define uwint_  UWINT
#define vapb1_  VAPB1
#define vapb_   VAPB
#define vlaget_ VLAGET
#define vlaiqr_ VLAIQR
#define vlanew_ VLANEW
#define vlaput_ VLAPUT
#define vlgtre_ VLGTRE
#define vlinqr_ VLINQR
#define vlnew_  VLNEW
#define vlvget_ VLVGET
#define vlviqr_ VLVIQR
#define vmove_  VMOVE
#define vmult1_ VMULT1
#define vmult_  VMULT
#define volpls_ VOLPLS
#define volplt_ VOLPLT
#define volshl_ VOLSHL
#define sllunq_ SLLUNQ
#define saaunq_ SAAUNQ
#define checkmsh_ CHECKMSH
#define kpput_  KPPUT
#define lsput_  LSPUT
#define arput_  ARPUT
#define vlput_  VLPUT
#define xoxvldel_  XOXVLDEL
#define xoxardel_  XOXARDEL
#define xoxlsdel_  XOXLSDEL
#define xoxkpdel_  XOXKPDEL
#define lsppar_    LSPPAR
#define lsgpar_    LSGPAR
#define lshtsp_    LSHTSP
#define lsgevl_    LSGEVL
#define arcpar_    ARCPAR
#define arppar_    ARPPAR
#define vlppar_    VLPPAR
#define sizeadd_   SIZEADD
#define axoxdbopen_ AXOXDBOPEN
#define axoxput_  AXOXPUT
#define axoxcharput_  AXOXCHARPUT
#define axoxrealput_  AXOXREALPUT
#define axoxget_  AXOXGET
#define axoxcharget_  AXOXCHARGET
#define axoxrealget_  AXOXREALGET
#define axoxdtleng_ AXOXDTLENG

#endif


/************************************************************************/





/****************************************************************************
 *    declarations of ANSYS Fortran calls                                   *
 ****************************************************************************/


      extern INT  CALLTYP rdinqr_();
      extern VOID CALLTYP cmdver_cint_();
      extern VOID CALLTYP izero_();
      extern VOID CALLTYP iges_absetup_();
      extern VOID CALLTYP merge_absetup_();
      extern VOID CALLTYP iges_abchek_();
      extern VOID CALLTYP abloop1_();
      extern VOID CALLTYP abfinish_();
      extern VOID CALLTYP lsgrphdelete_();
      extern VOID CALLTYP argrphdelete_();
      extern VOID CALLTYP sizeadd_();
      extern INT  CALLTYP xox_mem_allc_();
      extern VOID CALLTYP xox_mem_deal_();
      extern INT  CALLTYP axoxsizeresp_();
      extern VOID CALLTYP axoxloadvm_();
      extern INT  CALLTYP axoxalloc_();
      extern VOID  CALLTYP axoxmemerr_();
      extern INT  CALLTYP axoxcompbuff_();
      extern INT  CALLTYP axoxsimpsave_();
      extern VOID CALLTYP entatt_();
      extern VOID CALLTYP ernmem_();
      extern VOID CALLTYP axoxsyserr_();
      extern INT  CALLTYP araget_();
      extern INT  CALLTYP araiqr_();
      extern INT  CALLTYP argtre_();
      extern INT  CALLTYP arinqr_();
      extern INT  CALLTYP arlgt2_();
      extern INT  CALLTYP arliqr_();
      extern INT  CALLTYP arlnew_();
      extern INT  CALLTYP arnew_();
      extern INT  CALLTYP cvpget_();
      extern INT  CALLTYP cvpgt2_();
      extern INT  CALLTYP entdup_();
      extern INT  CALLTYP entmax_();
      extern INT  CALLTYP grinqr_();
      extern INT  CALLTYP kpnew_();
      extern INT  CALLTYP kpinqr_();
      extern INT  CALLTYP lsglsl_();
      extern INT  CALLTYP lsinqr_();
      extern INT  CALLTYP lsliqr_();
      extern INT  CALLTYP lsnew_();
      extern INT  CALLTYP mskiqr_();
      extern INT  CALLTYP nbdiqr_();
      extern INT  CALLTYP ncrget_();
      extern INT  CALLTYP nsrget_();
      extern INT  CALLTYP ptggx2_();
      extern INT  CALLTYP ptggxy_();
      extern INT  CALLTYP ptinqr_();
      extern INT  CALLTYP ptnew_();
      extern INT  CALLTYP saeiqr_();
      extern INT  CALLTYP sagpar_();
      extern INT  CALLTYP sagtre_();
      extern INT  CALLTYP sainqr_();
      extern INT  CALLTYP sainqr_();
      extern INT  CALLTYP salgto_();
      extern INT  CALLTYP saliqr_();
      extern INT  CALLTYP salnew_();
      extern INT  CALLTYP sarnew_();
      extern INT  CALLTYP sarput_();
      extern INT  CALLTYP scrgtx_(); 
      extern INT  CALLTYP scriqr_(); 
      extern INT  CALLTYP slgcvn_();
      extern INT  CALLTYP slgpts_();
      extern INT  CALLTYP slinqr_();
      extern INT  CALLTYP slsnew_();
      extern INT  CALLTYP slsput_();
      extern INT  CALLTYP supget_();
      extern INT  CALLTYP supgt2_();
      extern INT  CALLTYP svagto_();
      extern INT  CALLTYP svaiqr_();
      extern INT  CALLTYP svanew_();
      extern INT  CALLTYP svgtre_();
      extern INT  CALLTYP svinqr_();
      extern INT  CALLTYP svlnew_();
      extern INT  CALLTYP vlaget_();
      extern INT  CALLTYP vlaiqr_();
      extern INT  CALLTYP vlanew_();
      extern INT  CALLTYP vlgtre_();
      extern INT  CALLTYP vlinqr_();
      extern INT  CALLTYP vlnew_();
      extern INT  CALLTYP vlvget_();
      extern INT  CALLTYP vlviqr_();
      extern VOID CALLTYP araplt_();
      extern VOID CALLTYP arlput_();
      extern VOID CALLTYP arvadd_();
      extern VOID CALLTYP entgt1_();
      extern VOID CALLTYP entplt_();
      extern VOID CALLTYP errc1d_();
      extern VOID CALLTYP kptplt_();
      extern VOID CALLTYP lsaadd_();
      extern VOID CALLTYP lsgplt_();
      extern VOID CALLTYP lspkpt_();
      extern VOID CALLTYP ptpxy2_();
      extern VOID CALLTYP ptpxyz_();
      extern VOID CALLTYP ptskpt_();
      extern VOID CALLTYP ptssel_();
      extern VOID CALLTYP putare_();
      extern VOID CALLTYP putlsl_();
      extern VOID CALLTYP putsa2_();
      extern VOID CALLTYP putsa_();
      extern VOID CALLTYP putsl2_();
      extern VOID CALLTYP putslc_();
      extern VOID CALLTYP putsv_();
      extern VOID CALLTYP putvlv_();
      extern VOID CALLTYP saeexp_();
      extern VOID CALLTYP saeput_();
      extern VOID CALLTYP saesel_();
      extern VOID CALLTYP salput_();
      extern VOID CALLTYP sanexp_();
      extern VOID CALLTYP sanput_();
      extern VOID CALLTYP sansel_();
      extern VOID CALLTYP sappar_();
      extern VOID CALLTYP sarare_();
      extern VOID CALLTYP sasel_();
      extern VOID CALLTYP savadd_();
      extern VOID CALLTYP sccutp_();
      extern VOID CALLTYP scpar_();
      extern VOID CALLTYP scrdef_(); 
      extern VOID CALLTYP scrdel_(); 
      extern VOID CALLTYP scrdlr_();
      extern VOID CALLTYP screv_();
      extern VOID CALLTYP scrnxt_(); 
      extern VOID CALLTYP scrptx_(); 
      extern VOID CALLTYP scsl_(); 
      extern VOID CALLTYP scspl_(); 
      extern INT  CALLTYP entchk_();
      extern INT  CALLTYP imtch_();
      extern VOID CALLTYP sectim_();
      extern VOID CALLTYP slaadd_();
      extern VOID CALLTYP slsel_();
      extern VOID CALLTYP slslsg_();
      extern VOID CALLTYP sspar_();
      extern VOID CALLTYP ssrvu_();
      extern VOID CALLTYP ssrvv_();
      extern VOID CALLTYP sssar_(); 
      extern VOID CALLTYP ssspl_(); 
      extern VOID CALLTYP ssspu_(); 
      extern VOID CALLTYP ssspv_(); 
      extern VOID CALLTYP svaput_();
      extern VOID CALLTYP svlvol_();
      extern VOID CALLTYP svsel_();
      extern VOID CALLTYP tes_();
      extern VOID CALLTYP timget_();
      extern VOID CALLTYP uwdp_();
      extern VOID CALLTYP uwint_();
      extern VOID CALLTYP vapb1_();
      extern VOID CALLTYP vapb_();
      extern VOID CALLTYP vlaput_();
      extern VOID CALLTYP vmove_();
      extern VOID CALLTYP vmult1_();
      extern VOID CALLTYP vmult_();
      extern VOID CALLTYP volpls_();
      extern VOID CALLTYP volplt_();
      extern VOID CALLTYP volshl_();
      extern VOID CALLTYP sllunq_();
      extern VOID CALLTYP saaunq_();
      extern VOID CALLTYP checkmsh_();
      extern VOID CALLTYP kpput_();
      extern VOID CALLTYP lsput_();
      extern VOID CALLTYP arput_();
      extern VOID CALLTYP vlput_();
      extern VOID CALLTYP xoxkpdel_();
      extern VOID CALLTYP xoxlsdel_();
      extern VOID CALLTYP xoxardel_();
      extern VOID CALLTYP xoxvldel_();
      extern VOID CALLTYP lsppar_();
      extern INT  CALLTYP lsgpar_();
      extern VOID CALLTYP lshtsp_();
      extern VOID CALLTYP lsgevl_();
      extern VOID CALLTYP arcpar();
      extern VOID CALLTYP arppar_();
      extern VOID CALLTYP vlppar_();
      extern VOID CALLTYP axoxdbopen_();
      extern INT CALLTYP axoxget_();
      extern INT CALLTYP axoxcharget_();
      extern INT CALLTYP axoxrealget_();
      extern VOID CALLTYP axoxput_();
      extern VOID CALLTYP axoxcharput_();
      extern VOID CALLTYP axoxrealput_();
      extern INT CALLTYP axoxdtleng_();
