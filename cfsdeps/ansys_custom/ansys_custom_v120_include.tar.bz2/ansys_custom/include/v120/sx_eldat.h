/* CADOE */
/*
 *   eldat.h -- Acces au modele derive depuis le fortran 
 * 
 *  |Version : $Id: sx_eldat.h,v 1.1.6.1 2009/04/13 14:10:00 jtm Exp $
 */
#ifndef __ELDAT_X_DEJA_INCLUS
#define __ELDAT_X_DEJA_INCLUS 1


#include "sx_CADOE_solver.h"

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#if defined(LOWERCASENOUNDER_SYS)
#endif

#if defined(UPPERCASENOUNDER_SYS)
#define taymat  TAYMAT  
#define tayphy TAYPHY
#define taynel TAYNEL
#define tayord TAYORD
#define tayono TAYONO
#define taynoe TAYNOE
#define updnoe UPDNOE
#define tayfreq TAYFREQ
#define taynum TAYNUM
#define taytemp TAYTEMP
#define tayboo TAYBOO
#define eldatd1 ELDATD1
#define eldatd2 ELDATD2
#define eldatd3 ELDATD3
#define eldatd4 ELDATD4
#define eldatd5 ELDATD5
#define eldatd6 ELDATD6
#define propder PROPDER
#define propupd PROPUPD
#define propreset PROPRESET
#define tkder   TKDER
#define get_elm_family GET_ELM_FAMILY 
#define get_elm_type_geometrique GET_ELM_TYPE_GEOMETRIQUE
#define thermal_solve_nod_temp THERMAL_SOLVE_NOD_TEMP  
#endif

#if defined(LOWERCASEUNDER_SYS)
#define taymat taymat_  
#define tayphy tayphy_
#define taynel taynel_
#define tayord tayord_
#define tayono tayono_
#define taynoe taynoe_
#define updnoe updnoe_
#define tayfreq tayfreq_
#define taynum taynum_
#define taytemp taytemp_
#define tayboo tayboo_
#define eldatd1 eldatd1_
#define eldatd2 eldatd2_
#define eldatd3 eldatd3_
#define eldatd4 eldatd4_
#define eldatd5 eldatd5_
#define eldatd6 eldatd6_
#define propder propder_
#define propupd propupd_
#define propreset propreset_
#define tkder tkder_
#define get_elm_family get_elm_family_
#define get_elm_type_geometrique get_elm_type_geometrique_
#define thermal_solve_nod_temp thermal_solve_nod_temp_  
#endif

SUBROUTINE taymat( INT *label, INT *nbpmat, INT *maxord, INT *mid, INT *ipel, INT *opel, INT *mptr, DOUBLE *mte, INT *ier );
SUBROUTINE tayphy( INT *label, INT *nbpphy, INT *maxord, INT *pid, INT *ipel, INT *opel, INT *pptr, DOUBLE *pte, INT *ier );
SUBROUTINE taynel( INT *label, INT *og, INT *nb_nodes, DOUBLE nte[], INT *ier );
SUBROUTINE tayord( INT *ordre );
SUBROUTINE tayono( INT *label, INT *og, DOUBLE nte[3][ORDRE_GEOMETRIQUE+1], INT *ier );
SUBROUTINE taynoe( INT *label, INT *og, DOUBLE nte[3*(ORDRE_GEOMETRIQUE+1)], INT *ier );
SUBROUTINE updnoe( INT *label, INT *og, DOUBLE xyz[3], DOUBLE xyzu[3], INT *ier );
SUBROUTINE tayfreq( INT *label, INT *of, DOUBLE *pte, INT *ier );
SUBROUTINE taynum( INT *label, INT *nbpnum, INT *maxord, INT *pid, INT *ipel, INT *opel, INT *pptr, DOUBLE *pte, INT *ier );
SUBROUTINE taytemp( INT *label, INT *ot, DOUBLE tte[], INT *ier );
SUBROUTINE tayboo( INT *label, INT *ot, DOUBLE *scal, INT *ier );
SUBROUTINE eldatd1( INT *label, INT *activ, INT *iret );
SUBROUTINE eldatd2( INT *label, INT *sderiv, INT *pderiv, INT *mderiv, INT *nderiv, INT *tderiv, INT *bderiv, INT *dlderiv, INT *iret );
SUBROUTINE eldatd3( INT *label, INT *sorder, DOUBLE *elpert, INT *iret );
SUBROUTINE eldatd4( INT *label, INT *oorder, DOUBLE *onpert, INT *iret );
SUBROUTINE eldatd5( INT *label, INT *torder, DOUBLE *ttemp, INT *iret );
SUBROUTINE eldatd6( INT *label, INT *border, DOUBLE *scale, INT *iret );
SUBROUTINE propder( INT *dorder, INT *ityp, INT *ipel, INT *opel, DOUBLE *te, INT *iret );
SUBROUTINE tkder( INT *dorder, INT *label, INT *ityp, INT *id, INT *ipel, DOUBLE *pval, INT *opel, DOUBLE *te, INT *iret );
SUBROUTINE propupd( INT *iele, INT *ityp, INT *ipel, INT *modif_type, DOUBLE *val, INT *modified, INT *iret );
SUBROUTINE propreset( INT *iele, INT *ityp, INT *ipel, INT *modif_type, DOUBLE *val, INT *modified, INT *iret );
SUBROUTINE get_elm_family( INT *efam );
SUBROUTINE get_elm_type_geometrique( INT *etype );
SUBROUTINE thermal_solve_nod_temp( INT* );


#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif	 /* __ELDAT_X_DEJA_INCLUS__ */
