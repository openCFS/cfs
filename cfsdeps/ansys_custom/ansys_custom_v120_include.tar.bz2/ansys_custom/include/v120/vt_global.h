////////////////////////////////////////////////////////////////////////////
//                                                                        //
//          copyright(c) 2009 SAS IP, Inc.  All rights reserved.            //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: vt_global.h $
// $Revision: 1.2.2.1 $Id: 
// $Date: 2009/04/10 15:33:28 $
// $Author: jtm $
//
// Decription: 
//
////////////////////////////////////////////////////////////////////////////


#ifndef __VT_GLOBAL__
#define __VT_GLOBAL__ 1

#include "C_AnsysModele.h"

extern C_AnsysModele *G_AnsysModele;

#endif
