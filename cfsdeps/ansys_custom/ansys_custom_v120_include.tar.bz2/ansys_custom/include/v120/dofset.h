#ifndef _DOFSET_H_
#define _DOFSET_H_

class DofSet {
  protected:
    int flags;
  public:
    const static int max_known_dof = 40; // 8
    static int 
      Xdisp,
      Ydisp,
      Zdisp,
      XYZdisp,
      Xrot,
      Yrot,
      Zrot,
      XYZrot,
      Temp,
      Helm,
      Volt, Mag, Hdsp, Pres, EMF, Cur;
    // constructors
    DofSet()      { flags = 0; }
    DofSet(int t) { flags = t; }
    void setFlag(int t) {flags = t;}
  
    DofSet & operator|=(DofSet &ds) { flags |= ds.flags; return *this; }

    // mark marks given dofs as being used
    void mark(int dofs) { flags |= dofs; }

    void unmark(int dofs) { flags = flags ^ (flags & dofs); }

    void unmark(const DofSet &dofs) {  flags = flags ^ (flags & dofs.flags); }
  
    // tests if all the given dofs are present
    int test(int dofs) { return (flags & dofs) == dofs ; }

    // see presence of at least one dof
    int contains(int dofs) { return (flags & dofs); }

    // counts the number dofs marked in this node
    int count() ;

    int number(DofSet, int *); // This routine complements the previous
                  // one, numbering all the DOFs in the first argument

    int number(DofSet ds);
    
    // Locates a dof in the current set. Only works for single dofs
    // i.e. result is undefined for composites such as XYZrot and XYZdisp
    int locate(int dof);

    int list() { return flags; }

    void print(char *msg);

    DofSet operator & (DofSet d) { return DofSet(flags & d.flags); }
    DofSet operator ^ (DofSet d) { return DofSet(flags ^ d.flags); }
    DofSet operator | (DofSet d) { return DofSet(flags | d.flags); }
};

class Elemset;
class FSElement;

class EqNumberer {
  protected:
    int _numnodes; 	// total number of nodes
    int *_node_offset; 	// Where the nodes are
    int *_node_num_dofs; // Number of dofs associated with a node
    int *_renummap;    	// Renumbering mapping of the nodes

  public:
    // Return the total number of degrees of freedom
    int size(){ return _node_offset[_numnodes]; }

    // Return the number of nodes
    int numNodes() { return _numnodes; }

    // Return the first dof of a node
    int firstdof(int node) 
     { return (_node_num_dofs[node] > 0) ? _node_offset[node] : -1; }

    // Return the weight of a node (its number of dofs)
    int weight(int n) { return _node_num_dofs[n]; }

    int *allOffsets() { return _node_offset; }

    int *renumPtr() { return _renummap; }
};

class DofSetArray : public EqNumberer {
  protected:
    DofSet *_dofs;
    int *_rowcolnum;
    int *_invrowcol;
    int *_dofType; // 0 = translational, 1 = rotational

    DofSetArray() {}

  protected:
    void  makeOffset();
  public:
    DofSetArray(int nnodes, Elemset &elearray, int *renumtable=0);
    DofSetArray(int nnodes, int numEles,FSElement **ele, int *renumtable=0);
    DofSetArray(int nnodes, DofSet *df, int *renumtable=0);

    ~DofSetArray();

    // locate a dof for a given node
    int locate(int node, int dof);
    int number(int, DofSet, int *);

    // this version of number assumes there's only one dof flagged in the DofSet
    int number(int node, DofSet ds);
    
    // Mark dofs for a node
    void mark(int node, int dof);

    // Return the DofSet of a node
    DofSet &operator [](int i) { return _dofs[i]; }

    int getRCN(int dof)   { return _rowcolnum[dof]; }
    int invRCN(int dof)   { return _invrowcol[dof]; }

    int* getUnconstrNum() { return _rowcolnum; }
    int* getConstrndNum() { return _invrowcol; }

    int* makeDofTypeArray(); // creates and returns dofType array
                             // 0 = translational, 1 = rotational

    void print(int *localNodes, char *msg);

    friend class ConstrainedDSA;
};

class BCond;
class ComplexBCond;

class ConstrainedDSA : public DofSetArray {
  public:
    ConstrainedDSA(DofSetArray &, DofSet *);
    ConstrainedDSA(DofSetArray &, int, BCond *);
    ConstrainedDSA(DofSetArray &,DofSetArray &, int, BCond *,int);
    ConstrainedDSA(DofSetArray &, int, BCond *, int *bc);
    ConstrainedDSA(DofSetArray &, int, ComplexBCond *, int *bc);
    ConstrainedDSA(DofSetArray &dsa, BCond *bcdata, int nbc,
                               ComplexBCond *bcd, int nbcd, int *bc);
};

// Auxiliary definitions
#define BCFREE  0
#define BCLOAD  1
#define BCFIXED 2

class SimpleNumberer : public EqNumberer {
   public:
      SimpleNumberer(int nnodes, int *renumb = 0);
      void setWeight(int, int);
      void makeOffset();
};
#endif
