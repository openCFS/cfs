/*****************************************************************************
 *                   Copyright (C) 1999 CMSoft                               *
 *                                                                           *
 *  These lines of code and declarations contain unpublished proprietary     *
 *  information of CMSoft. They may not be copied or duplicated in whole     *
 *  or part without prior authorization from CMSoft.                         *
 *                                                                           *
 *****************************************************************************/
#ifndef _FS_ORTHO_SET_H_
#define _FS_ORTHO_SET_H_
#include "DistVector.h"
#include "DistInfo.h"
#include "ThreadManager.h"
#include "ParalExec.h"
#include "C_vstruct.h"

class OrthoSet 
{
  double * _allPFiP;
  double **_locP; // localized by thread
  double **_locFiP;
  
  int _len;
  int *_locLen;
  int *_offset;
  
  int _numP;
  int _maxP;
  
  int _numThreads;
  FSThreadLock _lock; // need a lock

protected:
  void subAdd(int, double *, double *);
  void Fdot(int, double *x, double *res);
  void dot(int, double *x, double *res);
  void subSubP(int, double *r, double *p, double *y);
  void MvP(int, double *x, double *y);
  void MvFiP(int, double *x, double *y);
  
public:
  OrthoSet(int size, int len);
  ~OrthoSet();
  
  void orthoAdd(double *, double *, double);
  void orthogonalize(double *, double *, double * = NULL);
  void orthogonalize2(double *, double *);
  void VmultPhi(double *w, double *z);
  void minimize(double *, double *);
  void MvFiP(double *x, double *y, bool transpose);
  void MvP(double *x, double *y, bool transpose);
  int numDir()    { return _numP; }

  void Write(FILE *);
  void Read(FILE *);
};

class KrylovSet
{
  double **_locP; // localized by thread
  
  int _len;
  int *_locLen;
  int *_offset;
  
  int _numP;
  int _maxP;
  
  int _numThreads;
  FSThreadLock _lock; // need a lock

protected:
  void subAdd(int, double *);
  void dot(int, double *x, double *res);
  void subSubP(int, double *r, double *p, double *y);
  void Mv(int iThread, double *coefs, double *y);
  
public:
  KrylovSet(int size, int len);
  ~KrylovSet();
  
  void orthoAdd(double *);
  void orthogonalize(double *, double *, double &, double &, double * = NULL);
  void Mv(double *alpha, double *res);
  int numDir()    { return _numP; }
};

#endif
