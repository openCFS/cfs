/* CADOE */
/**
 *	noeud.h -- fonctions attachees aux objets noeud
 *
 **/

#include "sx_CADOE_solver.h"
#ifndef __NOEUD_H_DEJA_INCLUS__
#define __NOEUD_H_DEJA_INCLUS__ 1

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

  extern IntegerAdr NOE_compter( T_noeud*, E_resultat_parametre, T_modele*, T_statut* );
  extern IntegerAdr NOE_compter2( T_noeud*, E_resultat_parametre, T_modele*, T_statut* );
  extern int NOE_nb_ddl( T_noeud*, T_modele* );
  extern double NOE_extraire_deplacement( T_noeud *noeud, int composante, E_zcomp zcomp, T_booleen, double *deplacement, T_modele*, T_statut *ier );
  extern double NOE_extraire_equivalent_tenseur( T_noeud *, int, int, T_fct_compo, T_champ_global*, double *, T_booleen, T_statut* );
  extern double NOE_extraire_tg( T_noeud *noeud, int composante, double *tg, T_statut *ier );
  extern int NOE_is_on( T_noeud *element, E_resultat_parametre resultat );
  extern int NOE_is_off( T_noeud *noeud, E_resultat_parametre resultat );
  extern void NOE_set_on( T_noeud *noeud, E_resultat_parametre resultat );
  extern void NOE_set_off( T_noeud *noeud, E_resultat_parametre resultat );
  extern T_statut NOE_initialise_champs(T_modele * modele);
#ifdef __cplusplus
}
#endif /* __cplusplus */


#endif	 /* __NOEUD_H_DEJA_INCLUS__ */
