
/* Define MPI communication tag */
#include "mpitag.h"



/* Global variables */

INT             GlbnNodes;
INT             GlbnElems;
INT             GlbnumDof;
INT             GlbnDomain;

INT             GlbadjustCE;  /* Number of CEs in cpce data structure summed */
                              /* between all machines into one value for all */
INT             GlbfinalCE;   /* Number of CEs in Glbcpce data structure     */
                              /* (this value is shared out on all machines)  */
INT             GlbfinalAcCE;
INT            *GlbfinalCEMark;

NodeList        GlbfeNodeList;
ElemArr         GlbelemArr;

sparseFactor    GlbA_adjArr;
sparseFactor    GlbM_adjArr;
sparseFactor    GlbD_adjArr;
sparseFactor    GlbA11;
sparseFactor    GlbA12T;
sparseFactor    GlbA21T;
sparseFactor    GlbM11;
sparseFactor    GlbM12T;
sparseFactor    GlbM21T;
sparseFactor    GlbD11;
sparseFactor    GlbD12T;
sparseFactor    GlbD21T;
DOUBLE*         Glbrhs;
DOUBLE*         GlbrhsMass;


DomainConnection SubToElem, ElemToNode, SubToNode, NodeToSub, SharedNodes;

INT*            GlbToLocalNode;
INT*            LocalToGlbNode;
INT*            GlbToLocalElem;
INT*            LocalToGlbElem;
DOUBLE          *GlbSendBufferPCGDof;
DOUBLE          *GlbRecvBufferPCGDof;
DOUBLE          *GlbSendBufferANSDof;
DOUBLE          *GlbRecvBufferANSDof;


INT*            NodeTouched;

INT*            GlblDofPerNode;
CpCe            Glbcpce;
sparseFactor    GlbG;

DOUBLE*         DofnSub;      /* nVars, 1/nSub on this DOF */

INT*            IntfaceLen;
INT*            IntfacePos;
INT*            IntfaceLenUniform;
INT*            IntfacePosUniform;

INT             TotalIntfLen;
INT             TotalIntfLenUniform;

LONGINTC        totalDiagLenL;
INT             maxMaster;

INT             *GlbForward;
INT             *GlbBack;
INT             *GlbExtToGlbIntElem;
INT             *GlbIntToGlbExtElem;

INT		maxSetVars;

PTR             sndReq[MAX_NUMCPU];
PTR             rcvReq[MAX_NUMCPU];

