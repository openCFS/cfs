/*HFILE statTableUtils.h                  ANSI_C                      dc
------------------------------------------------------------------------
------- Notice - This file contains ANSYS Confidential information
------------------------------------------------------------------------
*/

/*------------------------------ Description ---------------------------

\Author:    Dave Conover

\Title:     statistics gathering C header

\Desc:      Header for utilities used in c code for statistics gathering

            Currently contains the following functions:

		   cStatUpdateMPI_Send
                   cStatUpdateMPI_Recv
                   cStatUpdateMPI_Bcast
                   cStatUpdateMPI_Reduce
                   cStatUpdateMPI_Barrier
                   cStatUpdateMPI_AllReduce
                   cStatUpdateMPI_Probe
                   statInitMPI
                   statRetrieveMPI
                   statBegin
                   statEnd
                   statGlobalPut
                   statGlobalPutL
                   statGlobalPutDP

\History:   Created 8/17/04 (dc)

\Function(s)
 -Primary:      Standard C header
 -Secondary:    Prototypes for statTableUtils.c
 -External:     none
 -Internal:     none
 -Static:       none

----------------------------------------------------------------------*/


/*-------------------------------- Globals ---------------------------*/

extern INT       statLvl;
extern INT       LvlMPICalls[STATLVLMAX+1];
extern DOUBLE    LvlMPIDataSent[STATLVLMAX+1];
extern LONGINTC  LvlMPIMaxMsgLengthSent[STATLVLMAX+1];
extern DOUBLE    LvlMPIDataRecv[STATLVLMAX+1];
extern LONGINTC  LvlMPIMaxMsgLengthRecv[STATLVLMAX+1];
extern INT       LvlMPISendCalls[STATLVLMAX+1];
extern DOUBLE    LvlMPISendCP[STATLVLMAX+1];
extern DOUBLE    LvlMPISendWall[STATLVLMAX+1];
extern INT       LvlMPIRecvCalls[STATLVLMAX+1];
extern DOUBLE    LvlMPIRecvCP[STATLVLMAX+1];
extern DOUBLE    LvlMPIRecvWall[STATLVLMAX+1];
extern INT       LvlMPIBarrierCalls[STATLVLMAX+1];
extern DOUBLE    LvlMPIBarrierCP[STATLVLMAX+1];
extern DOUBLE    LvlMPIBarrierWall[STATLVLMAX+1];
extern INT       LvlMPIReduceCalls[STATLVLMAX+1];
extern DOUBLE    LvlMPIReduceCP[STATLVLMAX+1];
extern DOUBLE    LvlMPIReduceWall[STATLVLMAX+1];
extern INT       LvlMPIProbeCalls[STATLVLMAX+1];
extern DOUBLE    LvlMPIProbeCP[STATLVLMAX+1];
extern DOUBLE    LvlMPIProbeWall[STATLVLMAX+1];

/*------------------------------ Prototypes --------------------------*/

extern void      cStatUpdateMPI_Send(LONGINTC,DOUBLE,DOUBLE);
extern void      cStatUpdateMPI_Recv(LONGINTC,DOUBLE,DOUBLE);
extern void      cStatUpdateMPI_Bcast(LONGINTC,INT,INT,INT,DOUBLE,DOUBLE);
extern void      cStatUpdateMPI_Reduce(LONGINTC,INT,INT,INT,DOUBLE,DOUBLE);
extern void      cStatUpdateMPI_Barrier(LONGINTC,DOUBLE,DOUBLE);
extern void      cStatUpdateMPI_AllReduce(LONGINTC,DOUBLE,DOUBLE);
extern void      cStatUpdateMPI_Probe(LONGINTC,DOUBLE,DOUBLE);

/*------------------------- C called from FORTRAN --------------------*/

#if defined(UPPERCASENOUNDER_SYS)
#define statInitMPI STATINITMPI
#define statRetrieveMPI STATRETRIEVEMPI
#endif

#if defined(LOWERCASENOUNDER_SYS)
#define statInitMPI statinitmpi
#define statRetrieveMPI statretrievempi
#endif

#if defined(LOWERCASEUNDER_SYS)
#define statInitMPI statinitmpi_
#define statRetrieveMPI statretrievempi_
#endif

SUBROUTINE statInitMPI(INT*);
SUBROUTINE statRetrieveMPI(INT*, INT*, LONGINTC*, DOUBLE*);

/*------------------------- FORTRAN called from C --------------------*/

#if defined(UPPERCASENOUNDER_SYS)
#define statBegin       STATBEGIN
#define statEnd         STATEND
#define statGlobalPut   STATGLOBALPUT
#define statGlobalPutL  STATGLOBALPUTL
#define statGlobalPutDP STATGLOBALPUTDP
#endif

#if defined(LOWERCASENOUNDER_SYS)
#define statBegin       statbegin
#define statEnd         statend
#define statGlobalPut   statglobalput
#define statGlobalPutL  statglobalputl
#define statGlobalPutDP statglobalputdp
#endif

#if defined(LOWERCASEUNDER_SYS)
#define statBegin       statbegin_
#define statEnd         statend_
#define statGlobalPut   statglobalput_
#define statGlobalPutL  statglobalputl_
#define statGlobalPutDP statglobalputdp_
#endif

SUBROUTINE statBegin(INT*);
SUBROUTINE statEnd(INT*);
SUBROUTINE statGlobalPut(INT*, INT*);
SUBROUTINE statGlobalPutL(INT*, LONGINTC*);
SUBROUTINE statGlobalPutDP(INT*, DOUBLE*);

