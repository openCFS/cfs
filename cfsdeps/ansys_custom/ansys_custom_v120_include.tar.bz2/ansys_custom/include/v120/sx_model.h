/* CADOE */
/**
 *	model.h -- constantes attachees aux objets modele
 *  
 * |Version: $Id: sx_model.h,v 1.2.6.1 2009/04/13 14:10:00 jtm Exp $
 *
 *   
 **/

#include "sx_CADOE_solver.h"
#include "C_CadoeException.h"
#ifndef __MODEL_X_DEJA_INCLUS__
#define __MODEL_X_DEJA_INCLUS__ 1


#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

  extern T_modele* MOD_creer_modele (T_statut*) throw(C_CadoeException);
  extern T_statut MOD_add_group( T_modele*, T_groupe * ) throw(C_CadoeException);
  extern T_statut MOD_add_propriete( T_modele*, int, T_propriete * ) throw(C_CadoeException);
  extern T_statut MOD_affecter_element_modele (T_modele *, int, T_element **);
  extern T_statut MOD_affecter_noeud_modele (T_modele *, int, T_noeud **);
  extern T_statut MOD_creer_tableau_noeud (T_modele *);
  extern T_statut MOD_transferer_modele_element (T_modele *, T_booleen);
  extern T_statut MOD_liberer_modele( T_modele** );
  extern void MOD_init_a_calculer( T_modele* );
  extern void MOD_set_on( T_modele*, E_resultat_parametre );
  extern void MOD_set_off( T_modele*, E_resultat_parametre );
  extern T_booleen MOD_is_on( T_modele*, E_resultat_parametre );
  extern T_booleen MOD_is_off( T_modele*, E_resultat_parametre );
  extern int MOD_checksum( T_modele* );
  extern T_booleen MOD_modele_modifie(void);
  extern T_statut MOD_eval_base_reference( const _TCHAR*, T_modele *, PAR*, PAR*, int, double *);
  extern T_statut MOD_liberer_base_reference( T_modele * );
  
  extern char* MOD_solverstr ( T_modele * );
  extern T_statut MOD_restore_g0( T_modele * );
  extern T_statut MOD_zero_g0( T_modele * );
  extern T_statut MOD_mise_a_jour( T_modele *, VEC *, T_booleen , T_booleen );
  
  extern T_statut DEM_liberer_der_modele( T_modele *modele, T_der_modele **der_modele);
  
#ifdef __cplusplus
}
#endif /* __cplusplus */

extern T_statut MOD_modif_nb_modes( T_modele*, int );
  extern T_statut MOD_write_cs( FILE*, T_modele* );
  extern T_statut MOD_write_groups( FILE*, T_modele* );
  extern T_statut MOD_write_properties( FILE*, T_modele* );
  extern T_statut MOD_write_elements( FILE*, T_modele* );
  extern T_statut MOD_write_nodes( FILE*, T_modele* );
  extern T_statut MOD_write_model( FILE*, T_modele* );
  extern T_statut MOD_write_bodies( FILE*, T_modele* );
  extern T_statut MOD_write_bc( FILE *, T_modele * );
  extern void* MOD_read_cs( FILE*, void**, T_statut* );
  extern void* MOD_read_groups( FILE*, void**, T_statut* );
  extern void* MOD_read_groups_elem( FILE*, void**, T_statut* );
  extern void* MOD_read_properties( FILE*, void**, T_statut* );
  extern void* MOD_read_nodes( FILE*, void**, T_statut* );
  extern void* MOD_read_elements( FILE*, void**, T_statut* );
  extern void* MOD_read_model( FILE*, void**, T_statut* );
  extern void* MOD_read_bodies( FILE*, void**, T_statut* );
  extern void* MOD_read_bc( FILE*, void**, T_statut* );


#endif	 /* __MODEL_X_DEJA_INCLUS__ */
