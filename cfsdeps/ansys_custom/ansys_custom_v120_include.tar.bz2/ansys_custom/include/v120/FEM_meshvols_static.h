/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 2009 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_meshvols_static.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_meshvols_static.h
 *  Prototypes and macros for FEM_meshvols.h
 *
 */

#ifndef FEM_MESHVOLS_STATIC_INCLUDE
#define FEM_MESHVOLS_STATIC_INCLUDE

/*---------------- Prototypes for static functions ---------------------------*/

static INT fem_mvClassifyModel          ( const INT *a_vols,
                                   const INT num_vols,
                                   const INT *a_vshapes,
                                   const INT *a_mids,
                                   FEM_BOOLEAN &no_vols,
                                   const INT stat_process );

static INT fem_mvClassifyShellModel     ( const INT *a_areas,
                                   const INT num_areas,
                                   const INT *a_ashapes,
                                   const INT *a_mids,  
                                   const INT stat_process );

static INT fem_mvSetKpProperties        ( void );

static INT fem_mvSetLineProperties      ( void );

static INT fem_mvSetAreaProperties      ( void );

static INT fem_mvClassifyKps            ( void );

static INT fem_mvClassifyLines          ( void );

static INT fem_mvClassifyAreas          ( void );

static INT fem_mvClassifyShellAreas     ( const INT *a_areas,
                                   const INT num_areas,
                                   const INT *a_ashapes,
                                   const INT *a_mids );

static INT fem_mvClassifyVols           ( const INT *a_vols,
                                   const INT num_vols,
                                   const INT *a_vshapes,
                                   const INT *a_mids );

static INT fem_mvAssignIntervals        ( void );


static INT fem_mvDoTrgLineSmoothing     ( void );

static INT fem_mvAdjustMidnodes         ( void );

static INT fem_mvDeleteMeshDataBelow    ( VOL_PTYP obj_vol );
static INT fem_mvMakeAreaMeshConsistent( void );
static INT fem_mvMarkKpsBySrcTrgInfo(void) ;
static INT fem_mvMeshSideAreas( INT &iNeedRemesh );
static INT fem_mvCleanSideAreasNeedRemesh();
static INT fem_mvMeshForcedMapAreas( void );
static INT fem_mvAlignNode( 
    NODE_OBJ obj_node0, 
    AREA_PTYP obj_area0, 
    LINE_PTYP obj_line0,
    INT refIdx );
static void fem_mvMidNodeAdjust(void);
static INT fem_mvAlignSideAreasByLine( void );
static INT fem_mvAlignLine( 
    AREA_PTYP obj_startArea,
    LINE_PTYP obj_line0,
    AREA_PTYP obj_area0 ) ;
static INT fem_mvEdgesRelation( 
    LINE_PTYP obj_line0, 
    LINE_PTYP obj_line,
    AREA_PTYP obj_area,
    INT &answer );
static void getNodeMaxEdgLen( 
	NODE_OBJ obj_node, 
	DOUBLE &avgLen );
static INT fem_mvAlignSrcNodes( void ) ;
static INT fem_mvClassifyToSideAreas( void );
static INT fem_mvQuickCheckSweepable( VOL_PTYP &obj_vol, FEM_BOOLEAN &bSweepable );
#endif
