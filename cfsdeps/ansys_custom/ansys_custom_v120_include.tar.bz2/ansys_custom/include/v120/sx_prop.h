/* CADOE */
/**
 *	propriete.h -- constantes attachees aux objets propriete
 *   
 **/

#include "sx_CADOE_solver.h"
#ifndef __PROP_X_DEJA_INCLUS__
#define __PROP_X_DEJA_INCLUS__ 1

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

extern T_statut PRO_creer_propriete (E_type_propriete, T_propriete **);
extern T_statut PRO_affecter_prop_elem (T_propriete *, T_prop_elem *);
extern T_statut PRO_rechercher_prop_elem (T_propriete *, int, T_prop_elem**);
extern T_statut PRO_rechercher_prop_elem_reelle (T_propriete *, int, double *);
extern T_statut PRO_rechercher_prop_elem_entier (T_propriete *, int, int *);
extern T_statut PRO_rechercher_prop_elem_vec (T_propriete *, int, VEC *);
extern int PRO_rechercher_prop_by_num( int numero, int type_propriete, T_modele *modele, int *ier  );
extern int PRO_rechercher_prop_mat_num (int, T_modele *,int *);
extern int PRO_rechercher_prop_phy_num (int, T_modele *,int *);
extern int PRO_rechercher_prop_load_num (int, T_modele *,int *);
extern int PRO_rechercher_prop_num_num (int, T_modele *,int *);
extern int PRO_rechercher_elements(T_propriete*, E_type_propriete, T_modele*, IVEC **);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif	 /* __PROP_X_DEJA_INCLUS__ */
