/**
 * @file   Sx_AnsysFast.h
 * @author Frederic Thevenon
 * @date   Wed May  5 14:56:21 2004
 * 
 * @brief  Class for Parameterization of Ansys with the Fast Method
 * 
 * 
 */

#ifndef __SX_ITFANSYS_H__
#define __SX_ITFANSYS_H__ 1

#include "cadoe.h"
#include "cadoe_set.h"
#include "SxSparseMso.h"
#include "sx_model.h"

/*********************************************************************************
 *! \class	C_ItfAnsys
 *  \brief	Ansys Class To Use with Parameterization.
 *  \author	
 *  \date	2004-2005
 *  \bug
 *  \warning
 *
 *  \version 0.9 :       Initial Revision ( Ansys 11.0)
 *  
 *  This defines communication methods to use in a parametric env.
 */

template <typename T> class C_ItfAnsys
{
public :
  
  virtual int	GetDebugScope(void) { return E_SCOPE_ITFPARAMFAST;}  
  virtual const char *Version() const		{ return "1.0";}
  
  C_ItfAnsys( void);
  virtual ~C_ItfAnsys();
  
  virtual int	Write( FILE *fb);
  virtual int	Read( FILE *fb);

  // ===== Boundary conditions - Mapping between dof spaces

  virtual int InitMapping( void);
  virtual int IndToNod( C_Vec<T> &VInd, C_Vec<T> &VNod, bool ApplyAllBC = false);

  virtual int NodToInd( VEC *VInd, C_Vec<T> &VNod);
  virtual int NodToInd( C_Vec<T> &VNod, C_Vec<T> &VInd);

  virtual int ZeroSuppressed( double *Vec);
  virtual int ZeroThirdNodeMPC184( double *Vec, int nbvec=1);

  virtual int InitListElem( void);

  virtual int GetLoadedDofs( void);
  virtual int AddNodesLinkedByCpCe( BVEC *_BvtmpNd, C_VecPi<int> *BcsAdr=NULL);

  // ===== I/O on Full File

  virtual int ReadMatrixFromFull( int idmat, char *matname, T_m_ooc *&Mat, double coef=1.,
				  bool InCore=false);
  virtual int ReadMatrixFromFull( int idmat, char *matname, T_mso *&Mat, double coef=1.,
				  bool InCore=false);

protected :
  
  T_modele	*_modele;	/**< Link to the FEM Model			*/
  
  int		_SolveMethod;	/**< Method To Solve Initial LS			*/
  int		_nbddl;		/**< Number of Dofs In the nodal space		*/
  int		_nbcs;		/**< Number of Dofs In the BCS space		*/
  
  int		_kelreq[10];	/**< Array to drive Ansys assemblies		*/
  
  C_VecP<T>	_VtmpDdl;	/**< Temp. Vector ( Size = _nbdll)	*/
  C_VecPi<T>	_VtmpBcs;	/**< Temp. Vector ( Size = _nbcs)	*/
  VEC		*_Fint;		/**< Temp. Vector for int. forces ( Size = _nbdll) */
  VEC		*_Fext;		/**< Temp. Vector for ext. forces ( Size = _nbdll) */

  BVEC		*_BvtmpBcs;	/**< Bits Temp. Vector ( Size = _nbcs)		*/
  BVEC		*_BvtmpNd;	/**< Bits Temp. Vector ( Size = nb_nodes)	*/
  BVEC		*_BvtmpEl;	/**< Bits Temp. Vector ( Size = nb_elements)	*/

  IVEC		*_IvtmpBcs;	/**< Int Temp. Vector ( Size = _nbcs)		*/
  IVEC		*_IvtmpBcs2;	/**< Int Temp. Vector ( Size = _nbcs)		*/
  IVEC		*_ListElem;	/**< Int Temp. Vector ( Size = nb_elements)	*/
  IVEC		*_ListElemStress;/**< Int Temp. Vector ( Size = nb_elements)	*/
  
  T_mso		*_MatK0;	/**< Initial K matrix				*/
  bool		_MatSym;	/**< Matrices are symmetrical ?			*/
  
  C_VecPi<int>	_FullToBcs;	/**< Mapping between Full (SPARSE) And BCS (Independent) Numbering 	*/
  C_VecPi<int>	_BcsToAns;	/**< Mapping between BCS and Ansys Numbering 	*/
  C_VecPi<int>	_AnsToBcs;	/**< Mapping between Ansys Numbering and BCS	*/
  C_VecPi<int>	_FullToAns;	/**< Mapping between Full Numbering and Ansys	*/

  IVEC		*_ListSupp;	/**< List of Suppressed Dofs			*/
  IVEC		*_ListPres;	/**< List of Prescribed Dofs			*/
  BVEC		*_bLoadedDofs;	/**< Array of loaded dofs			*/
};

#endif /* __SX_ITFANSYS_H__ */
