/**
 * @file   C_DMIGFile.h
 * @author  <ftheveno@LYOFTHEVENO8>
 * @date   Fri Sep 04 18:39:18 2009
 * 
 * @brief  Nastran DMIG File Interface Object
 * 
 * 
 */

#ifndef __C_DMIGFILE_H__
#define __C_DMIGFILE_H__	1

#include "C_MatMGe.h"
#include "C_DataFile.h"

/*!
 *  \class	C_DMIGFile
 *  \brief	
 *  \author	Frederic Thevenon
 *  \version	1.0
 *  \date	2009
 *  \bug	
 *  \warning	
 *
 *  version 1.0 :       Initial Revision
 */

class C_DMIGFile : public C_DataFile
{
public:

  C_DMIGFile( string &FileName, char Delim = ' ');
  virtual ~C_DMIGFile( void);

  C_Mat<double>	*getMat(void);  

  string	&getMatName( void) { return _MatName;}
  int		getNumNodes( void) { return _NodeDofList.size();}

  bool		MatSym( void) { return (_IFO == 6);}

  int		GetDofNumber( int NumNode, int NumComp);
  void		FillNodDofLists( C_VecPi<int> &NodByRow, C_VecPi<int> &DofByRow, C_VecPi<int> &NodesList);

protected:

  C_CadoeMessage	_MsgPublic;

  int			_iLine;
  int			FirstLine( void);
  int			NextLine( void);

  void			ReadNodesDofsList( void);
  
  char			_Delim;
  ifstream		_infile;
  char			_Line[4096], *_Str;
  string		_MatName;

  // =====		Header Data

  int			_IFO, _TIN, _TOUT, _POLAR, _NCOL;

  // =====		Matrix Data

  map< int, unsigned char>	_NodeDofList;
  map< int, int>		_NodeToRow;
  int				_NmRow;
};

#endif
