/*! \file CEvalTool.h

  \brief This header file defines the CEvalTool virtual class.

  \author Stephane MARGUERIN &copy; CADOE

  \date January 1st, 2002

  \version $Id: CEvalTool.h,v 1.1 2006/12/15 06:48:52 jtm Exp $
 */

#ifndef __CEvalTool_h__ 
#define __CEvalTool_h__ 1 

#include "CDesignSet.h"

class CEvalTool
{
 public:
  CEvalTool(){};
  virtual ~CEvalTool(){};
  virtual int evalDesignSet( CDesignSet &set ) {return 0;}
  virtual int calculerDesignSet( CDesignSet &set ) {return 0;}
};


#endif
