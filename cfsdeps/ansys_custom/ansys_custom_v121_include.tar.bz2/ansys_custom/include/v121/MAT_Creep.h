////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         Copyright (C) 2009 ANSYS Inc.  All Rights Reserved             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MAT_Creep.h $
// $Revision: 1.3 $ 7.0
// $Date: 2009/01/21 16:43:23 $ March 28 2002
// $Author: pkgodala $ rjayasee/jlo
//
// Decription :
//
//	This is the base class for all creep models.
//  This contains all the basic creep functions
////////////////////////////////////////////////////////////////////////////// 

#if !defined(MAT_Creep_H)
#define MAT_Creep_H

#include  "MAT_ConstitutiveFunction.h"

class MAT_Creep  : public MAT_ConstitutiveFunction
{
public:

	MAT_Creep();
    // Default Constructor.

	static MAT_Creep* Construct() { return NULL; } ;
    // Default Constructor.

    virtual bool GenerateMaterialParameters() ;
    // Function that Generates the Material Parameters given
    // some experimental data. Which is already supplied

    virtual bool GenerateMaterialParametersWithNRMethod() ;
    // Function that Generates the Material Parameters given
    // some experimental data. Which is already supplied

    virtual bool GenerateMaterialParametersWithLMMethod() ;
    // Function that Generates the Material Parameters given
    // some experimental data. Which is already supplied
    
    virtual bool CalculateFittedExperimentalDataPoint( ANS_String const& oExperimentType,
                                                       vector<MAT_CFAttribute*> const& oParamVector,
                                                       double& oCalculatedValue ) ;
    //R Status of Function
    //I oExperimentType
    //I-Type of Experiment
    //I oParamVector
    //I-Vector of Parameters
    //O oCalculateValue
    //O-Value of Fitted Data
    //- Calculated Fitted Data Given Input

    virtual bool CalculateFittedExperimentalDataPoint
                ( MAT_ExperimentalDataFormat* pEDFormat,
                  vector<double>& oPoint ) ;
    //R bool
    //R-false is such a point or an experiment does not exist
    //I pEDFormat
    //I-Experimental Data Format
    //I oPoint
    //I Calulated Value of Experiment Point
    //- Returns the Fitted Experimental Data Point

    virtual bool CalculateFittedExperimentalDataPoint
                (  INT iExpID,
                   INT iPointIndex,
                   vector<double>& oPoint ) ;
    //R bool
    //R-false is such a point or an experiment does not exist
    //I pEDFormat
    //I-Experimental Data Format
    //I oPoint
    //I Calulated Value of Experiment Point
    //- Returns the Fitted Experimental Data Point

    virtual bool CalculateResidual( double& dResidual ) ;
    //R bool
    //I dResidual
    //I- Residual
    //- Calculates Residual for the coefficients + given exp data

    virtual void Print() ;
    // Prints the constitutive function

    virtual ~MAT_Creep();
    //Destructor

    virtual bool FunctionValue ( double* pVariables, INT iNumVariables,
                         double* pInputVariables, INT iNumInputVariables,
                         double& dCreepStrain ) { return false ; } ;
    //R bool
    //I pVariable
    //I-Value of Coefficients
    //I iNumVariables               
    //I-Number of variables
    //I dInputVariables     
    //I- Input Variables
    //I iNumInputVariables
    //I-Num Input Variables
    //I dCreepStrain
    //I- Calculated Value of Creep Strain
    //- Calculates the value of creep strain given params and independent variable data
                              
    virtual bool FirstDerivativeOfUnsquaredError
         ( double* pVariables,INT iNumVariables,
           double* pInputVariables, INT iNumInputVariables,
           INT iVariableIndex, double& dResult ) { return false; };
    //I pVariable
    //I-Value of Coefficients
    //I iNumVariables
    //I- Number of variables
    //I dInputVariables
    //I-Input Variables
    //I iNumInputVariables
    //I-Num Input Variables
    //I iVariableIndex
    //I-Variable w.r.t which the derivative is to be calculated
    //I dResult
    //I-Calculated value of derivative
    //R- Calculates the value of the Creep Strain Rate 

    virtual bool Assemble1stDerivativeMatrix
        ( double* dCoeffs,
          INT iNumCoeffs,
          double** d1stDerMatrix ) { return false; };
    //R-Status of the function
    //I dCoeff                      
    //I-array of coefficients
    //I iNumCoeffs                  
    //I-Number of Coefficients
    //I d1stDerMatrix               
    //I-The Resulting Matrix of 1st Derivatives
    //-Assemble the RHS Matrix for the Newton-Raphson Loop

    virtual bool Assemble2ndDerivativeMatrix
    ( double* dCoeffs,
      INT iNumCoeffs,
      double** d2ndDerMatrix ) { return false; };
    //R-Status of the function
    //I dCoeff                      
    //I-array of coefficients
    //I iNumCoeffs                  
    //I-Number of Coefficients
    //I d1stDerMatrix               
    //I-The Resulting Matrix of 2nd Derivatives
    //-Assemble the RHS Matrix for the Newton-Raphson Loop

    virtual bool Residual
        ( double* dCoeffs,
          INT iNumCoeffs,
          double& dResidual ) ;
    //R-Status of the function
    //I dCoeff                      
    //I-array of coefficients
    //I iNumCoeffs                  
    //I-Number of Coefficients
    //I d1stDerMatrix               
    //I-The Resulting Residual
    //- Calculates the Residual given the coefficients

    virtual bool Assemble1stDerivativeMatrixAtAllPoints
        ( double* dCoeffs,
          INT iNumCoeffs,
          INT iNumPoints,
          double** d1stDerMatrix ) ;
    //R-Status of the function
    //I pDataSet
    //I-Collection of Experimental Data
    //I dCoeff                      
    //I-array of coefficients
    //I iNumCoeffs                  
    //I-Number of Coefficients
    //I iNumPoints
    //I-Number of points
    //I d1stDerMatrix               
    //I-The Resulting Matrix of 1st Derivatives
    //-Assemble the RHS Matrix 

    virtual bool ResidualAtAllPoints
        ( double* dCoeffs,
          INT iNumCoeffs,
          INT iNumPoints,
          double** dResidual ) ;
    //R-Status of the function
    //I dCoeff                      
    //I-array of coefficients
    //I iNumCoeffs                  
    //I-Number of Coefficients
    //I iNumPoints
    //I-Number of Points
    //I dResidual               
    //I-The Resulting Array Resisuals
    //-Assemble the Error Matrix  

    virtual void EliminateTemperatureCoefficients() { return; }
    //Elimnates Temperature term and fixes it.

    INT GetNumberOfCoeffs() const 
    {
        return this->m_oParameterData.Size() ;
    };
    //R INT
    //- Gets number of coefficients

protected:

    vector<ANS_String> m_oExperimentComponents ;
    // Format of Experimental Data Required for Solver


    double** m_pExperimentalDataCache ;
    int m_iNumRowExperimentalDataCache ;
    int m_iNumColExperimentalDataCache ;

    bool GetPointDataInSpecifiedFormat( MAT_ExperimentalData* pEData,
                                        ANS_Point const * pPoint,
                                        vector<ANS_String> oOutPutFormat,
                                        double* pResultData ) ;
    //R bool
    //R-If the operation was successful
    //I pEData
    //I-Experimental Data
    //I pPoint
    //I-Point Data from Experiment
    //I oOutPutFormat
    //I-Format of Data to be output
    //O oResultData
    //O-The Format of Result Dat
    //- This experiment extracts data from experiment in the form desired
    //- by the fitting solver.

    bool CreateExperimentalDataCache() ;
    //R void
    //- Creates a cache of Experimental Data for Solver

    void CleanUpExperimentalDataCache() ;
    //R void
    //- Cleans up cache of Experimental Data for Solver

} ;

typedef MAT_Creep*(*MAT_CreepConstructorFunction)()  ;

struct MAT_CreepConstructorEntry
{
    MAT_CreepConstructorFunction m_oFunctionPointer ;
    //Pointer to Creep Constructor

    ANS_String m_oNameOfClass ;
    //Name of the Creep Class
} ;

class MAT_CreepConstructorFactory 
{
    public:

    MAT_Creep* ConstructCreepModel( ANS_String oName ) ;
    //R Pointer to Creep Model
    //- Constructs any creep model based on string

    ~MAT_CreepConstructorFactory() ;
    static void Destroy() ;
    //Destructor

    bool RegisterCreepModel( ANS_String oName , MAT_CreepConstructorFunction oPtrToFn ) ;
    //R Status of function
    //
    //- Constructs any creep model based on string

    static MAT_CreepConstructorFactory* Instance() ;
    //I Pointer to Creep Factory
    //- Pointer to Singleton Instantiator


    private:

    static MAT_CreepConstructorFactory* m_pInstance ;
    //Pointer to only instance of this class

    vector<MAT_CreepConstructorEntry*> m_oCreepConstructorDatabase ;

    MAT_CreepConstructorFactory() ;
    //Default constructor

    void StaticInitialization() ;
    //Force static initialization of all derived Creep Classes
} ;

#endif // !defined(MAT_Creep_H)
