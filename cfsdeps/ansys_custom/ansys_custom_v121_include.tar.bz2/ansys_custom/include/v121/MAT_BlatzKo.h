////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         Copyright (C) 2009 ANSYS Inc.  All Rights Reserved             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MAT_BlatzKo.h $
// $Revision: 1.3 $ 7.0
// $Date: 2009/01/21 16:43:13 $ March 28 2002
// $Author: pkgodala $ rjayasee/jlo
//
// Decription :
//
//	This class captures the Material Model abstraction for the MooneyRivline
//  model
//////////////////////////////////////////////////////////////////////////////

#if !defined( MAT_BLATZKO_H )
#define MAT_BLATZKO_H


#include "MAT_ConstitutiveFunction.h"
#include "MAT_OgdenVolumetricMode.h"

// #include "MAT_ConstitutiveFunction.h"
class MAT_ExperimentalDataSet ;

class MAT_BlatzKo : public MAT_HyperElasticLinearFit
{

public:

    MAT_BlatzKo();
    //Constructor

    virtual bool GenerateMaterialParameters() ;
    //R-bool
    //F-Function that Generates the Material Parameters given
    //F-some experimental data

    bool AssembleLeastSquaresMatrix
            ( MAT_ExperimentalDataSet* pDataSet) ;
    //R-bool
    //I-pDataSet
    //I-Pointer to a ExpDataSet
    //F-Assemble the matrix to be solved for the parameters

    bool SolveLeastSquaresMatrix() ;
    //R-bool
    //R-false if det or zero. Or if the only av data is shear data.
    //F-Inverts the Matrix to solve for the parameters

    virtual bool CalculateFittedExperimentalDataPoint
                    ( double* pCoeffs,
                      INT iNumCoeffs,
                      ANS_String oExpName,
                      vector<double>& oPoint ) ;
    //R bool
    //R-false is such a point or an experiment does not exist
    //I oExpName
    //I-Experiment Name
    //I oPoint
    //I Calulated Value of Experiment Point
    //- Returns the Fitted Experimental Data Point

    virtual void Print() ;
    //F-Print

  	virtual ~MAT_BlatzKo();
    //F-Destructor

private:

    double** m_pLHSMatrix ;
    INT m_pNumRowsLHSMatrix ;
    INT m_pNumColsLHSMatrix ;

    double** m_pRHSMatrix ;
    INT m_pNumRowsRHSMatrix ;
    INT m_pNumColsRHSMatrix ;

    bool CalculateJPrime( MAT_ExperimentType iExpType, double dLambda1, double dLambda2, double dLambda3, double& dJ ) ;
    //R- Status of the function
    //I iExpType
    //I-Experiment Type
    //I dLambda1
    //I-Principal Stretch
    //I dLambda2
    //I-Principal Stretch
    //I dLambda3
    //I-Principal Stretch
    //O dJ
    //O Calculate Values
    //- Calculate J' in Error minimizing function

    bool FunctionValue( double* dVariables,
                        INT iNumVariables,
                        MAT_ExperimentType iExpType,
                        double dLambda1, 
                        double dLambda2, 
                        double dLambda3, 
                        double& dStressN ) ;
    //R bool
    //I dVariables
    //I-Input Coeffecients
    //I iNumVariables
    //I-Number of Coeffecients = 2
    //I dLambdaN
    //I-Stretch
    //I iExpType
    //I 1 for unia, 2 for biax, 3 for tension
    //- Calculate Stress given stretch and coeffs

};

#endif // !defined(MAT_BLATZKO_H)
