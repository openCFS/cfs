////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         Copyright (C) 2009 ANSYS Inc.  All Rights Reserved             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MAT_ICGeneralizedGarofalo.h $
// $Revision: 1.3 $ 7.0
// $Date: 2009/01/21 16:43:42 $ March 28 2002
// $Author: pkgodala $ rjayasee
//
// Decription :
//              This class implement Generalized Garofalo Implicit Creep Model
//
////////////////////////////////////////////////////////////////////////////// 

#if !defined(MAT_ICGeneralizedGarofalo_H)
#define MAT_ICGeneralizedGarofalo_H

#include  "MAT_ConstitutiveFunction.h"
#include  "MAT_Creep.h"

class MAT_ICGeneralizedGarofalo  : public MAT_Creep
{
public:

	MAT_ICGeneralizedGarofalo();
    // Default Constructor.

    static MAT_Creep* Construct() ;

    virtual bool FunctionValue( double* pVariables, INT iNumVariables,
                                double* pInputVariables, INT iNumInputVariables, double& dCreepStrainRate ) ;
    //I pVariable
    //I-Value of Coefficients
    //I iNumVariables
    //I- Number of variables
    //I dInputVariables
    //I-Input Variables
    //I iNumInputVariables
    //I-Num Input Variables
    //I dCreepStrainRate
    //I-Calculated Value of Creep Strain Rate
    //R- Calculates the value of the Creep Strain Rate 

    virtual bool FirstDerivativeOfUnsquaredError
                ( double* pVariables,INT iNumVariables,
                  double* pInputVariables, INT iNumInputVariables,
                  INT iVariableIndex, double& dResult ) ;
    //I pVariable
    //I-Value of Coefficients
    //I iNumVariables
    //I- Number of variables
    //I dInputVariables
    //I-Input Variables
    //I iNumInputVariables
    //I-Num Input Variables
    //I iVariableIndex
    //I-Variable w.r.t which the derivative is to be calculated
    //I dResult
    //I-Calculated value of derivative
    //R- Calculates the value of the Creep Strain Rate 
             
    
    virtual void Print() ;
    // Prints the constitutive function

    virtual void EliminateTemperatureCoefficients();
    //Eliminates Temperature term and fixes it.

    virtual ~MAT_ICGeneralizedGarofalo();
    //Destructor

protected:


} ;


class MAT_ICGeneralizedGarofaloFactory
{
    public:

    static MAT_ICGeneralizedGarofaloFactory* Instance() ;
    //I Pointer to Creep Factory
    //- Pointer to Singleton Instantiator

    static void Destroy() ;
    ~MAT_ICGeneralizedGarofaloFactory() ;
    // Destructor

    private:

    MAT_ICGeneralizedGarofaloFactory() ;
    // Constructor

    static MAT_ICGeneralizedGarofaloFactory* m_pInstance ;
    //Pointer to only instance of this class
} ;

#endif // !defined(MAT_ICGeneralizedGarofalo_H)
