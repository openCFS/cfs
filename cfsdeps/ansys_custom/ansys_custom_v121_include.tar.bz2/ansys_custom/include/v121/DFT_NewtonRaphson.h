////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         Copyright (C) 2009 ANSYS Inc.  All Rights Reserved             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: DFT_NewtonRaphson.h $
// $Revision: 1.3 $ 7.0
// $Date: 2009/01/21 16:40:26 $ March 28 2002
// $Author: pkgodala $ rjayasee/jlo
//
// Decription :
//
//	This class implements the Newton Raphson algorigthm. This can be used by
//  supplying function pointer that return the value of the function and its
//  derivative to an instance of this class.
//////////////////////////////////////////////////////////////////////////////

#if !defined( DFT_NEWTONRAPHSON_H )
#define DFT_NEWTONRAPHSON_H

#include "MAT_ConstitutiveFunction.h"

class DFT_NewtonRaphson
{

public:

    DFT_NewtonRaphson();
    //Constructor

    bool SetNormalEquationFunction
        ( bool (MAT_ConstitutiveFunction::*pNormalMatrixFunction) ( double*, INT , double** ) ) ;
    //R-false if input is invalid
    //- Set the Function that can calculate the normal equation matrix

    bool SetJacobianFunction
        ( bool (MAT_ConstitutiveFunction::*pJacobianMatrixFunction) ( double*, INT , double** ) ) ;
    //R-false if input is invalid
    //- Set the Function that can calculate the Jacobian matrix

    bool SetResidualFunction
        ( bool (MAT_ConstitutiveFunction::*pResidualFunction) ( double*, INT , double& ) ) ;
    //R-false if input is invalid
    //- Set the Function that can calculate the residual matrix

    bool SetTheToBeOptimisedObjectPointer( MAT_ConstitutiveFunction* pObjPtr ) ;
    //R result
    //I pObjPtr
    //I-Pointer to the object which will call the routines
    //- Sets the Object the Routines are to be operated on

    bool SolveByNRMethod
        ( double* dInitCoeffs,
          INT iNumCoeffs,
          double* pResCoeffs ) ;
    //R-Status of the function
    //I dInitCoeff
    //I-Initial Value of the Coeff supplied by the user
    //I-or by the MaterialModel defaults
    //I iNumCoeffs
    //I-Number of Coefficients
    //I dInitCoeff
    //I-The result after the newton raphson solution
    //- The solves for the coefficients by the Newton's Raphsons method



    bool SetNumberOfIterations( INT iNIter ) ;
    //R- Status
    //R  False id iNITer is not positive    
    //I  iNIter
    //I- Number of iterations
    //-  Sets the Number of Iterations
   

  	virtual ~DFT_NewtonRaphson();
    //F-Destructor

private:


    double** m_pD2FMatrix ;
    INT m_iNumRowsD2FMatrix ;
    INT m_iNumColsD2FMatrix ;

    double** m_pD1FMatrix ;
    INT m_iNumRowsD1FMatrix ;
    INT m_iNumColsD1FMatrix ;

    INT m_iNumIterations ;
    INT m_iCurIteration ;
    // Coefficients Used in the Iteration


    MAT_ConstitutiveFunction* m_pOptimizationObject ;

    bool (MAT_ConstitutiveFunction::*m_pNormalMatrixFunction) ( double*, INT , double** ) ;
    // Pointer to functions that can return the normal matrice

    bool (MAT_ConstitutiveFunction::*m_pJacobianMatrixFunction) ( double*, INT , double** ) ;
    // Pointer to functions that can return the normal matrice

    bool (MAT_ConstitutiveFunction::*m_pResidualFunction) ( double*, INT , double& ) ;
    // Pointer to functions that can return the normal matrice

    bool AssembleNormalEquationsMatrix
        ( double* dCoeffs,
          INT iNumCoeffs,
          double** d1stDerMatrix ) ;
    //R-Status of the function
    //I dCoeff                      
    //I-array of coefficients
    //I iNumCoeffs                  
    //I-Number of Coefficients
    //I d1stDerMatrix               
    //I-The Resulting Matrix of 1st Derivatives
    //-Assemble the RHS Matrix for the Newton-Raphson Loop

    bool AssembleJacobianMatrix
    ( double* dCoeffs,
      INT iNumCoeffs,
      double** d2ndDerMatrix ) ;
    //R-Status of the function
    //I dCoeff                      
    //I-array of coefficients
    //I iNumCoeffs                  
    //I-Number of Coefficients
    //I d1stDerMatrix               
    //I-The Resulting Matrix of 2nd Derivatives
    //-Assemble the RHS Matrix for the Newton-Raphson Loop

    bool Residual
    ( double* dCoeffs,
      INT iNumCoeffs,
      double& dResidual ) ;
    //R-Status of the function
    //I dCoeff                      
    //I-array of coefficients
    //I iNumCoeffs                  
    //I-Number of Coefficients
    //o dResidual               
    //o-The Residual given coefficients
    //I Returns a residual given the initial coefficients

    bool BackTracking
        ( double* dInitCoeffs,
          INT iNumCoeffs,
          double* pResCoeffs ) ;
    //R-Status of the function
    //I dInitCoeff
    //I-Initial Value of the Coeff supplied by the user
    //I-or by the MaterialModel defaults
    //I iNumCoeffs
    //I-Number of Coefficients
    //I dInitCoeff
    //I-The result after the substepping/backtracking

    bool BackTrackingBySteepestDescent
            ( double* pInitCoeffs,
              INT iNumCoeffs,
              double** dDerivativeMatrix,
              double** dFunctionColMatrix,
              double* pDeltaCoeffs ) ;
    //R-Status of the function
    //I dInitCoeff
    //I-Initial Value of the Coeff supplied by the user
    //I-or by the MaterialModel defaults
    //I iNumCoeffs
    //I-Number of Coefficients
    //I dDerivativeMatrix               
    //I-The Resulting Matrix of 2nd Derivatives
    //I dFunctionColMatrix               
    //I-The Resulting Matrix of 1st Derivatives
    //I dInitCoeff
    //I-The result after the substepping/backtracking by steepest descent method

};

#endif // !defined(DFT_NewtonRaphson_H)
