#ifndef _DDS_GLOBALS_H_
#define _DDS_GLOBALS_H_ 1

#include <stdio.h>

#include "cadoe.h"
#include "commun.h"
#include "computer.h" 
#include "C_CadoeTrace.h"

extern "C" bool G_printDofs;
extern "C" bool G_dumpMatrices;
extern "C" bool G_debugCornerMaker;
extern "C" bool G_debugPCG;
extern "C" bool G_debugGeometry;
extern "C" bool G_debugDSA;
extern "C" bool G_TimeManager;
extern "C" bool G_compareWithBoeing;
extern "C" bool G_compareWithSubStruct;
extern "C" bool G_debugContact;
extern "C" bool G_debugConnectivity;
extern "C" bool G_debugOrtho;
extern "C" int  G_nbPenaltyPairs;
extern "C" bool G_useEdges;
extern "C" bool G_addPenInCoarse;
extern "C" bool G_createCEs;

extern "C" void printDomain(int glSubNum);

extern "C" void cwTrackBegin(char *);
extern "C" void cwTrackEnd(char *);

class C_TraceDDS : public  C_Trace 
{
public:
  C_TraceDDS(const char *fct, const char *file, int line) : C_Trace(fct,file,line) 
  {
    cwTrackBegin((char*) fct);
    _fct = fct;
  }
  ~C_TraceDDS() 
  {
    cwTrackEnd((char*) _fct.c_str());
  }
  
protected:
  string _fct;
};

#undef CADOE_TRACE
#define CADOE_TRACE( x ) C_TraceDDS _trace( ( x ),__FILE__,__LINE__) 

#define allocadd(size) (size == 0 ? NULL : NEW_AD(size,char,"allocad",MUP,__FILE__,__LINE__))

#endif
