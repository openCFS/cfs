////////////////////////////////////////////////////////////////////////////
//                                                                        //
//          copyright(c) 2009 SAS IP, Inc.  All rights reserved.            //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: CParamRange.h $
// $Revision: 1.5 $Id: CParamRange.h,v 1.5 2009/01/21 16:38:12 pkgodala Exp $ $
// $Date: 2009/01/21 16:38:12 $
// $Author: pkgodala $
//
// Decription: CParamRange and CParamHistory classes
//
////////////////////////////////////////////////////////////////////////////
#ifndef __CParamRange_h__ 
#define __CParamRange_h__ 1 

#include "cadoe.h"
#include "C_CbfObject.h"

#define RANGE_INPUT 0 //defined at pre-processing time, =ET_USER for compatibility
#define RANGE_GEO_OUTPUT 1 //adogeom output or validated range, =ET_GEOMETRY
#define RANGE_MSH_OUTPUT 2 //adomesh output or validated range, =ET_MESH
#define RANGE_MHC_OUTPUT 5 //adomesh hypercube validated range,
#define RANGE_SLV_INPUT 6 //solver input range
#define RANGE_SEN_OUTPUT 3 //sensitivity solve output or validated range, =ET_SENSI_SOLVE
#define RANGE_PAR_OUTPUT 4 //parametric solve output or validated range, =ET_PARAM_SOLVE

#define NUMBER_OF_RANGES 7

#define RANGE_OUTPUT 99 //to be used at post-processing time

#ifndef NO_CADOE_NAMESPACE  
namespace Cadoe { 
#endif 

	class CParamRange : public C_CbfObject
	{
	public:
		//! parameter status
		typedef enum { 
			CPS_EMPTY =0, 
			CPS_VALIDATED,  // range processed and available for use
			CPS_TOPROCESS,  // range not processed yet
			CPS_DELETED     // range processed; param has been deleted
		} ParStatus;

		CParamRange() 
		{
			_type = RANGE_INPUT;
#ifdef _DEBUG
			_min = _ini = _max = -999999.;
#else
			_min = _ini = _max = 0.;
#endif
			_order=-10000; 
			_status=CPS_EMPTY; 
		}
		~CParamRange() {};
		CParamRange( const CParamRange &range ) { *this = range; }
		CParamRange& operator =( const CParamRange &range ) 
		{
			if ( this!= &range )
			{
				_type = range._type;
				_min = range._min;
				_ini = range._ini;
				_max = range._max;
				_order = range._order;
				_status = range._status;
			}
			return *this;
		}
		bool isEmpty( void ) const { return (_status==CPS_EMPTY); }
		bool isToProcess( void ) const { return (_status==CPS_TOPROCESS); }
		bool isValidated( void ) const { return (_status==CPS_VALIDATED); }
		bool isDeleted( void ) const { return (_status==CPS_DELETED); }

		void setType(int type) { _type=type; }
		int getType() { return _type; }
		void setInitial(double ini) { _ini=ini; }
		double getInitial() const { return _ini; }
		void setMinimum(double min) { _min=min; }
		double getMinimum() const { return _min; }
		void setMaximum(double max) { _max=max; }
		double getMaximum() const { return _max; }
		void setDerivationOrder(int order) { _order=order; }
		int getDerivationOrder() const { return _order; } 
		void setStatus(ParStatus status) { _status=status; }
		ParStatus getStatus() const { return _status; }

		// implementation of teh C_CbfObject interface
		virtual const char * Version() const { return (const char *)"1"; }
		virtual int VersionInt() const { return 1; }
		virtual int Write( FILE *f );
		virtual int Read( FILE *f );

	private:    
		int _type;
		double _min;
		double _ini;
		double _max;
		int _order;
		ParStatus _status;
	};

	class CParamHistory : public C_CbfObject
	{
	public:
		CParamHistory()
		{      
			_current = 0;
			for( int i=0 ; i<NumRanges(); i++ )
				_ranges[i].setType(i);
			_output = RANGE_INPUT;
		}
		CParamHistory( const CParamHistory &ph ) { *this = ph; }
		~CParamHistory(){};  

		CParamHistory& operator = ( const CParamHistory &ph )
		{
			if ( this!= &ph )
			{
				_current = ph._current;
				for ( int i=0 ; i<NumRanges() ; i++ )
					_ranges[i] = ph._ranges[i];
				_output = ph._output;
			}
			return *this;
		}

		int NumRanges() const { return NUMBER_OF_RANGES; }
		void SetCurrent( int range ) { _current = range; }
		int GetCurrent() const { return _current; } 

		const CParamRange & operator [] ( int range ) const
		{
			if ( range==RANGE_OUTPUT )
				return _ranges[_output];
			else
				return _ranges[range];
		}

		CParamRange & findRange( int range )
		{
			if ( range==RANGE_OUTPUT )
				return _ranges[_output];
			else
				return _ranges[range];
		}

		void setInitial( double ini, int rangename ) {findRange(rangename).setInitial(ini); SetCurrent(rangename);DetermineRangeOutput();}
		void setMinimum( double min, int rangename ) {findRange(rangename).setMinimum(min); SetCurrent(rangename);DetermineRangeOutput();}
		void setMaximum( double max, int rangename ) {findRange(rangename).setMaximum(max); SetCurrent(rangename);DetermineRangeOutput();}
		void setStatus( CParamRange::ParStatus sta, int rangename ) {findRange(rangename).setStatus(sta); SetCurrent(rangename);DetermineRangeOutput();}
		void setDerivationOrder( int order, int rangename ) {findRange(rangename).setDerivationOrder(order); SetCurrent(rangename);DetermineRangeOutput();}

		// implementation of the C_CbfObject interface
		virtual const char * Version() const { return (const char *)"1"; }
		virtual int VersionInt() const { return 1; }
		virtual int Write( FILE *f );
		virtual int Read( FILE *f );

	private:
		void			DetermineRangeOutput();	

		int				_current;
		CParamRange		_ranges[NUMBER_OF_RANGES];
		int				_output; // code of the range used for output. Can use _ranges[_output].
	};

#ifndef NO_CADOE_NAMESPACE 
} //namespace Cadoe 
using namespace Cadoe;
#endif 

#endif
