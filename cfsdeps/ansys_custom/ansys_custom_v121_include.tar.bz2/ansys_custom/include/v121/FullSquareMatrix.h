#ifndef	_FULLSQUAREMATRIX_H_
#define	_FULLSQUAREMATRIX_H_

#include <stdio.h>

class FSFullMatrix;

class FullSquareMatrix {

protected:
	
	int	size;
	double*	value;

public:
    FullSquareMatrix(int i, double *l=0)
        { size = i; value = l ? l : new double [size*size]; }

	FullSquareMatrix() { size = 0; value = 0; }
	
    void setSize(int i) 
	{ if(value) delete [] value; size = i; value = new double [size*size];}
	double *operator[] (int row);
    int dim() { return size; }
	void zero();
    double* data() { return value; }

 
  
    void WriteMatlab(FILE *fp);
};

inline
double *
FullSquareMatrix::operator[](int row)
 { return value+size*row; }

class FSFullSquareAssmblMat : public FullSquareMatrix {
    int *dMap;
  public:
    FSFullSquareAssmblMat(int size, int *maps);
    void add(FullSquareMatrix &, int *dofs);
    void add(FSFullMatrix &, int *dofs); 
    void Copy(FSFullSquareAssmblMat &);
};

#endif
