////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         Copyright (C) 2009 ANSYS Inc.  All Rights Reserved             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MAT_MaterialRecord.h $
// $Revision: 1.3 $ 7.0
// $Date: 2009/01/21 16:43:52 $ October 21 2003
// $Author: pkgodala $ rjayasee
//
// Description :
//          Material Record Used to query/write  Element/Material Data
////////////////////////////////////////////////////////////////////////////

#if !defined(MAT_MaterialRecord_H)
#define MAT_MaterialRecord_H

#include "ANS_Allocator.h"
#include "MAT_MemoryManager.h"

class MAT_IntegrationPointRecord ;
class MAT_DataRecord ;

typedef ANS_Allocator<MAT_IntegrationPointRecord* > MAT_IntegrationPointRecordPtrAllocator ;
typedef vector<MAT_IntegrationPointRecord*, ANS_Allocator<MAT_IntegrationPointRecord* > > MAT_IntegrationPointRecordVector ;

class MAT_MaterialRecord
{
    public:

    inline void * operator new(size_t iMemSize )
    {
            return MAT_MALLOC(iMemSize) ;
    }

    inline void * operator new[]( size_t iSize )
    {
            return MAT_MALLOC(sizeof(MAT_MaterialRecord)*iSize) ;
    }

    inline void operator delete(void * pMemPtr)
    {
            MAT_FREE(pMemPtr) ;
    }

    inline void operator delete[](void * pMemPtr )
    {
        MAT_FREE(pMemPtr) ;
    }

    MAT_MaterialRecord() ;
    //Constructor

    ~MAT_MaterialRecord() ;
    //Destructor

    void CleanUp() ;
    //Cleans up all integration point data

    bool CreateCache( LONGINTC* pESavLoc, INT* pSvIdxNew, INT* pInitialStrainFlag,
                      bool bReadFromDatabase ) ;
    //R status
    //I pESaveLoc
    //I pSvIdxNew
    //I pInitialStrainFlag
    //I bReadFromDatabase
    //I-Flag to set whether to read from database or just initialize to zero
    //I-false just initializes to zero
    //- Creates Cache

    bool WriteCacheToDatabase( LONGINTC* pESavLoc, INT* pSVIdxNew ) ;
    //R Status
    //I pESaveLoc
    //I pSVIdxNew
    //- Writes Cache to Database

    bool AddIntegrationPointRecord( INT iIntegrationPoint,
                                    MAT_IntegrationPointRecord* pIntegrationPointRecord );
    //R Status of the Function
    //I iIntegrationPoint
    //I-Integration Point Number
    //I pIntegrationPointRecord
    //I-Integration Point Record 
    //- Function Adds Integration Point Object for an Element

    bool GetIntegrationPointRecord( INT iIntegrationPoint,
                                    MAT_IntegrationPointRecord*& pIntegrationPointRecord );
    //R Status of the Function
    //I iIntegrationPoint
    //I-Integration Point Number
    //O pIntegrationPointRecord
    //O-Integration Point Record extracted from Element Record
    //- Function Extracts Integration Point for an Element at an Integration Point

    bool GetNthIntegrationPointRecord( INT iRecordIndex, MAT_IntegrationPointRecord*& pIntegrationPointRecord ) ;
    //R result
    //I iRecordIndex
    //I-Type of Record Being Queried
    //O pIntegrationPointRecord
    //O-Integration Point Record extracted from Element Record
    //- Get a Nth Integration Point Record 

    INT GetNumberOfRecords()
    {
        return m_pIntegrationPointRecordVector.size() ;
    }
    //R INT
    //- Gets Number of Records

    void Print() ;
    //R void
    //- Prints Data Stored

    INT m_iElementNumber ;
    //Element Number

    DOUBLE* m_pCachedMaterialData ;
    //Raw Data Queries from Database

    DOUBLE* m_pCachedMaterialDataBackup ;
    //Raw Data Queries from Database

    INT m_iSizeOfCachedMaterialData ;
    //Size of Cached Material Data

    MAT_IntegrationPointRecordVector m_pIntegrationPointRecordVector ;
    //Integration Point Record Map

    void* m_pDataRecTotArray ;
    //Memory for m_pAllDataRecordPtrArray and m_pAllDoubleDataForDataRecord
    
    MAT_DataRecord* m_pAllDataRecords ;
    INT m_iNumAllDataRecords ;
    MAT_DataRecord** m_pAllDataRecordPtrArray ;

    MAT_IntegrationPointRecord* m_pAllIPRecords ;
    INT m_iNumAllIPRecords ;

    DOUBLE* m_pAllDoubleDataForDataRecord ;
    INT m_piNumllDoubleDataForDataRecord ;
    
    INT* m_pElmCharacteristics ;
    LONGINTC* m_pnlkword ;

};

#endif

