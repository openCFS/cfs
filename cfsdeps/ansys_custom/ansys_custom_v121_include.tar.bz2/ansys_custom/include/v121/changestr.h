/***********************************************************************\
 *                                                                     *
 *  changeStr.h       March 6, 1995                                    *
 *                                                                     *
 *  Header file for changeStr.c                                        *
 *                                                                     *
\***********************************************************************/
/* 
 * *** copyright(c) 2009 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */

 //  Prototypes  //

BOOL changeStr ( CHAR [], CHAR [], CHAR [] );
