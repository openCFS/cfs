////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         Copyright (C) 2009 ANSYS Inc.  All Rights Reserved             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MAT_Yeoh.h $
// $Revision: 1.3 $ 7.0
// $Date: 2009/01/21 16:44:18 $ March 28 2002
// $Author: pkgodala $ rjayasee/jlo
//
// Decription :
//
//	This class captures the Material Model abstraction for the
//  Polynomial model for Hyperelastic Materials
//////////////////////////////////////////////////////////////////////////////

#if !defined( MAT_YEOH_H )
#define MAT_YEOH_H


#include "MAT_HyperElasticLinearFit.h"
#include "MAT_OgdenVolumetricMode.h"


class MAT_ExperimentalDataSet ;

class MAT_Yeoh : public MAT_HyperElasticLinearFit
{

public:

    MAT_Yeoh();
    //Constructor

    bool SetPolynomialOrder( INT iOrder ) ;
    //R-bool
    //I-True if > 0
    //I-iOrder
    //I-Order of the Polynomial
    //I-Sets the Order of the Polynomial

     virtual INT GetNumberOfCoeffs() ;
    //R-bool
    //I-iOrder
    //I-Number of Coeffs
    //F-Set the Number of Coeffs
    //F-This is calculated from the polynomial order

    virtual bool GenerateMaterialParameters() ;
    //R-bool
    //F-Function that Generates the Material Parameters given
    //F-some experimental data

    virtual bool FillLHSAndRHSMatrix( ANS_String const& oExpName, ANS_Point const* pPoint,
                                       double** pLHSMatrix, double** pRHSMatrix ) ;
     //R bool
     //I pExpName
     //I-Experiment Name
     //I pPoint
     //I Data Point
     //O pLHSMatrix
     //O LHS Matrix
     //O pRHS Matrix
     //O RHS Matrix
     //- Fills up LHS and RHS Matrix for a given point/experimental data

    virtual bool CalculateFittedExperimentalDataPoint
                    ( double* pCoeffs,
                      INT iNumCoeffs,
                      ANS_String oExpName,
                      vector<double>& oPoint ) ;
    //R bool
    //R-false is such a point or an experiment does not exist
    //I pCoeffs
    //I-Coefficient Values
    //I iNumCoeffs
    //I-Number of Coefficients
    //I oExpName
    //I-Experiment Name
    //I oPoint
    //I Calulated Value of Experiment Point
    //- Returns the Fitted Experimental Data Point

     virtual void SetTemperatureFilterSolveFlag( bool bFlag ) 
     {
         MAT_ConstitutiveFunction::SetTemperatureFilterSolveFlag(bFlag) ;
         m_oVolumetricMode.SetTemperatureFilterSolveFlag(bFlag) ;
     }
     //R status
     //I bFlag
     //- This flag sets the Temperature Filter Solve on

     virtual void SetReferenceTemperature( double dTRef ) 
     {
         MAT_ConstitutiveFunction::SetReferenceTemperature(dTRef) ;
         m_oVolumetricMode.SetReferenceTemperature(dTRef) ;
     }

    virtual bool DeleteCoefficients( MAT_FieldVariableCollection const& oField  ) ;
    //R bool
    //I oField
    //I-Field Variable
    //- Removes/Deletes the Variable Independent coefficients at a particular temp/...

    virtual void Print() ;
    //F-Print

  	virtual ~MAT_Yeoh();
    //F-Destructor

protected:

    INT m_iOrder ;
    //Order of the Polynomial


    MAT_OgdenVolumetricMode m_oVolumetricMode ;
    // Volumetric Mode for Polynomial which is same as ogden


    // Helper function for Uniaxial Data
    static double FunctionIIJUniaxial( INT iI, INT iJ, double iLambda) ;
    //R double
    //R-Function to return Iij given i,j and iLambda

    static double FunctionAUniaxial( double iLambda ) ;
    //R double
    //I-iLambda
    //I-
    //I-Helper function for assembling the Matrix for uniaxial loading

    // Helper function for Biaxial Tension Data
    static double FunctionIIJBiaxial( INT iI, INT iJ, double iLambda) ;
    //R double
    //R-Function to return Iij given i,j and iLambda

    static double FunctionABiaxial( double iLambda ) ;
    //R double
    //I-iLambda
    //I-
    //I-Helper function for assembling the Matrix for uniaxial loading

    // Helper function for Pure Shear Data
    static double FunctionIIJPureShear( INT iI, INT iJ, double iLambda) ;
    //R double
    //R-Function to return Iij given i,j and iLambda

    static double FunctionAPureShear( double iLambda ) ;
    //R double
    //I-iLambda
    //I-
    //I-Helper function for assembling the Matrix for uniaxial loading

    // Helper function for Shear Data SimpleShear Stress
    static double FunctionIIJSimpleShearSS( INT iI, INT iJ, double iLambda) ;
    //R double
    //R-Function to return Iij given i,j and iLambda

    static double FunctionASimpleShearSS( double iLambda ) ;
    //R double
    //I-iLambda
    //I-
    //I-Helper function for assembling the Matrix for Shear Data SimpleShear Stress 

    // Helper function for  Shear Data SimpleShear Transverse Stress
    static double FunctionIIJSimpleShearTS( INT iI, INT iJ, double iLambda) ;
    //R double
    //R-Function to return Iij given i,j and iLambda

    static double FunctionASimpleShearTS( double iLambda ) ;
    //R double
    //I-iLambda
    //I-
    //I-Helper function for assembling the Matrix for Simple Shear Transverse Stress
};


class MAT_NeoHookean:public MAT_HyperElasticLinearFit
{
    public:

    MAT_NeoHookean();
    //Constructor

  	virtual ~MAT_NeoHookean();
    //F-Destructor
    
    virtual void Print() ;
    //- Print Command

     virtual INT GetNumberOfCoeffs() ;
    //R-bool
    //I-iOrder
    //I-Number of Coeffs
    //F-Set the Number of Coeffs
    //F-This is calculated from the polynomial order

    virtual bool GenerateMaterialParameters() ;
    //R-bool
    //F-Function that Generates the Material Parameters given
    //F-some experimental data

    virtual bool CalculateFittedExperimentalDataPoint
                    ( double* pCoeffs,
                      INT iNumCoeffs,
                      ANS_String oExpName,
                      vector<double>& oPoint ) ;
    //R bool
    //R-false is such a point or an experiment does not exist
    //I pCoeffs
    //I-Coefficient Values
    //I iNumCoeffs
    //I-Number of Coefficients
    //I oExpName
    //I-Experiment Name
    //I oPoint
    //I Calulated Value of Experiment Point
    //- Returns the Fitted Experimental Data Point
    
     virtual void SetTemperatureFilterSolveFlag( bool bFlag ) 
     {
         MAT_ConstitutiveFunction::SetTemperatureFilterSolveFlag(bFlag) ;
         m_pYeohOrder1->SetTemperatureFilterSolveFlag(bFlag) ;
     }
     //R status
     //I bFlag
     //- This flag sets the Temperature Filter Solve on

     virtual void SetReferenceTemperature( double dTRef ) 
     {
         MAT_ConstitutiveFunction::SetReferenceTemperature(dTRef) ;
         m_pYeohOrder1->SetReferenceTemperature(dTRef) ;
     }

     virtual bool DeleteCoefficients( MAT_FieldVariableCollection const& oField  ) ;
     //R bool
     //I oField
     //I-Field Variable
     //- Removes/Deletes the Variable Independent coefficients at a particular temp/...

    protected:
    MAT_Yeoh* m_pYeohOrder1 ;
};

#endif // !defined(MAT_Yeoh_H)
