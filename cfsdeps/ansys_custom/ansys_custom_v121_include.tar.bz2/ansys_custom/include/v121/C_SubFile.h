/**
 * @file   C_SubFile.h
 * @author 
 * @date   Thu Apr 10 16:44:40 2008
 * 
 * @brief  
 * 
 */

#ifndef __C_SUBFILE_H__
#define __C_SUBFILE_H__	1

#include "C_AnsysFile.h"
#include "C_MatMGe.h"

/*!
 *  \class	C_SubFile
 *  \brief	
 *  \author	Frederic Thevenon
 *  \version	1.0
 *  \date	2008
 *  \bug	
 *  \warning	
 *
 *  version 1.0 :       Initial Revision
 */

// ======================================================================
// ===== BLOCKS OF THE SUB FILE

//	SUB_HEADER
//	SUB_XFM
//	SUB_CTXM
//	SUB_DOF
//	SUB_DST
//	SUB_POS
//	SUB_ORG
//	SUB_BAC
//	SUB_TIT
//	SUB_NOD
//	SUB_XYZ
//	SUB_EDG
//	SUB_GDF
//	SUB_CG
//	SUB_LOD

class C_SubFile : public C_AnsysFile
{
public:
  C_SubFile( const _TCHAR *FileName, bool Create = false);
  ~C_SubFile(void) {};

  int	SubHeader(int ival) { return _SubHead[ival];}
  bool	SparseMatrix( void) { return _SparseMatrices;}
  
  bool MatrixIsOnFile( int numMat);

  C_Mat<double>	*getMat( int numMat);
  void		setMat( int numMat, C_Mat<double> &Mat);

  virtual void	WriteFile( _TCHAR *FileName);

  void	newFile( string &FileName, int units, int nmat, int nrow, int nfor, 
		    int nnod, int kuns, int thsubs, int dimkey, C_VecPi<int> &nodes, C_VecPi<int> &direct,
		    C_Mat<double> *StiffM, C_Mat<double> *MassM, C_Mat<double> *DampM, C_Mat<double> *StressM,
		    C_Mat<double> *Loads, C_VecPi<int> &nodlst, C_MatMGe<double> &xyzang, C_VecPi<double> &masscg);
  
protected:
  C_VecPi<int>	_SubHead;
  bool		_SparseMatrices;
  int		_nmatrx;
};

#endif
