#ifndef __C_SXCOMMANDMGR_H__
#define __C_SXCOMMANDMGR_H__ 1

#include "cadoe.h"
#include "cadoe_list.h"
#include "cadoe_map.h"
#include "cadoe_vector.h"

#include "C_SxCommand.h"

// ---------------------------------------------------------------------------
class C_SxCommandMgr
// ---------------------------------------------------------------------------
{
public:
  C_SxCommandMgr();
  virtual ~C_SxCommandMgr();

  virtual void Init(void);
  virtual void Clear(void);

  virtual int CheckForAddition( const C_SxVariable &cmd, bool &found, bool bCheckDuplicate=false, 
				E_EntyDefTypes iEntyDefType=EDT_NONE, int iNumEnty=0, int *iEntyList=NULL ) const;

  // add the command pointer to the manager's list. If the command already exists, it is updated.
  virtual int AddCommand( C_SxCommand* );  

  // remove a command from the manager's list
  virtual int DeleteCommand( const C_SxCommand* );
  virtual int DeleteCommand( const string &name );

  // remove all commands of the type "iVarType"
  virtual int DeleteCommands( E_VarTypes iVarType );

  // get the number of commands, all of them by default or only the one of a given category
  virtual int GetNumCommands( E_CmdCategory cat=E_CMDCAT_NONE ) const;

  // get the number of commands of a given type
  virtual int GetNumCommands( E_VarTypes iVarType ) const;

  // get the number of defined and active commands of a given type
  virtual int GetNumActiveCommands( E_VarTypes iVarType ) const;

  // returns true if the command "name" exists
  virtual bool CommandExists( const string &name ) const;

  // retrieve the pointer to a command by its name
  virtual C_SxCommand* GetCommand( const string &name ) const;
  // retrieve the pointer to the "index"th command of the variable type "iVarType"
  virtual C_SxCommand* GetCommand( E_VarTypes iVarType, int index=0 ) const;
  // retrieve the pointer to the "index"th command of the category "cat"
  virtual C_SxCommand* GetCommand( E_CmdCategory cat, int index=0 ) const;

  // loop over the command list. Return false at the end of the list
  virtual C_SxCommand* GetFirstCommand( void );
  virtual C_SxCommand* GetNextCommand( void );

  virtual C_SxCommand* GetFirstCommand( E_VarTypes iVarType );
  virtual C_SxCommand* GetNextCommand( E_VarTypes iVarType );

  virtual C_SxCommand* GetFirstCommand( E_CmdCategory cat );    
  virtual C_SxCommand* GetNextCommand( E_CmdCategory cat );

  /*-----------------------------------------------------------------
    Purpose:
    Check the list of entities (nodes or elements) if they have been 
    used in another existing command.
    For the PADE approximation we have to check:
    - NO element can be affected by more than one variable type
    no matter what the variable type is
	
    For the TAYLor approximation we have to check:
    - NO element can be affected by a discrete variable SXDISC
    and any other variable type
    -----------------------------------------------------------------*/
  virtual int CheckDuplicateEntities( const C_SxVariable &curVar, E_EntyDefTypes iEntyDefType, int iNumEnty, int *iEntyList ) const;	
  // check all of the existing commands against duplicated entities
  virtual int CheckAllDuplicateEntities ( bool &duplicate ) const;

  // create a command using the correct derived class based on the E_VarTypes information.
  // this command is not added ino the CommandMgr list
  virtual C_SxCommand* CreateCommand( E_VarTypes iVarType, int &iError ) const;

  // print informations about all input or output variables command of the type "iVarType"
  virtual int PrintVariables( E_VarTypes iVarType, E_PrintKeys iPrintElemKey=PRINT_NO );
  // print informations about all of the defined commands
  virtual int PrintCommands( E_PrintKeys iPrintEntyKey=PRINT_NO );

  // clear data
  virtual int ClearData( int iType, E_PrintKeys iPrintKey=PRINT_NO );

  // Sx Module Entered flag
  virtual void SetSxEntered( bool SxEntered=true ) { _bSxEntered = SxEntered; }
  virtual bool SxEntered(void) const { return _bSxEntered; }

  // Solve Status flag
  virtual void SetSolveDone( bool SolveDone=true ) { _bSolveDone = SolveDone; }
  virtual bool SolveDone(void) const { return _bSolveDone; }

  // Current Job Name
  virtual void SetJobName( const string &jobname ) { _sJobName = jobname; }
  virtual string GetJobName( void ) const { return _sJobName; }
  virtual const char * GetJobNameCstr( void ) const { return _sJobName.c_str(); }

  // Get the current RSX filename (from SXRFIL or Jobname by default)
  virtual void  GetRsxPathName( char *rsxPathName ) const;

  // Helper methods to get directly the current SXMETH data
  virtual void GetMethApprType( E_SXMETH_ApprTypes &type ) const;
  virtual void GetMethSolutionType( E_SXMETH_SoluTypes &type ) const;
  virtual void GetMethTrackType( E_SXMETH_TrackTypes &type ) const;

 protected:
  bool		_bSxEntered;
  bool		_bSolveDone;
  string 	_sJobName;
  list<C_SxCommand*>		_commandsList; // chronological list of pointers to the commands
  map<string,C_SxCommand*>	_commandsMap; // command name, command pointer
  vector<int>			_numByVarType; // num of commands by E_VarTypes
  list<C_SxCommand*>::iterator  _it;
};

// declaration of the global and unique SX Commands Manager instance
extern C_SxCommandMgr *g_CommandMgr;


#endif
