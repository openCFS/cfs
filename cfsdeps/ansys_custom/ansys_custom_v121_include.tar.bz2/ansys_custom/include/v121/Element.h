#ifndef	_ELEMENT_H_
#define	_ELEMENT_H_
#include <stdio.h>

#include "BlockAlloc.h"
#include "elempr.h"

class DofSetArray;
class Connectivity;
class MultiFront;
class Smooth;
class BlockAlloc;

//****************************************************************
//*
//*     class Node: Keeps the coordinates of a node
//*
//****************************************************************

class Node {
  public:
	// Constructors
        Node() {}
        Node(double *xyz) { x = xyz[0]; y = xyz[1]; z = xyz[2]; }

	// Coordinates 
	double 	x;
	double 	y;
	double 	z;
};

// ****************************************************************
// *                        WARNING                               *
// *       Nodes in the CoordSet are from 0 and not from 1        *
// *       It is a good idea to subtract 1 from node input        *
// *       from the user at any time a node is read in rather     *
// *       then keeping it from 1 and then subtracting 1 here     *
// *       and there....                                          *
// *       functions for this class are in Element.d/Coordset.C   *
// ****************************************************************

class CoordSet {
        INT nmax;
	Node **nodes;
        BlockAlloc ba;
public:
        // Constructors
        CoordSet(INT = 256);
	CoordSet(const CoordSet&, INT n, INT *nd);

	// Member functions
        INT   size() { return nmax ; }
        void  nodeadd(INT n, double*xyz);
	Node &getNode(INT);

        Node *operator[] (INT i) { return (i < nmax) ? nodes[i] : 0; }

        void deleteNodes() { delete [] nodes; }

        INT getFromAnsys(INT);
};

// ****************************************************************
// * Class Element defines functions for finite elements.         *
// * Each element has a structural property and a pressure        *
// * associated with it. Each element defines it's own dofs, sets *
// * it's own node numbers, calculates stiffness, calculates mass *
// * von mises stress, INTernal force and displacements. Where    *
// * these functions are written for each type of element and if  *
// * a function is not defined for an element type, it will       *
// * default to the appropriate function in Element.C             *  
// * i.e. an element with a zero mass matrix, will just return a  *
// * matrix of the appropriate size containing zeroes.            *
// ****************************************************************
struct PrioInfo {
   INT isReady; // wether this element is ready to be inserted
   INT priority; // the level of priority (undefined in isReady == 0)
};

class Element {
  public:
	Element() {}

        virtual Element *clone() { return 0; }
        virtual void renum(INT *)=0;

        static Element *build(INT,INT,INT*);

	virtual INT    numNodes() = 0;
	virtual INT*   nodes(INT * = 0) = 0;
        virtual float  weight() = 0;

	virtual INT    numNodesAll() = 0;
	virtual INT*   nodesAll(INT * = 0) = 0;

	virtual INT  getTopNumber();

        virtual void dumpTop(FILE *outFile)=0;
        virtual void evEdge(FILE *f, Connectivity*, INT*, INT*, INT*, INT)=0;
        virtual void evFace(FILE *f, INT*, INT*, INT)=0;
        virtual void evBody(FILE *outFile, INT*)=0;

        // Routines for the decomposer
        virtual PrioInfo examine(INT sub, MultiFront *)
                        { PrioInfo ret; ret.isReady = false; return ret; };
        virtual PrioInfo examine2(INT sub, Smooth *)
                        { PrioInfo ret; ret.isReady = false; return ret; };
        // isStart indicates if an element is suitable to
        // be a germination center for a subdomain (bars are not)
        virtual bool isStart() { return true; }

        // CG function
        void getCG(CoordSet &, double &xcg, double &ycg, double &zcg);

        virtual bool hasRot() { return false; }

        // dynamic_cast operator doesn't work on RS6000. Create this
        // virtual function to avoid the need of operation at AnsysDec.cpp
#if defined (RS6000_SYS) || (PCWINNT_SYS)
	virtual INT origNum() = 0;
#endif
	friend class Domain;
};

//*****************************************************************
//*                        WARNING                                *
//*       The same remark as for node is valid for elements       *
//*       The functions for this class are in Element.d/ElemSet.C *
//*****************************************************************

class Elemset {
    INT nType;
  protected:
    Element **elem;
    INT emax;
    BlockAlloc ba;
    INT *mark;
    INT marksize;
    INT markRealsize;
    Connectivity *disCntEtoN;
  public:
    Elemset(INT = 256, INT = 0);
    INT size() { return emax; }
    INT last();
    Element *operator[] (INT i) { return elem[i]; }
    void elemadd(INT num, Element *);
    void elemadd(INT num, INT type, INT nnodes, INT *nodes);
    void elemMark(INT, INT);
    void list();
    INT  markexist(INT);
    void markprint();
    INT getFromAnsys(INT, Elemset *, Elemset *, INT);
    INT ntype() { return nType; }
    Connectivity *getdisCntEtoN() { return disCntEtoN;}
    INT getMark(INT i) { return (marksize? mark[i] : -1); }
};

class AnsysMassElem: public Element {
   INT   eleNum;
   INT   nd;
 public:
   AnsysMassElem(INT iele, INT *nodes);
   bool  isStart() { return false; }
   INT   origNum() { return eleNum; }
   void  renum(INT *);
   INT   numNodes() { return 1; }
   INT*  nodes(INT * = 0);
   float weight();
   INT   numNodesAll() { return 1; }
   INT*  nodesAll(INT * = 0);
   void  dumpTop(FILE *outFile);
   void  evEdge(FILE *, Connectivity*, INT*, INT*, INT*, INT); 
   void  evFace(FILE *, INT*, INT*, INT);
   void  evBody(FILE *outFile, INT*);
};

class AnsysContact: public Element {
   INT   eleNum;
   INT   numNd;
   INT*  nd;
 public:
   AnsysContact(BlockAlloc &, INT, INT, INT*);
   bool  isStart() { return false; }
   INT   origNum() { return eleNum; }
   void  renum(INT *);
   INT   numNodes() { return numNd; }
   INT*  nodes(INT * = 0);
   float weight();
   INT   numNodesAll() { return numNd; }
   INT*  nodesAll(INT * = 0);
   void  dumpTop(FILE *outFile);
   void  evEdge(FILE *, Connectivity*, INT*, INT*, INT*, INT);
   void  evFace(FILE *, INT*, INT*, INT);
   void  evBody(FILE *outFile, INT*);
};

class AnsysSubStruct: public Element {
   INT   eleNum;
   INT   numNd;
   INT*  nd;
 public:
   AnsysSubStruct (BlockAlloc &, INT, INT, INT*);
   bool  isStart() { return false; }
   INT   origNum() { return eleNum; }
   void  renum(INT *);
   INT   numNodes() { return numNd; }
   INT*  nodes(INT * = 0);
   float weight();
   INT   numNodesAll() { return numNd; }
   INT*  nodesAll(INT * = 0);
   void  dumpTop(FILE *outFile);
   void  evEdge(FILE *, Connectivity*, INT*, INT*, INT*, INT);
   void  evFace(FILE *, INT*, INT*, INT);
   void  evBody(FILE *outFile, INT*);
};

class AnsysBar2: public Element {
 protected:
   INT   eleNum;
   INT   numNd;
   INT   nd[3];
 public:
   AnsysBar2(INT iele, INT *nodes, INT numnd);
   bool  isStart() { return false; };
#if defined (RS6000_SYS) || (PCWINNT_SYS)
   INT   origNum() { return eleNum; }
#endif
   void  renum(INT *);
   INT   numDofs() { return 0; } 
   void  markDofs(DofSetArray &) { }
   INT*  dofs(DofSetArray &, INT *p=0);
   INT   numNodes() { return 2; }
   INT*  nodes(INT * = 0);
   float weight();
   INT   numNodesAll() { return numNd; }
   INT*  nodesAll(INT * = 0); 
   void  dumpTop(FILE *outFile);
   void  evEdge(FILE *, Connectivity*, INT*, INT*, INT*, INT); 
   void  evFace(FILE *, INT*, INT*, INT);
   void  evBody(FILE *outFile, INT*);
   PrioInfo examine(INT sub, MultiFront *);
   PrioInfo examine2(INT sub, Smooth *);
};

class AnsysBeam2: public AnsysBar2 {
 public:
   AnsysBeam2(INT iele, INT *nodes, INT numnd):AnsysBar2(iele, nodes, numnd) {}
   PrioInfo examine(INT sub, MultiFront *);
   PrioInfo examine2(INT sub, Smooth *);
   bool isStart() { return true; }
   bool hasRot() { return true; }
};

class AnsysQuad4: public Element {
   INT   eleNum;
   INT   numNd;
   INT   nd[8];
   INT   edge[4];
   INT   clpToTri;
 public:
   AnsysQuad4(INT iele, INT *nodes, INT numnd);
#if defined (RS6000_SYS) || (PCWINNT_SYS)
   INT   origNum() { return eleNum; }
#endif
   void  renum(INT *);
   INT   numDofs() { return 0; }
   void  markDofs(DofSetArray &) { }
   INT*  dofs(DofSetArray &, INT *p=0);
   INT   numNodes() { return 4; }
   INT*  nodes(INT * = 0);
   float weight();
   INT   numNodesAll() { return numNd; }
   INT*  nodesAll(INT * = 0);
   void  dumpTop(FILE *outFile);
   void  evEdge(FILE *, Connectivity*, INT*, INT*, INT*, INT); 
   void  evFace(FILE *, INT*, INT*, INT);
   void  evBody(FILE *outFile, INT*);
   PrioInfo examine(INT sub, MultiFront *);
   PrioInfo examine2(INT sub, Smooth *);
};

class AnsysCube8: public Element {
   INT   eleNum;
   INT   numNd;
   INT   nd[20];
   INT   edge[12];
   INT   face[6];
 public:
   AnsysCube8(INT iele, INT *nodes, INT numnd);
#if defined (RS6000_SYS) || (PCWINNT_SYS)
   INT   origNum() { return eleNum; }
#endif
   void  renum(INT *);
   INT   numDofs() { return 0; }
   void  markDofs(DofSetArray &) { }
   INT*  dofs(DofSetArray &, INT *p=0);
   INT   numNodes() { return 8; }
   INT*  nodes(INT * = 0);
   float weight();
   INT   numNodesAll() { return numNd; }
   INT*  nodesAll(INT * = 0);
   void  dumpTop(FILE *outFile);
   void  evEdge(FILE *, Connectivity*, INT*, INT*, INT*, INT); 
   void  evFace(FILE *, INT*, INT*, INT);
   void  evBody(FILE *outFile, INT*);
   PrioInfo examine(INT sub, MultiFront *);
   PrioInfo examine2(INT sub, Smooth *);
};

class AnsysTri3: public Element {
   INT   eleNum;
   INT   numNd;
   INT   nd[6];
 public:
   AnsysTri3(INT iele, INT *nodes, INT numnd);
#if defined (RS6000_SYS) || (PCWINNT_SYS)
   INT origNum() { return eleNum; }
#endif
   void  renum(INT *);
   INT   numDofs() { return 0; }
   void  markDofs(DofSetArray &) { }
   INT*  dofs(DofSetArray &, INT *p=0);
   INT   numNodes() { return 3; }
   INT*  nodes(INT * = 0);
   float weight();
   INT   numNodesAll() { return numNd; }
   INT*  nodesAll(INT * = 0);
   void  dumpTop(FILE *outFile);
   void  evEdge(FILE *, Connectivity*, INT*, INT*, INT*, INT); 
   void  evFace(FILE *, INT*, INT*, INT);
   void  evBody(FILE *outFile, INT*);
   PrioInfo examine(INT sub, MultiFront *);
   PrioInfo examine2(INT sub, Smooth *);
};

class AnsysTetra: public Element {
 protected:
   INT   eleNum;
   INT   numNd;
   INT   nd[10];
   INT   edge[6];
   INT   face[4];
 public:
   AnsysTetra(INT iele, INT *nodes, INT numnd);
#if defined (RS6000_SYS) || (PCWINNT_SYS)
   INT   origNum() { return eleNum; }
#endif
   void  renum(INT *);
   INT   numDofs() { return 0; }
   void  markDofs(DofSetArray &) { }
   INT*  dofs(DofSetArray &, INT *p=0);
   INT   numNodes() { return 4; }
   INT*  nodes(INT * = 0);
   float weight();
   INT   numNodesAll() { return numNd; }
   INT*  nodesAll(INT * = 0);
   void  dumpTop(FILE *outFile);
   void  evEdge(FILE *, Connectivity*, INT*, INT*, INT*, INT); 
   void  evFace(FILE *, INT*, INT*, INT);
   void  evBody(FILE *outFile, INT*);
   PrioInfo examine(INT sub, MultiFront *);
   PrioInfo examine2(INT sub, Smooth *);
};

#define AnsysQuad9 AnsysQuad4
#define AnsysTri6 AnsysTri3
#define AnsysCube20 AnsysCube8


#endif
