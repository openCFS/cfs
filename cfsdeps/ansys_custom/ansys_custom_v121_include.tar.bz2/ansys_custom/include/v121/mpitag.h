
/*****************************************************************************

    ***  this is the definition of MPI TAG parameters for C  ***

  *** copyright(c) 2009 SAS IP, Inc.  All rights reserved.
  *** ansys, inc.

*****************************************************************************/


/* FE data tags: 100-1900 */
#define NODE_TAG       100
#define ELEM_TAG       200
#define ETYPE_TAG      300
#define MP_TAG         400
#define TB_TAG         500
#define REAL_TAG       600
#define SECT_TAG       700
#define CE_TAG         800
#define CP_TAG         900
#define CSYS_TAG      1000
#define DBC_TAG       1100
#define FBC_TAG       1200
#define ESURFBC_TAG   1300
#define EBODYBC_TAG   1400
#define NBODYBC_TAG   1500
#define RDSP_TAG      1600
#define RFOR_TAG      1700
#define BDRYELM_TAG   1800
#define NXREF_TAG     1900

/* global/local and common tags: 2000-2900 */
#define GLOBAL_TAG    2000
#define LOCAL_TAG     2100
#define COMMON_TAG    2200
#define COMMAND_TAG   2300
#define ERROR_TAG     2400

/* interface exchange tags: 3000-3900 */
#define SUB_INFO_TAG  3000
#define SUB_VECT_TAG  3100
#define COORD_TAG     3200
#define ELE_TAG       3300
#define BC_NUM_TAG    3400
#define BC_TAG        3500
#define BC_D_TAG      3600
#define BC_V_TAG      3700
#define STIFF_I_TAG   3800
#define STIFF_D_TAG   3900

/* gather/scatter tags: 4000-4900 */
#define GATHR_TAG     4000
#define SCATT_TAG     4100
#define GATHR2_TAG    4200
#define SCATT2_TAG    4300
#define GATHR3_TAG    4400
#define SCATT3_TAG    4500
#define SCATT4_TAG    4600  
#define SCATT5_TAG    4700

/* temporary work tags: 5000-5900 */
#define WORK1_TAG     5000
#define WORK2_TAG     5100
#define WORK3_TAG     5300
#define WORK4_TAG     5400
#define WORK5_TAG     5500
#define WORK6_TAG     5600

/* solver tags: 6000-7900 */
#define SETARR_TAG    6000
#define INTF_VEC_TAG  6100
#define PREC_VEC_TAG  6200
#define CPCE_TAG      6300
#define CPCE2_TAG     6400
#define DIAG_I_TAG    6500
#define DIAG_D_TAG    6600
#define SF_TAG        6700
#define PRECOND_TAG   6800
#define SVIV_TAG      6900
#define RADF_TAG      7000
#define ITER_TAG      7100
#define UVEC_TAG      7200
#define DSP_TAG       7300
#define DSP_MAP_TAG   7400
#define PARMETIS_TAG  7500

/* results file tags: 8000-8900 */
#define RES_U_TAG     8000
#define RES_RF_TAG    8100
#define RES_CN_TAG    8200
#define RES_FOR_TAG   8300
#define RES_ESL_TAG   8400
#define RES_EREC_TAG  8500
#define INIS_TAG      8800

/* distributed full file tags */
#define DFF1_TAG     10000   


