/**
 * @file   APDLMath.h
 * @author 
 * @date   Thu Apr 10 10:17:07 2008
 * 
 * @brief  
 * 
 * 
 */

#ifndef _C_APDLMATH_
#define _C_APDLMATH_	1

#include "CadoeAnsys.h"
#include "C_ModeFile.h"
#include "C_vstruct.h"
#include "C_MatFull.h"
#include "C_MatSp.h"
#include "SxSparseMso.h"
#include "C_BcsEngine.h"
#include "spdefines.h"
#include "syssys.h"
#include "cAns_printf.h"

#if defined(LOWERCASENOUNDER_SYS)
#define	APDLMath	apdlmath
#define ch8insub	ch8insub
#define intinfun	intinfun
#define dpinfun		dpinfun
#define cFnamesub	cfnamesub
#define GetSession	getsession
#define SetSession	setsession
#define APDLMathSetVal	apdlmathsetval
#define APDLMathGetVal	apdlmathgetval
#define APDLMathVar	apdlmathvar
#endif

#if defined(UPPERCASENOUNDER_SYS)
#define	APDLMath	APDLMATH
#define ch8insub	CH8INSUB
#define intinfun	INTINFUN
#define dpinfun		DPINFUN
#define cFnamesub	CFNAMESUB
#define GetSession	GETSESSION
#define SetSession	SETSESSION
#define APDLMathSetVal	APDLMATHSETVAL
#define APDLMathGetVal	APDLMATHGETVAL
#define APDLMathVar	APDLMATHVAR
#endif

#if defined(LOWERCASEUNDER_SYS)
#define	APDLMath	apdlmath_
#define ch8insub	ch8insub_
#define intinfun	intinfun_
#define dpinfun		dpinfun_
#define cFnamesub	cfnamesub_
#define GetSession	getsession_
#define SetSession	setsession_
#define APDLMathSetVal	apdlmathsetval_
#define APDLMathGetVal	apdlmathgetval_
#define APDLMathVar	apdlmathvar_
#endif

extern "C" {
  SUBROUTINE APDLMath( char*);
  SUBROUTINE ch8insub( int *iField, FCHAR(c1) FCHARL(c1_len));
  SUBROUTINE cFnamesub( int *iField, FCHAR(c1) FCHARL(c1_len));
  INT FUNCTION intinfun( int *iField);
  DOUBLE FUNCTION dpinfun( int *iField);
  SUBROUTINE GetSession( Hyper *HSession);
  SUBROUTINE SetSession( Hyper *HSession);
  INT FUNCTION APDLMathSetVal( char *Name, double *subc, double *DVal);
  INT FUNCTION APDLMathGetVal( char *Name, double *subc, double *DVal);
  INT FUNCTION APDLMathVar( char *cName);

  void uplabl_( char *str, int *len, int *len_dummy);
}

inline void 
UpperString( string &str)
{
  int len = strlen( str.c_str());
  uplabl_( (char *)str.c_str(), &len, &len);
}


inline void
SetEndStr( char *Str, int Len)
{
  int j=Len-1; 
  while( Str[j] == ' ' && j>0) j--;
  if ( j>=0) Str[j+1] = '\0';
}

inline void
Readch8( int *NumArg, char *str)
{
  ch8insub( NumArg, str, strlen(str));
  SetEndStr( str, 8);
}

inline void
ReadFName( int *NumArg, char *str)
{
  cFnamesub( NumArg, str, LENNAM);
  SetEndStr( str, LENNAM);
}

class C_APDLMath
{
public:

  C_APDLMath();
  ~C_APDLMath();

  void ProcessCommand( string &Command);
  
  void AllocMatrix( const char *Name, char Type, Hyper NRows = 0, Hyper NCols = 0);
  
  void ImportMatrix( const char *Name, char Type, string &FileName, char *Format,
		     char *Arg3 = NULL, char *Arg4 = NULL);
  
  template <typename T, typename T2> void
  CopyMatrix( C_Mat<T> &Min, string &MtxName);

  template <typename T> void
  ExportMatrix( C_Mat<T> *Mat, char *Format, string &FileName, char *Arg1, char *Arg2);

  template <typename T> void
  CreateLSEngine( string SolverType, string SolverName, string &MtxName, string &ArgMem);

  void FactorLSEngine( string &MtxName, bool invert = false);

  template <typename T> void
  CreateITEngine( string SolverType, string SolverName, string PrecondName, string MatrixName);

  template <typename T> void
  SolveLSEngine( string &MtxName, C_Mat<T> &VecsB, C_Mat<T> &VecsX);
  
  template <typename T1, typename T2> void 
  Mult( map< string, C_GenericMat *> &MapM, string &MtxName, char MtxTrans,
	map< string, C_GenericMat *> &Map, string &Vec1, char Vec1trans, string &Vec2);
  
  template <typename T1, typename T2> void
  Axpy( T2 alpha, C_Mat<T1> &M1, T2 beta, C_Mat<T2> &M2);

  template <typename T> void 
  Print( string &MtxName, C_Mat<T> &Mat, string &FileName, int NumRow=-1, int NumCol=-1);

  C_GenericMat		*GetMAT( const char *Cmd, string &Name, bool ShowError = true);
  C_GenericMat		*GetActiveMat( void) { return _ActiveMat;}
  
  C_Mat<double>		*GetdMAT( const char *Cmd, string &Name, bool ShowError = true);
  C_Mat<complex16_t>	*GetzMAT( const char *Cmd, string &Name, bool ShowError = true);
  C_Engine		*GetEngine( const char *Cmd, char *Name);

  void			FreeAll(void);
  void			FreeObject( string &ObjName);

protected:

  C_TimeManager				_TM;
  C_CadoeMessage			_MsgPublic, _MsgVerbose1;
  string				_ActiveCommand;

  C_GenericMat				*_ActiveMat;
  map< string, C_GenericMat *>		_Mat;
  map< C_GenericMat *, C_DataFile *>	_MatFile;

  map< string, C_Engine *>		_Engine;

  map< string, C_DataFile *>		_DataFile;
  map< string, C_DataFile *>::iterator	_ItF;

  map< string, string>			_Perm;
};


extern C_APDLMath	*GetAPDLMath(void);

#endif
