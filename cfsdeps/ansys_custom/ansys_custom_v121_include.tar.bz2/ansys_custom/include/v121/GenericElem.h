/*****************************************************************************
 *                   Copyright (C) 1999 CMSoft                               *
 *                                                                           *
 *  These lines of code and declarations contain unpublished proprietary     *
 *  information of CMSoft. They may not be copied or duplicated in whole     *
 *  or part without prior authorization from CMSoft.                         *
 *                                                                           *
 *****************************************************************************/
#ifndef _GENERIC_ELEM_H_
#define _GENERIC_ELEM_H_

#include <stdio.h>
#include "FSElement.h"
#include "dofset.h"

class FullSquareMatrix;

#define MAXNNODES 89

class GenericElement : public FSElement {
   int eleNum;
   int type;
   int tInfo;
   int numnodes;
   int numNZnodes;
   int nd[MAXNNODES];
   DofSet dofFlags;
 public:
   GenericElement(int iele, int _type, int _tInfo, int nnodes, int *nodes, int dofFlags);
   FullSquareMatrix stiffness(double *v, double *f);
   void renum(int *);

   int    numDofs();
   void   markDofs(DofSetArray &);
   int*   dofs(DofSetArray &, int *p=0);

   int    numNodes();
   int*   nodes(int * = 0);
   void dumpTop(FILE *outFile);
   int buffer(int *);
   int    prType(); 
};

#endif
