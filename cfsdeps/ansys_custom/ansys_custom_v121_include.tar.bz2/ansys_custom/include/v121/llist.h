/* 
 * *** copyright(c) 2009 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */
#define LL_

#ifndef COMMON_
#include "common.h"
#endif

typedef struct LinkNodeInfo{
struct    LinkNodeInfo    *Next;
struct    LinkNodeInfo    *Previous;
    char    *Data;
}LinkNodeInfo, *LinkNode;

typedef struct LinkListInfo {
   LinkNode  Head;
   LinkNode  Tail;
}LinkListInfo, *LinkList;


extern LinkList ll_CreateLinkList(void);

extern ll_AddNodeToList(/* List, Node */);

extern LinkNode ll_ForEachNode(register LinkList List, register char **Data, register LinkNode *StateNode);

extern INT32 ll_PushTail(LinkList List, char *Data);
extern INT32 ll_PopTail(LinkList List, char **Data);
extern INT32 ll_PushHead(LinkList List, char *Data);
extern INT32 ll_PopHead(LinkList List, char **Data);
extern BOOLEAN ll_IsListEmpty(LinkList List);

extern LinkList ll_MakeCopy(LinkList SourceList);

#if defined (PCWINNT_SYS)
extern void ll_DestroyLinkList(LinkList List);
#endif
