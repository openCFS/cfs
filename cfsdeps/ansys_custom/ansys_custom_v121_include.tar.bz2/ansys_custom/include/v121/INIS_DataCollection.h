////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         copyright(c) 2009 SAS IP, Inc.  All rights reserved.             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: INIS_Data.h $
// $Revision: 1.5 $ 7.0
// $Date: 2009/01/21 16:42:59 $ October 04 2005
// $Author: pkgodala $ rjayasee
//
// Decription :
// Collection of INIS_Data
//
////////////////////////////////////////////////////////////////////////////

#include "ANS_StandardIncludes.h"
#include "INIS_Data.h"
#include "INIS_Object.h"

#ifndef INIS_DATACOLLECTION_H
#define INIS_DATACOLLECTION_H


class INIS_DataCollection : public INIS_Object
{
    public :
    
    INIS_DataCollection( INT iMP1, INT iMP2, INT iMP3 );
    //Constructor

    static INIS_DataCollection* ConstructFromDoubleArray(DOUBLE* pDoubleArray, INT iStart, INT iSize) ;
    //Constructor

    ~INIS_DataCollection();
    //Destructor5

    INT GetWrittenDoubleArraySize();
    //R Get the size of the array needed to write the datastructure

    void SetData( DOUBLE* pData, INT iSize, INT iType, INT iPar1, INT iPar2, INT iPar3) ;
    //R void
    //I pData
    //- Data to be set
    //I iSize
    //- Size of the data
    //I iPar1
    //I iPar2
    //I iPar3
    //- Position of the Data (iPar1,iPar2,iPar3) iNLay*iSectIntPt*iElIntPt
    //- Sets data

    bool WriteToDoubleArray(DOUBLE* pDoubleArray, INT iPos, INT iSize, INT& iWrittenSize);
    //R bool
    //I pDoubleArray
    //I iPos
    //  Position to start writing to
    //I iSize
    // -Size of Array Provided
    //I iWrittenSize
    //  Written Data length
    //- Write the INIS_Data Struct to an Double Array Format

    INIS_Data* GetData( INT iLayNum, INT iSecIntPt, INT iElIntPt) ;
    //R Returns a pointer to an INIS_Data
    //I iLayNum
    //I Layer Number or Cell Index
    //I iSecIntPt
    //- Section Integration Point
    //I iElIntPt
    //- Element Integration Point

    INIS_Data** m_pData ;
    //Pointer to Data

    INT iMaxPar1 ;
    INT iMaxPar2 ;
    INT iMaxPar3 ;
    //There is a 3-D table stored in a single array

    INIS_Data** m_pPerimeterData ;
    //Use to set values of data beyond the defined limits iMaxPar*
    //There will be iMaxPar1*iMaxPar2+iMaxPar2*iMaxPar3+iMaxPar3*iMaxPar1
} ;

#endif
