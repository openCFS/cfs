/* cAnsInterface.h	                                        
------------------------------------------------------------------------
------- Notice - This file contains ANSYS Confidential information 
------------------------------------------------------------------------
*/

/* ---------------------------------------------------------------------
 * copyright(c) 2009 SAS IP, Inc.  All rights reserved. 
 * ---------------------------------------------------------------------*/

/*------------------------------ Description ---------------------------
 * Description:   The include file to be used for the ANSYS Interface
 *                API routines.
 *----------------------------------------------------------------------*/

#if !defined(__CANSINTERFACE_H__)
#define __CANSINTERFACE_H__   1

#include "globals.h"
/*--------------------- Static TypeDefs/Structures ---------------------*/

/*----------------------- Variable Definitions -------------------------*/
/* ANSYS keys */
#define ANSYS_GUICB 1         /* Key used to indicate a GUI call back */
#define ANSYS_CLEARCB 2       /* Key used to indicate /CLEAR call back
                                 is registered */
#define ANSYS_EXITGRANCB 3    /* Key used to indicate exit_granule call back
                                 is registered */
#define ANSYS_ABBRCB 4        /* Key used to indicate toolev_ call back
                                 is registered */
#define ANSYS_FINISHCB 5    /* Key used to indicate finish call back
                                 is registered */
#define ANSYS_MNRFSHCB 6    /* Key used to indicate main menu refresh call back
                                 is registered */
#define ANSYS_CURSORCB 7    /* Key used to indicate grcurs call back
                                 is registered */

/* ERROR CODES returned by: */
/* cAnsMakeArray() */

#define ERR_VMAKE_UNKNOWN      1    /* Unknown error occurred */
#define ERR_VMAKE_NONAME  -99991    /* No name give for new array/table */
#define ERR_VMAKE_NAMELEN -99992    /* Name given exceeds PARMSIZE (APDL parameter length) */
#define ERR_VMAKE_DIMSIZE -99993    /* Dimensions given are inconsistant with given size   */

/* Tcl/Tk keys */
#define TCLTK_RUNNING 101     /* Key used to indicate tcl/tk is active */
#define TCLTK_CLEARCB 102     /* Key used to indicate /CLEAR call back */
#define TCLTK_EXITGRANCB 103  /* Key used to indicate exit_granule call back */
#define TCLTK_ABBRCB 104      /* Key used to indicate toolev_ call back */
#define TCLTK_FINISHCB 105  /* Key used to indicate finish call back */
#define TCLTK_MNRFSHCB 106  /* Key used to indicate main menu refresh call back
                                 is registered */
#define TCLTK_CURSORCB 107  /* Key used to indicate grcurs call back */

/* External Command keys */
#define EXT_RUNNING 201       /* Key used to indicate external is active */
#define EXT_CLEARCB 202       /* Key used to indicate /CLEAR CB is active */
#define EXT_EXITGRANCB 203    /* Key used to indicate exit_granule call back */
#define EXT_ABBRCB 204        /* Key used to indicate toolev_ call back */
#define EXT_FINISHCB 205  /* Key used to indicate finish call back */
#define EXT_MNRFSHCB 206  /* Key used to indicate main menu refresh call back
                                 is registered */
#define EXT_CURSORCB 207  /* Key used to indicate grcurs call back */

/* Function Void Pointer keys */
#define EUIDL_COMMAND   1  /* Key used to indicate cAnsEuidlCommand ptr is 
                              active. The void* must point to a char
                            */
#define EUIDL_GETRESULT 2  /* Key used to indicate cAnsEuidlGetResult ptr is
                              active.  The void* must point to a 
                              EuidlGetResult Struct
                            */

/*------------------------- API Functions ------------------------------*/
struct EuidlGetResult {
   int   sizeResult;       /* The size of the Tcl result returned */
   char* getString;        /* The string Tcl will process to get the value. 
                              This should be typically a variable on the Tcl
                              side (e.g. "set rtn $verifyValue")
                            */
   char* result;            /* The memory pointed to for value must be blanked
                              to the appropriate size.  The function in Tcl/Tk
                              is going to do a strlen to determine how many
                              characters of the Tcl result to copy.  This can
                              be set to NULL to just get the string length of
                              the Tcl result.
                            */
};

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/*------------------------- API Functions ------------------------------*/
extern INT cAns_printf(char *format, ...);
extern INT cAns_printff(char *format, ...);
extern INT cAnsSendCommand(char*);
extern INT cAnsSendErrorMessage(INT,char*);
extern void cAnsLoadHelp(char*);
extern INT cAnsMenuCommand(INT);
extern INT cAnsMakeArray( double *arrload, int narrload, char *APDLname, int szX, int szY, int szZ);

extern INT cAnsEuidlCommand(char*);
extern void cAnsSetResource(char*, char*);

#if defined(PCWINNT_SYS)
extern void cAnsSetHardCopy(int, char*, char*, char*, int, int);
#else
/* No print dialog for UNIX */
#endif

/*------------------- ANSYS Internal API Functions ---------------------*/
extern void cAnsSetKey(INT, INT);
extern void cAnsSetProc(INT, void(*)(void));
extern void cAnsSetProc2(INT, INT(*)(void*));
extern INT  cAnsGetKey(INT);
extern void cAnsGetProc(INT, void(**)(void));
extern void cAnsGetProc2(INT, INT(**)(void*));

#ifdef __cplusplus
}
#endif /* __cplusplus */

/*---------------------------- End Of Module ---------------------------*/
#endif

/*------------------------------ API Description -----------------------
cAnsSendCommand

  int cAnsSendCommand(strCommand)
  char *strCommand;

Header file: cAnsInterface.h

Purpose:
     To send an ANSYS command string to the ANSYS command
     interpreter.

Parameters:
     Input
     -----------------------------
       strCommand
         The ANSYS command string which is null terminated.
         The string can have a maximum of 128 characters.

     Output
     -----------------------------

Return Value:
     If the function is successful, the return value is 0;
     otherwise it has one of the following values:
          1 - The command produced a NOTE
          2 - The command produced a WARNING and possibly a NOTE
          3 - The command produced an ERROR and possibly a WARNING
              and/or a NOTE.


Notes:
    If a GUI interfacing command is sent to the command interpreter
    the GUI widget will come up but will not respond to the user
    until the called code returns control back to ANSYS.

----------------------------- End API Description --------------------*/

/*--------------------------- API Description -----------------------
cAns_printf

  int cAns_printf(char *format, ...);


Header file: cAnsInterface.h

Purpose:
     To replace the printf function with a function which will write
     to ANSYS output.  There are some limitations to cAns_printf.
     The only escape sequences recognized are the newline "\n" and 
     horizontal tab "\t".  Also you must send a newline "\n" to have
     the data preceding it printed out.  If the printout has been 
     suppressed with /NOPR then the data will not print out.

Parameters:

     Input
     -----------------------------
     See the printf man pages for explanation  

     Output
     -----------------------------
     See the printf man pages for explanation  

Return Value:
     See the printf man pages for explanation  

-------------------------- End API Description ----------------------- */

/*--------------------------- API Description -----------------------
cAns_printff

  int cAns_printff(char *format, ...);


Header file: cAnsInterface.h

Purpose:
     To replace the printf function with a function which will write
     to ANSYS output.  There are some limitations to cAns_printf.
     The only escape sequences recognized are the newline "\n" and 
     horizontal tab "\t".  Also you must send a newline "\n" to have
     the data preceding it printed out.  If the printout has been 
     suppressed with /NOPR the data will print regardless.

Parameters:

     Input
     -----------------------------
     See the printf man pages for explanation  

     Output
     -----------------------------
     See the printf man pages for explanation  

Return Value:
     See the printf man pages for explanation  

-------------------------- End API Description ----------------------- */

/*------------------------------ API Description -----------------------
cAnsSendErrorMessage

  int cAnsSendErrorMessage(level, strErrMessage)
  char *strCommand;
  int slen;


Header file: cAnsInterface.h

Purpose:
     This function is used to send notes,warnings,and errors messages
     via the ANSYS error handling utilities.

Parameters:
     Input
     -----------------------------
      level
        The level of error severity.
        1=note, 2=warning, 3=error, 4=fatal

      strErrorMessage
        The error message to be displayed.
        The string can have a maximum of 256 characters

     Output
     -----------------------------
       ANSYS ERROR MESSAGE

Return Value:
     If the function is successful, the return value is 0
     otherwise an error has occurred.

-------------------------- End API Description -----------------------*/

/*------------------------------ API Description -----------------------
cAnsLoadHelp

  void cAnsLoadHelp(strIdxHelp)
  char *strIdxHelp;

Header file: cAnsInterface.h

Purpose:
     This function is used to invoke the help systems browser for the
     indicated topic

Parameters:
     Input
     -----------------------------
      strIdxHelp
        The help topic to display. The string may be any string or ANSYS
        command that appear in the left column ot ANSYS, CORP, or USER 
        help index files. Strings beginning with Hlp_ are case sensitive
        ANSYS command are case insensitive. If NULL the function returns 
        immediately.


     Output
     -----------------------------
       NONE

Return Value:
     NONE

-------------------------- End API Description -----------------------*/

/*------------------------------ API Description -----------------------
cAnsSetHardCopy

  void cAnsSetHardCopy(HardCopyDlg, printerName, driverName, portName)
     int     HardCopyDlg;
     char    *printerName;
     char    *driverName;
     char    *portName;

Purpose:
     To disable/enable the hard copy print dialog box by providing
     printer information from a different source while still printing
     out a hard copy of the ANSYS Graphics Window.

Parameters:
     Input
     -----------------------------
       HardCopyDlg;
         A value of 0 or 1 which disables or enables the hard copy print
         dialog box.
       printerName;
         This is gotten from the following registry location:
         HKEY_CURRENT_USER\Software\Microsoft\Windows NT\CurrentVersion\Devices
         If there are no entries then a printer was not installed.
       driverName;
         From the registry for the printerName this is the part of the string
         value before the comma
       portName;
         From the registry for the printerName this is the part of the string
         value after the comma

     Output
     -----------------------------
         NONE

Return Value:
     NONE

Notes:
    NONE

----------------------------- End API Description --------------------*/

/*------------------------------ API Description -----------------------
cAnsMenuCommand

  int cAnsMenuCommand(index)
  int index;

Header file: cAnsInterface.h

Purpose:
     To invoke an ANSYS utility menu item.

Parameters:
     Input
     -----------------------------
       index
         Index based on euidresource.h definitions

     Output
     -----------------------------

Return Value:
     If the function is successful, the return value is 0;
     otherwise it returns 1.


Notes:

----------------------------- End API Description --------------------*/

/*------------------------------ API Description -----------------------
cAnsMakeArray


  int cAnsMakeArray(arrload, narrload, APDLname, szX, szY, szZ)
     double  *arrload;
     int      narrload;
     char    *APDLname;
     int     szX;
     int     szY;
     int     szZ;

Purpose:
     To create an APDL array in ANSYS from the given data APDLname(szX,szY, szZ).

Parameters:
     Input
     -----------------------------
       arrload
         Double precison array, the data to load into the new APDL array.

       narrload
         The number doubles pointed to by arrload. The value of narrload must be
         equal to szX*sxY*sxZ. The size the vector arrload must be >= narrload.

       APDLname
         The ANSYS APDL array to be created.  This is null terminated string which
         contains the name of the ANSYS APDL vector to create. In ANSYS the 
         length of an APDL variable can not be longer than PARMSIZE characters. This
         implies that should be char APDLname[33].

         If an instance of this variable/array already exists, it will be deleted
         and/or overwritten without notifying the user. 

     Output
     -----------------------------

Return Value:
     If the function fails, the return value is non-zero.  otherwise it will return 
     a 0 (zero). See cAnsInterface.h for possible meanings.

----------------------------- End API Description --------------------*/

/*------------------------------ API Description -----------------------
cAnsSetResource

  int cAnsSetResource(option, value)
  char *option;
  char *value;

Header file: cAnsInterface.h

Purpose:
     To customize ANSYS color and font settings

Parameters:
     Input
     -----------------------------
       option
         resource to modify (ie background)
       value
         new color for option

     Output
     -----------------------------

Return Value:
     

Notes:

----------------------------- End API Description --------------------*/

