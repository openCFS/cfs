////////////////////////////////////////////////////////////////////////// 
//          Copyright (C) 2009 ANSYS Inc.  All Rights Reserved            // 
//                                                                        // 
// This file contains proprietary software licensed from ANSYS Inc.       // 
// This header must remain in any source code despite modifications or    // 
// enhancements by any party.                                             // 
//                                                                        // 
//////////////////////////////////////////////////////////////////////////// 
// 
// $Workfile: C_CndFile.h
// $Revision: 
// $Date: 
// $Author: 
// 
// Decription:  
// 
//////////////////////////////////////////////////////////////////////////// 

#ifndef _C_CNDFILE_H_
#define _C_CNDFILE_H_

#include "stdio.h"
#include "cadoe_string.h"
#include "cadoe_vector.h"

class C_CndFile
{
public:
  C_CndFile(string fileName, vector<string> &columns)
  {
    /*
<SOLUTION>
<HEADER FRQ="ITERATION">
 <COLUMN ID="    1">dummy </COLUMN>
 <COLUMN ID="    2">err Res</COLUMN>
 <COLUMN ID="    3">err Dual</COLUMN>
 <COLUMN ID="    4">Norm ur</COLUMN>
 <COLUMN ID="    5">Norm uc</COLUMN>
 <UNITS>SI</UNITS>
</HEADER>
    */
    _fileName = fileName;
    _dim = columns.size()-1;		// the 1st is dummy
    FILE *fp = fopen(_fileName.c_str(), "w");
    
    fprintf(fp, "<SOLUTION>\n");
    fprintf(fp, "<HEADER FRQ=\"ITERATION\">\n");
    
    vector<string>::iterator itc;
    int it = 1;
    for (it = 1, itc = columns.begin(); itc != columns.end(); itc++, it++)
      {
	string &nameColumn = (*itc);
	fprintf(fp, " <COLUMN ID=\" %d\">%s</COLUMN>\n", it, nameColumn.c_str());
      }
    fprintf(fp, " <UNITS>SI</UNITS>\n");
    fprintf(fp, "</HEADER>\n");
    fclose(fp);
  }
  ~C_CndFile();
  
  void Append(int loadstep, int substep, int ieqitr, double time, double *vals)
  {
    FILE *fp = fopen(_fileName.c_str(), "a");
    fprintf(fp, "<COLDATA LOAD_STEP=\"        %d\" SUBSTEP=\"        %d\" ITERATION=\"        %d\" TIME=\"    %e    \">\n", 
	    loadstep, substep, ieqitr, time);
    fprintf(fp, "%d ", 0);
    for (int i = 0; i < _dim; i++)
      fprintf(fp, "%e ", vals[i]);
    fprintf(fp, "\n</COLDATA>\n");
    fclose(fp);
  }
  
protected:
  string _fileName;
  int _dim;
};

extern C_CndFile *G_CndFile;

#endif
