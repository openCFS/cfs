/*! \file CCell.h

  \brief This header file defines the CCell class.

  \author Stephane MARGUERIN &copy; CADOE

  \date 28 November 2002

  \version $Id: CCell.h,v 1.1 2006/12/15 06:48:52 jtm Exp $

 */

#ifndef __CCell_h__ 
#define __CCell_h__ 1 

#include "CParameterMgrPortable.h"
#include "CDirection.h"


class CCell
{
public:
  CCell( CDirection *xDir, CDirection *yDir );
  CCell( const CCell &cell );
  ~CCell();

  CCell& operator =( const CCell &cell);

	int getId(void) const { return _id; }
  void setLevel( int level ) { _level=level; }
  int getLevel(void) const { return _level; }
	bool isSplit(void) const { return _split; }

	void setName( const string &name ) { _name = name; }
	string getName( void ) const { return _name; }

  CDesignSet* getNWSet(void) const { return _NWset; }
  CDesignSet* getNESet(void) const { return _NEset; }
  CDesignSet* getSESet(void) const { return _SEset; }
  CDesignSet* getSWSet(void) const { return _SWset; }

	CDesignSet* getNSet(void) const {return _Nset;}
	CDesignSet* getESet(void) const {return _Eset;}
	CDesignSet* getSSet(void) const {return _Sset;}
	CDesignSet* getWSet(void) const {return _Wset;}
	CDesignSet* getOSet(void) const {return _Oset;}
  
	CCell* getNWCell(void) const { return _NWcell; }
  CCell* getNECell(void) const { return _NEcell; }
  CCell* getSECell(void) const { return _SEcell; }
  CCell* getSWCell(void) const { return _SWcell; }

  CCell* createChild(CDesignSet *NWset, CDesignSet *NEset, CDesignSet *SEset, CDesignSet *SWset);
  int split(void);
	void print(void);

private:
  CCell();
	CCell::CCell( CDirection *xDir, CDirection *yDir, CDesignSet *NWset, CDesignSet *NEset, CDesignSet *SEset, CDesignSet *SWset );

	void generateInternalSets(void);

	static	int	_idGenerator;

  int     _level;       // cell level
	int			_id;
  bool    _split;
	string  _name;

	CDirection *_xDir;
	CDirection *_yDir;

  CDesignSet *_NWset;
  CDesignSet *_NEset;
  CDesignSet *_SEset;
  CDesignSet *_SWset;

	CDesignSet *_Oset;
	CDesignSet *_Nset;
	CDesignSet *_Eset;
	CDesignSet *_Sset;
	CDesignSet *_Wset;

  CCell   *_NWcell;
  CCell   *_NEcell;
  CCell   *_SEcell;
  CCell   *_SWcell;
};

#endif