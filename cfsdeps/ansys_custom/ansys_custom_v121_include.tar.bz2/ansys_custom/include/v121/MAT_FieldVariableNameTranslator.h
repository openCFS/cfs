////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         Copyright (C) 2009 ANSYS Inc.  All Rights Reserved             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MAT_FieldVariableNameTranslator.h $
// $Revision: 1.3 $ 7.0
// $Date: 2009/01/21 16:43:31 $ March 28 2002
// $Author: pkgodala $ rjayasee
//
// Decription :
//
//	This is just an array of Coefficients
////////////////////////////////////////////////////////////////////////////// 

#if !defined(MAT_FieldVariableNameTranslator_H)
#define MAT_FieldVariableNameTranslator_H

#include "MAT_FieldVariableCollection.h"

class MAT_FieldVariableNameTranslator  
{
public:

    static MAT_FieldVariableNameTranslator* Instance()
    {
        if ( NULL == m_pFieldVarNameTranslator )
        {
            m_pFieldVarNameTranslator = new MAT_FieldVariableNameTranslator() ;
        }
        return m_pFieldVarNameTranslator ;
    }

    static void Destroy()
    {
        if ( NULL != m_pFieldVarNameTranslator )
        {
            delete m_pFieldVarNameTranslator ;
        }
        return ;
    }

    bool AddPair( ANS_String oName, MAT_FieldVariable iVariable ) ;
    //R bool
    //I oName
    //I-Name of the String
    //I iVariable
    //I-Index of the Variable
    //- Creates a Field Variable,Name Pair

    ANS_String FieldVariableToName(MAT_FieldVariable iVar) ;
    //I iVar
    //I Variable Index
    //R Returns a String given a variable

    MAT_FieldVariable NameToFieldVariable(ANS_String oName) ;
    //I oName
    //I-Name
    //R Returns a Variable Index given a Name

protected:

    map<MAT_FieldVariable,ANS_String> m_oVariableNamePair ;
    map<ANS_String,MAT_FieldVariable> m_oNameVariablePair ;

    static MAT_FieldVariableNameTranslator* m_pFieldVarNameTranslator ;

	MAT_FieldVariableNameTranslator() ;
    // Default Constructor.

    ~MAT_FieldVariableNameTranslator() ;
    //Destructor
} ;



#endif // !defined(MAT_FieldVariableNameTranslator_H)

