////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         Copyright (C) 2009 ANSYS Inc.  All Rights Reserved             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MAT_ICModifiedTimeHardening.h $
// $Revision: 1.3 $ 7.0
// $Date: 2009/01/21 16:43:42 $ March 28 2002
// $Author: pkgodala $ rjayasee/jlo
//
// Decription :
//              This class implement Modified Time Hardening for Implicit
// Creep Models
//
////////////////////////////////////////////////////////////////////////////// 

#if !defined(MAT_ICModifiedTimeHardening_H)
#define MAT_ICModifiedTimeHardening_H

#include  "MAT_ConstitutiveFunction.h"
#include  "MAT_Creep.h"

class MAT_ICModifiedTimeHardening  : public MAT_Creep
{
public:

	MAT_ICModifiedTimeHardening();
    // Default Constructor.

    static MAT_Creep* Construct() ;

    virtual bool FunctionValue( double* pVariables, INT iNumVariables,
                                double* pInputVariables, INT iNumInputVariables, double& dCreepStrain ) ;
    //I pVariable
    //I-Value of Coefficients
    //I iNumVariables
    //I- Number of variables
    //I dInputVariables
    //I-Input Variables
    //I iNumInputVariables
    //I-Num Input Variables
    //I dCreepStrain
    //I-Calculated Value of Creep Strain
    //R- Calculates the value of the Creep Strain using Modified Time Hardering given  stretch

    virtual bool FirstDerivativeOfUnsquaredError
         ( double* pVariables,INT iNumVariables,
           double* pInputVariables, INT iNumInputVariables,
           INT iVariableIndex, double& dResult ) ;
    //I pVariable
    //I-Value of Coefficients
    //I iNumVariables
    //I- Number of variables
    //I dInputVariables
    //I-Input Variables
    //I iNumInputVariables
    //I-Num Input Variables
    //I dCreepStrain
    //I-Calculated Value of Creep Strain
    //I iVariableIndex
    //I-Variable w.r.t which the derivative is to be calculated
    //R- Calculates the value of the Creep Strain using Modified Time Hardering given  stretch
          
    
    virtual void Print() ;
    // Prints the constitutive function

    virtual void EliminateTemperatureCoefficients();
    //Eliminates Temperature term and fixes it.

    virtual ~MAT_ICModifiedTimeHardening();
    //Destructor


protected:


} ;


class MAT_ICModifiedTimeHardeningFactory
{
    public:

    static MAT_ICModifiedTimeHardeningFactory* Instance() ;
    //I Pointer to Creep Factory
    //- Pointer to Singleton Instantiator

    static void Destroy() ;
    ~MAT_ICModifiedTimeHardeningFactory() ;
    // Destructor

    private:

    MAT_ICModifiedTimeHardeningFactory() ;
    // Constructor

    static MAT_ICModifiedTimeHardeningFactory* m_pInstance ;
    //Pointer to only instance of this class
} ;

#endif // !defined(MAT_ICModifiedTimeHardening_H)
