/* expmdb_struct.h CADOE  */
/*******************************************************************************
 *
 *   expmdb_struct.h -- Structures de donnees adomesh
 *              
 * 
 * |Module: 
 *
 * |Description: 
 *
 * |Includes:	
 *        
 * |Auteur: Jean-Daniel Beley - Stephane Marguerin - Gilles Venet
 *
 * |Creation: 
 *
 * |Version: $Id: expmdb_struct.h,v 1.6 2009/01/21 16:48:58 pkgodala Exp $
 *
 * |Copyright:	copyright(c) 2009 SAS IP, Inc.  All rights reserved.
 *
 *   
 * HISTORY
 *   
 *   11/22/00 12:18 <        Marc Gadbois> Rel:ms9      SCCA:83109  Delta:9.4
 *   
 *   09/26/00 09:58 <       Brian Jantzen> Rel:ms8m1    SCCA:79107  Delta:81.3
 *   
 *   06/21/00 16:30 <       Brian Jantzen> Rel:ms8m1    SCCA:74307  Delta:81.2
 ******************************************************************************/

#ifndef __expmdbstructh__ 
#define __expmdbstructh__ 1 

#include <math.h>

/* Pour rechercher les erreurs IEEE */
#ifdef DEBUGIEEE
#include <sunmath.h>
#endif

#include "cadoe.h"
#include "cadoesys.h"

#ifdef __cplusplus
#include "CCadoePortable.h"
#endif

#include "cbf.h"
#include "liste_chainee.h"
#include "m_matrix.h"
#include "hash_util.h"

#ifndef __constantesadomeshh__
#include "constantes_adomesh.h"
#endif

/* types d'objets */
#define OBJ_ELEMENT     1
#define OBJ_NOEUD       2
#define OBJ_CONFIG      12
#define OBJ_RESULTAT    15
#define OBJ_COEFM       17
#define OBJ_REPERE      23
#define OBJ_MESH        60


/*#ifdef __cplusplus
extern "C" {
#endif*/

/* Variables globales de configuration */
extern int G_composition_cout;
/*extern int genere_fem;*/
extern int genere_res;
extern int est_verbeux;
extern int affiche_interne;
extern int est_verbeux3;
extern int affiche_interne3;
extern int linearise;
extern double prec;
extern int iter_glis;
extern int iter_proj;
extern double eps_limite;
extern double eps0;
extern int mode_interactif;
extern int silencieux;
extern int sous_integre;
extern int G_nb_couches;
extern int nb_couches_courant;
extern double factlog;
extern int no_shell;
extern double version_dam;
extern int type_ecriture;
extern int no_cont;
extern int no_bary;
extern int trace;
extern FILE* fic_trace;
extern int iterfrmax;
extern int itercntmax;
extern int fic_cont2, fic_cont3;
extern int fic_bary2, fic_bary3;
extern int cas_emcp2;
extern double G_precision;
extern double G_taille;
extern T_booleen probleme_XZ;
/*extern T_booleen dbg_eq;*/
extern T_booleen dbg_cfg;
/*extern T_booleen dbg_bary;
extern T_booleen dbg_prj;*/
extern T_booleen local;
extern T_booleen qamode;
extern int       avec_croise;
extern FILE      *G_mda;
extern FILE      *G_daa;
extern int       num_dbg;
/*extern int       num_uv_dbg;*/
extern int dbg_memory_leak;
extern T_booleen G_order_max_3;
extern T_booleen reconnec;
extern int	G_fcn_cout;
  extern T_booleen G_cbf_open;

/*#ifdef __cplusplus
}
#endif*/

struct __Bilan;
struct __Config;
struct __Coefm;
struct __Coefr;
struct __Fcout;
struct __Defo;
struct __Element;
struct __Groupe;
struct __Integration;
struct __Modele;
struct __Mesh;
struct __Mnoeud;
struct __Noeud;
struct __Normal;
struct __Polym;
struct __Repere;
struct __Resul;
struct __Support;
struct __EContact;
struct __NContact;
struct __Zone;

typedef struct __ZContact Z_Contact;
typedef struct __EContact E_Contact;
typedef struct __NContact N_Contact;
typedef struct __Zone T_Zone;
typedef struct __Bilan 		T_Bilan;
typedef struct __Config 	T_Config;
typedef struct __Coefm		T_Coefm;
typedef struct __Coefr		T_Coefr;
typedef struct __Fcout		T_FCout;
typedef struct __Defo 		T_Stat_defo;
typedef struct __Element 	T_Element;
typedef struct __Groupe		T_Groupe;
typedef struct __Integration 	T_Integration;
typedef struct __Modele 	T_Modele;
typedef struct __Mesh             T_Mesh;
typedef struct __Mnoeud		T_Mnoeud;
typedef struct __Noeud 		T_Noeud;
typedef struct __Dnoeud         T_Dnoeud;
typedef struct __Normal 	T_Normal;
typedef struct __Polym		T_Polym;
typedef struct __Repere		T_Repere;
typedef struct __Resul 		T_Resultat;
typedef struct __Support 	T_Support;

/*
 *-------------------------- type de maillage  ------------------------------
 */
typedef enum {
  MESH_GENERIQUE = 0, 
  MESH_LINEARISE = 1, 
  MESH_CL = 2       , 
  MESH_PEAU = 3     ,
  MESH_PEAU_UV = 4  ,
  MESH_MACRO = 5    ,
  MESH_PARTIE = 6   ,
  MESH_PB_AXIS = 7  ,
  MESH_FACE = 8	,
  MESH_DEGRE_SUP = 9,
  MESH_BOITE = 10	,
  MESH_VISU = 11	,
  MESH_FILS = 12     ,
  MESH_BLOC = 13     ,
  MESH_LAYER = 14	,
  MESH_LINKER = 15	,
  MESH_SWEEP = 16,
  MESH_SWEEP_DATA = 17,
  MESH_FREE_FACE = 18,
  MESH_BOUNDARY_LAYER = 19,
  MESH_BUFFER = 20,
  MESH_ADOMESH = 21,
  MESH_PERTURB = 22,
  MESH_AUTRE = 100    
} E_type_mesh;

/*
 *------------------------Type de groupe ----------------
*/
typedef enum {
  GRP_TYP_UNKNOWN	= 0,
  GRP_TYP_SDT		= 1,
  GRP_TYP_USER		= 2
}E_type_groupe;

typedef enum {
	SUPPORT_GRP_UNKNOWN,
	SUPPORT_GRP_SHELL,
	SUPPORT_GRP_FACET,
	SUPPORT_GRP_MIXTE
}
E_type_support_grp;



/*
 *-------------------------- type DATA maillage  ------------------------------
*/
typedef enum {
  MDATA_AUCUN,
    MDATA_SWEEP
  }E_type_Mdata;


/*
 *------------------------Type de stockage dans groupe ----------------
*/
typedef enum {
  GRP_DIRECT,
  GRP_CODAGE,
  GRP_TOUT,
  GRP_PAR_NUMERO
}E_GRP_stock;

/*
 *------------------------Type de repere ----------------
*/
typedef enum {
  REP_CARTHE,
  REP_CYLIND,
  REP_SPHERE
}E_REP_type;

typedef enum {
	NO_CONSTRAINT		= 0x0,
	CONSTRAINT_X		= 0x1,  // CONSTRAINT_XYZ & CONSTRAINT_X = true
								// CONSTRAINT_XY & CONSTRAINT_X = true
								// CONSTRAINT_XZ & CONSTRAINT_X = true
								// CONSTRAINT_X & ( NO_CONSTRAINT | CONSTRAINT_Y | CONSTRAINT_Z ) = false

	CONSTRAINT_Y		= 0x2,  // CONSTRAINT_XYZ & CONSTRAINT_Y = true 
								// CONSTRAINT_XY & CONSTRAINT_Y = true
								// CONSTRAINT_YZ & CONSTRAINT_Y = true
								// CONSTRAINT_Y & ( NO_CONSTRAINT | CONSTRAINT_X | CONSTRAINT_Z ) = false

	CONSTRAINT_XY		= 0x3,  // CONSTRAINT_XYZ & CONSTRAINT_XY = true 
								// CONSTRAINT_XY & CONSTRAINT_X = true
								// CONSTRAINT_XY & CONSTRAINT_Y = true
								// CONSTRAINT_XY & ( NO_CONSTRAINT | CONSTRAINT_Z ) = false

	CONSTRAINT_Z		= 0x4,  // CONSTRAINT_XYZ & CONSTRAINT_Z = true 
								// CONSTRAINT_XZ & CONSTRAINT_Z = true
								// CONSTRAINT_YZ & CONSTRAINT_Z = true
								// CONSTRAINT_Z & ( NO_CONSTRAINT | CONSTRAINT_X | CONSTRAINT_Y ) = false

	CONSTRAINT_XZ		= 0x5,  // CONSTRAINT_XYZ & CONSTRAINT_XZ = true
								// CONSTRAINT_XZ & CONSTRAINT_X = true
								// CONSTRAINT_XZ & CONSTRAINT_Z = true
								// CONSTRAINT_XZ & ( NO_CONSTRAINT | CONSTRAINT_Y ) = false

	CONSTRAINT_YZ		= 0x6,  // CONSTRAINT_XYZ & CONSTRAINT_YZ = true
								// CONSTRAINT_YZ & CONSTRAINT_Y = true
								// CONSTRAINT_YZ & CONSTRAINT_Z = true
								// CONSTRAINT_YZ & ( NO_CONSTRAINT | CONSTRAINT_X ) = false

	CONSTRAINT_XYZ		= 0x7   // CONSTRAINT_XYZ & CONSTRAINT_Y = true 
								// CONSTRAINT_XYZ & CONSTRAINT_X = true
								// CONSTRAINT_XYZ & CONSTRAINT_Z = true
								// CONSTRAINT_XYZ & NO_CONSTRAINT = false
} E_CONSTRAINT_type;

/*
 *-----------------------type de format d'import -----------
 */
typedef enum {
  FRM_NASTRAN,
  FRM_NOPO,
  FRM_NONE,
  FRM_ANSYS,
  FRM_CSV, 
  FRM_STAR,
  FRM_PATRAN,
  FRM_MAX3DA,
  FRM_MAX3DB,
  FRM_TASK,
  FRM_FLUENT, 
  FRM_SAMCEF,
  FRM_ABAQUS,
  FRM_DYNA,
  FRM_CFX
}E_FRM_INPUT_FILE;


typedef enum {
    CONTACT_STRICT, 
    CONTACT_PARTIEL,
		AUCUN_CONTACT
} E_type_contact;

typedef enum {
    _CONTACT_FACE_FACE, 
    _CONTACT_EDGE_FACE,
    _CONTACT_EDGE_EDGE,
    _CONTACT_INCONNU
} E_geo_contact;


typedef enum {
	ELE_MAITRE,
	ELE_ESCLAVE,
	ELE_NEUTRE
} E_type_ele_contact;

typedef enum 
	{
    MESH_UNDEFINED,
		MESH_IN_VAN,
    MESH_IN_MEMORY,
    MESH_IN_BUFFER,
    SKIN_IN_MEMORY
  } E_etat_chrg;

/* 
 *-------------------------- Bilan  ---------------------------
 */
struct __Bilan
{
  T_Element *element;
  int		indEle;
  int composante;
  double epsilon;
};

/* 
 *------------------ Coefficients du maillage polynomial ------
 */
struct __Coefm
{
  int	nb_comp;	/* nbr de composantes du coef ( noeud -> 3, repere -> 7 ) */
  int	nb_param;	/* nbr de parametres concernes */
  char	**nom;		/* tableau des noms des parametres */
  IVEC	*terme;		/* Terme associe ( dimension nb_param ) */
  IVEC	*ind;		/* Numero des noeuds concernes */
  VEC	*valeur;	/* Valeur des coefficients ( nb_comp*in->dim ) */
};

/* 
 *------------------ Coefficients des polynomes de repere ------
 */
struct __Coefr
{
  int  nb_param;                /* nbr de parametres concernes */
  char **nom;                   /* tableau des noms des parametres */
  IVEC *terme;    		/* Terme associe ( dimension nb_param ) */
  IVEC *numero;			/* Numero des reperes concernes */
  VEC *valeur;                  /* Valeur des coefficients ( 7*in->dim ) */
};


/*
 *-------------------------- Configuration ------------------------------
 */
struct __Config
{
  int     	numero;  	/* numero de la config */
  T_booleen   	a_traiter;    	/* signale config a traiter */
  T_liste       *lpar;          /* Liste de tous les parametres */
  int     	nb_param_mod; 	/* nombre de parametres concernes */
  char    	**nom;		/* tableau des noms de parametres */
  double  	*vcou; 		/* valeur courante de chaque parametre pour la config */
  double  	*vref; 		/* valeur de reference de la config */
  int     	*code; 		/* codes de valeur des parametres : VALMIN, VALMAX, VALREF */
  int     	*shape; 	/* codes de valeur des parametres : VALMIN, VALMAX, VALREF */
  double        deformation;    /* Deformation estimee de la config */
  int 		reduite;        /* Nombre de fois ou la config a deja ete reduite */
  T_Resultat    *res;           /* Maillage perturbe */
  void		*geom;
  void *config;
  T_ltete	*reperes;
};

/*
 *-------------------------- Cout  ------------------------------
 */
struct __Fcout {
  int		fcn_cout;	/*  Fonction cout				*/
  double 	epsmax;		/*  Deformation courante 			*/
  VEC 		*perturb;	/*  Perturbation des noeuds			*/
  VEC		*coutel;	/*  vecteur des composantes du cout de l'ele	*/
  VEC           *jacob;         /*  Vecteur de jacobien aux points de Gauss     */
  MAT		*gradient;	/*  matrice des gradients			*/
  MAT 		*mat_B;		/*  Matrice pour le calcul de la deformation 	*/
  T_Integration *integration;	/*  Integration de l'element 		     	*/
};


/*
 *--------- Statistiques deformation par elements ---------------
 */
struct __Defo
{
  int nb_zones;
  IVEC **zones;
  VEC *limites;
};


/*
 *------------------------- ELEMENT --------------------------
 */

struct __Element
{ 
  int numero;			/*  Numero Utilisateur		 	     	*/
  int indice;
  E_ele_type_geo type_geometrique;	/*  Type geometrique          	     	*/
  unsigned int est_traite:1;	/*  Flag element deja traite                 	*/
  unsigned int degenere:1;	/*  Flag element degenre irrecuperable		*/
  unsigned int est_sature:1;	/*  Flag si element ne peut pas descendre    	*/
  unsigned int a_bouge:1;	/*  Indice de mouvement                      	*/
  unsigned int couleur:5; 	/* couleur - jusqu'a 32 max 			*/
  int 		nb_noeud;	/*  Nombre de noeuds de l'element            	*/
  T_Noeud 	**noeud; 	/*  Liste des adresses des noeuds            	*/
  T_FCout      	*fcout;
  void		*propriete;
  void		*Edata;
  IVEC      *nd;
};


/* 
 *---------------------- Groupe --------------------------------------
 */
struct __Groupe{
  int nature;							/* NOEUDS , ELEMENTS(shell), FACET, ELEMENTS_VOL				  */
  char *nom;							/* Nom du groupe												  */
  unsigned int face_label;				/* Numero externe (dans le fichier de maillage mort)			  */
  int numero;							/* Numero utilisateur											  */
  unsigned int type_groupe;				/* Origine du groupe (Workbench): GRP_TYP_SDT, GRP_TYP_USER etc...*/ 
  /*unsigned int est_une_zone:1;*/		/* Est-ce que le groupe correspond a une frontiere			*/ 
  E_GRP_stock type_stockage;       		/* Stockage par indices ( DIRECT ) ou par codage ( CODAGE ) */
  int iterateur1, iterateur2;			/* Interateurs pour parcours du contenu du groupe			*/
  T_Mesh   *mesh;						/* Pour les numerotations			*/
  IVEC *vec;							/* Vecteur de stockage				*/
  void		*Lskin;						/* T_Mesh peau du groupe si volumik */
  T_booleen  exported; 
};


/*
 *------------------------- OBJET INTEGRATION --------------------------
 */
struct __Integration{
	int nb_point;			/*  Nombre de points d'integration */
	double *point;			/*  Coordonnees des points */
	double *poids;			/*  Poids d'integration */
	double *fonction;		/*  Valeurs des fonctions de forme */
	double *derivee;		/*  Derivees des fonctions de forme */
};


/*
 *------------------------- MODELE --------------------------
 */
struct __Modele
{
  int dimension;		/*  2D, 3D */
  E_appli type_modele;
  int num_config;			/*  Numero de la config courante */
  int part_id;
  int part_copie;
/*  T_booleen	mode_MSH_init;*/
  double version;
/*  char *nom_fic;*/			/*  Nom du probleme */
  T_cbf       *vaf;
  T_ltete	*lpart;
  T_ltete	*lmesh;
  void		*p_travail;		/*  La part de travail */
  void		*p_travailcao;	/*  La part de travail	cao						*/
  void    *p_section;
  void    *p_cfd;           /* la part de travail en environnement cfd				*/
  void    *p_cao_cfd;		/* la part cao specifique a la methodologie fluide		*/
/*  void *postAdomesh;	*/	/* pointeur sur l'objet CPostAdomesh */
  void *CModele;		/* pointeur sur l'objet CModele */
  void *meshmgr;			/* pointeur vers CMeshMgr dans Paramesh et CMeshMgrBase dans Postmesh */
  T_booleen doeMethod; /* VRAI si methode doe */
};

/*
 *------------------------- MAILLAGE --------------------------
 */
struct __Mesh
{
  int 		numero;
  int 		numero_pere;
  int 		dimension; 		/*  2D, 3D */
  int 		degre; 			/*  Degre du maillage */
  int 		fem_id; 		/*  Id du FEM */
  int 		nb_noeud;		/*  Nombre de noeuds */
  int 		nb_element;  		/*  Nombre d'elements */
  int		nb_groupe;
  int		part_id;		/* id du part associe */
  unsigned int 	to_update:1; 		/*  Flag element deja traite                 */
  unsigned int 	temporaire:1;
  unsigned int 	polym_update:1;
  unsigned int  in_memory;
  E_etat_chrg   where;
  E_etat_chrg   where_group;
  E_etat_chrg   where_rep;
  E_type_mesh	type;
  E_type_Mdata DATA_type;
  E_FRM_INPUT_FILE type_input;
  double      	taille; 		/*  Dimension moyenne d'un element */
  double	eps_max_peau;		/*  Epsilon max sur la peau calculer par peau_uv et coque */
  char        	*nom_mesh; 		/*  Nom du part */
  char		*import_file;
  T_Groupe    	*groupe_actif;
  T_Noeud     	**noeud;		/*  Tableau des noeuds */
  T_Element   	**element;		/*  Tableau des elements */
  T_Noeud       *n0; /* 1er noeud de la liste : initalise lors de la creation de la liste des noeuds, 
                      il ne doit JAMAIS change*/
  T_Element     *e0; /* 1er element de la liste : initalise lors de la creation de la liste des noeuds, 
                      il ne doit JAMAIS change*/
  T_Polym     	*polym;			/*  Maillage polynomial */
  T_Mesh      	*pere;
  T_Modele    	*modele;
  void *meshmgr;
  T_Mesh      	*avant;
  T_Mesh	*visu;
  T_Mesh	*fils;
  T_ltete    	*groupes;
  T_ltete	*reperes;
  void        	*data;
  void		*Mdata;
  T_Htable   	*tableno;		/*  Table numero utilisateur, numero interne noeuds  */ 
  T_Htable   	*tableel;		/*  Table numero utilisateur, numero interne elements */
  T_Htable	*tablerep;		/*  Table numero utilisateur, numero interne reperes */
  void *CLmesh;
  void *CLvisu;
  void *CFacetMesh;
  T_booleen useEulerAngle;
};

/*
 *-------------------------- NOEUD -------------------------
 */
struct __Noeud 
{
  int numero;			/*  Numero utilisateur					*/
  int indice;			/*  Indice du noeud 					*/
  unsigned int est_fixe:1;	/*  Indice de mobilite  				*/
  unsigned int a_bouge:1;	/*  Indice de mouvement					*/
  unsigned int est_traite:1;	/*  Significations variees !!!!				*/
  unsigned int front_initial:1;	/*  Noeud du front initial 			       	*/
  unsigned int front:1;      	/*  Noeud du front courant 			       	*/
  unsigned int est_primaire:1;	/*  Noeud primaire des elements DKT12 		       	*/ 
  unsigned int couleur:5;	/*  Noeud primaire des elements DKT12 		       	*/ 
  T_Noeud *noeud_sup;
  void		*equa;		/*  Equations de contraintes */
  void		*support_geo;	/*  Support geometrique */
  void		*mesh_data;	/*  Voisinage du noeud ( noeud et element ) 		*/
  double xyz[3];		/*  Coordonnees                                 	*/
  double perturb[3];            /*  Vecteur de la perturbation courante         	*/
  double sauve_perturb[3];      /*  Vecteur de la perturbation courante         	*/
  double poids;
  int      cs_depla_label;      /*  label du repere de deplacement */
  int		cs_def_label;
  T_Repere *cs_depla;           /*  repere de deplacement */ 
   void          *appli;         /* pour le calcul de l'intersection (param_uv *)        */
};

struct __Mnoeud {
  int		numero;
  int		couleur;
  unsigned int  nb_element;
  unsigned int  nb_element_max;
  double	nrm[3];
  T_booleen	primaire;
  T_Element	**element; 
  unsigned int  *ind_ele;
  T_liste	*noeud_voisin;
  T_liste	*aretes;
  /*  T_liste *faces;  */
  void		*appli;
};


struct __Dnoeud {
  int             nb_mesh;
  T_Mesh        **meshes;
  IVEC           *numeros;
};


/* Maillage polynomial */
struct __Polym
{
  int  nb_terme;                /* Nombre de terme du polynome */
  IVEC **termes;                 /* Description des termes du polynome ( dimension nb_termes*nb_param ) */
  T_Coefm **coef;               /* Description des coefficients */
  T_Coefr **coefrep;		/* description des coefficients des reperes */
  T_liste *lpert;               /* Liste des resultats deja inclus dans le polynome */
	void *_meshPert;
};


/*
 *-------------------------- Repere  --------------------------
 */
struct __Repere {
  int numero;
  int id;			/* id du repere */
  int label;			/* label du repere */
  E_REP_type	type:3;		/* type : carthesien, cylindrique*/
  E_CONSTRAINT_type constraint:4; /* type de contrainte */
  int	rdef_label;
  VEC *trans_abs;                /* Transformation du repere/absolue  */
  VEC *perturb;                  /* Transformation relative du repere   */
  VEC *quater;		/* representation en quaternion : 4 quater + 3 trans */
  T_Repere *ini, *modi;
  void *r_dep;
  T_liste	*lrep;
  double	AEuler[3];
};


/*
 *------------------------- Resultat config ---------------------------------
 */
struct __Resul
{
  int configId;             /* Config associee a ce resultat */
  T_booleen est_traite; 	/* Vrai si cette config a deja ete calculee ou chargee */
  T_booleen est_traitable;      /* Vrai si on dispose de donnees sur cette config */
  char nom[PATH_MAX]; 		/* Nom de la config */
  T_Bilan *eps_final; 		/* Deformation finale obtenue */
  double eps_peau; 		/* Deformation de la peau */
  T_Stat_defo *stat_defo; 	/* Repartition des deformations par categorie */
  IVEC *a_bouge;                /* Noeuds ayant bouge dans la config */
	IVEC *support_rep;            /* liste des Id de repere qui ont bouge */
  VEC *pert;                    /* Perturbation de ces noeuds */
  VEC *pert_rep;		/* Perturbation de ces reperes */
  T_ltete *lrep;
  int			m_iId; /* id unique pour debugger avec CObjectMgr */

};


/*
 *-----------------------normale des surfaces --------------
 */
struct __Normal
{
  unsigned int	geomId;
  int		noeud;
  double	nrm[3];
  double	axeX[3];
  int   type_axeX;
  int		forme;
  double sens_nrm;
  double sens_axeX;
};
/*
 *----------------------- contacts --------------
 */
struct __ZContact
{
	int id;
	T_booleen isFace1;
	T_booleen isFace2;
	int nbNodes1;
	int nbNodes2;
	BVEC *nodes1;
	BVEC *nodes2;
	T_booleen traite;
};

struct __Zone
	{
		T_liste *lele1;             /* lele1 inclus dans lele2 si inclusion strict ( partie maitresse ) */
		T_liste *lele2;				/* partie esclave si inclusion stricte								*/
		E_type_contact inclusion;
    E_geo_contact type_geo;
    T_Mesh *mesh_loc1;
    T_Mesh *mesh_loc2;
    int max_dep;
	void * vecele1;
	void * vecele2;
	};

struct __EContact					/* contact au niveau des elements       							*/
	{
	   T_liste			      *Ncontact;
	   T_Zone				  *zone;
	   E_type_ele_contact      type; /* maitre, esclave ou neutre    */  
	   E_type_contact inclusion;     /* ele totalement inclus ou non */	   
	};

struct __NContact
	{
		T_Noeud *noeud;
		double u;
		double v;
    int ind;
    T_Element *elem;
    T_booleen dim1;
    double nrm[3];
	int IdElt;
	   int IdNode;
	};

#endif

