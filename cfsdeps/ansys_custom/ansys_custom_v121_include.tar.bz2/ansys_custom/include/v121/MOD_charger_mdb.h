/* MOD_charger_mdb.h CADOE  */
/*
 * MOD_charger_mdb.h
 *
 * $Id: MOD_charger_mdb.h,v 1.3 2007/06/05 15:17:45 gdvenet Exp $
 *   
 * HISTORY
 *   
 *   06/28/00 10:47 <       Brian Jantzen> Rel:ms8m1    SCCA:74542  Delta:81.3
 *   
 *   06/21/00 16:30 <       Brian Jantzen> Rel:ms8m1    SCCA:74307  Delta:81.2
 */

#ifndef __modchargermdbh__
#define __modchargermdbh__ 1

#ifndef __expmdbstructh__
#include "expmdb_struct.h"
#endif

/*#ifdef __cplusplus
extern "C" {
#endif*/

extern T_statut MOD_charger_mdb( CModeleBase *, WString nom_fic, T_booleen );
extern T_statut MOD_charger_mdb_4 ( T_Modele * );
extern T_Modele * ADOM_open_modele ( const _TCHAR *nom_fic, T_statut *ier, T_booleen *var_env_ok, T_booleen *van_existe );
extern T_Modele * ADOM_open_modele2 (T_statut * ier);

/*#ifdef __cplusplus
}
#endif*/

#endif
