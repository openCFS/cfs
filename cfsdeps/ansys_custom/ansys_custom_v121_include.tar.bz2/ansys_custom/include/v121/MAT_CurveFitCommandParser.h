
/*
////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         Copyright (C) 2009 ANSYS Inc.  All Rights Reserved             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MAT_CurveFitCommandParser.h $
// $Revision: 1.3 $ 7.0
// $Date: 2009/01/21 16:43:23 $ March 28 2002
// $Author: pkgodala $ rjayasee/jlo
//
// Decription :
//
//	Code to*GET Curve Fitting Data
//////////////////////////////////////////////////////////////////////////////
*/

/*  tbfit.h */
#if !defined(MAT_CurveFitCommandParser_H)
#define MAT_CurveFitCommandParser_H


#ifdef __cplusplus
extern "C"
{
#endif

void MAT_CurveFitFCaseCommandParser( char pParamList[6][129] ) ;

void MAT_CurveFitExpCommandParser( char pParamList[6][129] ) ;

#ifdef __cplusplus
}
#endif

#endif
