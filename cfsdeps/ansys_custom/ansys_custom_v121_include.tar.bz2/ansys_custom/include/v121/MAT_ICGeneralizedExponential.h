////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         Copyright (C) 2009 ANSYS Inc.  All Rights Reserved             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MAT_ICGeneralizedExponential.h $
// $Revision: 1.3 $ 7.0
// $Date: 2009/01/21 16:43:42 $ March 28 2002
// $Author: pkgodala $ rjayasee
//
// Decription :
//              This class implement Generalized Exponential Implicit Creep Model
//
////////////////////////////////////////////////////////////////////////////// 

#if !defined(MAT_ICGeneralizedExponential_H)
#define MAT_ICGeneralizedExponential_H

#include  "MAT_ConstitutiveFunction.h"
#include  "MAT_Creep.h"

class MAT_ICGeneralizedExponential  : public MAT_Creep
{
public:

	MAT_ICGeneralizedExponential();
    // Default Constructor.

    static MAT_Creep* Construct() ;

    virtual bool FunctionValue( double* pVariables, INT iNumVariables,
                                double* pInputVariables, INT iNumInputVariables, double& dCreepStrainRate ) ;
    //I pVariable
    //I-Value of Coefficients
    //I iNumVariables
    //I- Number of variables
    //I dInputVariables
    //I-Input Variables
    //I iNumInputVariables
    //I-Num Input Variables
    //I dCreepStrainRate
    //I-Calculated Value of Creep Strain Rate
    //R- Calculates the value of the Creep Strain Rate 

    virtual bool FunctionExpTerm( double* pVariables, INT iNumVariables,
                                  double* pInputVariables, INT iNumInputVariables, double& dCreepStrainRate ) ;
    //I pVariable
    //I-Value of Coefficients
    //I iNumVariables
    //I- Number of variables
    //I dInputVariables
    //I-Input Variables
    //I iNumInputVariables
    //I-Num Input Variables
    //I dCreepStrainRate
    //I-Calculated Value of Exponential Term/ RTerm
    //R- Calculates the value of the Exp Portion of the Creep Function 

    bool FirstDerivativeOfUnsquaredError
         ( double* pVariables,INT iNumVariables,
           double* pInputVariables, INT iNumInputVariables,
           INT iVariableIndex, double& dResult ) ;
    //I pVariable
    //I-Value of Coefficients
    //I iNumVariables
    //I- Number of variables
    //I dInputVariables
    //I-Input Variables
    //I iNumInputVariables
    //I-Num Input Variables
    //I iVariableIndex
    //I-Variable w.r.t which the derivative is to be calculated
    //I dResult
    //I-Calculated value of derivative
    //R- Calculates the value of the Creep Strain Rate 
          
    bool FirstDerivativeOfExpTerm
         ( double* pVariables,INT iNumVariables,
           double* pInputVariables, INT iNumInputVariables,
           INT iVariableIndex, double& dResult ) ;
    //I pVariable
    //I-Value of Coefficients
    //I iNumVariables
    //I- Number of variables
    //I dInputVariables
    //I-Input Variables
    //I iNumInputVariables
    //I-Num Input Variables
    //I iVariableIndex
    //I-Variable w.r.t which the derivative is to be calculated
    //I dResult
    //I-Calculated value of derivative
    //R- Calculates the value of the derivative of the RTerm     
    
    virtual void Print() ;
    // Prints the constitutive function

    virtual void EliminateTemperatureCoefficients();
    //Elimnates Temperature term and fixes it.

    virtual ~MAT_ICGeneralizedExponential();
    //Destructor

protected:


} ;


class MAT_ICGeneralizedExponentialFactory
{
    public:

    static MAT_ICGeneralizedExponentialFactory* Instance() ;
    //I Pointer to Creep Factory
    //- Pointer to Singleton Instantiator

    static void Destroy() ;
    ~MAT_ICGeneralizedExponentialFactory() ;
    // Destructor

    private:

    MAT_ICGeneralizedExponentialFactory() ;
    // Constructor

    static MAT_ICGeneralizedExponentialFactory* m_pInstance ;
    //Pointer to only instance of this class
} ;

#endif // !defined(MAT_ICGeneralizedExponential_H)
