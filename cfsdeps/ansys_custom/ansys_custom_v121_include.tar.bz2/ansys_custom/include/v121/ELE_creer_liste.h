/* ELE_creer_liste.h CADOE  */
/*
 *  ELE_creer_liste.h -
 *
 *  $Id: ELE_creer_liste.h,v 1.2 2007/03/28 09:51:30 rlagha Exp $
 *   
 * HISTORY
 *   
 *   06/28/00 10:47 <       Brian Jantzen> Rel:ms8m1    SCCA:74542  Delta:81.3
 *   
 *   06/21/00 16:30 <       Brian Jantzen> Rel:ms8m1    SCCA:74307  Delta:81.2
 */

#ifndef __elecreerlisteh__
#define __elecreerlisteh__ 1

#ifndef __expmdbstructh__
#include "expmdb_struct.h"
#include "NOE_creer_liste.h"
#endif

/*#ifdef __cplusplus
extern "C" {
#endif*/

extern T_Element **ELE_creer_liste( int, T_Element **, int * );
  extern T_Element *ELE_creer_element( int nb_noeud, int *err );

/*#ifdef __cplusplus
}
#endif*/


#endif
