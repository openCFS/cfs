set line_count 0
set max_help 0
set max_html 0
set catch_g 0

puts "*** Issue  answish countem.tcl -H  for help"

set filearg [llength $argv]

if {$filearg > 0} {
   set filename [lindex $argv 0]
   if {$filename == "-get"} {
      catch {exec getcp ansys_Index.hlp > /dev/null} err
      set catch_g 1
   }
}

#
# Open file for reading
#
if {($filearg < 1) || ($catch_g == 1)} {
   set filename "ansys_Index.hlp"
   if [catch {open ansys_Index.hlp r} INDEX] {
      puts stderr "Could not open ansys_Index.hlp."
      exit 0
   }
} else {
   set filename [lindex $argv 0]
   if {$filename == "-H"} {
      puts "           *** Countem.tcl Help ***"
      puts ""
      puts "   This script takes an existing help command index, and adds"
      puts " or updates the first line, which contains the number of lines"
      puts " and the maximum sizes of the command and url fields."
      puts ""
      puts "   By default, countem.tcl operates on ansys_Index.hlp in the"
      puts " working directory and outputs new_ansys_Index.hlp."
      puts "   If countem.tcl is supplied with a file name, it will output"
      puts " new_(yourfilename)."
      puts ""
      puts " Ex:  answish countem.tcl           (Run countem on ansys_Index.hlp)"
      puts "      answish countem.tcl filename  (Run countem on filename)"
      puts "      answish countem.tcl -H        (Displays countem help)"
      exit 0
   } elseif [catch {open $filename r} INDEX] {
      puts stderr "Could not open $filename."
      exit 0
   }
}

#
# Determine the maximum lengths of the fields
#
foreach line [split [read $INDEX] \n] {
   if { [regexp {htm} $line] } {
      lappend CODE $line
      regsub {  *} $line { } line
      set templine $line
      set help_field [lindex [split $templine] 0]
      set templine $line
      set html_field [lindex [split $templine] 1]
      set help_field_length [string length $help_field]
      set html_field_length [string length $html_field]
      if {$help_field_length > $max_help} {
         set max_help $help_field_length
      }
      if {$html_field_length > $max_html} {
	 set max_html $html_field_length
      }
      incr line_count
   }
}
close $INDEX

incr max_help
incr max_html

#
# Open new file for writing
#
puts "Creating new_$filename ..."
if [catch {open new_$filename w} NEWINDEX] {
   puts stderr "Could not open new_$filename."
   exit 0
}

set prevcommand ""

#
# Sort lines and generate new file
#
puts $NEWINDEX "$line_count $max_help $max_html"

set SORTCODE [lsort $CODE]
foreach item $SORTCODE {
   puts $NEWINDEX "$item"

   set tempitem $item
   set command [lindex [split $tempitem] 0]
   if {$command == $prevcommand} {
      puts "*** Warning! Duplicate command encountered..."
      puts "*** $previtem"
      puts "*** $item"
      puts ""
   }
   set prevcommand $command
   set previtem $item
}
close $NEWINDEX

#normal exit
exit 0
