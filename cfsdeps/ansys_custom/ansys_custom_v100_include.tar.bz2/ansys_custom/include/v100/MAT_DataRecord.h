/* sid 50.1 copy of MAT_DataRecord.h last changed by upd111 on 2005/06/04 13:23:18 */
////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         Copyright (C) 2001 ANSYS Inc.  All Rights Reserved             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MAT_DataRecord.h $
// $Revision$ 7.0
// $Date$ October 21 2003
// $Author$ rjayasee
//
// Description :
//          Data Record Used for stress,strain...

////////////////////////////////////////////////////////////////////////////

#include "ANS_StandardIncludes.h"
#include "MAT_MemoryManager.h"

#if !defined(MAT_DataRecord_H)
#define MAT_DataRecord_H
/*

     $           LSTRAIN_T    =  1,
     $           LSTRESS_T    =  2,
     $           LSTRAINTH_T  =  3,
     $           LSTRAINPL_T  =  4,
     $           LEQPL_T      =  5,
     $           LSTRAINCR_T  =  6,
     $           LEQCR_T      =  7,
     $           LSTRAINI     =  8,
     &           LBACKSTRES_T =  9,
     &           LSTATEV_T    = 10,
     &           LEQSW_T      = 11,
     &           LSTRAIN_DEAD = 12,
     &           LCOORDS_T    = 13,
     &           LMISC_T      = 14,
     &           LPLDEFGRD_T  = 19,
     &           LRESIST_T    = 20
*/

enum MAT_RecordType
{
    MAT_UnknownRecordType = 0,
    MAT_StrainRecord = 1,
    MAT_StressRecord = 2,
    MAT_ThermalStrainRecord = 3,
    MAT_PlasticStrainRecord = 4,
    MAT_EquivPlasticStrainRecord = 5,
    MAT_CreepStrainRecord = 6,
    MAT_EquivalentCreepStrain = 7,
    MAT_InitialStrainRecord = 8,
    MAT_BackStressRecord = 9,
    MAT_StateVariablesRecord = 10,
    MAT_SwellingStrainRecord = 11,
    MAT_DeadElementStrainRecord = 12,
    MAT_IntegrPointsCoordRecord = 13,
    MAT_MiscellaneousRecord = 14,
    MAT_Unknown1 = 15,
    MAT_Unknown2 = 16,
    MAT_Unknown3 = 17,
    MAT_Unknown4 = 18,
    MAT_PlasticDeformationGradientRecord = 19,
    MAT_MechanicalResistanceRecord = 20,
} ;

static MAT_RecordType m_oRecordTypeIndex[21] =
{ MAT_UnknownRecordType ,
  MAT_StrainRecord ,
  MAT_StressRecord ,
  MAT_ThermalStrainRecord ,
  MAT_PlasticStrainRecord ,
  MAT_EquivPlasticStrainRecord ,
  MAT_CreepStrainRecord ,
  MAT_EquivalentCreepStrain,
  MAT_InitialStrainRecord ,
  MAT_BackStressRecord ,
  MAT_StateVariablesRecord ,
  MAT_SwellingStrainRecord ,
  MAT_DeadElementStrainRecord ,
  MAT_IntegrPointsCoordRecord ,
  MAT_MiscellaneousRecord ,
  MAT_Unknown1 ,
  MAT_Unknown2 ,
  MAT_Unknown3 ,
  MAT_Unknown4 ,
  MAT_PlasticDeformationGradientRecord ,
  MAT_MechanicalResistanceRecord 
} ;

static char m_oRecordTypeString[21][128] =
{ 
  "Unknow Type",
  "Strain" ,
  "Stress" ,
  "ThermalStrain" ,
  "PlasticStrain" ,
  "EquivPlasticStrain" ,
  "CreepStrain" ,
  "EquivCreepStrain" ,
  "InitialStrain" ,
  "BackStress" ,
  "StateVariables" ,
  "SwellingStrain" ,
  "DeadElementStrain" ,
  "IntegrPointsCoord" ,
  "Miscellaneous" ,
  "MAT_Unknown1"
  "MAT_Unknown2"
  "MAT_Unknown3"
  "MAT_Unknown4"
  "PlasticDeformationGradient" ,
  "MechanicalResistance" 
} ;

class MAT_DataRecord
{
    public:

    inline void * operator new(size_t iMemSize )
    {
            return MAT_FASTMALLOC(iMemSize) ;
    }

    inline void * operator new[]( size_t iSize )
    {
            return MAT_FASTMALLOC(sizeof(MAT_DataRecord)*iSize) ;
    }

    inline void operator delete(void * pMemPtr)
    {
            MAT_FASTFREE(pMemPtr) ;
    }

    inline void operator delete[](void * pMemPtr )
    {
        MAT_FASTFREE(pMemPtr) ;
    }

    MAT_DataRecord() ;
    //Constructor

    ~MAT_DataRecord() ;
    //Destructor

    void Print() ;
    //R void
    //- Prints Data Stored

    INT m_iSize ;
    //Size of the Record

    MAT_RecordType m_pRecordType ;
    //Record Type

    DOUBLE* m_pData ;
    //Data

    DOUBLE* m_pDataBackup ;
    //Data
};

#endif

