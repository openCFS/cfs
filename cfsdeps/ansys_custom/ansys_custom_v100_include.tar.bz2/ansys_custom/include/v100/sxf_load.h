/* sid 50.3 copy of sxf_load.h last changed by eedelor on 2005/06/02 12:41:10 */
/**
 * @file   sxf_load.h
 * @author Emmanuel Delor
 * @date   Wed Apr 20 05:08:26 EDT 2005
 * 
 * @brief  Extraction des chargements de pression, de convection, de flux
 * 
 */

#ifndef __SXF_LOAD__ 
#define __SXF_LOAD__ 1 

#include "cadoe.h"
#include "cadoe_set.h"
#include "computer.h"
#include "globals.h"
#include "ansysdef.h"
#include "cadoesys.h"
#include "CadoeAnsys.h"
#include "extmodl.h"
#include "elempr.h"

#if defined(LOWERCASENOUNDER_SYS)
#define cadoe_new_element_load 	cadoe_new_element_load
#define cadoe_new_node_load 	cadoe_new_node_load
#define cadoe_put_element_load 	cadoe_put_element_load
#define cadoe_put_node_load 	cadoe_put_node_load
#define FaceNodeList            facenodelist
#define eprget			eprget
#define ecvgetName	       	ecvgetname
#define ehfgetName	       	ehfgetname
#endif

#if defined(UPPERCASENOUNDER_SYS)
#define cadoe_new_element_load 	CADOE_NEW_ELEMENT_LOAD
#define cadoe_new_node_load 	CADOE_NEW_NODE_LOAD
#define cadoe_put_element_load 	CADOE_PUT_ELEMENT_LOAD
#define cadoe_put_node_load 	CADOE_PUT_NODE_LOAD
#define FaceNodeList            FACENODELIST
#define eprget			EPRGET
#define ecvgetName	       	ECVGETNAME
#define ehfgetName	       	EHFGETNAME
#endif

#if defined(LOWERCASEUNDER_SYS)
#define cadoe_new_element_load 	cadoe_new_element_load_
#define cadoe_new_node_load 	cadoe_new_node_load_
#define cadoe_put_element_load 	cadoe_put_element_load_
#define cadoe_put_node_load 	cadoe_put_node_load_
#define FaceNodeList            facenodelist_
#define eprget			eprget_
#define ecvgetName	       	ecvgetname_
#define ehfgetName	       	ehfgetname_
#endif

#ifdef __cplusplus
extern "C" {
#endif
  
  SUBROUTINE cadoe_new_element_load();
  SUBROUTINE cadoe_new_node_load();
  SUBROUTINE cadoe_put_element_load(INT *ielem, INT *iface);
  SUBROUTINE cadoe_put_node_load(INT *inode);
  SUBROUTINE FaceNodeList(INT *face, INT *ielc, INT *nodes, INT *nb_nodes, INT *fnodes);
  INT FUNCTION eprget(INT *, INT*, DOUBLE*);
  INT FUNCTION ecvgetName(INT *, INT*, INT*, INT*, DOUBLE*, FCHAR(c1) FCHARL(c1_len));
  INT FUNCTION ehfgetName(INT *, INT*, INT*, INT*, DOUBLE*, FCHAR(c1) FCHARL(c1_len));
#ifdef __cplusplus
}
#endif 

#define EL_TYPE 1

class C_ElementaryLoad
{
public:
  C_ElementaryLoad() {};
  virtual ~C_ElementaryLoad() {};

  int getNumero() {return _numero;}

protected:
  int _numero;
};

class C_NodeLoad : public C_ElementaryLoad
{
public:
  C_NodeLoad(int node) {_numero = node;};
  ~C_NodeLoad() {};
};

class C_ElementLoad : public C_ElementaryLoad
{
public:
  C_ElementLoad(int element, int face) {_numero = element, _face = face;};
  ~C_ElementLoad() {};
  
  int getFace()	   {return _face;   };
  
  void
  getFaceNodeList(int &nb_nodes, int fnodes[4])
  {  
    int ielc[IELCSZ+1];
    int elmdat[EL_DIM+1];
    int nodes[NNMAX+1];
    int itype;
    
    elmget(&_numero,elmdat,nodes);
    itype = elmdat[EL_TYPE];
    etyget(&itype,ielc);
    
    FaceNodeList(&_face,ielc,nodes,&nb_nodes,fnodes);
    
    return;
  }
  
protected:
  int _face;
};

class C_load
{
public:
  enum E_typeChargement
    {
      ELEMENTS,
      NOEUDS
    };

  C_load(E_typeChargement typeChargement) {_typeChargement = typeChargement;};
  ~C_load() 
    {
      for (C_ElementaryLoad *entitie = First(); entitie != NULL; entitie = Next())
	delete entitie;
    };
  
  E_typeChargement getTypeLoad() {return _typeChargement;};
  void insert(C_ElementaryLoad *entitie) { _setEntities.insert(entitie);};
  int  Dim() {return _setEntities.size();}
  void Print(FILE * fp) 
  {
    C_ElementaryLoad *entitie;
    switch (_typeChargement)
      {
      case ELEMENTS:
	fprintf(fp,"Chargement aux elements: \n"); 
	entitie = First();
	if (entitie != NULL) 
	  fprintf(fp,"esel,s,,,%d\n",entitie->getNumero());
	while (entitie != NULL)
	  {
	    fprintf(fp,"esel,a,,,%d\n",entitie->getNumero());
	    entitie = Next();
	  }
	break;
      case NOEUDS:
	fprintf(fp,"Chargement aux noeuds: \n");
	entitie = First();
	if (entitie != NULL) 
	  fprintf(fp,"nsel,s,,,%d\n",entitie->getNumero());
	while (entitie != NULL)
	  {
	    fprintf(fp,"nsel,a,,,%d\n",entitie->getNumero());
	    entitie = Next();
	  }
	break;
      }

  }
  
  C_ElementaryLoad* First()
  {
    _itentities = _setEntities.begin(); 
    if (_itentities == _setEntities.end()) return NULL;
    else return (*_itentities);
  }
  C_ElementaryLoad* Next()
  {
    _itentities++; 
    if (_itentities == _setEntities.end()) return NULL;
    else return (*_itentities);
  };
  
protected:
  set<C_ElementaryLoad*> _setEntities;  // ensemble des entites composant le chargement
  E_typeChargement	 _typeChargement;
  set<C_ElementaryLoad*>::iterator _itentities;
};

typedef set<C_load *> C_listLoad;

C_listLoad * cadoe_get_loadSet();
T_statut ITF_read_load(T_modele *modele);
void sxf_load_free();

#endif
 
