/* sid 50.1 copy of sx_adrel.h last changed by upd111 on 2005/06/04 13:23:04 */
/* CADOE */
/**
 *	adrel.h -- constantes attachees aux objets adressage de l'element
 *
 *  |Version: $Id$
 *   
 * HISTORY
 *   
 *   09/25/00 10:39 <       Brian Jantzen> Rel:ms8m1    SCCA:79107  Delta:81.2
 *   
 *   02/15/00 12:22 <       Brian Jantzen> Rel:ms8      SCCA:68558  Delta:8.3
 *   
 *   09/30/99 17:38 <         James Silva> Rel:ms8      SCCA:56512  Delta:8.2
 **/
#include "sx_CADOE_solver.h"
#ifndef __ADREL_X_DEJA_INCLUS__
#define __ADREL_X_DEJA_INCLUS__ 1

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

extern T_statut ADE_creer_adressage_element (int, int, int, T_adr_elem **);
extern T_statut ADE_cre_tab_adressage_element (void);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif	 /* __ADREL_X_DEJA_INCLUS__ */
