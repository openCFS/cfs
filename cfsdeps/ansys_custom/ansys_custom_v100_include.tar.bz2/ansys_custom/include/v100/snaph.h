/* sid 50.1 copy of snaph.h last changed by upd111 on 2005/06/04 13:14:04 */
/* 
 * *** ansys(r) copyright(c) 2000
 * *** ansys, inc.
 */
struct snap_struct {
     int     num;
     Widget  shell;
     Widget  swidget;
     Pixmap  snap_pix;
     int     height;
     int     width;
     Boolean snapover;
     char    name[81];
    };
