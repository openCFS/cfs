/* sid 50.1 copy of FEM_coIds.h last changed by upd111 on 2004/11/04 18:30:27 */
/*  FEM_coIds.h */
/*
 * *** ansys(r) copyright(c) 1999
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_coIds.h
 *  header file for FEM_coIds.c
 *
 */

/*************************************************************************/
/*********** INSTRUCTIONS FOR USING THIS MODULE **************************/
/*************************************************************************/
/* this module is used to keep track of entity ids in the C meshing data */
/* base.  Currently it stored both node and elem ids.  It is used to     */
/* avoid problems with gaps in the numbering of nodes and elements in    */
/* the native database.  Before this module can be used it must be       */
/* initialized by calling FEM_coInitIds().  After that you can save ids  */
/* by calling either FEM_coSaveNodeId or FEM_coSaveElemId.               */
/* FEM_coNewElemId or FEM_coNewNodeId can be called to get an id out of  */
/* the list.  If the list is empty, a unique default id is returned that */
/* is greater than the max value sent to FEM_coInitIds is returned.      */
/* FEM_coGetSavedIds returns a list of the ids currently saved.          */
/* FEM_coGetUsedIds returns a list of all ids saved since the last time  */
/* FEM_coInitIds was called including all ids popped of the list by      */
/* FEM_coNewElemId or FEM_coNewNodeId                                    */
/*************************************************************************/
/*************************************************************************/
#ifndef FEM_COIDS_INCLUDE
#define FEM_COIDS_INCLUDE

/*-------------- Globally accessible function prototypes -----------------*/

#ifdef __cplusplus
extern "C" {
#endif

              /* ======================================================== */
              /* === FEM_coClearSavedIds: Initialize this file to save    */
              /* === and process ids.                                     */
              /* ======================================================== */
void FEM_coInitIds (
   INT maxnodeid,       /* (IN) the number at which the next elem will be */
                        /*      numbered                                  */
   INT maxelemid,       /* (IN) the number at which the next node will be */
                        /*      numbered                                  */
   INT save_ids  );     /* (IN) If module will save deleted ids or just   */
                        /*      create new ones                           */

              /* ======================================================== */
              /* === FEM_coResetMaxElemId: reset the value at which any   */
              /* === new element id will begin.                           */
              /* ======================================================== */
INT FEM_coResetMaxElemId (
   INT newmax  );

              /* ======================================================== */
              /* === FEM_coResetMaxNodeId: reset the value at which any   */
              /* === new node id will begin.                              */
              /* ======================================================== */
INT FEM_coResetMaxNodeId (
   INT newmax  );       /* (IN) the new max id                            */

              /* ======================================================== */
              /* === FEM_coGetMaxNodeId: get the highest id of any node   */
              /* === in the mesh.  This number should be retrieved for    */
              /* === inspection only.  Do not try to manipulate or change */
              /* === this number                                          */
              /* ======================================================== */
INT FEM_coGetMaxNodeId (void );

              /* ======================================================== */
              /* === FEM_coGetMaxElemId: get the highest id of any elem   */
              /* === in the mesh.  This number should be retrieved for    */
              /* === inspection only.  Do not try to manipulate or change */
              /* === this number                                          */
              /* ======================================================== */
INT FEM_coGetMaxElemId (void );

              /* ======================================================== */
              /* === FEM_coGetFirstMaxNodeId: Get the id that was the max */
              /* === node id when FEM_coInitIds was called.  This should  */
              /* === be retrieved for inspection only.  Do not try to     */
              /* === manipulate or change this number.  FEM_coInitIds     */
              /* === must have already been called.                       */
              /* ======================================================== */
INT FEM_coGetFirstMaxNodeId (void );

              /* ======================================================== */
              /* === FEM_coGetFirstMaxElemId: Get the id that was the max */
              /* === elem id when FEM_coInitIds was called.  This should  */
              /* === be retrieved for inspection only.  Do not try to     */
              /* === manipulate or change this number.  FEM_coInitIds     */
              /* === must have already been called.                       */
              /* ======================================================== */
INT FEM_coGetFirstMaxElemId (void );

              /* ======================================================== */
              /* === FEM_coClearSavedIds: Free up memory used in this     */
              /* === module and initialize                                */
              /* ======================================================== */
INT FEM_coClearSavedIds (void );

              /* ======================================================== */
              /* === FEM_coSaveElemId: Save a elem in a file global so it */
              /* === can be used later.                                   */
              /* ======================================================== */
INT FEM_coSaveElemId (
   INT elem_id  );      /* (IN) the elem id to be saved                   */

              /* ======================================================== */
              /* === FEM_coSaveNodeId: Save a node in a file global so it */
              /* === can be used later.                                   */
              /* ======================================================== */
INT FEM_coSaveNodeId (
   INT node_id  );      /* (IN) the node id to be saved                   */

              /* ======================================================== */
              /* === FEM_coGetSavedNodeIds: Get a list of the saved node  */
              /* === ids.  DO NOT free the array that is returned.        */
              /* === Return: INT * pointer to list of ids.                */
              /* ======================================================== */
INT *FEM_coGetSavedNodeIds (
   INT *num_ids  );     /* (IN) number of ids returned                    */

              /* ======================================================== */
              /* === FEM_coGetPoppedNodeIds: Get a list of all nodes      */
              /* === stored in the list and then later returned by        */
              /* === FEM_coNewNodeId.  DO NOT free the array that is      */
              /* === returned.                                            */
              /* === Return: INT * pointer to list of ids.                */
              /* ======================================================== */
INT *FEM_coGetReusedNodeIds (
   INT *num_ids  );     /* (IN) number of ids returned                    */

              /* ======================================================== */
              /* === FEM_coGetSavedElemIds: Get a list of the saved elem  */
              /* === ids.  DO NOT free the array that is returned.        */
              /* === Return: INT * pointer to list of ids.                */
              /* ======================================================== */
INT *FEM_coGetSavedElemIds (
   INT *num_ids  );     /* (IN) number of ids returned                    */

              /* ======================================================== */
              /* === FEM_coGetPoppedElemIds: Get a list of all elems      */
              /* === stored in the list and then later returned by        */
              /* === FEM_coNewElemId.  DO NOT free the array that is      */
              /* === returned.                                            */
              /* === Return: INT * pointer to list of ids.                */
              /* ======================================================== */
INT *FEM_coGetReusedElemIds (
   INT *num_ids  );     /* (IN) number of ids returned                    */

              /* ======================================================== */
              /* === FEM_coNewNodeId: Pop a node id off of the saved list */
              /* === or get a new one completely.                         */
              /* ======================================================== */
INT FEM_coNewNodeId (void );

              /* ======================================================== */
              /* === FEM_coNewElemId: Pop a elem id off of the saved list */
              /* === or get a new one completely.                         */
              /* ======================================================== */
INT FEM_coNewElemId (void );

#ifdef __cplusplus
}
#endif

#endif
