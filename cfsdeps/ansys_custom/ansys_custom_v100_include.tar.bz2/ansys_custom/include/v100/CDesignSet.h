/* sid 50.1 copy of CDesignSet.h last changed by upd111 on 2005/06/04 13:21:12 */
/*! \file CDesignSet.h

  \brief This header file defines the CDesignSet class.

  \author Stephane MARGUERIN &copy; CADOE

  \date Juin 2002

  \version $Id$
*/
#ifndef __CDesignSet_h__ 
#define __CDesignSet_h__ 1 

#include "cadoe_map.h"
#include "cadoe_list.h"
#include "cadoe_string.h"


/*! \class CDesignSet CDesignSet.h
  \brief The CDesignSet class is used to describe a set of parameter values.
*/
class CDesignSet
{
public:

	typedef map<string,double> ParamValues;
	typedef map<int,double> CritValues;
	typedef map<int,int> IntCritValues;

	CDesignSet() { _x=0; _y=0; }
	CDesignSet( const CDesignSet &set );
	CDesignSet( const CDesignSet &majorSet, list<string> &majorParam, const CDesignSet &minorSet );
	~CDesignSet() {	resetParameters(); resetResults(); }

	CDesignSet& operator = ( const CDesignSet &set);

	int getNumberOfParameters( void ) const { return (int)_values.size(); }

	void resetParameter( const string &pName ) { _values.erase(pName); }

	void resetParameters( void ) { _values.clear(); }
	void resetResult(  int critId ) { _results.erase(critId); _accuracy.erase(critId); _location.erase(critId); }
	void resetResults(void) { _results.clear(); _accuracy.clear(); _location.clear(); }
	void reset(void) { resetParameters(); resetResults(); }

	void setName( const string &name ) { _name = name; }
	string getName( void ) const { return _name; }

	void setResult(  int critId, double res, double accuracy=0. ) 
		{ _results[critId] = res; _accuracy[critId] = accuracy; }
	void setResult(  int critId, double res, int location, double accuracy=0. ) 
		{ _results[critId] = res; _accuracy[critId] = accuracy; _location[critId] = location; }

	bool isEvaluated(  int critId=-1 ) const;
	double getResult(  int critId=-1 ) const;
	double getAccuracy(  int critId=-1 ) const;
	int getLocation( int critId=-1 ) const;

	void setValue( const string &pName, const double val ) { _values[pName] = val; }
	void setValues( const ParamValues &pval ) { _values = pval; }
	double getValue( const string &pName="" ) const;
	int getValues( ParamValues &pval) const;

	void print( void ) const;

	bool parameterIsSet( const string &pName ) const;
	CDesignSet* generateMiddleSet( CDesignSet &set, double ratio ) const;

	
	void setX( double x ) { _x=x; }
	void setY( double y ) { _y=y; }
	double getX(void) const { return _x; }
	double getY(void) const { return _y; }

private:
	string			  _name;		// name of the design set, if any
	ParamValues		_values;	// value for each parameter name
	CritValues		_results;	// scalar result for each critId
	CritValues		_accuracy; // accuracy for each critId
	IntCritValues		_location; // location for each critId
	double        _x; // x coordinate in a plot grid
	double        _y; // y coordinate in a plot grid 
};


#endif
