/* sid 50.5 copy of sifapi.h last changed by qzhang on 2005/04/07 20:01:09 */
/*
 * @author: Glenn Wettlaufer
 * @version: $Revision$
 * @date: $Date$
 * $Id$
 */
/*
 *      SUBROUTINE SIF_AcknowledgeRequest(pSocket, iErr)
 *          INTEGER         pSocket                 <- (I)
 *          INTEGER         iErr                    <- (I/O)
 *
 *      SUBROUTINE SIF_ErrorMsg(iErr, Msg)
 *          INTEGER         iErr                    <- (I)
 *          CHARACTER*(*)   Msg                     <- (O)
 *
 *      SUBROUTINE SIF_GetIntegerData(pSocket, ProcName, Attribute, Family,
 *     &                              What, Where, When, nDataTot, iDataS,
 *     &                              iDataF, RetData, iErr)
 *          INTEGER         pSocket                 <- (I)
 *          CHARACTER*(*)   ProcName                <- (I)
 *          CHARACTER*(*)   Attribute               <- (I)
 *          CHARACTER*(*)   Family                  <- (I)
 *          CHARACTER*(*)   What                    <- (I)
 *          CHARACTER*(*)   Where                   <- (I)
 *          CHARACTER*(*)   When                    <- (I)
 *          INTEGER         nDataTot                <- (I)
 *          INTEGER         iDataS                  <- (I)
 *          INTEGER         iDataF                  <- (O)
 *          INTEGER         RetData(*)              <- (O)
 *          INTEGER         iErr
 *
 *      SUBROUTINE SIF_GetRealData(pSocket, ProcName, Attribute, Family, What, 
 *     &                           Where, When, nDataTot, iDataS, iDataF, 
 *     &                           RetData, iErr)
 *          INTEGER         pSocket                 <- (I)
 *          CHARACTER*(*)   ProcName                <- (I)
 *          CHARACTER*(*)   Attribute               <- (I)
 *          CHARACTER*(*)   Family                  <- (I)
 *          CHARACTER*(*)   What                    <- (I)
 *          CHARACTER*(*)   Where                   <- (I)
 *          CHARACTER*(*)   When                    <- (I)
 *          INTEGER         nDataTot                <- (I)
 *          INTEGER         iDataS                  <- (I)
 *          INTEGER         iDataF                  <- (I)
 *          REAL            RetData(*)              <- (O)
 *          INTEGER         iErr                    <- (O)
 *
 *      SUBROUTINE SIF_GetDoubleData(pSocket, ProcName, Attribute, Family, What,
 *     &                             Where, When, nDataTot, iDataS, iDataF,
 *     &                             RetData, iErr)
 *          INTEGER         pSocket                 <- (I)
 *          CHARACTER*(*)   ProcName                <- (I)
 *          CHARACTER*(*)   Attribute               <- (I)
 *          CHARACTER*(*)   Family                  <- (I)
 *          CHARACTER*(*)   What                    <- (I)
 *          CHARACTER*(*)   Where                   <- (I)
 *          CHARACTER*(*)   When                    <- (I)
 *          INTEGER         nDataTot                <- (I)
 *          INTEGER         iDataS                  <- (I)
 *          INTEGER         iDataF                  <- (I)
 *          DOUBLE          RetData(*)              <- (O)
 *          INTEGER         iErr                    <- (O)
 *
 *      SUBROUTINE SIF_GetLocalHostName(name, iErr)
 *          CHARACTER*(*)   name                    <- (O)
 *          INTEGER         iErr                    <- (O)
 *
 *      SUBROUTINE SIF_GetNextRequest(pSocket, ProcName, Request, Attribute,
 *     &                              Family, What, Where, When, Message, iErr)
 *          INTEGER         pSocket                 <- (I/O)
 *          CHARACTER*(*)   ProcName                <- (O)
 *          CHARACTER*(*)   Request                 <- (O)
 *          CHARACTER*(*)   Attribute               <- (O)
 *          CHARACTER*(*)   Family                  <- (O)
 *          CHARACTER*(*)   What                    <- (O)
 *          CHARACTER*(*)   Where                   <- (O)
 *          CHARACTER*(*)   When                    <- (O)
 *          CHARACTER*(*)   Message                 <- (O)
 *          INTEGER         iErr                    <- (O)
 *
 *      SUBROUTINE SIF_GetStringData(pSocket, ProcName, Attribute, Family, What,
 *     &                             Where, When, nDataTot, iDataS, iDataF,
 *     &                             RetData, iErr)
 *          INTEGER         pSocket                 <- (I)
 *          CHARACTER*(*)   ProcName                <- (I)
 *          CHARACTER*(*)   Attribute               <- (I)
 *          CHARACTER*(*)   Family                  <- (I)
 *          CHARACTER*(*)   What                    <- (I)
 *          CHARACTER*(*)   Where                   <- (I)
 *          CHARACTER*(*)   When                    <- (I)
 *          INTEGER         nDataTot                <- (I)
 *          INTEGER         iDataS                  <- (I)
 *          INTEGER         iDataF                  <- (I)
 *          CHARACTER*(*)   RetData(*)              <- (O)
 *          INTEGER         iErr                    <- (O)
 *
 *      SUBROUTINE SIF_PutIntegerData(pSocket, nDataTot, iDataS, iDataF,
 *     &                              RetData, iErr)
 *          INTEGER         pSocket                 <- (I)
 *          INTEGER         nDataTot                <- (I)
 *          INTEGER         iDataS                  <- (I)
 *          INTEGER         iDataF                  <- (I)
 *          INTEGER         RetData(*)              <- (I)
 *          INTEGER         iErr                    <- (I/O)
 *
 *      SUBROUTINE SIF_PutRealData(pSocket, nDataTot, iDataS, iDataF, RetData,
 *     &                           iErr)
 *          INTEGER         pSocket                 <- (I)
 *          INTEGER         nDataTot                <- (I)
 *          INTEGER         iDataS                  <- (I)
 *          INTEGER         iDataF                  <- (I)
 *          REAL            RetData(*)              <- (I)
 *          INTEGER         iErr                    <- (I/O)
 *
 *      SUBROUTINE SIF_PutDoubleData(pSocket, nDataTot, iDataS, iDataF, RetData,
 *     &                             iErr)
 *          INTEGER         pSocket                 <- (I)
 *          INTEGER         nDataTot                <- (I)
 *          INTEGER         iDataS                  <- (I)
 *          INTEGER         iDataF                  <- (I)
 *          DOUBLE          RetData(*)              <- (I)
 *          INTEGER         iErr                    <- (I/O)
 *
 *      SUBROUTINE SIF_PutError(pSocket, iErr)
 *          INTEGER         pSocket                 <- (I)
 *          INTEGER         iErr                    <- (I/O)
 *
 *      SUBROUTINE SIF_PutStringData(pSocket, nDataTot, iDataS, iDataF, RetData,
 *     &                             iErr)
 *          INTEGER         pSocket                 <- (I)
 *          INTEGER         nDataTot                <- (I)
 *          INTEGER         iDataS                  <- (I)
 *          INTEGER         iDataF                  <- (I)
 *          CHARACTER*(*)   RetData(*)              <- (I)
 *          INTEGER         iErr                    <- (I/O)
 *
 *      SUBROUTINE SIF_SendCommand(pSocket, ProcName, CmdRequest, Attribute,
 *     &                           Message, iErr)
 *          INTEGER         pSocket                 <- (I)
 *          CHARACTER*(*)   ProcName                <- (I)
 *          CHARACTER*(*)   CmdRequest              <- (I)
 *          CHARACTER*(*)   Attribute               <- (I)
 *          CHARACTER*(*)   Message                 <- (I)
 *          INTEGER         iErr                    <- (O)
 *
 *      SUBROUTINE SIF_SocketClose(pSocket)
 *          INTEGER         pSocket                 <- (I)
 *
 *      SUBROUTINE SIF_SocketCreateClientSide(TimeOut, Port, HostName, pSocket,
 *     &                                      iErr)
 *          INTEGER         TimeOut                 <- (I)
 *          INTEGER         Port                    <- (I)
 *          CHARACTER*(*)   HostName                <- (I)
 *          INTEGER         pSocket                 <- (O)
 *          INTEGER         iErr                    <- (O)
 *
 *      SUBROUTINE SIF_SocketCreateServerSide(Port, pGSocket, iErr)
 *          INTEGER         Port                    <- (I/O)
 *          INTEGER         pGSocket                <- (O)
 *          INTEGER         iErr                    <- (O)
 *
 *      SUBROTUINE SIF_SocketWaitForConnection(TimeOut, pGSocket, pSocket, iErr)
 *          INTEGER         TimeOut                 <- (I)
 *          INTEGER         pGSocket                <- (I)
 *          INTEGER         pSocket                 <- (O)
 *          INTEGER         iErr                    <- (O)
 */
#ifndef _INCLUDED_SIFAPI_H_
#define _INCLUDED_SIFAPI_H_

/*  computercfx.h is to define CFX machine name, for Ansys use only */
#include "computercfx.h"

#ifdef ANSYS_SYS
#include "cfx_fproto.h"
#else
#include <cfx_fproto.h>
#endif
#include "ipcapi.h"


#ifdef __cplusplus
extern "C" {
#endif

/* these error codes must be between -1000 and -9999 */
#define ERROR_SIF_OK                0
#define ERROR_SIF_FIRST            -1000
#define ERROR_SIF_MEMORYALLOCATION -1000
#define ERROR_SIF_BADARGS          -1001
#define ERROR_SIF_UNKNOWN          -1002

#define ERROR_SIF_MESSAGES  \
{ \
    "Can't allocate memory", \
    "Invalid function arguments" \
}


/* this stuff should be moved to some common area */
typedef char    Fchar;
#ifdef INTEGER_8
typedef int_8   Fint;
#else
typedef int_4   Fint;
#endif
#ifdef CFX5_ATTR_DOUBLE
typedef float_8 Freal;
#else
typedef float_4 Freal;
#endif
#ifdef DOUBLE_16
typedef float_16    Fdouble;
#else
typedef float_8 Fdouble;
#endif
/* this is the (char *) length passed in by fortran */
typedef F_LENGTH_T  Flen;


/* this is going to be ugly */


/*
 *  this section maps from a made up name to the object file name
 */
#ifdef CFX5_OS_WINNT

#define STDCALL __stdcall

#define _SIF_AcknowledgeRequest_        SIF_ACKNOWLEDGEREQUEST
#define _SIF_ErrorMsg_                  SIF_ERRORMSG
#define _SIF_GetIntegerData_            SIF_GETINTEGERDATA
#define _SIF_GetRealData_               SIF_GETREALDATA
#define _SIF_GetDoubleData_             SIF_GETDOUBLEDATA
#define _SIF_GetLocalHostName_          SIF_GETLOCALHOSTNAME
#define _SIF_GetNextRequest_            SIF_GETNEXTREQUEST
#define _SIF_GetStringData_             SIF_GETSTRINGDATA
#define _SIF_PutIntegerData_            SIF_PUTINTEGERDATA
#define _SIF_PutRealData_               SIF_PUTREALDATA
#define _SIF_PutDoubleData_             SIF_PUTDOUBLEDATA
#define _SIF_PutError_                  SIF_PUTERROR
#define _SIF_PutStringData_             SIF_PUTSTRINGDATA
#define _SIF_SendCommand_               SIF_SENDCOMMAND
#define _SIF_SocketClose_               SIF_SOCKETCLOSE
#define _SIF_SocketCreateClientSide_    SIF_SOCKETCREATECLIENTSIDE
#define _SIF_SocketCreateServerSide_    SIF_SOCKETCREATESERVERSIDE
#define _SIF_SocketWaitForConnection_   SIF_SOCKETWAITFORCONNECTION

#elif defined UNDERSCORE_DBL

#define STDCALL

#define _SIF_AcknowledgeRequest_        sif_acknowledgerequest__
#define _SIF_ErrorMsg_                  sif_errormsg__
#define _SIF_GetIntegerData_            sif_getintegerdata__
#define _SIF_GetRealData_               sif_getrealdata__
#define _SIF_GetDoubleData_             sif_getdoubledata__
#define _SIF_GetLocalHostName_          sif_getlocalhostname__
#define _SIF_GetNextRequest_            sif_getnextrequest__
#define _SIF_GetStringData_             sif_getstringdata__
#define _SIF_PutIntegerData_            sif_putintegerdata__
#define _SIF_PutRealData_               sif_putrealdata__
#define _SIF_PutDoubleData_             sif_putdoubledata__
#define _SIF_PutError_                  sif_puterror__
#define _SIF_PutStringData_             sif_putstringdata__
#define _SIF_SendCommand_               sif_sendcommand__
#define _SIF_SocketClose_               sif_socketclose__
#define _SIF_SocketCreateClientSide_    sif_socketcreateclientside__
#define _SIF_SocketCreateServerSide_    sif_socketcreateserverside__
#define _SIF_SocketWaitForConnection_   sif_socketwaitforconnection__

#elif defined UNDERSCORE

#define STDCALL

#define _SIF_AcknowledgeRequest_        sif_acknowledgerequest_
#define _SIF_ErrorMsg_                  sif_errormsg_
#define _SIF_GetIntegerData_            sif_getintegerdata_
#define _SIF_GetRealData_               sif_getrealdata_
#define _SIF_GetDoubleData_             sif_getdoubledata_
#define _SIF_GetLocalHostName_          sif_getlocalhostname_
#define _SIF_GetNextRequest_            sif_getnextrequest_
#define _SIF_GetStringData_             sif_getstringdata_
#define _SIF_PutIntegerData_            sif_putintegerdata_
#define _SIF_PutRealData_               sif_putrealdata_
#define _SIF_PutDoubleData_             sif_putdoubledata_
#define _SIF_PutError_                  sif_puterror_
#define _SIF_PutStringData_             sif_putstringdata_
#define _SIF_SendCommand_               sif_sendcommand_
#define _SIF_SocketClose_               sif_socketclose_
#define _SIF_SocketCreateClientSide_    sif_socketcreateclientside_
#define _SIF_SocketCreateServerSide_    sif_socketcreateserverside_
#define _SIF_SocketWaitForConnection_   sif_socketwaitforconnection_

#else

#define STDCALL

#define _SIF_AcknowledgeRequest_        sif_acknowledgerequest
#define _SIF_ErrorMsg_                  sif_errormsg
#define _SIF_GetIntegerData_            sif_getintegerdata
#define _SIF_GetRealData_               sif_getrealdata
#define _SIF_GetDoubleData_             sif_getdoubledata
#define _SIF_GetLocalHostName_          sif_getlocalhostname
#define _SIF_GetNextRequest_            sif_getnextrequest
#define _SIF_GetStringData_             sif_getstringdata
#define _SIF_PutIntegerData_            sif_putintegerdata
#define _SIF_PutRealData_               sif_putrealdata
#define _SIF_PutDoubleData_             sif_putdoubledata
#define _SIF_PutError_                  sif_puterror
#define _SIF_PutStringData_             sif_putstringdata
#define _SIF_SendCommand_               sif_sendcommand
#define _SIF_SocketClose_               sif_socketclose
#define _SIF_SocketCreateClientSide_    sif_socketcreateclientside
#define _SIF_SocketCreateServerSide_    sif_socketcreateserverside
#define _SIF_SocketWaitForConnection_   sif_socketwaitforconnection

#endif

/*
 *  this section maps from an api name to a made up name.  It also takes care
 *  of any parameter swapping required by WINNT
 */
#if defined (CFX5_OS_WINNT) && !defined(ARGTRAIL)

#define SIF_AcknowledgeRequest      _SIF_AcknowledgeRequest_
#define SIF_ErrorMsg                _SIF_ErrorMsg_
#define SIF_GetIntegerData(pSocket, ProcName, Attribute, Family, What, Where, \
                           When, nDataTot, iDataS, iDataF, RetData, iErr, \
                           ProcNameLen, AttributeLen, FamilyLen, WhatLen, \
                           WhereLen, WhenLen) \
        _SIF_GetIntegerData_(pSocket, ProcName, ProcNameLen, Attribute, \
                             AttributeLen, Family, FamilyLen, What, WhatLen, \
                             Where, WhereLen, When, WhenLen, nDataTot, iDataS, \
                             iDataF, RetData, iErr)
#define SIF_GetDoubleData(pSocket, ProcName, Attribute, Family, What, Where, \
                          When, nDataTot, iDataS, iDataF, RetData, iErr, \
                          ProcNameLen, AttributeLen, FamilyLen, WhatLen, \
                          WhereLen, WhenLen) \
        _SIF_GetDoubleData_(pSocket, ProcName, ProcNameLen, Attribute, \
                            AttributeLen, Family, FamilyLen, What, WhatLen, \
                            Where, WhereLen, When, WhenLen, nDataTot, iDataS, \
                            iDataF, RetData, iErr)
#define SIF_GetLocalHostName(name, iErr, nameLen) \
        _SIF_GetLocalHostName_(name, nameLen, iErr)
#define SIF_GetNextRequest(pSocket, ProcName, Request, Attribute, Family, \
                           What, Where, When, Message, iErr, ProcNameLen, \
                           RequestLen, AttributeLen, FamilyLen, WhatLen, \
                           WhereLen, WhenLen, MessageLen) \
        _SIF_GetNextRequest_(pSocket, ProcName, ProcNameLen, Request, \
                             RequestLen, Attribute, AttributeLen, Family, \
                             FamilyLen, What, WhatLen, Where, WhereLen, When, \
                             WhenLen, Message, MessageLen, iErr)
#define SIF_GetRealData(pSocket, ProcName, Attribute, Family, What, Where, \
                        When, nDataTot, iDataS, iDataF, RetData, iErr, \
                        ProcNameLen, AttributeLen, FamilyLen, WhatLen, \
                        WhereLen, WhenLen) \
        _SIF_GetRealData_(pSocket, ProcName, ProcNameLen, Attribute, \
                          AttributeLen, Family, FamilyLen, What, WhatLen, \
                          Where, WhereLen, When, WhenLen, nDataTot, iDataS, \
                          iDataF, RetData, iErr)
#define SIF_GetStringData(pSocket, ProcName, Attribute, Family, What, Where, \
                          When, nDataTot, iDataS, iDataF, RetData, iErr, \
                          ProcNameLen, AttributeLen, FamilyLen, WhatLen, \
                          WhereLen, WhenLen, RetDataLen) \
        _SIF_GetStringData_(pSocket, ProcName, ProcNameLen, Attribute, \
                            AttributeLen, Family, FamilyLen, What, WhatLen, \
                            Where, WhereLen, When, WhenLen, nDataTot, iDataS, \
                            iDataF, RetData, RetDataLen, iErr)
#define SIF_PutIntegerData          _SIF_PutIntegerData_
#define SIF_PutDoubleData           _SIF_PutDoubleData_
#define SIF_PutError                _SIF_PutError_
#define SIF_PutRealData             _SIF_PutRealData_
#define SIF_PutStringData(pSocket, nDataTot, iDataS, iDataF, RetData, iErr, \
                          RetDataLen) \
        _SIF_PutStringData_(pSocket, nDataTot, iDataS, iDataF, RetData, \
                            RetDataLen, iErr)
#define SIF_SendCommand(pSocket, ProcName, Cmd, Arg, Msg, iErr, ProcNameLen, \
                        CmdLen, ArgLen, MsgLen) \
        _SIF_SendCommand_(pSocket, ProcName, ProcNameLen, Cmd, CmdLen, Arg, \
                          ArgLen, Msg, MsgLen, iErr)
#define SIF_SocketClose             _SIF_SocketClose_
#define SIF_SocketCreateClientSide(TimeOut, Port, HostName, pSocket, iErr, \
                                   HostNameLen) \
        _SIF_SocketCreateClientSide_(TimeOut, Port, HostName, HostNameLen, \
                                     pSocket, iErr)
#define SIF_SocketCreateServerSide  _SIF_SocketCreateServerSide_
#define SIF_SocketWaitForConnection _SIF_SocketWaitForConnection_

#else

#define SIF_AcknowledgeRequest      _SIF_AcknowledgeRequest_
#define SIF_ErrorMsg                _SIF_ErrorMsg_
#define SIF_GetIntegerData          _SIF_GetIntegerData_
#define SIF_GetDoubleData           _SIF_GetDoubleData_
#define SIF_GetLocalHostName        _SIF_GetLocalHostName_
#define SIF_GetNextRequest          _SIF_GetNextRequest_
#define SIF_GetRealData             _SIF_GetRealData_
#define SIF_GetStringData           _SIF_GetStringData_
#define SIF_PutIntegerData          _SIF_PutIntegerData_
#define SIF_PutDoubleData           _SIF_PutDoubleData_
#define SIF_PutError                _SIF_PutError_
#define SIF_PutRealData             _SIF_PutRealData_
#define SIF_PutStringData           _SIF_PutStringData_
#define SIF_SendCommand             _SIF_SendCommand_
#define SIF_SocketClose             _SIF_SocketClose_
#define SIF_SocketCreateClientSide  _SIF_SocketCreateClientSide_
#define SIF_SocketCreateServerSide  _SIF_SocketCreateServerSide_
#define SIF_SocketWaitForConnection _SIF_SocketWaitForConnection_

#endif
#ifdef NOSTDCALL
#   undef STDCALL
#   define STDCALL
#endif

/*
 *  this section is the api prototypes
 */
extern void STDCALL SIF_AcknowledgeRequest(Fint *pSocket,
                                           Fint *iErr);
extern void STDCALL SIF_ErrorMsg(Fint  *iErr,
                                 Fchar *Msg,
                                 Flen   MsgLen);
extern void STDCALL SIF_GetIntegerData(Fint  *pSocket,
                                       Fchar *ProcName,
                                       Fchar *Attribute,
                                       Fchar *Family,
                                       Fchar *What,
                                       Fchar *Where,
                                       Fchar *When,
                                       Fint  *nDataTot,
                                       Fint  *iDataS,
                                       Fint  *iDataF,
                                       Fint  *RetData,
                                       Fint  *iErr,
                                       Flen   ProcNameLen,
                                       Flen   AttributeLen,
                                       Flen   FamilyLen,
                                       Flen   WhatLen,
                                       Flen   WhereLen,
                                       Flen   WhenLen);
extern void STDCALL SIF_GetRealData(Fint  *pSocket,
                                    Fchar *ProcName,
                                    Fchar *Attribute,
                                    Fchar *Family,
                                    Fchar *What,
                                    Fchar *Where,
                                    Fchar *When,
                                    Fint  *nDataTot,
                                    Fint  *iDataS,
                                    Fint  *iDataF,
                                    Freal *RetData,
                                    Fint  *iErr,
                                    Flen   ProcNameLen,
                                    Flen   AttributeLen,
                                    Flen   FamilyLen,
                                    Flen   WhatLen,
                                    Flen   WhereLen,
                                    Flen   WhenLen);
extern void STDCALL SIF_GetDoubleData(Fint    *pSocket,
                                      Fchar   *ProcName,
                                      Fchar *Attribute,
                                      Fchar   *Family,
                                      Fchar   *What,
                                      Fchar   *Where,
                                      Fchar   *When,
                                      Fint    *nDataTot,
                                      Fint    *iDataS,
                                      Fint    *iDataF,
                                      Fdouble *RetData,
                                      Fint    *iErr,
                                      Flen     ProcNameLen,
                                      Flen   AttributeLen,
                                      Flen     FamilyLen,
                                      Flen     WhatLen,
                                      Flen     WhereLen,
                                      Flen     WhenLen);
extern void STDCALL SIF_GetLocalHostName(Fchar *name,
                                         Fint  *iErr,
                                         Flen   nameLen);
extern void STDCALL SIF_GetNextRequest(Fint  *pSocket,
                                       Fchar *ProcName,
                                       Fchar *Request,
                                       Fchar *Attribute,
                                       Fchar *Family,
                                       Fchar *What,
                                       Fchar *Where,
                                       Fchar *When,
                                       Fchar *Message,
                                       Fint  *iErr,
                                       Flen   ProcNameLen,
                                       Flen   RequestLen,
                                       Flen   AttributeLen,
                                       Flen   FamilyLen,
                                       Flen   WhatLen,
                                       Flen   WhereLen,
                                       Flen   WhenLen,
                                       Flen   MessageLen);
extern void STDCALL SIF_GetStringData(Fint  *pSocket,
                                      Fchar *ProcName,
                                      Fchar *Attribute,
                                      Fchar *Family,
                                      Fchar *What,
                                      Fchar *Where,
                                      Fchar *When,
                                      Fint  *nDataTot,
                                      Fint  *iDataS,
                                      Fint  *iDataF,
                                      Fchar *RetData,
                                      Fint  *iErr,
                                      Flen   ProcNameLen,
                                      Flen   AttributeLen,
                                      Flen   FamilyLen,
                                      Flen   WhatLen,
                                      Flen   WhereLen,
                                      Flen   WhenLen,
                                      Flen   RetDataLen);
extern void STDCALL SIF_PutIntegerData(Fint *pSocket,
                                       Fint *nDataTot,
                                       Fint *iDataS,
                                       Fint *iDataF,
                                       Fint *RetData,
                                       Fint *iErr);
extern void STDCALL SIF_PutRealData(Fint  *pSocket,
                                    Fint  *nDataTot,
                                    Fint  *iDataS,
                                    Fint  *iDataF,
                                    Freal *RetData,
                                    Fint  *iErr);
extern void STDCALL SIF_PutDoubleData(Fint    *pSocket,
                                      Fint    *nDataTot,
                                      Fint    *iDataS,
                                      Fint    *iDataF,
                                      Fdouble *RetData,
                                      Fint    *iErr);
extern void STDCALL SIF_PutError(Fint *pSocket,
                                 Fint *iErr);
extern void STDCALL SIF_PutStringData(Fint  *pSocket,
                                      Fint  *nDataTot,
                                      Fint  *iDataS,
                                      Fint  *iDataF,
                                      Fchar *RetData,
                                      Fint  *iErr,
                                      Flen   RetDataLen);
extern void STDCALL SIF_SendCommand(Fint  *pSocket,
                                    Fchar *ProcName,
                                    Fchar *CmdRequest,
                                    Fchar *Attribute,
                                    Fchar *Message,
                                    Fint  *iErr,
                                    Flen   ProcNameLen,
                                    Flen   CmdRequestLen,
                                    Flen   AttributeLen,
                                    Flen   MessageLen);
extern void STDCALL SIF_SocketClose(Fint *pSocket);
extern void STDCALL SIF_SocketCreateClientSide(Fint  *TimeOut, 
                                               Fint  *Port,
                                               Fchar *HostName,
                                               Fint  *pSocket,
                                               Fint  *iErr,
                                               Flen   HostNameLen);
extern void STDCALL SIF_SocketCreateServerSide(Fint *Port,
                                               Fint *pGSocket,
                                               Fint *iErr);
extern void STDCALL SIF_SocketWaitForConnection(Fint *TimeOut,
                                                Fint *pGSocket,
                                                Fint *pSocket,
                                                Fint *iErr);

#ifdef __cplusplus
}
#endif

#endif
