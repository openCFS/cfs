/* sid 50.1 copy of fem_elPriv.h last changed by upd111 on 2004/11/04 18:32:50 */
/*  FEM_elPriv.h */
/* 
 * *** ansys(r) copyright(c) 1999
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  *** */
/*                                                                         sjo
 *   FEM_elPriv.h
 *   Private header file for elements in FEM module
 */
#ifndef FEM_ELPRIVATE
#define FEM_ELPRIVATE

#include "FEM_cdbtypes.h"
                             /* === fem_elNewFaceUses: create the face use    */
                             /* === structures for the element                */
INT fem_elNewFaceUses (
   ELEMENT_OBJ obj_element  );         /* element object                      */

                             /* === fem_elDeleteFaceUses: delete the face     */
                             /* === uses from the element                     */
void fem_elDeleteFaceUses (
   ELEMENT_OBJ obj_element  );         /* element object                      */

                             /* === fem_elSetEdgeOrientations: set the        */
                             /* === edge orientations for the edges in each of*/
                             /* === the faces of the element                  */
void fem_elSetEdgeOrientations (
   ELEMENT_OBJ element_obj,            /* element object                      */
   FEM_BOOLEAN *a_node_orientation  ); /* array of node orientations          */
                                       /* based on the EDGE_NODE specification*/
                                       /* with respect to how the nodes are   */
                                       /* currently stored in the edge        */

/*
 * macros for accessing and updating the element linked list
 */

/*
 * --- The function definition of the element macros can be used instead of
 * --- the macros themselves by including -D NO_ELEM_MACRO on the
 * --- compile line.  The equivalent functions are found in fem_elPrivateMacro.c
 * --- Note: When adding a Macro - make sure the prototype and the macro
 * ---       appear in this file.
 */

/*============================================================================*/
/* === Macro:  fem_elSetTotal_C
 * === Author: sjo
 * === Description: set total number of elements in list
 * === Arguments: 
 *     ELEMENTLIST_OBJ obj_elist   element list object
 *     INT totelem                 new total number of elements
 * === Return: nothing
 */
#ifdef NO_ELEM_MAC
void fem_elSetTotal_C ( ELEMENTLIST_OBJ obj_elist, INT totelem  );
#else
#define fem_elSetTotal_C( obj_elist, totelem )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((ELEMENTLIST_PTYP)(obj_elist))->total = totelem;\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }
#endif


/*============================================================================*/
/* === Macro: fem_elSetList_C
 * === Author: sjo
 * === Description: set head of element list
 * === Arguments: 
       ELEMENTLIST_OBJ  obj_elist    element list object
       ELEMENT_OBJ obj_element       new first element in list
 * === Return:
 */
#ifdef NO_ELEM_MAC
void fem_elSetList_C ( ELEMENTLIST_OBJ  obj_elist, 
                                ELEMENT_OBJ obj_element  );
#else
#define fem_elSetList_C( obj_elist, obj_element )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((ELEMENTLIST_PTYP)(obj_elist))->ps_list = (ELEMENT_PTYP)obj_element;\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }
#endif


/*============================================================================*/
/* === Macro: fem_elSetCurrent_C
 * === Author: sjo
 * === Description: set current element in element object list
 * === Arguments: 
 *     ELEMENTLIST_OBJ obj_elist       element list object
 *     ELEMENT_OBJ obj_element         new current element
 * === Return:
 */
#ifdef NO_ELEM_MAC
void fem_elSetCurrent_C ( ELEMENTLIST_OBJ obj_elist,
                                   ELEMENT_OBJ obj_element  );
#else
#define fem_elSetCurrent_C( obj_elist, obj_element )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((ELEMENTLIST_PTYP)(obj_elist))->ps_current = \
                                      (ELEMENT_PTYP)obj_element;\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }
#endif


/*============================================================================*/
/* === Macro: fem_elAddElementToList_C
 * === Author: sjo
 * === Description: add element to linked list at front of list
 * === Arguments:
 *     ELEMENTLIST_OBJ obj_elist     element list object
 *     ELEMENT_OBJ obj_element       new element to be added
 * === Return: nothing
 */
#ifdef NO_ELEM_MAC
void fem_elAddElementToList_C ( ELEMENTLIST_OBJ obj_elist,
                                         ELEMENT_OBJ obj_element  );
#else
#define fem_elAddElementToList_C( obj_elist, obj_element )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((ELEMENT_PTYP)(obj_element))->ps_next =\
                   ((ELEMENTLIST_PTYP)(obj_elist))->ps_list;\
         ((ELEMENTLIST_PTYP)(obj_elist))->ps_list =\
                   (ELEMENT_PTYP)(obj_element);\
         if (((ELEMENT_PTYP)(obj_element))->ps_next != NULL) {\
            ((ELEMENT_PTYP)(obj_element))->ps_next->ps_previous =\
                      (ELEMENT_PTYP)(obj_element);\
         }\
         ((ELEMENT_PTYP)(obj_element))->ps_previous = NULL;\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }
#endif


/*============================================================================*/
/* === Macro: fem_elDeleteElementFromList_C
 * === Author: sjo
 * === Description: delete element from linked list
 * === Arguments:
 *     ELEMENTLIST_OBJ obj_elist   element list object
 *     ELEMENT_OBJ obj_element     element to be deleted
 * === Return: nothing
 */
#ifdef NO_ELEM_MAC
void fem_elDeleteElementFromList_C ( ELEMENTLIST_OBJ obj_elist,
                                              ELEMENT_OBJ obj_element  );
#else
#define fem_elDeleteElementFromList_C( obj_elist, obj_element )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         if (((ELEMENT_PTYP)(obj_element))->ps_next != NULL) {\
            ((ELEMENT_PTYP)(obj_element))->ps_next->ps_previous =\
                    ((ELEMENT_PTYP)(obj_element))->ps_previous;\
         }\
         if (((ELEMENT_PTYP)(obj_element))->ps_previous) {\
            ((ELEMENT_PTYP)(obj_element))->ps_previous->ps_next =\
                    ((ELEMENT_PTYP)(obj_element))->ps_next;\
         }\
         else{\
            ((ELEMENTLIST_PTYP)(obj_elist))->ps_list =\
               ((ELEMENT_PTYP)(obj_element))->ps_next;\
         }\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }
#endif

/*============================================================================*/
/* === Macro: fem_elInit_C
 * === Author: sjo
 * === Description: initialize (zero out) all fields of an element
 * === Arguments:
 *     ELEMENT_OBJ obj_element     element to be initialized
 * === Return: nothing
 */
#ifdef NO_ELEM_MAC
void fem_elInit_C ( ELEMENT_OBJ obj_element  );
#else
#define fem_elInit_C( obj_element )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((ELEMENT_PTYP)(obj_element))->id = 0;\
         ((ELEMENT_PTYP)(obj_element))->shape = UNDEFINED_SHAPE;\
         ((ELEMENT_PTYP)(obj_element))->numfaces = 0;\
         ((ELEMENT_PTYP)(obj_element))->aps_face_use[0] = NULL;\
         ((ELEMENT_PTYP)(obj_element))->aps_face_use[1] = NULL;\
         ((ELEMENT_PTYP)(obj_element))->aps_face_use[2] = NULL;\
         ((ELEMENT_PTYP)(obj_element))->aps_face_use[3] = NULL;\
         ((ELEMENT_PTYP)(obj_element))->aps_face_use[4] = NULL;\
         ((ELEMENT_PTYP)(obj_element))->aps_face_use[5] = NULL;\
         ((ELEMENT_PTYP)(obj_element))->as_face_element[0].ps_element =\
         ((ELEMENT_PTYP)(obj_element))->as_face_element[1].ps_element =\
         ((ELEMENT_PTYP)(obj_element))->as_face_element[2].ps_element =\
         ((ELEMENT_PTYP)(obj_element))->as_face_element[3].ps_element =\
         ((ELEMENT_PTYP)(obj_element))->as_face_element[4].ps_element =\
         ((ELEMENT_PTYP)(obj_element))->as_face_element[5].ps_element =\
                     (ELEMENT_PTYP)(obj_element);\
         ((ELEMENT_PTYP)(obj_element))->as_face_element[0].ps_next =\
         ((ELEMENT_PTYP)(obj_element))->as_face_element[1].ps_next =\
         ((ELEMENT_PTYP)(obj_element))->as_face_element[2].ps_next =\
         ((ELEMENT_PTYP)(obj_element))->as_face_element[3].ps_next =\
         ((ELEMENT_PTYP)(obj_element))->as_face_element[4].ps_next =\
         ((ELEMENT_PTYP)(obj_element))->as_face_element[5].ps_next =\
                     (NEXTELEMENT_PTYP)NULL;\
         ((ELEMENT_PTYP)(obj_element))->property = NO_PROPERTY;\
         ((ELEMENT_PTYP)(obj_element))->p_info = NULL;\
         ((ELEMENT_PTYP)(obj_element))->shape_metric = 0.0;\
         ((ELEMENT_PTYP)(obj_element))->geo_entity = 0;\
         ((ELEMENT_PTYP)(obj_element))->parent = 0;\
         ((ELEMENT_PTYP)(obj_element))->ps_next = (ELEMENT_PTYP)NULL;\
         ((ELEMENT_PTYP)(obj_element))->ps_previous = (ELEMENT_PTYP)NULL;\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }
#endif

/*============================================================================*/
/* === Macro: fem_elSetFaceOrientation_C
 * === Author: sjo
 * === Description: set the edge orientation flag in the face use structure
 * === Arguments:
 *     ELEMENT_OBJ obj_element     element object
 *     INT iface                   face on the element to be set
 *     FEM_BOOLEAN edge_orientation (-1 or 1) defines how the current use of
 *                                 the face is oriented with respect to how
 *                                 the face is stored
 * === Return: nothing
 */
#ifdef NO_ELEM_MAC
void fem_elSetFaceOrientation_C ( ELEMENT_OBJ obj_element,
                                           INT iface,
                                           FEM_BOOLEAN edge_orientation  );
#else
#define fem_elSetFaceOrientation_C( obj_element, iface, edge_orientation )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((ELEMENT_PTYP)(obj_element))->aps_face_use[iface]->edge_orientation =\
            (FEM_BOOLEAN)edge_orientation;\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }
#endif

/*============================================================================*/
/* === Macro: fem_elSetFaceInitialEdge_C
 * === Author: sjo
 * === Description: set the initial face in the face use structure
 * === Arguments:
 *     ELEMENT_OBJ obj_element     element object
 *     INT iface                   face on the element to be set
 *     INT index                   defines the first edge on the current use
 *                                 of the face with respect to how the face is 
 *                                 stored
 * === Return: nothing
 */
#ifdef NO_ELEM_MAC
void fem_elSetFaceInitialEdge_C ( ELEMENT_OBJ obj_element,
                                           INT iface,
                                           INT index  );
#else
#define fem_elSetFaceInitialEdge_C( obj_element, iface, index )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((ELEMENT_PTYP)(obj_element))->aps_face_use[iface]->initial_edge_idx =\
            (INT)index;\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }
#endif

#endif

/* eof */
