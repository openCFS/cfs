/* sid 50.1 copy of Starbase.h last changed by upd111 on 2005/06/04 13:14:34 */
/* $Source$ */
/* $Revision$ */
/* $Date$ */
/*
 * *** ansys(r) copyright(c) 2000
 * *** ansys, inc.
 */

#ifndef _XgStarbase_h
#define _XgStarbase_h

#include <starbase.c.h>
#include <Xm/Xm.h>

#ifdef __cplusplus
extern "C" {
#endif

/* New resources */
#define XgNopenMode "openMode"
#define XgNshadeMode "shadeMode"
#define XgNoverlay "overlay"
#define XgNtransparent "transparent"
#define XgNvisual "visual"
#define XgNdriver "driver"
#define XgNfildes "fildes"
#define XgNwmCmap "wmCmap"
#define XgNrescalePolicy "rescalePolicy"
#define XgNmaxWidth "maxWidth"
#define XgNmaxHeight "maxHeight"

#define XgCOpenMode "OpenMode"
#define XgCShadeMode "ShadeMode"
#define XgCOverlay "Overlay"
#define XgCTransparent "Transparent"
#define XgCVisual "Visual"
#define XgCDriver "Driver"
#define XgCFildes "Fildes"
#define XgCWmCmap "WmCmap"
#define XgCRescalePolicy "RescalePolicy"
#define XgCMaxWidth "MaxWidth"
#define XgCMaxHeight "MaxHeight"

#define XgROpenMode "openMode"
#define XgRShadeMode "shadeMode"
#define XgRWmCmap "wmCmap"
#define XgRRescalePolicy "rescalePolicy"

/* New resource settings */
#define XgINIT INIT
#define XgTHREE_D THREE_D
#define XgMODEL_XFORM MODEL_XFORM
#define XgFLOAT_XFORM FLOAT_XFORM
#define XgINT_XFORM INT_XFORM
#define XgINT_XFORM32 INT_XFORM32
#define XgUNACCELERATED UNACCELERATED
#define XgACCELERATED ACCELERATED
#define XgCMAP_NORMAL CMAP_NORMAL
#define XgCMAP_FULL CMAP_FULL
#define XgCMAP_MONOTONIC CMAP_MONOTONIC
#define XgWM_CMAP_NONE 0          /* Make no change to WM_COLORMAP_WINDOWS */
#define XgWM_CMAP_LOW_PRIORITY 1  /* Add to bottom of WM_COLORMAP_WINDOWS */
#define XgWM_CMAP_HIGH_PRIORITY 2 /* Add to top of WM_COLORMAP_WINDOWS */
#define XgRESCALE_NONE 0    /* Make no change to scale. */
#define XgRESCALE_DISTORT 1 /* Set p1-p2 to scale with distortion. */
#define XgRESCALE_MAJOR 2 /* Set p1-p2 to scale to max axis. */
#define XgRESCALE_MINOR 3 /* Set p1-p2 to scale to min axis. */

/* Class record pointer */
extern WidgetClass xgStarbaseWidgetClass;

/* C Widget type definition */
typedef struct _XgStarbaseClassRec *XgStarbaseWidgetClass;
typedef struct _XgStarbaseRec *XgStarbaseWidget;

#define XgIsStarbase(w) XtIsSubclass((w), xgStarbaseWidgetClass)

/*  Creation entry point: */
#ifdef __STDC__ /* FN PROTO [ */
extern Widget XgCreateStarbase(
    Widget p,
    String name,
    ArgList args,
    Cardinal n);
#else  /* __OLD_K&R_C ] [ */
extern Widget XgCreateStarbase();
#endif /* __OLD_K&R_C ] */

#ifdef __cplusplus
}  /* Close scope of 'extern "C"' declaration which encloses file. */
#endif

#endif /* _XgStarbase_h */
