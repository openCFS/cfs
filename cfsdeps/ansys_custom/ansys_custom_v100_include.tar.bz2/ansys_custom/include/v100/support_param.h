/* sid 50.1 copy of support_param.h last changed by smarguer on 2005/01/25 15:46:52 */
/*******************************************************************************
 *
 *   support_param.h
 *
 *
 * |Module: ADOMESH
 *
 * |Description:
 *
 * |Includes:
 *
 * |Auteur: Lionel Tomaso
 *
 * |Creation: April 2004
 *
 * |Copyright:  Copyright(c) CADOE 2004
 *
 *
 ******************************************************************************/

#ifndef __supportparamh__
#define __supportparamh__ 1

#ifdef __cplusplus
extern "C" {
#endif

extern BVEC *support_of_param( T_Modele *modele, const char *param, bool only_config_mono, double filtre, double filtre2, T_statut *ier );

#ifdef __cplusplus
}
#endif

#endif

