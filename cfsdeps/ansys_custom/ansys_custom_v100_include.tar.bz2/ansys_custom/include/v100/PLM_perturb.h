/* sid 50.1 copy of PLM_perturb.h last changed by smarguer on 2005/01/25 15:46:50 */
/* PLM_perturb.h CADOE  */
/*
 * PLM_perturb.h
 *
 * $Id$
 *   
 * HISTORY
 *   
 *   06/28/00 10:47 <       Brian Jantzen> Rel:ms8m1    SCCA:74542  Delta:81.3
 *   
 *   06/21/00 16:30 <       Brian Jantzen> Rel:ms8m1    SCCA:74307  Delta:81.2
 */

#ifndef __PLMperturbh__
#define __PLMperturbh__ 1

#ifndef __expmdbstructh__
#include "expmdb_struct.h"
#endif

#ifdef __cplusplus
extern "C" {
#endif

extern T_statut PLM_perturb ( CDesignSet *dset, T_Modele *, VEC *);


#ifdef __cplusplus
}
#endif

#endif
