/* sid 50.1 copy of MAT_Gent.h last changed by upd111 on 2005/06/04 13:20:52 */
////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         Copyright (C) 2001 ANSYS Inc.  All Rights Reserved             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MAT_Gent.h $
// $Revision$ 7.0
// $Date$ May 8 2002
// $Author$ rjayasee
//
// Decription :
//
//	This class is the gent abstraction for material curve fitting
//////////////////////////////////////////////////////////////////////////////

#if !defined( MAT_GENT_H )
#define MAT_GENT_H


#include "MAT_HyperElasticNonLinearFit.h"
#include "MAT_ArrudaBoyceVolumetricMode.h"

class MAT_ExperimentalDataSet ;

class MAT_Gent : public MAT_HyperElasticNonLinearFit
{

public:

    MAT_Gent();
    //Constructor

    virtual bool GenerateMaterialParametersWithLMMethod() ;
    //R-bool
    //F-Function that Generates the Material Parameters given
    //F-some experimental data with Levenberg Marquardt's Method

    virtual bool CalculateFittedExperimentalDataPoint
                    ( double* pCoeffs,
                      INT iNumCoeffs,
                      ANS_String oExpName,
                      vector<double>& oPoint ) ;
    //R bool
    //R oExpName
    //R-Experiment Name
    //O-Input/Output point data

    virtual INT GetNumberOfCoeffs() ;
    //R-bool
    //I-iOrder
    //I-Number of Coeffs
    //F-Set the Number of Coeffs
    //F-This is calculated from the polynomial order
     
    virtual bool DeleteCoefficients( MAT_FieldVariableCollection const& oField  ) ;
    //R bool
    //I oField
    //I-Field Variable
    //- Removes/Deletes the Variable Independent coefficients at a particular temp/...

    virtual void Print() ;
    //F-Print

  	virtual ~MAT_Gent();
    //F-Destructor


protected:
  
    MAT_ArrudaBoyceVolumetricMode m_oVolumetricMode ;
    // Volumetric Mode for arruda boyce

    virtual bool FirstDerivativeOfUnsquaredError( double* dVariables,
                                                  INT iNumVariables,
                                                  double dLambdaN, 
                                                  double dStressN,
                                                  MAT_ExperimentType iExpType,
                                                  INT iVariableIndex,
                                                  double& dResult ) ;
    //R bool
    //R-false if unknown exp type or null dVariables
    //I dAlphaj
    //I-Coefficent Alpha in Gent Expr
    //I dLambdan
    //I-Value of Stretch
    //I iExpType
    //I 1 for unia, 2 for biax, 3 for tension
    //-Calculates the value of the first derivative of the Gent Potential
    //-for a stress/stretch point


    virtual bool FunctionValue( double* dVariables,
                                INT iNumVariables,
                                double dLambdaN, 
                                MAT_ExperimentType iExpType,
                                double& dStressN ) ;
    //R bool
    //I dVariables
    //I-Input Coeffecients
    //I iNumVariables
    //I-Number of Coeffecients = 2
    //I dLambdaN
    //I-Stretch
    //I iExpType
    //I 1 for unia, 2 for biax, 3 for tension
    //- Calculate Stress given stretch and coeffs

    bool FunctionInvariantOnePrime( double dLambdaN, 
                                    MAT_ExperimentType iExpType,
                                    double& dI1 ) ;
    //R bool
    //I dLambdaN
    //I-Stretch
    //I iExpType
    //I 1 for unia, 2 for biax, 3 for tension
    //I dI1
    //I-Invariant One
    //- Calculate Stress Invariant Prime given stretch

    bool FunctionInvariantOne( double dLambdaN, 
                               MAT_ExperimentType iExpType,
                               double& dI1 ) ;
    //R bool
    //I dLambdaN
    //I-Stretch
    //I iExpType
    //I 1 for unia, 2 for biax, 3 for tension
    //I dI1
    //I-Invariant One
    //- Calculate Stress Invariant given stretch

    bool FunctionBeta( double dLambdaN, 
                       double dIM,
                       MAT_ExperimentType iExpType,
                       double& dStressN ) ;
    //R bool
    //I dLambdaN
    //I-Stretch
    //I dIM
    //I-Limiting value of I1 - 3
    //I iExpType
    //I-1 for unia, 2 for biax, 3 for tension
    //I dBeta
    //I-Value of Beta ( I1 - 3 / IM)
    //- Calculate Function Beta as in documentation

};

#endif // !defined(MAT_GENT_H)
