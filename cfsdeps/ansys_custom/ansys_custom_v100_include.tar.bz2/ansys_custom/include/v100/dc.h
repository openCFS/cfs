/* sid 50.1 copy of dc.h last changed by upd111 on 2005/06/04 13:14:11 */
/****************************************************************************
 DC.h

 The DC module handles setting and reading of the DC attributes.

****************************************************************************/


/****************************************************************************
   Types
****************************************************************************/
/* 
 * *** ansys(r) copyright(c) 2000
 * *** ansys, inc.
 */

/* Values needed to setup a DC */
typedef struct
{
   short    mapMode;
   POINT    windowOrg;
   POINT    windowExt;
   POINT    viewportOrg;
   POINT    viewportExt;

   POINT    penPos;
   POINT    brushOrg;

   BOOL     intersect;
   RECT     rIntersect;
   BOOL     exclude;
   RECT     rExclude;

   COLORREF bkColor;
   short    bkMode;

   LOGFONT  fontLarge;
   LOGFONT  fontSmall;
  	WORD     textAlign;
   short    breakExtra;
   short    breakCount;
   short    textExtra;
   COLORREF textColor;

   short    rop2;
   short    polyFillMode;
   short    bltMode;

   BYTE     patChecks[64];   /* treated as array of boolean, TRUE => 0 bit */

   /* Handles */
   HFONT    hFontLarge;
   HFONT    hFontSmall;

	int		fontSize;
   BOOL     releaseDC;
   BOOL     resetDC;
   HRGN     hClipRgn;
   HRGN     hClipRgnOld;
} DCValues;


struct mouseGraph
{
   UINT cmd;
   WORD fwKeys; 				/* key flags                     			*/
   WORD xPos;   				/* horizontal position of cursor 			*/
   WORD yPos;   				/* vertical position of cursor   			*/
   WORD leftBtnDwnXPos;    /* initial horizontal position of cursor 	*/
   WORD leftBtnDwnYPos;   	/* initial vertical position of cursor   	*/
   WORD leftBtnUpXPos;    	/* final horizontal position of cursor 	*/
   WORD leftBtnUpYPos;   	/* final vertical position of cursor   	*/
   WORD middleBtnDwnXPos;  /* initial horizontal position of cursor 	*/
   WORD middleBtnDwnYPos;  /* initial vertical position of cursor   	*/
   WORD middleBtnUpXPos;   /* final horizontal position of cursor 	*/
   WORD middleBtnUpYPos;   /* final vertical position of cursor   	*/
   WORD rightBtnDwnXPos;   /* initial horizontal position of cursor 	*/
   WORD rightBtnDwnYPos;   /* initial vertical position of cursor   	*/
   WORD rightBtnUpXPos;    /* final horizontal position of cursor 	*/
   WORD rightBtnUpYPos;   	/* final vertical position of cursor   	*/
};

/****************************************************************************
   Globals
****************************************************************************/

/* The global DC settings */
   DCValues dcv;
   HFONT    prevFont;
   HPEN     prevPen;
   HBRUSH   prevBrush;


/****************************************************************************
   Functions
****************************************************************************/

void ReadDC( HDC hdc );
void SetupDC( HDC hdc );

#define PALVERSION       (0x300)
#define MAXPALETTE       (0X100)      /* max # supported palette entries */

/* Flags used for display of messages */
#define NT_NONE    (0X0)       		/* Don't display any msgs */

/* Types */
#define NT_ERROR 	 (0X1)       		/* Display non window and function errors */
#define NT_WARN  	 (NT_ERROR * 2)	/* Display warnings */
#define NT_INF   	 (NT_WARN * 2)		/* Display informative messages*/
#define NT_WM    	 (NT_INF * 2)		/* Display windows wm_... messages*/
#define NT_ENTRY 	 (NT_WM * 2)		/* Display message on entry to subroutine */
#define NT_COLOR 	 (NT_ENTRY * 2)	/* Active show color function */
#define NT_WINERR  (NT_COLOR * 2)	/* Display windows errors */
#define NT_EXIT	 (NT_WINERR * 2)	/* Display message on exit from subroutine */
#define NT_DBG		 (NT_EXIT * 2)		/* Display debug info */
#define NT_DBG1	 (NT_DBG * 2)    	/* Display debug info */
#define NT_DBG2	 (NT_DBG1 * 2)    /* Display debug info */
#define NT_DBG3	 (NT_DBG2 * 2)    /* Display debug info */
#define NT_DBG4	 (NT_DBG3 * 2)    /* Display debug info */

/* Options */
#define NT_TYPE	 (NT_DBG4 * 2)		/* Display message type with message */

/* Where to display */
#define NT_CONSOLE (NT_TYPE * 2)    /* Display all messages in the colsole window */
#define NT_NOFILE  (NT_CONSOLE * 2) /* Don't display any messages in the error file */

/* Special type */
#define NT_CONMSG  (NT_NOFILE * 2)  /* Always force display this msg in the consol */
#define NT_FILMSG  (NT_CONMSG * 2)  /* Always force display this msg in the file */
#define NT_MSGBOX  (NT_FILMSG * 2)  /* Always force display this msg to the message box */

#define NT_ALL     (NT_CONSOLE - 1) /* Display all errors */

int errMsgFlag;
