/* sid 50.1 copy of FEM_readmtkjor.h last changed by upd111 on 2004/11/04 18:32:01 */
/*  FEM_readmtkjor.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_readmtkjor.h
 *  header file for FEM_readmtkjor.c
 *
 */
#ifndef FEM_CLEAR_INCLUDE
#define FEM_CLEAR_INCLUDE

/*----------------- Globally accessible function prototypes -----------------*/

                          /* =============================================== */
                          /* === FEM_readmtkjor: Read in a Ansys MTK journal */
                          /* === file.                                       */
                          /* === RETURN: 0 is successful, 1 if error         */
                          /* =============================================== */
int FEM_readmtkjor(
   char *filename );      /* (IN)  filename of journal file to read.         */
                          /* =============================================== */

#endif

