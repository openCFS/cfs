/* sid 50.1 copy of AnsMemPcDebug.h last changed by upd111 on 2005/06/04 13:17:33 */

/* *** ansys(r) copyright(c) 2000
 * *** ansys, inc.
 */

/*
 * define some debugging flags for PC development  
 * -- any other case, they are NULL 
 */
#if defined (DEVELOPMENT)
# if defined (PCWINNT_SYS)
#  if defined (DEBUG_MALLOC)
#   if !defined (_DEBUG)
#    define _DEBUG
#   endif
#   include <CRTDBG.H>
#   if !defined (_CRTDBG_MAP_ALLOC)
#    define _CRTDBG_MAP_ALLOC
#   endif
#   define  DEBUGGING_MALLOC_SETUP \
      _CrtSetDbgFlag(_CRTDBG_CHECK_ALWAYS_DF | _CrtSetDbgFlag(_CRTDBG_REPORT_FLAG)); \
      _CrtSetReportMode( _CRT_WARN, _CRTDBG_MODE_FILE ); \
      _CrtSetReportFile( _CRT_WARN, _CRTDBG_FILE_STDOUT ); \
      _CrtSetReportMode( _CRT_ERROR, _CRTDBG_MODE_FILE ); \
      _CrtSetReportFile( _CRT_ERROR, _CRTDBG_FILE_STDOUT ); \
      _CrtSetReportMode( _CRT_ASSERT, _CRTDBG_MODE_FILE ); \
      _CrtSetReportFile( _CRT_ASSERT, _CRTDBG_FILE_STDOUT )
#  else
#   define  DEBUGGING_MALLOC_SETUP ((void) 0) 
#  endif
# else
#  define  DEBUGGING_MALLOC_SETUP ((void) 0) 
# endif
#else
# define  DEBUGGING_MALLOC_SETUP ((void) 0) 
#endif

