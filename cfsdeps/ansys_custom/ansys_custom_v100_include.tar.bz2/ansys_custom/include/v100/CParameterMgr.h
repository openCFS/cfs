/* sid 50.1 copy of CParameterMgr.h last changed by smarguer on 2005/01/27 08:18:10 */
/*! \file CParameterMgr.h

  \brief This header file defines the CParameterMgr class.

  \author Stephane MARGUERIN &copy; CADOE

  \date 31 Mai 2002

  \version $Id$
*/
#ifndef __CParameterMgr_h__ 
#define __CParameterMgr_h__ 1 

#include "cadoe.h"
#include "cadoe_version.h"
#include "cadoe_map.h"
#include "cadoe_list.h"
#include "cadoe_vector.h"
#include "liste_chainee.h"
#include "parametre.h"
#include "CParameter.h"
#include "C_CbfObject.h"

class CParameter;
class CDirection;
class CDesignSet;

// class to search parameter by name 
// ex:  ParamList::iterator p = find_if( lpar.begin(), lpar.end(), CParameterFinder(pName) );
class CParameterFinder : public unary_function<CParameter *,bool>
{
public:
  CParameterFinder(string ch):
      _ch(ch)
      {
      }
      bool operator()(CParameter *par)
      {
        return par->getName()==_ch;
      }
private:
  string _ch;
};

/*! \class CParameterMgr CParameterMgr.h
  \brief The CParameterMgr class is the public Parameter Manager object shared by the different CADOE API.
*/
class CParameterMgr : public C_CbfObject
{
public:
  //! Unit factors 
  typedef enum {
    PUC_LENGTH,
    PUC_FORCEPERLENGTH,
    PUC_FORCE,
    PUC_TEMPERATURE,
    PUC_TEMPOFFSET
  } UnitCoef;
  
  //! Global database status
  typedef enum {
    GPS_NONE,
    GPS_PARAM_ADDED,
    GPS_PARAM_REMOVED,
    GPS_PARAM_MODIFIED
  } ModifStatus;
  
  //! parameter status : second definition
  typedef enum {
    ePT_STA_TOPROCESS = 0x1, /**< results are not yet available */
    ePT_STA_DELETED = 0x2, /**< parameter suppressed: no results available */
    ePT_STA_ACTIVE = 0x4, /**< parameter is active */
    ePT_STA_INACTIVE = 0x8, /**< parameter is not active for the current solve */
    ePT_STA_ALL = 0xF
  } staParameterType;
  
  //! list of parameter pointers
  typedef list<CParameter> ParamList;
  typedef list<CParameter*> ParamListPtr;
  //! vector of parameter pointers
  typedef vector<CParameter> ParamVector;
  //! map of the parameters; parameters name is the key
  typedef map<string,CParameter> ParamMap;
  //! map of the directions; direction name is the key
  typedef map <string,CDirection*> DirectionMap;
  
  
public:
  CParameterMgr();
  CParameterMgr( const string &filename );
  ~CParameterMgr();
  
  const string getVersion(void) const { return CADOE_VERSION_PRODUCT; }

  
  /*! \brief Read parameters from an existing file. Last read file is set as the current one.
  \param filename filename of the database to read, or nothing to use the current file
  \return -1 if fails.
  */
  int readFile( void );
  /*! \brief Write the current list of parameters: create a new file if it does not exists, 
  update the parameters list otherwise.
  \param filename filename of the database to write, or nothing to use the current file
  \return -1 if fails.
  */
  int writeFile( void );
  /*! \brief Write a parameter in the current list of parameters: create a new file if it does not exists, 
    update the parameters list otherwise.
  \param filename filename of the database to write, or nothing to use the current file
  \return -1 if fails.
  */
  int writeParameterInFile( const string &parameterName );

  /*! \brief Set the current file. By default the last read file is 
  the current one. So if you only read one file, you do not need to use this method.
  */
  void setFilename( const string &filename ) { m_sFilename = filename; }
  /*! \brief Get the current filename
  \return name of the current file
  */
  const string& getFilename( void ) const { return m_sFilename; }
  
  /*! \brief Get the number of parameters
  \return number of parameters
  */
  int getNumberOfParameters( void ) const;
  /*! \brief Get the number of SHAPE parameters.
  \return number of parameters
  */
  int getNumberOfShapeParameters( void ) const;
  /*! \brief Get the number of BOOLEAN parameters.
  \return number of parameters
  */
  int getNumberOfBooleanParameters( void ) const;

  /*! \brief Return a COPY of the parameters list.
  \return list of parameters
  */
  int getParameterList( CParameterMgr::ParamList &plist ) const;
  /*! \brief Return a COPY of the parameters vector.
  \return vector of parameters
  */
  
  int getParameterVector( CParameterMgr::ParamVector &pvec ) const;
  /*! \brief Return a COPY of the parameters map.
  \return map of parameters
  */
  int getParameterMap( CParameterMgr::ParamMap &pmap ) const;
  
  int getGeometryParameters( CParameterMgr::ParamVector &pvec) const;
  /*! \brief Return a COPY of a parameter, from its name.
  \param paramName name of the parameter to retrieve
  \param Parameter object
  \return -1 if fails
  */
  int getParameter( const string &paramName, CParameter &param ) const;
  
  /*! \brief Add or Update a parameter in the list
  \param param Parameter object to add in the list
  \return -1 if fails
  */
  int addParameter(  CParameter &param );
  int updateParameter(  CParameter &param ) { return addParameter(param); }
  /*! \brief Remove a parameter from the list attached to filename. The parameter object is NOT deleted.
  \param param Parameter object to remove
  \return -1 if fails
  */
  int removeParameter( const string &pName );
  
  /*! \brief Activate a parameter.
  \param param Parameter to activate 
  \param active true for activate (default), false to deactivate
  \return execution status
  */
  int activateParameter( const string &pName );
  /*! \brief Deactivate a parameter.
  \param param Parameter to activate 
  \return execution status
  */
  int deactivateParameter( const string &pName );
  
  int getDirectionMap( CParameterMgr::DirectionMap &dmap ) const;
  CDirection * createDirection( const string &name="" );
  CDirection * getDirection( const string &name ) const;
  CDirection * getDirectionById(  int id ) const;
  
  
  
  void setUnitCoef(  UnitCoef type,  double value );
  double getUnitCoef( UnitCoef type );
  
  // factors and offset conversion for SI->User. Ex: mm => lengthFactor=1000., etc
  void setUnitCoefs( double lengthFactor, double forcePerLengthFactor, double forceFactor, double tempFactor, double tempOffset=0. );
  
  
  void setStatusFilter( bool status ) { m_bStatusFilter=status; }
  void deactivateStatusFilter(void) { setStatusFilter(false); }
  
  void setStatus( ModifStatus st );
  bool isOutofdate( void ) const;
  ModifStatus getStatus( void ) const { return m_status; }
  
  
  bool AdogeomDone(void) const;
  bool AdogeomDeletedAllParam(void);
  bool AdomeshDone(void) const;
  bool AdomeshDeletedAllParam(void);
  bool SolveDone(void) const;
  
  /*! \brief Build a map giving the index of a parameter in a vec_param containing shape param only.
  \return map table
  */
  map<string,int> buildIndexVecParamAdomesh(void) const;
  /*! \brief Build a map giving the index of a parameter in a full vec_param, including internal parameters (Freq).
  \return map table
  */
  map<string,int> buildIndexVecParamAdoc(void) const;

  static CParameter::Type internal2public_type(  E_type_parametre internal );
  static E_type_parametre public2internal_type(  CParameter::Type type );

  void createParFreq( bool freq=true );
  bool parFreqExists(void) const { return m_bParFreqExists; }


  // Implementation of the C_CbfObject virtual methods for database IO
  static const int m_paramCbfVersion;
  static const int m_paramCbfCode;
  virtual int CbfRead( void );
  virtual int CbfWrite( void );
  virtual int CbfInfo( string &infostr ) const;

  int boutput( FILE *f ) const;
  int binput( FILE *f );

  double        SI2User(  E_type_parametre type ) const;
 
private:
  void        resetAll(void);
  void        resetLists(void);
  E_par_statut    convertStatus( CParamRange::ParStatus cstatus ) const;
  CParamRange::ParStatus convertStatus( E_par_statut oldstatus ) const;
    int         CParameter2oldparam( CParameter *cpNew, T_parameter * & pNew, double ) const;
  void        oldparam2CParameter( T_parameter *oldp, CParameter *param );
  CParameter*     findParameter( const string &pName ) const;
  void        applyStatusFilter( void );

  
  string		m_sFilename; // current file name
  ParamListPtr		m_lParametersFiltered; // list of parameters filtered on the status
  ParamListPtr		m_lParameters; // full list of the private parameters objects.
  double            	m_dUnitCoefs[5];
  DirectionMap		m_mDirections; // list of directions
  bool			m_bStatusFilter;
  ModifStatus		m_status;
  bool			m_bParFreqExists;  // true if the par freq exists
  bool			m_bParFreqToCreate; // true if the par freq must be added
  ParamListPtr		m_lInput;
  ParamListPtr		m_lOutput;
};





#endif
