/* sid 50.1 copy of FEM_hashtable.h last changed by upd111 on 2004/11/04 18:31:01 */
#ifndef FEM_HASHTABLE
#define FEM_HASHTABLE

#include "FEM_cdbtypes.h"
#include "FEM_cell.h"
#include "FEM_MemManager.h"

class HASHCELL_TYP;
typedef class HASHCELL_TYP *HASHCELL_PTYP;

class HASHCELL_TYP {
   private:
      INT m_id;
      HASHCELL_PTYP mps_next;
      void *m_cell;

   public:
      void SetId( INT id ) { m_id = id; };
      INT GetId( ) { return m_id; };
      HASHCELL_PTYP GetNext() const { return mps_next; };
      void SetNext( HASHCELL_PTYP next ) { mps_next = next; };
      void *GetCell() const { return m_cell; };
      void SetCell( void *thecell ) { m_cell = thecell; };
};

extern MemManager<HASHCELL_TYP> g_hashlinkmemory;
extern INT g_numhashtables;

template <class HashType> class HASHTABLE {

   private:
      HASHCELL_PTYP *maps_ht;
      INT m_size;
      INT GetHashKey( const INT id ) const
             { return abs(((id << 5) - 1) % m_size); };
 
   public:
      HASHTABLE() { Init(); };

      void Init( void )
      {
         g_numhashtables++;
         if ( g_numhashtables == 1 ) {
            g_hashlinkmemory.Init();
         }
         maps_ht = NULL;
         m_size = 0;
      };

      ~HASHTABLE()
      {
         Delete();
      };

      void Delete()
      {
         g_numhashtables--;
         if ( g_numhashtables == 0 ) {
            g_hashlinkmemory.FreeAll();
         }
         FEM_Free_C( maps_ht );
         m_size = 0;
      };

      INT InitHashTable( INT size )
      {
         INT i;

         /* === find the next highest prime number */

         if (size < 30) size = 31;
         else {
            i=2;
            while (i<size*0.5 + 1) {
               if (size % i == 0) {
                  i=2;
                  size++;
               }
               else {
                  i++;
               }
            }
         }
         maps_ht = (HASHCELL_PTYP *)FEM_Malloc_MAC(size*sizeof(HASHCELL_PTYP));
         if ( !maps_ht ) {
            FEM_Error_C( GENERIC, GEN_OUT_OF_MEMORY, FEM_ERROR, NULL );
            return EXIT_FAILURE;
         }
         m_size = size;
         for (i=0; i<size; i++) {
            maps_ht[i] = NULL;
         }

         return EXIT_SUCCESS;

      };

      INT Hash( HashType entity, INT id )
      {
         HASHCELL_PTYP ps_link;
         INT status = EXIT_FAILURE;

         if ( maps_ht ) {
            INT hash_key = GetHashKey( id );

            ps_link = g_hashlinkmemory.Allocate();
            if ( ps_link ) {
               ps_link->SetCell( entity );
               ps_link->SetId( id );
               ps_link->SetNext( maps_ht[hash_key] );
               maps_ht[hash_key] = ps_link;
               status = EXIT_SUCCESS;
            }
         }
         else {
            FEM_Error_C( GENERIC, GEN_UNKNOWN_ERROR, FEM_ERROR, NULL );
         }
         return status;

      };

      HashType Find( INT id, FEM_BOOLEAN & exists ) const
      {
         HASHCELL_PTYP ps_next;

         exists = 0;

         if ( !maps_ht ) {
            FEM_Error_C( GENERIC, GEN_UNKNOWN_ERROR, FEM_ERROR, NULL );
            return NULL;
         }

         INT hash_key = GetHashKey( id );

         ps_next = maps_ht[hash_key];
         while ( ps_next ) {
            if ( ((HASHCELL_PTYP)ps_next)->GetId() == id ) {
               exists = 1;
               return (HashType)(ps_next)->GetCell();
            }
            ps_next = ps_next->GetNext();
         }
         return NULL;
      };

      INT Remove( INT id ) const
      {
         if ( !maps_ht ) {
            FEM_Error_C( GENERIC, GEN_UNKNOWN_ERROR, FEM_ERROR, NULL );
            return EXIT_FAILURE;
         }

         INT hash_key = GetHashKey( id );

         HASHCELL_PTYP ps_cell = maps_ht[hash_key];
         HASHCELL_PTYP ps_prev = NULL;
         while ( ps_cell ) {

            HASHCELL_PTYP ps_next = ps_cell->GetNext();
            if ( ((HASHCELL_PTYP)ps_cell)->GetId() == id ) {
               if ( ps_prev ) {
                  ps_prev->SetNext( ps_next );
               }
               else {
                  maps_ht[hash_key] = ((HASHCELL_PTYP)ps_next);
               }
               g_hashlinkmemory.Free( ((HASHCELL_PTYP)ps_cell) );
               return EXIT_SUCCESS;
            }
            ps_prev = ps_cell;
            ps_cell = ps_next;
         }
         return EXIT_SUCCESS;
      };
}; 

#endif
