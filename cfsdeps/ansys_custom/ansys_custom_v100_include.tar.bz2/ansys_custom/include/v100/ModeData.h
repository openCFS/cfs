/* sid 50.1 copy of ModeData.h last changed by upd111 on 2005/06/04 13:18:45 */
#ifndef _MODES_H_
#define _MODES_H_
#include "DomainDec.h"


// Structure to contain Mode Data
// i.e. number of modes, number of nodes, 
// array of frequencies, and matrix of mode shapes.

struct ModeData {
  INT numModes;
  INT numNodes;
  double *frequencies;
  double (**modes)[6];
};

#endif
