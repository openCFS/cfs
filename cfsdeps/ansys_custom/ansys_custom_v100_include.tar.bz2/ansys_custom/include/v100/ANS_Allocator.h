/* sid 50.1 copy of ANS_Allocator.h last changed by mdm on 2005/02/22 20:02:02 */
////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         Copyright (C) 2001 ANSYS Inc.  All Rights Reserved             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: ANS_Allocator.h $
// $Revision$ 7.0
// $Date$ October 21 2003
// $Author$ rjayasee
//
// Description :
//          Custom Ansys STL Allocator
////////////////////////////////////////////////////////////////////////////

//***************************WINDOWS IMPLEMENTATION *******************************************

#if !defined(ANS_Allocator_H)
#define ANS_Allocator_H


#if defined (PCWINNT_SYS) && (_MSC_VER < 1310)
// xmemory internal header (from <memory>)

#include <cstdlib>
#include <new>

#include <utility>

#ifndef _FARQ	/* specify standard memory model */
     #define _FARQ
     #define _PDFT	ptrdiff_t
     #define _SIZT	size_t
#endif

#define _POINTER_X(T, A)	T _FARQ *
#define _REFERENCE_X(T, A)	T _FARQ &
	
    // TEMPLATE FUNCTION _Allocate
    template<class _Ty> inline
	_Ty _FARQ *_ANS_Allocate(_PDFT _N, _Ty _FARQ *)
	{
        if (_N < 0) _N = 0;
    	return ((_Ty _FARQ *)cAnsMemAlloc((_SIZT)_N * sizeof (_Ty),0,__FILE__,__LINE__) ) ;
    }
	
    // TEMPLATE FUNCTION _Construct
    template<class _T1, class _T2> inline
	void _ANS_Construct(_T1 _FARQ *_P, const _T2& _V)
	{
        new ((void _FARQ *)_P) _T1(_V); 
    }
		// TEMPLATE FUNCTION _Destroy
    template<class _Ty> inline
	void _ANS_Destroy(_Ty _FARQ *_P)
	{
        _DESTRUCTOR(_Ty, _P); 
    }
    
    inline void _ANS_Destroy(char _FARQ *_P)	{}
    inline void _ANS_Destroy(wchar_t _FARQ *_P)	{}

		// TEMPLATE CLASS allocator
template<class _Ty>	class ANS_Allocator 
{
    public:
	    typedef _SIZT size_type;
	    typedef _PDFT difference_type;
	    typedef _Ty _FARQ *pointer;
	    typedef const _Ty _FARQ *const_pointer;
	    typedef _Ty _FARQ& reference;
	    typedef const _Ty _FARQ& const_reference;
	    typedef _Ty value_type;

	    pointer address(reference _X) const
	    {
            return (&_X); 
        };
	    
        const_pointer address(const_reference _X) const
		{
            return (&_X); 
        };
	    
        pointer allocate(size_type __N, const void *)
		{
            return static_cast<_Ty*> (cAnsMemAlloc(__N * sizeof(_Ty),0,__FILE__,__LINE__)) ;
        };
	    
        char _FARQ *_Charalloc(size_type _N)
		{
            return (_ANS_Allocate((difference_type)_N,(char _FARQ *)0)); 
        };
	    
        void deallocate(void _FARQ *_P, size_type)
        { 
            cAnsMemFree(((void*)_P),__FILE__,__LINE__); 
        };
	    
        void deallocate(void _FARQ *_P)
        { 
            cAnsMemFree(((void*)_P),__FILE__,__LINE__); 
        };

        void construct(pointer _P, const _Ty& _V)
		{
            _ANS_Construct(_P, _V); 
        };
	    
        void destroy(pointer _P)
		{
            _ANS_Destroy(_P); 
        };
	    
        _SIZT max_size() const
		{
            _SIZT _N = (_SIZT)(-1) / sizeof (_Ty);
		    return (0 < _N ? _N : 1); 
        }

};

        template<class _Ty, class _U> inline
	    bool operator==(const ANS_Allocator<_Ty>&, const ANS_Allocator<_U>&)
	    {
            return (true); 
        };

        template<class _Ty, class _U> inline
	    bool operator!=(const ANS_Allocator<_Ty>&, const ANS_Allocator<_U>&)
	    {
            return (false); 
        };
		
        // CLASS allocator<void>
        template<> class _CRTIMP ANS_Allocator<void> 
        {
            public:
	        typedef void _Ty;
	        typedef _Ty _FARQ *pointer;
	        typedef const _Ty _FARQ *const_pointer;
	        typedef _Ty value_type;
	    };
//***************************WINDOWS IMPLEMENTATION ENDS*******************************************
#else
//***************************UNIX IMPLEMENTATION *******************************************
template <class _Tp>
class ANS_Allocator {
//   typedef alloc _Alloc;          // The underlying allocator.
public:
  typedef size_t     size_type;
  typedef ptrdiff_t  difference_type;
  typedef _Tp*       pointer;
  typedef const _Tp* const_pointer;
  typedef _Tp&       reference;
  typedef const _Tp& const_reference;
  typedef _Tp        value_type;

  template <class _Tp1> struct rebind {
    typedef ANS_Allocator<_Tp1> other;
  };

  ANS_Allocator() throw() {}
  // ANS_Allocator(const ANS_Allocator&) throw() {}
  template <class _Tp1> ANS_Allocator(const ANS_Allocator<_Tp1>&) throw() {}
  ~ANS_Allocator() throw() {}

  pointer address(reference __x) const { return &__x; }
  const_pointer address(const_reference __x) const { return &__x; }

  // __n is permitted to be 0.  The C++ standard says nothing about what
  // the return value is when __n == 0.
  _Tp* allocate(size_type __n, const void* = 0) {
    return __n != 0 ? static_cast<_Tp*>(cAnsMemAlloc(__n * sizeof(_Tp),0,__FILE__,__LINE__)) 
                    : 0;
  }

  // __p is not permitted to be a null pointer.
  void deallocate(pointer __p, size_type __n)
    { cAnsMemFree(((void*)__p),__FILE__,__LINE__); }

  // __p is not permitted to be a null pointer.
  void deallocate(pointer __p)
    { cAnsMemFree(((void*)__p),__FILE__,__LINE__); }

  size_type max_size() const throw() 
    { return size_t(-1) / sizeof(_Tp); }

  void construct(pointer __p, const _Tp& __val) { new(__p) _Tp(__val); }
  void destroy(pointer __p) { __p->~_Tp(); }
};
//***************************UNIX IMPLEMENTATION ENDS *******************************************
#endif


#endif

