/* sid 50.1 copy of ansCsystypes.h last changed by jrb on 2005/02/25 19:24:21 */

#include "ansysdef.h"


extern  INT  cCreateAnsCsys(INT,INT,INT*);
extern  INT  cDeleteAnsCsys(void);
extern  INT  cInquireAnsCsys(INT,INT);
extern  INT  cPutAnsCsys(INT,INT,INT*,INT,DOUBLE*);
extern  INT  cGetAnsCsys(INT,INT*,INT*,DOUBLE*);
extern  INT  cGetAnsCsysPtr(INT,INT*,INT**,DOUBLE**);
extern  INT  cDumpAnsCsys(INT);


/****************************************************************
 global-level structure for ANSYS coordinate systems
 ****************************************************************/
struct ansCsys_str {               /* Name of the structure                                       */
  INT        tag;                  /* Tag for this instance of the coordinate systems structure       */
  INT        numDef;               /* Number of defined coordinate systems in this structure          */
  INT        maxDef;               /* Maximum number of defined coordinate systems in this structure  */
  INT       *Internal_to_External; /* Mapping vector for global internal to global external       */
  INT       *External_to_Internal; /* Mapping vector for global external to global internal       */
  csysData  *dataVec;              /* Array of data for each coordinate system                    */
};

#define ansCsysTag(cs)                 (cs->tag)
#define ansCsysNumDef(cs)              (cs->numDef)
#define ansCsysMaxDef(cs)              (cs->maxDef)
#define ansCsysMaxSize(cs)             (cs->maxSize)

#define ansCsysInt2ExtPtr(cs)          (cs->Internal_to_External)
#define ansCsysInt2ExtVec(cs,i)        (cs->Internal_to_External[i])
#define ansCsysExt2IntPtr(cs)          (cs->External_to_Internal)
#define ansCsysExt2IntVec(cs,i)        (cs->External_to_Internal[i])

#define ansCsysDataPtr(cs)             (cs->dataVec)
#define ansCsysDataVec(cs,i)           (cs->dataVec+i)


/******************************************************************
 data-level structure for ANSYS coordinate systems
 ******************************************************************/
struct csysData_str {   /* Name of the structure                                                */
  char     modified;    /* Flag indicating whether this coordinate system has been modified     */
  char     internal;    /* Flag indicating whether this coordinate system is internal to object */
  INT      numIValues;  /* Number of integer values stored for this coordinate system           */
  INT      numDValues;  /* Number of double precision values stored for this coordinate system  */
  INT     *iValues;     /* Array of integer data for this coordinate system                     */
  DOUBLE  *dValues;     /* Array of double precision data for this coordinate system            */
};

#define csysDataModified(cData)        (cData->modified)
#define csysDataInternal(cData)        (cData->internal)
#define csysDataNumIValues(cData)      (cData->numIValues)
#define csysDataNumDValues(cData)      (cData->numDValues)

#define csysDataIValuesPtr(cData)      (cData->iValues)
#define csysDataIValuesVec(cData,i)    (cData->iValues[i])
#define csysDataDValuesPtr(cData)      (cData->dValues)
#define csysDataDValuesVec(cData,i)    (cData->dValues[i])

