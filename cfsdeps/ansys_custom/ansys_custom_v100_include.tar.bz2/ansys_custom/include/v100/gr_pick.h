/* sid 50.1 copy of gr_pick.h last changed by upd111 on 2005/06/04 13:18:24 */
/********************************************************/
/******  include file used for GENERAL Picker API   *****/
/********************************************************/
/*
 * *** ansys(r) copyright(c) 2000
 * *** ansys, inc.
 */

#define PCK_PCKSEL      0
#define     PCK_UNPCK 0
#define     PCK_PCK   1
#define PCK_SLECT       1
#define     PCK_SNGL 0
#define     PCK_BOX  1
#define     PCK_POLY 2
#define     PCK_CIRC 3
#define     PCK_LOOP 4
#define PCK_TYPE        3
#define PCK_ENTSEL      4
#define PCK_RBMODE      5
#define PCK_DUP         6
#define PCK_ORDR        7
#define PCK_ENTMIN      8
#define PCK_ENTMAX      9
#define PCK_NLIST      10
#define PCK_NDUP       11
#define PCK_CUR_ENTNUM 12
#define PCK_CUR_ENTTYP 13
#define PCK_PNUMTYP    14
#define PCK_PTYP       15
#define PCK_INIT       999
#ifndef FALSE
#define     FALSE 0
#endif
#ifndef TRUE
#define     TRUE  1
#endif
#define PK_ENT_NODE 1
#define PK_ENT_ELEM 2
#define PK_ENT_KEYP 3
#define PK_ENT_LINE 4
#define PK_ENT_AREA 5
#define PK_ENT_VOLU 6
#define PK_ENT_TRAC 7
#define PK_ENT_CMP  8
#define PK_ENT_GRPT 9
#define PK_ENT_FACE 10
#define PK_BIT_NODE 1
#define PK_BIT_ELEM 2
#define PK_BIT_KEYP 4
#define PK_BIT_LINE 8
#define PK_BIT_AREA 16
#define PK_BIT_VOLU 32
#define PK_BIT_TRAC 64
#define PK_BIT_CMP  128
#define PK_BIT_GRPT 256
#define PK_BIT_FACE 512
#define PK_KB_LIST  0
#define PK_KB_RANG  1

#if defined(PCWINNT_SYS)
#include <windows.h>
/* The W32Event structure is copied for the libAnsTclTk shared library. */
/* If any changes are made to this structure, you also need to modify */
/* cAnsPick.h */
typedef struct
{
   HWND hwnd;
   UINT message;
   WPARAM wParam;
   LPARAM lParam;
} W32Event;
#else
#include <X11/Xlib.h>
#endif

/* The pickData structure is copied for the libAnsTclTk shared library. */
/* If any changes are made to this structure, you also need to modify */
/* cAnsPick.h */
typedef struct {
   int      event;      /* The type of event:
                              0 - motion   
                              1 - button down
                              2 - button release
                              3 - key press  
                              4 - key release
                             22 - keyboard event -- pc only
                             98 - apply
                             99 - cancel */
   int      button;     /* Button or Key for event:
                              0 - no button event
                              1 - left mouse button
                              2 - middle mouse button
                              3 - right mouse button
                              n - ascii key for key event  */
   int      bmask;      /* Button Mask  */
   int      ixy[2];     /* Screen X and Y value of the picked location */ 
   int      entitynum;  /* The ANSYS ID for the selected entity */
   int      entitytype; /* The selected entity type which corresponds
                           to PCK_TYPE */
   double   xyz[3];     /* The global cartesian X, Y, and Z location
                           of the picked entity or WP picked location. */
   double   xywp[2];    /* The WP coordinate */
#if !defined(PCWINNT_SYS)
   XEvent eventData;    /* This will be used to store the X event data */
                        /* structure */
#else
   W32Event eventData;  /* This will be used to store the Windows event */
                        /* information.  See the above declared structure */
#endif
   int      ispare[10];
   double   dspare[10];
} pickData;

/* The keyData structure is copied for the libAnsTclTk shared library. */
/* If any changes are made to this structure, you also need to modify */
/* cAnsPick.h */
typedef struct {
#if !defined(PCWINNT_SYS)
   XEvent eventData;    /* This will be used to store the X event data */
                        /* structure */
#else
   W32Event eventData;  /* This will be used to store the Windows event */
                        /* information.  See the above declared structure */
#endif
   int      ispare[10];
   double   dspare[10];
} keyData;

void cAnsPick_EntityInfo(INT iop, INT ival);
   /*
    *    iop  = PCK_PCKSEL  ,0 ---  PCK_UNPCK   0
    *                               PCK_PCK     1
    *           PCK_SLECT   ,1 ---  PCK_SNGL    0
    *                               PCK_BOX     1
    *                               PCK_POLY    2
    *                               PCK_CIRC    3
    *                               PCK_LOOP    4
    */

INT cAnsPick_EntityInqr(INT iop);
   /*
    *    PCK_INFOKEY  = PCK_PCKSEL      , 0 ---  PCK_UNPCK   0
    *                                            PCK_PCK     1
    *                   PCK_SLECT       , 1 ---  PCK_SNGL    0
    *                                            PCK_BOX     1
    *                                            PCK_POLY    2
    *                                            PCK_CIRC    3
    *                                            PCK_LOOP    4
    *                   PCK_TYPE        , 3 ---  Entity Type(s)
    *                   PCK_ENTSEL      , 4 ---  Selection mode (sel,unsel,def)
    *                   PCK_RBMODE      , 5 ---  Rubberband Style
    *                   PCK_DUP         , 6 ---  Allow duplicate picks ?
    *                   PCK_ORDR        , 7 ---  Does order matter
    *                   PCK_ENTMIN      , 8 ---  Minimum picked required
    *                   PCK_ENTMAX      , 9 ---  Maximum picked
    *                   PCK_NLIST       ,10 ---  Number of entities picked
    *                   PCK_NDUP        ,11 ---  Number of duplicate entities picked
    *                   PCK_CUR_ENTNUM  ,12 ---  Current selected entity number
    *                   PCK_CUR_ENTTYP  ,13 ---  Current selected entity type
    *                   PCK_PNUMTYP     ,14 ---  Current number of entity types picked.
    *                   PCK_PTYPE       ,15 ---  Current entity types picked.
    */
void cAnsPick_Entity(INT itype, INT ksel, INT krub, INT dup,
                     INT korder, INT nmn, INT numreq, 
                     void (*externalCallBack)(void *));
void cAnsPick_EntityDump(INT *n, INT **list_ent, INT **list_typ);
void cAnsPick_EntityDone(void);
void cAnsPick_EntityPickAll(void);
void cAnsPick_EntityRange(INT itype, INT key, INT n, INT *idata);
   /*   itype    = entity type
        key      = list or min.max,inc (PK_KB_LIST, PK_KB_RANG)
        n        = number in list
        idata    = entity data          */
void cAnsPick_EntityRestart(INT *n);  /* used for apply  */
void cAnsPick_EntityReset(void);
void cAnsPick_EntityNextDup(void);
void cAnsPick_EntityPrevDup(void);
void cAnsPick_EntityDumpDup(INT *n, INT **list_ent, INT **list_typ);

void cAnsPick_XYZ(INT key, INT krub, INT nmn, INT numreq,  
                  void (*externalCallBack)(void *));
   /*  key -> 0= wp pick,  1= screen pick */
void cAnsPick_XYZDump(INT *nlist, double **list_xyz);
void cAnsPick_XYZDone(void);
void cAnsPick_XYZReset(void);
void cAnsPick_XYZInfo(INT iop, INT ival);
   /*    iop  = PCK_PCKSEL  ,0 ---  PCK_UNPCK   0
    *                               PCK_PCK     1 */
INT  cAnsPick_XYZInqr(INT iop);
   /*    
    *    PCK_INFOKEY  = PCK_PCKSEL      , 0 ---  PCK_UNPCK   0
    *                                            PCK_PCK     1
    *                   PCK_RBMODE      , 5 ---  Rubberband Style
    *                   PCK_ENTMIN      , 8 ---  Minimum picked required
    *                   PCK_ENTMAX      , 9 ---  Maximum picked
    *                   PCK_NLIST       ,10 ---  Number of entities picked 
    */
void cAnsPick_XYZAdd( double *xyz);
INT cAnsGraph_FindWn( INT ptrX, INT ptrY );
void gr_pick_control(void);
void gr_pick_apply(void);
void gr_pick_cancel(void);
void gr_pick_viewev(void);
void gr_lpick_control(void);
void gr_lpick_apply(void);
void gr_lpick_cancel(void);
void gr_lpick_viewev(void);

#if  defined(PCWINNT_SYS)
INT gr_pick_event (struct mouseGraph *event);
INT gr_lpick_event (struct mouseGraph *event);
#endif

/********************************************************/
/*****    system dependant for C/Fortran Interface  *****/
/********************************************************/
#if defined(RS6000_SYS) || defined(HP32_SYS)
    /*  c routines called from fortran  */
#define gr_pickst_       gr_pickst
#define gr_pkdata_       gr_pkdata
#define gr_point_add_    gr_point_add
#define gr_point_remove_ gr_point_remove
    /*  fortran routines called from c  */
#define gr_pkentg_    gr_pkentg
#define gr_picent_    gr_picent
#define gr_ls_loop_   gr_ls_loop
#define gr_ar_shel_   gr_ar_shel
#endif

#if defined(WATCOMC_SYS) \
    || defined(PCWINNT_SYS)
    /*  c routines called from fortran  */
#define gr_pickst_       GR_PICKST
#define gr_pkdata_       GR_PKDATA
#define gr_point_add_    GR_POINT_ADD
#define gr_point_remove_ GR_POINT_REMOVE
    /*  fortran routines called from c  */
#define gr_picent_    GR_PICENT
#define gr_pkentg_    GR_PKENTG
#define gr_ls_loop_   GR_LS_LOOP
#define gr_ar_shel_   GR_AR_SHEL
#endif

#if defined(WATCOMC_SYS) 
    /*  c routines called from fortran  */
#pragma aux GR_PICKST "^";
#pragma aux GR_PKDATA "^";
#pragma aux GR_POINT_ADD "^";
#pragma aux GR_POINT_REMOVE "^";
    /*  fortran routines called from c  */
#pragma aux GR_PKENTG "^";
#pragma aux GR_PICENT "^";
#pragma aux GR_LS_LOOP "^";
#pragma aux GR_AR_SHEL "^";
#endif

/*******************************************************/
/**********  FUNCTION RETURN TYPE DECLARATION **********/
/*******************************************************/
#if !defined(PCWINNT_SYS)
    /*  C routines called from FORTRAN  */ 
   void   gr_pickst_( INT *iptr1, INT *iptr2);
   void   gr_pkdata_( INT *itype, INT *ksel, INT *n, INT *nara, double *xyz, 
                      INT *xy, INT *nent, INT *nentmax, INT *work);
   void   gr_point_add_(INT *itype, INT *entadd);
   void   gr_point_remove_(INT *itype, INT *entrem);
    /*  FORTRAN routines called from C  */
   void   gr_pkentg_( INT *, INT*, INT*);
   void   gr_picent_( INT *, INT*, INT*);
   void   gr_ls_loop_(INT *, INT *, INT *);
   void   gr_ar_shel_(INT *, INT *, INT *);
#else
    /*  C routines called from FORTRAN  */
   void   CALLTYP  gr_pickst_( INT *iptr1, INT *iptr2);
   void   CALLTYP  gr_pkdata_( INT *itype, INT *ksel, INT *n, INT *nara, double *xyz, 
                               INT *xy, INT *nent, INT *nentmax, INT *work);
   void   CALLTYP gr_point_add_( INT *, INT * );
   void   CALLTYP gr_point_remove_( INT *, INT * );
    /*  FORTRAN routines called from C  */
   extern void CALLTYP gr_pkentg_( INT *, INT*, INT*);
   extern void CALLTYP gr_picent_( INT *, INT*, INT*);
   extern void CALLTYP gr_ls_loop_( INT *, INT *, INT * );
   extern void CALLTYP gr_ar_shel_( INT *, INT *, INT * );
#endif
