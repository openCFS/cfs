/* sid 50.1 copy of coefm.h last changed by upd111 on 2005/06/04 13:21:33 */
/* coefm.h CADOE  */
/*
 * coefm.h
 *
 * $Id$
 *   
 * HISTORY
 *   
 *   09/25/00 11:19 <       Brian Jantzen> Rel:ms8m1    SCCA:79107  Delta:81.4
 *   
 *   06/28/00 10:47 <       Brian Jantzen> Rel:ms8m1    SCCA:74542  Delta:81.3
 *   
 *   06/21/00 16:30 <       Brian Jantzen> Rel:ms8m1    SCCA:74307  Delta:81.2
 *   
 *   01/13/00 11:20 <        Marc Gadbois> Rel:ms8      SCCA:65669  Delta:8.3
 *   
 *   09/30/99 17:38 <         James Silva> Rel:ms8      SCCA:56512  Delta:8.2
 */

#ifndef __coefmh__
#define __coefmh__ 1

#ifndef __expmdbstructh__
#include "expmdb_struct.h"
#endif

#ifdef __cplusplus
extern "C" {
#endif

extern T_statut CFM_etendre_coefficient( T_Coefm*, IVEC* );
extern T_statut CFR_etendre_coefficient( T_Coefr*, IVEC* );
extern T_statut CFM_boutput( T_Coefm *Coef, FILE *fichier );
extern T_statut CFR_boutput( T_Coefr *Coef, FILE *fichier );
extern T_Coefm *CFM_binput( FILE *fichier, T_Coefm *coefm, double, T_statut *ier );
extern T_Coefr *CFR_binput( FILE *fichier, T_Coefr *coefr, double, T_statut *ier );
extern T_statut CFM_upgrader_coef( T_Modele *);

#ifdef __cplusplus
}
#endif

#endif
