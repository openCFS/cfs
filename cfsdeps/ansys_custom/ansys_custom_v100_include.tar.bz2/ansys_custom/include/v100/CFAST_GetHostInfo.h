/* sid 50.1 copy of CFAST_GetHostInfo.h last changed by upd111 on 2005/06/04 13:22:54 */
/* CFILE CFAST_GetHostInfo.h CADOE */
#ifndef _CFAST_GetHostInfo
#define _CFAST_GetHostInfo

#include "CFAST_Exception.h"
#ifndef WINNT
    #include <arpa/inet.h>
    #include <netdb.h>
    #include <netinet/in.h>
    #include <sys/socket.h>
#else
    #include <winsock2.h>
    #define in_addr_t unsigned long
#endif
    
enum hostType {NAME, ADDRESS};

class CFAST_GetHostInfo
{
#ifndef WINNT
    char cIteratorFlag;        // Host database iteration flag
#endif
    struct hostent *hostPtr;    // Entry within the host address database
public:
#ifndef WINNT
    // Default constructor.  Opens the host entry database
    CFAST_GetHostInfo()
    {
        vOpenHostDb();
    }
#endif
    // Retrieves the host entry based on the host name or address
    CFAST_GetHostInfo(const char *_sHostName, hostType _type);

    CFAST_GetHostInfo(in_addr_t *_netAddr);

    // Destructor.  Closes the host entry database.
    ~CFAST_GetHostInfo()
    {
#ifndef WINNT
        endhostent();
#endif
    }
#ifndef WINNT
    // Retrieves the next host entry in the database
    char cGetNextHost();

    // Opens the host entry database
    void vOpenHostDb()
    {
        endhostent();
        cIteratorFlag = 1;
        sethostent(1);
    }
#endif
    // Retrieves the hosts IP address
    char *sGetHostAddress() 
    {
        struct in_addr *addr_ptr;
        addr_ptr = (struct in_addr *)*hostPtr->h_addr_list;
        return inet_ntoa(*addr_ptr);
    }    
    
    // Retrieves the hosts name
    char *sGetHostName()
    {
        return hostPtr->h_name;
    }

    // Gets the system error
    char *sGetError()
      {
	#if defined(WINNT)
       	  static char buf[10];
	  sprintf(buf, "%d", WSAGetLastError());
	  return buf;
        #else
	  return NULL;
	#endif
      }
};

#endif
