/* sid 50.2 copy of FEM_pave.h last changed by jtm on 2004/11/05 14:33:51 */
/*  FEM_pave.h */
/*
 * *** ansys(r) copyright(c) 1999
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_pave.h
 *  header file for FEM_pave.c
 *
 */
#ifndef FEM_PAVE_INCLUDE
#define FEM_PAVE_INCLUDE

#ifdef __cplusplus
extern "C" {
#endif

                             /* === FEM_pave: convert tris to quads           */
INT FEM_pave (
   INT anum,                         /* (IN) Number of area to be paved       */
   NODELIST_OBJ obj_nlist,           /* (IN) node list                        */
   EDGELIST_OBJ obj_edlist,          /* (IN) edge list                        */
   FACELIST_OBJ obj_flist,           /* (IN) face list (all triangles)        */
   DOUBLE seam_angle1,               /* (IN) angle tolerance ?                */
   DOUBLE seam_angle2,               /* (IN) angle tolerance ?                */
   DOUBLE split_angle,               /* (IN) angle tolerance ?                */
   DOUBLE close_split_angle,         /* (IN) angle tolerance ?                */
   INT smooth_type,                  /* (IN) type of smoothing to perform     */
                                     /*      1: Blacker smoothing with avg siz*/
                                     /*      2: Blacker smoothing             */
                                     /*      3: laplacian smoothing           */
                                     /*      4: project smoothing             */
                                     /*      2: optimization smoothing        */
   INT debug  );                     /* (IN) debug flag                       */
                                     /*         debug==0: no debugging.       */
                                     /*         debug<0:  check states only.  */
                                     /*         debug>0:  do debugging        */
                                     /*         debug>=3: do debugging and    */
                                     /*                   check states.       */


                            /* === FEM_pvGetFronts: get boundary segments     */
                            /* === (fronts) remaining after paving            */
INT FEM_pvGetFronts (
   INT **pa_bsegm,                   /* return array of boundary segments     */
   INT *p_numseg,                    /* number of boundary segments           */
   INT *p_nloops  );                 /* number of loops                       */

                            /* === Function: FEM_pvCleanUp: clean up memory   */
                            /* === and stuff after paving                     */
void FEM_pvCleanUp(
   INT status );
#ifdef __cplusplus
}
#endif

#endif
