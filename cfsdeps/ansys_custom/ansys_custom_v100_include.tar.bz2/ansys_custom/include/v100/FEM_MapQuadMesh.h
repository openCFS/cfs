/* sid 50.1 copy of FEM_MapQuadMesh.h last changed by upd111 on 2004/11/04 18:29:44 */

/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 1999 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_MapQuadMesh.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_MapQuadMesh.h
 *  header file for FEM_MapQuadMesh.c
 *
 */
#ifndef FEM_MAP_QUAD_MESH_INCLUDE
#define FEM_MAP_QUAD_MESH_INCLUDE

#define UNKNOWN_TYPE    0
#define REVERSAL        1
#define CORNER          2
#define SIDE            3
#define END             4
#define DEGEN_SIDE      5
#define CLOSED_SIDESIDE (2*SIDE)    /* 6 */
#define CLOSED_ENDSIDE  (END+SIDE)  /* 7 */
#define CLOSED_ENDEND   (2*END)     /* 8 */

#define NUM_CORNER_REVERSAL        4
#define NUM_CORNER_CORNER          3
#define NUM_CORNER_SIDE            2
#define NUM_CORNER_END             1
#define NUM_CORNER_CLOSED_SIDESIDE (2*NUM_CORNER_SIDE)               /* 4 */
#define NUM_CORNER_CLOSED_ENDSIDE  (NUM_CORNER_END+NUM_CORNER_SIDE)  /* 3 */
#define NUM_CORNER_CLOSED_ENDEND   (2*NUM_CORNER_END)                /* 2 */


/*----------------- Globally accessible function prototypes -----------------*/

#ifdef __cplusplus
extern "C" {
#endif

                      /* ==================================================== */
                      /* === FEM_mqMapMeshArea: given an area number, map     */
                      /* === mesh the area.  Assumes all boundary nodes are   */
                      /* === at the beginning of the obj_nlist and are already*/
                      /* === projected to the parametric space of the area.   */
                      /* === Corners specified by calling FEM_mqSetCorners    */
                      /* === will be used as corners of the map mesh.         */
                      /* === Return: EXIT_SUCCESS or EXIT_FAILURE             */
                      /* ==================================================== */
INT FEM_mqMapMeshArea(
   INT area,          /* (IN)  area to map mesh                               */
   INT num_bound,     /* (IN)  number of boundary nodes.                      */
   INT non_manifold,  /* (IN)  TRUE if area is non-manifold, but not closed.  */
   INT midnodes,      /* (IN)  TRUE if area area needs midnodes.              */
   INT project,       /* (IN)  0 if straight midnodes, 1 if projected midnodes*/
   INT debug,        /* (IN)  debug flag.                                    */
   INT *numDistinctRegions ); /* (IN) number of distinct regions, >1 for periodics */
                      /* ==================================================== */



                      /* ==================================================== */
                      /* === FEM_mqSetCorners: Specify which keypoints should */
                      /* === be used as corners for meshing.                  */
                      /* === Return: EXIT_SUCCESS or EXIT_FAILURE             */
                      /* ==================================================== */
INT FEM_mqSetCorners(
   INT num_kps,       /* (IN)  The number of kps that are to be assigned as a */
                      /*       corner, etc.                                   */
   INT *a_kps,        /* (IN)  List of kp ids that are being specified.       */
   INT *a_kpstat,     /* (IN)  List parallel to a_kps specifying type at each */
   FEM_BOOLEAN flag );/* (IN)  If TRUE, then any node not at a keypoint in    */
                      /*       a_kps will be assumed to be a SIDE.            */
                      /*       If FALSE, then the angle at each node not at   */
                      /*       a keypoint in a_kps will be calculated and the */
                      /*       type will be assigned accordingly.             */
                      /* ==================================================== */



                      /* ==================================================== */
                      /* === FEM_mqSetCornerNodes: Specify which nodes should */
                      /* === be used as corners for meshing.                  */
                      /* === Return: EXIT_SUCCESS or EXIT_FAILURE             */
                      /* ==================================================== */
INT FEM_mqSetCornerNodes(
   INT num_nodes,     /* (IN)  The number of nodes that are to be assigned as */
                      /*       a corner, etc.                                 */
   NODE_OBJ *aobj_nodes,/*(IN) List of node that are being specified.         */
   INT *a_stat,       /* (IN)  List parallel to aobj_nodes specifying type at */
                      /*       each                                           */
   FEM_BOOLEAN flag );/* (IN)  If TRUE, then any node not in aobj_nodes will  */
                      /*       be assumed to be a SIDE.  If FALSE, then the   */
                      /*       angle at each node not in aobj_nodes will be   */
                      /*       calculated and the type will be assigned       */
                      /*       accordingly.                                   */
                      /* ==================================================== */


                      /* ==================================================== */
                      /* === FEM_mqDeleteCorners: Free memory used to store   */
                      /* === corners.                                         */
                      /* === Return: EXIT_SUCCESS or EXIT_FAILURE             */
                      /* ==================================================== */
void FEM_mqDeleteCorners( void );

#ifdef __cplusplus
}
#endif

#endif

