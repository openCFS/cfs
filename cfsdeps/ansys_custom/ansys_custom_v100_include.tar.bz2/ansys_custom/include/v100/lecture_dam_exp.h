/* sid 50.1 copy of lecture_dam_exp.h last changed by smarguer on 2005/01/25 15:46:48 */
/* lecture_dam_exp.h CADOE  */
/*
 * lecture_dam.h
 *
 * $Id$
 *   
 * HISTORY
 *   
 *   06/28/00 10:47 <       Brian Jantzen> Rel:ms8m1    SCCA:74542  Delta:81.3
 *   
 *   06/21/00 16:30 <       Brian Jantzen> Rel:ms8m1    SCCA:74307  Delta:81.2
 */

#ifndef __lecturedamexph__
#define __lecturedamexph__ 1

#ifndef __expmdbstructh__
#include "expmdb_struct.h"
#endif

#include "bf.h"
#include "cbf.h"

#ifdef __cplusplus
extern "C" {
#endif

  extern T_Mesh *MSH_find_mesh ( T_Modele *, char *, char*, T_statut * );
  extern T_statut MSH_delete_mesh ( T_Modele *, T_Mesh * ); 

extern T_statut DAM_lire_entete( T_cbf*, T_Modele* );

extern T_statut DAM_lire_maillage_5 ( T_cbf *, T_Modele * );
extern T_statut DAM_lire_entete_maillage ( T_cbf *, T_Modele * );
extern T_statut DAM_lire_maillage_6_data ( T_cbf *cbf, T_Mesh *mesh );
extern T_statut cbf_dam_lecture_maillage_data_6_1 ( FILE *vaf, T_Mesh *mesh );

extern T_Mesh	*MSH_find_mesh_in_file ( T_cbf*, T_Modele *, char *, T_statut * );

extern T_ltete	*DAM_lire_repinit_5 ( T_cbf *, T_statut * );
extern T_ltete	*DAM_lire_repere_init_6 ( T_cbf *, int, T_statut * );
extern T_ltete	*DAM_lire_repere_pert_6 ( T_cbf *, int, int, T_statut * );
extern T_ltete	*DAM_lire_repere_pert_5 ( T_cbf *, int, T_statut * );
extern T_Config *DAM_lire_parametres_config ( T_cbf *, T_cbf_header *, int, int, T_statut * );
extern T_Config *DAM_lire_config_suivante ( T_cbf *, T_cbf_header *, int, T_statut * );
extern T_statut	DAM_lire_groupes ( T_cbf *cbf, T_Mesh *mesh);
extern T_statut	DAM_lire_propriete_element ( char *nom_fic, T_Mesh *mesh );
extern T_statut	MSH_maj_liste_mesh ( T_Modele *modele );
extern T_Mesh	*MSH_find_mesh_by_numero ( T_Modele *modele, int numero, T_statut *ier );



extern void* cbf_lire_config ( FILE *, void ** , T_statut * );
extern void *cbf_dam_lire_repinit ( FILE *, void **, T_statut * );
extern void *cbf_dam_lire_pert_rep ( FILE *, void **, T_statut * );
extern void *cbf_dam_lire_pert_config ( FILE *, void **, T_statut * );
extern void *cbf_dam_lire_maillage ( FILE *vaf, void **vmod, T_statut *ier );
extern T_statut cbf_dam_lecture_maillage_ivec ( FILE *vaf, T_Mesh * );
extern T_statut	MSH_load_mesh_exp ( T_Modele *modele );
extern T_statut MSH_load_mesh_sans_element ( T_Modele *modele );
extern T_statut DAM_lire_noeuds_vtx ( T_cbf *cbf, T_Mesh *mesh);

#ifdef __cplusplus
}
#endif

#endif
