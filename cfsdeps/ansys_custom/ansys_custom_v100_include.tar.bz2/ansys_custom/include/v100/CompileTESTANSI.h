/* sid 50.1 copy of CompileTESTANSI.h last changed by upd111 on 2005/06/04 13:16:24 */
/*
 * *** ansys(r) copyright(c) 2000
 * *** ansys, inc.
 */
/* This is a header file created for the express porpoise of 
 * confusing the ansi compiler by making TESTv7.c mixed 
 * K&R and ANSI C  -- mjr  2.14.97
 */
/*-----------------Function Prototypes---------------------------*/

static int dummy1(int I1, float F1);

static int dummy2(int I2, float F2);

static int dummy3(int I3, float F3, char C3);

static int dummy4(int *ptr, double *ptr2, 
            int (*func)(void), double (*func2)(void));

void test_dummy(void);
void test_dummie(void);

/*----------------------------------------------------------------*/
