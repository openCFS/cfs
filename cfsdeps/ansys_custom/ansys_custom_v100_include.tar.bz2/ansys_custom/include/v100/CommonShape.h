/* sid 50.1 copy of CommonShape.h last changed by upd111 on 2005/06/04 13:15:00 */
/*
 * *** ansys(r) copyright(c) 2000
 * *** ansys, inc.
 */
#if defined(XOX_DEBUG)
#define CALLTYP
typedef int INT;
typedef  void VOID;
#include "ansproto.h"
#endif

#if !defined(include_xoxbolh)
#define include_xoxbolh
#include "xoxbol.h"
#endif
#include "shapesmt.h"
