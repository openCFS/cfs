/* sid 50.1 copy of Connectivity.h last changed by upd111 on 2005/06/04 13:18:42 */
#ifndef _CONNECTIVITY_H_
#define _CONNECTIVITY_H_

#include <stdio.h>
#include "DomainDec.h"


class Elemset;
class EqNumberer;

// component data structure
struct compStruct {
  INT numComp; // number of components
  INT *xcomp;  // poINTer to renum for the beginning of each component 
  INT *order;  // order of the nodes
  INT *renum;  // renumbering
};

#ifdef DISTRIBUTED
class SysCom;
#endif

class Connectivity {
protected:
        INT size;           // size of poINTer
        INT numtarget;      // size of target, number of Connections
        INT *poINTer;       // poINTer to target
        INT *target;        // value of the connectivity
        float *weight;      // weights of poINTer (or NULL)
protected:

        Connectivity(){ size = 0; numtarget = 0; 
                        poINTer = (INT*)0; target= (INT*) 0, 
                        weight = (float*) 0;}

 public:
        Connectivity(Elemset *);
        Connectivity(INT _size, INT *_poINTer, INT *_target);
        Connectivity(INT _size, INT *_count);
        Connectivity(INT ns);


        ~Connectivity();

        INT *operator[](INT i);
        INT csize();

        // Added Functions from TOP/DOMDEC Connectivity class
        INT numNonZeroP();
        virtual void end_count();
        void countlink(INT from, INT to);
        void addlink(INT from, INT to);

        INT numConnect(); // Total number of connections
        INT num(INT);
        INT num(INT, INT*);
        INT offset(INT i) { return poINTer[i]; } // Begining of ith part
        INT offset(INT i,INT j); // returns a unique id for connection i to j
        Connectivity* reverse(float *w = 0); // creates t->s from s->t
        Connectivity* transcon( Connectivity* );

        void findPseudoDiam(INT *n1, INT *n2, INT *mask=0);
        INT  rootLS(INT root, INT *xls, INT *ls, INT &w, INT *mask=0);

        // Create a rooted level structure
        INT *renumSloan(INT *mask, INT &firstNum, INT *ren = 0);
        INT *renumRCM(INT *mask, INT &firstNum, INT *ren = 0);
        INT *renumSloan();
        compStruct renumByComponent(INT);
        void prINT(FILE * = stdout);
        INT findMaxDist(INT *);
        INT findProfileSize( INT *);

        INT *getP() { return poINTer; }
        INT *getT() { return target; }

#ifdef DISTRIBUTED
        void broadcast(SysCom *sc);
        Connectivity(SysCom *sc);
#endif
};

inline INT
Connectivity::csize() { return size; }

inline INT
Connectivity::num(INT n) 
     { return (n >= size) ? 0 : poINTer[n+1] - poINTer[n]; }

inline INT *
Connectivity::operator[](INT i) { return target +poINTer[i] ; }

inline INT
Connectivity::numConnect() { return numtarget; }

class CountedConnectivity: public Connectivity {
     INT *cnt;
  public:
     CountedConnectivity(INT ns);
     ~CountedConnectivity();
     INT count(INT n);
     void end_count();
     void remove(INT from, INT to);
};


#endif
