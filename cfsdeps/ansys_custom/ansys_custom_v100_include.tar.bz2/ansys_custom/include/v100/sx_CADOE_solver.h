/* sid 50.8 copy of sx_CADOE_solver.h last changed by eedelor on 2005/05/23 15:28:50 */
/* CADOE */
/*******************************************************************************
 *
 *   CADOE_solver.h -- structures c CADOE_solver
 *              
 * 
 * |Module: CADOE_solver
 *
 * |Description: structures CADOE_solver
 *
 * |Includes:	
 *        
 * |Auteur: Jean-Daniel Beley
 *
 * |Creation: Avril 1999
 *
 * |Version: $Id$
 *
 * |Copyright:	Copyright(c) CADOE 1999
 *
 *   
 ******************************************************************************/
#ifndef __CADOE_SOLVER_H_DEJA_INCLUS__
#define __CADOE_SOLVER_H_DEJA_INCLUS__ 1

#include "cadoe.h"
#include "sx_cons_solver.h"
#include "m_matrix.h"
#include "liste_chainee.h"
#include "adoc.h"
#include "parametre.h"
#include "hash_util.h"
#include "sx_version.h"
#include "lmb.h"

struct __mode;
struct __adr_mod;
struct __body_load;
struct __der_body_load;
struct __champ_elem;
struct __champ_node;
struct __champ_global;
struct __champ_local;
struct __cond_lim_elem;
struct __cond_lim_elem_der;
struct __element;
struct __integration;
struct __modele;
struct __mod_phys;
struct __noeud;
struct __propriete;
struct __prop_elem;
struct __der_prop_elem;
struct __der_modele;
struct __der_repere;
struct __groupe;
struct __repere;
struct __critere;
struct __adr_bloc_res;
struct __res_cas_charge;
struct __resolution;
struct __optim;
struct __res_optim;
struct __scal2func;
struct __pg2noe;
struct __mapcrit;
struct __majutile;
struct __methode;
struct __resnat;
struct __transbase;
struct __obj_etude;
struct __tableau_resultat;
struct __menu_comp;
struct __structure_post;

typedef struct __mode T_mode;
typedef struct __adr_mod T_adr_mod;
typedef struct __body_load T_body_load;
typedef struct __der_body_load T_der_body_load;
typedef struct __champ_elem T_champ_elem;
typedef struct __champ_node T_champ_node;
typedef struct __champ_global T_champ_global;
typedef struct __champ_local T_champ_local;
typedef struct __cond_lim_elem T_cond_lim_elem;
typedef struct __cond_lim_elem_der T_cond_lim_elem_der;
typedef struct __element T_element;
typedef struct __integration T_integration;
typedef struct __modele T_modele;
typedef struct __mod_phys T_mod_phys;
typedef struct __noeud T_noeud;
typedef struct __propriete T_propriete;
typedef struct __prop_elem T_prop_elem;
typedef struct __der_prop_elem T_der_prop_elem;
typedef struct __der_modele T_der_modele;
typedef struct __der_repere T_der_repere;
typedef struct __groupe T_groupe;
typedef struct __repere T_repere;
typedef struct __critere T_critere;
typedef struct __res_cas_charge T_res_cas_charge;
typedef struct __resolution T_resolution;
typedef struct __optim T_optim;
typedef struct __res_optim T_res_optim;
typedef struct __scal2func T_scal2func;
typedef struct __pg2noe T_pg2noe;
typedef struct __mapcrit T_mapcrit;
typedef struct __majutile T_majutile;
typedef struct __methode T_methode;
typedef struct __resnat T_resnat;
typedef struct __transbase T_trans_base;
typedef struct __obj_etude T_obj_etude;
typedef struct __tableau_resultat T_tableau_resultat;
typedef struct __menu_comp T_menu_comp;
typedef struct __structure_post T_structure_post;

typedef double (*T_fct_compo) ( E_mode_analyse, double *, int );

/*
 *--------------------- OBJET ADRESSAGE MODELE-------------------------
 */

struct __adr_mod {
  int nb_inconnues;		/*  Nombre d'inconnues */
  T_modele *modele;		/* Modele porte par l'adressage */
  IVEC *num_inc_elem;		/* Numeros des ddl par element */
  IVEC *nb_elem_noeud;          /* Tableau des nombres d'elements par noeud */
  IVEC *connec_inv;             /* Tableau des elements par noeud */
  IVEC *pcon_inv;               /* Pointeur dans le tableau de connectivite inverse */
};

/*
 *--------------------- OBJET BODY LOAD -------------------------
 */

struct __body_load {
  T_groupe *component;
  double acel[3];
  double cgloc[3];
  double cgomga[3];
  double dcgomg[3];
  double cmdomega[3];
  double cmomega[3];
  double domega[3];
  double omega[3];
  T_der_body_load *der_bl;
};
/*
 *--------------------- OBJET BODY LOAD -------------------------
 */

struct __der_body_load {
  int order;
  double taylor_acel[3*(ORDRE_MAX+1)];
  double taylor_cgloc[3*(ORDRE_MAX+1)];
  double taylor_cgomga[3*(ORDRE_MAX+1)];
  double taylor_dcgomg[3*(ORDRE_MAX+1)];
  double taylor_cmdomega[3*(ORDRE_MAX+1)];
  double taylor_cmomega[3*(ORDRE_MAX+1)];
  double taylor_domega[3*(ORDRE_MAX+1)];
  double taylor_omega[3*(ORDRE_MAX+1)];
  double acel_upd[3];
  double cgloc_upd[3];
  double cgomga_upd[3];
  double dcgomg_upd[3];
  double cmdomega_upd[3];
  double cmomega_upd[3];
  double domega_upd[3];
  double omega_upd[3];
};

/*
 *------------- OBJET CHAMP ELEMENTAIRE -------------
 */

struct __champ_elem {
  E_resultat_parametre type_physique;	/*  Type physique */
  int harmonique;			/*  Numero d'harmonique */
  T_element *element;			/*  Element associe au champ */
  int dim;				/*  Nombre de composantes du champ elementaire */
  double *ve;				/*  Vecteur de stockage du champ */
  int cas_charge;       		/*  Cas de charge associe au champ elementaire */
};

/*
 *------------- OBJET CHAMP LOCAL -------------
 */

struct __champ_local{
  E_resultat_parametre type_physique;	/*  Type physique */
  int harmonique;			/*  Numero d'harmonique */
  int nb_champ_elem;			/*  Nombre de champs elementaires */
  T_champ_elem **champ_elem;		/*  Liste des adresses des champs elementaires */
  T_modele *modele;			/*  Modele associe au champ */
  VEC *valeur;				/*  Valeur du champ par element et par point d'integration */
  T_booleen ownMemoryValeur;
  double coefficient;			/*  Coefficient associe au champ */
  unsigned int adrext_dim;		/* allocated size of adrext */
  int *adrext;				/* store addresses to accelerate GRP_extraire_res() */
};

/*
 *------------- OBJET CHAMP NODAL -------------
 */

struct __champ_node {
  E_resultat_parametre type_physique;	/*  Type physique */
  T_noeud *noeud;			/*  Noeud associe au champ */
  int dim;				/*  Nombre de composantes du champ nodal */
  double    *ve;        		/*  Vecteur de stockage du champ */
  T_complex *zve;	 		/*  Vecteur de stockage du champ complexe */
};
/*
 *------------- OBJET CHAMP GLOBAL -------------
 */

struct __champ_global {
  E_resultat_parametre type_physique;	/*  Type physique */
  int nb_champ_node;			/*  Nombre de champs nodaux */
  int cas_charge;                	/*  Cas de charge associe au champ global */
  T_champ_node *champ_node;             /*  Vecteur des champs nodaux */
  T_modele *modele;			/*  Modele associe au champ */
  VEC *valeur;				/*  Vecteur de stockage du champ */
  ZVEC *zvaleur;                        /*  Vecteur de stockage du champ complexe */
  IVEC *combien;                        /* number of results per node for averaging */
  unsigned int adr_dim; 		/* allocated size of adr */
  unsigned int adrns_dim; 		/* allocated size of adrns */
  double **adr; 			/* store addresses to accelerate CHG_moyenner() */
  T_champ_node **adrns;			/* store addresses to accelerate CHG_moyenner_ns() */
};

/*
 *------------- OBJET CONDITION AUX LIMITES ELEMENTAIRE -------------
 */

struct __cond_lim_elem {
  int id;			/*  CL Id */
  int type;            		/*  Type de condition ( blocage, blocage oblique ... ) */
  int nb_termes;		/*  Nombre de degres de liberte par noeud */
  T_noeud **noeud;		/*  Liste des adresses des noeud */
  IVEC *codage_ddl;		/*  Liste des codages de ddl */
  VEC *coef;			/*  Liste des coefficients */
  T_cond_lim_elem *next;	/*  Cas de plusieurs equations liees */
  T_cond_lim_elem_der *dc;	/*  Derivative */
};

/*
 *------------- OBJET CONDITION AUX LIMITES ELEMENTAIRE -------------
 */

struct __cond_lim_elem_der {
  int ordre;
  VEC *dcoef;
  VEC *update;
  double dp;
};


/*
 *------------------------- OBJET ELEMENT --------------------------
 */
struct __element{
  unsigned int type_geometrique:27;	/* solver context code */
  unsigned int solveur:5;  /*  Type geometrique. */
  int numero;				/*  Numero utilisateur */
  int indice;				/*  Indice dans la liste du modele */
  unsigned int nb_sig:9;	/*  Number of stresses */
  unsigned int nb_ddl:10;	/*  Number of cumulated degres of freedom */
  unsigned int nb_noeud:7;	/*  Nombre de noeuds */
  unsigned int degenere:1; /* est un element degenere <=> contient des noeuds dupliques */
  unsigned int res[2];                  /*  Result mask on the element -> floor(TAILLE_TYPE_RES/NB_BIT_PER_INT+1) */
  T_propriete *prop_mat;		/*  Propriete materiau */
  T_propriete *prop_phy;		/*  Propriete physique */
  T_propriete *prop_num;		/*  Propriete numeriques */
  T_noeud **noeud;	        	/*  Liste des adresses des noeuds */
  T_noeud *orient_node;                 /*  Orientation node */
  T_integration *integration;		/*  Integration */
};

struct __integration{
  int nb_point;			/*  Nombre de points d'integration */
  double *point;		/*  Coordonnees des points */
  double *poids;		/*  Poids d'integration */
  double *fonction;		/*  Valeurs des fonctions de forme */
  double *derivee;		/*  Derivees des fonctions de forme */
};

struct __mapcrit{
  int crit_ext;			/* User criterion */
  E_critere crit_int;		/* Internal criterion */
  E_creagroup creagroup;	/* Location */
} ;

/* Integration point / Node results mapping table */
struct  __pg2noe{
  E_resultat_parametre champ_pg;
  E_resultat_parametre champ_noe;
};

struct __scal2func{
  E_math_scal scalarisation;
  T_fct_compo fct_compo;
} ;

/*
 *------------------------- OBJET MODE ----------------------------
 */
struct __mode {
  int numero;			/* Label du resultat ideas */
  T_booleen actif;		/* Actif si retenu par l'utilisateur */
  char nom[64];                 /* Nom Ideas + frequence en Hz */
  int num_freq;                 /* Numero dans la base modale */
  T_booleen complexe;           /* Mode complexe ou reel */
  T_complex frequence;            /* Frequence associee */
  double masse_modale;          /* Masse modale */
  T_champ_global *forme;        /* Forme modale */
  T_champ_global *forme_c;        /* Forme modale composantes : ux, uy ,uz, rx, ry, rz, magn U, magn R*/
  T_mode *mode_ref;             /* Mode initial identifie */
  VEC *mac;			/* Modal assurance Criterion */
};

/*
 *------------------------- OBJET MODELE --------------------------
 */
struct __modele{
  int build_date;			/* date du build qui a genere ce modele */
  E_solveur	solveur;		/*  Contexte solveur */
  char nom[257];                     	/*  Nom du probleme */
  T_mod_phys *mod_phys;			/*  Modelisation physique */
  int nb_prop_mat;                      /*  Nb materiaux */
  T_propriete **prop_mat;		/*  Table proprietes materiau */
  int nb_prop_phy;                      /*  Nb proprietes */
  T_propriete **prop_phy;		/*  Table propriete physique */
  int nb_prop_num;                      /*  Nb prop num */
  T_propriete **prop_num;		/*  Table proprietes numeriques */
  int nb_noeud;				/*  Nombre de noeuds */
  T_noeud **noeud;			/*  Liste des adresses des noeuds */
  int nb_element;			/*  Nombre d'elements */
  T_element **element;			/*  Liste des adresses des element */
  int nb_mod_char;                      /*  Nombre de modeles de chargement */
  T_modele **modele_char;               /*  Modeles de chargement */
  int cas_charge;			/*  Numero du cas de charge */
  T_adr_mod *adressage;			/*  Adressage du modele */
  int nb_group;                         /*  Nombre de groupes */
  T_groupe *groupe;                     /*  Groupes */
  int nb_reperes;                       /*  Nombre de reperes locaux */
  T_repere **repere;                    /*  Reperes locaux */
  int dimension;                        /*  Dimension du probleme    */
  T_Htable *hashnoe, *hashele;		/*  Tables de Hash sur les tableaux des noeuds et des elements */
  T_resolution *resolution;		/*  Solve options */
  int nb_bcelem;                      	/*  Nb of BC */
  T_cond_lim_elem **bc;			/*  BC table */
  int nb_bl;                            /*  Number of Body Loads */
  T_body_load **bl;			/*  Body Loads */
  int tab_a_calculer[TAILLE_TYPE_RES];	/*  CONTRAINTE et/ou REACTION  et/ou MASSE, ... */ 
  void *adr_res;			/*  Adressage de l'objet RES */
  int nb_modes;                         /*  Nombre de mode */
  T_liste *base_modale_ref;             /*  Base modale valeur centrale */
  int boset;				/*  Numero de BCS */
  int solset;				/*  Numero de solution set */
  T_booleen axi;			/*  VRAI si modele axi */
  T_structure_post *structpost;
  void *postAdomesh;			/* pointeur sur l'objet CPostAdomesh */
  double version;			/* version, sauvegardee dans la base par l'intermediaire de l'objetu */
  void *epa;			        /* pointeur sur les listes d'elements par parametres */
  char jobName[CADOE_NAMESIZE];		/* jobName (*.db) */
};

/*
 *-------------------- OBJET MODELISATION PHYSIQUE -----------------
 */
struct __mod_phys{
  int 			formulation;		/*  Formulation (bit field, bits = E_formulation */
  E_mode_analyse 	mode_analyse;		/*  Mode_analyse */
  E_type_analyse 	type_analyse;           /*  Statique, dynamique */
  E_nature_materiau 	nature_materiau;	/*  nature du materiau */
  E_modele_amort        modele_amort;           /*  modele d'amortissement */
};

/*
 *-------------------------- OBJET NOEUD -------------------------
 */
struct __noeud{
  int numero;			/*  Numero utilisateur */
  int indice;			/*  Indice dans la liste des noeuds du modele ( numerotation optimisee ) */
  double xyz[3];		/*  Coordonnees du noeud */
  unsigned int nb_ddl:10;	/*  Nombre de ddl du noeud */
  unsigned int nb_peau:5;	/*  Nombre de layers associees au noeud */
  unsigned int est_interne:1;	/*  Indique si le noeud est visible par l'utilisateur ou non */
  unsigned int est_secondaire:1;/*  Indique si le noeud est secondaire */
  int prem_inc;                 /*  1ere inconnue du noeud (numero dans le res du 1er ddl du noeud) */
  T_repere *repere;             /*  Adresse du repere local s'il existe */
  int res[2]; 			/*  Results Mask for this node floor(TAILLE_TYPE_RES/NB_BIT_PER_INT+1) */
};

/*
 *------------------------ OBJET PROPRIETE -------------------------
 */
struct __propriete{
  int  numero;                  /*  Numero de la propriete */
  E_type_propriete  type;	/*  Type de la propriete */
  int  nb_prop_elem;		/*  Nombre de proprietes elementaires */
  T_prop_elem **prop_elem;	/*  Liste des adresses des proprietes elementaires dimensionne au nombre max */
};

/*
 *------------------------ OBJET PROPRIETE ELEMENTAIRE -------------------------
 */
struct __prop_elem{
  int nom;			/*  Nom de la propriete elementaire */
  double val_rel;		/*  Valeur reelle de la propriete */
  T_der_prop_elem *dpe;		/*  Taylor expansion of the property */
};

/*
 *------------------------ propriete DERIVATION PROPRIETE ELEMENTAIRE -------------------------
 */
struct __der_prop_elem{
  int ordre;                	/*  Ordre de derivation de la propriete elementaire */
  double tay_val[ORDRE_MAX+1];	/*  Serie de Taylor de la propriete elementaire */
  double dp;                    /*  Delta parametre */
  double update;     		/*  Valeur updatee de la propriete ou coefficients de la variation affine */
  E_modification_type type;     /*  Type de variation */
};

/*
 *---------------------- OBJET REPERE -------------------------
 */
struct __repere {
  int numero;			/* label */
  E_nature_repere nature;	/*  Nature du repere (cylindrique ou spherique) */
  char nom[40];        		/*  Nom identificateur du repere */
  double origine[3];   		/*  Origine du repere */
  double rot[9];       		/*  Matrice rotation du repere global a ce repere */
  T_der_repere *repd;  		/*  repere derive */
};
  
/*
 *----------------------- OBJET DERIVATION DE MODELE -------------
 */
struct __der_modele{
  int ordre_deriv;			/*  Ordre de derivation */
  int ordre_forme;			/* ordre fourni par Adomesh */
  int ordre_rep;			/* ordre fourni par Adomesh */
  int ordre_temperature;        	/* Ordre fourni par adoc a l'issue du calcul thermique */
  int ordre_relation;   		/* ordre pour les relations lineaires */
  unsigned int frequence_a_deriver:1; 	/* VRAI ou FAUX */
  unsigned int forme_a_deriver:1;	/* VRAI ou FAUX */
  unsigned int physique_a_deriver:1;	/* VRAI ou FAUX */
  unsigned int materiau_a_deriver:1;	/* VRAI ou FAUX */
  unsigned int numerique_a_deriver:1;	/* VRAI ou FAUX */
  unsigned int booleen_a_deriver:1;	/* VRAI ou FAUX */
  unsigned int temperature_a_deriver:1;	/* VRAI ou FAUX */
  unsigned int load_a_deriver:1;     	/* VRAI ou FAUX */
  unsigned int relation_a_deriver:1; 	/* VRAI ou FAUX */
  T_modele *modele;			/*  adresse du modele */
  T_adr_mod *adressage;			/*  Adressage du modele de derivation */
  VEC *vec_param;			/*  Variation vector */
  VEC **liste_perturb_elem;		/*  adresse du champ local de perturbation de maillage */
  VEC *liste_perturb_noe;		/*  adresse des perturbation des noeuds d'orentation */
  VEC *liste_temp_noe;			/*  adresse des temperatures des noeuds */
  IVEC *elem_der_forme;			/* indiquant VRAI ou FAUX pour chaque element du modele */
  IVEC *noeud_der_forme;		/* indiquant VRAI ou FAUX pour chaque noeud du modele */
  IVEC *element_actif;			/* indiquant VRAI ou FAUX pour chaque element du modele */
  IVEC *rep_der_forme;			/* indiquant VRAI ou FAUX pour chaque repere du modele */
  VEC **tay_rep;			/* Serie de Taylor des repere */
  T_champ_global **tay_temp;    	/* Serie de Taylor des temperatures nodales */
  T_champ_global **disp;        	/* Serie de Taylor des coordonnees pour calcul */
  T_cond_lim_elem_der **tcelem; 	/* Serie de Taylor des equations de contraintes */
  T_prop_elem *tay_temp_glob;  		/* Serie de Taylor de la temperature - Cas global */
};

/*
 *----------------------- OBJET DERIVATION REPERE -------------
 */
struct __der_repere{
  int ordre;					/* derivated cs order */
  T_repere *repere;				/* Associated cs */
  double tay_orig[(ORDRE_GEOMETRIQUE+1)*3];	/* Origin Taylor exp */
  double tay_mat[(ORDRE_GEOMETRIQUE+1)*9];	/* Transformation matrix Taylor Exp */
  double update[9];                           	/* Updated matrix  */
};

/* 
 *---------------------- Groupe --------------------------------------
 */
struct __groupe{
  E_nature_groupe nature;		/* NOEUDS ou ELEMENTS */
  char nom[128];			/* Nom du groupe */
  int numero;				/* Numero utilisateur */
  int indice;				/* Indice interne */
  E_stockage_groupe type_stockage; 	/* Stockage par indices ( DIRECT ) ou par codage ( CODAGE ) */
  unsigned int nb_elem;		/* nombre d'entites reellement stockees dans le groupe (diff taille allouee) */
  BVEC * vec;                           /* BVEC contenant les indices/numeros des elements/noeuds du groupe */    
  T_modele *modele;                     /* Modele auquel le modele est attache */
};

/* Update ( properties, geometry ) + available */
struct  __majutile {
  E_transformation transformation;
  T_booleen maj_prop_utile;
  T_booleen maj_geom_utile;
  T_booleen available;
};

/* Calculation method */
struct __methode{
  E_critere critere;			/* Criterion */
  E_resultat_parametre resultat;	/* Basic result */
  E_math_scal scalarisation;		/* local result to local scalar operator */
  E_globalisant globalisant;		/* local to global operator */
  T_booleen modal;			/* Modal criterion */
  T_booleen identifie;			/* identified model criterion */
  int unite;				/* Unit. Pour specifier une unite differente du resultat de base dont le critere est extrait. */
} ;


/* 
 *--------------------- Critere ---------------------------------------
 */
struct __critere{
  char nom[257];                /* Nom du critere */
  int critere;			/* Type de critere ( NODE_STRESS, ... ) */
  T_modele *modele;             /* Modele associe au critere */
  int num_noeud;		/* Indice du noeud !!!!!! ( 0 a nbn )*/
  int num_elem;			/* Indice de l'element !!!!!! ( 0 a nbe ) */
  int num_mode;                 /* Numero du mode */
  int pt_gauss;			/* Numero du point de Gauss ( 1 a npg ) */
  IVEC *composante;		/* Liste de composantes ( de 1 a ... ) */
  E_zcomp zcomp;                /* Composante pour les complexes */
  T_groupe *groupe;             /* Pour les criteres sur des groupes */
  T_groupe *groupebase;         /* Groupe dans le RES */
  int peau;                     /* peau 0, 1 ou 2; -1 pour les 3 */
  int num_charge;		/* numero de cas de charge */
  char nom_charge[41];		/* nom du cas de charge ou de la combinaison */
  VEC *chargement;		/* Combinaison de cas de charges */
  E_comp comp;                  /* Operateur de comparaison pour limitations */
  double limite;		/* Borne pour limitations */
  double precision;		/* Precision pour limitations en egalite */
  T_booleen champ;		/* faux si critere scalaire */
  double valeur;                /* Valeur du critere */
  double valeur_min;		/* Valeur min du critere, en complement pour les max */
  int support;                  /* Lieu pour les max */
  int maj_util;                 /* Precise si MOD_maj_modele est utile pour le calcul du critere */
  VEC *vec_param;               /* parametres au point courrant */
  VEC *ini_param;               /* valeurs centrales des parametres */ 
  int ind_param;                /* indice du parametre critere */
  T_critere *critref;           /* Critere interne ou externe relie */
  T_res_cas_charge *resultat;	/* Resultat final sur le critere */
  double scale;	         	/* scale factor pour le deformed model uniquement */
  int scale_type;		/* type de scale factor pourcentage ou unite */   
  T_booleen show_error;		/* option show error */
  T_booleen absolu;		/* option valeur absolue */
  T_booleen negatif;		/* option valeur negatives */
  T_booleen minimum;		/* search over the minimum instead of maximum */
  int code_repere;		/* vaut CSC_NODAL, CSC_GLOBAL ou 1 label de repere */
  T_repere *repere;		/* Coordinate System */
  int type_accuracy;
};

/*
 *---------------------- Optimisation ----------------------------------
 */
struct __optim{
  char nompb[257];		/* Optimisation set name */
  char nom_van[257];		/* Polynomial Results database name */
  E_goal goal;                  /* Minimisation, maximisation */
  T_modele *modele;             /* pointeur sur le modele */
  VEC *vec_param;          	/* pointeur sur le vec_param */
  VEC *X_param;            	/* pointeur sur le X_param */
  BVEC *tabi;                   /* Tab indice dans le X_param */
  int maxeval;           	/* Nombre maxi d'evaluations */
  T_critere *fcout;      	/* Critere fonction objectif */
  int nb_limitations;		/* Nombre de criteres limitations */
  T_liste *limitations;	        /* Vecteur des limitations */
  T_liste *lcr;                 /* Liste complete des limitations et de la fonction cout */
  E_meth_opt meth_opt;		/* Methode de traitement */
  VEC *dmin, *dmax;		/* Bornes parametriques a traiter */
  T_res_cas_charge *res_cas;    /* Vecteur des resultats de chacun des cas de charges */
  T_res_optim *res_optim;       /* Resultats de l'optimisation */
  VEC    *point_init;           /* Point de depart de l'optimisation */
  double  coef_pas;             /* Coefficient definissant la taille du premier pas 1D */
  double  penalite_init;        /* Penalite initiale */
  double  penalite_max ;        /* Penalite maximale */
  double  penalite_coef;        /* Coefficient d'augmentation de la penalite */
  VEC     *precision_param;     /* Precision sur les parametres en pourcentage de la plage */
  double  precision_cout;       /* precision sur la variation du cout pour la convergence globale */
  double  glob_precision_param; 
  int     prec_cout_flag;       /* 0 si precision absolue 1 si precision en pourcentage */
  int     affichage;            /* Niveau d'affichage 0->Rien 1->Min 2->Moy 3->Max */
  int     courbes_conv;         /* Courbes de convergence des differentes boucles 0->non 1->oui */
  double   prec_1D;         /* precision necessaire sur la longueur du pas a la convergence de F-R */ 
  double   prec_lag;        /* precision necessaire sur le lagrangien a la convergence de F-R */           
  FILE     *conv_graph_FR;  /* fichier d'evoluiton de la fonction cout */
  FILE     *conv_graph_Lag; /* fichier d'evolution du lagrangien augmente */
  FILE     **limit_graph;   /* tableau des fichiers d'evoluiton des limitations */ 
  FILE     *graph_cmd;      /* fichier de commande d'affichage automatique */
  int      step_FR_tot;     /* nombre de pas total effectuer dans Fletcher-Reeves */
  int      nb_eval;         /* nombre d'evaluation courrant */
  int      nb_var;          /* nombre de variables d'optimisation */
  int      nb_var_ecart;    /* nombre de variables d'ecart */
  int      nb_lim;          /* nombre de limitations */
  IVEC     *var_ecart;      /* vecteur des variables d'ecart */
  IVEC     *ind_par_opt;    /* tableau de correspondance entre variables d'optimisation et objet PAR */
  VEC      *norme_var_coef; /* coefficient de normalisation des variables d'optimisation */
  VEC      *norme_var_const;/* constante de normalisation des variables d'optimisation */
  VEC      *norme_lim;      /* norme des limitations */
  double   norme_cout;      /* norme du cout */
  double   transl_cout;     /* translation du cout */
  double   sig_goal;        /* signe sur la fonction cout pour min/max */
};

struct __res_optim{
  char nompb[257];              /* Nom du pb d'optimisation (identique a celui di T_optim) */
  E_OPT_status status;
  int nb_etape;                 /* Nombre d'etapes de calcul */
  VEC *trace_contraintes;       /* Evolution des contraintes durant l'optimisation */
  VEC *trace_cout;              /* Evolution du cout durant l'optimisation */
  VEC *trace_param;             /* Evolution des valeurs des parametres durant l'optimisation (un bloc par etape) */
  VEC *rres;                    /* Additional DP results */
  IVEC *ires;                   /* Additional Integer Results */
};

/*
 *   Resultat d'un cas de charge 
 */ 
struct __res_cas_charge{
  int			cas_charge;
  T_champ_global 	*deplacement;
  T_champ_global 	*deplacement_c;
  T_champ_local 	*deformation;
  T_champ_local		*deformation_moy;
  T_champ_global	*deformation_noeud;
  T_champ_global	*deformation_noeud_c;
  T_champ_local		*contrainte;
  T_champ_local		*contrainte_moy;
  T_champ_global	*contrainte_noeud;
  T_champ_global	*contrainte_noeud_c;
  T_champ_local		*energie;
  T_champ_global	*reaction;
  T_champ_global	*reaction_c;
  T_champ_local		*effort_int;
  T_champ_local		*masse;
  T_champ_local 	*forces_internes;
  T_champ_global 	*forces_internes_noeud;
  T_champ_global 	*forces_internes_noeud_c;
  VEC 			*deformee;
  VEC			*perturb;
  T_mode	 	*mode;
  T_mode	 	*modeu;
  VEC 			*vec_param;
  VEC                   *res_dyna;
  T_champ_global 	*velocity;
  T_champ_global 	*acceleration;
  T_champ_global        *temperature;
  T_champ_local         *b;
  T_champ_local         *h;
  T_champ_local         *jt;
  T_champ_local         *fmag;
  T_champ_global        *b_noeud;
  T_champ_global        *h_noeud;
  T_champ_global        *jt_noeud;
  T_champ_global        *fmag_noeud;
  T_champ_local         *tg, *tf;
  T_champ_global        *tg_noeud, *tf_noeud;
  T_champ_global        *tg_noeud_c, *tf_noeud_c;
};

struct __obj_etude {
  char *gen;			/* curdir/nom_etude/nom_etude: unique indentifier of a study */
  char version[80];		/* chaine de description de la version ->.etu */
  int tab_a_calculer[TAILLE_TYPE_RES];		/* resultats parametres (codage bit a bit) */
  E_type_etude type;
  E_solveur method;
  E_type_analyse analysis;	
  double accuracy;		/* precision de parametrisation */
  double maxpolsize;		/* max polynomial size */
  int maxorder;
  T_booleen mixed;
  T_booleen vrml;
  T_booleen mode_tracking;
  char solver_scratch_dir[PATH_MAX];
  char vrmlfile[PATH_MAX];
  int formulation;              /* Bit Field - Bit from E_formulation enum */
};

/* Mathematical type of results */
struct __resnat{
  E_resultat_parametre resultat; 	/* Result */
  E_nature nature;			/* Mathematical nature */
  E_support lieu;			/* Location */
  int unite;				/* Unit */
} ;

/*
 *    Resolution 
 */
struct __resolution{  
  T_booleen complexe; 		/* Inconnue reelle si FAUX, complexe sinon -> rempli dans ITF_lire_modele 
                                   si des elements amortissants ou des materiaux amortissant sont presents */
  T_booleen freq_en_omega2;     /* si VRAI le parametre est omega2, si FAUX le parametre est la frequence
				   la propriete elementaire frequence suit la meme logique */
  int place_disque;   		/* Place disque pour stockage definitif */
  int place_scratch;  		/* Place disque temporaire */
  int place_memoire;  		/* RAM + swap disponible */
  int limite_ddl_incore; 	/* Limite pour passage sur disque */
  int blocksize;         	/* Taille des blocs pour la resolution outoffcore */
  int stocke_matrice;           /* Stockage de la matrice factorisee */
  char scratch_dir[257];	/* repertoire pour les fichiers scratch, set CADOE_TMPDIR dans lec_etu pour ADOC */
  char stockage_dir[257];	/* repertoire de stockage matrice */
  E_type_etude type_etude;	/* type d'etude demande par l'utilisateur */
};

struct __transbase{
  E_resultat_parametre cible;	/* Goal of the transformation */
  E_resultat_parametre base;	/* Basic result */
  int transformation;		/* Transformation */
  E_gr2gr gr2gr;		/* Transformation of the goal group to obtain the group on basic result */
};


struct __tableau_resultat{
  int critere;			/* code critere */
  E_result_class classe;	/* model, node, elem, group */
  int no_ligne;			/* position scrollList boite Critere. */
  E_component_type type_component;		/* type de composantes */
  E_point_type type_point;	/* point de gauss a choisir ou non */
  T_booleen peau;		/* peau coque a choisir ou non */
  int nature;         		/* nature d'entite fem attendu dans un groupe */
  int nom;			/* code MSG_get duf libelle du critere */
  int disponibilite;		/* disponibilite du critere suivant le contexte */
  int legende;			/* code MSG_get du format de la legende */
  E_champ_type champ;		/* type du champ complementaire de la legende */
  T_booleen complexe;
};

struct __menu_comp{
  E_component_type type;	/* type de composante */
  int comp;			/* constante composante - constante_modelisation.h */
  int defaut;			/* 1:composante par defaut, 0:sinon */
  int nom;			/* id msg du libelle */
};


struct __structure_post{
  IVEC *nb_mat_by_node ;
  IVEC *ind_new_node ;
  IVEC *start_ind_new_node ;
  T_modele *modele;
};

#include "sx_globva.h"

#endif				/* __CADOE_SOLVER_H_DEJA_INCLUS__ */
