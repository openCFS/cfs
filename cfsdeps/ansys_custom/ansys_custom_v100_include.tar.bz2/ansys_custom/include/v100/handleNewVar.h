/* sid 50.1 copy of handleNewVar.h last changed by upd111 on 2005/06/04 13:23:03 */
/*-------------------------------- Globals ---------------------------*/



/*------------------------- C called from FORTRAN --------------------*/

#if defined(UPPERCASENOUNDER_SYS)

#define  initGlobalVariables       INITGLOBALVARIABLES
#define  releaseGlobalVariables    RELEASEGLOBALVARIABLES
#define  initLocalVariables        INITLOCALVARIABLES
#define  releaseLocalVariables     RELEASELOCALVARIABLES
#define  distributeGlobalVariables DISTRIBUTEGLOBALVARIABLES
#define  getAnsNodeExt2IntListPtr  GETANSNODEEXT2INTLISTPTR
#define  getAnsNodeInt2ExtListPtr  GETANSNODEINT2EXTLISTPTR
#define  getAnsElmExt2IntListPtr   GETANSELMEXT2INTLISTPTR
#define  getAnsElmInt2ExtListPtr   GETANSELMINT2EXTLISTPTR

#endif


#if defined(LOWERCASENOUNDER_SYS)

#define  initGlobalVariables       initglobalvariables
#define  releaseGlobalVariables    releaseglobalvariables
#define  initLocalVariables        initlocalvariables
#define  releaseLocalVariables     releaselocalvariables
#define  distributeGlobalVariables distributeglobalvariables
#define  getAnsNodeExt2IntListPtr  getansnodeext2intlistptr
#define  getAnsNodeInt2ExtListPtr  getansnodeint2extlistptr
#define  getAnsElmExt2IntListPtr   getanselmext2intlistptr
#define  getAnsElmInt2ExtListPtr   getanselmint2extlistptr

#endif


#if defined(LOWERCASEUNDER_SYS)

#define  initGlobalVariables       initglobalvariables_
#define  releaseGlobalVariables    releaseglobalvariables_
#define  initLocalVariables        initlocalvariables_
#define  releaseLocalVariables     releaselocalvariables_
#define  distributeGlobalVariables distributeglobalvariables_
#define  getAnsNodeExt2IntListPtr  getansnodeext2intlistptr_
#define  getAnsNodeInt2ExtListPtr  getansnodeint2extlistptr_
#define  getAnsElmExt2IntListPtr   getanselmext2intlistptr_
#define  getAnsElmInt2ExtListPtr   getanselmint2extlistptr_

#endif



/*------------------------------ Prototypes --------------------------*/

SUBROUTINE    initGlobalVariables(INT*, INT*, INT*, INT*);
SUBROUTINE    releaseGlobalVariables(VOID);
SUBROUTINE    initLocalVariables(INT*, INT*);
SUBROUTINE    releaseLocalVariables(VOID);
SUBROUTINE    distributeGlobalVariables(VOID);
INT FUNCTION  getAnsNodeExt2IntListPtr(INT**);
INT FUNCTION  getAnsNodeInt2ExtListPtr(INT**);
INT FUNCTION  getAnsElmExt2IntListPtr(INT**);
INT FUNCTION  getAnsElmInt2ExtListPtr(INT**);

