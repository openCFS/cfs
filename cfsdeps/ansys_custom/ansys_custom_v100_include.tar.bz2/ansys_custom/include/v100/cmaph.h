/* sid 50.1 copy of cmaph.h last changed by upd111 on 2005/06/04 13:14:43 */
/* 
 * *** ansys(r) copyright(c) 2000
 * *** ansys, inc.
 */
#if defined(PCWINNT_SYS)
    /*  fortran routines called from c  */
extern LPTHREAD_START_ROUTINE CALLTYP cmap_( char [] ,int, char [], int, int *, int * );
#endif

void   CALLTYP xstart_( void );
void   CALLTYP cmapstop_( void );
