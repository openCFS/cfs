/* sid 50.1 copy of heapcmh.h last changed by upd111 on 2005/06/04 13:09:39 */
/* 
 * *** ansys(r) copyright(c) 2000
 * *** ansys, inc.
 */
/*          **********  DEFINITIONS FOR HEAP MANAGER  **********  */
          
#define HEAP_BYTE       0       
#define HEAP_INTEGER    1    
#define HEAP_REAL       2
#define HEAP_DOUBLE     3     
#define HEAP_COMPLEX    4
#define HEAP_FIXED     16     
#define HEAP_DISCARD   32   
#define HEAP_DISCARDED 64

