/* sid 50.1 copy of constantes_adomesh.h last changed by smarguer on 2005/01/25 15:46:52 */
/* constantes_adomesh.h CADOE  */
/**
 *	constantes_adomesh.h 
 *
 *  |Version: $Id$
 *   
 * HISTORY
 *   
 *   11/22/00 12:18 <        Marc Gadbois> Rel:ms9      SCCA:83109  Delta:9.5
 *   
 *   09/25/00 11:19 <       Brian Jantzen> Rel:ms8m1    SCCA:79107  Delta:81.4
 *   
 *   06/28/00 10:47 <       Brian Jantzen> Rel:ms8m1    SCCA:74542  Delta:81.3
 *   
 *   06/21/00 16:30 <       Brian Jantzen> Rel:ms8m1    SCCA:74307  Delta:81.2
 *   
 *   02/08/00 12:44 <       Brian Jantzen> Rel:ms8      SCCA:67206  Delta:8.4
 *   
 *   01/13/00 11:20 <        Marc Gadbois> Rel:ms8      SCCA:65669  Delta:8.3
 *   
 *   09/30/99 17:38 <         James Silva> Rel:ms8      SCCA:56512  Delta:8.2
 **/

#ifndef __constantesadomeshh__
#define __constantesadomeshh__ 1

#ifndef __CADOE_H__
#include "cadoe.h"
#endif

/*
 * noms d'appli, versions
 */
#include "version_adomesh.h"


#define PEAUUV 		1
#define LINEARISATION 	2
#define GENEREFEM 	3
#define FEMBINAIRE 	4
#define FEMSECTION      5

#define EPSILON 	1.e-6
#define ITER_GLIS 	5
#define ITER_PROJ 	1

#define SATURE 		2
#define AMELIORE 	4
#define CONVERGENCE 	5

#define SUPERIEUR 	1
#define EGAL 		0
#define INFERIEUR 	-1

/*
 * extensions de fichiers 
 */
#define EXT_MSH_DAM        ".van"
#define EXT_MSH_DAA        ".daa"
#define EXT_MSH_SUP        ".sup"
#define EXT_MSH_FIX        ".fix"
#define EXT_MSH_PAR        ".par"
#define EXT_MSH_RNG     ".van"
#define EXT_MSH_MDB        ".van"
#define EXT_MSH_BDM        ".bdm"
#define EXT_MSH_LIS        ".lis"
#define EXT_FEM_DAT        ".dat"
#define EXT_FEM_DAB        ".dab"
#define EXT_FEM_ETU        ".etu"
#define EXT_AES_FIC        ".fic"
#define EXT_QA_FIC        ".qa"

/* 
 * codes objets CBF
 */
#define CBF_GEO_HEADER    1000
#define CBF_GEO_NODES     1001
#define CBF_GEO_ELEMENTS  1002
#define CBF_GEO_GEOINIT   1003
#define CBF_GEO_GEOPERT   1004
#define CBF_GEO_CS        1005
#define CBF_GEO_POLYGEO   1006
#define CBF_GEO_GROUPES   1007
#define CBF_GEO_NURBS     1010
#define CBF_GEO_POLYEDRE  1011
#define CBF_GEO_WF        1012
#define CBF_GEO_CANONIQUE 1013
#define CBF_GEO_NURBS_INIT 1014
#define CBF_GEO_POLY_INIT 1015
#define CBF_GEO_WF_INIT   1016
#define CBF_GEO_CANO_INIT 1017
#define CBF_GEO_REP_INIT  1018
#define CBF_GEO_REP_PERT  1019
#define CBF_GEO_MESH      1020
#define CBF_GEO_POLY_PERT 1021
#define CBF_GEO_PROPELE   1022
#define CBF_GEO_POUTRE    1023
#define CBF_GEO_CONFIG    1024
#define CBF_GEO_GROUPES_GEO   1025
#define CBF_GEO_GEOCAO    1026
#define CBF_GEO_SECTION   1027


#define CBF_MSH_HEADER    1100
#define CBF_MSH_POLYNODES 1101
#define CBF_MSH_POLYCS    1102
#define CBF_MSH_CONFIGS   1103
#define CBF_MSH_PARREP    1104
#define CBF_MSH_MACRO     1105
#define CBF_MSH_PERTURB   1106
#define CBF_MSH_PRTFIN    1107

/* code valeur courante dans une config */
#define VALMIN	1
#define VALMAX	2
#define VALREF	3
#define VALPETITPAS 4

#define FACTEUR_CFG_CROISEE 0.7
#define PETITPAS 0.1


#define DIM_MAX 3	/* dimension maximal d'un probleme */
#define NB_DDL_MAX 32	/* nombre de ddl maximun pour un noeud */
#define NB_NOEUD_MAX 20	/* nombre de noeud maximun pour un element */
#define NB_INCO_MAX 60	/* nombre max d'inconnues pour un element */
#define NB_SIG_MAX 6	/* nombre de contraintes pour un noeud donne */
#define NPG_MAX 36	/* nombre de point de gauss maximum  */
#define NB_INCO_MECA 6	/* nombre d'inconnues pour un probleme 'physique' mecanique */
#define NB_COMP_TENS_MAX 6	/* nombre max de composantes pour un tenseur */
#define NB_COMP_CHAR 12	/* dimension de tableaux de travail decrivant une
			 * sollicitation d'un type donne sur un element donne */


/*
 *-------------------- attribut type geometrique -----------------
 */
#define LINEAIRE 1
#define PARABOL  2

#define TAILLE_TYPE_ELEMENTS 46

/*
 * !!!!!! A maintenir en coherence avec les constantes adofem 
 * !!!!!! pour la relecture du dab / dat !!!!!!!!!!!!!!!!!!!!
 */

typedef enum {
 TRI3		= 1,
 QUA4  		= 2,
 TRI6  		= 3,
 QUA8  		= 4,
 NOEUD  	= 5,
 CUB8  		= 6,
 CUB20  	= 7,
 PRI6  		= 8,
 PRI15  	= 9,
 TET4  		= 10,
 TET10  	= 11,
 COQ2  		= 12,
 DKT  		= 13,
 SEG2  		= 14,
 SEG3  		= 15,
 DKTP  		= 16,
 POU2_3D 	= 17,
 BIDON1         = 18,
 BIDON2         = 19,
 DKT12 		= 20,
 POU3_3D 	= 21,
 NNTSPR         = 22,    /* node node trans spring */
 NNRSPR         = 23,    /* node node rot spring */
 NGTSPR         = 24,    /* node ground trans spring */
 NGRSPR         = 25,    /* node ground rot spring */
 NOEUD_COUPLE   = 26,
 LPMASS		= 27,    /* lumped mass */
 NGTDMP		= 28,
 NNTDMP		= 29,
 RIGIDE         = 30,
 TRI3UV		= 31,
 QUA4UV		= 32,
 TRI6UV		= 33,
 QUA8UV		= 34,
 COQ_Q4         = 35,
 COQ_Q8         = 36,
 ROD            = 37,
 WEDGE6_COMP    = 38,
 WEDGE15_COMP   = 39,
 CUB8_COMP      = 40,
 CUB20_COMP     = 41,
 PYRA5 = 42,
 PYRA13 = 43,
 MPC    = 44,
 TARGET		= 45,
 CONTACT	= 46
} E_ele_type_geo;

/*
 * type de probleme
 */
typedef enum {
  MSH_VOLUMIQUE = 1,
  MSH_PLAN = 2,
  MSH_GUIDONDE = 3,
  MSH_PEAUUV = 4,
  MSH_2DAXI = 5,
  MSH_AVEC_INIT = 6,
  MSH_CFD = 7
} E_appli;


/*
 *-------------------- attribut forme geometrique -----------------
 */
#define FORM_NURBS_GENE       0     /*  arbitrary NURBS surface  */
#define FORM_PLAN_RECTANGLE   1     /*  rectangular planar patch  */
#define FORM CYLINDRE         2     /*  right circular cylinder  */
#define FORM_CONE             3     /*  right circular cone */
#define FORM_SPHERE_PATCH     4     /*  spherical patch */ 
#define FORM_TORE_PATCH	      5     /*  toroidal patch */ 
#define FORM_SURFACE_REV      6     /*  surface of revolution */ 
#define FORM_SURFACE_EXTRU    7     /*  TABCYL (extruded surface) */  
#define FORM_SURFACE_REGLEE   8     /*  ruled surface (rulings in t */ 
#define FORM_QUADRATIQUE      9     /*  general quadric surface */ 
#define FORM_PLAN_CIRCULAIRE 10     /*  planar circular capping surface */ 
#define FORM_PLAN_GENERAL    11     /*  planar quadrilateral, not rectangle */ 


/*
 *------------------ attribut mode d'analyse ----------------------
 */

#define  DIMENSION3  1
#define  CONTRAINTES_PLANES  2
#define  AXISYMETRIQUE  3
#define  FOURIER  4
#define  DEFORMATIONS_PLANES  5
#define  COQUE_3D  6
#define  POUTRE_TRIDIMENSIONNELLE  7

/*
 *------------ valeurs de la prop-elem niveau d'integration ----------
 */
#define TAILLE_NIVEAU_INTEGRATION 3

#define INTEGRATION_NORMALE 1
#define SOUS_INTEGRATION 2
#define SUR_INTEGRATION 3

/*
 *------------ valeurs de la prop-elem type des points d'integration ----------
 */
#define TAILLE_TYPE_POINTS 3

#define GAUSS 1
#define GAUSS_SS_INTEG 2
#define GAUSS_SUR_INTEG 3

/*
 *------------ valeurs de la prop-elem nombre des points d'integration ----------
 */
#define TAILLE_NOMBRE_POINTS 27




/* 
 *  Correction de peau 
 */
#define CORREC05 0.5 /* Correction moitie */
#define CORRECTO 1 /* Correction complete */

/* Nombre de plages pour les stats */
#define NBZONES 5

/* Nombre de couches par defaut pour la minimisation continue */
#define NBCOUCHES 4

/* pts integ * nb comp tenseur */
#define TAILLE_EPS 27*6

/* Max iterations de Fletcher-Reeves */
#define ITERFRMAX 20

/* Max iterations de minimisation continue */
#define ITERCNTMAX 20

/* facteur de correction du cisaillement dans matrice B */
#define FACT_CIS 0.5

/*
 *------------ Types d'ecriture des fichiers bdm ----------
 */
#define BINC 10
#define BINF 20
#define ALPHA 30

/* Reduction automatique de plage */
#define MAXREDUCTION 3
#define TROPREDUITE MAXREDUCTION+2
#define FACT_REDUCTION 0.66


/* Erreur sur les user attribut */
#define USR_ATTRIBUT_OK 1
#define USR_ATTRIBUT_ERROR 2
#define USR_ATTRIBUT_ERROR_GRAVE 3


#endif
