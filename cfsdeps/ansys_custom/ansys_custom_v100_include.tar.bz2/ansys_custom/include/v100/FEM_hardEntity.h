/* sid 50.1 copy of FEM_hardEntity.h last changed by upd111 on 2004/11/04 18:30:59 */
/*  FEM_hardEntity.h */
/*
 * *** ansys(r) copyright(c) 1999
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_hardEntity.h
 *  header file for FEM_hardEntity.c
 *
 */
#ifndef FEM_HARDENTITY_INCLUDE
#define FEM_HARDENTITY_INCLUDE

/*----------------- Globally accessible function prototypes -----------------*/

                             /* ============================================= */
                             /* === FEM_hls_rec: recover edges along hard     */
                             /* === lines.                                    */
                             /* === Return: INT  EXIT_SUCCESS or EXIT_FAILURE */
                             /* ============================================= */
INT FEM_hls_recv (
   INT anum  );        /* area number */

INT fem_hpt_node_chk (
   INT area_num,        /* area number */
   INT choice,          /* select an operation */
   INT node_id );       /* node id */

INT * fem_hpt_node_ls (
   INT area_num,            /* area number */
   INT *num_node );             /* number of nodes */

#endif

