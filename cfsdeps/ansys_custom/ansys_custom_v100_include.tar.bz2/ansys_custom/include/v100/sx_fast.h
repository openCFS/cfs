/* sid 50.1 copy of sx_fast.h last changed by ftheveno on 2005/02/18 09:03:57 */
/*******************************************************************************
 *
 *   sx_fast.h  --- Prototypes and Structures for FAST kernel
 *               
 * 
 * |Module:  
 *
 * |Description: 
 *
 * |Includes:	
 *        
 * |Auteur: Jerome Margat
 *
 * |Creation: December 2003
 *
 * |Version: $Id$
 *
 * |Copyright:	Copyright(c)  2002
 *
 ********************************************************************************/


#ifndef __SX_PROTO_FAST_H
#define __SX_PROTO_FAST_H

#include "SxSparse.h"
#include "sx_exploit_param_fast.h"
#include "sx_bases.h"
#include "blas_ansys.h"


/*Prototypes*/
#ifdef __cplusplus 
extern "C" {
#endif

extern T_statut  SX_loadModel(const char * rsxName);
extern void      DiscretiseHypercube(PAR *par, VEC *variation, int NbPtsByParametre, VEC **PtsVerif, int *ier);
extern T_statut  MOC_prod_mv_support( T_m_ooc *matparam, T_m_ooc *matK0, BVEC *DdlActive, double *vin, double *vout);
extern T_statut  MOC_prod_mm_support( T_m_ooc *matparam, T_m_ooc *matK0, BVEC *DdlActive, int nbv, double *vin, double *vout);
extern T_statut  MOC_dtrsv_support( T_m_ooc *matparam, T_m_ooc *matK0, VEC *DIAG, IVEC *DdlActive, char UPPER[1], double *vin, double *vout);
extern T_statut  MOC_dtrsv( T_m_ooc *matK0, char UPPER[1], double *vin, double *vout);
extern T_statut  MOC_dtrmv_support( T_m_ooc *matparam, T_m_ooc *matK0, VEC *DIAG, IVEC *DdlActive, char UPPER[1], double *vin, double *vout);
extern T_statut  MOC_dtrmv(T_m_ooc *matK0, char UPPER[1], double *vin, double *vout);
extern T_statut  MOC_extract_diag_support( T_m_ooc *matparam, T_m_ooc *matK0, IVEC *DdlActive, double *diag);
extern T_statut  MOC_extract_diag( T_m_ooc *matK0, double *diag);
extern T_statut  MOC_to_full( T_m_ooc *mat, VSTRUCT *K, int *ier);
extern T_statut  MOC_debug_support( T_m_ooc *matparam, T_m_ooc *matK0, IVEC *DdlActive);
extern T_statut  MOC_debug(T_m_ooc *mat);
extern int       CompressBase(VSTRUCT *Qin, double SEUIL, int *ier);
extern int       nb_vec(double prec, VEC *errmax_svd);
extern VSTRUCT  *ExploitParamInter(PAR *par, VSTRUCT *Q, VSTRUCT *SIGMA, VSTRUCT *MASS, VEC *epsi, IVEC **ListElem, IVEC **DdlToKeep, int *ier);
extern VSTRUCT  *ExploitParamConnex(PAR *par, T_basis bases, T_ExploitParamFast *Config, VEC *epsi, IVEC **ListElem, IVEC **DdlToKeep, 
				    double *residu, int *ier);
extern VSTRUCT  *ExploitParamInterp(PAR *par, T_basis bases, VEC *epsi, IVEC **ListElem, IVEC **DdlToKeep, int *ier);
extern VSTRUCT  *ExploitParamTest(PAR *par, T_basis bases, VEC *epsi, IVEC **ListElem, IVEC **ptrDdlToKeep, int *ier);
extern VSTRUCT  *ExploitParam(PAR *par, VSTRUCT *Q, VSTRUCT *SIGMA, VSTRUCT *MASS, VEC *epsi, IVEC **ListElem, IVEC **DdlToKeep, int *ier);
extern VEC      *GetBexact(int *ier);
extern VEC      *GetBexact_PCG(int *ier);
extern void      SetBexact_PCG(VEC*);
extern void      initPost(PAR *par, T_basis bases);
extern void      initPostConnex(PAR* par, VSTRUCT* Q, VSTRUCT *SIGMA, VSTRUCT *MASS);
extern void      SolveIter(PAR *par, T_modele *modele, VSTRUCT *Qin, VEC *PtsVerif, double SEUILCONV, int *ier);
extern T_statut  DEM_update_model_v2( T_der_modele *der_modele, PAR *par, void *param, double *dp );
extern void      initParamJMA(PAR* par,int* ier);
extern void      initParamJMA_PCG(PAR* par,int* ier);
extern void      paramJMA(PAR* par,int* ier);
extern void      paramJMA_PCG(PAR* par,int* ier);
extern VEC **    _LM_v_orthoHjma(int NBVEC,  int *KB, VEC **Qin, VEC **Qout, int line, char* fct, int* ier);

#ifdef __cplusplus
}
#endif


/*CONSTANTES pour LAPACK*/
static  char      TRANSC[2]   = "C";
static  char      NOTRANS[2]  = "N";
static  char      TRANST[2]   = "T";
static  int       NOTRANS_len = 1;
static  int       TRANST_len  = 1;
static  int       UPPER_len   = 1;
static  int       LOWER_len   = 1;
static  int       NODIAG_len  = 1;
static  int       NOUNIT_len  = 1;
static  char      UPPER[2]    = "U";
static  char      LOWER[2]    = "L";
static  char      NODIAG[2]   = "N";
static  char      NOUNIT[2]   = "N";
static  char      LETTERV[2]  = "V";
static  char      FACTE[2]    = "E";
static  const int IZERO=0,IONE=1,ITWO=2;
static  const int *PTRIZERO=&IZERO;
static  const int *PTRIONE=&IONE;
static  const int *PTRITWO=&ITWO;
static  const double ONE=1.0E0,ZERO=0.0E0,MINUSONE=-1.0E0;
static  const double *PTRONE=&ONE,*PTRZERO=&ZERO,*PTRMINUSONE=&MINUSONE;

#if defined(LOWERCASENOUNDER_SYS)
#define calc_vs		calc_vs
#define cadoe_vmove     cadoe_vmove
#define cadoe_vzero     cadoe_vzero
#define dposv           dposv
#define drscl           drscl
#define sx_dposv        sx_dposv
#define init_wrapper_bcsread init_wrapper_bcsread
#define wrapper_bcsread      wrapper_bcsread
#define bdcopy_cadoe         bdcopy_cadoe
#define cadoe_time           cadoe_time
#define initPostFAST	initpostfast
#define SxFEval		sxfeval
#define Sxf_evalUtilde  sxf_evalutilde
#define set_kelreq      set_kelreq
#define SxSetMatricesByParameterKey sxsetmatricesbyparameterkey
#define sxf_run         sxf_run
#define sxf_findPort    sxf_findport
#define sxf_getContext  sxf_getcontext
#define sxf_init        sxf_init 
#define sxf_end         sxf_end
#define SX_launchSolV   sx_launchsolv
#endif

#if defined(UPPERCASENOUNDER_SYS)
#define calc_vs		CALC_VS
#define cadoe_vmove     CADOE_VMOVE
#define cadoe_vzero     CADOE_VZERO
#define dposv           DPOSV
#define sx_dposv        SX_DPOSV
#define zungqr          ZUNGQR
#define zgeqrf          ZGEQRF
#define dorgqr          DORGQR
#define dgeqrf          DGEQRF
#define drscl           DRSCL
#define init_wrapper_bcsread INIT_WRAPPER_BCSREAD
#define wrapper_bcsread      WRAPPER_BCSREAD
#define bdcopy_cadoe         BDCOPY_CADOE
#define cadoe_time           CADOE_TIME
#define initPostFAST	INITPOSTFAST
#define SxFEval		SXFEVAL
#define Sxf_evalUtilde  SXF_EVALUTILDE
#define set_kelreq      SET_KELREQ
#define SxSetMatricesByParameterKey SXSETMATRICESBYPARAMETERKEY
#define sxf_run         SXF_RUN
#define sxf_findPort    SXF_FINDPORT
#define sxf_getContext  SXF_GETCONTEXT
#define sxf_init        SXF_INIT
#define sxf_end         SXF_END
#define SX_launchSolV   SX_LAUNCHSOLV
#endif

#if defined(LOWERCASEUNDER_SYS)
#define calc_vs		calc_vs_
#define cadoe_vmove     cadoe_vmove_
#define cadoe_vzero     cadoe_vzero_
#define dposv           dposv_
#define sx_dposv        sx_dposv_
#define zungqr          zungqr_
#define zgeqrf          zgeqrf_
#define dorgqr          dorgqr_
#define dgeqrf          dgeqrf_
#define drscl           drscl_
#define init_wrapper_bcsread init_wrapper_bcsread_
#define wrapper_bcsread      wrapper_bcsread_
#define bdcopy_cadoe         bdcopy_cadoe_
#define cadoe_time           cadoe_time_
#define initPostFAST	     initpostfast_
#define SxFEval		     sxfeval_
#define Sxf_evalUtilde       sxf_evalutilde_
#define SxSetMatricesByParameterKey sxsetmatricesbyparameterkey_
#define set_kelreq           set_kelreq_
#define sxf_run              sxf_run_
#define sxf_findPort         sxf_findport_
#define sxf_getContext       sxf_getcontext_
#define sxf_init             sxf_init_
#define sxf_end              sxf_end_
#define SX_launchSolV        sx_launchsolv_
#endif

SUBROUTINE dposv(FCHAR(c1), int *N, int *NRHS, double *A, int *LDA, double *B, int *LDB, int *INFO FCHARL(c1_len));
SUBROUTINE drscl(int *N, double *alpha, double *X, int *INCX);
SUBROUTINE sx_dposv(FCHAR(c1), int *JMIN, int *N, int *NRHS, double *A, int *LDA, double *B, int *LDB, int *INFO FCHARL(c1_len));

SUBROUTINE calc_vs(int*,int*,double*,double*,double*,double*,int* err);
SUBROUTINE zungqr( int*, int*, int*, T_complex*, int*, T_complex*, T_complex*, int*, int* );
SUBROUTINE zgeqrf( int*, int*, T_complex*, int*, T_complex*, T_complex*, int*, int* );
SUBROUTINE dorgqr( int*, int*, int*, double*, int*, double*, double*, int*, int* );
SUBROUTINE dgeqrf( int*, int*, double*, int*, double*, double*, int*, int* );
SUBROUTINE init_wrapper_bcsread(int *fortran_unit, int *ierr);
SUBROUTINE wrapper_bcsread(int *fortran_unit, int *nrec, int *SYIOLNbcs, double *z, int *err);
SUBROUTINE bdcopy_cadoe(int *n, double *dx, double *dy);
SUBROUTINE cadoe_vmove(void *ptr1, void *ptr2, int *length);
SUBROUTINE cadoe_vzero(void *ptr,  int *length);
SUBROUTINE cadoe_time(double *user, double *system, double *wall);
SUBROUTINE initPostFAST(int*);
SUBROUTINE SxFEval(int *values);
SUBROUTINE Sxf_evalUtilde();
SUBROUTINE SxSetMatricesByParameterKey(int *iMatricesByParameter);
#ifdef __cplusplus 
extern "C"  
{
  SUBROUTINE set_kelreq( int *);
  int FUNCTION sxf_run(int *);
  SUBROUTINE sxf_findPort(int *, int *);
  SUBROUTINE sxf_getContext(FCHAR(rsxName), int *context, int *ier FCHARL(rsxName_len));
  int FUNCTION sxf_init();
  int FUNCTION sxf_end();
  SUBROUTINE SX_launchSolV(FCHAR(command), FCHAR(option) FCHARL(command_len) FCHARL(option_len));
}
#endif

#endif /* __PROTOFAST_H */
