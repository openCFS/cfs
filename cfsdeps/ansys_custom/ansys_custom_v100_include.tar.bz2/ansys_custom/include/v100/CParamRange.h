/* sid 50.1 copy of CParamRange.h last changed by upd111 on 2005/06/04 13:23:23 */
/*! \file CParamRange.h

  \brief This header file defines the CParamRange class.

  \author Stephane MARGUERIN &copy; CADOE

  \date 26 april 2004

*/
#ifndef __CParamRange_h__ 
#define __CParamRange_h__ 1 


#define RANGE_INPUT 0 //defined at pre-processing time, =ET_USER for compatibility
#define RANGE_GEO_OUTPUT 1 //adogeom output or validated range, =ET_GEOMETRY
#define RANGE_MSH_OUTPUT 2 //adomesh output or validated range, =ET_MESH
#define RANGE_MHC_OUTPUT 5 //adomesh hypercube validated range,
#define RANGE_SLV_INPUT 6 //solver input range
#define RANGE_SEN_OUTPUT 3 //sensitivity solve output or validated range, =ET_SENSI_SOLVE
#define RANGE_PAR_OUTPUT 4 //parametric solve output or validated range, =ET_PARAM_SOLVE
#define RANGE_OUTPUT 99 //to be used at post-processing time

class CParamRange
{
public:
  //! parameter status
  typedef enum { 
    CPS_EMPTY =0, 
    CPS_VALIDATED,  // range processed and available for use
    CPS_TOPROCESS,  // range not processed yet
    CPS_DELETED     // range processed; param has been deleted
  } ParStatus;

  CParamRange() 
  {
#ifdef _DEBUG
    m_min = m_ini = m_max = -999999.;
#else
    m_min = m_ini = m_max = 0.;
#endif
    m_order=-10000; 
    m_status=CPS_EMPTY; 
  }
  ~CParamRange() {};
  CParamRange( const CParamRange &range ) { *this = range; }
  CParamRange& operator =( const CParamRange &range ) 
  {
    if ( this!= &range )
    {
      m_min = range.m_min;
      m_ini = range.m_ini;
      m_max = range.m_max;
      m_order = range.m_order;
      m_status = range.m_status;
    }
    return *this;
  }
  bool isEmpty( void ) const { return (m_status==CPS_EMPTY); }
  bool isToProcess( void ) const { return (m_status==CPS_TOPROCESS); }
  bool isValidated( void ) const { return (m_status==CPS_VALIDATED); }
  bool isDeleted( void ) const { return (m_status==CPS_DELETED); }


public:    
    double m_min;
    double m_ini;
    double m_max;
    int m_order;
  ParStatus m_status;
};


#endif
