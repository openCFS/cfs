/* sid 50.1 copy of ibmpplib.h last changed by upd111 on 2005/06/04 13:14:52 */
/* ibmpplib.h	1.1 IBM version*/
/* 
 * *** ansys(r) copyright(c) 2000
 * *** ansys, inc.
 */

/* MACROS FOR STATISTICS */
#ifdef IBMstat
	/* IBMstat enables statistic counters */
#include <values.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/mode.h>
#include <sys/shm.h>
#define IBMshsize sizeof(IBMcounters)
static int IBMonce=0;	/* toggle to initialize only one */
#define IBMstatinc( counter ) \
	fetch_and_add ( &(IBManchor -> counter), 1 ) ;
#define IBMstatquery(counter)\
	 (IBManchor -> counter )
#define IBMstatclear(counter)\
	 IBManchor -> counter = 0
#define IBMstatprint(name, counter)\
	 printf("%s \t\t%d \n",name, IBManchor -> counter )
	

typedef struct IBMctr 
{
unsigned int IBMstat_cwfrk;
unsigned int IBMstat_thread_create;
unsigned int IBMstat_ppinit ;
unsigned int IBMstat_ppfini ;
unsigned int IBMstat_ppresu ;
unsigned int IBMstat_pppark ;
unsigned int IBMstat_pprset ;
unsigned int IBMstat_ppbarrier ;
unsigned int IBMstat_ppproc ;
unsigned int IBMstat_ppnext ;
unsigned int IBMstat_pprange ;
unsigned int IBMstat_pplock ;
unsigned int IBMstat_ppunlock ;
unsigned int IBMstat_lockmiss ;
unsigned int IBMstat_lockspin ;
unsigned int IBMstat_ppinfo ;
unsigned int IBMstat_ppinqr ;
unsigned int IBMstat_get_proc_id ;
unsigned int IBMstat_start_threads ;
unsigned int IBMstat_wait_for_start ;
unsigned int IBMstat_barrier_init ;
unsigned int IBMstat_barrier_wait ;
unsigned int IBMstat_barrier_destroy ;
}IBMcounters;
 IBMcounters * IBManchor; /* global pointer for statistics area */
IBMstatinit()
{
	key_t key;
	int shkey;
	if (! IBMonce )
	{
	key = ftok("/usr/bin/ksh", 'R' );
	if ( -1 == (shkey = shmget(key,IBMshsize,IPC_CREAT|S_IRUSR|S_IWUSR|S_IROTH|S_IWOTH)))
		{ perror ("shmget"); exit(10); }
	if ( -1 == (IBManchor =( IBMcounters *) shmat( shkey ,0,0)))
		{ perror ( "shmat"); exit(10); }

	IBMonce=1;
	}
}
#else	/* if not defined, all code evaporates due to null macros */
#define IBMstatinit()
#define IBMstatinc( counter )
#define IBMstatquery()
#endif /* IBMstat */
/*  MACROS FOR FAST LOCKS */
#ifdef FASTLOCKS

#define UL_FREE               0x00000000
#define UL_BUSY               0x10000000
#define UL_WAIT         	0x20000000
#define _get_lock(lock) \
        (!_check_lock((atomic_p)lock, UL_FREE, UL_BUSY) || \
         !_check_lock((atomic_p)lock, UL_WAIT, UL_WAIT|UL_BUSY))


#define _put_lock(lock) \
        ( __iospace_sync()  , \
         !cs((atomic_p)lock, UL_BUSY, UL_FREE))

#define FASTLOCK(lock)     {if(!_get_lock((atomic_p)(&((lock)->__ptmtx_lock))))spin_lock(lock);}

#define FASTUNLOCK(lock)  \
	if (!_put_lock((atomic_p)(&((lock)->__ptmtx_lock)))) \
		pthread_mutex_unlock(lock) ;

void
spin_lock(pthread_mutex_t *lock)
{
        register int    i;
	IBMstatinc( IBMstat_lockmiss );

	for (i = 1; i < spincountmax; i++) {
	IBMstatinc( IBMstat_lockspin );
		if ( spincountmax == MAXINT ) i--; /* MAXINT means infinite count */
		if (_get_lock((atomic_p)(&((lock)->__ptmtx_lock))))
			goto done;

	}

	pthread_mutex_unlock(lock);
done:
        return;
}

#endif /* FASTLOCKS */
