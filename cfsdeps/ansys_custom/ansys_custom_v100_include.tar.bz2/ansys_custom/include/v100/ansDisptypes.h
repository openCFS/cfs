/* sid 50.1 copy of ansDisptypes.h last changed by jrb on 2005/02/25 19:24:21 */

#include "ansysdef.h"


extern  INT  cCreateAnsDisp(void);
extern  INT  cDeleteAnsDisp(void);
extern  INT  cInquireAnsDisp(INT,INT,INT);
extern  INT  cPutAnsDisp(INT,INT,DOUBLE*);
extern  INT  cGetAnsDisp(INT,INT,INT*,DOUBLE*);
extern  INT  cGetAnsDispPtr(INT,INT,INT*,DOUBLE**);
extern  INT  cActivateAnsDisp(INT,INT,INT);
extern  INT  cDumpAnsDisp(INT);


/****************************************************************
 global-level structure for ANSYS nodal displacements
 ****************************************************************/
struct ansDisp_str {         /* Name of the structure                                  */
  INT       tag;             /* Tag for this instance of the displacement structure    */
  INT       numDispNodes;    /* Number of nodes with displacements                     */
  INT       maxDispNode;     /* Maximum external node number having displacement       */
  INT       numDisp;         /* Total number of displacements (zero and non-zero)      */
};

#define ansDispTag(disp)                (disp->tag)
#define ansDispNumDispNodes(disp)       (disp->numDispNodes)
#define ansDispMaxDispNode(disp)        (disp->maxDispNode)
#define ansDispNumDisp(disp)            (disp->numDisp)



/******************************************************************
 data-level structure for ANSYS nodal displacements
 ******************************************************************/
struct dispData_str {    /* Name of the structure                                           */
  char      modified;    /* Flag indicating whether this displacement has been modified     */
  char      internal;    /* Flag indicating whether this displacement is internal to object */
  INT       dof;         /* External DOF value                                              */
  char      active;      /* Flag indicating if displacement is active or inactive           */
  DOUBLE   *values;      /* Vector containing displacement values (we store 4 values)       */
                         /*        (1:2) current real,imag values                           */
                         /*        (3:4) previous real,imag values                          */ 
  dispData *nextDisp;    /* Pointer to the next displacement data structure for this        */
                         /* node.  If this pointer is NULL, then this is the last           */
                         /* stored displacement for this node                               */
};

#define dispDataModified(dData)         (dData->modified)
#define dispDataInternal(dData)         (dData->internal)
#define dispDataDof(dData)              (dData->dof)
#define dispDataDispActive(dData)       (dData->active)

#define dispDataValuesPtr(dData)        (dData->values)
#define dispDataValuesVec(dData,i)      (dData->values[i])

#define dispDataNextDispPtr(dData)      (dData->nextDisp)

