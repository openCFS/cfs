/* sid 50.1 copy of OutputWin.h last changed by upd111 on 2005/06/04 13:15:16 */
/*
 * *** ansys(r) copyright(c) 2000
 * *** ansys, inc.
 */
extern int  fBatch;

void FortranToOutputWin ( const void *buffer, unsigned bytes );
void CToOutputWin( char * inputBuf, int numChars );

