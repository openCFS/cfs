/* sid 50.1 copy of fem_swFill.h last changed by upd111 on 2004/11/04 18:33:26 */

/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 1999 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_swFill.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_swFill.h
 *  header file for FEM_swFill.c
 *
 */
#ifndef FEM_SWFILL_INCLUDE
#define FEM_SWFILL_INCLUDE

/*----------------- Globally accessible variables ---------------------------*/

/*----------------- Globally accessible macros ------------------------------*/

/*----------------- Globally accessible function prototypes -----------------*/

                               /* ========================================== */
                               /* === FEM_swFill: The ribs in the volume     */
                               /* === sweepable mesh were just created.  Now */
                               /* === create the elements using the nodes on */
                               /* === those ribs.                            */
                               /* === Return: EXIT_SUCCESS or EXIT_FAILURE   */
                               /* ========================================== */
INT FEM_swFill (
   VOL_PTYP obj_vol,           /* (IN)  the volume being swept.              */
   AREA_PTYP obj_sarea,        /* (IN)  the source area on obj_vol           */
   FEM_BOOLEAN sweepmids,      /* (IN)  TRUE if midnodes should be added by  */
                               /*       sweeping.                            */
   FEM_BOOLEAN do_progress,    /* (IN)  TRUE if doing status window          */
   FEM_BOOLEAN debug );        /* (IN)  debug flag.                          */

#endif

