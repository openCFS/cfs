/* sid 50.1 copy of FEM_HexToTet.h last changed by upd111 on 2004/11/04 18:29:38 */

/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 1998 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_HexToTet.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_HexToTet.h
 *  Prototypes and macros for refining hexahedral meshes.
 *
 */

#ifndef FEM_HEX_TO_TET___H
#define FEM_HEX_TO_TET___H

                              /* ============================================ */
                              /* === FEM_htHexToTet: define pyramid elements  */
                              /* === on areas between hex and tet vols (top   */
                              /* === C routine for hex to tet)                */
                              /* === Return: INT EXIT_SUCCESS or EXIT_FAILURE */
                              /* ============================================ */
INT FEM_htHexToTet (
   INT vnum,                  /* (IN)  The volume number                      */
   INT num_areas,             /* (IN)  number of areas to process at hex-tet  */
                              /*       interface                              */
   INT *a_areas,              /* (IN)  array of areas at hex-tet interface    */
   INT midnodes,              /* (IN)  !0 if quadratic elements used          */
   INT open_pyramid,          /* (IN)  flag - use the open pyramid method     */
                              /*       always                                 */
   INT *num_pyrs_created,     /* (OUT) return number of pyramids created      */
   FILE *debug_fp );          /* (IN)  file pointer for debugging print out   */

                              /* ============================================ */
                              /* === FEM_htHexToPyr: function to convert an   */
                              /* === all-hex mesh into an all-pyramid mesh    */
                              /* === Return: void                             */
                              /* ============================================ */
INT FEM_htHexToPyr (
   FEM_BOOLEAN midnodes );    /* (IN)  flag - TRUE if midnodes on elements    */

                              /* ============================================ */
                              /* === FEM_htImproveWorstTets: function to      */
                              /* === do some more tet improvement if shape    */
                              /* === failures were detected                   */
                              /* ============================================ */
INT FEM_htImproveWorstTets(
   FEM_BOOLEAN midnodes,      /* (IN) flag - midnodes on elements             */
   INT iter,                  /* (IN) improvement iteration                   */
   INT vnum );                /* (IN) volume number                           */

                              /* ============================================ */
                              /* === FEM_htProcessQuad: form a pyramid at a   */
                              /* === single quad in the data base where it is */
                              /* === adjacent to 2 or more tets               */
                              /* ============================================ */
INT FEM_htProcessQuad( 
   FACE_OBJ obj_quad,
   INT midnodes,
   INT open_pyramid );

                              /* ============================================ */
                              /* === FEM_htSetHexdom: set the hex-dominant    */
                              /* === flag (small differences to algorithms    */
                              /* === when called from hex-dominant code)      */
                              /* ============================================ */
void FEM_htSetHexdom( 
   INT flag );

INT FEM_htSwapTet2to3       ( 
   ELEMENT_OBJ obj_tet1,
   ELEMENT_OBJ obj_tet2,
   FACE_OBJ obj_tri,
   INT midnode );

DOUBLE FEM_htPotentialMetric   ( 
   FACE_OBJ obj_face,
   ELEMENT_OBJ obj_tet1,
   ELEMENT_OBJ obj_tet2 );
#endif
