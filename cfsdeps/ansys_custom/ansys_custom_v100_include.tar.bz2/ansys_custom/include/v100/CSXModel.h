/* sid 50.9 copy of CSXModel.h last changed by smarguer on 2005/04/28 16:47:43 */
/*! \file CSXModel.h

  \brief This header file defines the CSXModel class.

  \author Stephane MARGUERIN &copy; CADOE

  \date 25 March 2005
*/
#ifndef __CSXModel_h__ 
#define __CSXModel_h__ 1 

#include "cadoe.h"
#include "cadoe_vector.h"
#include "cadoe_string.h"
#include "cadoe_map.h"

struct __modele;
typedef struct __modele T_modele;

//! Maximum number of nodes per element
#define CSX_MAX_NB_NODES_PER_ELEMENT		20
//! Maximum length of a group name
#define CSX_MAX_LEN_GROUP_NAME			256

//! Element types compatible with Variational Analysis 
typedef enum {
  VAEL_ROD	 =  1,    /**< Rod	                                              */
  VAEL_LBEAM   =  2,	/**< Linear beam */
  VAEL_TBEAM   =  6,	/**< Tapered beam                                      */
  VAEL_CBEAM   =  7,	/**< Curved beam                                       */
  VAEL_PBEAM   =  3,	/**< Parabolic beam                                    */
  VAEL_PSSLT   = 51,	/**< Plane Stress Linear Triangle                      */
  VAEL_PSSPT   = 53,	/**< Plane Stress Parabolic Triangle                   */
  VAEL_PSSLQ   = 52,	/**< Plane StresS Linear Quadrilateral                 */
  VAEL_PSSPQ   = 54,	/**< Plane Stress Parabolic Quadrilateral              */
  VAEL_PSTLT   = 56,	/**< Plane Strain Linear Triangle                      */
  VAEL_PSTPT   = 58,	/**< Plane Strain Parabolic Triangle                   */
  VAEL_PSTLQ   = 57,	/**< Plane StresS Linear Quadrilateral                 */
  VAEL_PSTPQ   = 59,	/**< Plane Strain Parabolic Quadrilateral              */
  VAEL_AXILT   = 45,	/**< Axisymetric Solid Linear Triangle                 */
  VAEL_AXIPT   = 47,	/**< Axisymetric Solid Parabolic Triangle              */
  VAEL_AXILQ   = 46,	/**< Axisymetric Solid Linear Quadrilateral            */
  VAEL_AXIPQ   = 48,	/**< Axisymetric Solid Parabolic Quadrilateral         */
  VAEL_TNLT    = 21,	/**< Thin Shell Linear Triangle                        */
  VAEL_TNPT    = 23,	/**< Thin Shell Parabolic Triangle                     */
  VAEL_TNLQ    = 22,	/**< Thin Shell Linear Quadrilateral                   */
  VAEL_TNPQ    = 24,	/**< Thin Shell Parabolic Quadrilateral                */
  VAEL_SOLLT   = 40,	/**< Solid Linear Tetrahedron                          */
  VAEL_SOLLW   = 43,	/**< Solid Linear Wedge                                */
  VAEL_SOLPW   = 44,	/**< Solid Parabolic Wedge                             */
  VAEL_SOLLB   = 41,	/**< Solid Linear Brick                                */
  VAEL_SOLPB   = 42,	/**< Solid Parabolic Brick                             */
  VAEL_SOLPT   = 49,	/**< Solid Parabolic Tetrahedron                       */
  VAEL_RIGMNT  =  4,	/**< Rigid Element                                     */
  VAEL_NNTSPR  = 31,	/**< Node To Node Translational Spring                 */
  VAEL_NNRSPR  = 35,	/**< Node To Node Rotational Spring                    */
  VAEL_NGTSPR  = 32,	/**< Node To Ground Translational Spring               */
  VAEL_NGRSPR  = 36,	/**< Node To Ground Rotational Spring                  */
  VAEL_NNATSPR = 33,	/**< Node To Node Axi Translational Spring             */
  VAEL_NNARSPR = 37,	/**< Node To Node Axi Rotational Spring                */
  VAEL_NGATSPR = 34,	/**< Node To Ground Axi Translational Spring           */
  VAEL_NGARSPR = 38,	/**< Node To Ground Axi Rotational Spring              */
  VAEL_NNDAMP  = 12,	/**< Node To Node Damper                               */
  VAEL_NGDAMP  = 13,	/**< Node To Gound Damper                              */
  VAEL_LMASS   = 11,	/**< Lumped Mass                                       */
  VAEL_AXSLS   = 25,	/**< Axisymetric Linear Shell                          */
  VAEL_CONCON  =  5,	/**< Constraint                                        */
  VAEL_MEMLQ   = 62,	/**< Membrane Linear Quadilateral                      */
  VAEL_MEMPQ   = 64,	/**< Membrane Parabolic Quadilateral                   */
  VAEL_MEMLT   = 61,	/**< Membrane Linear Triangle                          */
  VAEL_MEMPT   = 63	  /**< Membrane Parabolic Triangle                       */
} CSXElementType;
  
//! FEGroup entities nature
typedef enum {
  FGN_NONE = 0,	/**< default value when nothing specified */
  FGN_NODES, /**< nodes of the mesh */
  FGN_ELEMENTS, /**< finite element */
  FGN_ALL /**< all available entity type */
} CSXGroupNature;

/*! \class CSXNode 
\brief Description of a node.

Node is used to describe a node when retrieving
the mesh description from a results database. The \em label of the node
is the user-side identifier. \em id is the internal 0-n identifier.
*/
class CSXNode 
{
public:
  CSXNode() { label=id=-1; }
  ~CSXNode(){};

  long label;		// user label 
  long id;		// internal 0-n index
  double xyz[3];	// coordinates in the global system
};


/*! \class CSXElement
\brief Description of a finite element.

Element is used to describe an element when retrieving
the mesh description from a results database. The \p nodes array
lists the internal ids of the nodes of the element. The number of nodes
is given by \numNodes.
*/
class CSXElement
{
public:
  CSXElement() {label=id=-1; numNodes=0; }
  ~CSXElement(){};

  long label;		// user label
  long id;		// internal 0-n index
  CSXElementType type; // ansys element type
  short numNodes;	// number of nodes
  long nodes[CSX_MAX_NB_NODES_PER_ELEMENT]; // connectivity, nodes identified by their id
};

/*! \class CSXGroup
\brief Description of a finite entities group (or component)

FEGroup is used to describe a finite entities group that is an homogeneous
list of element or nodes from the current mesh. FEGroups are used associated with some 
criteria to limit the evaluation process to a given area of the mesh. See the EvalCriterion.
*/
class CSXGroup 
{  
public:
  CSXGroup() {label=0;size=0;entities=NULL;}
  ~CSXGroup()
  {
    if (entities) 
      {	CADOE_FREE(entities); entities = NULL;	}
  }
  CSXGroup( const CSXGroup &grp ) { *this = grp; }
  CSXGroup& operator = ( const CSXGroup &grp);

  bool isNamed( const char * cname ) const
  {
#ifdef WINNT			
    return (_stricoll(cname,name)==0)?true:false;
#else
    return (strcasecmp(cname,name)==0)?true:false;
#endif	
  }
  long label; // user label
  CSXGroupNature nature; // nature of the group's entities
  char name[CSX_MAX_LEN_GROUP_NAME]; // name of the group / component
  long size; // group's size
  long *entities; // nodes/elements array, entities identified by their id
};

class CSXModel
{
public:
  CSXModel(){ clear(); }
  ~CSXModel() { clear(); }

  long getNumNodes(void) { return _vnodes.size(); }
  long getNumElements(void) { return _velements.size(); }
  long getNumGroups(void) { return _vgroups.size(); }
  vector<CSXNode> & getNodes( void ) { return _vnodes; }
  vector<CSXElement> & getElements( void ) { return _velements; }
  vector<CSXGroup*> & getGroups( void ) { return _vgroups; }
  const CSXGroup * getGroup( const string &name );
  const CSXGroup * getParameterSupport( const string &paramName );
  bool isNode(int label);
  bool isElement(int label);
  int createGroups( int numGroups, const CSXGroup *groups, bool byIndex );

  void init( T_modele *model, bool postmodel, bool nodalAveragingAcrossBodies );
  void clear( void )
  {
    _model = NULL;
    _vnodes.clear(); 
    _velements.clear(); 
    vector<CSXGroup*>::iterator itg;
    for( itg=_vgroups.begin() ; itg!=_vgroups.end() ; itg++ )
      delete (*itg);
    _vgroups.clear();
    _IndexPubNode.clear();
    _IndexPubElem.clear();
  }

private:
  T_modele*			_model;
  vector<CSXNode>		_vnodes;
  vector<CSXElement>		_velements;
  vector<CSXGroup*>		_vgroups;
  map<long,long>		_IndexPubNode;
  map<long,long>		_IndexPubElem;
  map<long,long>::iterator _itindex;
};

#endif
