/* sid 50.1 copy of FxConstants.h last changed by upd111 on 2005/06/04 13:21:06 */
/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 2002                                         */
/* *** ansys, inc.                                                        */
/* ---------------------------------------------------------------------- */

/*CFILE  FxConstants.h            ANSI_C
* File name: FxConstants.h
* Author/date: Stefan Reh  2002-02-06
* Primary function:
*    Define constants for the DesignXplorer tool
*/

#ifndef  _FX_CONSTANTS_H_
#define  _FX_CONSTANTS_H_

#include "globals.h"
#include "sysparh.h"

#ifndef  FX_PARMSIZE
#define  FX_PARMSIZE             (PARMSIZE+1)
#endif

#ifndef  FX_LABSIZE
#define  FX_LABSIZE              (4+1)
#endif

#ifndef  EXIT_SUCCESS
#define  EXIT_SUCCESS            0
#endif

#ifndef  EXIT_FAILURE
#define  EXIT_FAILURE            1
#endif


#endif  /* _FX_CONSTANTS_H_ */
