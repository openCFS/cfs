/* sid 50.7 copy of C_SxCommand.h last changed by eedelor on 2005/04/11 12:35:18 */
#ifndef __C_SXCOMMAND_H__
#define __C_SXCOMMAND_H__ 1

#include "cadoe.h"
#include "cadoe_string.h"
#include "cadoe_vector.h"
#include "cadoe_list.h"

#include "SxConstants.h"

#include "CParameter.h"
#include "sx_cons_solver.h"
#include "sx_CADOE_solver.h"
#include "sx_groupe.h"

class CEvalResultsField;
class CEvalResults;
class CCriterion;
class CEvalProcess;
class CSolutionXplorer;

// Defines the different categories of commands
// TODO: a deplacer dans SxConstants.h
typedef enum {
  E_CMDCAT_NONE = 0,
  E_CMDCAT_GENERAL, // sxrfil, sxmeth, sxoption
  E_CMDCAT_OUTPUT_VAR, // sxrslt
  E_CMDCAT_INPUT_VAR // sxreal, sxmp, sxgeom, sxdisc, sxfreq, sxsec, ...
} E_CmdCategory;

// the class definition are visible only to C++
#ifdef __cplusplus

// ===========================================================================
//
class C_SxCommand
//
// ===========================================================================
{
public:
  C_SxCommand( );
  C_SxCommand( const C_SxCommand &cmd ) { *this = cmd; }
  virtual ~C_SxCommand() {};
	
  C_SxCommand& operator = ( const C_SxCommand &cmd );
  bool operator == ( const C_SxCommand &cmd ) const;

  virtual E_CmdCategory Category(void) const {return E_CMDCAT_GENERAL;}
  virtual const char * Label(void) const {return "Undefined";}
  virtual E_VarTypes VarType(void) const {return VAR_TYPE_NONE;}

  // set / get members
  void SetActive( bool active=true ) { _bActive = active; }
  void SetName( const string &name ) { _sName = name; }
  void SetCommandLine( const string &commandLine ) { _sCommandLine = commandLine; }

  bool IsActive(void) const { return _bActive; }
  bool IsNamed( const string &name, size_t ncar=0 ) const;
  const string GetName(void) const {return _sName;}
  const char * GetNameCstr(void) const { return _sName.c_str(); }
  const string GetCommandLine(void) const {return _sCommandLine;}
  const char * GetCommandLineCstr(void) const {return _sCommandLine.c_str();}

  // initialize all data of the command
  //virtual void Reset(void);

  virtual void Print( E_PrintKeys iPrintElemKey=PRINT_NO ) const;
  virtual void PrintName( void ) const;
  virtual void PrintStatus( void ) const;

protected:
  bool			_bActive; // boolean Status: command is active or not
  string		_sName; // name of the command
  string                _sCommandLine; // store the command line from the input deck
};

// ---------------------------------------------------------------------------
class C_SxRfil : public C_SxCommand
// ---------------------------------------------------------------------------
{
public:
  C_SxRfil();
  C_SxRfil( const C_SxRfil &cmd ) { *this = cmd; }
  virtual ~C_SxRfil() {};
  virtual C_SxRfil& operator = ( const C_SxRfil &cmd );
	
  virtual const char * Label(void) const {return "SXRFIL";}
  virtual E_VarTypes VarType(void) const {return VAR_TYPE_RFIL;}

  virtual void SetPathName( const string &pathname ) { _sPathName = pathname; }
  virtual void SetPathName2( const string &pathname2 ) { _sPathName2 = pathname2; }
  virtual void SetStatus2( bool status2 ) { _bStatus2 = status2; }

  virtual string GetPathName( void ) const { return _sPathName; }
  virtual const char * GetPathNameCstr( void ) const { return _sPathName.c_str(); }
  virtual string GetPathName2( void ) const { return _sPathName2; }
  virtual const char * GetPathName2Cstr( void ) const { return _sPathName2.c_str(); }
  virtual bool GetStatus2( void ) const { return _bStatus2; }

  virtual void Print( E_PrintKeys iPrintElemKey=PRINT_NO ) const;

protected:
  string  _sPathName; // full path name of file
  string  _sPathName2; // full path name of file2
  bool    _bStatus2; // true if second pathname is used
};

// ---------------------------------------------------------------------------
class C_SxMeth : public C_SxCommand
// ---------------------------------------------------------------------------
{
public:
  C_SxMeth();
  C_SxMeth( const C_SxMeth &cmd ) { *this = cmd; }
  virtual ~C_SxMeth() {};
  virtual C_SxMeth& operator = ( const C_SxMeth &cmd );
	
  virtual const char * Label(void) const {return "SXMETH";}
  virtual E_VarTypes VarType(void) const {return VAR_TYPE_METH;}

  virtual void SetSolutionType( E_SXMETH_SoluTypes type ) { _iSoluType = type; }
  virtual void SetApprType( E_SXMETH_ApprTypes type );
  virtual void SetVerifyType( E_SXMETH_VerifyTypes type ) { _iVerifyType = type; }
  virtual void SetTrackType( E_SXMETH_TrackTypes type ) { _iTrackType = type; }

  virtual E_SXMETH_SoluTypes GetSolutionType( void ) const { return _iSoluType; }
  virtual E_SXMETH_ApprTypes GetApprType( void ) const { return _iApprType; }
  virtual E_SXMETH_VerifyTypes GetVerifyType( void ) const { return _iVerifyType; }
  virtual E_SXMETH_TrackTypes GetTrackType( void ) const { return _iTrackType; }

  virtual void Print( E_PrintKeys iPrintElemKey=PRINT_NO ) const;

protected:
  E_SXMETH_SoluTypes		_iSoluType; // solution type
  E_SXMETH_ApprTypes		_iApprType; // approximation type
  E_SXMETH_VerifyTypes		_iVerifyType; // verification type
  E_SXMETH_TrackTypes		_iTrackType; // mode tracking
};

// ---------------------------------------------------------------------------
class C_SxEval : public C_SxCommand
// ---------------------------------------------------------------------------
{
public:
  C_SxEval();
  virtual ~C_SxEval();
	
  virtual const char * Label(void) const {return "SXEVAL";}
  virtual E_VarTypes VarType(void) const {return VAR_TYPE_EVAL;}

  virtual void SetResultsFileOpen( bool opened=true ) { _bResultsFileOpen = opened; }
  virtual void SetPathName( const string &name ) { _sPathName = name; }
  
  virtual bool ResultsFileOpened( void ) const { return _bResultsFileOpen; }
  virtual string GetPathName( void ) const { return _sPathName; }

  virtual int Open( void );
  virtual int Close( void );

  virtual int sxevalplus_xfer( int     kcco,
			       int     iModeIdx,
			       int     iNumInp,
			       char    **cVarName,
			       double  *dCurrVal,
			       DOUBLE  *dEigenFrequencyOut,
			       INT     *iNumEnty,
			       INT     *iMaxResPerEnty,
			       INT     *hEnty,
			       INT     *hNumResPerEnty,
			       INT     *hResult );

 protected:
  bool			_bResultsFileOpen;
  string		_sPathName;

 private:
  // do not authorize copy for this command
  C_SxEval( const C_SxEval &cmd ) { *this = cmd; }
  virtual C_SxEval& operator = ( const C_SxEval &cmd );


  CSolutionXplorer 	*_Xplorer; // SolutionXplorer instance(assoc w. .rsx)

  INT			*_EntTab; // Entities list for each support
  E_solveur 		_UsedMethod;

  CEvalProcess 		*_Contour;
  CEvalProcess 		*_Point;

  int 			_Kydbug; // debug key
  int 			_Mode;
  int 			_FreqContext;

  list<CCriterion*> 	_SelectedCrit; // criteria we'll select for evaluation

  // results field container: for several designSet and several criteria
  // for each designSet   
  CEvalResultsField 	*_Resf;
  CEvalResults 		*_Resc;
};

// ---------------------------------------------------------------------------
class C_SxOption : public C_SxCommand
// ---------------------------------------------------------------------------
{
public:
  C_SxOption();
  C_SxOption( const C_SxOption &cmd ) { *this = cmd; }
  virtual ~C_SxOption() {};
  virtual C_SxOption& operator = ( const C_SxOption &cmd );
	
  virtual const char * Label(void) const {return "SXOPT";}
  virtual E_VarTypes VarType(void) const {return VAR_TYPE_OPT;}

  virtual void SetValue( const string &val ) { _sValue = val; }
  void SetPublicName( const string &publicName ) { _sPublicName = publicName; }

  virtual string GetValue( void ) { return _sValue; }
  virtual const char * GetValueCstr( void ) const { return _sValue.c_str(); }
  virtual int GetValueInt( void ) const;
  virtual double GetValueDouble( void ) const;
  const string GetPublicName(void) const {return _sPublicName;}
  const char * GetPublicNameCstr(void) const { return _sPublicName.c_str(); }
  void SetPublicAndInternalNames( const string &pubName );

protected:
  string		_sValue;
  string		_sPublicName;
};

// ===========================================================================
//
class C_SxVariable : public C_SxCommand
//
// ===========================================================================
{
public:
  C_SxVariable();
  C_SxVariable( const C_SxVariable &cmd ) { *this = cmd; }
  virtual ~C_SxVariable();
  C_SxVariable& operator = ( const C_SxVariable &cmd );

  virtual E_CmdCategory Category(void) const {return E_CMDCAT_GENERAL;}
  virtual const char * Label(void) const {return "Undefined";}
  virtual E_VarTypes VarType(void) const {return VAR_TYPE_NONE;}

  virtual void SetEntityDefinitionType( E_EntyDefTypes type ) { _iEntDefType = type; }
  virtual void SetComponentName( const string &compName ) { _sCompName = compName; }
  virtual void SetListOfEntities( int numEntities, int *entityList );

  virtual E_EntyDefTypes GetEntityDefinitionType( void ) const { return _iEntDefType; }
  virtual const string GetComponentName( void ) const { return _sCompName; }
  virtual const char * GetComponentNameCstr( void ) const { return _sCompName.c_str(); }
  virtual int GetNumberOfEntities( void ) const { return _vEntities.size(); }
  virtual void GetEntities( vector<int> &EntList ) const { EntList = _vEntities; }
  //virtual int GetEntities( int *EntList ) const;

  virtual int CheckType( const C_SxVariable &cmd ) const;

  virtual void PrintName( void ) const;

protected:
  E_EntyDefTypes	_iEntDefType; // entity definition type
  string		_sCompName; // component name
  vector<int>		_vEntities; // resulting list of entities
};

// ---------------------------------------------------------------------------
class C_SxRslt : public C_SxVariable
// ---------------------------------------------------------------------------
{
public:
  C_SxRslt();
  C_SxRslt( const C_SxRslt &cmd ) { *this = cmd; }
  virtual ~C_SxRslt() {};
  virtual C_SxRslt& operator = ( const C_SxRslt &cmd );
	
  virtual E_CmdCategory Category(void) const {return E_CMDCAT_OUTPUT_VAR;}
  virtual const char * Label(void) const {return "SXRSLT";}
  virtual E_VarTypes VarType(void) const {return VAR_TYPE_RSLT;}

  virtual void SetEntityType( E_SXRSLT_Entity type ) { _iEntyType = type; }
  virtual void SetResultType( E_SXRSLT_Types typeId ) { _iTypeId = typeId; }
  virtual void SetComponentType( E_SXRSLT_Comps compId ) { _iCompId = compId; }
  virtual void SetAccuracy( double acc ) { _dAccuracy = acc; }

  virtual E_SXRSLT_Entity GetEntityType( void ) const { return _iEntyType; }
  virtual E_SXRSLT_Types GetResultType( void ) const { return _iTypeId; }
  virtual E_SXRSLT_Comps GetComponentType( void ) const { return _iCompId; }
  virtual double GetAccuracy( void ) const { return _dAccuracy; }

  virtual int CheckEntityComp( E_SXRSLT_Types iRstType, E_SXRSLT_Comps iCompType ) const;
  virtual int CheckEntityType( E_SXRSLT_Types type, E_SXRSLT_Entity entity ) const;

  virtual const char * GetEntityLabel( E_SXRSLT_Entity entity ) const;
  virtual const char * GetCompLabel( E_SXRSLT_Comps comp ) const;
  virtual const char * GetTypeLabel( E_SXRSLT_Types type ) const;

  virtual void Print(E_PrintKeys iPrintElemKey=PRINT_NO) const;
  virtual void PrintName( void ) const;
  virtual void PrintStatus( void ) const;
  virtual void PrintResultsQuantity( void ) const;
  virtual void PrintAccuracy( void ) const;
  virtual void PrintResultsComponent( void ) const;
  virtual void PrintElemDefTypeAndList( E_PrintKeys iPrintElemKey=PRINT_NO ) const;

protected:
  E_SXRSLT_Entity    _iEntyType;
  E_SXRSLT_Types     _iTypeId; // type id of result quantity
  E_SXRSLT_Comps     _iCompId; // component id of result quantity
  double  	     _dAccuracy; // accuracy requested for result quantity
};

// ===========================================================================
//
class C_SxInputVariable : public C_SxVariable
//
// ===========================================================================
{
public:
  C_SxInputVariable();
  C_SxInputVariable( const C_SxInputVariable &cmd ) { *this = cmd; }
  virtual ~C_SxInputVariable() {};
  C_SxInputVariable& operator = ( const C_SxInputVariable &cmd );

  virtual E_CmdCategory Category(void) const {return E_CMDCAT_INPUT_VAR;}
  virtual const char * Label(void) const {return "Undefined";}
  virtual E_VarTypes VarType(void) const {return VAR_TYPE_NONE;}

  // true if the support of the variable is a list of nodes instead of elements
  virtual bool NodeBased(void) const { return false; } 

  virtual int SetCurrentValue( double dCurrVal ){ _dCurrVal = dCurrVal; return EXIT_SUCCESS;}
  virtual int SetUserMinimumValue( double dUserMinVal ) { _dUserMinVal = dUserMinVal; return EXIT_SUCCESS;}
  virtual int SetUserMaximumValue( double dUserMaxVal ) { _dUserMaxVal = dUserMaxVal; return EXIT_SUCCESS;}
  virtual int SetReductionOption( E_RedOpts reductionOption ) { _iRedOpt = reductionOption; return EXIT_SUCCESS;}
  virtual int SetVariationType( E_VariaTypes variationType ) { _iVariaType = variationType; return EXIT_SUCCESS;}
  virtual int SetSolverMinimumValue( double dSolvMinVal ) { _dSolvMinVal = dSolvMinVal; return EXIT_SUCCESS;}
  virtual int SetSolverMaximumValue( double dSolvMaxVal ) { _dSolvMaxVal = dSolvMaxVal; return EXIT_SUCCESS;}
  virtual int SetOrder( int order ) { _iOrder = order; return EXIT_SUCCESS;}
  virtual int SetID( int iID ) { _iID = iID; return EXIT_SUCCESS; }
  virtual int SetPropertyType( int type ) { _iPropType = type; return EXIT_SUCCESS; }
	
  virtual void GetCurrentValue( double &currVal ) const {currVal = _dCurrVal;}
  virtual void GetUserMinimumValue( double &userMinVal ) const {userMinVal = _dUserMinVal;}
  virtual void GetUserMaximumValue( double &userMaxVal ) const {userMaxVal = _dUserMaxVal;}
  virtual E_RedOpts GetReductionOption( void ) const {return _iRedOpt;}
  virtual E_VariaTypes GetVariationType( void ) const {return _iVariaType;}
  virtual void GetSolverMinimumValue( double &solvMinVal ) {solvMinVal = _dSolvMinVal;}
  virtual void GetSolverMaximumValue( double &solvMaxVal ) {solvMaxVal = _dSolvMaxVal;}
  virtual int GetOrder( void ) {return _iOrder;}
  virtual int GetID( void ) const { return _iID; }
  virtual int GetPropertyType( void ) const { return _iPropType; }

  virtual void Print(E_PrintKeys iPrintElemKey=PRINT_NO) const;
  virtual void PrintStatus( void ) const;
  virtual void PrintCurrentValue( void ) const;
  virtual void PrintUserRange( void ) const;
  virtual void PrintReductionOption( void ) const;
  virtual void PrintVariationType( void ) const;
  virtual void PrintSolverRange( void ) const;
  virtual void PrintOrder( void ) const;
  virtual void PrintElemDefTypeAndList( E_PrintKeys iPrintElemKey=PRINT_NO ) const;

  CParameter *BuildParameter( CParameter::Type type, T_modele *modele=NULL, T_groupe **grp=NULL ) const;

protected:
  double	_dCurrVal; // current value
  double	_dUserMinVal; // min value of the user range
  double	_dUserMaxVal; // max value of the user range
  E_RedOpts	_iRedOpt; // range reduction option
  E_VariaTypes	_iVariaType; // variation type (VAL, FACT, ADD)
  double	_dSolvMinVal; // min value of the solver validated range
  double	_dSolvMaxVal; // max value of the solver validated range
  int		_iOrder; // user required derivation order
  int           _iID; // material, real constant or section ID
  int           _iPropType; // material, real constant or section Property Type
};


// ---------------------------------------------------------------------------
class C_SxFreq : public C_SxInputVariable
// ---------------------------------------------------------------------------
{
public:
  C_SxFreq();
  C_SxFreq( const C_SxFreq &cmd ) { *this = cmd; }
  virtual ~C_SxFreq() {}
  virtual C_SxFreq& operator = ( const C_SxFreq &cmd );

  virtual const char * Label(void) const {return "SXFREQ";}
  virtual E_VarTypes VarType(void) const {return VAR_TYPE_FREQ;}

  virtual void SetNumberIncrements( int numIncr ) { _iNumIncr = numIncr; }
  virtual int GetNumberIncrements( void ) const { return _iNumIncr; }

  virtual void Print(E_PrintKeys iPrintElemKey=PRINT_NO) const;

protected:
  int _iNumIncr; // number of increments
};

// ---------------------------------------------------------------------------
class C_SxTemp : public C_SxInputVariable
// ---------------------------------------------------------------------------
{
public:
  C_SxTemp();
  C_SxTemp( const C_SxTemp &cmd ) { *this = cmd; }
  virtual ~C_SxTemp() {};
  virtual C_SxTemp& operator = ( const C_SxTemp &cmd );

  virtual const char * Label(void) const {return "SXTEMP";}
  virtual E_VarTypes VarType(void) const {return VAR_TYPE_TEMP;}
  // true if the support of the variable is a list of nodes instead of elements
  virtual bool NodeBased(void) const { return true; } 

  virtual void Print(E_PrintKeys iPrintElemKey=PRINT_NO) const;

  CParameter *BuildParameter( T_modele *modele, T_groupe **grp ) const;

protected:
};

// ---------------------------------------------------------------------------
class C_SxMp : public C_SxInputVariable
// ---------------------------------------------------------------------------
{
public:
  C_SxMp();
  C_SxMp( const C_SxMp &cmd ) { *this = cmd; }
  virtual ~C_SxMp() {};
  virtual C_SxMp& operator = ( const C_SxMp &cmd );

  virtual const char * Label(void) const {return "SXMP";}
  virtual E_VarTypes VarType(void) const {return VAR_TYPE_MP;}

  virtual void SetMatPropertyType( E_MatPropTypes matType ) { _iPropType = (int)matType; }
  virtual void SetMatId( int matId ) { _iID = matId; }
  
  virtual E_MatPropTypes GetMatPropertyType( void ) const { return (E_MatPropTypes)_iPropType; }
  virtual int GetMatId( void ) const { return _iID; }

  virtual void Print(E_PrintKeys iPrintElemKey=PRINT_NO) const;

  CParameter *BuildParameter( T_modele *modele, T_groupe **grp ) const;

protected:
};

// ---------------------------------------------------------------------------
class C_SxIn : public C_SxInputVariable
// ---------------------------------------------------------------------------
{
public:
  C_SxIn();
  C_SxIn( const C_SxIn &cmd ) { *this = cmd; }
  virtual ~C_SxIn() {};
  virtual C_SxIn& operator = ( const C_SxIn &cmd );
	
  virtual const char * Label(void) const {return "SXIN";}
  virtual E_VarTypes VarType(void) const {return VAR_TYPE_IN;}

  virtual void SetLoadType( E_InLoadType loadType ) { _iLoadType = loadType; }
  virtual void SetLoadComponent( E_InLoadComp comp ) { _iLoadComp = comp; }

  virtual E_InLoadType GetLoadType(void) const {return _iLoadType; }
  virtual E_InLoadComp GetLoadComp(void) const {return _iLoadComp; }

  virtual void Print(E_PrintKeys iPrintElemKey=PRINT_NO) const;

  CParameter *BuildParameter( void ) const;

protected:
  E_InLoadType     _iLoadType; // inertia load type
  E_InLoadComp     _iLoadComp; // inertia load component
};

// ---------------------------------------------------------------------------
class C_SxReal : public C_SxInputVariable
// ---------------------------------------------------------------------------
{
public:
  C_SxReal();
  C_SxReal( const C_SxReal &cmd ) { *this = cmd; }
  virtual ~C_SxReal() {};
  virtual C_SxReal& operator = ( const C_SxReal &cmd );
	
  virtual const char * Label(void) const {return "SXREAL";}
  virtual E_VarTypes VarType(void) const {return VAR_TYPE_REAL;}

  virtual void SetRealPropertyType( E_RealPropTypes propType ) { _iPropType = (int)propType; }
  virtual void SetRealId( int realId ) { _iID = realId; }

  virtual E_RealPropTypes GetRealPropertyType( void ) const { return (E_RealPropTypes)_iPropType; }
  virtual int GetRealId( void ) const { return _iID; }

  virtual void Print(E_PrintKeys iPrintElemKey=PRINT_NO) const;

  CParameter *BuildParameter( T_modele *modele, T_groupe **grp ) const;

protected:
};

// ---------------------------------------------------------------------------
class C_SxSec : public C_SxInputVariable
// ---------------------------------------------------------------------------
{
public:
  C_SxSec();
  C_SxSec( const C_SxSec &cmd ) { *this = cmd; }
  virtual ~C_SxSec() {};
  virtual C_SxSec& operator = ( const C_SxSec &cmd );
	
  virtual const char * Label(void) const {return "SXSEC";}
  virtual E_VarTypes VarType(void) const {return VAR_TYPE_SEC;}

  virtual void SetSecPropType( E_SecPropTypes propType ) { _iSecPropType = propType; }
  virtual void SetSecId( int secId ) { _iID = secId; }
  virtual void SetLayerDefinitionType( E_LayerDefTypes layerDefType ) { _iLayerDefType = layerDefType; }
  virtual void SetLayerId( int layerId ) { _iLayerId =layerId; }

  virtual E_SecPropTypes GetSecPropType( void ) const { return _iSecPropType; }
  virtual int GetSecId( void ) const { return _iID; }
  virtual E_LayerDefTypes GetLayerDefinitionType( void ) const { return _iLayerDefType; }
  virtual int GetLayerId( void ) const { return _iLayerId; }

  virtual void Print(E_PrintKeys iPrintElemKey=PRINT_NO) const;

  CParameter *BuildParameter( T_modele *modele, T_groupe **grp ) const;

protected:
  E_SecPropTypes   _iSecPropType; // section property type
  E_LayerDefTypes  _iLayerDefType; // layer definition type
  int              _iLayerId; // layer identifier
};

// ---------------------------------------------------------------------------
class C_SxCe : public C_SxInputVariable
// ---------------------------------------------------------------------------
{
public:
  C_SxCe();
  C_SxCe( const C_SxCe &cmd ) { *this = cmd; }
  virtual ~C_SxCe() {};
  virtual C_SxCe& operator = ( const C_SxCe &cmd );
	
  virtual const char * Label(void) const {return "SXCE";}
  virtual E_VarTypes VarType(void) const {return VAR_TYPE_CE;}

  virtual void SetCeId( int id ) { _iCeId = id; }
  virtual void SetComp( int comp ) { _iComp = comp; }

  virtual int GetCeId( void ) const { return _iCeId; }
  virtual int GetComp( void ) const { return _iComp; }

  virtual void Print(E_PrintKeys iPrintElemKey=PRINT_NO) const;

protected:
  int _iCeId; // CE identifier
  int _iComp; // component id.
};

// ---------------------------------------------------------------------------
class C_SxHi : public C_SxInputVariable
// ---------------------------------------------------------------------------
{
public:
  C_SxHi();
  C_SxHi( const C_SxHi &cmd ) { *this = cmd; }
  virtual ~C_SxHi() {};
  virtual C_SxHi& operator = ( const C_SxHi &cmd );
	
  virtual const char * Label(void) const {return "SXHI";}
  virtual E_VarTypes VarType(void) const {return VAR_TYPE_HI;}

  // override methods to use integer type
  virtual int SetCurrentValue( int iCurrVal ) { _dCurrVal = (double)iCurrVal; return EXIT_SUCCESS;}
  virtual int SetUserMinimumValue( int iUserMinVal ) { _dUserMinVal = (double)iUserMinVal; return EXIT_SUCCESS;}
  virtual int SetUserMaximumValue( int iUserMaxVal ) { _dUserMaxVal = (double)iUserMaxVal; return EXIT_SUCCESS;}
  virtual int SetSolverMinimumValue( int iSolvMinVal ) { _dSolvMinVal = (double)iSolvMinVal; return EXIT_SUCCESS;}
  virtual int SetSolverMaximumValue( int iSolvMaxVal ) { _dSolvMaxVal = (double)iSolvMaxVal; return EXIT_SUCCESS;}
	
  virtual void GetCurrentVal( int &currVal ) const {currVal = (int)_dCurrVal;}
  virtual void GetUserMinimumValue( int &userMinVal ) const {userMinVal = (int)_dUserMinVal;}
  virtual void GetUserMaximumValue( int &userMaxVal ) const {userMaxVal = (int)_dUserMaxVal;}
  virtual void GetSolverMinimumValue( int &solvMinVal ) {solvMinVal = (int)_dSolvMinVal;}
  virtual void GetSolverMaximumValue( int &solvMaxVal ) {solvMaxVal = (int)_dSolvMaxVal;}

  // to remove linux warnings, let's define also the "double" ones :(
  virtual int SetCurrentValue( double dCurrVal ) { _dCurrVal = dCurrVal; return EXIT_SUCCESS; }
  virtual int SetUserMinimumValue( double dUserMinVal ) { _dUserMinVal = dUserMinVal; return EXIT_SUCCESS;}
  virtual int SetUserMaximumValue( double dUserMaxVal ) { _dUserMaxVal = dUserMaxVal; return EXIT_SUCCESS;}
  virtual int SetSolverMinimumValue( double dSolvMinVal ) { _dSolvMinVal = dSolvMinVal; return EXIT_SUCCESS;}
  virtual int SetSolverMaximumValue( double dSolvMaxVal ) { _dSolvMaxVal = dSolvMaxVal; return EXIT_SUCCESS;}	
  virtual void GetCurrentVal( double &currVal ) const {currVal = _dCurrVal;}
  virtual void GetUserMinimumValue( double &userMinVal ) const {userMinVal = _dUserMinVal;}
  virtual void GetUserMaximumValue( double &userMaxVal ) const {userMaxVal = _dUserMaxVal;}
  virtual void GetSolverMinimumValue( double &solvMinVal ) {solvMinVal = _dSolvMinVal;}
  virtual void GetSolverMaximumValue( double &solvMaxVal ) {solvMaxVal = _dSolvMaxVal;}

  virtual void Print(E_PrintKeys iPrintElemKey=PRINT_NO) const;
  virtual void PrintCurrentValue( void ) const;
  virtual void PrintUserRange( void ) const;
  virtual void PrintSolverRange( void ) const;

  CParameter *BuildParameter( void ) const;

protected:
};

// ---------------------------------------------------------------------------
class C_SxGeom : public C_SxInputVariable
// ---------------------------------------------------------------------------
{
public:
  C_SxGeom();
  C_SxGeom( const C_SxGeom &cmd ) { *this = cmd; }
  virtual ~C_SxGeom() {};
  virtual C_SxGeom& operator = ( const C_SxGeom &cmd );
	
  virtual const char * Label(void) const {return "SXGEOM";}
  virtual E_VarTypes VarType(void) const {return VAR_TYPE_GEOM;}

  virtual void SetRangeDefined( bool RangeDefined ) { _bRangeDefined = RangeDefined; }
  virtual bool GetRangeDefined( void ) const { return _bRangeDefined; }

  virtual void Print(E_PrintKeys iPrintElemKey=PRINT_NO) const;

  virtual void UpdateParameter( CParameter &mshParam ) const;

protected:
  bool _bRangeDefined; // true if range is redefined (use paramesh ones by default)
};

// ---------------------------------------------------------------------------
class C_SxDisc : public C_SxInputVariable
// ---------------------------------------------------------------------------
{
public:
  C_SxDisc();
  C_SxDisc( const C_SxDisc &cmd ) { *this = cmd; }
  virtual ~C_SxDisc() {};

  C_SxDisc& operator = ( const C_SxDisc &cmd );
	
  virtual const char * Label(void) const {return "SXDISC";}
  virtual E_VarTypes VarType(void) const {return VAR_TYPE_DISC;}

  virtual int SetCurrentValue( double dCurrVal );

  virtual void PrintCurrentValue( void ) const;
  virtual void Print(E_PrintKeys iPrintElemKey=PRINT_NO) const;

  CParameter *BuildParameter( T_modele *modele, T_groupe **grp ) const;

protected:
};

// ---------------------------------------------------------------------------
class C_SxSfe : public C_SxInputVariable
// ---------------------------------------------------------------------------
{
public:
  C_SxSfe();
  C_SxSfe( const C_SxSfe &cmd ) { *this = cmd; }
  virtual ~C_SxSfe() {};
  virtual C_SxSfe& operator = ( const C_SxSfe &cmd );
	
  virtual const char * Label(void) const {return "SXSFE";}
  virtual E_VarTypes VarType(void) const {return VAR_TYPE_SFE;}

  virtual void SetSurfaceLoadType( E_SXSFE_SurfLoadTypes surfLoadType ) { _iSurfLoadType = surfLoadType;}
  virtual void SetLoadKeyId( int loadKeyId ) { _iLoadKeyId = loadKeyId; }
  virtual void SetElementType( int elemType ) { _iElemType = elemType; }

  virtual E_SXSFE_SurfLoadTypes GetSurfaceLoadType( void ) const { return _iSurfLoadType; }
  virtual int GetLoadKeyId( void ) const { return _iLoadKeyId; }
  virtual int GetElementType( void ) { return _iElemType; }

  virtual void Print(E_PrintKeys iPrintElemKey=PRINT_NO) const;

  CParameter *BuildParameter( T_modele *modele ) const;

protected:
  E_SXSFE_SurfLoadTypes   _iSurfLoadType; // surface load type
  int              _iLoadKeyId; // load key id
  int              _iElemType;
};

#endif // __cplusplus

// ===========================================================================
//
//  C routines prototypes
//
// ===========================================================================

#ifdef __cplusplus
extern "C" {
#endif

  extern int PutSxdiscData( const char*, E_EntyDefTypes, const char*, int, int*, double, int );

  extern int PutSxgeomData( const char*, int, double, double, E_RedOpts, int, double ,double, int );

  extern int PutSxhiData( const char*, int, int, int, E_RedOpts, int );

  extern int PutSxVarData( const char *cVarName, E_VarTypes iVarType,
			   double dCurrVal, double dUserMinVal, double dUserMaxVal,
			   E_RedOpts iRedOpt, int iPropType, 
			   E_EntyDefTypes iElemDefType, int iID, 
			   E_LayerDefTypes iLayerDefType, int iLayerId, 
			   const char *cElemCompName, 
			   int iNumElem, int *iElemList, E_VariaTypes iVariaType, int iOrder, 
			   double dSolvMinVal, double dSolvMaxVal, int iStatus );

  extern int PutSxfreqData ( const char *cVarName, double dCurrVal, double dUserMinVal, double dUserMaxVal, 
			     int iNumIncr, E_RedOpts iRedOpt, 
			     double dSolvMinVal, double dSolvMaxVal, int iStatus );

  extern int PutSxinData( const char *cVarName, double dCurrVal, double dUserMinVal, double dUserMaxVal,
			  E_RedOpts iRedOpt, E_InLoadType iLoadType, E_InLoadComp iLoadComp,
			  E_VariaTypes iVariaType, int iOrder,
			  double dSolvMinVal, double dSolvMaxVal, int iStatus );

  extern int PutSxrsltData( const char *cVarName,
			    E_SXRSLT_Entity iEntyType, E_SXRSLT_Types iTypeId, E_SXRSLT_Comps iCompId,
			    double dAccuracy, 
			    E_EntyDefTypes iEntyDefType,
			    const char *cEntyCompName,
			    int iNumEnty, int *iEntyList, int iStatus );

  extern int PutSxceData( const char *cVarName, double CurrVal, double dUserMinVal, double dUserMaxVal, 
			  E_RedOpts iRedOpt, int iCeId, int iComp, E_VariaTypes iVariaType,
			  double dSolvMinVal, double dSolvMaxVal, int iStatus );

  extern int PutSxsfeData( const char *cVarName, double dCurrVal, double dUserMinVal, double dUserMaxVal,
			   E_RedOpts iRedOpt, E_SXSFE_SurfLoadTypes iSurfaceLoadType, int iLoadKeyId,
			   E_EntyDefTypes iElemDefTypeIn, const char *cEntyCompName, int iNumEnty, int *iEntyList, int iElemType, 
			   E_VariaTypes iVariaType, int iOrder, double dSolvMinVal, double dSolvMaxVal, int iStatus );
  
  extern int ProcSxevalCmd( E_PrintKeys, int, E_SXRSLT_Entity, E_SXRSLT_Types,
			    DOUBLE *, INT *, INT *, INT *, INT *, INT * );
  
  extern int InitSxevalData( void );
  extern int GetSxInpCurrVal( int *iNumInp, double **dCurrVal, char ***cVarName, char **cVarNameData );
  
  extern int ProcSxoptionCmd(const char *cCommandOption, const char *cNameOption, const char *cValOption);

  extern int ProcSxvmodCmd( const char *cVarName, E_SXVMOD_OperTypes iOperOpt, double dCurrVal, int iCheckOpt );

  extern int ProcSxqaCmd ( E_SXQA_Action Action, int Crit_NC, E_SXQA_Info_Item InfoIt, 
			   const char *pname, int NodeBool_NC, int Node, int ElemBool_NC, 
			   int Elem, int CompBool_NC, const char *Comp, E_SXQA_Layer Layer, 
			   int Absol_NC, int Negat_NC, int Global_NC, int Minim_NC, 
			   int NumSensiPoints, int NumRandomPoints);
      
#ifdef __cplusplus
}
#endif

#endif /*__C_SXCOMMAND_H__*/
