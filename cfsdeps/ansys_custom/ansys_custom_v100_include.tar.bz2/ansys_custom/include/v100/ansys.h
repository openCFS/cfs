/* sid 50.1 copy of ansys.h last changed by upd111 on 2005/06/04 13:18:14 */
/*HFILE ansys.h	                                            sam, system
------------------------------------------------------------------------
------- Notice - This file contains ANSYS Confidential information 
------------------------------------------------------------------------
*/

/*------------------------------ Description ---------------------------
\Author:	Sam Murgie (sam)
\Title:		main Ansys header
\Desc:		This header should be included in nearly all C and C++
                ANSYS routines.  It includes computer.h and globals.h.
\History:	99/02/16 - sam: Initial creation.

\Function(s) 
 -Primary:	To supply a single include file that contains all system
                dependent and other global definitions that are to be 
                included in all C & C++ source files.
 -Secondary:	none
 -External:	none
 -Internal:	none
 -Static:	none
----------------------------------------------------------------------*/

/*------------------------------ Header files ------------------------*/

#include "computer.h"
#include "globals.h"
#include "cAns_printf.h"

/*---------------------------- End Of Module -------------------------*/


