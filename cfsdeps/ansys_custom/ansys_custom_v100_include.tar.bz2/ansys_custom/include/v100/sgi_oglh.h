/* sid 50.1 copy of sgi_oglh.h last changed by upd111 on 2005/06/04 13:14:31 */
/* 
 * *** ansys(r) copyright(c) 2000
 * *** ansys, inc.
 */
#if defined(RS6000_SYS) || defined(HP32_SYS)
#define d2aaxx_ d2aaxx
#define gl_d2alxx_ gl_d2alxx
#define d2arxx_ d2arxx
#define d2bexx_ d2bexx
#define txtr_imag_xx_ txtr_imag_xx
#define d2foxx_ d2foxx
#define d2chxx_ d2chxx
#define d2msxx_ d2msxx
#define d2bmxx_ d2bmxx
#define d2cexx_ d2cexx
#define d2cixx_ d2cixx
#define d2cmxx_ d2cmxx
#define d2coxx_ d2coxx
#define d2cpxx_ d2cpxx
#define d2csxx_ d2csxx
#define d2crxx_ d2crxx
#define d2ctxx_ d2ctxx
#define d2dixx_ d2dixx
#define d2drxx_ d2drxx
#define d2dtxx_ d2dtxx
#define d2pdxx_ d2pdxx
#define d2enxx_ d2enxx
#define d2evxx_ d2evxx
#define d2gcxx_ d2gcxx
#define d2ggxx_ d2ggxx
#define d2raxx_ d2raxx
#define d2gmxx_ d2gmxx
#define d2ifxx_ d2ifxx
#define d2iqxx_ d2iqxx
#define d2iwxx_ d2iwxx
#define d2kcxx_ d2kcxx
#define d2kixx_ d2kixx
#define d2koxx_ d2koxx
#define d2ltxx_ d2ltxx
#define d2luxx_ d2luxx
#define d2lwxx_ d2lwxx
#define d2mvxx_ d2mvxx
#define d2nmxx_ d2nmxx
#define d2opxx_ d2opxx
#define d2paxx_ d2paxx
#define d2poxx_ d2poxx
#define d2puxx_ d2puxx
#define d2rcxx_ d2rcxx
#define d2rexx_ d2rexx
#define d2rsxx_ d2rsxx
#define d2sdxx_ d2sdxx
#define d2sgxx_ d2sgxx
#define d2spxx_ d2spxx
#define d2stxx_ d2stxx
#define d2swxx_ d2swxx
#define d2tcxx_ d2tcxx
#define d2tixx_ d2tixx
#define d2tmxx_ d2tmxx
#define d2tnxx_ d2tnxx
#define d2toxx_ d2toxx
#define d2trxx_ d2trxx
#define d2tsxx_ d2tsxx
#define d2ttxx_ d2ttxx
#define d2wnxx_ d2wnxx
#define d3arxx_ d3arxx
#define d3arxx_dlist_ d3arxx_dlist
#define d3cnxx_ d3cnxx
#define d3dlxx_ d3dlxx
#define d3drxx_ d3drxx
#define d3dtxx_ d3dtxx
#define d3fixx_ d3fixx
#define d3imxx_ d3imxx
#define d3lbxx_ d3lbxx
#define gl_d3lbxx_ gl_d3lbxx
#define gl_d3rlxx_ gl_d3rlxx
#define d2bxxx_ d2bxxx
#define d3ldxx_ d3ldxx
#define d3lnxx_ d3lnxx
#define d3loxx_ d3loxx
#define d3mvxx_ d3mvxx
#define d3rnxx_ d3rnxx
#define d3stxx_ d3stxx
#define d3upxx_ d3upxx
#define d3vdxx_ d3vdxx
#define d3vrxx_ d3vrxx
#define d3vwxx_ d3vwxx
#define d3wexx_ d3wexx
#define d3wsxx_ d3wsxx
#define d2cvxx_ d2cvxx
#define d2cvxx_them_ d2cvxx_them
#define d2fcxx_ d2fcxx
#define d2icxx_ d2icxx
#define d2zoxx_ d2zoxx
#define d2svxx_ d2svxx
#define d2vsxx_ d2vsxx
#define d2xrxx_ d2xrxx
#define d3dbxx_ d3dbxx
#define d3trixx_ d3trixx
#define d3tfanxx_ d3tfanxx
#define d3txtrxx_ d3txtrxx
#endif

#if defined(WATCOMC_SYS) \
    || defined(PCWINNT_SYS)
#define d2aaxx_ D2AAXX
#define gl_d2alxx_ GL_D2ALXX
#define d2arxx_ D2ARXX
#define d2bexx_ D2BEXX
#define txtr_imag_xx_ TXTR_IMAG_XX
#define d2foxx_ D2FOXX
#define d2chxx_ D2CHXX
#define d2msxx_ D2MSXX
#define d2bmxx_ D2BMXX
#define d2cexx_ D2CEXX
#define d2cixx_ D2CIXX
#define d2cmxx_ D2CMXX
#define d2coxx_ D2COXX
#define d2cpxx_ D2CPXX
#define d2csxx_ D2CSXX
#define d2crxx_ D2CRXX
#define d2ctxx_ D2CTXX
#define d2dixx_ D2DIXX
#define d2drxx_ D2DRXX
#define d2dtxx_ D2DTXX
#define d2pdxx_ D2PDXX
#define d2enxx_ D2ENXX
#define d2evxx_ D2EVXX
#define d2gcxx_ D2GCXX
#define d2ggxx_ D2GGXX
#define d2raxx_ D2RAXX
#define d2gmxx_ D2GMXX
#define d2ifxx_ D2IFXX
#define d2iqxx_ D2IQXX
#define d2iwxx_ D2IWXX
#define d2kcxx_ D2KCXX
#define d2kixx_ D2KIXX
#define d2koxx_ D2KOXX
#define d2ltxx_ D2LTXX
#define d2luxx_ D2LUXX
#define d2lwxx_ D2LWXX
#define d2mvxx_ D2MVXX
#define d2nmxx_ D2NMXX
#define d2opxx_ D2OPXX
#define d2paxx_ D2PAXX
#define d2poxx_ D2POXX
#define d2puxx_ D2PUXX
#define d2rcxx_ D2RCXX
#define d2rexx_ D2REXX
#define d2rsxx_ D2RSXX
#define d2sdxx_ D2SDXX
#define d2sgxx_ D2SGXX
#define d2spxx_ D2SPXX
#define d2stxx_ D2STXX
#define d2swxx_ D2SWXX
#define d2tcxx_ D2TCXX
#define d2tixx_ D2TIXX
#define d2tmxx_ D2TMXX
#define d2tnxx_ D2TNXX
#define d2toxx_ D2TOXX
#define d2trxx_ D2TRXX
#define d2tsxx_ D2TSXX
#define d2ttxx_ D2TTXX
#define d2wnxx_ D2WNXX
#define d3arxx_ D3ARXX
#define d3arxx_dlist_ D3ARXX_DLIST
#define d3cnxx_ D3CNXX
#define d3dlxx_ D3DLXX
#define d3drxx_ D3DRXX
#define d3dtxx_ D3DTXX
#define d3fixx_ D3FIXX
#define d3imxx_ D3IMXX
#define d3lbxx_ D3LBXX
#define gl_d3lbxx_ GL_D3LBXX
#define gl_d3rlxx_ GL_D3RLXX
#define d2bxxx_ D2BXXX
#define d3ldxx_ D3LDXX
#define d3lnxx_ D3LNXX
#define d3loxx_ D3LOXX
#define d3mvxx_ D3MVXX
#define d3rnxx_ D3RNXX
#define d3stxx_ D3STXX
#define d3upxx_ D3UPXX
#define d3vdxx_ D3VDXX
#define d3vrxx_ D3VRXX
#define d3vwxx_ D3VWXX
#define d3wexx_ D3WEXX
#define d3wsxx_ D3WSXX
#define d2cvxx_ D2CVXX
#define d2cvxx_them_ D2CVXX_THEM
#define d2fcxx_ D2FCXX
#define d2icxx_ D2ICXX
#define d2zoxx_ D2ZOXX
#define d2svxx_ D2SVXX
#define d2vsxx_ D2VSXX
#define d2xrxx_ D2XRXX
#define d3dbxx_ D3DBXX
#define d3trixx_ D3TRIXX
#define d3tfanxx_ D3TFANXX
#define d3txtrxx_ D3TXTRXX
#endif

#if defined(WATCOMC_SYS)
#pragma aux D2AAXX "^";
#pragma aux GL_D2ALXX "^";
#pragma aux D2ARXX "^";
#pragma aux D2BEXX "^";
#pragma aux TXTR_IMAG_XX "^";
#pragma aux D2FOXX "^";
#pragma aux D2CHXX "^";
#pragma aux D2MSXX "^";
#pragma aux D2BMXX "^";
#pragma aux D2CEXX "^";
#pragma aux D2CIXX "^";
#pragma aux D2CMXX "^";
#pragma aux D2COXX "^";
#pragma aux D2CPXX "^";
#pragma aux D2CSXX "^";
#pragma aux D2CRXX "^";
#pragma aux D2CTXX "^";
#pragma aux D2DIXX "^";
#pragma aux D2DRXX "^";
#pragma aux D2DTXX "^";
#pragma aux D2PDXX "^";
#pragma aux D2ENXX "^";
#pragma aux D2EVXX "^";
#pragma aux D2GCXX "^";
#pragma aux D2GGXX "^";
#pragma aux D2RAXX "^";
#pragma aux D2GMXX "^";
#pragma aux D2IFXX "^";
#pragma aux D2IQXX "^";
#pragma aux D2IWXX "^";
#pragma aux D2KCXX "^";
#pragma aux D2KIXX "^";
#pragma aux D2KOXX "^";
#pragma aux D2LTXX "^";
#pragma aux D2LUXX "^";
#pragma aux D2LWXX "^";
#pragma aux D2MVXX "^";
#pragma aux D2NMXX "^";
#pragma aux D2OPXX "^";
#pragma aux D2PAXX "^";
#pragma aux D2POXX "^";
#pragma aux D2PUXX "^";
#pragma aux D2RCXX "^";
#pragma aux D2REXX "^";
#pragma aux D2RSXX "^";
#pragma aux D2SDXX "^";
#pragma aux D2SGXX "^";
#pragma aux D2SPXX "^";
#pragma aux D2STXX "^";
#pragma aux D2SWXX "^";
#pragma aux D2TCXX "^";
#pragma aux D2TIXX "^";
#pragma aux D2TMXX "^";
#pragma aux D2TNXX "^";
#pragma aux D2TOXX "^";
#pragma aux D2TRXX "^";
#pragma aux D2TSXX "^";
#pragma aux D2TTXX "^";
#pragma aux D2WNXX "^";
#pragma aux D3ARXX "^";
#pragma aux D3ARXX_DLIST "^";
#pragma aux D3CNXX "^";
#pragma aux D3DLXX "^";
#pragma aux D3DRXX "^";
#pragma aux D3DTXX "^";
#pragma aux D3FIXX "^";
#pragma aux D3IMXX "^";
#pragma aux D3LBXX "^";
#pragma aux GL_D3LBXX "^";
#pragma aux GL_D3RLXX "^";
#pragma aux D2BXXX "^";
#pragma aux D3LDXX "^";
#pragma aux D3LNXX "^";
#pragma aux D3LOXX "^";
#pragma aux D3MVXX "^";
#pragma aux D3RNXX "^";
#pragma aux D3STXX "^";
#pragma aux D3UPXX "^";
#pragma aux D3VDXX "^";
#pragma aux D3VRXX "^";
#pragma aux D3VWXX "^";
#pragma aux D3WEXX "^";
#pragma aux D3WSXX "^";
#pragma aux D2CVXX "^";
#pragma aux D2CVXX_THEM "^";
#pragma aux D2FCXX "^";
#pragma aux D2ICXX "^";
#pragma aux D2ZOXX "^";
#pragma aux D2SVXX "^";
#pragma aux D2VSXX "^";
#pragma aux D2XRXX "^";
#pragma aux D3DBXX "^";
#pragma aux D3TRIXX "^";
#pragma aux D3TFANXX "^";
#pragma aux D3TXTRXX "^";
#endif


#if !defined(PCWINNT_SYS)
   void d2aaxx_();
   void gl_d2alxx_();
   void d2arxx_();
   void d2bexx_();
   INT  txtr_imag_xx_();
   void d2foxx_();
   void d2chxx_();
   void d2msxx_();
   void d2bmxx_();
   void d2cexx_();
   void d2cixx_();
   void d2cmxx_();
   void d2coxx_();
   void d2cpxx_();
   void d2csxx_();
   void d2crxx_();
   void d2ctxx_();
   void d2dixx_();
   void d2drxx_();
   void d2dtxx_();
   void d2pdxx_();
   void d2enxx_();
   void d2evxx_();
   void d2gcxx_();
   void d2ggxx_();
   void d2raxx_();
   void d2gmxx_();
   void d2ifxx_();
   void d2iqxx_();
   void d2iwxx_();
   void d2kcxx_();
   void d2kixx_();
   void d2koxx_();
   void d2ltxx_();
   void d2luxx_();
   void d2lwxx_();
   void d2mvxx_();
   void d2nmxx_();
   void d2opxx_();
   void d2paxx_();
   void d2poxx_();
   void d2puxx_();
   void d2rcxx_();
   void d2rexx_();
   void d2rsxx_();
   void d2sdxx_();
   void d2sgxx_();
   void d2spxx_();
   void d2stxx_();
   void d2swxx_();
   void d2tcxx_();
   void d2tixx_();
   void d2tmxx_();
   void d2tnxx_();
   void d2toxx_();
   void d2trxx_();
   void d2tsxx_();
   void d2ttxx_();
   void d2wnxx_();
   void d3arxx_();
   void d3arxx_dlist_();
   void d3cnxx_();
   void d3dlxx_();
   void d3drxx_();
   void d3dtxx_();
   void d3fixx_();
   void d3imxx_();
   void d3lbxx_();
   void gl_d3lbxx_();
   void gl_d3rlxx_();
   void d2bxxx_();
   void d3ldxx_();
   void d3lnxx_();
   void d3loxx_();
   void d3mvxx_();
   void d3rnxx_();
   void d3stxx_();
   void d3upxx_();
   void d3vdxx_();
   void d3vrxx_();
   void d3vwxx_();
   void d3wexx_();
   void d3wsxx_();
   void d2cvxx_();
   void d2cvxx_them_();
   void d2fcxx_();
   void d2icxx_();
   void d2zoxx_();
   void d2svxx_();
   void d2vsxx_();
   void d2xrxx_();
   void d3dbxx_();
   void d3trixx_();
   void d3tfanxx_();
   void d3txtrxx_();
#else
   void CALLTYP d2aaxx_( INT * );
   void CALLTYP gl_d2alxx_( double *, double *, INT *, INT * );
   void CALLTYP d2arxx_( double (*)[2], INT *, INT * );
   void CALLTYP d2bexx_( void );
   INT  CALLTYP txtr_imag_xx_( INT *, double *, double *);
   void CALLTYP d2foxx_( INT *, INT[8][65] );
   void CALLTYP d2chxx_( double *, double *);
   void CALLTYP d2msxx_( INT * );
   void CALLTYP d2bmxx_( void );
   void CALLTYP d2cexx_( void );
   void CALLTYP d2cixx_( double *, double *, INT * );
   void CALLTYP d2cmxx_( INT *, INT *, INT *, INT * );
   void CALLTYP d2coxx_( void );
   void CALLTYP d2cpxx_( void );
   void CALLTYP d2csxx_( double *, double *, INT * );
   void CALLTYP d2crxx_( INT *, double *, double *, double *, double *, INT * );
   void CALLTYP d2ctxx_( void );
   void CALLTYP d2dixx_( INT * );
   void CALLTYP d2drxx_( double *, double * );
   void CALLTYP d2dtxx_( double *, double * );
   void CALLTYP d2pdxx_( INT *, INT * );
   void CALLTYP d2enxx_( void );
   void CALLTYP d2evxx_( INT *, double *, double *, INT * );
   void CALLTYP d2gcxx_( INT *, INT *, INT *, INT *, INT * );
   void CALLTYP d2ggxx_( INT * );
   void CALLTYP d2raxx_( INT * );
   void CALLTYP d2gmxx_( void );
   void CALLTYP d2ifxx_( INT *, INT * );
   void CALLTYP d2iqxx_( INT *, INT * );
   void CALLTYP d2iwxx_( INT *, INT *, INT *, INT * );
   void CALLTYP d2kcxx_( void );
   void CALLTYP d2kixx_( INT * );
   void CALLTYP d2koxx_( void );
   void CALLTYP d2ltxx_( INT * );
   void CALLTYP d2luxx_( void );
   void CALLTYP d2lwxx_( INT * );
   void CALLTYP d2mvxx_( double *, double * );
   void CALLTYP d2nmxx_( INT * );
   void CALLTYP d2opxx_( void );
   void CALLTYP d2paxx_( void );
   void CALLTYP d2poxx_( void );
   void CALLTYP d2puxx_( double *, double *, double *, double * );
   void CALLTYP d2rcxx_( double *, double *, double *, double *, INT * );
   void CALLTYP d2rexx_( void );
   void CALLTYP d2rsxx_( void );
   void CALLTYP d2sdxx_( void );
   void CALLTYP d2sgxx_( INT *, INT * );
   void CALLTYP d2spxx_( void );
   void CALLTYP d2stxx_( void );
   void CALLTYP d2swxx_( INT * );
   void CALLTYP d2tcxx_( void );
   void CALLTYP d2tixx_( INT *, INT * );
   void CALLTYP d2tmxx_( void );
   void CALLTYP d2tnxx_( INT *, INT * );
   void CALLTYP d2toxx_( void );
   void CALLTYP d2trxx_( double * );
   void CALLTYP d2tsxx_( INT * );
   void CALLTYP d2ttxx_( INT * );
   void CALLTYP d2wnxx_( double *, double *, double *, double * );
   void CALLTYP d3arxx_( double *, INT *, double *, INT *, double *,
                         INT *, INT * );
   void CALLTYP d3arxx_dlist_( double *, INT *, double *, INT *, double *,
                               INT *, INT * );
   void CALLTYP d3cnxx_( double *, double * );
   void CALLTYP d3dlxx_( INT * );
   void CALLTYP d3drxx_( double [] );
   void CALLTYP d3dtxx_( double [] );
   void CALLTYP d3fixx_( void );
   void CALLTYP d3imxx_( void );
   void CALLTYP d3lbxx_( double [] , char [], INT, INT *);
   void CALLTYP gl_d3lbxx_( double *, INT *, INT * );
   void CALLTYP gl_d3rlxx_( double *, INT *, INT * );
   void CALLTYP d2bxxx_( INT *, double [][2], double * );
   void CALLTYP d3ldxx_( INT *, INT *, double *, INT* );
   void CALLTYP d3lnxx_( double *, INT * );
   void CALLTYP d3loxx_( INT *, INT *, INT * );
   void CALLTYP d3mvxx_( double [] );
   void CALLTYP d3rnxx_( INT *, INT * );
   void CALLTYP d3stxx_( INT * );
   void CALLTYP d3upxx_( INT *, double *, double *, double *, double *,
                         double *, INT *, INT *, double *, double *,
                         double *, double *, double *, double * );
   void CALLTYP d3vdxx_( INT * );
   void CALLTYP d3vrxx_( INT *, double [], double * );
   void CALLTYP d3vwxx_( INT *, double *, double *, double *, double *,
                         double *, INT *, INT *, double *, double *,
                         INT *, INT *, double *, double *, double *,
                         double *, double *, INT *);
   void CALLTYP d3wexx_( INT * );
   void CALLTYP d3wsxx_( INT * );
   void CALLTYP d2cvxx_( double *, double *, INT *, INT * );
   void CALLTYP d2cvxx_them_( INT *, double *, INT * );
   void CALLTYP d2fcxx_( double *, double *, INT *, INT * );
   void CALLTYP d2icxx_( INT *, INT *, double *, double * );
   void CALLTYP d2zoxx_( INT [], INT [], INT * );
   void CALLTYP d2svxx_( void );
   void CALLTYP d2vsxx_( INT * );
   void CALLTYP d2xrxx_( INT *, INT * );
   void CALLTYP d3dbxx_( INT *, INT * );
   void CALLTYP d3trixx_( INT *, double *, double *, INT*);
   void CALLTYP d3tfanxx_( INT *, double *, double *, INT *);
   void CALLTYP d3txtrxx_( INT *);
#endif
