/* sid 50.1 copy of FxSetJobName.h last changed by upd111 on 2005/06/04 13:21:09 */
/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 2002                                         */
/* *** ansys, inc.                                                        */
/* ---------------------------------------------------------------------- */
/*
 *    author/date: Stefan Reh  2002-04-17
 *
 *    primary function:
 *
 *        header for prototype definitions in ANSI C
 *
 *    Notice - This file contains ANSYS Confidential information ***
 *
 */

#ifndef _FX_SETJOBNAME_H_
#define _FX_SETJOBNAME_H_

extern int  FxSetJobName ( char cName[]);
extern char *FxGetJobName(void);
extern char *FxGetRFXName(void);
extern void FxSetJobName_end(void);

#endif /* _FX_SETJOBNAME_H_ */
