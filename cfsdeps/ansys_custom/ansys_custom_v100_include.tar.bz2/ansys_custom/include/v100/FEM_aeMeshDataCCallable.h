/* sid 50.1 copy of FEM_aeMeshDataCCallable.h last changed by upd111 on 2004/11/04 18:30:00 */
/* ********************************** */
/* *** ansys(r) copyright(c) 2000 *** */
/* *** ansys, inc.                *** */
/* ********************************** */

/*  FEM_aeMeshDataCCallable.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/* 
 *  FEM_aeMeshDataCCallable.h
 *  Mesh table xref mesh to fea entity
 *
 */
#ifndef FEM_AEMESHDATACCALLABLE
#define FEM_AEMESHDATACCALLABLE

#ifndef ux11
#ifdef DSPACE_CMDB
#pragma warning (disable:4786)
#endif
#endif



#ifdef __cplusplus
extern "C" {
#endif

INT FEM_aeHasForceMap( INT areaid );

#ifdef __cplusplus
}
#endif

#endif
