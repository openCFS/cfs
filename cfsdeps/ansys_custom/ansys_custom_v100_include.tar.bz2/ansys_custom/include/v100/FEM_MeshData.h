/* sid 50.1 copy of FEM_MeshData.h last changed by upd111 on 2004/11/04 18:29:47 */
#ifndef FEM_MESHDATA________________H
#define FEM_MESHDATA________________H

class MSHDAT_TYP {

   private:
      ADDRESS_TYP mp_genptr; // generic pointer
      CELL_PTYP mp_cell;     // cell

   protected:
      void InitMSH_TYP( ) { mp_cell = NULL; mp_genptr = NULL; };
      void SetCell( CELL_PTYP p_cell = NULL ) { mp_cell = p_cell; };
      CELL_PTYP GetCell( ) const { return mp_cell; };

   public:
      void SetGenPtr( ADDRESS_TYP p_genptr = NULL ) { mp_genptr = p_genptr; };
      ADDRESS_TYP GenPtr( )  const { return mp_genptr; }; 
      INT Id() { return mp_cell->GetId(); };

};

void FEM_vlMdN( INT id );
void FEM_aeMdN( INT id );
void FEM_lnMdN( INT id );
void FEM_kpMdN( INT id );

#endif

