/* sid 50.4 copy of CParameter.h last changed by eedelor on 2005/04/11 12:26:51 */
/*! \file CParameter.h

  \brief This header file defines the CParameter class.

  \author Stephane MARGUERIN &copy; CADOE

  \date 31 Mai 2002

  \version $Id$
*/
#ifndef __CParameter_h__ 
#define __CParameter_h__ 1 

#include "cadoe_map.h"
#include "cadoe_string.h"
#include "CParamRange.h"

/*! \class CParameter CParameter.h
  \brief The CParameter class is the public parameter object shared by the different CADOE API.
*/
class CParameter
{
 public:

  //! parameter type
  typedef enum {
    CPT_NONE =0,        /**< default value when nothing specified */
    CPT_SHAPE,          /**< shape parameter */
    CPT_SHAPE_DIMLESS,  /**< unitless shape parameter */
    CPT_FREQUENCY,      /**< frequency  */
    CPT_THICKNESS,      /**< thinshell thickness */
    CPT_YOUNG_MODULUS,  /**< Young's modulus ( isotropic ) */
    CPT_DENSITY,        /**< density */
    CPT_STRUCT_DAMPING, /**< structural damping */
    CPT_DAMPING_FACTOR, /**< damping factor */
    CPT_LUMPED_MASS,    /**< lumped mass */
    CPT_NU,             /**< Poisson's ratio ( isotropic ) */
    CPT_EX,             /**< X Young's modulus  */
    CPT_EY,             /**< Y Young's modulus ( orthotropic ) */
    CPT_EZ,             /**< Z Young's modulus ( orthotropic ) */
    CPT_NUXY,           /**< XY poisson's ratio ( orthotropic ) */
    CPT_NUXZ,           /**< XZ poisson's ratio ( orthotropic ) */
    CPT_NUYZ,           /**< YZ poisson's ratio ( orthotropic ) */
    CPT_PCT_TRAN_SPR,   /**< translational spring stiffness percentage */
    CPT_PCT_ROT_SPR,    /**< rotational spring stiffness percentage */
    CPT_PCT_LUMPED_MASS,/**< lumped mass inertia tensor percentage */
    CPT_PCT_TCK,        /**< thickness percentage */
    CPT_ALPHA,          /**< coef of thermal expansion ( isotropic ) */
    CPT_AX,             /**< X coef of thermal expansion ( orthotropic ) */
    CPT_AY,             /**< Y coef of thermal expansion ( orthotropic ) */
    CPT_AZ,             /**< Z coef of thermal expansion ( orthotropic ) */
    CPT_KTX,            /**< X translational spring stiffness */
    CPT_KTY,            /**< Y translational spring stiffness */
    CPT_KTZ,            /**< Z translational spring stiffness */
    CPT_KRX,            /**< X rotational spring stiffness */
    CPT_KRY,            /**< Y rotational spring stiffness */
    CPT_KRZ,            /**< Z rotational spring stiffness */
    CPT_IXX,            /**< IXX inertia */
    CPT_IYY,            /**< IYY inertia */
    CPT_IZZ,            /**< IZZ inertia */
    CPT_IXY,            /**< IXY inertia */
    CPT_IXZ,            /**< IXZ inertia */
    CPT_IYZ,            /**< IYZ inertia */
    CPT_GXY,            /**< XY shear modulus ( orthotropic ) */
    CPT_GXZ,            /**< XZ shear modulus ( orthotropic ) */
    CPT_GYZ,            /**< YZ shear modulus ( orthotropic ) */
    CPT_PCT_EXYZ,       /**< Percentage of modulus for orthotropic */
    CPT_PCT_GXYZ,       /**< Percentage of shear modulus for orthotropic */
    CPT_PCT_NUXYZ,      /**< Percentage of poisson for orthotropic */
    CPT_PCT_AXYZ,       /**< Percentage of thermal expansion for orthotropic */
    CPT_PENFAC,         /**< penalty factor */
    CPT_CONT_BOOL,      /**< Elements suppressed, [0;inf] */
    CPT_DISC_BOOL,        /**< Elements suppressed (0,1) */
    CPT_CE,             /**< Coefficients */
    CPT_HI,             /**< Harmonic Index */
    CPT_TEMPERATURE,    /**< Temperature */
    CPT_A,    /**< Area of section (BEAM) */
    CPT_BEAM_IYY, /**< IYY (BEAM) */
    CPT_BEAM_IYZ, /**< IYZ (BEAM) */
    CPT_BEAM_IZZ, /**< IZZ (BEAM) */
    CPT_IW,   /**< Warping constant (BEAM) */
    CPT_J,    /**< Torsional constant (BEAM) */
    CPT_IN_LOAD_ACEL_X, /**< Acceleration along X */
    CPT_IN_LOAD_ACEL_Y, /**< Acceleration along Y */
    CPT_IN_LOAD_ACEL_Z, /**< Acceleration along Z */
    CPT_IN_LOAD_ACEL_ALL, /**< Acceleration along all axis */
    CPT_IN_LOAD_CGLO_X, /**< Center of gravity along X */
    CPT_IN_LOAD_CGLO_Y, /**< Center of gravity along Y */
    CPT_IN_LOAD_CGLO_Z, /**< Center of gravity along Z */
    CPT_IN_LOAD_CGLO_ALL, /**< Acceleration along all axis */
    CPT_IN_LOAD_CGOM_X,
    CPT_IN_LOAD_CGOM_Y,
    CPT_IN_LOAD_CGOM_Z,
    CPT_IN_LOAD_CGOM_ALL,
    CPT_IN_LOAD_DCGO_X,
    CPT_IN_LOAD_DCGO_Y,
    CPT_IN_LOAD_DCGO_Z,
    CPT_IN_LOAD_DCGO_ALL,
    CPT_IN_LOAD_DOME_X,
    CPT_IN_LOAD_DOME_Y,
    CPT_IN_LOAD_DOME_Z,
    CPT_IN_LOAD_DOME_ALL,
    CPT_IN_LOAD_OMEG_X,
    CPT_IN_LOAD_OMEG_Y,
    CPT_IN_LOAD_OMEG_Z,
    CPT_IN_LOAD_OMEG_ALL,
    CPT_ORTH_ANGLE,
    CPT_CE_COEF, // CPT_CE already exist -> looks like a bug 
    CPT_KXX,
    CPT_KYY,
    CPT_KZZ,
    CPT_C,
    CPT_ENTH,
    CPT_QRAT,
    CPT_LSST,
    CPT_PERX,
    CPT_PERY,
    CPT_PERZ,
    CPT_RSVX,
    CPT_RSVY,
    CPT_RSVZ,
    CPT_SURF_PRES_X,
    CPT_SURF_PRES_Y,
    CPT_SURF_PRES_Z,
    CPT_SURF_PRES_ALL,
    CPT_SURF_PRES_NORMAL,
    CPT_SURF_CONV_COEF,
    CPT_SURF_CONV_TEMP,
    CPT_SURF_HFLUX,
  } Type;


  //!Variable type
  typedef enum {
	CPV_CONTINUOUS,
	CPV_BOOLEAN,
	CPV_DISCRETE
  } VariationType;

  //!physical category
  typedef enum {
    CPP_DEFAULT = 0,
    CPP_PHYS,
    CPP_LOAD,
    CPP_BOOL,
    CPP_NUM,
    CPP_MAT,
    CPP_REL,
    CPP_HI,
    CPP_FREQ,
    CPP_SHAPE
  }PhysicalType;
  
  //! Modification type
  typedef enum {
    CPM_VAL = 0,
    CPM_ADD = 1,
    CPM_FACT = 2
  } ParamModifType;

  CParameter();
  ~CParameter();
  CParameter( const CParameter &param );
  CParameter& operator =( const CParameter &param );


  string getName( void ) const { return m_sName; }
  const char * getNameCstr( void ) const { return m_sName.c_str(); }
  void setName( const string &name ) { m_sName = name; }

  void setDimName( const string &name ) { m_sName1 = name; }
  string getDimName( void ) const { return m_sName1; }

  void setPartName( const string &name ) { m_sName2 = name; }
  string getPartName( void ) const { return m_sName2; }

  void setGroupName( const string &name ) { m_sName2 = name; }
  string getGroupName( void ) const { return m_sName2; }

  /*! \brief Set the initial value.
    \param ini initial value
    \param rangename name of the range you want to set
  */

  bool rangeExists( int rangename=RANGE_OUTPUT ) const;
  /*! \brief Get the initial value.
    \param rangename Not used yet.
    \return initial value
  */
  double getInitial( int rangename=RANGE_OUTPUT ) const;
  /*! \brief Get the minimum value. By default, this is the value from the validated range
    that may be different from the user input. If you want to retrieve the value 
    from the user input or from an intermediate phase of the solve, use rangename=CParamRange::RNG_INPUT or 
    other RANGE values.
    \param rangename name of the range you want to retrieve
    \return minimum value
  */
  double getMinimum( int rangename=RANGE_OUTPUT ) const;
  /*! \brief Get the maximum value. By default, this is the value from the validated range
    that may be different from the user input. If you want to retrieve the value 
    from the user input or from an intermediate phase of the solve, use rangename=CParamRange::RNG_INPUT or 
    other RANGE values.
    \param rangename name of the range you want to retrieve
    \return maximum value
  */
  double getMaximum( int rangename=RANGE_OUTPUT ) const;

  double getRangeLength( int rangename=RANGE_OUTPUT ) const;


  /*! \brief Get the parameter type.
    \return type parameter type
  */
  Type getType( void ) const { return m_type; }
  void setType( Type type );
  
  VariationType getVariationType( void ) const { return m_variationType; }
  void setVariationType( VariationType type ) { m_variationType = type; }

  bool isBooleanVariable( void ) const { return m_variationType==CPV_BOOLEAN; }
  bool isGeometryVariable( void ) const { return m_physicalType == CPP_SHAPE; }

  /*! \brief Get the parameter status: active or inactive, to process, deleted.
    \return status parameter status
  */
  CParamRange::ParStatus getStatus( int rangename=RANGE_OUTPUT ) const;
  /*! \brief Set the parameter status. A newly created parameter will always have a n ACTIVE status.
    \param sta parameter status
  */
  void setStatus(  CParamRange::ParStatus sta, int rangename );

  /*! \brief Get the Parameter Modification Type (Value,Offset or Factor.
    \return Modification Type
  */
  ParamModifType getModifType( void ) const { return m_modifType; }
  PhysicalType getPhysicalType( void ) const { return m_physicalType; };


  int getNumProp( void ) const { return m_iNumProp; }
  int getNumGroup( void ) const { return m_iNumGroup; }
  int getPropElemType( void ) const { return m_iPropElemType; }


  void setInitial(  double ini, int rangename=RANGE_INPUT );
  /*! \brief Set the minimum value.
    \param min minimum value
    \param rangename name of the range you want to set
  */
  void setMinimum(  double min, int rangename=RANGE_INPUT );
  /*! \brief Set the maximum value.
    \param max maximum value
    \param rangename name of the range you want to set
  */
  void setMaximum( double max, int rangename=RANGE_INPUT );

  void setModifType(  ParamModifType type ) { m_modifType = type; }
  void setPhysicalType(  PhysicalType type ) { m_physicalType = type; }

  /*! \brief Allow the reduction of the range of variation if the parameter cannot be processed, 
    otherwise the parameter is suppressed.
    \param allow [in] true to allowReduction (default value)
  */
  void setAllowReduction(  bool allow ) { m_bAllowReduction = allow; }
  bool allowReduction( void ) const { return m_bAllowReduction; }

  void setNumGroup(  int numGroup ) { m_iNumGroup = numGroup; }
  void setNumProp(  int numProp ) { m_iNumProp = numProp; }
  void setPropElemType(  int propElemType ) { m_iPropElemType = propElemType; }

  int getDerivationOrder( int rangename=RANGE_OUTPUT ) const;
  void setDerivationOrder( int order, int rangename=RANGE_INPUT );

  // state based on the ranges status
  bool isEmpty( int rangename ) const { return const_findRange(rangename).isEmpty(); }
  bool isToProcess( int rangename ) const {return const_findRange(rangename).isToProcess(); }
  bool isValidated( int rangename ) const {return const_findRange(rangename).isValidated(); }
  bool isDeleted( int rangename ) const { return const_findRange(rangename).isDeleted(); }

  // parameter state (global, independant from the ranges)
  void setActive( bool bState=true ) {m_bActive=bState;}
  void setInactive(void) {m_bActive=false;}
  bool isActive( void ) const { return m_bActive; }
  bool isInactive( void ) const { return !m_bActive; }

 private:

  const CParamRange & const_findRange( int rangename ) const;
  CParamRange & findRange( int rangename );

  int				m_id;
  bool				m_bActive;
  string			m_sName;
  string			m_sName1; // dimName for geometry
  string			m_sName2; // partName for geometry, groupName otherwise
  CParamRange		m_rInput;
  CParamRange		m_rGeoOutput;
  CParamRange		m_rMshOutput;
  CParamRange       m_rMhcOutput;
  CParamRange       m_rSlvInput;
  CParamRange		m_rSenOutput;
  CParamRange		m_rParOutput;
  CParamRange		m_rOutput;
  Type				m_type;
  VariationType		m_variationType;
  int				m_iNumProp;
  int				m_iNumGroup;
  int				m_iPropElemType;
  bool				m_bAllowReduction;
  ParamModifType    m_modifType;
  PhysicalType      m_physicalType; 
};

#endif
