/* sid 50.1 copy of FEM_riemann.h last changed by upd111 on 2004/11/04 18:32:14 */

/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 1999 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_riemann.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_riemann.h
 *  header file that contains riemann space macros
 *
 */
#ifndef FEM_RIEMANN_INCLUDE
#define FEM_RIEMANN_INCLUDE


/* ---------------------------- Macros ----------------------------------------*/

/*==============================================================================
 * === Macro: FEM_riAnisoDist_MAC
 * === Author: sjo
 * === Description: compute an equaivalent distance in UV space given the
 * ===              anisotropic tensor, unit vector in UV and distance in 3D.
 * === Return: DOUBLE    2D distance in UV space
 *============================================================================*/
#define FEM_riAnisoDist_MAC( u, v, a11, a12, a22, d3 ) \
/* DOUBLE u,v           vector in u-v space */ \
/* DOUBLE a11,a12,a22   anisotropic tensor  */ \
/* DOUBLE d3            3D distance         */ \
   ( (d3) * (sqrt ( 1 / ((u)*(u)*(a11) + 2.0*(u)*(v)*(a12) + (v)*(v)*(a22)) )) )

/*==============================================================================
 * === Macro: FEM_riAnisoDist3D_MAC
 * === Author: sjo
 * === Description: compute an equaivalent distance in 3D space given the
 * ===              E,F,G tensor, vector in UV
 * === Return: DOUBLE    3D distance
 *============================================================================*/
#define FEM_riAnisoDist3D_MAC( u, v, a11, a12, a22 ) \
/* DOUBLE u,v           vector in u-v space */ \
/* DOUBLE a11,a12,a22   anisotropic tensor  */ \
   ( sqrt ((u)*(u)*(a11) + 2.0*(u)*(v)*(a12) + (v)*(v)*(a22)) )

/*==============================================================================
 * === Macro: FEM_riAnisoOrthoX_MAC
 * === Author: sjo
 * === Description: compute an equaivalent vector in UV space that is orthogonal
 * ===              in 3D space, given the E,F,G tensor, and vector in UV
 * === Return: DOUBLE    X component of orthogonal vector
 *============================================================================*/
#define FEM_riAnisoOrthoX_MAC( u, v, a11, a12, a22 ) \
/* DOUBLE u,v           vector in u-v space */ \
/* DOUBLE a11,a12,a22   anisotropic tensor  */ \
   ( -((a12)*(u) + (a22)*(v)) )

/*==============================================================================
 * === Macro: FEM_riAnisoOrthoY_MAC
 * === Author: sjo
 * === Description: compute an equaivalent vector in UV space that is orthogonal
 * ===              in 3D space, given the E,F,G tensor, and vector in UV
 * === Return: DOUBLE    Y component of orthogonal vector
 *============================================================================*/
#define FEM_riAnisoOrthoY_MAC( u, v, a11, a12, a22 ) \
/* DOUBLE u,v           vector in u-v space */ \
/* DOUBLE a11,a12,a22   anisotropic tensor  */ \
   ( (a11)*(u) + (a12)*(v) )

/*==============================================================================
 * === Macro: FEM_riDeterm_MAC
 * === Author: sjo
 * === Description: compute determinant of three 2D vectors
 * === Return: DOUBLE    determinant
 *============================================================================*/
#define FEM_riDeterm_MAC(p1,q1,p2,q2,p3,q3)\
     ((q3)*((p2)-(p1)) + (q2)*((p1)-(p3)) + (q1)*((p3)-(p2)))


/*==============================================================================
 * === Macro: FEM_riDot_C
 * === Author: jrt
 * === Description: compute determinant of three 2D vectors
 * === Return: DOUBLE    determinant
 *============================================================================*/
#define FEM_riDot_C(u1,v1,u2,v2,a11,a12,a22)\
     (((u1)*(a11)+(v1)*(a12))*(u2) + ((u1)*(a12)+(v1)*(a22))*(v2))


/*==============================================================================
 * === Macro: FEM_riMetricDeterm_C
 * === Author: jrt
 * === Description: compute determinant of three 2D vectors
 * === Return: DOUBLE    determinant
 *============================================================================*/
#define FEM_riMetricDeterm_C(a11,a12,a22)\
     (((a11)*(a22))-((a12)*(a12)))


/*==============================================================================
 * === Macro: FEM_riCross_C
 * === Author: jrt
 * === Description: compute determinant of three 2D vectors
 * === Return: DOUBLE    determinant
 *============================================================================*/
#define FEM_riCross_C(u1,v1,u2,v2,a11,a12,a22)\
     ((sqrt(FEM_riMetricDeterm_C((a11),(a12),(a22))))*((u1)*(v2)-(v1)*(u2)))


#ifdef __cplusplus
extern "C" {
#endif

                            /* ============================================== */
                            /* === FEM_riAnisoDist3DSum:given endpoints and   */
                            /* === end metrics for a segment calculate it's   */
                            /* === 3D distance                                */
                            /* === Return: DOUBLE distance                    */
                            /* === ********************************************/
                            /* === NOTE: This Function is the same as         */
                            /* === FEM_adAnisDist3DSum except we evaluate     */
                            /* === the metric instead of interpolating it from*/
                            /* === the background mesh                        */
                            /* === BE SURE TO PUT THE SAME CHANGES THERE      */
                            /* === BE SURE TO PUT THE SAME CHANGES THERE      */
                            /* === BE SURE TO PUT THE SAME CHANGES THERE      */
                            /* === BE SURE TO PUT THE SAME CHANGES THERE      */
                            /* === BE SURE TO PUT THE SAME CHANGES THERE      */
                            /* ============================================== */
DOUBLE FEM_riAnisoDist3DSum ( 
   DOUBLE uA,               /* u,v,metric at point A */
   DOUBLE vA,
   DOUBLE a11A,
   DOUBLE a12A,
   DOUBLE a22A,
   DOUBLE uB,               /* u,v,metric at point B */
   DOUBLE vB,
   DOUBLE a11B,
   DOUBLE a12B,
   DOUBLE a22B,
   INT    anum,             /* area to evaluate  */
   INT    *error);


                            /* ============================================== */
                            /* === FEM_riNewPoint: given a point in uv and    */
                            /* === a unit direction vector in uv space        */
                            /* === return a 2d distance and a new uv  for the */
                            /* === new point                                  */
                            /* === Return: DOUBLE 2D distance                 */
                            /* ============================================== */
DOUBLE FEM_riNewPoint ( 
   DOUBLE uA,               /* (IN)  u,v at point A */
   DOUBLE vA,
   DOUBLE Nu,               /* (IN)  unit vector in uv space */
   DOUBLE Nv,
   DOUBLE dist3D,           /* (IN)  3D distance from point A to new point B*/
   INT    anum,             /* (IN)  area to evaluate */
   DOUBLE *uB,              /* (OUT) u,v at point B */
   DOUBLE *vB,
   INT    *error);

                            /* ============================================== */
                            /* === FEM_riComputeMetric: given a point in uv   */
                            /* === determine the metric                       */
                            /* === Return: INT status                         */
                            /* === If EXIT_FAILURE: a11=a22=1 a12=0           */
                            /* === There is no transofrmation of coords       */
                            /* ============================================== */

INT FEM_riComputeMetric (
   DOUBLE u,               /* (IN)  u,v */
   DOUBLE v,
   INT    anum,            /* (IN)  area to evaluate */
   DOUBLE *a11,            /* (OUT) metric */
   DOUBLE *a12,
   DOUBLE *a22);

                            /* ============================================== */
                            /* === FEM_riDist3D:given endpoints and           */
                            /* === end metrics for a segment calculate it's   */
                            /* === 3D distance                                */
                            /* === This function checks if it should integrate*/
                            /* === or not                                     */
                            /* === Return: DOUBLE distance                    */
DOUBLE FEM_riDist3D (
   DOUBLE uA,               /* u,v,metric at point A */
   DOUBLE vA,
   DOUBLE a11A,
   DOUBLE a12A,
   DOUBLE a22A,
   DOUBLE uB,               /* u,v,metric at point B */
   DOUBLE vB,
   DOUBLE a11B,
   DOUBLE a12B,
   DOUBLE a22B,
   INT    anum,             /* area to evaluate  */
   INT    *error);

                            /* ============================================== */
                            /* === FEM_riSetParams:  Set status of file       */
                            /* === globals.                                   */
                            /* === Return: void                               */
                            /* ============================================== */
void FEM_riSetParams (
   INT anum,
   FEM_BOOLEAN integrate,/* (IN)  TRUE if forced to integrate when
                                  calculating 3d distances.   If FALSE,
                                   integration will only be used if
                                   fg_screwed. */
   INT    num_divs,      /* (IN)  number of intervals to use in integration. */
   INT maxiter,          /* (IN)  max number of iterations in riNewPoint.    */
   DOUBLE tol );         /* (IN)  tolerance for riNewPoint.                  */

									/*===================================================
									 * === Function: FEM_riOverRideAreaParamRange
									 * === Author: jrt/zjc
									 * === Description:  Override Param Range set in ri set params
									 * === Return: void
									 *===================================================*/
void FEM_riOverRideAreaParamRange (
	DOUBLE minu,         /* (IN) new minu */
	DOUBLE minv,
	DOUBLE maxu,
	DOUBLE maxv );

void FEM_riOldParamRange (
	DOUBLE *minu, /* (IN) new minu */
	DOUBLE *minv,
	DOUBLE *maxu,
	DOUBLE *maxv );

#ifdef __cplusplus
}
#endif

#endif

