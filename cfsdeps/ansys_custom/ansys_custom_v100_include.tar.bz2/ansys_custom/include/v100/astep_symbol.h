/* sid 50.1 copy of astep_symbol.h last changed by upd111 on 2005/06/04 13:15:30 */
/* NOTE: This file is DEAD and NO LONGER USED! */
