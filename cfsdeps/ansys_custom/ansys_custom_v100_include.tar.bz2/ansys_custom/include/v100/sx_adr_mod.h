/* sid 50.1 copy of sx_adr_mod.h last changed by upd111 on 2005/06/04 13:23:03 */
/* CADOE */
/**
 *	adr_mod.h -- constantes attachees aux objets adressage de modele
 *
 *  |Version: $Id$
 *   
 * HISTORY
 *   
 *   09/25/00 10:39 <       Brian Jantzen> Rel:ms8m1    SCCA:79107  Delta:81.2
 *   
 *   02/15/00 13:10 <       Brian Jantzen> Rel:ms8      SCCA:68558  Delta:8.3
 *   
 *   09/30/99 17:38 <         James Silva> Rel:ms8      SCCA:56512  Delta:8.2
 **/
#include "sx_CADOE_solver.h"
#ifndef __ADR_MOD_X_DEJA_INCLUS__
#define __ADR_MOD_X_DEJA_INCLUS__ 1

#ifdef __cplusplus
extern "C" {
#endif

extern T_statut ADM_creer_adressage (T_modele *);
extern T_statut ADM_nb_inconnues(T_modele *, T_adr_mod *);

#ifdef __cplusplus
}
#endif

#endif	 /* __ADR_MOD_X_DEJA_INCLUS__ */
