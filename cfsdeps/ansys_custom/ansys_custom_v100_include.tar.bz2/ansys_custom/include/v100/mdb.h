/* sid 50.1 copy of mdb.h last changed by upd111 on 2005/06/04 13:21:37 */
/* mdb.h CADOE  */
/*
 * mdb.h
 *
 * $Id$
 *   
 * HISTORY
 *   
 *   09/25/00 11:19 <       Brian Jantzen> Rel:ms8m1    SCCA:79107  Delta:81.2
 *   
 *   01/13/00 11:20 <        Marc Gadbois> Rel:ms8      SCCA:65669  Delta:8.3
 *   
 *   09/30/99 17:38 <         James Silva> Rel:ms8      SCCA:56512  Delta:8.2
 */

#ifndef __mdbh__
#define __mdbh__ 1

#ifdef __cplusplus
extern "C" {
#endif

extern T_statut MDB_ecrire_entete( T_cbf*, T_Modele * );
extern T_statut MDB_lire_entete( T_cbf*, T_Modele * );

#ifdef __cplusplus
}
#endif

#endif
