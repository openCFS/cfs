/* sid 50.1 copy of FEMa_recFacets.h last changed by upd111 on 2005/06/04 13:17:13 */

/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 2000 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEMa_recFacets.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_recFacets.h
 *  header file for FEM_recFacets.c
 *
 */
#ifndef FEM_RECFACETS_INCLUDE
#define FEM_RECFACETS_INCLUDE

                      /* ==================================================== */
                      /* === FEMa_RecoverFacets: Recover the facets off of an */
                      /* === area on a meshed volume.                         */
                      /* === Return: INT EXIT_SUCCESS or EXIT_FAILURE         */
                      /* ==================================================== */
INT FEMa_RecoverFacets (
   INT vol_id,        /* (IN)  The volume to recover facets off of.           */
   INT area_id,       /* (IN)  The area on vol_id to get the facets off of.   */
   DOUBLE **a_xyz,    /* (OUT) array of node locations on the area.           */
   INT **a_node_ids,  /* (OUT) parallel array to a_xyz for node ids.          */
   INT *num_nodes,    /* (OUT) number of nodes in a_xyz.                      */
   INT **a_iel,       /* (OUT) connectivity of nodes in a_xyz,                */
   INT *num_facets  );/* (OUT) number of facets in a_iel.                     */

#endif
