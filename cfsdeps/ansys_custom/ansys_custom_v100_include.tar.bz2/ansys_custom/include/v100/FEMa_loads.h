/* sid 50.1 copy of FEMa_loads.h last changed by upd111 on 2005/06/04 13:17:01 */

/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 2000 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEMa_loads.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEMa_loads.h
 *  header file for FEMa_loads.c
 *
 */
#ifndef FEM_LOADS_INCLUDE
#define FEM_LOADS_INCLUDE


/*----------------- Globally accessible function prototypes -----------------*/


                             /* === Function: FEMa_loCheckLoadConstraint  */
                             /* === Description: check for loads and      */
                             /* === constraints at the marked nodes       */
                             /* ===              and at adjacent elements */
 INT FEMa_loCheckLoadConstraint (
    FEM_BOOLEAN detached ); /* TRUE if not associated with solid model */

#endif

