/* sid 50.1 copy of elempr.h last changed by upd111 on 2005/06/04 13:17:07 */

/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 2000 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*elempr.h                                                              tpp jas
*/
#ifndef ELEMPR_H
#define ELEMPR_H

/*
  --- element parameter include deck
      Note: any changes made to parameters in this file must also be made 
      to the FORTRAN include file elempr.inc
*/

/* --- maximum nodes size (h elements) (currently set by conta174) */
#define NNMAX 89

/* --- maximum row size (h elements) (currently set by conta174) */
#define NSMAX 480

/* --- maximum row size (p elements) */
#define NSPMAX 576

/* --- maximum number of BFE loads (currently set by shell91, 181, and solid191) */
#define NBFEMAX 1024

/* --- maximum dimension of elmdat array */
#define ELATTLEN 11

/* --- maximum number of nodal stresses (currently the largest element result possible) */
/* --- this value used to be hardcoded in pagend                                        */
#define MAXENS 50000

#endif
