/* sid 50.1 copy of MAT_MaterialRecordCollection.h last changed by upd111 on 2005/06/04 13:23:21 */
////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         Copyright (C) 2001 ANSYS Inc.  All Rights Reserved             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MAT_MaterialRecordCollection.h $
// $Revision$ 7.0
// $Date$ October 21 2003
// $Author$ rjayasee
//
// Description :
//          Material Record Used to query/write  Element/Material Data
////////////////////////////////////////////////////////////////////////////

#if !defined(MAT_MaterialRecordCollection_H)
#define MAT_MaterialRecordCollection_H

#include "ANS_Allocator.h"
#include "MAT_MemoryManager.h"

class MAT_MaterialRecord ;

class MAT_MaterialRecordCollection
{
    public:

    static MAT_MaterialRecordCollection* Instance() ;
    //Singleton

    static void Destroy() ;
    //Destructor

    inline void * operator new(size_t iMemSize )
    {
            return MAT_MALLOC(iMemSize) ;
    }

    inline void * operator new[]( size_t iSize )
    {
            return MAT_MALLOC(sizeof(MAT_MaterialRecordCollection)*iSize) ;
    }

    inline void operator delete(void * pMemPtr)
    {
            MAT_FREE(pMemPtr) ;
    }

    inline void operator delete[](void * pMemPtr )
    {
        MAT_FREE(pMemPtr) ;
    }


    bool AddMaterialRecord( INT iElementIndex,
                                    MAT_MaterialRecord* pMaterialRecord );
    //R Status of the Function
    //I iElementIndex
    //I-Integration Point Number
    //I pMaterialRecord
    //I-Integration Point Record 
    //- Function Adds Integration Point Object for an Element

    bool GetMaterialRecord( INT iElementIndex,
                                    MAT_MaterialRecord*& pMaterialRecord );
    //R Status of the Function
    //I iElementIndex
    //I-Integration Point Number
    //O pMaterialRecord
    //O-Integration Point Record extracted from Element Record
    //- Function Extracts Integration Point for an Element at an Integration Point

    bool GetNthMaterialRecord( INT iRecordIndex, MAT_MaterialRecord*& pMaterialRecord ) ;
    //R result
    //I iRecordIndex
    //I-Type of Record Being Queried
    //O pMaterialRecord
    //O-Integration Point Record extracted from Element Record
    //- Get a Nth Integration Point Record 

    bool CleanUpMaterialRecord( INT iRecordIndex ) ;
    //R result
    //I iRecordIndex
    //I-Element Number of record
    //- Delete a material record for an element

    void SetMaxNumberOfRecords( INT iMaxRecords)
    {
        if ( NULL != m_pMaterialRecordVector )
        {
            assert(0) ;
        }

        m_pMaterialRecordVector = ((MAT_MaterialRecord**)(MAT_MALLOC(sizeof(MAT_MaterialRecord*)*iMaxRecords))) ;
        m_iNumMaterialRecords = iMaxRecords ;
        for ( INT iIndex = 0; iIndex < iMaxRecords ; iIndex ++ )
        {
            m_pMaterialRecordVector[iIndex] = NULL ;
        }
    }

    INT GetNumberOfRecords()
    {
        return m_iNumMaterialRecords ;
    }
    //R INT
    //- Gets Number of Records

    void Print() ;
    //R void
    //- Prints Data Stored

    protected:

    MAT_MaterialRecord** m_pMaterialRecordVector ;
    //Integration Point Record Vector

    INT m_iNumMaterialRecords ;
    //Num Material Records

    static MAT_MaterialRecordCollection* m_pMAT_MaterialRecordCollection  ;
    // Global Pointer to Element Record

    MAT_MaterialRecordCollection() ;
    //Constructor

    ~MAT_MaterialRecordCollection() ;
    //Destructor
};

static MAT_MaterialRecordCollection* m_pElementMaterialRecordCollection  ;
// Global Pointer to Element Record


#endif

