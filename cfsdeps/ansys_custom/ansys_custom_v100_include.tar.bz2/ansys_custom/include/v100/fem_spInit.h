/* sid 50.1 copy of fem_spInit.h last changed by upd111 on 2004/11/04 18:33:12 */
/*  fem_spInit.h */
/* 
 * *** ansys(r) copyright(c) 1999
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  fem_spInit.h
 *  Prototypes and macros for surface proximity refinement
 *
 */

#ifndef FEM_SPINIT_____H
#define FEM_SPINIT_____H

                          /* ================================================ */
                          /* === FEM_spInit: Initialize stuff for smrt sizing */
                          /* === surface proximity.                           */
                          /* === Return: EXIT_SUCCESS or EXIT_FAILURE         */
                          /* ================================================ */
INT FEM_spInit (
   NODELIST_OBJ obj_nodelist,  /* (IN)  nodelist                              */
   FACELIST_OBJ obj_facelist,  /* (IN)  facelist                              */
   INT *a_refineableareas,     /* (IN)  array of areas that can be refined on */
   INT num_refineableareas,    /* (IN)  length of a_refineableareas           */
   INT *a_refineablelines,     /* (IN)  array of lines that can be refined on */
   INT num_refineablelines,    /* (IN)  length of a_refineablelines           */
   INT *a_refineablekps,       /* (IN)  array of kps that can be refined on   */
   INT num_refineablekps,      /* (IN)  length of a_refineablekps             */
   INT percent,                /* (IN)  percent complete for abort window     */
   RANGETREE_TYP *ps_rtree,    /* (OUT) the range tree                        */
   INT *abort  );              /* (OUT) !0 if user requests abort             */

                          /* ================================================ */
                          /* === FEM_spInitOneFacet: Initializes a single     */
                          /* === facet:                                       */
                          /* ===    - construct the rectangles for the facet  */
                          /* ===    - compute normals and plane equations of  */
                          /* ===      the facet                               */
                          /* ===    - compute facet and vertex sizes of       */
                          /* ===      adjacent nodes                          */
                          /* === Return: EXIT_SUCCESS or EXIT_FAILURE         */
INT FEM_spInitOneFacet (
   FACE_OBJ obj_face,          /* (IN)     the face to insert into */
   RANGEDATA_PTYP *aps_Xrdata, /* (IN/OUT) the x data array of the Range Tree */
                               /*          to insert into                     */
   RANGEDATA_PTYP *aps_Yrdata, /* (IN/OUT) the y data array of the Range Tree */
                               /*          to insert into                     */
   RANGEDATA_PTYP *aps_Zrdata, /* (IN/OUT) the z data array of the Range Tree */
                               /*          to insert into                     */
   INT index_min,              /* (IN)     index into rdata arrays for min of */
                               /*          face bounding box.                 */
   INT index_max  );           /* (IN)     index into rdata arrays for max of */
                               /*          face bounding box.                 */

                          /* ================================================ */
                          /* === FEM_spInitMinAndMaxIndices: Init all of the  */
                          /* === min and max coordinates in each rectangle in */
                          /* === the range tree to -1                         */
                          /* === Return: EXIT_SUCCESS or EXIT_FAILURE         */
INT FEM_spInitMinAndMaxIndices (
   RANGETREE_TYP *ps_rtree  ); /* (IN/OUT) the range tree.                    */

#endif

