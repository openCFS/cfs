/* sid 50.1 copy of fem_noPriv.h last changed by upd111 on 2004/11/04 18:33:08 */
/*  fem_noPriv.h */
/* 
 * *** ansys(r) copyright(c) 1999
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  *** */
/*                                                                         sjo
 *   fem_noPriv.h
 *   Private header file for nodes in FEM module
 */

#ifndef FEM_NOPRIVATE
#define FEM_NOPRIVATE

#include "FEM_cdbtypes.h"

                             /* === fem_noRemoveAdjEdge: remove pointers from */
                             /* === the node to one of its adjacent edges     */
void fem_noRemoveAdjEdge (
   NODE_PTYP ps_node,                  /* the node                            */
   EDGE_PTYP ps_edge );                /* the edge that is to be removed      */
                                       /* from the node */
/*
 * Macros
 */

/*
 * --- The function definition of the node macros can be used instead of
 * --- the macros themselves by including -D NO_NODE_MACRO on the
 * --- compile line.  The equivalent functions are found in fem_noPrivateMacro.c
 * --- Note: When adding a Macro - make sure the prototype and the macro
 * ---       appear in this file.
 */

/*============================================================================*/
/* === Macro:  fem_noSetTotal_C
 * === Author: sjo
 * === Description: set total number of nodes in list
 * === Arguments:
 *     NODELIST_OBJ obj_nlist      node list object
 *     INT totnode                 new total number of nodes
 * === Return: nothing
 */
#ifdef NO_NODE_MAC
void fem_noSetTotal_C ( NODELIST_OBJ obj_nlist, INT totnode  );
#else
#define fem_noSetTotal_C( obj_nlist, totnode )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((NODELIST_PTYP)(obj_nlist))->total = totnode;\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }
#endif

/*============================================================================*/
/* === Macro: fem_noSetList_C
 * === Author: sjo
 * === Description: set head of node list
 * === Arguments:
       NODELIST_OBJ  obj_nlist       node list object
       NODE_OBJ obj_node             new first node in list
 * === Return:
 */
#ifdef NO_NODE_MAC
void fem_noSetList_C ( NODELIST_OBJ  obj_nlist, NODE_OBJ obj_node  );
#else
#define fem_noSetList_C( obj_nlist, obj_node )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((NODELIST_PTYP)(obj_nlist))->ps_list = (NODE_PTYP)obj_node;\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }
#endif

/*============================================================================*/
/* === Macro: fem_noSetCurrent_C
 * === Author: sjo
 * === Description: set current node in node object list
 * === Arguments:
 *     NODELIST_OBJ obj_nlist          node list object
 *     NODE_OBJ obj_node               new current node
 * === Return:
 */
#ifdef NO_NODE_MAC
void fem_noSetCurrent_C ( NODELIST_OBJ obj_nlist, NODE_OBJ obj_node  );
#else
#define fem_noSetCurrent_C( obj_nlist, obj_node )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((NODELIST_PTYP)(obj_nlist))->ps_current = (NODE_PTYP)obj_node;\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }
#endif

/*============================================================================*/
/* === Macro: fem_noAddNodeToList_C
 * === Author: sjo
 * === Description: add node to linked list at front of list
 * === Arguments:
 *     NODELIST_OBJ obj_nlist     node list object
 *     NODE_OBJ obj_node          new node to be added
 * === Return: nothing
 */
#ifdef NO_NODE_MAC
void fem_noAddNodeToList_C ( NODELIST_OBJ obj_nlist, 
                                      NODE_OBJ obj_node  );
#else
#define fem_noAddNodeToList_C( obj_nlist, obj_node )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((NODE_PTYP)(obj_node))->ps_next =\
                   ((NODELIST_PTYP)(obj_nlist))->ps_list;\
         ((NODELIST_PTYP)(obj_nlist))->ps_list =\
                   (NODE_PTYP)(obj_node);\
         if (((NODE_PTYP)(obj_node))->ps_next != NULL) {\
            ((NODE_PTYP)(obj_node))->ps_next->ps_previous =\
                      (NODE_PTYP)(obj_node);\
         }\
         ((NODE_PTYP)(obj_node))->ps_previous = NULL;\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }
#endif

/*============================================================================*/
/* === Macro: fem_noDeleteNodeFromList_C
 * === Author: sjo
 * === Description: delete node from linked list
 * === Arguments:
 *     NODELIST_OBJ obj_nlist   node list object
 *     NODE_OBJ obj_node     node to be deleted
 * === Return: nothing
 */
#ifdef NO_NODE_MAC
void fem_noDeleteNodeFromList_C ( NODELIST_OBJ obj_nlist,
                                           NODE_OBJ obj_node );
#else
#define fem_noDeleteNodeFromList_C( obj_nlist, obj_node )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         if (((NODE_PTYP)(obj_node))->ps_next != NULL) {\
            ((NODE_PTYP)(obj_node))->ps_next->ps_previous =\
                    ((NODE_PTYP)(obj_node))->ps_previous;\
         }\
         if (((NODE_PTYP)(obj_node))->ps_previous != NULL) {\
            ((NODE_PTYP)(obj_node))->ps_previous->ps_next =\
                    ((NODE_PTYP)(obj_node))->ps_next;\
         }\
         else{\
            ((NODELIST_PTYP)(obj_nlist))->ps_list =\
               ((NODE_PTYP)(obj_node))->ps_next;\
         }\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }
#endif

/*============================================================================*/
/* === Macro: fem_noInsertAdjEdge_MAC
 * === Author: sjo
 * === Description: insert into the node, a pointer to one of its
 *                  adjacent edges (use only for STANDARD_MESH data rep)
 * === Arguments:
 *     NODE_PTYP ps_node          node to be updated
 *     EDGE_PTYP ps_edge          edge to be added
 *     INT inode                  The location of node in edge (0 or 1)
 * === Return: nothing
 * === Note: if you move the node to a different slot in the edge's node
 *           array you also need to move the pointer to the new slot.
 */
#ifdef NO_NODE_MAC
void fem_noInsertAdjEdge_MAC ( NODE_PTYP ps_node, 
                                        EDGE_PTYP ps_edge, INT inode  );
#else
#define fem_noInsertAdjEdge_MAC( ps_node, ps_edge, inode )\
   ps_edge->as_node_edge[inode].ps_edge = ps_edge;\
   ps_edge->as_node_edge[inode].ps_next = ps_node->ps_adjedge;\
   ps_node->ps_adjedge = \
      (NEXTEDGE_TYP *)(ps_edge->as_node_edge + inode);
#endif

/*============================================================================*/
/* === Macro: fem_noInit_C
 * === Author: sjo
 * === Description: initialize edge structure
 * === Arguments:
 *     NODE_OBJ obj_face          face to be initialized
 * === Return: nothing
 */
#ifdef NO_NODE_MAC
void fem_noInit_C ( NODE_OBJ obj_node  );
#else
#define fem_noInit_C( obj_node )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((NODE_PTYP)(obj_node))->id = 0;\
         ((NODE_PTYP)(obj_node))->x = 0.0;\
         ((NODE_PTYP)(obj_node))->y = 0.0;\
         ((NODE_PTYP)(obj_node))->z = 0.0;\
         ((NODE_PTYP)(obj_node))->u = 0.0;\
         ((NODE_PTYP)(obj_node))->v = 0.0;\
         ((NODE_PTYP)(obj_node))->s = 0.0;\
         ((NODE_PTYP)(obj_node))->ps_adjedge = (NEXTEDGE_PTYP)NULL;\
         ((NODE_PTYP)(obj_node))->property = NO_PROPERTY;\
         ((NODE_PTYP)(obj_node))->geo_entity = 0;\
         ((NODE_PTYP)(obj_node))->p_info = NULL;\
         ((NODE_PTYP)(obj_node))->p_topolist = NULL;\
         ((NODE_PTYP)(obj_node))->ps_next = (NODE_PTYP)NULL;\
         ((NODE_PTYP)(obj_node))->ps_previous = (NODE_PTYP)NULL;\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }
#endif

#endif
