/* sid 50.1 copy of elmLoadtypes.h last changed by upd111 on 2005/06/04 13:21:55 */

#include "ansysdef.h"

/****************************************************************
 data-level structure for ANSYS element loads
 ****************************************************************/
struct elmLoad_str {                  /* Name of the structure                                      */
  char bodyTypes[MAXBODYLOADTYPE+1];  /* Array to flag element body load types for this element     */
                                      /* i.e., if bodyTypes[BODYLOAD_TEMP] = FALSE then no temps    */
                                      /*       if bodyTypes[BODYLOAD_TEMP] = TRUE  then temps exist */
                                      /* NOTE: we allocate 1 extra since we start at 1 and not 0    */
  elmBodyLoadData *bodyLoad;          /* Pointer to the first body load on this element. If this    */
                                      /* pointer is NULL then this element has no body loads        */
  char surfTypes[MAXSURFLOADTYPE+1];  /* Array to flag element surface load types for this element  */
                                      /* i.e., if surfTypes[SURFLOAD_PRES] = FALSE then no          */
                                      /*       pressures exist for this element                     */
                                      /*       if surfTypes[SURFLOAD_PRES] = TRUE  then pressures   */
                                      /*       do exist for this element                            */
                                      /* NOTE: we allocate 1 extra since we start at 1 and not 0    */
  elmSurfLoadData *surfLoad;          /* Pointer to the first surface load on this element          */
                                      /* If this pointer is NULL then that means this element       */
                                      /* has no surface loads on any of its faces                   */
};

#define elmLoadBodyTypesPtr(eload)         (eload->bodyTypes)
#define elmLoadBodyTypesVec(eload,i)       (eload->bodyTypes[i])
#define elmLoadSurfTypesPtr(eload)         (eload->surfTypes)
#define elmLoadSurfTypesVec(eload,i)       (eload->surfTypes[i])

#define elmLoadBodyLoadPtr(eload)          (eload->bodyLoad)
#define elmLoadSurfLoadPtr(eload)          (eload->surfLoad)

