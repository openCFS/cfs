/* sid 50.1 copy of STR_util.h last changed by upd111 on 2005/06/04 13:22:27 */
/* STR_util.h CADOE  */
/*
 * $Id$
 */

#ifndef __strutilh__
#define __strutilh__ 1

#ifdef WINNT
#define STRDUP _strdup
#define STRCMP _stricmp
#else
#define STRDUP strdup
#define STRCMP strcasecmp
#endif

#ifdef __cplusplus
extern "C" {
#endif

extern char *   get_racine ( char * );
extern char *   get_chaine_extremite ( char * );
extern char	*STR_vprintf ( const char *message, ... );
extern void	STR_rename ( char **nom, const char *message, ... );

#ifdef __cplusplus
}
#endif

#endif
