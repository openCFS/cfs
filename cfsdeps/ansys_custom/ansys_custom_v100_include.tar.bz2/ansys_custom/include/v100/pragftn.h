/* sid 50.1 copy of pragftn.h last changed by upd111 on 2005/06/04 13:13:19 */
/* pragftn.h                                                            FJB
/* 
 * *** ansys(r) copyright(c) 2000
 * *** ansys, inc.
 */

 ***********************************************************************
 *** Notice - This file contains ANSYS Confidential information ***
 *
 * Author:      F. J. Bogden
 *
 * Function:    pragma declarations for FORTRAN SUBROUTINES for WATCOM
 *		compiler on PC
 *
 * Description: This file contains pragma statements exclusively for
 *		WATCOM PC compiler/linker to declare C to FORTRAN
 *		interface. You 	must include one pragma for EVERY FORTRAN 
 *		interface and this file is only an illustration.
 *              NOTE : pragmas -MUST- be declared via an include file
 *              which is conditionally because some compilers will
 *              -not- recognize other than their own pragmas.
 *
 *** Notice - This file contains ANSYS Confidential information ***
 ***********************************************************************
 */

#ifndef PRAGFTN_H
#define PRAGFTN_H
#  pragma aux NAME_OF_FORTRAN_ROUTINE "^";
#endif
