/* sid 50.1 copy of msh_erreur.h last changed by upd111 on 2005/06/04 13:21:38 */
/* msh_erreur.h CADOE */
/*
 *  msh_erreur.h -- macro de traitement d'erreur
 *
 * |Version: $Id$
 *
 *   
 * HISTORY
 *   
 *   11/03/00 15:37 <         James Silva> Rel:ms9      SCCA:81744  Delta:9.2
 */
#ifndef __msherreurh__
#define __msherreurh__ 1

#define MSH_erreur(msg,fct,lig,fic) Erreur(fct,lig,fic,msg)

#define MSH_warning(msg,fct,lig,fic) Warning(fct,lig,fic,msg)

#define MSH_traceback(fct,lig,fic) fct_Trace(fct,lig,fic)


#ifdef OPENIDEAS
#define MSH_traceback_sortie(fct) {fct_Trace(fct,__LINE__,__FILE__); delete G_ideas; exit(1);}
#define MSH_erreur_sortie(msg,fct,lig,fic) {Erreur(fct,lig,fic,msg); delete G_ideas; exit(1);}
#else
#define MSH_traceback_sortie(fct) {fct_Trace(fct,__LINE__,__FILE__); exit(1);}
#define MSH_erreur_sortie(msg,fct,lig,fic) {Erreur(fct,lig,fic,msg); exit(1);}
#endif


#endif
