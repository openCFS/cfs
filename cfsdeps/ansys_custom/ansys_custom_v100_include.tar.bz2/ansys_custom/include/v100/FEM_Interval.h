/* sid 50.1 copy of FEM_Interval.h last changed by upd111 on 2004/11/04 18:29:41 */
#ifndef FEM_INTERVAL____________________________H
#define FEM_INTERVAL____________________________H

typedef enum { MAPPED_CONSTRAINT = 1,
               HARDDIV_CONSTRAINT = 2,
               SWEEP_NDIV_CONSTRAINT = 3,
               SUMEVEN_CONSTRAINT = 4 } CONSTR_TYPE_ENUM;

typedef enum { BAD_HARDDIVS_REASON = 1,
               UNKNOWN_REASON = 2 } INTERVAL_FAIL_REASON_ENUM;

typedef enum { NO_CAUSE = 1,
               PRIMARY_CAUSE = 2,
               SECONDARY_CAUSE = 3 } BAD_CONSTR_ENUM;

typedef struct {
   INT rhs;          /* rhs of constraint equation. */
   INT *a_coeffs;    /* coefficients in constraint for lines */
   INT num_coeffs;   /* The number of non-zero coefficients in a_coeffs */
   CONSTR_TYPE_ENUM type;
   CHAR name[10];
   BAD_CONSTR_ENUM caused_failure;
} CONSTR_TYP;

typedef struct {
   INT id;
   INT goal;          /* goal */
   INT weight;        /* How important the goal is. 1 means normal importance,
                         100 means maximum importance. */
   FEM_BOOLEAN fixed; /* TRUE if this line is lesized or pre-meshed. */
   CHAR name[10];
} VARIABLE_TYP;

typedef struct {
   INTERVAL_FAIL_REASON_ENUM reason;
   INT ln1;
   INT ln2;
   INT ndiv1;
   INT ndiv2;
} INTERVAL_FAIL_TYP;
 
#define EXIT_CANT_SOLVE 9876

#ifdef __cplusplus
extern "C" {
#endif

                       /* =================================================== */
                       /* === FEM_ivDetermineIntervals: Determine the number  */
                       /* === of divisions on a group of lines given goals &  */
                       /* === constraints.                                    */
                       /* === Return: EXIT_SUCCESS or EXIT_FAILURE            */
                       /* =================================================== */
INT FEM_ivDetermineIntervals(
   INT num_lines,             /* (IN)  number of lines to determine intervals.*/
   VARIABLE_TYP *a_vars,      /* (IN)  Design variables.                      */
                              /*       length = num_lines.                    */
   FEM_BOOLEAN fixed,         /* (IN)  TRUE if some of the variables in a_vars*/
                              /*       are fixed by lesizes or pre-meshing.   */
                              /*       Even if fixed == FALSE, the fixed flag */
                              /*       on one of the lines in a_vars may be   */
                              /*       TRUE, but should be ignored.           */
   INT num_constraints,       /* (IN   number of constraints in a_constraints */
   CONSTR_TYP *a_constraints, /* (IN)  constraints on lines in a_goals.       */
   INT num_sume_constraints,  /* (IN   number of sum-even constraints in      */
                              /*       a_sume_constraints                     */
   CONSTR_TYP *a_sume_constraints,/*(IN) sum-even constraints on lines in     */
                              /*       a_vars.                                */
   FEM_BOOLEAN *possible,     /* (OUT) FALSE if a solution can not be found.  */
                              /*       TRUE if a solution can be found.       */
   INTERVAL_FAIL_TYP *reason, /* (OUT) If !(*possible), the reason why is     */
                              /*       returned here.                         */
   INT *a_solutions,          /* (IN)  ndivs on each line in a_goals.         */
                              /*       length = num_lines.                    */
   INT stat_process,
   INT debug );
#ifdef __cplusplus
}
#endif

#endif

