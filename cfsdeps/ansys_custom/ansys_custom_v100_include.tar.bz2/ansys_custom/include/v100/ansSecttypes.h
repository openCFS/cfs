/* sid 50.2 copy of ansSecttypes.h last changed by jrb on 2005/04/06 19:00:25 */

#include "ansysdef.h"


extern  INT  cCreateAnsSect(INT,INT,INT*);
extern  INT  cDeleteAnsSect(void);
extern  INT  cInquireAnsSect(INT,INT);
extern  INT  cPutAnsSect(INT,INT,DOUBLE*);
extern  INT  cGetAnsSect(INT,INT*,DOUBLE*);
extern  INT  cGetAnsSectPtr(INT,INT*,DOUBLE**);
extern  INT  cGetAnsSectPartial(INT,INT,INT*,DOUBLE*);
extern  INT  cDumpAnsSect(INT);


/****************************************************************
 global-level structure for ANSYS section data
 ****************************************************************/
struct ansSect_str {               /* Name of the structure                                   */
  INT        tag;                  /* Tag for this instance of the section data structure     */
  INT        numDef;               /* Number of defined sections in this structure            */
  INT        maxDef;               /* Maximum number of defined sections in this structure    */
  INT        maxSize;              /* Maximum amount of data stored for any one section       */
  INT       *Internal_to_External; /* Mapping vector for global internal to global external   */
  INT       *External_to_Internal; /* Mapping vector for global external to global internal   */
  sectData  *dataVec;              /* Array of data for section                               */
};

#define ansSectTag(sect)                 (sect->tag)
#define ansSectNumDef(sect)              (sect->numDef)
#define ansSectMaxDef(sect)              (sect->maxDef)
#define ansSectMaxSize(sect)             (sect->maxSize)

#define ansSectInt2ExtPtr(sect)          (sect->Internal_to_External)
#define ansSectInt2ExtVec(sect,i)        (sect->Internal_to_External[i])
#define ansSectExt2IntPtr(sect)          (sect->External_to_Internal)
#define ansSectExt2IntVec(sect,i)        (sect->External_to_Internal[i])

#define ansSectDataPtr(sect)             (sect->dataVec)
#define ansSectDataVec(sect,i)           (sect->dataVec+i)


/******************************************************************
 data-level structure for ANSYS section data
 ******************************************************************/
struct sectData_str {  /* Name of the structure                                      */
  char     modified;   /* Flag indicating whether this section has been modified     */
  char     internal;   /* Flag indicating whether this section is internal to object */
  INT      numValues;  /* Number of values stored for this section                   */
  DOUBLE  *values;     /* Array of double precision data for this section            */
};

#define sectDataModified(sData)       (sData->modified)
#define sectDataInternal(sData)       (sData->internal)
#define sectDataNumValues(sData)      (sData->numValues)

#define sectDataValuesPtr(sData)      (sData->values)
#define sectDataValuesVec(sData,i)    (sData->values[i])

