/* sid 50.1 copy of domain_graph.h last changed by upd111 on 2005/06/04 13:18:07 */
/*CFILE domain_graph.h        mechanics      [ANSI_C]                   azs
 * ------------------------------------------------------------------------
 * ------- Notice - This file contains ANSYS Confidential information 
 * ------------------------------------------------------------------------
 */

/*------------------------------- Description ---------------------------- */
/*
 * Author:        azs 
 * Title:         domain_graph.h
 * Desc:          Header file for routines for getting the minimum 
 *                number of domaines for elements graph with multi 
 *                connectivities.
 * History:       99/01/29 - azs: initial creation
 *
 * ----------------------------------------------------------------------- */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <limits.h>
#include "computer.h"
#include "FEM_cdbtypes.h"
#include "MECH_CtoF.h"

/* -------------------------- Definition of types ------------------------ */

#define CUR_element_NODES   9
#define MAX_element_NODES   4
#define MAX_element_NEGBRS  120  
#define MAX_line_width      200

/* Basic Types. */
typedef unsigned int    graph_object_count ;
typedef unsigned int    graph_object_index ;
typedef int             graph_object_id ;
typedef char            graph_object_name ;
typedef char            graph_object_title ;
typedef char            ascii_file_line ;
typedef double          Ansys_model_measure;
typedef int             Ansys_model_id ;
typedef int             Ansys_model_element_nodes_list[2][MAX_element_NODES];
typedef unsigned  int   Ansys_model_element_negbrs_list[MAX_element_NEGBRS];
typedef double          Ansys_model_limit;
typedef unsigned int    Ansys_model_count;
typedef unsigned int    Ansys_model_index;

/* ------------------------------ Strucutres ----------------------------- */
typedef struct  element
{
  graph_object_count    graph_element_id;
  graph_object_count    graph_domain_id;
  graph_object_index    graph_element_nodes ;
  graph_object_index    graph_element_negbrs ;
  graph_object_index    graph_element_negbrs_updated ;
  Ansys_model_element_nodes_list 
  graph_element_nodes_list ;
  Ansys_model_element_negbrs_list 
  graph_element_adjecency_list ;
  
  struct element       *next_graph_element ;
  struct element       *prev_graph_element ;
} graph_element ;

/* ------------------------ Simple C. to F. Types ------------------------ */
typedef char           *Ansys_model_file_name;
typedef char           *Ansys_model_symbol;
typedef int            *Ansys_model_element_conn_list;
typedef int            *Ansys_model_CtoF_index ;
typedef graph_element  *Ansys_graph_element ;
typedef FILE           *Ansys_model_file;
typedef FILE           *LsDyna_ascii_file;


/* --------------------------- Enumerated types -------------------------- */
typedef enum method_exit{SUCCESS, FAIL, ABORT_NO_OPERATION,
                         CONTINUE_NO_OPERATION} graph_method_result ;


/* ------------------------- Definition of methods ----------------------- */
/* ----------------------------------------------------------------------- */

/* ----------------------- graph_element_tree_list ----------------------- */
/*  
 *  primary function: Initiate the tree list of the graph elements, by creating
 *                      the root node of the tree.
 *  secondary function: Create a new node for the tree.
 *
 * ----------------------- graph_element_tree_list ----------------------- */
Ansys_graph_element graph_tree_element_list(      
                               graph_object_count  graph_element_id ,
			       graph_object_count  graph_domain_id ,
			       graph_object_index  graph_element_nodes ,
			       Ansys_model_element_nodes_list  
                                              graph_element_nodes_list ) ;


/* --------------------------- add_tree_element -------------------------- */
/*   
 * primary function: Updates tree lists for new elements, by constructing
 *                   the connectivity between the new element and the tail
 *                   element.
 * secondary function: none.
 *
 * --------------------------- add_tree_element -------------------------- */
graph_method_result add_tree_element( 
                             Ansys_graph_element graph_first_element_ptr,
                             Ansys_graph_element new_graph_element ) ;


/* --------------------------- delete_tree_list -------------------------- */
/*
 * primary function: Deletes the entire tree list to deallocate all memory
 *                   allocated in these routines.
 * secondary function: none.
 *
 * --------------------------- delete_tree_list -------------------------- */
graph_method_result delete_tree_list(
                             Ansys_graph_element graph_element_ptr );


/* ---------------------- start_domain_decomposition --------------------- */
/*   
 * primary function: Initializes the decomposition of the tree, starting
 *                      with the root element.
 * secondary function: none.
 *  
 * ---------------------- start_domain_decomposition --------------------- */
graph_method_result start_domain_decomposition( 
                             Ansys_graph_element graph_element_ptr ) ;


/* ----------------------- tree_element_adjacency ------------------------ */
/*  
 * primary function: Creates the adjacenecy list for the graph tree.
 * secondary function: none.
 *
 * ---------------------- tree_element_adjacency ------------------------- */
graph_method_result tree_element_adjacency(
                             Ansys_graph_element  graph_element_ptr,
                             Ansys_model_index    total_element_number) ;


/* ---------------------- update_tree_element_negbrs --------------------- */
/*  
 * primary function: Updates the domain of the  negbrs elements of a tree 
 *                   node to the same domain ID of that node.
 * secondary function: none.
 *
 * ---------------------- update_tree_element_negbrs --------------------- */
graph_method_result update_tree_element_negbrs( 
                             Ansys_graph_element  graph_element_ptr ,
                             graph_object_count   graph_element_negbr , 
                             graph_object_count   graph_domain_id ) ;


/* ----------------------- decompose_tree_elements ----------------------- */
/*   
 * primary function: Decomposes the tree into domaines by spaning the tree.  
 * secondary function: none.
 *
 * ----------------------- decompose_tree_elements ----------------------- */
graph_method_result decompose_tree_elements(
                             Ansys_graph_element  graph_element_ptr ) ;


/* ------------------------ PRINT_GRAPH_TREE_INFO ------------------------ */
/*   
 * primary function: prints inforamtion about a element of a given ID for
 *                   debugging only. 
 * secondary function: none.
 *
 * ------------------------ PRINT_GRAPH_TREE_INFO ------------------------ */
graph_method_result print_graph_tree_info( 
                             Ansys_graph_element  first_ele , 
                             graph_object_count   i ) ;


/* ------------------------- tree_last_domain_get ------------------------ */
/* 
 * primary function: Span the tree for the largest domain ID.
 * secondary function: Creates the domain lowest node ID list.
 *
 * ------------------------ tree_last_domain_get ------------------------- */
graph_method_result  tree_last_domain_get( 
                                Ansys_graph_element first_ele , 
                                Ansys_model_CtoF_index  total_domains ,
                                Ansys_model_element_conn_list 
				                domain_first_node_list) ;


/* ------------------ graph_method_result_interpretation ----------------- */
/* 
 * primary function: Decode the graph_method_result signal.
 * secondary function: none.
 *
 *
 * ------------------- graph_method_result_interpretation ---------------- */
void graph_method_result_interpretation( 
                             graph_method_result    method_result) ;


/* ------------------------------ domain_graph --------------------------- */
/* Decompose Ansys graph into the minimum number of connect domaines
 * primary function: Creates the adjacenecy list for the graph tree.
 * secondary function: none.
 *
 * ----------------------------- domain_graph ---------------------------- */
INT CALLTYP domain_graph_( 
                   Ansys_model_CtoF_index    total_element_number,
                   Ansys_model_CtoF_index    total_domains_number,
                   Ansys_model_element_conn_list 
                                             elements_connectivity_list ,
                   Ansys_model_element_conn_list 
                                              domain_first_node_list ) ;

/* ------------------------------ err_warn_scan --------------------------- */
/* Scan LsDyna messag File for possible Errors and warnings.
 * primary function: Creates dyna.err file that reports all erros and warnings
 *                   in LsDyan run.
 * secondary function: none.
 *
 * ----------------------------- err_warn_scan ---------------------------- */
INT CALLTYP err_warn_scan_( 
                   Ansys_model_CtoF_index    total_errors_number,
                   Ansys_model_CtoF_index    total_warnings_number) ;

/* -------------------- End of definition of methods --------------------- */
