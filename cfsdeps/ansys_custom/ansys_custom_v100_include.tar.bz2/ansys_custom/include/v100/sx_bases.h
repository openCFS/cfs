/* sid 50.1 copy of sx_bases.h last changed by upd111 on 2005/06/04 13:22:50 */
/*******************************************************************************
 *
 *   sx_bases.h  --- 
 *               
 * 
 * |Module:  
 *
 * |Description: 
 *
 * |Includes:	
 *        
 * |Auteur: Jerome Margat
 *
 * |Creation: December 2003
 *
 * |Version: $Id$
 *
 * |Copyright:	Copyright(c)  2003
 *
 ********************************************************************************/

#ifndef __SX_BASES_H
#define __SX_BASES_H

#include "cadoe_version.h"

#define CBF_BASES_ID		30000
#define CBF_BASES_VERSION	1

#include "lmb.h"

typedef struct __SupportParam {
  BVEC *ActiveDofs;      /*List of dofs for this parameter, binary coding, dimensionned to number of dofs*/
  BVEC *LoadedDofs;      /*List of loaded dofs concerned by this parameter, binary coding, dimensionned to number of dofs*/
} T_SupportParam;


typedef 
struct __basis {
  char     JobName[512];
  VEC     *RHS0;
  VEC     *U0;
  VSTRUCT *Q;
  VSTRUCT *K0Q;
  VSTRUCT *SIGMA;
  VSTRUCT *MASS;
  VSTRUCT *DEFOR;
  int      DIMQsensi;
  int      DIMSIGMAsensi;
  int      DIMMASSsensi;
  int      DIMDEFORsensi;
  int      nbparam;
  T_SupportParam *SupportParam;
} T_basis;

#ifdef __cplusplus
extern "C" {
#endif

extern T_basis* sx_readBasis(const char *name, int *ier);
extern void     sx_writeBasis(const char *name,T_basis *basis, int *ier);

#ifdef __cplusplus
}
#endif

#endif /* __BASES_H */
