/* sid 50.1 copy of noeud.h last changed by smarguer on 2005/01/25 15:46:54 */
/*
 * noeud.h
 *
 * $Id$
 *   
 * HISTORY
 *   
 *   09/25/00 11:19 <       Brian Jantzen> Rel:ms8m1    SCCA:79107  Delta:81.4
 *   
 *   06/28/00 10:47 <       Brian Jantzen> Rel:ms8m1    SCCA:74542  Delta:81.3
 *   
 *   06/21/00 16:30 <       Brian Jantzen> Rel:ms8m1    SCCA:74307  Delta:81.2
 *   
 *   01/13/00 11:20 <        Marc Gadbois> Rel:ms8      SCCA:65669  Delta:8.3
 *   
 *   09/30/99 17:38 <         James Silva> Rel:ms8      SCCA:56512  Delta:8.2
 */

#ifndef __noeudh__
#define __noeudh__ 1

#ifndef __expmdbstructh__
#include "expmdb_struct.h"
#endif

#ifdef __cplusplus
extern "C" {
#endif

extern T_statut NOE_proj_init( T_liste* );
extern T_statut NOE_depla_bords( T_Modele*, T_Part*, T_Part* );
extern void NOE_proj_free(void);
extern double NOE_calculer_distance_2D( T_Noeud*, T_Mesh*, T_statut*, T_statut *);
extern double NOE_calculer_distance_3D( T_Noeud*, T_Mesh*, T_statut* );
extern T_statut NOE_repos_bary( T_Noeud*, T_Mesh*, T_liste **, int);
extern T_liste *NOE_voisins( T_Noeud*, T_statut* );
extern T_Noeud **	NOE_creer_liste( int, T_Noeud **, int * );
extern T_statut NOE_get_perturb_from_edge(T_Noeud *,T_statut );
extern T_booleen noeud_sur_geo_changee(T_Noeud *noeud);


#ifdef __cplusplus
}
#endif

#endif
