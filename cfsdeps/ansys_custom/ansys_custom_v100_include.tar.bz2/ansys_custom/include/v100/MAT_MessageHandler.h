/* sid 50.1 copy of MAT_MessageHandler.h last changed by upd111 on 2005/06/04 13:20:49 */
/*
////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         Copyright (C) 2001 ANSYS Inc.  All Rights Reserved             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MAT_MessageHandler.h $
// $Revision$ 7.0
// $Date$ May 01 2002
// $Author$ rjayasee
//
// Decription :
//
// This files defines the function necessary for Material Curve Fitting
// message handler
////////////////////////////////////////////////////////////////////////////
*/

#if !defined(MAT_MESSAGEHANDLER)
#define MAT_MESSAGEHANDLER

enum MAT_MessageType
{
    MAT_DEV_ERROR = 0,/* DEVELOPER ERROR */
    MAT_DEV_DEBUG,
    MAT_USR_ERROR,
    MAT_USR_WARNING,
    MAT_USR_NOTE, /* DIFFERENT LEVELS OF ERROR MESSAGES */
    MAT_USR_OUTPUT
    /* REGULAR PRINT TO DEFAULT STREAM */
} ;

#ifdef __cplusplus
extern "C"
{
#endif

    void MAT_SendMessage( enum MAT_MessageType oMsgType,
                          char* pFormat,
                          ... ) ;
    /*
    //R void
    //I oMsgType
    //I-Type of Message, whether error,warning...
    //I-Look at the defn of MAT_MessageType for the different types
    //- This function is the message handler for the Material API
    */
                          
#ifdef __cplusplus
}
#endif

#endif     

