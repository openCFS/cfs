/* sid 50.1 copy of FEM_vtbl_mtk.h last changed by upd111 on 2005/06/04 13:19:24 */

#ifdef UG_SCENARIO

#ifndef VTBL_H_INCLUDED
#define VTBL_H_INCLUDED

typedef enum
{
	InitAreas,
	InitMoreAreas,
	AreAreasInited,
	UnInitAreas,
	CanEvaluateArea,
	ProjectToArea,
	ProjectToAreaII,
	LineProjectToArea,
	AreaEvaluate,
	AreaNormal,
	AreaSlope,
	IsAreaFlat,
	IsAreaAnalytical,
	AreaCurvature,
	AreaNormalAndCurv,
	InitLinesI,
	InitLinesII,
	InitLinesIII,
	InitMoreLines,
	AreLinesInited,
	UnInitLines,
	CanEvaluateLine,
	ProjectToLine,
	LineEvaluate,
	IsLineStraight,
	LineCurvature,
	SetUpStatusWindow,
	KillStatusWindow,
	UpdateStatusWindow,
	CheckStatusWindow,
	ContStatusWindow,
	TimeStatusWindow,
	StatusWindowActive,
	UserAbort,
	NodeGeoEntity,
	LineNodeT,
	AreaNodeUV,
	LineMesh,
	LineMeshII,
	LineNumElemDivisions,
	LineNumNodes,
	NodeXYZ,
	NumVolShells,
	PossibleVolElemShape,
	VolumeElementShape,
	VolumeNumNodes,
	VolumeNumElems,
	TetJacobianErrorLimit,
	GetElemsInVolume,
	VolsAttachedToArea,
	NumVolsAttachedToArea,
	NumVolAreas,
	VolAreas,
	VolVolume,
	MaxNumAreas,
	IsAreaClosed,
	AreaParamRange,
	AreaHasLoneSeamKps,
	NumAreaLoops,
	NumAreaLoopLines,
	AreaLoopLines,
	AreaLines,
	IsAreaKpSide,
	GetElemsOnArea,
	GetFacetsOnArea,
	AreaElementShape,
	AreaNumNodes,
	AreaNumElems,
	MaxAreaId,
	NumAreaHardPoints,
	AreaHardPoints,
	AreaHardPointUV,
	AreaArea,
	LineKps,
	MaxNumLines,
	AreasAttachedToLine,
	LineLength,
	GetLineLayerInfo,
	NumLineHardPoints,
	LineHardPoints,
	LinesAttachedToKp,
	KpNodeId,
	MaxNumKps,
	KpXYZ,
	KpIsAreaHardPoint,
	KpIsLineHardPoint,
	TetJacobian,
	HexWedgePyrJacobian,
	CheckForSplit,
	DrawFace,
	TrackBegin,
	TrackPoint,
	TrackEnd,
	Error,
	String,
	PrintToOutputUnit,
	VerifyCommand,
	VerifyAllCommand,
	Interactive,
	Malloc,
	Free,
	SetParameters,
	AreaElemNodes,
	VolumeElemNodes,
	LineEsize,
	LineNumDiv,
	LineRatio,
	LineDivsFixed,
	LineSlope,
	LineSlopeCurv,
	KpEsize,
	RefChkNode,
	RefChkBfNode,
	RefChkElem,
	RefChkBfElem,
	AreaBoundingBox,
	CheckForSplit0,
	RecoverAreaMesh,
	LastFunction     /* DONOT DELETE !!! Add function names above this line*/
}FuncList;

struct FEM_VTBL_s
{
        /* From FEM_ansysshpchk.h */

        int (*func1)() ;  /* FEM_ComputeShapes */
        int (*func2)() ;  /* FEM_TestShapes */

        /* From FEM_ansysmtk.h */

        int  (*func3)()  ; /* FEM_ClearAreas */
        int  (*func4)()  ; /* FEM_ClearVols */
        int  (*func5)()  ; /* FEM_GetAreaElem */
        void (*func6)()  ; /* FEM_GetMaxIds */
        int  (*func7)()  ; /* FEM_GetNode */
        int  (*func8)()  ; /* FEM_GetTet */
        int  (*func9)()  ; /* FEM_Init */
        void (*func10)() ; /* FEM_Kill */
        int  (*func11)() ; /* FEM_MeshAreas */
        void (*func12)() ; /* FEM_SetMaxIds */
        int  (*func13)() ; /* FEM_TetMesh */
        void (*func14)() ; /* FEM_glSetExpansionFactor */
        void (*func15)() ; /* FEM_glSetFlatElemSize */
        void (*func16)() ; /* FEM_glSetMaxTran */
        void (*func17)() ; /* FEM_glSetSmoothInMesher */
        void (*func18)() ; /* FEM_glSetSplitQuads */
        void (*func19)() ; /* FEM_glSetTetExpand */
        void (*func20)() ; /* FEM_glSetTopoCleanInMesher */
        void (*func21)() ; /* FEM_glSetVerify */
        int  (*func22)() ; /* FEM_jrSetJournal */
} ;

typedef struct FEM_VTBL_s FEM_VTBL_t ;


extern void *FEM_vtbl_mtk_p[LastFunction];

#ifdef  UG_FEM_COMPILE_EXT

#define FEMex_InitAreas	\
	( (void (*)(FEM_INT *,FEM_INT,FEM_INT *))	\
	FEM_vtbl_mtk_p[0])
#define FEMex_InitMoreAreas	\
	( (void (*)(FEM_INT *,FEM_INT,FEM_INT *))	\
	FEM_vtbl_mtk_p[1])
#define FEMex_AreAreasInited	\
	( (FEM_BOOLEAN (*)(void))	\
	FEM_vtbl_mtk_p[2])
#define FEMex_UnInitAreas	\
	( (void (*)(void))	\
	FEM_vtbl_mtk_p[3])
#define FEMex_CanEvaluateArea	\
	( (void (*)(FEM_INT,FEM_BOOLEAN *,FEM_INT *))	\
	FEM_vtbl_mtk_p[4])
#define FEMex_ProjectToArea	\
	( (void (*)(FEM_INT,FEM_DOUBLE[3],FEM_DOUBLE,FEM_DOUBLE,FEM_BOOLEAN,FEM_DOUBLE*,FEM_DOUBLE*,FEM_DOUBLE[3],FEM_INT *))	\
	FEM_vtbl_mtk_p[5])
#define FEMex_ProjectToAreaII	\
	( (void (*)(FEM_INT,FEM_DOUBLE[3],FEM_DOUBLE,FEM_DOUBLE,FEM_BOOLEAN,FEM_DOUBLE *,FEM_DOUBLE *,FEM_DOUBLE[3],FEM_INT *))	\
	FEM_vtbl_mtk_p[6])
#define FEMex_LineProjectToArea	\
	( (void (*)(FEM_INT,FEM_INT,FEM_INT,FEM_DOUBLE[3],FEM_DOUBLE,FEM_DOUBLE,FEM_BOOLEAN,FEM_DOUBLE *,FEM_DOUBLE *, FEM_DOUBLE[3], FEM_INT *))	\
	FEM_vtbl_mtk_p[7])
#define FEMex_AreaEvaluate	\
	( (void (*)(FEM_INT,FEM_DOUBLE,FEM_DOUBLE,FEM_DOUBLE[3],FEM_INT *))	\
	FEM_vtbl_mtk_p[8])
#define FEMex_AreaNormal	\
	( (void (*)(FEM_INT,FEM_DOUBLE,FEM_DOUBLE,FEM_DOUBLE[3],FEM_DOUBLE[3],FEM_INT *))	\
	FEM_vtbl_mtk_p[9])
#define FEMex_AreaSlope	\
	( (void (*)(FEM_INT,FEM_DOUBLE,FEM_DOUBLE,FEM_DOUBLE[3],FEM_DOUBLE[3],FEM_INT *))	\
	FEM_vtbl_mtk_p[10])
#define FEMex_IsAreaFlat	\
	( (void (*)(FEM_INT,FEM_BOOLEAN *,FEM_INT *))	\
	FEM_vtbl_mtk_p[11])
#define FEMex_IsAreaAnalytical	\
	( (void (*)(FEM_INT,FEM_BOOLEAN *,FEM_INT *))	\
	FEM_vtbl_mtk_p[12])
#define FEMex_AreaCurvature	\
	( (void (*)(FEM_INT,FEM_DOUBLE,FEM_DOUBLE,FEM_DOUBLE *,FEM_INT*))  \
	FEM_vtbl_mtk_p[13])
#define FEMex_AreaNormalAndCurv	\
	( (void (*)(FEM_INT,FEM_DOUBLE,FEM_DOUBLE,FEM_DOUBLE[3],FEM_DOUBLE *,FEM_DOUBLE *,FEM_INT *))	\
	FEM_vtbl_mtk_p[14])

#define FEMex_InitLinesI	\
	( (void (*)(FEM_INT,FEM_BOOLEAN,FEM_INT *))	\
	FEM_vtbl_mtk_p[15])
#define FEMex_InitLinesII	\
	( (void (*)(FEM_INT *,FEM_INT,FEM_INT *,FEM_INT *,FEM_BOOLEAN,FEM_INT *))	\
	FEM_vtbl_mtk_p[16])
#define FEMex_InitLinesIII	\
	( (void (*)(FEM_INT *,FEM_INT,FEM_INT *))	\
	FEM_vtbl_mtk_p[17])
#define FEMex_InitMoreLines	\
	( (void (*)(FEM_INT *,FEM_INT,FEM_INT *))	\
	FEM_vtbl_mtk_p[18])
#define FEMex_AreLinesInited	\
	( (FEM_BOOLEAN (*)(void))	\
	FEM_vtbl_mtk_p[19])
#define FEMex_UnInitLines	\
	( (void (*)(void))	\
	FEM_vtbl_mtk_p[20])
#define FEMex_CanEvaluateLine	\
	( (void (*)(FEM_INT,FEM_BOOLEAN *,FEM_INT *))	\
	FEM_vtbl_mtk_p[21])
#define FEMex_ProjectToLine	\
	( (void (*)(FEM_INT,FEM_DOUBLE[3],FEM_DOUBLE,FEM_BOOLEAN,FEM_DOUBLE *,FEM_DOUBLE[3],FEM_INT *))	\
	FEM_vtbl_mtk_p[22])
#define FEMex_LineEvaluate	\
	( (void (*)(FEM_INT,FEM_DOUBLE,FEM_DOUBLE[3],FEM_INT *))	\
	FEM_vtbl_mtk_p[23])
#define FEMex_IsLineStraight	\
	( (FEM_BOOLEAN (*)(FEM_INT,FEM_INT *))	\
	FEM_vtbl_mtk_p[24])
#define FEMex_LineCurvature	\
	( (void (*)(FEM_INT,FEM_DOUBLE,FEM_DOUBLE *,FEM_INT *))	\
	FEM_vtbl_mtk_p[25])

#define FEMex_SetUpStatusWindow	\
	( (void (*)(FEM_INT,FEM_INT[3],FEM_INT *))	\
	FEM_vtbl_mtk_p[26])
#define FEMex_KillStatusWindow	\
	( (void (*)(void))	\
	FEM_vtbl_mtk_p[27])
#define FEMex_UpdateStatusWindow	\
	( (void (*)(FEM_INT,FEM_INT,FEM_INT[3],FEM_INT *))	\
	FEM_vtbl_mtk_p[28])
#define FEMex_CheckStatusWindow	\
	( (void (*)(FEM_INT,FEM_INT,FEM_INT[3],FEM_BOOLEAN *,FEM_INT *))	\
	FEM_vtbl_mtk_p[29])
#define FEMex_ContStatusWindow	\
	( (void (*)(FEM_INT *))	\
	FEM_vtbl_mtk_p[30])
#define FEMex_TimeStatusWindow	\
	( (void (*)(FEM_INT,FEM_INT,FEM_INT *))	\
	FEM_vtbl_mtk_p[31])
#define FEMex_StatusWindowActive	\
	( (FEM_BOOLEAN (*)(void))	\
	FEM_vtbl_mtk_p[32])
#define FEMex_UserAbort	\
	( (FEM_BOOLEAN (*)(void))	\
	FEM_vtbl_mtk_p[33])

#define FEMex_NodeGeoEntity	\
	( (void (*)(FEM_INT,FEM_INT *,GEOTYPE *,FEM_INT *))	\
	FEM_vtbl_mtk_p[34])
#define FEMex_LineNodeT	\
	( (void (*)(FEM_INT,FEM_INT,FEM_DOUBLE *,FEM_INT *))	\
	FEM_vtbl_mtk_p[35])
#define FEMex_AreaNodeUV	\
	( (void (*)(FEM_INT,FEM_INT,FEM_DOUBLE *,FEM_DOUBLE *,FEM_INT *))	\
	FEM_vtbl_mtk_p[36])

#define FEMex_LineMesh	\
	( (FEM_INT (*)(FEM_INT,FEM_DOUBLE *,FEM_DOUBLE *,FEM_INT *,FEM_INT *))	\
	FEM_vtbl_mtk_p[37])
#define FEMex_LineMeshII	\
	( (void (*)(FEM_INT,FEM_INT *,FEM_DOUBLE *,FEM_INT *))	\
	FEM_vtbl_mtk_p[38])
#define FEMex_LineNumElemDivisions	\
	( (FEM_INT (*)(FEM_INT,FEM_BOOLEAN *,FEM_INT *))	\
	FEM_vtbl_mtk_p[39])
#define FEMex_LineNumNodes	\
	( (FEM_INT (*)(FEM_INT,FEM_INT *))	\
	FEM_vtbl_mtk_p[40])

#define FEMex_NodeXYZ	\
	( (void (*)(FEM_INT,FEM_DOUBLE[3],FEM_INT *))	\
	FEM_vtbl_mtk_p[41])

#define FEMex_NumVolShells	\
	( (FEM_INT (*)(FEM_INT,FEM_INT *))	\
	FEM_vtbl_mtk_p[42])
#define FEMex_PossibleVolElemShape	\
	( (void (*)(FEM_INT,FEM_BOOLEAN *,FEM_BOOLEAN *,FEM_BOOLEAN *,FEM_BOOLEAN *,FEM_INT *))	\
	FEM_vtbl_mtk_p[43])

#define FEMex_VolumeElementShape	\
	( (FEM_INT (*)(FEM_INT,FEM_INT *))	\
	FEM_vtbl_mtk_p[44])
#define FEMex_VolumeNumNodes	\
	( (FEM_INT (*)(FEM_INT,FEM_INT *))	\
	FEM_vtbl_mtk_p[45])
#define FEMex_VolumeNumElems	\
	( (FEM_INT (*)(FEM_INT,FEM_INT *))	\
	FEM_vtbl_mtk_p[46])

#define FEMex_TetJacobianErrorLimit	\
	( (FEM_DOUBLE (*)(FEM_INT,FEM_INT *))	\
	FEM_vtbl_mtk_p[47])
#define FEMex_GetElemsInVolume	\
	( (FEM_INT (*)(FEM_INT,FEM_INT *,FEM_INT *))	\
	FEM_vtbl_mtk_p[48])
#define FEMex_VolsAttachedToArea	\
	( (FEM_INT (*)(FEM_INT,FEM_INT *,FEM_INT *))	\
	FEM_vtbl_mtk_p[49])
#define FEMex_NumVolsAttachedToArea	\
	( (FEM_INT (*)(FEM_INT,FEM_INT *))	\
	FEM_vtbl_mtk_p[50])
#define FEMex_NumVolAreas	\
	( (FEM_INT (*)(FEM_INT,FEM_INT *))	\
	FEM_vtbl_mtk_p[51])
#define FEMex_VolAreas	\
	( (FEM_INT (*)(FEM_INT,FEM_INT *,FEM_INT *))	\
	FEM_vtbl_mtk_p[52])
#define FEMex_VolVolume	\
	( (FEM_DOUBLE (*)(FEM_INT,FEM_INT *))	\
	FEM_vtbl_mtk_p[53])

#define FEMex_MaxNumAreas	\
	( (FEM_INT (*)(FEM_INT *))	\
	FEM_vtbl_mtk_p[54])

#define FEMex_IsAreaClosed	\
	( (void (*)(FEM_INT,FEM_BOOLEAN *,FEM_BOOLEAN *,FEM_INT *))	\
	FEM_vtbl_mtk_p[55])
#define FEMex_AreaParamRange	\
	( (void (*)(FEM_INT,FEM_DOUBLE *,FEM_DOUBLE *,FEM_DOUBLE *,FEM_DOUBLE *,FEM_INT *))	\
	FEM_vtbl_mtk_p[56])
#define FEMex_AreaHasLoneSeamKps	\
	( (void (*)(FEM_INT,FEM_INT[2],FEM_INT *,FEM_INT *))	\
	FEM_vtbl_mtk_p[57])
#define FEMex_NumAreaLoops	\
	( (FEM_INT (*)(FEM_INT,FEM_INT *))	\
	FEM_vtbl_mtk_p[58])
#define FEMex_NumAreaLoopLines	\
	( (FEM_INT (*)(FEM_INT,FEM_INT,FEM_INT *))	\
	FEM_vtbl_mtk_p[59])
#define FEMex_AreaLoopLines	\
	( (void (*)(FEM_INT,FEM_INT,FEM_INT *,FEM_INT *))	\
	FEM_vtbl_mtk_p[60])
#define FEMex_AreaLines	\
	( (void (*)(FEM_INT,FEM_INT *,FEM_BOOLEAN *,FEM_INT *,FEM_INT *))	\
	FEM_vtbl_mtk_p[61])
#define FEMex_IsAreaKpSide	\
	( (void (*)(FEM_INT,FEM_INT,FEM_INT *,FEM_INT *))	\
	FEM_vtbl_mtk_p[62])
#define FEMex_GetElemsOnArea	\
	( (FEM_INT (*)(FEM_INT,FEM_INT *,FEM_INT *))	\
	FEM_vtbl_mtk_p[63])
#define FEMex_GetFacetsOnArea	\
	( (void (*)(FEM_INT,FEM_DOUBLE **,FEM_INT **,FEM_INT *,FEM_INT **,FEM_INT *,FEM_INT *))	\
	FEM_vtbl_mtk_p[64])
#define FEMex_AreaElementShape	\
	( (FEM_INT (*)(FEM_INT,FEM_INT *))	\
	FEM_vtbl_mtk_p[65])
#define FEMex_AreaNumNodes	\
	( (FEM_INT (*)(FEM_INT,FEM_INT *))	\
	FEM_vtbl_mtk_p[66])
#define FEMex_AreaNumElems	\
	( (FEM_INT (*)(FEM_INT,FEM_INT *))	\
	FEM_vtbl_mtk_p[67])
#define FEMex_MaxAreaId	\
	( (FEM_INT (*)(FEM_INT *))	\
	FEM_vtbl_mtk_p[68])
#define FEMex_NumAreaHardPoints	\
	( (FEM_INT (*)(FEM_INT,FEM_INT *))	\
	FEM_vtbl_mtk_p[69])
#define FEMex_AreaHardPoints	\
	( (FEM_INT (*)(FEM_INT,FEM_INT *,FEM_INT *))	\
	FEM_vtbl_mtk_p[70])
#define FEMex_AreaHardPointUV	\
	( (void (*)(FEM_INT,FEM_DOUBLE *,FEM_DOUBLE *,FEM_DOUBLE[3],FEM_INT *))	\
	FEM_vtbl_mtk_p[71])
#define FEMex_AreaArea	\
	( (FEM_DOUBLE (*)(FEM_INT,FEM_INT *))	\
	FEM_vtbl_mtk_p[72])

#define FEMex_LineKps	\
	( (void (*)(FEM_INT,FEM_INT *,FEM_INT *,FEM_INT *))	\
	FEM_vtbl_mtk_p[73])
#define FEMex_MaxNumLines	\
	( (FEM_INT (*)(FEM_INT *))	\
	FEM_vtbl_mtk_p[74])

#define FEMex_AreasAttachedToLine \
	( (FEM_INT (*)(FEM_INT, FEM_INT *, FEM_INT *))  \
	FEM_vtbl_mtk_p[75])

#define FEMex_LineLength	\
	( (FEM_DOUBLE (*)(FEM_INT,FEM_INT *))	\
	FEM_vtbl_mtk_p[76])
#define FEMex_GetLineLayerInfo	\
	( (void (*)(FEM_INT,FEM_DOUBLE *,FEM_DOUBLE *,FEM_INT *))	\
	FEM_vtbl_mtk_p[77])
#define FEMex_NumLineHardPoints	\
	( (FEM_INT (*)(FEM_INT,FEM_INT *))	\
	FEM_vtbl_mtk_p[78])
#define FEMex_LineHardPoints	\
	( (FEM_INT (*)(FEM_INT,FEM_INT *,FEM_INT *))	\
	FEM_vtbl_mtk_p[79])
#define FEMex_LinesAttachedToKp	\
	( (FEM_INT (*)(FEM_INT,FEM_INT *,FEM_INT *))	\
	FEM_vtbl_mtk_p[80])
#define FEMex_KpNodeId	\
	( (FEM_INT (*)(FEM_INT,FEM_INT *))	\
	FEM_vtbl_mtk_p[81])
#define FEMex_MaxNumKps	\
	( (FEM_INT (*)(FEM_INT *))	\
	FEM_vtbl_mtk_p[82])
#define FEMex_KpXYZ	\
	( (FEM_INT (*)(FEM_INT,FEM_DOUBLE[3],FEM_INT *))	\
	FEM_vtbl_mtk_p[83])
#define FEMex_KpIsAreaHardPoint	\
	( (FEM_INT (*)(FEM_INT,FEM_INT *))	\
	FEM_vtbl_mtk_p[84])
#define FEMex_KpIsLineHardPoint	\
	( (FEM_INT (*)(FEM_INT,FEM_INT *))	\
	FEM_vtbl_mtk_p[85])

#define FEMex_TetJacobian	\
	( (void (*)(FEM_DOUBLE[30],FEM_DOUBLE *,FEM_INT *))	\
	FEM_vtbl_mtk_p[86])
#define FEMex_HexWedgePyrJacobian	\
	( (void (*)(INT[20],FEM_DOUBLE *,FEM_DOUBLE *,FEM_INT *))	\
	FEM_vtbl_mtk_p[87])
#define FEMex_CheckForSplit	\
	( (FEM_INT (*)(FEM_DOUBLE[24],FEM_INT,FEM_DOUBLE,FEM_DOUBLE,FEM_INT *,FEM_INT *))	\
	FEM_vtbl_mtk_p[88])

#define FEMex_DrawFace	\
	( (void (*)(FEM_INT,FEM_INT,FEM_DOUBLE *,FEM_INT *,FEM_INT))	\
	FEM_vtbl_mtk_p[89])

#define FEMex_TrackBegin	\
	( (void (*)(FEM_CHAR *))	\
	FEM_vtbl_mtk_p[90])
#define FEMex_TrackPoint	\
	( (void (*)(FEM_CHAR *))	\
	FEM_vtbl_mtk_p[91])
#define FEMex_TrackEnd	\
	( (void (*)(FEM_CHAR *))	\
	FEM_vtbl_mtk_p[92])

#define FEMex_Error	\
	( (void (*)(FEM_INT,FEM_INT,FEM_INT,FEM_DOUBLE *,FEM_CHAR *,FEM_INT))	\
	FEM_vtbl_mtk_p[93])

#define FEMex_String	\
	( (void (*)(FEM_CHAR[256],FEM_INT))	\
	FEM_vtbl_mtk_p[94])
#define FEMex_PrintToOutputUnit	\
	( (void (*)(FEM_CHAR *))	\
	FEM_vtbl_mtk_p[95])
#define FEMex_VerifyCommand	\
	( (void (*)(FEM_CHAR *,FEM_INT *))	\
	FEM_vtbl_mtk_p[96])
#define FEMex_VerifyAllCommand	\
	( (void (*)(FEM_CHAR *,FEM_INT *))	\
	FEM_vtbl_mtk_p[97])
#define FEMex_Interactive	\
	( (FEM_INT (*)(void))	\
	FEM_vtbl_mtk_p[98])

#define FEMex_Malloc	\
	( (FEM_CHAR * (*)(FEM_INT,FEM_CHAR *,FEM_INT))	\
	FEM_vtbl_mtk_p[99])
#define FEMex_Free	\
	( (void (*)(FEM_CHAR *,FEM_CHAR *,FEM_INT))	\
	FEM_vtbl_mtk_p[100])
#define FEMex_SetParameters	\
	( (void (*)(GEOTYPE,FEM_INT))	\
	FEM_vtbl_mtk_p[101])

#define FEMex_AreaElemNodes	\
	( (FEM_INT (*)(FEM_INT,FEM_INT[8],FEM_INT *,FEM_INT *,FEM_INT *))	\
	FEM_vtbl_mtk_p[102])
#define FEMex_VolumeElemNodes	\
	( (FEM_INT (*)(FEM_INT,FEM_INT[20],FEM_INT *,FEM_INT *))	\
	FEM_vtbl_mtk_p[103])

#define FEMex_LineEsize	\
	( (void (*)(FEM_INT,FEM_DOUBLE *,FEM_DOUBLE *,FEM_INT *))	\
	FEM_vtbl_mtk_p[104])
#define FEMex_LineNumDiv	\
	( (FEM_INT (*)(FEM_INT,FEM_INT *))	\
	FEM_vtbl_mtk_p[105])
#define FEMex_LineRatio	\
	( (FEM_DOUBLE (*)(FEM_INT,FEM_INT *))	\
	FEM_vtbl_mtk_p[106])
#define FEMex_LineDivsFixed	\
	( (FEM_INT (*)(INT,INT *))	\
	FEM_vtbl_mtk_p[107])
#define FEMex_LineSlope	\
	( (void (*)(FEM_INT,FEM_DOUBLE,FEM_DOUBLE *,FEM_INT *))	\
	FEM_vtbl_mtk_p[108])
#define FEMex_LineSlopeCurv	\
	( (void (*)(FEM_INT,FEM_DOUBLE,FEM_DOUBLE *,FEM_DOUBLE *,FEM_INT *))	\
	FEM_vtbl_mtk_p[109])
#define FEMex_KpEsize	\
	( (FEM_DOUBLE (*)(FEM_INT,FEM_INT *))	\
	FEM_vtbl_mtk_p[110])
#define FEMex_RefChkNode	\
	( (void (*)(FEM_INT,FEM_INT *,FEM_INT,FEM_INT,FEM_INT *))	\
	FEM_vtbl_mtk_p[111])
#define FEMex_RefChkBfNode	\
	( (void (*)(FEM_INT,FEM_INT *,FEM_INT,FEM_INT,FEM_INT *))	\
	FEM_vtbl_mtk_p[112])
#define FEMex_RefChkElem	\
	( (void (*)(FEM_INT,FEM_INT *,FEM_INT,FEM_INT *))	\
	FEM_vtbl_mtk_p[113])
#define FEMex_RefChkBfElem	\
	( (void (*)(FEM_INT,FEM_INT *,FEM_INT,FEM_INT *))	\
	FEM_vtbl_mtk_p[114])

#define FEMex_AreaBoundingBox	\
	( (void (*)(FEM_INT,FEM_DOUBLE[3],FEM_DOUBLE[3],FEM_INT *))	\
	FEM_vtbl_mtk_p[115])
#define FEMex_CheckForSplit0	\
	( (FEM_INT (*)(FEM_DOUBLE *,FEM_INT,FEM_DOUBLE *,FEM_DOUBLE *,FEM_INT *,FEM_INT *))	\
	FEM_vtbl_mtk_p[116])
#define FEMex_RecoverAreaMesh	\
	( (void (*)(FEM_INT,FEM_INT *))	\
	FEM_vtbl_mtk_p[117])

#endif

#endif
#endif

