/* sid 50.1 copy of integration.h last changed by upd111 on 2005/06/04 13:21:34 */
/* integration.h CADOE doeinc */
/*
 * integration.h
 *
 * $Id$
 *   
 * HISTORY
 *   
 *   09/25/00 11:19 <       Brian Jantzen> Rel:ms8m1    SCCA:79107  Delta:81.2
 *   
 *   01/13/00 11:20 <        Marc Gadbois> Rel:ms8      SCCA:65669  Delta:8.3
 *   
 *   09/30/99 17:38 <         James Silva> Rel:ms8      SCCA:56512  Delta:8.2
 */

#ifndef __integrationh__
#define __integrationh__ 1

#ifdef __cplusplus
extern "C" {
#endif

extern T_statut cre_tab_integration(void);
extern void free_tab_integration(void);
extern T_statut creer_integration( int, int, int, T_Integration** );

#ifdef __cplusplus
}
#endif

#endif
