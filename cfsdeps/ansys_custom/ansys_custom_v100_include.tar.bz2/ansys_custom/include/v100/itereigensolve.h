/* sid 50.2 copy of itereigensolve.h last changed by jrb on 2004/12/30 14:25:25 */
/* Header file for the iterative eignevalue solver	*/

#if defined(T)
#undef T
#endif
#if defined(F)
#undef F
#endif

/* Define MAX_INTRABLOCK_BLOCK_SIZE to be maximum of MAX_LANCZOS_BLOCK_SIZE and MAX_TOTAL_DIM */
#if (MAX_LANCZOS_BLOCK_SIZE > MAX_TOTAL_DIM)
#define MAX_INTRABLOCK_BLOCK_SIZE MAX_LANCZOS_BLOCK_SIZE
#else
#define MAX_INTRABLOCK_BLOCK_SIZE MAX_TOTAL_DIM
#endif

/* MAX_KRYLOV_SUBSPACE_DIM must be a multiple of 4 */
#define MAX_KRYLOV_SUBSPACE_DIM	3000
/* #define MIN_ALLOC_BLOCK_SIZE	6 */
#define MIN_ALLOC_BLOCK_SIZE	3

#define MAX_EXTRA_WORK_VECS	1024

#define ZERO_MASS_ADJUST_MULT	1.0e-4

#define LARGE_EIGEN_CHANGE_MULT	1.0e-2

/* Defined constant for setting shift sigma as fraction of estimate of
   lowest eigenvalue */
#define FRACTION_OF_LOW_EIGEN	0.001

/* Defined constant for setting the fraction of extra eigenvalues that
   should converge before stopping */
#define EXTRA_EP_FRACTION_K_LOWEST	0.0
#define EXTRA_EP_FRACTION_RANGE	0.0

#define eigenValsDenseFnExt	".denseevals"
#define eigenVecsDenseFnExt	".denseevecs"

#define eigenValsIterFnExt	".iterevals"
#define eigenVecsIterFnExt	".iterevecs"

#define eigenValsViaQTKQFnExt	".EVL.QTKQ"
#define eigenVecsViaQTKQFnExt	".EVC.QTKQ"

#define SHIFT_FN	"eigenshift.cas"

struct pccg_data_str {
  NodeList nl;
  SetArr sa;
  sparseFactor f;
  sparseFactor V;
  INT n;
  sparseFactor K;
  sparseFactor K11;
  sparseFactor K12T;
  CpCe cpce;
  ElemMatGen emg;
  BlockDiag bd;
  sparseFactor M;
  sparseFactor KDelta;
  INT lumpedMassF;
  DOUBLE sigma;
  DOUBLE pccgThresh;
  DOUBLE limitOnNumIter;
  DOUBLE maxDiag;
  DOUBLE *resultVec;
  DOUBLE **workVecs;
};

typedef struct pccg_data_str* PccgData;

#define pccgDataNl(pccgData)			(pccgData->nl)
#define pccgDataSa(pccgData)			(pccgData->sa)
#define pccgDataF(pccgData)			(pccgData->f)
#define pccgDataV(pccgData)			(pccgData->V)
#define pccgDataN(pccgData)			(pccgData->n)
#define pccgDataK(pccgData)			(pccgData->K)
#define pccgDataK11(pccgData)			(pccgData->K11)
#define pccgDataK12T(pccgData)			(pccgData->K12T)
#define pccgDataCpCe(pccgData)			(pccgData->cpce)
#define pccgDataEmg(pccgData)			(pccgData->emg)
#define pccgDataBd(pccgData)			(pccgData->bd)
#define pccgDataM(pccgData)			(pccgData->M)
#define pccgDataKDelta(pccgData)		(pccgData->KDelta)
#define pccgDataLumpedMassF(pccgData)		(pccgData->lumpedMassF)
#define pccgDataSigma(pccgData)			(pccgData->sigma)
#define pccgDataPccgThresh(pccgData)		(pccgData->pccgThresh)
#define pccgDataLimitOnNumIter(pccgData)	(pccgData->limitOnNumIter)
#define pccgDataMaxDiag(pccgData)		(pccgData->maxDiag)
#define pccgDataResultVec(pccgData)		(pccgData->resultVec)
#define pccgDataWorkVecs(pccgData)		(pccgData->workVecs)


#include "itereigendecls.h"
