/* sid 50.1 copy of fem_spMemory.h last changed by upd111 on 2004/11/04 18:33:14 */
/*  fem_spMemory.h */
/* 
 * *** ansys(r) copyright(c) 1999
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  fem_spMemory.h
 *  Prototypes and macros for Memory handling routines for surface curvature
 *      refinement.
 *
 */

#ifndef FEM_SPMEMORY_____H
#define FEM_SPMEMORY_____H

typedef enum { RANGEDATA,
               RECTLIST,
               VERTEXLIST,
               RECTANGLE,
               VERTEX,
               DOUBLE_VAR } SP_ENTITY_ENUM;

/******************************************************************************/
/******************************************************************************/
/*  Function Prototypes                                                       */
/******************************************************************************/
/******************************************************************************/

                          /* ================================================ */
                          /* === FEM_spFreeMemory: Free all remaining memory  */
                          /* === allocated for surface proximity processing.  */
                          /* === Return: void                                 */
                          /* ================================================ */
void FEM_spFreeMemory (
   RANGETREE_TYP *ps_rtree  );  /* a range tree                               */

                          /* ================================================ */
                          /* === FEM_spFreeGenericPointers: free generic      */
                          /* === pointers of edges and faces                  */
                          /* === Return: void                                 */
                          /* ================================================ */
void FEM_spFreeGenericPointers ( void );

                          /* ================================================ */
                          /* === FEM_spMalloc: Get memory for a single entity */
                          /* === of type "type".                              */
                          /* === Return:  void* pointer to the memory.        */
                          /* ================================================ */
void *FEM_spMalloc (
   INT type  );           /* Type type of memory requested                    */
 
                          /* ================================================ */
                          /* === FEM_spFree: Put some memory back on the stack*/
                          /* === that was allocated with fem_spMalloc.        */
                          /* === Return:  void                                */
                          /* ================================================ */
void FEM_spFree (
   INT type,              /* Type type of memory requested                    */
   void *point  );        /* pointer to the memory to be put back on stack    */

                          /* ================================================ */
                          /* === FEM_spFreeAll: Free All memory used in the   */
                          /* === surface proximity memory manager.            */
                          /* === Return:  void                                */
                          /* ================================================ */
void FEM_spFreeAll ( void  );


#endif

