/* sid 50.2 copy of LMatrix.h last changed by jdbeley on 2005/03/31 12:37:43 */
/* CADOE */
/*******************************************************************************
 *
 *   Lmatrix.h
 *              
 * 
 * |Module: LF EMAG - L matrix calculation
 *
 * |Description: 
 *
 * |Author: Jean-Daniel Beley
 *
 * |Creation Date: February 2005 
 *
 * |Version: $Id$
 *
 * |Copyright:	Copyright(c) ANSYS 2005
 *
 ******************************************************************************/
#ifndef __LMATRIX_H__
#define __LMATRIX_H__ 1

#include "cadoe.h"
#include "cadoe_string.h"
#include "computer.h"
#include "globals.h"
#include "sysparh.h"

#if defined(LOWERCASENOUNDER_SYS)
#define MgIncAddRhs mgincaddrhs
#define MgIncFree mgincfree
#define MgIncInitializeIterator  mgincinitializeiterator
#define MgIncAddEnergy mgincaddenergy
#define MgIncZeroEnergy mginczeroenergy
#define MgIncGetIndex mgincgetindex
#define MgIncIncIndex mgincincindex
#define OutputResult outputresult
#define MgIncSolve mgincsolve
#define setdisp setdisp
#define MgIncGetNbRHS mgincgetnbrhs
#define MgIncGetEnergy mgincgetenergy
#define printdisp printdisp
#define MgIncReadRHS mgincreadrhs
#endif

#if defined(UPPERCASENOUNDER_SYS)
#define MgIncAddRhs MGINCADDRHS
#define MgIncFree MGINCFREE
#define MgIncInitializeIterator MGINCINITIALIZEITERATOR
#define MgIncAddEnergy MGINCADDENERGY
#define MgIncZeroEnergy MGINCZEROENERGY
#define MgIncGetIndex MGINCGETINDEX
#define MgIncIncIndex MGINCINCINDEX
#define OutputResult OUTPUTRESULT
#define MgIncSolve MGINCSOLVE
#define setdisp SETDISP
#define MgIncGetNbRHS MGINCGETNBRHS
#define MgIncGetEnergy MGINCGETENERGY
#define printdisp PRINTDISP
#define MgIncReadRHS MGINCREADRHS
#endif

#if defined(LOWERCASEUNDER_SYS)
#define MgIncAddRhs mgincaddrhs_
#define MgIncFree mgincfree_
#define MgIncInitializeIterator mgincinitializeiterator_
#define MgIncAddEnergy mgincaddenergy_
#define MgIncZeroEnergy mginczeroenergy_
#define MgIncGetIndex mgincgetindex_
#define MgIncIncIndex mgincincindex_
#define OutputResult outputresult_
#define MgIncSolve mgincsolve_
#define setdisp setdisp_
#define MgIncGetNbRHS mgincgetnbrhs_
#define MgIncGetEnergy mgincgetenergy_
#define printdisp printdisp_
#define MgIncReadRHS mgincreadrhs_
#endif

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

  SUBROUTINE MgIncAddRhs( DOUBLE *force, INT *lenu, INT *ier );
  SUBROUTINE MgIncInitializeIterator(void);
  SUBROUTINE MgIncFree(void);
  SUBROUTINE MgIncAddEnergy( DOUBLE *e1, DOUBLE *e2 );
  SUBROUTINE MgIncZeroEnergy();
  SUBROUTINE MgIncGetIndex( INT *index, INT *iret );
  INT FUNCTION OutputResult(void);
  SUBROUTINE MgIncSolve( DOUBLE *Sol, DOUBLE *dSol, INT *lenu, INT *nrkey, INT *ier );
  SUBROUTINE MgIncGetEnergy( INT*, DOUBLE*, DOUBLE* );
  SUBROUTINE MgIncReadRHS( INT*, DOUBLE *);
  
#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __LMATRIX_H__ */
