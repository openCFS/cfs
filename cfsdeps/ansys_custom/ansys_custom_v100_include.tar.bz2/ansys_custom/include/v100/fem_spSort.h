/* sid 50.1 copy of fem_spSort.h last changed by upd111 on 2004/11/04 18:33:18 */
/*  fem_spSort.h */
/* 
 * *** ansys(r) copyright(c) 1999
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  fem_spSort.h
 *  Prototypes and macros for sorting range trees.
 *
 */

#ifndef FEM_SPSORT_____H
#define FEM_SPSORT_____H

                          /* ================================================ */
                          /* === FEM_spSort: Sort a range tree                */
                          /* === Return: EXIT_SUCCESS or EXIT_FAILURE         */
INT FEM_spSort (
   RANGETREE_TYP *ps_rtree  ); /* (IN/OUT) the range tree                     */

#endif

