/* sid 50.1 copy of FEM_clear.h last changed by upd111 on 2004/11/04 18:30:23 */

/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 1999 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_clear.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_clear.h
 *  header file for FEM_clear.c
 *
 */
#ifndef FEM_CLEAR_INCLUDE
#define FEM_CLEAR_INCLUDE

/*----------------- Globally accessible function prototypes -----------------*/

#ifdef __cplusplus
extern "C" {
#endif


                          /* =============================================== */
                          /* === FEM_clClearAreas: Given a list of area ids, */
                          /* === clear the nodes and elements on these areas */
                          /* === from the Ansys Mesh Database.               */
                          /* === RETURN: INT ( EXIT_SUCCESS or EXIT_FAILURE) */
                          /* =============================================== */
INT FEM_clClearAreas(
   INT num_area,          /* (IN)  The number of areas to be cleared.        */
                          /*       (dimension of a_areas)                    */
   INT *a_areas,          /* (IN)  Array of ids of all areas to be cleared.  */
   FEM_BOOLEAN adjgeo );  /* (IN)  FALSE if only elements and nodes on areas */
                          /*       are deleted.  Nodes on lines and          */
                          /*       keypoints adjacent to the areas are not   */
                          /*       deleted.                                  */
                          /*       TRUE if nodes on adjacent lines and       */
                          /*       keypoints not used by elements on non-    */
                          /*       cleared areas should also be deleted.     */
                          /* =============================================== */

                          /* =============================================== */
                          /* === FEM_clClearVols: Given a list of vol ids,   */
                          /* === clear the nodes and elements on these vols  */
                          /* === from the Ansys Mesh Database.               */
                          /* === RETURN: INT ( EXIT_SUCCESS or EXIT_FAILURE) */
                          /* =============================================== */
INT FEM_clClearVols(
   INT num_vol,           /* (IN)  The number of volumes to be cleared.      */
                          /*       (dimension of a_vols)                     */
   INT *a_vols,           /* (IN)  Array of ids of all volumes to be cleared */
   FEM_BOOLEAN adjgeo );  /* (IN)  FALSE if only elements and nodes on vols  */
                          /*       are deleted.  Nodes on areas, lines and   */
                          /*       keypoints adjacent to the vols are not    */
                          /*       deleted.                                  */
                          /*       TRUE if nodes on adjacent areas, lines &  */
                          /*       keypoints not used by elements on non-    */
                          /*       cleared volumes should also be deleted.   */
                          /* =============================================== */

                          /* =============================================== */
                          /* === FEM_clClearVolsAndAreas: Given a list of vol ids,   */
                          /* === clear the nodes and elements on these vols  */
                          /* === from the Ansys Mesh Database.   DO NOT CLEAR EDGES OR VERTICES            */
                          /* === RETURN: INT ( EXIT_SUCCESS or EXIT_FAILURE) */
                          /* =============================================== */
INT FEM_clClearVolsAndAreas(
   INT num_vol,           /* (IN)  The number of volumes to be cleared.      */
                          /*       (dimension of a_vols)                     */
   INT *a_vols );           /* (IN)  Array of ids of all volumes to be cleared */



#ifdef __cplusplus
}
#endif

#endif

