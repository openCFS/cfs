/* sid 50.1 copy of FEM_reUtil.h last changed by upd111 on 2004/11/04 18:32:00 */
/*  FEM_reUtil.h */
/*
 * *** ansys(r) copyright(c) 1999
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_reUtil.h
 *  Prototypes and macros for FEM face data type
 *
 */

#ifndef FEM_REUTIL
#define FEM_REUTIL

#include "FEM_cdbtypes.h"

/* === for parameter to fem_reCreateTri and fem_reCreateQuad,
   === FEM_reCreateTet, FEM_reCreatePyramid, FEM_reCreteWedge,
   === and FEM_reCreateHex */
#define NEW     -99

/* === property masks used with the property field in the face */

                              /* ============================================ */
                              /* === FEM_re2RefNodes_Quad: Compute location   */
                              /* === of interior node for 2-refinement on a   */
                              /* === quad.                                    */
INT FEM_re2RefNodes_Quad (
   FACE_OBJ obj_face,         /* the face object                              */
   DOUBLE *xc,                /* returned array of x locations for the node   */
   DOUBLE *yc,                /* returned array of y locations for the node   */
   DOUBLE *zc );              /* returned array of z locations for the node   */

                              /* ============================================ */
                              /* === FEM_re3RefNodes_Quad: Compute location   */
                              /* === of interior nodes for 3-refinement on a  */
                              /* === quad.                                    */
INT FEM_re3RefNodes_Quad (
   FACE_OBJ obj_face,           /* the face object                            */
   INT which_node,              /* which node is desired.  (0-3 or -1). If -1,*/
                                /* location of all 4 nodes is returned.  If   */
                                /* 0-3 location of specified node is returned.*/
   NODE_OBJ obj_firstnode,      /* first node on the face rotation            */
   NODE_OBJ obj_secondnode,     /* second node on the face rotation           */
   DOUBLE *xc,                  /* returned location of the specified node or */
   DOUBLE *yc,                  /* nodes                                      */
   DOUBLE *zc  );

                              /* ============================================ */
                              /* === FEM_re3RefNodes_Tri: Compute location of */
                              /* === interior nodes for 3-refinement on a tri */
INT FEM_re3RefNodes_Tri (
   FACE_OBJ obj_face,                    /* the face object                   */
   DOUBLE *xc,                /* returned array of x locations for the node   */
   DOUBLE *yc,                /* returned array of y locations for the node   */
   DOUBLE *zc );              /* returned array of z locations for the node   */

                              /* ============================================ */
                              /* === FEM_re3RefNodes_Hex: compute the         */
                              /* === location of 8 nodes evenly spaced in the */
                              /* === interior of a hexahedron to be used in   */
                              /* === 3-refinement.                            */
INT FEM_re3RefNodes_Hex (
   ELEMENT_OBJ obj_hex,       /* the element object                           */
   INT num_marked,            /* number of hex nodes marked                   */
   INT is_marked[8],          /* TRUE for each marked node                    */
   INT is_needed[8],          /* TRUE for new node locations needed           */
   DOUBLE xc[8],              /* return location of 8 nodes in the hex.       */
   DOUBLE yc[8],
   DOUBLE zc[8]  );

                              /* ============================================ */
                              /* === FEM_re3RefEdgeNodeIndex: Determine index */
                              /* === of new node added to edge.               */
INT FEM_re3RefFaceEdgeNodeIndex (
   FACE_OBJ obj_face,         /* the face object                              */
   FACE_OBJ obj_edge,         /* an edge on the face                          */
   INT which_node );          /* either the first or second node added in     */
                              /* 3-refinement                                 */

                              /* ============================================ */
                              /* === FEM_re3RefTetEdgeNodeIndex:  Given a tet */
                              /* === and an edge on that tet that has been    */
                              /* === split by adding two new nodes at the 1/3 */
                              /* === and 2/3 location determine the index of  */
                              /* === the which_node_th node in the nodes array*/
                              /* === pointed to by the edges generic pointer. */
INT FEM_re3RefTetEdgeNodeIndex (
   ELEMENT_OBJ obj_elem,      /* an element object                            */
   EDGE_OBJ obj_edge,         /* an edge on the elem                          */
   INT edge_index,            /* index of obj_edge on obj_elem                */
   INT which_node  );         /* either the first or second node added in
                                 3-refinement                                 */

                             /* ============================================= */
                             /* === FEM_reCreateTet: create a new tetrahedron */
                             /* === from the the list of nodes specified      */
INT FEM_reCreateTet (
   NODE_OBJ obj_node0,       /* node 0 on tet (see FEM_Public.c for numbering)*/
   NODE_OBJ obj_node1,       /* node 1 on tet (see FEM_Public.c for numbering)*/
   NODE_OBJ obj_node2,       /* node 2 on tet (see FEM_Public.c for numbering)*/
   NODE_OBJ obj_node3,       /* node 3 on tet (see FEM_Public.c for numbering)*/
   INT vol_number,           /* geo entity to assign to tet                   */
   INT elem_id,              /* element id of new tet                         */
   INT parent,               /* parent of new tet                             */
   INT mid_nodes,            /* if the new tet will have midnodes             */
   LONG degenerate_hex,      /* if the tet is a degenerate hex                */
   LONG project_midnode  );  /* if new midnodes are to be projected           */

                             /* ============================================= */
                             /* === FEM_reCreatePyramid: create a new Pyramid */
                             /* === from the the list of nodes specified      */
INT FEM_reCreatePyramid (
   NODE_OBJ obj_node0,       /* node 0 on pyr (see FEM_Public.c for numbering)*/
   NODE_OBJ obj_node1,       /* node 1 on pyr (see FEM_Public.c for numbering)*/
   NODE_OBJ obj_node2,       /* node 2 on pyr (see FEM_Public.c for numbering)*/
   NODE_OBJ obj_node3,       /* node 3 on pyr (see FEM_Public.c for numbering)*/
   NODE_OBJ obj_node4,       /* node 4 on pyr (see FEM_Public.c for numbering)*/
   INT vol_number,           /* geo entity to assign to pyramid               */
   INT elem_id,              /* element id of new pyramid                     */
   INT parent,               /* parent of new pyramid                         */
   INT mid_nodes,            /* if the new pyramid will have midnodes         */
   LONG degenerate_hex,      /* if the pyramid is a degenerate hex            */
   LONG project_midnode,     /* if new midnodes are to be projected           */
   ELEMENT_OBJ *obj_newpyramid  ); /* the new pyramid created                 */

                             /* ============================================= */
                             /* === FEM_reCreateWedge: create a new Wedge     */
                             /* === from the the list of nodes specified      */
INT FEM_reCreateWedge (
   NODE_OBJ obj_node0,       /* node 0 on wdg (see FEM_Public.c for numbering)*/
   NODE_OBJ obj_node1,       /* node 1 on wdg (see FEM_Public.c for numbering)*/
   NODE_OBJ obj_node2,       /* node 2 on wdg (see FEM_Public.c for numbering)*/
   NODE_OBJ obj_node3,       /* node 3 on wdg (see FEM_Public.c for numbering)*/
   NODE_OBJ obj_node4,       /* node 4 on wdg (see FEM_Public.c for numbering)*/
   NODE_OBJ obj_node5,       /* node 5 on wdg (see FEM_Public.c for numbering)*/
   INT vol_number,           /* geo entity to assign to wedge                 */
   INT elem_id,              /* element id of new wedge                       */
   INT parent,               /* parent of new wedge                           */
   INT mid_nodes,            /* if the new wedge will have midnodes           */
   LONG degenerate_hex,      /* if the wedge is a degenerate hex              */
   LONG project_midnode,     /* if new midnodes are to be projected           */
   ELEMENT_OBJ *obj_newwedge  );   /* the new pyramid created                 */

                             /* ============================================= */
                             /* === FEM_reCreateHex: create a new Hexahedron  */
                             /* === from the the list of nodes specified      */
INT FEM_reCreateHex (
   NODE_OBJ obj_node0,       /* node 0 on hex (see FEM_Public.c for numbering)*/
   NODE_OBJ obj_node1,       /* node 1 on hex (see FEM_Public.c for numbering)*/
   NODE_OBJ obj_node2,       /* node 2 on hex (see FEM_Public.c for numbering)*/
   NODE_OBJ obj_node3,       /* node 3 on hex (see FEM_Public.c for numbering)*/
   NODE_OBJ obj_node4,       /* node 4 on hex (see FEM_Public.c for numbering)*/
   NODE_OBJ obj_node5,       /* node 5 on hex (see FEM_Public.c for numbering)*/
   NODE_OBJ obj_node6,       /* node 6 on hex (see FEM_Public.c for numbering)*/
   NODE_OBJ obj_node7,       /* node 7 on hex (see FEM_Public.c for numbering)*/
   INT vol_number,           /* geo entity to assign to hex                   */
   INT elem_id,              /* element id of new hex                         */
   INT parent,               /* parent of new hex                             */
   INT mid_nodes,            /* if the new hex will have midnodes             */
   LONG project_midnode  );  /* if new midnodes are to be projected           */

#endif
