/* sid 50.1 copy of FEM_cleanTriTopo.h last changed by upd111 on 2004/11/04 18:30:21 */
/*  FEM_cleanTriTopo.h */
/*
 * *** ansys(r) copyright(c) 1999
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_cleanTri.h
 *  header file for FEM_cleanTri.c
 *
 */
#ifndef FEM_CLEAN_TRI_TOPO_INCLUDE
#define FEM_CLEAN_TRI_TOPO_INCLUDE

#ifdef __cplusplus
#define FEM_CPP_EXTERN extern "C"
#else
#define FEM_CPP_EXTERN  
#endif


/*----------------- Globally accessible function prototypes -----------------*/

                              /* =========================================== */
                              /* === FEM_clTriTopoCleanUp: cleans up tri     */
                              /* === mesh based on topology alone.           */
FEM_CPP_EXTERN INT FEM_clTriTopoCleanUp (
   INT anum,                 /* area to clean up                             */
   NODELIST_OBJ obj_nlist,   /* node list                                    */
   EDGELIST_OBJ obj_edlist,  /* edge list                                    */
   FACELIST_OBJ obj_flist,   /* face list                                    */
   FEM_BOOLEAN midnodes,     /* TRUE if elements are quadratic               */
   INT shape,                /* 3 for tri; 4 for quad/tri                    */
   INT maxloop  );           /* max number of cleanup iterations             */

#endif

