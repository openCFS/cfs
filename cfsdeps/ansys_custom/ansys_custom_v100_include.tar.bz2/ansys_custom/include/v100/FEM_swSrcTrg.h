/* sid 50.1 copy of FEM_swSrcTrg.h last changed by upd111 on 2004/11/04 18:32:26 */
/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 1999 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_swSrcTrg.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_swSrcTrg.h
 *  header file for FEM_swSrcTrg.c
 *
 */
#ifndef FEM_SWSRCTRG_INCLUDE
#define FEM_SWSRCTRG_INCLUDE

class VOLMSHDAT_TYP;
typedef class VOLMSHDAT_TYP  *VOLMSHDAT_PTYP;
/*----------------- Globally datatypes --------------------------------------*/

typedef struct SRCTRG_TYPE {
   AREA_PTYP src;
   AREA_PTYP trg;
   FEM_BOOLEAN axis_sweep;
} SRCTRG_TYPE;

/*----------------- Globally accessible function prototypes -----------------*/

                               /* =========================================== */
                               /* === FEM_swFindSrcTrg: Determine which areas */
                               /* === on a volume are the source and target   */
                               /* === areas, unless it is already decided.    */
                               /* === Verify that the volume can be swept     */
                               /* === with them also.                         */
                               /* === Return: EXIT_SUCCESS or EXIT_FAILURE    */
                               /* =========================================== */
INT FEM_swFindSrcTrg(
   MODEL_PTYP model,           /* (IN)  The model the volume is in we want to  sweep.  */   
   VOLMSHDAT_PTYP p_voldata,   /* (IN)  The volume we want to sweep.          */
   INT *num_matches,           /* (IN)  1 if user specified a src and trg     */
                               /*       and/or stored them in a_srctrg[0].    */
                               /*       Otherwise 0                           */
                               /* (OUT) number of possible src/trg            */
                               /*       combinations.  i.e. length of         */
                               /*       a_srctrg, at most 3.                  */
   SRCTRG_TYPE a_srctrg[3] );  /* (IN)  User specified source and target areas*/
                               /*       stored in a_srctrg[0]                 */
                               /* (OUT) Valid possible src/trg combinations.  */
                               /*       If the user specified a combination,  */
                               /*       then no other combinations will be    */
                               /*       checked                               */
                               /* =========================================== */

#endif

