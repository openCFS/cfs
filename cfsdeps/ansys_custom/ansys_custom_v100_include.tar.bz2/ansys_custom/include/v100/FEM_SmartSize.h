/* sid 50.1 copy of FEM_SmartSize.h last changed by upd111 on 2004/11/04 18:29:54 */
/*  FEM_SmartSize.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */

/* *** ansys(r) copyright(c) 2000
 * *** ansys, inc.
 */

/*
 *  FEM_SmartSize.h
 *  header file for FEM_SmartSize.cpp
 *
 */

#ifndef FEM_SMARTSIZE_H
#define FEM_SMARTSIZE_H

/* allowable element shapes */
#define _OTHER_     -1
#define _NOMESH_     0
#define _POINT_      1
#define _LINE_       2
#define _TRIANGLE_   3
#define _QUAD_       4
#define _QDTRI_      5
#define _TETRA_      6
#define _BRICK_      7
#define _BKTET_      8

#ifdef __cplusplus
extern "C" {
#endif
                        /*======================================================
                         * === Function: FEM_SmartSize                      
                         * === Description: main interface for smart sizing 
                         * ===              component - sets up the geometry
                         * ===              object model
                         * === Return: EXIT_SUCCESS or EXIT_FAILURE
                         *====================================================*/
INT FEM_SmartSize (
   INT num_vols,        /* (IN) number of volumes to smart size (can be 0)    */
   INT *a_vols,         /* (IN) array of volume topo ids                      */
   INT *a_vshape,       /* (IN)  The element shapes that each volume can have */
                        /*       This array is parallel to a_vols.            */
                        /*         0: Volume must be tet meshed.              */
                        /*         1: Volume can be either hex or tet meshed. */
                        /*         2: Volume must be hex meshed.              */   
   INT *a_vmid,         /* (IN) array of mid node information for each volume */
                        /*       This array is parallel to a_vols.            */
                        /*         0: No midnodes are needed.                 */
                        /*         1: Midnodes are needed, but can be dropped */
                        /*            to avoid linear/quadratic               */
                        /*            incompatibilities. Midnodes should be   */
                        /*            projected to geometry.                  */
                        /*        -1: Midnodes are needed, but can be dropped */
                        /*            to avoid linear/quadratic               */
                        /*            incompatibilities. Midnodes should not  */
                        /*            be projected to geometry.               */
                        /*         2: Midnodes are needed, but cannot be ever */
                        /*            dropped.  Midnodes should be            */
                        /*            projected to geometry.                  */
                        /*        -2: Midnodes are needed, but cannot be ever */
                        /*            dropped.  Midnodes should not be        */
                        /*            projected to geometry.                  */

   INT num_areas,       /* (IN) number of areas to smart size (can be 0)      */
                        /*      (these include only areas that are in addition*/
                        /*       to those attached to volumes in a_vols)      */
   INT *a_areas,        /* (IN) array of area topo ids                        */
   INT *a_ashape,       /* (IN)  The element shapes that each area can have   */
                        /*       This array is parallel to a_areas.           */
                        /*         0: Area must be triangle meshed.           */
                        /*         1: Area can be either tri or quad meshed.  */
                        /*         2: Area must be quad meshed.               */   
   INT *a_amid,         /* (IN) array of mid node information for each area   */
                        /*       This array is parallel to a_areas.           */
                        /*         same flags as for a_vmid                   */
   INT defaultshape,    /* (IN) default shape for meshing                     */
   INT debug,           /* (IN) the debug flag                                */
   MESH_OBJ *p_obj_mesh ); /* (OUT) return the mesh object - consisting of    */
                        /*          nodes and edges only                      */

/* === Macros for setting smart sizing parameters === */

/* ========================================================================== */
/* === Variable: fg_smrt_level                                                */
/* === Description: Smart size level (1-10). 1 = finest, 10 = coarsest        */
/* ========================================================================== */
#define SMRT_LEVEL 6
extern INT fg_smrt_level;
#define FEM_smSetLevel_C( level )\
         fg_smrt_level = level;
#define FEM_smLevel_C( ) fg_smrt_level

/* ========================================================================== */
/* === Variable: fg_smrt_mxiter                                               */
/* === Description: Smart size maximum number of iterations (cfprp7.inc)      */
/* ========================================================================== */
#define SMRT_MXITER 4
extern INT fg_smrt_mxiter;
#define FEM_smSetMaxIter_C( mxiter )\
         fg_smrt_mxiter = mxiter;
#define FEM_smMaxIter_C( ) fg_smrt_mxiter

/* ========================================================================== */
/* === Variable: fg_smrt_elsize                                               */
/* === Description: User specified guiding max element size                   */
/* ========================================================================== */
#define SMRT_ELSIZE 0.0e0
extern DOUBLE fg_smrt_elsize;
#define FEM_smSetElSize_C( elsize )\
         fg_smrt_elsize = (DOUBLE)elsize;
#define FEM_smElSize_C( ) fg_smrt_elsize

/* ========================================================================== */
/* === Variable: fg_smrt_fac                                                  */
/* === Description: scale factor used in smart sizing (see cfprp7.inc)        */
/* ========================================================================== */
#define SMRT_FAC 0.0e0
extern DOUBLE fg_smrt_fac;
#define FEM_smSetFac_C( fac )\
         fg_smrt_fac = (DOUBLE)fac;
#define FEM_smFac_C( ) fg_smrt_fac

/* ========================================================================== */
/* === Variable: fg_smrt_sfac                                                 */
/* === Description: This value is a factor used to compute an element size    */
/* ===              for SmartSizing when no default size is specified.        */
/* ===              (see mesh_tol.inc dp_mesh(31)                             */
/* ========================================================================== */
#define SMRT_SFAC 0.2e0
extern DOUBLE fg_smrt_sfac;
#define FEM_smSetSFac_C( sfac )\
         fg_smrt_sfac = (DOUBLE)sfac;
#define FEM_smSFac_C( ) fg_smrt_sfac

/* ========================================================================== */
/* === Variable: fg_smrt_maxEsize                                             */
/* === Description: Actual maximum element size defined by smart sizing       */
/* ===              (see cfprp7.inc)                                          */
/* ========================================================================== */
#define SMRT_MAXESIZE 0.0e0
extern DOUBLE fg_smrt_maxEsize;
#define FEM_smSetMaxEsize_C( max_esize )\
         fg_smrt_maxEsize = (DOUBLE)max_esize;
#define FEM_smMaxEsize_C( ) fg_smrt_maxEsize

/* ========================================================================== */
/* === Variable: fg_smrt_minEsize                                             */
/* === Description: Actual miminmum element size defined by smart sizing      */
/* ===              (see cfprp7.inc)                                          */
/* ========================================================================== */
#define SMRT_MINESIZE 0.0e0
extern DOUBLE fg_smrt_minEsize;
#define FEM_smSetMinEsize_C( min_esize )\
         fg_smrt_minEsize = (DOUBLE)min_esize;
#define FEM_smMinEsize_C( ) fg_smrt_minEsize

/* ========================================================================== */
/* === Variable: fg_smrt_smlang                                               */
/* === Description: Small angle coarsening flag                               */
/* ===              (mesh_tol.inc int_mesh(25)) (MOPT,TSAC)                   */
/* ========================================================================== */
#define SMRT_SMLANG 1
extern INT fg_smrt_smlang;
#define FEM_smSetSmlAng_C( smlang )\
         fg_smrt_smlang = (INT)smlang;
#define FEM_smSmlAng_C( ) fg_smrt_smlang

/* ========================================================================== */
/* === Variable: fg_smrt_quadfac                                              */
/* === Description:  Quad scale factor used in Smart Sizing                   */
/* ===              (mesh_tol.inc dp_mesh(22)) (MOPT,QFAC)                    */
/* ========================================================================== */
#define SMRT_QUADFAC 0.7071
extern DOUBLE fg_smrt_quadfac;
#define FEM_smSetQuadFac_C( quadfac )\
         fg_smrt_quadfac = (DOUBLE)quadfac;
#define FEM_smQuadFac_C( ) fg_smrt_quadfac

/* ========================================================================== */
/* === Variable: fg_smrt_dsmnes                                               */
/* === Description:  Minimum edge length as defined by Ansys DESIZE command   */
/* ===              (cfprp7.inc)                                              */
/* ========================================================================== */
#define SMRT_DSMNES 0.0e0
extern DOUBLE fg_smrt_dsmnes;
#define FEM_smSetDsmnes_C( dsmnes )\
         fg_smrt_dsmnes = (DOUBLE)dsmnes;
#define FEM_smDsmnes_C( ) fg_smrt_dsmne

/* ========================================================================== */
/* === Variable: fg_smrt_minesizefac                                          */
/* === Description:  This value is a factor used to compute a minimum element */ 
/* ===        size for smart sizing when no minimum global size is specified. */
/* ===        (mesh_tol.inc dp_mesh(32))                                      */
/* ========================================================================== */
#define SMRT_MINESIZEFAC 0.06666667e0
extern DOUBLE fg_smrt_minesizefac;
#define FEM_smSetMinEsizeFac_C( minesizefac )\
         fg_smrt_minesizefac = (DOUBLE)minesizefac;
#define FEM_smMinEsizeFac_C( ) fg_smrt_minesizefac

/* ========================================================================== */
/* === Variable: fg_smrt_gratio                                               */
/* === Description:  Smart sizing growth ratio                                */ 
/* ===        (cfprp7.inc)                                                    */
/* ========================================================================== */
#define SMRT_GRATIO 1.5e0
extern DOUBLE fg_smrt_gratio;
#define FEM_smSetGRatio_C( gratio )\
         fg_smrt_gratio = (DOUBLE)gratio;
#define FEM_smGRatio_C( ) fg_smrt_gratio

/* ========================================================================== */
/* === Variable: fg_smrt_linecurv                                             */
/* === Description:  Toggle line curvature checking in SmartSizing            */ 
/* ===        (mesh_tol.inc int_mesh(19) MOPT,TCUR)                           */
/* ========================================================================== */
#define SMRT_LINECURV 1
extern INT fg_smrt_linecurv;
#define FEM_smSetLineCurv_C( linecurv )\
         fg_smrt_linecurv = (INT)linecurv;
#define FEM_smLineCurv_C( ) fg_smrt_linecurv

/* ========================================================================== */
/* === Variable: fg_smrt_proximity                                            */
/* === Description:  Toggle line proximity checking in SmartSizing            */ 
/* ===        (mesh_tol.inc int_mesh(20) MOPT,TPRX)                           */
/* ========================================================================== */
#define SMRT_PROXIMITY 1
extern INT fg_smrt_proximity;
#define FEM_smSetProximity_C( proximity )\
         fg_smrt_proximity = (INT)proximity;
#define FEM_smProximity_C( ) fg_smrt_proximity

/* ========================================================================== */
/* === Variable: fg_smrt_surfcurv                                             */
/* === Description:  Toggle surface curvature checking in SmartSizing         */ 
/* ===        (mesh_tol.inc int_mesh(27) MOPT,TSCU)                           */
/* ========================================================================== */
#define SMRT_SURFCURV 1
extern INT fg_smrt_surfcurv;
#define FEM_smSetSurfCurv_C( surfcurv )\
         fg_smrt_surfcurv = (INT)surfcurv;
#define FEM_smSurfCurv_C( ) fg_smrt_surfcurv

/* ========================================================================== */
/* === Variable: fg_smrt_largecurv                                            */
/* === Description:  Toggle large curvature coarsening in SmartSizing         */
/* ===        (mesh_tol.inc dp_mesh(32) MOPT,TLCC)                            */
/* ========================================================================== */
#define SMRT_LARGECURV 1
extern INT fg_smrt_largecurv;
#define FEM_smSetLargeCurv_C( largecurv )\
         fg_smrt_largecurv = (INT)largecurv;
#define FEM_smLargeCurv_C( ) fg_smrt_largecurv

/* ========================================================================== */
/* === Variable: fg_smrt_maxspanangle                                         */
/* === Description:  Set the absolute maximum span angle for smart sizing.    */
/* ===        That is when small hole coarsening (formerly referred to as     */
/* ===        pseudo-small feature suppression) is active, what is the largest*/ 
/* ===        angle that we will allow, so as to make larger element sizes    */
/* ===        around tiny holes. (mesh_tol.inc dp_mesh(28) MOPT,MXAN)         */
/* ========================================================================== */
#define SMRT_MAXSPANANGLE 45.0e0
extern DOUBLE fg_smrt_maxspanangle;
#define FEM_smSetMaxSpanAngle_C( maxspanangle )\
         fg_smrt_maxspanangle = (DOUBLE)maxspanangle;
#define FEM_smMaxSpanAngle_C( ) fg_smrt_maxspanangle

/* ========================================================================== */
/* === Variable: fg_smrt_mxang_linear                                         */
/* === Description:  max spanning angle for linear elements                   */
/* ===         (cfprp7.inc  smrt_mxang(1))  SMRTSIZE,,,,,ANGL,                */
/* ========================================================================== */
#define SMRT_MXANG_LINEAR 22.5e0
extern DOUBLE fg_smrt_mxang_linear;
#define FEM_smSetMxangLinear_C( mxang_linear )\
         fg_smrt_mxang_linear = (DOUBLE)mxang_linear;
#define FEM_smMxangLinear_C( ) fg_smrt_mxang_linear

/* ========================================================================== */
/* === Variable: fg_smrt_mxang_quadratic                                      */
/* === Description:  max spanning angle for quadratic elements                */
/* ===         (cfprp7.inc  smrt_mxang(2))  SMRTSIZE,,,,,,ANGH                */
/* ========================================================================== */
#define SMRT_MXANG_QUADRATIC 30.0e0
extern DOUBLE fg_smrt_mxang_quadratic;
#define FEM_smSetMxangQuadratic_C( mxang_quadratic )\
         fg_smrt_mxang_quadratic = (DOUBLE)mxang_quadratic;
#define FEM_smMxangQuadratic_C( ) fg_smrt_mxang_quadratic

/* ========================================================================== */
/* === Variable: fg_smrt_maxCurv                                              */
/* === Description:  The maximum curvature that was computed while in smart   */ 
/* ===               sizing                                                   */
/* ===        (cfprp7.inc)                                                    */
/* ========================================================================== */
#define SMRT_MAXCURV 0.0e0
extern DOUBLE fg_smrt_maxCurv;
#define FEM_smSetMaxCurv_C( maxCurv )\
         fg_smrt_maxCurv = (DOUBLE)maxCurv;
#define FEM_smMaxCurv_C( ) fg_smrt_maxCurv

/* ========================================================================== */
/* === Variable: fg_smrt_LCCRatio                                             */
/* === Description:  SmartSize Lage Curvature Coarsening Ratio                */ 
/* ===        (mesh_tol.inc  dp_mesh(23)  MOPT,LCCR)                          */
/* ========================================================================== */
#define SMRT_LCCRATIO 10.0e0
extern DOUBLE fg_smrt_LCCRatio;
#define FEM_smSetLCCRatio_C( LCCRatio )\
         fg_smrt_LCCRatio = (DOUBLE)LCCRatio;
#define FEM_smLCCRatio_C( ) fg_smrt_LCCRatio

/* ========================================================================== */
/* === Variable: fg_smrt_trat                                                 */
/* === Description:  When small hole coarsening is on (formerly refered to as */
/* ===        pseudo-small hole coarsening), what is the size ratio threshold */
/* ===        at which we need to start increasing sizes by increasing the    */
/* ===        allowable spanned angle.                                        */
/* ===        (mesh_tol.inc  dp_mesh(29)  MOPT,TRAT)                          */
/* ========================================================================== */
#define SMRT_TRAT 5.0e0
extern DOUBLE fg_smrt_trat;
#define FEM_smSetThreshRatio_C( trat )\
         fg_smrt_trat = (DOUBLE)trat;
#define FEM_smThreshRatio_C( ) fg_smrt_trat

/* ========================================================================== */
/* === Variable: fg_smrt_mxrt                                                 */
/* === Description:   When small hole coarsening is on (formerly refered to as*/
/* ===        pseudo-small hole coarsening), what is the size ratio threshold */
/* ===        at which we set the size to the maximum allowable spanned angle.*/
/* ===        (mesh_tol.inc  dp_mesh(30)  MOPT,MXRT)                          */
/* ========================================================================== */
#define SMRT_MXRT 35.0e0
extern DOUBLE fg_smrt_mxrt;
#define FEM_smSetMaxRatio_C( mxrt )\
         fg_smrt_mxrt = (DOUBLE)mxrt;
#define FEM_smMaxRatio_C( ) fg_smrt_mxrt

/* ========================================================================== */
/* === Variable: fg_smrt_tshc                                                 */
/* === Description:   Toggle small hole coarsening feature suppression        */                        
/* ===        (mesh_tol.inc  int_mesh(23)  MOPT,TSHC)                         */
/* ========================================================================== */
#define SMRT_TSHC 1
extern INT fg_smrt_tshc;
#define FEM_smSetSmallHoleCoarsening_C( tshc )\
         fg_smrt_tshc = (INT)tshc;
#define FEM_smSmallHoleCoarsening_C( ) fg_smrt_tshc

#ifdef __cplusplus
}
#endif
#endif

