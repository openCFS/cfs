/* sid 50.1 copy of DrawDebug.h last changed by upd111 on 2005/06/04 13:17:23 */

/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 2000 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  DrawDebug.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  DrawDebug.h
 *  header file for tess_info.c
 *
 */

/*----------------- Globally accessible structure types     -----------------*/

/*----------------- Globally accessible function prototypes --------------*/

/* (1)-------------------------------------------------------------*/

#if defined(RS6000_SYS) || defined(HP32_SYS)

/* === C functions called from FORTRAN */

/* === FORTRAN subroutines called from C */

#define d2edge_        d2edge

#endif

/* (2)-------------------------------------------------------------*/

#if    defined(WATCOMC_SYS) \
    || defined(PCWINNT_SYS)
/* === C functions called from FORTRAN */

/* === FORTRAN subroutines called from C */

#define d2edge_         D2EDGE

#endif

/* (3)-------------------------------------------------------------*/
#if defined(WATCOMC_SYS)

/* === C functions called from FORTRAN */

/* === FORTRAN subroutines called from C */
#pragma aux D2EDGE "^";

#endif

/* (4)-------------------------------------------------------------*/
/*
 * *** FUNCTION RETURN TYPE DECLARATION
 */

#if !defined(PCWINNT_SYS)

/* === C functions called from FORTRAN */

/* === FORTRAN subroutines called from C */
   INT    d2edge_();

/* (5)-------------------------------------------------------------*/
#else

/* === C functions called from FORTRAN */

/* === FORTRAN subroutines called from C */
   INT    CALLTYP d2edge_( DOUBLE *, DOUBLE *, INT * );

#endif
