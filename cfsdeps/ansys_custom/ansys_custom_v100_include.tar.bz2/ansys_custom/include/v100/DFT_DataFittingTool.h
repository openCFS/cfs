/* sid 50.1 copy of DFT_DataFittingTool.h last changed by upd111 on 2005/06/04 13:20:36 */
////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         Copyright (C) 2001 ANSYS Inc.  All Rights Reserved             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: DFT_DataFittingTool.h $
// $Revision$ 7.0
// $Date$ March 28 2002
// $Author$ rjayasee/jlo
//
// Decription :
//
//	This is the API for all datafitting tools
//////////////////////////////////////////////////////////////////////////////

#if !defined( DFT_DATAFITTINGTOOL_H )
#define DFT_DATAFITTINGTOOL_H


#include "MAT_ConstitutiveFunction.h"

class MAT_ExperimentalDataSet ;
struct  MAT_CFAttribute ;

class DFT_DataFittingTool
{

public:

    DFT_DataFittingTool();
    //Constructor

    bool Fit
        ( vector<MAT_CFAttribute*> const& oAttributeList,
          MAT_ConstitutiveFunction* pConsFuncPtr ) ;
    //R-bool
    //R-IF the MaterialID or the oConsFuncName or requred Exp does 
    //R-not exist, this function returns false
    //I oAttributeList
    //I-List of Solution Parameters
    //IO-oConsFunName
    //IO-Name of the Constitutive Function ( eq mooney... )
    //F-Generated Material Parameters from Experimental Data              

    static bool GaussJordan( double **pEqnLHS,
                             INT iNumRowLHS,
                             double **pEqnRHS,
                             INT iNumColRHS ) ;
    //R- bool if the function was successful
    //I pEqnLHS
    //I-A in A*X = B
    //I iNumRowLHS
    //I-Number of Qows
    //I pEqnRHS
    //I-B in AX = B
    //I iNumColRHS
    //- Gauss-Jordan Method for solving linear equation

    static bool Invert( double const ** pMatrix, 
                        double** pMatrixInverted,
                        INT iSize ) ;
    //R- bool if the function was successful
    //I pMatrix
    //I-Pointer to Matrix to be Transposed
    //I pMatrixTrans
    //I-Resulting transposed matrix
    //I iNumRow
    //I-Number of Rows
    //I iNumCol
    //I-Number of Columns
    //- Function to Transpose a Matrix
    
    static bool GaussElimination
            ( double** pLHSMatrix, 
              double** pRHSMatrix, 
              INT iNumVariables,
              double** pResultMatrix ) ;
    //R-bool
    //R-false if it cannot be solved
    //I-pLHSMatrix
    //I-Left Hand Side Matrix of the Eqaution
    //I-pRHSMatrix
    //I-Right Hand Ride Matrix of the Equation
    //I-iNumVariables
    //I-Number of Variables
    //I pResultMatrix
    //I-Result N*1 Matrix
    //I- A*X=B
    //I- A---pLHSMatrix (N*N)
    //I- B---pRHSMatrix (N*1)
    //I- X---pResultMatrix (N*1)

    virtual ~DFT_DataFittingTool();
    //F-Destructor

private:

};

#endif // !defined(DFT_DATAFITTINGTOOL_H)
