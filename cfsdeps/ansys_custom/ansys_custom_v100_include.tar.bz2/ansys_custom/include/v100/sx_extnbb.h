/* sid 50.1 copy of sx_extnbb.h last changed by upd111 on 2005/06/04 13:23:07 */
/* CADOE */
/**
 *	extnbb.h -- Fonctions d'interface nbb /va
 *  
 * |Version: $Id$
 *
 *   
 * HISTORY
 *   
 *   09/25/00 10:39 <       Brian Jantzen> Rel:ms8m1    SCCA:79107  Delta:81.2
 *   
 *   02/28/00 07:49 <       Brian Jantzen> Rel:ms8      SCCA:69955  Delta:8.4
 *   
 *   01/31/00 15:39 <       Brian Jantzen> Rel:ms8      SCCA:67206  Delta:8.3
 *   
 *   01/05/00 14:54 <        Marc Gadbois> Rel:ms8      SCCA:64687  Delta:8.2
 *   
 **/


#ifndef __EXTNBB_X_DEJA_INCLUS__
#define __EXTNBB_X_DEJA_INCLUS__ 1


#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */


#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif	 /* __EXTNBB_X_DEJA_INCLUS__ */
