/* sid 50.1 copy of fem_spTag.h last changed by upd111 on 2004/11/04 18:33:20 */
/*  fem_spTag.h */
/* 
 * *** ansys(r) copyright(c) 1999
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  fem_spTag.h
 *  Prototypes and macros for surface proximity refinement
 *
 */

#ifndef FEM_SPTAG_____H
#define FEM_SPTAG_____H

                          /* ================================================ */
                          /* === FEM_spTagNodesForRefinement: Find and tag    */
                          /* === the nodes that need be refined               */
                          /* === Return: EXIT_FAILURE or EXIT_SUCCESS         */
INT FEM_spTagNodesForRefinement (
   NODELIST_OBJ obj_nodelist, /* (IN)  node list                              */
   FEM_BOOLEAN firsttime,     /* (IN)  TRUE if called for first iteraion      */
   RANGETREE_TYP *ps_rtree,   /* (IN)  range tree containing the rectangles   */
                              /*       that are used in intersection calcs.   */
   DOUBLE growth_ratio,       /* (IN)  allowable growth ratio                 */
   DOUBLE minesize,           /* (IN)  minimum size for element edges         */
   INT percent,               /* (IN)  percent complete for abort window      */
   VERTEXLIST_TYP **ps_vlist, /* (OUT) list of nodes marked for refinement.   */
   INT *num_markednodes,      /* (OUT) number of marked nodes (i.e. length    */
                              /*       of ps_vlist)                           */
   INT *abort  );             /* (OUT) !0 if user requested abort.            */

#endif

