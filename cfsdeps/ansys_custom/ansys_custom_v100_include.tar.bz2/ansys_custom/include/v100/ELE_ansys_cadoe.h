/* sid 50.1 copy of ELE_ansys_cadoe.h last changed by upd111 on 2005/06/04 13:21:27 */
/* ELE_ansys_cadoe.h CADOE  */
#ifndef __eleansyscadoeh__
#define __eleansyscadoeh__ 1

#ifdef __cplusplus
extern "C" {
#endif

#ifndef __expmdbstructh__
#include "expmdb_struct.h"
#endif

extern T_statut ELE_convert_to_cadoe( T_Element *elem );
extern T_statut ELE_convert_to_ansys( T_Element *elem );

#ifdef __cplusplus
}
#endif


#endif
