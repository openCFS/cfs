/* sid 50.1 copy of PLM_lire_polym_exp.h last changed by smarguer on 2005/01/25 15:46:55 */
/* PLM_lire_polym_exp.h CADOE  */
/*
 * PLM_lire_polym_exp.h
 *
 * $Id$
 *   
 * HISTORY
 *   
 *   09/25/00 11:19 <       Brian Jantzen> Rel:ms8m1    SCCA:79107  Delta:81.4
 *   
 *   06/28/00 10:47 <       Brian Jantzen> Rel:ms8m1    SCCA:74542  Delta:81.3
 *   
 *   06/21/00 16:30 <       Brian Jantzen> Rel:ms8m1    SCCA:74307  Delta:81.2
 */

#ifndef __PLMlirepolymexph__
#define __PLMlirepolymexph__ 1

#ifndef __CBF_H
#include "cbf.h"
#endif

#ifdef __cplusplus
extern "C" {
#endif

extern void *cbf_mdb_lire_polycs_v5( FILE *, void **, T_statut * );
extern T_statut PLM_lire_polycs_v5( T_cbf *, T_Modele * );
extern T_statut PLM_lire_polym( T_cbf *, T_Modele * );
extern T_statut PLM_lire_polym_4 ( T_cbf *, T_Modele * );
extern T_statut PLM_lire_polym_expl( T_cbf *, T_Modele * );
extern T_statut PLM_lire_configs( T_cbf *, T_Modele * );

#ifdef __cplusplus
}
#endif

#endif
