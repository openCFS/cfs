/* sid 50.1 copy of Cconfig.h last changed by smarguer on 2005/01/25 15:46:49 */
/* CConfig.h CADOE  */
/*! \file CConfig.h

  \brief This header file defines the CConfig class.

  \author Gilles VENET &copy; CADOE

  \date January 2004
*/
#ifndef __cconfigh__ 
#define __cconfigh__ 1 

#include "CCadoePortable.h"
#include "CDesignSet.h"
#include "CParameterMgr.h"
#include "CParameter.h"

#include "m_matrix.h"

typedef struct __Modele T_Modele;

/*! \class CConfig CConfig.h
  \brief The CConfig class is used to contain model ADOMESH
  */
class CConfig
{
public:
	enum EcodeParam
	{
    ValMin = 1,
    ValMax,
    ValRef,
    ValPP
	};
	typedef map<string,EcodeParam> TypeParam;

	CConfig();
	~CConfig();

  int initialise ( void );

	int getId( void ) const { return _numero; }
	int getPartInitId( void ) const { return _partInitID; }
	int getPartTargetId( void ) const { return _partTargetID; }
	double getDeformation( void ) const { return _deformation; }
  EcodeParam getParameterCode( const string &pName="" ) const;
	double getParameterShape( const string &pName="" ) const;
  double getValParameter ( string nom ) const ;
  CDesignSet *getDesignSet ( ) { return _designset; }

	int setName( const string &name );
	void setValue( const string &name, const double val ) { _designset->setValue(name, val); }
	void setId( const int val ) { _numero = val; }
	void setPartInitId( const int val ) { _partInitID = val; }
	void setPartTargetId( const int val ) { _partTargetID = val; }
	void setDeformation( const double val ) { _deformation = val; }
  void setParameterCode ( const string &pName, const EcodeParam val ) { _code[pName] = val; }
  void setParameterShape ( const string &pName, const EcodeParam val ) { _shape[pName] = val; }
  string getParameterName( const int indice ) const ;
  int readConfig ( T_cbf *vaf, T_cbf_header  *tmph );


private:
	typedef map<string,double> ParamValues;

  int     	_numero;  	/* numero de la config */
  int 		_reduite;        /* Nombre de fois ou la config a deja ete reduite */
  bool      _a_traiter;    	/* signale config a traiter */
  bool  	_initialized;
  double        _deformation;    /* Deformation estimee de la config */
	ParamValues		_ref;	/* valeur de reference de la config */
  TypeParam    	_code; 		/* codes de valeur des parametres : VALMIN, VALMAX, VALREF */
  TypeParam    	_shape; 	/* codes de valeur des parametres : VALMIN, VALMAX, VALREF */
  void     *_support;       /* support geometrique de la configuration */
  void    *_res;           /* Maillage perturbe */
  void		*_geom;
  CDesignSet *_designset;
  int _partInitID;
  int _partTargetID;

};


#endif
