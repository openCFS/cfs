/* sid 50.1 copy of liste_exp.h last changed by upd111 on 2005/06/04 13:21:35 */
/* liste_exp.h CADOE  */
/**
 *  liste_exp.h - definitions, prototypes des fonctions de listes chainees
 *            s'appuyant sur les listes non typees de OAstd.
 *
 *   
 * HISTORY
 *   
 *   06/28/00 10:47 <       Brian Jantzen> Rel:ms8m1    SCCA:74542  Delta:81.3
 *   
 *   06/21/00 16:30 <       Brian Jantzen> Rel:ms8m1    SCCA:74307  Delta:81.2
 **/

/* $Id$ */


/* protection contre lecture multiple */
#ifndef __adolisteexph__ 
#define __adolisteexph__ 1 

#ifndef __expmdbstructh__
#include "expmdb_struct.h"
#endif

#include "liste_chainee.h"

#ifdef __cplusplus
extern "C" {
#endif

/* repere */
extern T_Repere *LCS_chercher( T_liste *, int, int, T_statut * );
extern T_Repere *LCS_chercher_numero( T_liste *, int, T_statut *);

  /* element */
extern T_statut LIE_ins_debut( T_liste **, T_Element * );
extern T_statut LIE_ins_fin_unique( T_liste **, T_Element *, T_booleen * );

/* noeud */
extern T_statut LIN_ins_debut( T_liste **, T_Noeud * );
extern T_statut LIN_ins_fin_unique( T_liste**, T_Noeud*, T_booleen* );
extern T_statut LIN_ins_fin( T_liste**, T_Noeud*);
extern void LIN_afficher_liste( T_liste*);

#ifdef __cplusplus
}
#endif

#endif

