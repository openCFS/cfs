/* sid 50.1 copy of ax_malloc.h last changed by upd111 on 2005/06/04 13:16:43 */
/* ANSI_C ax_malloc.h - ANSYS Geometry Interface: malloc & strings */

/*--------------------------------------------------------------------------*/
/* ansys(r) copyright(c) 2000 */
/* ansys, inc.                */
/*--------------------------------------------------------------------------*/

#ifndef __AX_MALLOC_H__  /* Include this file only once! */
#define __AX_MALLOC_H__ 

#ifdef __cplusplus
extern "C" {
#endif
  
/*--------------------------------------------------------------------------*/

/* Memory allocation wrapper (ax_malloc.c public) */

void *ax_malloc (size_t size);
void *ax_realloc (void *ptr, size_t size);
void  ax_free_f (void *ptr);

#define ax_free(P)    DoMacro {    ax_free_f (P); P = NULL; } EndMacro
#define ax_strfree(S) DoMacro { ax_strfree_f ((char *) S); S = NULL; } EndMacro

char *ax_strdup (const char *s1);
void  ax_strfree_f (char *s1);

void  ax_bzero (void *b, int length);
void  ax_bcopy (const void *src, void *dst, int length);

/*--------------------------------------------------------------------------*/

/* Internal strings etc. (ax_malloc.c internal) */

#define ax_STRLEN 256

#define ax_strcopy(TARG,A,STRG)           ax_strcopy_f (1, TARG, A, STRG)
#define ax_strcopy_no_blanks(TARG,A,STRG) ax_strcopy_f (0, TARG, A, STRG)

int ax_strcopy_f (int with_blanks, char *target, int a, const char *string);

/*--------------------------------------------------------------------------*/

#if defined(__cplusplus)
}
#endif

#endif  /* #ifdef __AX_MALLOC_H */
