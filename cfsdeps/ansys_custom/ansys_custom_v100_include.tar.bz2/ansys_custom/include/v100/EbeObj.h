/* sid 50.2 copy of EbeObj.h last changed by jrb on 2005/04/01 13:33:25 */


/****************************************************************
 global-level structure for Elem-by-Elem (MSAVE) code
 ****************************************************************/
struct globalEbe_str {            /* Name of the structure                                   */
  INT       tag;                  /* Tag for this instance of the Ebe structure              */
  INT       numElem;              /* Number of defined elements in this structure            */
  INT       numMats;              /* Number of defined material matrices in this structure   */
  INT       antype;               /* Analysis type                                           */
                                  /*     0 = static, structural analysis                     */
                                  /*     2 = modal analysis                                  */
  INT       sstif;                /* Stress stiffening effects turned ON (1) or OFF (0)      */
  INT       nlgeom;               /* Nonlinear geometry effects turned ON (1) or OFF (0)     */
  INT       lumpMass;             /* Lumped mass matrix flag turned ON (1) or OFF (0)        */
  INT       rotations;            /* Flag signifying if nodal rotations exist (1) or not (0) */
  ebeElem  *elemVec;              /* Array of element structures                             */
  ebeMats  *matsVec;              /* Array of material matrix structures                     */
};

#define ebeTag(ebe)                (ebe->tag)
#define ebeNumElem(ebe)            (ebe->numElem)
#define ebeNumMats(ebe)            (ebe->numMats)
#define ebeAntype(ebe)             (ebe->antype)
#define ebeSstif(ebe)              (ebe->sstif)
#define ebeNlgeom(ebe)             (ebe->nlgeom)
#define ebeLumpMass(ebe)           (ebe->lumpMass)
#define ebeRotations(ebe)          (ebe->rotations)

#define ebeElemPtr(ebe)            (ebe->elemVec)
#define ebeElemVec(ebe,i)          (ebe->elemVec+i)
#define ebeMatsPtr(ebe)            (ebe->matsVec)
#define ebeMatsVec(ebe,i)          (ebe->matsVec+i)



/******************************************************************
 element-level structure for Elem-by-Elem (MSAVE) code
 ******************************************************************/
struct ebeElem_str {    /* Name of the structure                                     */
  CHAR      numNodes;   /* Number of nodes for this element                          */
  SHORT     flag;       /* Implicit/explicit element assembly flag                   */
  INT       matNum;     /* Internal material matrix number                           */
  INT      *startLocs;  /* Array of starting locations for each node of this element */
  DOUBLE   *jacobians;  /* Array of jacobian inverse matrix values for this element  */
};

#define ebeElemNumNodes(eData)         (eData->numNodes)
#define ebeElemFlag(eData)             (eData->flag)
#define ebeElemMatNum(eData)           (eData->matNum)

#define ebeElemStartLocsPtr(eData)     (eData->startLocs)
#define ebeElemJacobiansPtr(eData)     (eData->jacobians)



/******************************************************************
 material-level structure for Elem-by-Elem (MSAVE) code
 ******************************************************************/
struct ebeMats_str {    /* Name of the structure                                   */
  DOUBLE    *matrix;    /* Array of material matrix values for this material/temp  */
};

#define ebeMatsMatrixPtr(mData)        (mData->matrix)






/*------------------------- C called from FORTRAN --------------------*/

#if defined(UPPERCASENOUNDER_SYS)

#define  createEbeObj              CREATEEBEOBJ
#define  createEbeMats             CREATEEBEMATS
#define  deleteEbeObj              DELETEEBEOBJ
#define  putEbeElemData            PUTEBEELEMDATA
#define  putEbeJacobians           PUTEBEJACOBIANS
#define  putEbeStartLocs           PUTEBESTARTLOCS
#define  putEbeMatNum              PUTEBEMATNUM
#define  putEbeMatsData            PUTEBEMATSDATA
#define  getEbeElemData            GETEBEELEMDATA
#define  getEbeStartLocs           GETEBESTARTLOCS
#define  getEbeFlag                GETEBEFLAG
#define  getEbeMatsData            GETEBEMATSDATA
#define  getEbeNumJacobians        GETEBENUMJACOBIANS
#define  getEbeNumNodes            GETEBENUMNODES
#define  writeEbeObj               WRITEEBEOBJ
#define  readEbeObj                READEBEOBJ
#define  dumpEbeObj                DUMPEBEOBJ 

#endif


#if defined(LOWERCASENOUNDER_SYS)

#define  createEbeObj              createebeobj
#define  createEbeMats             createebemats
#define  deleteEbeObj              deleteebeobj
#define  putEbeElemData            putebeelemdata
#define  putEbeJacobians           putebejacobians
#define  putEbeStartLocs           putebestartlocs
#define  putEbeMatNum              putebematnum
#define  putEbeMatsData            putebematsdata
#define  getEbeElemData            getebeelemdata
#define  getEbeStartLocs           getebestartlocs
#define  getEbeFlag                getebeflag
#define  getEbeMatsData            getebematsdata
#define  getEbeNumJacobians        getebenumjacobians
#define  getEbeNumNodes            getebenumnodes
#define  writeEbeObj               writeebeobj
#define  readEbeObj                readebeobj
#define  dumpEbeObj                dumpebeobj

#endif


#if defined(LOWERCASEUNDER_SYS)

#define  createEbeObj              createebeobj_
#define  createEbeMats             createebemats_
#define  deleteEbeObj              deleteebeobj_
#define  putEbeElemData            putebeelemdata_
#define  putEbeJacobians           putebejacobians_
#define  putEbeStartLocs           putebestartlocs_
#define  putEbeMatNum              putebematnum_
#define  putEbeMatsData            putebematsdata_
#define  getEbeElemData            getebeelemdata_
#define  getEbeStartLocs           getebestartlocs_
#define  getEbeFlag                getebeflag_
#define  getEbeMatsData            getebematsdata_
#define  getEbeNumJacobians        getebenumjacobians_
#define  getEbeNumNodes            getebenumnodes_
#define  writeEbeObj               writeebeobj_
#define  readEbeObj                readebeobj_
#define  dumpEbeObj                dumpebeobj_

#endif


/*------------------------------ Prototypes --------------------------*/

SUBROUTINE createEbeObj(INT*, INT*, DOUBLE*);
SUBROUTINE createEbeMats(INT*);
SUBROUTINE deleteEbeObj(void);
SUBROUTINE putEbeElemData(INT*, INT*, INT*, INT*, INT*, INT*, DOUBLE*);
SUBROUTINE putEbeJacobians(INT*, INT*, DOUBLE*);
SUBROUTINE putEbeStartLocs(INT*, INT*, INT*);
SUBROUTINE putEbeMatNum(INT*, INT*);
SUBROUTINE putEbeMatsData(INT*, INT*, DOUBLE*, DOUBLE*);
SUBROUTINE getEbeElemData(INT*, INT*, INT*, INT*, INT**, DOUBLE**);
INT* FUNCTION getEbeStartLocs(INT*);
INT  FUNCTION getEbeFlag(INT*);
SUBROUTINE getEbeMatsData(INT*, DOUBLE**);
SUBROUTINE getEbeNumJacobians(INT*, INT*, INT*);
SUBROUTINE getEbeNumNodes(INT*, INT*);
SUBROUTINE writeEbeObj(INT*);
SUBROUTINE readEbeObj(INT*);
SUBROUTINE dumpEbeObj(void);

