/* sid 50.1 copy of Domain.h last changed by upd111 on 2005/06/04 13:18:44 */

/* *** ansys(r) copyright(c) 2000
 * *** ansys, inc.
 */

#ifndef _DOMAIN_H_
#define _DOMAIN_H_

/*#include <complex.h>*/
/*#include "MyComplex.h"*/
#include <stdio.h>

#include "Element.h"
// #include <Element.d/State.h>
#include "Connectivity.h"
#include "resize_array.h"
// #include <Driver.d/FAcoustic.h>
// #include <Driver.d/OutputInfo.h>


class DofSetArray;
class ConstrainedDSA;
class NBSparseMatrix;
class DBSparseMatrix;
class DBComplexSparseMatrix;
class SkyMatrix;
class SkyMatrixC;
class Connectivity;
class CuCSparse;
class CuCComplexSparse;
class BLKSparseMatrix;
class SGISparseMatrix;
class SGISky;
class UFront;
class DynamMat;
class Vector;
class VectorSet;
class ComplexVector;
class FlExchanger;
class Rbm;
class Solver;
class ComplexSolver;
class SparseMatrix;
class PCGSolver;
class NonLinSkyMatrix;
class GeomState;
class IntFullM;
class ControlInterface;

// ... Structure used to store problem Operators buildSkyOps 
// ... i.e. Only a Solver is needed for a static problem
// ... and a SparseMatrix for Kuc 
struct AllOps {

 // Constructor
 AllOps() { sysSolver = 0; K = 0; M = 0; C = 0; Kuc = 0; M12 = 0; C12 = 0; }

 Solver       *sysSolver; // i.e. system Solver
 SparseMatrix *K;	  // i.e. stiffness matrix
 SparseMatrix *M;	  // i.e. mass matrix
 SparseMatrix *C;	  // i.e. damping matrix
 SparseMatrix *Kuc;	  // i.e. constrained to unconstrained stiffness

 // added these sparsematrices for dynamics upgrade!
 SparseMatrix *M12;	  // i.e. constrained to unconstrained mass matrix
 SparseMatrix *C12;	  // i.e. constrained to unconstrained damping matrix

};

// Structure to store discrete masses
struct DMassData {
 DMassData *next;
 int    node;	// node number of discrete mass
 int    dof;	// dof  number of discrete mass
 double diMass; // value of discrete mass
};

// Structure to store dof renumbering information
struct Renumber {
  int *order;
  int *renumb;  
};

// Element attribute structure
struct Attrib {
  int nele;
  int attr;
  int cmp_attr, cmp_frm;
};

// Coefficient Data class for composites
class CoefData {
      double c[6][6];
    public:
      void zero();
      void setCoef(int,int,double);
      double *values () { return (double *)c; }
};


struct SolverInfo {
   enum { Static, Dynamic, Modal, NonLinStatic, NonLinDynam, 
	  ArcLength, ConditionNumber, Helmholtz, TempDynamic, Top
          };
   enum { off, on } timers;
   int probType;
   int aeroFlag;
   int extrapFlag;
   int type;    // 0 == direct 1 == CG
   int subtype; // subtype and matrix storage
   int iterType;
   int precond; // preconditioner
   int maxit;
   int renum; // renumbering scheme
   double tol; 
   double tmax, dt, dtemp, alphaDamp, betaDamp;
   double alphaTemp;
   double newmarkBeta, newmarkGamma;
   int subspaceSize, nEig;

   double tolEig, tolJac;
   double trbm, tolsvd, tolzem;

   int rbmflg;

   double condNumTolerance;

   int massFlag;

   // SET AEROELASTIC ALGORITHM
   void setAero(int alg, int extr = 0) { aeroFlag = alg; extrapFlag = extr; }

   // SET CONDITION NUMBER TOLERANCE
   void setCondNumTol( double tol ) { condNumTolerance = tol; }

   // ... NON LINEAR SOLVER INFORMATION VARIABLES
   int updateK;         // number of times to update K in NL analysis
   int kryflg;          // Krylov correction flag
   int initflg;         // initialization flag
   int reorthoflg;      // full reorthogonalization flag
   int maxiter;         // maximum # of newton iterations
   double NLtolerance;  // newton iteration tolerance
   int maxVecStorage;   // maximum # of vectors to store
   double dlambda;      // delta lambda (used in arclength module)
   double maxLambda;    // maximum load step value to attain
   double lfactor;      // scaling factor in determining step size in the load
   int fitAlgShell;     // fit algorithm for shell elements
   int fitAlgBeam;      // fit algorithm for beam elements
   int gepsFlg;         // Geometric pre-stress flag
   int buckling;        // Buckling analysis flag
   int zeroInitialDisp; // flag to set initial disp to zero

   // Set Nonlinear values
   void setNLInfo(int _maxiter, double _NLtolerance, int _maxVecStorage, 
                  double _dlambda=1.0, double _lfactor = 10.0)
    { maxiter = _maxiter; NLtolerance = _NLtolerance; 
      fitAlgShell = 3; fitAlgBeam = 3; 
      maxVecStorage = _maxVecStorage; dlambda = _dlambda; lfactor = _lfactor; }

   void setNewton(int n)     { updateK    = n; }
   void setKrylov()          { kryflg     = 1; }
   void setInitialization()  { initflg    = 1; }
   void setReOrtho()         { reorthoflg = 1; }

   // SET DYNAMIC VALUE FUNCTIONS

   void setTimes(double _tmax, double _dt, double _dtemp)
    { tmax = _tmax; dt = _dt; dtemp = _dtemp; }

   // Set Rayleigh damping stiffness coefficient alpha
   // Set Rayleigh damping mass coefficient beta
   void setDamping(double beta, double alpha)
    { alphaDamp = alpha; betaDamp = beta; }

   // SET RENUMBERING SCHEME
   void setRenum(int _renum) { renum = _renum; }

   void setProbType(int pbt, double beta = 0.25, double gamma = 0.50)
    { probType = pbt; newmarkBeta = beta; newmarkGamma = gamma; }

   void setTempType(int pbt, double epsiln =0.5) {
      probType = pbt;
      alphaTemp = epsiln;
      if(alphaTemp<0.5){
       fprintf(stderr," ... WARNING: UNSTABLE EXPLICIT SCHEME ...\n");
       }
   }


   void setModalInfo(int _subspaceSize,int _nEig,double _tolEig,double _tolJac)
    { subspaceSize = _subspaceSize; nEig = _nEig; tolEig = _tolEig; 
      tolJac = _tolJac; }

   void setSolver(int _substype) { type = 0; subtype = _substype; }

   void setSolver(int _precond, double _tol,int _maxit,int _iterType=1,
                  int _subtype=3)
    { type = 1; precond = _precond; tol = _tol; maxit = _maxit; 
      iterType = _iterType; subtype = _subtype; }

   void setTrbm(double _tolsvd)
    { trbm = _tolsvd; rbmflg = 0; }

   void setGrbm(double _tolsvd, double _tolzem) 
    { tolsvd = _tolsvd; tolzem = _tolzem; rbmflg = 1; }

};


struct ControlInfo {
   FILE *checkfileptr;
   char *checkfile;
   int   numSets;
   char *nodeSetName;
   char *elemSetName;
   char *decomposition;
   FILE *decPtr;
   ControlInfo() { checkfile = "check"; nodeSetName = "nodes"; 
                   elemSetName = "elems"; decomposition = "DECOMPOSITION";
                   numSets = 1; decPtr = 0; checkfileptr = 0; }
};

// Control Law Information class, see Control.d/control.C
// to implement user defined control forces, user defined forces or
// user defined displacements

struct ControlLawInfo {
 char *fileName;
 char *routineName;
 int numSensor;
 BCond *sensor;
 int numActuator;
 BCond *actuator;

 // KHP: added to implement user defined displacements
 int numUserDisp;
 BCond *userDisp;

 // KHP: added to implement user defined forces
 int numUserForce;
 BCond *userForce;

 ControlLawInfo() { fileName = routineName = 0; }

};


// Element Frame Data structure
struct EFrameData {
    int elnum;
    EFrame frame;
    EFrameData *next;
};

class Domain {
  protected:

     Solver *solver;            // this domains solver

     int numnodes;		// number of nodes
     CoordSet &nodes;   	// All the nodes

     Elemset eset;      	// this domains set of elements
     int numele;		// number of elements
     Elemset packedEset;	// The set of compressed elements

     int numprops;		// number of properties
     StructProp *sProps;	// set of those properties

     int numDirichlet;		// number of dirichlet bc
     ResizeArrayBCondPtr dbc;    // set of those dirichlet bc

     int numNeuman;		// number of Neuman bc
     ResizeArrayBCondPtr nbc;    // set of Neuman bc

     int na, namax;		// number of attributes, max # of attributes
     Attrib* attrib;		// set of attributes

     EFrameData *firstEFData;   // Element frame data structure (beams)

     int ndof;			// Total number of dofs in the dsa
     DofSetArray *dsa;		// Dof set array
     ConstrainedDSA *c_dsa;	// Constrained dof set array
     Connectivity *allDOFs;     // all dof arrays for each node
     int maxNumDOFs; 		// maximum number of dofs an element has

     Connectivity *elemToNode, *nodeToElem, *nodeToNode;

     SolverInfo sinfo;		// solver information structure

     compStruct renumb;         // renumbered nodes per structural component

     FILE *outFile;

     // for computing stress results in function getStressStrain(...)
     Vector *stress;
     Vector *weight;
     Vector *elDisp;
     Vector *elstress;
     Vector *elweight;

    // Constructor
    Domain(Domain &, int nele, int *ele, int nnodes, int *nodes);
    Domain(int nnodes, int nele);

  public:
     Domain();

     // functions for controlling printing to screen
     void setVerbose() { outFile = stderr; }
     void setSilent()  { outFile = 0;      }
     void readInModes(char* modesFileName);

// moved these functions here to work on StaticProb class:
     void make_bc(int *bc, double   *bcx);
//     void make_bc(int *bc, DComplex *bcx);
     void makeAllDOFs();

/*
     void createKelArray(FullSquareMatrix *& kel);
     void createKelArray(FullSquareMatrix *& kel,FullSquareMatrix *& mel);
     void reBuild(int iteration, FullSquareMatrix *kel);
*/

// Functions to suport the parsing:
     int  addNode(int nd, double xyz[3]);
     int  addElem(int en, Element *ele);
     int  addElem(int en, int type, int nn, int *nodes);
     int  addMat(int,StructProp &);
     int  setAttrib(int,int,int = -1,int = -1);
     int  setFrame(int,double *);
     int  addCFrame(int,double *);
     int  setDirichlet(int,BCond *);
     int  setNeuman(int,BCond *);

     // int  setUSDF(int);

     void setControl(char *, char *, char *);
     void setUpData();

     SolverInfo  &solInfo() { return sinfo; }

// ... General build functions to replace the specialized build
// ... functions and allow us to reuse the code in each problem
// ... type (i.e. use makeSparseOps in statics, dynamics, eigen, etc.)
/*

     void buildOps(AllOps &ops, double Kcoef, double Mcoef, double Ccoef, 
			Rbm* rbm=0, FullSquareMatrix *kelArray=0);

     void makeSparseOps(AllOps &ops, double Kcoef, double Mcoef, 
			double Ccoef, SparseMatrix* mat, 
                        FullSquareMatrix *kelArray=0);

     void makeFrontalOps(AllOps &ops, double Kcoef, double Mcoef, double Ccoef,
                         Rbm *rbm=0, FullSquareMatrix *kelArray=0);

     DBSparseMatrix   *constructDBSparseMatrix();
     NBSparseMatrix   *constructNBSparseMatrix();
     CuCSparse        *constructCuCSparse();
     SkyMatrix        *constructSkyMatrix(Rbm *rbm);
     SGISky           *constructSGISkyMatrix(Rbm *rbm);
     PCGSolver        *constructPCGSolver(SparseMatrix *K, Rbm *rbm=0);
     NonLinSkyMatrix  *constructNonLinSkyMatrix(Rbm *rbm=0);
     UFront           *constructFrontal(int maxFrontSize, Rbm *rbm=0); 

     Rbm              *constructRbm(int problemType=0);
     Rbm              *constructRbm(IntFullM *);
     BLKSparseMatrix  *constructBLKSparseMatrix(Rbm *rbm = 0);
     SGISparseMatrix  *constructSGISparseMatrix(Rbm *rbm = 0);
     SGISparseMatrix  *constructSGISparseMatrix(int subNumber, Rbm *rbm = 0);

// Functions to implement solvers.
     DBComplexSparseMatrix *makeComplexSparseMatrix(SparseMatrix *&kuc);

// Complex routines for HelmHoltz problem
     SkyMatrixC * makeSkyComplexK(SparseMatrix  *& kuc);

     void buildRHSForce(Vector        &force, SparseMatrix *kuc=0 );

     void buildRHSForce(ComplexVector &force, SparseMatrix *kuc);

     void buildPressureForce(Vector &force);
     void buildGravityForce(Vector &force);

     void preProcessing();

     void computeExtForce(Vector &force, Vector &gf, double t, SparseMatrix*,
                          double *userDefineDisp = 0);

     int  probType() { return sinfo.probType; }

     double computeStabilityTimeStep(DynamMat&);

     void getElementForces(Vector &sol, double *bcx, int fileNumber,
                int forceIndex, double time = 0);
*/

// renumbering functions

     Renumber getRenumbering();

// Eigen solver

/*
     Solver *getSolver() { return solver; }


     void make_constrainedDSA(int *bc);
     ConstrainedDSA* make_c_dsa(int *bc);


// returns the number of dof
     int  numdof()   { return dsa ? dsa->size() : -1; }

// returns the number of unconstrained dof
     int  numUncon() { return c_dsa ? c_dsa->size() : dsa->size(); }

// returns a pointer to the dirichlet boundary condtions
     BCond* getDBC() { return dbc+0; }

// returns the number of dirichlet bc
     int  nDirichlet() { return numDirichlet; }

// returns the number of neumann bc
     int  nNeumann() { return numNeuman; }
*/

// returns the number of nodes
     int  numNodes() { return nodeToNode->csize(); }
     int  numNode()  { return numnodes; }

// returns the number of elements
     int  numElements() { return numele; }

// returns the packed element set (allows element numbering gaps)
     Elemset& getElementSet() { return packedEset; }
     Elemset& getInitESet() { return eset; }

// returns the maximum number of dofs per element
     int  maxNumDOF() { return maxNumDOFs; }

// returns a pointer to the Connectivity allDOFs
     Connectivity *getAllDOFs() { return allDOFs; }

     CoordSet& getNodes() { return nodes; }

     ConstrainedDSA * getCDSA() { return c_dsa; }
     DofSetArray *    getDSA()  { return dsa;   }

     void makeTopFile();

     friend class DecDomain;
     friend class DistrDomain;
     friend class MasterDomain;
};

#endif
