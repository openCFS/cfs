/* sid 50.1 copy of jacobien.h last changed by upd111 on 2005/06/04 13:21:35 */
/* jacobien.h CADOE  */
/*
 *   
 * HISTORY
 *   
 *   06/28/00 10:47 <       Brian Jantzen> Rel:ms8m1    SCCA:74542  Delta:81.3
 *   
 *   06/21/00 16:30 <       Brian Jantzen> Rel:ms8m1    SCCA:74307  Delta:81.2
*/
#ifndef __jacobienh__
#define __jacobienh__ 1


#ifdef __cplusplus
extern "C" {
#endif

#ifndef __expmdbstructh__
#include "expmdb_struct.h"
#endif

extern void jacobien_set_precision( double precision, double taille );
extern double ELE_jacobien( int, int, double *, double *, T_statut * );
extern double ELE_volume( int, int, double *, double *);
extern double jacobien_dkt ( double * );
extern void   ELE_gradient_volume( int, int, double *, double *, double jacobig[NB_NOEUD_MAX][DIM_MAX]);
extern double jacobien_pou ( double * );
#ifdef __cplusplus
}
#endif


#endif
