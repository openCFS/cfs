/* sid 50.2 copy of sx_edge_node.h last changed by smarguer on 2005/05/13 06:24:41 */
/* CADOE */
/*******************************************************************************
 *
 *   edge_node.h -- Constants and structures for mid-node stresses
 *              
 * 
 * |Module: solveur / interface
 *
 * |Description: Constants and structures for mid-node stresses
 *
 * |Includes:	
 *        
 * |Auteur: Jean-Daniel Beley
 *
 * |Creation: January 2003
 *
 * |Version: $Id$
 *
 * |Copyright:	Copyright(c) CADOE 2003
 *
 ******************************************************************************/
#ifndef __EDGE_NODE_H__
#define __EDGE_NODE_H__ 1

struct __edge_list;
struct __elem_edge;

typedef struct __edge_list T_edge_list;
typedef struct __elem_edge T_elem_edge;

#define MAX_EDGE_PER_ELEMENT 12
struct __edge_list {
  int element_type;
  int nb_edge;
  T_elem_edge *edge[12];
};

struct __elem_edge {
  int node;
  int code;
};

/* 
 * Parabolic quadrilateral
 */

#define PLANE183_VE_0 (1u<<1)+(1u<<2)
#define PLANE183_VE_1 (1u<<2)+(1u<<3)
#define PLANE183_VE_2 (1u<<3)+(1u<<4)
#define PLANE183_VE_3 (1u<<4)+(1u<<1)

static T_elem_edge S_plane183_e0 = { 4, PLANE183_VE_0 };
static T_elem_edge S_plane183_e1 = { 5, PLANE183_VE_1 };
static T_elem_edge S_plane183_e2 = { 6, PLANE183_VE_2 };
static T_elem_edge S_plane183_e3 = { 7, PLANE183_VE_3 };

static T_edge_list S_plane183_edges = { fxel_PLANE183, 4, &S_plane183_e0, &S_plane183_e1, &S_plane183_e2, &S_plane183_e3, 
					NULL, NULL, NULL, NULL,  NULL, NULL, NULL, NULL };
/* 
 * Parabolic Brick
 */

#define SOLID186_VE_0 (1u<<1)+(1u<<2)
#define SOLID186_VE_1 (1u<<2)+(1u<<3)
#define SOLID186_VE_2 (1u<<3)+(1u<<4)
#define SOLID186_VE_3 (1u<<4)+(1u<<1)

#define SOLID186_VE_4 (1u<<5)+(1u<<6)
#define SOLID186_VE_5 (1u<<6)+(1u<<7)
#define SOLID186_VE_6 (1u<<7)+(1u<<8)
#define SOLID186_VE_7 (1u<<8)+(1u<<5)

#define SOLID186_VE_8 (1u<<1)+(1u<<5)
#define SOLID186_VE_9 (1u<<2)+(1u<<6)
#define SOLID186_VE_10 (1u<<3)+(1u<<7)
#define SOLID186_VE_11 (1u<<4)+(1u<<8)

static T_elem_edge S_solid186_e0 = { 8,  SOLID186_VE_0 };
static T_elem_edge S_solid186_e1 = { 9,  SOLID186_VE_1 };
static T_elem_edge S_solid186_e2 = { 10, SOLID186_VE_2 };
static T_elem_edge S_solid186_e3 = { 11, SOLID186_VE_3 };

static T_elem_edge S_solid186_e4 = { 12, SOLID186_VE_4 };
static T_elem_edge S_solid186_e5 = { 13, SOLID186_VE_5 };
static T_elem_edge S_solid186_e6 = { 14, SOLID186_VE_6 };
static T_elem_edge S_solid186_e7 = { 15, SOLID186_VE_7 };

static T_elem_edge S_solid186_e8 = { 16, SOLID186_VE_8 };
static T_elem_edge S_solid186_e9 = { 17, SOLID186_VE_9 };
static T_elem_edge S_solid186_e10= { 18, SOLID186_VE_10 };
static T_elem_edge S_solid186_e11= { 19, SOLID186_VE_11 };

static T_edge_list S_solid186_edges = { fxel_SOLID186, 12, &S_solid186_e0, &S_solid186_e1, &S_solid186_e2, &S_solid186_e3, 
					&S_solid186_e4, &S_solid186_e5, &S_solid186_e6, &S_solid186_e7, 
					&S_solid186_e8, &S_solid186_e9, &S_solid186_e10,&S_solid186_e11};

/* 
 * Parabolic Beam 
 */
#define BEAM189_VE_0 (1u<<1)+(1u<<2)

static T_elem_edge S_beam189_e0 = { 2, BEAM189_VE_0 };
static T_edge_list S_beam189_edges = { fxel_BEAM189, 1, &S_beam189_e0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 
				       NULL, NULL, NULL, NULL};


/* 
 * Parabolic Tetraedron
 */

#define SOLID187_VE_0 (1u<<1)+(1u<<2)
#define SOLID187_VE_1 (1u<<2)+(1u<<3)
#define SOLID187_VE_2 (1u<<3)+(1u<<1)
#define SOLID187_VE_3 (1u<<1)+(1u<<4)
#define SOLID187_VE_4 (1u<<2)+(1u<<4)
#define SOLID187_VE_5 (1u<<3)+(1u<<4)

static T_elem_edge S_solid187_e0 = { 4,  SOLID187_VE_0 };
static T_elem_edge S_solid187_e1 = { 5,  SOLID187_VE_1 };
static T_elem_edge S_solid187_e2 = { 6,  SOLID187_VE_2 };
static T_elem_edge S_solid187_e3 = { 7,  SOLID187_VE_3 };
static T_elem_edge S_solid187_e4 = { 8,  SOLID187_VE_4 };
static T_elem_edge S_solid187_e5 = { 9,  SOLID187_VE_5 };

static T_edge_list S_solid187_edges = { fxel_SOLID187, 6, &S_solid187_e0, &S_solid187_e1, &S_solid187_e2, &S_solid187_e3, 
					&S_solid187_e4, &S_solid187_e5, NULL, NULL, NULL, NULL, NULL, NULL };

/*
 * Triangular Solid
 */

#define PLANE2_VE_0 (1u<<1)+(1u<<2)
#define PLANE2_VE_1 (1u<<2)+(1u<<3)
#define PLANE2_VE_2 (1u<<3)+(1u<<1)

static T_elem_edge S_plane_e0 = { 3,  PLANE2_VE_0 };
static T_elem_edge S_plane_e1 = { 4,  PLANE2_VE_1 };
static T_elem_edge S_plane_e2 = { 5,  PLANE2_VE_2 };

static T_edge_list S_plane2_edges = { fxel_PLANE2, 3, &S_plane_e0, &S_plane_e1, &S_plane_e2, NULL, NULL, NULL, NULL, NULL, 
				      NULL, NULL, NULL, NULL };


/* Corner nodes and Midside Nodes */
static int S_plane152_np_degenere[] = { 8,  1,1,1,1,0,0,1,0};
static int S_plane183_np[] = { 8,  1,1,1,1,0,0,0,0};
static int S_solid187_np[] = { 10, 1,1,1,1,0,0,0,0,0,0};
static int S_beam189_np[]  = { 8,  1,1,0};
static int S_plane2_np[]   = { 6,  1,1,1,0,0,0};

/* 186:                                         I,J,K,L, M,N,O,P, Q,R,S,T, U,V,W,X, Y,Z,A,B */
static int S_solid186_np[]		= { 20, 1,1,1,1, 1,1,1,1, 0,0,0,0, 0,0,0,0, 0,0,0,0};
static int S_solid186_np_tetra[]	= { 20, 1,1,1,1, 1,1,1,1, 0,0,1,0, 1,1,1,1, 0,0,0,0};
static int S_solid186_np_pyramid[]	= { 20, 1,1,1,1, 1,1,1,1, 0,0,0,0, 1,1,1,1, 0,0,0,0};
static int S_solid186_np_prism[]	= { 20, 1,1,1,1, 1,1,1,1, 0,0,1,0, 0,0,1,0, 0,0,0,0};


#endif
