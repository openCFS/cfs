/* sid 50.1 copy of fem_swBndRibs.h last changed by upd111 on 2004/11/04 18:33:24 */
/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 1999 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_swBndRibs.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_swBndRibs.h
 *  header file for FEM_swBndRibs.c
 *
 */
#ifndef FEM_SWBNDRIBS_INCLUDE
#define FEM_SWBNDRIBS_INCLUDE

/*----------------- Globally accessible data types --------------------------*/

/*----------------- Globally accessible variables ---------------------------*/

/*----------------- Globally accessible macros ------------------------------*/

                               /* =========================================== */
                               /* === FEM_swBndRibs: Given a                  */
                               /* === list of the boundary nodes on the       */
                               /* === source area, determine the              */
                               /* === cooresponding nodes on the target       */
                               /* === area, and if requested, store all of    */
                               /* === the rib nodes on the exterior of the    */
                               /* === sweepable volume.                       */
                               /* === Return: EXIT_SUCCESS or EXIT_FAILURE    */
                               /* =========================================== */

INT FEM_swBndRibs(
   VOL_PTYP obj_vol,           /* (IN)  The volume being swept.               */
   AREA_PTYP obj_sarea,        /* (IN)  the source area                       */
   AREA_PTYP obj_tarea,        /* (IN)  the target area                       */
   NODE_OBJ *aobj_bnd_nodes,/*(IN)array of boundary nodes on source_area*/
   INT num_bnd_nodes,          /* (IN)  length of aobj_bnd_nodes              */
   FEM_BOOLEAN store,          /* (IN)  TRUE if the rib nodes should be stored*/
   NODE_OBJ **aobj_trg_nodes) ;
                               /* =========================================== */
                               /* === FEM_swNextRibNode:  Get the next node   */
                               /* === of a given rib that originated from a   */
                               /* === corner node.  This routine must         */
                               /* === be called first with a node on the      */
                               /* === source area, then the next node up,     */
                               /* === instead of just for any random node on  */
                               /* === a rib.                                  */
                               /* === Return: EXIT_SUCCESS or EXIT_FAILURE    */
                               /* =========================================== */
INT FEM_swNextRibNode(
   NODE_OBJ obj_node,          /* (IN)  The node on the source area start     */
                               /*       starts the rib.                       */
   FEM_BOOLEAN firstnode,      /* (IN)  TRUE if obj_node is the first node on */
                               /*       this rib.                             */
   VOL_PTYP obj_vol,           /* (IN)  The volume we are tracing up.         */
   AREA_PTYP obj_sarea,        /* (IN)  The source area.                      */
   AREA_PTYP obj_tarea,        /* (IN)  The target area.                      */
   NODE_OBJ *obj_nextnode,     /* (OUT) the trg node cooresponding to obj_node*/
   FEM_BOOLEAN *lastnode );    /* (OUT) TRUE if obj_nextnode is the last node */
                               /*       on this rib.                          */

                               /* =========================================== */
                               /* === FEM_swNextRibMidnode: Get the next node */
                               /* === of a given rib that originated from a   */
                               /* === midnode.  This routine must             */
                               /* === be called first with a node on the      */
                               /* === source area, then the next node up,     */
                               /* === instead of just for any random node on  */
                               /* === a rib.                                  */
                               /* === Return: EXIT_SUCCESS or EXIT_FAILURE    */
                               /* =========================================== */
INT FEM_swNextRibMidnode(
   NODE_OBJ obj_node,          /* (IN)  The node on the source area start     */
                               /*       starts the rib.                       */
   FEM_BOOLEAN firstnode,      /* (IN)  TRUE if obj_node is the first node on */
                               /*       this rib.                             */
   VOL_PTYP obj_vol,           /* (IN)  The volume we are tracing up.         */
   AREA_PTYP obj_sarea,        /* (IN)  The source area.                      */
   AREA_PTYP obj_tarea,        /* (IN)  The target area.                      */
   NODE_OBJ *obj_nextnode,     /* (OUT) the trg node cooresponding to obj_node*/
   FEM_BOOLEAN *lastnode );    /* (OUT) TRUE if obj_nextnode is the last node */
                               /*       on this rib.                          */

#endif

