/* sid 50.1 copy of SxCadoeMsgTool.h last changed by smarguer on 2005/01/14 14:59:25 */
/*******************************************************************************
 *
 *   SxCadoeMsgTool.h  --- routines to initialize and reset the Cadoe MessageTool
 *               
 * |Module:  ANSYS
 *
 * |Description: 
 *
 * |Includes:	
 *        
 * |Auteur: Stephane MARGUERIN
 *
 * |Creation: Janvier 2005
 *
 * |Version: $Id$
 *
 * |Copyright:	Copyright(c)  2005
 *
 ********************************************************************************/
#ifndef __SXCADOEMSGTOOL_H__
#define __SXCADOEMSGTOOL_H__ 1

#if defined(LOWERCASENOUNDER_SYS)
#define SxEndCadoeMsgTool sxendcadoemsgtool
#endif

#if defined(UPPERCASENOUNDER_SYS)
#define SxEndCadoeMsgTool SXENDCADOEMSGTOOL
#endif

#if defined(LOWERCASEUNDER_SYS) 
#define SxEndCadoeMsgTool sxendcadoemsgtool_
#endif

#ifdef __cplusplus
extern "C" {

  extern int SxInitVerbosityAndScope(const string &nameOption, const string &valOption);

#endif
  
  extern int SxInitCadoeMsgTool( const char*, int );
  SUBROUTINE SxEndCadoeMsgTool( void );
  
#ifdef __cplusplus
}
#endif

#endif /* __SXCADOEMSGTOOL_H__ */
