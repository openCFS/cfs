/* sid 50.1 copy of FEM_reRetain.h last changed by upd111 on 2004/11/04 18:31:58 */
/*  FEM_reRetain.h */
/*
 * *** ansys(r) copyright(c) 1999
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_reRetain.h
 *
 */
#ifndef FEM_RERETAIN
#define FEM_RERETAIN

#include "FEM_cdbtypes.h"

                   /* ========================================================*/
                   /* === FEM_reMakeTrisEven: The mesh in the CDB is about to */
                   /* === be refined using TWO_REF. The user specified that   */
                   /* === we must retain quads in initially all-quad meshes.  */
                   /* === To do so, we must make sure that the number of      */
                   /* === triangles in each transition region in each area is */
                   /* === even so FEM_clTriangleCombine can combined them     */
                   /* === all. We must mark which elements need special       */
                   /* === treatment to ensure that all triangles are          */
                   /* === eliminated.  All that happens is that some quad     */
                   /* === faces get a property flag set: FACE_QUAD_RETAIN.    */
                   /* === If it is not possible to maintain quads, possible   */
                   /* === is returned as FALSE.                               */

INT FEM_reMakeTrisEven (
   FACELIST_OBJ obj_flist,
   EDGELIST_OBJ obj_edlist,
   INT retain,
   INT *possible  );
#endif

