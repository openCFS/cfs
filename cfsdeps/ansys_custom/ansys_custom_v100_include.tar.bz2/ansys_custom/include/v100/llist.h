/* sid 50.1 copy of llist.h last changed by upd111 on 2005/06/04 13:13:13 */
/* 
 * *** ansys(r) copyright(c) 2000
 * *** ansys, inc.
 */
#define LL_

#ifndef COMMON_
#include "common.h"
#endif

typedef struct LinkNodeInfo{
struct    LinkNodeInfo    *Next;
struct    LinkNodeInfo    *Previous;
    char    *Data;
}LinkNodeInfo, *LinkNode;

typedef struct LinkListInfo {
   LinkNode  Head;
   LinkNode  Tail;
}LinkListInfo, *LinkList;


extern LinkList ll_CreateLinkList(void);

extern ll_AddNodeToList(/* List, Node */);

extern LinkNode ll_ForEachNode(register LinkList List, register char **Data, register LinkNode *StateNode);

extern INT32 ll_PushTail(LinkList List, char *Data);
extern INT32 ll_PopTail(LinkList List, char **Data);
extern INT32 ll_PushHead(LinkList List, char *Data);
extern INT32 ll_PopHead(LinkList List, char **Data);
extern BOOLEAN ll_IsListEmpty(LinkList List);

extern LinkList ll_MakeCopy(LinkList SourceList);

#if defined (PCWINNT_SYS)
extern void ll_DestroyLinkList(LinkList List);
#endif
