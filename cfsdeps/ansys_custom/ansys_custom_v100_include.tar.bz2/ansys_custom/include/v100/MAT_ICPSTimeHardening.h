/* sid 50.1 copy of MAT_ICPSTimeHardening.h last changed by upd111 on 2005/06/04 13:22:38 */
////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         Copyright (C) 2001 ANSYS Inc.  All Rights Reserved             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MAT_ICPSTimeHardening.h $
// $Revision$ 7.0
// $Date$ March 28 2002
// $Author$ rjayasee
//
// Decription :
//              This class implement Time Hardening Implicit Creep Model
//
////////////////////////////////////////////////////////////////////////////// 

#if !defined(MAT_ICPSTimeHardening_H)
#define MAT_ICPSTimeHardening_H

#include  "MAT_ConstitutiveFunction.h"
#include  "MAT_Creep.h"

class MAT_ICPSTimeHardening  : public MAT_Creep
{
public:

	MAT_ICPSTimeHardening();
    // Default Constructor.

    static MAT_Creep* Construct() ;

    virtual bool FunctionValue( double* pVariables, INT iNumVariables,
                                double* pInputVariables, INT iNumInputVariables, double& dCreepStrainRate ) ;
    //I pVariable
    //I-Value of Coefficients
    //I iNumVariables
    //I- Number of variables
    //I dInputVariables
    //I-Input Variables
    //I iNumInputVariables
    //I-Num Input Variables
    //I dCreepStrainRate
    //I-Calculated Value of Creep Strain Rate
    //R- Calculates the value of the Creep Strain Rate using Time Hardening 

    virtual bool FirstDerivativeOfUnsquaredError
         ( double* pVariables,INT iNumVariables,
           double* pInputVariables, INT iNumInputVariables,
           INT iVariableIndex, double& dResult ) ;
    //I pVariable
    //I-Value of Coefficients
    //I iNumVariables
    //I- Number of variables
    //I dInputVariables
    //I-Input Variables
    //I iNumInputVariables
    //I-Num Input Variables
    //I iVariableIndex
    //I-Variable w.r.t which the derivative is to be calculated
    //I dResult
    //I-Calculated value of derivative
    //R- Calculates the value of the Creep Strain using Strain Hardening          
    
    virtual void Print() ;
    // Prints the constitutive function

    virtual void EliminateTemperatureCoefficients();
    //Eliminates Temperature term and fixes it.

    virtual ~MAT_ICPSTimeHardening();
    //Destructor


protected:


} ;


class MAT_ICPSTimeHardeningFactory
{
    public:

    static MAT_ICPSTimeHardeningFactory* Instance() ;
    //I Pointer to Creep Factory
    //- Pointer to Singleton Instantiator

    static void Destroy() ;
    ~MAT_ICPSTimeHardeningFactory() ;
    // Destructor

    private:

    MAT_ICPSTimeHardeningFactory() ;
    // Constructor

    static MAT_ICPSTimeHardeningFactory* m_pInstance ;
    //Pointer to only instance of this class
} ;

#endif // !defined(MAT_ICPSTimeHardening_H)
