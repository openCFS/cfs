/* sid 50.1 copy of ansElmSurfLoadtypes.h last changed by jrb on 2005/02/25 19:24:22 */

#include "ansysdef.h"


extern  INT  cCreateAnsElmSurfLoad(void);
extern  INT  cDeleteAnsElmSurfLoad(void);
extern  INT  cInquireAnsElmSurfLoad(INT,INT,INT,INT);
extern  INT  cPutAnsElmSurfLoad(INT,INT,INT,DOUBLE*);
extern  INT  cGetAnsElmSurfLoad(INT,INT,INT,INT*,DOUBLE*);
extern  INT  cGetAnsElmSurfLoadPtr(INT,INT,INT,INT*,DOUBLE**);
extern  INT  cActivateAnsElmSurfLoad(INT,INT,INT,INT);
extern  INT  cDumpAnsElmSurfLoad(INT);


/****************************************************************
 global-level structure for ANSYS element surface loads
 ****************************************************************/
struct ansElmSurfLoad_str {  /* Name of the structure                                      */
  INT       tag;             /* Tag for this instance of the element loads structure       */
  INT       *numDef;         /* Number of defined surface loads for each surface load type */
  INT       *maxSize;        /* Maximum number of values stored for each surface load type */
};

#define ansElmSurfLoadTag(load)                (load->tag)

#define ansElmSurfLoadNumDefPtr(load)          (load->numDef)
#define ansElmSurfLoadNumDefVec(load,i)        (load->numDef[i])
#define ansElmSurfLoadMaxSizePtr(load)         (load->maxSize)
#define ansElmSurfLoadMaxSizeVec(load,i)       (load->maxSize[i])



/******************************************************************
 data-level structure for ANSYS element surface loads
 ******************************************************************/
struct elmSurfLoadData_str {    /* Name of the structure                                           */
  char              modified;   /* Flag indicating whether this surface load has been modified     */
  char              internal;   /* Flag indicating whether this surface load is internal to object */
  INT               face;       /* face number this element surface load is applied on             */
  INT               loadType;   /* type of surface load (see ansysdef.h for possible values)       */
  char              active;     /* flag indicating if surface load is active or inactive           */
  DOUBLE           *values;     /* Array containing element surface load values                    */
                                /* NOTE: this array should be 16 values long                       */
  elmSurfLoadData  *nextLoad;   /* Pointer to the next element surface load data structure         */
                                /* for this element.  If this pointer is NULL, then this is        */
                                /* the last stored surface load for this element                   */
};

#define elmSurfLoadDataModified(eData)         (eData->modified)
#define elmSurfLoadDataInternal(eData)         (eData->internal)
#define elmSurfLoadDataFace(eData)             (eData->face)
#define elmSurfLoadDataType(eData)             (eData->loadType)
#define elmSurfLoadDataActive(eData)           (eData->active)

#define elmSurfLoadDataValuesPtr(eData)        (eData->values)
#define elmSurfLoadDataValuesVec(eData,i)      (eData->values[i])

#define elmSurfLoadDataNextLoadPtr(eData)      (eData->nextLoad)

