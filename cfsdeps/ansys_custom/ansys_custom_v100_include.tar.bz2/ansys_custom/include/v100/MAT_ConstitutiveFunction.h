/* sid 50.1 copy of MAT_ConstitutiveFunction.h last changed by upd111 on 2005/06/04 13:20:39 */
////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         Copyright (C) 2001 ANSYS Inc.  All Rights Reserved             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MAT_ConstitutiveFunction.h $
// $Revision$ 7.0
// $Date$ March 28 2002
// $Author$ rjayasee/jlo
//
// Decription :
//
//	Any material can be modeled with multiple constitutive functions. This
//  is the base class for all constitutive function.
//  eg Mooney, Arruda-Boyce etc.
//  These can be constucted by specifying the Coeffs manually or by importing
//  ExperimentalDatas.
////////////////////////////////////////////////////////////////////////////// 

#if !defined(MAT_CONSTITUTIVEFUNCTION_H)
#define MAT_CONSTITUTIVEFUNCTION_H

#include  "MAT_ExperimentalData.h"
#include  "MAT_ExperimentalDataSet.h"
#include  "MAT_FieldVariableCollection.h"
#include  "MAT_CoefficientArray.h"
#include  "MAT_FieldVariableCollection.h"

typedef MAT_CoefficientArray* MAT_CoefficientArrayPtr;
typedef map< MAT_FieldVariableCollection, MAT_CoefficientArray*, MAT_FieldVariableCollectionPtrCmp> MAT_CoefficientCollectionMap ;
class MAT_ConstitutiveFunction  
{
public:

	MAT_ConstitutiveFunction();
    // Default Constructor.

    void SetName( ANS_String oString ) ;
    //R-void
    //I oString
    //I-Name
    //- Sets the Name of this constitutive function

    virtual bool GenerateMaterialParameters() ;
    // Function that Generates the Material Parameters given
    // some experimental data. Which is already supplied

    //-----------------------Set and Get Parameter Data ----------------------------
    bool SetParameterData
        ( vector<ANS_String> const& oParNameVector,
          vector<double> const& oParDataVector ) ;
    //R-bool
    //I-oParNameVector
    //I-Vector of parameter Names
    //I-oParDataVector
    //I-Vector of Parameter Data
    //F-Function to set the material parameter data

    bool SetParameterData
        ( ANS_String const & oParNameVector,
          double const& oParDataVector ) ;
    //R-bool
    //I-oParName
    //I-Vector of parameter Names
    //I-oParData
    //I-Vector of Parameter Data
    //F-Function to set the material parameter data

     bool SetCoefficients( double* pCoeff, INT iNumCoeffs ) ;
     //R bool
     //I pCoeff
     //I-Pointer to Coeffs
     //I iNumCoeffs
     //I-Number of Coefficients
     //- Saves the solved coefficients

     bool SetCoefficients( vector<double> const& oCoeffArray ) ;
     //R bool
     //I oCoeffArray
     //I-Array of coefficients
     //- Set the Variable Independent coefficients

     bool SetCoefficient( INT iIndex, double const& dCoeff ) ;
     //R bool
     //I iIndex
     //I-Index of coefficient
     //I dCoeff
     //I-Value of Coefficient
     //- Set the Coefficient ( 0 to N-1 )

     bool SetCoefficients( vector<double> const& oCoeffArray, 
                           MAT_FieldVariableCollection const& oField  ) ;
     //R bool
     //I oCoeffArray
     //I-Array of coefficients
     //I oField
     //I-Field Variable
     //- Set the Variable Independent coefficients at a particular temp/...

     virtual bool DeleteCoefficients( MAT_FieldVariableCollection const& oField  ) ;
     //R bool
     //I oField
     //I-Field Variable
     //- Removes/Deletes the Variable Independent coefficients at a particular temp/...

     bool AddCoeffsToFieldDependentDataStructure() ;
     //- Add the current set of coefficient data to field dependent data structure

     bool GetParameterData
        ( vector<ANS_String> & pParNameVector,
          vector<double> & pParDataVector ) ;
    //R-bool
    //O-pParNameVector
    //O-Vector of parameter Names
    //O-pParDataVector
    //O-Vector of Parameter Data
    //F-Function to get the material parameter data

    // virtual bool GetRegressionModel( CFT_RegressionModel*& pRegressionModel ) ;
    // Returns the response function defined for this particular
    // material model


     bool GetCoefficientSet( INT iIndex,
                             MAT_FieldVariableCollection& oField,
                             MAT_CoefficientArray const*& pCoeffArray) const ;
     //R Result
     //I iIndex
     //I-Index of Data
     //I oField
     //I-The Field Describing the Data
     //I pCoeffArray
     //I-Coefficient Array
     //- Return a Field,Coefficient Pair

     bool GetCoefficientSetAtField( MAT_FieldVariableCollection const& oField,
                                    MAT_CoefficientArray const*& pCoeffArray) const ;
     //R Result
     //I oField
     //I-The Field Describing the Data
     //I pCoeffArray
     //I-Coefficient Array
     //- Return a Coefficient Pair given a field

     INT GetNumberOfCoefficientSets() const;
     //R INT
     //R -Return the Number of Coefficient Sets

     bool GetCurrentCoefficients( double* pInitCoeffs, INT& iNumDefCoeffs ) ;
     //R bool
     //O pInitCoeffs
     //O-Initial Coeffs
     //O iNumDefCoeffs
     //O-Number of Coeffs
     //- This function returns the number of coeffs and the default coeffs

     bool GetCurrentCoefficients( vector<double>& oCurCoeffs ) ;
     //R bool
     //O oCurCoeffs
     //O-Current Coeffs
     //- This function returns the current coefficients


     void CleanUpCoefficientCollection() ;
     //-Cleans up coefficient collectiond data

     void RemoveLastCoefficient() ;
     //R- Removes the last coefficient

     //-----------------------Set and Get Parameter Data ENDs! ----------------------------

    virtual bool CalculateFittedExperimentalDataPoint( INT iExpID,
                                                       INT iIndex,
                                                       vector<double>& oPoint ) ;
    //R bool
    //R-false is such a point or an experiment does not exist
    //I iExpID
    //I-Experiment ID
    //I iIndex
    //I-Nth Point
    //I oPoint
    //I Calulated Value of Experiment Point
    //- Returns the Fitted Experimental Data Point

    virtual bool CalculateFittedExperimentalDataPoint( ANS_String const& oExperimentType,
                                                       vector<MAT_CFAttribute*> const& oParamVector,
                                                       double& oCalculatedValue ) 
    {
        return false ;
    }
    //R Status of Function
    //I oExperimentType
    //I-Type of Experiment
    //I oParamVector
    //I-Vector of Parameters
    //O oCalculateValue
    //O-Value of Fitted Data
    //- Calculated Fitted Data Given Input

    virtual bool CalculateFittedExperimentalDataPoint
                ( double* pCoeffs,
                  INT iNumCoeffs,
                  ANS_String oExpName,
                  vector<double>& oPoint ) ;
    //R bool
    //R-false is such a point or an experiment does not exist
    //I oExpName
    //I-Experiment Name
    //I oPoint
    //I Calulated Value of Experiment Point
    //- Returns the Fitted Experimental Data Point

    virtual bool CalculateFittedExperimentalDataPoint
                ( MAT_ExperimentalDataFormat* pEDFormat,
                  vector<double>& oPoint ) ;
    //R bool
    //R-false is such a point or an experiment does not exist
    //I pEDFormat
    //I-Experimental Data Format
    //I oPoint
    //I Calulated Value of Experiment Point
    //- Returns the Fitted Experimental Data Point

    virtual bool CalculateResidual( double& dResidual ) ;
    //R bool
    //I dResidual
    //I- Residual
    //- Calculates Residual for the coefficients + given exp data

    bool GetExperimentalDataSet( MAT_ExperimentalDataSet *& pEDataSet ) ;
    //R-false if one does not exist
    //O-pEDataSet
    //O-Pointer to ExpData Set object
    //R-Gets a pointer to the experimental data set
    //R-ExperimentalData objects can be added to this

     virtual bool SetNumberOfCoeffs( INT iOrder ) ;
    //R-bool
    //I-iOrder
    //I-Number of Coeffs
    //F-Set the Number of Coeffs
    //F-This is implemented here to return false always
    //F-It is reimplemented in each of the derived classes

     virtual void UseTrueStress( bool bFlag ) ;
     //R-bool
     //I bFlag
     //I-Flag to set flag is true stress or engg stress
     //- Set the Flags which indicates whether to use true stress or engineering
     //- Stress.
     //- REMARK:: Do all Materials have stress-vs-something. if so this is ok
     //- Else move this or make it more general.

     virtual void UseNormalizedLeastSquares( bool bFlag ) ;
     //R- void
     //-  Set the Flag which decides whether normalized least squares or unnormalized
     //-  least squares is to be used.
     //-  Un-Normalized - Sum 1-n [ ( Sexp - Scalc ) ^ 2 ]
     //-  Normalized    - Sum 1-n [ (( Sexp - Scalc ) ^ 2 ) / Sexp]

     virtual void GetNormalizedLeastSquaresFlag( bool& bFlag ) ;
     //R- void
     //-  Get the Flag which decides whether normalized least squares or unnormalized
     //-  least squares is to be used.
     //-  Un-Normalized - Sum 1-n [ ( Sexp - Scalc ) ^ 2 ]
     //-  Normalized    - Sum 1-n [ (( Sexp - Scalc ) ^ 2 ) / Sexp]

     virtual void Print() ;
    // Prints the constitutive function

    virtual ANS_String const* GetType() ;
    // Gets the type of the class
    // *** ? should this be made static? ***

    virtual ANS_String const* GetName() ;
    // Gets the type of the class
    // *** ? should this be made static? ***

    virtual ~MAT_ConstitutiveFunction();
    //Destructor

    virtual bool Assemble1stDerivativeMatrix
        ( double* dCoeffs,
          INT iNumCoeffs,
          double** d1stDerMatrix ) { return false; };
    //R-Status of the function
    //I dCoeff                      
    //I-array of coefficients
    //I iNumCoeffs                  
    //I-Number of Coefficients
    //I d1stDerMatrix               
    //I-The Resulting Matrix of 1st Derivatives
    //-Assemble the RHS Matrix for the Newton-Raphson Loop

    virtual bool Assemble2ndDerivativeMatrix
    ( double* dCoeffs,
      INT iNumCoeffs,
      double** d2ndDerMatrix ) { return false; };
    //R-Status of the function
    //I dCoeff                      
    //I-array of coefficients
    //I iNumCoeffs                  
    //I-Number of Coefficients
    //I d1stDerMatrix               
    //I-The Resulting Matrix of 2nd Derivatives
    //-Assemble the RHS Matrix for the Newton-Raphson Loop

    virtual bool Residual
        ( double* dCoeffs,
          INT iNumCoeffs,
          double& dResidual ) { return false; };
    //R-Status of the function
    //I dCoeff                      
    //I-array of coefficients
    //I iNumCoeffs                  
    //I-Number of Coefficients
    //I d1stDerMatrix               
    //I-The Resulting Residual
    //- Calculates the Residual given the coefficients

    virtual bool Assemble1stDerivativeMatrixAtAllPoints
        ( double* dCoeffs,
          INT iNumCoeffs,
          INT iNumPoints,
          double** d1stDerMatrix ) { return false ; }
    //R-Status of the function
    //I pDataSet
    //I-Collection of Experimental Data
    //I dCoeff                      
    //I-array of coefficients
    //I iNumCoeffs                  
    //I-Number of Coefficients
    //I iNumPoints
    //I-Number of points
    //I d1stDerMatrix               
    //I-The Resulting Matrix of 1st Derivatives
    //-Assemble the RHS Matrix 

    virtual bool ResidualAtAllPoints
        ( double* dCoeffs,
          INT iNumCoeffs,
          INT iNumPoints,
          double** dResidual ) { return false ; }
    //R-Status of the function
    //I dCoeff                      
    //I-array of coefficients
    //I iNumCoeffs                  
    //I-Number of Coefficients
    //I iNumPoints
    //I-Number of Points
    //I dResidual               
    //I-The Resulting Array Resisuals
    //-Assemble the Error Matrix  

    virtual void SetMarquardtFactorMu( double dMu ) ;
    //R-void
    //I dMu
    //I-Levenberg Marquardt Factor that controls factor that controls
    //I-the contribution of the steepest gradient method
    //- Set factors for the Levenberg Marquardt Algorithm

    virtual void SetMarquardtFactorGamma( double dGamma ) ;
    //R-void
    //I dGamma
    //I-Levenberg Marquardt Factor that controls the contribution of the
    //I-steepest gradient method
    //- Set factors for the Levenberg Marquardt Algorithm

     bool SetNumberOfIterations( INT iNumIter ) ;
     //R-Int Result of this operation
     //I iNumIter
     //I-Number Of Iterations
     //- Sets the Number of Iterations

     void GetNumberOfIterations( INT& iNumIter ) ;
     //R-Int Result of this operation
     //I iNumIter
     //I-Number Of Iterations
     //- Gets the Number of Iterations

     bool SetResidualChangeTolerance( double dResChangeTol ) ;
     //R-Int Result of this operation
     //I dResChangeTol
     //I-Maximum Allowed Residual Change
     //- Sets the Maximum Allowed Residual Change

     void GetResidualChangeTolerance( double& dResChangeTol ) ;
     //R-Int Result of this operation
     //I dResChangeTol
     //I-Maximum Allowed Residual Change
     //- Sets the Maximum Allowed Residual Change

     bool SetCoefficientChangeTolerance( double dCoeffChangeTol ) ;
     //R-Int Result of this operation
     //I iNumIter
     //I-Maximum Allowed Coeffient Change
     //- Sets the Maximum Allowed Coeffient Change
     
     void GetCoefficientChangeTolerance( double& dCoeffChangeTol ) ;
     //R-Int Result of this operation
     //I iNumIter
     //I-Maximum Allowed Coeffient Change
     //- Sets the Maximum Allowed Coeffient Change

     bool SetCoefficientFixedFlag( INT iCoeffIndex, bool bCoeffFixed ) ;
     //R bool
     //R false is such a coeff does not exist
     //I iCoeffIndex
     //I-Index of the Coeff
     //I bCoeffFixed
     //I-If the coeff is fixed use bool true else use bool false
     //- Function to Set if the Coeff is Fixed

     bool GetCoefficientFixedFlag( INT iCoeffIndex, bool& bCoeffFixed ) ;
     //R bool
     //R false is such a coeff does not exist
     //I iCoeffIndex
     //I-Index of the Coeff
     //O bCoeffFixed
     //O-If the coeff is fixed use bool true else use bool false
     //- Function to Get if the Coeff is Fixed

     virtual void SetTemperatureFilterSolveFlag( bool bFlag ) ;
     //R status
     //I bFlag
     //- This flag sets the Temperature Filter Solve on

     bool GetTemperatureFilterSolveFlag() const
     {
         return m_bFilterBasedSolve ;
     };
     //R status
     //I bFlag
     //- This flag sets the Temperature Filter Solve on

     virtual void SetReferenceTemperature( double dTRef ) ;
     //R-void
     //I dTRef
     //I-Value of Reference Temperature
     // - Sets Refererence Temperature

     void GetReferenceTemperature( double& dTRef ) const ;
     //R-void
     //I dTRef
     //I-Value of Reference Temperature
     // - Gets Refererence Temperature

     bool GetTemperatureOfExperimentalData(MAT_ExperimentalData* pExpData, double& dTemp)  ;
     //R bool
     //R-If the operation was successful
     //I pExpData
     //I-Experimental Data
     //O dTemp
     //O-Experiment Temperature
     //- Returns the Temperature of the Experimental Data

     MAT_CoefficientArray& CoefficientArray()
     {
         return this->m_oParameterData ;
     }
     //Returns a reference to the temperature independent coefficient array


protected:

    ANS_String m_oCFType ;
    // Type of the Constitutive Function for type identification

    ANS_String m_oCFName ;
    // Name of the Constitutive Function

	MAT_CoefficientArray m_oParameterData ;
    // List of Constitutive Model data

    vector<ANS_String> m_oParameterName ;
    // List of Constitutive Model data names

    map<INT,bool> m_oIsCoeffFixed ;
    // Map of Variable Index and Whether the Coefficient is Fixed

    MAT_ExperimentalDataSet m_oExpDataSet ;
    // Can be empty

    INT m_iNumCoeffs ;
    // Number of Coeffs

    bool m_bUseTrueStressFlag ;
    // Use True Stress or Engineering Stress

    bool m_bNormalizedLeastSquaresFlag ;
    // Use Normalized least squares flag

    double m_dMarquardtMu ;
    double m_dMarquardtGamma ;
    // Factors for the Levenberg Marquardt Method

    INT m_iNumIterations ;
    INT m_iCurIteration ;
    // Coefficients Used in the Iteration

    double m_dCalculatedResidual ;

    // Convergence Criteria
    double m_dResidualChangeTolerance ;
    double m_dCoefficientChangeTolerance ;

    bool m_bFilterBasedSolve ;
    //Variable Based Filter Solve

    double m_dReferenceTemperature ;
    //Reference Temperature to pick experimental data

    MAT_CoefficientCollectionMap m_oMAT_CoefficientCollection ;
    //Material Coefficient Collection
} ;



#endif // !defined(MAT_ConstitutiveFunction_H)
