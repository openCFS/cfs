/* sid 50.1 copy of FEM_layer.h last changed by upd111 on 2004/11/04 18:31:12 */
/*  FEM_layer.h */
/*
 * *** ansys(r) copyright(c) 1999
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_layer.h
 *  header file for FEM_layer.c
 *
 */
#ifndef FEM_LAYER_INCLUDE
#define FEM_LAYER_INCLUDE

/* --- ERROR message identifiers return values */

#define LAYER_MESH_ERROR -100
#ifdef __cplusplus
extern "C" {
#endif

/* ------------------ Prototypes --------------------------------------*/
                             /* === FEM_laInitLayerParams: initialize the     */
                             /* === layer meshing parameters for each line    */
INT FEM_laInitLayerParams (
   INT anum,                          /* the current area                     */
   INT flat,                          /* flag - area is flat                  */
   INT *p_layermesh  );               /* return if layer meshing              */

                             /* === FEM_laBGLayerMesh: define additional      */
                             /* === nodes for the background mesh to control  */
                             /* === sizing of elements close to layers        */
INT FEM_laBGLayerMesh (
   MESH_OBJ obj_mesh,                 /* the real mesh we are constructing    */
   MESH_OBJ obj_bgmesh,               /* background mesh object               */
   INT flat,                          /* flag - surface is flat               */
   INT use3D,                         /* flag - using 3D mesher               */
   INT anum,                          /* area we are working on               */
   DOUBLE elsize,                     /* user define esize                    */
   DOUBLE iesize  );                  /* user defined internal esize          */

                            /* === FEM_bgLayerNodes:  unmark any nodes        */
                            /* === for smoothing that are associated with a   */
                            /* === layer                                      */
INT FEM_laLayerNodes ( 
   NODELIST_OBJ obj_nlist  );         /* the current node list                */

                            /* === FEM_bgSmoothLayerNode: smooth a layer node */
INT FEM_laSmoothLayerNode (
   NODE_OBJ obj_node,                 /* node to smooth                       */
   VECTOR3D *new_location );          /* new location of node                 */

                            /* === FEM_bgKillLayerNodes: delete any memory    */
                            /* === alocated in FEM_bgLayerNodes               */
void FEM_laKillLayerNodes ( void  );

                            /* === FEM_bgAssignLayerNodes: assign layer info  */
                            /* === to node generic ponters for smoothing      */
INT FEM_laAssignLayerNodes ( void  );

                            /* === FEM_bgUnassignLayerNodes: restore any nodal*/
                            /* === generic pointers                           */
INT FEM_laUnassignLayerNodes ( void  );

                            /* === FEM_layerMeshActive: return current status */
                            /* === of layer meshing                           */
INT FEM_layerMeshActive ( void  );

                            /* === FEM_laBGLayerSize: return background       */
                            /* === layer mesh size                            */
DOUBLE FEM_laBGLayerSize ( void  );

                            /* === FEM_laElemEstimate: return the number of   */
                            /* === elements estimated in the layers           */
INT FEM_laElemEstimate ( void  );

                            /* === FEM_laMaxLevel: return max number of       */
                            /* === from boundary edge at which first layer    */
                            /* === is defined                                 */
INT FEM_laMaxLevel (
   EDGE_OBJ obj_edge  );              /* an edge on the boundary              */

                            /* === FEM_laGetCoords: return coordinates of node*/
void FEM_laGetCoords (
  INT *p_node,
  INT *p_num_bound,
  DOUBLE *a_coor3db,
  DOUBLE *a_coor3d,
  DOUBLE *a_xyz  );

                            /* === FEM_laDelete: delete layer meshing line    */
                            /* === data struct.  Make sure this is called at  */
                            /* === the end                                    */
void FEM_laDelete ( void  );

                            /* === FEM_laSmoothLayer: smooth only nodes on    */
                            /* === layer and those immediately adjacent using */
                            /* === regular smoothing (instead of layer        */
                            /* === smoothing)                                 */
INT FEM_laSmoothLayer (
   INT anum,
   DOUBLE *p_smotol  );     /* the smoothing tolerance */
#ifdef __cplusplus
}
#endif

#endif
