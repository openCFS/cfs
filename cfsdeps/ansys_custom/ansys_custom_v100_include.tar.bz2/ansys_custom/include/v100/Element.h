/* sid 50.1 copy of Element.h last changed by upd111 on 2005/06/04 13:18:45 */
#ifndef	_ELEMENT_H_
#define	_ELEMENT_H_
#include <stdio.h>

#include "BlockAlloc.h"

class DofSetArray;

class PolygonSet;

// Boundary Condition Structure
struct BCond {
 INT    nnum;   // node number
 INT    dofnum; // dof number
 double val;    // value of bc
};

typedef double EFrame[3][3];

// ****************************************************************
// * Class StructProp contains the defined structural properties  *
// ****************************************************************

// contains material and geometrical properties of elements

class StructProp {
  public:
	double	E;      // Elastic modulus
	double  A;  	// Cross-sectional area 
	double	nu; 	// Poisson's ratio
	double  rho; 	// Mass density per unit volume
     union {
	double  eh;	// Element thickness
	double  C1;	// Non-uniform torsion constant
        };
	double  Ixx;	// Cross-sectional moment of inertia about local x-axis
	double  Iyy;	// Cross-sectional moment of inertia about local y-axis
	double  Izz;	// Cross-sectional moment of inertia about local z-axis
     union { 
	double c; 	// Thermal convection coefficient
	double alphaY;  // Shear deflection constant associated to Iyy
	};
     union { 
	double k;       // Heat conduction coefficient
	double alphaZ;  // Shear deflection constant associated to Izz
	};
        double Q;	// Specific heat coeffiecient
	double W;	// Thermal expansion coefficient
        double P;	// Perimeter/circumference of thermal truss/beams
	double Ta;	// Ambient temperature

	double kappaHelm; // wave number
};

//****************************************************************
//*
//*     class Node: Keeps the coordinates of a node
//*
//****************************************************************

class Node {
  public:
	// Constructors
        Node() {}
        Node(double *xyz) { x = xyz[0]; y = xyz[1]; z = xyz[2]; }

	// Coordinates 
	double 	x;
	double 	y;
	double 	z;
};

// ****************************************************************
// *                        WARNING                               *
// *       Nodes in the CoordSet are from 0 and not from 1        *
// *       It is a good idea to subtract 1 from node input        *
// *       from the user at any time a node is read in rather     *
// *       then keeping it from 1 and then subtracting 1 here     *
// *       and there....                                          *
// *       functions for this class are in Element.d/Coordset.C   *
// ****************************************************************

class CoordSet {
        INT nmax;
	Node **nodes;
        BlockAlloc ba;
public:
        // Constructors
        CoordSet(INT = 256);
	CoordSet(const CoordSet&, INT n, INT *nd);

	// Member functions
        INT   size() { return nmax ; }
        void  nodeadd(INT n, double*xyz);
	Node &getNode(INT);

        Node *operator[] (INT i) { return (i < nmax) ? nodes[i] : 0; }

        void deleteNodes() { delete [] nodes; }

        INT getFromAnsys(INT);
};

// ****************************************************************
// * Class Element defines functions for finite elements.         *
// * Each element has a structural property and a pressure        *
// * associated with it. Each element defines it's own dofs, sets *
// * it's own node numbers, calculates stiffness, calculates mass *
// * von mises stress, INTernal force and displacements. Where    *
// * these functions are written for each type of element and if  *
// * a function is not defined for an element type, it will       *
// * default to the appropriate function in Element.C             *  
// * i.e. an element with a zero mass matrix, will just return a  *
// * matrix of the appropriate size containing zeroes.            *
// ****************************************************************
struct PrioInfo {
   INT isReady; // wether this element is ready to be inserted
   INT priority; // the level of priority (undefined in isReady == 0)
};

class MultiFront;



class Element {
  protected:
	StructProp *prop;	// structural properties for this element
        double pressure;	// pressure force applied to element
  public:
	Element() { prop = 0; pressure = 0.0; };

        virtual Element *clone() { return 0; }
        virtual void renum(INT *)=0;

        static Element *build(INT,INT,INT*);

	virtual INT    numNodes() = 0;
	virtual INT*   nodes(INT * = 0) = 0;

	virtual INT  getTopNumber();

        virtual void dumpTop(FILE *outFile)=0;

        // Routines for the decomposer
        virtual PrioInfo examine(INT sub, MultiFront *)
                        { PrioInfo ret; ret.isReady = false; return ret; };
        // isStart indicates if an element is suitable to
        // be a germination center for a subdomain (bars are not)
        virtual bool isStart() { return true; }

        // CG function
        void getCG(CoordSet &, double &xcg, double &ycg, double &zcg);

        // TOP/DOMDEC Element Functions
        //virtual INT facelist(PolygonSet &, INT * = 0) { return 0; }
        virtual bool hasRot() { return false; }

        // dynamic_cast operator doesn't work on RS6000. Create this
        // virtual function to avoid the need of operation at AnsysDec.cpp
#if defined (RS6000_SYS) || (PCWINNT_SYS)
	virtual INT origNum() = 0;
#endif
	friend class Domain;
};

//*****************************************************************
//*                        WARNING                                *
//*       The same remark as for node is valid for elements       *
//*       The functions for this class are in Element.d/ElemSet.C *
//*****************************************************************

class Elemset {
  protected:
    Element **elem;
    INT emax;
    BlockAlloc ba;
    INT *mark;
    INT marksize;
    INT markRealsize;
  public:
    Elemset(INT = 256, INT = 0);
    INT size() { return emax; }
    INT last();
    Element *operator[] (INT i) { return elem[i]; }
    void elemadd(INT num, Element *);
    void elemadd(INT num, INT type, INT nnodes, INT *nodes);
    void elemMark(INT, INT);
    void list();
    INT  markexist(INT);
    void markprint();
    INT getFromAnsys(INT, Elemset *, Elemset *, INT);
};


class AnsysLineContact: public Element {
   INT eleNum;
   INT nd[2];
 public:
   AnsysLineContact(INT iele, INT *nodes);

   INT    numNodes();
   INT*   nodes(INT * = 0);
   bool isStart() { return false; }
   INT origNum() { return eleNum; }
};

class AnsysMassElem: public Element {
   INT eleNum;
   INT nd;
 public:
   AnsysMassElem(INT iele, INT *nodes);
   INT numNodes();
   INT *nodes(INT * = 0);
   void renum(INT *);
   void dumpTop(FILE *outFile);
   INT origNum() { return eleNum; }
   bool isStart() { return false; }
};

class AnsysNodeContact: public Element {
    INT eleNum;
    INT nd;
 public:
   AnsysNodeContact(INT iele, INT *nodes);

   INT    numNodes();
   INT*   nodes(INT * = 0);
#if defined (RS6000_SYS) || (PCWINNT_SYS)
   INT origNum() { return eleNum; }
#endif
   bool isStart() { return false; }
};

class AnsysBar2: public Element {
 protected:
   INT eleNum;
   INT nd[2];
 public:
   AnsysBar2(INT iele, INT *nodes);
   void renum(INT *);
   // FullSquareMatrix stiffness(double *v, double *f);
   INT    numDofs();
   void   markDofs(DofSetArray &);
   INT*   dofs(DofSetArray &, INT *p=0);

   INT    numNodes();
   INT*   nodes(INT * = 0);
   void dumpTop(FILE *outFile);
   PrioInfo examine(INT sub, MultiFront *);
#if defined (RS6000_SYS) || (PCWINNT_SYS)
   INT origNum() { return eleNum; }
#endif
   bool isStart();
};

class AnsysBeam2: public AnsysBar2 {
 public:
   AnsysBeam2(INT iele, INT *nodes) : AnsysBar2(iele, nodes) {}
   PrioInfo examine(INT sub, MultiFront *);
   bool isStart() {return true;};
   bool hasRot() { return true; }
};


class BlockAlloc;

/* maximum node size in ANSYS. Must be consistant with NNMAX in elempr.inc */
#define ANSYSMAXNUMNODES 89

class AnsysContact: public Element {
    INT eleNum;
    INT numNd;
    INT *nd;
  public:
    AnsysContact(BlockAlloc &, INT, INT, INT*);
    bool isStart() { return false; }
    INT origNum() { return eleNum; }
    void renum(INT *);
    INT    numNodes();
    INT*   nodes(INT * = 0);
    void dumpTop(FILE *outFile);
};


class AnsysQuad4: public Element {
   INT eleNum;
   INT nd[4];
 public:
   AnsysQuad4(INT iele, INT *nodes);
   INT    numDofs();
   void   markDofs(DofSetArray &);
   INT*   dofs(DofSetArray &, INT *p=0);

   void renum(INT *);
   // FullSquareMatrix stiffness(double *v, double *f);
   INT    numNodes();
   INT*   nodes(INT * = 0);
   void dumpTop(FILE *outFile);
   //INT facelist(PolygonSet &, INT * = 0);
#if defined (RS6000_SYS) || (PCWINNT_SYS)
   INT origNum() { return eleNum; }
#endif
   PrioInfo examine(INT sub, MultiFront *);
};

class AnsysCube8: public Element {
   INT eleNum;
   INT nd[8];
 public:
   AnsysCube8(INT iele, INT *nodes);
   INT    numDofs();
   void   markDofs(DofSetArray &);
   INT*   dofs(DofSetArray &, INT *p=0);

   void renum(INT *);
   // FullSquareMatrix stiffness(double *v, double *f);
   INT    numNodes();
   INT*   nodes(INT * = 0);
   void dumpTop(FILE *outFile);
   //INT facelist(PolygonSet &, INT * = 0);
#if defined (RS6000_SYS) || (PCWINNT_SYS)
   INT origNum() { return eleNum; }
#endif
   PrioInfo examine(INT sub, MultiFront *);
};

class AnsysTri3: public Element {
   INT eleNum;
   INT nd[3];
 public:
   AnsysTri3(INT iele, INT *nodes);
   void renum(INT *);
   // FullSquareMatrix stiffness(double *v, double *f);
   INT    numDofs();
   void   markDofs(DofSetArray &);
   INT*   dofs(DofSetArray &, INT *p=0);

   INT    numNodes();
   INT*   nodes(INT * = 0);
   void dumpTop(FILE *outFile);
   //INT facelist(PolygonSet &, INT * = 0);
#if defined (RS6000_SYS) || (PCWINNT_SYS)
   INT origNum() { return eleNum; }
#endif
   PrioInfo examine(INT sub, MultiFront *);
};

class AnsysTetra: public Element {
 protected:
   INT eleNum;
   INT nd[4];
 public:
   AnsysTetra(INT iele, INT *nodes);
   void renum(INT *);
   INT    numDofs();
   void   markDofs(DofSetArray &);
   INT*   dofs(DofSetArray &, INT *p=0);

   INT    numNodes();
   INT*   nodes(INT * = 0);
   // FullSquareMatrix stiffness(double *v, double *f);
   void dumpTop(FILE *outFile);
   //INT facelist(PolygonSet &, INT * = 0);
#if defined (RS6000_SYS) || (PCWINNT_SYS)
   INT origNum() { return eleNum; }
#endif
   PrioInfo examine(INT sub, MultiFront *);
};

class AnsysTetra10: public AnsysTetra {
//class AnsysTetra10: public Element {
   INT extraNd[6];
   // INT nd[10];
 public:
   AnsysTetra10(INT iele, INT *nodes);
   void renum(INT *);
   INT    numNodes();
   INT*   nodes(INT * = 0);
   void dumpTop(FILE *outFile);
#if defined (RS6000_SYS) || (PCWINNT_SYS)
    INT origNum() { return eleNum; }
#endif
   PrioInfo examine(INT sub, MultiFront *);
};

/*
class AnsysE16: public Element {
   INT eleNum;
   INT nd[4];
 public:
   AnsysE16(INT iele, INT *nodes);
   void renum(INT *);
   INT    numNodes();
   INT*   nodes(INT * = 0);
};

class AnsysQuad9: public Element {
   INT eleNum;
   INT nd[4];
 public:
   AnsysQuad9(INT iele, INT *nodes);
   void renum(INT *);
   INT    numNodes();
   INT*   nodes(INT * = 0);
};

class AnsysTri6: public Element {
   INT eleNum;
   INT nd[4];
 public:
   AnsysTri6(INT iele, INT *nodes);
   void renum(INT *);
   INT    numNodes();
   INT*   nodes(INT * = 0);
};

class AnsysCube20 public Element {
   INT eleNum;
   INT nd[4];
 public:
   AnsysCube20INT iele, INT *nodes);
   void renum(INT *);
   INT    numNodes();
   INT*   nodes(INT * = 0);
};
*/

#define AnsysQuad9 AnsysQuad4
#define AnsysTri6 AnsysTri3
#define AnsysCube20 AnsysCube8


#endif
