/* sid 50.1 copy of astep_gdxbltlink.h last changed by upd111 on 2005/06/04 13:15:27 */
/* NOTE: This file is DEAD and NO LONGER USED! */
