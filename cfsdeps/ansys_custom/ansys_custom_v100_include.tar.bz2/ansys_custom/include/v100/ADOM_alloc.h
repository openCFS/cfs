/* sid 50.1 copy of ADOM_alloc.h last changed by smarguer on 2005/01/25 15:46:50 */
/* ADOM_alloc.h CADOE  */
/*
 *   
 * HISTORY
 *   
 *   06/28/00 10:47 <       Brian Jantzen> Rel:ms8m1    SCCA:74542  Delta:81.3
 *   
 *   06/21/00 16:30 <       Brian Jantzen> Rel:ms8m1    SCCA:74307  Delta:81.2
*/
#ifndef __adomalloch__
#define __adomalloch__ 1

#ifdef __cplusplus
extern "C" {
#endif

#ifndef __expmdbstructh__
#include "expmdb_struct.h"
#endif

extern T_FCout 		*ADOM_allouer_memoire_cout ( T_statut * );
extern T_Modele    	*ADOM_allouer_memoire_modele( T_statut * );
extern T_Mesh      	*ADOM_allouer_memoire_mesh ( T_statut * ); 
extern T_Config    	*CFG_allouer_config ( int , T_statut * );
extern T_Groupe 	*ADOM_allouer_memoire_groupes ( int, T_statut * );
extern T_Groupe		*ADOM_allouer_memoire_groupe ( T_statut * );
extern T_Normal		*REP_allouer_memoire_normal( T_statut *ier );
extern void        	CFG_liberer_config( T_Config ** );
extern T_statut 	MSH_allouer_memoire_mesh_data ( T_Noeud * );
extern T_Noeud		*MSH_allouer_memoire_noeud ( T_statut *ier );
extern T_Repere		*REP_allouer_memoire_repere( T_statut * );

extern void 		ADOM_liberer_cout ( T_FCout * );
extern void		MSH_init_noeud ( T_Noeud * );
extern void		MSH_init_Mnoeud ( T_Mnoeud * );
extern void		CFG_set_num_config_courant ( int num_config );

extern T_Mesh 		*ADOM_creer_mesh ( T_Modele *, char *, T_Mesh *, T_booleen, T_booleen,E_type_mesh, T_statut * );
extern T_statut ADOM_ajouter_mesh ( T_Modele *, char *, T_Mesh *mesh, T_Mesh *pere, T_booleen temporaire, T_booleen to_update, E_type_mesh type );
extern T_statut		ADOM_liberer_memoire_mesh ( T_Mesh *mesh );
extern void		ADOM_liberer_memoire_mesh_data ( T_Mesh *mesh );
extern T_statut		ADOM_liberer_mesh ( T_Mesh * );
extern void		ADOM_liberer_meoire_noeuds ( int nb_noeud, T_Noeud **n0, T_Noeud ***noeuds );
extern void		ADOM_liberer_meoire_elements ( int nb_ele, T_Element **e0, T_Element ***elements );
extern void		ADOM_liberer_repere ( T_Repere **repere );
extern void             ADOM_liberer_integration(T_Integration *);
extern void		RES_liberer_resultat ( T_Resultat **res );

extern T_statut		ADOM_liberer_all_mesh ( T_Modele *modele );
extern T_statut		delete_adomesh_mesh ( T_Modele *modele, T_ltete **llrep, T_ltete **lrep );
extern void		ADOM_liberer_liste_repere ( T_ltete *llrep, T_ltete *lrep );
extern T_statut		ADOM_liberer_polym ( T_Mesh *mesh );
extern void		GPE_liberer_groupe ( T_Groupe **groupe );
extern void ADOM_liberer_Ndata ( T_Mnoeud **Ndata );


#ifdef __cplusplus
}
#endif


#endif
