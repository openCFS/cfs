/* sid 50.1 copy of StandardH.h last changed by upd111 on 2005/06/04 13:15:35 */
/*
 * *** ansys(r) copyright(c) 2000
 * *** ansys, inc.
 */
#define True 1
#define False 0

#include "computer.h"

#if defined (__STDC__)
#define ANSI_C_COMPAT			1
#endif
