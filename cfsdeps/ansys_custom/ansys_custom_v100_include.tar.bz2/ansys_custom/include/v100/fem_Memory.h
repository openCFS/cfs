/* sid 50.1 copy of fem_Memory.h last changed by upd111 on 2004/11/04 18:32:44 */
/*  fem_Memory.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  fem_Memory.h
 *  header file for finite element mesh module memory management (mmmm:-)
 *
 */
/* 
 * *** ansys(r) copyright(c) 1999
 * *** ansys, inc.
 */
#ifndef FEM_MEMORY
#define FEM_MEMORY

/*========================================================================
 *  Mesh memory manager structures
 *  handles mesh memory management of the winged edge data structure
 *
 * === Memory is allocated in blocks as it is needed.  For each data
 * === type we have an array of blocks.  We also keep a stack of
 * === pointers to the free items in the blocks.
 * ===
 * === For each entity type there are 3 main array types used - 
 * === each of which is allocated as needed:
 * === 1) BLOCK: 
 * ===    Array of structures. (fgpa_xxxblock[i]).  This is the actual 
 * ===    memory where the entity is stored.  One block is allocated
 * ===    at a time.  The size of one block is XXX_BLOCK_SIZE
 * === 2) BLOCK POINTERS: 
 * ===    Array of pointers to the BLOCK arrays. (fgpa_xxxblock)
 * ===    Initially this will be allocated to a size XXX_BLOCK_GROUP_SIZE.  
 * ===    If more are needed, the BLOCK POINTER array will be realloced
 * ===    with an additional XXX_BLOCK_GROUP_SIZE pointers.  Unused block 
 * ===    pointers will be NULL and the number of blocks used will be 
 * ===    g_spxxxblocks.  The total size of the BLOCK POINTER array is 
 * ===    g_spxxxblocksize.
 * === 3) STACK:
 * ===    Pointers to a list of currently available entities.
 * ===    (fgpa_xxxstack).  There are 2 ways entities can be placed on the
 * ===    stack: (1) A new BLOCK is allocated and all new entities are
 * ===    loaded on the stack or (2) An entity is freed.  They are popped
 * ===    off the stack whenever a new entity is malloced.  The stack
 * ===    is a list of pointers to elements previously allocated in the 
 * ===    BLOCKS that are available for use.  The initial size of the 
 * ===    stack is XXX_STACK_GROUP_SIZE but can increase by increments
 * ===    of XXX_STACK_GROUP_SIZE if needed.  The current size of the
 * ===    stack is g_spxxxstacksize and current top of the stack is
 * ===    g_spxxxstack.
 * ===
 */

/* === valid types that can be passed to fem_Malloc */

typedef enum {ELEMENT, 
              FACE, 
              EDGE, 
              NODE, 
              EDGEUSE, 
              FACEUSE,
              NEXTNODE } ENTITY_ENUM;

/* === Max number of blocks for each type. */

#define ELEMENT_BLOCK_GROUP_SIZE   500
#define FACE_BLOCK_GROUP_SIZE      500
#define EDGE_BLOCK_GROUP_SIZE      1000
#define NODE_BLOCK_GROUP_SIZE      500
#define FACEUSE_BLOCK_GROUP_SIZE   2000 
#define EDGEUSE_BLOCK_GROUP_SIZE   3000
#define NEXTNODE_BLOCK_GROUP_SIZE  500

/*
 * === Block sizes. (These numbers imply a maximum number of entities
 * === i.e. maxelems = ELEMENT_BLOCK_SIZE * MAX_ELEMENT_BLOCKS
 * ===      maxfaces = FACE_BLOCK_SIZE * MAX_FACE_BLOCKS 
 * ===      etc..
 */ 

#define ELEMENT_BLOCK_SIZE   500
#define FACE_BLOCK_SIZE      500
#define EDGE_BLOCK_SIZE     1000
#define NODE_BLOCK_SIZE      500
#define FACEUSE_BLOCK_SIZE  2000
#define EDGEUSE_BLOCK_SIZE  1500
#define NEXTNODE_BLOCK_SIZE  500

/*
 * === Increment or size of group that the stack is incremented 
 * === when necessary
 */

#define ELEMENT_STACK_GROUP_SIZE   500
#define FACE_STACK_GROUP_SIZE      500
#define EDGE_STACK_GROUP_SIZE     1000
#define NODE_STACK_GROUP_SIZE      500
#define FACEUSE_STACK_GROUP_SIZE  2000
#define EDGEUSE_STACK_GROUP_SIZE  1500
#define NEXTNODE_STACK_GROUP_SIZE  500

/*======================================================================
 *      Private function prototypes
 */

/* === mesh memory management */

void fem_FreeAll ( void  );
void fem_Free ( INT type, void *point  );
void *fem_Malloc ( INT type  );
void FEM_MemStat ( void  );
void FEM_EdgeUseStat ( void  );

#endif
