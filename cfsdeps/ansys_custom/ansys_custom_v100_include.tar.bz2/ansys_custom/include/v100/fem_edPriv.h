/* sid 50.1 copy of fem_edPriv.h last changed by upd111 on 2004/11/04 18:32:48 */
/*  fem_edPriv.h */
/* 
 * *** ansys(r) copyright(c) 1999
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  *** */
/*                                                                         sjo
 *   fem_edPriv.h
 *   Private header file for edges in FEM module
 */
#ifndef FEM_EDPRIVATE
#define FEM_EDPRIVATE

#include "FEM_cdbtypes.h"
                             /* === fem_edRemoveAdjFace: remove pointers from */
                             /* === the edge to one of its adjacent faces     */
void fem_edRemoveAdjFace (
   EDGE_PTYP ps_edge,                  /* the edge                            */
   FACE_PTYP ps_face );                /* the face that is to be removed      */
                                       /* from the edge */
/*
 * Macros
 */

/*============================================================================*/
/* === Macro:  fem_edSetTotal_C
 * === Author: sjo
 * === Description: set total number of edges in list
 * === Arguments:
 *     EDGELIST_OBJ obj_edlist      edge list object
 *     INT totedge                 new total number of edges
 * === Return: nothing
 */
#define fem_edSetTotal_C( obj_edlist, totedge )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((EDGELIST_PTYP)(obj_edlist))->total = totedge;\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }

/*============================================================================*/
/* === Macro: fem_edSetList_C
 * === Author: sjo
 * === Description: set head of edge list
 * === Arguments:
       EDGELIST_OBJ  obj_edlist       edge list object
       EDGE_OBJ obj_edge             new first edge in list
 * === Return:
 */
#define fem_edSetList_C( obj_edlist, obj_edge )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((EDGELIST_PTYP)(obj_edlist))->ps_list = (EDGE_PTYP)obj_edge;\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }

/*============================================================================*/
/* === Macro: fem_edSetCurrent_C
 * === Author: sjo
 * === Description: set current edge in edge object list
 * === Arguments:
 *     EDGELIST_OBJ obj_edlist          edge list object
 *     EDGE_OBJ obj_edge               new current edge
 * === Return:
 */
#define fem_edSetCurrent_C( obj_edlist, obj_edge )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((EDGELIST_PTYP)(obj_edlist))->ps_current = (EDGE_PTYP)obj_edge;\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }

/*============================================================================*/
/* === Macro: fem_edAddEdgeToList_C
 * === Author: sjo
 * === Description: add edge to linked list at front of list
 * === Arguments:
 *     EDGELIST_OBJ obj_edlist     edge list object
 *     EDGE_OBJ obj_element       new element to be added
 * === Return: nothing
 */
#define fem_edAddEdgeToList_C( obj_edlist, obj_edge )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((EDGE_PTYP)(obj_edge))->ps_next =\
                   ((EDGELIST_PTYP)(obj_edlist))->ps_list;\
         ((EDGELIST_PTYP)(obj_edlist))->ps_list =\
                   (EDGE_PTYP)(obj_edge);\
         if (((EDGE_PTYP)(obj_edge))->ps_next != NULL) {\
            ((EDGE_PTYP)(obj_edge))->ps_next->ps_previous =\
                      (EDGE_PTYP)(obj_edge);\
         }\
         ((EDGE_PTYP)(obj_edge))->ps_previous = NULL;\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }

/*============================================================================*/
/* === Macro: fem_edDeleteEdgeFromList_C
 * === Author: sjo
 * === Description: delete edge from linked list
 * === Arguments:
 *     EDGELIST_OBJ obj_edlist   edge list object
 *     EDGE_OBJ obj_edge     edge to be deleted
 * === Return: nothing
 */
#define fem_edDeleteEdgeFromList_C( obj_edlist, obj_edge )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         if (((EDGE_PTYP)(obj_edge))->ps_next != NULL) {\
            ((EDGE_PTYP)(obj_edge))->ps_next->ps_previous =\
                    ((EDGE_PTYP)(obj_edge))->ps_previous;\
         }\
         if (((EDGE_PTYP)(obj_edge))->ps_previous != NULL) {\
            ((EDGE_PTYP)(obj_edge))->ps_previous->ps_next =\
                    ((EDGE_PTYP)(obj_edge))->ps_next;\
         }\
         else{\
            ((EDGELIST_PTYP)(obj_edlist))->ps_list =\
               ((EDGE_PTYP)(obj_edge))->ps_next;\
         }\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }

/*============================================================================*/
/* === Macro: fem_edInsertAdjFace_MAC
 * === Author: sjo
 * === Description: insert into the edge, a pointer to one of its
 *                  adjacent faces (use only for STANDARD_MESH data rep)
 * === Arguments:
 *     EDGE_PTYP ps_edge          edge to be updated
 *     FACE_PTYP ps_face          face to be added
 *     INT iedge                  The location of edge in face
 * === Return: nothing
 * === Note: if you move the edge to a different slot in the face's edge
 *           array you also need to move the pointer to the new slot.
 */
#define fem_edInsertAdjFace_MAC( ps_edge, ps_face, iedge )\
   ps_face->as_edge_face[iedge].ps_face = ps_face;\
   ps_face->as_edge_face[iedge].ps_next = ps_edge->ps_adjface;\
   ps_edge->ps_adjface = \
      (NEXTFACE_TYP *)(ps_face->as_edge_face + iedge);

/*============================================================================*/
/* === Macro: fem_edInit_C
 * === Author: sjo
 * === Description: initialize all fields of the edge
 * === Arguments:
 *     EDGE_OBJ obj_edge          edge to be initialized
 * === Return: nothing
 */
#define fem_edInit_C( obj_edge )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((EDGE_PTYP)(obj_edge))->id = 0;\
         ((EDGE_PTYP)(obj_edge))->aps_node[0] = (NODE_PTYP)NULL;\
         ((EDGE_PTYP)(obj_edge))->aps_node[1] = (NODE_PTYP)NULL;\
         ((EDGE_PTYP)(obj_edge))->aps_node[2] = (NODE_PTYP)NULL;\
         ((EDGE_PTYP)(obj_edge))->as_node_edge[0].ps_edge = \
                                           (EDGE_PTYP)(obj_edge);\
         ((EDGE_PTYP)(obj_edge))->as_node_edge[1].ps_edge = \
                                           (EDGE_PTYP)(obj_edge);\
         ((EDGE_PTYP)(obj_edge))->as_node_edge[2].ps_edge = \
                                           (EDGE_PTYP)(obj_edge);\
         ((EDGE_PTYP)(obj_edge))->ps_adjface = (NEXTFACE_PTYP)NULL;\
         ((EDGE_PTYP)(obj_edge))->as_node_edge[0].ps_next = \
                                           (NEXTEDGE_PTYP)NULL;\
         ((EDGE_PTYP)(obj_edge))->as_node_edge[1].ps_next = \
                                           (NEXTEDGE_PTYP)NULL;\
         ((EDGE_PTYP)(obj_edge))->as_node_edge[2].ps_next = \
                                           (NEXTEDGE_PTYP)NULL;\
         ((EDGE_PTYP)(obj_edge))->property = NO_PROPERTY;\
         ((EDGE_PTYP)(obj_edge))->p_info = (ADDRESS_TYP)NULL;\
         ((EDGE_PTYP)(obj_edge))->geo_entity = 0;\
         ((EDGE_PTYP)(obj_edge))->p_topolist = (ADDRESS_TYP)NULL;\
         ((EDGE_PTYP)(obj_edge))->ps_next = (EDGE_PTYP)NULL;\
         ((EDGE_PTYP)(obj_edge))->ps_previous = (EDGE_PTYP)NULL;\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }
    

#endif
