/* sid 50.1 copy of cmapsysh.h last changed by upd111 on 2005/06/04 13:14:44 */
/********************************************/
/***  include file used for CMAP routines ***/
/********************************************/
/* 
 * *** ansys(r) copyright(c) 2000
 * *** ansys, inc.
 */
#if defined(PCWINNT_SYS)
    /*  c routines called from fortran  */
#define cmapstop_   CMAPSTOP

    /*  fortran routines called from c  */
#define cmap_       CMAP
#endif
