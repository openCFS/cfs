/* sid 50.1 copy of MAT_IntegrationPointRecord.h last changed by upd111 on 2005/06/04 13:23:19 */
////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         Copyright (C) 2001 ANSYS Inc.  All Rights Reserved             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MAT_IntegrationPointRecord.h $
// $Revision$ 7.0
// $Date$ October 21 2003
// $Author$ rjayasee
//
// Description :
//          Material Record Used to query/write  Element/Material Data
////////////////////////////////////////////////////////////////////////////

#if !defined(MAT_IntegrationPointRecord_H)
#define MAT_IntegrationPointRecord_H

#include "ANS_StandardIncludes.h"
#include "ANS_Allocator.h"
#include "MAT_DataRecord.h"


typedef MAT_DataRecord* MAT_DataRecordPtr ;
typedef pair<INT,MAT_DataRecordPtr > MAT_DataRecordPair ;
typedef ANS_Allocator<MAT_DataRecordPtr > MAT_DataRecordPtrAllocator ;
typedef vector<MAT_DataRecordPtr ,MAT_DataRecordPtrAllocator > MAT_DataRecordVector ;

//_Rb_Tree_Node
class MAT_IntegrationPointRecord
{
    public:

    MAT_IntegrationPointRecord() ;
    //Constructor

    ~MAT_IntegrationPointRecord() ;
    //Destructor

    void SetDataRecordPtrArray( MAT_DataRecord** pDataRecPtrPtr, INT iMaxDataRecords );
    //R void
    //I iMaxDataRecords
    //- Max DataRecords
    //- Sets the Max Data Records

    inline void * operator new(size_t iMemSize )
    {
            return MAT_FASTMALLOC(iMemSize) ;
    }

    inline void * operator new[]( size_t iSize )
    {
            return MAT_FASTMALLOC((sizeof(MAT_IntegrationPointRecord)*iSize)) ;
    }

    inline void operator delete(void * pMemPtr)
    {
            MAT_FASTFREE(pMemPtr) ;
    }

    inline void operator delete[](void * pMemPtr )
    {
        MAT_FASTFREE(pMemPtr) ;
    }


    inline bool SetIntegrationPointId( INT iID ) 
    { 
        if ( iID < 1 ) return false ;
        m_iIntegrationPointNumber = iID; 
        return true; 
    } ;
    //R
    //I iID
    //I ID
    //- Sets Integration Point ID

    inline INT GetIntegrationPointId() 
    {
        return m_iIntegrationPointNumber;
    } ;
    //R
    //O iID
    //O ID
    //- Gets Integration Point ID

    INT GetNumberOfRecords()
    {
        return m_iNumDataRecords ;
    }
    //R INT
    //- Gets Number of Records

    bool AddDataRecord( INT iRecordIndex, MAT_DataRecord* pDataRecord ) ;
    //R result
    //I iRecordIndex
    //I-Type of Record Being Added
    //I pDataRecord
    //I-New Record being added
    //- Add a Data Record Given a Record Index and the Record

    bool GetDataRecord( INT iRecordIndex, MAT_DataRecord*& pDataRecord ) ;
    //R result
    //I iRecordIndex
    //I-Type of Record Being Queried
    //I pDataRecord
    //I-New Record being added
    //- Get a Data Record Given a Record Index and the Record

    bool GetNthDataRecord( INT iRecordIndex, MAT_DataRecord*& pDataRecord ) ;
    //R result
    //I iRecordIndex
    //I-Type of Record Being Queried
    //I pDataRecord
    //I-New Record being added
    //- Get a Nth Data Record 

    void Print() ;
    //R void
    //- Prints Data Stored

    private:

    INT m_iNumDataRecords ;

    INT m_iIntegrationPointNumber ;
    //Index/ID of Integration Point.

    MAT_DataRecord** m_pDataRecordVector ;
    // The Data Records Map. Index Vs DataRecord

    INT m_iMaxDataRecordSize ;
    // Maximum Number of Data Records
};
#endif

