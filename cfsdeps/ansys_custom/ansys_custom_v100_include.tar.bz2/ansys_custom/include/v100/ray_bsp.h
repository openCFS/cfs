/* sid 50.1 copy of ray_bsp.h last changed by upd111 on 2005/06/04 13:19:14 */

/*********************/
/* 3d geometry types */
/*********************/

typedef struct Point3Struct {	/* 3d point */
	double x, y, z;
	} Point3;
typedef Point3 Vector3;
/************/
/* booleans */
/************/

#define TRUE		1
#define FALSE		0
#define ON		1
#define OFF 		0
/*
typedef bool boolean;		
*/


typedef struct GeomObj{
     Point3   min, max;          /* extent of the primitive  */
     /* definition for different primitives */
     Point3   vert[4];           /* object vertices          */
     int      numvrts;           /* number of vertices       */
     int      objectID;          /* Index of raytrace object */
     void     *RayObjAddr;       /* Address  raytrace object */
     int      Cullflg ;          /* Cull flag for triangle   */
     struct   GeomObj   *Next;
} GeomObj, *GeomObjPtr;

typedef struct {
    /* Link list of primitives */
    GeomObj *primlist;
    int  length;                /* Length of the link list */
} GeomObjList;

typedef struct {
       Point3     origin;       /* ray origin */
       Point3     direction;    /* unit vector, indicating ray direction */
} RayBsp;

typedef struct BinNode {
    Point3      min, max;      /* extent of node */
    GeomObjList members;       /* list of enclosed primitives */
    struct BinNode *child[2];  /* pointers to children nodes, if any */

    /* distance to the plane which subdivides the children */
    double  (*DistanceToDivisionPlane)();

    /* children near/far ordering relative to a input point */
    void    (*GetChildren)();

} BinNode, *BinNodePtr;

typedef struct {
    Point3     min, max;       /* extent of the entire bin tree */
    GeomObjList members;       /* list of all of the primitives */
    int         MaxDepth;      /* max allowed depth of the tree */
    int         MaxListLength; /* max primitive allowed in a leaf node */
    BinNodePtr  root;          /* root of the entire bin tree */
} BinTree;


