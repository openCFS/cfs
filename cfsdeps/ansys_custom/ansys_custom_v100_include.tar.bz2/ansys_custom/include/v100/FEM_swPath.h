/* sid 50.1 copy of FEM_swPath.h last changed by upd111 on 2004/11/04 18:32:25 */
#ifndef FEM_SWPATH________H
#define FEM_SWPATH________H

#include "FEM_cdbtypes.h"
#include "FEM_Public.h"
#include "FEM_deque.h"

class SWPATH_TYP;
typedef class SWPATH_TYP *SWPATH_PTYP;

class SWPATH_TYP {

   private:
      INT m_length;
      INT m_allocatedlength;
      unsigned m_allharddivs:1;
      LINE_PTYP *m_aobj_lines;

   public:
      SWPATH_TYP() { m_allharddivs = 0; m_length = 0; m_allocatedlength = 0;
                     m_aobj_lines = NULL; };
      ~SWPATH_TYP() { Delete(); };
      void Init()
      {
         m_allharddivs = 0;
         m_length = 0;
         m_allocatedlength = 0;
         m_aobj_lines = NULL;
      }

      void Delete()
      {
         m_allharddivs = 0;
         m_length = 0;
         m_allocatedlength = 0;
         FEM_Free_C( m_aobj_lines );
      }
      INT Length() const { return m_length; };

      void SetAllHardDivs( const FEM_BOOLEAN stat = TRUE )
      {
         if ( stat ) m_allharddivs = 1;
         else m_allharddivs = 0;
      };
      FEM_BOOLEAN AllHardDivs( void ) const
      {
         if ( m_allharddivs ) return 1;
         else return 0;
      };
      LINE_PTYP operator[] ( const INT index ) const
      {
         if ( index < 0 || index >= m_length ) {
            return NULL;
         }
         return m_aobj_lines[index];
      };

      INT StoreLines( DEQUE_OBJ obj_linedeque );
      INT Copy( SWPATH_PTYP pobj_path );
      LINE_PTYP getPathLine( INT idx )
      {
         if ( idx < 0 || idx >= m_length ) 
            return NULL;
         return m_aobj_lines[idx];
      };
}; 


#endif
