/* sid 50.2 copy of MAT_TBCDWrite.h last changed by rjayasee on 2005/03/08 18:48:32 */

/*
////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         Copyright (C) 2001 ANSYS Inc.  All Rights Reserved             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MAT_TBCDWrite.h $
// $Revision$ 7.0
// $Date$ Feb 9 2005
// $Author$ rjayasee
//
// Decription :
//
//	C Entry point from Ansys to the Curve Fitting Code. This has all the
//  Command Parsing code
//////////////////////////////////////////////////////////////////////////////
*/

/*  tbfit.h */
#if !defined(MAT_TBCDWrite__1)
#define MAT_TBCDWrite__1
#define MAT_TBCDWrite_Get__1


/* (1)----------------------------------------------------------------*/
#if defined(LOWERCASENOUNDER_SYS)

/*
 *   The pattern for these platforms is the lowercased version of the name
 */

#define MAT_TBCDWrite          mat_tbcdwrite
#define MAT_TBCompCDW          mat_tbcompcdw
#endif


/* (2)----------------------------------------------------------------*/
#if defined(UPPERCASENOUNDER_SYS)

/*
 *   The pattern for these platforms is the uppercased version of the name
 */

#define MAT_TBCDWrite          MAT_TBCDWRITE
#define MAT_TBCompCDW          MAT_TBCOMPCDW

#endif


/* (3)----------------------------------------------------------------*/
#if defined(LOWERCASEUNDER_SYS)

/*
 *   The pattern for these platforms is the lowercased version of the name 
 *   followed by an underscore
 */

#define MAT_TBCDWrite          mat_tbcdwrite_
#define MAT_TBCompCDW          mat_tbcompcdw_


#endif


/* (4)----------------------------------------------------------------*/

/*
 *   This section is for definition of prototypes.  Each prototype 
 *   should be ANSI compliant and specify the types of each parameter 
 *   as well as the return type.
 */
#ifdef __cplusplus
extern "C"
{
#endif

INT FUNCTION MAT_TBCDWrite(INT* pUnit, INT* pMatId, DOUBLE* pTBData) ;
INT FUNCTION MAT_TBCompCDW(INT* pUnit, INT* pMatId, DOUBLE* pTBData) ;

#ifdef __cplusplus
}

#endif

#endif
