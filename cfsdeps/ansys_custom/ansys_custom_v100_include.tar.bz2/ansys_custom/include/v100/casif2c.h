/* sid 50.2 copy of casif2c.h last changed by jrb on 2005/04/22 19:48:06 */
/* casif2c.h  --  Standard Fortran to C header file */

/**  barf  [ba:rf]  2.  "He suggested using FORTRAN, and everybody barfed."

	- From The Shogakukan DICTIONARY OF NEW ENGLISH (Second edition) */
#ifndef F2C_INCLUDE
#define F2C_INCLUDE

typedef int logical;

#define TRUE_ (1)
#define FALSE_ (0)

typedef int ftnlen;

#define abs_CASI(x) ((x) >= 0 ? (x) : -(x))
#define dabs_CASI(x) (DOUBLE)abs_CASI(x)
#define min_CASI(a,b) ((a) <= (b) ? (a) : (b))
#define max_CASI(a,b) ((a) >= (b) ? (a) : (b))
#define dmin_CASI(a,b) (DOUBLE)min_CASI(a,b)
#define dmax_CASI(a,b) (DOUBLE)max_CASI(a,b)

#endif

#undef KR_headers

