/* sid 50.11 copy of CadoeAnsys.h last changed by jdbeley on 2005/04/29 12:42:18 */
/* 
 *  CadoeAnsys.h -- some common definitions for the Cadoe/Ansys product
 *
 *  |Auteur: Frederic Thevenon
 *
 *  |Version: $Id$
 */
#ifndef __CADOEANSYS_H__
#define __CADOEANSYS_H__ 1

#include "cadoe_int.h"
#include "m_matrix.h"

/* matrix code */
#define MATA_CPLX 1
#define MATK_REAL 2
#define MATC_REAL 3
#define MATM_REAL 4
#define MATK_CPLX 5

/* execution status checking macros. */
#define CHKIER { if (*ier != SUCCES) { Trace(fctn);}
#define CHKIERV if (*ier != SUCCES)  { Trace(fctn); return;}
#define CHKIERS if (ier != SUCCES )  { Trace(fctn); return ECHEC;}
#define CHKIERT if (*ier != SUCCES ) { Trace(fctn); return ECHEC;}
#define CHKIERP if (*ier != SUCCES ) { Trace(fctn); return NULL;}
#define CHKIERN if (ier != SUCCES )  { Trace(fctn); return NULL;}
#define CHKIERQ if (*ier != SUCCES ) { Trace(fctn); return 0;}

#define DB_NUMDEFINED 12
#define DB_NUMSELECTED 13
#define DB_MAXDEFINED 14
#define DB_MAXRECLENG 15
#define DB_GETNEXTRECD 16
#define DB_SELECTED 1

#define SV_FRONT	0
#define SV_JCG		1
#define SV_JCGOUT	2
#define SV_PCG		3
#define SV_PCGOUT	4
#define SV_ICCG		5
#define SV_ICCGOUT	6
#define SV_JCGNEW	7
#define SV_SPARSE	8
#define SV_USER		9
#define SV_AMG		10
#define SV_DOMAIN	11
#define SV_DPCG		12
#define SV_DJCG		13
#define SV_DSP		14

#if defined(LOWERCASENOUNDER_SYS)
#define fx_ls_extmodl 		fx_ls_extmodl
#define lire_nb_mode 		lire_nb_mode
#define lire_freq_mode 		lire_freq_mode
#define fx_ls_resid	       	fx_ls_resid
#define fx_nm_resid	       	fx_nm_resid
#define cadoe_bacsub	       	cadoe_bacsub
#define cadoe_getBCdispReal	cadoe_get_bcdispreal
#define svkan	               	svkan
#define svkan3_cadoe		svkan3_cadoe
#define liresol	               	liresol
#define cadoe_nb_supp_pres      cadoe_nb_supp_pres
#define cadoe_list_supp_pres    cadoe_list_supp_pres
#define cadoe_nb_cpce           cadoe_nb_cpce
#define list_cpce		list_cpce
#define cadoe_list_cpce         cadoe_list_cpce
#define next_element	        next_element   	
#define sx_next_active_elem	sx_next_active_elem    	
#define sx_next_active_elem_pp	sx_next_active_elem_pp    	
#define indice_element	       	indice_element
#define out_stress	       	out_stress
#define out_strain	       	out_strain
#define out_force	       	out_force
#define out_tg	       		out_tg
#define out_tf	       		out_tf
#define out_b	       		out_b
#define out_h	       		out_h
#define out_jt	       		out_jt
#define out_fmag	       	out_fmag
#define out_mass	       	out_mass
#define sx_out_mass_init        sx_out_mass_init
#define get_epsi               	get_epsi
#define get_is_spring           get_is_spring
#define sxopenfull		sxopenfull
#define sxclosefull		sxclosefull
#define sxopenfullnew           sxopenfullnew
#define sxinquirefull           sxinquirefull
#define fx_stiff_part		fx_stiff_part
#define get_xyz               	get_xyz
#define sx_update_node          sx_update_node
#define fact_kmw2m              fact_kmw2m
#define elm_is_active_for_stress elm_is_active_for_stress
#define elm_is_active_for_force elm_is_active_for_force
#define elm_is_active_for_tg    elm_is_active_for_tg
#define elm_is_active_for_tf    elm_is_active_for_tf
#define elm_is_active_for_b    elm_is_active_for_b
#define elm_is_active_for_h    elm_is_active_for_h
#define elm_is_active_for_jt    elm_is_active_for_jt
#define elm_is_active_for_fmag    elm_is_active_for_fmag
#define dwdot                   dwdot
#define expandu                 expandu
#define ndpang                  ndpang
#define ndpxyz2					ndpxyz2
#define rigidbody		rigidbody
#define dgeev 			dgeev
#define sxgetfullinfo		sxgetfullinfo
#define getmapbcstoansys	getmapbcstoansys
#define sxgetforce		sxgetforce
#define sxgetmatbcs		sxgetmatbcs
#define SxUpdateContactKey      sxupdatecontactkey
#define SxSetActiveAllElemsKey  sxsetactiveallelemskey
#define SxGetActiveAllElemsKey  sxgetactiveallelemskey
#define SxGetInLoadValue	sxgetinloadvalue
#define SxInLoadUpd		sxinloadupd
#define putcadoeubuckling	putcadoeubuckling
#define csym_ceequalupd         csym_ceequalupd
#define sectim                  sectim
#define pagend                  pagend
#define rfget                   rfget
#define fget                    fget
#define forget                  forget
#define RunCommand              runcommand
#define wrinqr					wrinqr
#define wrinfo					wrinfo
#define CreateDOFmapsPCG	createdofmapspcg
#define sfform                  sfform
#define eqfadd                  eqfadd
#define derivativeCpGtU         derivativecpgtu
#define derivativeGtU           derivativegtu
#define init_speedup            init_speedup
#define free_speedup            free_speedup
#define enrichQ                 enrichq
#define minresQ                 minresq
#define fwend                   fwend
#define fwend2                  fwend2
#define clearSolverData         clearsolverdata
#define upddsp                  upddsp
#define lnstrt                  lnstrt
#define sx_copy_cnv_crit        sx_copy_cnv_crit    
#define sx_write_mat_elem       sx_write_mat_elem    
#define getFaceId               getfaceid 
#define cnvfor                  cnvfor 
#define sxgetcforce 		sxgetcforce
#define cadoe_getBCdisp 	cadoe_getbcdisp 
#endif

#if defined(UPPERCASENOUNDER_SYS)
#define fx_ls_extmodl 		FX_LS_EXTMODL
#define lire_nb_mode 		LIRE_NB_MODE
#define lire_freq_mode 		LIRE_FREQ_MODE
#define fx_ls_resid	       	FX_LS_RESID
#define fx_nm_resid	       	FX_NM_RESID
#define cadoe_bacsub	       	CADOE_BACSUB
#define cadoe_getBCdispReal	CADOE_GET_BCDISPREAL
#define svkan	               	SVKAN
#define svkan3_cadoe		SVKAN3_CADOE
#define liresol	               	LIRESOL
#define cadoe_nb_supp_pres      CADOE_NB_SUPP_PRES
#define cadoe_list_supp_pres    CADOE_LIST_SUPP_PRES
#define list_cpce		LIST_CPCE
#define cadoe_nb_cpce           CADOE_NB_CPCE
#define cadoe_list_cpce         CADOE_LIST_CPCE
#define next_element	        NEXT_ELEMENT   	
#define sx_next_active_elem	SX_NEXT_ACTIVE_ELEM
#define sx_next_active_elem_pp	SX_NEXT_ACTIVE_ELEM_PP
#define indice_element	       	INDICE_ELEMENT
#define out_stress	       	OUT_STRESS
#define out_strain	       	OUT_STRAIN
#define out_force	       	OUT_FORCE
#define out_tg   	       	OUT_TG   
#define out_tf   	       	OUT_TF   
#define out_b   	       	OUT_B   
#define out_h   	       	OUT_H   
#define out_jt   	       	OUT_JT   
#define out_fmag   	       	OUT_FMAG   
#define out_mass	       	OUT_MASS
#define sx_out_mass_init        SX_OUT_MASS_INIT
#define get_epsi               	GET_EPSI
#define get_is_spring           GET_IS_SPRING
#define sxopenfull		SXOPENFULL
#define sxclosefull		SXCLOSEFULL
#define sxopenfullnew           SXOPENFULLNEW
#define sxinquirefull           SXINQUIREFULL
#define fx_stiff_part		FX_STIFF_PART
#define get_xyz               	GET_XYZ
#define sx_update_node		SX_UPDATE_NODE
#define fact_kmw2m              FACT_KMW2M
#define elm_is_active_for_stress ELM_IS_ACTIVE_FOR_STRESS
#define elm_is_active_for_force ELM_IS_ACTIVE_FOR_FORCE
#define elm_is_active_for_tg    ELM_IS_ACTIVE_FOR_TG
#define elm_is_active_for_tf    ELM_IS_ACTIVE_FOR_TF
#define elm_is_active_for_b     ELM_IS_ACTIVE_FOR_B
#define elm_is_active_for_h     ELM_IS_ACTIVE_FOR_H
#define elm_is_active_for_jt    ELM_IS_ACTIVE_FOR_JT
#define elm_is_active_for_fmag  ELM_IS_ACTIVE_FOR_FMAG
#define dwdot                   DWDOT
#define expandu                 EXPANDU
#define ndpang                  NDPANG
#define ndpxyz2					NDPXYZ2
#define rigidbody		RIGIDBODY
#define dgeev 			DGEEV
#define sxgetfullinfo		SXGETFULLINFO
#define getmapbcstoansys	GETMAPBCSTOANSYS
#define sxgetforce		SXGETFORCE
#define sxgetmatbcs		SXGETMATBCS
#define SxUpdateContactKey      SXUPDATECONTACTKEY
#define SxSetActiveAllElemsKey  SXSETACTIVEALLELEMSKEY
#define SxGetActiveAllElemsKey  SXGETACTIVEALLELEMSKEY
#define SxGetInLoadValue	SXGETINLOADVALUE
#define SxInLoadUpd		SXINLOADUPD
#define putcadoeubuckling	PUTCADOEUBUCKLING
#define csym_ceequalupd         CSYM_CEEQUALUPD
#define sectim                  SECTIM
#define pagend                  PAGEND
#define rfget                   RFGET
#define fget                    FGET
#define forget                  FORGET
#define RunCommand              RUNCOMMAND
#define wrinqr					WRINQR
#define wrinfo					WRINFO
#define CreateDOFmapsPCG	CREATEDOFMAPSPCG
#define sfform                  SFFORM
#define eqfadd                  EQFADD
#define derivativeCpGtU         DERIVATIVECPGTU
#define derivativeGtU           DERIVATIVEGTU
#define init_speedup            INIT_SPEEDUP
#define free_speedup            FREE_SPEEDUP
#define enrichQ                 ENRICHQ
#define minresQ                 MINRESQ
#define fwend                   FWEND
#define fwend2                  FWEND2
#define clearSolverData         CLEARSOLVERDATA
#define upddsp                  UPDDSP
#define lnstrt                  LNSTRT
#define sx_write_mat_elem       SX_WRITE_MAT_ELEM    
#define sx_copy_cnv_crit        SX_COPY_CNV_CRIT    
#define getFaceId               GETFACEID   
#define cnvfor                  CNVFOR 
#define sxgetcforce 		SXGETCFORCE
#define cadoe_getBCdisp 	CADOE_GETBCDISP
#endif

#if defined(LOWERCASEUNDER_SYS)
#define fx_ls_extmodl 		fx_ls_extmodl_
#define lire_nb_mode 		lire_nb_mode_
#define lire_freq_mode 		lire_freq_mode_
#define fx_ls_resid		fx_ls_resid_
#define fx_nm_resid		fx_nm_resid_
#define cadoe_bacsub		cadoe_bacsub_
#define cadoe_getBCdispReal	cadoe_getbcdispreal_
#define svkan		        svkan_
#define svkan3_cadoe		svkan3_cadoe_
#define liresol		        liresol_
#define cadoe_nb_supp_pres	cadoe_nb_supp_pres_
#define cadoe_list_supp_pres	cadoe_list_supp_pres_
#define list_cpce	        list_cpce_
#define cadoe_nb_cpce	        cadoe_nb_cpce_
#define cadoe_list_cpce	        cadoe_list_cpce_
#define next_element            next_element_
#define sx_next_active_elem	sx_next_active_elem_
#define sx_next_active_elem_pp	sx_next_active_elem_pp_
#define indice_element	       	indice_element_
#define out_stress		out_stress_
#define out_strain		out_strain_
#define out_force		out_force_
#define out_tg   		out_tg_
#define out_tf   		out_tf_
#define out_b   		out_b_
#define out_h   		out_h_
#define out_jt   		out_jt_
#define out_fmag   		out_fmag_
#define out_mass		out_mass_
#define sx_out_mass_init        sx_out_mass_init_
#define get_epsi                get_epsi_
#define get_is_spring           get_is_spring_
#define sxopenfull		sxopenfull_
#define sxclosefull		sxclosefull_
#define sxopenfullnew           sxopenfullnew_
#define sxinquirefull           sxinquirefull_
#define fx_stiff_part		fx_stiff_part_
#define get_xyz                 get_xyz_
#define sx_update_node		sx_update_node_
#define fact_kmw2m              fact_kmw2m_
#define elm_is_active_for_stress elm_is_active_for_stress_
#define elm_is_active_for_force elm_is_active_for_force_
#define elm_is_active_for_tg    elm_is_active_for_tg_
#define elm_is_active_for_tf    elm_is_active_for_tf_
#define elm_is_active_for_b     elm_is_active_for_b_
#define elm_is_active_for_h     elm_is_active_for_h_
#define elm_is_active_for_jt    elm_is_active_for_jt_
#define elm_is_active_for_fmag    elm_is_active_for_fmag_
#define dwdot                   dwdot_
#define expandu                 expandu_
#define ndpang                  ndpang_
#define ndpxyz2					ndpxyz2_
#define rigidbody		rigidbody_
#define dgeev 			dgeev_
#define sxgetfullinfo		sxgetfullinfo_
#define getmapbcstoansys	getmapbcstoansys_
#define sxgetforce		sxgetforce_
#define sxgetmatbcs		sxgetmatbcs_
#define SxUpdateContactKey      sxupdatecontactkey_
#define SxSetActiveAllElemsKey  sxsetactiveallelemskey_
#define SxGetActiveAllElemsKey  sxgetactiveallelemskey_
#define SxGetInLoadValue	sxgetinloadvalue_
#define SxInLoadUpd		sxinloadupd_
#define putcadoeubuckling	putcadoeubuckling_
#define csym_ceequalupd         csym_ceequalupd_
#define sectim                  sectim_
#define pagend                  pagend_
#define rfget                   rfget_
#define fget                    fget_
#define forget                  forget_
#define RunCommand              runcommand_
#define wrinqr					wrinqr_
#define wrinfo					wrinfo_
#define CreateDOFmapsPCG	createdofmapspcg_
#define sfform                  sfform_
#define eqfadd                  eqfadd_
#define derivativeCpGtU         derivativecpgtu_
#define derivativeGtU           derivativegtu_
#define init_speedup            init_speedup_
#define free_speedup            free_speedup_
#define enrichQ                 enrichq_
#define minresQ                 minresq_
#define fwend                   fwend_
#define fwend2                  fwend2_
#define clearSolverData         clearsolverdata_
#define upddsp                  upddsp_
#define lnstrt                  lnstrt_
#define sx_write_mat_elem       sx_write_mat_elem_   
#define sx_copy_cnv_crit        sx_copy_cnv_crit_    
#define getFaceId                getfaceid_ 
#define cnvfor                  cnvfor_
#define sxgetcforce 		sxgetcforce_
#define cadoe_getBCdisp 	cadoe_getbcdisp_
#endif

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

  SUBROUTINE fx_ls_extmodl( INT *ier );
  SUBROUTINE lire_nb_mode( INT *nb_mode );
  SUBROUTINE lire_freq_mode( DOUBLE*, DOUBLE*, INT*, INT * );
  SUBROUTINE fx_ls_resid( DOUBLE*, DOUBLE*, DOUBLE*, INT*, INT*, INT*);
  SUBROUTINE fx_nm_resid( DOUBLE*, DOUBLE*, DOUBLE* , INT*);
  SUBROUTINE cadoe_bacsub( INT*, DOUBLE*, DOUBLE*, INT *, INT *, INT *, INT *, INT *);
  SUBROUTINE cadoe_getBCdispReal(INT *nb_ddl, DOUBLE *X);
  SUBROUTINE svkan(INT *restrt);
  SUBROUTINE svkan3_cadoe(INT *restrt, INT *cadoe_pass);
  SUBROUTINE liresol(DOUBLE *U);
  SUBROUTINE cadoe_nb_supp_pres(INT *nb_supp, INT *nb_pres);
  SUBROUTINE cadoe_list_supp_pres(INT *list_supp, INT *list_pres, 
				  DOUBLE *val_pres);
  SUBROUTINE list_cpce(INT *list_cpce);
  SUBROUTINE cadoe_nb_cpce(INT *nb_cpce);
  SUBROUTINE cadoe_list_cpce(INT *list_cpce);
  SUBROUTINE next_element(INT *elord, INT *is_parallel);
  SUBROUTINE sx_next_active_elem( INT *elord);
  SUBROUTINE sx_next_active_elem_pp( INT *elord, INT *is_parallel);
  SUBROUTINE indice_element( INT *elemNo, INT *indice, INT *ier);
  SUBROUTINE out_stress(INT *indice, DOUBLE *stress);
  SUBROUTINE out_strain(INT *indice, DOUBLE *strain);
  SUBROUTINE out_force(INT *indice, DOUBLE *force);
  SUBROUTINE out_tg(INT *indice, DOUBLE *tg);
  SUBROUTINE out_tf(INT *indice, DOUBLE *tf);
  SUBROUTINE out_b(INT *indice, DOUBLE *b);
  SUBROUTINE out_h(INT *indice, DOUBLE *h);
  SUBROUTINE out_jt(INT *indice, DOUBLE *jt);
  SUBROUTINE out_fmag(INT *indice, DOUBLE *fmag);
  SUBROUTINE out_mass(INT *indice, DOUBLE *mass);
  SUBROUTINE sx_out_mass_init(INT *numero, DOUBLE *mass);
  SUBROUTINE get_epsi( DOUBLE *epsi);
  SUBROUTINE get_is_spring( INT *indice, INT *is_spring);
  SUBROUTINE get_xyz( INT *indice, INT *nb_noeud, DOUBLE *xyz_el);
  SUBROUTINE sx_update_node( INT *num, DOUBLE *xyz_node);
  SUBROUTINE fact_kmw2m( DOUBLE *lambda0, INT *restrt, INT *where, 
			 INT *kdone, INT *ier);
  INT FUNCTION elm_is_active_for_stress(INT *indice);
  INT FUNCTION elm_is_active_for_force(INT *indice);
  INT FUNCTION elm_is_active_for_tg(INT *indice);
  INT FUNCTION elm_is_active_for_tf(INT *indice);
  INT FUNCTION elm_is_active_for_b(INT *indice);
  INT FUNCTION elm_is_active_for_h(INT *indice);
  INT FUNCTION elm_is_active_for_jt(INT *indice);
  INT FUNCTION elm_is_active_for_fmag(INT *indice);
  SUBROUTINE sxopenfull(void);
  SUBROUTINE sxclosefull(void);
  SUBROUTINE sxopenfullnew(void);
  INT FUNCTION  sxinquirefull(void);
  
  SUBROUTINE fx_stiff_part( DOUBLE *U, DOUBLE *KU, DOUBLE *F, INT *FORCE_CALL,
			    INT *KEY_TO_FORCECALU, INT *KELREQ, INT*IER);
  DOUBLE FUNCTION dwdot( INT*, DOUBLE*, INT*, DOUBLE*, INT*, DOUBLE*, INT* );
  double FNM_dwdot( VEC*, VEC*, T_statut* );
  SUBROUTINE expandu(DOUBLE *disp, INT *no_of_disp);
  SUBROUTINE ndpang( INT *numnode , DOUBLE *angles );
  SUBROUTINE ndpxyz2( INT *numnode, DOUBLE *xyz );
  SUBROUTINE rigidbody(INT*, DOUBLE*, INT*);
  SUBROUTINE dgeev(FCHAR(c1), FCHAR(c2), INT*, DOUBLE*, INT*, DOUBLE*, DOUBLE*, DOUBLE*, INT*, DOUBLE*, INT*, DOUBLE*, INT*, INT* FCHARL(c1_len) FCHARL(c2_len) );

  SUBROUTINE sxgetfullinfo( INT *Matrix, INT *nbcs, INT *ncefull, INT *ntrmMat);
  SUBROUTINE getmapbcstoansys( INT *FULLtoBCSdof, INT *BCStoANSdof, INT *FULLtoANSdof);
  SUBROUTINE sxgetforce( INT *full2bcs, DOUBLE *fullvalues, DOUBLE *bcsvalues, INT *ier);
  SUBROUTINE sxgetcforce( INT *full2bcs, T_complex *fullvalues, T_complex *bcsvalues, INT *ier);
  SUBROUTINE sxgetmatbcs( INT *matid, INT *full2bcs, INT *rowslength, INT *colnum, DOUBLE *values, INT *ier);
  SUBROUTINE SxUpdateContactKey( INT *key );
  SUBROUTINE SxSetActiveAllElemsKey( INT *key );
  SUBROUTINE SxGetActiveAllElemsKey( INT *key );
  DOUBLE FUNCTION SxGetInLoadValue( INT*, INT* );
  SUBROUTINE SxInLoadUpd( INT*, INT*, DOUBLE* );
  SUBROUTINE putcadoeubuckling(DOUBLE *disp);
  SUBROUTINE csym_ceequalupd(DOUBLE *, T_statut * );
  SUBROUTINE sectim(DOUBLE * );

  SUBROUTINE pagend(INT*, INT*, INT*, INT*, INT*, INT*, DOUBLE*);
  INT FUNCTION rfget(INT*, INT*, INT*, DOUBLE*);
  DOUBLE FUNCTION fget(INT*, INT*, INT*);
  INT FUNCTION forget(INT*, INT*, DOUBLE*);
  INT FUNCTION RunCommand( INT*, FCHAR(c1) FCHARL(c1_len) );
  INT FUNCTION wrinqr( INT* );
  SUBROUTINE wrinfo( INT*, INT* );
  SUBROUTINE CreateDOFmapsPCG(INT *,INT *,INT *,INT *,INT *,INT *,INT *,INT *,INT *);
  SUBROUTINE sfform(INT*, INT*, DOUBLE*, INT*, INT*, INT*, INT*, INT*);
  SUBROUTINE eqfadd(INT*, DOUBLE*);
  SUBROUTINE derivativeCpGtU(INT*, DOUBLE*);
  SUBROUTINE derivativeGtU(DOUBLE*);
  SUBROUTINE init_speedup(long*, INT*, INT*);
  SUBROUTINE free_speedup(long*, INT*);
  SUBROUTINE enrichQ(long*, INT*, DOUBLE*, DOUBLE*, DOUBLE*, 
		     DOUBLE*, INT*, INT*);
  SUBROUTINE minresQ(long*, INT*, INT*, DOUBLE*, DOUBLE*, 
		     INT*, INT*, INT*, INT*,
		     INT*, DOUBLE*, INT*, DOUBLE*, INT*, INT*,
		     INT*, INT*, INT*);
  SUBROUTINE fwend(INT *, INT*);
  SUBROUTINE fwend2(INT *, INT*);
  SUBROUTINE clearSolverData(void);
  SUBROUTINE upddsp(INT*, DOUBLE*, INT*);
  SUBROUTINE lnstrt(INT*, INT*);
  SUBROUTINE sx_write_mat_elem(INT*, INT*, DOUBLE*);
  SUBROUTINE sx_copy_cnv_crit(DOUBLE*, DOUBLE*); 
  SUBROUTINE getFaceId( INT *iele, INT *iface, INT *nb_comp );
  SUBROUTINE cnvfor(DOUBLE *, DOUBLE *, DOUBLE *, INT *, INT *, INT *);
  SUBROUTINE cadoe_getBCdisp(INT *nb_ddl, T_complex *X );

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif


