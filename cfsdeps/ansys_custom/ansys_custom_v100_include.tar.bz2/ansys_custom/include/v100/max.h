/* sid 50.1 copy of max.h last changed by upd111 on 2005/06/04 13:14:58 */
/*   max.h                          kz372 */
/* 
 * *** ansys(r) copyright(c) 2000
 * *** ansys, inc.
 */

/*  Get maximum number of entities associated with subentity.*/ 
INT
CALLTYP xAnsysSubEntIdMax_ ansPROTO((
     INT  *dim 		/* I: dimension of subentities to inquire */
));

/*  Return max number of supcells in database*/ 
INT
CALLTYP xAnsysSubEntSupCellMax_ ansPROTO((
     INT *dim 			/* I: dimension of subent */
));

/*  Find maximum number of cells of dimension dim.*/ 
INT
CALLTYP xAnsysSubEntMax_ ansPROTO((
     INT  *dim 		/* I: dimension of subentities to inquire */
));

/*  Find max number of subentities associated with an entity.*/ 
INT
CALLTYP xAnsysEntCellMax_ ansPROTO((
     INT *dim 			/* I: dimension of entities to inquire */
));

/*  Find max number of sup entities for an entity of _dim.*/ 
INT
CALLTYP xAnsysEntSupEntMax_ ansPROTO((
     INT *dim 			/* I: dimension of entities to inquire */
));

/*  Return max size of parameter record.*/ 
INT
CALLTYP xAnsysMapParamMax_ ansPROTO((
     INT  *dim 		/* I: dimension of maps to inquire */
));

/*  Find max number of cells sharing a map of _dim*/ 
INT
CALLTYP xAnsysMapCellMax_ ansPROTO((
     INT  *dim 		/* I: dimension of maps to inquire */
));
