/* sid 50.1 copy of fifprintf.h last changed by upd111 on 2005/06/04 13:17:34 */

/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 2000 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


#if !defined (__FIFPRINTF_H__)
#define __FIFPRINTF_H__ 1

#include "computer.h"
#include "globals.h"

/* (1)----------------------------------------------------------------*/
#if defined(RS6000_SYS) || defined(HP32_SYS)

/*
 *   The pattern for these platforms is the name with underscore 
 *   redefined to be just the lowercased version of the name.
 */

#define fifprintf_       fifprintf

#endif


/* (2)----------------------------------------------------------------*/
#if defined(WATCOMC_SYS) || defined(PCWINNT_SYS)

/*
 *   The pattern for these platforms is the name with underscore 
 *   redefined to be just the uppercased version of the name.
 */


#define fifprintf_       FIFPRINTF

#endif


/* (3)----------------------------------------------------------------*/
#if defined(WATCOMC_SYS)

/*
 *   The pattern for these platforms is a pragma definition of aux 
 *   followed by the uppercased version of the name followed by "^"
 */

#pragma aux FIFPRINTF "^";

#endif

/* (4)----------------------------------------------------------------*/

VOID CALLTYP fifprintf_(PTR *filePtr, INT *iMessage, INT *numChar);
#endif
