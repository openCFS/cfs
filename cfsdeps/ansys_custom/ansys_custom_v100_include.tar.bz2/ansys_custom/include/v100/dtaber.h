/* sid 50.1 copy of dtaber.h last changed by upd111 on 2005/06/04 13:21:16 */
/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 2000 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  dtabre.h */
#if !defined(__DTABER_H__)
#define __DTABER_H__ 1

#include "ansys.h"

/* (1)----------------------------------------------------------------*/
#if defined(LOWERCASENOUNDER_SYS)

/*
 *   The pattern for these platforms is the lowercased version of the name
 */

#define erinfo                   erinfo
#define erinqr                   erinqr

#endif


/* (2)----------------------------------------------------------------*/
#if defined(UPPERCASENOUNDER_SYS)

/*
 *   The pattern for these platforms is the uppercased version of the name
 */

#define erinfo                   ERINFO
#define erinqr                   ERINFO

#endif


/* (3)----------------------------------------------------------------*/
#if defined(LOWERCASEUNDER_SYS)

/*
 *   The pattern for these platforms is the lowercased version of the name 
 *   followed by an underscore
 */

#define erinfo                   erinfo_
#define erinqr                   erinqr_

#endif


/* (4)----------------------------------------------------------------*/

/*
 *   This section is for definition of prototypes.  Each prototype 
 *   should be ANSI compliant and specify the types of each parameter 
 *   as well as the return type.
 */

SUBROUTINE erinfo(INT *, INT *);
INT FUNCTION  erinqr(INT *);

#endif
