/* sid 50.1 copy of ansTbtypes.h last changed by jrb on 2005/02/25 19:24:24 */

#include "ansysdef.h"


extern  INT  cCreateAnsTb(void);
extern  INT  cDeleteAnsTb(void);
extern  INT  cInquireAnsTb(INT,INT,INT);
extern  INT  cPutAnsTb(INT,INT,INT,DOUBLE*);
extern  INT  cGetAnsTb(INT,INT,INT*,DOUBLE*);
extern  INT  cGetAnsTbPtr(INT,INT,INT*,DOUBLE**);
extern  INT  cDumpAnsTb(INT);

extern  INT  cPutAnsTbTable(INT,LONGINTC*,INT,INT*,INT*,DOUBLE*);
extern  INT  cGetAnsTbKword(INT,LONGINTC*);
extern  INT  cGetAnsTbKwordPtr(INT,LONGINTC**);
extern  INT  cGetAnsTbIndex(INT,INT*);


/****************************************************************
 global-level structure for ANSYS nonlinear material properties
 ****************************************************************/
struct ansTb_str {        /* Name of the structure                                               */
  INT      tag;           /* Tag for this instance of the material property structure            */
  INT      maxNumProps;   /* Maximum number of properties stored for any nonlinear material      */
  INT      maxNumValues;  /* Maximum number of values stored for any nonlinear material property */
  tbData  *dataVec;       /* Array of material property and temperature data                     */
};

#define ansTbTag(mat)                (mat->tag)
#define ansTbMaxNumProps(mat)        (mat->maxNumProps)
#define ansTbMaxNumValues(mat)       (mat->maxNumValues)

#define ansTbDataPtr(mat)            (mat->dataVec)
#define ansTbDataVec(mat,i)          (mat->dataVec+i)



/******************************************************************
 data-level structure for ANSYS nonlinear material properties
 ******************************************************************/
struct tbData_str {     /* Name of the structure                                                 */
  char       modified;  /* Flag indicating whether this nonlinear material has been modified     */
  char       internal;  /* Flag indicating whether this nonlinear material is internal to object */
  INT        numProps;  /* Number of nonlinear properties stored for this material               */
  LONGINTC  *kword;     /* Array containing nonlinear material property information              */ 
                        /*   (see nlpropkword & initAnsTb for a complete description)            */
  INT       *props;     /* Array of property numbers stored for this nonlinear material          */
  INT       *numValues; /* Number of values stored for each nonlinear material property          */
  DOUBLE   **values;    /* Table of material property values                                     */
                        /*   values[prop][ival] where ival goes from 1->numValues[prop]          */
                        /*                      where prop goes from 1->numProps                 */
};

#define tbDataModified(tData)                (tData->modified)
#define tbDataInternal(tData)                (tData->internal)
#define tbDataNumProps(tData)                (tData->numProps)

#define tbDataKwordPtr(tData)                (tData->kword)
#define tbDataKwordVec(tData,i)              (tData->kword[i])
#define tbDataPropsPtr(tData)                (tData->props)
#define tbDataPropsVec(tData,i)              (tData->props[i])
#define tbDataNumValuesPtr(tData)            (tData->numValues)
#define tbDataNumValuesVec(tData,iProp)      (tData->numValues[iProp])
#define tbDataValuesPtr(tData)               (tData->values)
#define tbDataValuesVec(tData,iProp,iVal)    (tData->values[iProp][iVal])

