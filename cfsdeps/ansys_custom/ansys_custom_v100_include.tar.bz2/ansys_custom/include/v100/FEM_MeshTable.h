/* sid 50.1 copy of FEM_MeshTable.h last changed by upd111 on 2004/11/04 18:29:48 */
/* ********************************** */
/* *** ansys(r) copyright(c) 2000 *** */
/* *** ansys, inc.                *** */
/* ********************************** */

/*  FEM_MeshTable.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/* 
 *  FEM_MeshTable.h
 *  Mesh table xref mesh to fea entity
 *
 */
#ifndef FEM_MESHTABLE
#define FEM_MESHTABLE

#ifndef ux11
#ifdef DSPACE_CMDB
#pragma warning (disable:4786)
#endif
#endif

#define FEMMAKEVERTEXTOPID(t)	(((unsigned long)t)              & 0x1FFFFFFF)
#define FEMMAKEEDGETOPID(t)		((0x40000000 | (unsigned long)t) & 0x5FFFFFFF)
#define FEMMAKEFACETOPID(t)		((0x80000000 | (unsigned long)t) & 0x9FFFFFFF)
#define FEMMAKEVOLUMETOPID(t)	((0xc0000000 | (unsigned long)t) & 0xdFFFFFFF)
#define FEMMAKESHEETTOPID(t)	    ((0x20000000 | (unsigned long)t) & 0x3FFFFFFF)

/* Classify topids */
/**/
#define FEMISVERTEXTOPID(t)		(((unsigned long)t & 0xe0000000) == 0)
#define FEMISEDGETOPID(t)		(((unsigned long)t & 0xe0000000) == 0x40000000)
#define FEMISFACETOPID(t)		(((unsigned long)t & 0xe0000000) == 0x80000000)
#define FEMISVOLUMETOPID(t)		(((unsigned long)t & 0xe0000000) == 0xc0000000)
#define FEMISSHEETTOPID(t)		(((unsigned long)t & 0xe0000000) == 0x20000000)

#define FEMSTRIPTOPID(t)			((unsigned long)t & 0x1FFFFFFF)



#ifdef __cplusplus
extern "C" {
#endif

/* === The following functions can be used by anyone */

/* === NOTE!!!!!!!! IT IS THE CALLERS RESPONSIBILITY TO FREE THE MEMORY SENT BACK BY THE
    ==== FEM_mt* FUNCTIONS */



INT FEM_mtgetNodeOnVertex( INT geoid, NODE_OBJ *obj_node );
INT FEM_mtgetNodesOnVertex( INT geoid, NODE_OBJ **aobj_nodes, INT *length );
INT FEM_mtgetNodesOnEdge( INT geoid, NODE_OBJ **aobj_nodes, INT *length, FEM_BOOLEAN midnodes  );
INT FEM_mtgetEdgesOnEdge( INT geoid, EDGE_OBJ **aobj_edges, INT *length );

INT FEM_mtgetNodesOnFace( INT geoid, NODE_OBJ **aobj_nodes, INT *length, FEM_BOOLEAN midnodes );
INT FEM_mtgetEdgesOnFace( INT geoid, EDGE_OBJ **aobj_edges, INT *length );
INT FEM_mtgetFacesOnFace( INT geoid, FACE_OBJ **aobj_faces, INT *length );

/*
INT FEM_mtgetNodesInVolume( INT geoid, NODE_OBJ **aobj_nodes, INT *length, FEM_BOOLEAN midnodes );
INT FEM_mtgetEdgesInVolume( INT geoid, EDGE_OBJ **aobj_edges, INT *length );
INT FEM_mtgetFacesInVolume( INT geoid, FACE_OBJ **aobj_faces, INT *length );
INT FEM_mtgetElementsInVolume( INT geoid, ELEMENT_OBJ **aobj_elements, INT *length );
*/

INT FEM_mtgetNodesOnAreaBoundary( INT geoid, NODE_OBJ **aobj_nodes, INT *length, FEM_BOOLEAN midnodes );
INT FEM_mtgetEdgesOnFacePlusBoundaryEdges( INT geoid, EDGE_OBJ **aobj_edges, INT *length );
INT FEM_mtgetBoundaryEdgesOnFace( INT geoid, EDGE_OBJ **aobj_edges, INT *length );

INT FEM_mtgetAllNodesOnArea( INT geoid, NODE_OBJ **aobj_nodes, INT *length, FEM_BOOLEAN midnodes );

INT FEM_mtNumFacesOnFace( INT geoid, INT *length );
INT FEM_mtNumNodesOnFace( INT geoid, INT *length );

void FEM_mtDestroyTable();
void FEM_mtDestroyTableForAMesh( MESH_PTYP ps_mesh );


INT FEM_mtaddNodeToTable( unsigned long topoid, NODE_OBJ obj_node );
INT FEM_mtaddEdgeToTable( unsigned long topoid, EDGE_OBJ obj_edge);
INT FEM_mtaddFaceToTable( unsigned long topoid, FACE_OBJ obj_face );
INT FEM_mtaddElementToTable( unsigned long topoid, ELEMENT_OBJ obj_element );

INT FEM_mtremoveNodeFromTable( NODE_OBJ obj_node );
INT FEM_mtremoveEdgeFromTable(  EDGE_OBJ obj_edge );
INT FEM_mtremoveFaceFromTable(  FACE_OBJ obj_face );
INT FEM_mtremoveElementFromTable(  ELEMENT_OBJ obj_element );

INT FEM_mtgetTopoIdListForNode( NODE_OBJ obj_node, unsigned long **a_topoidlist,  INT *length );
INT FEM_mtgetTopoIdListForEdge( EDGE_OBJ obj_edge, unsigned long **a_topoidlist,  INT *length );
INT FEM_mtgetBoundaryEdgesOnFace( INT geoid, EDGE_OBJ **aobj_edges, INT *length );
INT FEM_mtgetBndEdgesOnFaceFromFaceElements( INT geoid, EDGE_OBJ **aobj_edges, INT *length );
INT FEM_mtgetBndNodesOnFaceFromFaceElements( INT geoid, NODE_OBJ **aobj_nodes, INT *length, INT midNode);
#ifdef __cplusplus
}
#endif

#endif
