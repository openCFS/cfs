/* sid 50.1 copy of CFAST_GetProtocol.h last changed by upd111 on 2005/06/04 13:22:55 */
/* CFILE CFAST_GetProtocol.h CADOE */
#ifndef _CFAST_GetProtocol
#define _CFAST_GetProtocol

#ifndef WINNT
    #include <netdb.h>
#else
    #include <winsock2.h>
#endif

#include "CFAST_Exception.h"

class CFAST_GetProtocol
{
#ifndef WINNT
    char cIteratorFlag;        // Protocol database iteration flag
#endif
    struct protoent *protocolPtr;    // Pointer to protocol database entry
public:
#ifndef WINNT
    // Default constructor.  Opens the protocol database
    CFAST_GetProtocol()
    {
        vOpenProtocolDb();
    }
#endif

    // Constructor.  Returns the protoent structure given the protocol name.
    CFAST_GetProtocol(const char *_sName);

    // Constructor.  Returns the protoent structure given the protocol number
    CFAST_GetProtocol(int _iProtocol);

    // Desstructor closes the database connection  
        ~CFAST_GetProtocol()
        {
#ifndef WINNT
                endprotoent();
#endif
        }

    // Opens the protocol database and sets the cIteratorFlag to true
#ifndef WINNT
    void vOpenProtocolDb()
    {
        endprotoent();
        cIteratorFlag = 1;
        setprotoent(1);
    }    

    // Iterates through the list of protocols
    char cGetNextProtocol()
    {
        if (cIteratorFlag == 1)
        {
            if ((protocolPtr = getprotoent()) == NULL)
                return 0;
            else
                return 1;
        }
        return 0;
    } 
#endif

    // Returns the protocol name
    char *sGetProtocolName() { return protocolPtr->p_name; }

    // Returns the protcol number
    int iGetProtocolNumber() { return protocolPtr->p_proto; }

    // Gets the system error
    char *sGetError()
      {
#if defined(WINNT)
	static char buf[10];
	sprintf(buf, "%d", WSAGetLastError());
	return buf;
#else
	return NULL;
#endif
      }
};

#endif
