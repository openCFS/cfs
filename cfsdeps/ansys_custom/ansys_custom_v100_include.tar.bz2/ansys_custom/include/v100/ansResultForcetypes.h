/* sid 50.1 copy of ansResultForcetypes.h last changed by jrb on 2005/02/25 19:24:24 */

#include "ansysdef.h"


extern  INT  cCreateAnsResultForce(void);
extern  INT  cDeleteAnsResultForce(void);
extern  INT  cInquireAnsResultForce(INT,INT,INT);
extern  INT  cPutAnsResultForce(INT,INT,DOUBLE);
extern  INT  cGetAnsResultForce(INT,INT,INT*,DOUBLE*);
extern  INT  cActivateAnsResultForce(INT,INT,INT);
extern  INT  cDumpAnsResultForce(INT);


/****************************************************************
 global-level structure for ANSYS nodal result forces
 ****************************************************************/
struct ansResultForce_str {   /* Name of the structure                               */
  INT       tag;              /* Tag for this instance of the result force structure */
  INT       numForceNodes;    /* Number of nodes with result forces                  */
  INT       maxForceNode;     /* Maximum external node number having result forces   */
  INT       numForce;         /* Total number of result forces (zero and non-zero)   */
};

#define ansResultForceTag(rforce)                (rforce->tag)
#define ansResultForceNumForceNodes(rforce)      (rforce->numForceNodes)
#define ansResultForceMaxForceNode(rforce)       (rforce->maxForceNode)
#define ansResultForceNumForce(rforce)           (rforce->numForce)



/******************************************************************
 data-level structure for ANSYS nodal result forces
 ******************************************************************/
struct resultForceData_str {  /* Name of the structure                                           */
  char             modified;  /* Flag indicating whether this result force has been modified     */
  char             internal;  /* Flag indicating whether this result force is internal to object */
  INT              dof;       /* External DOF value                                              */
  char             active;    /* Flag indicating if result force is active or inactive           */
  DOUBLE           value;     /* Result force value                                              */
  resultForceData *nextForce; /* Pointer to the next result force data structure for this        */
                              /* node.  If this pointer is NULL, then this is the last           */
                              /* stored result force for this node                               */
};

#define resultForceDataModified(rfData)         (rfData->modified)
#define resultForceDataInternal(rfData)         (rfData->internal)
#define resultForceDataDof(rfData)              (rfData->dof)
#define resultForceDataForceActive(rfData)      (rfData->active)
#define resultForceDataValue(rfData)            (rfData->value)

#define resultForceDataNextForcePtr(rfData)     (rfData->nextForce)

