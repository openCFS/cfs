/* sid 50.1 copy of FEM_tetUtil.h last changed by upd111 on 2004/11/04 18:32:29 */
/*  FEM_tetUtil.h */
/*
 * *** ansys(r) copyright(c) 1999
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_tetUtil.h
 *  header file for FEM_tetUtil.c
 *
 */
#ifndef FEM_TET_UTIL_INCLUDE
#define FEM_TET_UTIL_INCLUDE

/* ---------------- Constants -----------------------------------------------*/

#define MEPSF           DBL_EPSILON*100.0

#define EMPTY_CCSPH     0
#define MIN_SOL_ANG     1
#define RADIUS_RATIO    2
#define MEAN_RATIO      3
#define QUAD_MEAN_RATIO 4
#define MAX_FAC_ANG      5
#define QUAD_MAX_FAC_ANG 6

/*----------------- Global variable declarations ----------------------------*/
extern DDOUBLE g_tol;   /* relative tolerance for comparison with 0.0 */
                       /*  can be set by invoking FEM_teSetTolerance */
extern INT g_debug;    /* debug level > 0 produces output to debug file */
extern FILE *g_fpdbg;  /* file pointer for debug output if g_debug > 0  */


/*----------------- Globally accessible function prototypes -----------------*/

#ifdef __cplusplus
extern "C" {
#endif


                              /* =========================================== */
                              /* === FEM_teSetTolerance: set global variable */
                              /* === g_tol to max(tolin,MEPSF)               */
void FEM_teSetTolerance (
   DOUBLE tolin  ); /* desired value for g_tol */

                              /* =========================================== */
                              /* === FEM_teSetJacobErrLimit: set file global */
                              /* === variable fg_JacobErrLimit from Fortran  */
                              /* === common block                            */
void FEM_teSetJacobErrLimit ( 
   INT vnum  );               /* volume number */

                              /* =========================================== */
                              /* === FEM_teStats: compute statistics for     */
                              /* === data a_x[0..n-1]: min, max, mean,       */
                              /* === standard deviation, relative frequency  */
                              /* === in intervals a_x[i] < b+h, b+h <= a_x[i]*/
                              /* === < b+2*h, ..., b+(nf-1)*h <= a_x[i] <    */
                              /* === b+nf*h, and b+nf*h <= a_x[i]            */
void FEM_teStats (
   INT n,              /* number of measurements */
   DOUBLE a_x[],       /* data measurements */
   DOUBLE b, DOUBLE h, /* used for determining frequency intervals as above */
   INT nf,             /* highest index of freq array */
   DOUBLE *xmin,       /* minimum returned */
   DOUBLE *xmax,       /* maximum returned */
   DOUBLE *mean,       /* mean returned */
   DOUBLE *stdv,       /* standard deviation returned */
   DOUBLE a_freq[]  ); /* relative frequencies (fraction of 1) returned */

                              /* =========================================== */
                              /* === FEM_teBaryTet: compute barycentric      */
                              /* === coords of 3-D point wrt 4 tet vertices  */
void FEM_teBaryTet (
   VECTOR3D *a,        /* vertex a of tetrahedron */
   VECTOR3D *b,        /* vertex b of tetrahedron */
   VECTOR3D *c,        /* vertex c of tetrahedron */
   VECTOR3D *d,        /* vertex d of tetrahedron */
   VECTOR3D *e,        /* 5th point for which barycentric coordinates found  */
   DOUBLE reltol,      /* relative tolerance for numerically coplanar        */
   DOUBLE loalp,       /* an alpha[i] between loalp and hialp gets set to 0.0*/
   DOUBLE hialp,       /*  if corresponding volume is relatively small       */
   FEM_BOOLEAN *degen, /* TRUE returned iff a,b,c,d numerically coplanar     */
   DOUBLE alpha[4]  ); /* barycent coords of e wrt tet abcd returned if      */
                       /*  nondegen; e = alpha[0]*a+alpha[1]*b+alpha[2]*c    */
                       /*  +alpha[3]*d                                       */

                              /* =========================================== */
                              /* === FEM_teCircumsphere: find center and     */
                              /* === square of radius of circumsphere through*/
                              /* === 4 tet vertices, and determine whether a */
                              /* === fifth 3-D point is inside sphere        */
void FEM_teCircumsphere (
   VECTOR3D *a,         /* vertex a of tetrahedron */
   VECTOR3D *b,         /* vertex b of tetrahedron */
   VECTOR3D *c,         /* vertex c of tetrahedron */
   VECTOR3D *d,         /* vertex d of tetrahedron */
   VECTOR3D *e,         /* 5th point for in-sphere test */
   DOUBLE reltol,       /* relative tolerance for numerically coplanar       */
   INT *in,             /* return value of 2 if a,b,c,d coplanar; 1 if e in  */
                        /*  sphere; 0 if e on sphere; -1 if e outside sphere */
   DOUBLE *radsq,       /* square of sphere radius returned; -1.0 if *in = 2 */
   VECTOR3D *center  ); /* center of sphere returned in noncoplanar case     */

                              /* =========================================== */
                              /* === FEM_teCircumRadiusInverse: compute      */
                              /* === "inverse" of tet circumradius           */
DOUBLE FEM_teCircumRadiusInverse (
   VECTOR3D *a,    /* vertex a of tetrahedron */
   VECTOR3D *b,    /* vertex b of tetrahedron */
   VECTOR3D *c,    /* vertex c of tetrahedron */
   VECTOR3D *d  ); /* vertex d of tetrahedron */

                              /* =========================================== */
                              /* === FEM_teTetVolume6: compute 6 times signed*/
                              /* === volume of tet abcd where sign positive  */
                              /* === if abc, acd, adb, bdc are CCW from      */
                              /* === outside tet; 0 if degenerate            */
DOUBLE FEM_teTetVolume6 (
   VECTOR3D *a,    /* vertex a of tetrahedron */
   VECTOR3D *b,    /* vertex b of tetrahedron */
   VECTOR3D *c,    /* vertex c of tetrahedron */
   VECTOR3D *d  ); /* vertex d of tetrahedron */

                              /* =========================================== */
                              /* === FEM_teTetVolume6Nodes: same as          */
                              /* === FEM_teTetVolume6 but takes the node     */
                              /* === objects as arguments                    */
DOUBLE FEM_teTetVolume6Nodes (
   NODE_OBJ obj_nodeA,        /* ordered set of nodes on tet */
   NODE_OBJ obj_nodeB,
   NODE_OBJ obj_nodeC,
   NODE_OBJ obj_nodeD  );


                              /* =========================================== */
                              /* === FEM_teTetMeanRatio: compute signed mean */
                              /* === ratio of a tet where mean ratio = 12*(3 */
                              /* === *vol)^(2/3)/(sum of sqr of edge lengths)*/
                              /* === and sign is negative if signed volume   */
                              /* === is negative                             */
DOUBLE FEM_teTetMeanRatio (
   VECTOR3D *a,    /* vertex a of tetrahedron */
   VECTOR3D *b,    /* vertex b of tetrahedron */
   VECTOR3D *c,    /* vertex c of tetrahedron */
   VECTOR3D *d  ); /* vertex d of tetrahedron */

                              /* =========================================== */
                              /* === FEM_teQuadTetMeanRatio: compute signed  */
                              /* === mean ratio of a quadratic tet where mean*/
                              /* === ratio = 12*(3*vol)^(2/3)/(sum of sqr of */
                              /* === edge lengths) and sign is negative if   */
                              /* === signed volume is negative; volume and   */
                              /* === edge lengths are approximated; mean     */
                              /* === ratio is 0 if Jacobian determinant has  */
                              /* === opposite signs at sample points or      */
                              /* === opposite sign than signed volume or     */
                              /* === Jacobian ratio larger than error limit  */
DOUBLE FEM_teQuadTetMeanRatio (
   VECTOR3D *a,    /* vertex a of tetrahedron */
   VECTOR3D *b,    /* vertex b of tetrahedron */
   VECTOR3D *c,    /* vertex c of tetrahedron */
   VECTOR3D *d,    /* vertex d of tetrahedron */
   VECTOR3D *e,    /* midnode on edge ab */
   VECTOR3D *f,    /* midnode on edge bc */
   VECTOR3D *g,    /* midnode on edge ca */
   VECTOR3D *h,    /* midnode on edge ad */
   VECTOR3D *i,    /* midnode on edge bd */
   VECTOR3D *j  ); /* midnode on edge cd */

                              /* =========================================== */
                              /* === FEM_teTetRadiusRatio: compute signed    */
                              /* === radius ratio of a tetrahedron where     */
                              /* === radius ratio = 3*inradius/circumradius  */
                              /* === and sign is negative if signed volume   */
                              /* === is negative                             */
DOUBLE FEM_teTetRadiusRatio (
   VECTOR3D *a,    /* vertex a of tetrahedron */
   VECTOR3D *b,    /* vertex b of tetrahedron */
   VECTOR3D *c,    /* vertex c of tetrahedron */
   VECTOR3D *d  ); /* vertex d of tetrahedron */

                              /* =========================================== */
                              /* === FEM_teRadiusRatioNodes: Same as         */
                              /* === FEM_teTetRadiusRatio except that it     */
                              /* === takes NODE_OBJs                         */
DOUBLE FEM_teRadiusRatioNodes (
   NODE_OBJ obj_nodeA,         /* nodes of potential tet */
   NODE_OBJ obj_nodeB,
   NODE_OBJ obj_nodeC,
   NODE_OBJ obj_nodeD  );

                              /* =========================================== */
                              /* === FEM_teTetMinSolidAngle: compute 4 solid */
                              /* === angles of a tet and their min; actually,*/
                              /* === sin((solid angle)/2) and signed min are */
                              /* === computed where sign is negative if      */
                              /* === signed volume is negative               */
DOUBLE FEM_teTetMinSolidAngle (
   VECTOR3D *a,       /* vertex a of tetrahedron */
   VECTOR3D *b,       /* vertex b of tetrahedron */
   VECTOR3D *c,       /* vertex c of tetrahedron */
   VECTOR3D *d,       /* vertex d of tetrahedron */
   DOUBLE sang[4]  ); /* 4 solid angles at a,b,c,d, resp., returned; */
                      /*  actually sin(a/2), etc.                    */

                              /* =========================================== */
                              /* === FEM_teTetMaxFaceAng: compute signed     */
                              /* === measure for minimizing maximum face/    */
                              /* === dihedral angle:   sign*                 */
                              /* === [cos(largest face/dihedral angle)*.5+.5]*/
                              /* === where sign is 1 (-1) if tet has positive*/
                              /* === (negative) volume                       */
DOUBLE FEM_teTetMaxFaceAng (
   VECTOR3D *a,       /* vertex a of tetrahedron */
   VECTOR3D *b,       /* vertex b of tetrahedron */
   VECTOR3D *c,       /* vertex c of tetrahedron */
   VECTOR3D *d  );    /* vertex d of tetrahedron */

                              /* =========================================== */
                              /* === FEM_teQuadTetMaxFaceAng: compute signed */
                              /* === max face/dihedral angle measure as above*/
                              /* === but for quadratic tet where midnodes are*/
                              /* === used to compute extra face angles and   */
                              /* === measure is 0 if Jacobian determinant has*/
                              /* === opposite signs at sample points or      */
                              /* === Jacobian ratio larger than error limit  */
DOUBLE FEM_teQuadTetMaxFaceAng (
   VECTOR3D *a,    /* vertex a of tetrahedron */
   VECTOR3D *b,    /* vertex b of tetrahedron */
   VECTOR3D *c,    /* vertex c of tetrahedron */
   VECTOR3D *d,    /* vertex d of tetrahedron */
   VECTOR3D *e,    /* midnode on edge ab */
   VECTOR3D *f,    /* midnode on edge bc */
   VECTOR3D *g,    /* midnode on edge ca */
   VECTOR3D *h,    /* midnode on edge ad */
   VECTOR3D *i,    /* midnode on edge bd */
   VECTOR3D *j  ); /* midnode on edge cd */

                              /* =========================================== */
                              /* === FEM_teTetMetric: compute signed shape   */
                              /* === measure of a tetrahedron, either        */
                              /* === minimum solid angle (actually scaled    */
                              /* === version of sin((solid angle)/2)) or     */
                              /* === radius ratio or (quadratic) mean ratio  */
                              /* === or (quadratic) max face/dihedral angle  */
DOUBLE FEM_teTetMetric (
   INT mtype,      /* measure type (1 to 6)   */
   VECTOR3D *a,    /* vertex a of tetrahedron */
   VECTOR3D *b,    /* vertex b of tetrahedron */
   VECTOR3D *c,    /* vertex c of tetrahedron */
   VECTOR3D *d,    /* vertex d of tetrahedron */
   VECTOR3D *e,    /* midnode on edge ab if quadratic measure */
   VECTOR3D *f,    /* midnode on edge bc if quadratic measure */
   VECTOR3D *g,    /* midnode on edge ca if quadratic measure */
   VECTOR3D *h,    /* midnode on edge ad if quadratic measure */
   VECTOR3D *i,    /* midnode on edge bd if quadratic measure */
   VECTOR3D *j  ); /* midnode on edge cd if quadratic measure */

                              /* =========================================== */
                              /* === FEM_teQuadTetJacobian: compute min and  */
                              /* === max of determinant of Jacobian formed   */
                              /* === from mapping a regular quadratic tet to */
                              /* === arbitrary quadratic tet, where regular  */
                              /* === tet has signed volume 1/3 and min/max   */
                              /* === are approx by sampling at nodes and     */
                              /* === Gauss points                            */
void FEM_teQuadTetJacobian (
   VECTOR3D *a,       /* vertex a of tetrahedron */
   VECTOR3D *b,       /* vertex b of tetrahedron */
   VECTOR3D *c,       /* vertex c of tetrahedron */
   VECTOR3D *d,       /* vertex d of tetrahedron */
   VECTOR3D *e,       /* midnode on edge ab if quadratic measure */
   VECTOR3D *f,       /* midnode on edge bc if quadratic measure */
   VECTOR3D *g,       /* midnode on edge ca if quadratic measure */
   VECTOR3D *h,       /* midnode on edge ad if quadratic measure */
   VECTOR3D *i,       /* midnode on edge bd if quadratic measure */
   VECTOR3D *j,       /* midnode on edge cd if quadratic measure */
   DOUBLE *mindet,    /* return min determinant of Jacobian (from samples) */
   DOUBLE *maxdet  ); /* return max determinant of Jacobian (from samples) */

                              /* =========================================== */
                              /* === FEM_teSplitTet: create two tet from one */
                              /* === (obj_tet is deleted).  Nothing is done  */
                              /* === with midnodes (i.e. no mid nodes are    */
                              /* === created on new edges).  if !detached,   */
                              /* === geo entities of new faces are set.      */
INT FEM_teSplitTet (
   ELEMENT_OBJ obj_tet,       /* tet to be split                             */
   EDGE_OBJ obj_edge,         /* edge to be split                            */
   NODE_OBJ obj_nodeE,        /* node to split at                            */
   FEM_BOOLEAN detached  );   /* TRUE if detached from solid model           */

                              /* =========================================== */
                              /* === FEM_te3SplitTet: create 3 tets from one */
                              /* === (original is deleted) by splitting face */
                              /* === of tet into three subfaces using a new  */
                              /* === node on face (original face may also be */
                              /* === deleted)                                */
INT FEM_te3SplitTet (
   ELEMENT_OBJ obj_tet,       /* tet to be split                             */
   FACE_OBJ obj_face,         /* face to be split                            */
   NODE_OBJ obj_newnode,      /* node to split at                            */
   FEM_BOOLEAN midnode  );    /* TRUE if quadratic elements                  */

                              /* =========================================== */
                              /* === FEM_te4SplitTet: create 4 tets from one */
                              /* === (original is deleted) using a new node  */
                              /* === in interior of tet                      */
INT FEM_te4SplitTet (
   ELEMENT_OBJ obj_tet,       /* tet to be split                             */
   NODE_OBJ obj_newnode,      /* node to split at                            */
   FEM_BOOLEAN midnode  );    /* TRUE if quadratic elements                  */


#ifdef __cplusplus
}
#endif

#endif

