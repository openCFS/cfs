/* sid 50.1 copy of DFT_LevenbergMarquardt.h last changed by upd111 on 2005/06/04 13:20:49 */
////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         Copyright (C) 2001 ANSYS Inc.  All Rights Reserved             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: DFT_LevenbergMarquardt.h $
// $Revision$ 7.0
// $Date$ March 28 2002
// $Author$ rjayasee/jlo
//
// Decription :
//
//	This class implements the Levenberg Marquardt algorigthm. This can be used by
//  supplying function pointer that return the value of the function and its
//  derivative to an instance of this class.
//  Notes:
//  This is a combination of  Gradient Method and the Newtons method.
//
//  Ref: E.H.Twizell & R.W.Ogden, Non-Linear Optimization of Material Constants
//       in Ogden's Stress-Deformation Function for Incompressible Isotropic
//       Material.
//////////////////////////////////////////////////////////////////////////////

#if !defined( DFT_LEVENBERGMARQUARDT_H )
#define DFT_LEVENBERGMARQUARDT_H

#include "MAT_ConstitutiveFunction.h"
#include "Matrix.h"

class DFT_LevenbergMarquardt
{

public:

    DFT_LevenbergMarquardt();
    //Constructor

    bool SetNumberOfPoints( INT iNPts ) ;
    //R-void
    //- Sets the Number of Points that the constitutive model is going to use

    void SetMuFactor( double dMu ) ;
    //R-void
    //I-Set the Mu factor for the Method
    //I-Refer to paper

    void SetGammaFactor( double dGamma ) ;
    //R-void
    //I-Sets the Gamma Factor
    //I-Refer to paper

    bool SetGetGradientAtAllPointsFunction
        ( bool (MAT_ConstitutiveFunction::*pNormalMatrixFunction) 
               ( double*, INT, INT , double** ) 
         ) ;
    //R-false if input is invalid
    //- Set the Function that can calculate the normal equation matrix

    bool SetGetErrorAtAllPointsFunction
        ( bool (MAT_ConstitutiveFunction::*pJacobianMatrixFunction) 
                ( double*, INT, INT,  double** ) 
        ) ;
    //R-false if input is invalid
    //- Set the Function that can calculate the Jacobian matrix

    bool SetTheToBeOptimisedObjectPointer( MAT_ConstitutiveFunction* pObjPtr ) ;
    //R result
    //I pObjPtr
    //I-Pointer to the object which will call the routines
    //- Sets the Object the Routines are to be operated on

    bool Solve( double* dInitCoeffs,
                INT iNumCoeffs,
                double* pResCoeffs ) ;
    //R-Status of the function
    //I dInitCoeff
    //I-Initial Value of the Coeff supplied by the user
    //I-or by the MaterialModel defaults
    //I iNumCoeffs
    //I-Number of Coefficients
    //I dInitCoeff
    //I-The result after the newton raphson solution
    //- The solves for the coefficients

    bool Solve( vector<double> const& oInitCoeffs,
                vector<double>& oResCoeffs,
                INT iNumCoeffs ) ;
    //R-Status of the function
    //I oInitCoeffs
    //I-Initial Value of the Coeff supplied by the user
    //I-or by the MaterialModel defaults
    //I oResCoeffs
    //I-The result after the newton raphson solution
    //- The solves for the coefficients

    bool Solve( Matrix* dInitCoeffsMat,
                Matrix* pResCoeffsMat ) ;
    //R-Status of the function
    //I dInitCoeffMat
    //I-Initial Value of the Coeff supplied by the user
    //I-or by the MaterialModel defaults
    //I dInitCoeffMat
    //I-The result after the newton raphson solution
    //- This solves for the coefficients
    
    bool UpdateCoefficients
        ( Matrix* pXNMat, double dGamma, Matrix* pXNNewMat ) ;
    //R-Status of the function
    //I pXNMat
    //I-Initial Coeffs
    //I dGamma
    //I-Gamma Factor as in Ref Paper
    //I pXNNewMat
    //I-Updated Coefficients
    //- Updates coeffs as per the Leven-Marq methoid

    bool SetNumberOfIterations( INT iNIter ) ;
    //R- Status
    //R  False id iNITer is not positive    
    //I  iNIter
    //I- Number of iterations
    //-  Sets the Number of Iterations

     bool SetResidualChangeTolerance( double dResChangeTol ) ;
     //R-Int Result of this operation
     //I dResChangeTol
     //I-Maximum Allowed Residual Change
     //- Sets the Maximum Allowed Residual Change

     bool SetCoefficientChangeTolerance( double dCoeffChangeTol ) ;
     //R-Int Result of this operation
     //I iNumIter
     //I-Maximum Allowed Coeffient Change
     //- Sets the Maximum Allowed Coeffient Change

     bool SetCoefficientFixedFlag( INT iCoeffIndex, bool bCoeffFixed ) ;
     //R bool
     //R false is such a coeff does not exist
     //I iCoeffIndex
     //I-Index of the Coeff
     //I bCoeffFixed
     //I-If the coeff is fixed use bool true else use bool false
     //- Function to Set if the Coeff is Fixed

     bool GetCoefficientFixedFlag( INT iCoeffIndex, bool& bCoeffFixed ) ;
     //R bool
     //R false is such a coeff does not exist
     //I iCoeffIndex
     //I-Index of the Coeff
     //O bCoeffFixed
     //O-If the coeff is fixed use bool true else use bool false
     //- Function to Get if the Coeff is Fixed

     virtual ~DFT_LevenbergMarquardt();
    //F-Destructor

private:

    double** m_pErrorAtAllPointsMatrix ;
    INT m_iNumRowsErrorMatrix ;
    INT m_iNumColsErrorMatrix ;

    double** m_pGradientAtAllPointsMatrix ;
    INT m_iNumRowsGradientMatrix ;
    INT m_iNumColsGradientMatrix ;

    INT m_iNumIterations ;
    INT m_iCurIteration ;
    // Coefficients Used in the Iteration

    // Convergence Criteria
    double m_dResidualChangeTolerance ;
    double m_dCoefficientChangeTolerance ;

    MAT_ConstitutiveFunction* m_pOptimizationObject ;

    INT m_iNumPoints ;
    // Number of Points in the Data Set

    double m_dGammaFactor ;
    // Directs which type of method has a bigger factor in the Algorithms
    // Conjugate Gradient or Steepest Descent

    double m_dMuFactor ;
    // Depending on the error this factor modifies the GammaFactor appropriately

    bool (MAT_ConstitutiveFunction::*m_pGetGradientAtAllPointsFunction) 
        ( double*, INT, INT, double** ) ;
    // Pointer to functions that can return the normal matrice

    bool (MAT_ConstitutiveFunction::*m_pGetErrorAtAllPointsFunction) 
        ( double*, INT, INT, double** ) ;
    // Pointer to functions that can return the normal matrice

    bool GetGradientAtAllPoints
        ( Matrix* pCoeffMatrix,
          Matrix* pGradMatrix ) ;
    //R-Status of the function
    //I pCoeffMatrix                      
    //I-Matrix of coefficients
    //I pGradMatrix               
    //I-The Resulting Matrix 
    //-Assemble the Gradient Matrix for all points

    bool GetErrorAtAllPoints
    ( Matrix* pCoeffMatrix,
      Matrix* pErrorMatrix ) ;
    //R-Status of the function
    //I pCoeffMatrix                      
    //I-Matrix of coefficients
    //I pErrorMatrix               
    //I-The Resulting Matrix of Errors
    //-Assemble the Error Matrix for All Points
    
    bool GetSquaredErrorAtAllPoints
     ( Matrix* pCoeffMatrix,
       SymMatrix* pResidual ) ;
    //R-Status of the function
    //I pCoeffMatrix                      
    //I-Matrix of coefficients
    //I pResidual               
    //I-The Resulting Matrix of Errors
    //-Assemble the Error Squared Matrix for All Points
    

    map<INT,bool> m_oIsCoeffFixed ;
    // Map of Variable Index and Whether the Coefficient is Fixed
};

#endif // !defined(DFT_LEVENBERGMARQUARDT_H)
