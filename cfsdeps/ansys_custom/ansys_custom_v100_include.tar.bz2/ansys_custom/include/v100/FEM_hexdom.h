/* sid 50.1 copy of FEM_hexdom.h last changed by upd111 on 2004/11/04 18:31:02 */
/*  FEM_hexdom.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_hexdom.h
 *  header file for FEM_hexdom.c
 *
 */
#ifndef FEM_HEXDOM_H
#define FEM_HEXDOM_H

/*----------------- Globally accessible function prototypes -----------------*/

                         /* =================================================*/
                         /* Function: FEM_hexdom: main entry point for hex   */
                         /* dominant module                                  */
INT FEM_hexdom(
   INT volnum,           /* (IN) volume number                               */
   MESH_OBJ obj_mesh,    /* (IN/OUT) pass in the current mesh object         */
                         /*      containing a quad dominant set of faces on  */
                         /*      the boundary of the model.  mesh object will*/
                         /*      be returned with complete hex dominant mesh */
   INT num_nodes,        /* (IN) number of nodes on the volume boundary.     */
                         /*      These nodes are at the front of the         */
                         /*      nodelist in obj_mesh.                       */
   INT num_facets,       /* (IN) number of facets on the volume boundary.    */
                         /*      These facets are at the front of the        */
                         /*      facelist in obj_mesh.                       */
   INT debug,            /* (IN) flag 1 = draw progress of algorithm         */      
                         /*           2 = draw + do data structure checks    */      
                         /*           0 = no debug                           */ 
   INT smooth );         /* (IN) flag perform smoothing as postprocess       */    

#endif

