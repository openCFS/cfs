/* sid 50.1 copy of FEM_smooth.h last changed by upd111 on 2004/11/04 18:32:18 */
/*  FEM_smooth.h */
/*
 * *** ansys(r) copyright(c) 1999
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_smooth.h
 *  header file for FEM_smooth.c
 *
 */
#ifndef FEM_SMOOTH_INCLUDE
#define FEM_SMOOTH_INCLUDE

typedef enum SMOOTHENUM {
   LAPLACIAN,                      /* default */
   AREA_CENTROID
} SMOOTHENUM;

/*----------------- Globally accessible function prototypes -----------------*/

#ifdef __cplusplus
extern "C" {
#endif

                           /* ============================================== */
                           /* === FEM_smAreaSmooth: Do smoothing on areas    */
                           /* === Assumes C meshing data base is already     */
                           /* === set up with all appropriate entities.      */
                           /* === Assumes lines & areas have been cached     */
                           /* === and initial paprametric locations stored   */
                           /* === with the nodes                             */
                           /* === Return: INT EXIT_SUCCESS or EXIT_FAILURE   */
                           /* ============================================== */
INT FEM_smAreaSmooth ( 
   INT anum,               /* (IN)  area to smooth.  If 0, then all areas    */
                           /*       are smoothed.                            */
   FACELIST_OBJ obj_flist, /* (IN)  the face list                            */
   NODELIST_OBJ obj_nlist, /* (IN)  the node list                            */
   INT num_iterations,     /* (IN)  max number of smoothing iterations       */
   DOUBLE move_tolerance,  /* (IN)  tolerance for movement of mode           */
   INT line_smooth,        /* (IN)  0 = no line smoothing                    */
                           /*       1 = optimiz. based line smoothing        */
                           /*       2 = laplacian line smoothing             */
   INT high_curv,          /* (IN)  area has high curvature - check for      */
                           /*       max spanning angle                       */
   DOUBLE maxang,          /* (IN)  max spanning angle                       */
   INT debug,              /* (IN)  flag to print debug info                 */
   FEM_BOOLEAN do_progress,/* (IN)  TRUE if progress bar should be updated.  */
   INT stat_process );     /* (IN)  process for status window.               */
 
                             /* === FEM_smAreaOptMove: try to move interior  */
                             /* === node to a near-optimal position wrt its  */
                             /* === incident triangles or quadrilaterals     */
INT FEM_smAreaOptMove (
   NODE_OBJ obj_node,  /* interior node */
   FACE_OBJ *aobj_faces, /* faces around obj_node */
   INT nface,          /* numfaces in aobj_faces */
   DOUBLE measopt,     /* max measure for which optimization-based smoothing
                          is applied to try to move node; if measopt > 1.0,
                          then opt move is always tried; if measopt <= 0.0,
                          then opt move is tried for only inverted elements */
   DOUBLE meastol,     /* tolerance that measures must improve by in order to
                          move node */
   DOUBLE delta,       /* positive perturbation for estimating gradients */
   FEM_BOOLEAN *move_node  /* return TRUE if node is moved */
 );

                             /* === FEM_smComputeAlpha: compute the alpha    */
                             /* === shape metric for a triangle element      */
DOUBLE FEM_smComputeAlpha ( VECTOR3D *p0,
                                     VECTOR3D *p1,
                                     VECTOR3D *p2,
                                     VECTOR3D *surf_norm  );


                              /* === FEM_smSetAreaNodesSmoothable: In        */
                              /* === preparation to call FEM_smAreaSmooth,   */
                              /* === Set the NODE_SMOOTHABLE flag in all     */
                              /* === nodes.  The flag will be set to be TRUE */
                              /* === for all nodes with the NODE_ON_AREA     */
                              /* === property set but that is not adjacent   */
                              /* === to a volume element.  If linenodes != 0 */
                              /* === then nodes with the NODE_ON_LINE        */
                              /* === property will also get the              */
                              /* === NODE_SMOOTHABLE flag set if they are not*/
                              /* === adjacent to any volume elements.        */
INT FEM_smSetAreaNodesSmoothable (
   INT *a_areas,               
   INT iNumAreas,
   INT *a_lines,           
   INT num_lines,
   FEM_BOOLEAN bDoLineSmoothing,
   FEM_BOOLEAN bForceAllBeSmoothable);

                           /* ============================================== */
                           /* === FEM_smSetAreaNodesSmoothable2:  In         */
                           /* === preparation to call FEM_smAreaSmooth, Set  */
                           /* === the NODE_SMOOTHABLE flag in all nodes.     */
                           /* === The flag will be set to be TRUE for all    */
                           /* === nodes on "area" and all nodes on lines in  */
                           /* === a_lines that can be evaluated.  The        */
                           /* === exception is that nodes adjacnet to volume */
                           /* === elements will not be set as smoothable     */
                           /* === regardless of what area or line they are   */
                           /* === on. Finally, move all NODE_SMOOTHABLEs to  */
                           /* === the front of the node list and all faces   */
                           /* === on area to the front of the face list.     */
                           /* === Return: INT EXIT_SUCCESS or EXIT_FAILURE   */
                           /* ============================================== */
INT FEM_smSetAreaNodesSmoothable2(
   NODELIST_OBJ obj_nlist, /* (IN)  node list                                */
   FACELIST_OBJ obj_flist, /* (IN)  face list                                */
   INT area,               /* (IN)  the area to smooth.                      */
   INT *a_lines,           /* (IN)  list of lines to do line smoothing on.   */
   INT num_lines );          /* (IN)  length of a_lines                        */
                           /* ============================================== */

                           /*==============================================================================
                            * === FEM_smSetAreaNodesSmoothable3
                            * === In preparation to call FEM_smAreaSmooth, Set the
                            * === NODE_SMOOTHABLE flag in all nodes on the areas.  The flag will be
                            * === set to be TRUE for all nodes on "areas". If linenodes != 0, then all nodes with 
                            * === the NODE_ON_LINE property set but are not adjacent to
                            * === volume elements will also get their NODE_SMOOTHABLE
                            * === flag set. 
                            * === The exception is that nodes adjacnet to volume elements
                            * === will not be set as smoothable regardless of what area or
                            * === line they are on.
                            * === Finally, move all NODE_SMOOTHABLEs to the front of the node
                            * === list and all faces on area to the front of the face list.
                            * === Return: INT EXIT_SUCCESS or EXIT_FAILURE
                            *============================================================================*/
INT FEM_smSetAreaNodesSmoothable3(
   INT *a_areas,            /* (IN)  list of areas to do  smoothing on.  */
   INT numareas,            /* (IN)  length of a_areas */
   FEM_BOOLEAN linenodes );

                              /* === FEM_smShapeMetric: compute shell        */
                              /* === element metric (for quads and tris).    */
DOUBLE FEM_smShapeMetric (
   FACE_OBJ obj_face,
   VECTOR3D *surf_norm  );
DOUBLE FEM_smShapeMetricByNodes(
   NODE_OBJ *aobj_nodes,
   INT num_edges,
   VECTOR3D *surf_norm );
                              /* === FEM_smComputeBeta: compute the beta     */
                              /* === shape metric for a quad also uses SH.   */
                              /* === Lo shape metric for quads as described  */
                              /* === in same paper.  Nodes should be ordered */
                              /* === ccw                                     */ 
DOUBLE FEM_smComputeBeta (
   VECTOR3D *p0,
   VECTOR3D *p1,
   VECTOR3D *p2,
   VECTOR3D *p3,
   VECTOR3D *surf_norm  );

                           /* ============================================== */
                           /* === FEM_smCheckInversion: check if a face is   */
                           /* === inverted with respect to the surface       */
                           /* ============================================== */
INT FEM_smCheckInversion(
   FACE_OBJ obj_face,
   INT *p_inverted );

                           /* ============================================== */
                           /* === FEM_smGetElemDirection: return the elem    */
                           /* === direction with respect to the surface      */
                           /* === normal (as computed during smoothing)      */
                           /* === for last area smoothed                     */
                           /* ============================================== */
INT FEM_smGetElemDirection();

                           /* ============================================== */
                           /* === FEM_smSetSmoothMethod:                     */
                           /* === set the type of smoothing to be done in    */
                           /* === FEM_smAreaSmooth                           */
                           /* ============================================== */
void  FEM_smSetSmoothMethod( 
   SMOOTHENUM smoothtype );
INT FEM_smGetSmoothMethod( );

                           /* ============================================== */
                           /* === FEM_smSetMinMetric:                     */
                           /* === set the min metric to be smoothed    */
                           /* ============================================== */
void  FEM_smSetMinMetric( 
   DOUBLE minmetric);

void tangle();

INT FEM_smLaplacianSmoothingUv(
   INT anum);

DOUBLE FEM_smShapeMetricUV(
   FACE_OBJ obj_face);

INT FEM_smMarkHighCurvNodes();
INT FEM_smMarkHighCurvEdges();
DOUBLE FEM_smNodalShapeMetric( 
   NODE_OBJ obj_node, 
   FACE_OBJ aobj_faces[MAX_FACE_PER_NODE],
   INT nface,
   INT iLocation,
   INT *piTotallyInversedExist);


void FEM_smResetElementDirection( void );

#ifdef __cplusplus
}
#endif

#endif
