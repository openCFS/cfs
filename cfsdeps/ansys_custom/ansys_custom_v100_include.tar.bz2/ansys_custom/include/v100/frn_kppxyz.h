/* sid 50.1 copy of frn_kppxyz.h last changed by upd111 on 2005/06/04 13:16:50 */
/*  frn_kppxyz.h */
/* 
 * *** ansys(r) copyright(c) 2000
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  frn_kppxyz.h
 *  header file for frn_kppxyz.c
 *
 */

/* (1)-------------------------------------------------------------*/

#if defined(RS6000_SYS) || defined(HP32_SYS) 

/* === C functions called from FORTRAN */

#define frn_kppxyz_    frn_kppxyz

/* === FORTRAN subroutines called from C */


#endif

/* (2)-------------------------------------------------------------*/

#if defined(WATCOMC_SYS) \
    || defined(PCWINNT_SYS)
/* === C functions called from FORTRAN */

#define frn_kppxyz_     FRN_KPPXYZ

/* === FORTRAN subroutines called from C */

#endif

/* (3)-------------------------------------------------------------*/
#if defined(WATCOMC_SYS)

/* === C functions called from FORTRAN */
#pragma aux FRN_KPPXYZ "^";

/* === FORTRAN subroutines called from C */

#endif

/* (4)-------------------------------------------------------------*/
/*
 * *** FUNCTION RETURN TYPE DECLARATION
 */

#if !defined(PCWINNT_SYS)

/* === C functions called from FORTRAN */
   void frn_kppxyz_();

/* === FORTRAN subroutines called from C */

/* (5)-------------------------------------------------------------*/
#else

/* === C functions called from FORTRAN */
   void CALLTYP frn_kppxyz_( INT *, DOUBLE *);

/* === FORTRAN subroutines called from C */

#endif
