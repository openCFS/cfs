/* sid 50.1 copy of geom.h last changed by upd111 on 2005/06/04 13:14:58 */
/*    geom.h                                kz372              */
/* 
 * *** ansys(r) copyright(c) 2000
 * *** ansys, inc.
 */

/*  Get/Inquire the cells that are defined on a map*/ 
INT 
CALLTYP xAnsysMapCells_ ansPROTO((
     xINT  *map,
     INT  *cells,
     INT  *flag 
));

/*  Get the map type for a map*/ 
INT 
CALLTYP xAnsysMapType_ ansPROTO((
  xINT *map 			/* I: Map */
));

/*  Get the map form for a map*/ 
INT 
CALLTYP xAnsysMapForm_ ansPROTO((
  xINT *map 			/* I: Map */
));
