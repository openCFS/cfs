/* sid 50.3 copy of CPostAdomesh.h last changed by eedelor on 2005/05/26 15:04:37 */
/* CPostAdomesh.h CADOE doeinc */
/*! \file CPostAdomesh.h

  \brief This header file defines the CPostAdomesh class.

  \author Stephane MARGUERIN &copy; CADOE

  \date October 2003
*/
#ifndef __CPostAdomesh_h__ 
#define __CPostAdomesh_h__ 1 

#include "CCadoePortable.h"
#include "CDesignSet.h"
#include "CParameterMgr.h"

#include "m_matrix.h"
#include "lmb.h"


typedef struct __Modele T_Modele;
typedef struct __Mesh T_Mesh;
typedef struct __Fcout T_FCout;


/*! \class CPostAdomesh CPostAdomesh.h
  \brief The CPostAdomesh class is used to evaluate an adomesh parameterized mesh.
*/
class CPostAdomesh
{
public:

	CPostAdomesh();
	virtual ~CPostAdomesh();

	// initialize for standalone usage (build is own adomesh model)
	int initialize( const string &filename );
	// initialize using an existing model to limit memory usage
	int initialize( const string &filename, T_Modele *modele );

	bool isInitialized( const string &filename ) const;

	int getNumberOfShapeParameters( void ) const;
	int getNumberOfAdomeshParameters( void ) const;
	int getNumberOfNodes( void ) const;
	int getNumberOfElements( void ) const;
	int getCumulatedNumberOfNodes( int *cumnum, int *maxnode );
	int getNode( int ind, double xyz[3], int *numero ) const;
	int getNodeByNum ( int numero ) const;
	int getElementByNum ( int indice_adomesh ) const;
	int getIndiceElementByNum ( int numero ) const;
	int getElement( int ind, int *numero, int *nb_nodes, int *nodes, int *type_geom, bool adomeshOrder ) const;
	int getCs( int ind, VEC **csquater ) const;
	int getCsByNum(int numero, int *indice, VEC** csquater) const;
        int calculatePerturbation( CDesignSet &set, VEC **perturbation ) const;
	int calculatePerturbation( VEC *vec_param_shape, VEC **perturbation );

	int calculateDistortion( VEC *perturbation, VEC **distortion ) const;
	int calculateElementDistortion( int num_ele, VEC *perturbation, double *distortion ) const;

	int modifNodes( bool getPerturb, bool getDistortion, VEC **perturbation, VEC **distortion );
	int modifNodes( CDesignSet &dset, bool getPerturb, bool getDistortion, VEC **perturbation, VEC **distortion);
	int modifNodes( VEC *vec_param, bool getPerturb, bool getDistortion, VEC **perturbation, VEC **distortion, int isVecParamAdomesh );

	int derivNodes( CDesignSet &set, int *order, VEC **sdtn, IVEC **nabouge ) const;
	int derivNodes( VEC *vec_param_shape, int *order, VEC **sdtn, IVEC **nabouge ); 

	int derivCs( CDesignSet &set, int *order, VEC **stdn, IVEC **nabouge );
	int derivCs( VEC *vec_param_shape, int *order, VEC **stdn, IVEC **nabouge ) const;

	int deltaCs( CDesignSet &set, IVEC **nabouge, VEC **quater ) const;
	int deltaCs( VEC *vec_param_shape, IVEC **nabouge, VEC **quater );

	// create a Shape DesignSet from a FULL vec_param
	int designSet2VecParamAdomesh( const CDesignSet& set, VEC **vecParamAdomesh ) const;
	int vecParam2DesignSet( const VEC *vecParam, CDesignSet &set ) const;
	int vecParamShape2DesignSet( const VEC *vecParamAdomesh, CDesignSet &set ) const;
	int designSet2deltadesignSet( CDesignSet *dset, CDesignSet *deltaDset ) const;
	string getNameOfVecParamIndex ( int iv ) const;
	int getIndiceParameter ( const string &name );
	int isShapeParameterActive(const VEC *vparamAdoc, bool &isShapeParameterActive) const;
        
	int setDesignSetValue ( const string &p_nom, double val );
	double getDesignSetValue ( const string &p_nom );
	CDesignSet getDesignSet (void) const { return _dset; }
	void setAllParamToInitial( CDesignSet &dset, bool delta=false) const;
	int getSupportOfShapeParameter( const char *param, BVEC **vecParam ) const;
	int getMaxDistortedElements( CDesignSet *dset, int nb_max, double dist_max, bool inter, BVEC **max_ele ) const;
	double getModelSize(void) { return _taille; }
        int getExtremumR2Nodes( double *r2min, double *r2max, double *r2moy, bool affich) const;
  
protected:
	void createMyPmgr(void);
	void decomposeFilenameString( const string &fullname, string &dbname, string &meshname ) const;
	int MSH_calculer_r2( T_Mesh *mesh ) const;
  
	bool			_initialized;
	T_Modele		*_model;
	bool			_modelIsMine;
	T_Mesh			*_mesh;
	string			_dbname;
	string			_meshname;
	CParameterMgr	*_pmgr;
	bool			_pmgrIsMine;
	int				_nbParamAdomesh;
	map<string,int>	_indexAdomesh;
	map<string,int> _indexAdoc;
	int				_cumnum; // cumultaed number of nodes
	int				_maxnode; //maximum label of nodes
	CDesignSet		_dset;
	T_FCout			*_FCout;
	double			_taille;
};


#endif
