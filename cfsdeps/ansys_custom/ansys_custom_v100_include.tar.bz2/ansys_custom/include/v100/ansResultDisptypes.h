/* sid 50.1 copy of ansResultDisptypes.h last changed by jrb on 2005/02/25 19:24:24 */

#include "ansysdef.h"


extern  INT  cCreateAnsResultDisp(void);
extern  INT  cDeleteAnsResultDisp(void);
extern  INT  cInquireAnsResultDisp(INT,INT,INT);
extern  INT  cPutAnsResultDisp(INT,INT,DOUBLE);
extern  INT  cGetAnsResultDisp(INT,INT,INT*,DOUBLE*);
extern  INT  cActivateAnsResultDisp(INT,INT,INT);
extern  INT  cDumpAnsResultDisp(INT);


/****************************************************************
 global-level structure for ANSYS nodal result displacements
 ****************************************************************/
struct ansResultDisp_str {   /* Name of the structure                                      */
  INT       tag;             /* Tag for this instance of the result displacement structure */
  INT       numDispNodes;    /* Number of nodes with result displacements                  */
  INT       maxDispNode;     /* Maximum external node number having result displacement    */
  INT       numDisp;         /* Total number of result displacements (zero and non-zero)   */
};

#define ansResultDispTag(rdisp)                (rdisp->tag)
#define ansResultDispNumDispNodes(rdisp)       (rdisp->numDispNodes)
#define ansResultDispMaxDispNode(rdisp)        (rdisp->maxDispNode)
#define ansResultDispNumDisp(rdisp)            (rdisp->numDisp)



/******************************************************************
 data-level structure for ANSYS nodal result displacements
 ******************************************************************/
struct resultDispData_str {  /* Name of the structure                                          */
  char            modified;  /* Flag indicating whether this result disp has been modified     */
  char            internal;  /* Flag indicating whether this result disp is internal to object */
  INT             dof;       /* External DOF value                                             */
  char            active;    /* Flag indicating if result disp is active or inactive           */
  DOUBLE          value;     /* Result displacement value                                      */
  resultDispData *nextDisp;  /* Pointer to the next result disp data structure for this        */
                             /* node.  If this pointer is NULL, then this is the last          */
                             /* stored result displacement for this node                       */
};

#define resultDispDataModified(rdData)         (rdData->modified)
#define resultDispDataInternal(rdData)         (rdData->internal)
#define resultDispDataDof(rdData)              (rdData->dof)
#define resultDispDataDispActive(rdData)       (rdData->active)
#define resultDispDataValue(rdData)            (rdData->value)

#define resultDispDataNextDispPtr(rdData)      (rdData->nextDisp)

