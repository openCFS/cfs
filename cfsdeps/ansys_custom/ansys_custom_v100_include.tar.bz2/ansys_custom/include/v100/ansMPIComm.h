/* sid 50.4 copy of ansMPIComm.h last changed by jrb on 2005/04/06 12:33:00 */
/*HFILE ansMPIComm.h                       ANSI_C                           sam
------------------------------------------------------------------------
------- Notice - This file contains ANSYS Confidential information
------------------------------------------------------------------------
*/

/*------------------------------ Description ---------------------------

\Author:    Sam Murgie

\Title:     Standard MPI C Header

\Desc:      Include standard MPI C header
            Also provides prototypes for ansMPIComm.c


            Currently contains the following MPI functions:

                   cansMPI_Init
                   cansMPI_BufferAttach
                   cansMPI_Finalize
                   cansMPI_Abort
                   cansMPI_ISend
                   cansMPI_CSend
                   cansMPI_DSend
                   cansMPI_IBufSend
                   cansMPI_DBufSend
                   cansMPI_IRecv
                   cansMPI_CRecv
                   cansMPI_DRecv
                   cansMPI_ISum
                   cansMPI_DSum
                   cansMPI_IMax
                   cansMPI_IMin
                   cansMPI_DMax
                   cansMPI_DMin
                   cansMPI_Synch
                   cansMPI_Probe
                   cansMPI_ProbeAny
                   cansMPI_Inquire
                   cansMPI_disableCMPI

\History:   Created 5/1/03 (dc): Combined dpcg MPIComm.h and c_ampi_lib.h

\Function(s)
 -Primary:      Include standard MPI C header
 -Secondary:    Prototypes for cansMPICommm.c
 -External:     none
 -Internal:     none
 -Static:       thisCPU, numCPU

----------------------------------------------------------------------*/

/*------------------------------ Header files ------------------------*/

#ifdef USE_MPI
#ifdef RS6000_SYS
#  include "/usr/lpp/ppe.poe/include/mpi.h"
#else
#  include <mpi.h>
#endif
#endif

/*-------------------------------- Globals ---------------------------*/

extern INT  numCPU;
extern INT  thisCPU;
extern INT  world;

/*------------------------------ Prototypes --------------------------*/

extern void     cansMPI_Init(VOID);
extern void     cansMPI_BufferAttach(VOID);
extern void     cansMPI_Finalize(VOID);
extern void     cansMPI_Abort(VOID);

extern void     cansMPI_ISend(INT, INT, INT*, INT);
extern void     cansMPI_CSend(INT, INT, CHAR*, INT);
extern void     cansMPI_DSend(INT, INT, DOUBLE*, INT);
extern void     cansMPI_IBufSend(INT, INT, INT*, INT);
extern void     cansMPI_DBufSend(INT, INT, DOUBLE*, INT);

extern void     cansMPI_IRecv(INT*, INT, INT*, INT*);
extern void     cansMPI_CRecv(INT*, INT, CHAR*, INT*);
extern void     cansMPI_DRecv(INT*, INT, DOUBLE*, INT*);

extern void     cansMPI_ISum(INT, INT*);
extern void     cansMPI_DSum(INT, DOUBLE*);
extern void     cansMPI_IMax(INT, INT*);
extern void     cansMPI_IMin(INT, INT*);
extern void     cansMPI_DMax(INT, DOUBLE*);
extern void     cansMPI_DMin(INT, DOUBLE*);

extern void     cansMPI_Synch(VOID);
extern INT      cansMPI_Probe(INT, INT);
extern INT      cansMPI_ProbeAny(INT*, INT);

extern INT      cansMPI_Inquire(INT);
extern INT      cansMPI_disableCMPI(INT);


/*--------------------------End of Prototypes ------------------------*/

/*---------------------------- End Of Module -------------------------*/
