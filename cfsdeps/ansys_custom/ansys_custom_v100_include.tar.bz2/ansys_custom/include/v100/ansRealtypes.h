/* sid 50.1 copy of ansRealtypes.h last changed by jrb on 2005/02/25 19:24:23 */

#include "ansysdef.h"


extern  INT  cCreateAnsReal(INT,INT,INT*);
extern  INT  cDeleteAnsReal(void);
extern  INT  cInquireAnsReal(INT,INT);
extern  INT  cPutAnsReal(INT,INT,DOUBLE*);
extern  INT  cGetAnsReal(INT,INT*,DOUBLE*);
extern  INT  cGetAnsRealPtr(INT,INT*,DOUBLE**);
extern  INT  cDumpAnsReal(INT);


/****************************************************************
 global-level structure for ANSYS real constants
 ****************************************************************/
struct ansReal_str {               /* Name of the structure                                       */
  INT        tag;                  /* Tag for this instance of the real constants structure       */
  INT        numDef;               /* Number of defined real constants in this structure          */
  INT        maxDef;               /* Maximum number of defined real constants in this structure  */
  INT        maxSize;              /* Maximum number of values stored for any real constant set   */
  INT       *Internal_to_External; /* Mapping vector for global internal to global external       */
  INT       *External_to_Internal; /* Mapping vector for global external to global internal       */
  realData  *dataVec;              /* Array of data for each real constant set                    */
};

#define ansRealTag(rl)                 (rl->tag)
#define ansRealNumDef(rl)              (rl->numDef)
#define ansRealMaxDef(rl)              (rl->maxDef)
#define ansRealMaxSize(rl)             (rl->maxSize)

#define ansRealInt2ExtPtr(rl)          (rl->Internal_to_External)
#define ansRealInt2ExtVec(rl,i)        (rl->Internal_to_External[i])
#define ansRealExt2IntPtr(rl)          (rl->External_to_Internal)
#define ansRealExt2IntVec(rl,i)        (rl->External_to_Internal[i])

#define ansRealDataPtr(rl)             (rl->dataVec)
#define ansRealDataVec(rl,i)           (rl->dataVec+i)


/******************************************************************
 data-level structure for ANSYS real constants
 ******************************************************************/
struct realData_str {   /* Name of the structure                                                */
  char     modified;    /* Flag indicating whether this real constant set has been modified     */
  char     internal;    /* Flag indicating whether this real constant set is internal to object */
  INT      numValues;   /* number of values stored for this real constant set                   */
  DOUBLE  *values;      /* real constant values                                                 */
};

#define realDataModified(rData)       (rData->modified)
#define realDataInternal(rData)       (rData->internal)
#define realDataNumValues(rData)      (rData->numValues)

#define realDataValuesPtr(rData)      (rData->values)
#define realDataValuesVec(rData,i)    (rData->values[i])

