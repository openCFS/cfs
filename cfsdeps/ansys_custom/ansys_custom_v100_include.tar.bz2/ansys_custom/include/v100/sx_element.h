/* sid 50.7 copy of sx_element.h last changed by cwa on 2005/05/10 11:11:57 */
/* CADOE */
/**
 *	Sxelement.h -- fonctions attachees aux objets element
 *   
 * HISTORY
 *   
 *   02/15/00 12:22 <       Brian Jantzen> Rel:ms8      SCCA:68558  Delta:8.4
 *   
 *   01/05/00 14:54 <        Marc Gadbois> Rel:ms8      SCCA:64687  Delta:8.3
 *   
 *   09/30/99 17:38 <         James Silva> Rel:ms8      SCCA:56512  Delta:8.2
 **/
#include "sx_CADOE_solver.h"
#ifndef __SXELEMENT_H_DEJA_INCLUS__
#define __SXELEMENT_H_DEJA_INCLUS__ 1


#define ELE_is_on(elt,resultat) IS_ON((elt)->res[(int)((double)(resultat)*UN_SUR_NB_BIT_PER_INT)],(resultat)%NB_BIT_PER_INT)
#define ELE_is_off(elt,resultat) IS_OFF((elt)->res[(int)((double)(resultat)*UN_SUR_NB_BIT_PER_INT)],(resultat)%NB_BIT_PER_INT)
#define ELE_set_on(elt,resultat) SET_ON((elt)->res[(int)((double)(resultat)*UN_SUR_NB_BIT_PER_INT)],(resultat)%NB_BIT_PER_INT)
#define ELE_set_off(elt,resultat) SET_OFF((elt)->res[(int)((double)(resultat)*UN_SUR_NB_BIT_PER_INT)],(resultat)%NB_BIT_PER_INT)
#define ELE_type_geometrique(elt) ((elt)->type_geometrique)
#define ELE_solveur(elt) ((E_solveur)(elt)->solveur)

extern IntegerAdr ELE_compter( T_element*,E_resultat_parametre, T_statut* );
extern IntegerAdr ELE_compter_post( T_element*,E_resultat_parametre, T_statut* );
extern T_booleen ELE_is_type_surf( T_element* );
extern T_booleen ELE_is_type_rig( T_element* );
extern T_statut ELE_rechercher_prop_elem_entier( T_element*, int, int, int* );
extern T_statut ELE_rechercher_prop_elem_reelle( T_element*, int, int, double* );
extern T_statut ELE_rechercher_adresse_prop(T_element *, int, T_propriete** );
extern T_statut ELE_rechercher_adresse_pel(T_element *, int, int, T_prop_elem **);
extern T_booleen ELE_is_type_amo (T_element *elt);
extern T_booleen ELE_is_type_mas (T_element *elt);
extern T_booleen ELE_is_formder (T_element *elt);
extern T_booleen ELE_is_stressed (T_element *elt);
extern int ELE_make_type( E_solveur, int );
extern int ELE_order( T_element *elt, T_statut *ier );
extern T_booleen ELE_noe_est_primaire( T_element *elt, int in, T_statut *ier );
extern T_booleen ELE_noe_est_interne( T_element *elt, int in, T_statut *ier );
extern int ELE_find_corner_nodes( T_element *elt, int in, T_statut *ier );
extern void ELE_initialise_champs(T_modele * modele);
extern T_booleen ELE_is_duplicate_node( T_element *elt, int in );
extern int ELE_num_midside_nodes( T_element *elt, T_statut *ier );

#ifdef __cplusplus
extern "C" {
#endif

  extern E_mode_analyse ELE_mode_analyse( T_element* );

#ifdef __cplusplus
}
#endif

#endif	 /* __SXELEMENT_H_DEJA_INCLUS__ */

