/* sid 50.3 copy of statTableUtils.h last changed by jrb on 2004/12/16 18:45:57 */
/*HFILE statTableUtils.h                  ANSI_C                      dc
------------------------------------------------------------------------
------- Notice - This file contains ANSYS Confidential information
------------------------------------------------------------------------
*/

/*------------------------------ Description ---------------------------

\Author:    Dave Conover

\Title:     statistics gathering C header

\Desc:      Header for utilities used in c code for statistics gathering

            Currently contains the following functions:

		   cStatUpdateMPI_Send
                   cStatUpdateMPI_Recv
                   cStatUpdateMPI_Barrier
                   cStatUpdateMPI_AllReduce
                   cStatUpdateMPI_Probe
                   statInitMPI
                   statRetrieveMPI
                   statBegin
                   statEnd
                   statGlobalPut

\History:   Created 8/17/04 (dc)

\Function(s)
 -Primary:      Standard C header
 -Secondary:    Prototypes for statTableUtils.c
 -External:     none
 -Internal:     none
 -Static:       none

----------------------------------------------------------------------*/


/*-------------------------------- Globals ---------------------------*/

extern INT       statLvl;
extern INT       LvlMPICalls[STATLVLMAX];
extern DOUBLE    LvlMPIDataSent[STATLVLMAX];
extern LONGINTC  LvlMPIMaxMsgLengthSent[STATLVLMAX];
extern DOUBLE    LvlMPIDataRecv[STATLVLMAX];
extern LONGINTC  LvlMPIMaxMsgLengthRecv[STATLVLMAX];
extern INT       LvlMPISendCalls[STATLVLMAX];
extern DOUBLE    LvlMPISendCP[STATLVLMAX];
extern DOUBLE    LvlMPISendWall[STATLVLMAX];
extern INT       LvlMPIRecvCalls[STATLVLMAX];
extern DOUBLE    LvlMPIRecvCP[STATLVLMAX];
extern DOUBLE    LvlMPIRecvWall[STATLVLMAX];
extern INT       LvlMPIBarrierCalls[STATLVLMAX];
extern DOUBLE    LvlMPIBarrierCP[STATLVLMAX];
extern DOUBLE    LvlMPIBarrierWall[STATLVLMAX];
extern INT       LvlMPIReduceCalls[STATLVLMAX];
extern DOUBLE    LvlMPIReduceCP[STATLVLMAX];
extern DOUBLE    LvlMPIReduceWall[STATLVLMAX];
extern INT       LvlMPIProbeCalls[STATLVLMAX];
extern DOUBLE    LvlMPIProbeCP[STATLVLMAX];
extern DOUBLE    LvlMPIProbeWall[STATLVLMAX];

/*------------------------------ Prototypes --------------------------*/

extern void      cStatUpdateMPI_Send(INT,DOUBLE,DOUBLE);
extern void      cStatUpdateMPI_Recv(INT,DOUBLE,DOUBLE);
extern void      cStatUpdateMPI_Barrier(INT,DOUBLE,DOUBLE);
extern void      cStatUpdateMPI_AllReduce(INT,DOUBLE,DOUBLE);
extern void      cStatUpdateMPI_Probe(INT,DOUBLE,DOUBLE);

/*------------------------- C called from FORTRAN --------------------*/

#if defined(UPPERCASENOUNDER_SYS)
#define statInitMPI STATINITMPI
#define statRetrieveMPI STATRETRIEVEMPI
#endif

#if defined(LOWERCASENOUNDER_SYS)
#define statInitMPI statinitmpi
#define statRetrieveMPI statretrievempi
#endif

#if defined(LOWERCASEUNDER_SYS)
#define statInitMPI statinitmpi_
#define statRetrieveMPI statretrievempi_
#endif

SUBROUTINE statInitMPI(INT*);
SUBROUTINE statRetrieveMPI(INT*, INT*, LONGINTC*, DOUBLE*);

/*------------------------- FORTRAN called from C --------------------*/

#if defined(UPPERCASENOUNDER_SYS)
#define statBegin STATBEGIN
#define statEnd STATEND
#define statGlobalPut STATGLOBALPUT
#define statGlobalPutL STATGLOBALPUTL
#endif

#if defined(LOWERCASENOUNDER_SYS)
#define statBegin statbegin
#define statEnd statend
#define statGlobalPut statglobalput
#define statGlobalPutL statglobalputl
#endif

#if defined(LOWERCASEUNDER_SYS)
#define statBegin statbegin_
#define statEnd statend_
#define statGlobalPut statglobalput_
#define statGlobalPutL statglobalputl_
#endif

SUBROUTINE statBegin(INT*);
SUBROUTINE statEnd(INT*);
SUBROUTINE statGlobalPut(INT*, INT*);
SUBROUTINE statGlobalPutL(INT*, LONGINTC*);

