/* sid 50.1 copy of SxCommandGlobal.h last changed by smarguer on 2005/01/14 14:59:26 */
/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 2002                                         */
/* *** ansys, inc.                                                        */
/* ---------------------------------------------------------------------- */

/*
*    Author/date: Samuel Khor 05/20/2002
*    Primary function:
*    Global Header file for SX Command
*/

#ifndef _SX_COMMAND_GLOBAL_H_
#define _SX_COMMAND_GLOBAL_H_  1

#include "SxConstants.h"


#ifdef __cplusplus
extern "C" {
#endif

/* access function to global data */
/* ------------------------------ */

/* put solve flag */
extern int InitSxGlobals ( void );

/* deallocate the entire SeriesXpansion method database */
extern int SxDeallocateAll ( void );

/* put solve flag */
extern int PutSxSolvStatus ( int );

/* querry the solve flag */
extern int QrySxSolvStatus ( void );

/* put the job name into the SeriesXpansion method database */
extern int PutSxJobName ( const char* );

/* get the job name from the SeriesXpansion method database */
extern int GetSxJobName ( char* );

/* get a pointer to the job name from the SeriesXpansion method database */
extern const char* GetSxJobNamePtr ( void );

extern int ProcSxEnterCmd ( E_PrintKeys );
extern int PutSxEnterStatus ( int );
extern int QrySxEnterStatus ( void );

extern int ProcSxexitCmd( void );

#ifdef __cplusplus
}
#endif

#endif /* _SX_COMMAND_GLOBAL_H_ */
