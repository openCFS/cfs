/* sid 50.1 copy of disp_resource.h last changed by upd111 on 2005/06/04 13:14:41 */
//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by display.rc
//
#define IDR_MENU1                       101
#define IDD_DIALOG2                     103
#define IDD_CREATEANIM                  103
#define IDD_DIALOG1                     104
#define IDD_DIALOG3                     105
#define IDD_DIALOG4                     107
#define IDD_DIALOG5                     108
#define IDD_DIALOG6                     110
#define IDD_DIALOG7                     111
#define IDD_DIALOG8                     113
#define IDI_ICON1                       115
#define IDI_ICON2                       116
#define IDD_DIALOG9                     117
#define IDD_DIALOG10                    119
#define IDR_ACCELERATOR1                120
#define IDD_RESIZE_DLG                  123
#define IDD_DIALOG11                    124
#define IDR_ACCELERATOR2                125
#define IDD_METADLG                     126
#define IDC_EDIT1                       1000
#define IDC_EDIT2                       1001
#define IDC_EDIT5                       1002
#define IDC_EDIT6                       1003
#define IDC_EDIT3                       1004
#define IDC_BUTTON1                     1010
#define IDC_CHECK4                      1014
#define IDC_LIST1                       1022
#define IDC_CHECK1                      1023
#define IDC_EDIT4                       1024
#define IDC_COMBO1                      1025
#define IDC_USER1                       1026
#define IDC_BUTTON2                     1027
#define IDC_STATIC1                     1028
#define IDC_STATIC2                     1029
#define IDC_STATIC3                     1030
#define IDC_COMBO2                      1031
#define IDC_CHECK2                      1032
#define IDC_createfname                 1033
#define IDC_RADIO1                      2001
#define IDC_RADIO2                      2002
#define IDC_RADIO3                      2003
#define IDC_RADIO4                      2004
#define IDC_RADIO5                      2005
#define IDC_RADIO6                      2006
#define IDC_RADIO7                      2007
#define IDC_RADIO8                      2008
#define IDC_RADIO9                      2009
#define IDC_RADIO10                     2010
#define IDC_RADIO11                     2011
#define ID_FILE_EXIT                    40002
#define ID_FILE_OPEN_CMAP               40003
#define ID_CONTROLS_HPGL                40004
#define ID_CONTROLS_POSTSCRIPT          40005
#define ID_CONTROLS_TERMINALOPTIONS     40006
#define ID_FILE_COLORSORT               40008
#define ID_CONTROLS_NOCOLOR             40009
#define ID_CONTROLS_SEGMENT             40010
#define ID_CONTROLS_SEGMENT_SINGLE      40011
#define ID_CONTROLS_SEGMENT_MULTIPLE    40012
#define ID_CONTROLS_SEGMENT_DELETE      40013
#define ID_CONTROLS_SEGMENT_SAVE        40014
#define ID_CONTROLS_SEGMENT_NOSAVE      40015
#define ID_CONTROLS_SEGMENT_OFF         40016
#define ID_CONTROLS_SEGMENT_STAT        40017
#define ID_SHOW_WINDOW                  40018
#define ID_SHOW_ASCIIDUMP               40019
#define ID_SHOW_HPGL                    40020
#define ID_SHOW_INTERLEAF               40021
#define ID_SHOW_POSTSCRIPT              40022
#define ID_DISPLAY_ANIMATE              40023
#define ID_DISPLAY_PLOT                 40024
#define ID_HELP_CONTENTS                40025
#define ID_HELP_SEARCH                  40026
#define ID_HELP_ABOUTDISPLAY            40027
#define ID_HELP_STATUS                  40028
#define ID_FILE_PRINTSETUP              40029
#define ID_FILE_EXPORT                  40031
#define ID_FILE_EXPORTCONTROLS_HPGL     40032
#define ID_FILE_EXPORTCONTROLS_POSTSCRIPT 40033
#define ID_CONTROLS_ANIMATION_BEGINRECORD 40035
#define ID_CONTROLS_ANIMATION_STOPRECORD 40036
#define ID_CONTROLS_ANIMATION           40037
#define ID_ACCEL40039                   40039
#define ID_DISPLAY_ANIMATE_CREATE       40040
#define ID_FILE_OPEN_INPUT              40041
#define ID_FILE_READ_INPUT              40042
#define ID_FILE_READINPUTFROM           40043
#define ID_CONTROLS_RESIZE              40044
#define CTRL_C                          40045
#define ID_CONTROLS_FONTCONTROLS_LEGEND 40046
#define ID_CONTROLS_FONTCONTROLS_ENTITY 40047
#define ID_CONTROLS_FONTCONTROLS_ANOTXT 40048

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        127
#define _APS_NEXT_COMMAND_VALUE         40049
#define _APS_NEXT_CONTROL_VALUE         1038
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
