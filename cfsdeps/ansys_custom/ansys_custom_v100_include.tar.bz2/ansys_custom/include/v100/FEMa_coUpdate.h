/* sid 50.1 copy of FEMa_coUpdate.h last changed by upd111 on 2005/06/04 13:17:00 */

/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 2000 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEMa_coUpdate.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEMa_coUpdate.h
 *  header file for FEMa_coUpdate.c
 *
 */
#ifndef FEMA_COUPDATE_INCLUDE
#define FEMA_COUPDATE_INCLUDE

/*------- (defined in eshapcom.inc) ------------------------------------*/
#define ESHAPNPER 10

/*------- (return value for FEMa_coUpdateAnsys) -------------------------*/
#define EXIT_SHAPEFAILURE 399

typedef struct { INT etstat; DOUBLE a_shpar[ESHAPNPER]; } SHAPE_INFO;

                            /* ============================================= */
                            /* === FEMa_coUpdateAnsys: Description: update   */
                            /* === the ANSYS data base with the new nodes    */
                            /* === and elements                              */
                            /* ============================================= */
INT FEMa_coUpdateAnsys (
   INT *a_vols,                   /* (IN) list of volumes                    */
   INT num_vols,                  /* (IN) number of volumes in list          */
   INT *a_areas,                  /* (IN) list of areas                      */
   INT num_areas,                 /* (IN) number of areas in list            */
   INT *a_lines,                  /* (IN) list of lines                      */
   INT num_lines,                 /* (IN) number of lines in list            */
   INT *a_kps,                    /* (IN)  list of kps to update             */
   INT num_kps,                   /* (IN)  number of kps in a_kps            */
   FEM_BOOLEAN detached,          /* (IN) TRUE if not associated with solid  */
                                  /*      model                              */
   FEM_BOOLEAN handleids,         /* (IN) TRUE if FEMa_coUpdateAnsys needs to*/
                                  /*      worry about renumbering and saving */
                                  /*      ids, etc.  If FALSE, then the      */
                                  /*      calling routine has to do all of   */
                                  /*      it.                                */
   FEM_BOOLEAN concurrent_messages,/* (IN) TRUE if error/warning messages    */
                                  /*      should be printed out when computed*/
                                  /*      during coShapeCheck or after.      */
                                  /*      Either way they will be printed    */
                                  /*      out unless shape checking fails.   */
   FEM_BOOLEAN doShapeChecking,   /* (IN) TRUE if shape checking is TBD      */
   FEM_BOOLEAN storePsuedoFaces,  /* (IN) TRUE if we are storing psuedo faces*/
                                  /*       for volume meshing                */
   VECTOR3D *pcFaceNorm );

                            /* ============================================= */
                            /* === FEMa_coCreateAnsysNodeArray: creates an   */
                            /* === array of nodes in ansys element node form.*/
                            /* === This form duplicates degenerate nodes.    */
                            /* === Can be used for both volume and surface   */
                            /* === elements.  To use for surface elements,   */
                            /* === send element in obj_face and set          */
                            /* === obj_elem == NULL.  To use for volume      */
                            /* === elems, set obj_face == NULL, and send     */
                            /* === volume element in obj_elem.               */
                            /* ============================================= */
INT FEMa_coCreateAnsysNodeArray (
   FACE_OBJ obj_face,             /* (IN)  the face to get nodes from        */
   ELEMENT_OBJ obj_elem,          /* (IN)  the element to get nodes from     */
   NODE_OBJ aobj_nodes[8],        /* (OUT) the nodes on the face             */
   INT *num_nodes );             /* (OUT) length of aobj_nodes              */

                            /* ============================================= */
                            /* === FEMa_coShapeCheck: Check the quality of   */
                            /* === the elements in the cmeshing database     */
                            /* === in preparation to send the mesh back to   */
                            /* === the ANSYS database.                       */
INT FEMa_coShapeCheck (
   FACELIST_OBJ obj_flist,        /* (IN) the face list object, or NULL      */
                                  /*      if skip face shape check           */
   ELEMENTLIST_OBJ obj_ellist,    /* (IN) the element list object, or NULL   */
                                  /*      if skip element shape check        */
   FEM_BOOLEAN do_messages );    /* (IN) TRUE if element shape messages     */
                                  /*      should be printed                  */

                            /* ============================================= */
                            /* === FEMa_coCheckFaceShape: Check quality of   */
                            /* === of one shell element in the c data base   */
INT FEMa_coCheckFaceShape(
   FACE_OBJ obj_face,         /* (IN)  face to be checked */
   FEM_BOOLEAN new_elem,      /* (IN)  TRUE if this face is was created in
                                       the CDatabase or if it was passed into
                                       the CDatabase when it was initialized. */
   FEM_BOOLEAN do_messages ); /* (IN)  TRUE if elem quality messages should be
                                       printed */

                            /* ============================================= */
                            /* === fema_coCheckVolumeElemShape: Check quality*/
                            /* === of one vol element in the c data base     */
INT FEMa_coCheckVolumeElemShape( 
   ELEMENT_OBJ obj_elem,       /* (IN)  elem to be checked */
   FEM_BOOLEAN new_elem,       /* (IN)  TRUE if this elem is was created... */
   FEM_BOOLEAN do_messages );  /* (IN)  TRUE if elem quality messages should be
                                      printed */



                            /* ============================================= */
                            /* === FEMa_coFreeShapeInfoData: Free up         */
                            /* === resources allocated during                */
                            /* === FEMa_coShapeCheck.void                    */
                            /* === Return: void                              */
void FEMa_coFreeShapeInfoData ( void );

                            /* ============================================= */
                            /* === FEMa_coRenumber: Renumber node,face &     */
                            /* === and elem objects                          */
                            /* === Return: EXIT_SUCCESS or EXIT_FAILURE      */
INT FEMa_coRenumber (
   NODELIST_OBJ obj_nlist,       /* (IN) the nodelist object to renumber */
   ELEMENTLIST_OBJ obj_ellist,   /* (IN) the elementlist....             */
   FACELIST_OBJ obj_flist );    /* (IN) the facelist.......             */


#endif

