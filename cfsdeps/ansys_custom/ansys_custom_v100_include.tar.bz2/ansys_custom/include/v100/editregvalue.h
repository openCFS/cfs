/* sid 50.1 copy of editregvalue.h last changed by upd111 on 2005/06/04 13:14:14 */
/***********************************************************************\
 *                                                                     *
 *  regansys.h  -  PJM  - 11/21/94                                     *
 *                                                                      *
 *  Prototypes for registry functions.                                 *
 *                                                                     *
\***********************************************************************/
/*
 * *** ansys(r) copyright(c) 2000
 * *** ansys, inc.
 */

#include <stdlib.h>                  //  _MAX_PATH

 //  registry error types  //

#define OPEN    1
#define CREATE  2
#define SET     3
#define QUERY   4
#define REMOVE  5
#define ENUM    6

 //  function return codes  //

#define SUCCESS          0
#define PROD_DOESNT_EXIST 100
#define ONLY_PRODUCT      101

 //  product options  //

#define ANSYS                1
#define FLOTRAN              2
#define ANSYS_FLOTRAN        3
#define PREPPOST             4

 //  which ANSYS stuff to delete  //

#define PRERELEASE           1
#define NATIVE               2

 //  hive options  //

#define MACHINE 0
#define LOCAL 1

#define cchMax     255           //  max install path to match Al's setup
#define DLG_OFFSET 24            //  dialog box offset for GUI Config

 //  globals for setRegGuiConfig  //

INT scrnx, scrny, fntsz, positun, x, y;
FLOAT scrnax, aspect;
RECT rcMain, rcUtil, rcInput, rcGraph, rcTool;
RECT rcAnot, rcBeam, rcSelct, rcChgvw, rcWpst, rcWpof,rcMshtl;
RECT rcPick, rcCst, rcCnf, rcLister, rcCopy, rcEdit, rcScal, rcAry;
RECT rcMPick, rcRPick, rcSnap, rcMdlsmb;
RECT rcHelp, rcHcopy, rcHhis, rcHscr, rcHart, rcHlpon;
RECT rcOutput;

struct tagAppInfo
{
   CHAR szWorkDir[_MAX_PATH];
   CHAR szGraphDev[25];
   CHAR szJobname[253];
   CHAR szWorkSpace[25];
   INT  iReadStart;
   CHAR szParameters[625];
   CHAR szDatabase[25];
   INT  iListToOutput;
   CHAR szExtension[256];
};


 //  Setup  //

//BOOL setupReg ( CHAR [], CHAR [], CHAR [] );
BOOL setupRegMachine( CHAR szInstallPath[], CHAR szProdCode[] );
BOOL setupRegUser ( VOID );
BOOL setupRegVers ( VOID );
BOOL delAnsPath ( CHAR [], INT );
BOOL addRegPath ( CHAR [] );
BOOL addAnsDir ( CHAR [], CHAR [] );
BOOL addAnsysProd ( CHAR [] );
BOOL addProdCodes ( CHAR [] );
BOOL unSetupReg ( VOID );
BOOL isRegThere ( VOID );
BOOL querySecDev ( VOID );
BOOL isLocalGroup ( CHAR [] );
VOID remove23PrgGrp ( HKEY );
VOID removeRevData ( HKEY );
BOOL regQuickConfig ( VOID );
BOOL get52ProdCode ( CHAR [], INT );
VOID updateSubKeys( VOID );
VOID addSubKey(CHAR szSubKey[] );
BOOL deinstallReg( VOID );
BOOL RemoveKeyAndSubs( HKEY hParentKey, CHAR szKey[] );

INT removeProduct( CHAR [] );

 //  Geometry  //

BOOL setRegGeometry ( CHAR [], RECT );
BOOL getRegGeometry ( CHAR [], RECT * );

 //  Color  //

BOOL setRegColor ( CHAR [], COLORREF );
BOOL getRegColor ( CHAR [], COLORREF * );

 //  Integer  //

BOOL setRegInt ( CHAR [], INT );
BOOL getRegInt ( CHAR [], INT * );

 //  String  //

BOOL setRegString ( CHAR [], CHAR [], INT );
BOOL getRegString ( CHAR [], CHAR [], INT, INT );
BOOL getRegStringNoError ( CHAR [], CHAR [], INT, INT );
BOOL getRegUninstall ( CHAR [], CHAR [], INT);

 //  Structure  //

BOOL setRegAppInfo ( CHAR [], struct tagAppInfo );
BOOL getRegAppInfo ( CHAR [], struct tagAppInfo * );
// BOOL getRegStrSub ( CHAR [], CHAR [] , INT , CHAR [], HKEY, HANDLE );
BOOL getRegStrSub ( CHAR [], CHAR [] , INT , CHAR [], HKEY );
BOOL getRegIntSub ( CHAR [], INT *, CHAR [], HKEY );

 //  ANSYS_PRODUCT environment variable  //

BOOL setAnsysProd ( CHAR szData[] );
BOOL getAnsysProd ( CHAR szData[], INT iSizeData );

 //  GUI Configuration  //

VOID setRegGuiConfig ( INT, INT );
VOID setaGUIMenu ( INT );
VOID custlft ( VOID );
VOID custrit ( VOID );
VOID custbot ( VOID );

 //  Error Control  //

VOID regError ( INT, CHAR [] );
