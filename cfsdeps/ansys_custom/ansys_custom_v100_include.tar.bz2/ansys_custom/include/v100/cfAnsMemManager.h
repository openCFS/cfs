/* sid 50.1 copy of cfAnsMemManager.h last changed by upd111 on 2005/06/04 13:21:00 */
/*
 *  cfAnsMemManager.h
 *
 *  This file provides the data structures for the debug layer of the memory 
 *  manager.
 */

/* 
 * *** ansys(r) copyright(c) 2002
 * *** ansys, inc.
 */

#if !defined(__CFANSMEMMANAGER_H__)
#define __CFANSMEMMANAGER_H__

                                     /* 1234567890123456 */
static const char BLANK_BLOCK_NAME[] = "                ";

typedef struct BlocksTableTag {
   CHAR blockName[BLOCK_NAMES_SIZE+1]; /* array of memory block names (for 
                                           FORTRAN) */
   INT blockLength;      /* array of memory block lengths (for FORTRAN) */
   INT blockElementSize; /* sizes of elements that are alloced */
   INT blockType;        /* block types (for FORTRAN).  Also stores 
                            allocation group bit patterns (in bits 17-23) */
   INT lineNumber;       /* line numbers where allocs occured (C) */
   CHAR *fileName;       /* pointers to filenames where allocs occured (C) */
} BlocksTable;

typedef struct cfAnsMemTableTag {
   BlocksTable *tbl;       /* table that holds the debug info */
   INT debugTableLength;   /* length of the table */
   INT debugPadLength;     /* length of the debug pads that are added to the 
                              ends of each block */
   INT debugLevel;         /* debugging level (bit pattern) */
   INT debugMask;          /* base debugging mask */
   INT fReturn;            /* if 1, return to calling routine even if the 
                              memory request fails (defaults to stopping the 
                              run via an error call -- HEAP INTERFACE ONLY) */
   INT initialized;        /* if 0, this level of the manager is not initialized
                              if 1, this level of the manager is initialized */
} cfAnsMemTable;


/* prototypes for functions that are called within this file, but not externally */
void cJournalHelper(INT, void *);
void MemBlockDbgFill(void *, size_t);
INT MemBlockDbgCheck(void *, size_t);
INT cfAnsMemPrintLeak(INT handle);
void TrimCBlockName(CHAR *fname, INT lNum, INT sLen, CHAR *outStr);
INT cfAnsMemCheckPads(INT handle);
void AnsMemUserError(INT code, INT data);

void AnsMemError(CHAR *format, ...);
void AnsMemDebugMessage(CHAR *format, ...);
void AnsMemWarningMessage(CHAR *format, ...);
void AnsMemOutputOperation(CHAR *format, ...);

void AnsMemErrorImpl(UNSIGNED_INT debug, CHAR *format, va_list ap);
void AnsMemDebugMessageImpl(UNSIGNED_INT debug, CHAR *format, va_list ap);
void AnsMemWarningMessageImpl(UNSIGNED_INT debug, CHAR *format, va_list ap);
void AnsMemPrintFatalErrorMessage(UNSIGNED_INT debug, CHAR *format, va_list ap);

void AnsMemPrintVA(UNSIGNED_INT debugLevel,INT out,CHAR *format,va_list ap);
void ReportPadOverrun(INT handle, INT type);
#endif

