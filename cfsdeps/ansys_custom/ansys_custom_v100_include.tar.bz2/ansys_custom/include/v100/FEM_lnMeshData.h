/* sid 50.1 copy of FEM_lnMeshData.h last changed by upd111 on 2004/11/04 18:31:14 */
#ifndef FEM_LNMESHDATA________________H
#define FEM_LNMESHDATA________________H
#include "FEM_MeshData.h"

class LINEMSHDAT_TYP : public MSHDAT_TYP {

   private:
      unsigned m_meshed:1;
      unsigned m_premeshed:1;
      unsigned m_harddivs:1;
      unsigned m_softdivs:1;
      unsigned m_sweep_parallel:1;
      unsigned m_sweep_perpendicular:1;
      unsigned m_needsmidndoes:1;
      unsigned m_projectmids:1;
      unsigned m_onsweeppath:1;
      unsigned m_highprigoal:1;
      unsigned m_trgsmoothed:1;
      unsigned m_straight:1;
      INT m_onSweepableVol;
      INT m_frozen;	
      INT m_index;
      INT m_numdivs;
      INT m_goaldivs;
      INT m_nodeLocDivs;
      DOUBLE m_bias;
      DOUBLE *m_a_line_t;
      DOUBLE m_esize0;
      DOUBLE m_esize1; 
      DOUBLE m_curv;
      NODELIST_OBJ m_obj_nlist;
      NODE_OBJ *m_aobj_nodes ;
      INT m_num_nodes ;
      INT m_mark; // just for marking
      
   public:
      LINEMSHDAT_TYP() {Init(); };
      ~LINEMSHDAT_TYP() { Delete(); };

      void Init( ) { InitMSH_TYP();
                     m_meshed = 0;
                     m_premeshed = 0;
                     m_harddivs = 0;
                     m_softdivs = 0;
                     m_numdivs = 0;
                     m_goaldivs = 0;
                     m_nodeLocDivs = 0;
                     m_bias = 1.0;
                     m_a_line_t = NULL;
                     m_index = 0;
                     m_sweep_parallel = 0;
                     m_sweep_perpendicular = 0;
                     m_needsmidndoes = 0;
                     m_projectmids = 0;
                     m_highprigoal = 0;
                     m_onsweeppath = 0;
                     m_frozen = 0;
                     m_onSweepableVol = -1;
                     m_curv = 0.0e0;
                     m_esize0 = 0.0e0;
                     m_esize1 = 0.0e0;
                     m_trgsmoothed = 0;
                     m_straight = 0;
                     m_obj_nlist = NULL;
                     m_aobj_nodes = NULL ;
                     m_num_nodes = 0 ;
                     m_mark = 0;
      };

      void Delete( ) { m_meshed = 0;
                       m_premeshed = 0;
                       m_softdivs = 0;
                       m_harddivs = 0;
                       m_numdivs = 0;
                       m_goaldivs = 0;
                       m_nodeLocDivs = 0;
                       m_bias = 1.0;
                       FEM_Free_C( m_a_line_t );
                       m_index = 0;
                       m_sweep_parallel = 0;
                       m_sweep_perpendicular = 0;
                       m_needsmidndoes = 0;
                       m_projectmids = 0;
                       m_highprigoal = 0;
                       m_onsweeppath = 0;
                       m_onSweepableVol = -1;
                       m_esize0 = 0.0e0;
                       m_esize1 = 0.0e0;
                       m_frozen = 0;
                       m_curv = 0.e0;
                       m_trgsmoothed = 0;
                       m_straight = 0;
                       if (m_obj_nlist) {
                          FEM_noDeleteList (m_obj_nlist);
                       }
					   if( m_aobj_nodes )
						   FEM_Free_C( m_aobj_nodes ) ;
                       m_aobj_nodes = NULL ;
                       m_num_nodes = 0 ;
                       m_mark=0;
      };

      FEM_BOOLEAN IsOnSrcAndTrg( void ) const;
      FEM_BOOLEAN IsOnSrc( void ) const;
      FEM_BOOLEAN IsOnTrg( void ) const;

      inline void SetMeshed( const FEM_BOOLEAN meshed = TRUE )
      {
         if ( meshed ) m_meshed = 1;
         else m_meshed = 0;
      };

      inline FEM_BOOLEAN IsMeshed( ) const
      {
         if ( m_meshed == 1 ) return TRUE;
         else return FALSE;
      };

      inline void SetPreMeshed( const FEM_BOOLEAN meshed = TRUE )
      {
         if ( meshed ) m_premeshed = 1;
         else m_premeshed = 0;
      };

      inline FEM_BOOLEAN IsPreMeshed( ) const
      {
         if ( m_premeshed == 1 ) return TRUE;
         else return FALSE;
      };

      inline void SetTargetSmoothed( const FEM_BOOLEAN trgsmoothed = TRUE )
      {
         if ( trgsmoothed ) m_trgsmoothed = 1;
         else m_trgsmoothed = 0;
      };

      inline FEM_BOOLEAN TargetSmoothed( ) const
      {
         if ( m_trgsmoothed == 1 ) return TRUE;
         else return FALSE;
      };

      inline void SetStraight( const FEM_BOOLEAN straight = TRUE )
      {
         if ( straight ) m_straight = 1;
         else m_straight = 0;
      };

      inline FEM_BOOLEAN Straight( ) const
      {
         if ( m_straight == 1 ) return TRUE;
         else return FALSE;
      };

      inline void SetNeedsMidnodes( const FEM_BOOLEAN status = TRUE )
      {
         if ( status ) m_needsmidndoes = 1;
         else m_needsmidndoes = 0;
      };

      inline FEM_BOOLEAN NeedsMidnodes( ) const
      {
         if ( m_needsmidndoes == 1 ) return TRUE;
         else return FALSE;
      };

      inline void SetProjectMids( const FEM_BOOLEAN status = TRUE )
      {
         if ( status ) m_projectmids = 1;
         else m_projectmids = 0;
      };

      inline FEM_BOOLEAN ProjectMids( ) const
      {
         if ( m_projectmids == 1 ) return TRUE;
         else return FALSE;
      };

      inline void ResetSweepDir( )
      {
         m_sweep_parallel = 0;
         m_sweep_perpendicular = 0;
      };

      inline void SetParallelToSweepDir( const FEM_BOOLEAN status = TRUE )
      {
         if ( status ) {
            m_sweep_parallel = 1;
            m_sweep_perpendicular = 0;
         }
         else {
            m_sweep_parallel = 0;
            m_sweep_perpendicular = 1;
         }
      };

      inline FEM_BOOLEAN ParallelToSweepDir( ) const
      {
         if ( m_sweep_parallel == 1 ) return TRUE;
         else return FALSE;
      };

      inline void SetPerpendicularToSweepDir( const FEM_BOOLEAN status = TRUE )
      {
         if ( status ) {
            m_sweep_parallel = 0;
            m_sweep_perpendicular = 1;
         }
         else {
            m_sweep_parallel = 1;
            m_sweep_perpendicular = 0;
         }
      };

      inline FEM_BOOLEAN PerpendicularToSweepDir( ) const
      {
         if ( m_sweep_perpendicular == 1 ) return TRUE;
         else return FALSE;
      };

      inline void SetHardDivs( const FEM_BOOLEAN harddivs = TRUE )
      {
         if ( harddivs ) m_harddivs = 1;
         else m_harddivs = 0;
      };

      inline void SetSoftDivs( const FEM_BOOLEAN softdivs = TRUE )
      {
         if ( softdivs ) m_softdivs = 1;
         else m_softdivs = 0;
      };

      inline FEM_BOOLEAN HasHardDivs( ) const
      {
         if ( m_harddivs == 1 ) return TRUE;
         else return FALSE;
      };

      inline FEM_BOOLEAN HasSoftDivs( ) const
      {
         if ( m_softdivs == 1 ) return TRUE;
         else return FALSE;
      };

      inline void SetOnASweepPath( const FEM_BOOLEAN stat = TRUE )
      {
         if ( stat ) m_onsweeppath = 1;
         else m_onsweeppath = 0;
      };

      inline FEM_BOOLEAN OnASweepPath( ) const
      {
         if ( m_onsweeppath == 1 ) return TRUE;
         else return FALSE;
      };

      FEM_BOOLEAN OnSweepableVol();

      inline void SetIndex( const INT index = 0 ) { m_index = index; };
      inline INT Index( ) const { return m_index; };

      inline void SetNumDivs( const INT numdivs = 0 ) { m_numdivs = numdivs; };
      inline INT NumDivs( ) const { return m_numdivs; };

      inline void SetGoalDivs( const INT numdivs = 0 ) { m_goaldivs = numdivs; };
      inline INT GoalDivs( ) const { return m_goaldivs; };

      inline void SetHighPriorityGoal( const FEM_BOOLEAN stat = TRUE )
      {
         if ( stat ) m_highprigoal = 1;
         else m_highprigoal = 0;
      };

      inline FEM_BOOLEAN HighPriorityGoal( ) const
      {
         if ( m_highprigoal == 1 ) return TRUE;
         else return FALSE;
      };

      inline void SetBias( const DOUBLE bias = 0 ) { m_bias = bias; };
      inline DOUBLE Bias( ) const { return m_bias; };

      inline void SetLine( const LINE_PTYP obj_line ) { SetCell( obj_line ); };
      inline LINE_PTYP GetLine( ) const { return (LINE_PTYP)GetCell(); };

      INT FindNodeLocs();
      inline void SetNodeLocs( DOUBLE *a_line_t )
      {
         FEM_Free_C( m_a_line_t);
         m_a_line_t = a_line_t;
      };
      inline void SetNodeLocDivs( INT nodeLocDivs )
      {
         m_nodeLocDivs = nodeLocDivs;
		 SetNumDivs( nodeLocDivs ) ;
      }

      inline FEM_BOOLEAN NodeLocsFound() const
      {
         if ( m_a_line_t ) return TRUE;
         else return FALSE;
      }
      inline void DeleteNodeLocs() 
	  { 
		  FEM_Free_C( m_a_line_t ); 
		  SetNodeLocDivs( 0 ) ;
	  };
      inline DOUBLE const *NodeLocs() { return m_a_line_t; };
      inline INT  NodeLocDivs() { 
		return NumDivs() ;
		// return m_nodeLocDivs; 
	  };

      inline INT Frozen() const {return m_frozen;} ;
      inline void SetFrozen( const INT frozen ) {m_frozen = frozen; };

      inline DOUBLE Esize0() const { return m_esize0; };
      inline void SetEsize0( const DOUBLE esize0 ) { m_esize0 = esize0; };

      inline DOUBLE Esize1() const { return m_esize1; };
      inline void SetEsize1( const DOUBLE esize1 ) { m_esize1 = esize1; };

      inline DOUBLE Curv() const { return m_curv;} ;
      inline void SetCurv( const DOUBLE curv ) { m_curv = curv; };

      inline NODELIST_OBJ NodeList() const { return m_obj_nlist; };
      inline NODELIST_OBJ NewNodeList() { m_obj_nlist = FEM_noNewList();
                                   return m_obj_nlist; };
      void setNodesOnLine( NODE_OBJ *aobj_nodes, INT numNodes ) ;
      void getNodesOnLine( NODE_OBJ *&aobj_nodes, INT &numNodes ) ;
      inline void setMark( INT mark ) { m_mark = mark ;}
      inline INT  getMark() { return m_mark; } 
};    
typedef class LINEMSHDAT_TYP *LINEMSHDAT_PTYP;
void FEM_lnMd( LINEMSHDAT_PTYP obj_linedata );
#endif

