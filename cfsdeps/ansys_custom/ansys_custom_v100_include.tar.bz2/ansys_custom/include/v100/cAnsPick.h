/* sid 50.1 copy of cAnsPick.h last changed by upd111 on 2005/06/04 13:18:31 */
/* cAnsPick.h	                                        
------------------------------------------------------------------------
------- Notice - This file contains ANSYS Confidential information 
------------------------------------------------------------------------
*/

/* ---------------------------------------------------------------------
 * Copyright 1999 SAS IP, Inc. 
 * ---------------------------------------------------------------------*/

/*------------------------------ Description ---------------------------
 * Description:   The include file to be used for the ANSYS Picking
 *                API routines.
 *----------------------------------------------------------------------*/
#if defined(PCWINNT_SYS)
#include <windows.h>
typedef struct
{
   HWND hwnd;
   UINT message;
   WPARAM wParam;
   LPARAM lParam;
} W32Event;
#else
#include <X11/Xlib.h>
#endif

/*--------------------- Static TypeDefs/Structures ---------------------*/
typedef struct {
   int      event;      /* The type of event:
                              0 - motion   
                              1 - button down
                              2 - button release
                              3 - key press  
                              4 - key release
                             99 - cancel */
   int      button;     /* Button or Key for event:
                              0 - no button event
                              1 - left mouse button
                              2 - middle mouse button
                              3 - right mouse button
                              n - ascii key for key event  */
   int      bmask;      /* Button Mask  */
   int      ixy[2];     /* Screen X and Y value of the picked location */ 
   int      entitynum;  /* The ANSYS ID for the selected entity */
   int      entitytype; /* The selected entity type which corresponds
                           to PCK_TYPE */
   double   xyz[3];     /* The global cartesian X, Y, and Z location
                           of the picked entity or WP picked location. */
   double   xywp[2];    /* The WP coordinate */
#if !defined(PCWINNT_SYS)
   XEvent eventData;    /* This will be used to store the X event data */
                        /* structure */
#else
   W32Event eventData;  /* This will be used to store the Windows event */
                        /* information.  See the above declared structure */
#endif
   int      ispare[10];
   double   dspare[10];
} pickData;

typedef struct {
#if !defined(PCWINNT_SYS)
   XEvent eventData;    /* This will be used to store the X event data */
                        /* structure */
#else
   W32Event eventData;  /* This will be used to store the Windows event */
                        /* information.  See the above declared structure */
#endif
   int      ispare[10];
   double   dspare[10];
} keyData;



/*----------------------- Variable Definitions -------------------------*/
#define PCK_PCKSEL      0
#define     PCK_UNPCK 0
#define     PCK_PCK   1
#define PCK_SLECT       1
#define     PCK_SNGL 0
#define     PCK_BOX  1
#define     PCK_POLY 2
#define     PCK_CIRC 3
#define     PCK_LOOP 4
#define PCK_TYPE        3
#define PCK_ENTSEL      4
#define PCK_RBMODE      5
#define PCK_DUP         6
#define PCK_ORDR        7
#define PCK_ENTMIN      8
#define PCK_ENTMAX      9
#define PCK_NLIST      10
#define PCK_NDUP       11
#define PCK_CUR_ENTNUM 12
#define PCK_CUR_ENTTYP 13
#define PCK_PNUMTYP    14
#define PCK_PTYP       15
#define PCK_INIT       999
#ifndef FALSE
#define     FALSE 0
#endif
#ifndef TRUE
#define     TRUE  1
#endif
#define PK_ENT_NODE 1
#define PK_ENT_ELEM 2
#define PK_ENT_KEYP 3
#define PK_ENT_LINE 4
#define PK_ENT_AREA 5
#define PK_ENT_VOLU 6
#define PK_ENT_TRAC 7
#define PK_ENT_CMP  8
#define PK_ENT_GRPT 9
#define PK_BIT_NODE 1
#define PK_BIT_ELEM 2
#define PK_BIT_KEYP 4
#define PK_BIT_LINE 8
#define PK_BIT_AREA 16
#define PK_BIT_VOLU 32
#define PK_BIT_TRAC 64
#define PK_BIT_CMP  128
#define PK_BIT_GRPT 256
#define PK_KB_LIST  0
#define PK_KB_RANG  1

/*------------------------- API Functions ------------------------------*/

extern void cAnsPick_EntityInfo(int iop, int ival);
   /*
    *    iop  = PCK_PCKSEL  ,0 ---  PCK_UNPCK   0
    *                               PCK_PCK     1
    *           PCK_SLECT   ,1 ---  PCK_SNGL    0
    *                               PCK_BOX     1
    *                               PCK_POLY    2
    *                               PCK_CIRC    3
    *                               PCK_LOOP    4
    */

extern int cAnsPick_EntityInqr(int iop);
   /*
    *    PCK_INFOKEY  = PCK_PCKSEL      , 0 ---  PCK_UNPCK   0
    *                                            PCK_PCK     1
    *                   PCK_SLECT       , 1 ---  PCK_SNGL    0
    *                                            PCK_BOX     1
    *                                            PCK_POLY    2
    *                                            PCK_CIRC    3
    *                                            PCK_LOOP    4
    *                   PCK_TYPE        , 3 ---  Entity Type(s)
    *                   PCK_ENTSEL      , 4 ---  Selection mode (sel,unsel,def)
    *                   PCK_RBMODE      , 5 ---  Rubberband Style
    *                   PCK_DUP         , 6 ---  Allow duplicate picks ?
    *                   PCK_ORDR        , 7 ---  Does order matter
    *                   PCK_ENTMIN      , 8 ---  Minimum picked required
    *                   PCK_ENTMAX      , 9 ---  Maximum picked
    *                   PCK_NLIST       ,10 ---  Number of entities picked
    *                   PCK_NDUP        ,11 ---  Number of duplicate entities
    *                                            picked
    *                   PCK_CUR_ENTNUM  ,12 ---  Current selected entity number
    *                   PCK_CUR_ENTTYP  ,13 ---  Current selected entity type
    *                   PCK_PNUMTYP     ,14 ---  Current number of entity types
    *                                            picked.
    *                   PCK_PTYPE       ,15 ---  Current entity types picked.
    */
extern void cAnsPick_Entity(int itype, int ksel, int krub, int dup,
                     int korder, int nmn, int numreq, 
                     void (*externalCallBack)(void *));
extern void cAnsPick_EntityDump(int *n, int **list_ent, int **list_typ);
extern void cAnsPick_EntityDone(void);
extern void cAnsPick_EntityPickAll(void);
extern void cAnsPick_EntityRange(int itype, int key, int n, int *idata);
   /*   itype    = entity type
        key      = list or min.max,inc (PK_KB_LIST, PK_KB_RANG)
        n        = number in list
        idata    = entity data          */
extern void cAnsPick_EntityRestart(int *n);  /* used for apply  */
extern void cAnsPick_EntityReset(void);
extern void cAnsPick_EntityNextDup(void);
extern void cAnsPick_EntityPrevDup(void);
extern void cAnsPick_EntityDumpDup(int *n, int **list_ent, int **list_typ);

extern void cAnsPick_XYZ(int key, int krub, int nmn, int numreq,  
                  void (*externalCallBack)(void *));
   /*  key -> 0= wp pick,  1= screen pick */
extern void cAnsPick_XYZDump(int *nlist, double **list_xyz);
extern void cAnsPick_XYZDone(void);
extern void cAnsPick_XYZReset(void);
extern void cAnsPick_XYZInfo(int iop, int ival);
   /*    iop  = PCK_PCKSEL  ,0 ---  PCK_UNPCK   0
    *                               PCK_PCK     1 */
extern int  cAnsPick_XYZInqr(int iop);
   /*    
    *    PCK_INFOKEY  = PCK_PCKSEL      , 0 ---  PCK_UNPCK   0
    *                                            PCK_PCK     1
    *                   PCK_RBMODE      , 5 ---  Rubberband Style
    *                   PCK_ENTMIN      , 8 ---  Minimum picked required
    *                   PCK_ENTMAX      , 9 ---  Maximum picked
    *                   PCK_NLIST       ,10 ---  Number of entities picked 
    */
extern void cAnsPick_XYZAdd( double *xyz);

extern void cAnsGraph_KeyEvent(void (*externalCallBack)(void *));

extern int cAnsGraph_FindWn(int ptrX, int ptrY);

/*------------------------------ API Description -----------------------
cAnsPick_XYZInfo


  void cAnsPick_XYZInfo(iop, ival)
       int iop;
       int ival;

Header File: cAnsPick.h

Purpose:
     Provide information to the current locational picking operation 

Parameters:
     Input
     -----------------------------
       
       iop
         Operation key indicating which value to change.

         PCK_PCKSEL (defined in cAnsPick.h) Pick selection mode
      
       ival
         Value to be assigned for the given operational key.

         PCK_UNPCK - value indicates unpick mode.
         PCK_PCK   - value indicates pick mode.

     Output
     -----------------------------
  
       None

Return Value:

       N/A
----------------------------- End API Description --------------------*/


/*------------------------------ API Description -----------------------
cAnsPick_XYZInqr


  int cAnsPick_XYZInqr(int iop)
       int iop;

Header File: cAnsPick.h

Purpose:
     Obtain information about the current locational picking operation 

Parameters:
     Input
     -----------------------------
       
       iop
         Operation key indicating information desired.

         PCK_PCKSEL      ---  Current pick mode
                                  returns  PCK_UNPCK if unpicking
                                  returns  PCK_PCK   if picking
         PCK_RBMODE      ---  Rubberband Style
                           Possible return values:

                                    1 = lines
                                    2 = rectangle (corner - opp/corner)
                                    3 = circle (center - radius)
                                    4 = annulus (center - r1 - r2)
                                    5 = partial annulus
                                    6 = rectangle (center - corner)
                                    7 = circle (on circ - on circ)
                                    8 = square (center  - on edge)
                                   13 = 3 equal-sided polygon
                                   14 = 4 equal-sided polygon
                                   15 = 5 equal-sided polygon
                                   16 = 6 equal-sided polygon
                                   17 = 7 equal-sided polygon
                                   18 = 8 equal-sided polygon
                                  101 = polyhedren
                                  102 = block
                                  103 = cylinder-solid
                                  104 = cylinder-hollow
                                  105 = partial cylinder
                                  106 = block (center - corner)
                                  107 = cylinder-solid (on circ - on circ)
                                  108 = cone
                                  113 = 3 equal-sided polyhedren
                                  114 = 4 equal-sided polyhedren
                                  115 = 5 equal-sided polyhedren
                                  116 = 6 equal-sided polyhedren
                                  117 = 7 equal-sided polyhedren
                                  118 = 8 equal-sided polyhedren
                                  201 = electric inductor
                                  202 = electric capacitor
                                  203 = electric resistor
                                  204 = electric circuit cr1
                                  205 = electric circuit cr2
                                  206 = electric circuit cr3
                                  207 = electric circuit cr4
                                  208 = electric mutual inductor
                                  209 = torsional spring
                                  210 = simple diode
                                  211 = zener  diode
                                  212 = linear spring
                                  213 = linear damper
                                  214 = torsional damper
                                  215 = EMT transducer
                                  216 = piezoelectric crystal
                                  217 = lumped mass
         PCK_ENTMIN      ---  Minimum picked required
         PCK_ENTMAX      ---  Maximum picked
         PCK_NLIST       ---  Number of entities picked
      
     Output
     -----------------------------
       None

Return Value:

       Returns the current data value as indicated by the iop key.
       This function will return 0 (zero) for invalid iop keys.

----------------------------- End API Description --------------------*/

/*------------------------------ API Description -----------------------
cAnsPick_XYZ


void cAnsPick_XYZ(key, krub, nmn, numreq, (*externalCallBack)(void *))

       int key
       int krub
       int nmn
       int numreq,
       void (*externalCallBack)(void *))


Header File: cAnsPick.h

Purpose:
     Provide information to the current locational picking operation 

Parameters:
     Input
     -----------------------------
       
       key 
         Pick mode to invoke.
             0= wp pick
             1= screen pick 
  
       krub
         Rubber band mode to use.
         For wp picking (key=0) valid modes are:
                 1 = lines
                 2 = rectangle (corner - opp/corner)
                 3 = circle (center - radius)
                 4 = annulus (center - r1 - r2)
                 5 = partial annulus
                 6 = rectangle (center - corner)
                 7 = circle (on circ - on circ)
                13 = 3 equal-sided polygon
                14 = 4 equal-sided polygon
                15 = 5 equal-sided polygon
                16 = 6 equal-sided polygon
                17 = 7 equal-sided polygon
                18 = 8 equal-sided polygon
               101 = polyhedren
               102 = block
               103 = cylinder-solid
               104 = cylinder-hollow
               105 = partial cylinder
               106 = block (center - corner)
               107 = cylinder-solid (on circ - on circ)
               108 = cone
               113 = 3 equal-sided polyhedren
               114 = 4 equal-sided polyhedren
               115 = 5 equal-sided polyhedren
               116 = 6 equal-sided polyhedren
               117 = 7 equal-sided polyhedren
               118 = 8 equal-sided polyhedren
               201 = electric inductor
               202 = electric capacitor
               203 = electric resistor
               204 = electric circuit cr1
               205 = electric circuit cr2
               206 = electric circuit cr3
               207 = electric circuit cr4
               208 = electric mutual inductor
               209 = torsional spring
               210 = simple diode
               211 = zener  diode
               212 = linear spring
               213 = linear damper
               214 = torsional damper
               215 = EMT transducer
               216 = piezoelectric crystal
               217 = lumped mass
         For screen picking (key=1) valid modes are:
                 1 = lines
                 2 = rectangle (corner - opp/corner)
                 3 = circle (center - radius)
                 6 = rectangle (center - corner)
                 7 = circle (on circ - on circ)
                 8 = square (center  - on edge)

       nmn
         Minimum number of points needed

       numreq
         The upper limit on the number of points that can be picked.

      
       (*externalCallBack)(void *)) 
         A pointer to a function to be notified upon each valid pick
         event that occurs. This function is passed a pointer to a 
         pickData structure as defined in cAnsPick.h. The ANSYS functions
         that call this function own the pickData structure. A copy of it
         should be made by the externalCallBack function upon invocation.

     Output
     -----------------------------
  
       None

Return Value:

       N/A
----------------------------- End API Description --------------------*/

/*------------------------------ API Description -----------------------
cAnsPick_XYZDump

  void cAnsPick_XYZDump(n, list_xyz)
       int *n;
       double **list_xyz;

Header File: cAnsPick.h

Purpose:
     Dumps the current xyz location data set and undraws the picked 
     points highlighting.

Parameters:
     Input
     -----------------------------
       
       *n
         Pointer to an integer that will recieve the number of 
         points picked.

       **list_xyz
         Pointer to a double pointer. The pointer to the xyz location 
         data is returned to the calling function.

     Output
     -----------------------------
  
       *n
         The number of points picked is assigned to the integer 
         at this address.

       **list_xyz
         The pointer to the xyz location data is returned to the 
         calling function through this pointer.

Return Value:

       N/A
----------------------------- End API Description --------------------*/

/*------------------------------ API Description -----------------------
cAnsPick_XYZDone

  void cAnsPick_XYZDone()

Header File: cAnsPick.h

Purpose:
     Terminates the current location data picking link.

Parameters:
     Input
     -----------------------------
       
     None

     Output
     -----------------------------
  
     None

Return Value:

       N/A
----------------------------- End API Description --------------------*/

/*------------------------------ API Description -----------------------
cAnsPick_XYZReset

  void cAnsPick_XYZReset()

Header File: cAnsPick.h

Purpose:
     Resets the location picking mode to initial state.

Parameters:
     Input
     -----------------------------
       
     None

     Output
     -----------------------------
  
     None

Return Value:

       N/A
----------------------------- End API Description --------------------*/

/*------------------------------ API Description -----------------------
cAnsPick_XYZAdd

  void cAnsPick_XYZAdd(xyz)

       double *xyz;

Header File: cAnsPick.h

Purpose:
     Adds the given XYZ coordinate location to the picked set.

Parameters:
     Input
     -----------------------------
       
     xyz
         Pointer to double array containing the xyz coordinates 
         to be added to the current picked location data set.


     Output
     -----------------------------
  
     None

Return Value:

       N/A
----------------------------- End API Description --------------------*/

/*------------------------------ API Description -----------------------
cAnsPick_EntityInfo


  void cAnsPick_EntityInfo(iop, ival)
       int iop;
       int ival;

Header File: cAnsPick.h

Purpose:
     Provide information to the current entity picking operation 

Parameters:
     Input
     -----------------------------
       
       iop
         Operation key indicating which value to change.

         PCK_PCKSEL -  Selection mode
         PCK_SLECT  -  Selection style
      
       ival
         Value to be assigned for the given operational key.

         For iop =  PCK_PCKSEL
         PCK_UNPCK -  value indicates unselect mode.
         PCK_PCK   -  value indicates select mode.

         For iop =  PCK_SLECT   
         PCK_SNGL  - value indicates use single select style
         PCK_BOX   - value indicates use box select style
         PCK_POLY  - value indicates use polygon select style
         PCK_CIRC  - value indicates use circle select style
         PCK_LOOP  - value indicates use loop select style

     Output
     -----------------------------
  
       None

Return Value:

       N/A
----------------------------- End API Description --------------------*/

/*------------------------------ API Description -----------------------
cAnsPick_EntityInqr


  int cAnsPick_EntityInqr(iop)
       int iop;

Header File: cAnsPick.h

Purpose:
     Obtain information about the current entity picking operation 

Parameters:
     Input
     -----------------------------
       
       iop
         Operation key indicating which value to obtain.

         PCK_PCKSEL - Selection mode
         PCK_SLECT  - Seletcion style
      
       ival
         Value to be assigned for the given operational key.

         For iop = PCK_PCKSEL
         PCK_UNPCK      - returned value indicates unselect mode.
         PCK_PCK        - returned value indicates select mode.

         For iop = PCK_SLECT   
         PCK_SNGL       - returned value indicates single select style
         PCK_BOX        - returned value indicates box select style
         PCK_POLY       - returned value indicates polygon select style
         PCK_CIRC       - returned value indicates circle select style
         PCK_LOOP       - returned value indicates loop select style

         For iop = PCK_TYPE  
         PK_BIT_NODE    1 - returned value indicates picking nodes
         PK_BIT_ELEM    2 - returned value indicates picking elements
         PK_BIT_KEYP    4 - returned value indicates picking keypoints
         PK_BIT_LINE    8 - returned value indicates picking lines
         PK_BIT_AREA   16 - returned value indicates picking areas
         PK_BIT_VOLU   32 - returned value indicates picking volumes
         PK_BIT_TRAC   64 - returned value indicates picking traces
         PK_BIT_CMP   128 - returned value indicates picking components
         PK_BIT_GRPT  256 - returned value indicates picking graph points
         a combination of these (sum) keys indicates a multi-entity mode.

         For iop = PCK_ENTSEL ---  Selection mode currently active (sel,unsel,def)
         Possible return values:
           1 - returned value indicates only selected entities can be picked.
          -1 - returned value indicates only unselected entities can be picked.
           0 - returned value indicates both selected and unselected entities 
                can be picked.

         For iop = PCK_RBMODE ---  Rubberband Style
         Possible return values:
           1 = lines
           2 = rectangle (corner - opp/corner)
           3 = circle (center - radius)
           4 = annulus (center - r1 - r2)
           5 = partial annulus
           6 = rectangle (center - corner)
           7 = circle (on circ - on circ)
           8 = square (center  - on edge)
          13 = 3 equal-sided polygon
          14 = 4 equal-sided polygon
          15 = 5 equal-sided polygon
          16 = 6 equal-sided polygon
          17 = 7 equal-sided polygon
          18 = 8 equal-sided polygon
         101 = polyhedren
         102 = block
         103 = cylinder-solid
         104 = cylinder-hollow
         105 = partial cylinder
         106 = block (center - corner)
         107 = cylinder-solid (on circ - on circ)
         108 = cone
         113 = 3 equal-sided polyhedren
         114 = 4 equal-sided polyhedren
         115 = 5 equal-sided polyhedren
         116 = 6 equal-sided polyhedren
         117 = 7 equal-sided polyhedren
         118 = 8 equal-sided polyhedren
         201 = electric inductor
         202 = electric capacitor
         203 = electric resistor
         204 = electric circuit cr1
         205 = electric circuit cr2
         206 = electric circuit cr3
         207 = electric circuit cr4
         208 = electric mutual inductor
         209 = torsional spring
         210 = simple diode
         211 = zener  diode
         212 = linear spring
         213 = linear damper
         214 = torsional damper
         215 = EMT transducer
         216 = piezoelectric crystal
         217 = lumped mass

         For iop = PCK_DUP    ---  Allow duplicate picks ?
         Possible return values:
           0 = Not Allowed
           1 = Allowed
         
         For iop = PCK_ORDR  ---  Does order matter
         Possible return values:
           0 = Unordered
           1 = Ordered
         
         For iop = PCK_ENTMIN ---  Minimum entities required

         For iop = PCK_ENTMAX ---  Maximum allowed entities

         For iop = PCK_NLIST  ---  Number of entities picked

         For iop = PCK_NDUP   ---  Number of duplicate entities picked

         For iop = PCK_CUR_ENTNUM ---  Current selected entity number

         For iop = PCK_CUR_ENTTYP ---  Current selected entity type

         For iop = PCK_PNUMTYP ---  Current number of entity types picked.

         For iop = PCK_PTYP  ---  Current entity types picked.
         Returns a unique number which is the sum of all entity types 
         curently picked. Where the types are:
         PK_BIT_NODE - node mask
         PK_BIT_ELEM - element mask
         PK_BIT_KEYP - keypoint mask
         PK_BIT_LINE - line mask
         PK_BIT_AREA - area mask
         PK_BIT_VOLU - volume mask
         PK_BIT_TRAC - trace mask
         PK_BIT_CMP  - component mask
         PK_BIT_GRPT - graph point mask


     Output
     -----------------------------
  
       None

Return Value:

       Returns the current value of the requested item
----------------------------- End API Description --------------------*/

/*------------------------------ API Description -----------------------
cAnsPick_Entity


void cAnsPick_Entity(itype, ksel, krub, dup, korder,
                     nmn, numreq, (*externalCallBack)(void *))

       int itype
       int ksel
       int krub
       int dup
       int korder
       int nmn
       int numreq,
       void (*externalCallBack)(void *))


Header File: cAnsPick.h

Purpose:
     Provide information to the current locational picking operation 

Parameters:
     Input
     -----------------------------
       
       itype
         Expected values are:
           PK_BIT_NODE    1 - value indicates pick nodes
           PK_BIT_ELEM    2 - value indicates pick elements
           PK_BIT_KEYP    4 - value indicates pick keypoints
           PK_BIT_LINE    8 - value indicates pick lines
           PK_BIT_AREA   16 - value indicates pick areas
           PK_BIT_VOLU   32 - value indicates pick volumes
           PK_BIT_TRAC   64 - value indicates pick traces
           PK_BIT_CMP   128 - value indicates pick components
           PK_BIT_GRPT  256 - value indicates pick graph points
           a combination of these (sum) keys indicates a multi-entity mode.

       ksel - defines the set of entities from which to pick.
         Expected values are:
           1 - value indicates only selected entities can be picked.
          -1 - value indicates only unselected entities can be picked.
           0 - value indicates both selected and unselected entities
                can be picked.

       dup - defines the behavior for picking duplicates
         Expected values are:
           0 - Do not allow duplicates
           1 - Allow duplicates

       korder - defines the behavior for order dependence
         Possible return values:
           0 = Not order dependent
           1 = Order dependent

       krub
         Rubber band mode to use.
         For wp picking (key=0) valid modes are:
                 1 = lines
                 2 = rectangle (corner - opp/corner)
                 3 = circle (center - radius)
                 4 = annulus (center - r1 - r2)
                 5 = partial annulus
                 6 = rectangle (center - corner)
                 7 = circle (on circ - on circ)
                13 = 3 equal-sided polygon
                14 = 4 equal-sided polygon
                15 = 5 equal-sided polygon
                16 = 6 equal-sided polygon
                17 = 7 equal-sided polygon
                18 = 8 equal-sided polygon
               101 = polyhedren
               102 = block
               103 = cylinder-solid
               104 = cylinder-hollow
               105 = partial cylinder
               106 = block (center - corner)
               107 = cylinder-solid (on circ - on circ)
               108 = cone
               113 = 3 equal-sided polyhedren
               114 = 4 equal-sided polyhedren
               115 = 5 equal-sided polyhedren
               116 = 6 equal-sided polyhedren
               117 = 7 equal-sided polyhedren
               118 = 8 equal-sided polyhedren
               201 = electric inductor
               202 = electric capacitor
               203 = electric resistor
               204 = electric circuit cr1
               205 = electric circuit cr2
               206 = electric circuit cr3
               207 = electric circuit cr4
               208 = electric mutual inductor
               209 = torsional spring
               210 = simple diode
               211 = zener  diode
               212 = linear spring
               213 = linear damper
               214 = torsional damper
               215 = EMT transducer
               216 = piezoelectric crystal
               217 = lumped mass

       nmn
         Minimum number of entities needed

       numreq
         The upper limit on the number of entities that can be picked.

      
       (*externalCallBack)(void *)) 
         A point to a function to be notified upon each valid pick
         event that occurs. This function is passed a pointer to a 
         pickData structure as defined in cAnsPick.h. The ANSYS functions
         that call this function own the pickData structure. A copy of it
         should be made by the externalCallBack function upon invocation.

     Output
     -----------------------------
  
       None

Return Value:

       N/A
----------------------------- End API Description --------------------*/

/*------------------------------ API Description -----------------------
cAnsPick_EntityDump

  void cAnsPick_EntityDump( *n, **list_ent, **list_typ)
       int *n;
       int **list_ent;
       int **list_typ;

Header File: cAnsPick.h

Purpose:
     Dumps the current entity data set and undraws the picked
     entity highlighting.

Parameters:
     Input
     -----------------------------

       *n
         Pointer to an integer that will recieve the number of
         entities picked.

       **list_ent
         Pointer to an int pointer. The pointer to the entity number 
         data array is returned to the calling function.

       **list_typ
         Pointer to an int pointer. The pointer to the entity type 
         data array is returned to the calling function.

       The list_ent and list_typ arrays have a one to one correspondence.

     Output
     -----------------------------
 
       *n
         The number of entities picked is assigned to the integer
         at this address.

       **list_ent
         Pointer to an int pointer. The pointer to the entity number 
         data array is returned to the calling function.

       **list_typ
         Pointer to an int pointer. The pointer to the entity type 
         data array is returned to the calling function.

Return Value:

       N/A
----------------------------- End API Description --------------------*/

/*------------------------------ API Description -----------------------
cAnsPick_EntityDone

  void cAnsPick_EntityDone()

Header File: cAnsPick.h

Purpose:
     Terminates the current entity picking link.

Parameters:
     Input
     -----------------------------

     None

     Output
     -----------------------------
 
     None

Return Value:

       N/A
----------------------------- End API Description --------------------*/

/*------------------------------ API Description -----------------------
cAnsPick_EntityPickAll

  void cAnsPick_EntityPickAll()

Header File: cAnsPick.h

Purpose:
     This function forces all pickable entities into the picked state.

Parameters:
     Input
     -----------------------------

     None

     Output
     -----------------------------
 
     None

Return Value:

       N/A
----------------------------- End API Description --------------------*/

/*------------------------------ API Description -----------------------
cAnsPick_EntityRange

  void cAnsPick_EntityRange(itype, key, n, *idata)
        int itype     
        int key       
        int n         
        int *idata    

Header File: cAnsPick.h

Purpose:
     This function forces all pickable entities indicated into the picked state.

Parameters:
     Input
     -----------------------------

       itype --- type of entity to pick/unpick.
         Expected values are:
           PK_BIT_NODE    1 - value indicates pick nodes
           PK_BIT_ELEM    2 - value indicates pick elements
           PK_BIT_KEYP    4 - value indicates pick keypoints
           PK_BIT_LINE    8 - value indicates pick lines
           PK_BIT_AREA   16 - value indicates pick areas
           PK_BIT_VOLU   32 - value indicates pick volumes
           PK_BIT_TRAC   64 - value indicates pick traces
           PK_BIT_CMP   128 - value indicates pick components
           PK_BIT_GRPT  256 - value indicates pick graph points

       key   --- list or min.max,inc 
           PK_KB_LIST - set is represented as a list of n items in idata.
           PK_KB_RANG - set is represented as a range (min.max,inc) in idata.

       n     --- number of entities in list -- ignored for key = PK_KB_RANG

       idata --- pointer to an array of integers defining the set of 
                 entities to pick/unpick.
           For key = PK_KB_LIST idata contains a set of n entity numbers
           For key = PK_KB_RANG idata contains the min, max ,and icrement
                     of a range specification.
                 

     Output
     -----------------------------
 
     None

Return Value:

       N/A
----------------------------- End API Description --------------------*/

/*------------------------------ API Description -----------------------
cAnsPick_EntityRestart

  void cAnsPick_EntityRestart(*n)
        int *n         

Header File: cAnsPick.h

Purpose:
     This function reinitializes the current picking session against the 
     current set of pickable entities and restores the previously picked set
     of entities. Generally used in the case of an apply.


Parameters:
     Input
     -----------------------------

       *n     --- pointer to an int that will return the number of entities
                  picked.

     Output
     -----------------------------
 
       n      --- Returns the number of entities picked.

Return Value:

       N/A
----------------------------- End API Description --------------------*/

/*------------------------------ API Description -----------------------
cAnsPick_EntityReset

  void cAnsPick_EntityReset()
        int *n

Header File: cAnsPick.h

Purpose:
     This function reinitializes the current picking session to its 
     initial state.
   

Parameters:
     Input
     -----------------------------

       None
                  picked.

     Output
     -----------------------------

       None

Return Value:

       N/A
----------------------------- End API Description --------------------*/

/*------------------------------ API Description -----------------------
cAnsPick_EntityNextDup

  void cAnsPick_EntityNextDup()
        int *n

Header File: cAnsPick.h

Purpose:
     This function changes the currently selected entity to the next
     one when a series of entities share a common hot spot (duplicates).
     The behavior is circular.

Parameters:
     Input
     -----------------------------

       None
                  picked.

     Output
     -----------------------------

       None

Return Value:

       N/A
----------------------------- End API Description --------------------*/

/*------------------------------ API Description -----------------------
cAnsPick_EntityPrevDup

  void cAnsPick_EntityPrevDup()
        int *n

Header File: cAnsPick.h

Purpose:
     This function changes the currently selected entity to the previous
     one when a series of entities share a common hot spot (duplicates).
     The behavior is circular.

Parameters:
     Input
     -----------------------------

       None
                  picked.

     Output
     -----------------------------

       None

Return Value:

       N/A
----------------------------- End API Description --------------------*/

/*------------------------------ API Description -----------------------
cAnsPick_EntityDumpDup

  void cAnsPick_EntityDumpDup( *n, **list_ent, **list_typ)
       int *n;
       int **list_ent;
       int **list_typ;

Header File: cAnsPick.h

Purpose:
     Dumps the current set of entity data for a set of duplicates.

Parameters:
     Input
     -----------------------------

       *n
         Pointer to an integer that will recieve the number of
         entities picked.

       **list_ent
         Pointer to an int pointer. The pointer to the entity number 
         data array is returned to the calling function.

       **list_typ
         Pointer to an int pointer. The pointer to the entity type 
         data array is returned to the calling function.

       The list_ent and list_typ arrays have a one to one correspondence.

     Output
     -----------------------------
 
       *n
         The number of entities picked is assigned to the integer
         at this address.

       **list_ent
         Pointer to an int pointer. The pointer to the entity number 
         data array is returned to the calling function.

       **list_typ
         Pointer to an int pointer. The pointer to the entity type 
         data array is returned to the calling function.

Return Value:

       N/A
----------------------------- End API Description --------------------*/

/*---------------------------- End Of Module ---------------------------*/
