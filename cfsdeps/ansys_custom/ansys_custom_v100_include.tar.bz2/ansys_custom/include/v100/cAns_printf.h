/* sid 50.1 copy of cAns_printf.h last changed by upd111 on 2005/06/04 13:18:34 */
/* cAns_printf.h */

#if !defined(__CANSPRINTF_H__)
#define __CANSPRINTF_H__ 1

/* for the va_list declaration */
#include <stdarg.h>

#ifdef MAINWIN
#define INT int
#define CHAR char
#endif

#ifdef __cplusplus
extern "C" {
#endif

INT cAns_printf(CHAR *format, ...);
INT cAns_printff(CHAR *format, ...);
INT cAns_printffc(INT unit, INT nopr, CHAR *format, ...);

#ifdef __cplusplus
}
#endif

#ifdef MAINWIN
#undef INT
#undef CHAR
#endif

#endif
