/* sid 50.1 copy of fem_swPriv.h last changed by upd111 on 2004/11/04 18:33:34 */

/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 1999 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  fem_swPriv.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  fem_swPriv.h
 *  header file Volume sweeper module
 *
 */

#ifndef FEM_SWPRIV_INCLUDE
#define FEM_SWPRIV_INCLUDE

/*------------------ Datatypes ---------------------------------------*/

/*----------------- Globally accessible variables ---------------------------*/

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
#include "FEM_hashtable.h"

extern HASHTABLE<INT*> *g_ribsindexht;
extern INT *g_nodeids;
#endif

extern NODE_OBJ **ga_ribnodes;
extern INT g_numdivs;
extern INT g_num_ribs;
extern INT g_num_nodes_per_rib;
extern FEM_BOOLEAN g_sweepmids;

#ifdef __cplusplus
}
#endif

/*----------------- Globally accessible macros ------------------------------*/

/*==============================================================================
 * === Macro: fem_swNodeOnRib_C
 * === Author: mls
 * === Description:  Return the NODE_OBJ given a particular rib and the level
 * ===               on that rib.
 * === Return: NODE_OBJ to the node on the rib.
 *============================================================================*/
#define fem_swNodeOnRib_C( rib_id, level ) ga_ribnodes[rib_id][level]
#define fem_swTopNodeOnRib_C( rib_id ) \
   ga_ribnodes[rib_id][g_num_nodes_per_rib-1]

/*==============================================================================
 * === Macro: fem_swSetNodeOnRib_C
 * === Author: mls
 * === Description:  Set a node on a rib at a given level.
 * === Return: void.
 *============================================================================*/
#define fem_swSetNodeOnRib_C( rib_id, level, thenode, status )\
     if ( rib_id >= g_num_ribs ||\
          rib_id < 0 ||\
          level >= g_num_nodes_per_rib ||\
          level < 0 ) {\
        FEMe_Error(GENERIC,GEN_UNKNOWN_ERROR,FEM_ERROR,NULL,__FILE__,__LINE__);\
        status = EXIT_FAILURE;\
     }\
     else {\
        ga_ribnodes[rib_id][level] = thenode;\
        status = EXIT_SUCCESS;\
     }

#define fem_swSetTopNodeOnRib_C( rib_id, thenode, status )\
     if ( rib_id >= g_num_ribs ||\
          rib_id < 0 ) {\
        FEMe_Error(GENERIC,GEN_UNKNOWN_ERROR,FEM_ERROR,NULL,__FILE__,__LINE__);\
        status = EXIT_FAILURE;\
     }\
     else {\
        ga_ribnodes[rib_id][g_num_nodes_per_rib-1] = thenode;\
        status = EXIT_SUCCESS;\
     }

/*==============================================================================
 * === Macro: fem_swRibsAllocated_C
 * === Author: mls
 * === Description:  determine if space for nodes on the ribs have been
 * ===               allocated yet.
 * === Return: TRUE or FALSE if it has been allocated or not.
 *============================================================================*/
#define fem_swRibsAllocated_C() ((ga_ribnodes == NULL)?FALSE:TRUE)

#define fem_swMidnodeToEdgeRibId_C( edge_id )\
   ((-1 * abs( edge_id ))-1);

/* === RIBDATA_TYP is used to store information about generating internal nodes
   === on internal ribs inside of the sweepable volume.  */
typedef struct {
   INT rib1;             /* === the indexes in ga_ribnodes of the ribs that */
   INT rib2;             /* === define the triangle that this rib lies in */
   INT rib3;
   DOUBLE source_A;      /* === the bary coords of the rib at the source */
   DOUBLE source_B;      /* === area in the triangle defined by the 3 ribs */
   DOUBLE source_C;
   DOUBLE target_A;      /* === the bary coords of the rib at the target */
   DOUBLE target_B;      /* === area in the triangle defined by the 3 ribs */
   DOUBLE target_C;
   DOUBLE off_distsource; /* === offset distance at the source area */
   DOUBLE off_disttarget; /* === offset distance at the target area */
} RIBDATA_TYP;

void FEM_swInitRibData( RIBDATA_TYP *psRibData );

#endif

