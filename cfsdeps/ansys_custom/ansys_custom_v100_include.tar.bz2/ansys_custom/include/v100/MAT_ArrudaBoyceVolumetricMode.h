/* sid 50.1 copy of MAT_ArrudaBoyceVolumetricMode.h last changed by upd111 on 2005/06/04 13:20:54 */
////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         Copyright (C) 2001 ANSYS Inc.  All Rights Reserved             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MAT_ArrudaBoyceVolumetricMode.h $
// $Revision$ 7.0
// $Date$ March 28 2002
// $Author$ rjayasee/jlo
//
// Decription :
//
//	This class captures the Material Model abstraction for the Ogden Volumetric
//  mode. This is also used by mooney(order 1) and polymonial (same as ogden)
//////////////////////////////////////////////////////////////////////////////

#if !defined( MAT_ARRUDABOYCEVOLUMETRICMODE_H )
#define MAT_ARRUDABOYCEVOLUMETRICMODE_H


#include "MAT_HyperElasticLinearFit.h"

// #include "MAT_ConstitutiveFunction.h"
class MAT_ExperimentalDataSet ;

class MAT_ArrudaBoyceVolumetricMode : public MAT_HyperElasticLinearFit
{

public:

    MAT_ArrudaBoyceVolumetricMode();
    //Constructor

     virtual INT GetNumberOfCoeffs() ;
    //R-bool
    //I-iOrder
    //I-Number of Coeffs
    //F-Set the Number of Coeffs
    //F-This is calculated from the polynomial order

    virtual bool GenerateMaterialParameters() ;
    //R-bool
    //F-Function that Generates the Material Parameters given
    //F-some experimental data
    
    virtual bool SolveLeastSquaresMatrix() ;
    //R-bool
    //R-false if det or zero. Or if the only av data is shear data.
    //F-Inverts the Matrix to solve for the parameters

    virtual bool CalculateFittedExperimentalDataPoint
                    ( double* pCoeffs,
                      INT iNumCoeffs,
                      ANS_String oExpName,
                      vector<double>& oPoint ) ;
    //R bool
    //R-false is such a point or an experiment does not exist
    //I pCoeffs
    //I-Coefficient Values
    //I iNumCoeffs
    //I-Number of Coefficients
    //I oExpName
    //I-Experiment Name
    //I oPoint
    //I Calulated Value of Experiment Point
    //- Returns the Fitted Experimental Data Point

    virtual bool FillLHSAndRHSMatrix( ANS_String const& pExpName, ANS_Point const* pPoint,
                                      double** pLHSMatrix, double** pRHSMatrix ) ;
    //R bool
    //I pExpName
    //I-Experiment Name
    //I pPoint
    //I Data Point
    //O pLHSMatrix
    //O LHS Matrix
    //O pRHS Matrix
    //O RHS Matrix
    //- Fills up LHS and RHS Matrix for a given poin
    
    virtual bool FunctionValue( double* dVariables,
                        INT iNumVariables,
                        double dLambdaN, 
                        double& dStressN ) ;
    //R bool
    //I dVariables
    //I-Input Coeffecients
    //I iNumVariables
    //I-Number of Coeffecients = 2
    //I dLambdaN
    //I-Stretch
    //- Calculate Stress given stretch and coeffs

    virtual void Print() ;
    //F-Print

  	virtual ~MAT_ArrudaBoyceVolumetricMode();
    //F-Destructor

private:

    INT m_iOrder ;
    //Order of the Polynomial = Number of Coeffients = 1

    double FunctionAlpha( INT iK, double dLambda) ;
    //R-Value of Alpha in derived expression
    //I iK
    //I-Ith Term
    //I dLambda
    //I-Stretch = Strain + 1
    //F-Calculates Alpha as in the derivation in doc for least squares method
};

#endif // !defined(MAT_ARRUDABOYCEVOLUMETRICMODE_H)
