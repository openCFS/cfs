/* sid 50.1 copy of FEMa_ProcessErr.h last changed by upd111 on 2005/06/04 13:16:59 */

/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 2000 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEMa_ProcessErr.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEMa_ProcessErr.h
 *  header file for FEMa_ProcessErr.c
 *
 *  Contains routines for processing of errors in the C meshing database.  This
 *  is not part of the C meshing database but is an ansys specific
 *  implementation of error handling which can be used for the C meshing
 *  database.
 *
 *
 *  INSTRUCTIONS for use:
 *    to use this module follow the folling steps:
 *      1.  Initialize the module for error handling by calling
 *          FEMa_erInit().  The call to FEMa_erInit takes a status as an
 *          argument.  This status initialized the module to either display
 *          messsages immediately, save the messages in a buffer, or ignore
 *          any messages recieved.
 *      2.  Call FEMa_erProcErr() or FEMa_erProcString() to send a message to the
 *          module.  The error is either displayed immediately, saved in a
 *          buffer or ignored depending upon the status argument sent to
 *          FEMa_erInit().
 *      3.  If messages are saved, they can be displayed all at once by
 *          dumping the error buffer.  This is done by calling
 *          FEMa_erDumpBuffer().
 *      4.  Once you are done with this module, FEMa_erDelete must be called
 *          to free all allocated memory used by the module.  Once FEMa_erDelete
 *          is called, the buffer is deleted even if the error messages were
 *          never displayed.  After calling FEMa_erDelete, no more calls to 
 *          FEMa_erProcString or FEMa_erProcErr should be made until FEMa_erInit
 *          is called again.
 *
 *  Messages received by FEMa_erProcErr() are displayed with a call to
 *  fem_erhandler.  messages received by FEMa_erProcString() are displayed with
 *  a call to cwAnserr.
 *
 *
 */
#if 0 
 *   EXAMPLE:
 ****************************************************************************/
 *
 *    INT status = 1;
 *    FEMa_erInit( status );   /* initialize the module to save error
 *                               messages in a buffer */
 *
 *    FEMa_erProcError( .. );  /* Send errors to the module to be processed */
 *    FEMa_erProcError( .. );  /* none are printed, but saved to be printed */
 *    FEMa_erProcString( .. ); /* later when buffer is dumped. */
 *    FEMa_erProcString( .. );
 *    FEMa_erProcString( .. );
 *    FEMa_erProcError( .. );
 *
 *    FEMa_erDumpBuffer();     /* dump the buffer.  All error messages
 *                               previously sent are displayed. */
 *
 *    FEMa_erDelete();         /* Free all memory used in the module to save
 *                               error messages in the buffer. */
 *
 *
 ****************************************************************************
#endif

#ifndef FEM_PROCESSERR_INCLUDE
#define FEM_PROCESSERR_INCLUDE

#define IMMEDIATE_DISPLAY 0  /* === Error will be printed as soon as it is
                                === received */
#define SAVE_ERRORS       1  /* === Error will be saved in buffer until
                                === buffer is dumped */
#define IGNORE_ERRORS     2  /* === Errors will be ignored */

                             /* ============================================ */
                             /* === FEMa_erInit: Initialize this module and  */
                             /* === Set the current status of this module    */
                             /* === (IMMEDIATE_DISPLAY, SAVE_ERRORS, or      */
                             /* === IGNORE_ERRORS)                           */
                             /* === Return: void                             */
                             /* ============================================ */
void FEMa_erInit (
   INT status  );            /* (IN) how to process errors sent to the       */
                             /*      module.  Possible values include:       */
                             /*       0:  Messages displayed as they are     */
                             /*           recieved.                          */
                             /*       1:  Messages are saved in a buffer to  */
                             /*           be displayed with a call to        */
                             /*           FEMa_erDumpBuffer().               */
                             /*       2:  Messages are ignored and not saved */
                             /*           or displayed.                      */

                             /* ============================================ */
                             /* === FEMa_erGetError: Get the id of the worst */
                             /* === error sent to this module either by      */
                             /* === FEMa_erSetError or FEMa_erProcErr since  */
                             /* === it was last initialized with FEMa_erInit.*/
void FEMa_erGetError (
   INT *p_subprocessid,      /* (OUT) The subprocess that the error came from*/
   INT *p_errorid,           /* (OUT) The id of the error                    */
   INT *p_severity  );       /* (OUT) The severity of the error              */

                             /* ============================================ */
                             /* === FEMa_erSetError: Save the id and severity*/
                             /* === of an error if it is the worst error     */
                             /* === encountered since this module was        */
                             /* === initialized with FEMa_erInit.  The error */
                             /* === sent in is only saved if it has a        */
                             /* === severity worse than or equal to the      */
                             /* === currently saved error.  If the error     */
                             /* === sent in has the same severity as the     */
                             /* === error currently saved, the new error is  */
                             /* === saved.                                   */
void FEMa_erSetError (
   INT subprocessid,         /* (IN)  The subprocess that the error came from*/
   INT errorid,              /* (IN)  The id of the error                    */
   INT severity  );          /* (IN)  The severity of the error              */

                             /* ============================================ */
                             /* === FEMa_erProcErr: Handle an error message  */
                             /* === based on the current status of this      */
                             /* === module.                                  */
                             /* === Return: INT EXIT_FAILURE or EXIT_SUCCESS */
                             /* ============================================ */
INT FEMa_erProcErr (
   INT subprocessid,         /* (IN) which subprocess the error came from    */
   INT errorid,              /* (IN) which error in the subprocess           */
   INT severity,             /* (IN) how bad the error is.                   */
   DOUBLE *a_params,         /* (IN) params to the error message if any      */
   CHAR *string  );          /* (IN) a single character string to be printed */
                             /*      in the message.                         */


                             /* ============================================ */
                             /* === FEMa_erProcString: Handle an error       */
                             /* === message passed in as a string, based on  */
                             /* === the current status of this module.       */
                             /* === Return: INT EXIT_FAILURE or EXIT_SUCCESS */
                             /* ============================================ */
INT FEMa_erProcString (
   char string[256],         /* (IN) string to process                       */
   INT severity  );          /* (IN) how bad the error is.                   */

                             /* ============================================ */
                             /* === FEMa_erDumpBuffer: Dump all the contents */
                             /* === of the buffer of error messages.  If the */
                             /* === buffer is empty, nothing happens.        */
                             /* === Return: void                             */
                             /* ============================================ */
void FEMa_erDumpBuffer ( void  );

                             /* ============================================ */
                             /* === FEMa_erDelete:  Free all resources,      */
                             /* === memory, etc. used in this modele.        */
                             /* === INT EXIT_FAILURE or EXIT_SUCCESS         */
                             /* ============================================ */
void FEMa_erDelete ( void  );

#endif
