/* sid 50.1 copy of FEM_morph.h last changed by upd111 on 2005/06/04 13:18:54 */
/*  FEM_morph.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */

/* *** ansys(r) copyright(c) 2000
 * *** ansys, inc.
 */

/*
 *  FEM_morph.h
 *  Heaer file for FEM_morph.c (Morphing and Remeshing)
 *
 */

#ifndef FEM_MORPH_H
#define FEM_MORPH_H

/*------------------------ Data Structures -------------------------------------*/


typedef struct DISP_NODE_TYP *DISP_NODE_PTYP;
typedef struct DISP_NODE_TYP{
   DOUBLE dx, dy, dz;
   DOUBLE ix, iy, iz;
   NODE_OBJ obj_node;
} DISP_NODE_TYP;


/*------------------------ Prototypes ------------------------------------------*/

                         /*=====================================================*/
                         /* === morphing loop for areas					        */
                         /*=====================================================*/
INT FEM_moMorph2D(
   INT *a_areas,         /* list of areas to perform morphing (if detached, then
                            this is the array of elements) */
   INT num_areas,        /* number of areas (or numelems if detached) */
   INT *a_snodes,        /* list of structural nodes */
   INT num_snodes,       /* number of structural nodes */
   DOUBLE *a_disp,       /* displacement of structural nodes */
   INT *a_ns_nodes,      /* list of non-structural nodes on boundary
                            that can move */
   INT num_nsnodes,      /* number of non-structural nodes */
   INT midnodes,         /* do midnodes exist on the elements */
   INT remesh,			 /* remesh flag */
   INT rmshky,           /* remesh flag option (0=1st try morph then remesh if morph
                            fails. 1=Remesh only. 2=Morph only) */
   INT mshkey,           /* (IN) 0 = Use free Mesher Always.             */
                         /*      1 = Use Map Mesher Always.              */
                         /*      2 = Use Map Mesher if possible, and if  */
                         /*          not, use the free mesher.           */
   DOUBLE lratio,        /* for rmshky=0: if any specified displacement at a
                            node is greater than lratio*min length of any edge
                            attached, then goto remesh without attempting morph */
   DOUBLE minmetric,     /* for rmshky=0: if during morphing the quality of any
                            element drops below minmetric then goto remesh */
   INT doShapeChecking,  /* shape checking flag */
   INT debug,            /* debug flag */
   INT detached,         /* model is detached from solid (elements only)
                            if TRUE then send in array of element ids in a_areas */
   INT num_lines,        /* number of lines (length of a_lines) */
   INT *a_lines,		 /* list of lines adjacent areas */
   INT line_smoothing,   /* flag - smooth nodes on lines */
   INT ndisp,            /* number of displacement iterations */
   DISP_NODE_TYP *a_dnodes, /* displacement information at nodes */
   INT check_load,       /* flag for load check */
   INT *num_isnodes,     /* (OUT) number of inernal structural nodes */
   INT *p_abort );       /* user abort flag */

 
						 /*=====================================================*/
                         /* ===  Perform morphing and remeshing on 3D elements  */
                         /*=====================================================*/
INT  FEM_moMorph3D( 
   INT *a_vols,          /* list of volumes to perform morphing (if detached, then
                            this is the array of elements) */
   INT num_vols,         /* number of volumes (or numelems if detached) */
   INT *a_snodes,        /* list of structural nodes */
   DISP_NODE_TYP *a_dnodes, /* displacement information at nodes */
   INT nsnodes,          /* actual number of non-structural nodes */
   DOUBLE *a_disp,       /* displacement of structural nodes */
   INT *a_ns_nodes,      /* list of non-structural nodes on boundary 
                            that can move */
   INT num_nsnodes,      /* number of non-structural nodes */
   INT midnodes,         /* do midnodes exist on the elements */
   INT *a_kps,           /* array of keypoints */
   INT num_kps,          /* number of kps */
   INT *a_lines,         /* list of lines adjacent areas */
   INT num_lines,        /* number of lines (length of a_lines) */
   INT *a_areas,          /* array of areas */
   INT num_areas,        /* number of areas */
   INT line_smoothing,           /* smooth lines */
   INT rmshky,           /* remesh flag option (0=1st try morph then remesh if morph
                            fails. 1=Remesh only. 2=Morph only) */
   INT remesh,           /* number of areas remeshed */
   DOUBLE lratio,        /* for rmshky=0: if any specified displacement at a
                            node is greater than lratio*min length of any edge
                            attached, then goto remesh without attempting morph */
   INT ndisp,            /* number of displacement iterations */
   INT doShapeChecking,  /* shape checking flag */
   DOUBLE minmetric,     /* for rmshky=0: if during morphing the quality of any
                            element drops below minmetric then goto remesh */
   INT check_load,       /* flag for load check */
   INT debug,            /* debug flag */
   INT detached,         /* model is detached from solid (elements only)
                            if TRUE then send in array of element ids in a_vols */
   INT *noTet,           /* there are no any tet elements */
   INT *p_abort );       /* return if user abort */
#endif

