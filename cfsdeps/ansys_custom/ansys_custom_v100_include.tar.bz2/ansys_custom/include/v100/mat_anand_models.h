/* sid 50.1 copy of mat_anand_models.h last changed by upd111 on 2005/06/04 13:21:50 */
/*CFILE mat_anand_models.h        mechanics      [ANSI_C]                   azs
 * ------------------------------------------------------------------------
 * ------- Notice - This file contains ANSYS Confidential information 
 * ------------------------------------------------------------------------
 */

/*------------------------------- Description ---------------------------- */
/*
 * Author:        azs 
 * Title:         mat_anand_models.h
 * Desc:          Header file for C routines for Anand rate sensitive
 *                Plastic material models for 18x elements.
 *        --- primary function ---
 *                Anand rate-temperature sensitive plasticity
 *                material models for 18x elements. Integration of
 *                plastic constitutive equations, form the material
 *                Jacobian for these materials and provide plastic 
 *                work etc.
 *
 *        --- Methodology ---
 *                A return mapping algorithm for Anand Visco elasto-plasticity
 *                developed based on Computational Inelasticity
 *                by J.C. Simo and T.J.R. Hughes.  
 *
 * History:       azs: initial creation 1-22-03
 *
 * ----------------------------------------------------------------------- */

#include "mat_models_header.h"


/* -------------------------- Definition of types ------------------------ */
/* Material updating parameters. */

#define  MAT_ANAND_MODEL_TYPE      7
#define  MAT_NUM_ANAND_DATA        9
#define  MAT_NUM_ANAND_TEMP_DATA   10


/* Basic Types. */
typedef double          mat_anand_model_prop[MAT_NUM_ANAND_DATA] ;
typedef double          mat_anand_model_temp_prop[MAT_NUM_ANAND_TEMP_DATA] ;

/* -------------------------- Definition of Methods ---------------------- */
/* ----------------------------------------------------------------------- */

/* -------------------------- mat_anand_getprop -------------------------- */
/* 
 * primary function: Get the material properties from the buffer. 
 * secondary function: none.
 *
 *
 * -------------------------- mat_anand_getprop -------------------------- */
mat_model_return_signal  mat_anand_getprop(
					   mat_model_control_operator      start_position,
					   mat_anand_model_prop            anand_prop 
					   ) ;

/* ----------------------------------------------------------------------- */
/* 
 * primary function: Get the Anand properties from the buffer. 
 * secondary function: none.
 *
 *
 * ------------------------- mat_get_anand_prop -------------------------- */
mat_model_return_signal  mat_get_anand_prop( 
					    mat_model_control_operator   start_position,
					    mat_object_measure           initial_mechanical_resistance,
					    mat_object_measure           active_O_gas_const,  
					    mat_object_measure           pre_exp_factor , 
					    mat_object_measure           eXi ,
					    mat_object_measure           sensitivity_power,
					    mat_object_measure           initial_hard_soft,
					    mat_object_measure           hat_mechanical_resistance,
					    mat_object_measure           saturation_power,
					    mat_object_measure           hard_sensitivity
					    ) ;

/* --------------------------------mat_model_compress-----------------------*/
mat_model_return_signal  mat_model_compress( 
					    mat_model_tensor               tensor_representation ,
					    mat_model_vector               vector_representation ,
					    mat_model_local_measure        constant_factor ,
					    mat_model_local_measure        row_dim_vec ,
					    mat_model_local_measure        row_dim_tensor 
					    ) ;

/* --------------------------------mat_model_expand--------------------------*/
mat_model_return_signal  mat_model_expand( 
					  mat_model_vector               vector_representation ,
					  mat_model_tensor               tensor_representation ,
					  mat_model_local_measure        constant_factor ,
					  mat_model_local_measure        row_dim_vec ,
					  mat_model_local_measure        row_dim_tensor 
					  ) ;

/* ------------------------------- mat_anand_strain_energy--------------------*/ 
mat_model_return_signal  mat_anand_strain_energy( 
						 mat_elastic_strain_energy      sedEl, 
						 mat_plastic_strain_energy      sedPl,
						 mat_model_3Dstress_tensor      updated_stress,
						 mat_elastic_strain             elastic_strain,
						 mat_model_work_tensor          matmisc,
						 mat_eqvl_plastic_strain        eqpl,  
						 mat_model_local_measure        yield_stress_t,
						 mat_model_comp_size            nTens
						 ) ;

/*------------------------------mat_anand_3djac-------------------------------*/
mat_model_return_signal  mat_anand_3djac(
					 mat_model_comp_size            direct_comp , 
					 mat_model_comp_size            shear_comp , 
					 mat_model_comp_size            total_comp , 
					 mat_model_stress_predictor     stress_predictor , 
					 mat_model_measure              hard_modulus , 
					 mat_model_measure              delta_eqv_plastic_strain , 
					 mat_model_measure              shear_mod2, 
					 mat_model_3Dstress_tensor      flow_normal , 
					 mat_model_work_tensor          holder ,
					 mat_model_jacobian             elasticity_tensor ,
					 mat_model_jacobian             mat_tangent
					 )  ;   

/*------------------------------mat_anand_3d---------------------------------*/
mat_model_return_signal CALLTYP mat_anand_3d_( 
					      mat_model_debug_key            debugflag , 
					      mat_model_comp_size            direct_comp , 
					      mat_model_comp_size            shear_comp , 
					      mat_model_comp_size            total_comp , 
					      elem_object_index              elem_id , 
					      mat_object_index               mat_id , 
					      mat_model_comp_size            kDomIntPt , 
					      mat_model_comp_size            kLayer , 
					      mat_model_comp_size            kSectPt , 
					      mat_model_control_operator     tb_position ,
					      mat_model_control_key          Jac_form , 
					      mat_model_plasticity_ptr       plasticity_option ,  
					      mat_model_measure              temp , 
					      mat_model_measure              delta_temp , 
					      mat_model_measure              ref_temp ,
					      mat_model_prop                 mat_prop ,
					      mat_anand_model_prop           rate_prop ,
					      mat_model_control_key          pass_through , 
					      mat_model_measure              time_incr ,
					      mat_model_measure              total_time ,
					      mat_elastic_strain             elastic_strain_inc , 
					      mat_elastic_strain             elastic_strain , 
					      mat_plastic_strain             plastic_strain , 
					      mat_eqvl_plastic_strain        eqvl_plastic_strain ,
					      mat_model_work_tensor          mat_misc , 
					      mat_model_3Dstress_tensor      holder1 , 
					      mat_model_work_tensor          holder2 , 
					      mat_model_local_tensor         holder3 , 
					      mat_model_work_tensor          holder21 ,
					      mat_model_3Dstress_tensor      stress_predictor , 
					      mat_model_3Dstress_tensor      updated_stress , 
					      mat_model_3Dstress_tensor      updated_strain , 
					      mat_model_jacobian             elasticity_tensor ,
					      mat_model_jacobian             mat_tangent , 
					      mat_elastic_strain_energy      elastic_energy , 
					      mat_plastic_strain_energy      plastic_energy ,
					      mat_plastic_strain_history     plastic_strain_history ,
					      mat_deformation_grad           mat_updated_plastic_def_grad ,
					      mat_model_measure              updated_mechanical_resisitance,
					      mat_deformation_grad           mat_plastic_def_grad ,
					      mat_model_measure              mechanical_resisitance,
					      mat_deformation_grad_inc       mat_def_grad_inc ,
					      mat_deformation_grad           mat_def_grad
					      ) ;

/*-------------------- End of definition of methods --------------------- */




