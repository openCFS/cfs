/* sid 50.1 copy of fem_swMidNode.h last changed by upd111 on 2004/11/04 18:33:33 */

/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 1999 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  fem_swMidNode.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  fem_swMidNode.h
 *  header file for fem_swMidNode.c
 *
 */
#ifndef FEM_SWMIDNODE_INCLUDE
#define FEM_SWMIDNODE_INCLUDE

/*----------------- Globally accessible constants  --------------------------*/

/*----------------- Globally accessible data types --------------------------*/

/*----------------- Globally accessible function prototypes -----------------*/

#ifdef __cplusplus
extern "C" {
#endif

                      /* =================================================== */
                      /* === FEM_swAddMidNodes: Create midnodes on all new   */
                      /* === edges that need them.                           */
                      /* === Return: EXIT_SUCCESS or EXIT_FAILURE            */
                      /* =================================================== */
INT FEM_swAddMidNodes (
   FEM_BOOLEAN project,      /* (IN)  TRUE if midnode need to be projected to */
                             /*       the underlying geometry.                */
   FACE_OBJ obj_oldface,     /* (IN)  first face in the face list not created */
                             /*       by sweeping.                            */
   FEM_BOOLEAN do_progress  );/* (IN)  TRUE if doing status window            */
                             /* ============================================= */

#ifdef __cplusplus
}
#endif

#endif

