/* sid 50.1 copy of MAT_ArrudaBoyce.h last changed by upd111 on 2005/06/04 13:20:51 */
////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         Copyright (C) 2001 ANSYS Inc.  All Rights Reserved             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MAT_ArrudaBoyce.h $
// $Revision$ 7.0
// $Date$ May 8 2002
// $Author$ rjayasee
//
// Decription :
//
//	This class is the arruda boyce abstraction for material curve fitting
//////////////////////////////////////////////////////////////////////////////

#if !defined( MAT_ARRUDABOYCE_H )
#define MAT_ARRUDABOYCE_H


#include "MAT_HyperElasticNonLinearFit.h"
#include "MAT_ArrudaBoyceVolumetricMode.h"

class MAT_ExperimentalDataSet ;

class MAT_ArrudaBoyce : public MAT_HyperElasticNonLinearFit
{

public:

    MAT_ArrudaBoyce();
    //Constructor

    virtual bool GenerateMaterialParametersWithLMMethod() ;
    //R-bool
    //F-Function that Generates the Material Parameters given
    //F-some experimental data with Levenberg Marquardt's Method

    virtual bool CalculateFittedExperimentalDataPoint
                    ( double* pCoeffs,
                      INT iNumCoeffs,
                      ANS_String oExpName,
                      vector<double>& oPoint ) ;
    //R bool
    //R oExpName
    //R-Experiment Name
    //O-Input/Output point data

    virtual bool DeleteCoefficients( MAT_FieldVariableCollection const& oField  ) ;
    //R bool
    //I oField
    //I-Field Variable
    //- Removes/Deletes the Variable Independent coefficients at a particular temp/...

    virtual INT GetNumberOfCoeffs() ;
    //R-bool
    //I-iOrder
    //I-Number of Coeffs
    //F-Set the Number of Coeffs
    //F-This is calculated from the polynomial order
    
    virtual void Print() ;
    //F-Print

  	virtual ~MAT_ArrudaBoyce();
    //F-Destructor


protected:
    
    MAT_ArrudaBoyceVolumetricMode m_oVolumetricMode ;
    // Volumetric Mode for arruda boyce

    virtual bool FirstDerivativeOfUnsquaredError( double* dVariables,
                                          INT iNumVariables,
                                          double dLambdaN, 
                                          double dStressN,
                                          MAT_ExperimentType iExpType,
                                          INT iVariableIndex,
                                          double& dResult ) ;
    //R bool
    //R-false if unknown exp type or null dVariables
    //I dAlphaj
    //I-Coefficent Alpha in ArrudaBoyce Expr
    //I dLambdan
    //I-Value of Stretch
    //I iExpType
    //I 1 for unia, 2 for biax, 3 for tension
    //-Calculates the value of the first derivative of the ArrudaBoyce Potential
    //-for a stress/stretch point


    virtual bool FunctionValue( double* dVariables,
                        INT iNumVariables,
                        double dLambdaN, 
                        MAT_ExperimentType iExpType,
                        double& dStressN ) ;
    //R bool
    //I dVariables
    //I-Input Coeffecients
    //I iNumVariables
    //I-Number of Coeffecients = 2
    //I dLambdaN
    //I-Stretch
    //I iExpType
    //I 1 for unia, 2 for biax, 3 for tension
    //- Calculate Stress given stretch and coeffs

    void FunctionLAlpha( double dLambda,
                         MAT_ExperimentType iExpType,
                         double& dResult ) ;
    //R void
    //I dLambda                     
    //I-Value of Stretch
    //I MAT_ExperimentType
    //I-Experiment Type
    //- Calculate Lalpha as in derivation

    bool FunctionDIthTerm( double dLambda,
                           INT dIthTerm,
                           MAT_ExperimentType iExpType,
                           double& dResult ) ;
    //R bool
    //I dLambda                     
    //I- Value of Stretch
    //I dIthTerm
    //I- Ith term in the Arruda Boyce Formula
    //I iExpType
    //I- 1 for uniaxial, 2 for biaxial, 3 for shear
    //O dResult
    //O-Calculated Dith Term as in derivation
};

#endif // !defined(MAT_ArrudaBoyce_H)
