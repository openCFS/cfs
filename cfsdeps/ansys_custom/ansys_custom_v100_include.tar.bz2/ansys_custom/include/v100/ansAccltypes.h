/* sid 50.1 copy of ansAccltypes.h last changed by jrb on 2005/03/09 12:45:14 */

#include "ansysdef.h"


extern  INT  cCreateAnsAccl(void);
extern  INT  cDeleteAnsAccl(void);
extern  INT  cInquireAnsAccl(INT,INT,INT);
extern  INT  cPutAnsAccl(INT,INT,DOUBLE*);
extern  INT  cGetAnsAccl(INT,INT,INT*,DOUBLE*);
extern  INT  cGetAnsAcclPtr(INT,INT,INT*,DOUBLE**);
extern  INT  cActivateAnsAccl(INT,INT,INT);
extern  INT  cDumpAnsAccl(INT);


/****************************************************************
 global-level structure for ANSYS nodal accelerations
 ****************************************************************/
struct ansAccl_str {         /* Name of the structure                                  */
  INT       tag;             /* Tag for this instance of the acceleration structure    */
  INT       numAcclNodes;    /* Number of nodes with accelerations                     */
  INT       maxAcclNode;     /* Maximum external node number having acceleration       */
  INT       numAccl;         /* Total number of accelerations (zero and non-zero)      */
};

#define ansAcclTag(accl)                (accl->tag)
#define ansAcclNumAcclNodes(accl)       (accl->numAcclNodes)
#define ansAcclMaxAcclNode(accl)        (accl->maxAcclNode)
#define ansAcclNumAccl(accl)            (accl->numAccl)



/******************************************************************
 data-level structure for ANSYS nodal accelerations
 ******************************************************************/
struct acclData_str {    /* Name of the structure                                           */
  char      modified;    /* Flag indicating whether this acceleration has been modified     */
  char      internal;    /* Flag indicating whether this acceleration is internal to object */
  INT       dof;         /* External DOF value                                              */
  char      active;      /* Flag indicating if acceleration is active or inactive           */
  DOUBLE   *values;      /* Vector containing acceleration values (we store 4 values)       */
                         /*        (1:2) current real,imag values                           */
                         /*        (3:4) previous real,imag values                          */ 
  acclData *nextAccl;    /* Pointer to the next acceleration data structure for this        */
                         /* node.  If this pointer is NULL, then this is the last           */
                         /* stored acceleration for this node                               */
};

#define acclDataModified(aData)         (aData->modified)
#define acclDataInternal(aData)         (aData->internal)
#define acclDataDof(aData)              (aData->dof)
#define acclDataAcclActive(aData)       (aData->active)

#define acclDataValuesPtr(aData)        (aData->values)
#define acclDataValuesVec(aData,i)      (aData->values[i])

#define acclDataNextAcclPtr(aData)      (aData->nextAccl)

