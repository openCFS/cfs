/* sid 50.1 copy of fem_spDist.h last changed by upd111 on 2004/11/04 18:33:10 */
/*  fem_spDist.h */
/* 
 * *** ansys(r) copyright(c) 1999
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  fem_spDist.h
 *  Prototypes and macros for distance calculations for surface proximity
 *   refinement
 *
 */

#ifndef FEM_SPDIST_____H
#define FEM_SPDIST_____H

                          /* ================================================ */
                          /* === FEM_spDist2PointFacet: Return the squared    */
                          /* === distance from a point to a triangular facet. */
                          /* === Return: squared distance from ps_3Dpoint to  */
                          /* === facet of ps_rect                             */
                          /* ================================================ */
DOUBLE FEM_spDist2PointFacet (
   POINT_TYP *ps_3Dpoint,       /* (IN) a point (x,y,z)                       */
   RECTANGLE_TYP *ps_rect,      /* (IN) a rectangle                           */
   DOUBLE dist_to_plane  );     /* (IN) distance from ps_3Dpoint to the plane */
                                /*      of the facet of ps_rect               */

                          /* ================================================ */
                          /* === FEM_spDist2PointFacet: Return the distance   */
                          /* === from a point to a triangular facet.          */
                          /* === Return: distance from ps_3Dpoint to facet of */
                          /* === ps_rect.                                     */
                          /* ================================================ */
DOUBLE FEM_spDistPointFacet (
   POINT_TYP *ps_3Dpoint,       /* (IN) a point (x,y,z)                       */
   RECTANGLE_TYP *ps_rect,      /* (IN) a rectangle                           */
   DOUBLE dist_to_plane  );     /* (IN) distance from ps_3Dpoint to the plane */
                                /*      of the facet of ps_rect               */

#endif

