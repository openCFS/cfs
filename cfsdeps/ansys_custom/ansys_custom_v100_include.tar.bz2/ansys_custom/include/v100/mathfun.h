/* sid 50.1 copy of mathfun.h last changed by rjayasee on 2005/03/01 18:40:49 */
/* mathfun.h							FJB
------------------------------------------------------------------------
------- Notice - This file contains ANSYS Confidential information --------
------------------------------------------------------------------------
*/
/* 
 * *** ansys(r) copyright(c) 2000
 * *** ansys, inc.
 */

/*------------------------------ Description ---------------------------
\Author:        F J. Bogden/Lyle Fischer (XOX)
\Title:         Special math macros, functions and values
\Desc: 		This file contains special math functions and values 
  		some of which are computer(machine) dependent and key 
  		on the computer dependencies found in the header file
  		computer.h.  The definitions here were developed for 
  		a K&R c-program and some of these may need to be altered 
  		for ANSI89-c. The definitions in this file are -not-
  		necessarily complete and others may be needed. 
\History:       93/06/01 : fjb - initial creation.
		93/08/09 : pft - merge of motif ui.
		94/03/15 : fjb - redo in form of SASI C-guidelines.
\Function(s)
 -Primary:      To supply interface to common math functions and values.
 -Secondary:    To foster portability
 -External:     none
 -Internal:     none
 -Static:       none
----------------------------------------------------------------------*/

/* Below spans entire file */
#ifndef COMPUTER_MATH_FUNCTION
#  define COMPUTER_MATH_FUNCTION

/*------------------------------ Header files ------------------------*/
#ifndef SYSTEM_MATH_H
#  define SYSTEM_MATH_H
#  include <math.h>
#endif

/*------------------------------ Dependencies ------------------------*/

/*------------------ Static Macro Definitions/Functions --------------*/
/* PI */
#ifndef M_PI
#  define M_PI            3.14159265358979323846
#endif
#ifndef PI
#  define PI              (M_PI)
#endif
#ifndef M_PI_2
#  define M_PI_2          (PI/2)
#endif
#ifndef TWO_PI
#endif
#  define TWO_PI          (2*PI)

/* The degree -> radian -> degree functions DegToRad and RadToDeg */
#define DegToRad(deg) ((PI / 180.0) * (deg))
#define RadToDeg(rad) ((rad) / (PI / 180.0))

/* The absolute value function ABS */
#ifndef ABS
#define ABS(a) (a>=0 ? (a) : -(a))
#endif

/* The absolute value function FABS */
#ifdef UTUseSystem_fabs
#  define FABS(a) fabs(a)
#endif

/* The squared function SQUARE */
#define SQUARE(a) ((a)*(a))

/* The minmax functions MAX and MIN */
#ifndef MAX
#  define MAX(a, b) ((a)>(b) ? (a) : (b))
#endif
#ifndef MIN
#  define MIN(a, b) ((a)<(b) ? (a) : (b))
#endif

/* The algebraic sign function SIGN */
#ifndef SIGN
#  define SIGN(x) ((x)>=0 ? 1 : (-1))
#endif

/* The modulus function MOD */
#ifndef MOD
#  define MOD(x,y) ((x)%(y))
#endif

/* The squareroot function SQRT(val) and domain error function POW  */
#ifndef UseSpecialSqrt
#  define SQRT(val) ((val) < 0.0 ? 0.0 : sqrt(val))
#else
   extern REAL CRSqrtVal;
#  define POW(val, power) (pow((val), (power)))
#  define SQRT(val)                \
              (CRSqrtVal = (val),  \
              (CRSqrtVal < 0.0 ? 0.0 : (sqrt(CRSqrtVal))))
#endif

/* The floating point remainder function FMOD */
#ifndef Use_drem
#  ifndef DECAXPOSF_SYS
     extern double fmod(double, double);
#  endif
#  define FMOD(x,y) (fmod(x,y))
#else
   extern double drem(double,double);
#  define FMOD(x,y) (drem(x,y))
#endif

/* The trig functions ATAN2, ATAN, ACOS, ASIN, COS, SIN and TAN */
#define ATAN2(val1,val2)   (atan2((val1),(val2)))
#define ATAN(val1,val2)    (atan((val1),(val2)))
#define ACOS(radians)      (acos((radians)))
#define ASIN(radians)      (asin((radians)))
#define COS(radians)       (cos((radians)))
#define SIN(radians)       (sin((radians)))
#define TAN(radians)       (tan((radians)))

/*--------------------- Static TypeDefs/Structures -------------------*/

/*----------------------- Variable Definitions -----------------------*/

/*------------------------- Exported Functions ------------------------*/

/*------------------------- Internal Functions ------------------------*/

/*-------------------------- Static Functions ------------------------*/

/*--------------------------------------------------------------------*/
/* Below is the endif for the whole file. */
#endif
/*---------------------------- End Of Module -------------------------*/

