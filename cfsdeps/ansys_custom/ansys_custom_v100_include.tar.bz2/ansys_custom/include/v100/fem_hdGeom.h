/* sid 50.1 copy of fem_hdGeom.h last changed by upd111 on 2004/11/04 18:32:55 */
/*  fem_hdGeom.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  fem_hdGeom.h
 *  Prototypes and macros for hexdom geometry functions
 *
 */

#ifndef HDGEOM_H
#define HDGEOM_H

/*------------------------ Constants -------------------------------------------*/
#define EXIT_NO_ISECT -456

/*------------------------ Data Structures -------------------------------------*/

/*------------------------ Globals - used in only FEM_hd files -----------------*/

/*------------------------ Prototypes ------------------------------------------*/

INT        fem_hdGeoWhichPlane          ( FACE_OBJ obj_face );
INT        fem_hdGeoWhichPlane2         ( VECTOR3D *ps_norm );
INT        fem_hdGeoVectorTo2D          ( INT iplane,
                                          VECTOR3D *ps_vec,
                                          DOUBLE *p_x,
                                          DOUBLE *p_y );
INT        fem_hdGeoIsectVectSeg        ( VECTOR3D *ps_norm,
                                          VECTOR3D *ps_n0,
                                          VECTOR3D *ps_n1,
                                          VECTOR3D *ps_nv,
                                          VECTOR3D *ps_vec,
                                          VECTOR3D *ps_isec,
                                          DOUBLE *p_t );
INT        fem_hdGeoIsectVectEdge       ( FACE_OBJ obj_face,
                                          EDGE_OBJ obj_edge,
                                          NODE_OBJ obj_node,
                                          VECTOR3D *ps_vec,
                                          VECTOR3D *ps_isec );
INT        fem_hdGeoIsectVectPlane      ( VECTOR3D *ps_norm,
                                          DOUBLE fd,
                                          VECTOR3D *ps_pt,
                                          VECTOR3D *ps_vect,
                                          VECTOR3D *ps_isect,
                                          DOUBLE *p_t );
INT        fem_hdGeoIsectVectFace       ( FACE_OBJ obj_face,
                                          NODE_OBJ obj_node,
                                          VECTOR3D *ps_vec,
                                          VECTOR3D *ps_isect );
INT        fem_hdGeoIsectSegFace        ( FACE_OBJ obj_face,
                                          VECTOR3D *ps_n0,
                                          VECTOR3D *ps_n1,
                                          VECTOR3D *ps_isect );
INT        fem_hdGeoPointOnEdge         ( EDGE_OBJ obj_edge,
                                          NODE_OBJ obj_node0,
                                          DOUBLE ratio,
                                          VECTOR3D *ps_loc );

#endif

