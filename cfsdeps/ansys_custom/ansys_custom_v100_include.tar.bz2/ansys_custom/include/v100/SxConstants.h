/* sid 50.6 copy of SxConstants.h last changed by eedelor on 2005/04/11 12:35:18 */
/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 2002                                         */
/* *** ansys, inc.                                                        */
/* ---------------------------------------------------------------------- */

/*CFILE  SxConstants.h            ANSI_C
* File name: SxConstants.h
* Author/date: Stefan Reh  2002-02-06
* Primary function:
*    Define constants for the SeriesXpansion method
*    -------------------------------------------------------
*    constant definitions - the following list of constants
*    MUST match the equivalent list in "SxConstants.inc" !!!
*    -------------------------------------------------------
*
*/

#ifndef  _SX_CONSTANTS_H_
#define  _SX_CONSTANTS_H_  1

#include "globals.h"
#include "sysparh.h"

#ifndef  SX_NAMESIZE
#define  SX_NAMESIZE         (FNAME_MAX+1)
#endif

#ifndef  SX_FILENAMEMAX
#define  SX_FILENAMEMAX      (INPUT_PATH_MAX+1)
#endif

#ifndef  SX_PARMSIZE
#define  SX_PARMSIZE         (PARMSIZE+1)
#endif

#ifndef  SX_LABSIZE
#define  SX_LABSIZE          (4+1)
#endif

#ifndef  EXIT_SUCCESS
#define  EXIT_SUCCESS        0
#endif

#ifndef  EXIT_FAILURE
#define  EXIT_FAILURE        1
#endif

/* define whether defined */
#ifndef  UNDEFINED
#define  UNDEFINED           0
#endif

#ifndef  DEFINED
#define  DEFINED             1
#endif

/* define status  type */
#ifndef  INACTIVE
#define  INACTIVE            0
#endif

#ifndef  ACTIVE
#define  ACTIVE              1
#endif

/* define SX module ENTER status */
#ifndef  SX_ENTERED
#define  SX_ENTERED          123457
#endif

#ifndef  SX_NOT_ENTERED
#define  SX_NOT_ENTERED      -123457
#endif

/* define SX module SOLVED status */
#ifndef  SX_SOLVED
#define  SX_SOLVED           123457
#endif

#ifndef  SX_NOT_SOLVED
#define  SX_NOT_SOLVED       -123457
#endif

#ifndef  SX_BIG_INT
#define  SX_BIG_INT          MAXINT
#endif

/* define constant */
#ifndef  ADD_EXTRA_COMMANDS
#define  ADD_EXTRA_COMMANDS  10
#endif

/* derivation order defaults */
#ifndef  DEFAULT_ORDER
#define  DEFAULT_ORDER       -10000
#endif


/* define a unique type for each sx command, variables and others */
typedef enum
{
    /* default setting */
    VAR_TYPE_NONE = 0,
    VAR_TYPE_FREQ = 1,
    VAR_TYPE_MP   = 2,
    VAR_TYPE_REAL = 3,
    VAR_TYPE_SEC  = 4,
    VAR_TYPE_CE   = 5, 
    VAR_TYPE_HI   = 6,
    VAR_TYPE_TEMP = 7,
    VAR_TYPE_GEOM = 8,
    VAR_TYPE_DISC = 9,
    VAR_TYPE_RSLT = 10,
    VAR_TYPE_IN   = 11,
    VAR_TYPE_METH = 12,
    VAR_TYPE_RFIL = 13,
    VAR_TYPE_EVAL = 14,
    VAR_TYPE_OPT = 15,
    VAR_TYPE_SFE = 16,

    /* keep this in last position: max value for E_VarTypes */
    VAR_TYPE_MAXIMUM
} E_VarTypes;


/* define material property types for SXMP command */
typedef enum 
{
    MAT_PROP_NONE = 0,
    MAT_PROP_EX   = 1,
    MAT_PROP_EY   = 2,
    MAT_PROP_EZ   = 3,
    MAT_PROP_NUXY = 4,
    MAT_PROP_NUYZ = 5,
    MAT_PROP_NUXZ = 6,
    MAT_PROP_GXY  = 7,
    MAT_PROP_GYZ  = 8,
    MAT_PROP_GXZ  = 9,
    MAT_PROP_ALPX = 10,
    MAT_PROP_ALPY = 11,
    MAT_PROP_ALPZ = 12,
    MAT_PROP_DENS = 13,
    MAT_PROP_KXX=16,
    MAT_PROP_KYY=17,
    MAT_PROP_KZZ=18,
    MAT_PROP_C=22,
    MAT_PROP_ENTH=26,
    MAT_PROP_QRAT=59,
    MAT_PROP_LSST=27,
    MAT_PROP_PERX=34,
    MAT_PROP_PERY=35,
    MAT_PROP_PERZ=36,
    MAT_PROP_RSVX=19,
    MAT_PROP_RSVY=20,
    MAT_PROP_RSVZ=21
} E_MatPropTypes;

/* define intertial load type */
typedef enum 
{
    IN_LOAD_NONE  = 0,
    IN_LOAD_ACEL  = 1,
    IN_LOAD_CGLO  = 2,
    IN_LOAD_CGOM  = 3,
    IN_LOAD_DCGO  = 4,
    IN_LOAD_DOME  = 5,
    IN_LOAD_OMEG  = 6
} E_InLoadType;

/* define intertial load component */
typedef enum 
{
    IN_LOAD_COMP_NONE  	= 0,
    IN_LOAD_COMP_X  	= 1,
    IN_LOAD_COMP_Y  	= 2,
    IN_LOAD_COMP_Z  	= 3,
    IN_LOAD_COMP_ALL  	= 4
} E_InLoadComp;

/* define real constant property types for SXREAL command */
typedef enum 
{
    REAL_PROP_NONE = 0,
    REAL_PROP_TK   = 1,
    REAL_PROP_STIF = 2,
    REAL_PROP_MASS = 3
} E_RealPropTypes;

/* define section property types for SXSEC command */
typedef enum 
{
    SEC_PROP_NONE = 0,
    SEC_PROP_TK   = 1,
    SEC_PROP_A    = 2,
    SEC_PROP_IYY  = 3,
    SEC_PROP_IYZ  = 4,
    SEC_PROP_IZZ  = 5,
    SEC_PROP_IW   = 6,
    SEC_PROP_J    = 7,
    SEC_PROP_EX   = 8,
    SEC_PROP_EY   = 9,
    SEC_PROP_EZ   = 10,
    SEC_PROP_NUXY = 11,
    SEC_PROP_NUYZ = 12,
    SEC_PROP_NUXZ = 13,
    SEC_PROP_GXY  = 14,
    SEC_PROP_GYZ  = 15,
    SEC_PROP_GXZ  = 16,
    SEC_PROP_ALPX = 17,
    SEC_PROP_ALPY = 18,
    SEC_PROP_ALPZ = 19,
    SEC_PROP_DENS = 20,
    SEC_PROP_THETA = 21
} E_SecPropTypes;


/* define entity definition types for several commands */
typedef enum
{
    EDT_NONE   = 0,
    EDT_MATID  = 1,
    EDT_REALID = 2,
    EDT_SECID  = 3,
    EDT_ELEM   = 4,
    EDT_NODE   = 5,
    EDT_COMP   = 6,
    EDT_ALL    = 7
} E_EntyDefTypes;


/* define layer definition types for SXSEC command */
typedef enum
{
    LDT_NONE  = 0,
    LDT_ALL   = 1,
    LDT_LAYID = 2
} E_LayerDefTypes;


/* define the reduction options of input variable ranges */
typedef enum
{
    RED_OPT_NONE = 0,
    RED_OPT_CONT = 1,
    RED_OPT_STOP = 2
} E_RedOpts;


/* define variability types for several commands */
typedef enum
{
    VARIA_TYPE_NONE = 0,
    VARIA_TYPE_FACT = 1,
    VARIA_TYPE_ADD  = 2,
    VARIA_TYPE_VAL  = 3
} E_VariaTypes;

/* define SXRSLT command entity keys */
typedef enum
{
    SXRSLT_ENTY_NONE = 0,
    SXRSLT_ENTY_ELEM = 1,
    SXRSLT_ENTY_MODE = 2,
    SXRSLT_ENTY_NODE = 3
} E_SXRSLT_Entity;

/* define SXRSLT command result quantitytypes */
typedef enum
{
    SXRSLT_TYPE_NONE = 0,
    SXRSLT_TYPE_AX   = 1,
    SXRSLT_TYPE_EPEL = 2,
    SXRSLT_TYPE_MODE = 3,
    SXRSLT_TYPE_FREQ = 4,
    SXRSLT_TYPE_MASS = 5,
    SXRSLT_TYPE_RF   = 6,
    SXRSLT_TYPE_S    = 7,
    SXRSLT_TYPE_U    = 8,
    SXRSLT_TYPE_VOLU = 9,
    SXRSLT_TYPE_IF    = 11,
    SXRSLT_TYPE_TEMP = 12,
    SXRSLT_TYPE_VOLT = 13,
    SXRSLT_TYPE_TG   = 14,
    SXRSLT_TYPE_TF   = 15,
    SXRSLT_TYPE_D    = 16,
    SXRSLT_TYPE_EF   = 17,
    SXRSLT_TYPE_JC   = 18,
    SXRSLT_TYPE_B    = 19,
    SXRSLT_TYPE_H    = 20,
    SXRSLT_TYPE_JT   = 21,
    SXRSLT_TYPE_FMAG = 22,
    SXRSLT_TYPE_AZ   = 23
} E_SXRSLT_Types;

/* define SXRSLT command component result quantity types */
typedef enum 
{
    SXRSLT_COMP_NONE = 0,
    SXRSLT_COMP_X    = 1,
    SXRSLT_COMP_Y    = 2,
    SXRSLT_COMP_Z    = 3,
    SXRSLT_COMP_XY   = 4,
    SXRSLT_COMP_YZ   = 5,
    SXRSLT_COMP_ZX   = 6,
    SXRSLT_COMP_FX   = 7,
    SXRSLT_COMP_FY   = 8,
    SXRSLT_COMP_FZ   = 9,
    SXRSLT_COMP_MX   = 10,
    SXRSLT_COMP_MY   = 11,
    SXRSLT_COMP_MZ   = 12,
    SXRSLT_COMP_ALL  = 13
} E_SXRSLT_Comps;

/* define variable modification operations */
typedef enum 
{
    SXVMOD_OPER_NONE  = 0,
    SXVMOD_OPER_ACT   = 1,
    SXVMOD_OPER_DEACT = 2,
    SXVMOD_OPER_DEL   = 3,
    SXVMOD_OPER_SET   = 4
} E_SXVMOD_OperTypes;

/* define the print entities of a variable types for several commands */
typedef enum 
{
    PRINT_NO  = 0,
    PRINT_YES = 1
} E_PrintKeys;


/* define SXMETH command type keys */
typedef enum
{
    SXMETH_SOLU_NONE = 0,
    SXMETH_SOLU_BASE = 1,
    SXMETH_SOLU_INDP = 2,
    SXMETH_SOLU_FULL = 3
} E_SXMETH_SoluTypes;


/* define SXMETH command approximation keys */
typedef enum
{
    SXMETH_APPR_NONE = 0,
    SXMETH_APPR_TAYL = 1,
    SXMETH_APPR_PADE = 2,
    SXMETH_APPR_AUTO = 3,
    SXMETH_APPR_FAST = 4
} E_SXMETH_ApprTypes;

typedef enum
{
    SXMETH_TRACK_NONE = 0,
    SXMETH_TRACK_ON = 1,
    SXMETH_TRACK_OFF = 2
} E_SXMETH_TrackTypes;

/* define SXMETH command test and verification keys */
typedef enum
{
    SXMETH_TEST_NONE  = 0,
    SXMETH_TEST_VERIF = 1,
    SXMETH_TEST_DERIV = 2
} E_SXMETH_VerifyTypes;



/* define file open status */
typedef enum
{
    FILE_OPENED_NO  = -1,
    FILE_OPENED_YES = 1
} E_FileOpenStatus;


/* define SXCLR command type keys */
typedef enum 
{
    SXCLR_TYPE_NONE = 0,
    SXCLR_TYPE_ALL  = 1,
    SXCLR_TYPE_RSLT = 2
} E_SXCLR_Types;


typedef enum 
{
        AB_MSG   = 1,
        AB_BAR   = 2,
        AB_KIL   = 4,
        GR_ABORT = 3
} E_SX_Progress;



typedef enum 
{
  SXQA_ACTION_NOMI   = 0,
  SXQA_ACTION_FULL   = 1,	
  SXQA_ACTION_INDP   = 2,	
  SXQA_ACTION_CURR   = 3,	
  SXQA_ACTION_INFO   = 4,
  SXQA_ACTION_PERT   = 5,
  SXQA_ACTION_SENSI  = 6,
  SXQA_ACTION_RANDOM = 7,
  SXQA_ACTION_CORNER = 8
} E_SXQA_Action;


typedef enum
{
  SXQA_INFO_ITEM_MODEL = 0,
  SXQA_INFO_ITEM_PARAM = 1,	
  SXQA_INFO_ITEM_COMP = 2
} E_SXQA_Info_Item;
             



typedef enum
{
  SXQA_LAYER_NONE = 0,
  SXQA_LAYER_MAX = 1,
  SXQA_LAYER_TOP = 2,	
  SXQA_LAYER_MIDDLE = 3,	
  SXQA_LAYER_BOTTOM = 4
} E_SXQA_Layer;

/* define surface load types for SXSFE command */
typedef enum 
{
  SXSFE_LOAD_NONE = 0,
  SXSFE_LOAD_PRES = 1,
  SXSFE_LOAD_CONV_COEF = 2,
  SXSFE_LOAD_CONV_TEMP = 3,
  SXSFE_LOAD_HFLUX = 4
} E_SXSFE_SurfLoadTypes;

#endif  /* _SX_CONSTANTS_H_ */



