/* sid 50.1 copy of MAT_MaterialRecordApi.h last changed by upd111 on 2005/06/04 13:23:20 */
////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         Copyright (C) 2001 ANSYS Inc.  All Rights Reserved             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MAT_MaterialRecordApi.h $
// $Revision$ 7.0
// $Date$ October 21 2003
// $Author$ rjayasee
//
// Description :
//          Material Record Used to query/write  Element/Material Data
////////////////////////////////////////////////////////////////////////////

#if !defined(MAT_MaterialRecordApi_H)
#define MAT_MaterialRecordApi_H

#include "ansys.h"

#if defined (HP_SYS) || defined(HPIA64_SYS) || defined(HP32_SYS) 
    #define const const
#endif 

/* (1)----------------------------------------------------------------*/
#if defined(LOWERCASENOUNDER_SYS)

/*
 *   The pattern for these platforms is the lowercased version of the name
 */

#define MAT_SetNumberOfCaches             mat_setnumberofcaches
#define MAT_InitializeCacheForElement     mat_initializecacheforelement
#define MAT_InMemoryCacheStartUp          mat_inmemorycachestartup
#define MAT_InMemoryCacheCleanUp          mat_inmemorycachecleanup
#define MAT_InMemoryCacheEnd              mat_inmemorycacheend
#define MAT_InMemoryCachePrint            mat_inmemorycacheprint
#define MAT_GetDataRecordAtIntPt          mat_getdatarecordatintpt
#define MAT_GetDataRecordAtIntPtOrig      mat_getdatarecordatintptorig
#define MAT_SetDataRecordAtIntPt          mat_setdatarecordatintpt
#define MAT_GetDataRecordAtIntPtCopy      mat_getdatarecordatintptcopy
#define MAT_GetIDataRecordAtIntPtCopy     mat_getidatarecordatintptcopy
#define MAT_WriteCacheToDatabase          mat_writecachetodatabase
#endif


/* (2)----------------------------------------------------------------*/
#if defined(UPPERCASENOUNDER_SYS)

/*
 *   The pattern for these platforms is the uppercased version of the name
 */
#define MAT_SetNumberOfCaches             MAT_SETNUMBEROFCACHES
#define MAT_InitializeCacheForElement     MAT_INITIALIZECACHEFORELEMENT
#define MAT_InMemoryCacheStartUp          MAT_INMEMORYCACHESTARTUP
#define MAT_InMemoryCacheCleanUp          MAT_INMEMORYCACHECLEANUP
#define MAT_InMemoryCacheEnd              MAT_INMEMORYCACHEEND
#define MAT_InMemoryCachePrint            MAT_INMEMORYCACHEPRINT
#define MAT_GetDataRecordAtIntPt          MAT_GETDATARECORDATINTPT
#define MAT_GetDataRecordAtIntPtOrig      MAT_GETDATARECORDATINTPTORIG
#define MAT_SetDataRecordAtIntPt          MAT_SETDATARECORDATINTPT
#define MAT_GetDataRecordAtIntPtCopy      MAT_GETDATARECORDATINTPTCOPY
#define MAT_GetIDataRecordAtIntPtCopy     MAT_GETIDATARECORDATINTPTCOPY
#define MAT_WriteCacheToDatabase          MAT_WRITECACHETODATABASE
#endif


/* (3)----------------------------------------------------------------*/
#if defined(LOWERCASEUNDER_SYS)

/*
 *   The pattern for these platforms is the lowercased version of the name 
 *   followed by an underscore
 */

#define MAT_SetNumberOfCaches             mat_setnumberofcaches_
#define MAT_InitializeCacheForElement     mat_initializecacheforelement_
#define MAT_InMemoryCacheStartUp          mat_inmemorycachestartup_
#define MAT_InMemoryCacheCleanUp          mat_inmemorycachecleanup_
#define MAT_InMemoryCacheEnd              mat_inmemorycacheend_
#define MAT_InMemoryCachePrint            mat_inmemorycacheprint_
#define MAT_GetDataRecordAtIntPt          mat_getdatarecordatintpt_
#define MAT_GetDataRecordAtIntPtOrig      mat_getdatarecordatintptorig_
#define MAT_SetDataRecordAtIntPt          mat_setdatarecordatintpt_
#define MAT_GetDataRecordAtIntPtCopy      mat_getdatarecordatintptcopy_
#define MAT_GetIDataRecordAtIntPtCopy     mat_getidatarecordatintptcopy_
#define MAT_WriteCacheToDatabase          mat_writecachetodatabase_


#endif

#ifdef __cplusplus
extern "C"
{
#endif

INT FUNCTION MAT_SetNumberOfCaches( INT* pNumCache) ;
//R Result
//I pNumCache
//I number of Caches
//- Sets Number of Caches

INT FUNCTION MAT_InitializeCacheForElement( INT* iIndex) ;
//R Result
//I Creates cache for all elements/nproc elements. Does not create cache data under element

INT FUNCTION MAT_InMemoryCacheStartUp( INT* pElementIndex, LONGINTC* pEsavLoc, 
                                       INT* pSVIdx, INT* pInitialFlag,
                                       INT* pReadFromDBFlag) ;
//I Result
//I pElementIndex
//I-Element ID
//I pEsavLoc
//I-ESAV location
//I pSVIdx
//I-Save Indices
//I pInitialFlag
//I-Initial Strain Flag
//I pReadFromDBFlag
//- 1 if read from database
//- Starts Up the Memory Cache. Creates cache for one element

INT FUNCTION MAT_InMemoryCachePrint(INT*) ;
//I Result
//- Prints InMemory Cache

INT FUNCTION MAT_InMemoryCacheCleanUp(INT*) ;
//I Result
//- Cleans Up InMemory Cache for the particular element

INT FUNCTION MAT_InMemoryCacheEnd() ;
//I Result
//- Clear memory cache totally

INT FUNCTION MAT_WriteCacheToDatabase( INT* pElementIndex, LONGINTC* pEsavLoc, INT* pSvIdx ) ;
//R Resutl
//- This function writes the cache back to the database

INT FUNCTION MAT_GetDataRecordAtIntPt(  INT* iElementIndex,
                                        INT* iIntegrationPoint, 
                                        INT* pRecordType,
                                        DOUBLE** pDataRecord,
                                        INT* pLengthOfRecord ) ;
/*
//R Status of the Function 1 for success 
//I iElementIndex
//I-Element ID
//I iIntegrationPoint
//I-Integration Point
//O pDataRecord
//O-Pointer to DOUBLE array that refers to a data record at some integration point
//O pLengthOfRecord
//O-Length of the Record
//- Function Extracts data record at an integration point for an Element
*/

INT FUNCTION MAT_GetDataRecordAtIntPtCopy(  INT* iElementIndex,
                                            INT* iIntegrationPoint, 
                                            INT* pRecordType,
                                            DOUBLE* pDataRecord,
                                            INT* pLengthOfRecord ) ;
/*
//R Status of the Function 1 for success 
//I iElementIndex
//I-Element ID
//I iIntegrationPoint
//I-Integration Point
//O pDataRecord
//O-Pointer to DOUBLE array that refers to a data record at some integration point
//O pLengthOfRecord
//O-Length of the Record
//- Function Extracts data record at an integration point for an Element
//- This function makes a copy of the data in the memory loc provide by pDataRecord
*/

INT FUNCTION MAT_GetDataRecordAtIntPtOrig(  INT* iElementIndex,
                                                INT* iIntegrationPoint, 
                                                INT* pRecordType,
                                                DOUBLE** pDataRecord,
                                                INT* pLengthOfRecord ) ;
/*
//R Status of the Function 1 for success 
//I iElementIndex
//I-Element ID
//I iIntegrationPoint
//I-Integration Point
//O pDataRecord
//O-Pointer to DOUBLE array that refers to a data record at some integration point
//O pLengthOfRecord
//O-Length of the Record
//- Function Extracts data record at an integration point for an Element
*/

INT FUNCTION MAT_GetIDataRecordAtIntPtCopy(  INT* iElementIndex,
                                                    INT* iIntegrationPoint, 
                                                    INT* pRecordType,
                                                    DOUBLE* pDataRecord,
                                                    INT* pLengthOfRecord ) ;
/*
//R Status of the Function 1 for success 
//I iElementIndex
//I-Element ID
//I iIntegrationPoint
//I-Integration Point
//O pDataRecord
//O-Pointer to DOUBLE array that refers to a data record at some integration point
//O pLengthOfRecord
//O-Length of the Record
//- Function Extracts data record at an integration point for an Element
//- This function makes a copy of the data in the memory loc provide by pDataRecord
*/

INT FUNCTION MAT_SetDataRecordAtIntPt( INT* pElementIndex,
                                       INT* pIntegrationPoint, 
                                       INT* pRecordType,
                                       DOUBLE* pIntegrationPointData,
                                       INT* pLengthOfRecord ) ;
/*
//R Status of the Function 1 for success 
//I iElementIndex
//I-Element ID
//I iIntegrationPoint
//I-Integration Point
//O pDataRecord
//O-Pointer to DOUBLE array that refers to a data record at some integration point
//O pLengthOfRecord
//O-Length of the Record
//- Function Sets/Puts data record at an integration point for an Element
*/

void FUNCTION InitializeRecordSizeTable( INT pRecSizeArray[20], INT iNTens, INT iStateVar ) ;
/*
//R Returns Record Size Tables
//O-pRecSizeArray
//O Record Size Array
//I-iNTens
//I NTens Variable
//I iStateVar
//I-State Variable
//- Set the record sizes

*/

#define IELCSZ 150
#define MAX_NODES 10
#define NNMAX 89
//In AnsysDef.inc
const int MAT_NumMaterialRecords = 20 ;


//NL defines
#define NLKWVAL  2
#define NLKWMAX  12
#define NLKWSIZE NLKWMAX*NLKWVAL
#define NCOMPN 52
// From AnsysDef.inc

#define EL_MAT          1
#define EL_TYPE         2
#define EL_REAL         3
#define EL_SECT         4
#define EL_CSYS         5
#define EL_DEAD         6
#define EL_SOLID        7
#define EL_SHAPE        8
#define EL_OBJOPTIONS   9
#define EL_PEXCLUDE     10
#define EL_DIM          10


//Element Query Parmameters

#define numElementPara   29
#define           CADOEUPD_INDEX        0
#define           ELEMID_INDEX          1
#define           ELMATPOINT_INDEX      2
#define           ESAVEUPD_INDEX        3
#define           NDIM_INDEX            4
#define           NCOMP_INDEX           5
#define           NELMATPOINT_INDEX     6
#define           ELDSHAP_INDEX         7
#define           NLAYER_INDEX          8
#define           ELTYPE_INDEX          9
#define           NSECTINTPTS_INDEX    10
#define           NCORNER_INDEX        11
#define           ROTUPD_INDEX         12
#define           NELGAUSSPTS_INDEX    13
#define           NELGAUSSPTSB_INDEX   14
#define           RSTEREXNODE_INDEX    15
#define           MATRECUPD_INDEX      16
#define           UPKEY_INDEX          17
#define           SUBSTEP_INDEX        18
#define           DEBUGFLAG_INDEX      19
#define           NDIRECT_INDEX        20
#define           MATID_INDEX          21
#define           KCJACOBI_INDEX       22
#define           NSVAR_INDEX          23
#define           ELSHAPE_INDEX        29

/*
      parameter  (IETYP = 1, JETYP = 2,
     x KYOP1 = 3, KYOP2 = 4, KYOP3 = 5, KYOP4 = 6, KYOP5 = 7, KYOP6 = 8,
     x KYOP7 = 9, KYOP8 =10, KYOP9 =11, KYOP10=12, KYOP11=13, KYOP12=14,
     x KYOP13=15, KYOP14=16, KYOP15=17, KYOP16=18, KYOP17=19, KYOP18=20)
*/

#ifdef __cplusplus
}
#endif

#endif

