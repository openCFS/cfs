/* sid 50.1 copy of fem_hdSeam.h last changed by upd111 on 2004/11/04 18:32:56 */
/*  fem_hdSeam.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  fem_hdSeam.h
 *  Prototypes and macros for hexdom seam functions
 *
 */

#ifndef HDSEAM_H
#define HDSEAM_H

/*------------------------ Constants -------------------------------------------*/

/*------------------------ Data Structures -------------------------------------*/


/*------------------------ Prototypes ------------------------------------------*/

INT           fem_hdUpdateSeamList          ( HDFRONT_PTYP *a_fronts,
                                              INT numfronts );

INT           fem_hdDoSeams                 ( INT level );

void          fem_hdDumpSeams               ( FILE *fp );
void          fem_hdResumeSeams             ( FILE *fp );

#endif
