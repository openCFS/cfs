/* sid 50.1 copy of fem_swLocate.h last changed by upd111 on 2004/11/04 18:33:28 */

/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 1999 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_swLocate.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_swLocate.h
 *  header file for FEM_swLocate.c
 *
 */
#ifndef FEM_SWLOCATE_INCLUDE
#define FEM_SWLOCATE_INCLUDE

#include "fem_swRibs.h"

/*----------------- Globally accessible variables ---------------------------*/

/*----------------- Globally accessible function prototypes -----------------*/

                          /* =============================================== */
                          /* === FEM_swLocateNodes: After the background     */
                          /* === mesh is created with the boundary nodes of  */
                          /* === the source area, locate each interior node  */
                          /* === on the source area in the background mesh   */
                          /* === and store its location.                     */
                          /* === Return: INT EXIT_SUCCESS or EXIT_FAILURE    */
                          /* =============================================== */
INT FEM_swLocateNodes(
   MESH_OBJ obj_bgmesh,       /* (IN)  The background mesh                   */
   NODE_OBJ const*aobj_area_nodes, /* (IN)  list of nodes on source_area.    */
   INT num_area_nodes,        /* (IN)  number of nodes on source area stored */
                              /*       in aobj_area_nodes[0-num_area_nodes]. */
   INT num_area_edges,        /* (IN)  number of edges on source area.  If   */
                              /*       g_sweepmids, they are stored in       */
                              /*       aobj_area_nodes after num_area_nodes. */
   NODE_OBJ const *aobj_src_bnd_nodes,/* (IN)list of nodes on the boundary of*/
                              /*        the source_area.                     */
   NODE_OBJ const *aobj_trg_bnd_nodes,/* (IN)list of nodes on the boundary of*/
                              /*        the target_area.                     */
   VECTOR3D *a_src_normals,   /* (IN)  Normal at each boundary node on       */
                              /*       the source_area.                      */
   VECTOR3D *a_trg_normals,   /* (IN)  Normal at each boundary node on       */
                              /*       the target_area.                      */
   INT num_bnd_nodes,         /* (IN)  length of aobj_src_bnd_nodes,         */
                              /*       aobj_trg_bnd_nodes, a_src_normals,    */
                              /*       and a_trg_normals.                    */
   INT source_area,           /* (IN)  the source area.                      */
   INT target_area,           /* (IN)  the target area.                      */
   FEM_BOOLEAN do_plane_offset,/* (IN)  TRUE if logic to displace nodes      */
                              /*       off of tesselation should be used.    */
   RIBDATA_TYP *a_node_data,  /* (OUT) Data filled in for each area node     */
   FEM_BOOLEAN do_progress,   /* (IN)  TRUE if doing status window           */
   INT debug  );              /* (IN)  debug flag                            */
                          /* =============================================== */

#endif

