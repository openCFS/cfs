/* sid 50.1 copy of pds_constants.h last changed by upd111 on 2005/06/04 13:19:27 */
/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 2000                                         */
/* *** ansys, inc.                                                        */
/* ---------------------------------------------------------------------- */

/*CFILE pds_constants.h            ANSI_C
* File name: pds_constants.h
* Author/date: Stefan Reh  02/18/2000
* Primary function:
*    Define constants for the PDS tool
*/

#ifndef  _PDS_CONSTANTS_H_
#define  _PDS_CONSTANTS_H_

#include "globals.h"
#include "sysparh.h"

/*
#if defined (PDS_MEMORYCHECK)
#define  return     PDS_CheckMemory(__LINE__,__FILE__);return
#endif
*/

#define PDS_TOTALRUN                100
#define PDS_INITIALSEED             123457
#define PDS_PARMSIZE                (PARMSIZE+1)
#define PDS_COMMANDLENGTH           (COMMAND_WORD_LEN+1)
#define PDS_SOLULABLENGTH           (PARMSIZE+1)
#define PDS_LAB4LENGTH              5
#define PDS_DISTYPE_NAMELENGTH      5
#define PDS_DISTRIBUTIONPARAMS      4
#define PDS_FILENAMELENGTH          (FNAME_MAX+1+PDS_SOLULABLENGTH+1)
#define PDS_EXTENSIONLENGTH         (EXTENSION_MAX+1)
#define PDS_DIRECTORYLENGTH         (DIRECTORY_MAX+1)
#define PDS_FILEWITHDIRECTORY       (SYS_PATH_MAX+PDS_SOLULABLENGTH+1+1)
#define PDS_TITLELENGTH             81
#define ADD_EXTRA_RV                100
#define RSM_BBM_MIN_RV              3
#define RSM_BBM_MAX_RV              12
#define RSM_BBM_LEVELS              3
#define RSM_CCD_MIN_RV              2
#define RSM_CCD_MAX_RV              20
#define RSM_CCD_LEVELS              5
#define PDS_TINY                    pow(2.0,-100.0)
#define PDS_HUGE                    pow(2.0,100.0) 
#define PDS_LONG_MAX                2147483563
#define PDS_MINRESULTCOLWIDTH       17

/* The list of enums */
enum Distribution_Function_List 
{
    PDS_GAUSSIAN=1,  PDS_TRUNGAU,	PDS_LOGNORMAL1,   PDS_LOGNORMAL2,
    PDS_TRIANGULAR,  PDS_UNIFORM,   PDS_WEIBULL,	  PDS_EXPONENTIAL,
    PDS_GAMMA,       PDS_BETA,
    PDS_DISTRIBUTION_END
};

enum CDF_Plotting_Types_List
{
    CDF_PLOT_BEG=-1,
    CDF_PLOT_EMP=0,
    CDF_PLOT_GAUS,
    CDF_PLOT_LOGN,
    CDF_PLOT_EXPO,
    CDF_PLOT_WEIB,
    CDF_PLOT_END
};

enum Method_List 
{
    MCS_BEG =0  , MCS_DIR,	MCS_EFF,	MCS_LHS,	MCS_USR,     MCS_END,
    RSM_BEG =100, RSM_CCD,  RSM_BBM,	RSM_USR,	RSM_END,
    SCRS_BEG=200, PDS_SCRS, SCRS_END
};

enum Run_List
{
	PDS_SERIAL=0, PDS_MRUN, PDS_LSF
};

enum DOE_Levels_Distribution_Option
{
    DOE_LVL_OPT_BND = 0, DOE_LVL_OPT_ALL
};

enum DOE_Levels_Value_Type
{
    DOE_VAL_TYPE_PROB = 0, DOE_VAL_TYPE_PHYS
};

enum DOE_Levels_Defined
{
    DOE_LVL_NOT_DEFINED = 0, DOE_LVL_DEFINED
};

enum CCD_Experimental_Point
{
    CCD_NEG_ALPHA = -2, CCD_NEG_ONE, CCD_ZERO, CCD_ONE, CCD_ALPHA
};

enum BBM_Experimental_Point
{
    BBM_NEG_ONE = -1, BBM_ZERO, BBM_ONE
};

enum RSM_Method_Option
{
	RSM_ALL = 0, RSM_AUTO, RSM_FIX
};

enum Seed_Value_Handling
{
    SEED_TIME = -2, SEED_INIT, SEED_CONT, SEED_VALUE
};

enum MCS_Method_Option
{
	MCS_ALL = 0, MCS_AUTO
};

enum MCS_Variance_Reduction_Option
{
	MCS_VR_NONE = 0, MCS_VR_ATV
};

enum LHS_Interval_Option
{
	LHS_INTV_RAND = 0, LHS_INTV_MEAN, LHS_INTV_MEDI
};

enum PDS_Progress
{
	AB_MSG = 1, AB_BAR = 2, AB_KIL = 4, GR_ABORT = 3
};


#endif  /* _PDS_CONSTANTS_H_ */
