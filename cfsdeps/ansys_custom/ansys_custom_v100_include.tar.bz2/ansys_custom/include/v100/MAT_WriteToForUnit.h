/* sid 50.1 copy of MAT_WriteToForUnit.h last changed by rjayasee on 2005/03/03 21:27:15 */
/*
////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         Copyright (C) 2001 ANSYS Inc.  All Rights Reserved             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MAT_WriteToFortranUnit.h $
// $Revision$ 7.0
// $Date$ March 01 2005
// $Author$ rjayasee
//
// Decription :
//
// Write a command or line to a specific fortran unit
////////////////////////////////////////////////////////////////////////////
*/

#if !defined(MAT_WriteToFortranUnit)
#define MAT_WriteToFortranUnit

                         
#ifdef __cplusplus
extern "C"
{
#endif
    
void MAT_WriteToForUnit( int iUnit,
                             char* pFormat, ... ) ;
/*
//R void
//I oMsgType
//I-Type of Message, whether error,warning...
//I-Look at the defn of MAT_MessageType for the different types
//- This function is the message handler for the Material API
*/

#ifdef __cplusplus
}
#endif

#endif     

