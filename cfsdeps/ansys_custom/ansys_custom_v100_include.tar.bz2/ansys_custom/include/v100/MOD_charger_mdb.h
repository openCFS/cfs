/* sid 50.1 copy of MOD_charger_mdb.h last changed by upd111 on 2005/06/04 13:21:29 */
/* MOD_charger_mdb.h CADOE  */
/*
 * MOD_charger_mdb.h
 *
 * $Id$
 *   
 * HISTORY
 *   
 *   06/28/00 10:47 <       Brian Jantzen> Rel:ms8m1    SCCA:74542  Delta:81.3
 *   
 *   06/21/00 16:30 <       Brian Jantzen> Rel:ms8m1    SCCA:74307  Delta:81.2
 */

#ifndef __modchargermdbh__
#define __modchargermdbh__ 1

#ifndef __expmdbstructh__
#include "expmdb_struct.h"
#endif

#ifdef __cplusplus
extern "C" {
#endif

extern T_statut MOD_charger_mdb( T_Modele *, T_booleen );
extern T_statut MOD_charger_mdb_4 ( T_Modele * );
extern T_statut MOD_verifier_mdb( T_Modele *modele, T_booleen *van_existe, T_booleen *mdb_existe );

#ifdef __cplusplus
}
#endif

#endif
