/* sid 50.1 copy of ansElmBodyLoadtypes.h last changed by jrb on 2005/02/25 19:24:21 */

#include "ansysdef.h"


extern  INT  cCreateAnsElmBodyLoad(void);
extern  INT  cDeleteAnsElmBodyLoad(void);
extern  INT  cInquireAnsElmBodyLoad(INT,INT,INT);
extern  INT  cPutAnsElmBodyLoad(INT,INT,INT,DOUBLE*);
extern  INT  cGetAnsElmBodyLoad(INT,INT,INT*,DOUBLE*);
extern  INT  cGetAnsElmBodyLoadPtr(INT,INT,INT*,DOUBLE**);
extern  INT  cActivateAnsElmBodyLoad(INT,INT,INT);
extern  INT  cDumpAnsElmBodyLoad(INT);


/****************************************************************
 global-level structure for ANSYS element body loads
 ****************************************************************/
struct ansElmBodyLoad_str {  /* Name of the structure                                   */
  INT       tag;             /* Tag for this instance of the element loads structure    */
  INT       *numDef;         /* Number of defined body loads for each body load type    */
  INT       *maxSize;        /* Maximum number of values stored for each body load type */
};

#define ansElmBodyLoadTag(load)                (load->tag)

#define ansElmBodyLoadNumDefPtr(load)          (load->numDef)
#define ansElmBodyLoadNumDefVec(load,i)        (load->numDef[i])
#define ansElmBodyLoadMaxSizePtr(load)         (load->maxSize)
#define ansElmBodyLoadMaxSizeVec(load,i)       (load->maxSize[i])



/******************************************************************
 data-level structure for ANSYS element body loads
 ******************************************************************/
struct elmBodyLoadData_str {    /* Name of the structure                                        */
  char              modified;   /* Flag indicating whether this body load has been modified     */
  char              internal;   /* Flag indicating whether this body load is internal to object */
  INT               loadType;   /* type of body load (see ansysdef.h for possible values)       */
  char              active;     /* flag indicating if body load is active or inactive           */
  INT               numValues;  /* number of values stored for this element body load           */
  DOUBLE           *values;     /* Array containing element body load values (numValues long)   */
                                /* NOTE: this array contains the current and previous values    */
                                /* both.  The first numValues/2 values are the current values   */
                                /* and the second numValues/2 values are the previous values    */
  elmBodyLoadData  *nextLoad;   /* Pointer to the next element body load data structure         */
                                /* for this element.  If this pointer is NULL, then this is     */
                                /* the last stored body load for this element                   */
};

#define elmBodyLoadDataModified(eData)         (eData->modified)
#define elmBodyLoadDataInternal(eData)         (eData->internal)
#define elmBodyLoadDataType(eData)             (eData->loadType)
#define elmBodyLoadDataActive(eData)           (eData->active)
#define elmBodyLoadDataNumValues(eData)        (eData->numValues)

#define elmBodyLoadDataValuesPtr(eData)        (eData->values)
#define elmBodyLoadDataValuesVec(eData,i)      (eData->values[i])

#define elmBodyLoadDataNextLoadPtr(eData)      (eData->nextLoad)

