/* sid 50.1 copy of FEM_mqMapable.h last changed by upd111 on 2004/11/04 18:31:30 */

/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 1999 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_mqMapable.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_mqMapable.h
 *  header file for FEM_mqMapable.c
 *
 */
#ifndef FEM_MQMAPABLE_INCLUDE
#define FEM_MQMAPABLE_INCLUDE

/*----------------- Globally accessible function prototypes -----------------*/

#ifdef __cplusplus
extern "C" {
#endif

                      /* ==================================================== */
                      /* === FEM_mqIsAreaMapable: given an area determine if  */
                      /* === it can be mapped or sub-mapped meshed.           */
                      /* === Return: EXIT_SUCCESS or EXIT_FAILURE             */
                      /* ==================================================== */
INT FEM_mqIsAreaMapable(
   INT area,          /* (IN)  area to map mesh                               */
   FEM_BOOLEAN *mappable,/*(OUT)TRUE or FALSE.                                */
   INT **a_kps,       /* (OUT) list of keypoint ids on this area.             */
   INT *num_areakps,  /* (OUT) number of keypoints on this area.              */
   INT **a_kpstat,    /* (OUT) array parallel to a_kps saying stat of each kp */
                      /*       i.e. if it is a END, CORNER, REVERSAL, or SIDE */
                      /*       Not returned if sent in as null.               */
   DOUBLE **a_kpang );/* (OUT) array parallel to a_kps saying angle at each kp*/
                      /*       Not returned if sent in as null.               */

                      /* ==================================================== */
                      /* === FEM_mqIsGeometryMappable: Given an area,         */
                      /* === determine if it is mappable by looking at        */
                      /* === precalculated angles and characteristics.        */
                      /* === Return: EXIT_SUCCESS or EXIT_FAILURE             */
                      /* ==================================================== */
INT FEM_mqTestMapByAngClass(
   INT area,                 /* (IN)  the area to check. */
   INT num_areakps,          /* (IN)  number of kps on this area. */
   INT num_ends,             /* (IN)  The number of ENDS on this area. */
   INT num_reversals,        /* (IN)  The number of REVERSALS on this area. */
   INT num_corners,          /* (IN)  The number of CORNERS on this area. */
   DOUBLE *a_kpangles,       /* (IN)  angles at kps on this area. */
   FEM_BOOLEAN *mappable );  /* (OUT) TRUE or FALSE. */

#ifdef __cplusplus
}
#endif

#endif

