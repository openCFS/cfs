/* sid 50.1 copy of changestr.h last changed by upd111 on 2005/06/04 13:14:12 */
/***********************************************************************\
 *                                                                     *
 *  changeStr.h       March 6, 1995                                    *
 *                                                                     *
 *  Header file for changeStr.c                                        *
 *                                                                     *
\***********************************************************************/
/* 
 * *** ansys(r) copyright(c) 2000
 * *** ansys, inc.
 */

 //  Prototypes  //

BOOL changeStr ( CHAR [], CHAR [], CHAR [] );
