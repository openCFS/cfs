/* sid 50.1 copy of nodeResulttypes.h last changed by upd111 on 2005/06/04 13:22:03 */

#include "ansysdef.h"

/****************************************************************
 data-level structure for ANSYS nodal results
 ****************************************************************/
struct nodeResult_str {     /* Name of the structure                                      */
  resultDispData   *disp;   /* Pointer to the first calculated displacement on this node  */
  resultForceData  *force;  /* Pointer to the first calculated force on this node         */
                            /* If either the disp or force pointer is NULL that means     */
                            /* this node has no result displacements or forces (or both)  */
};

#define nodeResultDispPtr(nresult)        (nresult->disp)
#define nodeResultForcePtr(nresult)       (nresult->force)

