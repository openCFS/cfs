/* sid 50.1 copy of mem.h last changed by upd111 on 2005/06/04 13:13:14 */
/* 
 * *** ansys(r) copyright(c) 2000
 * *** ansys, inc.
 */
#define MEM_


#ifdef SPARC
#define mem_Zero(Dest, Length) bzero(Dest, Length)
#define mem_Copy(Src, Dest, Length) bcopy(Src, Dest, Length)
#define mem_Compare(Src, Dest, Length) memcmp(Src, Dest, Length)
#else
#define mem_Zero(Dest, Length) memset(Dest, 0, (INT32) Length)
#define mem_Copy(Src, Dest, Length) memcpy(Dest, Src, Length)
#define mem_Compare(Src, Dest, Length) memcmp(Src, Dest, Length)
#endif

