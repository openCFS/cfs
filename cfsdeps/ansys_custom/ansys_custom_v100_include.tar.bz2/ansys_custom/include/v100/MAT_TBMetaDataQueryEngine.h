/* sid 50.3 copy of MAT_TBMetaDataQueryEngine.h last changed by rjayasee on 2005/03/11 19:16:11 */

/*
////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         Copyright (C) 2001 ANSYS Inc.  All Rights Reserved             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MAT_TBMetaDataQueryEngine.h $
// $Revision$ 7.0
// $Date$ Feb 9 2005
// $Author$ rjayasee
//
// Decription :
//
//	Query Information about TB Material Data
//
//////////////////////////////////////////////////////////////////////////////
*/

#if !defined(MAT_TBMetaDataQueryEngine_H)
#define MAT_TBMetaDataQueryEngine_H

#include "ANS_StandardIncludes.h"

typedef map<INT,ANS_String> MAT_StringIntMap;
typedef MAT_StringIntMap::iterator MAT_StringIntMapIter ;
typedef map<ANS_String,MAT_StringIntMap*> MAT_TbOptStringMap;
typedef MAT_TbOptStringMap::iterator MAT_TbOptStringMapIter ;
typedef MAT_TbOptStringMap::value_type MAT_TbOptStringMapVT ;
class MAT_TBMetaDataQueryEngine
{
    public:

        static MAT_TBMetaDataQueryEngine* Instance() ;
        //Singleton

        static void Destroy() ;
        //Singleton

        // INT GetTbOpt( ANS_String& oClassOfMat, ANS_String& oTbOptName ) const;

        ANS_String GetTbOptName( ANS_String& oClassOfMat, INT& iTbOpt) const;
        //R String
        //I oClassOfMat
        //I iTbOpt
        //- Return the string associated with the tbopt

        INT GetOrderGivenNumCoeffs( ANS_String oClassOfMat, INT iTbOpt, INT iNumCoeffs) const;
        //R String
        //I oClassOfMat
        //I iTbOpt
        //- Return the order associated with the tbopt


        bool IsSupportedClass( ANS_String oClassName) ;
        //R
        //I oClassName
        //I-Name of the class of materials
        //- Is supported class of materials

    protected:

        MAT_TBMetaDataQueryEngine();
        //Constructor

        ~MAT_TBMetaDataQueryEngine();
        //Destructor

        void Initialize() ;
        //Initializing Classes

        bool AddNewMaterialClass(ANS_String oClass) ;
        //R Result
        //I oClassName

        bool AddTbOptForMaterialClass(ANS_String oClass, INT iTbOpt, ANS_String oTbOptName) ;
        //R Result
        //I oClassName
        //I-Class of Material
        //I iTbOpt
        //I-Id of tbopt
        //I oTbOptName
        //I-String Attached to the TbOpt

        static MAT_TBMetaDataQueryEngine* m_pMAT_TBMetaDataQueryEngine ;
        //Static object

        MAT_TbOptStringMap* m_pMaterialMetaData ;
} ;

#endif
