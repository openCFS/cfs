/* sid 50.1 copy of FEM_BJMetric.h last changed by upd111 on 2004/11/04 18:29:33 */
#ifndef __FEM_BJMetrics_H__
#define __FEM_BJMetrics_H__

#ifdef __cplusplus
extern "C" {
#endif
double MeasTet(int mtype, const double a[], const double b[],
   const double c[], const double d[]) ;

double MeasWedg(int mtype, const double a[], const double b[],
   const double c[], const double d[], const double e[], const double f[],
   double tol) ;

double MeasHex(int mtype, const double a[], const double b[],
   const double c[], const double d[], const double e[], const double f[],
   const double g[], const double h[], double tol);
void JacHex(const double a[], const double b[], const double c[],
   const double d[], const double e[], const double f[], const double g[],
   const double h[], double *pmindet, double *pmaxdet) ;

void JacWedg(const double a[], const double b[], const double c[],
   const double d[], const double e[], const double f[], double *pmindet,
   double *pmaxdet) ;

#ifdef __cplusplus
}
#endif
#endif
