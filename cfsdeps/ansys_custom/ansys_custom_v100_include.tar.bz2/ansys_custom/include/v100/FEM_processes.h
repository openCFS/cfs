/* sid 50.1 copy of FEM_processes.h last changed by upd111 on 2004/11/04 18:31:52 */

/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 1999 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_processes.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_processes.h
 *  Prototypes and macros available in the C meshing database.
 *
 */

#ifndef FEM_PROCESSES_INCLUDE
#define FEM_PROCESSES_INCLUDE

#include "FEM_cdbtypes.h"

                             /* ============================================ */
                             /* === FEM_MarkNodesForRefinement: mark the     */
                             /* === nodes that will be involved in           */
                             /* === refinement. This must be before calling  */
                             /* === FEM_reDoRefinement.                      */
                             /* === Return: 0 if successful, otherwise 1     */
                             /* ============================================ */
INT FEM_MarkNodesForRefinement (
   INT *a_nodes,             /* (IN)  array of nodes to refine about         */
   INT num_nodes,            /* (IN)  number of nodes in a_nodes             */
   INT numlevels,            /* (IN)  number of levels to refine             */
   INT *num_marked  );       /* (OUT) return number of nodes marked          */
                             /* ============================================ */

                             /* ============================================ */
                             /* === FEM_Refinement:  Main entry point        */
                             /* === for refinement.  Whatever mesh that      */
                             /* === exists in the C meshing database is      */
                             /* === refined.  Before calling this routine, 2 */
                             /* === things must be done:                     */
                             /* ===    1.  The MeshToolBox must be           */
                             /* ===        filled with a mesh containing     */
                             /* ===        face and/or volume elements.      */
                             /* ===    2.  Nodes must be marked where        */
                             /* ===        refinement is desired. To mark    */
                             /* ===        nodes, call                       */
                             /* ===        FEM_MarkNodesForRefinement().     */
                             /* === Return: 0 if successful, otherwise 1     */
                             /* ============================================ */
INT FEM_Refinement (
   INT *num_marked,          /* (IN/OUT) number of nodes in mesh that are    */
                             /*          marked                              */
   INT algorithm,            /* (IN) THREE_REF or TWO_REF                    */
   INT *a_areas,             /* (IN) array of area ids which contain face    */
                             /*      elements being refined.                 */
   INT num_areas,            /* (IN) length of a_areas.                      */
   FEM_BOOLEAN detached,     /* (IN) if elements are detached from geometry. */
                             /*      if detached == TRUE, new nodes are      */
                             /*      projected to geometry.                  */
   FEM_BOOLEAN midnodes,     /* (IN) TRUE if refining quadratic elements     */
   FEM_BOOLEAN smooth,       /* (IN) TRUE if smoothing should be done after  */
                             /*       refinement                             */
   FEM_BOOLEAN cleanup,      /* (IN) TRUE if topological cleanup should be   */
                             /*      done after refinement.  If this is      */
                             /*      TRUE, then smooth is ignored and        */
                             /*      smoothing is always performed.          */
   FEM_BOOLEAN quadsplit,    /* (IN) TRUE if poorquads should be split into  */
                             /*      2 tris rather than keep a poor quad.    */
   DOUBLE tolerance,         /* (IN) tolerance for smoothing.  Required if   */
                             /*      either smooth == TRUE or cleanup == TRUE*/
   FEM_BOOLEAN usetarget,    /* (IN) TRUE if targetsize is used for          */
                             /*      termination, otherwise, use num_iters   */
   FEM_BOOLEAN retain,       /* (IN) TRUE if quads must maintained.          */
   INT num_iters,            /* (IN) number of iterations or refinement,     */
                             /*      this is only used if                    */
                             /*      usetarget == FALSE.                     */
   DOUBLE targetsize  );     /* (IN) targetsize of elements in refinement    */
                             /*      region.  This is only used if           */
                             /*      usetarget == TRUE.                      */
                             /* ============================================ */
#define TWO_REF   0
#define THREE_REF 1


                             /* ============================================ */
                             /* === FEM_SurfProxRefinement: Perform          */
                             /* === refinement on a tri mesh based on facet  */
                             /* === to facet proximity.  This assumes that   */
                             /* === the MeshToolBox is set up with triangle  */
                             /* === face elements only.  Unlike              */
                             /* === FEM_Refinement, you do not need to call  */
                             /* === FEM_MarkNodesForRefinement.              */
                             /* === FEM_SurfProxRefinement determines where  */
                             /* === refinement is needed and does it without */
                             /* === requiring nodes to be marked.  Cleanup   */
                             /* === and smoothing is automatically performed */
                             /* === on the mesh after refinement so there is */
                             /* === no need for the user to do so also.      */
                             /* === Return: 0 if successful, otherwise 1     */
                             /* ============================================ */
INT FEM_SurfProxRefinement (
   DOUBLE growth_ratio,      /* (IN)  max allowable growth ratio             */
   DOUBLE minesize,          /* (IN)  minimum edge length size.  Refinement  */
                             /*       will not create any edge smallet than  */
                             /*       this size.                             */
   INT *a_refineableareas,   /* (IN)  array of areas that can be refined on  */
   INT num_refineableareas,  /* (IN)  length of a_refineableareas            */
   INT *a_refineablelines,   /* (IN)  array of lines that can be refined on  */
   INT num_refineablelines,  /* (IN)  length of a_refineablelines            */
   INT *a_refineablekps,     /* (IN)  array of lines that can be refined on  */
   INT num_refineablekps,    /* (IN)  length of a_refineablekps              */
   INT midnodes,             /* (IN)  True if midnodes exist                 */
   INT *abort  );            /* (OUT) !0 if user requests abort              */
                             /* ============================================ */

                             /* ============================================ */
                             /* === FEM_QuadTopoCleanUp: Perform             */
                             /* === topological cleanup on a quad dominant   */
                             /* === mesh.  Cleanup is performed to optimize  */
                             /* === node valence.  Smoothing may be          */
                             /* === performed during the cleanup procedure   */
                             /* === to avoid creating inverted elements,     */
                             /* === however, smoothing should be called      */
                             /* === after cleanup is done to improve         */
                             /* === elements more.                           */
                             /* ===                                          */
                             /* === NOTE: Cleanup is an iterative proceedure */
                             /* === and continues until a specified number   */
                             /* === of iterations are performed or until     */
                             /* === equilibrium is achieved. The maximum     */
                             /* === number of iterations is defined by       */
                             /* === FEM_glSetMaxCleanUpLoops_C() which should*/
                             /* === be called in FEMe_SetParameters()        */
                             /* ===                                          */
                             /* === ALSO: Cleanup cannot be performed on a   */
                             /* === mesh that is detached from any solid     */
                             /* === model associativity.                     */
                             /* ===                                          */
                             /* === Return: 0 if successful, otherwise 1     */
                             /* ============================================ */
INT FEM_QuadTopoCleanUp (
   INT area,                 /* (IN)  the id of the area that is to be       */
                             /*       cleaned up                             */
   INT midnodes,             /* (IN)  1 if area has midnodes on elements,    */
                             /*       otherwise 0                            */
   DOUBLE tolerance,         /* (IN)  tolerance for smoothing                */
   INT *cleanedup  );        /* (OUT) returned as 1 if the mesh was changed. */
                             /*       returned as 0 if no changes are made.  */
                             /* ============================================ */

                             /* ============================================ */
                             /* === FEM_QuadQualCleanUp:  Perform quality    */
                             /* === based cleanup on a quad dominant mesh.   */
                             /* === Cleanup is performed to optimize corner  */
                             /* === angles.  Smoothing may be                */
                             /* === performed during the cleanup procedure   */
                             /* === to avoid creating inverted elements,     */
                             /* === however, smoothing should be called      */
                             /* === after cleanup is done to improve         */
                             /* === elements more.  For best results,        */
                             /* === call FEM_clQuadTopoCleanUp first         */
                             /* === followed by a few (2) iterations of      */
                             /* === smoothing (FEM_SmoothArea) before calling*/
                             /* === FEM_QuadQualCleanUp.  And of course      */
                             /* === follow the call to FEM_QuadQualCleanUp   */
                             /* === with another call to the smoother.       */
                             /* ===                                          */
                             /* === NOTE: Unlike topological cleanup,        */
                             /* === this quality cleanup is not iterative.   */
                             /* === only one iteration is performed          */
                             /* === regardless of the return value from      */
                             /* === FEMe_SetParameters()                     */
                             /* ===                                          */
                             /* === ALSO: Cleanup cannot be performed on a   */
                             /* === mesh that is detached from any solid     */
                             /* === model associativity.                     */
                             /* ===                                          */
                             /* === Return: 0 if successful, otherwise 1     */
                             /* ============================================ */
INT FEM_QuadQualCleanUp (
   INT area,                 /* (IN)  the id of the area that is to be       */
                             /*       cleaned up                             */
   INT midnodes,             /* (IN)  1 if area has midnodes on elements,    */
                             /*       otherwise 0                            */
   INT *cleanedup  );        /* (OUT) returned as 1 if the mesh was changed. */
                             /*       returned as 0 if no changes are made.  */
                             /* ============================================ */

                             /* ============================================ */
                             /* === FEM_TriTopoCleanUp: Perform topological  */
                             /* === cleanup on a triangle mesh.  Cleanup is  */
                             /* === performed to optimize node valence.      */
                             /* === Smoothing is may performed during the    */
                             /* === cleanup procedure to avoid creating      */
                             /* === inverted elements, however, smoothing    */
                             /* === should be called after cleanup is done   */
                             /* === to improve elements more.                */
                             /* === Return: 0 if successful, otherwise 1     */
                             /* ============================================ */
INT FEM_TriTopoCleanUp (
   INT anum,                 /* (IN) area to clean up                        */
   FEM_BOOLEAN midnodes,     /* (IN) TRUE if midnodes exist.                 */
   INT shape,                /* (IN) if shape = 3, the mesh is a tri mesh.   */
                             /*          If midnodes == TRUE, then corner    */
                             /*          with angles greater than 45 degrees */
                             /*          will be split into 2 triangles.  If */
                             /*          midnodes == FALSE, corner with      */
                             /*          angles greater than 15 degress will */
                             /*          be split into 2 triangles.          */
                             /*      if shape = 4, the mesh is a tri mesh    */
                             /*          that will eventually get converted  */
                             /*          into a quad mesh.  In this case,    */
                             /*          corners are not split into 2        */
                             /*          triangles.                          */
   INT maxloop  );           /* (IN) max number of cleanup iterations        */
                             /* ============================================ */

                             /* ============================================ */
                             /* === FEM_TetCleanUp: Perform Cleanup on an    */
                             /* === tet mesh by doing swaps and combination  */
                             /* === flips.  The MeshToolBox can contain non- */
                             /* === tet elements but improvement will only   */
                             /* === affect the tet elements.  Swaps and flips*/
                             /* === are based on local empty circumsphere    */
                             /* === criterion or local max-min tetrahedron   */
                             /* === shape measure criterion.  For best       */
                             /* === results, you should call FEM_VolumeSmooth*/
                             /* === to adjust nodes after the swapping and   */
                             /* === flipping.                                */
                             /* === Return: 0 if successful, otherwise 1     */
                             /* ============================================ */
INT FEM_TetCleanUp (
   INT vnum,                 /* (IN)  volume number                          */
   FEM_BOOLEAN bndcon,       /* (IN)  1 if boundary is constrained to not    */
                             /*       change.                                */
   FEM_BOOLEAN combfl,       /* (IN)  1 if combination of flips are to be    */
                             /*       applied to improve triangulation       */
                             /*       further                                */
   INT mtype,                /* (IN)  measure type used to determine if swap */
                             /*       or flip should be done (0 to 6).       */
                             /*                                              */
                             /*          0: Constrained delaunay criteria.   */
                             /*             For linear or quadratic tets.    */
                             /*                                              */
                             /*          1: Minimum solid angle criteria.    */
                             /*             For linear or quadratic tets.    */
                             /*                                              */
                             /*          2: Radius ratio criteria.           */
                             /*             For linear or quadratic tets.    */
                             /*                                              */
                             /*          3: Mean ratio criteria.             */
                             /*             For linear or quadratic tets.    */
                             /*                                              */
                             /*          4: Quadratic mean ratio criteria.   */
                             /*             For quadratic tets only.         */
                             /*                                              */
                             /*          5: Maximum face angle criteria.     */
                             /*             For linear or quadratic tets.    */
                             /*                                              */
                             /*          6: Quadratic Maximum face angle     */
                             /*             criteria.  For quadratic tets    */
                             /*             only.                            */
                             /*                                              */
   FEM_BOOLEAN midnode,      /* (IN)  1 iff quadratic elements exist.        */
   INT nexpass,              /* (IN)  number of expensive passes for         */
                             /*       combination flips when mtype > 0.      */
                             /*       After nexpass passes, combination      */
                             /*       flips are only used to remove tets     */
                             /*       with measure < minratio.               */
   DOUBLE minratio,          /* (IN)  ratio < minratio considered poorly     */
                             /*       shaped (not used for mtype 0)          */
   FEM_BOOLEAN *abort  );    /* (OUT) return 1 (with successful exit) if     */
                             /*       user abort occurred                    */
                             /* ============================================ */

                             /* ============================================ */
                             /* === FEM_TryUninvertQuadTets: Un-invert any   */
                             /* === quadratic tets in the MeshToolBox by     */
                             /* === adjusting midnode locations.  If no      */
                             /* === inverted elements exist or no midnodes   */
                             /* === This routine should only be called if    */
                             /* === FEM_TetCleanUp was called and inverted   */
                             /* === tets remained.                           */
                             /* === Return: 0 if successful, otherwise 1     */
                             /* ============================================ */
INT FEM_TryUninvertQuadTets (
   INT mtype,                /* (IN)  quadratic measure type (see header for */
                             /*       FEM_TetCleanUp()                       */
   FEM_BOOLEAN change_bound, /* (IN)  1 if boundary can be modified          */
   FEM_BOOLEAN msg_on,       /* (IN)  1 if error message displayed for       */
                             /*       inverted tets that cannot be           */
                             /*       un-inverted                            */
   INT *ninvtet,             /* (OUT) return number of inverted tets found   */
   INT *nmidmov_ncb  );      /* (OUT) return count of midnode moves on       */
                             /*       non-changeable boundary parts          */
                             /* ============================================ */

                             /* ============================================ */
                             /* === FEM_TryRemovePoorTets: Try to remove     */
                             /* === poorly shaped tetrahedra by inserting    */
                             /* === nodes on long edges and applying simple  */
                             /* === flips to nearby transformable interior   */
                             /* === faces, based on local max-min tet shape  */
                             /* === measure criterion.  If midnodes exist,   */
                             /* === first try to perturb midnodes.           */
                             /* ============================================ */
INT FEM_TryRemovePoorTets (
   FEM_BOOLEAN bndcon,       /* (IN)  1 if boundary is constrained           */
   INT mtype,                /* (IN)  measure type (1 to 6) (See header to   */
                             /*       FEM_TetCleanUp).                       */
   DOUBLE minmeas,           /* (IN)  tets with shape measure < minmeas are  */
                             /*       considered poorly shaped               */
   FEM_BOOLEAN midnode  );   /* (IN)  1 iff quadratic elements               */
                             /* ============================================ */

                             /* ============================================ */
                             /* === FEM_AreaSmooth: Do smoothing on areas    */
                             /* === Return: 0 if successful, otherwise 1     */
                             /* ============================================ */
INT FEM_SmoothArea (
   INT num_iterations,       /* (IN)  number of iterations to smooth         */
   DOUBLE tolerance,         /* (IN)  distance node must move before it is   */
                             /*       repositioned                           */
   INT line_smoothing,       /* (IN)  0 = no line smoothing                  */
                             /*       1 = optimization based line smoothing  */
   INT high_curv,            /* (IN)  flag = to indicate that area has high  */
                             /*       curvature and to do extra checking to  */
                             /*       make sure a max spanning angle is not  */
                             /*       violated.                              */
   DOUBLE max_angle,         /* (IN)  max spanning angle (used only if       */
                             /*       high_curv == 1)                        */
   FEM_BOOLEAN do_progress  );/* (IN)  TRUE if progress bar should be updated.*/
                             /* ============================================= */

                             /* ============================================ */
                             /* === FEM_VolumeSmooth: apply constrained      */
                             /* === Laplacian smoothing to movable           */
                             /* === (interior) vertices of the tet mesh in   */
                             /* === the MeshToolBox.  optimization-based     */
                             /* === moves may be attempted for some vertices */
                             /* === depending on shape measures              */
                             /* === Return: 0 if successful, otherwise 1     */
                             /* ============================================ */
INT FEM_VolumeSmooth (
   INT npass,                /* (IN)  maximum number of smoothing passes.    */
                             /*       actual number of passes may be fewer   */
                             /*       if no vertices moved in a pass         */
   INT mtype,                /* (IN)  measure type used to determine if      */
                             /*       smooth should be done (1 to 6).        */
                             /*                                              */
                             /*          1: Minimum solid angle criteria.    */
                             /*             For linear or quadratic tets.    */
                             /*                                              */
                             /*          2: Radius ratio criteria.           */
                             /*             For linear or quadratic tets.    */
                             /*                                              */
                             /*          3: Mean ratio criteria.             */
                             /*             For linear or quadratic tets.    */
                             /*                                              */
                             /*          4: Quadratic mean ratio criteria.   */
                             /*             For quadratic tets only.         */
                             /*                                              */
                             /*          5: Maximum face angle criteria.     */
                             /*             For linear or quadratic tets.    */
                             /*                                              */
                             /*          6: Quadratic Maximum face angle     */
                             /*             criteria.  For quadratic tets    */
                             /*             only.                            */
                             /*                                              */
   DOUBLE mtmov,             /* (IN)  vertex is moved if min(measures of     */
                             /*       new tets incident on vertex) >         */
                             /*       min(measures of old tets, mtmov) +     */
                             /*       movtol; so if mtmov >= 1.0, movement   */
                             /*       occurs only if worst tet is improved   */
   DOUBLE movtol,            /* (IN)  tolerance that measures must improve   */
                             /*       by in order to move vertex (see above) */
   DOUBLE mtopt,             /* (IN)  max tet measure for which              */
                             /*       optimization-based smoothing is        */
                             /*       applied to move vertex; if             */
                             /*       mtopt > 1.0 (and pass# <= nexpass),    */
                             /*       then optimization move is always       */
                             /*       attempted; if mtopt <= 0.0, then no    */
                             /*       optimization move is attempted         */
                             /*       (assuming no inverted tets)            */
   INT nexpass,              /* (IN)  number of expensive passes for which   */
                             /*       opt-based smoothing may be applied     */
   FEM_BOOLEAN *abort  );    /* (OUT) return 1 if user abort occurred        */
                             /* ============================================ */

                             /* ============================================ */
                             /* === FEM_MapTriMesh: Assuming the MeshToolBox */
                             /* === is filled with a quadrilateral mesh with */
                             /* === no volume elements, convert the mesh     */
                             /* === into a tri mesh by splitting all the     */
                             /* === quads according to a particular pattern. */
                             /* === Return: 0 if successful, otherwise 1     */
                             /* ============================================ */
INT FEM_MapTriMesh (
   INT pattern  );           /* (IN) map mesh pattern                        */
                             /*      0 maximize minimum angle                */
                             /*      1 unidirectional TR BL                  */
                             /*      2 unidirectional TL BR                  */
                             /* ============================================ */

                             /* ============================================ */
                             /* === FEM_SplitPoorQuads: Look at all quads in */
                             /* === the MeshToolBox and split any poor quads */
                             /* === into 2 triangles.  Quads are determined  */
                             /* === to be poor by FEMe_CheckForSplit which   */
                             /* === must be written by you, the user of the  */
                             /* === MeshToolBox.  Quads adjacent to a volume */
                             /* === will not be split even if they are       */
                             /* === poorly shaped.                           */
                             /* === Return: 0 if successful, otherwise 1     */
                             /* ============================================ */
INT FEM_SplitPoorQuads (
   INT *quads_split  );      /* (OUT) returned as TRUE if any quads were     */
                             /*       split.                                 */
                             /* ============================================ */

                             /* ============================================ */
                             /* === FEM_HexToTet: Assuming the MeshToolBox   */
                             /* === was initialized with tetrahedral with    */
                             /* === solid model attachment, create pyramids  */
                             /* === on a list of areas to transition away    */
                             /* === from quads or hexes also adjacent to the */
                             /* === area.                                    */
                             /* === Return: 0 if successful, otherwise 1     */
                             /* ============================================ */
INT FEM_HexToTet (
   INT vnum,                 /* (IN)  The volume number                      */
   INT num_areas,            /* (IN)  number of areas on vnum to create      */
                             /*       pyramids on if necessary.              */
   INT *a_areas,             /* (IN)  array of areas on vnum to create       */
                             /*       pyramids on if necessary.              */
   INT midnodes,             /* (IN)  1 if midnodes exist, otherwise 0.      */
   INT open_pyramid,         /* (IN)  flag indicating which method to use to */
                             /*       create the pyramids:                   */
                             /*          0 : use swapping when possible, and */
                             /*              pyramid open method when        */
                             /*              swapping is not possible.       */
                             /*         !0 : use the open pyramid method     */
                             /*              always                          */
   INT *num_pyrs_created  ); /* (OUT) return number of pyramids created      */
                             /* ============================================ */

                             /* ============================================ */
                             /* === FEM_HexToPyr: Convert an all hex mesh    */
                             /* === into an all-pyramid mesh.  This assumes  */
                             /* === that the MeshToolBox only has hex elems  */
                             /* === If any other volume elem is encountered, */
                             /* === an error value will be returned.         */
                             /* === Return: 0 if successful, otherwise 1     */
                             /* ============================================ */
INT FEM_HexToPyramids (
   INT midnodes  );          /* (IN)  1 if midnodes exist, otherwise 0.      */
                             /* ============================================ */

                             /* ============================================ */
                             /* === FEM_MeshArea:  Given a list of boundary  */
                             /* === nodes, mesh the area with triangle area  */
                             /* === elements.                                */
                             /* === Return: 0 if successful, otherwise 1     */
                             /* ============================================ */
INT FEM_MeshArea (
   INT anum,                 /* (IN)  the area to mesh                       */
   INT numbound,             /* (IN)  number of boundary nodes on all loops  */
                             /*       (length of a_ibound)                   */
   INT *a_loops_begin,       /* (IN)  array of indices into a_ibound showing */
                             /*       what nodes begin each loop.            */
   INT *a_loops_end,         /* (IN)  array of indices into a_ibound showing */
                             /*       what nodes end each loop.              */
   INT num_loops,            /* (IN)  number of loops (length of             */
                             /*       a_loops_begin and a_loop_end.          */
   INT *a_ibound  );         /* (IN)  array of ordered node ids defining     */
                             /*       boundary segments.                     */
                             /* ============================================ */

                             /* ============================================ */
                             /* === FEM_QuadConversion:  Take an existing tri*/
                             /* === mesh and convert it into a quad mesh     */
                             /* === Assumes that the tri mesh is not attached*/
                             /* === to any volume elements (i.e. tets, etc.) */
                             /* === Return: 0 if successful, otherwise 1     */
                             /* ============================================ */
INT FEM_QuadConversion (
   INT anum  );              /* (IN)  the area containing the tri mesh.      */
                             /* ============================================ */
#endif

