/* sid 50.1 copy of FxOut.h last changed by upd111 on 2005/06/04 13:21:07 */
/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 2002                                         */
/* *** ansys, inc.                                                        */
/* ---------------------------------------------------------------------- */
/*
 *    author/date: Stefan Reh  2002-02-06
 *
 *    primary function:
 *
 *        header for prototype definitions in ANSI C
 *
 *    Notice - This file contains ANSYS Confidential information ***
 *
 */

#ifndef _FX_OUT_H_
#define _FX_OUT_H_

extern int     PutFxOutSettings ( char cName[], char cType[], char cComp[], double dAccuracy, int iNumElems, int iElemList[] );
extern double FxGetAccuracy(void);

#endif /* _FX_OUT_H_ */
