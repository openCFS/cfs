/* sid 50.1 copy of AnsysDom.h last changed by upd111 on 2005/06/04 13:18:40 */

/* *** ansys(r) copyright(c) 2000
 * *** ansys, inc.
 */

#ifndef _ANSYS_DOM_H_
#define _ANSYS_DOM_H_

#include <stdio.h>

#include "Domain.h"
#include "dofset.h"

class SkyMatrix;
class DecDomain;
class FetiSolver;

class AnsysDom : public Domain {
        
        int dofsPerNode;
        double *bcx;
        SkyMatrix *sysMat;

// The decomposed domain for FETI
        DecDomain *decDom;
        FetiSolver *solver;

   public:
        AnsysDom(int nele, int nnodes, int dpn);

        int addNeuman(int node, int dof, double v);
        int addDirichlet(int node, int dof, double v);
        int addNode(int nd, double xyz[3]);
        int addElem(int en, Element *ele);

        void getDecomp(FILE *f);
        void getDecomp(int *);
        void makeSubD();
        void getDomainConnect();
        void distributeBCs();
        void distributeBCsHelm();
        void makeInterface();
        void staticSolve();
        int addK(int iele, double *k, int ldk, double *load);
        void assembleSky();
        void solve(int len, double *f, double *u);
        void solve(int len, double *f, double *u, int *eorder);

     void setupData();
     void dumpTopFile(FILE *outfile);
     void dumpFemFile(FILE *outfile);
     void prepSystem();
};

#define MAXNNODES 32

class AnsysElement : public Element {
   int eleNum;
   int type;
   int numnodes;
   int nd[MAXNNODES];
   DofSet dofFlags;
 public:
   AnsysElement(int iele, int _type, int nnodes, int *nodes, int dofFlags);
   // FullSquareMatrix stiffness(double *v, double *f);
   void renum(int *);

   int    numDofs();
   void   markDofs(DofSetArray &);
   int*   dofs(DofSetArray &, int *p=0);

   int    numNodes();
   int*   nodes(int * = 0);
   void dumpTop(FILE *outFile);
   int buffer(int *);
};

class AnsysLineContact: public Element {
   int eleNum;
   int nd[2];
 public:
   AnsysLineContact(int iele, int *nodes);

   int    numNodes();
   int*   nodes(int * = 0);
};

class AnsysNodeContact: public Element {
    int eleNum;
    int nd;
 public:
   AnsysNodeContact(int iele, int *nodes);

   int    numNodes();
   int*   nodes(int * = 0);
};

class AnsysBar2: public Element {
   int eleNum;
   int nd[2];
 public:
   AnsysBar2(int iele, int *nodes);
   void renum(int *);
   // FullSquareMatrix stiffness(double *v, double *f);
   int    numDofs();
   void   markDofs(DofSetArray &);
   int*   dofs(DofSetArray &, int *p=0);

   int    numNodes();
   int*   nodes(int * = 0);
   void dumpTop(FILE *outFile);
};

class AnsysQuad4: public Element {
   int eleNum;
   int nd[4];
 public:
   AnsysQuad4(int iele, int *nodes);
   int    numDofs();
   void   markDofs(DofSetArray &);
   int*   dofs(DofSetArray &, int *p=0);

   void renum(int *);
   // FullSquareMatrix stiffness(double *v, double *f);
   int    numNodes();
   int*   nodes(int * = 0);
   void dumpTop(FILE *outFile);
   int facelist(PolygonSet &, int * = 0);
};

class AnsysCube8: public Element {
   int eleNum;
   int nd[8];
 public:
   AnsysCube8(int iele, int *nodes);
   int    numDofs();
   void   markDofs(DofSetArray &);
   int*   dofs(DofSetArray &, int *p=0);

   void renum(int *);
   // FullSquareMatrix stiffness(double *v, double *f);
   int    numNodes();
   int*   nodes(int * = 0);
   void dumpTop(FILE *outFile);
   int facelist(PolygonSet &, int * = 0);
};

class AnsysTri3: public Element {
   int eleNum;
   int nd[3];
 public:
   AnsysTri3(int iele, int *nodes);
   void renum(int *);
   // FullSquareMatrix stiffness(double *v, double *f);
   int    numDofs();
   void   markDofs(DofSetArray &);
   int*   dofs(DofSetArray &, int *p=0);

   int    numNodes();
   int*   nodes(int * = 0);
   void dumpTop(FILE *outFile);
   int facelist(PolygonSet &, int * = 0);
};

class AnsysTetra: public Element {
   int eleNum;
   int nd[4];
 public:
   AnsysTetra(int iele, int *nodes);
   void renum(int *);
   int    numDofs();
   void   markDofs(DofSetArray &);
   int*   dofs(DofSetArray &, int *p=0);

   int    numNodes();
   int*   nodes(int * = 0);
   // FullSquareMatrix stiffness(double *v, double *f);
   void dumpTop(FILE *outFile);
   int facelist(PolygonSet &, int * = 0);
};

/*
class AnsysE16: public Element {
   int eleNum;
   int nd[4];
 public:
   AnsysE16(int iele, int *nodes);
   void renum(int *);
   int    numNodes();
   int*   nodes(int * = 0);
};

class AnsysQuad9: public Element {
   int eleNum;
   int nd[4];
 public:
   AnsysQuad9(int iele, int *nodes);
   void renum(int *);
   int    numNodes();
   int*   nodes(int * = 0);
};

class AnsysTri6: public Element {
   int eleNum;
   int nd[4];
 public:
   AnsysTri6(int iele, int *nodes);
   void renum(int *);
   int    numNodes();
   int*   nodes(int * = 0);
};

class AnsysCube20 public Element {
   int eleNum;
   int nd[4];
 public:
   AnsysCube20int iele, int *nodes);
   void renum(int *);
   int    numNodes();
   int*   nodes(int * = 0);
};
*/

#define AnsysQuad9 AnsysQuad4
#define AnsysTri6 AnsysTri3
#define AnsysCube20 AnsysCube8

#endif
