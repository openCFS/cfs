/* sid 50.16 copy of sx_cons_solver.h last changed by smarguer on 2005/04/27 12:34:39 */
/* CADOE */
/*******************************************************************************
 *
 *   cons_solver.h -- constantes nbbva
 *              
 * 
 * |Module: solveur / interface
 *
 * |Description: constantes nbbva
 *
 * |Includes:	
 *        
 * |Auteur: Jean-Daniel Beley
 *
 * |Creation: Avril 1999 - Avril 2002 Ajout des elements ANSYS.
 *
 * |Version: $Id$
 *
 * |Copyright:	Copyright(c) CADOE 2002
 *
 ******************************************************************************/
#ifndef __CONS_SOLVER_H__
#define __CONS_SOLVER_H__ 1

#ifdef VAN
/* #include "stbinc/fesprm.h" */
#endif

/*
 *------------------------- OBJET ELEMENT --------------------------
 */

/*
 *-------------------- attribut type geometrique -----------------
 */ 
/* Solveur SDRC VA */

/* Rod	                                             */
#define nbbel_ROD       1  		

/* Linear beam                                       */
#define nbbel_LBEAM     2		

/* Tapered beam                                      */
#define nbbel_TBEAM     6		

/* Curved beam                                       */
#define nbbel_CBEAM     7		

/* Parabolic beam                                    */
#define nbbel_PBEAM     3		

/* Plane Stress Linear Triangle                      */
#define nbbel_PSSLT    51		

/* Plane Stress Parabolic Triangle                   */
#define nbbel_PSSPT    53		

/* Plane StresS Linear Quadrilateral                 */
#define nbbel_PSSLQ    52		

/* Plane Stress Parabolic Quadrilateral              */
#define nbbel_PSSPQ    54		

/* Plane Strain Linear Triangle                      */
#define nbbel_PSTLT    56		

/* Plane Strain Parabolic Triangle                   */
#define nbbel_PSTPT    58		

/* Plane StresS Linear Quadrilateral                 */
#define nbbel_PSTLQ    57		

/* Plane Strain Parabolic Quadrilateral              */
#define nbbel_PSTPQ    59		

/* Axisymetric Solid Linear Triangle                 */
#define nbbel_AXILT    45		

/* Axisymetric Solid Parabolic Triangle              */
#define nbbel_AXIPT    47		

/* Axisymetric Solid Linear Quadrilateral            */
#define nbbel_AXILQ    46		

/* Axisymetric Solid Parabolic Quadrilateral         */
#define nbbel_AXIPQ    48		

/* Thin Shell Linear Triangle                        */
#define nbbel_TNLT     21		

/* Thin Shell Parabolic Triangle                     */
#define nbbel_TNPT     23		

/* Thin Shell Linear Quadrilateral                   */
#define nbbel_TNLQ     22		

/* Thin Shell Parabolic Quadrilateral                */
#define nbbel_TNPQ     24		

/* Solid Linear Tetrahedron                          */
#define nbbel_SOLLT    40		

/* Solid Linear Wedge                                */
#define nbbel_SOLLW    43		

/* Solid Parabolic Wedge                             */
#define nbbel_SOLPW    44		

/* Solid Linear Brick                                */
#define nbbel_SOLLB    41		

/* Solid Parabolic Brick                             */
#define nbbel_SOLPB    42		

/* Solid Parabolic Tetrahedron                       */
#define nbbel_SOLPT    49		

/* Rigid Element                                     */
#define nbbel_RIGMNT    4  		

/* Node To Node Translational Spring                 */
#define nbbel_NNTSPR   31  		

/* Node To Node Rotational Spring                    */
#define nbbel_NNRSPR   35  		

/* Node To Ground Translational Spring               */
#define nbbel_NGTSPR   32  		

/* Node To Ground Rotational Spring                  */
#define nbbel_NGRSPR   36  		

/* Node To Node Axi Translational Spring             */
#define nbbel_NNATSPR  33  		

/* Node To Node Axi Rotational Spring                */
#define nbbel_NNARSPR  37  		

/* Node To Ground Axi Translational Spring           */
#define nbbel_NGATSPR  34  		

/* Node To Ground Axi Rotational Spring              */
#define nbbel_NGARSPR  38  		

/* Node To Node Damper                               */
#define nbbel_NNDAMP   12  		

/* Node To Gound Damper                              */
#define nbbel_NGDAMP   13  		

/* Lumped Mass                                       */
#define nbbel_LMASS    11  		

/* Axisymetric Linear Shell                          */
#define nbbel_AXSLS    25  		

/* Constraint                                        */
#define nbbel_CONCON    5		

/* Membrane Linear Quadilateral                      */
#define nbbel_MEMLQ    62		

/* Membrane Parabolic Quadilateral                   */
#define nbbel_MEMPQ    64		

/* Membrane Linear Triangle                          */
#define nbbel_MEMLT    61		

/* Membrane Parabolic Triangle                       */
#define nbbel_MEMPT    63		

#define fxel_NOTYPE              0

/*   */
#define fxel_LINK1		   1   

/* 6 Noded Triangular Structural Solid */
#define fxel_PLANE2		   2   

/* 2D Elastic Beam */
#define fxel_BEAM3		   3   

/* 3D Elastic Beam */
#define fxel_BEAM4		   4   

/* 3D Coupled Field Solid */
#define fxel_SOLID5		   5   

/* Revolute Joint */
#define fxel_COMBIN7		   7   

/* 3D Truss */
#define fxel_LINK8		   8   

/* 2D Infinite Boundary */
#define fxel_INFIN9		   9   

/* Tension Only or Compression Only Spar */
#define fxel_LINK10		  10   

/* Linear Actuator */
#define fxel_LINK11		  11   

/* 2D Point to Point Contact Element */
#define fxel_CONTAC12		  12   

/* 2D Coupled Field Solid */
#define fxel_PLANE13		  13   

/* Spring Damper */
#define fxel_COMBIN14		  14   

/* Elastic Straight Pipe */
#define fxel_PIPE16  		  16   

/* Elastic Pipe Tee */
#define fxel_PIPE17  		  17   

/* Elbow */
#define fxel_PIPE18		  18   

/* Plastic Straight Pipe */
#define fxel_PIPE20		  20   

/* Structural Mass */
#define fxel_MASS21		  21   

/* 2D Plastic Beam */
#define fxel_BEAM23		  23   

/* 3D Thin Walled Beam */
#define fxel_BEAM24		  24   

/* Axisymmetric Harmonic 4Noded Structural Solid  */
#define fxel_PLANE25		  25   

/* 2D Point To Ground Contact */
#define fxel_CONTAC26		  26   

/* Matrix */
#define fxel_MATRIX27		  27   

/* Shear Twist Pannel */
#define fxel_SHELL28		  28   

/* 2D Acoustic Fluid */
#define fxel_FLUID29		  29   

/* 3D Acoustic Fluid */
#define fxel_FLUID30		  30   

/* Radiation Link */
#define fxel_LINK31		  31   

/* 2D Conduction Bar */
#define fxel_LINK32		  32   

/* 3D Conduction Bar */
#define fxel_LINK33		  33   

/* Convection Link */
#define fxel_LINK34		  34   

/* 6-Noded Triangular Thermal Solid */
#define fxel_PLANE35		  35   

/* Current Source */
#define fxel_SOURC36		  36   

/* Control */
#define fxel_COMBIN37		  37   

/* Dynamic Fluid Coupling */
#define fxel_FLUID38		  38   

/* Nonlinear Spring */
#define fxel_COMBIN39		  39   

/* Combination */
#define fxel_COMBIN40		  40   

/* Membrane Shell */
#define fxel_SHELL41		  41   

/* 2D Structural Solid */
#define fxel_PLANE42		  42   

/*  4-Noded Plastic Large Strain Solid*/
#define fxel_SHELL43		  43   

/*  3D Elastic Unsym Beam */
#define fxel_BEAM44		  44   

/*  3D Structural Solid */
#define fxel_SOLID45		  45   

/*  3D 8-Noded Layered Structural Solid */
#define fxel_SOLID46		  46   

/*  3D Infinite Boundary */
#define fxel_INFIN47		  47   

/*  2D Pt to Surface Constact */
#define fxel_CONTAC48		  48   

/*  2D Pt to Surface Constact */
#define fxel_CONTAC49		  49   

/*  Superelement */
#define fxel_MATRIX50		  50   

/*  Axi Structural Shell */
#define fxel_SHELL51		  51   

/*  3D Pt to Pt Constact */
#define fxel_CONTAC52		  52   

/*  2D 8 Noded Magnetic Solid */
#define fxel_PLANE53		  53   

/*  2D Elastic Tapered Unsym Beam */
#define fxel_BEAM54		  54   

/*  2D Thermal Solid */
#define fxel_PLANE55		  55   

/*  2D 4 Noded Mixed U-P Hyperelastic */
#define fxel_HYPER56		  56   

/*  Thermal Shell */
#define fxel_SHELL57		  57   

/*  3D 8 Noded Mixed U-P Hyperelastic */
#define fxel_HYPER58		  58   

/*  Immersed Pipe or Cable */
#define fxel_PIPE59		  59   

/*  Plastic Curved Pipe */
#define fxel_PIPE60		  60   

/*  Axi Harm Structural Shell */
#define fxel_SHELL61		  61   

/*  3D Magneto Structurl Solid */
#define fxel_SOLID62		  62   

/*  Elastic Shell */
#define fxel_SHELL63		  63   

/*  3D Anisotropic Structural Solid */
#define fxel_SOLID64		  64   

/*  3D Reinforced Concrete Solid */
#define fxel_SOLID65		  65   

/*  2D Thermal Electric Solid */
#define fxel_PLANE67 		  67   

/*  Thermal Electric Line */
#define fxel_LINK68		  68   

/*  3D Thermal Electric Solid */
#define fxel_SOLID69		  69   

/*  3D Thermal Solid */
#define fxel_SOLID70		  70   

/*  Thermal Mass */
#define fxel_MASS71		  71   

/*  */
#define fxel_HYPER74		  74   

/*  */
#define fxel_PLANE75		  75   

/*  */
#define fxel_PLANE77		  77   

/*  */
#define fxel_PLANE78		  78   

/*  */
#define fxel_FLUID79		  79   

/*  */
#define fxel_FLUID80		  80   

/*  */
#define fxel_FLUID81		  81   

/*  */
#define fxel_PLANE82		  82   

/*  */
#define fxel_PLANE83		  83   

/*  */
#define fxel_HYPER84		  84   

/*  */
#define fxel_HYPER86		  86   

/*  */
#define fxel_SOLID87		  87   

/*  */
#define fxel_VISCO88		  88   

/*  */
#define fxel_VISCO89		  89   

/*  */
#define fxel_SOLID90		  90   

/*  */
#define fxel_SHELL91		  91   

/*  */
#define fxel_SOLID92		  92   

/*  */
#define fxel_SHELL93		  93   

/*  */
#define fxel_CIRCU94		  94   

/*  */
#define fxel_SOLID95		  95   

/*  */
#define fxel_SOLID96		  96   

/*  */
#define fxel_SOLID97		  97   

/*  */
#define fxel_SOLID98		  98   

/*  */
#define fxel_SHELL99		  99   

/*  */
#define fxel_VISCO106		 106   

/*  */
#define fxel_VISCO107		 107   

/*  */
#define fxel_VISCO108		 108   

/*  */
#define fxel_TRANS109		 109   

/*  2D Infinite Solid */
#define fxel_INFIN110		 110   

/*  3D Infinite Solid */
#define fxel_INFIN111		 111   

/*  3D Magnetic Interface */
#define fxel_INFIN115		 115   

/*  Thermal Fluid Pipe */
#define fxel_FLUID116		 116   

/*  3D 20 Node Magnetic Solid */
#define fxel_SOLID117		 117   

/*  2D HF Quadrilateral Solid */
#define fxel_HF118		 118   

/*  3D HF Tetraedral Solid*/
#define fxel_HF119		 119   

/*  3D HF Brick Solid*/
#define fxel_HF120		 120   

/*  2D 8-Noded  Electrostatic Solid */
#define fxel_PLANE121		 121   

/*  20 Noded Brick  Electrostatic Solid */
#define fxel_SOLID122		 122   

/*  10 Noded Tet Electrostatic Solid */
#define fxel_SOLID123		 123   

/*  General Circuit */
#define fxel_CIRCU124		 124   

/*  Zener Diode */
#define fxel_CIRCU125		 125   

/*  Electroc Meca Transducer */
#define fxel_TRANS126		 126   

/*  3D Tet Electrostatic Solid P Element*/
#define fxel_SOLID127		 127   

/*  3D Brick Electrostatic Solid P Element */
#define fxel_SOLID128		 128   

/*  2D Infinite Acoustic */
#define fxel_FLUID129		 129   

/*  3D Infinite Acoustic */
#define fxel_FLUID130		 130   

/*  3D 4-Node Layered Thermal Shell */
#define fxel_SHELL131		 131

/*  3D 8-Node Layered Thermal Shell */
#define fxel_SHELL132		 132

/*  2D Fluid Thermal */
#define fxel_FLUID141		 141   

/*  3D Fluid Thermal */
#define fxel_FLUID142		 142   

/*  4-Node Plastic Small Strain Shell */
#define fxel_SHELL143		 143   

/*  2D Quad Structural Solid P-Element*/
#define fxel_PLANE145		 145   

/*  2D Triangular Structural Solid P-Element*/
#define fxel_PLANE146		 146   

/*  3D Brick Structural Solid  P-Element */
#define fxel_SOLID147		 147   

/*  3D Tet Structural Solid  P-Element */
#define fxel_SOLID148		 148   

/*  8-Node Structural Shell P-Element */
#define fxel_SHELL150		 150   

/*  2D Thermal Surface Effect */
#define fxel_SURF151		 151   

/*  3D Thermal Surface Effect */
#define fxel_SURF152		 152   

/*  2D Structural Surface Effect */
#define fxel_SURF153		 153   

/*  2D Structural Surface Effect */
#define fxel_SURF154		 154   

/*  Thermal Electric Shell */
#define fxel_SHELL157		 157   

/*  10 Noded Tet U-P Mixed Formulation */
#define fxel_HYPER158		 158   

/*  Explicit 3D Truss */
#define fxel_LINK160		 160   

/*  Explicit 3D Beam */
#define fxel_BEAM161		 161   

/*  Explicit 2D Structural Solid */
#define fxel_PLANE162		 162   

/*  Explicit Shell */
#define fxel_SHELL163		 163   

/*  Explicit 3D Structural Solid */
#define fxel_SOLID164		 164   

/*  Explicit Spring Damper */
#define fxel_COMBI165		 165   

/*  Explicit Structural Mass */
#define fxel_MASS166		 166   

/*  Explicit Tension Only Spar */
#define fxel_LINK167		 167   

/*  2D Target Segment */
#define fxel_TARGE169		 169   

/*  3D Target Segment */
#define fxel_TARGE170		 170   

/*  2D 2-Node Surface to Surface Contact */
#define fxel_CONTA171		 171   

/*  2D 3-Node Surface to Surface Contact */
#define fxel_CONTA172		 172   

/*  2D 4-Node Surface to Surface Contact */
#define fxel_CONTA173		 173   

/*  2D 8-Node Surface to Surface Contact */
#define fxel_CONTA174		 174   

/*  3D 1-Node Node to Surface Contact */
#define fxel_CONTA175		 175   

/*  3D Node To Node Contact */
#define fxel_CONTA178		 178   

/*  2D 3D Pre Tension */
#define fxel_PRETS179		 179   

/*  3D Finite Strain Truss */
#define fxel_LINK180		 180   

/*  Finite Strain Shell */
#define fxel_SHELL181		 181   

/*  2D 4 Node Structural Solid */
#define fxel_PLANE182		 182   

/*  2D 8 Node Structural Solid */
#define fxel_PLANE183		 183   

/*  3 Node Multi Point Constraint Rigid Link and Rigid Beam */
#define fxel_MPC184		 184  

/*  3D 8 Node Structural Solid */
#define fxel_SOLID185		 185   

/*  3D 20 Node Structural Solid */
#define fxel_SOLID186		 186   

/*  3D 10 Node Structural Solid */
#define fxel_SOLID187		 187   

/*  3D Linear Finite Strain Beam */
#define fxel_BEAM188		 188   


/*  3D Quadratic Finite Strain Beam */
#define fxel_BEAM189		 189   

/*  3D 20-Node Layered Structural Solid */
#define fxel_SOLID191		 191   

/*  Meshing Facet */
#define fxel_MESH200		 200    

/* Axi Shell 2 nodes */
#define fxel_SHELL208            208

/* Axi Shell 3 nodes */
#define fxel_SHELL209            209

/* Coupled field 2D Solid, 8 nodes */
#define fxel_PLANE223            223

/* Coupled field 3D Solid, 20 nodes */
#define fxel_SOLID226            226

/* Coupled field 3D Solid, 8 nodes */
#define fxel_SOLID227            227

/* Electric 2D Solid, 8 nodes */
#define fxel_PLANE230            230

/* Electric 3D Solid, 20 nodes */
#define fxel_SOLID231            231

/* Electric 3D Solid, 8 nodes */
#define fxel_SOLID232            232

/* 2D Radiosity Surface */
#define fxel_SURF251 		 251

/* 2D Radiosity Surface */
#define fxel_SURF252 		 252


/* 
 * shell layers identification for post-processing.
 * - negative values are used for specific usage (see below),
 * - positive values for shell #, from 0-bottom to n-top
 */
#define LAYER_NONE	-100	/* no layer available */
#define LAYER_MAX	-1	/* to search maximum over all the layers */
#define LAYER_TOP	-2	/* to evaluate the top layer */
#define LAYER_MIDDLE	-3	/* to evaluate a middle layer, averaged of top and bottom */
#define LAYER_BOTTOM	-4	/* to evaluate the bottom layer */


/*
 *------------------- OBJET REPERE --------------------------------
 */
 
/*
 *------------------- attribut nature -----------------------------
 */
typedef enum {
  CARTESIEN,
  CYLINDRIQUE,
  SPHERIQUE
} E_nature_repere;

/*
 *-------------------- OBJET MODELISATION PHYSIQUE -----------------
 */

/*
 *------------------------ attribut formulation --------------------
 */
#define  TAILLE_FORMULATION 6

typedef enum {
  NO_FORMULATION=0,
  MECANIQUE=1,
  THERMIQUE=2,
  HIGHFREQ=3,
  ELECTRIC=4,
  MAGNETIC=5
} E_formulation;

/*
 *------------------ attribut mode d'analyse ----------------------
 */
/* voir l'enum TeFemFAM dans stbinc/fesprm.h */
#define  TAILLE_MODE_ANALYSE 24
typedef enum {
   fem_eNOFAM	 =  0,
   fem_eRODFAM   =  1,  /* Rod Family                                        */
   fem_eBMFAM    =  2,  /* Beam Family                                       */
   fem_ePIPFAM   =  3,  /* Pipe Family                                       */
   fem_ePSEFAM   =  4,  /* Plane Stress                                      */
   fem_ePSAFAM   =  5,  /* Plane Strain                                      */
   fem_ePLTFAM   =  6,  /* Plate                                             */
   fem_eMEMFAM   =  7,  /* Membrane                                          */
   fem_eASOFAM   =  8,  /* Axisymetric Solid                                 */
   fem_eTNSFAM   =  9,  /* Thin Shell                                        */
   fem_eTKSFAM   = 10,  /* Thick Shell                                       */
   fem_eSOLFAM   = 11,  /* Solid                                             */
   fem_eRBFAM    = 12,  /* Rigid Family                                      */
   fem_eSPRFAM   = 13,  /* Spring Family                                     */
   fem_eDMPFAM   = 14,  /* Damper Family                                     */
   fem_eGAPFAM   = 15,  /* Gap Family                                        */
   fem_eLMFAM    = 16,  /* Lumped mass Family                                */
   fem_eATSFAM   = 17,  /* Axisymetric thin shell                            */
   fem_eCONFAM   = 18,  /* Constraint Family                                 */
   fem_ePLSFAM   = 19,  /* Plastic Family                                    */
   fem_eINTFAM   = 20,  /* Interface family                                  */
   fem_eAINFAM   = 21,  /* Axisymmetric interface family                     */
   fem_eIRSFAM   = 22,  /* Rigid surface family                              */
   fem_eARSFAM   = 23,  /* Axisymmetric rigid surface family                 */  
   fem_eSEFFAM   = 24   /* surface/edge effect family                        */  
}  E_mode_analyse;

/*
 *------------- attribut comportement du materiau -----------------
 */
#define  TAILLE_COMPORTEMENT_MATERIAU  3

typedef enum {
  ELASTIQUE=1,
  PLASTIQUE,
  VISCOPLASTIQUE
} E_comportement_materiau;
/*
 *---------------- attribut nature du materiau --------------------
 */
#define  TAILLE_NATURE_MATERIAU  3

typedef enum {
  ISOTROPE=1,
  ANISOTROPE,
  ORTHOTROPE
} E_nature_materiau;

/* 
 *---------------  attribut modele d'amortissement ----------------
 */
typedef enum {
  PASDAMORT=0,
  ALPHABETA,
  MODULECOMPLEXE,
  ANALYTIQUE
} E_modele_amort;

/* 
 *---------------- attribut type d'analyse ------------------------
 */
typedef enum {
  STATIQUE=1,
  HARMONIQUE,
  MODAL,
  BUCKLING
} E_type_analyse;

/*
 *-------------------------- OBJET NOEUD -------------------------
 */

/*
 *------------------- attribut degre de liberte --------------------
 */
#define TAILLE_DEGRE_DE_LIBERTE 8

/* ddl pour le solveur / composantes de deplacement pour le post */
#define  UX  1
#define  UY  2
#define  UZ  3
#define  RX  4
#define  RY  5
#define  RZ  6

#define  TEMPERATURE 1

/* normes pour le post */
#define  NORME_TRANSLATION	7
#define  NORME_ROTATION		8
#define  NORME_INF_TRANSLATION	9
#define  NORME_INF_ROTATION	10

/* equivalents traites commes composantes en contour */
#define  EQ_CP_UX	11
#define  EQ_CP_UY	12
#define  EQ_CP_UZ	13
#define  EQ_VONMISES	14
#define  EQ_TRESCA	15
#define  EQ_MSSHEAR	16

#define  TEMP 17
#define  VOLT 18
#define  AX 19
#define  AY 20
#define  AZ 21

/* nombre max de composantes disponibles pour 1 critere donne */
#define NB_MAX_COMPOSANTES	21

typedef enum {
  COMPO_RE,
  COMPO_IM,
  COMPO_MO,
  COMPO_PH
} E_zcomp;

/*
 *------------------------ OBJET PROPRIETE -------------------------
 */

/*
 *------------------- attribut type de propriete --------------------
 */
#define TAILLE_TYPE_PROPRIETE 3

typedef enum {
  MATERIAU=1,
  PHYSIQUE=2,
  NUMERIQUE=3
} E_type_propriete;

/*
 *-------------------- OBJET PROPRIETE ELEMENTAIRE ------------------
 */

/* Mod Sol properties */
/* nouvelle proprietes elementaires  qui sont pas dans Mod Sol */
/* materiaux dans mdsinc/mdsmai.x*/
#define mfp_UELAST   -401
#define mfp_USHRMOD  -402
#define mfp_UEX      -403
#define mfp_UEY      -404
#define mfp_UEZ      -405
#define mfp_UGXY     -406
#define mfp_UGYZ     -407
#define mfp_UGXZ     -408
#define mfp_NUYX     -501
#define mfp_NUZY     -502
#define mfp_NUZX     -503
#define mfp_DENU1    -504 
#define mfp_DENU2    -505
#define mfp_DENU3    -506
#define mfp_DENU4    -507
#define mfp_DENU5    -508
#define mfp_DORTH1   -550
#define mfp_DORTH2   -551
#define mfp_DORTH3   -552
#define mfp_DORTH4   -553
#define mfp_DORTH5   -554
#define mfp_DORTH6   -555
#define mfp_DORTH7   -556
#define mfp_DORTH8   -557
#define mfp_DORTH9   -558
#define mfp_DORTH10  -559
#define mfp_DORTH11  -560
#define mfp_FREQ     -561
#define mfp_TYPMAT   -998
/* physique dans stbinc/phy.h*/
#define phy_eUTK      301
#define phy_eUTK2     302
#define phy_eTK3S12   303
#define phy_eKTX      304
#define phy_eKTY      305
#define phy_eKTZ      306
#define phy_eUKTX     307
#define phy_eUKTY     308
#define phy_eUKTZ     309
#define phy_eKRX      310
#define phy_eKRY      311
#define phy_eKRZ      312
#define phy_eUKRX     313
#define phy_eUKRY     314
#define phy_eUKRZ     315
#define phy_eTK2S12   316
#define phy_eLMIXX    317
#define phy_eLMIYY    318
#define phy_eLMIZZ    319
#define phy_eLMIXY    320
#define phy_eLMIXZ    321
#define phy_eLMIYZ    322
#define phy_TKTYP     997
#define phy_TYPHY     998

#define num_PENFAC    996
#define num_UPENFAC   995
#define num_BOOLFAC   994

#define pen_PENFAC 1
#define pen_BOOLFAC 2
#define pen_UPENFAC 3

/* Ansys properties */
#define pem_None        0
#define pem_EX    	1 /* Elastic moduli */
#define pem_EY    	2
#define pem_EZ    	3
#define pem_NUXY        4 /* Minor Poisson's ratios */
#define pem_NUYZ        5
#define pem_NUXZ        6
#define pem_GXY   	7 /* Shear moduli */
#define pem_GYZ   	8
#define pem_GXZ   	9
#define pem_ALPX       	10 /* Coefficients of thermal expansion */
#define pem_ALPY       	11
#define pem_ALPZ       	12
#define pem_DENS       	13 /* Mass density */
#define pem_MU   	14 /* Coefficient of friction */
#define pem_DAMP        15 /* K matrix multiplier for damping.domain. */
#define pem_KXX  	16 /* Thermal conductivities */
#define pem_KYY  	17
#define pem_KZZ  	18
#define pem_RSVX        19 /* Electrical resistivities */
#define pem_RSVY        20
#define pem_RSVZ        21
#define pem_C	        22 /* Specific heat */
#define pem_HF   	23 /* Convection or film coefficient. */
#define pem_VISC        24 /* Viscosity */
#define pem_EMIS        25 /* Emissivity. */
#define pem_ENTH        26 /* Enthalpy */
#define pem_LSST        27 /* Dielectric loss tangent. Valid for high-frequency electromagnetic analyses only */
#define pem_PRXY        28 /* Major Poisson's ratios */
#define pem_PRYZ        29
#define pem_PRXZ        30
#define pem_MURX        31 /* Magnetic relative permeabilities */
#define pem_MURY        32
#define pem_MURZ        33
#define pem_PERX        34
#define pem_PERY        35
#define pem_PERZ        36
#define pem_MGXX        37
#define pem_MGYY        38
#define pem_MGZZ        39
#define pem_EGXX        40
#define pem_EGYY        41
#define pem_EGZZ        42
#define pem_SBKX        43
#define pem_SBKY        44
#define pem_SBKZ        45
#define pem_SONC        46
#define pem_ORTH        54
#define pem_CABL        55
#define pem_RIGI        56
#define pem_HGLS        57
#define pem_BM   	58
#define pem_QRAT        59
#define pem_REFT        60
#define pem_PLAS        61
#define pem_CREE        62
#define pem_FAIL        63
#define pem_BH   	64
#define pem_PIEZ        65
#define pem_SWEL        66
#define pem_WATE        67
#define pem_ANEL        70
#define pem_ACOU        71
#define pem_EVIS        72
#define pem_USER        73
#define pem_NL   	74
#define pem_HYPE        75
#define pem_NNEW        76
#define pem_MOON        77
#define pem_OGDE        78
#define pem_SUTH        79
#define pem_WIND        80
/* type par interne */
#define  pem_UEX        81
#define pem_UEY  	82
#define pem_UEZ  	83
#define pem_UGXY        84
#define pem_UGXZ        85
#define pem_UGYZ        86
#define pem_TYPMAT     	87  /* nature of the material: ISO, ORTHO, ANISO */
#define pem_FREQ       	88
#define pem_CONC        89
#define pem_PFLO        90

#define pem_LAYEX    	1000 /* Elastic moduli */
#define pem_LAYEY    	2000
#define pem_LAYEZ    	3000
#define pem_LAYNUXY     4000 /* Minor Poisson's ratios */
#define pem_LAYNUYZ     5000
#define pem_LAYNUXZ     6000
#define pem_LAYGXY   	7000 /* Shear moduli */
#define pem_LAYGYZ   	8000
#define pem_LAYGXZ   	9000
#define pem_LAYALPX     10000 /* Coefficients of thermal expansion */
#define pem_LAYALPY     11000
#define pem_LAYALPZ     12000
#define pem_LAYDENS     13000 /* Mass density */


/* Ansys Phys props */
#define pep_None         0
#define pep_TK   1
#define pep_KTX  2
#define pep_KTY  3
#define pep_KTZ  4
#define pep_KRX  5
#define pep_KRY  6
#define pep_KRZ  7
/* type par interne */
#define pep_UTK        8 
#define pep_UKTX         9
#define pep_UKTY        10
#define pep_UKTZ        11
#define pep_UKRX        12
#define pep_UKRY        13
#define pep_UKRZ        14
#define pep_TKVAR       15  /* flag prop variable */
#define pep_TYPHY       16   /* type de prop phys*/
/* */
#define pep_MA          17
#define pel_TEMP	18
#define pep_A		19 /* Area of section */
#define pep_IYY		20 /* Moment of inertia about the y axis */
#define pep_IYZ		21 /* Product of inertia */
#define pep_IZZ		22 /* Moment of inertia about the z axis */
#define pep_IW		23 /* Warping constant */
#define pep_J		24 /* Torsional constant */
#define pel_PRES	25 /* Surface Load : pressure */
#define pel_CONV_COEF	26 /* Surface Load : convection -- film coefficient  */
#define pel_CONV_TEMP	27 /* Surface Load : convection -- bulk temperature  */
#define pel_HFLUX	28 /* Surface Load : heat flux */
#define pep_LAYTK       1000 /* TK par layer. (numeros reserves jusqu'a 1255) (duc) */
#define pep_LAYUTK      2000 /* TK par layer. (numeros reserves jusqu'a 2255) (duc) */
#define pep_ORTH_ANGLE	21000 /* ORTH_ANGLE par layer. (numeros reserves jusqu'a 3255) (duc) */
/* Numerical properties for the harmonic index */
#define pen_HI_SECTOR_ANGLE 101
#define pen_HI_INITIAL_INDEX 102

/*
 *----------------------- OBJETS CHAMPS LOCAL ET GLOBAL -------------
 */


/*
 *------------------ Objet Critere ----------------------------------
 */
/*
 *------------------ Objet Critere ----------------------------------
 */
#define  NODE_STRESS            1
#define  NODE_STRAIN            2
#define  NODE_DISP              3
#define  NODE_MISES             4
#define  NODE_TRESCA            5
#define  NODE_REACTION          6
#define  NODE_SPRING_REAC       7   
#define  NODE_USER1             8
#define  NODE_USER2             9
#define  NODE_USER3             10

#define  ELEM_PG_STRESS         11
#define  ELEM_PG_STRAIN         12
#define  ELEM_PG_MISES          13
#define  ELEM_PG_TRESCA         14
#define  ELEM_MOY_STRESS        15
#define  ELEM_MOY_STRAIN        16
#define  ELEM_MOY_MISES         17
#define  ELEM_MOY_TRESCA        18
#define  ELEM_MASS              19
#define  ELEM_ENER_STRAIN       20  
#define  ELEM_SED               21
#define  ELEM_CP                22
#define  ELEM_MAX_CP            23
#define  ELEM_USER1             24
#define  ELEM_USER2             25
#define  ELEM_USER3             26

#define  MOD_ELEM_MAXSTRESS     27
#define  MOD_ELEM_MAXSTRAIN     28
#define  MOD_ELEM_MAXMISES      29
#define  MOD_ELEM_MAXTRESCA     30
#define  MOD_NODE_MAXDISP       31
#define  MOD_NODE_MAXSTRESS     32
#define  MOD_NODE_MAXSTRAIN     33
#define  MOD_NODE_MAXMISES      34
#define  MOD_NODE_MAXTRESCA     35
#define  MOD_MASS               36
#define  MOD_SED                37 
#define  MOD_ENER_STRAIN        38 
#define  MOD_ELEM_MAX_ENER_STRAIN 39
#define  MOD_ELEM_MAX_CP        40
#define  MOD_REACTION           41
#define  MOD_NODE_SPRING_REAC   42
#define  MOD_USER1              43
#define  MOD_USER2              44
#define  MOD_USER3              45

#define  GRP_ELEM_MAXSTRESS     46
#define  GRP_ELEM_MAXSTRAIN     47
#define  GRP_ELEM_MAXMISES      48
#define  GRP_ELEM_MAXTRESCA     49
#define  GRP_NODE_MAXDISP       50
#define  GRP_NODE_MAXSTRESS     51
#define  GRP_NODE_MAXSTRAIN     52
#define  GRP_NODE_MAXMISES      53
#define  GRP_NODE_MAXTRESCA     54
#define  GRP_MASS               55
#define  GRP_SED                56 
#define  GRP_ENER_STRAIN        57 
#define  GRP_ELEM_MAX_ENER_STRAIN 58
#define  GRP_ELEM_MAX_CP        59
#define  GRP_REACTION           60
#define  GRP_NODE_SPRING_REAC   61
#define  GRP_USER1              62
#define  GRP_USER2              63
#define  GRP_USER3              64
#define  ELEM_EFFORT            65
#define  ELEM_MAX_EFFORT        66
#define  MOD_ELEM_MAX_EFFORT    67
#define  GRP_ELEM_MAX_EFFORT    68
#define  MOD_PARAMETER          69
#define  NULL_COST_F            70
#define  ELEM_MAX_STRESS        71
#define  ELEM_MAX_STRAIN        72
#define  ELEM_MAX_MISES         73
#define  ELEM_MAX_TRESCA        74
#define  GRP_SOM_REAC           75
#define  MOD_SOM_REAC           76
#define  FREQUENCE_PROPRE       77
#define  MOD_MODE_MAXDISP       78
#define  GRP_MODE_MAXDISP       79
#define  NODE_MODE_DISP         80
#define  FREQUENCE_PROPRE_ID    81
#define  MOD_MODE_ID_MAXDISP    82
#define  GRP_MODE_ID_MAXDISP    83
#define  NODE_MODE_ID_DISP      84
#define  RES_DISP_NODES		85
#define  RES_DEFORM_MODEL	86
#define  RES_STRAIN_POINTS	87
#define  RES_STRESS_POINTS	88
#define  RES_ENERGIE		89
#define  RES_EFFORT_INT		90
#define  RES_REACTION		91
#define  RES_MESH_STRAIN_ELEM   92
#define  RES_MESH_PERTURB	93
#define  RES_SECTION_PERTURB	94
#define  RES_MODE		95
#define  RES_MODE_ID		96
#define  RES_DEFORME_MODALE	97
#define  RES_DEFORME_MODALE_ID	98
#define  RES_ENERGIE_MODALE	99
#define  RES_ENERGIE_MODALE_ID	100
#define  MOD_MODAL_ENER         101
#define  GRP_MODAL_ENER         102
#define  ELE_MODAL_ENER         103
#define  MOD_MODAL_ENER_ID      104
#define  GRP_MODAL_ENER_ID      105
#define  ELE_MODAL_ENER_ID      106
#define  NODE_HDISP            	107
#define  GRP_NODE_MAXHDISP     	108
#define  MOD_NODE_MAXHDISP     	109
#define  NODE_HVELO            	110
#define  NODE_HACCE            	111
#define  GRP_NODE_MAXHVELO     	112
#define  MOD_NODE_MAXHVELO     	113
#define  GRP_NODE_MAXHACCE     	114
#define  MOD_NODE_MAXHACCE     	115
#define  NODE_HVELO_DB          116
#define  NODE_HACCE_DB          117
#define  MOD_MODEU_MAXDISP      118
#define  GRP_MODEU_MAXDISP      119
#define  NODE_MODEU_DISP        120
#define  RES_MODEU              121
#define  ELEM_DP                122
#define  ELEM_MAX_DP            123
#define  MOD_ELEM_MAX_DP        124
#define  GRP_ELEM_MAX_DP        125
#define  RES_TEMPERATURE        126
#define  RES_FLUX               127

#define  GRP_MAX_TEMP           129
#define  MOD_MAX_TEMP           130
#define  ELEM_FLUX              131
#define  GRP_MAX_FLUX           132
#define  MOD_MAX_FLUX           133
#define  RES_STRESS_NODES	134
#define  RES_STRAIN_NODES	135
#define  GRP_NB_VARIABLES       136
#define  MOD_NB_VARIABLES       137
#define  RES_DISP_NODES_C	138
#define  RES_STRESS_NODES_C	139
#define  RES_STRAIN_NODES_C	140

#define  ELEM_MSSHEAR		141
#define  NODE_MSSHEAR		142
#define  GRP_NODE_MAX_MSSHEAR	143
#define  GRP_ELEM_MAX_MSSHEAR	144
#define  MOD_NODE_MAX_MSSHEAR	145
#define  MOD_ELEM_MAX_MSSHEAR	146

#define  NODE_CP		147
#define  NODE_MAX_CP		148
#define  GRP_NODE_CP		149
#define  GRP_NODE_MAX_CP	150
#define  MOD_NODE_MAX_CP	151
#define  MOD_NODE_CP		152

#define  RES_MODE_C         153

#define  NODE_FORCE		154
#define  GRP_NODE_MAXFORCE	155
#define  MOD_NODE_MAXFORCE	156
#define  RES_FORCE_NODES_C      157
#define  RES_FORCE_NODES        158
#define  RES_REACTION_C         159
#define  ELEM_PG_FORCE          160
#define  MOD_ELEM_MAXFORCE      161
#define  GRP_ELEM_MAXFORCE	162
#define  ELEM_MAX_FORCE         163
#define  RES_MASSE              164

#define  LOAD_FACTOR            165
#define  LOAD_FACTOR_ID         166

#define NODE_TEMP               167
#define NODE_VOLT		168
#define GRP_TEMP                169
#define GRP_VOLT                170
#define MOD_TEMP                171
#define MOD_VOLT                172
#define RES_VOLT          	174
#define ELEM_TG                 175
#define NODE_TG                 176
#define RES_TG                  177
#define MOD_ELEM_MAXTG          178
#define MOD_NODE_MAXTG          179
#define GRP_ELEM_MAXTG          180
#define GRP_NODE_MAXTG          181
#define ELEM_TF                 182
#define NODE_TF                 183
#define RES_TF                  184
#define MOD_ELEM_MAXTF          185
#define MOD_NODE_MAXTF          186
#define GRP_ELEM_MAXTF          187
#define GRP_NODE_MAXTF          188
#define NOD_B                   189
#define GRP_B                   190
#define MOD_B                   191
#define RES_B                   192
#define ELEM_B                  193
#define NOD_H                   194
#define GRP_H                   195
#define MOD_H                   196
#define RES_H                   197
#define ELEM_H                  198
#define NOD_JT                  199
#define GRP_JT                  200
#define MOD_JT                  201
#define RES_JT                  202
#define ELEM_JT                 203
#define NOD_FMAG                204
#define GRP_FMAG                205
#define MOD_FMAG                206
#define RES_FMAG                207
#define ELEM_FMAG               208
#define NOD_AZ                  209
#define GRP_AZ                  210
#define MOD_AZ                  211
#define RES_AZ                  212
#define RES_TG_NOEUD_C          213
#define RES_TF_NOEUD_C          214
#define RES_TG_NOEUD			215
#define RES_TF_NOEUD			216

/*
 *------------------ indicateur de resultats paramatres -------------
 */

typedef enum {
  CALCUL_RIEN=0,
  CALCUL_DEPLACEMENT,
  CALCUL_DEFORMATION,
  CALCUL_DEFORMATION_MOY,	/* obsolete */
  CALCUL_CONTRAINTE,	
  CALCUL_CONTRAINTE_MOY,	/* obsolete */
  CALCUL_ENERGIE,
  CALCUL_REACTION,
  CALCUL_EFFORT_INT,		
  CALCUL_MASSE,
  CALCUL_PERT,
  CALCUL_RES_DYNA,
  CALCUL_VP,
  CALCUL_VP_ID,
  CALCUL_MODE,
  CALCUL_MODE_ID,
  CALCUL_MODE_COMPLEXE,
  CALCUL_PARAMETRE,
  CALCUL_DEFORMATION_NOEUD_EL,
  CALCUL_CONTRAINTE_NOEUD_EL,
  CALCUL_ENERGIE_NOEUD_EL,
  CALCUL_DEFORMATION_NOEUD,
  CALCUL_CONTRAINTE_NOEUD,
  CALCUL_DEFORMATION_PEAU,
  CALCUL_CONTRAINTE_PEAU,
  CALCUL_DEFORMEE,
  CALCUL_MAC,
  CALCUL_DEFORMEE_MODALE,
  CALCUL_DEFORMEE_MODALE_ID,
  CALCUL_ENER_MODALE,
  CALCUL_ENER_MODALE_ID,
  CALCUL_ENER_MODALE_N_EL,
  CALCUL_ENER_MODALE_N_EL_ID,
  CALCUL_FORCE,
  CALCUL_FORCE_COMPLEXE,
  CALCUL_TEMPERATURE,
  CALCUL_VELOCITY,
  CALCUL_ACCELERATION,
  CALCUL_MODEU,
  CALCUL_USER,			/* empty entry for specific dev, avoid the need to modify TAILLE_TYPE_RES */
  CALCUL_FLUX,
  CALCUL_DEPLACEMENT_C,
  CALCUL_DEFORMATION_NOEUD_C,
  CALCUL_CONTRAINTE_NOEUD_C,
  CALCUL_FORCE_NOEUD,
  CALCUL_FORCE_NOEUD_C,
  CALCUL_MODE_C,
  CALCUL_REACTION_C,
  CALCUL_TG,
  CALCUL_TG_NOEUD,
  CALCUL_TG_NOEUD_C,
  CALCUL_TF,
  CALCUL_TF_NOEUD,
  CALCUL_TF_NOEUD_C,
  CALCUL_D,
  CALCUL_EF,
  CALCUL_JC,
  CALCUL_VOLT,
  CALCUL_MAGNETIC_POTENTIAL,
  CALCUL_B,
  CALCUL_H,
  CALCUL_JT,
  CALCUL_FMAG,
  CALCUL_TG_NOEUD_EL,
  CALCUL_TF_NOEUD_EL,
  /* KEEP TAILLE_TYPE_RES IN LAST POSITION! */
  TAILLE_TYPE_RES
} E_resultat_parametre;

/*
 *------------------ type physique du resultat -------------
 */
#define UNIT_LENGTH_DEF	1.0
#define UNIT_FORCEPERLENGTH_DEF  1.0
#define UNIT_FORCE_DEF  1.0
#define UNIT_TEMPERATURE_DEF  1.0
#define UNIT_TEMPOFFSET_DEF  0.0

#define  UNIT_DEPLACEMENT   	1
#define  UNIT_CONTRAINTE    	2
#define  UNIT_DEFORMATION  	3
#define  UNIT_ENER_DEFO         4
#define  UNIT_DENS_ENER_DEFO    5
#define  UNIT_REACTION	        6
#define  UNIT_EFFORT		7
#define  UNIT_MASSE             8
#define  UNIT_FREQUENCE         9
#define  UNIT_NONE		10  /* for unitless criteria */
#define  UNIT_TEMPERATURE       11
#define  UNIT_FLUX              12
#define  UNIT_FORCE		13
#define  UNIT_VOLT              14

/*
 *----------------- Pour la definition de la "frequence" ---------------
 */

typedef enum {
  FREQ_FREQUENCE=1,
  FREQ_PULSATION,
  FREQ_PERIODE
} E_unit_frequence;

typedef enum {
  TFR_RANGE=1,
  TFR_NUMBER,
  TFR_FIXED
} E_type_frequence;

/*
 * Type d'etude
 */
typedef enum {
  ETUDE_STANDARD=1,
  ETUDE_SENSIBILITE,
  ETUDE_PARAMETREE
} E_type_etude;

/* Objet optimisation */
typedef enum { 
MAXIMISATION=1, 
MINIMISATION=2 
} E_goal;

typedef enum { 
INFERIEUR=0, 
EGAL=1, 
SUPERIEUR=2 
} E_comp;

typedef enum { 
MONTECARLO=1, 
LAGRANGIEN=2, 
LAGRANGIEN_GLOBAL=3,
NGAUSS=4,
NUNIFORM=5
} E_meth_opt;

/* 
 * Gestion des groupes 
 */ 
/* Nature du groupe : Ces constantes doivent etre identiques a oa_FEM_NODES et oa_FEM FELEM */
typedef enum {
NOEUDS=7,
ELEMENTS=8,
GROUPES=9
} E_nature_groupe;

/* Type de stockage */
typedef enum {
DIRECT,
CODAGE,
TOUT,
BLOC
} E_stockage_groupe;

/* Nature des valeurs a extraire */
typedef enum {
INDICE,
NUMERO
} E_extract_groupe;

/* Fin de groupe */
#define PLUSDELEMENT -1

/*
 *------------ valeurs de la prop-elem type des points d'integration ----------
 */
#define TAILLE_TYPE_POINTS 3

typedef enum {
  GAUSS=1,
  GAUSSINTEG,
  GAUSURINTEG
} E_point_integration;
/*
 *------------ valeurs de la prop-elem nombre des points d'integration ----------
 */
#define TAILLE_NOMBRE_POINTS 27

/*
 *    Pour rechercher les pel
 */
#define MPROP 1
#define PPROP 2
#define FPROP 3
#define NPROP 4
#define LPROP 5


#define ORDRE_GEOMETRIQUE 3


/* Pour la dynamique */
#define ONENPRENDPLUS 3


/* ordre max de la derivation */
#define ORDRE_MAX 7

/* les ordres max - utilise par objetu */
#define MAXORDER_STATIQUE	7
#define MAXORDER_MODAL		6
#define MAXORDER_BUCKLING      	6
#define MAXORDER_HARMONIQUE	6

#define PLACE_DISQUE 500. 

/* va File */
#define CBF_VA_LIGHT 18
#define CBF_VA_VERSION 2000
#define CBF_VA_MODEL 2001
#define CBF_VA_ELEMENTS 2002
#define CBF_VA_NODES 2003
#define CBF_VA_GROUPS 2004
#define CBF_VA_DESIGN 2005
#define CBF_VA_PROPS 2006
#define CBF_VA_CS 2007
#define CBF_VA_CRIT 2008
#define CBF_VA_OPTIM 2009
#define CBF_VA_RES_OPTIM 2010
#define CBF_VA_OPTIM_OUT_RES 2011
#define CBF_VA_ADR_RES 2012
#define CBF_VA_BODIES 2013
#define CBF_VA_BC 2014

/* Nature Mathematique du resultat */
typedef enum {
  NAT_SCAL,
  NAT_VECT,
  NAT_TENS,
  NAT_TORS
} E_nature;

/* Support des resultats */
typedef enum {
  SUP_PTG,
  SUP_NOE_ELEM,
  SUP_ELEM,
  SUP_NOE,
  SUP_SANS
} E_support;

/* Transformation */
typedef enum {
  TRA_IDENTITE,			/* Pas de changement de lieu */
  TRA_EX_VP, 			/* Extraction of the eigen values */
  TRA_EX_MAC,			/* MAC extraction */
  TRA_DISP_2_STRAIN,		/* eps = B * u */
  TRA_MODE_2_STRAIN,    	/* eps = B * phi */
  TRA_STRAIN_2_STRESS,  	/* sig = D * eps */
  TRA_STRESS_2_STRAIN,		/* eps = 1/D * sig */
  TRA_STRAINMOY_2_STRESS,	/* sig ( integ point )  = D * eps ( average ) */
  TRA_STRESSMOY_2_STRAIN,	/* eps ( integ point )  = 1/D * sig ( average ) */
  TRA_CALCUL_MASSE,		/* Mass calculation */
  TRA_CALCUL_EFFORT,		/* Element forces */
  TRA_CALCUL_REACTION,		/* Reactions */
  TRA_CALCUL_PERT,		/* Node perturbation calculation */
  TRA_STRESS_STRAIN,		/* in product eps * sig */
  TRA_NOE_ELEM_2_ELEM,		/* Average value over the element */
  TRA_MOY_2_NOE_ELEM,		/* Average value to nodes on element */
  TRA_NOE_ELEM_2_NOE,		/* Passage des noeuds des eleemnts aux noeuds */
  TRA_MODE_2_MODE_ID,		/* Mode to identified mode */
  TRA_VP_2_VP_ID,		/* Eigen Value to identified eigen value */
  TRA_DISP_2_VELO,              /* For Harm Analsysis */
  TRA_DISP_2_ACCE,              /* For Harm Analsysis */
  TRA_MODE_2_MODEU,             /* Unit displacement normalization */
  TRA_COUNT,                    /* Count the number of active variables */
  TRA_DISP_2_DISP_COMP,		/* extraction of the selected disp components (includes equivalents) */
  TRA_STRESS_2_STRESS_COMP,	/* extraction of the selected stress components (includes equivalents) */
  TRA_NOE_ELEM_2_NOE_VECTEUR,	/* Passage des noeuds des elements aux noeuds */
  TRA_TG_2_TG_COMP,		/* extraction of the selected TG and TF components (includes equivalents) */
  TRA_NOE_ELEM_2_MIDNOE_ELEM	/* average value to midside nodes on elements */
} E_transformation;

/* Operateur mathematique "scalarisant" */
typedef enum {
  MATH_IDENTITE,
  MATH_TENS_COMPO,
  MATH_TENS_VP,
  MATH_TENS_VP_MAX,
  MATH_TENS_MISES,
  MATH_TENS_TRESCA,
  MATH_VEC_COMPO,
  MATH_SCAL_ABS,
  MATH_TORS_COMPO,
  MATH_TENS_MSSHEAR
} E_math_scal;

/* Operateur globalisant */
typedef enum {
  GLOB_IDENTITE,
  GLOB_SOMME,
  GLOB_MAX,
  GLOB_MOY
} E_globalisant;


/* Internal criteria */
typedef enum {
  CRI_PAS_DE_CRITERE, 	/* Critere non calculable */
  CRI_E_M_STRESS, 	/* max de composantes des contraintes sur un groupe d'elements */
  CRI_E_M_STRAIN, 	/* max de composantes des deformation sur un groupe d'elements */
  CRI_E_M_VONMISES, 	/* max de Vonmises sur un groupe d'elements */
  CRI_E_M_TRESCA, 	/* max de Tresca sur un groupe d'elements */
  CRI_P_M_STRESS, 	/* max de composantes des contraintes sur un groupe d'elements */
  CRI_P_M_STRAIN, 	/* max de composantes des deformation sur un groupe d'elements */
  CRI_P_M_FORCE, 	/* max de composantes des forces internes sur un groupe d'elements */
  CRI_P_M_VONMISES, 	/* max de Vonmises sur un groupe d'elements */
  CRI_P_M_TRESCA, 	/* max de Tresca sur un groupe d'elements */
  CRI_N_M_STRESS, 	/* max de composantes des contraintes sur un groupe d'elements */
  CRI_N_M_STRAIN, 	/* max de composantes des deformation sur un groupe d'elements */
  CRI_N_M_VONMISES, 	/* max de Vonmises sur un groupe d'elements */
  CRI_N_M_TRESCA, 	/* max de Tresca sur un groupe d'elements */
  CRI_MASSE,  		/* Masse d'un groupe d'elements */
  CRI_ENERGY, 		/* Energie de deformation */
  CRI_NE_M_ENERGY,      /* Energie aux noeuds des elements */
  CRI_N_M_DISP, 	/* Max de deplacement sur un groupe de noeuds */
  CRI_N_M_VELO, 	/* Max de vitesse sur un groupe de noeuds */
  CRI_N_M_ACCE, 	/* Max d'acceleration sur un groupe de noeuds */
  CRI_N_M_REAC, 	/* Max de reaction sur un groupe de noeuds */
  CRI_N_S_REAC, 	/* Somme de reaction sur un groupe de noeuds */
  CRI_E_CP, 		/* Contrainte pricipale Si sur un groupe d'elements */
  CRI_E_M_CP, 		/* Max de Contrainte pricipale max sur un groupe d'elements */
  CRI_E_M_DP, 		/* Max de deformation pricipale max sur un groupe d'elements */
  CRI_E_M_FI, 		/* Max de composante d'effort interne */
  CRI_N_M_PERT,		/* Max de perturbation sur un groupe de noeuds */
  CRI_PARAMETER,        /* Parametre */
  CRI_DEFORMEE,         /* Combinaison deplacement | perturbation */
  CRI_ADOMESH_DEF,      /* Deformation de maillage */
  CRI_NE_M_STRESS,      /* Contraintes aux noeuds des elements */
  CRI_NE_M_STRAIN,      /* Deformations aux noeuds des elements */
  CRI_NE_M_FORCE,       /* Forces internes aux noeuds des elements */
  CRI_FREQUENCE,        /* Ieme frequence brute */
  CRI_FREQUENCE_ID,     /* Ieme frequence suivie */
  CRI_N_M_MODE, 	/* Max de deplacement modal sur un groupe de noeuds */
  CRI_N_M_MODE_ID, 	/* Max de deplacement modal sur un groupe de noeuds */
  CRI_ENERGY_MODALE,    /* Energie de deformation modale */
  CRI_ENERGY_MODALE_ID, /* Energie de deformation modale ( mode identifie ) */
  CRI_DEFOR_MODALE,     /* perturbation + mode */
  CRI_DEFOR_MODALE_ID,  /* perturbation + mode */
  CRI_NE_M_ENER_MOD,	/* Modal strain energy */
  CRI_NE_M_ENER_MOD_ID,	/* Modal Strain Energy ( identified mode ) */
  CRI_NULL,             /* Criterion always equal to zero */
  CRI_TOUT,             /* The whole RES */
  CRI_N_M_MODEU, 	/* Max de deplacement modal sur un groupe de noeuds */
  CRI_E_DP, 		/* Deformation pricipale Si sur un groupe d'elements */
  CRI_TEMPERATURE,      /* Temperature */
  CRI_FLUX,		/* Thermal Flux */
  CRI_TG,
  CRI_TF,
  CRI_N_M_TG,
  CRI_NE_M_TG,
  CRI_N_M_TF,
  CRI_NE_M_TF,
  CRI_N_M_TG_C,
  CRI_N_M_TF_C,
  CRI_NB_VARIABLES,     /* Number of boolean variables */
  CRI_N_M_DISP_C,	/* displacement components: ux, uy, ... magn u, magn r */
  CRI_N_M_STRESS_C,	/* stresses components: xx, yy, ... cp1, cp2... vmises, tresca... */
  CRI_N_M_STRAIN_C,	/* strain components: */
  CRI_N_MSSHEAR,        /* Max shear stress on node */
  CRI_E_MSSHEAR,	/* Max shear stress on element */
  CRI_N_M_MSSHEAR,      /* Max of max shear stress Nodes */
  CRI_E_M_MSSHEAR,      /* Max of max shear stress Elements */
  CRI_N_M_SIGNORM,	/* Max normal stress (xy, xz, yz) Nodes */
  CRI_E_M_SIGNORM,	/* Max normal stress (xy,xz, yz) Elements */
  CRI_N_CP,		/* Contrainte principale Si aux noeuds */
  CRI_N_M_CP,		/* max de contrainte principale max aux noeuds */
  CRI_N_M_MODE_C,	/* mode components: ux, uy, ... magn u, magn r */
  CRI_N_M_FORCE,        /* Forces internes a un noeud */
  CRI_N_M_FORCE_C,      /* Forces components */
  CRI_N_M_REACTION_C,   /* Reactions components */
  CRI_N_M_TEMP,         /* Node Temperature */
  CRI_N_M_VOLT, 
  CRI_N_M_AZ,
  CRI_N_M_B,
  CRI_N_M_H,
  CRI_E_M_JT,
  CRI_N_M_FMAG
} E_critere;

/* Transformation of results */
typedef enum {
  GRP_IDENTITE,
  GRP_ELEM_2_NOEUD,
  GRP_NOEUD_2_ELEM,
  GRP_NOEUD_2_ELEM_2_NOEUD
} E_gr2gr;

/* External / Internal criteria mapping table */
typedef enum {
  PAS_DE_GROUPE,
  GROUPE_A_UN_NOEUD,
  GROUPE_A_UN_ELEMENT,
  GROUPE_DE_NOEUDS,
  GROUPE_D_ELEMENTS,
  GROUPE_TOUT_NOEUD,
  GROUPE_TOUT_ELEMENT,
  GROUPE_TOUT_GROUPE,
  GROUPE_DE_GROUPES
} E_creagroup;

/* Resultats de l'Optimisation */
typedef enum {
  DONE,
  ADMISSIBLE,
  PAS_PT_ADMISSIBLE,
  CONVERGENT,
  NON_CONVERGENT,
  INTERROMPU
} E_OPT_status;

/* Context solveur */
typedef enum {
  SDRC_VA	= 0,
  SDRC_VA_LITE	= 1,
  ANSYS_TAYLOR	= 2,
  ANSYS_PADE	= 3,
  ANSYS_FAST    = 4,
  ANSYS_AUTO    = 5,
  ADOMESH_ONLY  = 6
} E_solveur;

typedef enum {
  E_CELEM_SUPPRESSED,
  E_CELEM_PRESCRIBED,
  E_CELEM_CE,
  E_CELEM_CP,
  E_CELEM_HICE
} E_celem_type;




/* CS code (CSC) used with T_critere, to define the post-processing CS.
 * Negative values for CS codes, positive values reserved for CS labels.
 */
#define CSC_NODAL	-1
#define CSC_GLOBAL	-2


/* type champ pour tableau_resultat */
typedef enum {
  E_PASDECHAMP=0,
  E_NUMERO_NOEUD,
  E_NUMERO_ELEMENT,
  E_NOMDUGROUPE,
  E_NOMDUMODE,
  E_NUMERODUMODE,
  E_MODE_NOEUD,
  E_NUMODE_NOEUD,
  E_MODE_ELEMENT,
  E_NUMODE_ELEMENT,
  E_MODE_GROUPE,
  E_NUMODE_GROUPE
} E_champ_type;

/* 
 * Disponibilite du resultat selon le contexte: codage bit a bit 
 * - 0: indisponible
 * - STAT_ADOC_CONTOUR: dispo si statique, post contour et .adoc existe
 * - DYN_BDM_ADOC_CONTOUR: dispo si dynamique, post contour, .bdm et .adoc existent
 * - etc...
 */
#define DISP_STAT 	1 /* dispo en statique */
#define DISP_DYNA 	2 /* dispo en dynamique */	
#define CONTOUR_UNI	3 /* dispo en contour SEULEMENT */
#define DISP_BDM	4 /* dispo des qu'on a un .bdm/.mdb */
#define DISP_ADOC	5 /* dispo des qu'on a un .adoc */
#define DISP_HARM       6 /* harmonique */
#define DISP_BUCK       7 /* buckling */

/* codages cle en main pour ecriture table plus facile */
#define INDISPONIBLE		0
#define STAT_CONTOUR		(1u<<DISP_STAT)|(1u<<CONTOUR_UNI)
#define DYNA_CONTOUR		(1u<<DISP_DYNA)|(1u<<CONTOUR_UNI)
#define HARM_CONTOUR		(1u<<DISP_HARM)|(1u<<CONTOUR_UNI)
#define STAT_DYN_BDM_CONTOUR	(1u<<DISP_STAT)|(1u<<DISP_DYNA)|(1u<<DISP_BDM)|(1u<<CONTOUR_UNI)
#define STAT_DYNA_ADOC		(1u<<DISP_STAT)|(1u<<DISP_DYNA)|(1u<<DISP_ADOC)
#define DYNA_BDM_CONTOUR	(1u<<DISP_STAT)|(1u<<DISP_BDM)|(1u<<CONTOUR_UNI)
#define DYNA_ADOC_CONTOUR	(1u<<DISP_DYNA)|(1u<<DISP_ADOC)|(1u<<CONTOUR_UNI)
#define HARM_ADOC_CONTOUR	(1u<<DISP_DYNA)|(1u<<DISP_ADOC)|(1u<<CONTOUR_UNI)
#define STAT_ADOC		(1u<<DISP_STAT)|(1u<<DISP_ADOC)
#define DYNA_ADOC		(1u<<DISP_DYNA)|(1u<<DISP_ADOC)
#define HARM_ADOC		(1u<<DISP_HARM)|(1u<<DISP_ADOC)
#define BUCK_ADOC		(1u<<DISP_BUCK)|(1u<<DISP_ADOC)
#define DYNA_BUCK_ADOC		(1u<<DISP_DYNA)|(1u<<DISP_BUCK)|(1u<<DISP_ADOC)
#define DYNA_BUCK_ADOC_CONTOUR	(1u<<DISP_DYNA)|(1u<<DISP_BUCK)|(1u<<DISP_ADOC)|(1u<<CONTOUR_UNI)

#define STAT_ADOC_CONTOUR	(1u<<DISP_STAT)|(1u<<DISP_ADOC)|(1u<<CONTOUR_UNI)
#define STAT_BDM_ADOC_CONTOUR	(1u<<DISP_STAT)|(1u<<DISP_ADOC)|(1u<<CONTOUR_UNI)|(1u<<DISP_BDM)

#define DYNA_BDM_ADOC_CONTOUR	(1u<<DISP_DYNA)|(1u<<DISP_BDM)|(1u<<DISP_ADOC)|(1u<<CONTOUR_UNI)
#define HARM_BDM_ADOC_CONTOUR	(1u<<DISP_DYNA)|(1u<<DISP_BDM)|(1u<<DISP_ADOC)|(1u<<CONTOUR_UNI)


#define COMP_SCALAR	-1

/* type de point */
typedef enum {
  E_NO_POINT,
  E_POINT,
  E_MODE,
  E_POINTETMODE
} E_point_type;

/* type de composantes */
typedef enum {
  E_NO_COMPONENT,
  E_STRAIN_COMPONENT,
  E_REACTION_COMPONENT,
  E_CP_COMPONENT,
  E_DISP_COMPONENT,
  E_FORCE_COMPONENT,
  E_NUM_COMPONENT,
  E_ALL_COMPONENTS,
  E_STRESS_EQ_COMPONENT,
  E_TG_COMPONENT,
  E_TF_COMPONENT
} E_component_type;

#define RESULTAT_REEL     0
#define RESULTAT_COMPLEXE 1

/* Classes des resultats */
typedef enum {
  E_CLASS_NODE=1,
  E_CLASS_ELEM,
  E_CLASS_MOD,
  E_CLASS_GRP,
  E_CLASS_MOD_CTR,
  E_CLASS_GRP_CTR
} E_result_class;


#define CADOE_NAMESIZE 249 	/* defini dans SxConstants.h : SX_NAMESIZE = FNAME_MAX+1 = 248+1 */
#define CADOE_FILENAMEMAX 261 	/* defini dans SxConstants.h : SX_FILENAMEMAX = INPUT_PATH_MAX+1 = 260+1 */


#endif /* __CONS_SOLVER_H__ */
