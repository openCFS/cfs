/* sid 50.1 copy of FEM_meshTree.h last changed by upd111 on 2004/11/04 18:31:20 */

/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 1999 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_MeshTree.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_MeshTree.h
 *  header file for FEM_MeshTree.cpp
 *
 */
#ifndef FEM_MeshTREE_H
#define FEM_MeshTREE_H


typedef enum { kQuad2DTree = 0, kQuad3DTree, kOctTree, kQuad2DAndOctTree, kQuad3DAndOctTree } _eTreeType;



#ifdef __cplusplus
extern "C" {
#endif

    void FEM_buildMeshTree ( MESH_OBJ obj_mesh, _eTreeType eType );
    void FEM_detroyMeshTree ( MESH_OBJ obj_mesh );

#ifdef __cplusplus
}
#endif

#endif

