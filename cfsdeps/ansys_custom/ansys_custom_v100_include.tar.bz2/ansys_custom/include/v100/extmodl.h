/* sid 50.6 copy of extmodl.h last changed by dc on 2005/06/06 20:11:26 */
/* CADOE */
/**
 *	extmodl.h -- Fonctions d'interface modl /va
 *  
 * |Version: $Id$
 *
 *   
 **/


#ifndef __EXTMODL_X_DEJA_INCLUS__
#define __EXTMODL_X_DEJA_INCLUS__ 1

#include "sx_CADOE_solver.h"
#include "computer.h"
#include "sysparh.h"

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#if defined(LOWERCASENOUNDER_SYS)
#define mpinqr mpinqr
#define ndinqr ndinqr
#define mpget mpget
#define fx_ls_extmodl fx_ls_extmodl
#define fx_ls_solve fx_ls_solve
#define fx_nm_solve fx_nm_solve
#define fx_csnm_solve fx_csnm_solve
#define nodbac nodbac
#define ndgang ndgang
#define ndgxyz ndgxyz
#define elebac elebac
#define elmget elmget
#define etyget etyget
#define rlget rlget
#define elmiqr elmiqr
#define mpinqr mpinqr
#define cpinqr cpinqr
#define ceinqr ceinqr
#define cpget cpget
#define ceget ceget
#define ceput ceput
#define cpput cpput
#define disput disput
#define sectinqr sectinqr
#define ParTabChek partabchek
#define lstcmd lstcmd
#define ShellSection shellsection
#define GetShellSecData getshellsecdata
#define GetBeamAsecSecData getbeamasecsecdata 
#define GetShellLayerTh getshelllayerth
#define GetShellLayerAngle getshelllayerangle
#define get_cmp_iname get_cmp_iname
#define cmpsel cmpsel
#define cmplocDB cmplocdb
#define cmpiqrDB cmpiqrdb
#define cmpiqrDBL cmpiqrdbl
#define cmpnxtDB cmpnxtdb
#define cmpnxtDBL cmpnxtdbl
#define get_cmp_card get_cmp_card
#define get_cmp_type get_cmp_type
#define ndsel ndsel
#define elsel elsel
#define GetNbLayers getnblayers
#define GetSectionMatIds getsectionmatids
#define getsumnbnodes getsumnbnodes
#define get_nnd_cont get_nnd_cont
#define sx_store_hice sx_store_hice
#endif

#if defined(UPPERCASENOUNDER_SYS)
#define mpinqr MPINQR
#define ndinqr NDINQR
#define mpget MPGET
#define fx_ls_extmodl FX_LS_EXTMODL
#define fx_ls_solve FX_LS_SOLVE
#define fx_nm_solve FX_NM_SOLVE
#define fx_csnm_solve FX_CSNM_SOLVE
#define nodbac NODBAC
#define ndgang NDGANG
#define ndgxyz NDGXYZ
#define elebac ELEBAC
#define elmget ELMGET
#define etyget ETYGET
#define rlget RLGET
#define elmiqr ELMIQR
#define mpinqr MPINQR
#define cpinqr CPINQR
#define ceinqr CEINQR
#define cpget CPGET
#define ceget CEGET
#define ceput CEPUT
#define cpput CPPUT
#define disput DISPUT
#define sectinqr SECTINQR
#define ParTabChek PARTABCHEK
#define lstcmd LSTCMD
#define ShellSection SHELLSECTION
#define GetShellSecData GETSHELLSECDATA
#define GetBeamAsecSecData GETBEAMASECSECDATA 
#define GetShellLayerTh GETSHELLLAYERTH
#define GetShellLayerAngle GETSHELLLAYERANGLE
#define get_cmp_iname GET_CMP_INAME
#define cmpsel CMPSEL
#define cmpiqrDB CMPIQRDB
#define cmpiqrDBL CMPIQRDBL
#define cmplocDB CMPLOCDB
#define cmpnxtDB CMPNXTDB
#define cmpnxtDBL CMPNXTDBL
#define get_cmp_card GET_CMP_CARD
#define get_cmp_type GET_CMP_TYPE
#define ndsel NDSEL
#define elsel ELSEL
#define GetNbLayers GETNBLAYERS
#define GetSectionMatIds GETSECTIONMATIDS
#define getsumnbnodes GETSUMNBNODES
#define get_nnd_cont GET_NND_CONT
#define sx_store_hice SX_STORE_HICE
#endif

#if defined(LOWERCASEUNDER_SYS)
#define mpinqr mpinqr_
#define ndinqr ndinqr_
#define mpget mpget_
#define fx_ls_extmodl fx_ls_extmodl_
#define fx_ls_solve fx_ls_solve_
#define fx_nm_solve fx_nm_solve_
#define fx_csnm_solve fx_csnm_solve_
#define nodbac nodbac_
#define ndgang ndgang_
#define ndgxyz ndgxyz_
#define elebac elebac_
#define elmget elmget_
#define etyget etyget_
#define rlget rlget_
#define elmiqr elmiqr_
#define mpinqr mpinqr_
#define cpinqr cpinqr_
#define ceinqr ceinqr_
#define cpget cpget_
#define ceget ceget_
#define ceput ceput_
#define cpput cpput_
#define disput disput_
#define sectinqr sectinqr_
#define ParTabChek partabchek_
#define lstcmd lstcmd_
#define ShellSection shellsection_
#define GetShellSecData getshellsecdata_
#define GetBeamAsecSecData getbeamasecsecdata_
#define GetShellLayerTh getshelllayerth_
#define GetShellLayerAngle getshelllayerangle_
#define get_cmp_iname get_cmp_iname_
#define cmpsel cmpsel_
#define cmplocDB cmplocdb_
#define cmpiqrDB cmpiqrdb_
#define cmpiqrDBL cmpiqrdbl_
#define cmpnxtDB cmpnxtdb_
#define cmpnxtDBL cmpnxtdbl_
#define get_cmp_card get_cmp_card_
#define get_cmp_type get_cmp_type_
#define ndsel ndsel_
#define elsel elsel_
#define GetNbLayers getnblayers_
#define GetSectionMatIds getsectionmatids_
#define getsumnbnodes getsumnbnodes_
#define get_nnd_cont get_nnd_cont_
#define sx_store_hice sx_store_hice_
#endif

  INT FUNCTION ndinqr( INT*, INT *);
  INT FUNCTION elmiqr( INT*, INT* );
  INT FUNCTION nodbac( INT* );
  INT FUNCTION ndgang( INT*, DOUBLE* );
  INT FUNCTION ndgxyz( INT*, DOUBLE* );
  INT FUNCTION elebac( INT* );
  INT FUNCTION elmget( INT*, INT*, INT* );
  INT FUNCTION etyget( INT*, INT* );
  SUBROUTINE rlget( INT*, DOUBLE* );
  INT FUNCTION mpget( INT*, INT*, DOUBLE*, DOUBLE* );
  INT FUNCTION mpinqr( INT*, INT*, INT* );
  INT FUNCTION cpinqr(INT*, INT*);
  INT FUNCTION ceinqr(INT*, INT*);
  INT FUNCTION cpget(INT*, INT*);
  INT FUNCTION ceget(INT*, INT*, DOUBLE*);
  SUBROUTINE ceput(INT*, INT*, INT*, DOUBLE*);
  SUBROUTINE cpput(INT*, INT*, INT*);
  SUBROUTINE disput( INT*, INT*, DOUBLE*);
  INT FUNCTION sectinqr( INT*, INT*);
  INT FUNCTION lstcmd( INT* );
  INT FUNCTION ParTabChek (DOUBLE *);
  SUBROUTINE ShellSection(INT *);
  SUBROUTINE GetShellSecData(INT*, INT* ,INT*, INT*, INT*, INT*, INT*, INT*, DOUBLE*,  DOUBLE*, DOUBLE*, DOUBLE*, DOUBLE*, DOUBLE*, DOUBLE*, DOUBLE*, INT*, DOUBLE*);
  SUBROUTINE GetBeamAsecSecData(INT *, DOUBLE *);
  SUBROUTINE GetShellLayerTh(INT*, INT*, DOUBLE*);
  SUBROUTINE GetShellLayerAngle(INT*, INT*, DOUBLE*);
  SUBROUTINE get_cmp_iname(INT*, INT*);
  SUBROUTINE cmpsel(FCHAR(toto1), FCHAR(toto2) FCHARL(toto1_len) FCHARL(toto2_len) );
  INT FUNCTION cmplocDB(FCHAR(toto1) FCHARL(toto1_len));
  INT FUNCTION cmpiqrDB(INT*, INT*);
  LONG FUNCTION cmpiqrDBL(INT*, INT*);
  SUBROUTINE cmpnxtDB(INT*, INT*, INT*, INT*);
  SUBROUTINE cmpnxtDBL(INT*, LONG*,INT*,INT*);
  SUBROUTINE get_cmp_card (INT*);
  SUBROUTINE get_cmp_type (FCHAR(toto), INT* FCHARL(toto_len));
  SUBROUTINE ndsel(INT*, INT*);
  SUBROUTINE elsel(INT*, INT*);
  SUBROUTINE GetNbLayers(INT*, INT*);
  SUBROUTINE GetSectionMatIds(INT*, INT*, INT*, INT*, INT*);
  SUBROUTINE getsumnbnodes( INT* );
  SUBROUTINE get_nnd_cont (INT*, INT*, INT*);
  void vastssiz( int *stssiz );
  T_statut MOD_stssiz( T_modele *modele );
  SUBROUTINE sx_store_hice(INT*);

  SUBROUTINE fx_nm_solve( INT *ier, INT *nb_ddl, INT *restrt_f, INT *where_f,
			  INT *kdone_f);
  extern T_modele *ITF_extraire_modele_fs( T_statut *ier);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif	 /* __EXTMODL_X_DEJA_INCLUS__ */
