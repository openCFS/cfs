/* sid 60.9 copy of INIS_Defines.h last changed by rjayasee on 2006/06/07 20:16:11 */
/* ---------------------------------------------------------------------- */
/* *** copyright(c) 2006 SAS IP, Inc.  All rights reserved. */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */

#include "ansys.h"

#if !defined(INIS_DEFINES_H)
#define INIS_DEFINES_H

/* Data Format */
#define INIS_DATAFORMAT     101

/* Header Information */
#define INIS_HEADERSIZE      10
#define INIS_DATAHEAD        6

/*Data Types*/
#define INIS_UNKNOWN        0
#define INIS_INITIALSTRESS  1
#define INIS_PLASTICSTRAIN  2
#define INIS_ELASTICSTRAIN  3
#define INIS_CREEPSTRAIN    4
#define INIS_THERMALSTRAIN  5
#define INIS_SWELLINGSTRAIN 6
#define INIS_TOTALMECHSTRAIN  7
#define INIS_NLVAR  8
#define INIS_SVAR  9

#define INIS_CSYS           10

/*Data Source*/
#define INIS_DSFROMFILE     1
#define INIS_DSFROMCOMMAND  2

/* Header Positions*/
#define INI_RECORDSIZEPOS 0
#define INI_DATAFORMATPOS 1    
#define INI_HEADERSIZEPOS 2
#define INI_ISMATBASEDPOS 3
#define INI_DATASOURCEPOS 8

#define NNMAX 89
const int MAT_NumMaterialRecords = 20 ;

#define NCOMPN 52

#define EL_MAT          1
#define EL_TYPE         2
#define EL_REAL         3
#define EL_SECT         4
#define EL_CSYS         5
#define EL_DEAD         6
#define EL_SOLID        7
#define EL_SHAPE        8
#define EL_OBJOPTIONS   9
#define EL_PEXCLUDE     10
#define EL_DIM          10

/*
#define INIS_NEW(x,y) (x*)cAnsMemAlloc(sizeof(x)*y,0,__FILE__,__LINE__)
#define INIS_DELETE(x) cAnsMemFree((x),__FILE__,__LINE__)
*/

#define INIS_MALLOC(x)  ANS_TagMemManagerMalloc((x),__FILE__,__LINE__)
#define INIS_FREE(x)  ANS_TagMemManagerFree((x),__FILE__,__LINE__)

#define INIS_NEW(x,y) (x*)ANS_TagMemManagerMalloc(sizeof(x)*y,__FILE__,__LINE__)
#define INIS_DELETE(x) ANS_TagMemManagerFree((x),__FILE__,__LINE__)


#endif
