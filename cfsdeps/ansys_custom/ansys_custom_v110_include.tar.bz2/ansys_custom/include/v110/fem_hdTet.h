/* sid 60.1 copy of fem_hdTet.h last changed by upd111 on 2005/07/21 19:42:18 */
/*  fem_hdTet.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  fem_hdTet.h
 *  Prototypes and macros for hexdom tet functions
 *
 */

#ifndef HDTET_H
#define HDTET_H

/*------------------------ Constants -------------------------------------------*/
#define EXIT_CANT_REDUCE -995
static const DOUBLE ON_LINE_TOL = 1.0e-3;
static const DOUBLE NEG_METRIC_TOL = 1.0e-4;

/*------------------------ Data Structures -------------------------------------*/
typedef enum {TET_SWAP22,
              TET_SWAP23,
              TET_SWAP32} TET_SWAP_ENUM;

/*------------------------ Globals - used in only FEM_hd files -----------------*/

/*------------------------ Prototypes ------------------------------------------*/

INT      fem_hdTetEntityAtVector        ( NODE_OBJ obj_node,
                                          VECTOR3D *ps_vec,
                                          ANY_OBJ *p_obj_entity,
                                          ENTITY_ENUM *p_entype );
FEM_BOOLEAN  fem_hdIsTetAtVector        ( ELEMENT_OBJ obj_tet,
                                          NODE_OBJ obj_node,
                                          VECTOR3D *ps_vec );
INT      fem_hdTetEntityAtVectorFromEdge( EDGE_OBJ obj_edge,
                                          VECTOR3D *ps_vec,
                                          ANY_OBJ *p_obj_entity,
                                          ENTITY_ENUM *p_entype );
INT      fem_hdTetEntityAtVectorFromFace( EDGE_OBJ obj_face,
                                          VECTOR3D *ps_vec,
                                          ELEMENT_OBJ *p_obj_tet );
INT      fem_hdTetInsertNode            ( NODE_OBJ obj_node,
                                          VECTOR3D *ps_vec,
                                          ADDRESS_TYP obj_entity,
                                          ENTITY_ENUM entype,
                                          DOUBLE frontlen,
                                          EDGE_OBJ *p_obj_edge );
INT      fem_hdTet23Swap                ( ELEMENT_OBJ obj_tet1,
                                          ELEMENT_OBJ obj_tet2,
                                          FACE_OBJ obj_tri,
                                          FEM_BOOLEAN check,
                                          FEM_BOOLEAN *p_swapped );
INT      fem_hdTet22Swap                ( ELEMENT_OBJ obj_tet1,
                                          ELEMENT_OBJ obj_tet2,
                                          FACE_OBJ obj_tri,
                                          FEM_BOOLEAN check,
                                          FEM_BOOLEAN *p_swapped );
INT      fem_hdTet32Swap                ( EDGE_OBJ obj_edge,     
                                          FEM_BOOLEAN check,
                                          FEM_BOOLEAN *p_swapped );
INT      fem_hdTet44Swap                ( EDGE_OBJ obj_edge,
                                          INT config,
                                          FEM_BOOLEAN check,
                                          FEM_BOOLEAN *p_swapped );
INT      fem_hdTetSplit4                ( ELEMENT_OBJ obj_tet,
                                          NODE_OBJ *p_obj_node,
                                          VECTOR3D *ps_node,
                                          FEM_BOOLEAN centroid );
INT      fem_hdTetSplitAtEdge           ( EDGE_OBJ obj_edge,
                                          VECTOR3D *ps_split,
                                          NODE_OBJ *p_obj_node );
INT      fem_hdTetSplitAtFace           ( FACE_OBJ obj_face,
                                          VECTOR3D *ps_split,
                                          NODE_OBJ *p_obj_node );
INT      fem_hdTetReduceShell           ( EDGE_OBJ obj_edge,
                                          INT target_ntet,
										            INT *p_numtets );
FEM_BOOLEAN  fem_hdTetInverted              ( NODE_OBJ obj_a,
                                          NODE_OBJ obj_b,
                                          NODE_OBJ obj_c,
                                          NODE_OBJ obj_d );
DOUBLE   fem_hdTetVol                   ( VECTOR3D *a,
                                          VECTOR3D *b,
                                          VECTOR3D *c,
                                          VECTOR3D *d );
INT      fem_hdTetSupressEdge           ( EDGE_OBJ obj_edge,
                                          FEM_BOOLEAN *p_swapped,
                                          INT *p_ntets );
INT      fem_hdTetCollapseEdge          ( EDGE_OBJ obj_edge,
                                          NODE_OBJ *p_obj_node,
                                          FACE_OBJ *p_obj_lastface ); 
INT      fem_hdTetDoCollapse            ( EDGE_OBJ obj_edge,
                                          ELEMENT_OBJ *aobj_elems,
                                          INT num_elems,
                                          NODE_OBJ obj_nodeA,
                                          NODE_OBJ obj_nodeB,
                                          ELEMENT_OBJ *aobj_Aelems,
                                          INT num_Aelems,
                                          ELEMENT_OBJ *aobj_Belems,
                                          INT num_Belems,
                                          VECTOR3D *ps_merge,
                                          NODE_OBJ *p_obj_node,
                                          FACE_OBJ *p_obj_lastface ); 
INT      fem_hdTetCheckCollapse         ( EDGE_OBJ obj_edge,
                                          FACE_OBJ obj_facebegin,
                                          FACE_OBJ obj_faceend,
                                          ELEMENT_OBJ obj_elembegin,
                                          ELEMENT_OBJ *aobj_elems,
                                          INT *p_num_elems,
                                          ELEMENT_OBJ *aobj_Aelems,
                                          INT *p_num_Aelems,
                                          ELEMENT_OBJ *aobj_Belems,
                                          INT *p_num_Belems,
                                          NODE_OBJ *pobj_nodeA,
                                          NODE_OBJ *pobj_nodeB,
                                          VECTOR3D *ps_merge );    

#endif

