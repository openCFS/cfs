/* sid 60.2 copy of FEM_vlMeshData.h last changed by jtm on 2005/08/23 13:33:31 */
#ifndef FEM_VLMESHDATA________________H
#define FEM_VLMESHDATA________________H
#include "FEM_MeshData.h"
#include "FEM_deque.h"
#include "FEM_swPath.h"
#include "FEM_swSrcTrg.h"

class VOLMSHDAT_TYP : public MSHDAT_TYP {

   private:
      unsigned m_sweepable:1;
      FEM_BOOLEAN m_bSweepableSuppress;
      unsigned m_hexdommeshable:1;
      unsigned m_tetmeshable:1;
      unsigned m_needsmidnodes:1;
      unsigned m_projectmids:1;
      unsigned m_dropmidnodes:1;
      unsigned m_sweepwedges:1;
      INT m_num_kps;
      INT *m_a_corner_count;
      KP_PTYP *m_aobj_kps;
      INT m_num_matches;
      INT m_index;
      INT m_cursweepdir;
      DOUBLE m_bias;
      SRCTRG_TYPE m_a_srctrg[3];
      SWPATH_TYP *m_aobj_paths;
      SWPATH_PTYP *m_apobj_paths;
      INT         m_iAllocatedPaths;
      INT         m_iPathIterCount;
      FEM_BOOLEAN m_bUserSpecifiedData;

   public:
      VOLMSHDAT_TYP() { };
      ~VOLMSHDAT_TYP() { Delete(); };

      void Init( ) { InitMSH_TYP();
                     m_meshed = 0; m_num_kps = 0;
                     m_aobj_kps = NULL; m_a_corner_count = NULL;
                     m_apobj_paths = NULL; m_aobj_paths = NULL;
                     m_sweepable = 0; m_hexdommeshable = 0;
                     m_bSweepableSuppress=FALSE;
                     m_tetmeshable = 0; m_num_matches = 0;
                     m_index = 0; m_needsmidnodes = 0;
                     m_projectmids = 0; m_dropmidnodes = 0;
                     m_sweepwedges = 0;
                     m_cursweepdir = 0;
                     m_numdivs = 0; m_bias = 1.0;
                     m_a_srctrg[0].src = m_a_srctrg[0].trg = 
                     m_a_srctrg[1].src = m_a_srctrg[1].trg = 
                     m_a_srctrg[2].src = m_a_srctrg[2].trg = NULL;
                     m_iAllocatedPaths = 0;
                     m_iPathIterCount = 0;};
      void Delete( ) { m_meshed = 0;
                       m_sweepable = 0;
                       m_bSweepableSuppress=FALSE;
                       m_hexdommeshable = 0;
                       m_tetmeshable = 0;
                       m_num_matches = 0;
                       m_index = 0;
                       m_needsmidnodes = 0;
                       m_projectmids = 0;
                       m_dropmidnodes = 0;
                       m_sweepwedges = 0;
                       m_cursweepdir = 0;
                       m_numdivs = 0;
                       m_bias = 1.0;
                       if ( m_aobj_paths ) {
                          for ( INT i = 0; i < m_num_kps; i++ ) {
                             m_aobj_paths[i].Delete();
                          }
                       }
                       FEM_Free_C( m_aobj_paths );
                       FEM_Free_C( m_apobj_paths );
                       FEM_Free_C( m_aobj_kps );
                       FEM_Free_C( m_a_corner_count );
                       m_num_kps = 0; 
                       m_iAllocatedPaths = 0;
                       m_iPathIterCount = 0;};

      void SetIndex( const INT index = 0 ) { m_index = index; };
      INT Index( ) const { return m_index; };

      void SetSweepNdiv( const INT ndiv = 0 ) 
      { 
          this->SetNumDivs(ndiv); 
      };
      INT SweepNdiv( ) const { return this->NumDivs(); };
      INT GetSweepNdiv() {
          return SweepNdiv() ; // just to make consistent set-get interfaces
      }

      void SetSweepBias( const DOUBLE bias = 0 ) { m_bias = bias; };
      FEM_BOOLEAN UserSweepBias( ) const
      {
         if ( m_bias < 1.01 && m_bias > 0.99 ) return FALSE;
         else return TRUE;
      }
      DOUBLE SweepBias( ) const { return m_bias; };

      void SetSweepable( const FEM_BOOLEAN stat = TRUE )
      {
         if ( stat )
             m_sweepable = 1;
         else 
             m_sweepable = 0;
      };
      void setSweepableSuppress( FEM_BOOLEAN val ) { if ( this->IsTetMeshable()) { m_bSweepableSuppress = val;}};
      FEM_BOOLEAN getSweepableSuppress() { return m_bSweepableSuppress;}
      FEM_BOOLEAN IsSweepable( ) const
      {
         if ( m_sweepable == 1 ) return TRUE;
         else return FALSE;
      };

      void SetSweepWedges( const FEM_BOOLEAN stat = TRUE )
      {
         if ( stat ) m_sweepwedges = 1;
         else m_sweepwedges = 0;
      };
      
      FEM_BOOLEAN SweepWedges( ) const
      {
         if ( m_sweepwedges == 1 ) return TRUE;
         else return FALSE;
      };

      INT SetSweepSrcTrg( const SRCTRG_TYPE a_srctrg[3],
                          const INT num_matches );
      INT GetNumSrcTrgs( ) const { return m_num_matches; };
      void SetNumSrcTrgs( INT num_matches ) { m_num_matches = num_matches; };
      void SetSweepDir( INT dir ) { m_cursweepdir = dir; };

      INT GetSrc( AREA_PTYP &obj_sarea ) const
      { 
         obj_sarea = m_a_srctrg[m_cursweepdir].src;
         return EXIT_SUCCESS;
      }
      AREA_PTYP GetSrc( ) const
      { 
         return m_a_srctrg[m_cursweepdir].src;
      }
      INT GetTrg( AREA_PTYP &obj_tarea ) const
      { 
         obj_tarea = m_a_srctrg[m_cursweepdir].trg;
         return EXIT_SUCCESS;
      }
      AREA_PTYP GetTrg( ) const
      { 
         return m_a_srctrg[m_cursweepdir].trg;
      }
      INT GetSrcTrg( AREA_PTYP &obj_sarea, AREA_PTYP &obj_tarea ) const
      { 
         obj_sarea = m_a_srctrg[m_cursweepdir].src;
         obj_tarea = m_a_srctrg[m_cursweepdir].trg;
         return EXIT_SUCCESS;
      }
      INT SetSrcTrg( const AREA_PTYP obj_sarea, const AREA_PTYP obj_tarea )
      { 
         m_a_srctrg[m_cursweepdir].src = obj_sarea;
         m_a_srctrg[m_cursweepdir].trg = obj_tarea;
         return EXIT_SUCCESS;
      }
      AREA_PTYP GetSrc( const INT index ) const
      { 
         if ( index >= m_num_matches ) {
            FEM_Error_C( GENERIC, GEN_UNKNOWN_ERROR, FEM_ERROR, NULL );
            return NULL;
         }
         return m_a_srctrg[index].src;
      }
      AREA_PTYP GetTrg( const INT index ) const
      { 
         if ( index >= m_num_matches ) {
            FEM_Error_C( GENERIC, GEN_UNKNOWN_ERROR, FEM_ERROR, NULL );
            return NULL;
         }
         return m_a_srctrg[index].trg;
      }
      INT SetSrcTrg( const INT index, const AREA_PTYP obj_sarea,
                     const AREA_PTYP obj_tarea )
      { 
         if ( index > 2 || index < 0  ) {
            FEM_Error_C( GENERIC, GEN_UNKNOWN_ERROR, FEM_ERROR, NULL );
            return EXIT_FAILURE;
         }
         m_a_srctrg[index].src = obj_sarea;
         m_a_srctrg[index].trg = obj_tarea;
         return EXIT_SUCCESS;
      }

      void SetHexDomMeshable( const FEM_BOOLEAN stat = TRUE )
      {
         if ( stat ) m_hexdommeshable = 1;
         else m_hexdommeshable = 0;
      };

      FEM_BOOLEAN IsHexDomMeshable( ) const
      {
         if ( m_hexdommeshable == 1 ) return TRUE;
         else return FALSE;
      };

      void SetTetMeshable( const FEM_BOOLEAN stat = TRUE )
      {
         if ( stat ) m_tetmeshable = 1;
         else m_tetmeshable = 0;
      };

      FEM_BOOLEAN IsTetMeshable( ) const
      {
         if ( m_tetmeshable == 1 ) return TRUE;
         else return FALSE;
      };

      void SetVol( const VOL_PTYP obj_vol ) { SetCell( obj_vol ); };
      VOL_PTYP GetVol( ) const { return (VOL_PTYP)GetCell(); };

      void SetKpList( KP_PTYP *aobj_kps, const INT num_kps )
      {
         m_aobj_kps = aobj_kps;
         m_num_kps = num_kps;
      };

      KP_PTYP const *KpList( INT & num_kps );
   
      INT CountSweepCorners( );
      INT *CornerCount() const { return m_a_corner_count; };
      void ChangeCornerCount( const INT kp_id, const INT change );

      INT InitFindSweepPath( MODEL_TYP &model );
      INT FindSweepPath( CELL_PTYP obj_srckp, FEM_BOOLEAN &pathfound,
                         SWPATH_TYP &obj_path );

      INT MarkSrcTrgKps( AREA_PTYP obj_sarea, AREA_PTYP obj_tarea );
      INT ForceAxisEndStatus( AREA_PTYP obj_sarea, AREA_PTYP obj_tarea );

      void SetDropMidnodes( const FEM_BOOLEAN status = TRUE )
      {
         if ( status ) m_dropmidnodes = 1;
         else m_dropmidnodes = 0;
      };

      FEM_BOOLEAN CanDropMidnodes( ) const
      {
         if ( m_dropmidnodes == 1 ) return TRUE;
         else return FALSE;
      };

      void SetNeedsMidnodes( const FEM_BOOLEAN status = TRUE )
      {
         if ( status ) m_needsmidnodes = 1;
         else m_needsmidnodes = 0;
      };

      FEM_BOOLEAN NeedsMidnodes( ) const
      {
         if ( m_needsmidnodes == 1 ) return TRUE;
         else return FALSE;
      };

      void SetProjectMids( const FEM_BOOLEAN status = TRUE )
      {
         if ( status ) m_projectmids = 1;
         else m_projectmids = 0;
      };

      FEM_BOOLEAN ProjectMids( ) const
      {
         if ( m_projectmids == 1 ) return TRUE;
         else return FALSE;
      };

      INT SaveSweepPath( const CELL_PTYP obj_skp, const SWPATH_PTYP obj_path );
      SWPATH_PTYP GetSweepPath( const CELL_PTYP obj_skp );
      SWPATH_PTYP GetSweepPath( int idx );
      SWPATH_PTYP SweepPathBeginIter();
      SWPATH_PTYP SweepPathNextIter();

      inline void SetHasUserSpecifiedData( FEM_BOOLEAN bUserSpecifiedData ) { m_bUserSpecifiedData = bUserSpecifiedData; };
      inline FEM_BOOLEAN GetHasUserSpecifiedData( ) { return m_bUserSpecifiedData; };

   private:
      INT RecursivelyFindSweepPath( CELL_PTYP obj_kp, CELL_PTYP obj_pathline,
                                    DEQUE_OBJ obj_linedeque, DEQUE_OBJ obj_visitedLines,
                                    FEM_BOOLEAN &pathfound );
};
typedef class VOLMSHDAT_TYP  *VOLMSHDAT_PTYP;
void FEM_vlMd( VOLMSHDAT_PTYP obj_voldata );
#endif

