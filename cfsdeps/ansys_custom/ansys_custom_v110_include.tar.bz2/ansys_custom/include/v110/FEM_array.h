/* sid 60.1 copy of FEM_array.h last changed by upd111 on 2005/07/21 19:39:13 */
/* ********************************** */
/* *** ansys(r) copyright(c) 1999 *** */
/* *** ansys, inc.                *** */
/* ********************************** */

/*  FEM_array.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_array.h
 *  header file for FEM_array.c
 *
 */
#ifndef FEM_ARRAY_INCLUDE
#define FEM_ARRAY_INCLUDE

/*----------------- Globally accessible function prototypes -----------------*/

#ifdef __cplusplus
extern "C" {
#endif

                        /* ================================================= */
                        /* === FEM_arIsInIntArray: Find a particular integer */
                        /* === value in an array of values.                  */
                        /* === Return: INT location of value in array.  If   */
                        /* === value is not in the array, 0 is returned.     */
                        /* === Location is returned based on FORTRAN array   */
                        /* === indexing (i.e. if value is in 1st location in */
                        /* === array, 1 is returned).                        */
                        /* ================================================= */
INT FEM_arIsInIntArray (
   INT *a_array,        /* (IN)  array to look in for value                  */
   INT value,           /* (IN)  value to look for in a_array                */
   INT dimen  );        /* (IN)  length of a_array                           */

                        /* ================================================= */
                        /* === FEM_arIsInSortedIntArray: Find a particular   */
                        /* === integer value in an array of values.  The     */
                        /* === array must be sorted in ASCENDING_ORDER by    */
                        /* === calling FEM_arSortIntArray().                 */
                        /* === Return: INT location of value in array.  If   */
                        /* === value is not in the array, 0 is returned.     */
                        /* === Location is returned based on FORTRAN array   */
                        /* === indexing (i.e. if value is in 1st location in */
                        /* === array, 1 is returned).                        */
                        /* ================================================= */
INT FEM_arIsInSortedIntArray (
   INT *a_array,        /* (IN)  array to look in for value                  */
   INT value,           /* (IN)  value to look for in a_array                */
   INT dimen  );        /* (IN)  length of a_array                           */

                        /* ================================================= */
                        /* === FEM_arInsertInSortedIntArray: Insert a value  */
                        /* === into a sorted array in such a way that is it  */
                        /* === is still sorted after being inserted.         */
                        /* ================================================= */
void FEM_arInsertInSortedIntArray(
   INT *a_array,        /* (IN)  a sorted array.                             */
   INT value,           /* (IN)  The value to be added to a_array.           */
   INT *dimen );        /* (IN/OUT) The length of a_array.                   */

                        /* ================================================= */
                        /* === FEM_arIntZero: zero out an integer array      */
                        /* ================================================= */
void FEM_arIntZero (
   INT *a_array,        /* (OUT) array to be zeroed out.                     */
   INT dimen  );        /* (IN)  length of a_array                           */

                        /* ================================================= */
                        /* === FEM_arIntInit: Initialize an integer array to */
                        /* === a constant value.                             */
                        /* ================================================= */
void FEM_arIntInit(
   INT *a_array,        /* (OUT) array to be initialized.                    */
   INT dimen,           /* (IN)  length of a_array                           */
   INT constant );      /* (IN)  constant to init array to.                  */

                        /* ================================================= */
                        /* === FEM_arIntMult: multiply a integer array by a  */
                        /* === constant.                                     */
                        /* ================================================= */
void FEM_arIntMult (
   INT *a_result,       /* (OUT) the resulting array                         */
   INT *a_array,        /* (IN)  original array                              */
   INT dimen,           /* (IN)  length of a_array                           */
   INT constant  );     /* (IN)  constant to multiply the array by           */

                        /* ================================================= */
                        /* === FEM_arSortIntArray: sort an integer array     */
                        /* === into either descending or ascending order.    */
                        /* ================================================= */
void FEM_arSortIntArray (
   INT *a_array,        /* (IN/OUT)  the array to sort                       */
   INT dimen,           /* (IN)  length of a_array                           */
   INT direction  );    /* (IN)  either ASCENDING_ORDER or DESCENDING_ORDER  */

                        /* ================================================= */
                        /* === FEM_utGetBiasLocations: Given a DOUBLE array  */
                        /* === (xx) sorted in ascending order and a scalar   */
                        /* === DOUBLE (x), find an integer (j) such that x   */
                        /* === is between xx[j] and xx[j+1].                 */
                        /* === Return: EXIT_SUCCESS or EXIT_FAILURE          */
                        /* ================================================= */
INT FEM_arLocateDbl (
   DOUBLE *xx,                /* (IN)  See description above                 */
   INT n,                     /* (IN)  See description above                 */
   DOUBLE x,                  /* (IN)  See description above                 */
   INT *j );                  /* (OUT) See description above                 */

                        /* ================================================= */
                        /* === FEM_arSortDblArray: sort a DOUBLE array       */
                        /* === into either descending or ascending order.    */
                        /* ================================================= */
void FEM_arSortDblArray (
   DOUBLE *a_array,     /* (IN/OUT)  the array to sort                       */
   INT dimen,           /* (IN)  length of a_array                           */
   INT direction  );    /* (IN)  either ASCENDING_ORDER or DESCENDING_ORDER  */

#define ASCENDING_ORDER 1
#define DESCENDING_ORDER 2

                        /* ================================================= */
                        /* === FEM_arRemoveSortedDuplicates: Remove          */
                        /* === duplicate values in a sorted array.  The array*/
                        /* === must be sorted by FEM_arSortIntArray          */
                        /* === Return: void                                  */
                        /* ================================================= */
void FEM_arRemoveSortedDuplicates (
   INT *a_array,
   INT dimen,
   INT *newdimen  );

                        /* ================================================= */
                        /* === FEM_arRemove: Remove a value from the array.  */
                        /* === Shuffle the values after iloc down to fill    */
                        /* === the gap.                                      */
                        /* === Return: void                                  */
                        /* ================================================= */
void FEM_arRemove(
   INT *a_array,
   INT iloc,
   INT dimen );


#ifdef __cplusplus
}
#endif

#endif

