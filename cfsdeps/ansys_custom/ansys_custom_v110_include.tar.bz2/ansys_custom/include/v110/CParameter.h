/* sid 60.7 copy of CParameter.h last changed by smarguer on 2006/06/01 17:53:42 */
////////////////////////////////////////////////////////////////////////////
//                                                                        //
//          copyright(c) 2006 SAS IP, Inc.  All rights reserved.            //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: CParameter.h $
// $Revision$Id: CParameter.h,v 60.6 2006/05/16 13:52:26 jtm Exp $ $
// $Date$
// $Author$
//
// Decription: CParameter
//
////////////////////////////////////////////////////////////////////////////
#ifndef __CParameter_h__ 
#define __CParameter_h__ 1 

#include "cadoe_map.h"
#include "cadoe_string.h"
#include "C_Parameter.h"
#include "CParamRange.h"
#include "CParameterHelper.h"

#ifndef NO_CADOE_NAMESPACE 
namespace Cadoe { 
#endif 

  /*! \class CParameter CParameter.h
    \brief The CParameter class is the public parameter object shared by the different CADOE API.
  */
  class CParameter : public C_Parameter
    {
    public:
      CParameter();
      ~CParameter() {};
      CParameter( const CParameter &param ) { *this = param; }
      CParameter& operator =( const CParameter &param );


	  // Id is the unique parameter identifier. String.
	  string getId( void ) const { return GetId(); }
      const char * getIdCstr( void ) const { return GetIdCstr(); }
      void setId( const string &id ) { SetId(id); }

	  // Name=Id. Name is kept only for code compatibility. Use Caption for friendly name.
      string getName( void ) const { return GetId(); }
      const char * getNameCstr( void ) const { return GetIdCstr(); }
      void setName( const string &name ) { SetId(name); }

	  // Caption is the user friendly name
	  string getCaption( void ) const { return GetCaption(); }
	  void setCaption( const string &caption ) { SetCaption(caption); }

      void setType( Type type );
      Type getType( void ) const { return C_Parameter::GetType(); }
  

      //
      // Properties
      //

      void setActive( bool bState=true ) { SetProperty("Active",bState==true?1:0); }
      void setInactive(void) { SetProperty("Active",0); }
      bool isActive( void ) const { int active=0; GetProperty("Active",active); return active==0?false:true; }
      bool isInactive( void ) const { int active=0; GetProperty("Active",active); return active==0?true:false; }

      void setDimName( const string &name ) { SetProperty("DimName",name); }
      string getDimName( void ) const { string name(""); GetProperty("DimName",name); return name; }

      void setPartName( const string &name ) { SetProperty("PartName",name); }
      string getPartName( void ) const { string name(""); GetProperty("PartName",name); return name; }

      void setGroupName( const string &name ) { SetProperty("GroupName",name); }
      string getGroupName( void ) const { string name(""); GetProperty("GroupName",name); return name; }

      void setNumGroup( int numGroup ) { SetProperty("GroupNum",numGroup); }
      int getNumGroup( void ) const { int num=0; GetProperty("GroupNum",num); return num; }

      void setNature( Nature nat ) { SetProperty("Nature",nat); }
      Nature getNature( void ) const 
	{ 
	  int nat=(int)CPN_INPUT; 
	  GetProperty("Nature",nat); 
	  return (Nature)nat; 
	}

      // CONTINUOUS, BOOL, DISCRETE
      void setVariationType( VariationType type ) { SetProperty("VariationType",type); }
      VariationType getVariationType( void ) const 
	{ 
	  int vtype=(int)CPV_CONTINUOUS; 
	  GetProperty("VariationType",vtype); 
	  return (VariationType)vtype; 
	}

      // FACT, ADD, VAL
      void setModifType( ParamModifType type ) { SetProperty("ModifType",type); }
      ParamModifType getModifType( void ) const 
	{ 
	  int type=(int)CPM_VAL; 
	  GetProperty("ModifType",type); 
	  return (ParamModifType)type; 
	}

      void setPhysicalType( PhysicalType type ) { SetProperty("PhysicalType",type); }
      PhysicalType getPhysicalType( void ) const 
	{ 
	  int type=(int)CPP_DEFAULT; 
	  GetProperty("PhysicalType",type); 
	  return (PhysicalType)type; 
	}

      void setNumProp(  int numProp ) { SetProperty("PropertyNum",numProp); }
      int getNumProp( void ) const { int num=0; GetProperty("PropertyNum",num); return num; }

      void setPropElemType( int propElemType ) { SetProperty("PropElemType",propElemType); }
      int getPropElemType( void ) const { int type=0; GetProperty("PropElemType",type); return type; }

      void setAllowReduction( bool allow ) { SetProperty("AllowReduction",allow==true?1:0); }
      bool allowReduction( void ) const { int allow=0; GetProperty("AllowReduction",allow); return allow==0?false:true; }

      bool isBooleanVariable( void ) const 
	{ 
	  int vtype=(int)CPV_CONTINUOUS; 
	  GetProperty("VariationType",vtype); 
	  return vtype==(int)CPV_BOOLEAN; 
	}
      bool isGeometryVariable( void ) const 
	{ 
	  int vtype=(int)CPP_DEFAULT; 
	  GetProperty("PhysicalType",vtype); 
	  return vtype==(int)CPP_SHAPE; 
	}


      //
      // Data attached to the parameter history: values and ranges, state, derivation order
      //

      void setInitial(  double ini, int rangename=RANGE_INPUT ) {_ph.setInitial(ini,rangename);}
      double getInitial( int rangename=RANGE_OUTPUT ) const {return _ph[rangename].getInitial();}

      void setMinimum(  double min, int rangename=RANGE_INPUT ) {_ph.setMinimum(min,rangename);}
      double getMinimum( int rangename=RANGE_OUTPUT ) const {return _ph[rangename].getMinimum();}

      void setMaximum( double max, int rangename=RANGE_INPUT ) {_ph.setMaximum(max,rangename);}
      double getMaximum( int rangename=RANGE_OUTPUT ) const { return _ph[rangename].getMaximum(); }

      void setStatus( CParamRange::ParStatus sta, int rangename ) { _ph.setStatus(sta,rangename);}
      CParamRange::ParStatus getStatus( int rangename=RANGE_OUTPUT ) const { return _ph[rangename].getStatus(); }

      void setDerivationOrder( int order, int rangename=RANGE_INPUT ) {_ph.setDerivationOrder(order,rangename);}
      int getDerivationOrder( int rangename=RANGE_OUTPUT ) const {return _ph[rangename].getDerivationOrder();}

      bool rangeExists( int rangename=RANGE_OUTPUT ) const;
      double getRangeLength( int rangename=RANGE_OUTPUT ) const;

      bool isEmpty( int rangename ) const { return _ph[rangename].isEmpty(); }
      bool isToProcess( int rangename ) const {return _ph[rangename].isToProcess(); }
      bool isValidated( int rangename ) const {return _ph[rangename].isValidated(); }
      bool isDeleted( int rangename ) const { return _ph[rangename].isDeleted(); }

      // implementation of the C_CbfObject interface
      virtual const char * Version() const { return (const char *)"1"; }
      virtual int VersionInt() const { return 1; }
      virtual int Write( FILE *f );
      virtual int Read( FILE *f );

    private:
      CParamHistory _ph;
    };

#ifndef NO_CADOE_NAMESPACE 
} //namespace Cadoe 
using namespace Cadoe; 
#endif 

#endif
