/* sid 60.1 copy of mem.h last changed by jtm on 2006/05/15 19:44:30 */
/* 
 * *** copyright(c) 2006 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */
#define MEM_


#ifdef SPARC
#define mem_Zero(Dest, Length) bzero(Dest, Length)
#define mem_Copy(Src, Dest, Length) bcopy(Src, Dest, Length)
#define mem_Compare(Src, Dest, Length) memcmp(Src, Dest, Length)
#else
#define mem_Zero(Dest, Length) memset(Dest, 0, (INT32) Length)
#define mem_Copy(Src, Dest, Length) memcpy(Dest, Src, Length)
#define mem_Compare(Src, Dest, Length) memcmp(Src, Dest, Length)
#endif

