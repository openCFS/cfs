/* sid 60.2 copy of FEM_kpMeshData.h last changed by jtm on 2005/08/23 13:33:30 */
#ifndef FEM_KPMESHDATA________________H
#define FEM_KPMESHDATA________________H
#include "FEM_MeshData.h"

class KPMSHDAT_TYP : public MSHDAT_TYP {

   private:
      NODE_OBJ m_obj_node;
      unsigned m_onsrc:1;
      unsigned m_ontrg:1;
      INT m_index;
      INT m_numareas;
      AREA_PTYP *m_aobj_areas;
      INT m_frozen;
      DOUBLE m_curv;
      DOUBLE m_esize;
      DOUBLE m_z;
      DOUBLE m_y;
      DOUBLE m_x;



   public:
      KPMSHDAT_TYP() { };
      ~KPMSHDAT_TYP() { Delete(); };

      void Init( ) { InitMSH_TYP(); m_obj_node = NULL; m_onsrc = 0; m_ontrg = 0;
                     m_index = 0; m_numareas = 0; m_aobj_areas = NULL; };
      void Delete( ) { m_obj_node = NULL; m_onsrc = 0; m_ontrg = 0;
                       m_numareas = 0; FEM_Free_C( m_aobj_areas ); };

      inline DOUBLE GetX() const { return m_x; };
      inline DOUBLE GetY() const { return m_y; };
      inline DOUBLE GetZ() const { return m_z; };
      inline void SetX( const DOUBLE x ) { m_x = x; };
      inline void SetY( const DOUBLE y ) { m_y = y; };
      inline void SetZ( const DOUBLE z ) { m_z = z; };

      inline INT Frozen() const { return m_frozen; };
      inline void SetFrozen( const INT frozen ) { m_frozen = frozen; };

      inline DOUBLE Curv() const { return m_curv; };
      inline void SetCurv( const DOUBLE curv ) { m_curv = curv; };

      inline void SetIndex( const INT index = 0 ) { m_index = index; };
      inline INT Index( ) const { return m_index; };

      inline FEM_BOOLEAN IsMeshed( ) const
      {
         if ( m_obj_node == NULL ) return FALSE;
         else return TRUE;
      };
      inline void SetNode( const NODE_OBJ obj_node ) { m_obj_node = obj_node; }; 
      inline NODE_OBJ Node( ) { return m_obj_node; }; 
      inline void SetOnSrc( const FEM_BOOLEAN onsrc = TRUE )
      {
         if ( onsrc ) m_onsrc = 1;
         else m_onsrc = 0;
      }
      inline void SetOnTrg( const FEM_BOOLEAN ontrg = TRUE )
      {
         if ( ontrg ) m_ontrg = 1;
         else m_ontrg = 0;
      }

                       /* =================================================== */
                       /* === IsOnSrcOrTrg: Return TRUE if this kp is on      */
                       /* === OR the src and the trg area. (see IsOnSrcAndTrg */
                       /* === also).                                          */
                       /* =================================================== */
      inline FEM_BOOLEAN IsOnSrcOrTrg() const
      {
         if ( m_onsrc == 1 || m_ontrg ) return TRUE;
         return FALSE;
      }

                       /* =================================================== */
                       /* === IsOnSrcAndTrg: Return TRUE if this kp is on     */
                       /* === BOTH the src and the trg area. (see IsOnSrcOrTrg*/
                       /* === also).                                          */
                       /* =================================================== */
      inline FEM_BOOLEAN IsOnSrcAndTrg() const
      {
         if ( m_onsrc == 1 && m_ontrg ) return TRUE;
         return FALSE;
      }

      inline FEM_BOOLEAN IsOnSrc() const
      {
         if ( m_onsrc == 1 ) return TRUE;
         return FALSE;
      }

      inline FEM_BOOLEAN IsOnTrg() const
      {
         if ( m_ontrg == 1 ) return TRUE;
         return FALSE;
      }

      inline void SetKp( const KP_PTYP obj_kp ) { SetCell( obj_kp ); };
      inline KP_PTYP GetKp( ) const { return (KP_PTYP)GetCell(); };

      INT NumAdjSrcTrgLines( ) const;
      AREA_PTYP const *AreaList( INT &num_areas );
      INT CountSweepCorners( VOL_PTYP obj_vol, INT &num_corners );
};
typedef class KPMSHDAT_TYP   *KPMSHDAT_PTYP;
void FEM_kpMd( KPMSHDAT_PTYP obj_kpdata );
#endif

