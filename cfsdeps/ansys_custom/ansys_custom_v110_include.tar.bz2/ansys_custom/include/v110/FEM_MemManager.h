/* sid 60.1 copy of FEM_MemManager.h last changed by upd111 on 2005/07/21 19:38:51 */
#ifndef FEM_MEMMANAGER
#define FEM_MEMMANAGER

#include "FEM_Public.h"

template <class MemType> class MemManager {

   private:
      INT m_spstack;
      INT m_spblocks;
      INT m_spblocksize;
      INT m_spstacksize;
      INT M_BLOCK_GROUP_SIZE;
      INT M_BLOCK_SIZE;
      INT M_STACK_GROUP_SIZE;
      MemType **mpa_blocks;
      MemType **mpa_stack;

      MemType *AllocateLink( );

   public:
      MemManager( ) { Init(); };
      ~MemManager( ) { FreeAll(); };
      void Init( ) { m_spstack = -1;
                     m_spblocks = -1;
                     m_spblocksize = 0;
                     m_spstacksize = 0;
                     M_BLOCK_GROUP_SIZE = 500;
                     M_STACK_GROUP_SIZE = 500;
                     M_BLOCK_SIZE = 500;
                     mpa_blocks = NULL;
                     mpa_stack = NULL; };
      MemType *Allocate()
      {
         INT size,i;
         MemType *result;
         MemType **temp;

         /* === We need to malloc another block */

         if (m_spstack < 0) {
            m_spblocks++;
            m_spstack = 0;

            /* === If the block pointer array needs to be extended */
            /* === (or initially set up) */

            if (m_spblocks >= m_spblocksize) {

               /* === realloc the block pointer array by mallocing, */
               /* === copying then freeing */

               size = m_spblocksize + M_BLOCK_GROUP_SIZE;
               temp = (MemType**)
                      FEM_Malloc_MAC( size * sizeof(MemType*) );
               if (!temp) {
                  FEM_Error_C( GENERIC, GEN_OUT_OF_MEMORY, FEM_ERROR, NULL );
                  m_spblocks--;
                  return NULL;
               }
               for ( i = 0; i<m_spblocksize; i++ ){
                  temp[i] = mpa_blocks[i];
               }
               for ( i = m_spblocksize; i<size; i++){
                  temp[i] = NULL;
               }
               if (mpa_blocks) {
                  FEM_Free_C( mpa_blocks );
               }
               mpa_blocks = temp;
               temp = NULL;
               m_spblocksize = size;
            }

            /* === allocate the new block */

            size = sizeof(MemType) * M_BLOCK_SIZE;
            mpa_blocks[m_spblocks] =
                  (MemType*)FEM_Malloc_MAC( size );

            /* === if our malloc failed */

            if (!mpa_blocks[m_spblocks]) {
               FEM_Error_C( GENERIC, GEN_OUT_OF_MEMORY, FEM_ERROR, NULL );
               m_spblocks--;
               return((MemType*)NULL);
            }

            /* === If the stack hasn't been allocated yet */

            if (!m_spstacksize) {
               size = M_STACK_GROUP_SIZE * sizeof(MemType*);
               mpa_stack = (MemType**)FEM_Malloc_MAC( size );

               /* === if our malloc failed */

               if (!mpa_stack) {
                  FEM_Error_C( GENERIC, GEN_OUT_OF_MEMORY, FEM_ERROR, NULL );
                  FEM_Free_C( mpa_blocks[m_spblocks] );
                  mpa_blocks[m_spblocks] = NULL;
                  m_spblocks--;
                  return( (MemType *) NULL );
               }
               m_spstacksize = M_STACK_GROUP_SIZE;
            }

            /* === Load the newly available items into the stack */

            mpa_stack[m_spstack] =
                     (MemType*)mpa_blocks[m_spblocks];
            for ( i = 1; i < M_BLOCK_SIZE; i++ ) {
               mpa_stack[i] = mpa_stack[i - 1] + 1;
            }
            m_spstack = M_BLOCK_SIZE - 1;
         }

         /* === pop the next one off the stack */

         result = mpa_stack[m_spstack];
         m_spstack--;

         return result;
      };

      void Free( MemType *ptr )
      {
         MemType **temp;
         INT size, i;

         /* === place the entity back on the stack */
         /* === if we've exceeded the size of the stack then realloc to */
         /* === add some more space to it */

         if (m_spstack == m_spstacksize - 1) {

            /* --- since there is currently no FEM_Realloc_MAC, first */
            /* --- malloc the required memory, copy the old into the new, then */
            /* --- free the old memory */

            size = m_spstacksize + M_STACK_GROUP_SIZE;
            temp = (MemType**)FEM_Malloc_MAC( size  * sizeof(MemType*) );

            if (temp) {
               for ( i=0; i<m_spstacksize; i++ ) {
                  temp[i] = mpa_stack[i];
               }
               for ( i=m_spstacksize; i<size; i++) {
                  temp[i] = NULL;
               }
               FEM_Free_C( mpa_stack );
               mpa_stack = temp;
               m_spstacksize = size;
            }

            /* --- if we couldn't realloc, then just put it back onto the */
            /* --- last slot of the stack.  (Other faces previously placed */
            /* --- on the last position of the stack will be unretreivable, */
            /* --- but they will be freed when fem_freeall is called) */

            else  {
               m_spstack--;
            }
         }

         /* === push the entity onto the stack */

         m_spstack++;
         mpa_stack[m_spstack] = ptr;
      };

      void FreeAll( )
      {
         INT i;

         /* === free the arrays */

         for(i = 0; i <= m_spblocks; i++) {
            FEM_Free_C( mpa_blocks[i] );
            mpa_blocks[i] = NULL;
         }

         if (mpa_blocks != NULL) {
            FEM_Free_C( mpa_blocks );
            mpa_blocks = NULL;
         }

         if (mpa_stack != NULL) {
            FEM_Free_C( mpa_stack );
            mpa_stack = NULL;
         }

         /* === reset the stack pointers and sizes */

         m_spblocks = -1;
         m_spblocksize = 0;
         m_spstack = -1;
         m_spstacksize = 0;

      };

};

#endif

