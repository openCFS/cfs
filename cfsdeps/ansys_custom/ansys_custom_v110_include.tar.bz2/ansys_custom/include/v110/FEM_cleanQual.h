/* sid 60.1 copy of FEM_cleanQual.h last changed by upd111 on 2005/07/21 19:39:21 */
/*  FEM_cleanqual.h */
/*
 * *** ansys(r) copyright(c) 1999
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_cleanqual.h
 *  header file for FEM_cleanqual.c
 *
 */
#ifndef FEM_CLEANQUAL_INCLUDE
#define FEM_CLEANQUAL_INCLUDE

/*----------------- Globally accessible function prototypes -----------------*/

                          /* === FEM_clQuadQualityClean: Tests to see if any */
                          /* === quality-based diagonal swaps should be done.*/
INT FEM_clQuadQualityClean ( 
   INT area,         /* the area to clean up                                 */
   FEM_BOOLEAN midnodes, /* TRUE if midnodes exist                           */
   INT *change  );   /* returned as TRUE if something changed                */

#endif

