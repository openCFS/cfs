/* sid 60.1 copy of FEM_CheckTopology.h last changed by upd111 on 2005/07/21 19:38:38 */

/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 1999 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_CheckTopology.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_CheckTopology.h
 *  header file for FEM_CheckTopology.c
 *
 */
#ifndef FEM_CHECK_TOPO_INCLUDE
#define FEM_CHECK_TOPO_INCLUDE

#define PRE_CHECK                    0
#define POST_CHECK                   1

/*----------------- Globally accessible function prototypes -----------------*/

                             /* ============================================ */
                             /* === FEM_ctCountEdge: if there are gaps in    */
                             /* === the facet model or there is a non        */
                             /* === manifold situation give error & return 3 */
                             /* ============================================ */
INT FEM_ctCountEdge ( void );

                             /* ============================================ */
                             /* === FEM_ctMultiVol: if there are mulitple    */
                             /* === shells give warning & return kerr of 2   */
                             /* ============================================ */
INT FEM_ctMultiVol ( void );

                             /* ============================================ */
                             /* === FEM_ctFaceWoutTet: Check if there are    */
                             /* === any faces without tets.  If there are    */
                             /* === give a warning and return 2.             */
                             /* ============================================ */
INT FEM_ctFaceWoutTet ( void );

#endif
