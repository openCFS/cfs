/* sid 60.1 copy of FEM_coGet.h last changed by upd111 on 2005/07/21 19:39:32 */
/*  FEM_coGet.h */
/*
 * *** ansys(r) copyright(c) 1999
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_coGet.h
 *  header file for FEM_coGet.c
 *
 */
#ifndef FEM_COGET_INCLUDE
#define FEM_COGET_INCLUDE

/*----------------- Globally accessible function prototypes -----------------*/

#ifdef __cplusplus
extern "C" {
#endif

                       /*=================================================== */
                       /* === FEM_coInitCMeshDataBase: Initialize the C mesh */
                       /* === data base and the node hash table in           */
                       /* === preparation to calling FEM_coGetAreaElements   */
                       /* === or FEM_coGetVolumeElements.                    */
                       /* === Return: INT  EXIT_SUCCESS or EXIT_FAILURE      */
                       /*=================================================== */
INT FEM_coInitCMeshDataBase (
   INT num_vols,       /* (IN) number of volumes that will be stored         */
   INT *a_vols,        /* (IN) list of volumes that will be stored           */
   INT num_areas,      /* (IN) number of volumes that will be stored         */
   INT *a_areas,       /* (IN) list of volumes that will be stored           */
   INT num_lines,      /* (IN)  number of lines that will be stored.         */
   INT *a_lines,       /* (IN)  list of lines that will be stored.           */
   INT num_kps,        /* (IN)  number of kps that will be stored.           */
   INT *a_kps,         /* (IN)  list of kps that will be stored.             */
   INT *maxvolelems,   /* (OUT) returned as the maximum number of elements   */
                       /*       on any one volume                            */
   INT *maxareaelems );/* (OUT) returned as the maximum number of elements   */
                       /*       on any one area                              */
                       /*=================================================== */

                       /*=================================================== */
                       /* === FEM_coGetAreaElements: get the elements on an  */
                       /* === area and store them in the C  meshing data base*/
                       /* === FEM_coInitCMeshDataBase must be called before  */
                       /* === calling this function.                         */
                       /* === Return: INT  EXIT_SUCCESS or EXIT_FAILURE      */
                       /*=================================================== */
INT FEM_coGetAreaElements (
   INT num_areas,      /* (IN)  number of areas in list                      */
   INT *a_areas,       /* (IN)  array of area numbers                        */
   INT maxelems,       /* (IN)  maximum number of elements in one area       */
   INT stat_process,   /* (IN)  process to be sent to status window routines */
   FEM_BOOLEAN *midnodes );/* (OUT) return whether midnodes exist on elements */
                       /*=================================================== */

                       /*=================================================== */
                       /* === FEM_coGetAreaFacets: get the facets on a list  */
                       /* === of area and store them in the C meshing data   */
                       /* === base.                                          */
                       /* === The facets are either area elements or the     */
                       /* === facets recovered off of volume elements.       */
                       /* === FEM_coInitCMeshDataBase must be called before  */
                       /* === calling this function.                         */
                       /* === Return: INT  EXIT_SUCCESS or EXIT_FAILURE      */
                       /*=================================================== */
INT FEM_coGetAreaFacets (
   INT num_areas,      /* (IN)  number of areas in list                      */
   INT *a_areas,       /* (IN)  array of area numbers                        */
   INT maxelems,       /* (IN)  maximum number of elements on one area.      */
                       /*       this value is returned from                  */
                       /*       FEM_coInitCMeshDataBase                      */
   INT stat_process,   /* (IN)  process to send to status window routines    */
   FEM_BOOLEAN *midnodes  );/* (OUT) return whether midnodes exist on elements*/
                       /*=================================================== */

                       /*=================================================== */
                       /* === FEM_coGetFacetsOnArea:  Recover facets off of  */
                       /* === the volume elements adjacent to an area and    */
                       /* === store them in the C meshing database.          */
                       /* === Return: INT  EXIT_SUCCESS or EXIT_FAILURE      */
                       /*=================================================== */
INT FEM_coGetFacetsOnArea(
   INT area,           /* (IN)  The area to get elements off of              */
   INT stat_process,   /* (IN)  process to send to status window routines.   */
   INT start_percent,  /* (IN)  starting point for progress bar.             */
   INT end_percent,    /* (IN)  ending point for progress bar.               */
   INT ivalue[3],      /* (IN)  for progress bar.                            */
   INT *midnodes,      /* (OUT) TRUE if midnodes exist.                      */
   INT *num_area_elems);/* (OUT) number of elements on this area             */
                       /*=================================================== */


                       /*=================================================== */
                       /* === FEM_coGetVolumeElements: get the elements in a */
                       /* === volume and store them in the C meshing data    */
                       /* === base FEM_coInitCMeshDataBase must be called    */
                       /* === before calling this function.                  */
                       /* === Return: INT  EXIT_SUCCESS or EXIT_FAILURE      */
                       /*=================================================== */
INT FEM_coGetVolumeElements (
   INT num_vols,       /* number of volumes in list                          */
   INT *a_vols,        /* array of volume numbers                            */
   INT maxelems,       /* maximum number of elements in one volume           */
   INT stat_process,   /* process to be sent to status window routines       */
   FEM_BOOLEAN *midnodes );/* return if midnodes exist on elems              */
                       /*=================================================== */


                       /*=================================================== */
                       /* === FEM_coSetEdgeMidProjProp: set EDGE_MID_PROJECT */
                       /* === property for edges of volume mesh; if an edge  */
                       /* === of area or line has midnode projected, then    */
                       /* === all edges of this area or line have            */
                       /* === EDGE_MID_PROJECT property set                  */
INT FEM_coSetEdgeMidProjProp ( void  );

#ifdef __cplusplus
}
#endif

#endif

