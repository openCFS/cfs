/* sid 60.3 copy of CPrivSolutionXplorer.h last changed by smarguer on 2006/07/20 08:12:28 */
/*******************************************************************************
 *
 *   CPrivSolutionXplorer.h -- SolutionXplorer Private Class (CSX)
 *              
 * |Module: SolutionXplorer
 *
 * |Description: this class defines the private class of SolutionXplorer. 
 *  Do not include it if you do not want to depend on all the internal CADOE 
 *  headers; use CSolutionXplorer instead.
 *        
 * |Auteur: Stephane MARGUERIN
 *
 * |Creation: mars 2002
 *
 * |Version: $Id$
 *
 * |Copyright:	copyright(c) 2006 SAS IP, Inc.  All rights reserved.
 *
 *   
 ******************************************************************************/
#ifndef __CPrivSolutionXplorer_h__ 
#define __CPrivSolutionXplorer_h__ 1 

#include "cadoe.h"
#include "cadoe_version.h"
#include "cadoe_string.h"
#include "cadoe_list.h"
#include "cadoe_vector.h"
#include "cadoe_map.h"

#include "liste_chainee.h"
#include "sx_version.h"
#include "sx_cons_solver.h"
#include "sx_CADOE_solver.h"
#include "sx_postTraitement.h"

#include "adoc.h"
#include "ADOC_Session.h"
#include "C_ParamFast.h"

#include "C_MessageTool.h"
#include "CParameterMgr.h"
#include "CSolutionXplorer.h"
#include "C_ItfPostFastPost.h"

#include "vstruct.h"
#include "lmb.h"
#include "sx_bases.h"

class CC_Ansys;
class CC_SocketDriver;


class CPrivSolutionXplorer : public CSolutionXplorer 
{
public:

  CPrivSolutionXplorer(const int iNumPort = -1);
  CPrivSolutionXplorer(C_AdocSession *session, const int iNumPort = -1);
  
  virtual ~CPrivSolutionXplorer(); 

  string getVersion(void) const { return string(CADOE_VERSION_PRODUCT); }

  void setNodalAveragingAcrossBodies( bool averaging ) { _nodalAveragingAcrossBodies = averaging; }
  bool getNodalAveragingAcrossBodies(void) const { return _nodalAveragingAcrossBodies ; }

  //////////////////////////////////////////////////////////////////////
  // MODEL
  //////////////////////////////////////////////////////////////////////

  int loadModel( const string &filename );

  void setModel( void *model );


  CSolutionXplorer::ContextType getContextType(void) const ;
  CSolutionXplorer::AnalysisType getAnalysisType(void) const ;
  CSolutionXplorer::StudyType getStudyType(void) const ;
	
  void getIDEASSetNumbers( int &solset, int &boset) const ;

  bool isModelAxisymmetric(void) const ;

  int getNumberOfLoadCases( void ) const;
  int getLoadCases( vector<string> &loadCasesName );
  int getLoadCases( map<string,int> &loadCasesMap );
	
  //////////////////////////////////////////////////////////////////////
  // MESH - CSXMODEL
  //////////////////////////////////////////////////////////////////////

  // full initial mesh description
  CSXModel & getCSXModel( bool postmodel = false );
  long getNumberOfNodes( bool postmodel = false ) ;
  long getNumberOfElements( bool postmodel = false );

  bool isFast() const { return (_modele->solveur == ANSYS_FAST ? true : false); }

  bool isNode(int label);
  bool isElement(int label);
  int getMinNodeLabel(void) const { return _minNodeLabel; }
  int getMaxNodeLabel(void) const { return _maxNodeLabel; }
  int getMinElementLabel(void) const { return _minElementLabel; }
  int getMaxElementLabel(void) const { return _maxElementLabel; }
  bool isWithShell(void) const { return _withShell; }

  //////////////////////////////////////////////////////////////////////
  // FE GROUPS
  //////////////////////////////////////////////////////////////////////
	
  long getNumberOfFEGroups( void );
  int createFEGroups( int numGroups, const CSXGroup *groups, bool indice = true );
  const CSXGroup * getFEGroup( const string &name );
  const CSXGroup * getParameterSupport( const string &paramName );


  //////////////////////////////////////////////////////////////////////
  // PARAMETERS
  //////////////////////////////////////////////////////////////////////

  // returns the number of parameters that are available for post-processing
  int getNumberOfParameters( void ) const 
  { return _pmgr->getNumberOfParameters(); }

  int getParameterVector( CParameterMgr::ParamVector &pvec )	const 
  {	return _pmgr->getParameterVector(pvec); 	}
  int getParameterList( CParameterMgr::ParamList &plist ) const 
  { return _pmgr->getParameterList(plist);	}
  int getParameterMap( CParameterMgr::ParamMap &pmap ) const 
  {	return _pmgr->getParameterMap(pmap);	}

  void setParameterManager( CParameterMgr* pmgr );
  CParameterMgr *getParameterManager( void ) const { return _pmgr; }

  void		SetAdocSession( C_AdocSession *Session) { _Session = Session;}
  C_AdocSession	*GetAdocSession( void) { return _Session;}
  
  
  //////////////////////////////////////////////////////////////////////
  // EVALUATION PROCESS CONTROL
  //////////////////////////////////////////////////////////////////////
  
  CEvalProcess* new_EvalProcess( CEvalProcess::PostType postType );
  void delete_EvalProcess( CEvalProcess* evalProcess );
  
  T_modele *getModele(void) const { return _modele; }
  int getPhysics(void) {return (_modele?(_modele->mod_phys?_modele->mod_phys->formulation:0):0);}
  PAR *getPar(void) const { return _par; }
  PAR *getParUser(void) const { return _parUser; }
  
  double userVal2Del( int indice, double userVal ) const ;
  double del2UserVal( int indice, double delta ) const ;
  double del2Val( int ip, double delta ) const;
  
  int configureMsgTool( void ) const;

  CEvalProcess* retrieveEvalProcess( int id );

  CDesignSetsCache * getCacheObject() { return _cache; }
  void resetCacheObject();
  bool getCachedCriterion( const CCriterion &crit, CCriterion &cachedCrit );
  void addCachedCriterion( CCriterion &crit );
  
  //////////////////////////////////////////////////////////////////////
  // Interface with solver
  //////////////////////////////////////////////////////////////////////

  int getNumPort()		{return _numPort;};
  void setNumPort(int port) 	{_numPort = port;}
  
  C_ItfPostFastPost* getItfPostFast() {return _itfPostFast;}
  void setItfPostFast(C_ItfPostFastPost*itf) {_itfPostFast = itf;};

  CC_AnsysClient *getAnsysDriver(void) { return _ansysDriver; }
  void setAnsysDriver(CC_AnsysClient *driver) { _ansysDriver = driver; }

  CC_AnsysClient *getCadoeDriver(void) { return _cadoeDriver; }
  void setCadoeDriver(CC_AnsysClient *driver) { _cadoeDriver = driver; }

private:
  void release(void);

  bool paramIsInverse( int indice ) const ;
  void buidCSXModel( bool postmodel = false );

  string			_filename;	// filename of the current database
  T_modele*		_modele;	// modele 
  C_AdocSession		*_Session;
  bool 			_SessionToDelete;
  PAR*			_par;		// objet par adoc en representation interne
  PAR*			_parUser;	// objet par adoc en representation interne

  CParameterMgr*		_pmgr;
  bool			_pmgrIsMine;	// pmgr has been created by me, so I must delete it.
  list<CEvalProcess*>	*_processList; // liste des eval process
  bool			_verbose;

  int			_minNodeLabel;
  int			_maxNodeLabel;
  int			_minElementLabel;
  int			_maxElementLabel;
  bool			_withShell;
  bool			_adomeshOnly;
  E_solveur		_appliContext;
  bool			_modelLoaded;
  bool			_modelIsMine;
  bool			_polymLoaded;
  bool			_nodalAveragingAcrossBodies;
  int 			_numPort;
  C_ItfPostFastPost	*_itfPostFast;
  CC_AnsysClient *_ansysDriver;
  CC_AnsysClient *_cadoeDriver;

  CSXModel		  _csxmodel;

  CDesignSetsCache		*_cache;
  vector<CCriterion>	_cachedCriteria;
};




#endif
