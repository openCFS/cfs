/* sid 60.1 copy of CEvalResultsField.h last changed by upd111 on 2006/10/09 19:57:48 */
/*! \file CEvalResultsField.h

  \brief This header file defines the CEvalResultsField class.

  \author Stephane MARGUERIN &copy; CADOE

  \date 23 Mai 2002

  \version $Id$

*/

#ifndef __CEvalResultsField_h__ 
#define __CEvalResultsField_h__ 1 

#include "cadoe_map.h"
#include "CDesignSet.h"

/*! \class CEvalResultsField CEvalResultsField.h
  \brief The CEvalResultsField class is a container for the field results
  returned by the contour evaluation process. 

  It is organized in a number of results, each results corresponding to a DesignSet
  and holding all the selected criteria for this DesignSet.
  Call getNumberOfResults() to retrieve the number of results.
  
  Each results field is made of getNumberOfData() data accessible with getResults(). 
  The array returned contains results for each support (node, element or nodes at elements) 
  depending of the criterion definition. getNumberOfValues() returns an array that gives 
  the number of values for each individual support (node or element). This number may be different 
  from one support to	another, depending on the element type. With shells, this number must 
  be divided by the number of layers.
  
  The CEvalResults is memory independent: the deletion of its parent
  CEvalProcess has no effect on it, so you can keep it on your side as
  long as you need it. 
			
  
	\todo Add getResultLegend()

*/
class CEvalResultsField
{
public:

  //! Support type
  typedef enum {
    SPT_INDEX=0,
    SPT_NUMBER
  } SupportType;

  //! default constructor
  CEvalResultsField(bool providesupport=false, SupportType supporttype=SPT_NUMBER);
  //! destructor
  ~CEvalResultsField();

  /*! 
    \ brief return true if Support of criterion si provided
  */
  bool getProvideSupport() {return _provideSupport;}
  
  /*! 
    \ brief return true if the provided Support type is by number, false if it's by index
  */
  CEvalResultsField::SupportType getSupportType() {return _supportType;}
  
  /*! \brief retrieve the number of results
    \return number of results
  */
  int getNumberOfResults(void) { return _numRes; }
  
  /*! \brief retrieve the number of data for one given criterion of one result
    \return number of data
  */
  int getNumberOfData( int iRes, int criterionId );

  
  /*! \brief retrieve the number of support (nodes or elements) for one given criterion of one result
    \return number of data
  */
  int getNumberOfSupport( int iRes, int criterionId );

  
  /*! \brief returns the size of a designSet description array, which is the same
    as the total number of parameters.
    \return DesignSet size
  */
  int getDesignSetSize(void) { return _designSetSize; }

  /*! \brief returns the values for each parameters of a designSet
    \param iRes results number
    \return pointer to the designSet description
  */
  CDesignSet & getDesignSet( int iRes );

  /*! \brief returns a pointer to the array that gives the number of values for each support (node/element) in the field
    \param iRes results number
    \param criterionId criterion code
    \return pointer to the numberOfVal array
  */
  int * getNumValuesArray( int iRes, int criterionId );
  /*! \brief returns a pointer to the array of results for one given block
    \param iRes results number
    \param criterionId criterion code
    \return pointer to the array of results
  */
  double * getResults( int iRes, int criterionId );

  bool getFrequency( int iRes, int criterionId, double *frequency );
  bool getModalMass( int iRes, int criterionId, double *modalMass );

  int * getSupportArray( int iRes, int criterionId);
  int getSupportLabel( int iRes, int criterionId, int iSupport );
  

  // internal usage only

  int initialize( int nbXDir, int nbXStep, int numberOfParameters=0 );
  int initializeBlock( int iRes, int criterionId, int nbSupport, int blockSize );
  void release(void);

  void setCritId( int pos, int criterionId ) { _critPos[criterionId] = pos; _numCrit+=1; }
  int setDesignSet( int iRes, CDesignSet &set );
  int setResult( int iRes, int critCode, int iVal, double *val, int numVal );
  int setFrequency( int iRes, int critCode, double frequency ); 
  int setModalMass( int iRes, int critCode, double modalMass );
  void setProvideSupport(bool provideSupport) {_provideSupport = provideSupport;}
  void setSupportType( CEvalResultsField::SupportType supporttype) {_supportType = supporttype;}

  int setSupport( int iRes, int critCode, int iSupport, int numVal, int label );
  double * getSupportResult( int iRes, int criterionId, int supportLabel, int *numValues );

  void print(void);

private:
  int critPos( int critId )
  {
    map<int,int>::iterator itm = _critPos.find(critId);
    if ( itm==_critPos.end() ) return -1;
    else return (*itm).second;
  }
  CEvalResultsField( const CEvalResultsField &res );
  CEvalResultsField& operator =( const CEvalResultsField &res);

  int	_numRes; // number of result blocks (block= 1 contour result field )
  int   _numBlocks;
  int	_numCrit; 
  int	_numXDir; 
  int	_numXStep;
  bool  _provideSupport;
  CEvalResultsField::SupportType _supportType;

  int	*_blockSize;	// number of data for each block
  int	*_nbSupport;	// number of support for each block
  int	_designSetSize; // design set size = number of parameters/values for each design set in _designSets.
  map<int,CDesignSet> _designSets; // one designSet for each iRes
  int	**_nbSupVal; // number of values for each support of the result field
  int   **_support;  // label of entities for each support of the result field
  double	**_results;	// results values
  map<int,int> _critPos; // position order of the criteria selected
  map<int,double> _frequency;
  map<int,double> _modalMass;

  map<int,int>	*_supportMap; // map[support label] = support index in _support and _nbSupVal
  map<int,double*> *_resultsMap; // map[support label] = results pointer in _results
  bool	*_resultsMapDirty;
};

#endif
