/* sid 60.1 copy of resultat.h last changed by smarguer on 2006/02/09 09:13:01 */
/* resultat.h CADOE  */
/*
 * resultat.h
 *
 * $Id$
 *   
 * HISTORY
 *   
 *   09/25/00 11:19 <       Brian Jantzen> Rel:ms8m1    SCCA:79107  Delta:81.4
 *   
 *   06/28/00 10:47 <       Brian Jantzen> Rel:ms8m1    SCCA:74542  Delta:81.3
 *   
 *   06/21/00 16:30 <       Brian Jantzen> Rel:ms8m1    SCCA:74307  Delta:81.2
 *   
 *   01/13/00 11:20 <        Marc Gadbois> Rel:ms8      SCCA:65669  Delta:8.3
 *   
 *   09/30/99 17:38 <         James Silva> Rel:ms8      SCCA:56512  Delta:8.2
 */

#ifndef __resultath__
#define __resultath__ 1

#ifndef __expmdbstructh__
#include "expmdb_struct.h"
#endif

/*#ifdef __cplusplus
extern "C" {
#endif*/

extern T_Resultat *RES_creer_resultat( int configId, T_statut* );
extern T_Resultat *RES_binput( FILE*,T_Modele *, T_statut* );
extern VEC *RES_etendre_pert( T_Resultat *,T_Modele *, IVEC *, T_statut * );

/*#ifdef __cplusplus
}
#endif*/

#endif
