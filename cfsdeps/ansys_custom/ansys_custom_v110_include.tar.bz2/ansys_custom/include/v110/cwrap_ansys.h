/* sid 60.16 copy of cwrap_ansys.h last changed by jrb on 2006/12/07 16:03:14 */

/*****************************************************************************
   This include file is used for the ANSYS cwrap_ansys.c routines and
   cwrap_amg.c routines.
   *** mpg cwrap_ansys.h < LMatrix,msgdfc: C<->Fortran

*****************************************************************************/

#ifdef __cplusplus
extern "C" {
#endif

typedef void (*T_fct_1)(void*);
typedef void (*T_fct_2)(void*,void*);
typedef void (*T_fct_3)(void*,void*,void*);
typedef void (*T_fct_4)(void*,void*,void*,void*);
typedef void (*T_fct_5)(void*,void*,void*,void*,void*);
typedef void (*T_fct_6)(void*,void*,void*,void*,void*,void*);
typedef void (*T_fct_7)(void*,void*,void*,void*,void*,void*,void*);

extern void      cwPpfrk1( T_fct_1, void* );
extern void      cwPpfrk2( T_fct_2, void*, void* );
extern void      cwPpfrk3( T_fct_3, void*, void*, void* );
extern void      cwPpfrk4( T_fct_4, void*, void*, void*, void* );
extern void      cwPpfrk5( T_fct_5, void*, void*, void*, void*, void* );
extern void      cwPpfrk6( T_fct_6, void*, void*, void*, void*, void*, void* );
extern void      cwPpfrk7( T_fct_7, void*, void*, void*, void*, void*, void*, void* );
extern void      cwPpsync(void);
extern void      cwPpsynci(void);
extern void      cwPpresu(void);
extern void      cwPpinfo(INT*,INT*);
extern void      cwPppark(void);
extern INT       cwPpinqr(INT*);
extern INT       cwPpproc(void);
extern void      cwPprange(INT*, INT*, INT*);
extern void      cwPprangeL(LONGINTC*, LONGINTC*, LONGINTC*);
extern INT       cwPpnext(void);
extern void      cwPpgroup(INT*, INT*, INT*, INT*);
extern void      cwPplock(INT*);
extern void      cwPpunlock(INT*);

extern INT       cPcgSlvRun(INT*,INT*,INT*,DOUBLE*,INT*,DOUBLE*);

extern void      cwnonzrodispchk(INT*, INT*, INT*, INT*, INT*);
extern INT       cput_amgmem2pcg(DOUBLE*,DOUBLE*,INT*,INT*,INT*,INT*);
extern INT       crecoverx1aftercecp(INT*,INT*,INT*,DOUBLE*,DOUBLE*);
extern INT       crecoverf2aftercecp(INT*,INT*,INT*,DOUBLE*);
extern INT       cwupdatefullheader(INT*,INT*,INT*);
extern INT       cwupdatemodeheader(INT*,INT*,INT*);
extern void      cwbiowrt_int(INT*,INT*,INT*,INT*);
extern void      cwbiowrt_dp(INT*,INT*,DOUBLE*,INT*);
extern void      cwbiord_int(INT*,INT*,INT*,INT*);
extern void      cwbiord_dp(INT*,INT*,DOUBLE*,INT*);
extern INT       cPcgKtimesU(INT*,INT*,DOUBLE*,DOUBLE*);
extern INT       cPcggetCurrVarnock(INT,INT);
extern void      cwGet_Times(DOUBLE*,DOUBLE*);
extern void      cwAxElemMult(INT*,INT*,INT*,INT*,INT*,DOUBLE*,DOUBLE*,DOUBLE*);
extern void      cwAxElemMassMult(INT*,INT*,INT*,INT*,DOUBLE*,DOUBLE*);
extern void      cwSolabt(INT,INT);
extern INT       cwSysexe(char*);
extern void      cwPcgstat(INT,DOUBLE,DOUBLE,INT*);
extern void      cwPcglanstat(INT,INT,INT,INT,INT*);
extern INT       cwGetOutOfCore(void);
extern INT       cwGetSingle(void);
extern INT       cwGetStep(void);
extern INT       cwGetStop(void);
extern void      cwsubpfq(INT*,DOUBLE*,DOUBLE*);
extern void      cwressav_fromPCG(INT*,INT*,DOUBLE*,DOUBLE*,DOUBLE*);
extern void      cwFastBlockLanczos(INT,INT*,INT*,DOUBLE*,INT,INT*,INT*,DOUBLE*,
                                    INT,DOUBLE,DOUBLE,INT*,DOUBLE*,DOUBLE*,INT*);
extern INT       cwBcsStat(INT*,INT*,DOUBLE*,DOUBLE*);

extern void      cwPutAnsys_commond(INT*,DOUBLE*,INT*);
extern INT       cwansys_commond(INT*,DOUBLE*);
extern INT       cwintfromdp(DOUBLE*);
extern void      cwbiowrt_complex(INT*,INT*,DOUBLE*,DOUBLE*,DOUBLE*,INT*);
extern LONGINTC  cwLargeIntGet(INT*,INT*);
extern void      cwLargeIntPut(LONGINTC*,INT*,INT*);
extern INT       cwamg_alloc(INT*,LONGINTC*,INT*);
extern void      cwcalrigidb(INT*);
extern INT       cwamgsolver(INT*,INT*,LONGINTC*,INT*,INT*,INT*,
                             DOUBLE*,DOUBLE*);
extern void      cwamg_deallo_pcg(void);
extern void      cwamg_coord_pcg(INT*,INT*);

#if !defined (PTR64)
extern void      cDSPmainPCG(INT*,DOUBLE*,INT*,LONGINTC*,LONGINTC*,INT*,INT*,DOUBLE*,DOUBLE*,INT*,INT*,INT*,INT*,INT*);
#else
extern void      cDSPmainPCG(INT*,DOUBLE*,INT*,LONGINTC*,LONGINTC*,LONGINTC*,LONGINTC*,DOUBLE*,DOUBLE*,INT*,INT*,INT*,INT*,INT*);
#endif

extern INT       cwIopiqr(INT*);

#ifdef __cplusplus
}
#endif
