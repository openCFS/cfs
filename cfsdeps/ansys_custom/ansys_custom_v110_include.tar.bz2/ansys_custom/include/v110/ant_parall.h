/* sid 60.1 copy of ant_parall.h last changed by jtm on 2006/05/15 19:43:40 */
/*HFILE parallel.h                                      fjb,system
------------------------------------------------------------------------
------- Notice - This file contains ANSYS Confidential information --------
------------------------------------------------------------------------
*/
/*
 * *** copyright(c) 2006 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */


/*------------------------------ Description ---------------------------
\Author:        F. Bogden
\Title:         Parallel Primitives Library header
\Desc:          This file is the header file for all of the cc interface
		routines to create and manage threads.
\History:       94/11/30 - fjb: Initial creation

\Function(s)
 -Primary:      parallel primitives header
 -Secondary:    none
 -External:     none
 -Internal:     none
 -Static:       none
----------------------------------------------------------------------*/


#ifndef PARALLEL_H
#define PARALLEL_H

/*------------------ Header files and declarations -------------------*/
#include "computer.h"
#include "globals.h"
#include "syssys.h"

/*------------------------------ Dependencies ------------------------*/

/*----------------------- Static Macro Definitions -------------------*/

/*
   ppDebug = 0, no debug, create threads.
   ppDebug = 1, yes debug, create threads.
   ppDebug = 2, yes debug, direct calls -no- threads.

   OPTION : compile with -DDEBUG to get debugging messages -or-
            compile with -DNO_DEBUG to get -no- debugging messages ever.
*/
# define debug 0
#ifdef DEBUG
# define debug 1
#endif
#ifdef NO_DEBUG
# define debug 0
#endif

/***********************************************************************
                  * * *  N O T I C E  * * *
The definition of MAX_LOCKS MUST be the same size as the PPNUMLOCK
parameter statement in FORTRAN common PPCOM.  Also, the definition of
MAXARGS is the maximum number of FORTRAN arguments permitted by this
version.  This MUST be consistent with the FORTRAN ppfrkx calls.
                  * * *  N O T I C E  * * *
***********************************************************************/
#define MAX_LOCKS 128
#define MAXARGS 15
#define MAXARGS1 (MAXARGS + 1)

/* define the MAX_CPUS permitted for this version */
#define MAX_CPUS 32

/*--------------------- Static TypeDefs/Structures -------------------*/

/*
 *	 Barrier data type
 */

typedef struct {
 HANDLE					hTerminalEvent[MAX_CPUS];
 HANDLE					hLeaderSignal;
 HANDLE					hLeaderLock;
 CRITICAL_SECTION		csInternalLock;
 INT					iNumThreads;
} barrier_t;


/* App may want to dynamically allocate as many of these as it needs, for
   now we just have one the app.
   These barriers once initialized are labeled, e.g., cannot be  reinitialized.
   If more than one is needed, need to allocate more.
*/

/*----------------------- Variable Definitions -----------------------*/
/* global variables */
INT ppDebug;

/*------------------------- Internal Functions -----------------------*/

VOID (*subr1) ();
VOID (*subr2) (VOID *);
VOID (*subr3) (VOID *,VOID *);
VOID (*subr4) (VOID *,VOID *,VOID *);
VOID (*subr5) (VOID *,VOID *,VOID *,VOID *);
VOID (*subr6) (VOID *,VOID *,VOID *,VOID *,VOID *);
VOID (*subr7) (VOID *,VOID *,VOID *,VOID *,VOID *,VOID *);
VOID (*subr8) (VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *);
VOID (*subr9) (VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *);
VOID (*subr10) (VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,
                VOID *);
VOID (*subr11) (VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,
		VOID *,VOID *);
VOID (*subr12) (VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,
		VOID *,VOID *,VOID *);
VOID (*subr13) (VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,
		VOID *,VOID *,VOID *,VOID *);
VOID (*subr14) (VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,
		VOID *,VOID *,VOID *,VOID *,VOID *);
VOID (*subr15) (VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,
		VOID *,VOID *,VOID *,VOID *,VOID *,VOID *);
VOID (*subr16) (VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,
		VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *);


/*------------------------- Exported Functions -----------------------*/
/* used either from fortran and/or C */
 VOID ppbarrier (barrier_t *);
 VOID ppfrk0_ ( VOID *(*)() );
 VOID ppfrk1_( VOID *(*)(VOID *), VOID *[] );
 VOID ppfrk2_( VOID *(*)(VOID *,VOID *), VOID *[], VOID *[] );
 VOID ppfrk3_( VOID *(*)(VOID *,VOID *,VOID *), VOID *[], VOID *[],
		     VOID *[] );
 VOID ppfrk4_( VOID *(*)(VOID *,VOID *,VOID *,VOID *), VOID *[],
                     VOID *[], VOID *[], VOID *[] );
 VOID ppfrk5_( VOID *(*)(VOID *,VOID *,VOID *,VOID *,VOID *), VOID *[],
		     VOID *[], VOID *[], VOID *[], VOID *[] );
 VOID ppfrk6_( VOID *(*)(VOID *,VOID *,VOID *,VOID *,VOID *,VOID *),
		     VOID *[], VOID *[], VOID *[], VOID *[], VOID *[],
                     VOID *[] );
 VOID ppfrk7_( VOID *(*)(VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,
                     VOID *), VOID *[], VOID *[], VOID *[], VOID *[], VOID *[],
                     VOID *[], VOID *[] );
 VOID ppfrk8_( VOID *(*)(VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,
		     VOID *), VOID *[], VOID *[], VOID *[], VOID *[], VOID *[],
                     VOID *[], VOID *[], VOID *[] );
 VOID ppfrk9_( VOID *(*)(VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,
                     VOID *,VOID *), VOID *[], VOID *[], VOID *[], VOID *[],
                     VOID *[], VOID *[], VOID *[], VOID *[], VOID *[] );
 VOID ppfrk10_( VOID *(*)(VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,
                      VOID *,VOID *, VOID *), VOID *[], VOID *[], VOID *[],
                      VOID *[], VOID *[], VOID *[], VOID *[], VOID *[], VOID *[],
                      VOID *[] );
 VOID ppfrk11_( VOID *(*)(VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,
                      VOID *,VOID *, VOID *, VOID *), VOID *[], VOID *[],
                      VOID *[], VOID *[], VOID *[], VOID *[], VOID *[], VOID *[],
                      VOID *[], VOID *[], VOID *[] );
 VOID ppfrk12_( VOID *(*)(VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,
                      VOID *,VOID *, VOID *, VOID *,VOID *), VOID *[], VOID *[],
                      VOID *[], VOID *[], VOID *[], VOID *[], VOID *[], VOID *[],
                      VOID *[], VOID *[], VOID *[], VOID *[] );
 VOID ppfrk13_( VOID *(*)(VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,
                      VOID *,VOID *, VOID *, VOID *,VOID *,VOID *), VOID *[],
                      VOID *[], VOID *[], VOID *[], VOID *[], VOID *[], VOID *[],
                      VOID *[], VOID *[], VOID *[], VOID *[], VOID *[], VOID *[] );
 VOID ppfrk14_( VOID *(*)(VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,
                      VOID *,VOID *, VOID *, VOID *,VOID *,VOID *,VOID *), VOID *[],
                      VOID *[], VOID *[], VOID *[], VOID *[], VOID *[], VOID *[],
                      VOID *[], VOID *[], VOID *[], VOID *[], VOID *[], VOID *[],
                      VOID *[] );
 VOID ppfrk15_( VOID *(*)(VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,
                      VOID *,VOID *, VOID *, VOID *,VOID *,VOID *,VOID *,VOID *),
                      VOID *[], VOID *[], VOID *[], VOID *[], VOID *[], VOID *[],
                      VOID *[], VOID *[], VOID *[], VOID *[], VOID *[], VOID *[],
                      VOID *[], VOID *[], VOID *[] );
/* do not modify source, make sure length for strings is
  after the string itelf*/
 VOID ppinit_( CHAR [], INT, INT *, INT *);
 VOID ppfini_( void );
 VOID ppresu_( void );
 VOID pppark_( void );
 VOID pprset_( void );
 VOID ppsynci_( void );
 VOID ppsync_( void );
 VOID pplock_( INT * );
 VOID lockst_( INT * );
 VOID ppunlock_( INT * );
 VOID lockcl_( INT * );
 VOID ppinfo_( INT*, INT * );
 INT ppinqr_( INT * );
 INT ppnext_( void );
 INT ppproc_( void );
 VOID pprange_(INT*,INT*,INT*);
 void ppsleep_();

 VOID pplockprt_( void );
 VOID ppunlockprt_( void );
 VOID printf_lck_(const char *format, ...);


#endif		/* PARALLEL_H */
/*---------------------------- End Of Module -------------------------*/

