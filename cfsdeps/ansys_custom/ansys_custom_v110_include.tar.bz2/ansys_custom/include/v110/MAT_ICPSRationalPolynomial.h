/* sid 60.1 copy of MAT_ICPSRationalPolynomial.h last changed by upd111 on 2006/10/09 19:57:59 */
////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         Copyright (C) 2001 ANSYS Inc.  All Rights Reserved             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MAT_ICPSRationalPolynomial.h $
// $Revision$ 7.0
// $Date$ March 28 2002
// $Author$ rjayasee
//
// Decription :
//              This class implement Strain Hardening Implicit Creep Model
//
////////////////////////////////////////////////////////////////////////////// 

#if !defined(MAT_ICPSRationalPolynomial_H)
#define MAT_ICPSRationalPolynomial_H

#include  "MAT_ConstitutiveFunction.h"
#include  "MAT_Creep.h"

class MAT_ICPSRationalPolynomial  : public MAT_Creep
{
public:

	MAT_ICPSRationalPolynomial();
    // Default Constructor.

    static MAT_Creep* Construct() ;

    virtual bool FunctionValue( double* pVariables, INT iNumVariables,
                                double* pInputVariables, INT iNumInputVariables,
                                double& dValue ) ;
    //I pVariable
    //I-Value of Coefficients
    //I iNumVariables
    //I- Number of variables
    //I dInputVariables
    //I-Input Variables
    //I iNumInputVariables
    //I-Num Input Variables
    //I dValue
    //I-Calculated Value of Creep Strain Rate
    //R- Calculates the value of the Creep Strain Rate using Strain Hardening 


    virtual bool FirstDerivativeOfUnsquaredError
             ( double* pVariables,INT iNumVariables,
               double* pInputVariables, INT iNumInputVariables,
               INT iVariableIndex, double& dResult ) ;
    //I pVariable
    //I-Value of Coefficients
    //I iNumVariables
    //I- Number of variables
    //I dInputVariables
    //I-Input Variables
    //I iNumInputVariables
    //I-Num Input Variables
    //I iVariableIndex
    //I-Variable w.r.t which the derivative is to be calculated
    //I dResult
    //I-Calculated value of derivative
    //R- Calculates the value of the Creep Strain using Strain Hardening        

    virtual void Print() ;
    // Prints the constitutive function

    virtual ~MAT_ICPSRationalPolynomial();
    //Destructor


protected:

    bool m_bUsingStrainRate ;


    bool TermCreepStrain( double* pVariables, INT iNumVariables,
                          double* pInputVariables, INT iNumInputVariables,
                          double& dValue ) ;
    //I pVariable
    //I-Value of Coefficients
    //I iNumVariables
    //I- Number of variables
    //I dInputVariables
    //I-Input Variables
    //I iNumInputVariables
    //I-Num Input Variables
    //I dValue
    //I-Calculated Value of Creep Strain 
    //R- Calculates the value of the Ecr 

    bool TermCreepStrainRate( double* pVariables, INT iNumVariables,
                              double* pInputVariables, INT iNumInputVariables,
                              double& dValue ) ;
    //I pVariable
    //I-Value of Coefficients
    //I iNumVariables
    //I- Number of variables
    //I dInputVariables
    //I-Input Variables
    //I iNumInputVariables
    //I-Num Input Variables
    //I dValue
    //I-Calculated Value of Ec 
    //R-Calculates the value of the Ec Dot 

    bool TermCreepStrainPrime( double* pVariables, INT iNumVariables,
                               double* pInputVariables, INT iNumInputVariables,
                               INT iVariableIndex, double& dValue ) ;
    //I pVariable
    //I-Value of Coefficients
    //I iNumVariables
    //I- Number of variables
    //I dInputVariables
    //I-Input Variables
    //I iNumInputVariables
    //I-Num Input Variables
    //I dValue
    //I-Calculated Value of Creep Strain  Derivative
    //R- Calculates the value of the Creep Strain Derivative 

    bool TermCreepStrainRatePrime( double* pVariables, INT iNumVariables,
                                   double* pInputVariables, INT iNumInputVariables,
                                   INT iVariableIndex, double& dValue ) ;
    //I pVariable
    //I-Value of Coefficients
    //I iNumVariables
    //I- Number of variables
    //I dInputVariables
    //I-Input Variables
    //I iNumInputVariables
    //I-Num Input Variables
    //I dValue
    //I-Calculated Value of Creep Strain Rate Derivative 
    //R-Calculates the value of the Creep Strain Rate Derivative

    bool TermECDot( double* pVariables, INT iNumVariables,
                    double* pInputVariables, INT iNumInputVariables,
                    double& dValue ) ;
    //I pVariable
    //I-Value of Coefficients
    //I iNumVariables
    //I- Number of variables
    //I dInputVariables
    //I-Input Variables
    //I iNumInputVariables
    //I-Num Input Variables
    //I dValue
    //I-Calculated Value of Ec Dot
    //R- Calculates the value of the Ec Dot 

    bool TermEC( double* pVariables, INT iNumVariables,
                 double* pInputVariables, INT iNumInputVariables,
                 double& dValue ) ;
    //I pVariable
    //I-Value of Coefficients
    //I iNumVariables
    //I- Number of variables
    //I dInputVariables
    //I-Input Variables
    //I iNumInputVariables
    //I-Num Input Variables
    //I dValue
    //I-Calculated Value of Ec 
    //R- Calculates the value of the Ec Dot 

    bool TermEMDot( double* pVariables, INT iNumVariables,
                    double* pInputVariables, INT iNumInputVariables,
                    double& dValue ) ;
    //I pVariable
    //I-Value of Coefficients
    //I iNumVariables
    //I- Number of variables
    //I dInputVariables
    //I-Input Variables
    //I iNumInputVariables
    //I-Num Input Variables
    //I dValue
    //I-Calculated Value of Em Dot
    //R- Calculates the value of the Em Dot 

    bool TermC( double* pVariables, INT iNumVariables,
                double* pInputVariables, INT iNumInputVariables,
                double& dValue ) ;
    //I pVariable
    //I-Value of Coefficients
    //I iNumVariables
    //I- Number of variables
    //I dInputVariables
    //I-Input Variables
    //I iNumInputVariables
    //I-Num Input Variables
    //I dValue
    //I-Calculated Value of Term C
    //R- Calculates the value of the Term C 

    bool TermP( double* pVariables, INT iNumVariables,
                double* pInputVariables, INT iNumInputVariables,
                double& dValue ) ;
    //I pVariable
    //I-Value of Coefficients
    //I iNumVariables
    //I- Number of variables
    //I dInputVariables
    //I-Input Variables
    //I iNumInputVariables
    //I-Num Input Variables
    //I dValue
    //I-Calculated Value of Term C
    //R- Calculates the value of the Term C 


    bool FirstDerivativeOfCreepStrain
             ( double* pVariables,INT iNumVariables,
               double* pInputVariables, INT iNumInputVariables,
               INT iVariableIndex, double& dResult ) ;
    //I pVariable
    //I-Value of Coefficients
    //I iNumVariables
    //I- Number of variables
    //I dInputVariables
    //I-Input Variables
    //I iNumInputVariables
    //I-Num Input Variables
    //I iVariableIndex
    //I-Variable w.r.t which the derivative is to be calculated
    //I dResult
    //I-Calculated value of derivative
    //R- Calculates the value of the Creep Strain        

    bool FirstDerivativeOfCreepStrainRate
             ( double* pVariables,INT iNumVariables,
               double* pInputVariables, INT iNumInputVariables,
               INT iVariableIndex, double& dResult ) ;
    //I pVariable
    //I-Value of Coefficients
    //I iNumVariables
    //I- Number of variables
    //I dInputVariables
    //I-Input Variables
    //I iNumInputVariables
    //I-Num Input Variables
    //I iVariableIndex
    //I-Variable w.r.t which the derivative is to be calculated
    //I dResult
    //I-Calculated value of derivative
    //R- Calculates the value of the Creep Strain Rate        

    bool TermCPrime( double* pVariables,INT iNumVariables,
                     double* pInputVariables, INT iNumInputVariables,
                     INT iVariableIndex, double& dResult ) ;
    //I pVariable
    //I-Value of Coefficients
    //I iNumVariables
    //I- Number of variables
    //I dInputVariables
    //I-Input Variables
    //I iNumInputVariables
    //I-Num Input Variables
    //I iVariableIndex
    //I-Variable w.r.t which the derivative is to be calculated
    //I dResult
    //I-Calculated value of derivative
    //R- Calculates the derivative of C

    bool TermPPrime( double* pVariables,INT iNumVariables,
                    double* pInputVariables, INT iNumInputVariables,
                    INT iVariableIndex, double& dResult ) ;
    //I pVariable
    //I-Value of Coefficients
    //I iNumVariables
    //I- Number of variables
    //I dInputVariables
    //I-Input Variables
    //I iNumInputVariables
    //I-Num Input Variables
    //I iVariableIndex
    //I-Variable w.r.t which the derivative is to be calculated
    //I dResult
    //I-Calculated value of derivative
    //R- Calculates the derivative of P        

    bool TermEMDotPrime( double* pVariables,INT iNumVariables,
                        double* pInputVariables, INT iNumInputVariables,
                        INT iVariableIndex, double& dResult ) ;
    //I pVariable
    //I-Value of Coefficients
    //I iNumVariables
    //I- Number of variables
    //I dInputVariables
    //I-Input Variables
    //I iNumInputVariables
    //I-Num Input Variables
    //I iVariableIndex
    //I-Variable w.r.t which the derivative is to be calculated
    //I dResult
    //I-Calculated value of derivative
    //R- Calculates the derivative of EMDot        

    bool TermECDotPrime( double* pVariables,INT iNumVariables,
                        double* pInputVariables, INT iNumInputVariables,
                        INT iVariableIndex, double& dResult ) ;
    //I pVariable
    //I-Value of Coefficients
    //I iNumVariables
    //I- Number of variables
    //I dInputVariables
    //I-Input Variables
    //I iNumInputVariables
    //I-Num Input Variables
    //I iVariableIndex
    //I-Variable w.r.t which the derivative is to be calculated
    //I dResult
    //I-Calculated value of derivative
    //R- Calculates the derivative of ECDot        

    bool TermECPrime( double* pVariables,INT iNumVariables,
                      double* pInputVariables, INT iNumInputVariables,
                      INT iVariableIndex, double& dResult ) ;
    //I pVariable
    //I-Value of Coefficients
    //I iNumVariables
    //I- Number of variables
    //I dInputVariables
    //I-Input Variables
    //I iNumInputVariables
    //I-Num Input Variables
    //I iVariableIndex
    //I-Variable w.r.t which the derivative is to be calculated
    //I dResult
    //I-Calculated value of derivative
    //R- Calculates the derivative of EC
} ;


class MAT_ICPSRationalPolynomialFactory
{
    public:

    static MAT_ICPSRationalPolynomialFactory* Instance() ;
    //I Pointer to Creep Factory
    //- Pointer to Singleton Instantiator

    static void Destroy() ;
    ~MAT_ICPSRationalPolynomialFactory() ;
    // Destructor

    private:

    MAT_ICPSRationalPolynomialFactory() ;
    // Constructor

    static MAT_ICPSRationalPolynomialFactory* m_pInstance ;
    //Pointer to only instance of this class
} ;

#endif // !defined(MAT_ICPSRationalPolynomial_H)
