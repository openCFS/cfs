/* sid 60.1 copy of CEvalTool.h last changed by upd111 on 2006/10/09 19:57:49 */
/*! \file CEvalTool.h

  \brief This header file defines the CEvalTool virtual class.

  \author Stephane MARGUERIN &copy; CADOE

  \date January 1st, 2002

  \version $Id$
 */

#ifndef __CEvalTool_h__ 
#define __CEvalTool_h__ 1 

#include "CDesignSet.h"

class CEvalTool
{
 public:
  CEvalTool(){};
  virtual ~CEvalTool(){};
  virtual int evalDesignSet( CDesignSet &set ) {return 0;}
  virtual int calculerDesignSet( CDesignSet &set ) {return 0;}
};


#endif
