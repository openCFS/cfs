/* sid 60.6 copy of nbbP.h last changed by eedelor on 2006/06/19 08:46:34 */
/*  
 *  nbbP.h 
 *  
 * |Description:  Includes partie parametrisation ( variables globales, fonctions communes  
 *   solveur et interface  ). 
 * 
 * |Version: $Id$ 
 *    
 */ 
#ifndef __NBBP_X_DEJA_INCLUS__ 
#define __NBBP_X_DEJA_INCLUS__ 1 
 
#ifdef CADOE_ANSYS 
#include "computer.h" 
#include "globals.h" 
#include "sysparh.h" 
#endif 
 
#include "sx_CADOE_solver.h" 
#include "cadoelic.h" 
#include "sx_exploit_param_fast.h" 
#include "sx_bases.h" 
 
#ifdef __cplusplus 
extern "C" { 
#endif	 
	 
extern int sx_ConnectServices( E_type_analyse AnalyseType, PAR *par);
   
extern void aff_ordres( int *, int *); 
 
extern T_der_modele* DEM_preparer_derivation( PAR *, T_modele*, void *, int, T_statut* ); 
extern T_der_modele *DEM_updater_derivation( T_der_modele *der_modele, T_modele *modele, PAR *par, 
					     void *param, T_statut *ier);

extern T_statut DEM_update_model( T_der_modele*, PAR *, void *, double); 
extern T_statut DEM_update_model_v2( T_der_modele*, PAR *, void *, double *dp);  
extern T_statut DEM_update_coord( T_modele*, VEC* dxyz );  
extern T_statut DEM_liberer_der_modele( T_modele *modele, T_der_modele **der_modele); 

extern void intadoc_end( PAR *par);
extern void current_step( T_but, int, int ); 
extern void aff_plage( PARAM *param, double *min_int, double *max_int); 
extern void aff_par(PAR* ); 
extern void nombre_directions( int, int ); 
 
  /* ===== Prototypes for FX static						*/ 
 
extern void FLS_InitSolveur( PAR *par, VEC **U0, VEC **F0, int *ier); 
extern void FLS_InitSensib( PAR *par, int num_param, double *vmin, double *vmax,  
			    double vparam, int *ordre_K, int *ordre_F, VSTRUCT *Fi, VSTRUCT *KiU0,  
			    int *ordreB, int *ier); 
 
extern void FLS_CompRhs( PAR *par, int ordre, VEC *Sn, int *ier); 
extern void FLS_Resol( VEC *B, VEC *X, int UseBcsDof, int *ier); 
extern void FNM_Resol( VEC *B, VEC *X, int nbrhs, int UseBcsDof, int *ier); 
extern void FLS_ProdKiU( PAR *par, int ordre, VEC *U, VSTRUCT *KiU, int *ier); 
extern void FLS_ProdKiQ( PAR *par, int num_param, double vparam, int ordre_K, 
			 VSTRUCT *Q, VSTRUCT *KiQ, int ordreB, VSTRUCT *BiQ, VSTRUCT *Thi, int *ier); 
extern void FLS_CompB0Q( PAR *par, VSTRUCT *Q, VSTRUCT *B0Q, VEC *VTherm, int *ier); 
 
extern void FLS_GetNumGrpMass( int *numgrp); 
extern void FLS_GetDerPrescribed( PAR *par, int num_param, double vparam, int ordre_K, 
				  int ordre_B, VSTRUCT *BiPresc, int *ier); 
extern void FLS_GetPrescribed(PAR *par, VEC **U_presc, VEC **prescribed, int *ier); 
 
 
  /* ===== Prototypes for sx_resol.c							*/ 
 
extern void SX_InitSxResolLs(int context); 
extern void SX_InitSxResolNm(int context);   
extern void SX_FreeSxResol(); 
extern void SX_update_derivee(VEC *, T_statut *); 

   /* ===== Prototypes for sx_reac.cpp							*/ 

extern VEC* SX_getReac();
extern IVEC *SX_getNam5();
extern IVEC *SX_getNam6();
extern void SX_setNam5(IVEC *nam5);
extern void SX_setNam6(IVEC *nam6);
extern void SX_FreeSxReac(); 

  /* ===== Prototypes for sx_list_elem.cpp						*/ 

extern IVEC *SX_GetElemPres(void); 
extern IVEC *SX_GetElemDerive(void); 
extern void SX_build_list_elem(T_modele*,int *ier); 
extern void SX_build_list_elem_pres(T_modele*,int *ier); 
extern void SX_build_list_elem_hice(T_modele*,int *ier);
extern void SX_list_elem_param_K(T_modele*,IVEC *list_elem_to_derive,  
				 int nb_elem_max_interp, int *ier); 
extern void SX_list_elem_param_B(T_modele*,IVEC *list_elem_to_derive,  
				 int *nb_elem_max_interp, int *ier); 
extern void SX_list_elem_res(T_modele*,int *nb_elem, int *ier); 
extern void SX_list_elem_res_mm(T_modele*, int *nb_elem, int *ier); 
extern void SX_list_elem_param(T_modele*,int *nb_elem, int *ier); 
extern void SX_list_elem_param_res(T_modele*,int *nb_elem, int *ier); 
extern void SX_list_elem_param_res_mm(T_modele*,int *nb_elem, int *ier); 
extern void SX_list_elem_pres_res(T_modele*,int *nb_elem, int *ier);   
extern void SX_list_elem_pres_param_res(T_modele*,int *nb_elem, int *ier);   
extern void SX_list_elem_pres_param(T_modele*,int *nb_elem, int *ier);   
extern void SX_FreeListElem(void); 
 
/* ===== Prototypes for sx_BcsToAns.c						*/ 
 
extern int SX_GetNbBcsDofs(void); 
extern int SX_GetNbCeFull(void); 
extern IVEC *SX_GetFULLtoBCSdof(void); 
extern IVEC *SX_GetBCStoANSdof(void); 
extern IVEC *SX_GetANStoBCSdof(void); 
extern VEC *SX_NodToInd( VEC *VecNod, VEC *VecInd, int *ier); 
extern VEC *SX_IndToNod( VEC *VecInd, VEC *VecNod, int *ier); 
extern ZVEC *SX_z_NodToInd( ZVEC *VecNod, ZVEC *VecInd, int *ier); 
extern ZVEC *SX_z_IndToNod( ZVEC *VecInd, ZVEC *VecNod, int *ier); 
extern ZVEC *SX_z_IndToNodExp( ZVEC *VecInd, ZVEC *VecNod, int *ier);
extern void SX_InitBcsToAns( int nb_ddl, int *ier); 
extern VEC *SX_IndToNodExp( VEC *VecInd, VEC *VecNod, int *ier); 
extern void SX_FreeBcsToAns(); 
 
/* ===== Prototypes for FAST method						*/ 
extern void initParamFAST_PCG(PAR* par,int* ier); 
extern void paramFAST_PCG(PAR *par, int *ier); 
extern VSTRUCT *VerifpFast( T_modele *modele, T_der_modele *der_modele, PAR *par, VEC *vparam, VSTRUCT *SolParKQfull, 
			    VSTRUCT **SolParKQpartiel, VSTRUCT *SigmaKQfull, VSTRUCT **SigmaParamKQpartiel, int NbListElem, VEC *epsi, 
			    int *ier); 
extern VSTRUCT *ExploitParamNewton(PAR *par, T_basis bases, T_ExploitParamFast *Config, VEC *epsi, IVEC **ListElem01, IVEC **ptrDdlToKeep, 
				   double *ResiduDdlComputed, VSTRUCT *KQUtilde, int *ier); 
 
/* ===== Prototypes for DX static						*/ 
 
extern void calcul_sol( PAR *par, ADOC_DRCT *RES, int *ier); 
extern void calcul_der_sol( PAR *par, ADOC_DRCT *RES, ADOC_DRCT *der_RES, int *ier); 
extern void SX_AllocateTabXyz( T_modele *modele, int *ier); 
 
  /* ===== Prototypes for FX Normal Modes					*/ 
 
extern void FNM_InitSolveur(PAR *par, VEC *lambda, VSTRUCT **Modes, double *seuil, int *ier); 
extern void FNM_MassInit(PAR *par, VEC *Mass, int *ier); 
 
extern void FNM_KinitV( int nbv, VEC *V, VEC *KV, int *ier); 
extern void FNM_MinitV( int nbv, VEC *V, VEC *MV, int *ier); 
extern void FNM_ProdVS( int nump, int IdMat, int Ordre, VSTRUCT *V, VSTRUCT *AV,  
			int *ier); 
 
extern void FNM_factor( double lambda0, int *ier); 
extern void FNM_Dep_0( VEC *Sn, int *ier); 
extern void FNM_KiV(int nump, int ordre, VEC *V, VEC *KiV, int *ier); 
extern void FNM_MiV(int nump, int ordre, VEC *V, VEC *MiV, int *ier); 
 
extern void FNM_VtAV( int IdMat, int OrderMat, int nbv, double *tabv, 
			double *vtav, int *ier); 
 
extern void FNM_InitSensib(PAR *par, int num_param, double *vmin,  
			   double *vmax, double vparam, VEC *Sn0, 
			   int *ordre_K, int *ordre_M, VSTRUCT *Mass,  
			   int *ier); 
extern void FNM_InitSensibTay(PAR *par, VEC *variation, int ordre_param,  
			      int *ordre_K, int *ordre_M, int *ier); 
extern void FNM_write_restart(int restrt_f, int where_f, int kdone_f); 
extern T_statut init_adoc( void ); 
 
extern void SX_FreeLsDxAdoc( PAR *par); 
extern void SX_FreeLsFxAdoc( PAR *par); 
extern void SX_FreeNmFxAdoc( PAR *par); 
 
  /* ===== Fonctions de sx_shape.c						*/ 
 
extern IVEC *elem_shape_active( int *ier); 
 
  /* ===== Fonctions de sx_boundcond.c						*/ 
 
extern void SX_InitBoundCond( VEC *U0, int *ier); 
extern void SX_ZeroVecSupp( VEC *vec, int *ier); 
extern void SX_ZeroVecPres( VEC *vec, int *ier); 
extern void SX_ZeroVecCpce( VEC *vec, int *ier); 
extern void SX_SetSupp(IVEC *); 
extern void SX_SetPres(IVEC *);
extern IVEC *SX_GetSupp(void); 
extern IVEC *SX_GetPres(void); 
extern IVEC *SX_GetCpce(void); 
extern IVEC *SX_GetHice(void);
extern VEC *SX_GetValPres(void); 
extern void SX_FreeBoundCond(void); 
extern T_statut SX_UpdateSupp(VEC * X); 
extern void SX_ApplyPres(VEC *vec, int *ier); 
 
  /* ===== Fonctions de sx_update.c						*/ 
 
extern void SX_SetNumElem( int num); 
extern void SX_SetNumSig( int num); 
extern void SX_SetNumMas( int num); 
 
extern void SX_SetEpsi( double val); 
extern double SX_GetEpsi(void); 
 
extern void SX_InitBefAssembly( double eps, IVEC *list_elem_to_derive,  
				int *ier); 
 
  extern VEC *SX_GetDxyz(void); 
extern void SX_PutDxyz(VEC *dxyz); 
 
extern void SX_FreeUpdate(void); 
 
/* ===== Fonctions de sx_order.c						*/ 
 
extern void SX_order_K_F_M_B(T_der_modele *der_modele, PAR *par, int num_param, double *vmin,  
			     double *vmax, double vparam,  
			     VEC *U0, IVEC *list_elem_to_derive, int *ordre_K,  
			     int *ordre_F, int *ordre_M, int *ordre_B,  
			     int *ier); 
extern void FLS_order_B(T_der_modele *der_modele, PAR *par, double valeur, double vmin, double vmax,  
			double vparam, VEC *variation,  
			VEC *U0, IVEC *list_elem_to_derive, int ordre_K,  
			int *ordre_B, int *ier); 
 
extern T_statut SX_AnalyticOrder( PAR *par, VEC *variation, int DerivationOrder, int *oK, int *oM, 
				  int *oF); 
 
/* ===== Fonctions de sx_check_coherence.c  					*/ 
 
extern T_statut sx_check_dynamique(PAR * par); 
extern T_statut sx_check_fx_ls_resid(PAR * par); 
extern T_statut sx_check_static(PAR *par); 
extern T_statut sx_check_residus(); 
extern T_statut sx_check_assemblees(); 
extern void sx_print_vec(VEC * v, char * nom_fich); 
 
/* ===== Fonctions de sx_kelreq.c						*/ 
 
extern T_statut sx_kelreq( int Want_K, int Want_M, int Want_C, int Want_KS,  
			   int Want_Fint, int Want_Fext, T_modele *modele,  
			   int Want_Res, int kelreq[10]); 
 
/* ==== Fonctions de SxReadAnsysResults.cpp 				*/ 
extern void SX_FreeReadAnsysResults(); 

/* ==== Fonctions de sx_connectivity.cpp					*/ 
extern BVEC* SX_DdlToNode(BVEC *DdlToKeep, int *ier); 
extern BVEC* SX_NodeToElem(BVEC *NodeToKeep, BVEC *ElemToKeep, int *ier); 
extern BVEC* SX_DdlToElem(BVEC *DdlToKeep, int *ier); 
 
extern int SX_ListTrace(char *rsxFileName, char *nameFileOut);

#ifdef __cplusplus 
} 
#endif 
 
#endif				/* __NBBP_X_DEJA_INCLUS__ */ 
