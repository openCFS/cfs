/* sid 60.2 copy of FEM_ansysmtk.h last changed by upd111 on 2006/05/11 18:00:52 */

/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 1999 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_ansysmtk.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_ansysmtk.h
 *  header file for the Ansys Meshing Toolkit
 *
 */

#ifndef __ANSYS_MESHING_DATABASE_H__
#define __ANSYS_MESHING_DATABASE_H__

#if defined(EXTERNAL_COMPILE) || defined(EXTERNAL_LINK)
# include "FEM_cdbtypes.h"
#endif

#if 0



GENERAL
-------

   This file contains the front end API for the Ansys Meshing Toolkit.  This
API contains prototypes for the functions that will need to be called in order
to mesh a volume or area.  The file FEM_external.h contains the back end API.
This back end API contains functions that the CAD database will need to
provide to the Ansys Meshing Tookkit to provide topological information,
memory management, error handling, geometric projections, etc.  





TERMINOLOGY
-----------

Keypoint:  A keypoint is a topological vertex or point defined by an xyz
           location.

Line:      A line is a topological edge.  A line is topologically delineated
           by two keypoints -- one at each end.  The direction of the line
           goes from the first keypoint towards the second keypoint.  These
           lines must be parameterized using arc length parameterization
           where t = 0.0 at the first keypoint and t = 1.0 at the second
           keypoint.  A line does not have to be straight.

Area:      An area is a topological face.  An area is bounded by a list of
           lines.  An area can have any number of line loops.  The first loop
           is always the outer most loop.  An area does not have to be flat.

Volume:    A volume is a topological part or body.  A volume is bounded by a
           list of areas.  A volume can have any number of area shells.  The
           first shell is always the outermost shell.

Hardpoint: A hardpoint is a special kind of keypoint.  It specifies a location
           on a line or area where a node must be placed by the mesher.  Since
           a hardpoint is just a special kind of keypoint, the number for
           hardpoints and keypoints is one in the same.  For example, It is
           not possible to have both a keypoint #14 and a hardpoint #14.
           Rather, when ever you refer to keypoint #14, you are also refering
           to hardpoint #14.

   Each keypoint, line, area, and volume is identified by a unique topological
id.  "Topo ids" are always positive integers.  Zero is not a valid
"topo id".  For example, a line may have the "topo id" of 14.
There can only be one line with the "topo id" of 14.  However, it is valid to
have both an area and a line each with the "topo id" of 14.  These "topo ids"
are used by the CAD database to specify which area or volume is to be meshed.
In addition, the "topo ids" are used by the Ansys Meshing Database to specify
which keypoint/line/area/volume a node is associated with, needs to be
projected to, etc.  "Topo ids" do not have to be incremental.  The lowest
"topo ids" in a model could be 10,000.  However, "topo ids" must be small
enough to fit into an integer variable on all platforms supported.





STEPS FOR USING ANSYS MESHING DATABASE
--------------------------------------

  To use the Ansys Meshing Toolkit, there are 4 basic steps that must be
followed:

  1.  Initialize the Ansys Meshing Database:  This is done by calling
      FEM_Init().  This initialization must be done before calls to
      any mesher can be made.

  2.  Call one or more of the meshers:  After the Ansys Meshing Database has
      been initialized, one or more of the meshers can be called.  For example,
      you could call FEM_MeshAreas to mesh an area with quads, followed by
      another call to FEM_MeshAreas to mesh an area with tris.  You could then
      make another call to FEM_TetMesh to mesh a volume with tets.  By making
      these three meshing calls, all the elements on all the areas and volume
      that were meshed by the meshing commands remain stored in the Ansys
      Meshing Database.

  3.  Retrieve the nodes and elements from the Ansys Meshing Database:  After
      an area and/or volume has been meshed in step 2, the nodes and elements
      in that mesh can be retrieved for storage in the native CAD database by
      using the functions:

              FEM_GetNode()
              FEM_GetAreaElem()
              FEM_GetTet()

      These functions return the locations of nodes as well as the connectivity
      of nodes to form the various element types.  Even after a node or element
      is retrieved by use of these functions, that node and/or element still
      resides in the Ansys Meshing Database.  Nodes and elements are not
      removed from the Ansys Meshing Database until a call to FEM_Kill is
      made (see step 4).

  4.  Kill the Ansys Meshing Database:  Free all memory used by the Ansys
      Meshing Database by calling FEM_Kill.  After killing the Ansys Meshing
      Database, no more calls to any of the meshers can be made until FEM_Init
      is called again.


  These 4 steps must be performed in the order that they are listed above.

  Step 2 allows any of the meshers to be called any number of times.  As
each mesher is called the resulting elements are stored in the Ansys Meshing
Database.  If several meshers are called without clearing (step 4) and
reinitializing (step1), the memory size of the Ansys Meshing Database can
become quite large.  It is suggested that unless you need more than one mesh
in the Ansys Meshing Database at the same time, to retrieve the nodes and
elements (step 3), clear (step 4) and reinitialize (step 1) before a
subsequent mesher is called.  Cases where you would not want to clear and
reinitialize would be if you are calling an area mesher to mesh the areas on
a volume in preparation to call the tet mesher.



USER ABORTS and PROCESS FAILURES
--------------------------------

   If a process is stopped because of a user abort or if a process returns
EXIT_FAILURE, the Ansys Meshing Database may be corrupt because the process
was stopped in the middle.  You may need to kill the Ansys Meshing Database
and remesh any other areas and/or volumes previously meshed.

#endif



/* ========================================================================= */
/* ========================================================================= */
/* ========================================================================= */
/* ========== Function Prototypes ========================================== */
/* ========================================================================= */
/* ========================================================================= */
/* ========================================================================= */

                          /* =============================================== */
                          /* === FEM_Init: Initialize the ANSYS Meshing      */
                          /* === Database.                                   */
                          /* === RETURN: FEM_INT ( EXIT_SUCCESS or           */
                          /* ===                   EXIT_FAILURE)             */
                          /* =============================================== */
FEM_CPP_EXTERN FEM_INT FEM_Init(
   FEM_INT start_node_id, /* (IN)  Id at which new nodes created by the      */
                          /*       Ansys Meshing Toolkit can begin.  All     */
                          /*       nodes created by the Ansys Meshing        */
                          /*       Toolkit will have ids greater than or     */
                          /*       equal to this id.  This value should be   */
                          /*       larger than any node id saved in the      */
                          /*       native CAD database to avoid multiple     */
                          /*       nodes with the same id.                   */
   FEM_INT start_elem_id );/*(IN)  Id at which new elements created by the   */
                          /*       Ansys Meshing Toolkit can begin.  All     */
                          /*       elements (both area elements and volume   */
                          /*       elements) created by the Ansys Meshing    */
                          /*       Toolkit will have ids greater than or     */
                          /*       equal to this id.  This value should be   */
                          /*       larger than any elem id saved in the      */
                          /*       native CAD database to avoid multiple     */
                          /*       nodes with the same id.                   */
                          /* =============================================== */



                          /* =============================================== */
                          /* === FEM_MeshAreas: Mesh a list of areas with    */
                          /* === either triangles or quadrilaterals.         */
                          /* === FEM_Init must have already been called.     */
                          /* ===                                             */
                          /* === Note:  All that is needed to start the      */
                          /* ===        meshing process is the topological   */
                          /* ===        ids of the areas to be meshed.       */
                          /* ===        With the areas ids, the mesher will  */
                          /* ===        call one of the FEMe routines in the */
                          /* ===        back end API to get the topo ids of  */
                          /* ===        all lines on each area.              */
                          /* ===                                             */
                          /* ===        Then the mesher will then look for   */
                          /* ===        nodes already in the Ansys Meshing   */
                          /* ===        Database on these lines.  If a line  */
                          /* ===        if not meshed in the Ansys Meshing   */
                          /* ===        Database, the mesher will call       */
                          /* ===        FEMe_LineMesh to see if it is already*/
                          /* ===        meshed in the native CAD database.   */
                          /* ===        If the line is already meshed in     */
                          /* ===        the native CAD database, the nodes   */
                          /* ===        on this line will be placed in the   */
                          /* ===        Ansys Meshing Database.              */
                          /* ===                                             */
                          /* ===        If a line is not already meshed, the */
                          /* ===        mesher will call FEMe_LineMeshII to  */
                          /* ===        determine the number of desired      */
                          /* ===        element divisions on each unmeshed   */
                          /* ===        line.  With this information, the    */
                          /* ===        mesher will mesh each unmeshed line. */
                          /* ===                                             */
                          /* ===        After all lines are meshed, the      */
                          /* ===        area mesher will mesh each area with */
                          /* ===        area elements.                       */
                          /* ===                                             */
                          /* ===        Upon completion the mesh will be     */
                          /* ===        stored in the ANSYS Meshing Database.*/
                          /* ===        The mesh can be retrieved with the   */
                          /* ===        FEM_GetX routines.                   */
                          /* ===                                             */
                          /* === RETURN: FEM_INT ( EXIT_SUCCESS or           */
                          /* ===                   EXIT_FAILURE)             */
                          /* ===         If EXIT_FAILURE is returned, the    */
                          /* ===         Ansys Meshing Database may be       */
                          /* ===         corrupt.  You may need to kill      */
                          /* ===         the Ansys Meshing Database and      */
                          /* ===         remesh any other areas and/or       */
                          /* ===         volumes previously meshed by the    */
                          /* ===         Ansys Meshing Toolkit.              */
                          /* =============================================== */
FEM_CPP_EXTERN FEM_INT FEM_MeshAreas(
   FEM_INT num_area,      /* (IN)  The number of areas to be meshed.         */
                          /*       (dimension of a_areas)                    */
   FEM_INT *a_areas,      /* (IN)  Array of ids of all areas to be meshed.   */
   AREAELEM_SHAPE shape,  /* (IN)  The desired element shape on these areas. */
   MESHTYPE mshtype,      /* (IN)  whether to use the free or map mesher.    */
   FEM_BOOLEAN midnodes,  /* (IN)  TRUE if midnodes are to be added to edges */
                          /*       on this area.  Midnodes will be added to  */
                          /*       all new edges created by this mesh        */
                          /*       operation.  Midnodes will not be added to */
                          /*       pre-existing  boundary edges created from */
                          /*       meshing an adjacent area with linears     */
                          /*       elements, or on line edges retrieved from */
                          /*       the native CAD database.                  */
   FEM_BOOLEAN proj_mids, /* (IN)  TRUE if midnodes should be projected to   */
                          /*       the geometry.  FALSE if midnodes should   */
                          /*       be linear interpolation of corner nodes.  */
                          /*       Ignored if midnodes == FALSE.             */
   FEM_INT smrt_size );   /* (IN)  NOT CURRENTLY SUPPORTED.                  */
                          /*       Smrt size level to use while meshing the  */
                          /*       areas in a_areas.  Possible values        */
                          /*       include:                                  */
                          /*           0:    do not do smart sizing.         */
                          /*           1:    create finest possible mesh.    */
                          /*           2:                                    */
                          /*           .                                     */
                          /*           .     varying degrees of coarseness.  */
                          /*           .                                     */
                          /*           9:                                    */
                          /*           10:   create coarsest possible mesh.  */
                          /* =============================================== */

                          /* =============================================== */
                          /* === FEM_ClearAreas:  Given a list of area ids,  */
                          /* === clear the nodes and elements on these areas */
                          /* === from the Ansys Mesh Database.               */
                          /* ===                                             */
                          /* === NOTE:  Any ndptr or elptr returned by one   */
                          /* ===        of the FEM_GetX routines before      */
                          /* ===        calling FEM_ClearAreas becomes       */
                          /* ===        unusable after calling               */
                          /* ===        FEM_ClearAreas.  After calling       */
                          /* ===        FEM_ClearAreas, the next call to any */
                          /* ===        of the FEM_GetX routines must have   */
                          /* ===        ndptr or elptr == NULL.              */
                          /* ===                                             */
                          /* === RETURN: FEM_INT ( EXIT_SUCCESS or           */
                          /* ===                   EXIT_FAILURE)             */
                          /* =============================================== */
FEM_CPP_EXTERN FEM_INT FEM_ClearAreas(
   FEM_INT num_area,      /* (IN)  The number of areas to be cleared.        */
                          /*       (dimension of a_areas)                    */
   FEM_INT *a_areas,      /* (IN)  Array of ids of all areas to be cleared.  */
   FEM_BOOLEAN adjgeo );  /* (IN)  FALSE if only elements and nodes on areas */
                          /*       are deleted.  Nodes on lines and          */
                          /*       keypoints adjacent to the areas are not   */
                          /*       deleted.                                  */
                          /*       TRUE if nodes on adjacent lines and       */
                          /*       keypoints not used by elements on non-    */
                          /*       cleared areas should also be deleted.     */
                          /* =============================================== */

                          /* =============================================== */
                          /* === FEM_TetMesh: Mesh a volume with tetrahedra. */
                          /* === FEM_Init must have already been called.     */
                          /* === Upon completion the mesh will reside in     */
                          /* === the ANSYS Meshing Database and can be       */
                          /* === retrieved with the FEM_GetX routines.       */
                          /* ===                                             */
                          /* === Note:  All that is needed to start the      */
                          /* ===        meshing process is the topological   */
                          /* ===        ids of the volumes to be meshed.     */
                          /* ===        With the volume ids, the mesher will */
                          /* ===        call one of the FEMe routines in the */
                          /* ===        back end API to get the topo ids of  */
                          /* ===        all lines and areas on each volume.  */
                          /* ===                                             */
                          /* ===        Then the mesher will then look for   */
                          /* ===        nodes already in the Ansys Meshing   */
                          /* ===        Database on these lines.  If a line  */
                          /* ===        if not meshed in the Ansys Meshing   */
                          /* ===        Database, the mesher will call       */
                          /* ===        FEMe_LineMesh to see if it is already*/
                          /* ===        meshed in the native CAD database.   */
                          /* ===        If the line is already meshed in     */
                          /* ===        the native CAD database, the nodes   */
                          /* ===        on this line will be placed in the   */
                          /* ===        Ansys Meshing Database.              */
                          /* ===                                             */
                          /* ===        If a line is not already meshed, the */
                          /* ===        mesher will call FEMe_LineMeshII to  */
                          /* ===        determine the number of desired      */
                          /* ===        element divisions on each unmeshed   */
                          /* ===        line.  With this information, the    */
                          /* ===        mesher will then mesh each unmeshed  */
                          /* ===        line.                                */
                          /* ===                                             */
                          /* ===        After all lines are meshed, the      */
                          /* ===        mesher will look in the Ansys        */
                          /* ===        Meshing Database to see which areas  */
                          /* ===        are already meshed.  If an area is   */
                          /* ===        not meshed in the Ansys Meshing      */
                          /* ===        Database, the mesher will call       */
                          /* ===        FEMe_GetElemsOnArea to see if the    */
                          /* ===        area is meshed in the native CAD     */
                          /* ===        database.  If the area is not meshed */
                          /* ===        in the native CAD database, the      */
                          /* ===        mesher will call FEMe_GetFacetsOnArea*/
                          /* ===        to recover facets of any adjacent    */
                          /* ===        meshed volumes.                      */
                          /* ===                                             */
                          /* ===        If the area is not meshed and no     */
                          /* ===        adjacent volumes are meshed, the     */
                          /* ===        tet mesher will automatically call   */
                          /* ===        the area mesher to mesh each         */
                          /* ===        unmeshed area with triangles.        */
                          /* ===        These automatically generated        */
                          /* ===        triangles are not stored as          */
                          /* ===        regular area elements and will not   */
                          /* ===        be returned from FEM_GetAreaElem.    */
                          /* ===                                             */
                          /* ===        After all lines and areas are        */
                          /* ===        meshed, the mesher will mesh each    */
                          /* ===        volume with tetrahedra.              */
                          /* ===                                             */
                          /* ===        Upon completion the mesh will be     */
                          /* ===        placed in the ANSYS Meshing Database.*/
                          /* ===        The mesh can then be retrieved with  */
                          /* ===        with the FEM_GetX routines.          */
                          /* ===                                             */
                          /* === RETURN: FEM_INT ( EXIT_SUCCESS or           */
                          /* ===                   EXIT_FAILURE)             */
                          /* ===         If EXIT_FAILURE is returned, the    */
                          /* ===         Ansys Meshing Database may be       */
                          /* ===         corrupt.  You may need to kill      */
                          /* ===         the Ansys Meshing Database and      */
                          /* ===         remesh all other areas and/or       */
                          /* ===         volumes previously meshed by the    */
                          /* ===         Ansys Meshing Toolkit.              */
                          /* =============================================== */
FEM_CPP_EXTERN FEM_INT FEM_TetMesh(
   FEM_INT num_vols,      /* (IN)  The number of volumes to be meshed.       */
                          /*       (dimension of a_vols)                     */
   FEM_INT *a_vols,       /* (IN)  Array of ids of all volumes to be meshed. */
   FEM_BOOLEAN midnodes,  /* (IN)  TRUE if midnodes are to be added to edges */
                          /*       on this volume. Midnodes will be added to */
                          /*       all new edges created by this mesh        */
                          /*       operation.  Midnodes will not be added to */
                          /*       pre-existing  boundary edges created from */
                          /*       meshing an adjacent area or volume with   */
                          /*       linears elements, or on line and/or area  */
                          /*       edges retrieved from the native CAD       */
                          /*       database.                                 */
   FEM_BOOLEAN proj_mids, /* (IN)  TRUE if midnodes should be projected to   */
                          /*       the geometry.  FALSE if midnodes should   */
                          /*       be linear interpolation of corner nodes.  */
                          /*       Ignored if midnodes == FALSE.             */
   FEM_INT smrt_size );   /* (IN)  NOT CURRENTLY SUPPORTED.                  */
                          /*       Smrt size level to use while meshing the  */
                          /*       volumes in a_vols.  Possible values       */
                          /*       include:                                  */
                          /*           0:    do not do smart sizing.         */
                          /*           1:    create finest possible mesh.    */
                          /*           2:                                    */
                          /*           .                                     */
                          /*           .     varying degrees of coarseness.  */
                          /*           .                                     */
                          /*           9:                                    */
                          /*           10:   create coarsest possible mesh.  */
                          /* =============================================== */

                          /* =============================================== */
                          /* === FEM_ClearVols:  Given a list of volume ids, */
                          /* === clear the nodes and elements on these       */
                          /* === volumes from the Ansys Mesh Database.       */
                          /* ===                                             */
                          /* === NOTE:  Any ndptr or elptr returned by one   */
                          /* ===        of the FEM_GetX routines before      */
                          /* ===        calling FEM_ClearVols becomes        */
                          /* ===        unusable after calling               */
                          /* ===        FEM_ClearVols.  After calling        */
                          /* ===        FEM_ClearVols, the next call to any  */
                          /* ===        of the FEM_GetX routines must have   */
                          /* ===        ndptr or elptr == NULL.              */
                          /* ===                                             */
                          /* === RETURN: FEM_INT ( EXIT_SUCCESS or           */
                          /* ===                   EXIT_FAILURE)             */
                          /* =============================================== */
FEM_CPP_EXTERN FEM_INT FEM_ClearVols(
   FEM_INT num_vols,      /* (IN)  The number of volumes to be cleared.      */
                          /*       (dimension of a_vols)                     */
   FEM_INT *a_vols,       /* (IN)  Array of ids of all volumes to be cleared.*/
   FEM_BOOLEAN adjgeo );  /* (IN)  FALSE if only elements and nodes in       */
                          /*       volumes are deleted.  Nodes on lines,     */
                          /*       areas, and keypoints adjacent to the      */
                          /*       volumes are not deleted.                  */
                          /*       TRUE if nodes on adjacent areas, lines &  */
                          /*       keypoints not used by elements on non-    */
                          /*       cleared volumes should also be deleted.   */
                          /* =============================================== */




                          /* =============================================== */
                          /* === FEM_GetNode: Get the next node stored in    */
                          /* === the ANSYS Meshing Database.                 */
                          /* === To get the first node send in               */
                          /* === *ndptr == NULL.  Continue calling until     */
                          /* === *ndptr is returned as NULL.                 */
                          /* === FEM_Init must have already been called.     */
                          /* === RETURN: FEM_INT ( EXIT_SUCCESS or           */
                          /* ===                   EXIT_FAILURE)             */
                          /* =============================================== */
FEM_CPP_EXTERN FEM_INT FEM_GetNode(
   void **ndptr,          /* (IN/OUT)                                        */
                          /*       (IN)  The void * returned the last time   */
                          /*             FEM_GetNode was called.  To get the */
                          /*             first node, send in *ndptr = NULL.  */
                          /*       (OUT) The void * to send to the next call */
                          /*             to FEM_GetNode.  If *ndptr is       */
                          /*             returned as NULL, the node returned */
                          /*             is the last node in the list.       */
   FEM_INT *node_id,      /* (OUT) The id of this node.  This id is later    */
                          /*       referenced by the a_iel arrays returned   */
                          /*       by FEM_GetAreaElem and FEM_GetTet.  If    */
                          /*       ndptr is sent in as NULL to request the   */
                          /*       first node, but there are no nodes in the */
                          /*       list, node_id is returned as 0.           */
   FEM_GEOTYPE *geo_type, /* (OUT) What type of geometric entity this node   */
                          /*       lies on.                                  */
   FEM_INT *geo_id,       /* (OUT) The id of the geometric entity this node  */
                          /*       lies on.                                  */
   FEM_DOUBLE xyz[3],     /* (OUT) The 3d location of this node.             */
   FEM_DOUBLE uv[2] );    /* (OUT) The parametric location of the node.      */
                          /*       If *geo_type == FEM_ON_AREA, both u and v */
                          /*          are returned.                          */
                          /*       If *geo_type == FEM_ON_LINE, t is returned*/
                          /*          in uv[0].                              */
                          /*       If *geo_type == FEM_AT_KEYPOINT or        */
                          /*          *geo_type == FEM_IN_VOLUME, nothing is */
                          /*          returned in uv[0] or uv[1].            */
                          /* =============================================== */


                          /* =============================================== */
                          /* === FEM_GetAreaElem: Get an area element stored */
                          /* === in the ANSYS Meshing Database.              */
                          /* === To get the first area element send in       */
                          /* === *elptr == NULL.  Continue calling until     */
                          /* === *elptr is returned as NULL.                 */
                          /* === FEM_Init must have already been called.     */
                          /* === RETURN: FEM_INT ( EXIT_SUCCESS or           */
                          /* ===                   EXIT_FAILURE)             */
                          /* =============================================== */
FEM_CPP_EXTERN FEM_INT FEM_GetAreaElem(
   void **elptr,          /* (IN/OUT)                                        */
                          /*       (IN)  The void * returned the last time   */
                          /*             FEM_GetAreaElem was called.  To get */
                          /*             the first area element, send in     */
                          /*             *elptr = NULL.                      */
                          /*       (OUT) The void * to send to the next call */
                          /*             to FEM_GetAreaElem.  If *elptr is   */
                          /*             returned as NULL, the area elem     */
                          /*             returned is the last elem stored.   */
   FEM_INT *elem_id,      /* (OUT) The id of this area element.  If elptr is */
                          /*       sent in as NULL to request the first area */
                          /*       elem, but there are no area elems in the  */
                          /*       list, elem_id is returned as 0.           */
   FEM_INT *geo_id,       /* (OUT) The id of the area that this area element */
                          /*       lies on                                   */
   AREAELEM_SHAPE *shape, /* (OUT) The shape of this element.                */
   FEM_INT a_iel[8] );    /* (OUT) Connectivity of nodes to form this        */
                          /*       element.  Values returned in a_iel        */
                          /*       coorespond with the node_ids returned     */
                          /*       from FEM_GetNode.  Nodes in a_iel are in  */
                          /*       a counterclockwise order.  i.e.:          */
                          /*                                                 */
                          /*                                corner nodes     */
                          /*              441                                */
                          /*        176*---*---*125         a_iel[0] = 176   */
                          /*           |       |            a_iel[1] = 200   */
                          /*        400*       *431         a_iel[2] = 132   */
                          /*           |       |            a_iel[3] = 125   */
                          /*        200*---*---*132                          */
                          /*              440               midnodes         */
                          /*                                a_iel[4] = 400   */
                          /*                                a_iel[5] = 440   */
                          /*                                a_iel[6] = 431   */
                          /*                                a_iel[7] = 441   */
                          /*                                                 */
                          /*                                                 */
                          /*                                corner nodes     */
                          /*                                                 */
                          /*        176*                    a_iel[0] = 176   */
                          /*           |\                   a_iel[1] = 200   */
                          /*        400* *431               a_iel[2] = 132   */
                          /*           |  \                                  */
                          /*        200*-*-*132             midnodes         */
                          /*            440                                  */
                          /*                                a_iel[3] = 440   */
                          /*                                a_iel[4] = 440   */
                          /*                                a_iel[5] = 431   */
                          /*                                                 */
                          /*    NOTE:  If a midnode does not exist on an     */
                          /*           edge, its location in a_iel will be   */
                          /*           filled with 0.                        */
                          /* =============================================== */


                          /* =============================================== */
                          /* === FEM_GetTet: Get the next tetrahedra         */
                          /* === element stored in the ANSYS Meshing         */
                          /* === Database.  To get the next tet send in      */
                          /* === *elptr == NULL.  Continue calling until     */
                          /* === *elptr is returned as NULL.                 */
                          /* === FEM_Init must have already been called.     */
                          /* === RETURN: FEM_INT ( EXIT_SUCCESS or           */
                          /* ===                   EXIT_FAILURE)             */
                          /* =============================================== */
FEM_CPP_EXTERN FEM_INT FEM_GetTet(
   void **elptr,          /* (IN/OUT)                                        */
                          /*       (IN)  The void * returned the last time   */
                          /*             FEM_GetTet was called.  To get the  */
                          /*             first tet element, send in          */
                          /*             *elptr = NULL.                      */
                          /*       (OUT) The void * to send to the next call */
                          /*             to FEM_GetTet.  If *elptr is        */
                          /*             returned as NULL, the tet elem      */
                          /*             returned is the last tet stored.    */
   FEM_INT *elem_id,      /* (OUT) The id of this tet element.  If elptr is  */
                          /*       sent in as NULL to request the first tet  */
                          /*       elem, but there are no tet elems in the   */
                          /*       list, elem_id is returned as 0.           */
   FEM_INT *geo_id,       /* (OUT) The id of the volume that this tet elem   */
                          /*       is in.                                    */
   FEM_INT a_iel[10],     /* (OUT) Connectivity of nodes to form this tet    */
                          /*       element.  Values returned in a_iel        */
                          /*       coorespond with the node_ids returned     */
                          /*       from FEM_GetNode and FEM_GetNextNode.     */
                          /*       Nodes in a_iel are ordered as shown below:*/
                          /*                                                 */
                          /*                               cornernodes       */
                          /*                                                 */
                          /*         145*___               a_iel[0] = 127    */
                          /*           / \  \___*333       a_iel[1] = 130    */
                          /*          /   \      \____*76  a_iel[2] = 76     */
                          /*         /     \455    ../     a_iel[3] = 145    */
                          /*     121*       *   ../ /                        */
                          /*       /   500*..\./   * 437   midnodes          */
                          /*      /   .../    \   /                          */
                          /*     /.../         \ /         a_iel[4] = 440    */
                          /* 127*-------*-------*130       a_iel[5] = 437    */
                          /*           440                 a_iel[6] = 500    */
                          /*                               a_iel[7] = 121    */
                          /*                               a_iel[8] = 455    */
                          /*                               a_iel[9] = 333    */
                          /*                                                 */
                          /*    NOTE:  If a midnode does not exist on an     */
                          /*           edge, its location in a_iel will be   */
                          /*           0.                                    */
                          /*                                                 */
   FEM_BOOLEAN *degen_hex );/*(OUT) TRUE if the elem returned is a hexahedra */
                          /*       degenerated to tetrahedra shape.          */
                          /* =============================================== */



                          /* =============================================== */
                          /* === FEM_Kill:  Free up all resources used by    */
                          /* === the ANSYS Meshing Database.  No more calls  */
                          /* === can be made until FEM_Init is called again. */
                          /* === RETURN: void                                */
                          /* =============================================== */
FEM_CPP_EXTERN void FEM_Kill( void );

                          /* =============================================== */
                          /* === FEM_Kill:  Free up all resources used by    */
                          /* === the ANSYS Meshing Database.  No more calls  */
                          /* === can be made until FEM_Init is called again. */
                          /* === 0 == kill all, != 0 kill some               */
                          /* === RETURN: void                                */
                          /* =============================================== */
FEM_CPP_EXTERN void FEM_KillWithOptions( INT iOpt );

                          /* =============================================== */
                          /* === FEM_SetMaxIds: Set the ids at which new     */
                          /* === elements and nodes will be numbered.        */
                          /* === RETURN: void                                */
                          /* =============================================== */
FEM_CPP_EXTERN void FEM_SetMaxIds(
   FEM_INT start_node_id, /* (IN)  Id at which new nodes created by the      */
                          /*       Ansys Meshing Toolkit can begin.  All     */
                          /*       nodes created by the Ansys Meshing        */
                          /*       Toolkit will have ids greater than or     */
                          /*       equal to this id.  This value should be   */
                          /*       larger than any node id saved in the      */
                          /*       native CAD database to avoid multiple     */
                          /*       nodes with the same id.                   */
   FEM_INT start_elem_id );/*(IN)  Id at which new elements created by the   */
                          /*       Ansys Meshing Toolkit can begin.  All     */
                          /*       elements (both area elements and volume   */
                          /*       elements) created by the Ansys Meshing    */
                          /*       Toolkit will have ids greater than or     */
                          /*       equal to this id.  This value should be   */
                          /*       larger than any node id saved in the      */
                          /*       native CAD database to avoid multiple     */
                          /*       nodes with the same id.                   */
                          /* =============================================== */

                          /* =============================================== */
                          /* === FEM_GetMaxIds: Get the greatest id used for */
                          /* === node and elements.                          */
                          /* === RETURN: void                                */
                          /* =============================================== */
FEM_CPP_EXTERN void FEM_GetMaxIds(
   FEM_INT *next_node_id, /* (OUT) The next available node id in the Ansys   */
                          /*       Meshing Database.  This number is simply  */
                          /*       the id sent to FEM_SetMaxIds or FEM_Init, */
                          /*       plus the number of nodes that have been   */ 
                          /*       created since that call.                  */
   FEM_INT *next_elem_id );/*(OUT) The next available elem id in the Ansys   */
                          /*       Meshing  Database.  This number is simply */
                          /*       the id sent to FEM_SetMaxIds or FEM_Init, */
                          /*       plus the number of elements(quads, tris,  */
                          /*       or tets) that have been created since     */
                          /*       that call.                                */ 
                          /* =============================================== */

                          /* =============================================== */
                          /* === FEM_glSetMaxTran: max transition for        */
                          /* === element size in advancing front mesher.     */
                          /* === This option is used to control how rapidly  */
                          /* === elements are permitted to change in size    */
                          /* === from the boundary to the interior of an     */
                          /* === area.  Max transition factor defaults to    */
                          /* === 2.0 which permits elements to approximately */
                          /* === double in size from one element to an       */
                          /* === adjacent element as they approach the       */
                          /* === interior of the area.  Max transition must  */
                          /* === be greater than 1.0 and for best results,   */
                          /* === should be less than 4.0.                    */
                          /* === Return: void                                */
                          /* =============================================== */
FEM_CPP_EXTERN void FEM_glSetMaxTran( FEM_DOUBLE tran );

                          /* =============================================== */
                          /* === FEM_glSetExpansionFactor: For meshing of    */
                          /* === all surfaces, this variable specifies       */
                          /* === how fast transition will occur from the     */
                          /* === boundary element size into the interior of  */
                          /* === the mesh.  > 1 , elements get larger, < 1   */
                          /* === elements get smaller.  If exp_fac == 0.0,   */
                          /* === no expansion factor is used only g_maxtran  */
                          /* === is used.                                    */
                          /* === Return: void                                */
                          /* =============================================== */
FEM_CPP_EXTERN void FEM_glSetExpansionFactor( FEM_DOUBLE exp_fac );

                          /* =============================================== */
                          /* === FEM_glSetFlatElemSize: For meshing of flat  */
                          /* === surfaces, this variable specifies the edge  */
                          /* === length  of elemets on the interior of the   */
                          /* === area.  If set to 0.0, it is ignored and     */
                          /* === size is determined by the boundary edge     */
                          /* === lengths.                                    */
                          /* === Return: void                                */
                          /* =============================================== */
FEM_CPP_EXTERN void FEM_glSetFlatElemSize( FEM_DOUBLE new_size );

                          /* =============================================== */
                          /* === FEM_glSetTetExpand: Used to size internal   */
                          /* === elements in a tet mesh based on the size of */
                          /* === the elements on the volume's boundary.      */
                          /* === exp_fac is the expansion or contraction     */
                          /* === factor.  For example, if exp_fac == 2, a    */
                          /* === volume will allow a mesh with elements that */
                          /* === are approximately twice as large in the     */
                          /* === interior of the volume as they are on the   */
                          /* === boundary.  If exp_fac is less than 1.0, a   */
                          /* === mesh with smaller elements on the interior  */
                          /* === of the volume will be allowed.  exp_fac     */
                          /* === should be greater than 0.1 but less than    */
                          /* === 3.0.  If exp_fac is greater than 2.0,       */
                          /* === mesher robustness may be affected.          */
                          /* === Return: void                                */
                          /* =============================================== */
FEM_CPP_EXTERN void FEM_glSetTetExpand( FEM_DOUBLE exp_fac );

                          /* =============================================== */
                          /* === FEM_glSetSplitQuads: Specify whether poor   */
                          /* === quads in the mesh are to be split into      */
                          /* === triangles after meshing or refinement.  If  */
                          /* === !0, quads will be split.  If 0, quads will  */
                          /* === not be split.                               */
                          /* === Return: void                                */
                          /* =============================================== */
FEM_CPP_EXTERN void FEM_glSetSplitQuads( FEM_INT split );

                          /* =============================================== */
                          /* === FEM_glSetSmoothInMesher: Specify whether    */
                          /* === smoothing should be performed during        */
                          /* === meshing.                                    */
                          /* === Return: void                                */
                          /* =============================================== */
FEM_CPP_EXTERN void FEM_glSetSmoothInMesher( FEM_INT msmooth );

                          /* =============================================== */
                          /* === FEM_glSetTopoCleanInMesher: Specify whether */
                          /* === topological cleanup should be performed     */
                          /* === during meshing.                             */
                          /* === Return: void                                */
                          /* =============================================== */
FEM_CPP_EXTERN void FEM_glSetTopoCleanInMesher( FEM_INT clean );

                          /* =============================================== */
                          /* === FEM_glSetVerify: Turn on debugging in the   */
                          /* === Ansys Mesh Toolkit.                         */
                          /* === Return: void                                */
                          /* =============================================== */
FEM_CPP_EXTERN void FEM_glSetVerify(
    FEM_INT verify );     /* (IN) 1 if debug output is desired.              */
                          /*      0 if debug output is not desired.          */

                          /* =============================================== */
                          /* === FEM_jrSetJournal: Turn on/off journal file  */
                          /* === writing for debuggin the Ansys Mesh Toolkit.*/
                          /* === RETURN: FEM_INT ( EXIT_SUCCESS or           */
                          /* ===                   EXIT_FAILURE)             */
                          /* =============================================== */
FEM_CPP_EXTERN FEM_INT FEM_jrSetJournal(
   JOURNAL_WRITE_TYPE stat, /* (IN) status of writing or reading journal.    */
   char *journalfile );     /* (IN) journal file name for reading.  ignored  */
                            /*      unless stat == READ_JOURNAL.             */

#endif
