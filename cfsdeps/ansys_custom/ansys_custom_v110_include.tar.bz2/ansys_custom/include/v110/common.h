/* sid 60.1 copy of common.h last changed by jtm on 2006/05/15 19:43:51 */
/* 
 * *** copyright(c) 2006 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */
#define COMMON_

#define TRUE  1
#define FALSE 0
/* #define NULL  0 */

/*#define INTEGER int */

#ifdef SPARC
/*
 * SPARC defines
 */
#define INT32  int
#define INT16  int
#define UINT32 unsigned int
#define UINT16 unsigned int
#define UINT8  unsigned char
#define INTEGER INT32
#else
/*
 * PC defines
 */
#define INT32  long
#define INT16  int
#define UINT32 unsigned long
#define  UINT16 unsigned int
#define UINT8 unsigned char
#endif

#define BOOLEAN int
#define FLOAT  float

#define FILESTART 0 
#define FILEEND 2


/* Disable PCVM_ */

