/* sid 60.1 copy of ansVelotypes.h last changed by upd111 on 2006/10/09 19:58:56 */

#include "ansysdef.h"


extern  INT  cCreateAnsVelo(void);
extern  INT  cDeleteAnsVelo(void);
extern  INT  cInquireAnsVelo(INT,INT,INT);
extern  INT  cPutAnsVelo(INT,INT,DOUBLE*);
extern  INT  cGetAnsVelo(INT,INT,INT*,DOUBLE*);
extern  INT  cGetAnsVeloPtr(INT,INT,INT*,DOUBLE**);
extern  INT  cActivateAnsVelo(INT,INT,INT);
extern  INT  cDumpAnsVelo(INT);


/****************************************************************
 global-level structure for ANSYS nodal velocities
 ****************************************************************/
struct ansVelo_str {         /* Name of the structure                              */
  INT       tag;             /* Tag for this instance of the velocity structure    */
  INT       numVeloNodes;    /* Number of nodes with velocities                    */
  INT       maxVeloNode;     /* Maximum external node number having velocity       */
  INT       numVelo;         /* Total number of velocities (zero and non-zero)     */
};

#define ansVeloTag(velo)                (velo->tag)
#define ansVeloNumVeloNodes(velo)       (velo->numVeloNodes)
#define ansVeloMaxVeloNode(velo)        (velo->maxVeloNode)
#define ansVeloNumVelo(velo)            (velo->numVelo)



/******************************************************************
 data-level structure for ANSYS nodal velocities
 ******************************************************************/
struct veloData_str {    /* Name of the structure                                       */
  char      modified;    /* Flag indicating whether this velocity has been modified     */
  char      internal;    /* Flag indicating whether this velocity is internal to object */
  INT       dof;         /* External DOF value                                          */
  char      active;      /* Flag indicating if velocity is active or inactive           */
  DOUBLE   *values;      /* Vector containing velocity values (we store 4 values)       */
                         /*        (1:2) current real,imag values                       */
                         /*        (3:4) previous real,imag values                      */ 
  veloData *nextVelo;    /* Pointer to the next velocity data structure for this        */
                         /* node.  If this pointer is NULL, then this is the last       */
                         /* stored velocity for this node                               */
};

#define veloDataModified(vData)         (vData->modified)
#define veloDataInternal(vData)         (vData->internal)
#define veloDataDof(vData)              (vData->dof)
#define veloDataVeloActive(vData)       (vData->active)

#define veloDataValuesPtr(vData)        (vData->values)
#define veloDataValuesVec(vData,i)      (vData->values[i])

#define veloDataNextVeloPtr(vData)      (vData->nextVelo)

