/* sid 60.1 copy of pds_macros.h last changed by jtm on 2006/05/15 19:44:42 */
/* ---------------------------------------------------------------------- */
/* *** copyright(c) 2006 SAS IP, Inc.  All rights reserved.                                         */
/* *** ansys, inc.                                                        */
/* ---------------------------------------------------------------------- */

/*
 *    author/date: Stefan Reh 03-10-2000
 *
 *    primary function:
 *
 *        Definiton of macros that are use in the PDS code
 *
 *    Notice - This file contains ANSYS Confidential information ***
 *
 */

#ifndef _PDS_MACROS_
#define _PDS_MACROS_

#include "pds_c_types.h"

/* memory allocation and deallocation */
#define Pds_malloc(n)                PDS_malloc(n, __LINE__, __FILE__)
#define Pds_free(n)                  PDS_free(n, __LINE__, __FILE__)
#define Pds_DoubleMatrixAlloc(n, m)  PDS_DoubleMatrixAlloc(n, m, __LINE__, __FILE__)
#define Pds_DoubleMatrixDealloc(n, m) PDS_DoubleMatrixDealloc(n, m, __LINE__, __FILE__)
#define Pds_IntMatrixAlloc(n, m)     PDS_IntMatrixAlloc(n, m, __LINE__, __FILE__)
#define Pds_IntMatrixDealloc(n, m)    PDS_IntMatrixDealloc(n, m, __LINE__, __FILE__)
#define Pds_CharMatrixAlloc(n, m)    PDS_CharMatrixAlloc(n, m, __LINE__, __FILE__)
#define Pds_CharMatrixDealloc(n, m)   PDS_CharMatrixDealloc(n, m, __LINE__, __FILE__) 
#define Pds_MatrixDealloc(n, m)      PDS_MatrixDealloc(n, m, __LINE__, __FILE__)
             

/* Solution Sets data */
#define PDSSoluLabel(i)              Pds_SoluSets[i].SoluLab
#define PDSSoluResFileNam(i)         Pds_SoluSets[i].results_file_name
#define PDSSoluMethod(i)             Pds_SoluSets[i].pds_method
#define PDSSoluNumIter(i)            Pds_SoluSets[i].num_iter
#define PDSSoluMaxIter(i)            Pds_SoluSets[i].max_iter
#define PDSSoluNumCycl(i)            Pds_SoluSets[i].num_cycl
#define PDSSoluMaxCycl(i)            Pds_SoluSets[i].max_cycl
#define PDSSoluNumLoop(i)            Pds_SoluSets[i].num_loop
#define PDSSoluMaxLoop(i)            Pds_SoluSets[i].max_loop
#define PDSSoluNumTotFail(i)         Pds_SoluSets[i].num_tot_fail
#define PDSSoluMaxTotFail(i)         Pds_SoluSets[i].max_tot_fail
#define PDSSoluNumCyclFail(i)        Pds_SoluSets[i].num_cycl_fail
#define PDSSoluMaxCyclFail(i)        Pds_SoluSets[i].max_cycl_fail
#define PDSSoluParOpt(i)             Pds_SoluSets[i].parallel_option
#define PDSSoluMcs(i)                Pds_SoluSets[i].McsOpts
#define PDSSoluRsm(i)                Pds_SoluSets[i].RsmOpts
#define PDSSoluCCDLevels(i)          Pds_SoluSets[i].RsmOpts.CCDLevels
#define PDSSoluCCDValType(i,j)       Pds_SoluSets[i].RsmOpts.CCDLevels[j].iValType
#define PDSSoluCCDLvlOpt(i,j)        Pds_SoluSets[i].RsmOpts.CCDLevels[j].iLvlOpt
#define PDSSoluCCDLvlDefined(i,j)    Pds_SoluSets[i].RsmOpts.CCDLevels[j].iLvlDefined
#define PDSSoluCCDLvlVals(i,j)       Pds_SoluSets[i].RsmOpts.CCDLevels[j].dLvlVals
#define PDSSoluBBMLevels(i)          Pds_SoluSets[i].RsmOpts.BBMLevels
#define PDSSoluBBMValType(i,j)       Pds_SoluSets[i].RsmOpts.BBMLevels[j].iValType
#define PDSSoluBBMLvlOpt(i,j)        Pds_SoluSets[i].RsmOpts.BBMLevels[j].iLvlOpt
#define PDSSoluBBMLvlDefined(i,j)    Pds_SoluSets[i].RsmOpts.BBMLevels[j].iLvlDefined
#define PDSSoluBBMLvlVals(i,j)       Pds_SoluSets[i].RsmOpts.BBMLevels[j].dLvlVals

#define PDSUser                 Pds_UserSettings[0]

/* Random variables data */
#define PDSRvName(i)            Pds_RvDatas[i].Rv_Name
#define PDSRvType(i)            Pds_RvDatas[i].DistributionType 
#define PDSRvNumParms(i)        Pds_RvDatas[i].NumParms
#define PDSRvValue(i)           Pds_RvDatas[i].Current_value

#define PDSRvDisParms(i)        Pds_RvDatas[i].DisParms.General.Parm

#define PDSRvGauMean(i)         Pds_RvDatas[i].DisParms.Gaussian.Mean
#define PDSRvGauSD(i)           Pds_RvDatas[i].DisParms.Gaussian.Std_Dev
#define PDSRvTGauMean(i)        Pds_RvDatas[i].DisParms.TrunGau.Mean
#define PDSRvTGauSD(i)          Pds_RvDatas[i].DisParms.TrunGau.Std_Dev
#define PDSRvTGauMax(i)         Pds_RvDatas[i].DisParms.TrunGau.Max
#define PDSRvTGauMin(i)         Pds_RvDatas[i].DisParms.TrunGau.Min
#define PDSRvLog1Mean(i)        Pds_RvDatas[i].DisParms.Lognormal1.Mean
#define PDSRvLog1SD(i)          Pds_RvDatas[i].DisParms.Lognormal1.Std_Dev
#define PDSRvLog2Mean(i)        Pds_RvDatas[i].DisParms.Lognormal2.Mean
#define PDSRvLog2SD(i)          Pds_RvDatas[i].DisParms.Lognormal2.Std_Dev
#define PDSRvTriLow(i)          Pds_RvDatas[i].DisParms.Triangular.Low_Bound
#define PDSRvTriMid(i)          Pds_RvDatas[i].DisParms.Triangular.Most_Likely_Point
#define PDSRvTriHigh(i)         Pds_RvDatas[i].DisParms.Triangular.High_Bound
#define PDSRvUniLow(i)          Pds_RvDatas[i].DisParms.Uniform.Low_Bound
#define PDSRvUniHigh(i)         Pds_RvDatas[i].DisParms.Uniform.High_Bound
#define PDSRvWeiExp(i)          Pds_RvDatas[i].DisParms.Weibull.Exponent
#define PDSRvWeiChar(i)         Pds_RvDatas[i].DisParms.Weibull.Char_Value
#define PDSRvWeiOff(i)          Pds_RvDatas[i].DisParms.Weibull.Offset
#define PDSRvExpDecay(i)        Pds_RvDatas[i].DisParms.Exponential.Decay_Value
#define PDSRvExpIni(i)          Pds_RvDatas[i].DisParms.Exponential.Initial_Value
#define PDSRvGamPow(i)          Pds_RvDatas[i].DisParms.Gamma.Power_Value
#define PDSRvGamDecay(i)        Pds_RvDatas[i].DisParms.Gamma.Decay_Value
#define PDSRvBetaP(i)           Pds_RvDatas[i].DisParms.Beta.Power_P
#define PDSRvBetaQ(i)           Pds_RvDatas[i].DisParms.Beta.Power_Q
#define PDSRvBetaLow(i)         Pds_RvDatas[i].DisParms.Beta.Low_Bound
#define PDSRvBetaHigh(i)        Pds_RvDatas[i].DisParms.Beta.High_Bound

#define PDSRvCCDValType(i)      Pds_CCDLevels[i].iValType
#define PDSRvCCDLvlOpt(i)       Pds_CCDLevels[i].iLvlOpt
#define PDSRvCCDLvlDefined(i)   Pds_CCDLevels[i].iLvlDefined
#define PDSRvCCDLvlVals(i)      Pds_CCDLevels[i].dLvlVals

#define PDSRvBBMValType(i)      Pds_BBMLevels[i].iValType
#define PDSRvBBMLvlOpt(i)       Pds_BBMLevels[i].iLvlOpt
#define PDSRvBBMLvlDefined(i)   Pds_BBMLevels[i].iLvlDefined
#define PDSRvBBMLvlVals(i)      Pds_BBMLevels[i].dLvlVals

/* Random output parameter data */
#define PDSRpName(i)            Pds_RpDatas[i].Rp_Name
#define PDSRpValue(i)           Pds_RpDatas[i].Current_value

/* Results File data */
#define PDSResultsFileLoaded(i)        Pds_ResultsFileDatas[i].Loaded
#define PDSResultsFileNumSamples(i)    Pds_ResultsFileDatas[i].NumSamples
#define PDSResultsFileIterNum(i)       Pds_ResultsFileDatas[i].IterNum
#define PDSResultsFileCyclNum(i)       Pds_ResultsFileDatas[i].CyclNum
#define PDSResultsFileLoopNum(i)       Pds_ResultsFileDatas[i].LoopNum
#define PDSResultsFileFailIdx(i)       Pds_ResultsFileDatas[i].FailIdx
#define PDSResultsFileInputSamples(i)  Pds_ResultsFileDatas[i].InputSamples
#define PDSResultsFileOutputSamples(i) Pds_ResultsFileDatas[i].OutputSamples

#define PDSResultsFileMean(i)          Pds_ResultsFileDatas[i].Mean
#define PDSResultsFileStdev(i)         Pds_ResultsFileDatas[i].Stdev
#define PDSResultsFileSkew(i)          Pds_ResultsFileDatas[i].Skew
#define PDSResultsFileKurt(i)          Pds_ResultsFileDatas[i].Kurt
#define PDSResultsFileMin(i)           Pds_ResultsFileDatas[i].Min
#define PDSResultsFileMax(i)           Pds_ResultsFileDatas[i].Max

#define PDSResultsFilePdprobMed(i)     Pds_ResultsFileDatas[i].PdprobMed
#define PDSResultsFilePdprobLow(i)     Pds_ResultsFileDatas[i].PdprobLow
#define PDSResultsFilePdprobUpp(i)     Pds_ResultsFileDatas[i].PdprobUpp
#define PDSResultsFilePdpinvMed(i)     Pds_ResultsFileDatas[i].PdpinvMed
#define PDSResultsFilePdpinvLow(i)     Pds_ResultsFileDatas[i].PdpinvLow
#define PDSResultsFilePdpinvUpp(i)     Pds_ResultsFileDatas[i].PdpinvUpp

#define PDSResultsFileLinCorrCoef(i)   Pds_ResultsFileDatas[i].LinCorrCoef
#define PDSResultsFileRnkCorrCoef(i)   Pds_ResultsFileDatas[i].RnkCorrCoef

/* Post-Sampling of response surfaces */
#define RSPostSampDone(i)           Pds_RSPostSamples[i].Done
#define RSPostSampNumSamples(i)     Pds_RSPostSamples[i].NumSamples
#define RSPostSampNumRSOut(i)       Pds_RSPostSamples[i].NumRSOut
#define RSPostSampIdx2Rp(i)         Pds_RSPostSamples[i].Idx2Rp
#define RSPostSampInputSamples(i)   Pds_RSPostSamples[i].InputSamples
#define RSPostSampOutputSamples(i)  Pds_RSPostSamples[i].OutputSamples
#define RSPostSampMean(i)           Pds_RSPostSamples[i].Mean
#define RSPostSampStdev(i)          Pds_RSPostSamples[i].Stdev
#define RSPostSampSkew(i)           Pds_RSPostSamples[i].Skew
#define RSPostSampKurt(i)           Pds_RSPostSamples[i].Kurt
#define RSPostSampMin(i)            Pds_RSPostSamples[i].Min
#define RSPostSampMax(i)            Pds_RSPostSamples[i].Max

#define RSPostSampPdprobMed(i)      Pds_RSPostSamples[i].PdprobMed
#define RSPostSampPdprobLow(i)      Pds_RSPostSamples[i].PdprobLow
#define RSPostSampPdprobUpp(i)      Pds_RSPostSamples[i].PdprobUpp
#define RSPostSampPdpinvMed(i)      Pds_RSPostSamples[i].PdpinvMed
#define RSPostSampPdpinvLow(i)      Pds_RSPostSamples[i].PdpinvLow
#define RSPostSampPdpinvUpp(i)      Pds_RSPostSamples[i].PdpinvUpp

#define RSPostSampLinCorrCoef(i)    Pds_RSPostSamples[i].LinCorrCoef
#define RSPostSampRnkCorrCoef(i)    Pds_RSPostSamples[i].RnkCorrCoef

#endif /* _PDS_MACROS_ */
