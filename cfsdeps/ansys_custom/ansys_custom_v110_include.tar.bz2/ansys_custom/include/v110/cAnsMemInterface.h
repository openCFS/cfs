/* sid 60.1 copy of cAnsMemInterface.h last changed by upd111 on 2006/10/09 19:54:59 */
/*HFILE cAnsMemInterface.h                               rlr */

#ifndef __CANSMEMINTERFACE_H__
#define __CANSMEMINTERFACE_H__ 1

#include "ansys.h"


/* pull in the CtoF definitions so that debugging routines are accessible 
   from both languages */
#include "AnsMemCtoF.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Memory API from C */
void *cAnsMemAlloc(size_t length, INT key, CHAR *fileName, INT lineNum);
void *cAnsMemAllocL(PTR length, INT key, CHAR *fileName, INT lineNum);
void cAnsMemFree(void *memPtr, CHAR *fileName, INT lineNum);
void *cAnsMemRealloc(void *memPtr, size_t length, INT key, CHAR *fileName, INT lineNum);
void cAnsMemGroupFree(INT groupKey);
INT cAnsMemHandle(void *memPtr);
void *cAnsMemPointer(INT handle);
void *cAnsMemLock(INT handle);
INT cAnsMemUnlock(void *memPtr);
PTR cAnsMemInquire(INT handle, INT key);
void cAnsMemInform(INT key, void *value);

#ifdef __cplusplus
}
#endif

/* macros to call the memory routines */
#define ANSYSMALLOC(x) cAnsMemAlloc((x),0,__FILE__,__LINE__)
#define ANSYSFREE(x) cAnsMemFree((x),__FILE__,__LINE__)
#define ANSYSREALLOC(x,y) cAnsMemRealloc((x),(y),0,__FILE__,__LINE__)

/* special allocation macros */
#define ANS_SOLVER_MEMORY_GROUP_CODE_1    65536
#define ANS_GRAPHICS_MEMORY_GROUP_CODE   131072

#define ANSYSGRAPHICSMALLOC(x) cAnsMemAlloc((x),ANS_GRAPHICS_MEMORY_GROUP_CODE,__FILE__,__LINE__)
#define ANSYSSOLVERSMALLOC(x,y) cAnsMemAlloc((x),(y),__FILE__,__LINE__)

/*
 *  Documentation of the allocation control word bits:
 * 
 *  1           1  \
 *  2           2   Used by MEM_INTEGER, MEM_REAL, etc.
 *  3           4  /
 *  4           8
 *  5          16  MEM_FIXED
 *  6          32
 *  7          64  MEM_QUERY
 *  8         128  MEM_RETURN
 *  9         256  MEM_INITIAL
 * 10         512  MEM_GROWTH
 * 11        1024  MEM_FAIL
 * 12        2048  MEM_RESTRICTED
 * 13        4096
 * 14        8192
 * 15       16384
 * 16       32768
 * 17       65536  \
 * 18      131072       
 * 19      262144       
 * 20      524288   Group allocation codes
 * 21     1048576   (127 possible)
 * 22     2097152
 * 23     4194304  /
 * 24     8388608
 * 25    16777216
 * 26    33554432
 * 27    67108864
 * 28   134217728
 * 29   268435456
 * 30   536870912
 * 31  1073741824
 * 32  2147483648
 *
 */

#endif
