/* sid 60.1 copy of FEM_quadsplit.h last changed by upd111 on 2005/07/21 19:41:05 */
/*
 * *** ansys(r) copyright(c) 1999
 * *** ansys, inc.
 */
/*  FEM_quadsplit.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_quadsplit.h
 *  header file for FEM_quadsplit.c
 *
 */
#ifndef FEM_QUADSPLIT_INCLUDE
#define FEM_QUADSPLIT_INCLUDE

/*----------------- Globally accessible function prototypes -----------------*/

#ifdef __cplusplus
extern "C" {
#endif

                              /* === FEM_qsSplitPoorQuads: Split any poorly  */
                              /* === shaped quad face not attached to any    */
                              /* === elements into 2 triangles.              */
INT FEM_qsSplitPoorQuads (
   INT area_id,               /* (IN)  The id of the area to split quads on. */
   INT *split  );             /* (OUT) returned as TRUE if any quad was split*/

                               /* === FEM_qsSplitQuad:                       */
                               /* === split a quad (obj_face) using obj_node */
                               /* === as the vertex.  Called from            */
                               /* === from fem_quadsplit.c                   */

INT FEM_qsSplitQuad (
   FACE_OBJ obj_face,         /* face to be split */
   NODE_OBJ obj_node,         /* split vertex */
   FACELIST_OBJ obj_flist,    /* face list */
   FACE_OBJ *obj_newtri1,     /* (OUT) one of the resulting tris. */
   FACE_OBJ *obj_newtri2 );   /* (OUT) the other resulting tris. */

                              /* === FEM_qsTrisFromQuad: same as             */
                              /* === FEM_qsSplitQuad but doesn't delete the  */
                              /* === quad (also returns the new tris)        */
INT FEM_qsTrisFromQuad (
   FACE_OBJ obj_face,                   /* face to be split */
   NODE_OBJ obj_node,                   /* split vertex */
   FACELIST_OBJ obj_flist,              /* face list */
   FACE_OBJ *p_obj_tri1,                /* return new tri */
   FACE_OBJ *p_obj_tri2  );             /* return new tri */


                              /* === FEM_qsCentroid: same as  */
                              /* === FEM_re2RefNodes_QuadA     */
                              /* === finds centroid of quad using shape function */
INT FEM_qsCentroid(
   FACE_OBJ obj_face,     /* (IN)  the face object */
   DOUBLE *xc,            /* (OUT) return the location of centroid */
   DOUBLE *yc,
   DOUBLE *zc );



                              /* === Function: FEM_qsMaxMinAng               */
                              /* === Description: Before splitting quad      */
                              /* === determine what node to split at by      */
                              /* === maximizing the minimum angle            */

 /* * === Loop through the 4 nodes in the element and determine
    * === if the split node should be the next one around
    * === MAXIMIZE THE MINIMUM ANGLE

       Figure: illustrating splitting and angles along with pairs
       inod=0..3       pairs from 0to2 and 1to3
       cang=0..7
    
                   3                        2
                       -------------------
                      | \ 3           4 / |
                      |5                2 |
                      |                   |
                      |                   |
                      |                   |
                      |                   |
                      |                   |
                      |                   |
                      |0                 7|
                      | / 6           1 \ |
                       -------------------
                    0                       1

                          


 *============================================================================*/

NODE_OBJ FEM_qsMaxMinAng (   
   NODE_OBJ     aobj_nodes[8]  );  /* nodes of the face */


                           /*==============================================================================
                            * === Funtion: FEM_qsSetQSForMappedTriMesh
                            * === Author: jrt
                            * === Description: set mapped tri meshing or not
                            * === Return: void 
                            *============================================================================*/

void FEM_qsSetQSForMappedTriMesh( FEM_BOOLEAN flag );

INT FEM_qsNeedSplitQuads (
   INT area_id,  /* (IN)  The id of the area to split quads on. */
   INT *pSplit );

#ifdef __cplusplus
}
#endif

#endif

