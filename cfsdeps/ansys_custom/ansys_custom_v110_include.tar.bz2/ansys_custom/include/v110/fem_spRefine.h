/* sid 60.1 copy of fem_spRefine.h last changed by upd111 on 2005/07/21 19:42:37 */
/*  fem_spRefine.h */
/* 
 * *** ansys(r) copyright(c) 1999
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  fem_spRefine.h
 *  Prototypes and macros for surface proximity refinement
 *
 */

#ifndef FEM_SPREFINE_____H
#define FEM_SPREFINE_____H

                          /* ================================================ */
                          /* === FEM_spRefineTagesNodes: Refine around the    */
                          /* === nodes that were marked. Refinement is        */
                          /* === performed by FEM_reProcessElements.          */
                          /* === Return: EXIT_FAILURE or EXIT_SUCCESS         */
INT FEM_spRefineTagedNodes (
   VERTEXLIST_TYP *ps_vertexlist,  /* (IN/OUT) list of vertices to refine   */
   INT num_taged,                  /* (IN/OUT) numbr of vertices in
                                               ps_vertexlist                */
   RANGETREE_TYP *ps_range_tree,   /* (IN/OUT) the range tree               */
   DOUBLE growth_ratio,            /* (IN)     growth ratio                 */
   DOUBLE minesize,                /* (IN)     lower limit on element size  */
   INT midnodes,                   /* (IN)     TRUE if midnodes exist       */
   INT percent,                    /* (IN)     % complete for abort window  */
   INT *abort  );                  /* (OUT)    !0 if user requests abort    */

#endif

