/* sid 60.8 copy of CLMeshBase.h last changed by sgaltier on 2006/07/31 12:05:35 */
/******************************************************************/
/*!
\file CLMesh.h
\brief Classe de base pour la gestion des maillages ligths
\version 1.00
*/
/******************************************************************/

#ifndef CLMESHBASE_H
#define CLMESHBASE_H 11


#include "cadoe.h"
#include "CCadoePortable.h"
#include "expmdb_struct.h"
#include "LIGHT_struct_base.h"
#include "Cnodes.h"

class CLMpertBase;
class Point3D;

extern FILE *openMVWfile ( const string nom );

class CLMeshBase 
{

	enum E_LIGHT_ERR
	{
		LIGHT_NO_ERROR,
		LIGHT_NO_INV_CONNECT,
		LIGHT_VAN_NOT_FOUND
	};

private:
	T_Mesh			 *GetEntete(); 

protected:
	int NB_NOEUD_MAX_PAR_ELT;

	T_Lelement       *GetElements();
	T_statut		 SetElementNonValide();
	unsigned int     GetNbElementNonValide();
	T_statut		 ReplaceNumeroByIndex();
	void desallouer_element_courant	  (  );

public:
//  friend CLMpertBase;
  CLMeshBase( T_Mesh *mesh );
	CLMeshBase( CLMeshBase * pMeshBase );
	CLMeshBase();
	void SetNoeudElement(T_Lnoeud *,T_Lelement * );
	T_statut InitCLMesh();
	void  allouer_element_courant();
	T_statut  Construire_tableele();
	virtual ~CLMeshBase();
	bool copyFromTmesh ( T_Mesh *mesh );

	/* save & read */
	bool      isMeshLoaded ();

	bool loadData ( T_cbf *cbf, T_Mesh * );

	void        setMesh ( T_Mesh *mesh ) { _mesh = mesh; _dimension = mesh->dimension; };

	//les noeuds
	bool setNbNodes ( int nb_noeud );
	int addNode ( int numero, double *xyz );
	T_Noeud ** CopyNodeByIndex(IVEC *IndexNode, T_Noeud ** n0, T_statut *ier );
	T_Lnoeud *getNodes() { return _Lnode; };                    // recupere le pointeur des noeuds
	void setNodes ( T_Lnoeud *nodes ) { _Lnode = nodes; };      // charge le pointeur des noeuds

	//les elementss
	bool setNbElements ( int nb_element );
	bool addElement ( int numero, E_ele_type_geo type_geo, int nb_noeud, int *noeuds, unsigned int *indice );
	void setElements ( T_Lelement *eles ) { _Lelement = eles; };      // charge le pointeur des elements
	T_Lelement *getElements() { return _Lelement; };                    // recupere le pointeur des elements

	int  IdentifierFacette( int nume_ini,unsigned int *node);
	int  IdentifierFacetteByNumero( int nume_ini,unsigned int *nodes);
	
	//les groupes
	bool	isComponentExist(const char * nom);

	/* ele_travail */
	T_Element   * GetNoeudofTelement (int indEle);
	T_Element	* getElemCourant(int indice);

	/* elts non valides */
	unsigned int GetNbElement1D(int &nbnoeudmax);
	unsigned int  GetNbElement0D();
	unsigned int    GetNbElementValide   ();
	T_booleen       IsElementValide( int numero);
	T_booleen		IsElementValideByIndice( int ind); 
	int				GetIndiceElementValide( int indice );
	int				getDimensionElement ( int indE );


	/* critere qualit� */
	T_statut		LIGHT_ELE_calculer_qualite ( VEC *pert, int critere, VEC **klite );
	int				calculateDistortion  ( VEC *perturbation, VEC **distortion ) ;
	T_booleen		LIGHT_verif_convexite( T_booleen avec_perturb, T_statut *ier );

	/* le polynome */
	BVEC *getSupportOfParam( const char *param, bool only_config_mono, double filtre, double filtre2, T_statut *ier );

	/* perturbations */
	bool SetPerturb( VEC *pert);
	double * GetNoeudPerturb( int numero, T_Noeud &nd );
	double * GetNoeudPerturbByIndice( int indice , T_Noeud &nd );

	bool        addCSdepla ( int numero, int indice = -1 );
	int getCSdepla ( int indNoe );

	/* Sur les elts */
	bool			IsVolumique();
	unsigned int	getNbNodes();
	unsigned int	getNbNodesMax();
	unsigned int	GetNbElements(); 
	unsigned int	GetNbElementsMax(); 
	bool	IsElementVolumique( int IdEle);

	int		*		ElementGetPrimaryNode(int IndexEle, int &nb_noeud, vector<int> &IdxNode);
	int    *		ElementGetNode(int IndexEle, int &nb_noeud);
	int	   *		GetElement ( int numero,int *indEle, E_ele_type_geo *type, int *nb_noeud ); // LES INDICES EN RETOUR
	int	   *        GetElement ( int numero, T_Element &ele );									// LES INDICES EN RETOUR

	int			*GetEleWithNumNode( int numero,int *indEle, E_ele_type_geo *type , int *nb_noeud, vector<int> * numnd = NULL ); // LES NUMEROS EN RETOUR
	int			*GetEleWithNumNode (int numero, T_Element &ele, vector<int> * numnd = NULL);									// LES NUMEROS EN RETOUR

	int    *        GetElementByIndice(int indice , T_Element &ele, vector<int> * num_nd = NULL);
	int    *        GetElementByIndice(int indice, int *numero, E_ele_type_geo *type, int *nb_noeud, vector<int> * num_nd= NULL);// retourne le numero des nds 
	void    		GetElementByIndice(int ie , int &numero);  
	T_Element  *    GetElementByIndice( int indice );
	int				GetNumElement( int ie ); 
	E_ele_type_geo  GetElementType ( int numero, int **ele, int *nb_noeud );
	E_ele_type_geo  GetElementType ( int indice );
	int             GetIndiceElement( int numero );
	bool			IsShellElement(int indice);

	bool setElementData ( T_Lelement *Lele );

	/* elements voisins */
	T_statut		GetElementVoisin( int numeroEle, vector<int> &numeros);
	IVEC   *        GetElementVoisin( vector <int> &numeros, T_statut *ier);
	T_statut		GetElementVoisinByIndice( int indiceEle, vector<int> &numeros);

	/* Sur les nds */
	double *		XYZ( int indNd );
	double *		getPoint3D( int indNd, Point3D *pt ) { return NULL; }
	void			setXYZ( int indNd, double *xyz );
	T_booleen		NoeudExiste ( int numero, int *indice );
	double *		GetNoeud ( int numero );
	T_Lnoeud		 *GetNoeuds();
	double *        GetNoeud( int numero, T_Noeud &nd );
	double *		GetNoeudByIndice ( int indice, int *numero );
	double *        GetNoeudByIndice( int indice , T_Noeud &nd );
	double *		GetIndiceNoeud ( int numero, int *indice );
	int				GetNumNoeud (int indice);
	double			getDistanceTwoNodes ( int n0, int n1 );
	int				ElementGetNbNode(int IndexEle);
	VEC *getAllNodesXYZ();

	/* Epaisseur */
	map<int, double> * GetEpaisseurs(); 
	void	 insertEpaisseur(const map<int, double> & mEpaisseurs);

	/* Materiaux */
	map<int, int> * GetMateriaux(); 
	void	 insertMateriaux(const map<int, int> & mMateriaux);

	/* degre */
	unsigned int	SetDegree();
	unsigned int	SetDegree ( int degre );
	unsigned int    GetDegree();
	bool	setElementType(int IndexEle, E_ele_type_geo type);

	/* dimension */
	unsigned int getDimension ( ) { return _dimension; };
	void         setDimension ( unsigned int dimension ) { _dimension = dimension; };

	/* pour parcourir */
	void            InitIter();
	int				GetNextNum(int entite);

	void getZbuffer ( double *direc, double *Zmin, double *Zmax );

	/* taille */
	void		setTaille ( );
	double		 getTaille ();

	/* pour les contact */
	bool isMeshUseContact();
	double	get_dist_to_elt( int elem, int noeud );


	/* sortie pour meshViewer */
	//  void ecrireMeshViewerFile ( const string nom );
	/* sortie pour meshViewer */
	void ecrireMeshViewerFile ( const string nom, VEC *perturb = NULL );
	void ecrireMeshViewerFileNodeData ( const string nom, VEC *input_pert );
	void ecrireMeshViewerFileEleData ( const string nom, VEC *input_pert, VEC *Npert = NULL );
	void ecrireMeshViewerFileEleData ( const string nom, IVEC *input_pert, VEC *Npert = NULL );
	void ecrireNoeudData ( FILE *fic, int indN, VEC *Npert, double Ndata );

	void WRITE_ELEMENT_VIEWER( const char *name );
	/* Pour le debug  */
	T_statut	DBG_check_element(int numero);
	void		DBG_check_element_by_index(int indice);
	int			GetNumeroEleMax();
	unsigned int getNumeroMaxForNode(){return _numMaxForNode;};
	unsigned int getNumeroMaxForElement(){return _numMaxForElement;};


	void LibererLelement();
	void LibererLnoeud();
	void LibererMemoire();

	/*===============*/
	/*  les ami(e)s  */
	/*===============*/

	/*=================================*/
	/*		les donn�es membres		   */
	/*=================================*/
public:

	T_Mesh					*_mesh;					/*	uniquement l entete et les dimensions du maillage */

protected:
	T_Element				* ele_travail;			/* elt courant de travail. Vou� a disparaitre		  */


	double					_taille;				/* taille du maillage */
	double					_precision;				/* precision absolue */
	unsigned int			_degre ;				
//	unsigned int			_nbNodes;
	unsigned int			_nbElements;
	unsigned int			_dimension;
	T_Lelement				*_Lelement;
	T_Lnoeud				*_Lnode;
	VEC						*_Lperturb;				/*	vecteur des perturbations nodales 	*/
	IVEC					*_cs_depla_label;
	IVEC					*_cs_def_label;
	IVEC					*_indEleNonValide;		/*  indices  des elements non valides	*/
	unsigned int			_numMaxForNode;
	unsigned int			_numMaxForElement;

private:
	Cnodes					*_nodes;
	BVEC					*_Nsupport;
	BVEC					*_Esupport;
//	T_Lnoeud				*_Lnode;	
};


#endif /* CLMESH_H */



