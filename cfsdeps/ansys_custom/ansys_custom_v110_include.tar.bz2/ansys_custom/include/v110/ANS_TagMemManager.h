/* sid 60.3 copy of ANS_TagMemManager.h last changed by jtm on 2006/05/16 13:52:25 */
////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         copyright(c) 2006 SAS IP, Inc.  All rights reserved.             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: ANS_TagMemManager.h $
// $Revision$ 7.0
// $Date$ October 21 2003
// $Author$ rjayasee
//
// Description :
//          Block Memory Manager
////////////////////////////////////////////////////////////////////////////

#if !defined(ANS_TAGMEMMANAGER_H)
#define ANS_TAGMEMMANAGER_H

#include "ANS_StandardIncludes.h"

extern "C"
{
    void *cAnsMemAlloc(size_t length, INT key, CHAR *fileName, INT lineNum);
    void cAnsMemFree(void *memPtr, CHAR *fileName, INT lineNum);

    #define ANS_MALLOC(x)  cAnsMemAlloc((x),0,__FILE__,__LINE__)
    #define ANS_FREE(x)  cAnsMemFree((x),__FILE__,__LINE__)
}


void*  ANS_TagMemManagerMalloc(size_t iSz, char* pFile, int iLineNum ) ;
void  ANS_TagMemManagerFree(void* pPtr, char* pFName, int iLineNum) ;

class ANS_TagMemManager
{
    public:

    ANS_TagMemManager( INT iMinBlockSize, INT iMaxBlocks ) ;
    // iMinBlocks
    //-Creates a Minimum of iMinBlock
    // iMaxBlocks
    //-Maximum number of blocks
    // Constructor

    ~ANS_TagMemManager() ;
    //Delete the Whole thing

    /*
    void * operator new(size_t iMemSize )
    {
        return ANS_MALLOC(iMemSize) ;
    }

    void * operator new[]( size_t iSize )
    {
        return ANS_MALLOC(iSize) ;
    }

    void operator delete(void * pMemPtr)
    {
            ANS_FREE(pMemPtr) ;
    }

    void operator delete[](void * pMemPtr )
    {
            ANS_FREE(pMemPtr) ;
    }
    */

    void *Malloc(size_t iLength, CHAR *pFileName, INT iLineNum);
    //R void*
    //R-Pointer to the allocator memory
    //I length
    //I-length of the memory
    //I pFileName
    //I File Name where allocated
    //I iLineNum
    //I-Line Number where allocated

    void Free(void *pMemPtr, CHAR *pFileName, INT iLineNum);
    //R void
    //I pMemPtr
    //I-Pointer to the memory to be deleted
    //I pFileName
    //I File Name where allocated
    //I iLineNum
    //I-Line Number where allocated

    void ReUse( bool bInitFlag );
    //I bInitFlag
    //- Whether to reinitialize to Zero
    //Initialize all blocks data to zero to reuse

    protected:

    ANS_TagMemManager() ;

    void** m_pBlockPtrs ;
    //Actual Memory Allocated

    INT m_iNumBlockPtrs ;
    //Number of Block Pointers

    INT* m_pBlockPtrSize ;
    //Size of Each Block Ptr

    INT m_iNumBlocks ;
    //Number of Allocated Blocks

    INT m_iRemainingBlockSz ;
    //Remaining Size of the current Block

    INT m_iCurBlockIndex ;
    //As the name says

    INT m_iMinBlockSize ;

    void* m_pCurAllocPosPtr ;
    //This is the pointer from which then next data is to be allocated

    INT m_iRefCount ;
} ;

#endif
