/* sid 60.1 copy of fem_hdSmooth.h last changed by upd111 on 2005/07/21 19:42:16 */
/*  fem_hdSmooth.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  fem_hdSmooth.h
 *  Prototypes and macros for hexdom smooth functions
 *
 */

#ifndef HDSMOOTH_H
#define HDSMOOTH_H

/*------------------------ Constants -------------------------------------------*/
#define EXIT_CANT_SMOOTH -994
#define EXIT_SMOOTH_FAILURE  -899
#define EXIT_SMOOTH_ADJUSTED -897

/*------------------------ Data Structures -------------------------------------*/
typedef enum {
   FRONTAL_SMOOTH,
   FRONTAL_PLANE_SMOOTH,
   ISOPARAMETRIC_SMOOTH,
   LAPLACIAN_SMOOTH,
   OPTI_SMOOTH
}SMOOTH_ENUM;

/*------------------------ Globals - used in only FEM_hd files -----------------*/
#include "fem_hdFront.h"

/*------------------------ Prototypes ------------------------------------------*/

INT               fem_hdElemLocalSmooth         ( NODE_OBJ *aobj_nodes,
                                                  INT numnodes,
                                                  HDFRONT_PTYP *a_update_front,
                                                  INT *p_num_update_front );

INT               fem_hdLocalSmooth             ( SMOOTH_ENUM smoothtype,
                                                  NODE_OBJ obj_node,
                                                  HDFRONT_PTYP *a_update_front,
                                                  INT *p_num_update_front );

INT               fem_hdSmoothNode              ( SMOOTH_ENUM smoothtype,
                                                  NODE_OBJ obj_node,
                                                  HDFRONT_PTYP *a_update_front,
                                                  INT *p_num_update_front,
                                                  FEM_BOOLEAN *p_moved );

INT               fem_hdSmoothLaplacian         ( NODE_OBJ obj_node,
                                                  FEM_BOOLEAN *p_moved );

INT               fem_hdSmoothIsoParametric     ( NODE_OBJ obj_node,
                                                  FEM_BOOLEAN *p_moved );    

INT               fem_hdSmoothRandom            ( NODE_OBJ obj_node,
                                                  FEM_BOOLEAN *p_moved );

void              fem_hdSmoothDraw              ( NODE_OBJ obj_node,
                                                  VECTOR3D *ps_old );

INT               fem_hdOptiSmooth              ( NODE_OBJ obj_node,
                                                  FEM_BOOLEAN *p_moved );
INT               fem_hdOptiSmoothAll           ( void );
INT               fem_hdSmoothOnFront           ( NODE_OBJ obj_node,
                                                  FEM_BOOLEAN *p_moved );
INT               fem_hdCheckMetrics            ( );

INT               fem_hdSmoothAdjust            ( NODE_OBJ obj_node,
                                                  ELEMENT_OBJ *aobj_elements,
                                                  INT num_elems,
                                                  VECTOR3D *ps_last,
                                                  VECTOR3D *ps_best );
FEM_BOOLEAN       fem_hdIsInverted              ( NODE_OBJ obj_node,
                                                  ELEMENT_OBJ obj_elem );  


#endif
