/* sid 60.5 copy of FEM_globals.h last changed by upd111 on 2006/03/03 15:00:33 */

/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 1998 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


#ifndef FEM_GLOBALS__H
#define FEM_GLOBALS__H


/* === This file contains global variables which specify global 
   === meshing parameters for the ANSYS Meshing Toolkit.  In addition, this 
   === file contains Macros to access and set the value of these variables.  
   === The first 5 variables (g_maxtran,g_expansionfactor, g_flatelemsize,  
   === g_tetexpand, and g_quadsplit) are user controlable and it is 
   === appropriate to let the user control these variables through the gui 
   === or command line.  The user values for these variables are given to 
   === the mesh toolkit by calling the appropriate FEM_glSetX_C Macro or FEM_glSetX
   === function in 
   === FEMe_SetParameters().  The next 3 variables (g_meshersmooth, g_verify, 
   === and g_meshertopoclean) are for debugging purposes and the user should
   === not be allowed to alter these.  You, however, may experiment with them
   === in the event of a mesher failure during debugging.  FEM_glSetVerify_C()
   === turns on a general debugging flag that causes debugging information to
   === be printed out and intermediate mesh images to be printed to the screen.
   === The rest of the variables in this file are for internal development
   === experimentation only.  Do not attempt to change the value of any of
   === these variables.  Once smart sizing is included, some of these
   === variables will be included in the list of variables to let users
   === specify. */




#ifdef __cplusplus
extern "C" {
#endif


/* ========================================================================= */
/* === Variable: g_maxtran                                                   */
/* === Description: max transition for element size in advancing front mesher*/
/* ===              This option is used to control how rapidly elements are  */
/* ===              permitted to change in size from the boundary to the     */
/* ===              interior of an area.  Max transition factor defaults to  */
/* ===              2.0 which permits elements to approximately double in    */
/* ===              size from one element to an adjacent element as they     */
/* ===              approach the interior of the area.  Max transition must  */
/* ===              be greater than 1.0 and for best results, should be less */
/* ===              than 4.0.                                                */
/* === Access: FEM_glSetMaxTran_C, FEM_glSetMaxTran, FEM_glMaxTran_C         */
/* === Default: 2.0                                                          */
/* === Used By: FEM_advFront                                                 */

extern DOUBLE g_maxtran;

#define MAXTRAN_DEFAULT  2.0

#define FEM_glSetMaxTran_C( tran )\
           g_maxtran = (DOUBLE)tran;

#define FEM_glMaxTran_C() (g_maxtran)





/* ========================================================================= */
/* === Variable: g_expansionfactor                                           */
/* === Description: For meshing of non flat surfaces, this variable          */
/* ===              specifies how fast transition will occur from the        */
/* ===              boundary element size into the interior of the mesh.     */
/* ===              > 1 , elements get larger, < 1 elements get smaller.     */
/* ===              If g_expansionfactor == 0.0, no expansion factor is used */
/* ===              only g_maxtran is used.                                  */
/* === Default: 0.0                                                          */
/* === Access: FEM_glExpansionFactor_C, FEM_glSetExpansionFactor, and        */
/* ===         FEM_glSetExpansionFactor_C                                    */
/* === Used By: Delaunay area mesher on non-flat surfaces only.              */
/* ========================================================================= */
extern DOUBLE g_expansionfactor;

#define EXPANSIONFACTOR_DEFAULT         0

#define FEM_glSetExpansionFactor_C( exp_fac )\
         g_expansionfactor = (DOUBLE)exp_fac;

#define FEM_glExpansionFactor_C( ) g_expansionfactor





/* ========================================================================= */
/* === Variable: g_flatelemsize                                              */
/* === Description: For meshing of flat surfaces, this variable specifies    */
/* ===              the edge length  of elemets on the interior of the area. */
/* ===              If set to 0.0, it is ignored and size is determined by   */
/* ===              the boundary edge lengths.                               */
/* === Default: 0.0                                                          */
/* === Access: FEM_glFlatElemSize_C, FEM_glSetFlatElemSize_C, and            */
/* ===         FEM_glSetFlatElemSize.                                        */
/* === Used By: Delaunay area mesher on flat surfaces only.                  */
/* ========================================================================= */
extern DOUBLE g_flatelemsize;

#define FLATELEMSIZE_DEFAULT            0.00

#define FEM_glSetFlatElemSize_C( new_size )\
         g_flatelemsize = (DOUBLE)new_size;

#define FEM_glFlatElemSize_C( ) g_flatelemsize




/* ========================================================================= */
/* === Variable: g_tetexpand                                                 */
/* === Description: Used to size internal elements in a tet mesh based on    */
/* ===              the size of the elements on the volume's boundary.       */
/* ===              g_tetexpand is the expansion or contraction factor.  For */
/* ===              example, if g_tetexpand == 2, a volume will allow a mesh */
/* ===              with elements that are approximately twice as large in   */
/* ===              the interior of the volume as they are on the boundary.  */
/* ===              If g_tetexpand is less than 1.0, a mesh with smaller     */
/* ===              elements on the interior of the volume will be allowed.  */
/* ===              g_tetexpand should be greater than 0.1 but less than     */
/* ===              3.0.  If g_tetexpand is greater than 2.0, mesher         */
/* ===              robustness may be affected.                              */
/* === Default: 1.0                                                          */
/* === Access: FEM_glTetExpand_C, FEM_glSetTetExpand_C, and                  */
/* ===         FEM_glSetTetExpand                                            */
/* === Used By: PLG tet mesher.                                              */
/* ========================================================================= */
extern DOUBLE g_tetexpand;

#define TETEXPAND_DEFAULT 1.0

#define FEM_glSetTetExpand_C( exp_fac )\
         g_tetexpand = (DOUBLE)exp_fac;

#define FEM_glTetExpand_C( ) g_tetexpand





/* ========================================================================= */
/* === Variable: g_quadsplit                                                 */
/* === Description: Specify whether poor quads in the mesh are to be split   */
/* ===              into triangles after meshing or refinement.  If !0, quads*/
/* ===              will be split.  If 0, quads will not be split.           */
/* === Access: FEM_glSplitQuads_C, FEM_glSetSplitQuads_C, and                */
/* ===         FEM_glSetSplitQuads.                                          */
/* === Default: 1                                                            */
/* === Used By: Mesh Refinement of quadrilaterals.                           */
/* ========================================================================= */
extern INT g_quadsplit;

#define SPLITQUADS_DEFAULT              1

#define FEM_glSetSplitQuads_C( split )\
         g_quadsplit = (INT)split;

#define FEM_glSplitQuads_C( ) g_quadsplit




/* ========================================================================= */
/* === Variable: g_meshersmooth                                              */
/* === Description: Specify whether smoothing should be performed during     */
/* ===              meshing.                                                 */
/* === Access: FEM_glSmoothInMesher_C, FEM_glSetSmoothInMesher_C, and        */
/* ===         FEM_glSetSmoothInMesher.                                      */
/* === Default: 1                                                            */
/* === Used By: FEM_areamesh                                                 */
/* ========================================================================= */
extern INT g_meshersmooth;

#define SMOOTHINMESHER_DEFAULT  1

#define FEM_glSetSmoothInMesher_C( msmooth )\
         g_meshersmooth = (INT)msmooth;

#define FEM_glSmoothInMesher_C( ) g_meshersmooth





/* ========================================================================= */
/* === Variable: g_meshertopoclean                                           */
/* === Description: Specify whether topological cleanup should be performed  */
/* ===              during meshing.                                          */
/* === Access: FEM_glTopoCleanInMesher_C, FEM_glSetTopoCleanInMesher_C, and  */
/* ===         FEM_glSetTopoCleanInMesher.                                   */
/* === Default: 1                                                            */
/* === Used By: FEM_areamesh                                                 */
/* ========================================================================= */
extern INT g_meshertopoclean;

#define TOPOCLEANINMESHER_DEFAULT       1

#define FEM_glSetTopoCleanInMesher_C( clean )\
         g_meshertopoclean = (INT)clean;

#define FEM_glTopoCleanInMesher_C( ) g_meshertopoclean




/*============================================================================*/
/* === Macro: FEM_glSetVerify_C
 * === Author: mls
 * === Description: set the g_verify flag for debug output.
 * === Arguments:
 *     INT msmooth        1 if debug output is desired.
 *                        0 if debug output is not desired.
 * === Return: void
 */
#define FEM_glSetVerify_C( verify )\
         g_verify = (INT)verify;



/* ========================================================================= */
/* ========================================================================= */
/* ========================================================================= */
/* ========================================================================= */
/* ========================================================================= */
/* ========================================================================= */
/* === The global variables below here are for debugging and development === */
/* === experimentation ONLY.  These should not be used or altered in any === */
/* === way when implementing the ANSYS Mesh Toolkit into a 3rd party CAD === */
/* === Package.  USE AT YOUR OWN RISK!!!                                 === */
/* ========================================================================= */
/* ========================================================================= */
/* ========================================================================= */
/* ========================================================================= */
/* ========================================================================= */
/* ========================================================================= */
/* ========================================================================= */








/* ========================================================================= */
/* === Variable: g_maxlinearquadangle                                        */
/* === Description: In topological cleanup of linear quad meshes, swapping   */
/* ===              will not be performed if the resulting angle is greater  */
/* ===              than this angle in radians.                              */
/* === Default: 2.637599670076 radians                                       */
/* === Access: FEM_glMaxLinQuadAngle_C and FEM_glSetMaxLinQuadAngle_C        */
/* === Used By: Topological cleanup which is called from Paver, Quad         */
/* ===          Refinement.                                                  */
/* ========================================================================= */
extern DOUBLE g_maxlinearquadangle;

#define MAXLINQUADANGLE_DEFAULT         2.637599670076

#define FEM_glMaxLinQuadAngle_C( ) g_maxlinearquadangle

#define FEM_glSetMaxLinQuadAngle_C( max_angle )\
         g_maxlinearquadangle = (DOUBLE)max_angle;





/* ========================================================================= */
/* === Variable: g_maxquadquadangle                                          */
/* === Description: In topological cleanup of quadratic quad meshes, swapping*/
/* ===              will not be performed if the resulting angle is greater  */
/* ===              than this angle in radians.                              */
/* === Default: 2.637599670076 radians                                       */
/* === Access: FEM_glMaxQuadQuadAngle_C and FEM_glSetMaxQuadQuadAngle_C      */
/* === Used By: Topological cleanup which is called from Paver, Quad         */
/* ===          Refinement.                                                  */
/* ========================================================================= */
extern DOUBLE g_maxquadquadangle;

#define MAXQUADQUADANGLE_DEFAULT        2.637599670076

#define FEM_glMaxQuadQuadAngle_C( ) g_maxquadquadangle

#define FEM_glSetMaxQuadQuadAngle_C( max_angle )\
         g_maxquadquadangle = (DOUBLE)max_angle;





/* ========================================================================= */
/* === Variable: g_smoothtolconv                                             */
/* === Description: Specify the minimum distance that a node must be moved   */
/* ===              in smoother.  The minimum distance is g_smoothtolconv *  */
/* ===              the average edge length.                                 */
/* === Default: 0.05                                                         */
/* === Access: FEM_glSmoothConvTol_C and FEM_glSetSmoothConvTol_C            */
/* === Used By: Smoother called from the delauney mesher.                    */
/* ========================================================================= */
extern DOUBLE g_smoothtolconv;

#define SMOOTHCONVTOL_DEFAULT           0.05

#define FEM_glSmoothConvTol_C( ) g_smoothtolconv

#define FEM_glSetSmoothConvTol_C( new_tol )\
         g_smoothtolconv = (DOUBLE)new_tol;




/* ========================================================================= */
/* === Variable: g_cleanboundary                                             */
/* === Description: Specify whether topological cleanup should be performed  */
/* ===              specifically to improve the boundary.  Interior may get  */
/* ===              worse, but boundary will get better.                     */
/* === Access: FEM_glCleanBoundary_C and FEM_glSetCleanBoundary_C            */
/* === Default: 1                                                            */
/* === Used By: Mesh Refinement of quadrilaterals.                           */
/* ========================================================================= */
extern INT g_cleanboundary;

#define CLEANBOUNDARY_DEFAULT           1

#define FEM_glCleanBoundary_C( ) g_cleanboundary

#define FEM_glSetCleanBoundary_C( clean )\
         g_cleanboundary = (INT)clean;





/* ========================================================================= */
/* === Variable: g_hexrefinement                                             */
/* === Description: specify whether hex refinement can be done or not        */ 
/* === Access: FEM_glHexRefinement_C and FEM_glSetHexRefinement_C            */
/* === Default: 1                                                            */
/* === Used By: Mesh Refinement of quadrilaterals.                           */
/* ========================================================================= */
extern INT g_hexrefinement;

#define HEXREFINEMENT_DEFAULT           0

#define FEM_glHexRefinement_C( ) g_hexrefinement

#define FEM_glSetHexRefinement_C( hexref )\
         g_hexrefinement = (INT)hexref;





/* ========================================================================= */
/* === Variable: g_arealinesmoothing                                         */
/* === Description: Specify whether line smoothing should be performed on    */
/* ===              area meshes.                                             */
/* === Access: FEM_glSmoothAreaLines_C and FEM_glSetSmoothAreaLines_C        */
/* === Default: 0                                                            */
/* === Used By:                                                              */
/* ========================================================================= */
extern INT g_arealinesmoothing;

#define SMOOTHAREALINES_DEFAULT         0

#define FEM_glSmoothAreaLines_C( ) g_arealinesmoothing

#define FEM_glSetSmoothAreaLines_C( lsmooth )\
         g_arealinesmoothing = (INT)lsmooth;





/* ========================================================================= */
/* === Variable: g_maxcleanuploop                                            */
/* === Description: Specify the maximum number of iterations of cleanup can  */
/* ===              be performed.                                            */
/* === Access: FEM_glMaxCleanUpLoops_C and FEM_glSetMaxCleanUpLoops_C        */
/* === Default: 25                                                           */
/* === Used By: Topological cleanup which is called from quad refinement and */
/* ===          Paver.                                                       */
/* ========================================================================= */
extern INT g_maxcleanuploop;

#define MAXCLEANUPLOOPS_DEFAULT         25

#define FEM_glMaxCleanUpLoops_C( ) g_maxcleanuploop

#define FEM_glSetMaxCleanUpLoops_C( num_iter )\
         g_maxcleanuploop = (INT)num_iter;





/* ========================================================================= */
/* === Variable: g_surfproxstat                                              */
/* === Description: Specify what level of surface proximity is to be done    */
/* ===                 0:            no surface proximity is to be done      */
/* ===                 PROX_TOTAL:   surface proximity is done including     */
/* ===                               altering pre-existing shell elements    */
/* ===                 PROX_LIMITED: surface proximity is done but not on    */
/* ===                               pre-existing shell elements.            */
/* === Access: FEM_glSurfProxStatus_C and FEM_glSetSurfProxStatus_C          */
/* === Default: 1                                                            */
/* === Used By: Not used.                                                    */
/* ========================================================================= */
extern INT g_surfproxstat;

#define PROX_TOTAL   1
#define PROX_LIMITED 2
#define SURFPROXSTATUS_DEFAULT          1

#define FEM_glSurfProxStatus_C( ) g_surfproxstat;

#define FEM_glSetSurfProxStatus_C( status )\
         g_surfproxstat = (INT)status;





/* ========================================================================= */
/* === Variable: g_volumelinesmoothing                                       */
/* === Description: Specify whether line smoothing should be performed on    */
/* ===              volume meshes.                                           */
/* === Access: FEM_glVolumeLineSmooth_C and FEM_glVolumeSetLineSmooth_C      */
/* === Default: 0                                                            */
/* === Used By:                                                              */
/* ========================================================================= */
extern INT g_volumelinesmoothing;

#define SMOOTHVOLUMELINES_DEFAULT       0

#define FEM_glSmoothVolumeLines_C( ) g_volumelinesmoothing

#define FEM_glSetSmoothVolumeLines_C( lsmooth )\
         g_volumelinesmoothing = (INT)lsmooth;





/* ========================================================================= */
/* === Variable: g_pmethod                                                   */
/* === Description: Specify pmethod analysis will be done on the resulting   */
/* ===              mesh.                                                    */
/* === Access: FEM_glSetPMethod_C and FEM_glPMethod_C                        */
/* === Default: 0                                                            */
/* === Used By:                                                              */
/* ========================================================================= */
extern INT g_pmethod;

#define PMETHOD_DEFAULT                 0

#define FEM_glPMethod_C( ) g_pmethod

#define FEM_glSetPMethod_C( status )\
         g_pmethod = (INT)status;





/* ========================================================================= */
/* === Variable: g_linmaxspanangle                                           */
/* === Description: maximum spanning angle on curved surfaces (radians)      */
/* ===              for linear elements                                      */
/* === Access: FEM_glSetLinMaxSpanAngle_C and FEM_glLinMaxSpanAngle_C        */
/* === Default: PI/8    (22.5 degrees)                                       */
/* === Used By: FEM_bgmesh                                                   */
/* ========================================================================= */
extern DOUBLE g_linmaxspanangle;

#define LINMAXSPANANGLE_DEFAULT         0.392699081699

#define FEM_glSetLinMaxSpanAngle_C( maxang )\
           g_linmaxspanangle = (DOUBLE)maxang;

#define FEM_glLinMaxSpanAngle_C() (g_linmaxspanangle)





/* ========================================================================= */
/* === Variable: g_quadmaxspanangle                                          */
/* === Description: maximum spanning angle on curved surfaces (radians)      */
/* ===              for quadratic elements                                   */
/* === Access: FEM_glSetQuadMaxSpanAngle_C and FEM_glQuadMaxSpanAngle_C      */
/* === Default: PI/6  (30 degrees)                                           */
/* === Used By: FEM_bgmesh                                                   */
/* ========================================================================= */
extern DOUBLE g_quadmaxspanangle;

#define QUADMAXSPANANGLE_DEFAULT        0.523598775598

#define FEM_glSetQuadMaxSpanAngle_C( maxang )\
           g_quadmaxspanangle = (DOUBLE)maxang;

#define FEM_glQuadMaxSpanAngle_C() (g_quadmaxspanangle)





/* ========================================================================= */
/* === Variable: g_surfcurv                                                  */
/* === Description: flag - do sizing based on surface curvature              */
/* === Access: FEM_glSetSurfCurv_C and FEM_glSurfCurv_C                      */
/* === Default: 1                                                            */
/* === Used By:  FEM_bgmesh,FEM_advFront                                     */
/* ========================================================================= */
extern INT g_surfcurv;

#define SURFCURV_DEFAULT                1

#define FEM_glSetSurfCurv_C( surfcurv )\
           g_surfcurv = (INT)surfcurv;

#define FEM_glSurfCurv_C() (g_surfcurv)





/* ========================================================================= */
/* === Variable: g_smallholecoarsening                                       */
/* === Description: flag - do small hole coarsening for curved lines and     */
/*                  surfaces                                                 */
/* === Access: FEM_glSetSmallHoleCoarsening_C and FEM_glSmallHoleCoarsening_C*/
/* === Default: 1                                                            */
/* === Used By: FEM_bgmesh                                                   */
/* ========================================================================= */
extern INT g_smallholecoarsening;

#define SMALLHOLECOARSENING_DEFAULT     1

#define FEM_glSetSmallHoleCoarsening_C( shc )\
           g_smallholecoarsening = (INT)shc;

#define FEM_glSmallHoleCoarsening_C() (g_smallholecoarsening)





/* ========================================================================= */
/* === Variable: g_shcmaxangle                                               */
/* === Description: max angle for small hole coarsening                      */
/* === Access: FEM_glSetSHCMaxAngle_C and FEM_glSHCMaxAngle_C                */
/* === Default: PI/4  (45 degrees)                                           */
/* === Used By: FEM_bgmesh                                                   */
/* ========================================================================= */
extern DOUBLE g_shcmaxangle;

#define SHCMAXANGLE_DEFAULT             0.785398163398

#define FEM_glSetSHCMaxAngle_C( maxang )\
           g_shcmaxangle = (DOUBLE)maxang;

#define FEM_glSHCMaxAngle_C() (g_shcmaxangle)





/* ========================================================================= */
/* === Variable: g_shcminratio                                               */
/* === Description: small hole coarsening: min ratio between largest to      */
/* ===              smallest edge at which shc will take effect              */
/* === Access: FEM_glSetSHCMinRatio and FEM_glSHCMinRatio_C                  */
/* === Default: 5.0                                                          */
/* === Used By: FEM_bgmesh                                                   */
/* ========================================================================= */
extern DOUBLE g_shcminratio;

#define SHCMINRATIO_DEFAULT             5.0

#define FEM_glSetSHCMinRatio_C( minrat )\
           g_shcminratio = (DOUBLE)minrat;

#define FEM_glSHCMinRatio_C() (g_shcminratio)





/* ========================================================================= */
/* === Variable: g_shcmaxratio                                               */
/* === Description: small hole coarsening:  max ratio between largest to     */
/* ===              smallest edge that sizes will no longer be coarsened     */
/* === Access: FEM_glSetSHCMaxRatio and FEM_glSHCMaxRatio_C                  */
/* === Default: 35.0                                                         */
/* === Used By: FEM_bgmesh                                                   */
/* ========================================================================= */
extern DOUBLE g_shcmaxratio;

#define SHCMAXRATIO_DEFAULT             35.0

#define FEM_glSetSHCMaxRatio_C( maxrat )\
           g_shcmaxratio = (DOUBLE)maxrat;

#define FEM_glSHCMaxRatio_C() (g_shcmaxratio)





/* ========================================================================= */
/* === Variable: g_maxesize                                                  */
/* === Description: max allowable element size                               */
/* === Access: FEM_glSetMaxEsize_C and FEM_glMaxEsize_C                      */
/* === Default: 0.0  (no limit)                                              */
/* === Used By: FEM_bgmesh                                                   */
/* ========================================================================= */
extern DOUBLE g_maxesize;

#define MAXESIZE_DEFAULT                0.0

#define FEM_glSetMaxEsize_C( esize )\
           g_maxesize = (DOUBLE)esize;

#define FEM_glMaxEsize_C() (g_maxesize)





/* ========================================================================= */
/* === Variable: g_minesize                                                  */
/* === Description: min allowable element size                               */
/* === Access: FEM_glSetMinEsize_C and FEM_glMinEsize_C                      */
/* === Default: 0.0  (no limit)                                              */
/* === Used By: FEM_bgmesh                                                   */
/* ========================================================================= */
extern DOUBLE g_minesize;

#define MINESIZE_DEFAULT                0.0

#define FEM_glSetMinEsize_C( esize )\
           g_minesize = (DOUBLE)esize;

#define FEM_glMinEsize_C() (g_minesize)





/* ========================================================================= */
/* === Variable: g_quadfactor                                                */
/* === Description: Quad scale factor used in Smart Sizing - so that tris    */
/* ===              and quads will have a similar size specification         */
/* === Access: FEM_glSetQuadFactor_C and FEM_glQuadFactor_C                  */
/* === Default: 0.71                                                         */
/* === Used By: FEM_bgmesh                                                   */
/* ========================================================================= */
extern DOUBLE g_quadfactor;

#define QUADFACTOR_DEFAULT              0.71

#define FEM_glSetQuadFactor_C( factor )\
           g_quadfactor = (DOUBLE)factor;

#define FEM_glQuadFactor_C() (g_quadfactor)





/* ========================================================================= */
/* === Variable: g_numparmdiv                                                */
/* === Description: Number of parametric divisions - used as initial division*/
/* ===              for quadtree in back ground sizing                       */
/* === Access: FEM_glSetNumParmDiv_C and FEM_glNumParmDiv_C                  */
/* === Default: 10                                                           */
/* === Used By: FEM_bgmesh                                                   */
/* ========================================================================= */
extern INT g_numparmdiv;

#define NUMPARMDIVS_DEFAULT             10

#define FEM_glSetNumParmDiv_C( npdv )\
           g_numparmdiv = (INT)npdv;

#define FEM_glNumParmDiv_C() (g_numparmdiv)





/* ========================================================================= */
/* === Variable: g_largecurvcoarsening                                       */
/* === Description: flag - toggle large curvature coarsening for smart       */
/* ===              sizing - curvature on surfaces with high curvature will  */
/* ===              be limited, reducing the number of elements in high curv */
/* ===              regions (ie. cones)                                      */
/* === Access: FEM_glSetLargCurvCoarsening_C and FEM_glLargeCurvCoarsening_C */
/* === Default: 1                                                            */
/* === Used By: FEM_bgmesh                                                   */
/* ========================================================================= */
extern INT g_largecurvcoarsening;

#define LARGCURVCOARSENING_DEFAULT      1

#define FEM_glSetLargCurvCoarsening_C( lcc )\
           g_largecurvcoarsening = (INT)lcc;

#define FEM_glLargeCurvCoarsening_C() (g_largecurvcoarsening)





/* ========================================================================= */
/* === Variable: g_maxcurv                                                   */
/* === Description: greatest allowable curvature value (used only with       */
/* ===              g_largecurvcoarse)                                       */
/* === Access: FEM_glSetMaxCurv_C and FEM_glMaxCurv_C                        */
/* === Default: 100.0                                                        */
/* === Used By: FEM_bgmesh                                                   */
/* ========================================================================= */
extern DOUBLE g_maxcurv;

#define MAXCURV_DEFAULT                 100.0

#define FEM_glSetMaxCurv_C( maxcurv )\
           g_maxcurv = (DOUBLE)maxcurv;

#define FEM_glMaxCurv_C() (g_maxcurv)





/* ========================================================================= */
/* === Variable: g_esize                                                     */
/* === Description: user defined element size                                */
/* === Access: FEM_glSetEsize_C and FEM_glEsize_C                            */
/* === Default: 0.0 (none set)                                               */
/* === Used By: FEM_bgmesh                                                   */
/* ========================================================================= */
extern DOUBLE g_esize;

#define ESIZE_DEFAULT                   0.0

#define FEM_glSetEsize_C( esize )\
           g_esize = (DOUBLE)esize;

#define FEM_glEsize_C() (g_esize)





/* ========================================================================= */
/* === Variable: g_maxsmoothiter                                             */
/* === Description: max number of smoothing iterations in mesher             */
/* === Access: FEM_glSetMaxSmoothIter_C FEM_glMaxSmoothIter_C                */
/* === Default: 3                                                            */
/* === Used By: FEM_areamesh                                                 */
/* ========================================================================= */
extern INT g_maxsmoothiter;

#define MAXSMOOTHITER_DEFAULT           3

#define FEM_glSetMaxSmoothIter_C( niter )\
           g_maxsmoothiter = (INT)niter;

#define FEM_glMaxSmoothIter_C() (g_maxsmoothiter)





/* ========================================================================= */
/* === Variable: g_mintran                                                   */
/* === Description: min transition for element size in advancing front mesher*/
/* === Access: FEM_glSetMinTran_C FEM_glMinTran_C                            */
/* === Default: 0.55                                                         */
/* === Used By: FEM_advFront                                                 */
/* ========================================================================= */
extern DOUBLE g_mintran;

#define MINTRAN_DEFAULT                 0.55

#define FEM_glSetMinTran_C( tran )\
           g_mintran = (DOUBLE)tran;

#define FEM_glMinTran_C() (g_mintran)





/* ========================================================================= */
/* === Variable: g_searchradiusfactor                                        */
/* === Description: factor used to define search radius in advancing front   */
/* ===              mesher.  radius = factor * edgelen                       */
/* === Access: FEM_glSetSearchRadiusFactor_C FEM_glSearchRadiusFactor_C      */
/* === Default: 3                                                            */
/* === Used By: FEM_advFront                                                 */
/* ========================================================================= */
extern DOUBLE g_searchradiusfactor;

#define SEARCHRADIUSFACTOR_DEFAULT      0.8

#define FEM_glSetSearchRadiusFactor_C( factor )\
           g_searchradiusfactor = (DOUBLE)factor;

#define FEM_glSearchRadiusFactor_C() (g_searchradiusfactor)





/* ========================================================================= */
/* === Variable: g_smrt_mxitr                                                */
/* === Description: factor used to define search radius in advancing front   */
/* ===              mesher.  radius = factor * edgelen                       */
/* === Access: FEM_glSetSmrtMaxIter_C FEM_glSmrtMaxIter_C                    */
/* === Default: -4                                                           */
/* === Used By: FEM_areamesh                                                 */
/* ========================================================================= */
extern INT g_smrt_mxitr;

#define SMRTMAXITER_DEFAULT            -4

#define FEM_glSetSmrtMaxIter_C( smrt_mxitr )\
           g_smrt_mxitr = (INT)smrt_mxitr;

#define FEM_glSmrtMaxIter_C() (g_smrt_mxitr)


/* ========================================================================= */
/* === Variable: INT g_XOX                                                   */
/* === Description: XOX geometry database is being used                      */
/* === Access: FEM_glXOX_C                                                   */
/* === Default: 0                                                            */
/* === Used By: FEM_smooth                                                   */
/* ========================================================================= */
extern INT g_XOX;

#define XOX_DEFAULT         0

#define FEM_glSetXOX_C( xox )\
           g_XOX = (INT)xox;

#define FEM_glXOX_C() (g_XOX)


/* ========================================================================= */
/* === Variable: INT g_param_method                                          */
/* === Description: surface paramaterization method in use                   */
/* === Access: FEM_glParamMethod_C                                           */
/* === Default: 0                                                            */
/* === Used By: FEM_XOX etc..                                                */
/* ========================================================================= */
extern INT g_param_method;

#define PARAMMETHOD_DEFAULT         0

#define FEM_glSetParamMethod_C( pmeth )\
           g_param_method = (INT)pmeth;

#define FEM_glParamMethod_C() (g_param_method)

/* ========================================================================= */
/* === Variable: g_gratio                                                    */
/* === Description: growth ratio used in smrt sizing.                        */
/* ===              Values from 1.2 to 5.0 are allowed however               */
/* ===              Values from 1.5 to 2.0 are reccomend                     */
/* === Access: FEM_glSetGratio_C, FEM_glSetGratio, FEM_glGratio_C         */
/* === Default: 2.0                                                          */
/* === Used By: FEM_advFront                                                 */

extern DOUBLE g_gratio;

#define GRATIO_DEFAULT  2.0

#define FEM_glSetGratio_C( gratio )\
           g_gratio = (DOUBLE)gratio;

void FEM_glSetGratio( DOUBLE gratio );

#define FEM_glGratio_C() (g_gratio)


/* ========================================================================= */
/* === Variable: g_vsweepinterpmeth                                          */
/* === Description: Interpolation method to use in FEM_sweep.c.              */
/* ===              0 - Let algorithm decide.                                */
/* ===              1 - Use background mesh interpolation.                   */
/* ===              2 - Use linear interpolation.                            */
/* === Access: FEM_glSetVsweepInterpMeth_C, FEM_glVsweepInterpMeth_C         */
/* === Default: 0                                                            */
/* === Used By: FEM_sweep                                                    */

extern INT g_vsweepinterpmeth;

#define VSWEEPINTERPMETH_DEFAULT 0

#define FEM_glSetVsweepInterpMeth_C( method )\
           g_vsweepinterpmeth = (INT)(method);

#define FEM_glVsweepInterpMeth_C() (g_vsweepinterpmeth)


/* ========================================================================= */
/* === Variable: g_mapendangle                                               */
/* === Description:  An angle threshold for the Rieman space quad map mesher.*/
/* ===  Any angle less than this we be considered an "end."                  */
/* === Access: FEM_glSetMapEndAngle_C, FEM_glMapEndAngle_C                   */
/* === Default: 0                                                            */
/* === Used By: FEM_MapQuadMesh                                              */

extern DOUBLE g_mapendangle;

#define MAPENDANGLE_DEFAULT 135.0

#define FEM_glSetMapEndAngle_C( angle )\
           g_mapendangle = (DOUBLE)(angle);

#define FEM_glMapEndAngle_C() (g_mapendangle)


/* ========================================================================= */
/* === Variable: g_mapsideangle                                              */
/* === Description:  An angle threshold for the Rieman space quad map mesher.*/
/* ===  Any angle less than this we be considered an "side."                 */
/* === Access: FEM_glSetMapSideAngle_C, FEM_glMapSideAngle_C                 */
/* === Default: 0                                                            */
/* === Used By: FEM_MapQuadMesh                                              */

extern DOUBLE g_mapsideangle;

#define MAPSIDEANGLE_DEFAULT 225.0

#define FEM_glSetMapSideAngle_C( angle )\
           g_mapsideangle = (DOUBLE)(angle);

#define FEM_glMapSideAngle_C() (g_mapsideangle)


/* ========================================================================= */
/* === Variable: g_mapcornerangle                                            */
/* === Description:  An angle threshold for the Rieman space quad map mesher.*/
/* ===  Any angle less than this we be considered an "corner."               */
/* === Access: FEM_glSetMapCornerAngle_C, FEM_glMapCornerAngle_C             */
/* === Default: 0                                                            */
/* === Used By: FEM_MapQuadMesh                                              */

extern DOUBLE g_mapcornerangle;

#define MAPCORNERANGLE_DEFAULT 315.0

#define FEM_glSetMapCornerAngle_C( angle )\
           g_mapcornerangle = (DOUBLE)(angle);

#define FEM_glMapCornerAngle_C() (g_mapcornerangle)


/* ========================================================================= */
/* === Variable: g_testextcompile                                            */
/* === Description: Flag saying if we are testing the C Meshing database     */
/* ===              for use outside of Ansys                                 */
/* === Access: FEM_glSetTestExtCompile, FEM_glTestExtCompile                 */
/* === Default: 0                                                            */
/* === Used By:                                                              */

extern INT g_testextcompile;

#define TESTEXTCOMPILE_DEFAULT 0

#define FEM_glSetTestExtCompile_C( value )\
           g_testextcompile = (INT)(value);

#define FEM_glTestExtCompile_C() (g_testextcompile)


/* ========================================================================= */
/* === Variable: g_mapmesher                                                 */
/* === Description: Flag saying which map mesher to use.                     */
/* === Access: FEM_glSetMapMesher_C, FEM_glMapMesher_C                       */
/* === Default: TRY_BOTH_MAP_MESHER                                          */
/* === Used By:                                                              */

extern INT g_mapmesher;

#define TRY_BOTH_MAP_MESHERS 0
#define SWEEPING_MAP_MESHER  1
#define FORTRAN_MAP_MESHER   2

#define FEM_glSetMapMesher_C( value )\
           g_mapmesher = (INT)(value);

#define FEM_glMapMesher_C() (g_mapmesher)



/* ========================================================================= */
/* === Variable: g_aesize                                                    */
/* === Description:  element size for interior of an area AESIZE command     */
/* === Access: FEM_glSetAesize_C, FEM_glAesize_C                             */
/* === Default: 0.0                                                          */
/* === Used By: FEM_bgmesh                                                   */

extern DOUBLE g_aesize;

#define AESIZE_DEFAULT 0.0

#define FEM_glSetAesize_C( aesize )\
           g_aesize = (DOUBLE)(aesize);

#define FEM_glAesize() (g_aesize)


/* ========================================================================= */
/* === Variable: g_preevaluateboundarynodes                            */
/* === Description:  preevaluate boundary nodes to speed up surface meshing process */
/* === Access: FEM_glSetPreEvaluateBoundaryNodes_C, FEM_glPreEvaluateBoundaryNodes_C  */
/* === Default: 0                                                          */

extern INT g_preevaluateboundarynodes;

#define PREEVALUATEBOUNDARYNODES_DEFAULT 0

#define FEM_glSetPreEvaluateBoundaryNodes_C( flag )\
           g_preevaluateboundarynodes = (INT)(flag);

#define FEM_glPreEvaluateBoundaryNodes_C() (g_preevaluateboundarynodes )

/* ========================================================================= */
/* === Variable: g_minsurfprojparamdot                            */
/* === Description:  min angle btwn facets for surf project param */
/* === Access: FEM_glSetMinSurfProjParamDot_C, FEM_glMinSurfProjParamDot_C  */
/* === Default: 0                                                          */

extern DOUBLE g_minsurfprojparamdot;

#define MINSURFPROJPARAMDOT_DEFAULT 0.017452406437283512819418978516316

#define FEM_glSetMinSurfProjParamDot_C( flag )\
           g_minsurfprojparamdot = (DOUBLE)(flag);

#define FEM_glMinSurfProjParamDot_C() (g_minsurfprojparamdot )


/* ========================================================================= */
/* === Variable: g_BoundingBoxProjectionMultiplier                            */
/* === Description:  multiplier to be used on bounding box of surface  for point projections */
/* === Access: FEM_glSetBoundingBoxProjectionMultiplier_C, FEM_glBoundingBoxProjectionMultiplier_C  */
/* === Default: 0                                                          */

extern DOUBLE g_BoundingBoxProjectionMultiplier;

#define BOUNDINGBOXPROJECTIONMULTIPLIER_DEFAULT 0.015

#define FEM_glSetBoundingBoxProjectionMultiplier_C( flag )\
           g_BoundingBoxProjectionMultiplier = (DOUBLE)(flag);

#define FEM_glBoundingBoxProjectionMultiplier_C() (g_BoundingBoxProjectionMultiplier )


/* ========================================================================= */
/* === Variable: g_bIsRefinementAdaptive                            */
/* === Description:  is refinement called b/c of adaptivity or something elses */
/* === Access: FEM_glSetIsRefinementAdaptive_C, FEM_glIsRefinementAdaptive_C  */
/* === Default: 0                                                          */

extern INT g_bIsRefinementAdaptive;

#define FEM_glSetIsRefinementAdaptive_C( flag )\
           g_bIsRefinementAdaptive = (INT)(flag);

#define FEM_glIsRefinementAdaptive_C() (g_bIsRefinementAdaptive )



/* ========================================================================= */
/* === Variable: g_bIsHexDominant                            */
/* === Description:  is mesher doing hex dominant meshing   */
/* === Access: FEM_glSetIsHexDominant_C, FEM_glIsHexDominant_C  */
/* === Default: 0                                                          */

extern INT g_bIsHexDominant;

#define FEM_glSetIsHexDominant_C( flag )\
           g_bIsHexDominant = (INT)(flag);

#define FEM_glIsHexDominant_C() (g_bIsHexDominant )



/* ========================================================================= */
/* === Variable: g_previewsurfacemesh                            */
/* === Description:  is mesher previewing surface mesh  */
/* === Access: FEM_glSetPreviewSurfaceMesh_C, FEM_glPreviewSurfaceMesh_C  */
/* === Default: 0                                                          */
#define NOT_PREVIEWING 0
#define PREVIEWSURFACEMESH 1
#define PREVIEWSRCTRG 2

extern INT g_previewsurfacemesh;

#define FEM_glSetPreviewSurfaceMesh_C( flag )\
           g_previewsurfacemesh = (INT)(flag);

#define FEM_glPreviewSurfaceMesh_C() (g_previewsurfacemesh )


/* ========================================================================= */
/* === Variable: g_bglobalesizeset                            */
/* === Description:  is mesher previewing surface mesh  */
/* === Access: FEM_glSetGlobalEsizeSet_C, FEM_glGlobalEsizeSet_C  */
/* === Default: 0                                                          */


extern INT g_bglobalesizeset;

#define FEM_glSetGlobalEsizeSet_C( flag )\
           g_bglobalesizeset = (FEM_BOOLEAN)(flag);

#define FEM_glGlobalEsizeSet_C() (g_bglobalesizeset )

#ifdef __cplusplus
}

#endif
#endif





