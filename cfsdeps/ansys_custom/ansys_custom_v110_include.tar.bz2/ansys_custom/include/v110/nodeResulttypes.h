/* sid 60.1 copy of nodeResulttypes.h last changed by jrb on 2006/05/31 17:50:38 */

#include "ansysdef.h"

/****************************************************************
 data-level structure for ANSYS nodal results
 ****************************************************************/
struct nodeResult_str {     /* Name of the structure                                             */
  resultDispData   *rdisp;  /* Pointer to the first calculated real displacement on this node    */
  resultDispData   *cdisp;  /* Pointer to the first calculated complex displacement on this node */
  resultForceData  *force;  /* Pointer to the first calculated force on this node                */
                            /* If either the disp or force pointer is NULL that means            */
                            /* this node has no result displacements or forces (or both)         */
};

#define nodeResultRealDispPtr(nresult)     (nresult->rdisp)
#define nodeResultCplxDispPtr(nresult)     (nresult->cdisp)
#define nodeResultForcePtr(nresult)        (nresult->force)

