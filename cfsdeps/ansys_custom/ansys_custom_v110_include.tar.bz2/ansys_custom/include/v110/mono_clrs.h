/* sid 60.1 copy of mono_clrs.h last changed by jtm on 2006/05/15 19:44:31 */
/*HFILE mono_clrs.h	<any keyword identifiers	gps,system
------------------------------------------------------------------------
------- Notice - This file contains ANSYS Confidential information --------
------------------------------------------------------------------------
*/
/* 
 * *** copyright(c) 2006 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */

/*------------------------------ Description ---------------------------
\Author:	Greg Sharpe
\Title:		Monochrone color resources
\Desc:		Alternate color resource set for monoChrome displays
\History:	94/08/02 - gps: Initial creation

\Function(s) 
 -Primary:	Define alternate color resources for monochrome displays
 -Secondary:	none
 -External:	none
 -Internal:	none
 -Static:	none
----------------------------------------------------------------------*/
#ifndef MONO_H
#  define MONO_H

/*------------------------------ Header files ------------------------*/

/*------------------------------ Dependencies ------------------------*/

/*----------------------- Static Macro Definitions -------------------*/

#define  NUM_MONO_COLORS 6

/*--------------------- Static TypeDefs/Structures -------------------*/

static char *mono_colors[NUM_MONO_COLORS] = 
{
"! Note and Warning dialog boxes (monochrome)      \n",
"Ansys-Main.Command*Note*Foreground:        #000000\n",
"Ansys-Main.Command*Note*Background:        #ffff00\n",
"! Error dialog boxes (monochrome)                 \n",
"Ansys-Main.Command*Error*Foreground:       #000000\n",
"Ansys-Main.Command*Error*Background:       #ffff00\n"
};

/*----------------------- Variable Definitions -----------------------*/

/*------------------------- Exported Functions -----------------------*/

/*------------------------- Internal Functions -----------------------*/


/*-------------------------- Static Functions ------------------------*/

/* Below is the endif for the whole file. */ 
#endif
/*---------------------------- End Of Module -------------------------*/


