/* sid 60.5 copy of ggi_ftoc.h last changed by gawang on 2006/08/01 18:05:21 */
#ifdef __cplusplus
extern "C" {
#endif

/***********************************************************************\
 *  Declare functions for Converting between Fortran and C strings     *
\***********************************************************************/

static void string_2_C_string(char *string, int string_length,
    char *c_string, int max_len, int *ierr) ;

static void string_2_F_string(char *c_string, char *string,
    int string_length, int *ierr) ;

/***********************************************************************\
 *  Declare libary wrapper functions 
\***********************************************************************/

void FMNAME (ggi_init_f,GGI_INIT_F) () ;

void FMNAME (ggi_finish_f,GGI_FINISH_F) () ;

void FMNAME (ggi_set_sepfact_f,GGI_SET_SEPFACT_F) 
            (REAL_GGI *SeparationFactor) ;

void FMNAME (ggi_set_frctol_f,GGI_SET_FRCTOL_F)
            (REAL_GGI FrcTolerance) ;

void FMNAME (ggi_set_treesearch_f,GGI_SET_TREESEARCH_F)
            (int TreeSearch) ;

void FMNAME (ggi_set_resolution_f,GGI_SET_RESOLUTION_F)
            (int *Resolution) ;

void FMNAME (ggi_set_intsectmethod_f,GGI_SET_INTSECTMETHOD_F)
            (int *IntsectMethod) ;

void FMNAME (ggi_get_ncs_f,GGI_GET_NCS_F) (int *ncs_out) ;

void FMNAME (ggi_get_ncsc_f,GGI_GET_NCSC_F) (int *ncsc_out) ;

void FMNAME (ggi_get_frctol_f,GGI_GET_FRCTOL_F) (REAL_GGI *FRCTOL_out) ;

void FMNAME (ggi_get_nggifc_f,GGI_GET_NGGIFC_F) (int *iside, int *nggifc_out) ;

void FMNAME (ggi_get_mesh_f,GGI_GET_MESH_F)
            (int *iside, int *NVxBcp, int *NSfcBcp, int *NVxPerFc, 
             int *KVxBcp_ptr, int *KGGIFcIP_ptr, int *KCsFc_ptr, 
             int *NCsFc_ptr, REAL_GGI *AreaIpFc_ptr, 
             REAL_GGI *AreaNod_ptr, int *ierr) ;

void FMNAME (ggi_get_csdat_f,GGI_GET_CSDAT_F)
            (int *CsNum_optr, REAL_GGI *CsFactor_optr, int *ierr) ;

void FMNAME (ggi_area_nod_f,GGI_AREA_NODE_F)
            (int *ISide_ptr, int *NVxBcp_ptr, int *NSfcBcp_ptr, 
             int *NVxPerFc_ptr, int *KVxBcp_ptr, REAL_GGI *AreaNod_ptr,
             int *ierr) ;

void FMNAME (ggi_get_nonovlp_f,GGI_GET_NONOVLP_F)
            (int *ISide_ptr, int *NVxBcp_ptr, int *NSfcBcp_ptr,
             int *NVxPerFc_ptr, int *KVxBcp_ptr,
             int *NonOvlp_ptr, int *nNonOvlp, int *ierr) ;

void FMNAME (ggi_interp_ip_f,GGI_INTERP_IP_F)
            (int *NVxBcpA_ptr, int *NSfcBcpA_ptr, int *NVxPerFcA_ptr,
             int *KVxBcpA_ptr, REAL_GGI *VarNodA_ptr,
                               int *NSfcBcpB_ptr, int *NVxPerFcB_ptr,
                                    REAL_GGI *VarIpB_ptr,  int *NCOMPT_ptr,
             int *ierr) ;

void FMNAME (ggi_interp_nod_f,GGI_INTERP_NOD_F)
            (int *Cons_Key,
             int *NVxBcpA_ptr, int *NSfcBcpA_ptr, int *NVxPerFcA_ptr,
             int *KVxBcpA_ptr, REAL_GGI *VarNodA_ptr,
             int *NVxBcpB_ptr, int *NSfcBcpB_ptr, int *NVxPerFcB_ptr,
             int *KVxBcpB_ptr, REAL_GGI *VarNodB_ptr, int *NCOMPT_ptr,
             int *ierr) ;

void FMNAME (ggi_setup_f, GGI_SETUP_F)
            (int *NVxBcpA_ptr, int *NSfcBcpA_ptr, int *NVxPerFcA_ptr,
             int *KVxBcpA_ptr, REAL_GGI *CrdVxBcpA_ptr,
             int *NVxBcpB_ptr, int *NSfcBcpB_ptr, int *NVxPerFcB_ptr,
             int *KVxBcpB_ptr, REAL_GGI *CrdVxBcpB_ptr, int *ierr) ;

/***********************************************************************\
 *      Declare wrapper functions for error handling                   *
\***********************************************************************/

void FMNAME(ggi_get_error_f, GGI_GET_ERROR_F) (STR_PSTR(errmsg) STR_PLEN(errmsg)) ;

void FMNAME(ggi_error_exit_f, GGI_ERROR_EXIT_F) () ;

void FMNAME(ggi_error_print_f, GGI_ERROR_PRINT_F) () ;

void FMNAME(ggi_error_f, GGI_ERROR_F) (STR_PSTR(errmsg) STR_PLEN(errmsg)) ;

void FMNAME(ggi_warning_f, GGI_WARNING_F) (STR_PSTR(errmsg) STR_PLEN(errmsg)) ;


#ifdef __cplusplus
}
#endif
