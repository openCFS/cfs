/* sid 60.5 copy of C_ItfAnsysModal.h last changed by ftheveno on 2006/06/15 14:38:42 */
/**
 * @file   Sx_HarmIndex.h
 * @author 
 * @date   Mon Nov 28 12:44:24 2005
 * 
 * @brief  
 * 
 * 
 */

#ifndef __SX_ITFANSYSMODAL_H__
#define __SX_ITFANSYSMODAL_H__ 1

#include "Sx_AnsysFast.h"
#include "C_HarmIndex.h"

/*********************************************************************************
 *! \class	C_ItfAnsysModal
 *  \brief	Class Ansys for VT Modal Analysis
 *  \author	Frederic Thevenon
 *  \date	2006
 *  \bug
 *  \warning
 *
 *  \version 1. :       Initial Revision ( Ansys 11.0)
 */

class C_ItfAnsysModal
  : public C_ItfHarmIndex<double>, public C_ItfAnsys
{
public :

  virtual int	GetDebugScope(void) { return E_SCOPE_ITFPARAMFAST;}  
  virtual const char *Version() const		{ return "0.1";}
  
  C_ItfAnsysModal( const string &nom = "", PAR *par = NULL);
  virtual ~C_ItfAnsysModal();
  
  virtual double HiToAngle( int NumHI);

  virtual int	InitSolver( int NbModesMax, C_VecPi<double> &Eval,
			    C_VSTRUCT<double> &Evec, double &Treshold);  

  virtual int	InitParam( int &Korder, int &Morder);

  virtual int MltMatVect( char IdMat, int order, C_VSTRUCT<double> &Q,
			  C_VSTRUCT<double> &AQ);
  
  virtual int MltMatVect( int HrmIndex, C_VSTRUCT<double> &Q,
			  C_VSTRUCT<double> &KQ, C_VSTRUCT<double> &MQ,
			  int UpdateLevel=1);

  virtual int GetProjOperators( double angle, C_VSTRUCT<double> &Q,
				C_VSTRUCT<double> &AQ,
				C_MatMSym<double> &QtKQ, C_MatMSym<double> &QtMQ);

  virtual int	GetUpdatedResults( int HrmIndex, int NbModes,
				   C_VecPi<double> &Eval,
				   C_VSTRUCT<double> &Evec);

  virtual int	SetUpdatedResults( int HrmIndex, int NbModes, 
				   C_VecPi<double> &Eval,
				   C_VSTRUCT<double> &Evec);

protected :
  
  T_m_ooc	*CreateMatrixFromFull( int idmat, char *matname);
  void		SetHrmIdx( int Hi);
  void		SetLdStep( int i);
  void		IncLdStep( void);

  // ===== Members

  T_mso			*_MatM0;	/**< Initial M matrix				*/
  C_VSTRUCT<double>	_Qnod;

  int		_NbModes;
  int		_HiInit;
  double	_AngleInit, _IncAngle;
  int		_NbPointsHi;  
  int		_InCore;
  bool		_FirstRes;

  T_m_ooc	*_HI_K0;
  T_m_ooc	*_HI_M0;
  T_m_ooc	*_HI_coef_K;
  T_m_ooc	*_HI_coef_M;
  T_m_ooc	*_HI_K0ct;
  T_m_ooc	*_HI_M0ct;

  VEC		*_Variation;
};

#endif /* __SX_ITFANSYSMODAL_H__ */

