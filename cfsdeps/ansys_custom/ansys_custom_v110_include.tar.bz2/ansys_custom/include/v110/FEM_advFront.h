/* sid 60.1 copy of FEM_advFront.h last changed by upd111 on 2005/07/21 19:39:02 */

/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 1999 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_advFront.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_advFront.h
 *  header file for FEM_advFront.c
 *
 */
#ifndef FEM_ADVFRONT_INCLUDE
#define FEM_ADVFRONT_INCLUDE

#ifdef __cplusplus
extern "C" {
#endif

/* === ERROR Message identifiers === */


                            /* ============================================== */
                            /* === FEM_trimesh: define a triangle mesh from a */
                            /* === set of node loops in 2D                    */
                            /* ============================================== */
INT FEM_advFront (
   MESH_OBJ obj_mesh,       /* (IN) initial boundary nodes and edges */
                            /* (OUT) the completed tri mesh */
   INT anum,                /* (IN) current area */
   INT numbound,            /* (IN) number of boundary nodes */
   INT aniso,               /* (IN) do anisotropic meshing */
   INT midnodes,            /* (IN) will we add midnodes   */
   INT highcurv,            /* (IN) high curvature flag   */
   INT debug  );            /* (IN) debug flag (1 = draw) */

                            /* ============================================== */
                            /* === FEM_adCleanUp: clean up memory and stuff   */
                            /* === after meshing                              */
                            /* ============================================== */
void FEM_adCleanUp( void );


void FEM_adSetAllowedToSplitBoundaryEdges( FEM_BOOLEAN bFlag );

#ifdef __cplusplus
}
#endif


#endif
