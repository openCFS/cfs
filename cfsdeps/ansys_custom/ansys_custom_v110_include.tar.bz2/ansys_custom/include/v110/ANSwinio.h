/* sid 60.1 copy of ANSwinio.h last changed by elp on 2006/08/31 14:55:21 */
// windows I/O data structures
typedef struct
{
    DWORD Bytes;
    OVERLAPPED Overlapped;
} WINIOCONTEXT;

typedef struct
{
    WINIOCONTEXT* IoContext;
    HANDLE      FileHandle;
} WINIOEVENT;

#define MAXIOUNITS 70
WINIOEVENT WinIoUnitsArray[MAXIOUNITS];
DWORD MaxIoBytes;
INT   MaxPipelineDepth;
