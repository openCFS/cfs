/* sid 60.3 copy of MOD_charger_mdb.h last changed by gdvenet on 2006/09/01 07:55:23 */
/* MOD_charger_mdb.h CADOE  */
/*
 * MOD_charger_mdb.h
 *
 * $Id$
 *   
 * HISTORY
 *   
 *   06/28/00 10:47 <       Brian Jantzen> Rel:ms8m1    SCCA:74542  Delta:81.3
 *   
 *   06/21/00 16:30 <       Brian Jantzen> Rel:ms8m1    SCCA:74307  Delta:81.2
 */

#ifndef __modchargermdbh__
#define __modchargermdbh__ 1

#ifndef __expmdbstructh__
#include "expmdb_struct.h"
#endif

/*#ifdef __cplusplus
extern "C" {
#endif*/

extern T_statut MOD_charger_mdb( CModeleBase *, string nom_fic, T_booleen );
extern T_statut MOD_charger_mdb_4 ( T_Modele * );
extern T_statut MOD_verifier_mdb( T_Modele *modele, const char *, T_booleen *van_existe, T_booleen *mdb_existe );
extern T_Modele * ADOM_open_modele ( const char *nom_fic, T_statut *ier, T_booleen *var_env_ok, T_booleen *van_existe );
extern T_Modele * ADOM_open_modele2 (T_statut * ier);

/*#ifdef __cplusplus
}
#endif*/

#endif
