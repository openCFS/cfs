/* sid 60.21 copy of INIS_Api.h last changed by rjayasee on 2006/08/01 18:37:13 */

/*
////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         copyright(c) 2006 SAS IP, Inc.  All rights reserved.             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: INIS_API.h $
// $Revision$ 7.0
// $Date$ October 04 2005
// $Author$ rjayasee
//
// Decription :
// Api for the Initial State Cache. Data is stored here/cached here before
// written/exported to the database or a file ....
//
// This is the single point/junction for writing and reading data.
//
////////////////////////////////////////////////////////////////////////////
*/

#include "ANS_StandardIncludes.h"

/* (1)----------------------------------------------------------------*/
#if defined(LOWERCASENOUNDER_SYS)

/*
 *   The pattern for these platforms is the lowercased version of the name
 */

#define INIS_SetData          inis_setdata
#define INIS_SetParam         inis_setparam
#define INIS_GetData          inis_getdata
#define INIS_DeleteData       inis_deletedata
#define INIS_WriteToFile      inis_writetofile
#define INIS_CDWrite          inis_cdwrite
#define INIS_ReadFromFile     inis_readfromfile
#define INIS_ListData         inis_listdata
#define INIS_GetInitialState  inis_getinitialstate
#define INIS_IsNewVersionUsed inis_isnewversionused
#define INIS_TriggerNewVersion inis_triggernewversion
#define INIS_TriggerWrite      inis_triggerwrite
#define INIS_IsWriteOn         inis_iswriteon
#define INIS_SetWrittenFlag    inis_setwrittenflag
#define INIS_ClearInMemDB     inis_clearinmemdb
#define INIS_DeleteCacheForCurProc inis_deletecacheforcurproc
#define INIS_StartMemoryManager     inis_startmemorymanager
#define INIS_ShutDownMemoryManager  inis_shutdownmemorymanager
#define INIS_StartMemForProc     inis_startmemforproc
#define INIS_EndMemForProc       inis_endmemforproc
#define INIS_InitializeDatabase  inis_initializedatabase
#define INIS_GetWriteCS          inis_getwritecs
#define INIS_SetWriteCS          inis_setwritecs
#define INIS_UpdISFILEWarnCount  inis_updisfilewarncount
#define INIS_GetISFILEWarnCount  inis_getisfilewarncount
#define INIS_DistributeGlobalVariables inis_distributeglobalvariables
#define INIS_MergeDistrIstFiles  inis_mergedistristfiles
#endif


/* (2)----------------------------------------------------------------*/
#if defined(UPPERCASENOUNDER_SYS)

/*
 *   The pattern for these platforms is the uppercased version of the name
 */

#define INIS_SetData          INIS_SETDATA
#define INIS_SetParam         INIS_SETPARAM
#define INIS_GetData          INIS_GETDATA
#define INIS_DeleteData       INIS_DELETEDATA
#define INIS_WriteToFile      INIS_WRITETOFILE
#define INIS_CDWrite          INIS_CDWRITE
#define INIS_ReadFromFile     INIS_READFROMFILE
#define INIS_ListData         INIS_LISTDATA
#define INIS_GetInitialState  INIS_GETINITIALSTATE
#define INIS_IsNewVersionUsed INIS_ISNEWVERSIONUSED
#define INIS_TriggerNewVersion INIS_TRIGGERNEWVERSION
#define INIS_TriggerWrite      INIS_TRIGGERWRITE
#define INIS_IsWriteOn         INIS_ISWRITEON
#define INIS_SetWrittenFlag    INIS_SETWRITTENFLAG
#define INIS_ClearInMemDB     INIS_CLEARINMEMDB
#define INIS_DeleteCacheForCurProc INIS_DELETECACHEFORCURPROC
#define INIS_StartMemoryManager     INIS_STARTMEMORYMANAGER
#define INIS_ShutDownMemoryManager  INIS_SHUTDOWNMEMORYMANAGER
#define INIS_StartMemForProc     INIS_STARTMEMFORPROC
#define INIS_EndMemForProc       INIS_ENDMEMFORPROC
#define INIS_InitializeDatabase  INIS_INITIALIZEDATABASE
#define INIS_GetWriteCS          INIS_GETWRITECS
#define INIS_SetWriteCS          INIS_SETWRITECS
#define INIS_UpdISFILEWarnCount  INIS_UPDISFILEWARNCOUNT
#define INIS_GetISFILEWarnCount  INIS_GETISFILEWARNCOUNT
#define INIS_DistributeGlobalVariables INIS_DISTRIBUTEGLOBALVARIABLES
#define INIS_MergeDistrIstFiles  INIS_MERGEDISTRISTFILES
#endif


/* (3)----------------------------------------------------------------*/
#if defined(LOWERCASEUNDER_SYS)

/*
 *   The pattern for these platforms is the lowercased version of the name 
 *   followed by an underscore
 */

#define INIS_SetData          inis_setdata_
#define INIS_SetParam         inis_setparam_
#define INIS_GetData          inis_getdata_
#define INIS_DeleteData       inis_deletedata_
#define INIS_WriteToFile      inis_writetofile_
#define INIS_CDWrite          inis_cdwrite_
#define INIS_ReadFromFile     inis_readfromfile_
#define INIS_ListData         inis_listdata_
#define INIS_GetInitialState  inis_getinitialstate_
#define INIS_IsNewVersionUsed inis_isnewversionused_
#define INIS_TriggerNewVersion inis_triggernewversion_
#define INIS_TriggerWrite      inis_triggerwrite_
#define INIS_IsWriteOn         inis_iswriteon_
#define INIS_SetWrittenFlag    inis_setwrittenflag_
#define INIS_ClearInMemDB     inis_clearinmemdb_
#define INIS_DeleteCacheForCurProc inis_deletecacheforcurproc_
#define INIS_StartMemoryManager     inis_startmemorymanager_
#define INIS_ShutDownMemoryManager  inis_shutdownmemorymanager_
#define INIS_StartMemForProc     inis_startmemforproc_
#define INIS_EndMemForProc       inis_endmemforproc_
#define INIS_InitializeDatabase  inis_initializedatabase_
#define INIS_GetWriteCS          inis_getwritecs_
#define INIS_SetWriteCS          inis_setwritecs_
#define INIS_UpdISFILEWarnCount  inis_updisfilewarncount_
#define INIS_GetISFILEWarnCount  inis_getisfilewarncount_
#define INIS_DistributeGlobalVariables inis_distributeglobalvariables_
#define INIS_MergeDistrIstFiles  inis_mergedistristfiles_

#endif


#ifdef __cplusplus
extern "C"
{
#endif


INT INIS_SetParam( FCHAR(oName), FCHAR(oVal), DOUBLE* pParamValue FCHARL(oName_len) FCHARL(oVal_len));
/*
//R Result
//R 0 if failure, 1 if success
//I oName
//- Parameter Name
//I pParamValue
//- Parameter Value
//- Set the Initial State Parameters
*/

FUNCTION INT INIS_GetWriteCS();
FUNCTION VOID INIS_SetWriteCS(INT*);
//- Gets the Current Coordinate System to be applied to future INIS commands
//- or the CS to which initial stress is written to.

INT INIS_SetData( INT* pElemId, 
                  INT* pIntPtInfo, 
                  INT* pNumIntPtInfo, 
                  DOUBLE* pData, 
                  INT* pDataSize ) ;
/*
//R Result
//R 0 if failure, 1 if success
//L pElemId
//- Element Id
//L pElemType
//- Element Type
//I pCSID
//- Coordinate System ID
//I pIntPtInfo
//- Integration Point Info.
//- pIntPtInfo[0] --- Integration Point
//- pIntPtInfo[1] --- Layer Index for Composite Sections
//- pIntPtInfo[2] --- Section Int Pt within a Layer
//I pData
//- Data to be written
//I pDataSize
//- Size of the Data
//I iDataType
//- DataType
//- Set the Initial State of the Data
*/

INT INIS_DeleteData( INT* pElem, INT* pCSID,
                     INT* pIntPtInfo, INT* pNumIntPtInfo ) ;
/*
//R Result
//R 0 if failure, 1 if success
//L pElem
//- Element Id
//I pCSID
//- Coordinate System ID
//I pIntPtInfo
//- Integration Point Info.
//- pIntPtInfo[0] --- Integration Point
//- pIntPtInfo[1] --- Layer Index for Composite Sections
//- pIntPtInfo[2] --- Section Int Pt within a Layer
//I pData
//- Data to be written
//I pDataSize
//- Size of the Data
//I iDataType
//- DataType
//- Delete or Set to Zero the initial state of the element
*/

INT INIS_GetData( INT* pElem, INT* pCSID,
                  INT* pIntPtInfo, INT* pNumIntPtInfo, 
                  DOUBLE* pData, INT* pDataSize ) ;
/*
//R Result
//R 0 if failure, 1 if success
//L pElem
//- Element Id
//I pCSID
//- Coordinate System ID
//I pIntPtInfo
//- Integration Point Info.
//- pIntPtInfo[0] --- Integration Point
//- pIntPtInfo[1] --- Layer Index for Composite Sections
//- pIntPtInfo[2] --- Section Int Pt within a Layer
//I pData
//- Data to be written
//O pDataSize
//- Size of the Data
//O iDataType
//- DataType
//- Get the Initial State of the Data
*/

INT INIS_ListData( INT* pElemId );
/*
//R Result
//I pElemId
//- Element Id
//- Printing Initial State Data
*/

INT INIS_WriteToFile( INT* iSelFlag, INT* pDataTypes, INT* pNumDataTypes ) ;
/*
//R
//I iSelFlag
//-
//I pDataType
//- Data Type to be written to file
//I pNumDataType
//- Num Data Types provided
//- Writes All Initial State Information to a file
*/

FUNCTION INT INIS_ReadFromFile( char* pFileName FCHARL(pFileName_len)  ) ;
//R INT
//R 0 if failure
//I pFileName
//I IST File Name
//- Reads initial stress data from a file

FUNCTION INT INIS_CDWrite(INT* pUnit, INT* iElemId) ;
//R INT
//I pUnit
//- Fortran Unit to write the cdb data to
//I iElemId
//I-Element Id
//- Code to generate cdb data for initial state

FUNCTION VOID INIS_InitializeDatabase();
/*
//- Initialized/Creates the initial structure
*/

INT INIS_LoadCacheFromDatabase(INT iElem, DOUBLE*pISData) ;
/*
//R Result
//I iElem
//- Element Id
//I pISData
//- Array to use to load up the cache
//- Loads Cache from Database
*/

INT INIS_GetInitialState( INT* pVar, INT* pCSID, INT* pElemId,
                          INT* pKLayer, INT* pKSect, INT* pIntPt,
                          INT* pMatId, DOUBLE* pDataVec, INT* pVecSize ) ;
/*
//R  1 if success,0 if failure
//I pVar
//- Variable Type
//I pCSID
//- Coordinate System Id
//I pElemId
//- Element Id
//I pKLayer
//- Layer Index
//I pKSect
//- Section Index
//I pIntPt
//- Integration Point
//I pDataVec
//- Data Vector
//I pVecSize
//- Vector Size
//- Returns the Initial State for an element
*/

INT INIS_IsNewVersionUsed();
//R- 1 if the new version of INIS is being used

VOID INIS_TriggerNewVersion( INT* pFlag );

VOID INIS_TriggerWrite( INT* pFlag );

INT INIS_IsWriteOn();
//R- 1 if the new version of INIS is being used

VOID INIS_SetWrittenFlag( INT* pFlag );
//R- Set the Flag indicating that ist file was written

INT INIS_GetElementTemplate( INT pElemType, struct INIS_ElementTemplate& oElemTempate  ) ;
//R
//I pElemType
//- Element Type
//I oElemTempate
//- Element Template
//- Returns the Element Template Info

SUBROUTINE INIS_DeleteCacheForCurProc() ;
//-  Deletes the Local Cache for the current processor

SUBROUTINE INIS_ClearInMemDB() ;
//-  Deletes the Local Database Memory for INIS Stress.
//-  For all Threads/Procs

SUBROUTINE INIS_StartMemoryManager();
SUBROUTINE INIS_ShutDownMemoryManager() ;
SUBROUTINE INIS_StartMemForProc();
SUBROUTINE INIS_EndMemForProc() ;

SUBROUTINE INIS_UpdISFILEWarnCount();
FUNCTION INT  INIS_GetISFILEWarnCount();
//Sets and Update ISFILE Warning Count

SUBROUTINE INIS_DistributeGlobalVariables() ;
//Code to distribute global variables

SUBROUTINE INIS_MergeDistrIstFiles(char* pFileName FCHARL(pFileName_len)) ;
//R-Voild
//I pFileName
//I-FileName
//I pFileName_len
//I-Length of FileName
//- Code to Merge IST files for distr ansys solve

extern void cansMPI_ISendToAll(INT,INT*,INT*);

class ANS_TagMemManager;
extern ANS_TagMemManager** g_ppINISMemManager ;

//Memory Manager for Initial Stress
#ifdef __cplusplus
}
#endif

