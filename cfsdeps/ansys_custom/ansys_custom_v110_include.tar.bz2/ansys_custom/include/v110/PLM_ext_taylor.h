/* sid 60.1 copy of PLM_ext_taylor.h last changed by smarguer on 2006/02/09 09:13:00 */
/* PLM_ext_taylor.h CADOE  */
/*
 * PLM_ext_taylor.h
 *
 * $Id$
 *   
 * HISTORY
 *   
 *   06/28/00 10:47 <       Brian Jantzen> Rel:ms8m1    SCCA:74542  Delta:81.3
 *   
 *   06/21/00 16:30 <       Brian Jantzen> Rel:ms8m1    SCCA:74307  Delta:81.2
 */

#ifndef __plmexttaylorh__
#define __plmexttaylorh__ 1

#ifndef __expmdbstructh__
#include "expmdb_struct.h"
#endif

#ifndef __CADOE_H__
#include "cadoe.h"
#endif

#include "CCadoePortable.h"
#include "CDesignSet.h"

/*#ifdef __cplusplus
extern "C" {
#endif*/
extern VEC *PLM_extraire_SerieTaylor( CDesignSet, T_Modele *, int *, IVEC **, VEC *, T_statut * );
extern VEC *PLM_extraire_SerieTaylor_cs( VEC *, T_Modele *, int *, IVEC **, VEC *, T_statut *);
extern VEC *PLM_extraire_SerieTaylor_deltaCS( CDesignSet &, T_Modele *, IVEC **, VEC*, T_statut *);

/*#ifdef __cplusplus
}
#endif*/

#endif
