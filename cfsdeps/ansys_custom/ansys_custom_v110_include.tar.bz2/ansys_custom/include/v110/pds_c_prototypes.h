/* sid 60.2 copy of pds_c_prototypes.h last changed by dc on 2006/09/28 19:21:56 */
/* ---------------------------------------------------------------------- */
/* *** copyright(c) 2006 SAS IP, Inc.  All rights reserved.                                         */
/* *** ansys, inc.                                                        */
/* ---------------------------------------------------------------------- */

/*
 *    author/date: Stefan Reh  02-18-2000  
 *
 *    primary function:
 *
 *        header for prototype definitions in ANSI C
 *
 *    Notice - This file contains ANSYS Confidential information ***
 *
 */

#ifndef _PDS_C_PROTOTYPES_
#define _PDS_C_PROTOTYPES_

#include "rs_c_types.h"

/*for memory checking we need this*/
/*extern int  cAnsMemHandle    (void *Ptr);*/
/*extern int  cwansmemcheckall (char msg[]);*/


extern void     GetGauPar(int i, double *arg1, double *arg2);
extern void     GetTGauPar(int i, double *arg1, double *arg2, double *arg3, double *arg4);
extern void     GetLog1Par(int i, double *arg1, double *arg2);
extern void     GetLog2Par(int i, double *arg1, double *arg2);
extern void     GetTriPar(int i, double *arg1, double *arg2, double *arg3);
extern void     GetUniPar(int i, double *arg1, double *arg2);
extern void     GetWeiPar(int i, double *arg1, double *arg2, double *arg3);
extern void     GetExpPar(int i, double *arg1, double *arg2);
extern void     GetGamPar(int i, double *arg1, double *arg2);
extern void     GetBetaPar(int i, double *arg1, double *arg2, double *arg3, double *arg4);

/* from pds_wraper.c */
extern void     PDS_msg(char*, INT, INT, char*, double[], INT, char*, INT);
extern void     ProgressBarInit       ( INT, char*, INT );
extern void     ProgressBarUpdate     ( INT, char*, INT );
extern INT      ProgressBarCheckAbort (  );
extern void     ProgressBarFinish     ( INT );
extern void     *PDS_malloc(size_t, LONG, char*);
extern void     *SYS_malloc(size_t);
extern void     PDS_free(void*, LONG, char*);
extern void     SYS_free(void*);
extern void     **PDS_DoubleMatrixAlloc(INT, INT , LONG, char*);
extern INT      PDS_DoubleMatrixDealloc(double ***, INT, long INT, char* );
extern void     **PDS_IntMatrixAlloc   (INT, INT , LONG, char*);
extern INT      PDS_IntMatrixDealloc   (INT ***, INT, LONG, char* );
extern void     **PDS_CharMatrixAlloc  (INT, INT , LONG INT, char*);
extern INT      PDS_CharMatrixDealloc  (char ***, INT, LONG, char* );

extern INT      PDS_MatrixDealloc      (void ***, INT, LONG, char*);
extern void     PDS_CheckMemory        (LONG , char*);

/* from pds_debug.c */
extern void     debug_global(FILE *file, char *function_name);
extern void     debug_user_input(FILE *file, char *function_name);
extern void     debug_int_pointer(FILE *file, int format, int *ptr, int row, int col);
extern void     debug_dble_pointer(FILE *file, int format, double *ptr, int row, int col);

/* from pds_auxi.c */
extern void     GetInitialSeed            (int, long, long*);
extern void     GetDataStatistics         (int, double*, double*, double*, double*, double*, double*, double*);
extern int      CholeskiDecomposition     ( int, double**, double** );
extern double   CalculateRnkCorrCoef      ( int, double*, double* );
extern double   CalculateLinCorrCoef      ( int, double*, double* );
extern double   get_vector_norm2          (double*, int);
extern int      powerint                  (int, int);
extern int      pds_nint                  ( double );
extern int      pds_combin        ( int, int, int, int* );
extern void     pds_ksmallest     ( int, double[], int, double[]);
extern void     pds_klargest      ( int, double[], int, double[]);
extern int      c_fillab          ( char*, char*, char*, char* );
extern void     inttochar         ( INT* aa, char* bb, INT i);
extern INT      leftstrlen        ( char *cString );
extern void     c_chartoint       ( char*, INT*, INT);
extern int      GaussHermite              ( int, double[], double[] );
extern void     beta              ( double, double, double* );
extern int      betai             ( double, double, double, double* );
extern int      betacf            ( double, double, double, double* );
extern int      gammp             ( double, double, double* );
extern int      gcf               ( double*, double, double, double* );
extern int      gser              ( double*, double, double, double* );
extern void     gammln            ( double, double* );
extern double   bico              ( int, int );
extern double   factln            ( int );
extern void     RandomUniformLong ( long*, int, double* );
extern int      straightline_fit  ( double[], double[], int, double*, double*, double*, double*, double*, double*, double*);
extern int      gaussj            ( double[], int, double[], int );
extern void     covsrt            ( double[], int, int[], int);
extern void     QuickSort         ( int, double*, double* );
extern void     QuickRank         ( int, double*, int, double*);
extern double   CartesianDistance ( int , double*, double* );


/* from pds_pre.c */
extern void    PutMethodKey                ( int  );
extern void    GetMethodKey                ( int* );
extern void    GetMethodName               ( int, char*, char* );
extern int     CheckUserSamplingFile       ( char*, char*, int* );
extern void    put_user_sample_filename    ( char*, int);
extern int     CountLinesOfData            ( FILE*, int, int* );
extern int     ParamLineOfSamplingFile     ( FILE*, int, int, char *param_names[], int* );
extern int     DataLineOfSamplingFile      ( FILE*, int, int, int*, int*, int*, double*, int*, int* );
extern int     ReadOneLineFromSamplingFile ( FILE*, int, char*, int * );
extern int     ReadLineFromFile            ( FILE*, int, char* );
extern int     ReadParameterValuesFromFile ( FILE*, int, char *param_names[], int*, int*, int*, int*, double**, int*);


/* from pds_run.c */
extern int     write_mcs_dir_sample2file   ( char*, int, int, PDS_RvData*, int, int*, double**, int );
extern int     write_mcs_lhs_sample2file   ( char*, int, int, int, PDS_RvData*, int, int*, double**, int, int );
extern int     write_mcs_usr_sample2file   ( char*, int );
extern int     write_rsm_ccd_sample2file   ( char*, int, PDS_RvData*, int, int*, double** );
extern int     write_rsm_bbm_sample2file   ( char*, int, PDS_RvData*, int, int*, double** );
extern int     write_rsm_usr_sample2file   ( char*, int );
extern int     GenerateSampleFileHeader    ( char*, char* );
extern int     write_sample2file           ( char*, int, int*, int*, int*, int, int*, double**);
extern int     position_sample_file_pointer( char* );
extern void    FreeRvLoopSample            ( void );
extern int     GenerateResultsFileHeader   ( void );
extern int     GetNextLoopSettings         ( int, char*, int, char*, int*, int*, int*, int*, int*, int*, int*, int*, int*, int* );
extern int     CheckAutoStop               ( int, int, int* );


/* from pds_graphics.c */
extern INT      pl_rv_graph (INT, double*, double*, double*,
                             char*,   char*,
                             INT, double, double, double, double,
                             double,   double,
                             INT, double, INT, double );
extern INT      pl_cdf(INT, 
                       double[], double[], 
                       double[], double[], 
                       char*, char*,
                       INT, double[], double[],
                       INT, double[], double[],
                       double, double, double,
                       double, double,
                       double, double );
extern INT      pl_hist(INT, double[], double[], INT,
                        INT, double*, double*,
                        char*, char*,
                        double, double,
                        double, double,
                        double, double );
extern INT      pl_samp( INT, INT, INT,
                         INT, double*, INT,
                         char*, char*,
                         double, double, double,
                         double, double,
                         double, double );
extern INT      pl_sens( INT, double*, double*, char*, INT*,
                         char*, char*,
                         INT, INT,
                         INT, char*,
                         double );
extern INT      pl_scat( INT, INT, double*, double*, 
                         char*, char*, char*,
                         double, double,
                         INT, double*, double*,
                         double, double,
                         INT, INT, double*,
                         double, double );
extern INT      pl_resp_surf_3d ( char*, char*, char*, char*, 
                                  INT, INT, double*, double*, double*,
                                  INT,
                                  INT, double*, double*, double* );

/* from pds_methods.c */
extern int     generate_mcs_dir_samples       ( int, int, PDS_RvData*, int, int*, double**, int, long*, double**);
extern int     generate_mcs_lhs_samples       ( int, int, PDS_RvData*, int, int*, double**, int, int, long*, double**);
extern int     generate_rsm_ccd_samples       ( int, int, int*, PDS_RvData*, int, int*, double**, PDS_CCDLevels*, int, int**, double**);
extern int     generate_rsm_ccd_codedmatrix   ( int, int, int*, int, int, int, int, int**, double** );
extern void    FactorialDesignCharacteristics ( int, int*, int*, int* );
extern int     FactorialDesignMaxFraction     ( int, int, int* );
extern int     FactorialDesignDefiningEqs     ( int, int, int, int**);
extern int     generate_rsm_bbm_samples       ( int, int, int*, PDS_RvData*, int, int*, double**, PDS_BBMLevels*, double**);
extern int     generate_rsm_bbm_codedmatrix   ( int, int, int*, int, int, int, int, int, int, double** );
extern void    BoxBehnkenDesignCharacteristics( int, int*, int*, int*, int* );
extern int     GetMaxCCDSamples               ( int );
extern int     GetMaxBBMSamples               ( int );
extern int     GetMaxUSRSamples               ( void );

/* from pds_distribution.c */
extern int     dis_tgau_mean   ( double, double, double, double, double*);
extern void    dis_log2_mean   ( double, double, double*);
extern void    dis_tria_mean   ( double, double, double, double*);
extern void    dis_unif_mean   ( double, double, double*);
extern void    dis_weib_mean   ( double, double, double, double*);
extern void    dis_expo_mean   ( double, double, double*);
extern void    dis_gamm_mean   ( double, double, double*);
extern void    dis_beta_mean   ( double, double, double, double, double*);
extern int     dis_tgau_stdv   ( double, double, double, double, double*);
extern void    dis_log2_stdv   ( double, double, double*);
extern void    dis_tria_stdv   ( double, double, double, double*);
extern void    dis_unif_stdv   ( double, double, double*);
extern void    dis_weib_stdv   ( double, double, double, double*);
extern void    dis_expo_stdv   ( double, double, double*);
extern void    dis_gamm_stdv   ( double, double, double*);
extern void    dis_beta_stdv   ( double, double, double, double, double*);
extern void    dis_gaus_pdf    ( double, double, double, double*);
extern int     dis_tgau_pdf    ( double, double, double, double, double, double*);
extern void    dis_log1_pdf    ( double, double, double, double*);
extern void    dis_log2_pdf    ( double, double, double, double*);
extern void    dis_tria_pdf    ( double, double, double, double, double*);
extern void    dis_unif_pdf    ( double, double, double, double*);
extern void    dis_weib_pdf    ( double, double, double, double, double*);
extern void    dis_expo_pdf    ( double, double, double, double*);
extern void    dis_gamm_pdf    ( double, double, double, double*);
extern void    dis_beta_pdf    ( double, double, double, double, double, double*);
extern int     dis_gaus_inv    ( double, double, double, double*);
extern int     dis_tgau_inv    ( double, double, double, double, double, double*);
extern int     dis_log1_inv    ( double, double, double, double*);
extern int     dis_log2_inv    ( double, double, double, double*);
extern void    dis_tria_inv    ( double, double, double, double, double*);
extern void    dis_unif_inv    ( double, double, double, double*);
extern void    dis_weib_inv    ( double, double, double, double, double*);
extern void    dis_expo_inv    ( double, double, double, double*);
extern int     dis_gamm_inv    ( double, double, double, double*);
extern int     dis_beta_inv    ( double, double, double, double, double, double*);
extern int     dis_gaus_cdf    ( double, double, double, double*);
extern int     dis_tgau_cdf    ( double, double, double, double, double, double*);
extern int     dis_log1_cdf    ( double, double, double, double*);
extern int     dis_log2_cdf    ( double, double, double, double*);
extern void    dis_tria_cdf    ( double, double, double, double, double*);
extern void    dis_unif_cdf    ( double, double, double, double*);
extern void    dis_weib_cdf    ( double, double, double, double, double*);
extern void    dis_expo_cdf    ( double, double, double, double*);
extern int     dis_gamm_cdf    ( double, double, double, double*);
extern int     dis_beta_cdf    ( double, double, double, double, double, double*);
extern int     dis_stdn_cdf    ( double, double*);
extern int     dis_stdn_inv    ( double, double*);
extern void    dis_stdn_pdf    ( double, double*);
extern int     dis_chi2_inv    ( double, double, double* );
extern int     dis_fish_cdf    ( double, double, double, double* );
extern int     dis_fish_inv    ( double, double, double, double* );
extern int     dis_stud_cdf    ( double, double, double* );
extern int     dis_stud_inv    ( double, double, double* );
extern int     dis_arbitrary_mean ( int, int, double*, double*);
extern int     dis_arbitrary_stdv ( int, int, double*, double*);
extern int     dis_arbitrary_pdf  ( double, int , int, double*, double*);
extern int     dis_arbitrary_cdf  ( double, int , int, double*, double*);
extern int     dis_arbitrary_inv  ( double, int , int, double*, double*);

/* from pds_distribution.c */
extern int     get_rv_cdf      ( int, double, double*);
extern int     get_rv_inv      ( int, double, double*);
extern int     get_rv_pdf      ( int, double, double*);
extern int     get_rv_mean     ( int, double*);
extern int     get_rv_stdv     ( int, double*);
extern int     get_rv_min      ( int, double*);
extern int     get_rv_max      ( int, double*);

/* from pds_correlations.c */
extern int     process_correlations     ( int, PDS_RvData*, int, int*, double**, double**, double** );
extern int     BuildXXCorrelationMatrix ( int, PDS_CorrPair* , int, int*, double** );

/* from pds_transformation.c */
extern int     trans_p2u       ( int, double* );
extern int     trans_z2x       ( int, int, int, double*, double* );
extern void    trans_cv_u2z    ( int, int, int*, double**, double** );
extern int     trans_rank2u    ( int, double* );
extern int     trans_cc_x2z    ( int, int, double*, int, int, double*, double, double*);

/* from pds_post.c */
extern void    FreeAllPostCorrCoefs          ( void );
extern int     ConfidenceOfMean              ( double, double, int, double, double*, double* );
extern int     ConfidenceOfStdev             ( double, int, double, double*, double* );
extern int     GetAllSampleCDFwithConfidence ( int, double, double* );
extern int     GetAllSampleCDFnoConfidence   ( int, double* );
extern int     GetOneSampleCDFwithConfidence ( int, int, double, double* );
extern int     GetOneSampleCDFnoConfidence   ( int, int, double* );
extern int     GetOneSampleInverse           ( int, double, int*, int*, double*, double*, double* );
extern void    EvalHistogramRange            ( int, int, double, int, double, double*, double*, double* );
extern void    EvalHistogramBars             ( int, double*, int, int, double, double, double[], double[] );
extern int     EvalSampledCdfData            ( int, int, double[], double, double, double,
                                               double[], double[], double[], double[], int* );
extern int     TransSampledCdfData           ( int, int, int, 
                                               double[], double[], double[], double[], 
                                               double[], double[], double[], double[], 
                                               int*, double*, double*,
                                               int*, double*, double* );
extern int     GetSampledMEANData            ( int, double*, double, double*, int*, int* );
extern int     GetSampledSTDEVData           ( int, double*, double, double*, int*, int* );
extern int     GetSampledMINData             ( int, double*, double, double*, int*, int* );
extern int     GetSampledMAXData             ( int, double*, double, double*, int*, int* );
extern int     GetResultStartAddress         ( int, int, int, char*, double**, int* );
extern double  poly_fit                      ( double, int, double[], double[] );
extern double  expo_fit                      ( double, int, double[], double[] );
extern double  logn_fit                      ( double, int, double[], double[] );
extern double  log10_fit                     ( double, int, double[], double[] );
extern void    put_post_statistics_db        ( int, int, int, double, double, double, double, double, double );
extern int     GetDBPostStatistics           ( int, int, int, double*, double*, double*, double*, double*, double* );
extern int     GetDBPostCorrCoefs            ( int, int, int, int, int, double*, double* );
extern int     PutDBPostCorrCoefs            ( int, int, int, int, int, double, double );
extern int     ComputeOrRetrievePostCorrCoef ( int, int, int, int, int, int, int, double*, double*, double* );
extern int     correlation_significance      ( double, int, double, double*, int* );
extern int     GetSampledSensitivities       ( int, double*, int*, int*, int*, double*, double*, int*, double* );
extern int     CheckIfAnalysisDone           ( char* );

extern int     GetResultSetIdx               ( char*, char*, int* );
extern int     GetResultSetLastIdx           ( int, char*, int* );
extern void    PutResultSetLastIdx           ( int );
extern int     GetResultSetLabel             ( int, char* );
extern int     GetResultSetMethod            ( int, int* );

/* from pds_database.c */
extern void    OpenPDSystem          ( void );
extern int     GetOpenPdsDB          ( void );
extern void    PutOpenPdsDB          ( int );
extern void    InitialDefaultSettings( void );
extern void    InitialPreSettings    ( void );
extern void    InitialSoluSettings   ( void );
extern void    InitialPostSettings   ( void );
extern void    InitialDBSettings     ( void );

extern int     GetAnlFlag             ( void );

extern void    InitialRvData          ( int );
extern void    IncreaseRvDataMemory   ( void );
extern int     PutRvToDB              ( int, char*, double, int, double* );
extern void    DeleteRvFromDB         ( int );
extern int     GetNumRv               ( void );
extern void    GetRvDisPar            ( int, double* );
extern void    GetRvDisNumPar         ( int, int* );
extern void    GetRvDisName           ( int, char* );
extern void    GetDisName             ( int, char* );
extern int     GetDisType             ( char* );
extern void    FreeRvData             ( void );

extern int     GetParameterIndex      ( char*, char*, int, int*, int* );

extern void    InitialRpData          ( int );
extern void    IncreaseRpDataMemory   ( void );
extern void    PutRpToDB              ( int, char*, double );
extern int     GetNumRp               ( void );
extern void    DeleteRpFromDB         ( int );
extern void    FreeRpData             ( void );

extern void    InitialCorrPairs       ( int );
extern void    IncreaseCorrPairsMemory( void );
extern void    SetCorCoefInDB         ( int, int, double );
extern int     DeleteCorrPairFromDB   ( int, int );
extern int     GetCorrPairsCount      ( void );
extern int     GetCorrRvCount         ( void );
extern void    GetIndex2Correlated    ( int*, int*);
extern int     GetIsParameterCorrelated( int );
extern void    FreeCorrPairs          ( void );

extern void    InitialRvDoELevels     ( int );
extern void    PutRvDoELevels         ( int, int, int, int, int*, double* );
extern void    GetRvCCDValType        ( int, int* );
extern void    GetRvCCDLvlOpt         ( int, int* );
extern void    GetRvCCDLvlDefined     ( int, int* );
extern void    GetRvCCDLvlVals        ( int, double* );
extern void    GetRvBBMValType        ( int, int* );
extern void    GetRvBBMLvlOpt         ( int, int* );
extern void    GetRvBBMLvlDefined     ( int, int* );
extern void    GetRvBBMLvlVals        ( int, double* );
extern void    FreeRvDoELevels        ( void );


extern void    AnalysisFileStatus     ( void );
extern void    InputVariableStatus    ( void );
extern void    CorrelationStatus      ( void );
extern void    OutputVariableStatus   ( void );
extern void    AnalysisMethodStatus   ( void );
extern void    SolutionStatus         ( void );
extern void    RSSetStatus            ( void );

extern void    FreeAllDBData          ( void );
extern void    WriteHeader            ( FILE* );
extern void    WriteRvData            ( FILE* );
extern void    WriteRpData            ( FILE* );
extern void    WriteCorRvData         ( FILE* );
extern void    WriteRvDoELevels       ( FILE* );
extern void    WriteSoluSets          ( FILE* );
extern void    WriteResponseSurfaces  ( FILE* );
extern void    WriteUserSettings      ( FILE* );

extern int     ReadHeader             ( FILE*, char*, int* );
extern void    ReadRvData             ( FILE*, int );
extern void    ReadRpData             ( FILE* );
extern void    ReadCorRvData          ( FILE* );
extern void    ReadRvDoELevels        ( FILE*, int );
extern void    ReadSoluSets           ( FILE*, int );
extern void    ReadResponseSurfaces   ( FILE*, int );
extern void    ReadUserSettings       ( FILE*, int );



extern int     GetNumSoluSets          ( void );
extern void    PutNumSoluSets          ( int );
extern int     GetSoluSetIdx           ( char*, char*, int* );
extern int     GetSoluSetLastIdx       ( void );
extern void    PutSoluSetLastIdx       ( int );
extern int     GetSoluSetLabel         ( int, char* );
extern int     GetSoluSetMethod        ( int, int* );
extern int     GetSoluSetResultsFile   ( int, char* );
extern int     GetSoluSetCounters      ( int, int*, int*, int*, int*, int*, int*, int*, int*, int*, int* );
extern int     GetSoluSetSeeds         ( int, long*, long* );
extern int     GetSoluSetAutoStop      ( int, int* );
extern int     GetSoluSetAccMean       ( int, double* );
extern int     GetSoluSetAccStdev      ( int, double* );
extern int     GetSoluSetCheckFreq     ( int, int* );
extern void    PutSoluSet              ( int, char*, int, int, int, int, int, int, int, int, int, int);

extern int     GetDBResultsFileLoaded      ( int );
extern int     GetDBResultsFileNumSamples  ( int );
extern int     ReadResultsFileNumSamples   ( char*, int, int, int, int* );
extern int     ReadResultsFileData         ( char*, int, int, int, int,
                                             int*, int*, int*, int*, double*, double*);
extern int     LoadResultsFromFile2DB      ( int, int );

extern void    FreeResultsFileData         ( int );
extern void    FreeAllResultsFileData      ( void );
extern void    InitialResultsFileData      ( int, int, int, int );
extern void    InitialAllResultsFileData   ( void );

extern void    FreeSoluSetDoELevels        ( int );
extern void    FreeAllSoluSetDoELevels     ( void );
extern void    InitialSoluSetCCDLevels     ( int, int );
extern void    InitialSoluSetBBMLevels     ( int, int );
extern void    InitialAllSoluSetDoELevels  ( void );


/* from pds_responsesurfaces.c */
extern int     GetNumRSSets                ( void );
extern void    PutNumRSSets                ( int );
extern int     GetMaxRSInp                 ( void );
extern void    PutMaxRSInp                 ( int );
extern int     GetMaxRSOut                 ( void );
extern void    PutMaxRSOut                 ( int );
extern int     GetRSSetLabel               ( int, char* );
extern int     GetRSSetIdx                 ( char*, char*, int* );
extern int     GetRSSetLastIdx             ( void );
extern void    PutRSSetLastIdx             ( int );
extern int     GetRSSetNumRSOut            ( int );
extern int     GetRSSetIdx2Rp              ( int, int );
extern int     GetRSOutputIdx              ( int, int );
extern int     GetRSSetSoluIdx             ( int, int* );
extern int     GetRSSetRegMod              ( int, int, int* );
extern int     GetRSSetYTrans              ( int, int, int* );
extern int     GetRSSetYTrVal              ( int, int, double* );
extern int     GetRSSetXFilt               ( int, int, int* );
extern int     GetRSSetXFiltConf           ( int, int, double* );
extern int     GetRSSetYPower              ( int, int, double* );
extern int     GetRSSetNumTerms            ( int, int, int* );
extern int     GetRSSetTermType            ( int, int, int, int* );
extern int     GetRSSetTermRv1             ( int, int, int, int* );
extern int     GetRSSetTermRv2             ( int, int, int, int* );
extern int     GetRSSetTermCoef            ( int, int, int, double* );
extern int     GetRSSetScaleSlope          ( int, int, int, double* );
extern int     GetRSSetScaleIntercept      ( int, int, int, double* );


extern int     GetRSSetVIF                 ( int, int, int, double *);
extern int     GetRSSetHatMtxDiag          ( int, int, int, double *);
extern int     GetRSSetStudRes             ( int, int, int, double *);
extern int     GetRSSetStudDelRes          ( int, int, int, double *);
extern int     GetRSSetCooksDist           ( int, int, int, double *);
extern int     GetRSSetStudResError        ( int, int, int, int *);

extern int     GetRSSetSSE                 ( int, int, double* );
extern int     GetRSSetSSEadj              ( int, int, double* );
extern int     GetRSSetR2                  ( int, int, double* );
extern int     GetRSSetR2adj               ( int, int, double* );
extern int     GetRSSetConstVarStat        ( int, int, double* );
extern int     GetRSSetConstVarProb        ( int, int, double* );
extern int     GetRSSetConstVarMaxIdx      ( int, int, int* );
extern int     GetRSSetMaxStudRes          ( int, int, double *);
extern int     GetRSSetMaxStudDelRes       ( int, int, double *);
extern int     GetRSSetMaxStudDelResProb   ( int, int, double *);
extern int     GetRSSetMaxResAbs           ( int, int, double *);
extern int     GetRSSetMaxResRel           ( int, int, double *);
extern int     GetRSSetMaxCooksDist        ( int, int, double *);
extern int     GetRSSetMaxCooksProb        ( int, int, double *);


extern void    PutRSSetData                ( char*, int, int, int, 
                                             int, int, double, int, double, int, 
                                             double*, double*,
                                             double, int, int*, 
                                             double*, int, double*,
                                             double**,
                                             RS_RegCoefGOF*, int, RS_SampleGOF*, RS_ScalarGOF* );

extern void    FreeRSSet                   ( int, int );
extern void    FreeAllRSSets               ( void );
extern int     InitialRSSet                ( int, int, int, int);
extern int     InitialAllRSSets            ( int, int );

extern int     RegressionAnalysisForRSSet  ( char*, char*, int, char*,
                                             int, int, double**, double*, 
                                             int, char**,
                                             int, int, double, int, double, int, double,
                                             double*, double*,
                                             double*, int*, short*, double*, double* );
extern int     RegrBuildDesignMatrix       ( int, int, int, double**, short*, int, double*, double** );

extern int     RegrTransOutputVector       ( int, double, double, int, double*, double* );
extern int     RegrBackTransOutputVector   ( int, double, double, int, double*, double* );

extern int     EvalInputScaling            ( int, int, int, double**,
                                             double*, double* );
extern int     RegrScaleInputMatrix        ( int, int, double**, 
                                             double*, double*,
                                             double** );
extern int     RegrTransInputMatrix        ( int, int, int, double*, double**, double** );
extern int     EvalApprOutUsingDesignMtx   ( int, int, double**, double*, 
                                             int, double, double, 
                                             double* );
extern int     EvalApprOutUsingRegMod      ( int, int, double, int, 
                                             double*, double*,
                                             double, int, int, short*, double*, double*,
                                             int, int, double**,
                                             double* );
extern int     EvalMaxTerms                ( int, int );
extern int     ForwardStepwiseRegression   ( int, int, char**, int, double**, double*, double, int*, short*, double* );
extern int     EvalLinearRegrCoeffs        ( int, int, double**, double*, double * );
extern double  CalcRegrSSE                 ( int, double*, double* );
extern double  CalcRegrFisherF             ( double, double, int, int );
extern void    MultMatrixTransposeByVector ( double**, double*, int, int, double* );
extern void    MultMatrixByVector          ( double**, double*, int, int, double* );
extern void    MultTransposeOfMatrixByMatrix( double**, int, int, double** );
extern void    MultMatrixByMatrix          (double **, double **, 
                                            double **, int, int, int);


extern void    ForwardSubstitution         ( double**, double*, int, double* );
extern void    BackwardSubstitution        ( double**, double*, int, double* );
extern void    SwitchMatrixColumns         ( double**, int, int );
extern int     RegrBoxCoxOnInput ( char *cmd_text, char *SoluLab, int iActMeth, char *pname,
                                   int iNumInputs, int iNumSamples, double **dSampInpMtx, double *dSampOutVec,
                                   int iMaxTerms, char **cTermNames,
                                   int iRegMod, int iYTrans, double dYTrVal, int iXFilt, double dXFiltConf, int iXTrans, double dXTrAcc,
                                   double *dScaleSlopes, double *dScaleIntercepts,
                                   double *dYPower, int *iNumTerms, short *iTermSelect, double *dCoefs, double *dXPowers );


extern int    EvalModelParamCovariance(int, int, double, int,
                                       double *, double *, 
                                        double, int, 
                                        short *, double *,
                                        int, int, double **,
                                        double *, double *, double *, 
                                        double **);


extern int     EvalAndersonDarlingTest(int, double *, int, 
                                       double *, double *, double *);

extern int     EvalGoodnessOfFit        (char *, int, int, int, double **, double *, double *,
                                         int, int, double, int,
                                         double *, double *,
                                         double, int, int, short *, double *, double *,
                                         double **, double, double **, double, 
                                         RS_RegCoefGOF*, RS_SampleGOF*, RS_ScalarGOF* );

extern int     ModifiedLeveneTest( int, int, int, double **, double *, double *, double *,
                                   double *, int * );

extern int     EvalAbsoluteResidualDeviationFromMedian( int, int *, double *, double *,
                                                        double * );

extern int     EvalTwoSampleTstat( int, double *, int, double *, double *, double * );


extern int     EvalVarInfFactorsUsingRegrModel(int, int, double *,
                                               double *, int,  
                                               int, int, double **,
                                               short *, double *, double,
                                               double **, double *);


extern int     EvalHatMtxUsingRegrModel(int, int, double *,
                                        double *, double, int,  
                                        int, int, double **,
                                        short *, double *, double **, 
                                        double , double *);


extern int     EvalHatMtx              (double **, double **, double, 
                                        int, int, double *);


extern int     EvalStudResidAndCooksDist(double, double *,
                                         int, int, 
                                         RS_SampleGOF *);


extern int     PrintResponseSurface        ( char*, char*, char*, int, char*,
                                             int, char**,
                                             int, char**,
                                             int, int, double, int, double, int, 
                                             double*, double*,
                                             double, int, short*, double*, double*, 
                                             int, double*, double*,
                                             int, double,
                                             double**,
                                             RS_RegCoefGOF*, RS_SampleGOF*, RS_ScalarGOF* );



extern int     generate_samples_on_rs(int,int,int,int);
extern int     GetNumOfTerms(int, int);


extern int     FreeRSPostSamples           ( int );
extern int     FreeAllRSPostSamples        ( void );
extern int     InitialRSPostSamples        ( int, int, int, int );
extern int     InitialAllRSPostSamples     ( void );
extern int     AppendRSPostSamples         ( int, int, int, int*, int, double**, double** );
extern int     GetRSPostSampDone           ( int );
extern int     GetRSPostSampNumSamples     ( int );
extern int     GenerateRSPostSampFileHeader( char*, char*, int, int* );



#endif /* _PDS_C_PROTOTYPES_ */
