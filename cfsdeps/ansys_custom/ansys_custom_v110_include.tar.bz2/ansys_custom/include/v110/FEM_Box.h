/* sid 60.1 copy of FEM_Box.h last changed by upd111 on 2005/07/21 19:38:37 */
#ifndef FEM_BOX_H
#define FEM_BOX_H
#ifdef DSPACE_CMDB
#include "DSMemManager.h"
#endif

//struct DOUBLE;
//struct INT;

class CBBox
{
public:
    CBBox();
    ~CBBox() {};
    
    inline bool doBoxesOverLap( const CBBox & box ) const
    {
        if (box.m_adBox[0][0] > this->m_adBox[1][0]) return (false);
        if (box.m_adBox[1][0] < this->m_adBox[0][0]) return (false);
        if (box.m_adBox[0][1] > this->m_adBox[1][1]) return (false);
        if (box.m_adBox[1][1] < this->m_adBox[0][1]) return (false);
        if (box.m_adBox[0][2] > this->m_adBox[1][2]) return (false);
        if (box.m_adBox[1][2] < this->m_adBox[0][2]) return (false);
        return true;
    };
    
    inline bool isPointInBox( const DOUBLE xyz[3] ) const
    {
        if (xyz[0] > this->m_adBox[1][0]) return (false);
        if (xyz[0] < this->m_adBox[0][0]) return (false);

        if (xyz[1] > this->m_adBox[1][1]) return (false);
        if (xyz[1] < this->m_adBox[0][1]) return (false);

        if (xyz[2] > this->m_adBox[1][2]) return (false);
        if (xyz[2] < this->m_adBox[0][2]) return (false);
        return true;
    };
    
    void   getDoubleBox( DOUBLE box[2][3] ) const;
    DOUBLE getDiagonalDist2() const;
    
    CBBox & operator= (const CBBox &box);
    CBBox & operator= (const DOUBLE box[2][3]);
    bool operator==  (const CBBox &box) const;
    bool operator!=  (const CBBox &box) const;

    void expandBox      (const DOUBLE & dPercent);
    void expandBoxByDist(const DOUBLE & dDist);

    /* expand a box by a rate Independently -- each direction all by itself */
    int  expandBoxIndependently( const DOUBLE &dRate ); 

    bool doesChordGoThroughBox (const DOUBLE beginOfChord[3],
                                const DOUBLE endOfChord[3],
                                const DOUBLE vectorToEndOfChord[3],
                                DOUBLE & tval, bool bCheckEndPoints = true ) ;

    /* modify bounding box by a point */
    inline void boxCoord ( DOUBLE xyz[3])
    {
        INT j;
        DOUBLE * xb1, * xb2;
        const DOUBLE * x;

        x = xyz;
        xb1 = m_adBox[0];
        xb2 = m_adBox[1];

        for (j=0;j<3;j++,x++,xb1++,xb2++)
        {
            if (*x < *xb1) *xb1 = *x;
            if (*x > *xb2) *xb2 = *x;
        }
        m_bCenterValid = false;

    };

    /* find bounding box for a number of points */
    inline void boxCoords ( INT iNumberOfCoords, DOUBLE xyz[][3])
    {
        INT i,j;
        DOUBLE * xb1, * xb2;
        DOUBLE * x;

        for (i=0;i<iNumberOfCoords;i++)
        {
            x = xyz[i];
            xb1 = m_adBox[0];
            xb2 = m_adBox[1];

            for (j=0;j<3;j++,x++,xb1++,xb2++)
            {
                if (*x < *xb1) *xb1 = *x;
                if (*x > *xb2) *xb2 = *x;
            }
        }
        m_bCenterValid = false;
        
    };

#ifdef DSPACE_CMDB
     static CDSMemManager<CBBox> m_cMemManager;

#if defined(ux11) || defined(_WIN64)
	 inline void* operator new( size_t nSize )
#else
	 inline void* operator new( unsigned int nSize )
#endif
    {
        CBBox* pcT = m_cMemManager.getNextAvailablePointerToData(); 
        return pcT;
    }

    inline void operator delete( void* pcTVoid )
    {
        CBBox* pcT = (CBBox*)pcTVoid;
        m_cMemManager.returnPointerToDSMemManager( pcT );
    }
#endif

    inline void setGenericPointer( void * pgen ) { m_pgeneric = pgen; };

    inline void *getGenericPointer(){return m_pgeneric;};

    inline void getCenter( DOUBLE adCenter[3] ) 
    {
        int i;
        if ( !m_bCenterValid )
        {
            for ( i = 0; i < 3; i++ ) 
            {
                m_adCenter[i] = 0.5*(m_adBox[0][i] + m_adBox[1][i]);
            }
            m_bCenterValid = true;
        }

        for ( i = 0; i < 3; i++ ) 
        {
            adCenter[i] = m_adCenter[i];
        }


    }

private:
    DOUBLE m_adBox[2][3];
    DOUBLE m_adCenter[3];
    void   *m_pgeneric;
    bool   m_bCenterValid;
    
};

#endif

