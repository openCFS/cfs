/* sid 60.3 copy of FEM_prMesh.h last changed by upd111 on 2005/11/08 15:00:14 */

/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 1998 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_prMesh.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_prMesh.h
 *  header file for FEM_prMesh.c
 *
 */
#ifndef FEM_PRMESH_INCLUDE
#define FEM_PRMESH_INCLUDE

/*----------------- Globally accessible function prototypes -----------------*/

#ifdef __cplusplus
extern "C" {
#endif

                      /* =================================================== */
                      /* === FEM_prMeshSeamLines: See if an area has a       */
                      /* === seamline without a line.  If so, put edges and  */
                      /* === nodes along it in preparation to call the       */
                      /* === advancing front mesher.                         */
                      /* === Return: EXIT_SUCCESS or EXIT_FAILURE            */
                      /* =================================================== */
INT FEM_prMeshSeamLines(
   INT area_id,       /* (IN)  The area to check for seamlines.              */
   PERIODIC_TYPE periodic, /* (IN) whether a surface is periodic or not.     */
   INT *num_bnd_edges,/* (IN/OUT)  number of boundary edges on this area.    */
                      /*           This will be incremented appropriately if */
                      /*           seam lines exist since edges will be      */
                      /*           added to the seamline.                    */
   INT *numLoop,
   INT debug ,       /* (IN)  debug flag                                    */
   SEAM_DIR seamDir  ); /* (IN) seam direction */

                      /* =================================================== */
                      /* === FEM_prDuplicateLine: Duplicate nodes and edges  */
                      /* === on a line.                                      */
                      /* === Return: EXIT_SUCCESS or EXIT_FAILURE            */
                      /* =================================================== */
INT FEM_prDuplicateLine(
   SEAM_DIR uv_dir,             /* (IN) which direction, if any, this area   */
                                /*      is closed in.                        */
   DOUBLE min_param,            /* (IN) if uv_dir != NO_DIR, the min param   */
                                /*      in closed direction.                 */
   DOUBLE max_param,            /* (IN) if uv_dir != NO_DIR, the max param   */
                                /*      in closed direction.                 */
   FEM_BOOLEAN orientation,     /* (IN) orientation of newedges with respect */
                                /*      to area.                             */
   EDGE_OBJ obj_startedge,      /* (IN) the first edge on line to duplicate. */
   NODE_OBJ obj_startnode,      /* (IN) the first node on line to duplicate. */
   NODE_OBJ obj_startdblnode,   /* (IN) the duplicate of obj_startnode.      */
   NODE_OBJ obj_quitnode,       /* (IN) the last node on line to duplicate.  */
   NODE_OBJ obj_quitdblnode,    /* (IN) the duplicate of obj_quitnode.       */
   EDGE_OBJ *obj_lastseamedge,  /* (OUT) last edge on seamline to be          */
                                /*       duplicated. (adj to obj_quitnode)    */
   INT *num_bound );            /* (IN/OUT) number of edges on boundary.     */

                      /* =================================================== */
                      /* === FEM_prCreateDuplicateEndNodes: Create 2 new     */
                      /* === nodes, one at the start and one at the end of   */
                      /* === the seamline.  These new nodes area DOUBLEs of  */
                      /* === the nodes that start and end the seamline.      */
                      /* === They are duplicated, however, since the surface */
                      /* === needs to be unwrapped in uv space.              */
                      /* === Return: EXIT_SUCCESS or EXIT_FAILURE            */
                      /* =================================================== */
INT FEM_prCreateDuplicateEndNodes(
   NODE_OBJ obj_node1,          /* (IN)  first node to duplicate.            */ 
   NODE_OBJ obj_node2,          /* (IN)  second node to dupliate.            */
   SEAM_DIR uv_dir,             /* (IN)  which direction, if any, this area  */
                                /*       is closed in.                       */
   DOUBLE min_param,            /* (IN)  if uv_dir != NO_DIR, the min param  */
                                /*       in closed direction.                */
   DOUBLE max_param,            /* (IN)  if uv_dir != NO_DIR, the max param  */
                                /*       in closed direction.                */
   NODE_OBJ *obj_dblnode1,      /* (OUT) The duplicate of obj_node1.         */
   NODE_OBJ *obj_dblnode2 );    /* (OUT) The duplicate of obj_node2.         */

                      /* =================================================== */
                      /* === FEM_prCreateDuplicateEndEdges: Create 2 new     */
                      /* === edges, one at the start and one at the end of   */
                      /* === the seamline.  These new nodes area DOUBLEs of  */
                      /* === the edges that connect to the start and end the */
                      /* === seamline.  They are duplicated, however, since  */
                      /* === the surface needs to be unwrapped in uv space.  */
                      /* === Return: EXIT_SUCCESS or EXIT_FAILURE            */
                      /* =================================================== */
INT FEM_prCreateDuplicateEndEdges(
   NODE_OBJ obj_node1,    /* (IN)  node at start of seamline.                */
   NODE_OBJ obj_node2,    /* (IN)  node at end of seamline.                  */
   NODE_OBJ obj_dblnode1, /* (IN)  duplicate of obj_node1                    */
   NODE_OBJ obj_dblnode2, /* (IN)  duplicate of obj_node2                    */
   EDGE_OBJ obj_xedge1,   /* (IN)  edge adjacent to seamline at start.       */
   EDGE_OBJ obj_xedge2 ); /* (IN)  edge adjacent to seamline at end.         */

                      /* =================================================== */
                      /* === FEM_prHandle4EdgeNode: we found 4 edge nodes    */
                      /* === on the boundary of this model. This means we    */
                      /* === have the following:                             */
                      /* ===                                                 */
                      /* ===          \#####/       # = inside of area       */
                      /* ===           \###/                                 */
                      /* ===            \#/                                  */
                      /* ===             * obj_node                          */
                      /* ===            /#\                                  */
                      /* ===           /###\                                 */
                      /* ===          /#####\                                */
                      /* ===                                                 */
                      /* === We need to duplicate obj_node so that we have   */
                      /* === the following:                                  */
                      /* ===                                                 */
                      /* ===          \#####/       # = inside of area       */
                      /* ===           \###/                                 */
                      /* ===            \#/                                  */
                      /* ===             * duplicate of obj_node             */
                      /* ===                                                 */
                      /* ===             * obj_node                          */
                      /* ===            /#\                                  */
                      /* ===           /###\                                 */
                      /* ===          /#####\                                */
                      /* ===                                                 */
                      /* === Return: EXIT_SUCCESS or EXIT_FAILURE            */
                      /* =================================================== */
INT FEM_prHandle4EdgeNodes(
   INT area_id,              /* (IN)  The area to check for seamlines.       */
   NODE_OBJ *aobj_4edgenodes,/* (IN)  a list of obj_nodes for the figure     */
                             /*       above.                                 */
   INT num_4edgenodes,       /* (IN)  number of nodes in aobj_4edgenodes.    */
   INT numbound );           /* (IN)  The number of boundary edges.          */

INT FEM_shiftInParamSpace( 
	INT area_id, 
	DOUBLE *range, 
	SEAM_DIR seamDir,
	INT *numLoop,
	INT *numLoopEdges,
    INT *did ) ;

INT FEM_shiftBackInParamSpace(
   INT anum );

INT FEM_prUpdateAreaBndRec( 
	INT area_id,
	INT needRmOld,
	INT numBndEdges ) ;

INT FEM_prNodesTopOrBottom(
    INT anum,
    INT *piBottomTopChanged);

INT FEM_prReorderBnds( INT numbound );

INT FEM_prProcessSeam(
    INT anum, 
    INT *numbound,              /* (IN) total number of nodes on bdry           */
    PERIODIC_TYPE periodic,    /* (IN) Whether a surface is periodic or not.   */
    INT fg_debug,
    INT *piNumLoop);

INT FEM_prGetKpAreaAngle( INT anum, INT iKp, DOUBLE *angle );
INT FEM_amSetXyzByUv( INT  anum );

/* get all the edges on the external loop */
INT FEM_prGetExternalLoopEdges( 
   INT area_id, 
   EDGE_OBJ  *aobj_extEdges,
   INT *iNumExtEdges);
#ifdef __cplusplus
}
#endif


#endif

