/* sid 60.1 copy of MAT_CurveFitToAnsysExporter.h last changed by upd111 on 2006/10/09 19:56:54 */
////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         Copyright (C) 2001 ANSYS Inc.  All Rights Reserved             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MAT_CurveFitToAnsysExporter.h $
// $Revision$ 7.0
// $Date$ March 28 2002
// $Author$ rjayasee
//
// Decription :
// This is the Class that exports Curve Fitting Data to the Ansys 
// Database which is same as the TB commands.
////////////////////////////////////////////////////////////////////////////

#if !defined(MAT_CURVEFITTOANSYSEXPORTER_H)
#define MAT_CURVEFITTOANSYSEXPORTER_H

#include "AnsCmdCtoF.h"

#ifdef __cplusplus
extern "C"
{
#endif

INT MAT_WriteToAnsysDataBase( INT iMatId,
                              INT iExportMatId,
                              char* pConsFuncName ) ;
/*
//R INT
//R 1 if success and 0 if failure
//I iMatID
//I-Material ID to Export
//I iExportMaterialID
//I-Material ID in Ansys to Export To
//I pConsFuncName
//I-Name of the Constitutive Function To Export
//- This function exports curve fitting data to Ansys Database
*/

#ifdef __cplusplus
}
#endif

 
#ifdef __cplusplus
class MAT_CurveFitToAnsysExporter  
{
    public:

        static MAT_CurveFitToAnsysExporter* Instance() ;
        //R-MAT_CurveFitToAnsysExporter*
        //R-Pointer to the only Material API object
        //F-Static Constructor
        //F-Returns a pointer to the only existing MAT_CurveFitToAnsysExporter object

        bool WriteToDatabase( INT iMatId,
                              INT iExportMatId,
                              ANS_String const& pConsFuncName ) ;
        //R bool
        //I iMatID
        //I-Material ID to Export
        //I iExportMaterialID
        //I-Material ID in Ansys to Export To
        //I pConsFuncName
        //I-Name of the Constitutive Function To Export
        //- This function exports curve fitting data to Ansys Database

        bool WriteHyperElasticMaterialToDatabaseFormat
                                              ( INT iMatId,
                                                ANS_String const& pConsFuncName,
                                                DOUBLE*& pDatabaseArray,
                                                INT& iSizeOfArray ) ;
        //R bool
        //I iMatID
        //I-Material ID to Export
        //I iExportMaterialID
        //I-Material ID in Ansys to Export To
        //I pConsFuncName
        //I-Name of the Constitutive Function To Export
        //- This function exports curve fitting mooney data to Ansys Database


        bool WritePronyViscoHypoElasticToDatabaseFormat
                    ( INT iMatId,
                      ANS_String const& pConsFuncName ) ;
        //R bool
        //I iMatID
        //I-Material ID to Export
        //I iExportMaterialID
        //I-Material ID in Ansys to Export To
        //I pConsFuncName
        //I-Name of the Constitutive Function To Export
        //- This function exports curve fitting Prony
        //- data to Ansys Database

        bool WriteCreepToDatabaseFormat
                    ( INT iMatId,
                      ANS_String const& pConsFuncName ) ;
        //R bool
        //I iMatID
        //I-Material ID to Export
        //I iExportMaterialID
        //I-Material ID in Ansys to Export To
        //I pConsFuncName
        //I-Name of the Constitutive Function To Export
        //- This function exports curve fitting Creep
        //- data to Ansys Database

        ~MAT_CurveFitToAnsysExporter();
        // Destructor

    private:

        static MAT_CurveFitToAnsysExporter* m_pInstance ;
        // Singleton. Pointer for singleton implementation

   	    MAT_CurveFitToAnsysExporter();
        // Default constructor
};
#endif
/* End of Class */


#endif /* !defined(MAT_CURVEFITTOANSYSEXPORTER_H) */

