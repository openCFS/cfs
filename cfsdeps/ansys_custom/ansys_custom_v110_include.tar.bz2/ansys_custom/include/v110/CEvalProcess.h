/* sid 60.1 copy of CEvalProcess.h last changed by upd111 on 2006/10/09 19:57:46 */
/*! \file CEvalProcess.h

  \brief This header file defines the CEvalProcess class.

  \author Stephane MARGUERIN &copy; CADOE

  \date 20 April 2002

  \version $Id$
*/

#ifndef __CEvalProcess_h__ 
#define __CEvalProcess_h__ 1 

#include "cadoe_list.h"
#include "cadoe_map.h"
#include "cadoe_vector.h"
#include "cadoe_string.h"

#include "CEvalTool.h"
#include "CEvalResults.h"
#include "CEvalResultsField.h"
#include "CEvalCriterion.h"
#include "CDirection.h"

class CSolutionXplorer;

/*! \class CEvalProcess CEvalProcess.h
  \brief The CEvalProcess allows to evaluate a set of criteria along
  defined directions thru the parameterized results space. 
  
  \attention This class is defined as a pure virtual class. Because of
  this, it must be instanciated and delete only by using the methods
  CSolutionXplorer::new_EvalProcess() and 
  CSolutionXplorer::delete_EvalProcess().

  The first thing you need to do is to retrieve the list of the
  available criteria with getAvailableCriteria() and then select the
  ones you need to evaluate using addCriterion().
	You can also test directly a criterion availability by using the method
	getCriterionIfAvailable().

  Then you will select one or several evaluation directions for X, Y
  or both axis with selectDirection(). Set the options and finally
  evaluate the solution by calling evaluate() or evalContour() method.

  On the CEvalProcess side, the memory allocation is handled for you
  and everything is freed once you delete the evalProcess instance.

  See the CEvalResults documentation for detailed description of the
  returned results.

	\todo Add getTitle(), getXAxisLegend(), getYAxisLegend(), getResultName()

	\todo Add methods to manage the evaluation progression and abort.

	\todo Add an evalDiscrete() method to allow evaluation for a set of
	discrete values.
*/
class CEvalProcess : public CEvalTool
{
 public:

  //! Post-processing task type
  typedef enum {    
    PST_NONE=0,		/**< default value    */
    PST_POINT,		/**< current point, scalar criteria    */
    PST_CURVE,		/**< simple curve (X), scalar criteria   */ 
    PST_HANDBOOK,	/**< handbook ( X and Y), scalar criteria    */
    PST_SURFACE,	/**< surface (X and Y), scalara criteria    */
    PST_HISTOGRAM,	/**< histogram, scalar criteria    */
    PST_CONTOUR,	/**< contour results, field criteria   */ 
    PST_OPTIMIZATION,	/**< design optimization */
    PST_TOLERANCE,   	/**< tolerance analysis */
    PST_ADOMESH,	/**< adomesh only contour results */
    PST_SERIESEXPANSION /**< extract the series expansion itself  */
  } PostType;
  
  //! Graph axis
  typedef enum {
    AXIS_NONE=0,			/**< default value */
    AXIS_X,						/**< X axis */
    AXIS_Y						/**< Y axis */
  } Axis;
  
  typedef enum {
    GOA_NONE=0,
    GOA_MAXIMIZATION=1,
    GOA_MINIMIZATION=2
  } OptGoal;

  typedef enum {
    MTO_NONE=0,
    MTO_MONTECARLO=1,
    MTO_LAGRANGIAN=2,
    MTO_GLOBAL_LAGRANGIAN=3,
    MTO_NGAUSS=4,
    MTO_NUNIFORM=5
  } OptMethod;


  virtual ~CEvalProcess(){};

  virtual int getId(void) const =0;

  /*! \brief Returns a pointer on the parent CSolutionXplorer instance.
    \return CSolutionXplorer parent
  */
  virtual	CSolutionXplorer* getParentSolutionXplorer(void) const =0;

  /*! \brief Get informations about the available criteria in the current context 
    
    Depending on the context, criteria may be available or not: this is
    automatically handled by the CEvalProcess. The context is defined by
    the post-processing task you want to perform, the results contained
    in the database and the analsys nature.
  
    \return const reference on the internal list of available criteria
  */
  virtual const CCritInfo::CritInfoList& getCritInfoList( void ) const =0;
  virtual int getCritInfoVector( CCritInfo::CritInfoVector& vec ) const =0;

  /*! \brief Get a criterion by its code if it is available.
    
    Depending on the context, criteria may be available or not (see getAvailableCriteria()).
    In the case the criterion you are asking for is available.
	  
    \param code [in] code of the criterion you are asking for
    \param crit [in/out] unique criterion created, identified by its id (getId())
    \return true if the criterion is available
  */
  virtual bool getCriterionIfAvailable( CCritInfo::Code code, CCriterion &crit ) const =0;  
  /*! \brief Select a criterion to be evaluated. At selection, the criterion is given a
    unique id (see getId()) that you can use to retrieve results once the evaluation is done.
    \param crit [in] criterion to add
    \return execution status, 0 if success
  */
  virtual int selectCriterion( CCriterion &crit) =0;
  /*! \brief Deselect a criterion (remove it from the evaluation list)
    \param criterionId unique internal id
  */
  virtual void deselectCriterion( int critId ) =0;
  virtual void deselectCriterion( CCriterion &crit ) =0;

  /*! \brief Select an existing evaluation direction and assign it to the X or Y axis. Any
    modifications performed on this directions from the EvalProcess object will not affect
    the original direction hold by the SolutionXplorer.

    \param dirName direction name
    \param axis axis selected for this direction. This parameter is
    only significant when evaluating for handbooks or surfaces.
    \return internal direction id for future reference, or -1 if failed
  */
  virtual int selectDirection( CDirection* drt,  CEvalProcess::Axis axis=CEvalProcess::AXIS_X ) =0;
  /*! \brief Deselect an evaluation direction
    \param dirName direction name
  */
  virtual void deselectDirection( CDirection *drt ) =0;
  virtual CDirection* getDirection( const string &name ) const =0;

  /* deselect all criteria and directions */
  virtual void deselectAll( void ) =0;

  /*! \brief Activate or deactivate the normalization of the X axis.

    The normalization of an axis is used when several curves must be
    plotted on the same graph. When each curve represent a criterion
    depending on a different parameter, the values on the X axis are not
    compatible and graphical comparison is not possible. To avoid this
    situation, you can normalize this axis. Then, for each parameter,
    the reference value is considered as value 0 and the minimum and the
    maximum are respectively considered as -1 and +1.
    \param norm [in] true to activate normalization
  */
  virtual void normalizeParamX(  bool norm=true ) =0;
  /*! \brief Activate or deactivate the normalization of the Y axis.

    See normalizeParamX. For the same reason, when plotting handbook or
    surfaces, it could be interesting to normalize the Y axis.
    \param norm [in] true to activate normalization
  */
  virtual void normalizeParamY(  bool norm=true ) =0;
  /*! \brief Activate or deactivate the normalization of the results.

    The normalization produces relative values instead of absolute
    values for the evaluated criteria. The relative values are
    percentage of evolution of the criterion compared to its value at
    the reference point. The reference point is determined by the
    combination of the reference values assigned to each parameter,
    which is their initial value by default.
    \param norm [in] true to activate normalization
  */
  virtual void normalizeResults(  bool norm=true ) =0;

  /*! \brief Activate or deactivate the results accuracy evaluation.

    The CADOE technology is able to control the parameterization
    accuracy. If you activate this option, the SolutionXplorer will
    retrieve both the results and the corresponding accuracy for each
    evaluated point. This accuracy is an error percentage for a
    given value of the criterion.
    \param eval [in] true to activate accuracy evaluation
  */
  virtual void setEvaluateAccuracy(  bool eval=false ) = 0;


  /*! \brief sets the number of evaluation steps for X and Y
    axis.

    All the X directions are evaluated using the same number of
    steps. The same on Y axis. These number of steps may be modified
    internally because a minimal number steps could be necessary in
    specific situations. In the future, new evaluation methods will
    also need to modify these steps numbers.

    This settings are ignored when evaluating for single points and histograms.

    \param nbXSteps [in] number of steps for the X axis
    \param nbYSteps [in] number of steps for the Y axis
  */
  virtual void setNumberOfSteps(  int nbXSteps=0,  int nbYSteps=0 ) =0;
  virtual void setTessaletionError( double Error=0.01 ) =0;
  virtual void setTessaletionFlag( bool tesal=true ) =0;
  virtual double getTessaletionError( void ) =0;
  virtual void setGoal(OptGoal goal) =0;
  virtual void setGlobalAccuracy(double acc) =0;
  virtual void setMethOpt(OptMethod meth_opt) =0;
  virtual void setNbEval(int nb) =0;
  virtual void setPenalty(double ip,double mp,double pc) =0;
  virtual void setLineSearchStep(double lss) =0;

  /*! \brief Perform evaluations corresponding to the criteria and directions selected
    and return all the data in the CEvalResults passed in argument.

    This method handles all teh scalar criteria evaluations: use it for post processing
    type PST_POINT, PST_CURVE, PST_HISTOGRAM, PST_HANDBOOK and PST_SURFACE.
    For PST_CONTOUR, see the evalContour() method.

    <b>PST_POINT:</b> evaluates all the criteria at the current point of the
    parameterized space.

    The current point is defined by the reference value of each
    parameter. By default it is exactly the initial model because the
    default reference value of a parameter is its initial value.
    
    Even if this is a single-point evaluation, you need to create a
    direction to be able to modify the reference value of the
    parameters.

    <b>PST_CURVE:</b> evaluates the criteria for each X direction in order to
    plot curves.

    For each X direction, the criteria are evaluated in nbXSteps
    between the starValue and the endValue. The reference value is
    used for normalization.

    The CEvalResults returned contains several results, one for each y-line curve.

    <b>PST_HANDBOOK, PST_SURFACE:</b> evaluates the criteria for each Y and X direction in
    order to plot handbooks or surfaces.

    The goal is to evaluate a set of criteria when a parameter is
    varying on X, and this for a set of values of another parameter
    on Y. 

    The CEvalResults returned contains several results, one for each y-line curve.

    <b>PST_HISTOGRAM:</b> evaluates the criteria for each X direction in order to
    plot an histogram where the weight of each X direction is a bar of
    the histogram.

    For each X direction, the criteria are evaluated at the starValue,
    the refValue and the endValue. 

    For the simplest representation you can build, the height of the
    histogram bar would be the sum of the results for starValue and
    endValue. One classical application is to plot an histogram to
    compare the weight of each parameter on a given criterion. For
    this, you need to create one X direction for each parameter.

    The CEvalResults returned contains several results, one for each bar.

    \param res [in/out] results 
    \return 0 if success
  */
  virtual int evaluate( CEvalResults &res ) =0;

  virtual int evalDesignSet( CDesignSet &set ) =0;
  virtual int evalDesignSetList( list<CDesignSet> &lset ) =0;


  virtual int evalSurface( list<CDesignSet*> &lset, double accuracy=0.01, double dxMin=0.01, double dyMin=0.01 ) =0;

  virtual int evalCurve( CEvalResults &res) =0;

  /*! \brief Perform evaluations corresponding to the criteria selected along one single X direction
    and return all the data in the CEvalResultsField passed in argument.

    The CEvalResultsField returned contains several results, one for each design set.

    \param res [in/out] results 
    \return 0 if success
  */
  virtual int evalContour( CEvalResultsField &res ) =0;

  /*! \brief Perform evaluations corresponding to the criteria selected with a designSet 
    and return all the data in the CEvalResultsField passed in argument.

    \param set [in] designSet
    \param res [in/out] results 
    \return 0 if success
  */
  virtual int evalContour( CDesignSet &set, CEvalResultsField &res ) =0;
	
  /*! \brief Perform evaluations corresponding to the criteria selected with a list of designSets 
    and return all the data in the CEvalResultsField passed in argument.

    The CEvalResultsField returned contains several results, one for each design set.

    \param set [in] designSet
    \param res [in/out] results 
    \return 0 if success
  */
  virtual int evalContour( list<CDesignSet> &setList, CEvalResultsField &res ) =0;
	

  virtual int evalSampleMatrix(int numPoints, int numInputs, int numOutputs, double** ppdInputMatrix, double** ppdOutputMatrix) =0;
  virtual int dumpSeriesExpansion( string SeriesExpansionFilename, string DescriptionFilename, bool verbose=false ) = 0;
  virtual int writeMorphedMesh( FILE *fp, CEvalResultsField &res, int iRes, int criterionId, int Node=0 ) = 0;

  //! \brief debug display
  virtual void printDirections(void) const = 0;

  /*! \brief debug display
    \param fic opened file stream, stdout by default
    \param withLimit full display
  */
  virtual void printCriteria( const FILE *fic=stdout, const bool withLimit=false ) const =0;

  virtual void deleteSolutionVector(void) =0;

  virtual bool canNormalizeResults() =0;

  virtual void setAdocOption( const char *optionName, int value ) =0;
  virtual void setAdocOption( const char *optionName, double value ) =0;
  virtual void setAdocOption( const char *optionname, const char *optionValue ) =0;

  virtual int getNumberOfSelectedCriteria(void) =0;
  
 protected:
  CEvalProcess(){};
};


#endif
