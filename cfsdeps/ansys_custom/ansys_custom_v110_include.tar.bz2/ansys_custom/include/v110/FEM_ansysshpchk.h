/* sid 60.1 copy of FEM_ansysshpchk.h last changed by upd111 on 2005/07/21 19:39:10 */

/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 1999 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_ansysshpchk.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_ansysshpchk.h
 *  header file for the Ansys Shape Checking
 *
 */

#ifndef __ANSYS_SHAPE_CHECKING_H__
#define __ANSYS_SHAPE_CHECKING_H__

#if defined(EXTERNAL_COMPILE) || defined(EXTERNAL_LINK)
# include "FEM_cdbtypes.h"
#endif

#ifdef __cplusplus
#define FEM_CPP_EXTERN extern "C"
#else
#define FEM_CPP_EXTERN
#endif

                          /* =============================================== */
                          /* === SH_QUAL_ENUM: value returned from           */
                          /* === FEM_TestShapes that indicates whether the   */
                          /* === element passed or failed the quality checks.*/
                          /* =============================================== */
typedef enum { SH_WARNING_ELEM=0,/* At least one warning limit was violated. */
               SH_ERROR_ELEM=1,  /* At least one error limit was violated.   */
               SH_OK_ELEM=2,     /* No warning or error limits were violated.*/
               SH_NOT_TESTED=3   /* This particular test was not performed   */
                                 /* on this element.                         */
             } SH_QUAL_ENUM;




                          /* =============================================== */
                          /* === SH_SHAPE_ENUM: value sent to shape checking */
                          /* === to signify the shape of the element being   */
                          /* === sent in to be checked.                      */
                          /* =============================================== */
typedef enum { SH_LIN_SHAPE=2,    /* line elements                           */
               SH_TRI_SHAPE=3,    /* triangle shaped elements. */
               SH_QUAD_SHAPE=4,   /* quad shaped elements.  (This includes   */
                                  /* quads that are degenerated into tris.   */
               SH_TET_SHAPE=5,    /* tet shaped elements. */
               SH_BRK_SHAPE=6     /* Brick shaped elements. (This includes   */
                                  /* bricks that are degenerated into tets.  */
             } SH_SHAPE_ENUM;



                          /* =============================================== */
                          /* === SH_ELEM_TYPE_ENUM: value sent to            */
                          /* === FEM_ComputeShapes and FEM_TestShapes to     */
                          /* === specify what kind of element is being sent  */
                          /* === in to be checked.                           */
                          /* =============================================== */
typedef enum { SH_SHELL28, /* shear/twist panel.  This is the only shell     */
                           /* that gets tested for angle deviation.          */
                           /* This shell is tested for warp.                 */

               SH_SHELL41, /* 3-d stress shell without bending resistance,   */
                           /* needing extremely low warping limits.  Same as */
                           /* SH_SHELL63M.                                   */
                           /* This shell is tested for warp.                 */

               SH_SHELL43, /* 3-d stress shell with bending resistance and   */
                           /* high warping limits. Same as SH_SHELL181.      */
                           /* This shell is tested for warp.                 */

               SH_SHELL57, /* non-stress shell                               */
                           /* This shell is tested for warp.                 */

               SH_SHELL63, /* 3-d stress shell with bending resistance.      */
                           /* This shell is tested for warp.                 */
                           /* NOTE:  This is the best generic shell element. */
                           /*        Unless you know otherwise, use this     */
                           /*        value for any shell element.            */

               SH_SHELL63M,/* 3-d stress shell without bending resistance,   */
                           /* needing extremely low warping limits.  Same as */
                           /* SH_SHELL41.                                    */
                           /* This shell is tested for warp.                 */

               SH_SHELL91, /* 3-d stress shell with bending resistance. Same */
                           /* as SH_SHELL93 and SH_SHELL99.                  */
                           /* This shell is not tested for warp.             */

               SH_SHELL93, /* 3-d stress shell with bending resistance. Same */
                           /* as SH_SHELL91 and SH_SHELL99.                  */
                           /* This shell is not tested for warp.             */

               SH_SHELL99, /* 3-d stress shell with bending resistance. Same */
                           /* as SH_SHELL91 and SH_SHELL93.                  */
                           /* This shell is not tested for warp.             */

               SH_SHELL181,/* 3-d stress shell with bending resistance and   */
                           /* high warping limits. Same as SH_SHELL43.       */
                           /* This shell is tested for warp.                 */

               SH_SURFACE, /* 3-d quadrilateral or triangle not tested for   */
                           /* warp.  Used for elements without stiffness.    */

               SH_PLANAR,  /* 2-d planar quadrilateral or triangle.          */

               SH_SOLID    /* This element is a 3D solid element.  (Tet,     */
                           /* pyramid, wedge, or brick.)                     */
             } SH_ELEM_TYPE_ENUM;


                          /* =============================================== */
                          /* === TEST_RESULT_TYP: The structure that is      */
                          /* === returned from FEM_TestShapes containing     */
                          /* === info about how an element performed in a    */
                          /* === particular test.                            */
                          /* =============================================== */
typedef struct {
   SH_QUAL_ENUM status;
   INT error_id;
   DOUBLE limit;
   DOUBLE act_value;
} TEST_RESULT_TYP;


                          /* =============================================== */
                          /* === FEM_ComputeShapes: Given a single element,  */
                          /* === (either tri, quad, tet, or brick) run       */
                          /* === shape tests on it to determine its quality. */
                          /* === The results of the test are not compared    */
                          /* === against any warning/error limits.  Rather,  */
                          /* === the tests are performed, the results stored */
                          /* === in the output argument a_shpar, which can   */
                          /* === then be passed to FEM_TestShapes to do the  */
                          /* === comparison against the warning/error limits.*/
                          /* ===                                             */
                          /* === NOTE: aspect_ratio, qdbrk_parallel,         */
                          /* ===       max_angle, angle_dev, warp,           */
                          /* ===       jacob_ratio specify if a particular   */
                          /* ===       kind of test should be performed on   */
                          /* ===       the element.  If you specify a test   */
                          /* ===       to be performed on an element but,    */
                          /* ===       it does not make sense to perform     */
                          /* ===       it based on the type argument, the    */
                          /* ===       test will not be performed.  For      */
                          /* ===       example, if you specify type ==       */
                          /* ===       SH_SURFACE, but you set warp == TRUE, */
                          /* ===       the element will not be tested for    */
                          /* ===       warp since surface elements are not   */
                          /* ===       influenced by warp.                   */
                          /* ===                                             */
                          /* === RETURN: FEM_INT ( EXIT_SUCCESS or           */
                          /* ===                   EXIT_FAILURE)             */
                          /* =============================================== */
FEM_CPP_EXTERN FEM_INT FEM_ComputeShapes(
   SH_SHAPE_ENUM shape,   /* (IN)  The shape of the element to test.         */
   FEM_BOOLEAN quad_pelm, /* (IN)  TRUE if the element is quadratic or if it */
                          /*       is a p-element.  Even the element has all */
                          /*       of its midnodes dropped, if it is         */
                          /*       quadratic, send in TRUE                   */
   FEM_BOOLEAN mphysics,  /* (IN)  TRUE if this element has fluid velocity   */
                          /*       or magnetic potential degrees of freedom. */
                          /*       If TRUE, this element is excluded from    */
                          /*       aspect ratio, quad parallel deviation,    */
                          /*       and maximum angle tests.                  */
   SH_ELEM_TYPE_ENUM type,/* (IN)  The type of element to test.              */
   FEM_DOUBLE thk_qshell, /* (IN)  if this element is a quadrilateral shell, */
                          /*       this is the thickness of the shell.  If   */
                          /*       this element is not a quadrilateral shell,*/
                          /*       or if the thickness is unavailable.       */
                          /*       (NOTE: warping factor calculations done   */
                          /*              without a supplied thickness may   */
                          /*              be unconservative.  Quad warping   */
                          /*              should be re-evaluated if the      */
                          /*              thickness is defined or changed    */
                          /*              later.)                            */
   FEM_DOUBLE a_xyz[],    /* (IN)  contains the Cartesian XYZ node locations */
                          /*       for this element, ordered the same as the */
                          /*       a_nodes array next. Repeated nodes (for   */
                          /*       degenerate elements) should have repeated */
                          /*       xyz values. Missing midnodes should have  */
                          /*       0.0 for the X coordinate.                 */
                          /*                                                 */
                          /*        a_xyz[0] = x location of a_nodes[0]      */
                          /*        a_xyz[1] = y location of a_nodes[0]      */
                          /*        a_xyz[2] = z location of a_nodes[0]      */
                          /*        a_xyz[3] = x location of a_nodes[1]      */
                          /*        a_xyz[4] = y location of a_nodes[1]      */
                          /*        a_xyz[5] = z location of a_nodes[1]      */
                          /*           etc.                                  */
                          /*                                                 */
   FEM_INT a_nodes[],     /* (IN)  defines the connectivity of the element.  */
                          /*       The actual integer values in "a_nodes"    */
                          /*       are irrelevant. What matters is which     */
                          /*       positions contain positive integers,      */
                          /*       which contain zeros (indicating missing   */
                          /*       nodes), and which positions contain       */
                          /*       duplicates (indicating collapsed element  */
                          /*       edges).                                   */
                          /*                                                 */
                          /*       examples:                                 */
                          /*                                                 */
                          /*                  for an ordinary 4-noded quad   */
                          /*                                                 */
                          /*         8*-------*1            a_nodes[0] = 8   */
                          /*          |       |             a_nodes[1] = 2   */
                          /*          |       |             a_nodes[2] = 3   */
                          /*         2*-------*3            a_nodes[3] = 1   */
                          /*                                                 */
                          /*                  for an ordinary 4-noded quad   */
                          /*                  degenerated into a triangle.   */
                          /*                                                 */
                          /*          *4                    a_nodes[0] = 8   */
                          /*          |\                    a_nodes[1] = 2   */
                          /*          | \                   a_nodes[2] = 4   */
                          /*         8*--*2                 a_nodes[3] = 4   */
                          /*                                                 */
                          /*                  for an ordinary 8-noded quad   */
                          /*              7                                  */
                          /*      15*-----*-----*45         a_nodes[0] = 15  */
                          /*        |           |           a_nodes[1] = 21  */
                          /*        |           |           a_nodes[2] = 13  */
                          /*      54*           *8          a_nodes[3] = 45  */
                          /*        |           |           a_nodes[4] = 54  */
                          /*        |           |           a_nodes[5] = 100 */
                          /*      21*-----*-----*13         a_nodes[6] = 8   */
                          /*             100                a_nodes[7] = 7   */
                          /*                                                 */
                          /*                  for an 8-noded quad with two   */
                          /*                  missing midside node.          */
                          /*              7                                  */
                          /*      15*-----*-----*45         a_nodes[0] = 15  */
                          /*        |           |           a_nodes[1] = 21  */
                          /*        |           |           a_nodes[2] = 13  */
                          /*      54*           |           a_nodes[3] = 45  */
                          /*        |           |           a_nodes[4] = 54  */
                          /*        |           |           a_nodes[5] = 0   */
                          /*      21*-----------*13         a_nodes[6] = 0   */
                          /*                                a_nodes[7] = 7   */
                          /*                                                 */
                          /*                  for an 8-noded quad degenerated*/
                          /*                  to a triangle.                 */
                          /*              7                                  */
                          /*           21*                  a_nodes[0] = 8   */
                          /*             |\                 a_nodes[1] = 7   */
                          /*             | \                a_nodes[2] = 21  */
                          /*           14*  *5              a_nodes[3] = 21  */
                          /*             |   \              a_nodes[4] = 101 */
                          /*             |    \             a_nodes[5] = 5   */
                          /*            8*--*--*7           a_nodes[6] = 21  */
                          /*               101              a_nodes[7] = 14  */
                          /*                                                 */
                          /*                  for an oridinary 8-noded tet   */
                          /*                                                 */
                          /*         145*___                a_nodes[0] = 127 */
                          /*           / \  \___*333        a_nodes[1] = 130 */
                          /*          /   \      \____*76   a_nodes[2] = 76  */
                          /*         /     \455    ../      a_nodes[3] = 145 */
                          /*     121*       *   ../ /                        */
                          /*       /   500*..\./   * 437    midnodes         */
                          /*      /   .../    \   /                          */
                          /*     /.../         \ /          a_nodes[4] = 440 */
                          /* 127*-------*-------*130        a_nodes[5] = 437 */
                          /*           440                  a_nodes[6] = 500 */
                          /*                                a_nodes[7] = 121 */
                          /*                                a_nodes[8] = 455 */
                          /*                                a_nodes[9] = 333 */
                          /*                                                 */
                          /*                 for an oridinary 20-noded brick */
                          /*              14                                 */
                          /*        7*-----*-----*6         a_nodes[0] = 80  */
                          /*        /|          /|          a_nodes[1] = 1   */
                          /*       /           / |          a_nodes[2] = 2   */
                          /*    15*  |      13*  |          a_nodes[3] = 3   */
                          /*     /   *20     /   *19        a_nodes[4] = 4   */
                          /*    /  12|      /    |          a_nodes[5] = 5   */
                          /*  4*-----*-----*5    |          a_nodes[6] = 6   */
                          /*   |     |     |     |          a_nodes[7] = 7   */
                          /*   |    3*- - *|- - -*2         a_nodes[8] = 8   */
                          /*   |    /    10|    /           a_nodes[9] = 9   */
                          /* 16*           *17 /            a_nodes[10] = 10 */
                          /*   |  *11      |  *9            a_nodes[11] = 11 */
                          /*   |           | /              a_nodes[12] = 12 */
                          /*   |/          |/               a_nodes[13] = 13 */
                          /* 80*-----*-----*1               a_nodes[14] = 14 */
                          /*         8                      a_nodes[15] = 15 */
                          /*                                a_nodes[16] = 16 */
                          /*                                a_nodes[17] = 17 */
                          /*                                a_nodes[18] = 19 */
                          /*                                a_nodes[19] = 20 */
                          /*                                                 */
                          /*                 for a 20-noded brick degenerated*/
                          /*                 to a wedge.                     */
                          /*        11                                       */
                          /*  3*-----*-----*5               a_nodes[0] = 70  */
                          /*   |\         /|                a_nodes[1] = 1   */
                          /*   | \       / |                a_nodes[2] = 2   */
                          /*   |  *9  10*  |                a_nodes[3] = 2   */
                          /* 12*   \   /   *14              a_nodes[4] = 3   */
                          /*   |    \ /    |                a_nodes[5] = 4   */
                          /*   |     *4    |                a_nodes[6] = 5   */
                          /*   |     |     |                a_nodes[7] = 5   */
                          /* 70*- - -|*8- -*2               a_nodes[8] = 6   */
                          /*    \    |    /                 a_nodes[9] = 7   */
                          /*     \ 13*   /                  a_nodes[10] = 2  */
                          /*     6*  |  *7                  a_nodes[11] = 8  */
                          /*       \ | /                    a_nodes[12] = 9  */
                          /*        \|/                     a_nodes[13] = 10 */
                          /*         *                      a_nodes[14] = 5  */
                          /*         1                      a_nodes[15] = 11 */
                          /*                                a_nodes[16] = 12 */
                          /*                                a_nodes[17] = 13 */
                          /*                                a_nodes[18] = 14 */
                          /*                                a_nodes[19] = 14 */
                          /*                                                 */
   FEM_BOOLEAN asp_ratio, /* (IN)  TRUE if this element should be checked    */
                          /*       for aspect ratio.                         */
   FEM_BOOLEAN qdbrk_prll,/* (IN)  For quadrilaterals, check how far from    */
                          /*       parallel are opposite edges of the quad.  */
                          /*       For Bricks, wedges, and pryamids, checks  */
                          /*       deviation from parallel of opposite edges */
                          /*       on all quad faces and x-sections.         */
   FEM_BOOLEAN max_angle, /* (IN)  For triangles and quadrilaterals,         */
                          /*       calculate the maximum angle at any node.  */
                          /*       For bricks, wedges, pyrmaids, and tets,   */
                          /*       calculate the maximum angle on any face   */
                          /*       or x-section.                             */
   FEM_BOOLEAN angle_dev, /* (IN)  For SH_SHELL28, calculate the each corner */
                          /*       angles deviation from 90 degrees.  This   */
                          /*       flag is ignored unless type == SH_SHELL28 */
   FEM_BOOLEAN warp,      /* (IN)  FOR any of the SH_SHELLX elements that    */
                          /*       are degenerated into a triangle, check    */
                          /*       how close from planar the 4 nodes are.    */
   FEM_BOOLEAN jacob_rat, /* (IN)  calculate the jacobian ratio for this     */
                          /*       element.                                  */
   FEM_DOUBLE a_shpar[10]);/*(OUT) This array is filled with the results of  */
                          /*       the shape tests for this element.  This   */
                          /*       must be passed unchanged into             */
                          /*       FEM_TestShapes which compares each value  */
                          /*       to the warning/error limits.              */
                          /* =============================================== */



                          /* =============================================== */
                          /* === FEM_TestShapes:  After calling              */
                          /* === FEM_ComputeShapes for an element, test the  */
                          /* === values computed against a set of            */
                          /* === error/warning limits to see if they have    */
                          /* === violated error/warning element criteria.    */
                          /* === RETURN: FEM_INT ( EXIT_SUCCESS or           */
                          /* ===                   EXIT_FAILURE)             */
                          /* =============================================== */
FEM_CPP_EXTERN FEM_INT FEM_TestShapes(
   FEM_BOOLEAN warnonly,  /* (IN)  indicates shape checking is set for       */
                          /*       WARNINGS ONLY.  If this is TRUE, both     */
                          /*       error and warning elements recieve        */
                          /*       warnings.                                 */
   SH_SHAPE_ENUM shape,   /* (IN)  The shape of the element to test.  This   */
                          /*       the same as the shape argument to         */
                          /*       FEM_ComputeShapes.                        */
   FEM_BOOLEAN quad_helm, /* (IN)  TRUE if the element is a quadratic h-elem.*/
                          /*       Even the element has all of its midnodes  */
                          /*       dropped, if it is quadratic, send in TRUE */
   FEM_BOOLEAN pelm,      /* (IN)  TRUE if the element is a p-element.       */
                          /*       If quadratic_helm == TRUE, this arg is    */
                          /*       ignored.                                  */
   SH_ELEM_TYPE_ENUM type,/* (IN)  The type of element to test.              */
   FEM_DOUBLE a_shpar[10],/* (IN)  This array is the array returned from     */
                          /*       FEM_ComputeShapes.  This array contains   */
                          /*       the results of the shape tests performed  */
                          /*       on this element.  The values in this      */
                          /*       array are compared against the            */
                          /*       warning/error limits.  You should not     */
                          /*       alter or change the values in this array  */
                          /*       after they are returned from              */
                          /*       FEM_ComputeShapes.                        */
   FEM_INT a_nodes[],     /* (IN)  defines the connectivity of the element.  */
                          /*       See comment for FEM_ComputeShapes()       */
                          /*       argument list for detail.                 */
   FEM_BOOLEAN asp_ratio, /*(IN) TRUE if this element should be checked    */
                          /*       for aspect ratio.                         */
   FEM_BOOLEAN qdbrk_prll,/* (IN)  For quadrilaterals, check how far from    */
                          /*       parallel are opposite edges of the quad.  */
                          /*       For Bricks, wedges, and pryamids, checks  */
                          /*       deviation from parallel of opposite edges */
                          /*       on all quad faces and x-sections.         */
   FEM_BOOLEAN max_angle, /* (IN)  For triangles and quadrilaterals,         */
                          /*       calculate the maximum angle at any node.  */
                          /*       For bricks, wedges, pyrmaids, and tets,   */
                          /*       calculate the maximum angle on any face   */
                          /*       or x-section.                             */
   FEM_BOOLEAN angle_dev, /* (IN)  For SH_SHELL28, calculate the each corner */
                          /*       angles deviation from 90 degrees.  This   */
                          /*       flag is ignored unless type == SH_SHELL28 */
   FEM_BOOLEAN warp,      /* (IN)  FOR any of the SH_SHELLX elements that    */
                          /*       are degenerated into a triangle, check    */
                          /*       how close from planar the 4 nodes are.    */
   FEM_BOOLEAN jacob_ratio,/*(IN)  calculate the jacobian ratio for this     */
                          /*       element.                                  */
   FEM_BOOLEAN mphysics,  /* (IN)  TRUE if this element has fluid velocity   */
                          /*       or magnetic potential degrees of freedom. */
                          /*       If TRUE, this element is excluded from    */
                          /*       aspect ratio, quad parallel deviation,    */
                          /*       and maximum angle tests.                  */
   FEM_BOOLEAN nlgeom,    /* (IN)  TRUE if this element will be used in      */
                          /*       geometric nonlinear static structural     */
                          /*       analysis.  If TRUE, quad shell warping    */
                          /*       limits are much more restrictive if       */
                          /*       type == SH_SHELL63.  Use FALSE if the     */
                          /*       element is not a quad shell, or if this   */
                          /*       analysis information is unavailable.      */
                          /*       (NOTE: warping factor evaluations done    */
                          /*              without nlgeom == TRUE [when it    */
                          /*              should be] may be unconservative.  */
                          /*              Quad warping should be             */
                          /*              re-evaluated if geometric          */
                          /*              nonlinearities are activated       */
                          /*              later.)                            */
   FEM_DOUBLE a_limits[68],/*(IN)  array of limits on element quality        */
                          /*       measures.  (see FEM_ansysshpchk.h for     */
                          /*       details.)                                 */
   SH_QUAL_ENUM *result,  /* (OUT) Whether the element tripped an error or   */
                          /*       warning limit.                            */
   TEST_RESULT_TYP *aspect_ratio_result,
                          /* (OUT) Whether this element tripped the aspect   */
                          /*       ratio warning or error limits.            */
   TEST_RESULT_TYP *qdbrk_parallel_result,
                          /* (OUT) Whether this element tripped the quad/brk */
                          /*       parallel edges warning or error limits.   */
   TEST_RESULT_TYP *max_angle_result,
                          /* (OUT) Whether this element tripped the maximum  */
                          /*       angle warning or error limits.            */
   TEST_RESULT_TYP *angle_dev_result,
                          /* (OUT) Whether this element tripped the angle    */
                          /*       deviation warning or error limits.        */
   TEST_RESULT_TYP *warp_result,
                          /* (OUT) Whether this element tripped the warp     */
                          /*       warning or error limits.                  */
   TEST_RESULT_TYP *jacob_ratio_result,
                          /* (OUT) Whether this element tripped the jacobian */
                          /*       ratio warning or error limits.            */
   TEST_RESULT_TYP *gen_results );
                          /* (OUT) Other results for other general tests run */
                          /* =============================================== */

/* === possible values for TEST_RESULT_TYP.error_id which is returned from
   === FEM_TestShapes() */

   /* error_id return value */       /* suggested error/warning message */

#define ASPRAT_Wrn        1   /* *** WARNING *** ____ element ____ has an 
                                 aspect ratio of ____, which exceeds the
                                 warning limit of ____.   */

#define ASPRAT_Err        2   /* *** ERROR *** ____ element ____ has an
                                 aspect ratio of ____, which exceeds the
                                 error limit of ____. */

#define PRL_0LSidErr      3   /* *** ERROR *** ____ element ____ has a zero
                                 length edge. */

#define PRL_AngleWrn      4   /* *** WARNING *** ____ element ____ has a pair
                                 of opposite edges that are ____ degrees away
                                 from being parallel.  This exceeds the warning
                                 limit of ____ degrees. */

#define PRL_AngleErr      5   /* *** ERROR *** ____ element ____ has a pair of
                                 opposite edges that are ____ degrees away from
                                 being parallel. This exceeds the error limit
                                 of ____ degrees. */

#define MAXANG_Wrn        6   /* *** WARNING *** ____ element ____ has an angle
                                 between adjacent edges of ____ degrees, which
                                 exceeds the warning limit of ____ */

#define MAXANG_Err        7   /* *** ERROR *** ____ element ____ has an angle
                                 between adjacent edges of ____ degrees, which
                                 exceeds the error limit of ____ */

#define ANGD_Z180dErr     8   /* *** ERROR *** Quadrilateral SHELL28
                                 (SHEAR/TWIST panel) element ____ has a zero
                                 or 180 degree angle between adjacent edges,
                                 or a zero length edge. */

#define ANGD_TwistErr     9   /* TwistErr' "*** ERROR *** Quadrilateral SHELL28
                                 (SHEAR/TWIST panel) element ____ is
                                 excessively twisted (in-plane distortion). */

#define ANGD_AngleWrn     10  /* *** WARNING *** Quadrilateral SHELL28
                                 (SHEAR/TWIST panel) element ____ has an angle
                                 between adjacent edges of ____ degrees, which
                                 is outside the "no-warning" range of ____ to
                                 ____ degrees. */

#define ANGD_AngleErr     11  /* *** ERROR *** Quadrilateral SHELL28
                                 (SHEAR/TWIST panel) element ____ has an angle
                                 between adjacent edges of ____ degrees, which
                                 is outside the "no-error" range of ____ to
                                 ____ degrees. */

#define WARP_NrmtrErr     12  /* For Quads:
                                 *** ERROR *** Quadrilateral shell element ____
                                 has an unacceptable shape (cannot normalize
                                 transformation matrix).

                                 For 3-D solid elements:
                                 *** ERROR *** ____ element ____ has a
                                 quadrilateral face with an unacceptable shape
                                 (cannot normalize transformation matrix). */

#define WARP_Z180dErr     13  /* For Quads:
                                 *** ERROR *** Quadrilateral shell element
                                 ____ has a zero or 180 degree angle between
                                 adjacent edges, or a zero length edge.

                                 For 3-D solid elements:
                                 *** ERROR *** ____ element ____ has a
                                 quadrilateral face having a zero or 180
                                 degree angle between adjacent edges, or a
                                 zero length edge. */

#define WARP_AreacErr     14  /* For Quads:
                                 *** ERROR *** Quadrilateral shell element
                                 ____ has an unacceptable shape (cannot compute
                                 area).

                                 For 3-D solid elements:
                                 *** ERROR *** ____ element ____ has a
                                 quadrilateral face with an unacceptable shape
                                 (cannot compute area). */

#define WARP_63ld_Wrn     15  /* *** WARNING *** Quadrilateral SHELL63 element
                                 ____ has a warping factor of ____, which
                                 exceeds the large deflection warning limit
                                 of ____. */

#define WARP_63ld_Err     16  /* *** ERROR *** Quadrilateral SHELL63 element
                                 ____ has a warping factor of ____, which
                                 exceeds the large deflection error limit of
                                 ____. Use two triangular elements. */

#define WARP_43_181_Wrn   17  /* *** WARNING *** Quadrilateral SHELL__ element
                                  ____ has a warping factor of ____, which
                                  exceeds the warning limit of ____. */

#define WARP_43_181_Err   18  /* *** ERROR *** Quadrilateral SHELL__ element
                                 ____ has a warping factor of ____, which
                                 exceeds the error limit of ____.  Use two
                                 triangular elements. */

#define WARP_28___Wrn     19  /* *** WARNING *** Quadrilateral SHELL28
                                 (SHEAR/TWIST panel) element ____ has a warping
                                 factor of ____, which exceeds the warning
                                 limit of ____. */

#define WARP_28___Err     20  /* *** ERROR *** Quadrilateral SHELL28
                                 (SHEAR/TWIST panel) element ____ has a warping
                                 factor of ____, which exceeds the error limit
                                 of ____. Use two triangular elements. */

#define WARP_Bend_Wrn     21  /* *** WARNING *** Quadrilateral flat shell
                                 element ____ has a warping factor of ____,
                                 which exceeds the warning limit of ____. */

#define WARP_Bend_Err     22  /* *** ERROR *** Quadrilateral flat shell element
                                 ____ has a warping factor of ____, which
                                 exceeds the error limit of ____. Use two
                                 triangular elements. */

#define WARP_MembrWrn     23  /* *** WARNING *** Quadrilateral flat membrane
                                 shell element ____ has a warping factor of
                                 ____, which exceeds the warning limit of
                                 ____. */

#define WARP_MembrErr     24  /* *** ERROR *** Quadrilateral flat membrane
                                 shell element ____ has a warping factor of
                                 ____, which exceeds the error limit of ____.
                                 Use two triangular elements. */

#define WARP_Face_Wrn     25  /* *** WARNING *** ____ element ____ has a
                                 quadrilateral face with a warping factor of
                                 ____, which exceeds the warning limit of
                                 ____. */

#define WARP_Face_Err     26  /* *** ERROR *** ____ element ____ has a
                                 quadrilateral face with a warping factor of
                                 ____, which exceeds the error limit of ____. */

#define GEN_ZCnodErr      27  /* *** ERROR *** ____ element ____ has a corner
                                 node number of zero. */

#define GEN_UCnodErr      28  /* *** ERROR *** ____ element ____ has an
                                 undefined corner node. */

#define GEN_CCnodWrn      29  /* *** WARNING *** ____ element ____ has a
                                 midside node on a zero length edge. This is
                                 not recommended. */

#define GEN_SinguWrn      30  /* *** WARNING *** ____ element ____ has a
                                 midside node which is off-center by a distance
                                 ratio of ____. This may be OK if you are
                                 simulating a stress singularity using quarter
                                 point elements. */

#define JBR_SgnCgErr      31  /* *** ERROR *** ____ element ____ has a zero or
                                 inverted Jacobian determinant at one of its
                                 corner nodes. Midside nodes, if any, may be
                                 poorly positioned. */

#define JBR_RatioWrn      32  /* *** WARNING *** ____ element ____ has a
                                 Jacobian ratio of ____, which exceeds the
                                 warning limit of ____. Midside nodes, if any,
                                 may be poorly positioned. */

#define JBR_Qpnt_Wrn      33  /* if TEST_RESULT_TYP.act_value < -99.9 then:
                                 *** WARNING *** ____ element ____ has a zero
                                 or inverted Jacobian determinant at one of
                                 its corner nodes.  This may be OK if you are
                                 simulating a stress singularity using quarter
                                 point elements.

                                 else if TEST_RESULT_TYP.act_value > 0 then:
                                 *** WARNING *** ____ element ____ has a
                                 Jacobian ratio of ____, which exceeds the
                                 error limit of ____. This may be OK if you
                                 are simulating a stress singularity using
                                 quarter point elements. */

#define JBR_RatioErr      34  /* *** ERROR *** ____ element ____ has a Jacobian
                                 ratio of ____, which exceeds the error limit
                                 of ____. Midside nodes, if any, may be poorly
                                 positioned. */


/*--------------------------------------------------------------------------
The following table documents the a_limits array which is sent to
FEM_TestShapes().  The suggested defaults, are just that: suggestions.  You
can modify these values as desired to enforce greater/lower element quality.
In Ansys 5.X, we allow the user to modify these values as an advanced control.

                   description                        |   Suggested default
----------------------------------------------------------------------------
a_limits[0]  |  Aspect ratio warning limit.           |   20.0
a_limits[1]  |  Aspect ratio error limit.             |   1.0e14
a_limits[2]  |              Not Used.                 |   N\A
a_limits[3]  |              Not Used.                 |   N\A
a_limits[4]  |              Not Used.                 |   N\A
a_limits[5]  |              Not Used.                 |   N\A
a_limits[6]  |  Angle deviation from 90 degrees       |
             |    warning limit. Used for SH_SHELL28  |   5.0
a_limits[7]  |  Angle deviation from 90 degrees       |
             |    warning limit. Used for SH_SHELL28  |   30.0
a_limits[8]  |              Not Used.                 |   N\A
a_limits[9]  |              Not Used.                 |   N\A
a_limits[10] |  Quad/Brick parallel deviation without |
             |    midnodes warning limit.             |   70.0
a_limits[11] |  Quad/Brick parallel deviation without |
             |    midnodes error limit.               |   150.0
a_limits[12] |  Quad/Brick parallel deviation with    |
             |    midnodes warning limit.             |   100.0
a_limits[13] |  Quad/Brick parallel deviation with    |
             |    midnodes error limit.               |   170.0
a_limits[14] |  Maximum angle in triangles warning    |
             |    limit.                              |   165.0
a_limits[15] |  Maximum angle in triangles error      |
             |    limit.                              |   179.9
a_limits[16] |  Maximum angle in quadrilaterals       |
             |    without midnodes warning limit.     |   155.0
a_limits[17] |  Maximum angle in quadrilaterals       |
             |    without midnodes error limit.       |   179.9
a_limits[18] |  Maximum angle in quadrilaterals       |
             |    with midnodes warning limit.        |   165.0
a_limits[19] |  Maximum angle in quadrilaterals       |
             |    with midnodes error limit.          |   179.9
a_limits[20] |              Not Used.                 |   N\A
a_limits[21] |              Not Used.                 |   N\A
a_limits[22] |              Not Used.                 |   N\A
a_limits[23] |              Not Used.                 |   N\A
a_limits[24] |              Not Used.                 |   N\A
a_limits[25] |              Not Used.                 |   N\A
a_limits[26] |              Not Used.                 |   N\A
a_limits[27] |              Not Used.                 |   N\A
a_limits[28] |              Not Used.                 |   N\A
a_limits[29] |              Not Used.                 |   N\A
a_limits[30] |  h-method Jacobian Ratio warning limit |   30.0
a_limits[31] |  h-method Jacobian Ratio error limit   |   1000.0
a_limits[32] |  p-method Jacobian Ratio warning limit |   30.0
a_limits[33] |  p-method Jacobian Ratio error limit   |   40.0
a_limits[34] |              Not Used.                 |   N\A
a_limits[35] |              Not Used.                 |   N\A
a_limits[36] |              Not Used.                 |   N\A
a_limits[37] |              Not Used.                 |   N\A
a_limits[38] |              Not Used.                 |   N\A
a_limits[39] |              Not Used.                 |   N\A
a_limits[40] |              Not Used.                 |   N\A
a_limits[41] |              Not Used.                 |   N\A
a_limits[42] |              Not Used.                 |   N\A
a_limits[43] |              Not Used.                 |   N\A
a_limits[44] |              Not Used.                 |   N\A
a_limits[45] |              Not Used.                 |   N\A
a_limits[46] |              Not Used.                 |   N\A
a_limits[47] |              Not Used.                 |   N\A
a_limits[48] |              Not Used.                 |   N\A
a_limits[49] |              Not Used.                 |   N\A
a_limits[50] |  warp factor warning limit for         |
             |    SH_SHELL43 and SH_SHELL181.         |   1.0
a_limits[51] |  warp factor error limit for           |
             |    SH_SHELL43 and SH_SHELL181.         |   5.0
a_limits[52] |  warp factor warning limit for         |
             |    SH_SHELL63 if nlgeom == FALSE, and  |
             |    SH_SHELL57.                         |   0.1
a_limits[53] |  warp factor error limit for           |
             |    SH_SHELL63 if nlgeom == FALSE, and  |
             |    SH_SHELL57.                         |   1.0
a_limits[54] |  warp factor warning limit for         |
             |    SH_SHELL41 and SH_SHELL63M.         |   0.00004
a_limits[55] |  warp factor error limit for           |
             |    SH_SHELL41 and SH_SHELL63M.         |   0.04
a_limits[56] |  warp factor warning limit for         |
             |    SH_SHELL28                          |   0.1
a_limits[57] |  warp factor error limit for           |
             |    SH_SHELL28                          |   1.0
a_limits[58] |  warp factor warning limit for         |
             |    SH_SHELL63 if nlgeom == TRUE.       |   0.00001
a_limits[59] |  warp factor error limit for           |
             |    SH_SHELL63 if nlgeom == TRUE.       |   0.01
a_limits[60] |              Not Used.                 |   N\A
a_limits[61] |              Not Used.                 |   N\A
a_limits[62] |              Not Used.                 |   N\A
a_limits[63] |              Not Used.                 |   N\A
a_limits[64] |              Not Used.                 |   N\A
a_limits[65] |              Not Used.                 |   N\A
a_limits[66] |  warp factor warning limit for 3-d     |
             |     solid element faces and cross      |
             |     sections.                          |   0.20
a_limits[67] |  warp factor error limit for 3-d       |
             |     solid element faces and cross      |
             |     sections.                          |   0.40
----------------------------------------------------------------------*/

#endif
