/* sid 60.1 copy of fem_ivDebug.h last changed by upd111 on 2005/07/21 19:42:21 */
#ifndef DEBUG_______________H
#define DEBUG_______________H

/* prototypes for debug printing by other files */

#ifdef __cplusplus
extern "C" {
#endif

void debug_print(lprec *lp, char *format, ...);
void debug_print_solution(lprec *lp);
void debug_print_bounds(lprec *lp, REAL *upbo, REAL *lowbo);

#ifdef __cplusplus
}
#endif

#endif

