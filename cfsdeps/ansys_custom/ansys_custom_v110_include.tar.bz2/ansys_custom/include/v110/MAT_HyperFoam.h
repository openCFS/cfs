/* sid 60.1 copy of MAT_HyperFoam.h last changed by upd111 on 2006/10/09 19:56:47 */
////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         Copyright (C) 2001 ANSYS Inc.  All Rights Reserved             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MAT_HyperFoam.h $
// $Revision$ 7.0
// $Date$ May 8 2002
// $Author$ rjayasee
//
// Decription :
//
//	This class is the Hyperfoam abstraction for material curve fitting
//////////////////////////////////////////////////////////////////////////////

#if !defined( MAT_HyperFoam_H )
#define MAT_HyperFoam_H


#include "MAT_ConstitutiveFunction.h"

class MAT_ExperimentalDataSet ;

class MAT_HyperFoam : public MAT_ConstitutiveFunction
{

public:

    MAT_HyperFoam();
    //Constructor

     virtual INT GetNumberOfCoeffs() ;
    //R-bool
    //I-iOrder
    //I-Number of Coeffs
    //F-Set the Number of Coeffs
    //F-This is calculated from the polynomial order

     virtual bool SetOrder( INT iOrder ) ;
    //R-bool
    //I-iOrder
    //I-Number of Coeffs
    //F-Set the Order of the Model.

    virtual bool GenerateMaterialParameters() ;
    //R-bool
    //F-Function that Generates the Material Parameters given
    //F-some experimental data

    virtual bool GenerateMaterialParametersWithLMMethod() ;
    //R-bool
    //F-Function that Generates the Material Parameters given
    //F-some experimental data with Levenberg Marquardt's Method

    virtual bool GenerateMaterialParametersWithNRMethod() ;
    //R-bool
    //F-Function that Generates the Material Parameters given
    //F-some experimental data with Newton's Method
    
    virtual bool CalculateFittedExperimentalDataPoint
                    ( ANS_String const& oExperimentType,
                      vector<MAT_CFAttribute*> const& oParamVector,
                      double& oCalculatedValue ) ;
    //R Status of Function
    //I oExperimentType
    //I-Type of Experiment
    //I oParamVector
    //I-Vector of Parameters
    //O oCalculateValue
    //O-Value of Fitted Data
    //- Calculated Fitted Data Given Input

    virtual bool CalculateFittedExperimentalDataPoint
                ( double* pCoeffs,
                  INT iNumCoeffs,
                  ANS_String oExpName,
                  vector<double>& oPoint ) ;
    //R bool
    //I oExpName
    //I-Experiment Type
    //I oPoint
    //I-Point at which the stress is to be calculated
    //- Calculates the Stress at a strain point given the experiment type

    virtual void Print() ;
    //F-Print

  	virtual ~MAT_HyperFoam();
    //F-Destructor


private:


    // Note: 
    // Coefficients are ordered in the following mode. Same as Ansys
    // mu1,alpha1,mu2,alpha2....Beta1,Beta2....

    double** m_pD2FMatrix ;
    INT m_iNumRowsD2FMatrix ;
    INT m_iNumColsD2FMatrix ;

    double** m_pD1FMatrix ;
    INT m_iNumRowsD1FMatrix ;
    INT m_iNumColsD1FMatrix ;

    INT m_iOrder ;
    //Order of the model

    bool AssembleDerivativesMatrices
         ( MAT_ExperimentalDataSet* pDataSet) ;
    //R-bool
    //I-pDataSet
    //I-Pointer to a ExpDataSet
    //F-Assemble the matrix to be solved for the parameters
    
    bool FirstDerivativeOfUnsquaredError( double* dVariables,
                                          INT iNumVariables,
                                          MAT_ExperimentType iExpType,
                                          double dLambda1, 
                                          double dLambda2, 
                                          double dLambda3, 
                                          INT iVariableIndex,
                                          double& dResult ) ;
    //R bool
    //R-false if unknown exp type or null dVariables
    //I dVariables
    //I-Input Coeffients
    //I iNumVariables
    //I-Number of Variables
    //I dLambda1
    //I-Value of Principal Stretch 1
    //I dLambda2
    //I-Value of Principal Stretch 2
    //I dLambda3
    //I-Value of Principal Stretch 3
    //I dStress
    //I-Value of Stress
    //I iExpType
    //I- 1 for uniaxial, 2 for biaxial, 3 for shear
    //I iVariableIndex
    //I-Variable with which we differentiate
    //- Calculates the value of the first derivative of the Gent Potential
    //- for a stress/stretch point


    bool FunctionValue( double* dVariables,
                        INT iNumVariables,
                        MAT_ExperimentType iExpType,
                        double dLambda1, 
                        double dLambda2, 
                        double dLambda3, 
                        double& dStress ) ;
    //R bool
    //I dVariables
    //I-Input Coeffients
    //I iNumVariables
    //I-Number of Variables
    //I dLambda1
    //I-Value of Principal Stretch 1
    //I dLambda2
    //I-Value of Principal Stretch 2
    //I dLambda3
    //I-Value of Principal Stretch 3
    //I dStress
    //I-Value of Stress
    //- Calculate Stress given stretch and coeffs

    bool FirstDerivativeTerm( double* dVariables, 
                              INT iNumVariables,
                              double dLambda1, 
                              double dLambda2, 
                              double dLambda3, 
                              double dStressN,
                              MAT_ExperimentType iExpType,
                              INT iVariableIndex,
                              double& dResult ) ;
    //R-Status of the function
    //I dVariables
    //I-Input Coeffients
    //I iNumVariables
    //I-Number of Variables
    //I dLambda1
    //I-Value of Principal Stretch 1
    //I dLambda2
    //I-Value of Principal Stretch 2
    //I dLambda3
    //I-Value of Principal Stretch 3
    //I dStress
    //I-Value of Stress
    //I iExpType
    //I- 1 for uniaxial, 2 for biaxial, 3 for shear
    //I-iVariableIndexJ
    //I-Variable by which it is differentiated first
    //I-iVariableIndexK
    //I-Variable by which it is differentiated next
    //O-dResult
    //I-Value of the second derivative
    //- Calculates the value of the first derivative of the Stress
    //- Error Squared at a point

    bool SecondDerivativeTerm( double* dVariables,
                               INT iNumVariables,
                               double dLambda1, 
                               double dLambda2, 
                               double dLambda3, 
                               double dStress,
                               MAT_ExperimentType iExpType,
                               INT iVariableIndexJ,
                               INT iVariableIndexK,
                               double& dResult ) ;
    //R-true if if was a success
    //I dAlpha
    //I-Coefficent Alpha in Gent Expr
    //I dMu
    //I-Coefficent Mu in Gent Expr
    //I dLambda1
    //I-Value of Principal Stretch 1
    //I dLambda2
    //I-Value of Principal Stretch 2
    //I dLambda3
    //I-Value of Principal Stretch 3
    //I dStress
    //I-Value of Stress
    //I iExpType
    //I- 1 for uniaxial, 2 for biaxial, 3 for shear
    //I-iVariableIndexJ
    //I-Variable by which it is differentiated first
    //I-iVariableIndexK
    //I-Variable by which it is differentiated next
    //O-dResult
    //I-Value of the second derivative
    //- Calculates the value of the first derivative of the Gent Stress
    //- Error Squared at a point

    bool Assemble1stDerivativeMatrix
        ( double* dCoeffs,
          INT iNumCoeffs,
          double** d1stDerMatrix ) ;
    //R-Status of the function
    //I pDataSet
    //I-Collection of Experimental Data
    //I dCoeff                      
    //I-array of coefficients
    //I iNumCoeffs                  
    //I-Number of Coefficients
    //I d1stDerMatrix               
    //I-The Resulting Matrix of 1st Derivatives
    //-Assemble the RHS Matrix for the Newton-Raphson Loop

    bool Assemble1stDerivativeMatrixAtAllPoints
        ( double* dCoeffs,
          INT iNumCoeffs,
          INT iNumPoints,
          double** d1stDerMatrix ) ;
    //R-Status of the function
    //I pDataSet
    //I-Collection of Experimental Data
    //I dCoeff                      
    //I-array of coefficients
    //I iNumCoeffs                  
    //I-Number of Coefficients
    //I iNumPoints
    //I-Number of points
    //I d1stDerMatrix               
    //I-The Resulting Matrix of 1st Derivatives
    //-Assemble the 1st Derivatives of Error ( Numpoints * Numcoeffs)
   
    
    bool Assemble2ndDerivativeMatrix
    ( double* dCoeffs,
      INT iNumCoeffs,
      double** d2ndDerMatrix ) ;
    //R-Status of the function
    //I dCoeff                      
    //I-array of coefficients
    //I iNumCoeffs                  
    //I-Number of Coefficients
    //I d1stDerMatrix               
    //I-The Resulting Matrix of 2nd Derivatives
    //-Assemble the RHS Matrix for the Newton-Raphson Loop

    bool Residual
        ( double* dCoeffs,
          INT iNumCoeffs,
          double& dResidual ) ;
    //R-Status of the function
    //I dCoeff                      
    //I-array of coefficients
    //I iNumCoeffs                  
    //I-Number of Coefficients
    //I dResidual               
    //I-The Resulting Resisuals
    //- Calculates the Residual given the coefficients

    bool ResidualAtAllPoints
        ( double* dCoeffs,
          INT iNumCoeffs,
          INT iNumPoints,
          double** dResidual ) ;
    //R-Status of the function
    //I dCoeff                      
    //I-array of coefficients
    //I iNumCoeffs                  
    //I-Number of Coefficients
    //I iNumPoints
    //I-Number of Points
    //I dResidual               
    //I-The Resulting Array of Errors ( NumPoints * 1)
    //-Assemble the Error Matrix


    bool GetPrincipalStretchAndStressDataFromPoint( ANS_String const & oExpType,
                                                    ANS_Point const & oPoint,
                                                    MAT_ExperimentalDataFormat & pExpDataFormat,
                                                    double& dLambda1 ,
                                                    double& dLambda2 ,
                                                    double& dLambda3 ,
                                                    double& dStress ) ;
    //R bool
    //I oExpType
    //I Experiment Type
    //I oPoint
    //I-Point from which experimental data is to be extracted
    //I pExpDataFormat
    //I-Experimental Data Format
    //O dLambda1
    //O dLambda2
    //O dLambda3
    //- Gets the Value of the Principal Stretches dLambda1, dLambda2 and dLambda3
};

#endif // !defined(MAT_HyperFoam_H)
