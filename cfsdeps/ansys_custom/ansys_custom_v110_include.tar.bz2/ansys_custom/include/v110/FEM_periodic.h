/* sid 60.1 copy of FEM_periodic.h last changed by upd111 on 2005/07/21 19:40:54 */

/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 1999 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_periodic.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_periodic.h
 *  header file for FEM_periodic.c
 *
 */
#ifndef FEM_PERIODIC_INCLUDE
#define FEM_PERIODIC_INCLUDE

/*----------------- Constants defined in this file --------------------------*/

typedef enum { AREA_NOT_PERIODIC=0,
               AREA_CLOSED_INU=1,
               AREA_CLOSED_INV=2,
               AREA_NON_MANIFOLD=3,
               AREA_CLOSED_INU_AND_INV = 4 } PERIODIC_TYPE;

typedef enum { NO_DIR,
               U_DIR,
               V_DIR } SEAM_DIR;

#ifdef __cplusplus
extern "C" {
#endif

/*----------------- Globally accessible function prototypes -----------------*/

                        /* ================================================== */
                        /* === FEM_prPeriodicCheck:  See if an area is        */
                        /* === periodic.  If so add in extra edges on the     */
                        /* === duplicated line.                               */
                        /* === Return: INT EXIT_SUCCESS or EXIT_FAILURE       */
                        /* ================================================== */
INT FEM_prPeriodicCheck(
   INT *a_lines,        /* (IN)  array of line ids on area we are meshing.    */
   INT num_lines,       /* (IN)  length of a_lines.                           */
   INT *periodic );     /* (OUT) 0 if not periodic, 1 if cone, 2 if cylinder  */
                        /* ================================================== */

                        /* ================================================== */
                        /* === FEM_prInit: Given a periodic surface, Get      */
                        /* === ready to process it.  In doing so, we mark the */
                        /* === edges along the seamline as EDGE_NON_MANIFOLD  */
                        /* === edges, and also find degenerate points on the  */
                        /* === seamline.                                      */
                        /* === Return: INT EXIT_SUCCESS or EXIT_FAILURE       */
                        /* ================================================== */
INT FEM_prInit(
   INT area_id,         /* (IN)  The area to check for seamlines.             */
   INT num_bound,       /* (IN)  number of boundary edges on this area.       */
   INT debug );         /* (IN)  debug flag                                   */

                        /* ================================================== */
                        /* === FEM_prGetConeTips: Return a pointer to the     */
                        /* === tips of any cones found during FEM_prInit.     */
                        /* === Return: INT number of cone tips.               */
                        /* ================================================== */
INT FEM_prGetConeTips(
   EDGE_OBJ **aobj_conetips ); /* (OUT) pointer to tips. */

                        /* ================================================== */
                        /* === FEM_prDeleteConeTips: Free memory holding cone */
                        /* === tips allocated in FEM_prInit.                  */
                        /* === Return: void                                   */
                        /* ================================================== */
void FEM_prDeleteConeTips( void );

                        /* ================================================== */
                        /* === FEM_prUndoPeriodicDoubles:  A periodic surface */
                        /* === was just meshed.  Before meshing,              */
                        /* === FEM_prPeriodicCheck was called which added a   */
                        /* === bunch of extra nodes and edges to handle the   */
                        /* === periodicalness(???)!!!  Delete these extra     */
                        /* === nodes and edges now that we are done meshing.  */
                        /* === Return: INT EXIT_SUCCESS or EXIT_FAILURE       */
                        /* ================================================== */
INT FEM_prUndoPeriodicDoubles(
   INT *numbound );     /* (IN/OUT) (IN)  number of boundary edges included   */
                        /*                periodic doubles.                   */
                        /*          (OUT) number of boundary edges after      */
                        /*                periodic doubles were deleted and   */
                        /*                merged.                             */
                        /* ================================================== */

#ifdef __cplusplus
}
#endif

#endif

