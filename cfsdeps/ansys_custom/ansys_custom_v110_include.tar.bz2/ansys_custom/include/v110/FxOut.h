/* sid 60.1 copy of FxOut.h last changed by jtm on 2006/05/15 19:43:18 */
/* ---------------------------------------------------------------------- */
/* *** copyright(c) 2006 SAS IP, Inc.  All rights reserved.                                         */
/* *** ansys, inc.                                                        */
/* ---------------------------------------------------------------------- */
/*
 *    author/date: Stefan Reh  2002-02-06
 *
 *    primary function:
 *
 *        header for prototype definitions in ANSI C
 *
 *    Notice - This file contains ANSYS Confidential information ***
 *
 */

#ifndef _FX_OUT_H_
#define _FX_OUT_H_

extern int     PutFxOutSettings ( char cName[], char cType[], char cComp[], double dAccuracy, int iNumElems, int iElemList[] );
extern double FxGetAccuracy(void);

#endif /* _FX_OUT_H_ */
