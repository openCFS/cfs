/* sid 60.8 copy of ggilib.h last changed by gawang on 2006/08/07 16:07:13 */
#ifdef __cplusplus
extern "C" {
#endif

/***********************************************************************\
 * Declare Internal Functions                                          *
\***********************************************************************/

void ggi_free(void *mem_ptr) ;

void ggi_free_int(int **mem_ptr) ;

void ggi_free_real(REAL_GGI **mem_ptr) ;

void ggi_init() ;

void ggi_finish() ;

void ggi_set_sepfact(REAL_GGI SeparationFactor) ;

void ggi_set_frctol(REAL_GGI FrcTolerance) ;

void ggi_set_treesearch(int TreeSearch);

void ggi_set_resolution(int Resolution);

void ggi_set_intsectmethod(int MF_IntsectMethod);

int ggi_get_ncs() ;

int ggi_get_ncsc() ;

REAL_GGI ggi_get_frctol() ;

int ggi_get_nggifc(int iside) ;

int ggi_get_mesh(int iside, int NVxBcp, int NSfcBcp, int NVxPerFc,
                 int *KVxBcp_ptr, int *KGGIFcIP_ptr, int *KCsFc_ptr,
                 int *NCsFc_ptr, REAL_GGI *AreaIpFc_ptr,
                 REAL_GGI *AreaNod_ptr);

int ggi_get_csdat (int *CsNum_optr, REAL_GGI *CsFactor_optr) ;

int ggi_area_nod(int ISide, int NVxBcp, int NSfcBcp, int NVxPerFc,
                 int *KVxBcp_ptr, REAL_GGI *AreaNod_ptr) ;

int ggi_get_nonovlp(int ISide, int NVxBcp, int NSfcBcp,
                    int NVxPerFc, int *KVxBcpA_ptr,
                    int *NonOvlp_ptr, int *nNonOvlp) ;

int ggi_interp_ip(int NVxBcpA, int NSfcBcpA, int NVxPerFcA,
                  int *KVxBcpA_ptr, REAL_GGI *VarNodA_ptr,
                               int NSfcBcpB, int NVxPerFcB,
                                    REAL_GGI *VarIpB_ptr,  int NCOMPT) ;

int ggi_interp_nod(int Cons_Key,
                   int NVxBcpA, int NSfcBcpA, int NVxPerFcA,
                   int *KVxBcpA_ptr, REAL_GGI *VarNodA_ptr,
                   int NVxBcpB, int NSfcBcpB, int NVxPerFcB,
                   int *KVxBcpB_ptr, REAL_GGI *VarNodB_ptr, int NCOMPT) ;

int ggi_setup(int NVxBcpA, int NSfcBcpA, int NVxPerFcA,
              int *KVxBcpA_ptr, REAL_GGI *CrdVxBcpA_ptr,
              int NVxBcpB, int NSfcBcpB, int NVxPerFcB,
              int *KVxBcpB_ptr, REAL_GGI *CrdVxBcpB_ptr) ;

int  ggi_srf_frac(int *KVxFcA_ptr, int *KGFcFcA_ptr, REAL_GGI *CrdVxA_ptr,
                  int NVxA, int NFcA, REAL_GGI DistA, REAL_GGI *EdgSclA_ptr,
                  int *KVxFcB_ptr, int *KGFcFcB_ptr, REAL_GGI *CrdVxB_ptr,
                  int NVxB, int NFcB, REAL_GGI DistB,
                  int NGFc, int NCSD, int *ICSCON_ptr,
                  int *LSTART_ptr, int *ISLCSV_ptr, REAL_GGI *CIJXYP_ptr,
                  int *LNEXT_ptr, int *IREF_ptr, REAL_GGI *CSXCOR_ptr,
                  REAL_GGI *CSFRAC_ptr, REAL_GGI FracTolerance) ;

/***********************************************************************\
 * Declare Error-checking Functions                                    *
\***********************************************************************/

void ggi_error(char *format, ...) ;

void ggi_warning(char *format, ...) ;

char const *ggi_get_error() ;

void ggi_error_exit() ;

void ggi_error_print() ;

/***********************************************************************\
 * Declare External Fortran Functions                                  *
\***********************************************************************/

void FMCALL (set_ia_ib,SET_IA_IB) (int *, int *, int *);

void FMCALL (set_ia_ir,SET_IA_IR) (int *, int *, int *);

void FMCALL (set_ir_iai,SET_IR_IAI) (int *, int *, int *, int *);

void FMCALL (set_iai_ir,SET_IAI_IR) (int *, int *, int *, int *);

void FMCALL (set_a_b,SET_A_B) (REAL_GGI *, REAL_GGI *, int *);

void FMCALL (set_a_r,SET_A_R) (REAL_GGI *, REAL_GGI *, int *);

void FMCALL (set_ai_r,SET_AI_R) (REAL_GGI *, int *, REAL_GGI *, int *);

void FMCALL (set_a_0,SET_A_0) (REAL_GGI *, int *);

void FMCALL (set_a_adivbyr, SET_A_ADIVBYR)
            (REAL_GGI *, REAL_GGI *, int *);

void FMCALL (set_a_adivbybn0,SET_A_ADIVBYBN0)
            (REAL_GGI *, REAL_GGI *, int *);

void FMCALL (set_u_shrinku, SET_U_SHRINKU)
            (REAL_GGI *, int *, int *, int *);

void FMCALL (set_iu_shrinkiu, SET_IU_SHRINKIU)
            (int *, int *, int *, int *);

void FMCALL (set_ia_indexia, SET_IA_INDEXIA) (int *, int *);

void FMCALL (set_ia_iaplusir, SET_IA_IAPLUSIR) (int *, int *, int *);

void FMCALL (set_a_magu, SET_A_MAGU) 
            (REAL_GGI *, REAL_GGI *, int *, int *);
 
void FMCALL (set_tracesd_r, SET_TRACESD_R) 
            (REAL_GGI *, REAL_GGI *, int *);


void FMCALL (ggi_cal_areanod, GGI_CAL_AREANOD)
            (int *, int *, int *, int *, int *, int *,
             REAL_GGI *, REAL_GGI *);

void FMCALL (ggi_cal_areanod_ovlp, GGI_CAL_AREANOD_OVLP)
            (int *, int *, int *, int *, int *, int *,
             int *, int *, REAL_GGI *, int *, int *,
             REAL_GGI *, REAL_GGI *);

void FMCALL (ggi_cal_nonovlp,GGI_CAL_NONOVLP)
            (int *, int *, int *, int *, int *, int *, int *, int *,
             REAL_GGI *, int *, int *, int *, int *, REAL_GGI *, int *);

void FMCALL (ggi_cal_varip, GGI_CAL_VARIP)
            (int *, int *, int *, int *, int *, int *, int *, int *,
             int *, int *, int *, int *, int *, int *,
             REAL_GGI *, int *, REAL_GGI *, int *, int *,
             REAL_GGI *, REAL_GGI *, REAL_GGI *, int *);

void FMCALL (ggi_cal_varnod_prof, GGI_CAL_VARNOD_PROF)
            (int *, int *, int *, int *, int *, int *, int *, int *,
             int *, int *, int *, int *, int *, int *, int *, int *,
             REAL_GGI *, REAL_GGI *,
             REAL_GGI *, int *, REAL_GGI *, int *, int *,
             REAL_GGI *, REAL_GGI *, REAL_GGI *, REAL_GGI *, int *);

void FMCALL (ggi_cal_varnod_cons, GGI_CAL_VARNOD_CONS)
            (int *, int *, int *, int *, int *, int *, int *, int *,
             REAL_GGI *, REAL_GGI *,
             int *, int *, int *, int *, int *, int *, int *, int *,
             REAL_GGI *, int *, REAL_GGI *, int *, int *,
             REAL_GGI *, REAL_GGI *, REAL_GGI *, REAL_GGI *, int *);

void FMCALL (ggi_srf_setup, GGI_SRF_SETUP) 
            (int *, int *, int *, int *, int *, int *,
             int *, int *, int *, int *, int *, int *,
             REAL_GGI *, REAL_GGI *, REAL_GGI *,  REAL_GGI *,
             REAL_GGI *, REAL_GGI *) ;

void FMCALL (ggi_cs_adj_add, GGI_CS_ADJ_ADD)
            (int *, int *, int *, int *, REAL_GGI *, REAL_GGI *,
             int *, int *, int *, int *, int*, REAL_GGI *);

void FMCALL (ggi_cs_adj_rcp, GGI_CS_ADJ_RCP)
            (int *, int *, int *, REAL_GGI *, REAL_GGI *,
             REAL_GGI *, REAL_GGI *, REAL_GGI *, 
             int *, int *, int *, int *);

void FMCALL (ggi_cs_get_size, GGI_CS_GET_SIZE)
            (int *, int *, int *, int *, int *, int *,
             int *, REAL_GGI *, REAL_GGI *);

void FMCALL (ggi_cs_final, GGI_CS_FINAL)
            (int *, int *, int *, int *, int *, int *,
             int *, int *, int *, int *, int *, 
             REAL_GGI *, REAL_GGI *, int *, int *, REAL_GGI *) ;

void FMCALL (ggi_tree_dir_flag,GGI_TREE_DIR_FLAG)
            (int *, int *, int *, REAL_GGI *, REAL_GGI *, REAL_GGI *);

void FMCALL (ggi_tree_init, GGI_TREE_INIT)
            (int *, int *, int *, int *, int *,
             int *, int *, int *, int *, int *,
             REAL_GGI *, int *, REAL_GGI *, REAL_GGI *, int *, int *, 
             REAL_GGI *, REAL_GGI *, REAL_GGI *, REAL_GGI *,
             int *, int *, int *, int *, int *, int *,
             REAL_GGI *, REAL_GGI *, int *);

void FMCALL (ggi_detect_deg_fc, GGI_DETECT_DEG_FC)
            (int *, int *, int *, int *, int *,
             REAL_GGI *, REAL_GGI *, REAL_GGI *);

void FMCALL (ggi_tree_search, GGI_TREE_SEARCH)
            (int *, int *, int *, int *, int *, int *, int *,
             REAL_GGI *, int *, REAL_GGI *, int *, int *, int *, int *,
             REAL_GGI *, REAL_GGI *, REAL_GGI *, REAL_GGI *,
             int *, int *);
void FMCALL (ggi_tree_sort, GGI_TREE_SORT)
            (int *, int*, int *, int *, int *);

void FMCALL (ggi_srf_ort,GGI_SRF_ORT)
            (int *, int *, int *, REAL_GGI *, int *, int *,
             REAL_GGI *, REAL_GGI *, REAL_GGI *, REAL_GGI *,
             int *, int *, int *, REAL_GGI *,
             int *, REAL_GGI *, REAL_GGI *);

void FMCALL (ggi_srf_draw, GGI_SRF_DRAW)
            (REAL_GGI *, REAL_GGI *, int *, int *, int *,
             REAL_GGI *, int *, int *, int *, int *,
             REAL_GGI *, int *, REAL_GGI *);

void FMCALL (ggi_cs_compute, GGI_CS_COMPUTE)
            (int *, int *, int *, int *, int *, int *, int *,
             REAL_GGI *, REAL_GGI *, REAL_GGI *, REAL_GGI *, REAL_GGI *,
             int *, int *, int *, REAL_GGI *, REAL_GGI *, int *, int *);

void FMCALL (ggi_srf_ort_dir,GGI_SRF_ORT_DIR)
            (int *, int *, int *, REAL_GGI *, int *, int *,
             REAL_GGI *, REAL_GGI *, REAL_GGI *, REAL_GGI *,
             int *, int *, REAL_GGI *, REAL_GGI *);

void FMCALL (ggi_srf_draw_dir, GGI_SRF_DRAW_DIR)
            (REAL_GGI *, int *, int *,
             REAL_GGI *, int *, int *, REAL_GGI *);

void FMCALL (ggi_poly_area_cent, GGI_POLY_AREA_CENT)
            (REAL_GGI *, REAL_GGI *, int *, int *, REAL_GGI *);

void FMCALL (ggi_cs_compute_dir, GGI_CS_COMPUTE_DIR)
            (int *, int *, int *, int *, int *, int *,
             REAL_GGI *, REAL_GGI *, int *, int *, REAL_GGI *, 
             REAL_GGI *, REAL_GGI *, int *, REAL_GGI *, REAL_GGI *);

void FMCALL (ggi_iloccs, GGI_ILOCCS)
            (int *, int *, int *, int *, int *, int *,
             REAL_GGI *, REAL_GGI *, int *, int *);


#ifdef __cplusplus
}
#endif
