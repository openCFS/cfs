/* sid 60.1 copy of BIL_binput.h last changed by smarguer on 2006/02/09 09:12:46 */
/* BIL_binput.h CADOE  */
/*
 * BIL_binput.h
 *
 * $Id$
 *   
 * HISTORY
 *   
 *   06/28/00 10:47 <       Brian Jantzen> Rel:ms8m1    SCCA:74542  Delta:81.3
 *   
 *   06/21/00 16:30 <       Brian Jantzen> Rel:ms8m1    SCCA:74307  Delta:81.2
 */

#ifndef __bilbinputh__
#define __bilbinputh__ 1

#ifndef __expmdbstructh__
#include "expmdb_struct.h"
#endif

/*#ifdef __cplusplus
extern "C" {
#endif*/

extern T_Bilan *BIL_binput( FILE *, T_Mesh *, T_statut * );
extern T_Bilan *BIL_allouer_bilan( T_statut * );
extern void	BIL_liberer_bilan ( T_Bilan **bilan );

/*#ifdef __cplusplus
}
#endif*/

#endif
