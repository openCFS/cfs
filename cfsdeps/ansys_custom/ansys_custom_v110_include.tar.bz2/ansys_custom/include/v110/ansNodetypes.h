/* sid 60.3 copy of ansNodetypes.h last changed by jrb on 2006/10/30 15:56:40 */

#include "ansysdef.h"


extern  INT  cCreateAnsNode(INT,INT,INT,INT*);
extern  INT  cDeleteAnsNode(void);
extern  INT  cInquireAnsNode(INT,INT);
extern  INT  cPutAnsNode(INT,INT,DOUBLE*);
extern  INT  cGetAnsNode(INT,INT,DOUBLE*);
extern  INT  cGetAnsNodePtr(INT,INT,DOUBLE**);
extern  INT  cDumpAnsNode(INT);

extern  INT  cPutAnsNodeCnData(INT,DOUBLE*,INT);
extern  INT  cGetAnsNodeCnData(INT,DOUBLE*,INT*);
extern  INT  cGetAnsNodeExt2IntListPtr(INT**);
extern  INT  cGetAnsNodeInt2ExtListPtr(INT**);
extern  INT  cPutAnsNodeFlag(INT,INT,INT);


/****************************************************************
 global-level structure for ANSYS nodes
 ****************************************************************/
struct ansNode_str {               /* Name of the structure                                 */
  INT        tag;                  /* Tag for this instance of the node structure           */
  INT        numDef;               /* Number of defined nodes in this structure             */
  INT        maxDef;               /* Maximum number of defined nodes in this structure     */
  INT        maxNumCoords;         /* Maximum number of coordinate stored for any node      */
  INT       *Internal_to_External; /* Mapping vector for global internal to global external */
  INT       *External_to_Internal; /* Mapping vector for global external to global internal */
  INT       *Internal_to_Domain;   /* Mapping vector for global internal to domain          */
  INT       *Domain_to_Internal;   /* Mapping vector for domain to global internal          */
  nodeData  *dataVec;              /* Array of data for each node                           */
};

#define ansNodeTag(nd)                 (nd->tag)
#define ansNodeNumDef(nd)              (nd->numDef)
#define ansNodeMaxDef(nd)              (nd->maxDef)
#define ansNodeMaxNumCoords(nd)        (nd->maxNumCoords)

#define ansNodeInt2ExtPtr(nd)          (nd->Internal_to_External)
#define ansNodeInt2ExtVec(nd,i)        (nd->Internal_to_External[i])
#define ansNodeExt2IntPtr(nd)          (nd->External_to_Internal)
#define ansNodeExt2IntVec(nd,i)        (nd->External_to_Internal[i])
#define ansNodeInt2DomPtr(nd)          (nd->Internal_to_Domain)
#define ansNodeInt2DomVec(nd,i)        (nd->Internal_to_Domain[i])
#define ansNodeDom2IntPtr(nd)          (nd->Domain_to_Internal)
#define ansNodeDom2IntVec(nd,i)        (nd->Domain_to_Internal[i])

#define ansNodeDataPtr(nd)             (nd->dataVec)
#define ansNodeDataVec(nd,i)           (nd->dataVec+i)



/******************************************************************
 data-level structure for ANSYS nodes (currently only coordinates)
 ******************************************************************/
struct nodeData_str {      /* Name of the structure                                         */
  char        modified;    /* Flag indicating whether this node has been modified or not    */
  char        internal;    /* Flag indicating whether this node is internal to object       */
                           /* NOTE: this internal flag is for object ONLY and is NOT the    */
                           /*       same as the intFlag below                               */
  char        selected;    /* Flag indicating whether this node is selected or not          */
                           /* (this is currently only used by the DB_NEXT inquiry function) */
  INT         masterDof;   /* Master DOF bitmask for this node (if a DOF is a master DOF    */
                           /* then bit-1 is set to one where bit=DOF (1->32)                */
  INT         intFlag;     /* Flag indicating whether this node is external (user-defined)  */
                           /* or internal (created by ANSYS for solution)                   */
  INT         orientFlag;  /* < 0 contact LM node, == 0 no orientation for beam             */
                           /* > 0 this is an orientation node for beam                      */
  INT         numCoords;   /* Number of coordinates stored for this node                    */
  INT         numCnData;   /* Number of nodal contact data for this node                    */
  DOUBLE     *coords;      /* X,Y,Z coordinates along with THXY, THYZ, THZX angles          */
                           /* NOTE:  We only store up to the last non-zero XYZ/ANGLE value  */
  DOUBLE     *cnData;      /* Array of nodal contact data (used by ndpcn/ndgcn)             */
  nxrefData  *nxData;      /* Pointer to node-element cross reference data for this node    */
                           /* NOTE:  If pointer is NULL then no nxref exists for this node  */
  nodeLoad   *nLoad;       /* Pointer to the nodal loads for this node                      */
                           /* NOTE:  If pointer is NULL then no loads exist for this node   */
  nodeResult *nResult;     /* Pointer to the nodal results for this node                    */
                           /* NOTE:  If pointer is NULL then no results exist for this node */
};

#define nodeDataModified(nData)       (nData->modified)
#define nodeDataInternal(nData)       (nData->internal)
#define nodeDataSelected(nData)       (nData->selected)
#define nodeDataMasterDof(nData)      (nData->masterDof)
#define nodeDataIntFlag(nData)        (nData->intFlag)
#define nodeDataOrientFlag(nData)     (nData->orientFlag)
#define nodeDataNumCoords(nData)      (nData->numCoords)
#define nodeDataNumCnData(nData)      (nData->numCnData)

#define nodeDataCoordsPtr(nData)      (nData->coords)
#define nodeDataCoordsVec(nData,i)    (nData->coords[i])

#define nodeDataCnDataPtr(nData)      (nData->cnData)
#define nodeDataCnDataVec(nData,i)    (nData->cnData[i])

#define nodeDataNxrefPtr(nData)       (nData->nxData)
#define nodeDataLoadPtr(nData)        (nData->nLoad)
#define nodeDataResultPtr(nData)      (nData->nResult)

