/* sid 60.1 copy of FEM_cpBgMesh.h last changed by upd111 on 2005/07/21 19:39:42 */

/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 1999 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_cpBgMesh.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_cpBgMesh.h
 *  header file for FEM_cpBgMesh.c
 *
 */
#ifndef FEM_CPBGMESH_INCLUDE
#define FEM_CPBGMESH_INCLUDE

/*----------------- Globally accessible constants  --------------------------*/

/*----------------- Globally accessible data types --------------------------*/

/*----------------- Globally accessible function prototypes -----------------*/

#ifdef __cplusplus
extern "C" {
#endif

                      /* =================================================== */
                      /* === FEM_cpSetUpBgMesh: Create a background mesh that*/
                      /* === can be used to interpolate between 2 area meshes*/
                      /* === Return: INT EXIT_SUCCESS or EXIT_FAILURE        */
                      /* =================================================== */
INT FEM_cpSetUpBgMesh (
   INT source_area,               /* (IN)  source area.                      */
   INT target_area,               /* (IN)  target area.                      */
   NODE_OBJ const *aobj_src_bnd_nodes,  /* (IN)  nodes on source boundary    */
   NODE_OBJ const *aobj_trg_bnd_nodes,  /* (IN)  nodes on target boundary    */
   INT const *a_iel,              /* (IN)  edges on src boundary             */
   INT num_edges,                 /* (IN)  number of edes in a_iel           */
   INT num_bnd_nodes,             /* (IN)  length of 2 arrays                */
   FEM_BOOLEAN line_smoothing,    /* (IN)  TRUE if trg boundary nodes can be */
                                  /*       smoothed.                         */
   FEM_BOOLEAN midnodes,          /* (IN)  TRUE if midnodes in               */
                                  /*       aobj_src_bnd_nodes should be      */
                                  /*       added to the bgmesh.              */
   MESH_OBJ *obj_bgmesh,          /* (OUT) The back ground mesh created.     */
   FEM_BOOLEAN do_progress,       /* (IN)  True if doing status window       */
   FEM_BOOLEAN *abort,            /* (OUT) True if user hit abort.           */
   INT debug  );                  /* (IN)  debug flag                        */

                      /* =================================================== */
                      /* === FEM_cpDeleteBgMesh: Delete the background mesh  */
                      /* === data.                                           */
                      /* === Return: INT EXIT_SUCCESS or EXIT_FAILURE        */
                      /* =================================================== */
void FEM_cpDeleteBgMesh ( void );


                      /* =================================================== */
                      /* === FEM_cpGetSrcBndUv: Get the source area uv       */
                      /* === coordinates of boundary nodes in bg mesh.       */
                      /* === Return: DOUBLE * ptr to array of bnd nodes.     */
                      /* =================================================== */
DOUBLE * FEM_cpGetSrcBndUv ( void  );

                      /* =================================================== */
                      /* === FEM_cpGetTrgBndUv: Get the target area uv       */
                      /* === coordinates of boundary nodes in bg mesh.       */
                      /* === Return: DOUBLE * ptr to array of bnd nodes.     */
                      /* =================================================== */
DOUBLE * FEM_cpGetTrgBndUv ( void  );

#ifdef __cplusplus
}
#endif

#endif

