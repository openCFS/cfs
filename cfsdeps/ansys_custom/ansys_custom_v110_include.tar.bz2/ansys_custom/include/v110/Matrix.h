/* sid 60.1 copy of Matrix.h last changed by upd111 on 2006/10/09 19:56:38 */
////////////////////////////////////////////////////////////////////////////
//                                                                        //
//          Copyright (C) 2001 ANSYS Inc.  All Rights Reserved            //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: Matrix.h $
// $Revision$
// $Date$
// $Author$
//
// Decription:
//
// Header file for matrix.
////////////////////////////////////////////////////////////////////////////

#ifndef __Matrix_H__
#define __Matrix_H__

#ifdef SGIR8K_SYS
    #pragma set woff 1681,1682
#endif

#include "ANS_StandardIncludes.h"


#ifndef  EXIT_SUCCESS
#define  EXIT_SUCCESS  0
#endif
#ifndef  EXIT_FAILURE
#define  EXIT_FAILURE  1
#endif
#ifndef  EXIT_REALLOC
#define  EXIT_REALLOC  2
#endif

#include "MatrixType.h"
#include "MatrixOperation.h"

#endif
