/* sid 60.1 copy of ipcapi.h last changed by qzhang on 2006/07/27 19:03:26 */
/*
 * @author: Glenn Wettlaufer
 * @version: $Revision$
 * @date: $Date$
 * $Id$
 */
#ifndef _INCLUDED_IPCAPI_H_
#define _INCLUDED_IPCAPI_H_

/*  computercfx.h is to define CFX machine name, for Ansys use only */
#include "computercfx.h"

#ifdef __cplusplus
extern "C" {
#endif

/* these error codes must be between -1 and -999 */
#define ERROR_IPC_OK                0
#define ERROR_IPC_INITIALIZATION   -1
#define ERROR_IPC_BADARGS          -2
#define ERROR_IPC_READ             -3
#define ERROR_IPC_WRITE            -4
#define ERROR_IPC_HOSTNAME         -5
#define ERROR_IPC_CREATE           -6
#define ERROR_IPC_CONNECT          -7
#define ERROR_IPC_MEMORYALLOCATION -8
#define ERROR_IPC_UNKNOWN          -9
#define ERROR_IPC_TIMEOUT          -10  /* this is generally not an error */
#define ERROR_IPC_DATATYPE         -11
#define ERROR_IPC_DATALENGTH       -12
#define ERROR_IPC_CORRUPTION       -13
#define ERROR_IPC_DATASIZE         -14

#define ERROR_IPC_MESSAGES  \
{ \
    "Ok", \
    "Can't initialize sockets", \
    "Invalid function arguments", \
    "Read", \
    "Write", \
    "Can't get host name", \
    "Can't create socket", \
    "Can't connect to socket", \
    "Can't allocate memory", \
    "Unknown", \
    "Time out", \
    "Invalid data type", \
    "Invalid data length", \
    "Corrupted data stream", \
    "Datatype size mismatch" \
}


#if !defined CFX5_OS_WINNT && !defined CFX5_OS_WINNT_AMD64 && !defined CFX5_OS_AIX && !defined CFX5_OS_LINUX
#define HAS_FLOAT16
#endif
#undef HAS_FLOAT16


typedef char        int_1;
typedef short       int_2;
typedef int         int_4;
#ifdef CFX5_OS_WINNT
typedef __int64     int_8;
#else
typedef long long   int_8;
#endif
typedef float       float_4;
typedef double      float_8;
#ifdef HAS_FLOAT16
typedef long double float_16;
#endif


/* ipc functions for getting text message for error */
char           *ipc_ErrorMsg(int e);

/* ipc functions for creating and destroying sockets */
int             ipc_GetLocalHostName(char *szName,
                                     int   iNameLen);
int             ipc_CreateServer(int *piPort);
int             ipc_WaitForConnection(int iHandle,
                                      int iTimeOut);
int             ipc_CreateClient(const char *szHostName,
                                 int         iPort,
                                 int         iNumTries);
void            ipc_Close(int iHandle);
int             ipc_GetHostName(int    iHandle,
                                char **szName);
int             ipc_GetHandle(int iHandle);
/* this should only be used for attaching a file to ipc */
int             ipc_SetHandle(int iFH,
                              int iIsSocket);

int             ipc_HasData(int *iHandle,
                            int  iTimeOut);

/* ipc functions for reading and writing built-in data types */
int             ipc_ReadString(int   iHandle,
                               char *szBuffer,
                               int   iCount);
int             ipc_ReadStringExt(int    iHandle,
                                  char **pszBuffer);

int             ipc_WriteString(int         iHandle,
                                const char *szBuffer);

int             ipc_ReadRaw(int   iHandle,
                            void *pvBuffer,
                            int   iCount);
int             ipc_ReadInt1(int    iHandle,
                             int_1 *piBuffer,
                             int    iCount);
int             ipc_ReadInt2(int    iHandle,
                             int_2 *piBuffer,
                             int    iCount);
int             ipc_ReadInt4(int    iHandle,
                             int_4 *piBuffer,
                             int    iCount);
int             ipc_ReadError(int    iHandle,
                              int_4 *piError);
int             ipc_ReadInt8(int    iHandle,
                             int_8 *piBuffer,
                             int    iCount);

int             ipc_WriteRaw(int         iHandle,
                             const void *pvBuffer,
                             int         iCount);
int             ipc_WriteInt1(int          iHandle,
                              const int_1 *piBuffer,
                              int          iCount);
int             ipc_WriteInt2(int          iHandle,
                              const int_2 *piBuffer,
                              int          iCount);
int             ipc_WriteInt4(int          iHandle,
                              const int_4 *piBuffer,
                              int          iCount);
int             ipc_WriteError(int   iHandle,
                               int_4 iError);
int             ipc_WriteInt8(int          iHandle,
                              const int_8 *piBuffer,
                              int          iCount);

int             ipc_ReadFloat4(int      iHandle,
                               float_4 *pfBuffer,
                               int      iCount);
int             ipc_ReadFloat8(int      iHandle,
                               float_8 *pfBuffer,
                               int      iCount);
#ifdef HAS_FLOAT16
int             ipc_ReadFloat16(int       iHandle,
                                float_16 *pfBuffer,
                                int       iCount);
#endif

int             ipc_WriteFloat4(int            iHandle,
                                const float_4 *pfBuffer,
                                int            iCount);
int             ipc_WriteFloat8(int            iHandle,
                                const float_8 *pfBuffer,
                                int            iCount);
#ifdef HAS_FLOAT16
int             ipc_WriteFloat16(int             iHandle,
                                 const float_16 *pfBuffer,
                                 int             iCount);
#endif
int             ipc_Skip(int iHandle,
                         int iDataSize,
                         int iCount);

/* ipc functions for reading and writing tokens */
int             ipc_ReadToken(int  *iHandle,
                              char *cpBuffer,
                              int   iCount,
                              int   iTimeOut);
int             ipc_WriteToken(int         iHandle,
                               const char *szBuffer);

#ifdef __cplusplus
}
#endif

#endif
