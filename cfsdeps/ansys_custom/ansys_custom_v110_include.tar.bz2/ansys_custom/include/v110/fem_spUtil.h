/* sid 60.1 copy of fem_spUtil.h last changed by upd111 on 2005/07/21 19:42:45 */
/* CFILE fem_utils.h        meshing                                 alc */
/* 
 * *** ansys(r) copyright(c) 1999
 * *** ansys, inc.
 */

/*************************************************************************
  PLEASE, UPDATE HISTORY FIELD BELOW WHEN YOU MAKE ANY MODIFICATION
 *************************************************************************
 Description    : Defined here are some general macros, error handling
		  macros and constants.
		  ** Primaraly used on FEM_sp* and fem_sp* files/functions
 Author         : alc
 History        : 09/12/96 - created by alc
 *************************************************************************/

#ifndef SP_UTILS_H
#define SP_UTILS_H


/*************************************************************************
 Misc. Routines.
 *************************************************************************/

                         /* ============================================ */
                         /* === FEM_spCompareNormals: compares the       */
                         /* === normal at a vertex (average normal of    */
                         /* === connected facets) and the normal of a    */
                         /* === facet through their dot product to see   */
                         /* === if vertex and facet face each other.     */
                         /* === Return: 0  - if vertex and facet DO NOT  */
                         /* ===              face each other             */
                         /* ===         1  - otherwise                   */
                         /* ============================================ */
INT FEM_spCompareNormals (
   const VERTEX_TYP *ps_vertex,    /* (IN) vertex */
   const RECTANGLE_TYP *ps_rect  );/* (IN) rectangle that contains a facet */


/*************************************************************************
 GLOBALS AND CONSTANTS
 *************************************************************************/

#ifndef _ONETHIRD
#define _ONETHIRD 0.333333333333
#endif

#ifndef _TWOTHIRDS
#define _TWOTHIRDS 0.666666666667
#endif

/*************************************************************************
 NUMERICAL MACROS
 *************************************************************************/

#ifndef ABS
#define ABS(a) ((a) > 0 ? (a) : -(a))
#endif

#ifndef MAX3
#define MAX3(a,b,c) ((a) > (b) ? ((a) > (c) ? (a) : (c)) : ((b) > (c) ? \
							    (b) : (c)))
#endif

#ifndef MAX3_POINTER
#define MAX3_POINTER(a,b,c) (*(a) > *(b) ? ((*(a) > *(c)) ? a : c) : \
			     ((*(b) > *(c)) ? b : c))
#endif

#ifndef MIN3
#define MIN3(a,b,c) ((a) < (b) ? ((a) < (c) ? (a) : (c)) : ((b) < (c) ? \
							    (b) : (c)))
#endif

#ifndef MIN3_POINTER
#define MIN3_POINTER(a,b,c) (*(a) < *(b) ? ((*(a) < *(c)) ? a : c) : \
			    ((*(b) < *(c)) ? b : c))
#endif

#endif

