/* sid 60.1 copy of MOD_Table.h last changed by smarguer on 2006/02/09 09:12:51 */
/* MOD_Table.h CADOE  */
/*
 *  MOD_numnoe.h -
 *
 *  $Id$
 *   
 * HISTORY
 *   
 *   06/28/00 10:47 <       Brian Jantzen> Rel:ms8m1    SCCA:74542  Delta:81.3
 *   
 *   06/21/00 16:30 <       Brian Jantzen> Rel:ms8m1    SCCA:74307  Delta:81.2
 */
#ifndef __modtableh__
#define __modtableh__ 1

#ifndef __expmdbstructh__
#include "expmdb_struct.h"
#endif
#ifndef __modnumnoeh__
#include "MOD_numnoe.h"
#endif

#ifndef __CADOE_H__
#include "cadoe.h"
#endif

/*#ifdef __cplusplus
extern "C" {
#endif*/
  extern T_Htable	*MOD_creer_table_hash ( int, T_statut * );
  extern T_statut	HASH_ajouter_objet ( T_Htable *, int, void * );
  extern T_statut	HASH_ajouter_objet_2_cles ( T_Htable *table, int num1, int num2, void *element );
  extern T_statut	HASH_effacer_objet ( T_Htable *, int );
  extern void		*HASH_get_objet ( T_Htable *, int );
  extern void		*HASH_get_objet_2_cles ( T_Htable *, int, int );
  extern T_statut HASH_effacer_objet_2_cles ( T_Htable *table, int num1, int num2 );
  extern void		HASH_detruit_table ( T_Htable * );

  extern T_Element	*MOD_GetElement( T_Mesh *, int );
      
/*#ifdef __cplusplus
}
#endif*/


#endif
