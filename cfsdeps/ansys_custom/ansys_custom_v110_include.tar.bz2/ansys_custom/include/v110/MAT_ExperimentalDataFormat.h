/* sid 60.1 copy of MAT_ExperimentalDataFormat.h last changed by upd111 on 2006/10/09 19:56:31 */
////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         Copyright (C) 2001 ANSYS Inc.  All Rights Reserved             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MAT_ExperimentalDataFormat.h $
// $Revision$ 7.0
// $Date$ March 28 2002
// $Author$ rjayasee/jlo
//
// Description :
//      This class describes the format of each ExperimentalData object.
// Currently this is implemented to store information about each column in the
// experimental data. Infomation like name, format ( integer/double/string),
// units.
//
//////////////////////////////////////////////////////////////////////////////

#if !defined(MAT_EXPERIMENTALDATAFORMAT_H)
#define MAT_EXPERIMENTALDATAFORMAT_H

#include "ANS_StandardIncludes.h"
#include "MAT_Api.h"


class MAT_ExperimentalDataFormat  
{
public:

    

    MAT_ExperimentalDataFormat() ;
    //Constructor

    void SetName( ANS_String const& oName ) ;
    //R-void
    //I-oName
    //I-Name of the Graph
    //F-Sets the name of the graph

    ANS_String const& GetName() const ;
    //R-Returns the name of the graph

    void SetVariableNames( vector<ANS_String*> const& oVariableNames ) ;
    //R-void
    //I-oVariableNames
    //I-List of variable names
    //F-Set the Name of each variable in the Experimental Data

    void GetAttributeNames( vector<ANS_String> & pAttNames ) const ;
    //R-void
    //I-pAttNames
    //I-List of attribute names
    //F-Gets the Names of each attribute in the Experimental Data Format

    void GetVariableNames( vector<ANS_String*> const *& pVariableNames ) const ;
    //R-void
    //I-pVariableNames
    //I-List of variable names
    //F-Gets the Names of each variable in the Experimental Data

    bool SetAttributeValue( ANS_String const& oAttrName,
                            ANS_String const& oAttrValue ) ;
    //R bool
    //R-True of false
    //I oAttrName
    //I-Name of the Attribute
    //I oAttrValue
    //I-Value of the Attribute
    //- Get the String Value of an attribute

    bool SetAttributeValue( ANS_String const& oAttrName,
                            double const& oAttrValue ) ;
    //R bool
    //R-True of false
    //I oAttrName
    //I-Name of the Attribute
    //I oAttrValue
    //I-Value of the Attribute
    //- Get the Real/Double Value of an attribute

    bool SetAttributeValue( ANS_String const& oAttrName,
                            INT const& oAttrValue ) ;
    //R bool
    //R-True of false
    //I oAttrName
    //I-Name of the Attribute
    //I oAttrValue
    //I-Value of the Attribute
    //- Get the Integer Value of an attribute

    bool GetAttributeValue( ANS_String oAttrName,
                            ANS_String& oAttrValue ) const ;
    //R bool
    //R-true / false
    //I oAttrName
    //I-Name of the Attribute
    //O oAttrValue
    //O-Value of the Attribute
    //- Get the String Value of an attribute

    bool GetAttributeValue( ANS_String oAttrName,
                            INT& oAttrValue )  const ;
    //R bool
    //R-true / false
    //I oAttrName
    //I-Name of the Attribute
    //O oAttrValue
    //O-Value of the Attribute
    //- Get the Integer Value of an attribute

    bool GetAttributeValue( ANS_String oAttrName,
                            double& oAttrValue ) const ;
    //R bool
    //R-true / false
    //I oAttrName
    //I-Name of the Attribute
    //O oAttrValue
    //O-Value of the Attribute
    //- Get the real(as in real numbers) Value of an attribute

    void Print() const ;
    //Print function
        
    virtual ~MAT_ExperimentalDataFormat();

private:

   ANS_String m_oExperimentalDataName ;
   // Response Name
   // Should this be an enum data type
   // Advantage is string is a possibility for a user-defined ConstitutiveModel
   // that can be fit into this framework

    vector<ANS_String*> m_oVariableNames ;
    // Name of each variable

    vector<MAT_CFAttribute*> m_oAttributeVector ;
    // List of Attribute of the Experiment
};

#endif // !defined(MAT_EXPERIMENTALDATAFORMAT_H)
