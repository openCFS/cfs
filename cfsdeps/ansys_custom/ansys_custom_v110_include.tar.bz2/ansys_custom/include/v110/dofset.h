/* sid 60.1 copy of dofset.h last changed by upd111 on 2006/10/09 19:55:41 */
#ifndef _DOFSET_H_
#define _DOFSET_H_

class DofSet {
  protected:
    int flags;
  public:
    static int max_known_dof; // 8
    static int 
      Xdisp,
      Ydisp,
      Zdisp,
      XYZdisp,
      Xrot,
      Yrot,
      Zrot,
      XYZrot,
      Temp,
      Helm;
    // constructors
    DofSet()      { flags = 0; }
    DofSet(int t) { flags = t; }

    DofSet & operator|=(DofSet &ds) { flags |= ds.flags; return *this; }

    // mark marks given dofs as being used
    void mark(int dofs) { flags |= dofs; }

    void unmark(int dofs) { flags = flags ^ (flags & dofs); }

    // tests if all the given dofs are present
    int test(int dofs) { return (flags & dofs) == dofs ; }

    // see presence of at least one dof
    int contains(int dofs) { return (flags & dofs); }

    // counts the number dofs marked in this node
    int count() ;

    int number(DofSet, int *); // This routine complements the previous
                  // one, numbering all the DOFs in the first argument

    // Locates a dof in the current set. Only works for single dofs
    // i.e. result is undefined for composites such as XYZrot and XYZdisp
    int locate(int dof);

    int list() { return flags; }

    DofSet operator & (DofSet d) { return DofSet(flags & d.flags); }
};

class Elemset;

class EqNumberer {
  protected:
    int numnodes; 	// total number of nodes
    int *node_offset; 	// Where the nodes are
    int *node_num_dofs; // Number of dofs associated with a node
    int *renummap;    	// Renumbering mapping of the nodes

  public:
    // Return the total number of degrees of freedom
    int size(){ return node_offset[numnodes]; }

    // Return the number of nodes
    int numNodes() { return numnodes; }

    // Return the first dof of a node
    int firstdof(int node) 
     { return (node_num_dofs[node] > 0) ? node_offset[node] : -1; }

    // Return the weight of a node (its number of dofs)
    int weight(int n) { return node_num_dofs[n]; }

    int *allOffsets() { return node_offset; }
};

class DofSetArray : public EqNumberer {
  protected:
    DofSet *dofs;
    int *rowcolnum;
    int *invrowcol;
    int *dofType; // 0 = translational, 1 = rotational

    DofSetArray() {}

  protected:
    void  makeOffset();
  public:
    DofSetArray(int nnodes, Elemset &elearray, int *renumtable=0);

    ~DofSetArray();

    // locate a dof for a given node
    int locate(int node, int dof);
    int number(int, DofSet, int *);

    // Mark dofs for a node
    void mark(int node, int dof);

    // Return the DofSet of a node
    DofSet &operator [](int i) { return dofs[i]; }

    int getRCN(int dof)   { return rowcolnum[dof]; }
    int invRCN(int dof)   { return invrowcol[dof]; }

    int* getUnconstrNum() { return rowcolnum; }
    int* getConstrndNum() { return invrowcol; }

    int* makeDofTypeArray(); // creates and returns dofType array
                             // 0 = translational, 1 = rotational

    friend class ConstrainedDSA;
};

class BCond;
class ComplexBCond;

class ConstrainedDSA : public DofSetArray {
  public:
    ConstrainedDSA(DofSetArray &, int, BCond *);
    ConstrainedDSA(DofSetArray &,DofSetArray &, int, BCond *,int);
    ConstrainedDSA(DofSetArray &, int, BCond *, int *bc);
    ConstrainedDSA(DofSetArray &, int, ComplexBCond *, int *bc);
    ConstrainedDSA(DofSetArray &dsa, BCond *bcdata, int nbc,
                               ComplexBCond *bcd, int nbcd, int *bc);
};

// Auxiliary definitions
#define BCFREE  0
#define BCLOAD  1
#define BCFIXED 2

class SimpleNumberer : public EqNumberer {
   public:
      SimpleNumberer(int nnodes, int *renumb = 0);
      void setWeight(int, int);
      void makeOffset();
};
#endif
