/* sid 60.1 copy of FEM_MappedTriMesh.h last changed by upd111 on 2005/07/21 19:38:50 */

/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 1999 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_MappedTriMesh.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_MappedTriMesh.h
 *  header file for FEM_MappedTriMesh.c
 *
 */
#ifndef FEM_MAPPED_TRI_MESH_INCLUDE
#define FEM_MAPPED_TRI_MESH_INCLUDE

#ifdef __cplusplus
extern "C" {
#endif


/*----------------- Globally accessible function prototypes -----------------*/

                           /* ============================================== */
                           /* === fem_mtCreateTris: process pattern for      */
                           /* === mapped tri meshing                         */
                           /* === Return: INT  EXIT_SUCCESS or EXIT_FAILURE  */
                           /* ============================================== */
INT FEM_mtCreateTris (
   INT *a_areas,
   INT num_areas,
   INT pattern  );         /* (IN) map mesh pattern                           */
                           /*      0 maximize minimum angle                   */
                           /*      1 unidirectional TR BL                     */
                           /*      2 unidirectional TL BR                     */
                           /*      3 herringbone R->L                         */
                           /*      4 herringbone L->R                         */
                           /*      5 herringbone B->T                         */
                           /*      6 herringbone T->B                         */
                           /*      7 union-jack  closed                       */
                           /*      8 union-jack  open                         */
#ifdef __cplusplus
}
#endif

#endif
