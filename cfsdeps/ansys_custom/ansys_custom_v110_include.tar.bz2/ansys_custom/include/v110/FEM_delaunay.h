/* sid 60.1 copy of FEM_delaunay.h last changed by upd111 on 2005/07/21 19:39:47 */
/*  FEM_delaunay.h */
/*
 * *** ansys(r) copyright(c) 1999
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_delaunay.h
 *  header file for FEM_delaunay.c
 *
 */
#ifndef FEM_DELAUNAY_INCLUDE
#define FEM_DELAUNAY_INCLUDE

#define determ(p1,q1,p2,q2,p3,q3)\
     ((q3)*((p2)-(p1)) + (q2)*((p1)-(p3)) + (q1)*((p3)-(p2)))

#define SIZE_NEIGHTRI 100
#define TOL        DBL_EPSILON

/* === Enumeration for the 2D entities */

typedef enum {FEMNODE_ENTITY,
              EDGE_ENTITY,
              FACE_ENTITY,
              NO_ENTITY} MESH_ENTITY_ENUM;

/* === Circumcircle structure (for each face) */

typedef struct sBBox {
    DOUBLE  x_min;
    DOUBLE  y_min;
    DOUBLE  x_max;
    DOUBLE  y_max;
} sBBox;

typedef struct CCIRC_TYP *CCIRC_PTYP;
typedef struct CCIRC_TYP{
   INT flag;              /* visited flag */
   DOUBLE r2;             /* radius squared of circumcircle */
   DOUBLE cx, cy;         /* center of circumcircle */
   DEQUE_OBJ obj_deque;   /* deque where tri is contained (based on worst angle) */
   ADDRESS_TYP p_location; /* location in deque */
   sBBox       sBox;
} CCIRC_TYP;

/*----------------- Globally accessible function prototypes -----------------*/

#ifdef __cplusplus
extern "C" {
#endif

                             /* === FEM_delaunay: Do 2D unconstrained        */
                             /* === Delaunay triangulation on specified nodes*/
INT FEM_delaunay (
   MESH_OBJ obj_mesh,                  /* nodes only to be tesselated        */
   INT anum,                           /* area number                        */
   INT use_scalar_values );            /* flag - 0 = no scalar values        */
                                       /* 1 = insert nodes regardless of     */
                                       /*     scalar value                   */
                                       /* 2 = insert nodes only if scalar at */
                                       /*     node is different than         */
                                       /*     interpolated scalar at node    */

                             /* === FEM_deDeleteDelaunayMesh: function to    */
                             /* === delete the delaunay mesh and its         */
                             /* === associated data structures               */
void FEM_deDeleteDelaunayMesh ( void  );

                             /* === FEM_deLocatePoint: find the triangle     */
                             /* === (or edge, or node) containing the point  */
                             /* === NOTE: use FEM_deSetStartTriangle to set  */
                             /* === the initial triangle for searching.  If  */
                             /* === NULL, will start from first tri in list  */
MESH_ENTITY_ENUM FEM_deLocatePoint (
   DOUBLE x, DOUBLE y,                 /* the point to find */
   ADDRESS_TYP *p_obj_entity,          /* the node, edge or face the point   */
                                       /* is on                              */
   VECTOR3D *ps_bary  );               /* return barycentric coords          */

                             /* === FEM_deExhaustiveLocatePoint: find the    */
                             /* === triangle (or edge, or node) containing   */
                             /* === the point using exhaustive search        */
                             /* === Can be called if FEM_deLocatePoint fails */
MESH_ENTITY_ENUM FEM_deExhaustiveLocatePoint (
   DOUBLE x, DOUBLE y,                 /* the point to find */
   ADDRESS_TYP *p_obj_entity,          /* the node, edge or face the point   */
                                       /* is on                              */
   VECTOR3D *ps_bary  );               /* return barycentric coords          */

                             /* === FEM_deFindClosestTri:  After calling     */
                             /* === FEM_deExhaustiveLocatePoint, we still    */
                             /* === have been unable to find which tri       */
                             /* === contains a point probably because this   */
                             /* === point lies just outside of the domain.   */
                             /* === Find the triangle that is closest to     */
                             /* === containing this point.                   */
MESH_ENTITY_ENUM FEM_deFindClosestTri (
   DOUBLE x, DOUBLE y,                 /* the point to find */
   ADDRESS_TYP *p_obj_entity,          /* the node, edge or face the point   */
                                       /* is on                              */
   VECTOR3D *ps_bary  );               /* return barycentric coords          */


                             /* === FEM_deCircumCircle: compute the radius   */
                             /* === squared and circum-circle center of      */
                             /* === three 2D points                          */
INT FEM_deCircumCircle (
   DOUBLE x0, DOUBLE y0,               /* tri vertex 0                       */
   DOUBLE x1, DOUBLE y1,               /* tri vertex 1                       */
   DOUBLE x2, DOUBLE y2,               /* tri vertex 2                       */
   DOUBLE *p_xc, DOUBLE *p_yc,         /* return circumcenter                */
   DOUBLE *p_rad2  );                  /* return radius                      */

                             /* === FEM_deNaturalNeighborTris: return an     */
                             /* === array of tris which are natural          */
                             /* === neighbors of the given point (all        */
                             /* === triangles whose circumcircle contain the */
                             /* === point)                                   */
INT FEM_deNaturalNeighborTris (
   DOUBLE x, DOUBLE y,                 /* the point                          */
   FACE_OBJ **pa_obj_neightri,         /* return array of faces (allocated   */
                                       /* here) whose circumcircle contain   */
                                       /* the point                          */
   INT *p_num_neightri,                /* return num of tri in               */
                                       /* pa_obj_neightri                    */
   MESH_ENTITY_ENUM *p_entity_type,    /* return type of entity where        */
                                       /* point lies (node, edge, or face)   */
   ADDRESS_TYP *p_obj_entity,          /* return node, edge or face object   */
                                       /* where point lies                   */
   INT iRound );                       /* round of trying to insert          */

                             /* === FEM_deNNTrisAtNode: same as              */
                             /* === FEM_deNaturalNeighborTris except         */
                             /* === the point is a node in the current       */
                             /* === tessellation                             */
INT FEM_deNNTrisAtNode (
   NODE_OBJ obj_node,                  /* the node                           */
   FACE_OBJ **pa_obj_neightri,         /* return array of faces (allocated   */
                                       /* here) whose circumcircle contain   */
                                       /* the point                          */
   INT *p_num_neightri  );             /* return num of tri in               */
                                       /* pa_obj_neightri                    */

                             /* === FEM_deNewCCirc: return pointer to one    */
                             /* === circum-circle structure handle all       */
                             /* === allocation, reallocation                 */
CCIRC_PTYP FEM_deNewCCirc ( void  );
             
                             /* === FEM_deDeleteCCirc: free a ccirc by       */
                             /* === placing it back on the available ccirc   */
                             /* === stack                                    */
void FEM_deDeleteCCirc (
   CCIRC_PTYP p_ccirc  );              /* address of the ccirc to be freed   */

                             /* === FEM_deDeleteAllCCirc: get rid of any     */
                             /* === ccirc structures that remain             */
INT FEM_deDeleteAllCCirc ( void  );

                             /* === FEM_deTolerance: function to retreive    */
                             /* === the tolerance for the Delaunay mesh      */
DOUBLE FEM_deTolerance ( void  );

                             /* === FEM_deSetTolerance: function to set      */
                             /* === the tolerance for the Delaunay mesh      */
                             /* === and point location                       */
void FEM_deSetTolerance ( 
   DOUBLE tol  );                      /* the tolerance                      */

                             /* === FEM_deDefineCircumCircle: define         */
                             /* === ccirc data and the the structure         */
INT FEM_deDefineCircumCircle ( FACE_OBJ obj_face  );

                             /* === Do an insert into the Delaunay           */
                             /* === triangulatioon using a Watson algorithm  */
INT FEM_deWatsonInsert (
   NODE_OBJ obj_node,                  /* the node object to insert          */
   FACE_OBJ *aobj_neightri,            /* tris whose ccirc contain the node  */
   INT num_neightri,                   /* size of aobj_neightri              */
   INT *piDid );

                             /* === FEM_deSetStartTriangle: Set the starting */
                             /* === triangle for the point location algorithm*/
void FEM_deSetStartTriangle (
   FACE_OBJ obj_face  );               /* The starting tri                   */

                             /* === FEM_deStartTriangle: Get the starting    */
                             /* === triangle for the point location algorithm*/
FACE_OBJ FEM_deStartTriangle ( void  );

                             /* === FEM_deGetBounds: get the bounds of the   */
                             /* current triangulation (not including the the */
                             /* bounding triangles)                          */
void FEM_deGetBounds (
   DOUBLE *p_minx,
   DOUBLE *p_miny,
   DOUBLE *p_maxx,
   DOUBLE *p_maxy  );

void FEM_deSetBounds (    
   DOUBLE minx,
   DOUBLE miny,
   DOUBLE maxx,
   DOUBLE maxy,
   DOUBLE *pdRatio );


                             /* === FEM_deInsertOneNode: Insert one node into*/
                             /* === the Delaunay mesh.  Can conditionally    */
                             /* === insert based on use_scalar argument      */
INT FEM_deInsertOneNode ( 
   NODE_OBJ obj_node,                  /* node to insert                     */
   INT use_scalar,                     /* 0 = always insert node             */
                                       /* 1 = insert node only if scalar     */
                                       /*     value asscociated with node    */
                                       /*     (z field of obj_node) is more  */
                                       /*     than 5% different from the     */
                                       /*     interpolated value             */ 
   INT *piDid,
   INT iRound);                        /* round of trying insert the node    */

                             /* === FEM_deInitBox: Initialize a bounding box */
                             /* === for the triangulation                    */
INT FEM_deInitBox ( 
   NODELIST_OBJ obj_nlist,             /* the current node list              */
   DOUBLE minx,                        /* the bounding box                   */
   DOUBLE maxx,
   DOUBLE miny,
   DOUBLE maxy,
   DOUBLE maxz,
   NODE_OBJ aobj_boxnodes[4]  );       /* array of nodes inserted            */

                             /* === FEM_deDeleteBox: delete nodes, edges and */
                             /* === tris associated with the bounding box    */  
INT FEM_deDeleteBox ( 
   NODELIST_OBJ obj_nlist,
   NODE_OBJ aobj_boxnodes[4]  );


#ifdef __cplusplus
}
#endif

#endif
