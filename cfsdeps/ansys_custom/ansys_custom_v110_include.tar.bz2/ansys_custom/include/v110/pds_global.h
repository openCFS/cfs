/* sid 60.1 copy of pds_global.h last changed by jtm on 2006/05/15 19:44:42 */
/* ---------------------------------------------------------------------- */
/* *** copyright(c) 2006 SAS IP, Inc.  All rights reserved.                                         */
/* *** ansys, inc.                                                        */
/* ---------------------------------------------------------------------- */

/*
 *    author/date: Stefan Reh 03-01-2000
 *
 *    primary function:
 *
 *        header for global function 
 *        definition of global data
 *
 *    Notice - This file contains ANSYS Confidential information ***
 *
 */

#ifndef  _PDS_GLOBAL_H_
#define  _PDS_GLOBAL_H_

#include "pds_constants.h"
#include "rs_constants.h"
#include "pds_c_types.h"
#include "rs_c_types.h"
#include "pds_macros.h"
#include "rs_macros.h"
#include "pds_c_prototypes.h"
#include "pds_debug.h"


/* Declaration of global variables */    
/* =============================== */    

/* for pds_database */
extern int     Pds_OpenPdsDB;
extern int     Pds_SaveResuFlag;
extern char    Pds_SaveResuNam[PDS_FILENAMELENGTH];
extern char    Pds_SaveResuExt[PDS_EXTENSIONLENGTH];
extern char    Pds_SaveResuDir[PDS_DIRECTORYLENGTH];

/* for pds_pre */
extern int     Pds_AnlFlag;
extern char    Pds_AnlNam[PDS_FILENAMELENGTH];
extern char    Pds_AnlExt[PDS_EXTENSIONLENGTH];
extern char    Pds_AnlDir[PDS_DIRECTORYLENGTH];

extern int     Pds_NumRv;
extern int     Pds_MaxRv;
extern int     Pds_NumCorrPairs;
extern int     Pds_MaxCorrPairs;
extern int     Pds_NumRp;           
extern int     Pds_MaxRp;

/* for pds_methods */
extern long    Pds_seed;

/* for pds_run */
extern int     Pds_ContinuedLoopings;
extern int     Pds_InterActiveFlag;
extern int     Pds_MenuOnFlag;

/* solution variables/ used in pds_run/pds_post */
extern char    Pds_jobname[PDS_FILENAMELENGTH];
extern int     Pds_SoluSetCount;
extern int     Pds_SoluSetLastIdx;

/* for pds_responsesurfaces */
extern int     Pds_NumRSSets;
extern int     Pds_RSSetLastIdx;
extern int     Pds_MaxRSInp;
extern int     Pds_MaxRSOut;

/* for pds_post */
extern int     Pds_ResultSetLastIdx;
extern char    Pds_title[PDS_TITLELENGTH];

/* for pds_debug */
extern int     Pds_debug;

/* Definitions of the default values */
extern int     Pds_default_num_sim;
extern int     Pds_default_num_rep;
extern int     Pds_default_VROpt;
extern int     Pds_default_IntervalOpt;
extern int     Pds_default_AutoStopOpt;
extern double  Pds_default_AccMean;
extern double  Pds_default_AccStdev;
extern int     Pds_default_CheckFreq;
extern int     Pds_default_SeedOption;
extern int     Pds_default_rsm_option;
extern int     Pds_default_num_imp;
extern double  Pds_default_imp_value;
extern int     Pds_default_rsm_loops;
extern double  Pds_default_ccd_prob1;
extern double  Pds_default_ccd_prob2; 
extern double  Pds_default_ccd_prob3;
extern double  Pds_default_ccd_prob4;
extern double  Pds_default_ccd_prob5;
extern double  Pds_default_bbm_prob1;
extern double  Pds_default_bbm_prob2;
extern double  Pds_default_bbm_prob3;

/* for pds_run */
extern int     Pds_default_parallel_option;
extern int     Pds_default_nfail;

/* for pds_run (running serial executions) */
extern FILE    *Pds_SampleFilePtr;
extern int      Pds_system_rv_count;
extern double  *Pds_system_rv_values;
extern char    *Pds_system_rv_names;

/* the user settings are used in various places (pds_get/pds_database/pds_pre/pds_run */
extern PDS_UserSettings       Pds_UserSettings[1];

/* for pds_pre */
extern PDS_RvData             *Pds_RvDatas;
extern PDS_CorrPair           *Pds_CorrPairs;
extern PDS_RpData             *Pds_RpDatas;
extern PDS_CCDLevels          *Pds_CCDLevels;
extern PDS_BBMLevels          *Pds_BBMLevels;
extern PDS_ResultsFileData    Pds_ResultsFileDatas[PDS_TOTALRUN];
extern PDS_SoluSet            Pds_SoluSets[PDS_TOTALRUN];

/* for pds_responsesurfaces */
extern RS_ResponseSurface     ResponseSurfaces[PDS_TOTALRUN];
extern RS_PostSample          Pds_RSPostSamples[PDS_TOTALRUN];

/* for pds_debug */
extern FILE    *file_debug;

#endif  /* _PDS_GLOBAL_H_ */
