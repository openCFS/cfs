/* sid 60.10 copy of FEM_Public.h last changed by upd111 on 2006/10/04 14:00:46 */
/* ********************************** */
/* *** ansys(r) copyright(c) 1999 *** */
/* *** ansys, inc.                *** */
/* ********************************** */

/*  FEM_public.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/* 
 *  FEM_public.h
 *  Finite element mesh module
 *
 */
#ifndef FEM_PUBLIC
#define FEM_PUBLIC

#ifndef DSPACE_CMDB
#include "globals.h"
#endif
#include "FEM_publicElementDefinition.h"
#ifndef EXTERNAL_COMPILE
typedef INT BOOLEAN;
#endif

typedef struct { DOUBLE x, y, z; } VECTOR3D;
typedef struct { DOUBLE x, y; } POINT2D;

#if !defined (FUJITSU_SYS)
#if !(defined (MAINWIN) && (__GNUC_MINOR__==4) && defined(__cplusplus))
#ifndef min
#define min(A,B) (((A)<(B))?(A):(B))
#ifndef MIN
#define MIN min
#endif
#endif

#ifndef MIN
#define MIN min
#endif

#ifndef max
#define max(A,B) (((A)<(B))?(B):(A))
#ifndef MAX
#define MAX max
#endif
#endif

#ifndef MAX
#define MAX max
#endif
#endif
#endif

#ifndef sqr
#define sqr(x) ((x)*(x))
#endif

#ifndef EXIT_ABORT
#define EXIT_ABORT -9999
#endif

#ifndef STANDALONE_DELAUNAY
#define MAX_FACE_PER_NODE 200
#else
#define MAX_FACE_PER_NODE 1500
#endif

#define MAX_ELEM_PER_EDGE 200
#ifndef TINY100
#define TINY100 1.0e-100
#endif

#include "FEM_errors.h" 

/*
 * === Mesh data representation definitions.
 */

typedef enum{SMALL_MESH, 
             STANDARD_MESH, 
             BIG_MESH,
             UNDEFINED_MESH} MESH_ENUM;
#ifdef __cplusplus
extern "C" {
#endif

extern MESH_ENUM g_meshtype;  /* initialized in FEM_NewMesh */
extern INT g_currentprocess;

#ifdef __cplusplus
}
#endif

#define PROC_REFINEMENT   1
#define PROC_IMPROVEMENT  2
#define PROC_MESHING      3
#define PROC_VSWEEP       4
#define PROC_HEXTOTET     5
#define PROC_UNKNOWN     -1

/*
 * === Possible element shapes
 */


/*
 * === Global Verification flag for debugging
 */
extern INT g_verify;

/*
 * === Entity "Objects"
 * --- Notes: An object is simply a pointer to a structure.  It is called an
 * --- object because it should never be dereferenced directly.  To set and
 * --- get info about the object, C++ style reader and writer functions are
 * --- used.  Since we are allowing multiple data representations
 * --- of the same object types, all objects have been typedeffed to void*.
 * --- In order to access info in the structure represented by the object, it
 * --- is first necessary to cast the object to one of the _PTYP pointers
 * --- defined in fem_elStruct.  Because it should be unnecessary in general
 * --- for most applications to reference directly the info in the object,
 * --- only private fem_* functions and macros should need to cast an object
 */

#if defined ansANSI || defined DSPACE_CMDB || defined ANSYSDSPACE_CMDB
#define ADDRESS_TYP void*
#else
#define ADDRESS_TYP char*
#endif 

typedef ADDRESS_TYP ELEMENT_OBJ;
typedef ADDRESS_TYP FACE_OBJ;
typedef ADDRESS_TYP EDGE_OBJ;
typedef ADDRESS_TYP NODE_OBJ;

typedef ADDRESS_TYP ELEMENTLIST_OBJ;
typedef ADDRESS_TYP FACELIST_OBJ;
typedef ADDRESS_TYP EDGELIST_OBJ;
typedef ADDRESS_TYP NODELIST_OBJ;
typedef ADDRESS_TYP ANY_OBJ;

typedef ADDRESS_TYP MESH_OBJ;

typedef ADDRESS_TYP DEQUE_OBJ;


/*
 * General Mesh Prototypes
 */

#ifdef __cplusplus
extern "C" {
#endif


/*
 * === Define the standard node, edge and face arrangement for 
 * === each type of element
 * --- Note: These arrays actually reside in the file FEM_Public.c
 * --- They are initialized there as well.  The mesh topology arrays
 * --- are only externed in this file.
 */
/* === TRI === */

extern FEM_BOOLEAN TET_FACE_EDGE_USE[4][3];
extern FEM_BOOLEAN WEDGE_FACE_EDGE_USE[5][4];
extern FEM_BOOLEAN PYRAMID_FACE_EDGE_USE[5][4];
extern FEM_BOOLEAN HEX_FACE_EDGE_USE[6][4];



                             /* === FEM_NewMesh: Initialize a new mesh       */
                             /* === must be called before any other mesh call*/
MESH_OBJ FEM_NewMesh ( 
   MESH_ENUM );                       /* type of data representation to use */

                             /* === FEM_DeleteMesh: Delete the mesh          */
                             /* === called once after finishing with mesh    */
INT FEM_DeleteMesh ( void );
                             /* === FEM_VerifyOn: turn on verify flag        */
void FEM_VerifyOn ( void );
                             /* === FEM_VerifyOff: turn off verify flag      */
void FEM_VerifyOff ( void );

void FEM_KillCMDB ( void );

#ifdef __cplusplus
}
#endif

/*
 *  Mesh Object Macros
 */

/*============================================================================*/
/* === Macro: FEM_meshGenericPointer_MAC
 * === Author: sjo
 * === Description: retreive the generic pointer from the mesh object
 * === Arguments:
 * === Return: (void *) a generic pointer (must be caste to correct type)
 */
#ifdef NO_MESH_MAC
ADDRESS_TYP FEM_meshGenericPointer_MAC (   );
#else
#define FEM_meshGenericPointer_MAC( )\
   ((g_meshtype == STANDARD_MESH) ?\
      (((MESH_PTYP)(gps_mesh))->p_info) :\
   NULL)
#endif

/*============================================================================*/
/* === Macro: FEM_meshSetGenericPointer_C
 * === Author: sjo
 * === Description: set a generic pointer into the mesh object
 * === Arguments:
 *     ADRESS_TYP obj_entity   any object entity or generic void pointer
 * === Return: void
 */
#ifdef NO_MESH_MAC
void FEM_meshSetGenericPointer_C ( INT obj_entity  );
#else
#define FEM_meshSetGenericPointer_C( obj_entity )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((MESH_PTYP)(gps_mesh))->p_info = (ADDRESS_TYP)obj_entity;\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }
#endif
/*============================================================================*/
/* === Macro: FEM_ElementList_C
 * === Author: sjo
 * === Description: return the element list for the mesh
 * === Arguments: none
 * === Return: ELEMENTLIST_OBJ obj_elist      the element list object
 */
#define FEM_ElementList_C()\
   ((g_meshtype == STANDARD_MESH) ?\
      (ELEMENTLIST_OBJ)(((MESH_PTYP)(gps_mesh))->ps_elist) :\
   NULL)

/*============================================================================*/
/* === Macro: FEM_FaceList_C
 * === Author: sjo
 * === Description: return the face list for the mesh
 * === Arguments: none
 * === Return: FACELIST_OBJ obj_flist      the face list object
 */
#define FEM_FaceList_C()\
   ((g_meshtype == STANDARD_MESH) ?\
      (FACELIST_OBJ)(((MESH_PTYP)(gps_mesh))->ps_flist) :\
   NULL)

/*============================================================================*/
/* === Macro: FEM_EdgeList_C
 * === Author: sjo
 * === Description: return the edge list for the mesh
 * === Arguments: none
 * === Return: EDGELIST_OBJ obj_elist      the edge list object
 */
#define FEM_EdgeList_C()\
   ((g_meshtype == STANDARD_MESH) ?\
      (EDGELIST_OBJ)(((MESH_PTYP)(gps_mesh))->ps_edlist) :\
   NULL)

/*============================================================================*/
/* === Macro: FEM_NodeList_C
 * === Author: sjo
 * === Description: return the node list for the mesh
 * === Arguments: none
 * === Return: NODELIST_OBJ obj_nlist      the node list object
 */
#define FEM_NodeList_C()\
   ((g_meshtype == STANDARD_MESH) ?\
      (NODELIST_OBJ)(((MESH_PTYP)(gps_mesh))->ps_nlist) :\
   NULL)

/*============================================================================*/
/* === Macro: FEM_SetActiveMesh_C
 * === Author: sjo
 * === Description: set the active mesh to a valid mesh object
 * === Arguments: MESH_OBJ obj_mesh
 * === Return: nothing
 */
#define FEM_SetActiveMesh_C( obj_mesh )\
   gps_mesh = (MESH_PTYP)obj_mesh;\
   if ( gps_mesh ) {\
      g_meshtype = gps_mesh->meshtype;\
   }\
   else {\
      g_meshtype = UNDEFINED_MESH;\
   }

/*============================================================================*/
/* === Macro: FEM_ActiveMesh_C
 * === Author: sjo
 * === Description: get the active mesh object
 * === Arguments: 
 * === Return: MESH_OBJ obj_mesh
 */
#define FEM_ActiveMesh_C( )\
   ((MESH_OBJ)gps_mesh)

/*============================================================================*/
/* === Macro: FEM_CurrentProcess_C
 * === Author: mls
 * === Description: get the current process
 * === Arguments: 
 * === Return: INT g_currentprocess
 */
#define FEM_CurrentProcess_C( ) g_currentprocess

/*============================================================================*/
/* === Macro: FEM_SetCurrentProcess_C
 * === Author: mls
 * === Description: set the current process
 * ===              default == 3.
 * === Arguments: INT new_proc
 * === Return: nothing
 */
#define FEM_SetCurrentProcess_C( new_proc )\
   if ( new_proc == 0 ) g_currentprocess = 3;\
   else g_currentprocess = new_proc;

/*============================================================================*/
/* === Macro: FEM_Error_C
 * === Author: mls
 * === Description: call a error handling routine.
 * === Arguments:  See FEMe_Error in FEM_external.h
 * === Return: nothing
 */
#define FEM_Error_C( subprocessid, errorid, severity, a_params )\
   FEMe_Error( subprocessid, errorid, severity, a_params,\
               __FILE__, __LINE__ );

/*============================================================================*/
/* === Macro: FEM_Malloc_MAC
 * === Author: mls
 * === Description: call a memory allocation routine
 * === Arguments:  See FEMe_Malloc in FEM_external.h
 * === Return: pointer to the allocated memory
 */
#define FEM_Malloc_MAC( size ) FEMe_Malloc( size, __FILE__, __LINE__ )

/*============================================================================*/
/* === Macro: FEM_Free_C
 * === Author: mls
 * === Description: call a memory deallocation routine
 * === Arguments:  See FEMe_Free in FEM_external.h
 * === Return: void
 */
#define FEM_Free_C( ptr )\
   if ( ptr != NULL ) {\
      FEMe_Free( (char*)(ptr), __FILE__, __LINE__ );\
      ptr = NULL;\
   }


/*
 * Include all of the Public FEM headers 
 */

#ifndef STANDALONE_DELAUNAY
#include "FEM_elPublic.h"
#include "FEM_noGeom.h"
#endif

#include "FEM_faPublic.h"
#include "FEM_edPublic.h"
#include "FEM_noPublic.h"
#include "FEM_MeshTable.h"
#include "FEM_meshTree.h"

/*
 *  Prototypes for debugging functions in FEM_debug.c
 *  All of these functions, given the appropriate object
 *  will print out the contents of the object and its
 *  adjacency information
 */

#ifdef __cplusplus
extern "C" {
#endif

void *FEM_noN ( INT id );
void FEM_no  ( NODE_OBJ obj_node );
void FEM_noL ( NODELIST_OBJ obj_nlist );
void *FEM_elN ( INT id );
void FEM_el  ( ELEMENT_OBJ obj_element );
void FEM_elL ( ELEMENTLIST_OBJ obj_elist );
void *FEM_edN ( INT id );
void FEM_ed  ( EDGE_OBJ obj_edge );
void FEM_edL ( EDGELIST_OBJ obj_edlist );
void *FEM_faN ( INT id );
void FEM_fa  ( FACE_OBJ obj_face );
void FEM_faL ( FACELIST_OBJ obj_flist );
#ifdef MATT_DEBUG
void FEM_faP ( FACE_OBJ obj_p_face );
INT FEM_elVerify ( ELEMENT_OBJ obj_element, FILE * );
INT FEM_faVerify ( FACE_OBJ obj_face, FILE * );
INT FEM_edVerify ( EDGE_OBJ obj_edge, FILE * );
INT FEM_noVerify ( NODE_OBJ obj_node, FILE * );
#else
INT FEM_elVerify ( ELEMENT_OBJ obj_element );
#ifndef STANDALONE_DELAUNAY
INT FEM_faVerify ( FACE_OBJ obj_face );
#else
#define FEM_faVerify(x) 1
#endif
INT FEM_edVerify ( EDGE_OBJ obj_edge );
INT FEM_noVerify ( NODE_OBJ obj_node );
#endif
INT FEM_MattCheck ( void * param1, void * param2, INT int_in1 );
INT FEM_MeshStat ( FILE *fp );
#ifndef STANDALONE_DELAUNAY
INT FEM_Verify (void);
INT FEM_noVerifyHash (void);
void FEM_faDraw ( FACE_OBJ obj_face );
void FEM_faDrawAll (void);
void FEM_edDrawAll (void);
void FEM_edDraw ( EDGE_OBJ obj_edge );
void FEM_color ( INT color );
void FEM_drawUV ( INT status );
void FEM_label ( INT label );
void FEM_noDrawFaces ( NODE_OBJ obj_node );
void FEM_DrawTriCoor ( DOUBLE xa, DOUBLE ya,
                                DOUBLE xb, DOUBLE yb,
                                DOUBLE xc, DOUBLE yc, INT flag );
void FEM_DrawLine2 ( DOUBLE x1, DOUBLE y1, DOUBLE z1,
                     DOUBLE x2, DOUBLE y2, DOUBLE z2 );
#else
#define FEM_Verify() 1
#define FEM_noVerifyHash() 1
#define FEM_faDraw(x)
#define FEM_faDrawAll()
#define FEM_edDrawAll()
#define FEM_edDraw(x)
#define FEM_color(x)
#define FEM_drawUV(x)
#define FEM_label(x)
#define FEM_noDrawFaces(x)
#define FEM_DrawTriCoor(x1,x2,x3,x4,x5,x6,x7)
#define FEM_DrawLine2(x1,x2,x3,x4,x5,x6)
#endif

void FEM_elDraw ( ELEMENT_OBJ obj_element );
void FEM_elDrawAll (void);
void FEM_elNDraw( INT id );

void FEM_noDrawEdges ( NODE_OBJ obj_node );
void FEM_edDrawElems (EDGE_OBJ obj_edge);
void FEM_faDrawN ( INT id );
void FEM_faDrawArea ( INT anum );
void FEM_edDrawArea ( INT anum );
void FEM_edDrawLine ( INT line );
void FEM_edCheckMid (void);
void FEM_SaveFacetFile ( INT num );
void FEM_DrawLine ( NODE_OBJ obj_node0, NODE_OBJ obj_node1  );
void FEM_AnsysLogFile( FEM_BOOLEAN uv_space, DOUBLE sx, DOUBLE sy, DOUBLE sz );
void FEM_AnsysBndLogFile( INT num_bnd, FEM_BOOLEAN uv_space );
void FEM_AnsysAreaLogFile( INT area, FEM_BOOLEAN uv_space );
INT FEM_Vdump( INT type );
void FEM_CDBdump();
void FEM_CDBread();
void FEM_dbgParm( INT parm, INT value );
void FEM_SetFP( FILE *fp );
void FEM_eview3D();
void FEM_eview3D_file( char *fileName );
void FEM_evAreaMt( INT area, FEM_BOOLEAN uv_space, FEM_BOOLEAN midnodes );
INT FEM_evElem(ELEMENT_OBJ obj_elem) ;
INT FEM_evElemLay(ELEMENT_OBJ obj_elem, INT lay );
INT FEM_evElemN(INT elem_id) ;
INT FEM_evEdgeN(INT elem_id) ;
INT FEM_evEdge(EDGE_OBJ obj_edge) ;
INT FEM_evNodes(NODE_OBJ *aobj_nodes, INT iNumNodes );
INT FEM_evSphere( DOUBLE cx, DOUBLE cy, DOUBLE cz, DOUBLE dR );
INT FEM_evNodeSphereN( INT id, DOUBLE dR );
void FEM_eviewBndLogFile( INT num_bnd, FEM_BOOLEAN uv_space );
void FEM_eviewAreaLogFile( INT area, FEM_BOOLEAN uv_space, FEM_BOOLEAN midnodes );
void FEM_eviewVolumeLogFile( INT iVolumeId );
void FEM_writeMarkedNodes();
INT FEM_evEdges( EDGE_OBJ *aobj_edges, INT iNumEdges, INT iUv, INT iMid );
void FEM_showmexyz( DOUBLE x, DOUBLE y, DOUBLE z, FEM_BOOLEAN flag );
void FEM_showme_a_xyz( DOUBLE * a_xyz, FEM_BOOLEAN flag );
void FEM_showmev ( VECTOR3D s_v, FEM_BOOLEAN flag );

FILE * FEM_fopen( const char * fname , char * mode);

#ifdef DSPACE_CMDB

void FEM_dbgprintf( char *format, ... );

void FEM_prependWindowsTempPath( char *fname );

#else

#define FEM_dbgprintf printf

#endif


/* === apply transformations to anything drawn in FEM_debug */

void FEM_iden ( );
void FEM_tran ( DOUBLE dx, DOUBLE dy, DOUBLE dz );
void FEM_scal ( DOUBLE scal );
void FEM_rotx ( DOUBLE angle );
void FEM_roty ( DOUBLE angle );
void FEM_rotz ( DOUBLE angle );
void FEM_tfm ( );

#ifdef __cplusplus
}
#endif

/* === color identifiers to be sent to FEM_color() */

#define COLOR_BLACK    0
#define COLOR_RED      1
#define COLOR_BLUE     5
#define COLOR_GREEN    8
#define COLOR_YELLOW  10
#define COLOR_ORANGE  11
#define COLOR_WHITE   15

#endif

