/* sid 60.3 copy of FEM_poorTet.h last changed by upd111 on 2007/01/02 21:02:56 */
/*  FEM_poorTet.h */
/*
 * *** ansys(r) copyright(c) 1999
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_poorTet.h
 *  header file for FEM_poorTet.c
 *
 */
#ifndef FEM_POOR_TET_INCLUDE
#define FEM_POOR_TET_INCLUDE


#ifdef __cplusplus
extern "C" {
#endif

/*----------------- Globally accessible function prototypes -----------------*/

                              /* === FEM_ptTryRemovePoorTets: try to remove  */
                              /*     poorly shaped tets in a given tet mesh  */
                              /*     (in a global data structure, possibly   */
                              /*     containing non-tet elements) by insert- */
                              /*     ing new nodes on long edges and applying*/
                              /*     simple flips to nearby transformable    */
                              /*     interior faces, based on local max-min  */
                              /*     shape measure criterion; in quadratic   */
                              /*     tet case, first try to perturb midnodes */
INT FEM_ptTryRemovePoorTets (
   FEM_BOOLEAN bndcon,                  /* TRUE if boundary is constrained   */
                                        /* (no T22 flips); FALSE if only     */
                                        /* certain boundary edges may be     */
                                        /* constrained                       */
   INT mtype,                           /* measure type (1 to 4)             */
   DOUBLE minmeas,                      /* tets with shape measure < minmeas */
                                        /* are considered poorly shaped      */
   FEM_BOOLEAN midnode  );              /* TRUE if quadratic elements        */

DOUBLE FEM_ptCalTetMetric  ( 
   INT mtyp,
   ELEMENT_OBJ obj_tet,
   FEM_BOOLEAN midnode );

INT FEM_ptRemoveKiteOnSurface ( 
   INT mtype, 
   FEM_BOOLEAN bndcon, 
   ELEMENT_OBJ obj_tet,
   FEM_BOOLEAN midnode,
   FACE_OBJ    *pobj_face0,
   FACE_OBJ    *pobj_face1 );

INT FEM_ptTryRemovePoorBndTet (
   ELEMENT_OBJ obj_tet,
   FEM_BOOLEAN *p_goodtet );

#ifdef __cplusplus
}
#endif

#endif

