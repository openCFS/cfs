/* sid 60.1 copy of FEM_matrix.h last changed by upd111 on 2005/07/21 19:40:26 */
/* ********************************** */
/* *** ansys(r) copyright(c) 1999 *** */
/* *** ansys, inc.                *** */
/* ********************************** */

/*  FEM_array.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_array.h
 *  header file for FEM_array.c
 *
 */
#ifndef FEM_ARRAY_INCLUDE
#define FEM_ARRAY_INCLUDE

/*----------------- Globally accessible function prototypes -----------------*/

#ifdef __cplusplus
extern "C" {
#endif

                        /* ================================================= */
                        /* === FEM_mxZero: Zero out a matrix.                */
                        /* === Return: void                                  */
                        /* ================================================= */
void FEM_mxZero(
   DOUBLE a_mat[4][4] );/* (IN/OUT) matrix to zero out.                      */
                        /* ================================================= */

                        /* ================================================= */
                        /* === FEM_mxVectMult: Multiply a vector by a matrix.*/
                        /* === Return: void                                  */
                        /* ================================================= */
void FEM_mxVectMult(
   DOUBLE a_vect[4],    /* (IN)  a vector                                    */
   DOUBLE a_mat2[4][4], /* (IN)  a matrix                                    */
   DOUBLE a_ans[4] );   /* (OUT) the result                                  */
                        /* ================================================= */

                        /* ================================================= */
                        /* === FEM_mxMult: Multiply 2 matrices.              */
                        /* === Return: void                                  */
                        /* ================================================= */
void FEM_mxMult(
   DOUBLE a_mat1[4][4], /* (IN)  matrix1                                     */
   DOUBLE a_mat2[4][4], /* (IN)  matrix2                                     */
   DOUBLE a_ans[4][4] );/* (OUT) the result                                  */
                        /* ================================================= */

#ifdef __cplusplus
}
#endif

#endif

