/* sid 60.1 copy of pds_corrfield.h last changed by jtm on 2006/05/15 19:44:40 */
/* ---------------------------------------------------------------------- */
/* *** copyright(c) 2006 SAS IP, Inc.  All rights reserved.                                         */
/* *** ansys, inc.                                                        */
/* ---------------------------------------------------------------------- */

/*
 *    author/date: Stefan Reh  06-26-2000  
 *
 *    primary function:
 *
 *        header for prototype definitions in ANSI C
 *
 *    Notice - This file contains ANSYS Confidential information ***
 *
 */

#ifndef _PDS_CORRFIELD_H_
#define _PDS_CORRFIELD_H_


extern int     NodalPathCorrelations   ( int, int, int*, double*, int, int*, int*, int, double, double* );
extern int     NodalPathDistances      ( int, int, int*, double*, int, int*, int*, double* );

extern int     ElementPathCorrelations ( int, int, double*, int*, int*, int, double, double* );
extern int     ElementPathDistances    ( int, int, double*, int*, int*, double* );


enum Corr_Field_Type
{
    CFLD_NONE = 0, CFLD_LEXP, CFLD_QEXP, CFLD_DIST
};


#endif  /* _PDS_CORRFIELD_H_ */
