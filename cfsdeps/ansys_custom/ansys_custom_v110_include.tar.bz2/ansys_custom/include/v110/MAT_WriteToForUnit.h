/* sid 60.2 copy of MAT_WriteToForUnit.h last changed by jtm on 2006/05/16 13:52:43 */
/*
////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         copyright(c) 2006 SAS IP, Inc.  All rights reserved.             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MAT_WriteToFortranUnit.h $
// $Revision$ 7.0
// $Date$ March 01 2005
// $Author$ rjayasee
//
// Decription :
//
// Write a command or line to a specific fortran unit
////////////////////////////////////////////////////////////////////////////
*/

#if !defined(MAT_WriteToFortranUnit)
#define MAT_WriteToFortranUnit

                         
#ifdef __cplusplus
extern "C"
{
#endif
    
void MAT_WriteToForUnit( int iUnit,
                             char* pFormat, ... ) ;
/*
//R void
//I oMsgType
//I-Type of Message, whether error,warning...
//I-Look at the defn of MAT_MessageType for the different types
//- This function is the message handler for the Material API
*/

#ifdef __cplusplus
}
#endif

#endif     

