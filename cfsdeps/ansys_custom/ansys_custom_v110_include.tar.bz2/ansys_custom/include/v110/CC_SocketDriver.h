/* sid 60.1 copy of CC_SocketDriver.h last changed by upd111 on 2006/10/09 19:58:04 */
/* CFILE CC_SocketDriver.h CADOE */

#ifndef CC_SOCKETDRIVER_H
#define CC_SOCKETDRIVER_H

#include "CFAST_TcpSocket.h"

class CC_SocketDriver
{
 public:
  CC_SocketDriver();
  ~CC_SocketDriver();

 public:
  int get_Password(char** val);
  int put_Password(char* newVal);
  int get_Username(char** val);
  int put_Username(char* newVal);
  int get_Port(int* val);
  int put_Port(int newVal);
  int get_Host(char** val);
  int put_Host(char* newVal);
  
  int Connect();
  int Disconnect();

  unsigned int iSendArray(const void * ptr, unsigned int dim);
  unsigned int iReceiveArray(void *cArray, unsigned int size /* nb bytes*/, int _iOption);

  
  unsigned int iSendMessage(char *cmdline) {   
    char command[256];
    sprintf(command,"ans_sendcommand %s\n",cmdline);
    return m_pSocket->iSendMessage(command,(unsigned int)strlen(command));
  }
  int get_Execute(char* cmdline,char** ret);
  

  void setTcpSocket(CFAST_TcpSocket * tcpSocket);
  
 private:
  int Cleanup();
  
  char*		m_host;
  int		m_port;
  char*		m_username;
  char*		m_password;
  
  CFAST_TcpSocket*	m_pSocket;
};

#endif
