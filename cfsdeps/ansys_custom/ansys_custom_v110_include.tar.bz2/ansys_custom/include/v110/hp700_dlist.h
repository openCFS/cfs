/* sid 60.1 copy of hp700_dlist.h last changed by jtm on 2006/05/15 19:44:16 */
/* 
 * *** copyright(c) 2006 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */
/* define display list data structures */

typedef struct {
        double  x, y, z;
} GPxyz;

typedef struct ch {
        char      *data1, *data2, *data3, *data4;
        struct ch *prev, *next;
        int       n;
        char      flag;
} chunk;

#if !defined(PCWINNT_SYS)
   void hp_dl_init();
   void hp_dl_open();
   void hp_dl_delete();
   void hp_dl_renew();
   static chunk *nextchunk();
   void hp_dl_coord();
   void hp_dl_text();
   void hp_dl_area();
   void hp_dl_line();
   void hp_dl_attr();
   void hp_dl_datt();
   void hp_dl_cntr();
   void hp_dl_tristrip();
   void hp_dl_trifan();
#if defined(SOLARIS_SYS)
#define  hp_dl_init     hp_dl_init_
#define  hp_dl_open     hp_dl_open_
#define  hp_dl_delete   hp_dl_delete_
#define  hp_dl_renew    hp_dl_renew_
#define  hp_dl_coord    hp_dl_coord_
#define  hp_dl_text     hp_dl_text_
#define  hp_dl_area     hp_dl_area_
#define  hp_dl_line     hp_dl_line_
#define  hp_dl_attr     hp_dl_attr_
#define  hp_dl_datt     hp_dl_datt_
#define  hp_dl_cntr     hp_dl_cntr_
#define  hp_dl_tristrip hp_dl_tristrip_
#define  hp_dl_trifan   hp_dl_trifan_
#endif
#else
   void hp_dl_init( void );
   void hp_dl_open( int * );
   void hp_dl_delete( int *);
   void hp_dl_renew( int*, int* );
   static chunk *nextchunk( void );
   void hp_dl_coord( int*, double [] );
   void hp_dl_text( int*, double [], int*, int[] );
   void hp_dl_area( double (*)[3], int*, double [], int*, double (*)[3],
                 int*, int[] );
   void hp_dl_line( int*, int*, double (*)[3] );
   void hp_dl_attr( int*, int* );
   void hp_dl_datt( int*, double* );
   void hp_dl_cntr( int*, double [] );
   void hp_dl_tristrip ( int *, double (*)[3], double (*)[3], int *);
   void hp_dl_trifan ( int *, double (*)[3], double (*)[3], int *);
#endif

