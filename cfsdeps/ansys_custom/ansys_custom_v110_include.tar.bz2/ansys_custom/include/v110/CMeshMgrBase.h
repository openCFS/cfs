/* sid 60.3 copy of CMeshMgrBase.h last changed by ehmalves on 2006/04/03 14:03:28 */
/* CMeshMgr.h CADOE doeinc */
/*! \file CMeshMgr.h

\brief This header file defines the CfileMgr class.

\author Gilles VENET &copy; CADOE

\date October 2004
*/
#ifndef __cmeshmgrBaseh__ 
#define __cmeshmgrBaseh__ 1 
#include "cadoe.h"
#include "decodeargs.h"
#include "fct_times.h"
#include "erreur.h"
#include "MSG_get.h"
#include "cbf.h"
#include "chaine.h"
#include "liste_chainee.h"

#include "expmdb_struct.h"
#include "CModeleBase.h"
#include "CCadoePortable.h"

/*! \class CSection CSection.h
\brief The CSection class is used to contain model ADOMESH
*/

#define CBF_CLOSE_FILE(vaf)  if ( vaf != NULL ) closeFile ( );


class CMeshMgrBase
{

	// Enums
public:
	enum Enum_MMGR_error
	{
		MMGR_NO_ERROR,
		MMGR_VAN_NOT_FOUND,
		MMGR_INVALID_MESH_TO_LOAD,
		MMGR_VAN_NOT_CREATE,
		MMGR_MESH_NOT_IN_MEMORY
	};

public:
	typedef list<T_Mesh*> MeshListBase;

	CMeshMgrBase ();
	CMeshMgrBase ( const string filename );

	virtual ~CMeshMgrBase ();


	virtual bool isInitialized ( string filename ) const;
	virtual bool openFileToRead ();
	virtual bool openFileToRead ( string filename );
	virtual bool closeFile ();
	virtual bool readFile ( const string dbname = "" );

	virtual T_Mesh *getMeshByLabel ( const int numero );
	virtual T_Mesh *getMeshByNameAndType ( const char *nom, const int type );
	virtual T_Mesh *getMeshByName ( const char *nom );
	virtual T_Mesh *getMesh () { return _current; };

	T_cbf *getVaf () { return _vaf; };
	virtual void setCurrent ( T_Mesh *mesh ) { _current = mesh; };

	virtual bool loadMesh ( T_Mesh *mesh );
	//virtual bool loadGroupes ( T_Mesh *mesh );
	virtual bool loadReperes ( T_Mesh *mesh );


	virtual bool newMesh ( T_Mesh ** );
	virtual bool addMesh ( T_Mesh *Lmesh );
	virtual bool addMeshInMemory ( T_Mesh *Lmesh );
	virtual bool deleteMesh ( int numero );
	void setDatabaseFilename(const char * filename);
	virtual bool deleteMesh ( T_Mesh *LmeshToDel );

	virtual void setModele ( CModeleBase *modele );
	virtual CModeleBase * getModele (  ) { return _modele; };


	//  int getAppliType ();
protected:
	virtual bool loadData( );


	// Attributes
protected:
	double _precision;
	string _dbname;
	string _buffername;
	Enum_MMGR_error	_lastError;
	unsigned int _numeroMax;
	MeshListBase _lmesh;
	bool _initialized;
	T_cbf       *_vaf;
	T_Mesh *_current;
	CModeleBase *_modele;
	T_cbf       *_buf;
};


#endif
