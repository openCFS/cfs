/* sid 60.1 copy of MatrixType.h last changed by upd111 on 2006/10/09 19:56:40 */
////////////////////////////////////////////////////////////////////////////
//                                                                        //
//          Copyright (C) 2001 ANSYS Inc.  All Rights Reserved            //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MatrixType.h $
// $Revision$
// $Date$
// $Author$
//
// Decription:
//
// Header file for matrix types.
////////////////////////////////////////////////////////////////////////////

#ifndef __MatrixType_H__
#define __MatrixType_H__

#ifndef  RECTMTX
#define  RECTMTX  1
#endif

#ifndef  SQRMTX
#define  SQRMTX   2
#endif

#ifndef  SYMMTX
#define  SYMMTX   3
#endif

#ifndef  LOWTMTX
#define  LOWTMTX  4
#endif

#ifndef  UPTMTX
#define  UPTMTX   5
#endif

#ifndef  DIAGMTX
#define  DIAGMTX  6
#endif

#ifndef  ROWVEC
#define  ROWVEC   7
#endif

#ifndef  COLVEC
#define  COLVEC   8
#endif

//======================================================================================//
//                                          Matrix
//======================================================================================//
// DESCRIPTION:
//
// General rectangular matrix class. Provides methods for reading, writing and querying
// the matrix. The memory can be increased dynamically (user request). Initialization
// methods are provided for developers only.
//
// PARENTS: None
//
// CONTENTS: None
//
//======================================================================================//

class Matrix
{
    public:

		// Lifecycle
        Matrix( );              
        Matrix( const int &, const int & ); 
        Matrix( const int &, const int &, const double & );
        Matrix( Matrix & );
        virtual ~Matrix( );
         
        // Memory management
        virtual int Allocate( void ); 
        virtual int Allocate( const int &, const int & );
        virtual int IncreaseMatrix( const int &, const int & );
       
        // Operations ("PUT", "GET" and "QUERY")
        virtual int PutDimensions( const int &, const int & );
        virtual int GetDimensions( int &, int & ) const;
        
        virtual int PutMatrixEntire( const double * const * const );
        int GetMatrixEntire( const double ** & ) const;                   //  Not overridden
        
        virtual int PutMatrixRow( int, const double * const );
        virtual int GetMatrixRow( int, const double * & ) const;
        virtual int GetRowCopy( int, double * ) const;

        virtual int PutMatrixCol( int, const double * const );
        virtual int GetColCopy( int, double * ) const;
        
        virtual int PutMatrixValue( int, int, const double & );
        virtual int GetMatrixValue( int, int, double & ) const;
		
        int QryMatrixType( void ) const;                                  //  Not overridden
        
    protected:

        int     iNumberRows, iNumberCols;
        double  **dMatrix;
        int     iType;

        // Initialization routines (no access to user)
        void InitDimensions( void );                                      //  Not overridden
        void InitMatrix( void );                                          //  Not overridden

    private:

        // None

};

//======================================================================================//
//                                     SqrMatrix
//======================================================================================//
// DESCRIPTION:
//
// Square matrix class. Provides methods for reading, writing and querying the matrix.
// The memory can be increased dynamically (user request). Protected initialization
// methods are provided. Provides trace computation.
//
// PARENTS: Matrix
//
// CONTENTS: None
//
//======================================================================================//

class SqrMatrix:public Matrix
{
    public:

	    // Lifecycle 
        SqrMatrix( );
        SqrMatrix( const int & ); 
        SqrMatrix( const int &, const double & );
        SqrMatrix( SqrMatrix & );
        virtual ~SqrMatrix( );
 
        // Memory management
        // virtual int Allocate( void );                                  ---  Matrix
        virtual int Allocate( const int & );
        virtual int IncreaseMatrix( const int & );

	    // Operations ("PUT", "GET" and "QUERY")
        virtual int PutDimensions( const int & );
        // virtual int PutDimensions( const int &, const int & );         ---  Matrix
        virtual int GetDimensions( int & ) const;
        virtual int GetDimensions( int &, int & ) const;

        // virtual int PutMatrixEntire( const double ** );                ---  Matrix
        // int GetMatrixEntire( const double ** & );                      ---  Matrix

        // virtual int PutMatrixRow( int, const double * );               ---  Matrix
        // virtual int GetMatrixRow( int &, const double * & ) const;     ---  Matrix
        // virtual int GetRowCopy( int, double * ) const;                 ---  Matrix

        // virtual int PutMatrixCol( int, const double * const );         ---  Matrix
        // virtual int GetColCopy( int, double * ) const;                 ---  Matrix
        
        // virtual int PutMatrixValue( int, int, const double & );        ---  Matrix
        // virtual int GetMatrixValue( int, int, double & ) const;        ---  Matrix
         
        virtual double Trace( void ) const;

        // int QryMatrixType( void ) const;                               ---  Matrix

    protected:

        // Matrix

    private:

        // None

}; 

//======================================================================================//
//                                     SymMatrix
//======================================================================================//
// DESCRIPTION:
//
// Symmetric matrix class. Provides methods for reading, writing and querying the matrix.
// The memory can be increased dynamically (user request). Protected initialization
// methods are provided. Provides trace computation. Lower triangular storage.
//
// PARENTS: SqrMatrix
//
// CONTENTS: None
//
//======================================================================================//

class SymMatrix:public SqrMatrix
{
    public:

        // Lifecyle
        SymMatrix( );
        SymMatrix( const int & );
        SymMatrix( const int &, const double & );
        SymMatrix( SymMatrix & );
        virtual ~SymMatrix( );

        // Memory management
        virtual int Allocate( void );
        virtual int Allocate( const int & );
		virtual int IncreaseMatrix( const int & );

	    // Operations ("PUT", "GET" and "QUERY")
        // virtual int PutDimensions( const int & );                      ---  SqrMatrix
        // virtual int PutDimensions( const int &, const int & );         ---  Matrix
        // virtual int GetDimensions( int & ) const;                      ---  SqrMatrix
        // virtual int GetDimensions( int &, int & ) const;               ---  Matrix

        virtual int PutMatrixEntire( const double * const * const );
        // int GetMatrixEntire( const double ** & ) ;                     ---  Matrix
        
        virtual int PutMatrixRow( int, const double * const );
        // virtual int GetMatrixRow( int, const double * & ) const;       ---  Matrix
        virtual int GetRowCopy( int, double * ) const;

        virtual int PutMatrixCol( int, const double * const );
        virtual int GetColCopy( int, double * ) const;

        virtual int PutMatrixValue( int, int, const double & );
        virtual int GetMatrixValue( int, int, double & ) const;
        
        // virtual double Trace( void ) const;                            ---  SqrMatrix

        // int QryMatrixType( void ) const;                               ---  Matrix
       
    protected:

        // Matrix

    private:

        // None

};

//======================================================================================//
//                                     LowerMatrix
//======================================================================================//
// DESCRIPTION:
//
// Lower triangular matrix class. Provides methods for reading, writing and querying the
// matrix. The memory can be increased dynamically (user request). Protected
// initialization methods are provided. Provides trace computation. Lower triangular
// storage.
//
// PARENTS: SqrMatrix
//
// CONTENTS: None
//
//======================================================================================//

class LowerMatrix:public SqrMatrix
{
    public:

        // Lifecycle
        LowerMatrix( );
        LowerMatrix( const int & );
        LowerMatrix( const int &, const double & );
        LowerMatrix( LowerMatrix & );
        virtual ~LowerMatrix( );
        
        // Memory management
        virtual int Allocate( void );
        virtual int Allocate( const int & );
		virtual int IncreaseMatrix( const int & );

        // Operations ("PUT", "GET" and "QUERY")
        // virtual int PutDimensions( const int & );                      ---  SqrMatrix
        // virtual int PutDimensions( const int &, const int & );         ---  Matrix
        // virtual int GetDimensions( int & ) const;                      ---  SqrMatrix
        // virtual int GetDimensions( int &, int & ) const;               ---  Matrix

        virtual int PutMatrixEntire( const double * const * const );
        // int GetMatrixEntire( const double ** & );                      ---  Matrix
        
        virtual int PutMatrixRow( int, const double * const );
        // virtual int GetMatrixRow( int , const double * & ) const;      ---  Matrix
        virtual int GetRowCopy( int, double * ) const;

        virtual int PutMatrixCol( int, const double * const );
        virtual int GetColCopy( int, double * ) const;

        virtual int PutMatrixValue( int, int, const double & ); 
        virtual int GetMatrixValue( int, int, double & ) const;
        
        // virtual double Trace( void ) const;                            ---  SqrMatrix

        // int QryMatrixType( void ) const;                               ---  Matrix

    protected:

        // Matrix

    private:

        // None

};

//======================================================================================//
//                                      UpperMatrix
//======================================================================================//
// DESCRIPTION:
//
// Upper triangular matrix class. Provides methods for reading, writing and querying the
// matrix. The memory can be increased dynamically (user request). Protected
// initialization methods are provided. Provides trace computation. Upper triangular
// storage.
//
// PARENTS: SqrMatrix
//
// CONTENTS: None
//
//======================================================================================//

class UpperMatrix:public SqrMatrix
{
    public:

        // Lifecycle
        UpperMatrix( );
        UpperMatrix( const int & );
        UpperMatrix( const int &, const double & );
        UpperMatrix( UpperMatrix & );
        virtual ~UpperMatrix( );

        // Memory management
        virtual int Allocate( void ); 
        virtual int Allocate( const int & );
		virtual int IncreaseMatrix( const int & );

        // Operations ("PUT", "GET" and "QUERY")
        // virtual int PutDimensions( const int & );                      ---  SqrMatrix
        // virtual int PutDimensions( const int &, const int & );         ---  Matrix
        // virtual int GetDimensions( int & ) const;                      ---  SqrMatrix
        // virtual int GetDimensions( int &, int & ) const;               ---  Matrix                           
         
        virtual int PutMatrixEntire( const double * const * const );
        // int GetMatrixEntire( const double ** & );                      ---  Matrix
        
        virtual int PutMatrixRow( int, const double * const );
        // int GetMatrixRow( int &, const double * & ) const;             ---  Matrix
        virtual int GetRowCopy( int, double * )const;

        virtual int PutMatrixCol( int, const double * const );
        virtual int GetColCopy( int, double * ) const;

        virtual int PutMatrixValue( int, int, const double & );
        virtual int GetMatrixValue( int, int, double & ) const;
        
        virtual double Trace( void ) const;
        
        // int QryMatrixType( void ) const;                               ---  Matrix

    protected:

        // Matrix

    private:

        // None

};

//======================================================================================//
//                                     DiaMatrix
//======================================================================================//
// DESCRIPTION:
//
// Diagonal  matrix class. Provides methods for reading, writing and querying the matrix.
// The memory can be increased dynamically (user request). Protected initialization
// methods are provided. Provides trace computation. Single column storage.                                   
//                                                                                      
// PARENTS: SymMatrix
//
// CONTENTS: None
//
//======================================================================================//

class DiaMatrix:public SymMatrix
{
    public:

        // Lifecycle
        DiaMatrix( );
        DiaMatrix( const int & ); 
        DiaMatrix( const int &, const double & );
        DiaMatrix( DiaMatrix & );
        virtual ~DiaMatrix( );
    
        // Memory management
        virtual int Allocate( void );     
        virtual int Allocate( const int & );
		virtual int IncreaseMatrix( const int & );
       
        // Operations ("PUT", "GET" and "QUERY")
        // virtual int PutDimensions( const int & );                      ---  SqrMatrix
        // virtual int PutDimensions( const int &, const int & );         ---  Matrix
        // virtual int GetDimensions( int & ) const;                      ---  SqrMatrix
        // virtual int GetDimensions( int &, int & ) const;               ---  Matrix 
         
        virtual int PutMatrixEntire( const double * const );
        // int GetMatrixEntire( const double ** & );                      ---  Matrix

        virtual int PutMatrixRow( int, const double * const );
        // virtual int GetMatrixRow( int &, const double * & ) const;     ---  Matrix
        virtual int GetRowCopy( int, double * ) const;

        virtual int PutMatrixCol( int, const double * const );
        virtual int GetColCopy( int, double * ) const;

        virtual int PutMatrixValue( int, const double & );
        virtual int GetMatrixValue( int, double & ) const;
        
        virtual double Trace( void ) const;

        // int QryMatrixType( void ) const;                               ---  Matrix

    protected:

        // Matrix

    private:

        // None

};

//======================================================================================//
//                                         RowVector
//======================================================================================//
// DESCRIPTION:
//
// Row Vector class. Provides methods for reading, writing and querying the vector. The
// memory can be increased dynamically (user request). Protected initialization methods
// are provided. Row storage.                                                                         
//                                                                                      
// PARENTS: Matrix
//
// CONTENTS: None
//
//======================================================================================//

class RowVector:public Matrix
{
    public:

        // Lifecycle
        RowVector( );
        RowVector( const int & );
        RowVector( const int &, const double & );
        RowVector( RowVector & );
        virtual ~RowVector( );

        // Memory management
        virtual int Allocate( void ); 
        virtual int Allocate( const int & ); 
		virtual int IncreaseMatrix( const int & );

        // Operations ("PUT", "GET" and "QUERY")
        virtual int PutDimensions( const int & );
        virtual int PutDimensions( const int &, const int & );
        virtual int GetDimensions( int & ) const;
        virtual int GetDimensions( int &, int & ) const;

        virtual int PutMatrixEntire( const double * const );
        // virtual int GetMatrixEntire( const double ** & );              ---  Matrix

        virtual int PutMatrixRow( const double * const );
        virtual int GetMatrixRow( const double * & ) const;
        virtual int GetRowCopy( double * ) const;

        virtual int PutMatrixCol( int, const double * const );
        virtual int GetColCopy( int, double * ) const;

        virtual int PutMatrixValue( int, const double & );
        virtual int GetMatrixValue( int, double & ) const;

        // int QryMatrixType( void ) const;                               ---  Matrix

    protected:

        // Matrix

    private:

        // None

};

//======================================================================================//
//                                         ColVector
//======================================================================================//
// DESCRIPTION:
//
// Column Vector class. Provides methods for reading, writing and querying the vector.
// The memory can be increased dynamically (user request). Protected initialization
// methods are provided. Column storage.
//
// PARENTS: Matrix
//
// CONTENTS: None
//
//======================================================================================//

class ColVector:public Matrix
{
    public:

        // Lifecycle
        ColVector( );
        ColVector( const int & );
        ColVector( const int&, const double & );
        ColVector( ColVector & );
        virtual ~ColVector( );
   
        // Memory management
        virtual int Allocate( void );
        virtual int Allocate( const int & );
		virtual int IncreaseMatrix( const int & );

        // Operations ("PUT", "GET" and "QUERY")
        virtual int PutDimensions( const int & );
        virtual int PutDimensions( const int &, const int & );
        virtual int GetDimensions( int & ) const;
        virtual int GetDimensions( int &, int & ) const;

        virtual int PutMatrixEntire( const double * const ); 
        // int GetMatrixEntire( const double ** & );                      ---  Matrix
        
        virtual int PutMatrixRow( int, const double * const );
        // virtual int GetMatrixRow( int, const double * & );             ---  Matrix
        virtual int GetRowCopy( int, double * ) const;

        virtual int PutMatrixCol( const double * const );
        virtual int GetColCopy( double * ) const;

        virtual int PutMatrixValue( int, const double & );
        virtual int GetMatrixValue( int, double & ) const;
        
        // int QryMatrixType( void ) const;                               ---  Matrix

    protected:

        // Matrix

    private:

        // None

}; 

# endif
