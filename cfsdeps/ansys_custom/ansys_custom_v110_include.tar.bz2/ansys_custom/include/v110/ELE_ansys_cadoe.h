/* sid 60.1 copy of ELE_ansys_cadoe.h last changed by smarguer on 2006/02/09 09:12:47 */
/* ELE_ansys_cadoe.h CADOE  */
#ifndef __eleansyscadoeh__
#define __eleansyscadoeh__ 1

/*#ifdef __cplusplus
extern "C" {
#endif*/

#ifndef __expmdbstructh__
#include "expmdb_struct.h"
#endif

extern T_statut ELE_convert_to_cadoe( T_Element *elem );
extern T_statut ELE_convert_to_cadoe_vec ( E_ele_type_geo *type_geo, int *nb_noeud, long *nodes, int *noeud_cadoe );
extern T_statut ELE_convert_to_ansys( T_Element *elem );

/*#ifdef __cplusplus
}
#endif*/


#endif
