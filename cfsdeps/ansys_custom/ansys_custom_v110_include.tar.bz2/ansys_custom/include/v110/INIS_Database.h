/* sid 60.20 copy of INIS_Database.h last changed by jtm on 2006/05/15 19:43:21 */
/* ---------------------------------------------------------------------- */
/* *** copyright(c) 2006 SAS IP, Inc.  All rights reserved. */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */

#include "ansys.h"

#if !defined(INIS_DATABASE_H)
#define INIS_DATABASE_H

#include "INIS_DataCollection.h"
#include "INIS_Object.h"

/* Data Stucture for Individual Data */
/*Data Structure for a Collection of Data */

/* Data Structure for a single element-intpt/secpt/layer pair */
struct INIS_ElementData : public INIS_Object
{
    public:

    INIS_ElementData() ;
    ~INIS_ElementData() ;
    //Constructor and Destructor

    bool WriteToHeader( DOUBLE* pDoubleArray ) ;
    //R
    //I pDoubleArray
    //- Write the Element Data Header To Double Array

    bool ReadFromHeader( DOUBLE* pDoubleArray ) ;
    //R
    //I pDoubleArray
    //- Read the Element Data Header from a Double Array

    INT m_iTotalDataSize ;
    INT m_iDataFormat ;
    INT m_iHeaderSize ;
    INT m_iDataSource ;
    INT m_iIsMatBased ;
    INIS_DataCollection* m_pDataCollection ;
} ;

/* Has information on element type */
/* Primarily to dictate the size of the data for each element */
struct INIS_ElementTemplate : public INIS_Object
{
    INIS_ElementTemplate() ;

    ~INIS_ElementTemplate() ;
    
    void SetParams( INT iNumLays, INT iNumIntPts ) ;
    //R
    //I iNumLays
    //- Number Of Layers
    //I iNumSects
    //- Number Of Sections
    //I iNumIntPts
    //- Num Gauss Integration Pts
    //- Sets the necessary parameters

    INT m_iNumLayers ;
    INT m_iNumIntegrationPoints ;
    INT* m_pNumIntPtsInLayer ;
} ;

class INIS_ElementTemplateArray : public INIS_Object
{
    public:

    INIS_ElementTemplateArray() ;

    ~INIS_ElementTemplateArray() ;

    struct INIS_ElementTemplate** m_ppElemTempate ;
    /* Array of Element Templates*/
    INT*                   m_pElementTypeIndex ;
    /* Array of Element Type Indices*/
} ;

class INIS_Database : public INIS_Object
{
    public:

    INIS_Database();
    //Constructor

    ~INIS_Database();
    //Destructor

    INIS_ElementData* m_pElemINISData ;
    /* Element Has Data for each intpt,secpt,layerid combination */

    INT m_iElemId ;
    /* Current Element Id*/

    INIS_ElementTemplateArray* m_pElemTemplateArray ;
    /* Maximum Possible Element Id*/
} ;

class INIS_CommandParams
{
    public:

    void * operator new(size_t iMemSize )
    {
        return ANS_MALLOC(iMemSize) ;
    }

    void * operator new[]( size_t iSize )
    {
        return ANS_MALLOC(iSize) ;
    }

    void operator delete(void * pMemPtr)
    {
            ANS_FREE(pMemPtr) ;
    }

    void operator delete[](void * pMemPtr )
    {
            ANS_FREE(pMemPtr) ;
    }

    INIS_CommandParams() ;
    //Constructor

    INT m_iCSID ;
    INT m_iDataType ;
    INT m_iMatId ;
};
//Code to store the Parameters necessary for Initial State Data

extern int g_iMaxRecSize ;
extern INT g_iINIS_NewVersionUsed ;
extern INT g_iINIS_Write ;

#endif
