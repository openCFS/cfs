/* sid 60.2 copy of MPCelnfor.h last changed by psc on 2005/10/14 17:49:26 */


/*------------------------- FORTRAN called from C --------------------*/

#if defined(UPPERCASENOUNDER_SYS)
#define  enfput   ENFPUT
#define  elmiqr   ELMIQR
#define  ndgxyz   NDGXYZ
#define  enfrcUpdate ENFRCUPDATE
#endif

#if defined(LOWERCASENOUNDER_SYS)
#define  enfput   enfput
#define  elmiqr   elmiqr
#define  ndgxyz   ndgxyz
#define  enfrcUpdate enfrcupdate
#endif

#if defined(LOWERCASEUNDER_SYS)
#define  enfput   enfput_
#define  elmiqr   elmiqr_
#define  ndgxyz   ndgxyz_
#define  enfrcUpdate enfrcupdate_
#endif

SUBROUTINE enfput(INT*, INT*, DOUBLE *);
INT FUNCTION elmiqr(INT*, INT*);
INT FUNCTION ndgxyz(INT*, DOUBLE *);  
SUBROUTINE enfrcUpdate(INT*, LONGINTC*, INT*, DOUBLE *);
