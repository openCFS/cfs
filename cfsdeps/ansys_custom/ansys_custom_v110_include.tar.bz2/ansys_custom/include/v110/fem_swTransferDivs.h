/* sid 60.1 copy of fem_swTransferDivs.h last changed by upd111 on 2005/07/21 19:43:03 */

/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 1999 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  fem_swTransferDivs.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  fem_swTransferDivs.h
 *  header file for fem_swTransferDivs.c
 *
 */
#ifndef FEM_SWTRANSFERDIVS_INCLUDE
#define FEM_SWTRANSFERDIVS_INCLUDE

/*----------------- Globally accessible function prototypes -----------------*/

                            /* ============================================== */
                            /* === FEM_swTransDivs: Transfer division         */
                            /* === spacing from the source area lines to      */
                            /* === perpendicular side lines and to the target */
                            /* === lines.                                     */
                            /* === Return: EXIT_SUCCESS or EXIT_FAILURE       */
                            /* ============================================== */
INT FEM_swTransDivs(
   VOL_PTYP obj_vol,        /* (IN) The volume to transferdivs on.            */
   AREA_PTYP obj_sarea,     /* (IN) The source area during sweeping           */
   AREA_PTYP obj_tarea,     /* (IN) The source area during sweeping           */
   FEM_BOOLEAN debug );     /* (IN) debug flag.                               */
                            /* ============================================== */

                            /* ============================================== */
                            /* === FEM_swGetTLocs: determine the parametric   */
                            /* === location of nodes on a line.               */
                            /* === Return: EXIT_SUCCESS or EXIT_FAILURE       */
                            /* ============================================== */
INT FEM_swGetTLocs(
   LINE_PTYP obj_line,      /* (IN)  The line to mesh */
   DOUBLE **a_line_t );     /* (OUT) The line divisions. */
                            /* ============================================== */

#endif

