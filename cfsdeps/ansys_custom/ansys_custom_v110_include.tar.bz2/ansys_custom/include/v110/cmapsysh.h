/* sid 60.1 copy of cmapsysh.h last changed by jtm on 2006/05/15 19:43:50 */
/********************************************/
/***  include file used for CMAP routines ***/
/********************************************/
/* 
 * *** copyright(c) 2006 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */
#if defined(PCWINNT_SYS)
    /*  c routines called from fortran  */
#define cmapstop_   CMAPSTOP

    /*  fortran routines called from c  */
#define cmap_       CMAP
#endif
