/* sid 60.1 copy of FEM_SphereOfInfluenceStruct.h last changed by upd111 on 2005/07/21 19:39:01 */
#ifndef FEM_SPHEREPFINLFUENCESTRUCT
#define FEM_SPHEREPFINLFUENCESTRUCT
#include "FEM_cdbtypes.h"

typedef struct SPHERE_OF_INFLUENCE_TYP     *SPHERE_OF_INFLUENCE_PTYP;

typedef struct SPHERE_OF_INFLUENCE_TYP{
    DOUBLE xyz[3];
    DOUBLE size;
    DOUBLE r1;
    DOUBLE r2;
    short  iSpecial;
} SPHERE_OF_INFLUENCE_TYP;





#endif


