/* sid 60.4 copy of CLMpertBase.h last changed by sgaltier on 2006/05/02 16:07:09 */
/******************************************************************/
/*!
  \file CLMesh.h
  \brief Classe de base pour la gestion des maillages ligths
  \version 1.00
 */
/******************************************************************/

#ifndef CLMPERTBASE_H
#define CLMPERTBASE_H 11


#include "cadoe.h"
#include "CCadoePortable.h"
//#include "expmdb_struct.h"
#include "LIGHT_struct_base.h"
#include "CLMeshBase.h"
#include "CconfigBase.h"
#include "CMeshMgrBase.h"
#include "CDesignSet.h"

class CLMeshBase;
class CConfigBase;
class CMeshMgrBase;
class Point3D;

class CLMpertBase
{
public:
  CLMpertBase ();
  CLMpertBase ( CLMeshBase *CLmesh, bool *ier );
  E_type_mesh getMeshType ( );

	virtual ~CLMpertBase();

	double * getPerturb2 ( int indNo, Point3D *pt );
	double * getPerturb ( int indNo ){ return &( _perturb->ve[_dimension*indNo]); }

	double *getSauvPerturb(int indNd){ return &(this->_sauve_perturb->ve[_dimension*indNd]); }
  double   setPerturb ( int indNo, double *pert, double *ini = NULL ); // if ini != NULL then perturb = pert - ini
  //bool   setPerturb ( CLMpertBase *Cinput );
	bool   setPerturb ( VEC *Vpert );
  void   setSavePerturb ( int indNo, double *pert ); // if ini != NULL then perturb = pert - ini
   void   addPerturb ( int indNd, double *, double *ini = NULL );
  bool   setNodeMoved ( int indice );
  bool   setNodeMoved ( int indice, double *xyz );
  bool isNodeMoved ( int indice );

 	double getPerturbMax (  );
  double getModule2OfPerturb ( int indNoe );
  double getModule2OfPerturb ( double *xyz );
  void   getAllPerturb ( VEC *, IVEC *a_bouge = NULL, double taille = 0 );
  void   getAllPerturb ( VEC ** );

	bool	updateWithPolynom	( CConfigBase *	);

  void   razPerturb ();
  void   savePerturb ();
  void   restaurePerturb ();

  void setPerturbAccuracy ( double taille );
  bool getResultat ( T_Resultat *res );
  bool setPerturbWithPolynom ( CDesignSet *dset, T_Mesh *mesh = NULL );
  bool setPerturbFromPolynom ( CDesignSet *dset, T_Mesh *mesh, VEC *pert = NULL );

	double getElementDeformationByIndice ( int EleInd, bool *err );
	double getMeshDeformation ( bool *err, CLMeshBase *CLmesh = NULL );
	int getElementDefMax () { return _indEle; }
	int getEpsMaxComposant () { return _composante; }

	bool isDeformationUpdated () { return _epsMaxUpdated; }
	bool updateFcnCout ( int Eind, T_Element *ele );
	bool updateFcnCout ( int Eind, int nb_noeud, int *noeud, T_FCout **fcout );
	bool updateFcnCout ( int Eind, VEC *epert, T_FCout **fcout );

private:
  void CLMpertBaseInit ();


protected:
	unsigned int _dimension;
	VEC				 *_perturb;
	VEC				 *_sauve_perturb;
  IVEC        *_numero;
  BVEC      *_isMoved;
  BVEC      *_sauve_isMoved;
	BVEC			*_eleToCalculate;
	VEC				*_epsMaxEle;
	VEC				*m_vCompressMax;
	VEC       *m_vAllongeMax;
	IVEC			*_IndComposante;
	VEC       *_mod2perturb;
  double _perturbMin;
  double _perturbMin2;
  int _meshID;
	CLMeshBase   *_CLmesh;
  CMeshMgrBase *_meshmgr;
	T_FCout _FCout;
	bool	_Eperturb;
	bool	_epsMaxUpdated;
	double _epsMax;
	unsigned int _composante;
	int _indEle;
	int _critere;
//	MAT **_matB;
//	int _nbMatB;
};


#endif


