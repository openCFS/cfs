/* sid 60.1 copy of changestr.h last changed by jtm on 2006/05/15 19:43:49 */
/***********************************************************************\
 *                                                                     *
 *  changeStr.h       March 6, 1995                                    *
 *                                                                     *
 *  Header file for changeStr.c                                        *
 *                                                                     *
\***********************************************************************/
/* 
 * *** copyright(c) 2006 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */

 //  Prototypes  //

BOOL changeStr ( CHAR [], CHAR [], CHAR [] );
