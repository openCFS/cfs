/* sid 60.1 copy of pragcom.h last changed by jtm on 2006/05/15 19:44:44 */
/* pragcom.h                                                            FJB
/* 
 * *** copyright(c) 2006 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */

 ***********************************************************************
 *** Notice - This file contains ANSYS Confidential information ***
 *
 * Author:      F. J. Bogden
 *
 * Function:    pragma declarations for FORTRAN COMMONs for WATCOM
 *		compiler on PC
 *
 * Description: This file contains pragma statements exclusively for
 *		WATCOM PC compiler/linker to declare FORTRAN LABELED
 *		COMMONs. You must include one pragma for EVERY FORTRAN 
 *		COMMON BLOCK and this file is only an illustration.
 *              NOTE : pragmas -MUST- be declared via an include file
 *              which is conditionally because some compilers will
 *              -not- recognize other than their own pragmas.
 *
 *** Notice - This file contains ANSYS Confidential information ***
 ***********************************************************************
 */

#ifndef PRAGCOM_H
#define PRAGCOM_H
#  pragma aux STRUCTURE_NAME_IN_C "^";
#endif
