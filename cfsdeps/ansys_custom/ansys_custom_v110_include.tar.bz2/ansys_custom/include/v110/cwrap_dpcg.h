/* sid 60.1 copy of cwrap_dpcg.h last changed by jrb on 2006/03/09 18:50:12 */

/*****************************************************************************
   This include file is used for the ANSYS cwrap_dpcg.c routines
*****************************************************************************/


extern INT       cexchange_cpce(INT*,INT*);
extern void      exchangeUseGlbBuffer2(DOUBLE*,INT);
extern INT       cNodeTouch(INT);
extern void      cansMPI_ISendToAll(INT,INT*,INT*);
extern void      cansMPI_CSendToAll(INT,CHAR*,INT*);
extern void      cansMPI_DSendToAll(INT,DOUBLE*,INT*);
extern INT       cGlbToLocalNd(INT);
extern INT       cLocalToGlbNd(INT);

extern void      cbuildInterfaceLen(void);
extern void      cbuildInterfaceLenUniform(void);
extern void      cexchange_extraBC(void);

extern INT       cGlbCpCeBegin(INT,INT);
extern INT       cGlbCpDef(INT,INT,INT*);
extern INT       cGlbCeDef(INT,INT*,INT*,DOUBLE*,DOUBLE);
extern INT       cGlbCpCeEnd(DOUBLE*);
extern INT       cGetGlbCurrVarnock(INT,INT);

extern void      cwDistributeGlobalSolution(INT*,DOUBLE*,INT*,DOUBLE*,INT*);



#if defined(PCWINNT_SYS)
extern  void   CALLTYP DISTRIBUTEGLOBALSOLUTION();
#elif defined(NOUNDER_SYS)
extern  void           distributeglobalsolution();
#else
extern  void           distributeglobalsolution_();
#endif

