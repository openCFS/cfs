/* sid 60.1 copy of Polygon.h last changed by upd111 on 2006/10/09 19:55:40 */
#ifndef _POLYGON_H_
#define _POLYGON_H_

#include "resize_array.h"
#include <stdio.h>
#include "BlockAlloc.h"

class PolyLine2;
class PolyTri3;
class PolyQuad4;
class PolyTri6;
class PolyQuad9;
class PolyQuad8;

class CoordSet;
class PolyObj;

class IPointset;
class ExitInfo;
class DegreedList;
class NrmInfo;

class Polygon {
  public:
    enum LineMode { outline, elemental, both };
    int is_unique;
    int attrib;
    int eleNum;
    Polygon *next;

    Polygon() { is_unique = 1; next = 0; }
    void mark_internal() { is_unique = 0; }
    void link(Polygon *p) { next = p; }
    virtual int min_node() {return 0;}
    virtual int numNodes() = 0;
    virtual int* getNodes(int *nd = 0) = 0;

   // Make lines adds all the 'edge lines' to the set of lines
    virtual void makeLines(IPointset &, LineMode ){};
   // The following function return 0 if the polygons are different, 1 if
   // Exactly equal and -1 if the have opposite rotations
    virtual int isLike(PolyLine2 *);
    virtual int isLike(PolyTri3 *);
    virtual int isLike(PolyQuad4 *);
    virtual int isLike(PolyTri6 *);
    virtual int isLike(PolyQuad9 *);
    virtual int isLike(PolyQuad8 *);

};

class PolyLine2 : public Polygon {
    int n[2];
    int edge[1];
  public:
    PolyLine2(int,int);
    int isLike(PolyLine2 *);
    void makeLines(IPointset &, LineMode);
    int min_node();
    int numNodes();
    int* getNodes(int *nd = 0);
};

class PolyTri3 : public Polygon {
  protected:
    int n[3];
  public:
    PolyTri3(int,int,int);
    int isLike(PolyTri3 *);
    int min_node();
    void makeLines(IPointset &, LineMode);
    int numNodes();
    int* getNodes(int *nd = 0);
    // void draw(PolyObj *);
};


class PolyQuad4 : public Polygon {
  protected:
    int n[4];  // Node numbers to which this polygon is connected
  public:
    PolyQuad4(int,int,int,int);
    int isLike(PolyQuad4 *);
    void makeLines(IPointset &, LineMode);
    int min_node();
    int numNodes();
    int* getNodes(int *nd = 0);
    // void draw(PolyObj *);
};


class PolyTri6 : public Polygon {
    int n[6];
    int edge[6];
  public:
    PolyTri6(int,int,int,int,int,int);
    int isLike(PolyTri6 *);
    void number_edges(IPointset &ips);
    int min_node();
    int numNodes();
    int* getNodes(int *nd = 0);
    void makeLines(IPointset &, LineMode);
    //void draw(PolyObj *);
};

class PolyQuad9 : public Polygon {
    int n[9];
    int edge[8];
  public:
    PolyQuad9(int,int,int,int,int,int,int,int,int);
    int isLike(PolyQuad9 *);
    void number_edges(IPointset &ips);
    int numNodes();
    int* getNodes(int *nd = 0);
//    void connect(Polygon * *);
//    void draw(PolyObj *);
};

class PolyQuad8 : public Polygon {
    int n[8];
    int edge[8];
  public:
    PolyQuad8(int,int,int,int,int,int,int,int);
    int isLike(PolyQuad8 *);
    void number_edges(IPointset &ips);
    int numNodes();
    int* getNodes(int *nd = 0);
    // void connect(Polygon * *);
    // void draw(PolyObj *);
};

class AnimObj;
class LabelElem;

class PolygonSet {
    int nmax;
    float *v;
    float *nrm;
    int numNrm;
    int *table;

  public:
    ResizeArrayPolygonPtr  polys;
    int cur_attrib;
    int curElemNum;
    int isID;

    BlockAlloc loc;

    PolygonSet();
    ~PolygonSet();
    int addLine2(int,int);
    int addTri3(int,int,int);
    int addQuad4(int,int,int,int);
    int addTri6(int,int,int,int,int,int);
    int addQuad9(int,int,int,int,int,int,int,int,int);
    int addQuad8(int,int,int,int,int,int,int,int);

    void setElemNum(int i) { curElemNum = i; }
} ;

#endif
