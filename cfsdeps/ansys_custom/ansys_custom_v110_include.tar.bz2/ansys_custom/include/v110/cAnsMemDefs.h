/* sid 60.1 copy of cAnsMemDefs.h last changed by upd111 on 2006/10/09 19:56:02 */
/*
 *  This file contains symbolic definitions for the memory manager
 *
 *   CAUTION WHEN EDITING THIS FILE!!!
 *
 *   THIS FILE HAS A TWIN FILE NAMED fAnsMemDefs.inc, AND ALL DEFINITIONS 
 *   MUST REMAIN IN SYNC FOR THE MANAGER TO WORK PROPERLY!!!
 */

/* values of bits for masks */
#define BIT_1        1
#define BIT_2        2
#define BIT_3        4
#define BIT_4        8
#define BIT_5       16
#define BIT_6       32
#define BIT_7       64
#define BIT_8      128
#define BIT_9      256
#define BIT_10     512
#define BIT_11    1024
#define BIT_12    2048
#define BIT_13    4096
#define BIT_14    8192
#define BIT_15   16384
#define BIT_16   32768
#define BIT_17   65536
#define BIT_18  131072
#define BIT_19  262144
#define BIT_20  524288

/* flags that can be sent into the manager for inquires or informs */
#define ECHO_OPERATIONS                          BIT_1
#define ECHO_TABLE_ON_ERROR                      BIT_2
#define ECHO_REMARKABLE_EVENTS                   BIT_3
#define ECHO_STATS_ON_DESTROY                    BIT_4
#define RESTRICTED_USES_1ST_BLOCK                BIT_5
#define WATCH_FRAGMENTATION                      BIT_6
#define ECHO_TABLE_ON_OPERATIONS                 BIT_7
#define ECHO_BLOCK_MANIPULATIONS                 BIT_8
#define TABLE_CONSISTENCY                        BIT_9
#define ECHO_ERROR_MESSAGES                     BIT_10
#define CHECK_PADS_ON_OPERATIONS                BIT_11
#define BEST_FIT                                BIT_12
#define FREE_INITIAL_BLOCK                      BIT_13
#define FREE_GROWTH_BLOCKS                      BIT_14
#define FILL_MEMORY                             BIT_15
#define SHUFFLE_BEFORE_GROWTH                   BIT_16
#define RANGE_PADS                              BIT_17
#define MEM_TRACK_LEVEL                         BIT_20



/* various return codes from the manager */
#define INITIAL_POOL_MALLOC_FAILURE             -1001
#define CANNOT_RESET_MANAGER                    -1026

#define UNKNOWN                                 -2001
#define INITIALIZER_SUCCESS                     -2002
#define INITIAL_MEMORY_TABLE_MALLOC_FAILURE     -2003

#define MEM_BLOCK_BEYOND_STACK                  BIT_1
#define MEM_BLOCK_IN_GROWTH                     BIT_2
#define MEM_BLOCK_IN_BASE                       BIT_3
#define MEM_TOO_FRAGMENTED                      BIT_4
#define MEM_NONSENSE_REQUEST                    BIT_5
#define MEM_NO_MEMORY_TABLE                     BIT_6
#define MEM_REQUEST_TOO_LARGE                   BIT_7
   

/* memory related definitions from ansysdef.inc -- not all are used */

#define HEAP_BYTE                 0
#define HEAP_INTEGER              1
#define HEAP_REAL                 2
#define HEAP_DOUBLE               3
#define HEAP_COMPLEX              4
#define HEAP_POINTER              5
#define HEAP_LONGINT              6
#define HEAP_FIXED               16
#define HEAP_QUERY               64
#define HEAP_RETURN             128
#define HEAP_INITIAL            256
#define HEAP_GROWTH             512
#define HEAP_FAIL              1024

#define MEM_BYTE                  0
#define MEM_INTEGER               1
#define MEM_REAL                  2
#define MEM_DOUBLE                3
#define MEM_COMPLEX               4
#define MEM_POINTER               5
#define MEM_LONGINT               6
#define MEM_FIXED                16
#define MEM_QUERY                64
#define MEM_RETURN              128
#define MEM_INITIAL             256
#define MEM_GROWTH              512
#define MEM_FAIL               1024
#define MEM_RESTRICTED         2048

#define MEM_DEBUG                 1
#define MEM_JOURNAL_PTR       -3001
#define MEM_LAST_MESSAGE      -3002
#define MEM_LARGEST_BLK       -3003
#define MEM_CURRENT_SIZE      -3004
#define MEM_MAX_SIZE          -3005
#define MEM_CURRENT_USED      -3006
#define MEM_MAX_USED          -3007
#define MEM_OVERHEAD          -3008
#define MEM_1ST_POOL_ADDR     -3010
#define MEM_ALIGNMENT         -3011
#define MEM_LARGEST_1ST_BLK   -3012
#define MEM_SUCCESS           -3013
#define MEM_HIGH_ADDR         -3014
#define MEM_LOW_ADDR          -3015
#define MEM_GROWTH_POOL_SIZE  -3016
#define MEM_FRAG_RATIO        -3017
#define MEM_FRAG_LEVEL        -3018
#define MEM_FRAG_WARN_FLAG    -3019
#define MEM_INITIALIZED       -3020
#define MEM_MAX_MAX_SIZE      -3021
#define MEM_MAX_MAX_USED      -3022
#define MEM_TRACK_DEPTH       -3023
#define MEM_PAD_SIZE          -3024
#define MEM_BLOCK_LENGTH      -3025
#define MEM_BLOCK_ELEMSIZE    -3026
#define MEM_BLOCK_TYPE        -3027
#define MEM_SEARCH            -3028
#define MEM_FIRSTFIT          -3029
#define MEM_BESTFIT           -3030
#define MEM_NUM_BLOCKS_USED   -3031
#define MEM_NUM_BLOCKS        -3032


#define MEM_WARN                  1
#define MEM_LENG                  3
#define MEM_HEAPSIZE              5
#define MEM_DISKPAGE              7
#define MEM_COREPAGE              8
#define MEM_FIXEDM                9
#define MEM_PAGESIZE             10
#define MEM_DB                   12
#define MEM_XOX_ADDRESS          13
#define MEM_XOX_LENG             14
#define MEM_XOX_PER              15
#define MEM_DB_MB                16
#define MEM_MEMORY_FIXED          1
#define MEM_HEAP_FIXED            2
#define MEM_DYNAMIC               0
#define MEM_DEFAULT              -1


/* stuff for the virtual memory manager */
#define BAD_INPUTS_TO_VIRT_INITIAL              -1027
#define LRU_STACK_MALLOC_FAILURE                -1028
