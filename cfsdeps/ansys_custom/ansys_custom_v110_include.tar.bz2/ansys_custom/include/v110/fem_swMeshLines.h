/* sid 60.1 copy of fem_swMeshLines.h last changed by upd111 on 2005/07/21 19:42:55 */

/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 1998 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  fem_swMeshLines.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  fem_swMeshLines.h
 *  header file for fem_swMeshLines.c
 *
 */
#ifndef FEM_SWMESHLINES_INCLUDE
#define FEM_SWMESHLINES_INCLUDE

/*----------------- Globally accessible function prototypes -----------------*/

                          /* ================================================ */
                          /* === FEM_swMeshLines: Mesh all unmeshed lines on  */
                          /* === the volume being swept.                      */
                          /* === Return: EXIT_SUCCESS or EXIT_FAILURE         */
                          /* ================================================ */
INT FEM_swMeshLines(
   AREAINFO *source_area, /* (IN) the source area for sweeping.               */
   AREAINFO *target_area, /* (IN) the target area for sweeping.               */
   INT num_divs,          /* (IN) number of divions along sweep.              */
   DOUBLE bias );         /* (IN) bias along sweep direction.                 */
                          /* ================================================ */

#endif

