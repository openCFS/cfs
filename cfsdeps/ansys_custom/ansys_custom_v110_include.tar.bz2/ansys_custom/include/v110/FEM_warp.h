/* sid 60.1 copy of FEM_warp.h last changed by upd111 on 2005/07/21 19:41:58 */
/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 1999 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_warp.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_warp.h
 *  header file for FEM_warp.c
 *
 */
#ifndef FEM_WARP_INCLUDE
#define FEM_WARP_INCLUDE

/*----------------- Globally accessible function prototypes -----------------*/

#ifdef __cplusplus
extern "C" {
#endif

                              /* =========================================== */
                              /* === FEM_wpSetUp: set up a parametric space  */
                              /* === in which meshing can take place. if     */
                              /* === area is flat, then just define a        */
                              /* === transformation that will place all      */
                              /* === coords into the x-y plane.  For general */
                              /* === surfaces compute a piecewise 2D surface */
                              /* === that approximates the 3D surface        */
                              /* === Return: EXIT_SUCCESS or EXIT_FAILURE    */
                              /* =========================================== */
INT FEM_wpSetUp (       
   INT *a_anum,               /* (IN) array of areas to be initialized       */
   INT num_areas,             /* (IN) number of areas to be initialized      */
   INT num_pardiv  );         /* (IN) number of parametric divisions         */

                              /*=============================================*/
                              /* === Function: FEM_wpKill                    */
                              /* === Description: kill all memory allocated  */
                              /* === for warp data structures                */
                              /* === Return: void                            */
                              /*=============================================*/
void FEM_wpKill ( void  );

                              /*=============================================*/
                              /* === Function: FEM_wpSetCurrent              */
                              /* === Description: Set the current area for   */
                              /* === transformations                         */
                              /* === Return: void                            */
                              /*=============================================*/
void FEM_wpSetCurrent ( 
  INT anum  );

                              /*=============================================*/
                              /* === Function: FEM_wpFromXYZ                 */
                              /* === Description: compute warped coords from */
                              /* === world coords                            */
                              /* === Return: EXIT_SUCCESS or EXIT_FAILURE    */
                              /*=============================================*/
INT FEM_wpFromXYZ ( 
   INT uv_status,             /* (IN) 0 = U-V coords unknown                 */
                              /*      1 = U-V coords unknown, but here's     */
                              /*          an intial guess                    */
                              /*      2 = U-V coordinates known              */
   DOUBLE world_x,            /* word coord                                  */    
   DOUBLE world_y,
   DOUBLE world_z,
   DOUBLE *p_u,               /* (INT/OUT) uv-coords or guess - not used if  */
   DOUBLE *p_v,               /* area is flat                                */
   FEM_BOOLEAN no_guess,      /* (IN)  TRUE if no guess is available for     */
                              /*        u,v.  i.e. p_u and p_v input is      */
                              /*        ignored.                             */
   DOUBLE *p_warp_x,          /* return in warped coordinate space           */
   DOUBLE *p_warp_y  );

                              /*=============================================*/
                              /* === Function: FEM_wpFromBoundXYZ            */
                              /* === Description: compute warped coords from */
                              /* === world coords for node on boundary       */
                              /* === Return: EXIT_SUCCESS or EXIT_FAILURE    */
                              /*=============================================*/
INT FEM_wpFromBoundXYZ (
   INT geo_entity,            /* (IN) geo entity id                          */
   INT geo_type,              /* (IN) 0 = KP, 1 = LINE                       */
   DOUBLE world_x,            /* (IN) world coordinates                      */
   DOUBLE world_y,
   DOUBLE world_z,
   DOUBLE *p_u,               /* (IN/OUT) uv coords - not used if area flat  */
   DOUBLE *p_v,
   FEM_BOOLEAN no_guess,         /* (IN)  TRUE if no guess is available for   */
                                 /*        u,v.  i.e. p_u and p_v input is    */
                                 /*        ignored.                           */
   DOUBLE *p_warp_x,          /* (OUT) warped coords                         */
   DOUBLE *p_warp_y  );

                              /*=============================================*/
                              /* === Function: FEM_wpToXYZ                   */
                              /* === Description: compute warped coords from */
                              /* === world coords                            */
                              /* === Return: EXIT_SUCCESS or EXIT_FAILURE    */
                              /*=============================================*/
INT FEM_wpToXYZ ( 
   DOUBLE warp_x,             /* warped coord                                */
   DOUBLE warp_y,
   DOUBLE *p_u,               /* return u-v coords for non-flat surfaces     */
   DOUBLE *p_v,
   DOUBLE *p_world_x,         /* return world coord                          */
   DOUBLE *p_world_y,
   DOUBLE *p_world_z  );

                              /*=============================================*/
                              /* === Function: FEM_wpFromUV                  */
                              /* === Description: compute warped coords from */
                              /* === U-V coords                              */
                              /* === Return: EXIT_SUCCESS or EXIT_FAILURE    */
                              /*=============================================*/
INT FEM_wpFromUV (
   DOUBLE u,
   DOUBLE v,                  /* known parametric coordinates                */
   DOUBLE *p_warp_x,          /* return warped coordinates                   */
   DOUBLE *p_warp_y  );

                              /*=============================================*/
                              /* === Function: FEM_wpToUV                    */
                              /* === Description: compute U-V coords from    */
                              /* === warped coords                           */
                              /* === Return: EXIT_SUCCESS or EXIT_FAILURE    */
                              /*=============================================*/
INT FEM_wpToUV (
   DOUBLE warp_x,             /* warped coords                               */
   DOUBLE warp_y,
   DOUBLE *p_u,               /* return u-v coords                           */
   DOUBLE *p_v  );


                             /* =========================================== */
                              /* === FEM_spWarpToNormal1: Convert a single   */
                              /* === coordinate in warped parametric space   */
                              /* === into normal parametric space.           */
                              /* === Return: EXIT_SUCCESS or EXIT_FAILURE    */
                              /* =========================================== */
INT FEM_wpWarpToNormal1 (
   DOUBLE uv[2],              /* (IN)  warped uv to convert to normal uv     */
   DOUBLE new_uv[2]  );       /* (OUT)  converted normal uv                  */


                              /* =========================================== */
                              /* === FEM_wpIsSetUp: check if setup is called */
                              /* === Return: 0: NO, otherwise: YES           */
                              /* =========================================== */
INT FEM_wpIsSetUp (         
   INT anum );             /* (IN)  areas is initialized ?     */

                              /*=============================================*/
                              /* === Function: FEM_wpMoveNodeOntoFlatSurface */
                              /* === Description: move a point onto a flat   */
                              /* === surface                                 */
                              /* === Return: EXIT_SUCCESS or EXIT_FAILURE    */
                              /*=============================================*/
INT FEM_wpMoveXYZOntoFlatSurface (
   DOUBLE *p_world_x,          /* (IN/OUT) world coordinates                 */
   DOUBLE *p_world_y,
   DOUBLE *p_world_z );


#ifdef __cplusplus
}
#endif

#endif

