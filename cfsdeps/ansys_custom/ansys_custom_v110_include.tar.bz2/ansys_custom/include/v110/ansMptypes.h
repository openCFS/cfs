/* sid 60.2 copy of ansMptypes.h last changed by jrb on 2006/10/30 15:04:39 */

#include "ansysdef.h"


extern  INT  cCreateAnsMp(INT,INT,INT*);
extern  INT  cDeleteAnsMp(void);
extern  INT  cInquireAnsMp(INT,INT,INT);
extern  INT  cPutAnsMp(INT,INT,INT,DOUBLE*,DOUBLE*);
extern  INT  cGetAnsMp(INT,INT,INT*,DOUBLE*,DOUBLE*);
extern  INT  cGetAnsMpPtr(INT,INT,INT*,DOUBLE**,DOUBLE**);
extern  INT  cDumpAnsMp(INT);

extern  INT  cPutAnsMpTable(INT,INT,INT*,INT*,DOUBLE*,DOUBLE*);
extern  INT  cGetAnsMpEval(INT,INT,INT*,INT,DOUBLE,INT*,INT*,INT*,INT*,DOUBLE*);
extern  INT  cGetAnsMpIndex(INT,INT*);


/****************************************************************
 global-level structure for ANSYS linear material properties
 ****************************************************************/
struct ansMp_str {               /* Name of the structure                                    */
  INT      tag;                  /* Tag for this instance of the material property structure */
  INT      numDef;               /* Number of defined materials in this structure            */
  INT      maxDef;               /* Maximum number of defined materials in this structure    */
  INT      maxNumProps;          /* Maximum number of properties stored for any material     */
  INT      maxNumTemps;          /* Maximum number of temperatures stored for any property   */
  INT     *Internal_to_External; /* Mapping vector for global internal to global external    */
  INT     *External_to_Internal; /* Mapping vector for global external to global internal    */
  mpData  *dataVec;              /* Array of material property and temperature data          */
};

#define ansMpTag(mat)                (mat->tag)
#define ansMpNumDef(mat)             (mat->numDef)
#define ansMpMaxDef(mat)             (mat->maxDef)
#define ansMpMaxNumProps(mat)        (mat->maxNumProps)
#define ansMpMaxNumTemps(mat)        (mat->maxNumTemps)

#define ansMpInt2ExtPtr(mat)         (mat->Internal_to_External)
#define ansMpInt2ExtVec(mat,i)       (mat->Internal_to_External[i])
#define ansMpExt2IntPtr(mat)         (mat->External_to_Internal)
#define ansMpExt2IntVec(mat,i)       (mat->External_to_Internal[i])

#define ansMpDataPtr(mat)            (mat->dataVec)
#define ansMpDataVec(mat,i)          (mat->dataVec+i)



/******************************************************************
 data-level structure for ANSYS linear material properties
 ******************************************************************/
struct mpData_str {      /* Name of the structure                                              */
  char     modified;     /* Flag indicating whether this linear material has been modified     */
  char     internal;     /* Flag indicating whether this linear material is internal to object */
  INT      numProps;     /* Number of properties stored for this material                      */
  INT     *props;        /* Array of the property numbers stored for this material             */
  INT     *numTemps;     /* Array of the number of temps for each property of this material    */
  DOUBLE **temps;        /* Array of temperatures for each property of this material           */ 
                         /*   NOTE: temps must be sorted in increasing order                   */
                         /*   temps[prop][temp]  where temp goes from 1->numTemps[prop]        */
                         /*                      where prop goes from 1->numProps              */
  DOUBLE **values;       /* Material property values for each temperature value                */
                         /*   values[prop][temp] where temp goes from 1->numTemps[prop]        */
                         /*                      where prop goes from 1->numProps              */
};

#define mpDataModified(mData)                (mData->modified)
#define mpDataInternal(mData)                (mData->internal)
#define mpDataNumProps(mData)                (mData->numProps)

#define mpDataPropsPtr(mData)                (mData->props)
#define mpDataPropsVec(mData,i)              (mData->props[i])
#define mpDataNumTempsPtr(mData)             (mData->numTemps)
#define mpDataNumTempsVec(mData,iProp)       (mData->numTemps[iProp])
#define mpDataTempsPtr(mData)                (mData->temps)
#define mpDataTempsVec(mData,iProp,iTemp)    (mData->temps[iProp][iTemp])
#define mpDataValuesPtr(mData)               (mData->values)
#define mpDataValuesVec(mData,iProp,iTemp)   (mData->values[iProp][iTemp])

