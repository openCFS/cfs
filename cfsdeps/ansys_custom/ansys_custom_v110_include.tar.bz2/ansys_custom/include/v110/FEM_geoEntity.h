/* sid 60.2 copy of FEM_geoEntity.h last changed by upd111 on 2006/05/05 14:00:42 */

/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 1999 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_geoEntity.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_geoEntity.h
 *  header file for FEM_geoEntity.c
 *
 */
#ifndef FEM_GEO_ENTITY_INCLUDE
#define FEM_GEO_ENTITY_INCLUDE

/*----------------- Globally accessible function prototypes -----------------*/
#ifdef __cplusplus
extern "C" {
#endif


                        /* ================================================= */
                        /* === FEM_geDetermineFaceGeoEntity: for a face,     */
                        /* === determine what geo entity is associated with  */
                        /* === it.  Areas must be completely constructed     */
                        /* === before calling this. Node entities must be up */
                        /* === to date.                                      */
                        /* ================================================= */
INT FEM_geDetermineFaceGeoEntity (
   FACE_OBJ obj_face,
   INT *pVolNum );

                        /* ================================================= */
                        /* === FEM_geDetermineEdgeGeoEntity:  for an edge    */
                        /* === determine what geo entity is associated with  */
                        /* === it Areas must be completely constructed before*/
                        /* === calling this node entities and face entities  */
                        /* === must be up to date If used for a volume mesh  */
                        /* === FEM_geDetermineFaceGeoEntity must have already*/
                        /* === been called                                   */
                        /* === Return: INT EXIT_SUCCESS or EXIT_FAILURE      */
                        /* ================================================= */
INT FEM_geDetermineEdgeGeoEntity (
   EDGE_OBJ obj_edge  );

                        /* ================================================= */
                        /* === FEM_geGenerateLineKpList: Given a list of     */
                        /* === areas, create a list of all lines and a list  */
                        /* === of kps on the areas.  No line or kp will be   */
                        /* === in their list more than once and the lists    */
                        /* === will be sorted from smallest to greatest area */
                        /* === id.  hard points on the areas and adjacent    */
                        /* === lines are included in the keypoint list.      */
                        /* === Return: INT EXIT_SUCCESS or EXIT_FAILURE      */
                        /* ================================================= */
INT FEM_geGenerateLineKpLists (
   INT *a_areas,       /* (IN)  list of areas. */
   INT num_areas,      /* (IN)  length of a_areas */
   FEM_BOOLEAN hpts,   /* (IN)  TRUE if hardpoints should be included. */
   INT **a_lines,      /* (OUT) lines on the areas is a_areas. */
   INT *num_lines,     /* (OUT) length of a_lines */
   INT **a_kps,        /* (OUT) kps on areas in a_areas including hard points */
   INT *num_kps  );    /* (OUT) length of a_kps */

                        /* ================================================= */
                        /* === FEM_geGenerateSortedKpList: Given a list of   */
                        /* === lines, create a list of kps that define the   */
                        /* === lines.  No kp will be in the kp more than     */
                        /* === one.  The KP list will also be sorted from    */
                        /* === smallest to greatest.                         */
                        /* === Return: INT EXIT_SUCCESS or EXIT_FAILURE      */
                        /* ================================================= */
INT FEM_geGenerateSortedKpList (
   INT *a_lines,        /* (IN)  the list of lines                           */
   INT num_lines,       /* (IN)  length of a_lines                           */
   INT **a_kps,         /* (OUT) array of kps (allocated by this routine)    */
   INT *num_kps  );     /* (OUT) length of a_kps                             */

                        /* ================================================= */
                        /* === FEM_geGenerateAreaList: Given a list of       */
                        /* === volumes, create a list of all areas on the    */
                        /* === volumes.  No area will be in the list more    */
                        /* === than once and the list will be sorted from    */
                        /* === smallest to greatest area id.                 */
                        /* === Return: INT EXIT_SUCCESS or EXIT_FAILURE      */
                        /* ================================================= */
INT FEM_geGenerateAreaList (
   INT *a_vols,         /* (IN)  list of volumes.                            */
   INT num_vols,        /* (IN)  length of a_vols                            */
   FEM_BOOLEAN negatives,/* (IN)  FALSE if negative area ids should be made   */
                        /*       positive.                                   */
   INT **a_areas,       /* (OUT) areas on the volumes is a_vols.             */
   INT *num_areas  );   /* (OUT) length of a_areas                           */

                        /* ================================================= */
                        /* === FEM_geGenerateLineList: Given a list of       */
                        /* === areas, create a list of all lines on the      */
                        /* === areas.  No line will be in the list more than */
                        /* === once and the list will be sorted from         */
                        /* === smallest to greatest line id.                 */
                        /* === Return: INT EXIT_SUCCESS or EXIT_FAILURE      */
                        /* ================================================= */
INT FEM_geGenerateLineList (
   INT *a_areas,        /* (IN)  list of areas.                              */
   INT num_areas,       /* (IN)  length of a_areas                           */
   INT **a_lines,       /* (OUT) lines on the areas is a_areas.              */
   INT *num_lines  );   /* (OUT) length of a_lines                           */

INT FEM_gePointInPolygon ( 
    DOUBLE thepoint[2],
    INT numpoints,
    INT **a_polygon,
    DOUBLE **a_polypoints );


#ifdef __cplusplus
}
#endif

#endif

