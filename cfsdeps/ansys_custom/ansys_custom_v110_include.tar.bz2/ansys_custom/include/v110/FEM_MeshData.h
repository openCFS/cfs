/* sid 60.6 copy of FEM_MeshData.h last changed by upd111 on 2007/01/02 21:02:18 */
#ifndef FEM_MESHDATA________________H
#define FEM_MESHDATA________________H

class MSHDAT_TYP {

   private:
      ADDRESS_TYP mp_genptr; // generic pointer
      CELL_PTYP mp_cell;     // cell

   protected:
      void InitMSH_TYP( ) { 
          mp_cell = NULL; 
          mp_genptr = NULL; 
          m_meshed = 1;
          m_esize = 0.0;
          m_ulPreviewFilter = 0;
          m_igroup = -1;
      };


      void SetCell( CELL_PTYP p_cell = NULL ) { mp_cell = p_cell;};
      CELL_PTYP GetCell( ) const { return mp_cell; };

   public:
      virtual ~MSHDAT_TYP() {};
      void SetGenPtr( ADDRESS_TYP p_genptr = NULL ) { mp_genptr = p_genptr; };
      ADDRESS_TYP GenPtr( )  const { return mp_genptr; }; 
      INT Id() { return mp_cell->GetId(); };


   protected:
    unsigned m_meshed:1;
    unsigned m_harddivs:1;
    unsigned m_softdivs:1;
    unsigned m_highprigoal:1;
    unsigned m_sweep_parallel:1;
    unsigned m_onsweeppath:1;
    unsigned long m_ulPreviewFilter;
    DOUBLE m_bias;
    DOUBLE m_esize;
    INT m_numdivs;
    INT m_goaldivs;
    INT m_index;
    INT m_igroup;

   public:

      inline void SetOnASweepPath( const FEM_BOOLEAN stat = TRUE )
      {
         if ( stat ) m_onsweeppath = 1;
         else m_onsweeppath = 0;
      };

      inline FEM_BOOLEAN OnASweepPath( ) const
      {
         if ( m_onsweeppath == 1 ) return TRUE;
         else return FALSE;
      };      
      
      inline void SetBias( const DOUBLE bias = 0 ) { m_bias = bias; };
      inline DOUBLE Bias( ) const { return m_bias; };

      inline void SetHighPriorityGoal( const FEM_BOOLEAN stat = TRUE )
      {
         if ( stat ) m_highprigoal = 1;
         else m_highprigoal = 0;
      };

      inline FEM_BOOLEAN HighPriorityGoal( ) const
      {
         if ( m_highprigoal == 1 ) return TRUE;
         else return FALSE;
      };

      inline void SetGoalDivs( const INT numdivs = 0 ) { m_goaldivs = numdivs; };
      inline INT GoalDivs( ) const { return m_goaldivs; };

      inline void SetNumDivs( const INT numdivs = 0 ) { m_numdivs = numdivs; };
      inline INT NumDivs( ) const { return m_numdivs; };

      inline void SetIndex( const INT index = 0 ) { m_index = index; };
      inline INT Index( ) const { return m_index; };



      inline void SetHardDivs( const FEM_BOOLEAN harddivs = TRUE )
      {
         if ( harddivs ) m_harddivs = 1;
         else m_harddivs = 0;
      };

      inline void SetSoftDivs( const FEM_BOOLEAN softdivs = TRUE )
      {
         if ( softdivs ) m_softdivs = 1;
         else m_softdivs = 0;
      };

      inline FEM_BOOLEAN HasHardDivs( ) const
      {
         if ( m_harddivs == 1 ) return TRUE;
         else return FALSE;
      };

      inline FEM_BOOLEAN HasSoftDivs( ) const
      {
         if ( m_softdivs == 1 ) return TRUE;
         else return FALSE;
      }; 
      
      inline void SetMeshed( const FEM_BOOLEAN meshed = TRUE )
      {
         if ( meshed ) m_meshed = 1;
         else m_meshed = 0;
      };

      inline FEM_BOOLEAN IsMeshed( ) const
      {
         if ( m_meshed == 1 ) return TRUE;
         else return FALSE;
      };

      inline void ResetSweepDir( )
      {
         m_sweep_parallel = 0;
      };

      inline void SetParallelToSweepDir( const FEM_BOOLEAN status = TRUE )
      {
         if ( status ) {
            m_sweep_parallel = 1;
         }
         else {
            m_sweep_parallel = 0;
         }
      };

      inline FEM_BOOLEAN ParallelToSweepDir( ) const
      {
         if ( m_sweep_parallel == 1 ) return TRUE;
         else return FALSE;
      };

      inline void SetEsize( DOUBLE dEsize  ) { m_esize = dEsize;};
      inline DOUBLE Esize(){return m_esize;};

    inline void setPreviewFilter(unsigned long ulFilter){ m_ulPreviewFilter = ulFilter;};

    inline unsigned long getPreviewFilter(){ return m_ulPreviewFilter;};

    inline void setGroup(INT iGroup){ m_igroup = iGroup;};
    inline INT getGroup() { return m_igroup; };

};
typedef class MSHDAT_TYP *MSHDAT_PTYP;

void FEM_vlMdN( INT id );
void FEM_aeMdN( INT id );
void FEM_lnMdN( INT id );
void FEM_kpMdN( INT id );

#endif

