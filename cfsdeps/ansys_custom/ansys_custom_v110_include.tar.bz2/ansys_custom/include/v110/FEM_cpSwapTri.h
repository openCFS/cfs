/* sid 60.1 copy of FEM_cpSwapTri.h last changed by upd111 on 2005/07/21 19:39:44 */

/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 1999 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_cpSwapTri.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_cpSwapTri.h
 *  header file for FEM_cpSwapTri.c
 *
 */
#ifndef FEM_CPSWAPTRI_INCLUDE
#define FEM_CPSWAPTRI_INCLUDE

/*----------------- Globally accessible constants  --------------------------*/

/*----------------- Globally accessible data types --------------------------*/

/*----------------- Globally accessible function prototypes -----------------*/

#ifdef __cplusplus
extern "C" {
#endif

                      /* =================================================== */
                      /* === FEM_cpSwapTri: Check the tesselation of a       */
                      /* === background mesh using the locations of a        */
                      /* === different set of nodes.  If any of the          */
                      /* === triangles are inverted with the other locations,*/
                      /* === swap to uninvert them.                          */
                      /* === Return: INT EXIT_SUCCESS or EXIT_FAILURE        */
                      /* =================================================== */
INT FEM_cpSwapTri(
   MESH_OBJ obj_bgmesh,       /* (IN)  The bgmesh                             */
   INT num_bound_nodes,       /* (IN)  The number of boundary nodes in the    */
                              /*       both obj_bgmesh and in the other set   */
                              /*       of boundary nodes that need to be      */
                              /*       checked (i.e. aobj_bnd_nodes.)         */
   NODE_OBJ const *aobj_src_bnodes, /* (IN)  soruce boundary nodes.           */
   NODE_OBJ const *aobj_trg_bnodes, /* (IN)  soruce boundary nodes.           */
   INT src_area,              /* (IN)  source area id.                        */
   INT trg_area,              /* (IN)  target area id.                        */
   FEM_BOOLEAN *changed,      /* (OUT) TRUE if obj_bgmesh was swapped to get  */
                              /*       rid of an inverted triangle.           */
   FEM_BOOLEAN *not_ok,       /* (OUT) TRUE if we were unable to uninvert the */
                              /*       mesh.                                  */
   FEM_BOOLEAN do_progress,   /* (IN)  TRUE if doing progress bar.            */
   FEM_BOOLEAN *abort,        /* (OUT) TRUE if user requests abort.           */
   FEM_BOOLEAN debug );       /* (IN)  debug flag.                            */

#ifdef __cplusplus
}
#endif

#endif

