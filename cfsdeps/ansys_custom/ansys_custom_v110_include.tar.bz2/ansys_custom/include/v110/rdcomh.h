/* sid 60.1 copy of rdcomh.h last changed by jtm on 2006/05/15 19:44:47 */
/*
 *    author/date: gregory sharpe 12-5-96
 *
 *    primary function:
 *
 *        header for the common data location RDCOM
 *
 *    secondary function:
 *
 *        none
 *
 *    routines included:
 *
 *        none
 *
 *    history
 *
 *        none
 *
 *    comments:
 *
 *        none
 *
 *    Notice - This file contains ANSYS Confidential information ***
 *
 */
/* 
 * *** copyright(c) 2006 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */


#define MAXCMDFIELD 20
#define MAXCMDLONGFIELD 15

#  define CALLTYP  

#if defined(RS6000_SYS) || defined(HP32_SYS)

/*
 *    Fortran common blocks
 */
#define rdcom_ rdcom
#define rdcomc_ rdcomc

#endif



#if defined(WATCOMC_SYS) \
    || defined(PCWINNT_SYS)


/*
 *    Fortran common blocks
 */

#define rdcom_ RDCOM
#define rdcomc_ RDCOMC

#endif

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/


      extern struct rdcom_type {
          double dpin[MAXCMDFIELD];
          INT intin[MAXCMDFIELD];
          INT subin[3][MAXCMDFIELD];
          INT quotbt;
          INT rdspar[7];
      } CALLTYP rdcom_;

      extern struct rdcomc_type {
          char titlin[72];
          char ch32in[MAXCMDLONGFIELD][32];
          char lab8in[MAXCMDFIELD][8];
          char lab4in[MAXCMDFIELD][4];
          char oldlab[4];
          char ch64in[MAXCMDLONGFIELD][64];
      } CALLTYP rdcomc_;
