/* sid 60.1 copy of FEM_refineHex.h last changed by upd111 on 2005/07/21 19:41:21 */
/*  FEM_refineHex.h */
/*
 * *** ansys(r) copyright(c) 1999
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_refineHex.h
 *  Prototypes and macros for refining hexahedral meshes.
 *
 */

#ifndef FEM_REFINEHEX
#define FEM_REFINEHEX

#include "FEM_cdbtypes.h"

/* === valid node marking orientations on a hex */
#define VALID1  ((1L<<0))  /* node 0 marked only */
#define VALID2  ((1L<<1))  /* node 1 marked only */
#define VALID3  ((1L<<2))  /* node 2 marked only */
#define VALID4  ((1L<<3))  /* node 3 marked only */
#define VALID5  ((1L<<4))  /* node 4 marked only */
#define VALID6  ((1L<<5))  /* node 5 marked only */
#define VALID7  ((1L<<6))  /* node 6 marked only */
#define VALID8  ((1L<<7))  /* node 7 marked only */

#define VALID9  ((1L<<0) | (1L<<1))  /* nodes 0 & 1 marked only */
#define VALID10 ((1L<<0) | (1L<<4))  /* nodes 0 & 4 marked only */
#define VALID11 ((1L<<1) | (1L<<5))  /* nodes 1 & 5 marked only */
#define VALID12 ((1L<<1) | (1L<<2))  /* nodes 1 & 2 marked only */
#define VALID13 ((1L<<2) | (1L<<6))  /* nodes 2 & 6 marked only */
#define VALID14 ((1L<<2) | (1L<<3))  /* nodes 2 & 3 marked only */
#define VALID15 ((1L<<3) | (1L<<7))  /* nodes 3 & 7 marked only */
#define VALID16 ((1L<<3) | (1L<<0))  /* nodes 3 & 0 marked only */
#define VALID17 ((1L<<4) | (1L<<5))  /* nodes 4 & 5 marked only */
#define VALID18 ((1L<<5) | (1L<<6))  /* nodes 5 & 6 marked only */
#define VALID19 ((1L<<6) | (1L<<7))  /* nodes 6 & 7 marked only */
#define VALID20 ((1L<<7) | (1L<<4))  /* nodes 7 & 4 marked only */

#define VALID21 ((1L<<0)|(1L<<1)|(1L<<2)|(1L<<3))/* nodes 0,1,2,3 marked only */
#define VALID22 ((1L<<4)|(1L<<5)|(1L<<6)|(1L<<7))/* nodes 4,5,6,7 marked only */
#define VALID23 ((1L<<0)|(1L<<3)|(1L<<4)|(1L<<7))/* nodes 0,3,4,7 marked only */
#define VALID24 ((1L<<0)|(1L<<1)|(1L<<4)|(1L<<5))/* nodes 0,1,4,5 marked only */
#define VALID25 ((1L<<1)|(1L<<2)|(1L<<5)|(1L<<6))/* nodes 1,2,5,6 marked only */
#define VALID26 ((1L<<2)|(1L<<3)|(1L<<6)|(1L<<7))/* nodes 2,3,6,7 marked only */

#define VALID27 ((1L<<0)|(1L<<1)|(1L<<2)|(1L<<3)|\
                 (1L<<4)|(1L<<5)|(1L<<6)|(1L<<7)) /*all nodes are marked */



                              /* ============================================ */
                              /* === FEM_reProcessHex_3Ref: process a         */
                              /* === hexahedral element for splitting using   */
                              /* === 3-Refinement.                            */
INT FEM_reProcessHex_3Ref (
   ELEMENTLIST_OBJ obj_ellist,/* the element list                             */
   NODELIST_OBJ obj_nlist,    /* the node list                                */
   FACE_OBJ obj_elem,         /* hexahedron to be split                       */
   FEM_BOOLEAN detached,      /* TRUE if not associated with solid model      */
   FEM_BOOLEAN no_lines  );   /* TRUE if no new nodes can be created on lines */

#endif
