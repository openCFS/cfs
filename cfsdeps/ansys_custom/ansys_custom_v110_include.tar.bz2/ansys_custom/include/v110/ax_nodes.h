/* sid 60.1 copy of ax_nodes.h last changed by upd111 on 2006/10/09 19:54:43 */
/* ANSI_C ax_nodes.h - ANSYS Geometry Interface: internal node types */

/*--------------------------------------------------------------------------*/
/* ansys(r) copyright(c) 2000 */
/* ansys, inc.                */
/*--------------------------------------------------------------------------*/

#ifndef __AX_NODES_H__  /* Include this file only once! */
#define __AX_NODES_H__

#ifdef __cplusplus
extern "C" {
#endif

/*--------------------------------------------------------------------------*/

/* Node type constants */

/* Topology class ............... 1201xxxx */
#define ax_TOPO_CLASS             12010000
#define ax_BREP_SOLID             12010001
#define ax_SHELL                  12010002
#define ax_FACE                   12010003
#define ax_LOOP                   12010004
#define ax_EDGE                   12010005
#define ax_VERTEX                 12010006

/* Surface class................. 1202xxxx */
#define ax_SURF_CLASS             12020000
#define ax_NURBS_SURF             12020001
#define ax_PLANE                  12020002
#define ax_CYLINDRICAL_SURF       12020003
#define ax_CONICAL_SURF           12020004
#define ax_SPHERICAL_SURF         12020005
#define ax_TOROIDAL_SURF          12020006
#define ax_REVOLUTION_SURF        12020007
#define ax_LINEAR_EXTRUSION_SURF  12020008
#define ax_SURF_CLASS_END         12029999 /* cf. at.c */
 
/* Curve class .................. 1203xxxx */
#define ax_CURVE_CLASS            12030000
#define ax_NURBS_CURVE            12030001
#define ax_CONIC_ARC              12030002
#define ax_CIRCULAR_ARC           12030003
#define ax_ELLIPTICAL_ARC         12030004
#define ax_HYPERBOLIC_ARC         12030005
#define ax_PARABOLIC_ARC          12030006
#define ax_LINE_SEGMENT           12030007
#define ax_POLYLINE_SEGMENTS      12030008
#define ax_TRIMMED_CURVE          12030009
#define ax_COMPOSITE_CURVE        12030010

/* Point class .................. 1204xxxx */
#define ax_POINT_CLASS            12040000
#define ax_POINT_1D               12040001
#define ax_POINT_2D               12040002
#define ax_POINT                  12040003

/* Control point class .......... 1205xxxx */
#define ax_CPOINT_CLASS           12050000
#define ax_CPOINT_ARRAY           12050001

/* Other ........................ 1206xxxx */
#define ax_OTHER                  12060000
#define ax_PLACEMENT              12060002
#define ax_VECTOR                 12060003
#define ax_SCALAR                 12060004
#define ax_SCALAR_ARRAY           12060005

/* Dummy ........................ 1209xxxx */
#define ax_UNUSED                 12091111

/*--------------------------------------------------------------------------*/

/* Type equivalence: returns non-zero if 2 types are in same class */

#define ax_type_eq(T1,T2) ( ((T1) / 10000) == ((T2) / 10000) )
#define ax_type_hard(T)   ( (T) % 10000 )

/*--------------------------------------------------------------------------*/

/* Generic node: All other nodes are "extensions" of ax_NODE */

typedef struct ax_node_rec
{
  ax_ENTITY entity;
} ax_NODE;

/*--------------------------------------------------------------------------*/

/* NOTE: All fields pointing to dynamic arrays MUST follow the entry field! */

typedef struct ax_node_dyn_3_rec
{
  ax_ENTITY entity;
  void *dyn_1;
  void *dyn_2;
  void *dyn_3;
} ax_NODE_dyn_3;

typedef struct ax_node_dyn_2_rec
{
  ax_ENTITY entity;
  void *dyn_1;
  void *dyn_2;
} ax_NODE_dyn_2;

typedef struct ax_node_dyn_1_rec
{
  ax_ENTITY entity;
  void *dyn_1;
} ax_NODE_dyn_1;

/*--------------------------------------------------------------------------*/

/* Topology nodes */

typedef struct ax_brep_solid_rec
{
  ax_ENTITY  entity;
  ax_ENTITY *shell;         /* [0..n-1] */
  ax_BIT    *shell_orient;  /* [0..n-1] */
  ax_INDEX  *shell_tree;    /* [0..n-1] */
  ax_INDEX   n;
} ax_BREP_SOLID_NODE;

typedef struct ax_shell_node_rec
{
  ax_ENTITY entity;
  ax_ENTITY *face;         /* [0..n-1] */
  ax_BIT    *face_orient;  /* [0..n-1] */
  ax_INDEX  n;
} ax_SHELL_NODE;

typedef struct ax_face_node_rec
{
  ax_ENTITY  entity;
  ax_ENTITY *loop;        /* [0..n-1] */
  ax_BIT    *loop_orient; /* [0..n-1] */
  ax_INDEX  *loop_tree;   /* [0..n-1] */
  ax_INDEX   n;
  ax_ENTITY  surf;
  ax_BIT     surf_orient;
} ax_FACE_NODE;

typedef struct ax_loop_node_rec
{
  ax_ENTITY  entity;
  ax_ENTITY *edge;         /* [0..n-1] */
  ax_BIT    *edge_orient;  /* [0..n-1] */
  ax_INDEX   n;
} ax_LOOP_NODE;

typedef struct ax_edge_node_rec
{
  ax_ENTITY entity;
  ax_ENTITY a, b;
  ax_ENTITY curve;
  ax_BIT    curve_orient;
} ax_EDGE_NODE;

typedef struct ax_vertex_node_rec
{
  ax_ENTITY entity;
  ax_ENTITY point;
} ax_VERTEX_NODE;

/*--------------------------------------------------------------------------*/

/* Surface nodes */

typedef struct ax_nurbs_surf_rec
{
  ax_ENTITY entity;
  ax_DEGREE p, q;
  ax_INDEX  n, m;
  ax_ENTITY cp;
  ax_ENTITY uk, vk;
  ax_FLAGS  flags;
  ax_FORM   form;
} ax_NURBS_SURF_NODE;

typedef struct ax_plane_node_rec
{
  ax_ENTITY entity;
  ax_ENTITY pl;
} ax_PLANE_NODE;

typedef struct ax_cylindrical_surf_node_rec
{
  ax_ENTITY entity;
  ax_ENTITY pl;
  ax_ENTITY r;
} ax_CYLINDRICAL_SURF_NODE;

typedef struct ax_conical_surf_node_rec
{
  ax_ENTITY entity;
  ax_ENTITY pl;
  ax_ENTITY r;
  ax_ENTITY al;
} ax_CONICAL_SURF_NODE;

typedef struct ax_spherical_surf_node_rec
{
  ax_ENTITY entity;
  ax_ENTITY pl;
  ax_ENTITY r;
} ax_SPHERICAL_SURF_NODE;

typedef struct ax_toroidal_surf_node_rec
{
  ax_ENTITY entity;
  ax_ENTITY pl;
  ax_ENTITY r1, r2;
} ax_TOROIDAL_SURF_NODE;

typedef struct ax_revolution_surf_node_rec
{
  ax_ENTITY entity;
  ax_ENTITY curve;
  ax_ENTITY c;
  ax_ENTITY axis;
  ax_ENTITY sa, sb;
} ax_REVOLUTION_SURF_NODE;

typedef struct ax_linear_extrusion_surf_node_rec
{
  ax_ENTITY entity;
  ax_ENTITY curve;
  ax_ENTITY vec;
} ax_LINEAR_EXTRUSION_SURF_NODE;

/*--------------------------------------------------------------------------*/

/* Curve nodes */

typedef struct ax_nurbs_curve_node_rec
{
  ax_ENTITY entity;
  ax_DEGREE p;
  ax_INDEX  n;
  ax_ENTITY cp;
  ax_ENTITY kn;
  ax_FLAGS  flags;
  ax_FORM   form;
} ax_NURBS_CURVE_NODE;

typedef struct ax_conic_arc_node_rec
{
  ax_ENTITY entity;
  ax_ENTITY pl;
  ax_REAL   A, B, C, D, E, F;
  ax_FORM   form;
  ax_ENTITY a, b;
} ax_CONIC_ARC_NODE;

typedef struct ax_circular_arc_node_rec
{
  ax_ENTITY entity;
  ax_ENTITY pl;
  ax_ENTITY r;
  ax_ENTITY a, b;
} ax_CIRCULAR_ARC_NODE;

typedef struct ax_elliptical_arc_node_rec
{
  ax_ENTITY entity;
  ax_ENTITY pl;
  ax_ENTITY r1;
  ax_ENTITY r2;
  ax_ENTITY a, b;
} ax_ELLIPTICAL_ARC_NODE;

typedef struct ax_hyperbolic_arc_node_rec
{
  ax_ENTITY entity;
  ax_ENTITY pl;
  ax_ENTITY a1;
  ax_ENTITY a2;
  ax_ENTITY a, b;
} ax_HYPERBOLIC_ARC_NODE;

typedef struct ax_parabolic_arc_node_rec
{
  ax_ENTITY entity;
  ax_ENTITY pl;
  ax_ENTITY f;
  ax_ENTITY a, b;
} ax_PARABOLIC_ARC_NODE;

typedef struct ax_line_segment_node_rec
{
  ax_ENTITY entity;
  ax_ENTITY a, b;
} ax_LINE_SEGMENT_NODE;

typedef struct ax_polyline_segments_node_rec
{
  ax_ENTITY  entity;
  ax_ENTITY *point;  /* [0..n-1] */
  ax_INDEX   n;
  ax_FLAGS   flags;
} ax_POLYLINE_SEGMENTS_NODE;

typedef struct ax_trimmed_curve_node_rec
{
  ax_ENTITY entity;
  ax_ENTITY curve;
  ax_BIT    orient;
  ax_ENTITY a, b;
} ax_TRIMMED_CURVE_NODE;

typedef struct ax_composite_curve_node_rec
{
  ax_ENTITY  entity;
  ax_ENTITY *segment;          /* [0..n-1] */
  ax_ENTITY *segment_orient;   /* [0..n-1] */
  ax_FORM   *transition_code;  /* [0..n-1] or NULL */
  ax_INDEX   n;
  ax_FLAGS   flags;
} ax_COMPOSITE_CURVE_NODE;

/*--------------------------------------------------------------------------*/

/* Point nodes */

typedef struct ax_point_node_rec
{
  ax_ENTITY entity;
  ax_REAL   coord[3];
} ax_POINT_NODE;

typedef struct ax_point_2d_node_rec
{
  ax_ENTITY entity;
  ax_REAL   coord[2];
} ax_POINT_2D_NODE;

/*--------------------------------------------------------------------------*/

/* Control point nodes */

typedef struct ax_cpoint_array_node_rec
{
  ax_ENTITY entity;
  ax_REAL *cp;  /* [0..(d+1)*n-1] */
  ax_INDEX n;
  ax_INDEX d;   /* d==3 */
} ax_CPOINT_ARRAY_NODE;

/*--------------------------------------------------------------------------*/

/* Other nodes */

typedef struct ax_placement_node_rec
{
  ax_ENTITY entity;
  ax_ENTITY c;
  ax_ENTITY axis;
  ax_ENTITY ref;
} ax_PLACEMENT_NODE;

typedef struct ax_vector_node_rec
{
  ax_ENTITY entity;
  ax_REAL   v[3];
} ax_VECTOR_NODE;

typedef struct ax_scalar_node_rec
{
  ax_ENTITY entity;
  ax_REAL   v;
} ax_SCALAR_NODE;

typedef struct ax_scalar_array_node_rec
{
  ax_ENTITY entity;
  ax_REAL *sc;  /* [0..n-1] */
  ax_INDEX n;
} ax_SCALAR_ARRAY_NODE;

/*--------------------------------------------------------------------------*/

/* Dummy --- NOTE: sizeof(ax_UNUSED) < sizeof(ax_ENTITY) !!! */

typedef char ax_UNUSED_NODE;

/*--------------------------------------------------------------------------*/

#if defined(__cplusplus)
}
#endif

#endif  /* #ifndef __AX_NODES_H__  */
