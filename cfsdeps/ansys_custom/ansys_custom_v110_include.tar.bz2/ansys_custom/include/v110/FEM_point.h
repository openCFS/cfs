/* sid 60.1 copy of FEM_point.h last changed by upd111 on 2005/07/21 19:40:55 */
/* CFILE FEM_point.h        meshing                                 alc */
/*
 * *** ansys(r) copyright(c) 1999
 * *** ansys, inc.
 */

/*************************************************************************
  PLEASE, UPDATE HISTORY FIELD BELOW WHEN YOU MAKE ANY MODIFICATION
 *************************************************************************
 Data type name : POINT_TYP
 Description    : This abstract data type represents a point in 3D space
                  with coordinates x,y,z. It also works as a 3D
                  vector in affine space, so you can perform dot and
                  cross products, etc. The list of operations on
                  points follows below.
 Notes          : Like any other abstract data type, POINT_TYP helps in
                  code writing, debugging, maintenance, ...
 Author         : alc
 History        : 06/27/96 - created by alc
 *************************************************************************
 Interfaces for POINT_TYP data type:

  Macros:

   FEM_ptSetValue_C          sets point coordinate values
   FEM_ptNorm_C              returns norm of point (as in vector norm)
   FEM_ptNorm2_C             returns sqr norm of point
   FEM_ptAssign_C            p = q
   FEM_ptSumAssign_C         p += q (coordinatewise)
   FEM_ptSumScalarAssign_C   p += a (sum a to each coordinate)
   FEM_ptSum_C               r = p + q
   FEM_ptSumScalar_C         r = p + a
   FEM_ptSum3_C              r = p + q + s
   FEM_ptSubAssign_C         p -= q
   FEM_ptSubScalarAssign_C   p -= a
   FEM_ptSub_C               r = p - q
   FEM_ptSubScalar_C         r = p - a
   FEM_ptMultAssign_C        p *= a
   FEM_ptMultScalar_C        r = p * a
   FEM_ptDivAssign_C         p /= a
   FEM_ptDivScalar_C         r = p/a
   FEM_ptDotProd_C           return dot product of points
   FEM_ptCrossProd_C         r = p X q, cross product (right hand rule)
   FEM_ptDist_C              macro version of FEM_ptDist below
   FEM_ptDist2_C             macro version of FEM_ptDist2 below
   FEM_prPrint_C             prints point coords on stderr

  Functions (defined in FEM_point.c file):

   FEM_ptNormalize      normalize point (becomes a unit vector)
   FEM_ptDist           euclidean distance of two points
   FEM_ptDist2          square dist (cheaper! - avoid sqrt)

 *************************************************************************/

#ifndef _POINT_TYP_H_
#define _POINT_TYP_H_

/**************************************************************************
  DEFINE POINT_TYP DATA TYPE
 **************************************************************************/

typedef struct POINT_TYP {
    DOUBLE   x,y,z;         /* 3D point coordinates */
} POINT_TYP;

/**************************************************************************
 POINT_TYP MACROS

  Note: p,q,r,s below denote points
   a,b,c denote scalar values
 **************************************************************************/


#define      FEM_ptSetValue_C(p,a,b,c) \
         (p)->x = (a); (p)->y = (b); (p)->z = (c)

#define      FEM_ptNorm_C(p) \
              sqrt(((p)->x*(p)->x + (p)->y*(p)->y + (p)->z*(p)->z))

#define      FEM_ptNorm2_C(p) \
         ((p)->x*(p)->x + (p)->y*(p)->y + (p)->z*(p)->z)

#define      FEM_ptAssign_C(p,q) \
         (p)->x = (q)->x; (p)->y = (q)->y; (p)->z = (q)->z

#define      FEM_ptSumAssign_C(p,q) \
         (p)->x += (q)->x; (p)->y += (q)->y; (p)->z += (q)->z

#define      FEM_ptSumScalarAssign_C(p,a) \
         (p)->x += (a); (p)->y += (a); (p)->z += (a)

#define      FEM_ptSum_C(r, p, q) \
         (r)->x = (p)->x + (q)->x; \
         (r)->y = (p)->y + (q)->y; \
         (r)->z = (p)->z + (q)->z

#define      FEM_ptSumScalar_C(r, p, a) \
         (r)->x = (p)->x + a; \
         (r)->y = (p)->y + a; \
         (r)->z = (p)->z + a

#define      FEM_ptSum3_C(r, p, q, s) \
         (r)->x = (p)->x + (q)->x + (s)->x; \
         (r)->y = (p)->y + (q)->y + (s)->y; \
         (r)->z = (p)->z + (q)->z + (s)->z

#define      FEM_ptSubAssign_C(p,q) \
         (p)->x -= (q)->x; (p)->y -= (q)->y; (p)->z -= (q)->z

#define      FEM_ptSubScalarAssign_C(p,a) \
         (p)->x -= (a); (p)->y -= (a); (p)->z -= (a)

#define      FEM_ptSub_C(r, p, q) \
         (r)->x = (p)->x - (q)->x; \
         (r)->y = (p)->y - (q)->y; \
         (r)->z = (p)->z - (q)->z

#define      FEM_ptSubScalar_C(r, p, a) \
         (r)->x = (p)->x - a; \
         (r)->y = (p)->y - a; \
         (r)->z = (p)->z - a

#define      FEM_ptMultAssign_C(p,a) \
         (p)->x *= (a); (p)->y *= (a); (p)->z *= (a)

#define       FEM_ptMultScalar_C(r, p, a) \
         (r)->x = (p)->x * a; \
         (r)->y = (p)->y * a; \
         (r)->z = (p)->z * a

#define      FEM_ptDivAssign_C(p,a) \
         (p)->x /= (a); (p)->y /= (a); (p)->z /= (a)

#define       FEM_ptDivScalar_C(r, p, a) \
         (r)->x = (p)->x / a; \
         (r)->y = (p)->y / a; \
         (r)->z = (p)->z / a

#define      FEM_ptDotProd_C(p,q) \
         ((p)->x*(q)->x + (p)->y*(q)->y + (p)->z*(q)->z)

#define      FEM_ptCrossProd_C(r, p, q) \
         (r)->x = (p)->y * (q)->z - (p)->z * (q)->y; \
         (r)->y = (p)->z * (q)->x - (p)->x * (q)->z; \
         (r)->z = (p)->x * (q)->y - (p)->y * (q)->x

#define      FEM_ptDist_C(r, p, q, a) \
         FEM_ptSub_C(r, p, q); \
         (a) = FEM_ptNorm_C(r)

#define      FEM_ptDist2_C(r, p, q, a) \
         FEM_ptSub_C(r, p, q); \
         (a) = FEM_ptNorm2_C(r)

#define      FEM_ptPrint_C(p) \
      fprintf(stderr,"x = %f y = %f z = %f\n",(p)->x,(p)->y,(p)->z) 


/**************************************************************************
 POINT_TYP PROTOTYPES
 **************************************************************************/

void        FEM_ptNormalize(POINT_TYP*);
DOUBLE      FEM_ptDist(const POINT_TYP*, const POINT_TYP*);
DOUBLE      FEM_ptDist2(const POINT_TYP*, const POINT_TYP*);
INT         FEM_ptNormalOf4Points( VECTOR3D *p0, VECTOR3D *p1,
                                   VECTOR3D *p2, VECTOR3D *p3,
                                   DOUBLE *xn, DOUBLE *yn, DOUBLE *zn );
INT         FEM_ptNormalOf3Points( VECTOR3D *p0, VECTOR3D *p1, VECTOR3D *p2,
                                   DOUBLE *xn, DOUBLE *yn, DOUBLE *zn );

#endif /* _POINT_TYP_H_ */
