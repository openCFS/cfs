/* sid 60.4 copy of MAT_CApi.h last changed by jtm on 2006/05/16 13:52:38 */
/*
////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         copyright(c) 2006 SAS IP, Inc.  All rights reserved.             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MAT_API.h $
// $Revision$ 7.0
// $Date$ March 28 2002
// $Author$ rjayasee/jlo
//
// Decription :
//
// This class defines the C API for the whole material subsystem  or
// component. This provides handles to the material data and the tools
// to generate or manipulate them.
// This can be used from C or C++
////////////////////////////////////////////////////////////////////////////
*/

#if !defined(MAT_CAPI)
#define MAT_CAPI


struct MAT_CFAttribute
{
    char* m_pName ;
    /* Name of the Attribute */

    double* m_dValue ;
    /* Value of the Attribute in double form */

    char* m_sValue ;
    /* Value of the Attribute in string form  */

    INT* m_iValue ;
    /* Value of the Attribute in integer form */
} ;

#ifdef __cplusplus
extern "C"
{
#endif

    INT ConstructConstitutiveModel_(INT oMatID ) ;
   /*
    //R-INT
    //R-0 for failure/ 1 for success
    //I-oMatID
    //I-Material ID
    //F-Function To Construct A Constitutive Model
    */

    INT MAT_IsCaseCreationOn() ;
    /*
     //Return 1 of the Case portion of the code has started
    */
    INT MAT_GetNumMatIds() ;
/*
    //R Returns the number of MatIds
*/

    INT GetMaterialIDList_( INT** pMatIDList,
                            INT* pNumMatIDs ) ;
    /*
    //R void
    //O oMatIDList
    //O-Vector of Material ID List
    //O pNumMatIDs
    //O-Number of Material IDs
    //- This function returns a vector of material id list
    //- Memory assigned for the array only within the function delete it outside
    //- using malloc and free
    */

    INT GetConstitutiveFunctionNameList_( INT iMatID,
                                           char*** oConsFuncNameList,
                                           INT* pNumConsFuncs ) ;
    /*
    //R INT
    //R 0 implies failure
    //I iMatId
    //I-Material ID
    //O oConsFuncNameList
    //O-List of Constitutive Function Names
    //O pNumConsFuncs
    //O Number of Constitutive Function Names
    //- This function returns a list of constitutive function names
    //- Memory assigned for the array oConsFuncNameList within the function delete it outside
    //- using malloc and free
    */

    INT MAT_GetNumExpNames( INT iMatID,
                            INT* pMaxNameSize,
                            INT* pNumExpNames ) ;
/*
    //R Success or Failure
    //I iMatId
    //- Material Id
    //  pMaxNameSize
    //- Maximum Name Size
    //  pNumExpNames
    //- Number of Experiment Names
    //- Returns the Number of Experiment and Max Size of Name
*/

    INT GetExperimentNameList_( INT iMatID,
                                 char*** oExpNameList,
                                 INT* pNumExpNames) ;
    /*
    //R INT
    //R 0 implies failure
    //I iMatId
    //I-Material ID
    //I oConsFuncName
    //I-Name of the Constitutive Function
    //O oExpNameList
    //O-List of Experiment Names
    //O pNumExpNames
    //O-Number of Experiment Names
    //- This function returns a list of experiment names given
    //- a Material Id and a Constitutive Function Name
    */

    INT GetNumberOfExperimentalDataPoints_( INT iMatID,
                                            INT iExpID,
                                            INT* pNumPoints ) ;
    /*
    //R INT
    //R 0 implies failure
    //I iMatId
    //I-Material ID
    //I oConsFuncName
    //I-Name of the Constitutive Function
    //I iExpID
    //I-Experiment ID
    //O pNumPoints
    //O- Number of Points
    //- Returns the number of points in the experimental data
    */
   
    INT MAT_GetFittedExperimentalDataPointSize( INT iMatID,
                                                char* pConsFuncName,
                                                INT iExpID,
                                                INT iPointId ) ;
/*
    //R 1 or 0
    //I iMatId
    //I-Material ID
    //I pConsFuncName
    //I-Name of Constitutive Function
    //I iExpID
    //I-Experiment ID
    //I iPointId
    //I-Index of Point
    //- This function returns the number of terms 
    //- coordinates of a point in an ExperimentalData Object
    //- But here it is the the "curve fitted" coordinate points
*/

    INT GetExperimentalDataPoint_( INT iMatID,
                                   INT iExpID,
                                   INT iPointId,
                                   double** pPointCoords,
                                   INT* iNumCoords ) ;
    /*
    //R INT
    //R 0 implies failure
    //I iMatId
    //I-Material ID List
    //I oConsFuncName
    //I-Name of the Constitutive Function
    //I iExpID
    //I-Experiment ID
    //I iPointID
    //I-Point to be read/data extracted
    //I pPointCoords
    //I-Array of Coordinates
    //I pNumCoords
    //I-Number of Coordinate Points
    //- This function returns the coordinates of a point in an ExperimentalData Object
    */

    void MAT_GetExtendedExperimentName( INT iMatID,
                                        char* pConsFuncName,
                                        char* pShortName,
                                        char* pExtName ) ;
    /*
    //R void
    //I iMatId
    //I-Material ID List
    //I oConsFuncName
    //I-Name of the Constitutive Function
    //I pShortName
    //I pExtName
    //- Full Detailed Name of the Experiment
    */

    INT GetResidual_( INT iMatID,
                      char* pConsFuncName,
                      double* pResidual ) ;
   /*
    //R bool
    //I iMatId
    //I-Material ID List
    //I pConsFuncName
    //I-Name of the Constitutive Function
    //- This function returns the calculated residual
    */

    INT GetFittedExperimentalDataPoint_( INT iMatID,
                                          char* oConsFuncName,
                                          INT iExpID,
                                          INT iPointId,
                                          double** pPointCoords,
                                          INT* iNumCoords ) ;
    /*
    //R INT
    //R 0 implies failure
    //I iMatId
    //I-Material ID List
    //I oConsFuncName
    //I-Name of the Constitutive Function
    //I iExpID
    //I-Experiment ID
    //I iPointID
    //I-Point to be read/data extracted
    //I pPointCoords
    //I-Array of Coordinates
    //I pNumCoords
    //I-Number of Coordinate Points
    //- This function returns the coordinates of a point in an ExperimentalData Object
    //- But here is the the "curve fitted" coordinate points
    //- Again memory for pPoint is allocated internally
    */

    INT AddConstitutiveFunction_ ( INT oMatID,
                               char* const pFunctionName,
                               struct MAT_CFAttribute* pAttrList,
                               INT iNumAttribs ) ;
    /*
    //R-INT result status
    //I INT iMatID
    //I-Material ID
    //I char* pFunctionName
    //I-Name of the constitutive function
    //I-pAttrList
    //I-List of Attributes for the ConstitutiveFunction
    //- Adds a constitutive function
    */
        
    INT AddConstitutiveFunctionWithAttribs_ ( struct MAT_CFAttribute* pAttrList,
                                              INT iNumAttribs ) ;
    /*
    //R-INT result status
    //I-pAttrList
    //I-List of Attributes for the ConstitutiveFunction
    //I-iNumAttribs
    //I-Number of Attributes
    //- Adds a Constitutive Function specified in the Attribute list
    */

    INT  AddExperimentalData_
        ( INT oMatID,
          char* const oFileName,
          char* oExpName,
          char** oExpVarNames,
          INT oNumVarNames ) ;
    /*
    //R-INT result status
    //I-oMatID
    //I-Material ID
    //I-pFunctionName
    //I-Constitutive Function Name
    //I-oFileName
    //I-File Name to be read from
    //I-oExpName
    //I-Experiment Name
    //I-oExpVarNames
    //I-Variable Names in the Experimental Data
    //I-oNumVarNames
    //I-Number of Variable Names
    //-Interface To Construct An Experimental Data Object
    */

    INT  AddExperimentalDataWithAttribs_
        ( struct MAT_CFAttribute* pMTAttrList,
          INT iMTNumAttribs,
          struct MAT_CFAttribute* pExpDataAttrList,
          INT iExpDataNumAttribs) ;
    /*
    //R-INT result status
    //I-pMTAttrList
    //I-List of Material Definition Attributes for the ConstitutiveFunction
    //I-iMTNumAttribs
    //I-Number of Attributes
    //I-pExpDataAttrList
    //I-List of Experimental Data Attributes for the ConstitutiveFunction
    //I-iExpDataNumAttribs
    //I-Number of Attributes
    //- Constructs an Experimental Data with input specified as Attributes
    */

    INT  GenerateMaterialParameters_
        ( INT oMatID,
          char* const pFunctionName ,
          struct MAT_CFAttribute* pSolDataAttrList,
          INT iNumSolAttribs) ;
    /*
    //R-INT result status
    //I-oMatID
    //I-Material ID
    //I-pFunctionName
    //I-Constitutive Function Name
    //I-pSolDataAttrList
    //I-List of Experimental Data Attributes for the ConstitutiveFunction
    //I-iNumSolAttribs
    //I-Number of Attributes
    //- Interface To Generate Material Parameters
    */


    INT   SetConstitutiveFunctionDataSet_
        ( INT oMatID,
          char*  pFunctionName,
          char** pParameterName,
          double* pParameterData,
          INT   iNumParameters ) ;
    /*
    //R-INT result status
    //I-oMatID
    //I-Material ID
    //I-pFunctionName
    //I-Constitutive Function Name
    //I-pParameterName
    //I-Array of Parameter Names
    //I-pParameterData
    //I-Array of Parameter Values
    //- Sets some of the Constitutive Function Data Manually
    */

    INT SetConstitutiveFunctionStringData_ ( INT iMatID,
                                             char* pConsFuncName,
                                             char* pCoeffName,
                                             char* pCoeffValue ) ;
    /*
    //R Result
    //I pConsFuncName
    //I-Name of the Constitutive Function
    //I iCoeffNum
    //I-Index of the Coefficient
    //I dCoeff
    //I-Value of the Coefficient
    //- Set the Coeffiecient in a Constitutive Function
    */

    INT SetConstitutiveFunctionData_ ( INT iMatID,
                                       char* pConsFuncName,
                                       char* pCoeffName,
                                       double iCoeff ) ;
    /*
    //R Result
    //I pConsFuncName
    //I-Name of the Constitutive Function
    //I iCoeffNum
    //I-Index of the Coefficient
    //I dCoeff
    //I-Value of the Coefficient
    //- Set the Coeffiecient in a Constitutive Function
    */

    INT   GetConstitutiveFunctionData_
        ( INT oMatID,
          char* pConsFuncName,
          char*** pParameterName,
          double** pParameterData,
		  INT* pNumParams ) ;
    /*
    //R-INT result status
    //I-oMatID
    //I-Material ID
    //I-pConsFuncName
    //I-Constitutive Function Name
    //O-pParameterName
    //O-Array of Parameter Names
    //O-pParameterData
    //O-Array of Parameter Values
    //- Gets some of the Constitutive Function Data Manually
    */
    
    INT MAT_SetConstitutiveFunctionCoefficientFixedFlag
        ( INT iMatID,
          char* oConsFuncName,
          INT iCoeffIndex,
          INT iCoeffFixedFlag ) ;
    /*
    //R-bool
    //R-1 if success. Fails if the MaterialID or the
    //R-function type does not exist.
    //I-iMatID
    //I-ID of the Material Model
    //I-oConsFuncName
    //I-Constitutive Function Name
    //I iCoeffIndex
    //I-Index of the Coeff
    //I bCoeffFixed
    //I-If the coeff is fixed use 1 else use 0
    //- Function to Set if the Coeff is Fixed
    */

    INT MAT_GetConstitutiveFunctionCoefficientFixedFlag
        ( INT iMatID,
          char* oConsFuncName,
          INT iCoeffIndex,
          INT* iCoeffFixedFlag ) ;
    /*
    //R-bool
    //R-1 if success. Fails if the MaterialID or the
    //R-function type does not exist.
    //I-iMatID
    //I-ID of the Material Model
    //I-oConsFuncName
    //I-Constitutive Function Name
    //I iCoeffIndex
    //I-Index of the Coeff
    //O bCoeffFixed
    //O-If the coeff is fixed use 1 else use 0
    //- Function to Get if the Coeff is Fixed
    */
        
    INT   PrintConstitutiveModel_ ( INT oMatID ) ;
    /*
    //R-INT result status
    //I-oMatID
    //I-Material ID
	//F-Print ConstitutiveModel Data
    */

    INT DeleteConstitutiveModel_(INT iMatID ) ;
    /*
    //R-INT
    //R-0 for failure/ 1 for success
    //I-oMatID
    //I-Material ID
    //F-Function To Delete A Constitutive Model
    */

    INT DeleteConstitutiveFunctionWithAttribs_ ( struct MAT_CFAttribute* pAttrList,
                                                 INT iNumAttribs ) ;
    /*
    //R-INT result status
    //I-pAttrList
    //I-List of Attributes for the ConstitutiveFunction
    //I-iNumAttribs
    //I-Number of Attributes
    //- Deletes a Constitutive Function specified in the Attribute list
    */

    INT MAT_DeleteCoefficients(struct MAT_CFAttribute* pMTAttrList,
                               INT iMTNumAttribs ) ;
    /*
    //R Result Status
    //I pMATAttrList
    //I-Attribute List
    //I iMTNumAttribs
    //I-Number of Attribs
    */

    INT  DeleteExperimentalDataWithAttribs_
        ( struct MAT_CFAttribute* pMTAttrList,
          INT iMTNumAttribs,
          struct MAT_CFAttribute* pExpDataAttrList,
          INT iExpDataNumAttribs) ;
    /*
    //R-INT result status
    //I-pMTAttrList
    //I-List of Material Definition Attributes for the ConstitutiveFunction
    //I-iMTNumAttribs
    //I-Number of Attributes
    //I-pExpDataAttrList
    //I-List of Experimental Data Attributes for the ConstitutiveFunction
    //I-iExpDataNumAttribs
    //I-Number of Attributes
    //- Deletes an Experimental Data Object with input specified as Attributes
    */

    void MAT_ConstructAttributeWithMalloc( struct MAT_CFAttribute* pAttrib,
                                           INT iSizeOfString ) ;
    /*
    //R void
    //I pAttrib
    //I-Pointer to Attribute
    //I iSizeOfString
    //I-Size of String
    //- Constructs And Attribute with Malloc
    */

    void MAT_CleanUpAttributeWithFree( struct MAT_CFAttribute* pAttrib) ;
    /*
    //R void
    //O pAttrib
    //O-Pointer to Attribute
    //- Cleans an Attribute contents with the Free function
    */

    void MAT_CleanUpAttributeArrayWithFree( struct MAT_CFAttribute** pAttrib,INT iSizeOfArray) ;
    /*
    //R void
    //I pAttrib
    //I-Pointer to Attribute
    //I iSizeOfArray
    //I-Size of Array
    //- Delets an Attribute Array with the Free function
    */

    INT GetAttributeIValue_( struct MAT_CFAttribute* pAttList, 
                             INT iNumAtts, 
                             char* pAttName,
                             INT* iValue ) ;
    /*
    //R-INT result status
    //I-pAttrList
    //I-List of Attributes for the ConstitutiveFunction
    //I-iNumAttribs
    //I-Number of Attributes
    //I-pAttName
    //I-Attribute Name
    //O-iValue
    //O-The value of the attribute
    //- Returns the integer value of the first matching attribute
    */

    INT GetAttributeDValue_( struct MAT_CFAttribute* pAttList, 
                             INT iNumAtts, 
                             char* pAttName,
                             double* dValue ) ;
    /*
    //R-INT result status
    //I-pAttrList
    //I-List of Attributes for the ConstitutiveFunction
    //I-iNumAttribs
    //I-Number of Attributes
    //I-pAttName
    //I-Attribute Name
    //O-dValue
    //O-The value of the attribute
    //- Returns the double value of the first matching attribute
    */

    INT GetAttributeSValue_( struct MAT_CFAttribute* pAttList, 
                           INT iNumAtts, 
                           char* pAttName,
                           char* sValue ) ;
    /*
    //R-INT result status
    //I-pAttrList
    //I-List of Attributes for the ConstitutiveFunction
    //I-iNumAttribs
    //I-Number of Attributes
    //I-pAttName
    //I-Attribute Name
    //O-sValue
    //O-The value of the attribute
    //- Returns the string value of the first matching attribute
    */

    INT MAT_SetAttributeIValue( struct MAT_CFAttribute* pAttList, 
                                INT iNumAtts, 
                                char* pAttName,
                                INT iValue ) ;
    /*
    //R-INT result status
    //I-pAttrList
    //I-List of Attributes for the ConstitutiveFunction
    //I-iNumAttribs
    //I-Number of Attributes
    //I-pAttName
    //I-Attribute Name
    //O-iValue
    //O-The value of the attribute
    //- Sets the integer value of the first matching attribute
    */

    INT MAT_SetAttributeDValue( struct MAT_CFAttribute* pAttList, 
                                INT iNumAtts, 
                                char* pAttName,
                                double dValue ) ;
    /*
    //R-INT result status
    //I-pAttrList
    //I-List of Attributes for the ConstitutiveFunction
    //I-iNumAttribs
    //I-Number of Attributes
    //I-pAttName
    //I-Attribute Name
    //O-dValue
    //O-The value of the attribute
    //- Sets the double value of the first matching attribute
    */

    INT MAT_SetAttributeSValue( struct MAT_CFAttribute* pAttList, 
                                INT iNumAtts, 
                                char* pAttName,
                                char* sValue ) ;
    /*
    //R-INT result status
    //I-pAttrList
    //I-List of Attributes for the ConstitutiveFunction
    //I-iNumAttribs
    //I-Number of Attributes
    //I-pAttName
    //I-Attribute Name
    //O-sValue
    //O-The value of the attribute
    //- Sets the string value of the first matching attribute
    */

    INT GetAttributePosition_( char* pAttrName, struct MAT_CFAttribute* pAttribList, INT iNAttribs ) ;
        /*
    //R-INT returns the position of the attribute in the array
    //I-pAttrName
    //I-Attribute Name
    //I-pAttribList
    //I-List of Attributes
    //I-iNAttribs
    //I-Number of Attributes
    //O-sValue
    //O-The value of the attribute
    //- Returns the string value of the first matching attribute
    */

    INT CreateDefaultAttributes_() ;
    /*
    //R void
    //- Initialized the data structure for the (ansys?) command interface
    //-
    */

    void MAT_Clear() ;
    /*
    //R void
    //- Clears the Material Inmemory Data
    */

#ifdef __cplusplus
}
#endif

#endif     
/*
// !defined( MAT_CAPI_H )
*/
