/* sid 60.4 copy of CconfigBase.h last changed by ltomaso on 2006/06/29 15:37:55 */
/* CConfig.h CADOE doeinc */
/*! \file CConfig.h

  \brief This header file defines the CConfig class.

  \author Gilles VENET &copy; CADOE

  \date January 2004
*/
#ifndef __cconfigbaseh__ 
#define __cconfigbaseh__ 1 

#include "CCadoePortable.h"
#include "CDesignSet.h"
#include "CParameterMgr.h"
#include "CParameter.h"
#include "cbf.h"
#include "expmdb_struct.h"
#include "CModeleBase.h"

#include "m_matrix.h"

class CConfigMgrBase;

typedef struct __Modele T_Modele;

/*! \class CConfig CConfig.h
  \brief The CConfig class is used to contain model ADOMESH
  */
class CConfigBase
{
  //friend class CConfig;

public:
	enum EcodeParam
	{
    ValMin = 1,
    ValMax,
    ValRef,
    ValPP
	};
	typedef map<string,EcodeParam> TypeParam;

	CConfigBase();
	CConfigBase( int, int);
	virtual ~CConfigBase();

  int initialise ( void );

	int getId( void ) const { return _numero; }
	int getPartInitId( void ) const { return _partInitID; }
	int getPartTargetId( void ) const { return _partTargetID; }	
	double getDeformation( void ) const { return _deformation; }
//  int getMeshId ( ) const { return _meshID; }
  EcodeParam getParameterCode( const string &pName="" ) const;
	double getParameterShape( const string &pName="" ) const;
  double getValParameter ( string nom ) const ;
  CDesignSet *getDesignSet ( ) { return _designset; }

	int setName( const string &name );
	void setValue( const string &name, const double val ) { _designset->setValue(name, val); }
	void setId( const int val ) { _numero = val; }
	void setPartInitId( const int val ) { _partInitID = val; }
	void setPartTargetId( const int val ) { _partTargetID = val; }
	void setDeformation( const double val ) { _deformation = val; }
  void setParameterCode ( const string &pName, const EcodeParam val ) { _code[pName] = val; }
  void setParameterShape ( const string &pName, const EcodeParam val ) { _shape[pName] = val; }
  void setMaxReduction ( int reduit ) { _MaxReduction = reduit; }
  void  setMeshId ( int meshID ) { _meshID = meshID; }
  bool getParameterName( const int indice, string &) const ;
  int readConfig ( T_cbf *vaf, T_cbf_header  *tmph );
  bool readConfig ( FILE *fic );
  bool isConfigUseThisParameter ( string param );
  void toProcess ( const bool a_traiter ) { _a_traiter = a_traiter; }
  bool isToProcess ( ) { return _a_traiter; }
  bool isMonoParam ();
  bool isMonoParamValPP ();
  bool  getFirstParameterName( string &);
  bool  getNextParameterName( string &);
  int   getNumberOfParameters ();
  void removeParameter ( const string name );
  void majTconfig ( T_Config *cfg );
  void setResultat ( T_Resultat *res ) { _res = res; }
  void getResultat ( T_Resultat **res ) { *res = _res; }
  void setRepere ( T_ltete *rep ) { _rep = rep; }
  void getRepere ( T_ltete **rep ) { *rep = _rep; }
  void showParameters();

  CModeleBase *getModele ();
	bool isEquivalent ( CDesignSet *dset, CConfigBase::EcodeParam type );
  void setCfgMgr ( CConfigMgrBase *cfgmgr ) { _CfgMgr = ( void * ) cfgmgr; }
  CConfigMgrBase *getCfgMgr ( void ) { return ( CConfigMgrBase * ) _CfgMgr; }

protected:

	int 		_reduite;        /* Nombre de fois ou la config a deja ete reduite */
	int			_MaxReduction; /*Nombre maximum de reduction */
	bool      _a_traiter;    	/* signale config a traiter */
  double        _deformation;    /* Deformation estimee de la config */
  CDesignSet *_designset;
  int _meshID;
  int     	_numero;  	/* numero de la config */
  int _partInitID;
  int _partTargetID;
  T_Resultat    *_res;           /* Maillage perturbe */
  void *_CfgMgr;
  
private:
	typedef map<string,double> ParamValues;
  void raz_config ( void );

  bool  	_initialized;
	ParamValues		_ref;	/* valeur de reference de la config */
  TypeParam    	_code; 		/* codes de valeur des parametres : VALMIN, VALMAX, VALREF */
  TypeParam    	_shape; 	/* codes de valeur des parametres : VALMIN, VALMAX, VALREF */
  void     *_support;       /* support geometrique de la configuration */
  T_ltete  *_rep;
//  void		*_geom;
  int _curP;
};


#endif
