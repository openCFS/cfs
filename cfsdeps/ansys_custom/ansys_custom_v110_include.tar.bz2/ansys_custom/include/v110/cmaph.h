/* sid 60.1 copy of cmaph.h last changed by jtm on 2006/05/15 19:43:50 */
/* 
 * *** copyright(c) 2006 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */
#if defined(PCWINNT_SYS)
    /*  fortran routines called from c  */
extern LPTHREAD_START_ROUTINE CALLTYP cmap_( char [] ,int, char [], int, int *, int * );
#endif

void   CALLTYP xstart_( void );
void   CALLTYP cmapstop_( void );
