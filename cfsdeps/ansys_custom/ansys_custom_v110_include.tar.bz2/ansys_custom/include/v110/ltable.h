/* sid 60.1 copy of ltable.h last changed by upd111 on 2006/10/27 16:52:13 */
/* ANSI_C ltable.h - String lookup tables via ternary search trees (TSTs) */

/*--------------------------------------------------------------------------*/
/* Origin: Public Domain */
/*--------------------------------------------------------------------------*/

#ifndef __ltable_H_FILE__  /* Include this file only once! */
#define __ltable_H_FILE__

#ifdef __cplusplus
extern "C" {
#endif

/*--------------------------------------------------------------------------*/

/* For additional code check use -D__lint or -DDEVELOPMENT */
/* NOTE: -D__lint *might* invalidate the code in some system #include files! */

#if (defined(__lint) || defined(DEVELOPMENT)) && !defined(ltable_lint)
# define ltable_lint
#endif

/*--------------------------------------------------------------------------*/

/* ltable_iCONST() to avoid compiler warnings about constant conditionals */

#ifdef ltable_lint
  int ltable_iCONST (int id);
#else
# define ltable_iCONST  /*relax*/
#endif

/*--------------------------------------------------------------------------*/

/* Abstract data type (ADT) for char string lookup table */

typedef void *LTABLE;

/*--------------------------------------------------------------------------*/

/* Interface functions */

LTABLE ltable_new    (void);
void   ltable_clear  (LTABLE table);
int    ltable_insert (LTABLE table, char s[], void *pointer);
void  *ltable_search (LTABLE table, char s[]);
void   ltable_free_f (LTABLE table);

#define ltable_free(table) \
if (ltable_iCONST (1)) {  ltable_free_f (table); table = NULL; } else {;}

/* NOTE: ltable_free() is implemented as a macro to avoid dangling pointers */

/*--------------------------------------------------------------------------*/

/* Info inquiries */

typedef struct ltable_info_struct
{
  int size_of_node;
  int nodes;
} LTABLE_INFO;

LTABLE_INFO *ltable_info (LTABLE table);

/*--------------------------------------------------------------------------*/

/* User-defined memory management and error handling */

void ltable_malloc_hooks (void * (* user_malloc)  (size_t size),
                          void * (* user_realloc) (void *p, size_t size),
                          void   (* user_free)    (void *p));

void ltable_error_hook (void (* user_error) (const char msg[]));

/*--------------------------------------------------------------------------*/

#if defined(__cplusplus)
}
#endif

#endif  /* #ifndef __ltable_H_FILE__ */
