/* sid 60.1 copy of ansResultDisptypes.h last changed by jrb on 2006/05/31 17:49:42 */

#include "ansysdef.h"


extern  INT  cCreateAnsResultDisp(void);
extern  INT  cDeleteAnsResultDisp(void);
extern  INT  cInquireAnsResultDisp(INT,INT,INT,INT);
extern  INT  cPutAnsResultDisp(INT,INT,INT,DOUBLE);
extern  INT  cGetAnsResultDisp(INT,INT,INT,INT*,DOUBLE*);
extern  INT  cActivateAnsResultDisp(INT,INT,INT,INT);
extern  INT  cDumpAnsResultDisp(INT);

#define RDSP_REAL   -4001
#define RDSP_CPLX   -4002


/****************************************************************
 global-level structure for ANSYS nodal result displacements
 ****************************************************************/
struct ansResultDisp_str {     /* Name of the structure                                            */
  INT       tag;               /* Tag for this instance of the result displacement structure       */
  INT       numRealDispNodes;  /* Number of nodes with real-value result displacements             */
  INT       numCplxDispNodes;  /* Number of nodes with complex-value result displacements          */
  INT       maxRealDispNode;   /* Maximum external node number having real result displacement     */
  INT       maxCplxDispNode;   /* Maximum external node number having complex result displacement  */
  INT       numRealDisp;       /* Total number of real result displacements (zero and non-zero)    */
  INT       numCplxDisp;       /* Total number of complex result displacements (zero and non-zero) */
};

#define ansResultDispTag(rdisp)                (rdisp->tag)
#define ansResultDispNumRealDispNodes(rdisp)   (rdisp->numRealDispNodes)
#define ansResultDispNumCplxDispNodes(rdisp)   (rdisp->numCplxDispNodes)
#define ansResultDispMaxRealDispNode(rdisp)    (rdisp->maxRealDispNode)
#define ansResultDispMaxCplxDispNode(rdisp)    (rdisp->maxCplxDispNode)
#define ansResultDispNumRealDisp(rdisp)        (rdisp->numRealDisp)
#define ansResultDispNumCplxDisp(rdisp)        (rdisp->numCplxDisp)



/******************************************************************
 data-level structure for ANSYS nodal result displacements
 ******************************************************************/
struct resultDispData_str {  /* Name of the structure                                          */
  char            modified;  /* Flag indicating whether this result disp has been modified     */
  char            internal;  /* Flag indicating whether this result disp is internal to object */
  INT             dof;       /* External DOF value                                             */
  char            active;    /* Flag indicating if result disp is active or inactive           */
  DOUBLE          value;     /* Result displacement value                                      */
  resultDispData *nextDisp;  /* Pointer to the next result disp data structure for this        */
                             /* node.  If this pointer is NULL, then this is the last          */
                             /* stored result displacement for this node                       */
};

#define resultDispDataModified(rdData)         (rdData->modified)
#define resultDispDataInternal(rdData)         (rdData->internal)
#define resultDispDataDof(rdData)              (rdData->dof)
#define resultDispDataDispActive(rdData)       (rdData->active)
#define resultDispDataValue(rdData)            (rdData->value)


#define resultDispDataNextDispPtr(rdData)      (rdData->nextDisp)

