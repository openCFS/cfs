/* sid 60.2 copy of FEM_mqAngleClassifier.h last changed by upd111 on 2006/03/27 19:00:41 */
#ifndef _FEM_MQANGLECLASSIFIER_
#define _FEM_MQANGLECLASSIFIER_
#ifdef __cplusplus
extern "C" {
#endif
    
void FEM_mqSetAreaAngles(INT iArea, DOUBLE dCorner, DOUBLE dEnd, DOUBLE dSide );
void FEM_mqResetAreaAngles( INT iArea );
void FEM_mqGetAreaAngles(INT iArea, DOUBLE *pdCorner, DOUBLE *pdEnd, DOUBLE *pdSide);
void FEM_mqResetAllAreas();
void FEM_mqCreateClassifier();
void FEM_mqDeleteClassifier();

#ifdef __cplusplus
}
#endif
#endif