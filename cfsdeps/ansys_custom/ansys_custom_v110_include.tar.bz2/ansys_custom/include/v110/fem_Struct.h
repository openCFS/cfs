/* sid 60.4 copy of fem_Struct.h last changed by upd111 on 2007/01/02 21:03:19 */
/*  fem_Struct.h */
/* 
 * *** ansys(r) copyright(c) 1999
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  fem_Struct.h
 *  Contains the structures for the various data representations used by
 *  the FEM (finite element mesh) module
 *
 *  Note: This file should only be included in fem_Private.h.  Include
 *  fem_Private.h if FEM_ data structures are needed.  Do not access 
 *  structure fields directly in any of these data structures.  You should
 *  use the C++ style reader and writer functions provided for accessing
 *  data.  Do not use any of the structures provided here directly.  You
 *  should you one of the _OBJ types defined in FEM_Public.h.  This will
 *  allow us to generically use any data representation we need regardless
 *  of the application.  Before accessing any of the data in these structures
 *  the private functions will first cast the _OBJ type to its appropriate
 *  structure pointer type based on the current g_meshtype.
 *
 */
#ifndef FEM_STRUCT
#define FEM_STRUCT

/*
 * ***  Standard Data Representation 
 * ***  (g_meshtype == STANDARD_MESH)
 */

typedef struct NODE_TYP     *NODE_PTYP;
typedef struct EDGE_TYP     *EDGE_PTYP;
typedef struct FACE_TYP     *FACE_PTYP;
typedef struct ELEMENT_TYP  *ELEMENT_PTYP;

typedef struct NODELIST_TYP     *NODELIST_PTYP;
typedef struct EDGELIST_TYP     *EDGELIST_PTYP;
typedef struct FACELIST_TYP     *FACELIST_PTYP;
typedef struct ELEMENTLIST_TYP  *ELEMENTLIST_PTYP;

typedef struct NEXTELEMENT_TYP *NEXTELEMENT_PTYP;
typedef struct NEXTFACE_TYP    *NEXTFACE_PTYP;
typedef struct NEXTEDGE_TYP    *NEXTEDGE_PTYP;
typedef struct NEXTNODE_TYP    *NEXTNODE_PTYP;
typedef struct LINK_TYP        *LINK_PTYP;
typedef struct DEQUE_TYP       *DEQUE_PTYP;
typedef struct OBJINFO_TYP     *OBJINFO_PTYP;

typedef struct FACEUSE_TYP *FACEUSE_PTYP;
typedef struct EDGEUSE_TYP *EDGEUSE_PTYP;

/* 
 * === The global mesh structure
 * --- contains pointers to all data types
 */

typedef struct MESH_TYP *MESH_PTYP;

#ifdef __cplusplus
extern "C" {
#endif

extern MESH_PTYP gps_mesh;

#ifdef __cplusplus
}
#endif

typedef struct MESH_TYP{
   ELEMENTLIST_PTYP ps_elist;
   FACELIST_PTYP    ps_flist;
   EDGELIST_PTYP    ps_edlist;
   NODELIST_PTYP    ps_nlist;
   MESH_ENUM        meshtype;
   ADDRESS_TYP      p_info;              /* generic pointer */

} MESH_TYP;

/*
 * === Elements
 */

typedef struct NEXTELEMENT_TYP{
   ELEMENT_PTYP      ps_element;
   NEXTELEMENT_PTYP  ps_next;
} NEXTELEMENT_TYP;

typedef struct ELEMENT_TYP {
   INT               id;
   SHAPE_ENUM        shape;
   INT               numfaces;            /* 4, 5 or 6 */
   FACEUSE_PTYP      aps_face_use[6];     /* up to 6 faces/element */
   NEXTELEMENT_TYP   as_face_element[6];  /* memory for face to element */
                                          /* pointers */
   LONG              property;
   ADDRESS_TYP       p_info;              /* generic pointer */
   DOUBLE            shape_metric;        /* element shape metric */
   INT               geo_entity;          /* underlying Ansys geometric entity*/
   INT               parent;              /* id of parent element */
   ELEMENT_PTYP      ps_next;
   ELEMENT_PTYP      ps_previous;
} ELEMENT_TYP;

typedef struct ELEMENTLIST_TYP{
   INT               total;
   INT               max_id;
   ELEMENT_PTYP      ps_list;
   ELEMENT_PTYP      ps_current;
} ELEMENTLIST_TYP;

/*
 * === Faces (Also used for 2D elements)
 */

typedef struct FACEUSE_TYP{
   INT               initial_edge_idx;
   FEM_BOOLEAN       edge_orientation;    /* 1=ccw (+), -1=cw (-) */
   FACE_PTYP         ps_face;
} FACEUSE_TYP;

typedef struct NEXTFACE_TYP{
   FACE_PTYP         ps_face;
   NEXTFACE_PTYP     ps_next;
} NEXTFACE_TYP;

typedef struct FACE_TYP{ 
   INT               id;
   INT               numedges;            /* 3 or 4 edges */
   EDGEUSE_PTYP      aps_edge_use[4];
   NEXTELEMENT_PTYP  ps_adjelem;          /* list of adjacent elements */
                                          /* (can be > 2) */
   NEXTFACE_TYP      as_edge_face[4];     /* memory for edge to face pointers */
   LONG              property;
   DOUBLE            shape_metric;        /* element shape metric */
   ADDRESS_TYP       p_info;              /* generic pointer */
   INT               geo_entity;          /* underlying Ansys geometric entity*/
   INT               parent;              /* id of parent face */
   FACE_PTYP         ps_next;
   FACE_PTYP         ps_previous;
   unsigned long     ulNumFaces;
} FACE_TYP;

typedef struct FACELIST_TYP{
   INT               total;
   INT               max_id;
   FACE_PTYP         ps_list;
   FACE_PTYP         ps_current;
} FACELIST_TYP;

/*
 * === Edges
 */

typedef struct EDGEUSE_TYP{
   FEM_BOOLEAN       node_orientation;    /* 1=[0],[1], -1=[1],[0] */
   EDGE_PTYP         ps_edge;
} EDGEUSE_TYP;

typedef struct NEXTEDGE_TYP{
   EDGE_PTYP         ps_edge;
   NEXTEDGE_PTYP     ps_next;
} NEXTEDGE_TYP;

typedef struct EDGE_TYP{
   INT               id;
   NODE_PTYP         aps_node[3];         /* 0=begin, 1=end, 2=midnode */
   NEXTFACE_PTYP     ps_adjface;          /* list of adjacent faces */
                                          /* (handles non-manifold) */
   NEXTEDGE_TYP      as_node_edge[3];     /* memory for node to edge pointers */
   LONG              property;
   ADDRESS_TYP       p_info;              /* generic pointer */
   INT               geo_entity;          /* underlying Ansys geometric entity*/
   ADDRESS_TYP       p_topolist;             /* really an stl vector of topos this entity is on */
   EDGE_PTYP         ps_next;
   EDGE_PTYP         ps_previous;
   unsigned long     ulNumEdges;
} EDGE_TYP;

typedef struct EDGELIST_TYP{
   INT               total;
   INT               max_id;
   EDGE_PTYP         ps_list;
   EDGE_PTYP         ps_current;
}EDGELIST_TYP;

/*
 * === Nodes
 */

typedef struct NEXTNODE_TYP{
   NODE_PTYP         ps_node;
   NEXTNODE_PTYP     ps_next;
} NEXTNODE_TYP;

typedef struct NODE_TYP{
   INT               id;
   DDOUBLE           x,y,z;
   DDOUBLE           u,v;
   DDOUBLE           s;
   NEXTEDGE_PTYP     ps_adjedge;          /* list of edges connected to node */
   LONG              property;
   INT               geo_entity;          /* underlying Ansys geometric entity*/
   ADDRESS_TYP       p_info;              /* generic pointer */
   ADDRESS_TYP       p_info0;             /* generic pointer */
   ADDRESS_TYP       p_topolist;             /* really an stl vector of topos this entity is on */
   NODE_PTYP         ps_next;
   NODE_PTYP         ps_previous;
   unsigned long     ulNumNodes;
} NODE_TYP;

typedef struct NODELIST_TYP{
   INT               total;
   INT               max_id;
   NODE_PTYP         ps_list;
   NODE_PTYP         ps_current;
   INT               ht_size;             /* hash table size */
   NEXTNODE_PTYP     *aps_ht;             /* hash table */
} NODELIST_TYP;

/* ======= (object, info) pair - alc ======= */

typedef struct OBJINFO_TYP {
    ADDRESS_TYP      p_obj;
    ADDRESS_TYP      p_info;
} OBJINFO_TYP;

/* ========= stuff for deques =============*/

typedef struct LINK_TYP {
   union {
      ADDRESS_TYP ptr;
      DOUBLE dbl;
   } p_data;
   LINK_PTYP ps_prev;
   LINK_PTYP ps_next;
} LINK_TYP;

typedef struct DEQUE_TYP {
   LINK_PTYP ps_top;        /* the top item on the deque */
   LINK_PTYP ps_bottom;     /* the bottom item on the deque */
   INT length;
   INT type;
} DEQUE_TYP;

#endif
