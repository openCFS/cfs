/* sid 60.1 copy of MAT_MooneyRivlin.h last changed by upd111 on 2006/10/09 19:56:35 */
////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         Copyright (C) 2001 ANSYS Inc.  All Rights Reserved             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MAT_MooneyRivlin.h $
// $Revision$ 7.0
// $Date$ March 28 2002
// $Author$ rjayasee/jlo
//
// Decription :
//
//	This class captures the Material Model abstraction for the MooneyRivline
//  model
//////////////////////////////////////////////////////////////////////////////

#if !defined( MAT_MOONEYRIVLIN_H )
#define MAT_MOONEYRIVLIN_H


#include "MAT_HyperElasticLinearFit.h"
#include "MAT_OgdenVolumetricMode.h"

// #include "MAT_ConstitutiveFunction.h"
class MAT_ExperimentalDataSet ;

class MAT_MooneyRivlin : public MAT_HyperElasticLinearFit
{

public:

    MAT_MooneyRivlin();
    //Constructor

    bool SetNumberOfCoeffs( INT iOrder ) ;
    //R-bool
    //I-iOrder
    //I-Number of Coeffs
    //F-Set the Number of Coeffs
    //F-This is implemented here

    virtual bool GenerateMaterialParameters() ;
    //R-bool
    //F-Function that Generates the Material Parameters given
    //F-some experimental data

    virtual bool CalculateFittedExperimentalDataPoint
                    ( double* pCoeffs,
                      INT iNumCoeffs,
                      ANS_String oExpName,
                      vector<double>& oPoint ) ;
    //R bool
    //R-false is such a point or an experiment does not exist
    //I pCoeffs
    //I-Coefficient Values
    //I iNumCoeffs
    //I-Number of Coefficients
    //I oExpName
    //I-Experiment Name
    //I oPoint
    //I Calulated Value of Experiment Point
    //- Returns the Fitted Experimental Data Point

     virtual bool FillLHSAndRHSMatrix( ANS_String const& pExpName, ANS_Point const* pPoint,
                                       double** pLHSMatrix, double** pRHSMatrix ) ;
     //R bool
     //I pExpName
     //I-Experiment Name
     //I pPoint
     //I Data Point
     //O pLHSMatrix
     //O LHS Matrix
     //O pRHS Matrix
     //O RHS Matrix
     //- Fills up LHS and RHS Matrix for a given point/experimental data

     virtual void SetTemperatureFilterSolveFlag( bool bFlag ) 
     {
         MAT_ConstitutiveFunction::SetTemperatureFilterSolveFlag(bFlag) ;
         m_oVolumetricMode.SetTemperatureFilterSolveFlag(bFlag) ;
     }
     //R status
     //I bFlag
     //- This flag sets the Temperature Filter Solve on

     virtual void SetReferenceTemperature( double dTRef ) 
     {
         MAT_ConstitutiveFunction::SetReferenceTemperature(dTRef) ;
         m_oVolumetricMode.SetReferenceTemperature(dTRef) ;
     }

    virtual bool DeleteCoefficients( MAT_FieldVariableCollection const& oField  ) ;
    //R bool
    //I oField
    //I-Field Variable
    //- Removes/Deletes the Variable Independent coefficients at a particular temp/...

    virtual void Print() ;
     //F-Print

   	 virtual ~MAT_MooneyRivlin();
     //F-Destructor

private:

     MAT_OgdenVolumetricMode m_oVolumetricMode ;
};

#endif // !defined(MAT_MOONEYRIVLIN_H)
