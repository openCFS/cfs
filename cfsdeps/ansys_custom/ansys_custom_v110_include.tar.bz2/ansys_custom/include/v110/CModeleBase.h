/* sid 60.6 copy of CModeleBase.h last changed by ltomaso on 2006/06/22 13:50:28 */
/* CModele.h CADOE doeinc */
/*! \file CModele.h

  \brief This header file defines the CAdomsh class.

  \author Gilles VENET &copy; CADOE

  \date January 2004
*/
#ifndef __cmodelebaseh_h__ 
#define __cmodelebaseh_h__ 1 

#include "CCadoePortable.h"
#include "CDesignSet.h"
#include "CParameterMgr.h"
#include "CParameter.h"
#include "expmdb_struct.h"
#include "Cintegration.h"

#include "m_matrix.h"

typedef struct __Modele T_Modele;
typedef struct __Config T_Config;

class CConfigMgrBase;
class CConfigBase;
class CLMeshBase;
class CMeshMgrBase;

/*! \class CAdomsh CAdomsh.h
  \brief The CAdomsh class is used to contain model ADOMESH
  */
class CModeleBase
{
public:
	enum Enum_erreur 
  	{
		NoError = 0,
		VafNotOpen,
		VafNotConforme,
		VafReadError,
		AllParamSuppressed,
		ProcessAbortedByUser
    };

	typedef vector<CParameter> ParamVector;
	typedef map<string,int> ParamMap;

  CModeleBase ( );
  CModeleBase ( CParameterMgr *pmg );
  virtual ~CModeleBase();

	virtual int InitModel();

  // initialize for standalone usage (build is own adomesh model)
	virtual int OpenFile( const string filename, bool alone = true );

  //virtual bool  openVan ( );
  bool  closeVan ();


	bool isInitialized( string filename ) const;
  bool isInitialized( ){ return _initialized;} 
  bool IsVanExiste ();
  bool IsVarEnvExiste ();

  T_statut getParameter ( const string &nom_param, CParameter &param );
  int getNumberOfParameters ( );
  bool getFirstParameter ( CParameter &param );
  bool getNextParameter ( CParameter &param );
  void getNameOfVan ( string & );
  void getNameOfVan ( char * );
  int getIndiceParameter ( const string name );
  void setCurrentFilename ( );
  //virtual bool setDeltaSet ( CDesignSet *dset, CDesignSet &deltaset );
  T_Modele *getModele ();

	CParameterMgr *getParameterMgr() { return _pmgr; };

  string getNameOfVecParamIndex ( int iv ) const;
  int getNumberOfShapeParameters( void ) const;
  int getNumberOfAdomeshParameters( void ) const;
  int getShapeParameterVector( CModeleBase::ParamVector &pvec ) const;
  int getParameterByIndex ( int indice, CParameter & );
  bool MsgShapeParameters( int type );

	bool  isPolynomeExiste ();
  T_cbf *getcbf();
  bool openDatabaseToRead ( );

  virtual T_Mesh *getCurrentMesh ( void );
  T_Mesh *getCurrentMesh ( CLMeshBase *&Cmesh );

  void setDatabaseFilename(const char * filename);

  //virtual void setModTraceOn ( );
  //virtual void setModTraceOff ();
  //virtual void setModConnec ( );
  void setPrecision ( double val );
  //virtual void setFactLog ( double val );
  virtual void setNameOfFile ( string nom ) { _nom_fic = nom; }
	void getBufferName ( string &buffername ) { buffername = _buffername; };
  void setModele ( T_Modele * modele ){ _model = modele ;}
 	CMeshMgrBase *getMeshMgr() { return _meshmgr; };
	double getVersion () { return _version;};

public:

	CConfigMgrBase  *_cfgmgr;

protected:
	bool majParams ();
	void createMyPmgr(void);

	bool			_initialized;
  bool      _var_env_existe;
  bool      _van_existe;
	T_Modele		*_model;
	string			_nom_fic;
	string		_buffername;
	int				_nbParamAdomesh;
  CParameterMgr	*_pmgr;
  CMeshMgrBase  *_meshmgr;	  

protected:
	void initCModeleBase();
  void createMyCfgMgr(void);
  void createMyMeshMgr(void);

	unsigned int       _indexParam;
	bool			_modelIsMine;
	bool			_pmgrIsMine;
	bool			_pmgrToSave;
	int				_maxnode; //maximum label of nodes
  CModeleBase::ParamVector _ParamVec;
  CModeleBase::ParamMap _ParamMap;
  bool  _modTrace;
  bool  _modConnec;
	double _version;
  double _precision;     // precision globale
  Enum_erreur _lastErreur;
};


#endif
