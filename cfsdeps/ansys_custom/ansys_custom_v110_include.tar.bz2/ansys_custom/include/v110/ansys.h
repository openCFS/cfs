/* sid 60.4 copy of ansys.h last changed by jtm on 2006/08/08 12:08:37 */
/*HFILE ansys.h	                                            sam, system
------------------------------------------------------------------------
------- Notice - This file contains ANSYS Confidential information 
------------------------------------------------------------------------
*/

/*------------------------------ Description ---------------------------
\Author:	Sam Murgie (sam)
\Title:		main Ansys header
\Desc:		This header should be included in nearly all C and C++
                ANSYS routines.  It includes computer.h and globals.h.
\History:	99/02/16 - sam: Initial creation.

\Function(s) 
 -Primary:	To supply a single include file that contains all system
                dependent and other global definitions that are to be 
                included in all C & C++ source files.
 -Secondary:	none
 -External:	none
 -Internal:	none
 -Static:	none
 *** mpg ansys.h < LMatrix,msgdfc: machine,print data
         computer, globals,cAns_printf
----------------------------------------------------------------------*/

/*------------------------------ Header files ------------------------*/

#include "computer.h"
#include "globals.h"
#include "cAns_printf.h"

/*---------------------------- End Of Module -------------------------*/


