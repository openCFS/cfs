/* sid 60.20 copy of Fx_Info.h last changed by eedelor on 2006/08/21 13:11:35 */
/*******************************************************************************
 *
 *   fx_Info.h  --- Retrieve and Set some FOTRAN common variables
 *               
 * 
 * |Module:  
 *
 * |Description: 
 *
 * |Includes:	
 *        
 * |Auteur: Jean-Daniel Beley
 *
 * |Creation: Mars 2002
 *
 * |Version: $Id$
 *
 * |Copyright:	Copyright(c)  2002
 *
 ********************************************************************************/
#ifndef __FX_INFO_H__
#define __FX_INFO_H__ 1

#include "computer.h"
#include "globals.h"
#include "sysparh.h"

/* ===================================================================== */
/* For systems needing lower case names without an underscore at the end */
/* ===================================================================== */
#if defined(LOWERCASENOUNDER_SYS)
#define fx_getinfo   fx_getinfo
#define fx_setinfo   fx_setinfo
#endif
#if defined(UPPERCASENOUNDER_SYS)
#define fx_getinfo   FX_GETINFO
#define fx_setinfo   FX_SETINFO
#endif
#if defined(LOWERCASEUNDER_SYS)
#define fx_getinfo   fx_getinfo_
#define fx_setinfo   fx_setinfo_
#endif

typedef enum {
  E_I_LENBAC = 1,
  E_I_NUME = 2,
  E_I_LENU= 3,
  E_I_NEQN= 4,
  E_I_ANTYPE= 5,
  E_I_NUMDOF= 6,
  E_I_NRKEY= 7,
  E_I_LDSTEP= 8,
  E_I_CADOE_ANTYPE = 9,
  E_D_TINY= 10,
  E_D_HUGE= 11,
  E_D_FRQBEG= 12,
  E_D_FRQEND= 13,
  E_I_STRUCURAL= 14,
  E_I_THERMAL= 15,
  E_I_ELECTRIC= 16,
  E_I_EMAG= 17,
  E_I_CFD= 18,
  E_I_M_VARIABLE= 19,
  E_I_C_VARIABLE= 20,
  E_I_K_VARIABLE= 21,
  E_I_NSUBST = 22,
  E_I_HARMONIC_INDEX = 23,
  E_D_HARMONIC_ANGLE = 24,
  E_I_DEBUG_KEY = 25,
  E_I_CADOE_PASS_INPUT = 26,
  E_I_SSTIF = 27,
  E_I_CADOE_OPEN_ESAV = 28,
  E_I_CADOE_OPEN_EMAT = 29,
  E_I_CADOE_FREQ_MIN = 30,
  E_I_ACCEL_EXIST = 31,
  E_I_HRMSXTYPE = 32,
  E_I_SOLVEMETHOD = 33,
  E_I_CADOE_APPR_TYPE = 34,
  E_I_SXFPOSTASSEMBLY = 35,
  E_I_CADOE_K_PART = 36,
  E_I_NUMITER = 37,
  E_I_NUMSUBSTEP = 38,
  E_I_FXSHIT = 39,
  E_I_SXNL_KPART = 40,
  E_I_SXNL_DERIVKT = 41,
  E_I_SXNL_CHECKCNV = 42,
  E_I_SXNL_EXPANDU = 43,
  E_I_SXNL_CONTACT = 44,
  E_I_KPLUPD = 45,
  E_I_KUPHVR = 46,
  E_I_KUPSVR = 47,
  E_I_SXNL_LS = 48,
  E_I_KFSTIT = 49,
  E_I_HIUNMATCH = 50,
  E_I_IEQITR = 51,
  E_I_STNMAX = 52,
  E_I_SXFNBCALLSFFORM = 53,
  E_I_SXNL_EX = 55,
  E_I_KFSTPS = 56,
  E_D_PRDFCT = 57,
  E_I_LSLOOP = 58,
  E_I_SXNL_CDM = 59,
  E_I_ANCONT = 60,
  E_I_MODEXT = 61,
  E_I_SXNL_BACSUB = 62,
  E_I_SXNL_UPDDSP = 63,
  E_I_SXNL_ELEM = 64,
  E_I_CHKNLE = 65,
  E_I_DCNVGD = 66,
  E_I_ECNVGD = 67,
  E_I_FCNVGD = 68,
  E_I_SXNL_ITER = 69,
  E_I_SXNL_VERIFCNV = 70,
  E_I_SXNL_MINRESQ = 71,
  E_I_SXNL_KREFRM = 72,
  E_I_SXNL_DFDX = 73,
  E_I_FRDSUP = 74,
  E_I_SXNL_REST = 75
} E_info_fx;

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

SUBROUTINE fx_getinfo( E_info_fx*, int*, double * );
SUBROUTINE fx_setinfo( E_info_fx*, int*, double * );

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif
