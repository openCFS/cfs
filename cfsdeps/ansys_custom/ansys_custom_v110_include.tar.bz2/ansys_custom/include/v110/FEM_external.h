/* sid 60.10 copy of FEM_external.h last changed by upd111 on 2007/01/02 21:02:33 */

/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 1999 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_external.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_external.h
 *  header file for FEM_external.c
 *
 *   NOTE:  This file contains function prototypes for all API routines
 *          that the Ansys Meshing Toolkit will need to be written for queries
 *          into the native CAD database.  They need to be rewritten each time
 *          the Ansys Meshing Toolkit is integrated into a new environment.
 *
 *   NOTE: All of these functions are implementation specific         
 *         functions. They are to be rewritten each time 
 *         the Ansys Meshing Toolkit is integrated    
 *         into a new environment.                    
 *
 */
#ifndef FEM_EXTERNAL_INCLUDE
#define FEM_EXTERNAL_INCLUDE

#include "FEM_cdbtypes.h"

/*----------------- Globally accessible function prototypes -----------------*/
#if 0

FEM_external routines grouped and indexed.
The routines listed below are the ones that UG will have to write to support
the initial version of the Ansys Mesh Toolkit in UG/Scenario.

/* === Memory Management */
 
FEMe_Free
FEMe_Malloc
 
/* === Error/Message handling */
 
FEMe_String
FEMe_Error
FEMe_VerifyCommand
FEMe_Interactive
 
/* === Debugging */
 
FEMe_DrawFace
FEMe_TrackPoint
FEMe_TrackBegin
FEMe_TrackEnd
 
/* === Status Window */
 
FEMe_KillStatusWindow
FEMe_SetUpStatusWindow
FEMe_CheckStatusWindow
FEMe_TimeStatusWindow
FEMe_UpdateStatusWindow
FEMe_UserAbort
 
/* === Keypoint inquires. */
 
FEMe_MaxNumKps
FEMe_KpXYZ
FEMe_KpNodeId
FEMe_LinesAttachedToKp
FEMe_KpIsLineHardPoint
FEMe_KpIsAreaHardPoint
FEMe_KpEsize 
/* === Line Geometry inquires */
 
FEMe_InitLinesII
FEMe_UnInitLines
FEMe_LineEvaluate
FEMe_AreLinesInited
FEMe_ProjectToLine
FEMe_IsLineStraight
FEMe_CanEvaluateLine
FEMe_LineLength
FEMe_LineSlope
FEMe_LineSlopeCurv
 
/* === Line Topology Inquires */
 
FEMe_MaxNumLines
FEMe_LineKps
FEMe_NumLineHardPoints
FEMe_LineHardPoints
FEMe_AreasAttachedToLine
FEMe_LineEsize
FEMe_LineFrozen
FEMe_LineNumDiv
FEMe_LineRatio
FEMe_LineDivsFixed
 
/* === Area Geometry inquires. */
 
FEMe_AreaParamRange
FEMe_IsAreaClosed
FEMe_UnInitAreas
FEMe_IsAreaAnalytical
FEMe_AreaSlope
FEMe_InitAreas
FEMe_InitAreaShift
FEMe_UnInitAreaShift
FEMe_LineProjectToArea
FEMe_AreaEvaluate
FEMe_ProjectToArea
FEMe_ProjectToAreaWithTol
FEMe_ProjectToAreaII
FEMe_IsAreaFlat
FEMe_AreAreasInited
FEMe_AreaNormal
FEMe_CanEvaluateArea
FEMe_AreaBoundingBox
FEMe_SurfaceOrientationWRTArea
FEMe_NumberOfRadialDivisionsOnArea

 
/* === Area topology inquires */
 
FEMe_MaxNumAreas
FEMe_AreaLines
FEMe_NumAreaHardPoints
FEMe_AreaHardPoints
FEMe_AreaArea
FEMe_NumAreaLoops
FEMe_NumAreaLoopsII
 
/* === Volume topology inquires */
 
FEMe_VolAreas
FEMe_VolVolume

/* === Generic geometry inquiries */
FEMe_GeometryType
 
/* === Elem/Node Inquires */
 
FEMe_LineNumNodes
FEMe_LineMesh
FEMe_LineMeshII
FEMe_LineNodeT
FEMe_AreaNodeUV
FEMe_LineNumElemDivisions
FEMe_NodeGeoEntity
FEMe_NodeXYZ
FEMe_AreaElemNodes
FEMe_CheckForSplit
FEMe_AreaNumElems
FEMe_GetFacetsOnArea
FEMe_GetElemsOnArea
 
/* === check BCs and Constraints */

FEMe_RefChkNode 
FEMe_RefChkBfNode
FEMe_RefChkElem 
FEMe_RefChkBfElem 

/* === Misc. */
FEMe_SetParameters


#endif


#ifdef __cplusplus
#define FEM_CPP_EXTERN extern "C"
#else
#define FEM_CPP_EXTERN  
#endif




/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++   Area Projection and Evaluation Routines ++++++++++++++++*/
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/



                     /* ==================================================== */
                     /* === FEMe_InitAreas: Cache area information for fast  */
                     /* === projections and evaluations.  The areas sent in  */
                     /* === "a_areas" are about to be used in a meshing      */
                     /* === operation that will require projections,         */
                     /* === evaluations, normal calculations, etc.           */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_InitAreas (
   FEM_INT *a_areas, /* (IN)  Areas to initialize for area evaluations and   */
                     /*       projections                                    */
   FEM_INT num_areas,/* (IN)  Length of a_areas                              */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */




                     /* ==================================================== */
                     /* === FEMe_InitMoreAreas: After initializing an        */
                     /* === initial set of areas with FEMe_InitAreas, cach   */
                     /* === some more areas while keeping the original ones  */
                     /* === cached as well.                                  */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_InitMoreAreas(
   FEM_INT *a_areas, /* (IN)  additional areas to cache.                     */
   FEM_INT num_areas,/* (IN)  length of a_areas.                             */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */




                     /* ==================================================== */
                     /* === FEMe_AreAreasInited: Check to see if areas have  */
                     /* === been cached by calling FEMe_InitAreas.           */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (FEM_BOOLEAN)                            */
                     /* ===                   TRUE if they have been         */
                     /* ===                        initialized               */
                     /* ===                   FALSE if they have not been    */
                     /* ===                         initialized              */
                     /* ==================================================== */
FEM_CPP_EXTERN FEM_BOOLEAN FEMe_AreAreasInited ( void  );




                     /* ==================================================== */
                     /* === FEMe_UnInitAreas: Free up any memory etc. that   */
                     /* === was used to provide area evaluations and         */
                     /* === projections.  After calling this routine, no     */
                     /* === more area evaluations or projections can be      */
                     /* === performed until FEM_eInitAreas is called again.  */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_UnInitAreas ( void  );




                     /* ==================================================== */
                     /* === FEMe_CanEvaluateArea: Determine if it is ok to   */
                     /* === project or evaluate a given area ( i.e.,  if the */
                     /* === area has been cached for projections and         */
                     /* === evaluations in a call to FEMe_InitAreas).        */
                     /* ===                                                  */
                     /* === The purpose of this function is to determine if  */
                     /* === an area can be modified by a particular meshing  */
                     /* === operations.  If the area is not cached, that     */
                     /* === means it can not be modified by the particular   */
                     /* === meshing operation.                               */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_CanEvaluateArea (
   FEM_INT area_id,  /* (IN)  Id of area to check                            */
   FEM_BOOLEAN *ok,  /* (OUT) Returned as TRUE if the area has been,         */
                     /*       cached, otherwise FALSE                        */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */



                     /*=======================================================*/
                     /* === Function: FEMe_InitAreaShift                     */
                     /* === Author: jrt                                       */
                     /* === Description: Init the parametric shift for an area*/ 
                     /* === so the evaluators will be aware of the shift in   */
                     /* ==== parametric space that has taken place;           */
                     /* === Return: void                                      */
                     /*=======================================================*/
FEM_CPP_EXTERN void FEMe_InitAreaShift(
   INT area_num,     /* (IN) areas to initialize for shift */
   INT *error );     /* (OUT) error flag. */



                     /*=======================================================*/
                     /* === Function: FEMe_UnInitAreaShift                     */
                     /* === Author: jrt                                       */
                     /* === Description: Un Init the parametric shift for an area*/ 
                     /* === so the evaluators will be aware of the shift in   */
                     /* ==== parametric space that has taken place;           */
                     /* === Return: void                                      */
                     /*=======================================================*/
FEM_CPP_EXTERN void FEMe_UnInitAreaShift(
   INT area_num,     /* (IN) areas to initialize for shift */
   INT *error );     /* (OUT) error flag. */


                     /* ==================================================== */
                     /* === FEMe_ProjectToArea: Project a point to an area.  */
                     /* === FEMe_InitAreas() must have previously called.    */
                     /* === s_out and t_out are not returned if the area is  */
                     /* === flat or analytical.  If t_out and s_out are      */
                     /* === required to be returned, call                    */
                     /* === FEMe_ProjectToAreaII.  Also, if the area is flat */
                     /* === no projection is done because it assumes the     */
                     /* === node is already in the plane.                    */
                     /* ===                                                  */
                     /* === NOTE: The purpose of this function is to provide */
                     /* ===       a faster projection method for flat and    */
                     /* ===       analytical areas.  If the native CAD       */
                     /* ===       database does not distinguish between      */
                     /* ===       analytical and/or flat surfaces,           */
                     /* ===       FEMe_ProjectToArea can be identical to     */
                     /* ===       FEMe_ProjectToAreaII.  If, however, it is  */
                     /* ===       possible to take advantage of analytical   */
                     /* ===       and flat area information, please do so.   */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_ProjectToArea (
   FEM_INT area_id,  /* (IN)  Id of area being projected to.  This area must */
                     /*       be cached previously by FEM_InitAreas.  If it  */
                     /*       has not been cached, DO NOT call a slower more */
                     /*       expensive projection routine, rather return    */
                     /*       without projecting and return                  */
                     /*       error == EXIT_FAILURE                          */
   FEM_DOUBLE xyzin[3],/*(IN) Unprojected location of point                  */
   FEM_DOUBLE s_in,  /* (IN)  Guess at s parametric location.  If a guess    */
                     /*       cannot be determined, guess arg will be TRUE   */
   FEM_DOUBLE t_in,  /* (IN)  Guess at t parametric location.  If a guess    */
                     /*       cannot be determined, guess arg will be TRUE   */
   FEM_BOOLEAN no_guess,/*(IN)TRUE if s_in and t_in are not able to be       */
                     /*       determined and are ignored.                    */
   FEM_DOUBLE *s_out,/* (OUT) Computed s parametric location.                */
                     /*       This will not be returned if the area is flat  */
                     /*       or analytical.                                 */
   FEM_DOUBLE *t_out,/* (OUT) Computed t parametric location.                */
                     /*       This will not be returned if the area is flat  */
                     /*       or analytical.                                 */
   FEM_DOUBLE xyzout[3],/*(OUT)Projected location of point                   */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */
                     /*       Return EXIT_FAILURE if area is                 */
                     /*       not cached or for any other error condition.   */


FEM_CPP_EXTERN void FEMe_ProjectToAreaWithTol (
   FEM_INT area_id,  /* (IN)  Id of area being projected to.  This area must */
                     /*       be cached previously by FEM_InitAreas.  If it  */
                     /*       has not been cached, DO NOT call a slower more */
                     /*       expensive projection routine, rather return    */
                     /*       without projecting and return                  */
                     /*       error == EXIT_FAILURE                          */
   FEM_DOUBLE xyzin[3],/*(IN) Unprojected location of point                  */
   FEM_DOUBLE s_in,  /* (IN)  Guess at s parametric location.  If a guess    */
                     /*       cannot be determined, guess arg will be TRUE   */
   FEM_DOUBLE t_in,  /* (IN)  Guess at t parametric location.  If a guess    */
                     /*       cannot be determined, guess arg will be TRUE   */
   FEM_BOOLEAN no_guess,/*(IN)TRUE if s_in and t_in are not able to be       */
                     /*       determined and are ignored.                    */
   DOUBLE dTol,
   FEM_DOUBLE *s_out,/* (OUT) Computed s parametric location.                */
                     /*       This will not be returned if the area is flat  */
                     /*       or analytical.                                 */
   FEM_DOUBLE *t_out,/* (OUT) Computed t parametric location.                */
                     /*       This will not be returned if the area is flat  */
                     /*       or analytical.                                 */
   FEM_DOUBLE xyzout[3],/*(OUT)Projected location of point                   */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */
                     /*       Return EXIT_FAILURE if area is                 */
                     /*       not cached or for any other error condition.   */


                     /* ==================================================== */
                     /* === FEMe_ProjectToAreaII: Project a point to an      */
                     /* === area.  Same as FEMe_ProjectToArea except that    */
                     /* === s_out and t_out will always be filled in even if */
                     /* === the surface is flat or analytical.  This can be  */
                     /* === costly, so call FEMe_ProjectToArea unless s_out, */
                     /* === t_out are needed.  FEMe_InitAreas() must have    */
                     /* === benn previously called.  The benefit of this     */
                     /* === routine over FEMe_ProjectToArea is that you will */
                     /* === always do a projection, even if the area is      */
                     /* === flat.                                            */
                     /* ===                                                  */
                     /* === NOTE: See note in FEMe_ProjectToArea function    */
                     /* ===       comment.                                   */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_ProjectToAreaII (
   FEM_INT area_id,  /* (IN)  Id of area being projected to.  This area must */
                     /*       be cached previously by FEM_InitAreas.  If it  */
                     /*       has not been cached, DO NOT call a slower more */
                     /*       expensive projection routine, rather return    */
                     /*       without projecting and return                  */
                     /*       error == EXIT_FAILURE                          */
   FEM_DOUBLE xyzin[3],/*(IN) Unprojected location of point                  */
   FEM_DOUBLE s_in,  /* (IN)  Guess at s parametric location.  If a guess    */
                     /*       cannot be determined, guess arg will be TRUE   */
   FEM_DOUBLE t_in,  /* (IN)  Guess at t parametric location.  If a guess    */
                     /*       cannot be determined, guess arg will be TRUE   */
   FEM_BOOLEAN no_guess,/*(IN)TRUE if s_in and t_in are not able to be       */
                     /*       determined and are ignored.                    */
   FEM_DOUBLE *s_out,/* (OUT) Computed s parametric location.                */
   FEM_DOUBLE *t_out,/* (OUT) Computed t parametric location.                */
   FEM_DOUBLE xyzout[3],/*(OUT)Projected location of point                   */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */
                     /*       Return EXIT_FAILURE if area is                 */
                     /*       not cached or for any other error condition.   */




                     /* ==================================================== */
                     /* === FEMe_LineProjectToArea: Project a point on a     */
                     /* === boundary to an area                              */
                     /* === (Note: This is the same as FEMe_ProjectToArea    */
                     /* === This is used only to make the projection more    */
                     /* === robust.  If the data is available: should do a   */
                     /* === project to line first then a parametric eval     */
                     /* === of the trimming curve on the area.  If data is   */
                     /* === not available just use FEMe_ProjectToArea)       */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_LineProjectToArea (
   FEM_INT area_id,  /* (IN)  Id of area being projected to                  */
   FEM_INT geo_entity,/* (IN) Line or kp number where point resides          */
   FEM_INT geo_type, /* (IN)  1 = KP, 2 = LINE                               */
   FEM_DOUBLE xyzin[3],/*(IN) Unprojected location of point                  */
   FEM_DOUBLE s_in,  /* (IN)  guess at s parametric location.  If a guess    */
                     /*       cannot be determined, the guess arg is TRUE.   */
   FEM_DOUBLE t_in,  /* (IN)  guess at t parametric location.  If a guess    */
                     /*       cannot be determined, the guess arg is TRUE.   */
   FEM_BOOLEAN no_guess,/*(IN)TRUE if s_in and t_in are not able to be       */
                     /*       determined and are ignored.                    */
   FEM_DOUBLE *s_out,/* (OUT) Computed s parametric location.                */
   FEM_DOUBLE *t_out,/* (OUT) Computed t parametric location.                */
   FEM_DOUBLE xyzout[3],/*(OUT)Projected location of point                   */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */
                     /*       Return EXIT_FAILURE if area is                 */
                     /*       not cached or for any other error condition.   */




                     /* ==================================================== */
                     /* === FEMe_AreaEvaluate: Evaluate a specified          */
                     /* === parametric location on an area.  FEMe_InitAreas  */
                     /* === must have been previously called.                */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_AreaEvaluate (
   FEM_INT area_id,  /* (IN)  Id of area being evaluated.  This area must    */
                     /*       have been previously cached by FEM_InitAreas.  */
                     /*       If it has not been cached, DO NOT call a       */
                     /*       slower more expensive evaluation routine,      */
                     /*       rather return without evaluating and return    */
                     /*       error == EXIT_FAILURE                          */
   FEM_DOUBLE u,     /* (IN)  u parametric location                          */
   FEM_DOUBLE v,     /* (IN)  v parametric location                          */
   FEM_DOUBLE xyz[3],/* (OUT) xyz location of u, v                           */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */
                     /*       Return EXIT_FAILURE if area is                 */
                     /*       not cached or for any other error condition.   */




                     /* ==================================================== */
                     /* === FEMe_AreaNormal: Calculate surface normal at a   */
                     /* === specified parametric location on an area.        */
                     /* === FEMe_InitAreas must have been previously called. */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_AreaNormal (
   FEM_INT area_id,  /* (IN)  Id of area being evaluated for normals.  This  */
                     /*       area must have been cached previously by       */
                     /*       FEM_InitAreas.  If it has not been cached, DO  */
                     /*       NOT call a slower more expensive normal        */
                     /*       evaluation routine, rather return without      */
                     /*       evaluating the normal and return               */
                     /*       error == EXIT_FAILURE                          */
   FEM_DOUBLE u,     /* (IN)  u parametric location                          */
   FEM_DOUBLE v,     /* (IN)  v parametric location                          */
   FEM_DOUBLE xyz[3],/* (IN)  World coord on surface -used only for analytic */
                     /*       surfaces (u,v are ignored)                     */
   FEM_DOUBLE norm[3],/*(OUT) Surface normal at u, v,  Surface normal does   */
                     /*       not need to be normalized.                     */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */
                     /*       Return EXIT_FAILURE if area is                 */
                     /*       not cached or for any other error condition.   */




                     /* ==================================================== */
                     /* === FEMe_AreaSlope: Calculate surface slope at a     */
                     /* === specified parametric location on an area.        */
                     /* === FEMe_InitAreas must have been previously called. */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_AreaSlope (
   FEM_INT area_id,  /* (IN)  Id of area being evaluated for slope.  This    */
                     /*       area must have been cached previously by       */
                     /*       FEM_InitAreas.  If it has not been cached, DO  */
                     /*       NOT call a slower more expensive slope         */
                     /*       evaluation routine, rather return without      */
                     /*       evaluating the slope and return                */
                     /*       error == EXIT_FAILURE                          */
   FEM_DOUBLE u,     /* (IN)  u parametric location                          */
   FEM_DOUBLE v,     /* (IN)  v parametric location                          */
   FEM_DOUBLE du[3], /* (OUT) Vector in u direction.  These should not be    */
                     /*       normalized.  Magnitude is the magnitude of the */
                     /*       first deriviative in the u direction.          */
   FEM_DOUBLE dv[3], /* (OUT) Vector in v direction.  These should not be    */
                     /*       normalized.  Magnitude is the magnitude of the */
                     /*       first deriviative in the v direction.          */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */
                     /*       Return EXIT_FAILURE if area is                 */
                     /*       not cached or for any other error condition.   */




                     /* ==================================================== */
                     /* === FEMe_IsAreaFlat: Determines if an area is flat.  */
                     /* === FEMe_InitAreas must have been previously called. */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_IsAreaFlat (
   FEM_INT area_id,  /* (IN)  Id of area being checked.  This area must be   */
                     /*       cached previously by FEM_InitAreas.  If it has */
                     /*       not been cached, return error == EXIT_FAILURE  */
   FEM_BOOLEAN *isflat,/*(OUT) TRUE if area is flat,                         */
                     /*       FALSE is area is not flat,                     */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */
                     /*       Return EXIT_FAILURE if area is                 */
                     /*       not cached or for any other error condition.   */




                     /* ==================================================== */
                     /* === FEMe_IsAreaAnalytical: Determines if an area is  */
                     /* === an analytical surface.  This routine is called   */
                     /* === in preparation to call FEMe_ProjectToArea().  If */
                     /* === a surface is not analytical, then the Ansys      */
                     /* === Meshing Database calculates a guess at u, v      */
                     /* === before calling the projection.  If the surface is*/
                     /* === analytical, not u, v guess is needed.            */
                     /* === FEMe_InitAreas must have been previously called. */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_IsAreaAnalytical (
   FEM_INT area_id,  /* (IN)  Id of area being checked.  This area must be   */
                     /*       cached previously by FEM_InitAreas.  If it has */
                     /*       not been cached, return error == EXIT_FAILURE  */
   FEM_BOOLEAN *isanal,/*(OUT)TRUE if area is analytical,                    */
                     /*       FALSE is area is not analytical,               */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */
                     /*       Return EXIT_FAILURE if area is                 */
                     /*       not cached or for any other error condition.   */




                     /* ==================================================== */
                     /* === FEMe_AreaCurvature: Calculate the curvature at a */
                     /* === point on an area.                                */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_AreaCurvature (
   FEM_INT area_id,  /* (IN)  Id of area being evaluated for curvature.      */
                     /*       This area must have been cached previously by  */
                     /*       FEM_InitAreas.  If it has not been cached, DO  */
                     /*       NOT call a slower more expensive curvature     */
                     /*       evaluation routine, rather return without      */
                     /*       evaluating the curvature and return            */
                     /*       error == FEM_FAILURE                           */
   FEM_DOUBLE u,     /* (IN)  u parameter value on area                      */
   FEM_DOUBLE v,     /* (IN)  v parameter value on area                      */
   FEM_DOUBLE *curv, /* (OUT) Evaluated curvature                            */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_SUCCESS or EXIT_FAILURE)    */
                     /*       Return EXIT_FAILURE if area is                 */
                     /*       not cached or for any other error condition.   */




                     /* ==================================================== */
                     /* === FEMe_AreaNormalAndCurv: Calculate the normal and */
                     /* === curvature at a point simiultaneously.            */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_AreaNormalAndCurv (
   FEM_INT area_id,  /* (IN)  Id of area being evaluated for normal and      */
                     /*       curvature.  This area must have been cached    */
                     /*       previously by FEM_InitAreas.  If it has not    */
                     /*       been cached, DO NOT call a slower more         */
                     /*       expensive normal and curvature evaluation      */
                     /*       routine, rather return without evaluating the  */
                     /*       normal and curvature and return                */
                     /*       error == FEM_FAILURE                           */
   FEM_DOUBLE u,     /* (IN)  u parameter value on area                      */
   FEM_DOUBLE v,     /* (IN)  v parameter value on area                      */
   FEM_DOUBLE xyz[3],/* (IN)  World coordinates of location on surface.  Only*/
                     /*       used if surface is analytical                  */
   FEM_DOUBLE *norm, /* (OUT) Evaluated normal.  a_normal does not need to be*/
                     /*       normalized.                                    */
   FEM_DOUBLE *curv, /* (OUT) Evaluated curvature                            */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_SUCCESS or EXIT_FAILURE)    */
                     /*       Return EXIT_FAILURE if area is                 */
                     /*       not cached or for any other error condition.   */





/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++   Line Projection and Evaluation Routines ++++++++++++++++*/
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

                     /* ==================================================== */
                     /* === FEMe_InitLinesI: Cache line information for fast */
                     /* === projections and evaluations.  The lines adjacent */
                     /* === to area_id are about to be used in a meshing     */
                     /* === operation that requires projections, evaluations,*/
                     /* === curvature calculations, etc.  This routine is    */
                     /* === called when a meshing operation will be done on  */
                     /* === a single area and the mesher does not already    */
                     /* === have the adjacent lines determined.              */
                     /* ===                                                  */
                     /* === NOTE: The expected line parameterization is arc  */
                     /* ===       length parameterization and goes from 0.0  */
                     /* ===       to 1.0 where:                              */
                     /* ===       s = 0.0 at kp1 returned from FEMe_LineKps  */
                     /* ===       s = 1.0 at kp2 returned from FEMe_LineKps  */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_InitLinesI (
   FEM_INT area_id,  /* (IN)  All lines on this area will be initialized for */
                     /*       projections and evaluations according to the   */
                     /*       all_lines flag setting.                        */
   FEM_BOOLEAN all_lines,
                     /* (IN)  If FALSE, then only lines adjacent to area_id  */
                     /*       that are not adjacent to any other area that   */
                     /*       is already meshed in the native CAD database   */
                     /*       will be cached.  If TRUE, all lines defining   */
                     /*       area_id  are cached.                           */
                     /*       This is done so that lines adjacent to         */
                     /*       previously meshed areas will not be altered by */
                     /*       the meshing or smoothing process.  Since lines */
                     /*       adjacent to previously meshed areas are not    */
                     /*       cached if all_lines == FALSE, none of the other*/
                     /*       projection or evaluation routines will alter   */
                     /*       the line in any way since they return an error */
                     /*       status if an uncached line is sent to them.    */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */




                     /* ==================================================== */
                     /* === FEMe_InitLinesII: Cache line information for fast*/
                     /* === projections and evaluations.  The lines adjacent */
                     /* === to areas in a_areas are about to be used in a    */
                     /* === meshing operation that requires projections,     */
                     /* === evaluations,curvature calculations, etc.         */
                     /* === This is the same as FEMe_InitLinesI except it    */
                     /* === takes an array of areas instead of a single area */
                     /* === and returns the ids of the line cached.          */
                     /* === This routine is called when a meshing operation  */
                     /* === will be done on multiple areas and the mesher    */
                     /* === does not already have the adjacent lines         */
                     /* === determined.                                      */
                     /* ===                                                  */
                     /* === NOTE: The expected line parameterization is arc  */
                     /* ===       length parameterization and goes from 0.0  */
                     /* ===       to 1.0 where:                              */
                     /* ===       s = 0.0 at kp1 returned from FEMe_LineKps  */
                     /* ===       s = 1.0 at kp2 returned from FEMe_LineKps  */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_InitLinesII (
   FEM_INT *a_areas, /* (IN)  Array of areas which will have adjacent lines  */
                     /*       cached according to the all_lines flag setting.*/
   FEM_INT num_areas,/* (IN)  Number of input areas (dimension of a_areas)   */
   FEM_INT *a_lines, /* (OUT) List of lines cached for projections and       */
                     /*       evaluations.  Calling function is responsible  */
                     /*       for allocating memory for this array.          */
   FEM_INT *num_lines,
                     /* (OUT) Number of output lines (dimension of a_lines)  */
   FEM_BOOLEAN all_lines,
                     /* (IN)  If FALSE, then only lines adjacent to area_id, */
                     /*       that are not adjacent to any other area, that  */
                     /*       is already meshed in the native CAD database,  */
                     /*       will be cached.  If TRUE, all lines defining   */
                     /*       area_id  are cached.                           */
                     /*       This is done so that lines adjacent to         */
                     /*       previously meshed areas will not be altered by */
                     /*       the meshing or smoothing process.  Since lines */
                     /*       adjacent to previously meshed areas are not    */
                     /*       cached if all_lines == FALSE, none of the other*/
                     /*       projection or evaluation routines will alter   */
                     /*       the line in any way since they return an error */
                     /*       status if an uncached line is sent to them.    */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */




                     /* ==================================================== */
                     /* === FEMe_InitLinesIII: Cache line information for    */
                     /* === fast projections and evaluations.  The lines in  */
                     /* === a_lines are about to be used in a meshing        */
                     /* === operation that requires projections,             */
                     /* === evaluations, curvature calculations, etc.        */
                     /* ===                                                  */
                     /* === NOTE: The expected line parameterization is arc  */
                     /* ===       length parameterization and goes from 0.0  */
                     /* ===       to 1.0 where:                              */
                     /* ===       s = 0.0 at kp1 returned from FEMe_LineKps  */
                     /* ===       s = 1.0 at kp2 returned from FEMe_LineKps  */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_InitLinesIII (
   FEM_INT *a_lines, /* (IN)  List of lines to be cached for projections and */
                     /*       evaluations                                    */
   FEM_INT num_lines,/* (IN)  Number of input lines (dimension of a_lines)   */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */




                     /* ==================================================== */
                     /* === FEMe_InitMoreLines: After initializing an        */
                     /* === initial set of lines with one of the             */
                     /* === FEMe_InitLinesX routines, cach some more lines   */
                     /* === while keeping the original ones cached as well.  */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_InitMoreLines(
   FEM_INT *a_lines, /* (IN)  additional lines to cache.                     */
   FEM_INT num_lines,/* (IN)  length of a_lines.                             */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */





                     /* ==================================================== */
                     /* === FEMe_AreLinesInited: Check to see if lines have  */
                     /* === been cached for evaluations and projections.     */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (FEM_BOOLEAN)                            */
                     /* ===                   TRUE if they have been         */
                     /* ===                          initialized             */
                     /* ===                   FALSE if they have not been    */
                     /* ===                          initialized             */
                     /* ==================================================== */
FEM_CPP_EXTERN FEM_BOOLEAN FEMe_AreLinesInited ( void  );




                     /* ==================================================== */
                     /* === FEMe_UnInitLines: Free up any memory, etc. that  */
                     /* === was used to cache lines for evaluations and      */
                     /* === projections.                                     */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_UnInitLines ( void  );




                     /* ==================================================== */
                     /* === FEMe_CanEvaluateLine: Determine if it is ok to   */
                     /* === project or evaluate a given line ( i.e., if the  */
                     /* === line has been initialized for projections and    */
                     /* === evaluations ). FEMe_InitLinesI, FEMe_InitLinesII */
                     /* === or FEMe_InitLinesIII must have been called       */
                     /* === previously.                                      */
                     /* ===                                                  */
                     /* === The purpose of this function is to determine if  */
                     /* === a line can be modified by a particular meshing   */
                     /* === operations.  If the line is not cached that means*/
                     /* === it can not be modified by the particular meshing */
                     /* === operation.                                       */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_CanEvaluateLine (
   FEM_INT line_id,  /* (IN)  Id of line to check                            */
   FEM_BOOLEAN *ok,  /* (OUT) Returned as TRUE if line has been cached for   */
                     /*       projections and evaluations, otherwise FALSE   */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */




                     /* ==================================================== */
                     /* === FEMe_ProjectToLine: Project a point to a line.   */
                     /* === FEMe_InitLinesI, FEMe_InitLinesIII, or           */
                     /* === FEMe_InitLinesII must have been previosly        */
                     /* === called.                                          */
                     /* ===                                                  */
                     /* === NOTE: The expected line parameterization is arc  */
                     /* ===       length parameterization and goes from 0.0  */
                     /* ===       to 1.0 where:                              */
                     /* ===       s = 0.0 at kp1 returned from FEMe_LineKps  */
                     /* ===       s = 1.0 at kp2 returned from FEMe_LineKps  */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_ProjectToLine (
   FEM_INT line_id,  /* (IN)  Id of line being projected to.  This line must */
                     /*       have been cached previously by one of the      */
                     /*       FEM_InitLinesX routines.  If it has not been   */
                     /*       cached, DO NOT call a slower more expensive    */
                     /*       projection routine, rather return without      */
                     /*       projecting and return error == EXIT_FAILURE    */
   FEM_DOUBLE xyzin[3], 
                     /* (IN)  Unprojected location of point                  */
   FEM_DOUBLE s_in,  /* (IN)  Guess at s parametric location.  If a guess    */
                     /*       cannot be determined, guess arg will be TRUE   */
   FEM_BOOLEAN no_guess,
                     /* (IN)  TRUE if s_in are not able to be determined and */
                     /*       are ignored.                                   */
   FEM_DOUBLE *s_out,/* (OUT) Computed s parametric location                 */
   FEM_DOUBLE xyzout[3],
                     /* (OUT) Projected location of point                    */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */
                     /*       Return EXIT_FAILURE if line is                 */
                     /*       not cached or for any other error condition.   */




                     /* ==================================================== */
                     /* === FEMe_LineEvaluate: Evaluate a specified          */
                     /* === parametric location on a line.  FEMe_InitLinesI, */
                     /* === FEMe_InitLinesII, or FEMe_InitLinesIII, must     */
                     /* === have been previously called.                     */
                     /* ===                                                  */
                     /* === NOTE: The expected line parameterization is arc  */
                     /* ===       length parameterization and goes from 0.0  */
                     /* ===       to 1.0 where:                              */
                     /* ===       s = 0.0 at kp1 returned from FEMe_LineKps  */
                     /* ===       s = 1.0 at kp2 returned from FEMe_LineKps  */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_LineEvaluate (
   FEM_INT line_id,  /* (IN)  Id of line being evaluated.  This line must    */
                     /*       have been cached previously by one of the      */
                     /*       FEM_InitLinesX routines.  If it has not been   */
                     /*       cached, DO NOT call a slower more expensive    */
                     /*       evaluation routine, rather return without      */
                     /*       evaluating and return error == EXIT_FAILURE    */
   FEM_DOUBLE s,     /* (IN)  s parametric location                          */
   FEM_DOUBLE xyz[3],/* (OUT) xyz value at s on line                         */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */
                     /*       Return EXIT_FAILURE if line is                 */
                     /*       not cached or for any other error condition.   */




                     /* ==================================================== */
                     /* === FEMe_IsLineStraight: Determine if a line is      */
                     /* === straight ( i.e. no curvature what so ever).      */
                     /* === FEMe_InitLinesI, FEMe_InitLinesII, or            */
                     /* === FEMe_InitLinesIII must have been called          */
                     /* === previously.                                      */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (FEM_BOOLEAN)                            */
                     /* ===                   TRUE if line is straight       */
                     /* ===                   FALSE if not straight.         */
                     /* ==================================================== */
FEM_CPP_EXTERN FEM_BOOLEAN FEMe_IsLineStraight (
   FEM_INT line_id,  /* (IN)  Id of line being checked.  This line must be   */
                     /*       cached previously by one of the FEM_InitLinesX */
                     /*       routines.  If it has not been cached, return   */
                     /*       error == EXIT_FAILURE                          */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */
                     /*       Return EXIT_FAILURE if line is                 */
                     /*       not cached or for any other error condition.   */




                     /* ==================================================== */
                     /* === FEMe_LineCurvature: Evaluate the curvature at a  */
                     /* === location on a line.  FEMe_InitLinesI,            */
                     /* === FEMe_InitLinesII, FEMe_InitLinesIII, must have   */
                     /* === been previously called.                          */
                     /* ===                                                  */
                     /* === NOTE: The expected line parameterization is arc  */
                     /* ===       length parameterization and goes from 0.0  */
                     /* ===       to 1.0 where:                              */
                     /* ===       s = 0.0 at kp1 returned from FEMe_LineKps  */
                     /* ===       s = 1.0 at kp2 returned from FEMe_LineKps  */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_LineCurvature (
   FEM_INT line_id,  /* (IN)  Id of line being evaluated for curvature.  This*/
                     /*       line must have been cached previously by one   */
                     /*       of the FEM_InitLinesX routines.  If it has not */
                     /*       been cached, DO NOT call a slower more         */
                     /*       expensive curvature evaluation routine, rather */
                     /*       return without evaluating curvature and return */
                     /*       error == FEM_FAILURE                           */
   FEM_DOUBLE s,     /* (IN)  s parametric location                          */
   FEM_DOUBLE *curv, /* (OUT) Curvature at s                                 */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_SUCCESS or EXIT_FAILURE)    */
                     /*       Return EXIT_FAILURE if line is                 */
                     /*       not cached or for any other error condition.   */





/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++   Status Window Manipulation +++++++++++++++++++++++++++++*/
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

#if 0
   The following prototypes describe the functions used to control and update
a status window and abort button.  These functions will be called in the
following order:

    1.  FEMe_SetUpStatusWindow will be called.  When it is called, the
        native CAD software should initialize and pop up the status window
        on the screen showing that 0 percent of the operation has been
        completed.  The argument process_type specifies what type of
        process is being started and can be used to generate a text string
        to be displayed on the Status Window.  Possible values for
        process_type are described in Mstat.h.  Each process_type
        is broken up into sub-processes which are denoted by the variable
        arguments process_subtype.  These are subprocesses of process_type.
        Each of these subprocesses is also described in Mstat.h.

        "a_ivalues[3]" are integer numbers used to describe what is geometric
        entity is being meshed in the current process (i.e., meshing volume
        id 15, etc.).  A description of these values is found in
        Mstat.h.  The "a_ivalues" array sent to FEMe_SetUpStatusWindow
        applies to the entire process.

   2.   During the process FEMe_UpdateStatusWindow, FEMe_CheckStatusWindow,
        and FEMe_UserAbort will be called periodically to update the status
        window and check for user aborts.  Percentages passed in refer to
        the percent complete of the current subprocess rather than of the
        entire process.  The "a_ivalues[3]" array sent to these functions
        applies to the current subprocess rather than to the entire process and
        are described in Mstat.h.

   3.   At the end of the process FEMe_KillStatusWindow will be called to
        free up any resources required to maintain the status window.

  Since no return data is required from the status window and abort routines
except if the user requested an abort.  These functions do not have to be
implemented.  They can be stubbed out returning FALSE for abort whenever
called.  This, however, would not allow the user to stop a large process that
is taking too long.

#endif
                     /* ==================================================== */
                     /* === FEMe_SetUpStatusWindow: Do whatever              */
                     /* === initialization is required to allow for progress */
                     /* === window bar updating and abort button access for  */
                     /* ===  the specified process type.                     */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_SetUpStatusWindow (
   FEM_INT process_type,
                     /* (IN)  Process type identifier                        */
   FEM_INT a_ivalues[3],
                     /* (IN)  Process specific integer values printed on     */
                     /*       process box dialog.  Description of possible   */
                     /*       values can be found in Mstat.h                 */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */




                     /* ==================================================== */
                     /* === FEMe_KillStatusWindow: Do whatever cleanup is    */
                     /* === necessary ( memory deallocation, etc.) now that  */
                     /* === the progess status window is no longer needed.   */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_KillStatusWindow( void  );




                     /* ==================================================== */
                     /* === FEMe_UpdateStatusWindow: Update status window    */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_UpdateStatusWindow (
   FEM_INT process_subtype,
                     /* (IN)  Sub-process identifier.                        */
   FEM_INT percent,  /* (IN)  Process percent complete (int from 0 to 100)   */
   FEM_INT a_ivalues[3],
                     /* (IN)  Sub-process specific integer values printed on */
                     /*       process box dialog.  Description of possible   */
                     /*       values can be found in Mstat.h                 */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */




                     /* ==================================================== */
                     /* === FEMe_CheckStatusWindow: Same as                  */
                     /* === FEMe_UpdateStatusWindow except it also checks    */
                     /* === for user abort                                   */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_CheckStatusWindow (
   FEM_INT process_subtype,
                     /* (IN)  See FEMe_UpdateStatusWindow                    */
   FEM_INT percent,  /* (IN)  See FEMe_UpdateStatusWindow                    */
   FEM_INT a_ivalues[3],
                     /* (IN)  See FEMe_UpdateStatusWindow                    */
   FEM_BOOLEAN *abort,
                     /* (OUT) TRUE if user abort requested.                  */
                     /*       FALSE if no abort requested.                   */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */




                     /* ==================================================== */
                     /* === FEMe_ContStatusWindow: Override the user abort   */
                     /* === and bring up the window after it has gone away.  */
                     /* === Can only be called after FEMe_SetUpStatusWindow  */
                     /* === and before FEMe_KillStatusWindow.                */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_ContStatusWindow (
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_SUCCESS or EXIT_FAILURE)    */


                     /* ==================================================== */
                     /* === FEMe_TimeStatusWindow: Set relative time for    */
                     /* === a given process                                  */
                     /* === Can only be called after FEMex_SetUpStatusWindow  */
                     /* === and before FEMex_KillStatusWindow.                */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_TimeStatusWindow (
   FEM_INT proc,
   FEM_INT itime,
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_SUCCESS or EXIT_FAILURE)    */


                     /* ==================================================== */
                     /* === FEMe_StatusWindowActive: return whether the      */
                     /* === status window is currently active                */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (FEM_BOOLEAN)                            */
                     /* ===                   TRUE if status window is       */
                     /* ===                        active,                   */
                     /* ===                   FALSE if status window is not  */
                     /* ===                        active,                   */
                     /* ==================================================== */
FEM_CPP_EXTERN FEM_BOOLEAN FEMe_StatusWindowActive ( void  );




                     /* ==================================================== */
                     /* === FEMe_UserAbort: Determine if user abort has      */
                     /* === occurred;                                        */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (FEM_BOOLEAN)                            */
                     /* ===                   FALSE for no abort             */
                     /* ===                   TRUE for abort.                */
                     /* ==================================================== */
FEM_CPP_EXTERN FEM_BOOLEAN FEMe_UserAbort ( void  );





/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++   Node Attribute Inquires ++++++++++++++++++++++++++++++++*/
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

                     /* ==================================================== */
                     /* === FEMe_NodeGeoEntity:  Determine the solid model   */
                     /* === attachment of a node.  node_id is the id of a    */
                     /* === node that already exists in the native CAD       */
                     /* === database.                                        */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_NodeGeoEntity (
   FEM_INT node_id,  /* (IN)  The node id                                    */
   FEM_INT *geo_id,  /* (OUT) Id of geo entity associated with node.  If     */
                     /*       node does not exist yet, geo_id == 0.          */
   FEM_GEOTYPE *geo_type,/* (OUT) geo type of geo_id                             */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */




                     /* ==================================================== */
                     /* === FEMe_LineNodeT: Given a node on a line, determine*/
                     /* === the parametric location of the node on the line. */
                     /* === node_id is the id of a node that already exists  */
                     /* === in the native CAD database.                      */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_LineNodeT (
   FEM_INT node_id,  /* (IN)  The node id                                    */
   FEM_INT line_id,  /* (IN)  The line id                                    */
   FEM_DOUBLE *tparm,/* (OUT) Parametric location on the line                */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */



                     /* ==================================================== */
                     /* === FEMe_AreaNodeUV: Given a node on an area,        */
                     /* === determine the parametric location of the node on */
                     /* === the area.  node_id is the id of a node that      */
                     /* === already exists in the native CAD database.       */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_AreaNodeUV (
   FEM_INT node_id,  /* (IN)  The node id                                    */
   FEM_INT area_id,  /* (IN)  The area id                                    */
   FEM_DOUBLE *u,    /* (OUT) Parametric location on the line                */
   FEM_DOUBLE *v,    /* (OUT) Parametric location on the line                */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */




                     /* ==================================================== */
                     /* === FEMe_LineMesh:  Given a line number, return      */
                     /* === information about the nodes and edges on it.     */
                     /* === Midnodes are not returned.  This routine should  */
                     /* === only return nodes that are already stored on this*/
                     /* === line in the native CAD database.                 */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (FEM_INT) Number of element divisions    */
                     /* ===               that already exist on the line.    */
                     /* ==================================================== */
FEM_CPP_EXTERN FEM_INT FEMe_LineMesh (
   FEM_INT line_id,  /* (IN)  The line id                                    */
   FEM_DOUBLE *a_line_t,
                     /* (OUT) Parametric locations ( 0 <= t <= 1.0 ) of the  */
                     /*       nodes on the line.                             */
                     /*       (length of array = num elem divisions - 1)     */
                     /*       Calling routine is responsible for allocating  */
                     /*       memory for this routine.                       */
                     /*                                                      */
                     /*      NOTE: The expected line parameterization is     */
                     /*            arc length parameterization and goes      */
                     /*            from 0.0 to 1.0 where:                    */
                     /*            s = 0.0 at kp1 returned from FEMe_LineKps */
                     /*            s = 1.0 at kp2 returned from FEMe_LineKps */
                     /*                                                      */
                     /*      NOTE:  If the line does not have any keypoints  */
                     /*             at its' ends, then a_line_t MUST be      */
                     /*             returned as 0.0 for the first node on    */
                     /*             the line.  In this case, there MUST be a */
                     /*             node at t = 0.0 on the line.             */
                     /*                                                      */
   FEM_DOUBLE *a_xyz,/* (OUT) xyz location of nodes on the line              */
                     /*       (length = 3 * num elem divisions - 1)          */
                     /*       nodes at the keypoints at the 2 ends are not   */
                     /*       included in this array.                        */
                     /*       this array is parallel to a_line_t             */
                     /*       Calling routine is responsible for allocating  */
                     /*       memory for this routine.                       */
                     /*                                                      */
                     /*      NOTE:  If the line does not have any keypoints  */
                     /*             at its' ends, then a_xyz MUST be         */
                     /*             returned as the location of the first    */
                     /*             node on the line (at t = 0.0).  In this  */
                     /*             case, there MUST be a node at t = 0.0 on */
                     /*             the line.                                */
                     /*                                                      */
   FEM_INT *a_ids,   /* (OUT) Ids of the nodes on the line                   */
                     /*       (length of = num elem divisions - 1)           */
                     /*       this array is parallel to a_line_t             */
                     /*       Calling routine is responsible for allocating  */
                     /*       memory for this routine.                       */
                     /*                                                      */
                     /*      NOTE:  If the line does not have any keypoints  */
                     /*             at its' ends, then a_ids MUST be         */
                     /*             returned as the id of the first node on  */
                     /*             the line (at t = 0.0).  In this  case,   */
                     /*             there MUST be a node at t = 0.0 on the   */
                     /*             line.                                    */
                     /*                                                      */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */




                     /* ==================================================== */
                     /* === FEMe_LineMeshII:  Given a line number, return    */
                     /* === information about the desired mesh on it.        */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_LineMeshII (
   FEM_INT line_id,  /* (IN)  The line id                                    */
   FEM_INT *num_divs,/* (OUT) Number of desired divisions (element edges) on */
                     /*       this line                                      */
   FEM_DOUBLE *bias, /* (OUT) Spacing ratio for biasing.  If positive,       */
                     /*       "bias" is the nominal ratio of last division   */
                     /*       size to first division size.  (If > 1.0, sizes */
                     /*       increase, if < 1.0, sizes decrease). If        */
                     /*       negative, |bias|  is nominal ratio of center   */
                     /*       division(s) size to end division size.         */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */




                     /* ==================================================== */
                     /* === FEMe_LineNumElemDivisions: return the number of  */
                     /* === element divisions on a line.  This routine is    */
                     /* === used for two purposes: (1) to see how much       */
                     /* === to allocate to send down to FEMe_LineMesh        */
                     /* === and (2) to see if the locations of the node on   */
                     /* === a line can be changed by line smoothing.  If the */
                     /* === number of divisions returned from this routine   */
                     /* === is positive, the locations of nodes on the line  */
                     /* === will not be changed by line smoothing.  This is  */
                     /* === done to preserve any node location bias          */
                     /* === set by the user.                                 */
                     /* ===                                                  */
                     /* === Return: (FEM_INT) num elem divisions on the line.*/
                     /* ===                                                  */
                     /* ===    If the line is not meshed and the user has    */
                     /* ===        not specified how many divisions the line */
                     /* ===        gets, 0 is returned.                      */
                     /* ===    If the line is not meshed, but the user has   */
                     /* ===        specified how many divisions the line     */
                     /* ===        gets, num_divs is returned, where         */
                     /* ===        num_divs is the number of divisions the   */
                     /* ===        user wants on the line.                   */
                     /* ===    If the line is meshed and the user does not   */
                     /* ===        want the number of divisions to change,   */
                     /* ===        num_divs is returned, where num_divs is   */
                     /* ===        the number of divisions on the line.      */
                     /* ===    If the line is meshed but the user does not   */
                     /* ===        care if the number of divisions changes,  */
                     /* ===        -num_divs is returned, where num_divs is  */
                     /* ===        the number of divisions on the line.      */
                     /* ===                                                  */
                     /* === If the return value is positive, no splitting,   */
                     /* === smoothing or any other operation will alter the  */
                     /* === number of divisions or node placement on the line*/
                     /* ==================================================== */
FEM_CPP_EXTERN FEM_INT FEMe_LineNumElemDivisions (
   FEM_INT line_id,  /* (IN)  The line id                                    */
   FEM_BOOLEAN *soft,/* (OUT) TRUE if the line is not meshed, and the user   */
                     /*       would rather not have the divisions change on  */
                     /*       this line, but if they must in order to get a  */
                     /*       mesh, they can.                                */
                     /*       FALSE if the divisions on this line are set by */
                     /*       user and they cannot change even if it means a */
                     /*       mesh failure will result.                      */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */




                     /* ==================================================== */
                     /* === FEMe_LineNumNodes                                */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (FEM_INT) the number of nodes on a line  */
                     /* ===               including midnodes, (Not including */
                     /* ===               nodes at keypoints on each end).   */
                     /* ===               If the line is not meshed, 0 is    */
                     /* ===               returned.  If the line is meshed   */
                     /* ===               but there are no nodes on the line */
                     /* ===               (i.e., there is only one elem      */
                     /* ===               division on the line and no        */
                     /* ===               midnodes ), -1 is returned.        */
                     /* ==================================================== */
FEM_CPP_EXTERN FEM_INT FEMe_LineNumNodes (
   FEM_INT line_id,  /* (IN)  The line id                                    */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */




                     /* ==================================================== */
                     /* === FEMe_NodeXYZ: Retrieve a pre-existing node's xyz */
                     /* === location.   "node_id" is the id of a node that   */
                     /* === already exists in the native CAD database.       */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_NodeXYZ (
   FEM_INT node_id,  /* (IN)  The node id                                    */
   FEM_DOUBLE xyz[3],/* (OUT) xyz location of node                           */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */




/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++   Volume Attribute Inquires ++++++++++++++++++++++++++++++*/
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/




                     /* ==================================================== */
                     /* === FEMe_NumVolShells: return the number of shells   */
                     /* === on a volume.                                     */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (FEM_INT) the number of shells on the    */
                     /* ===                   volume                         */
                     /* ==================================================== */
FEM_CPP_EXTERN FEM_INT FEMe_NumVolShells (
   FEM_INT vol_id,   /* (IN)  The volume id                                  */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_SUCCESS or EXIT_FAILURE)    */




                     /* ==================================================== */
                     /* === FEMe_PossibleVolElemShape: return the possible   */
                     /* === element shape that can be put in this unmeshed   */
                     /* === volume.                                          */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: void                                     */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_PossibleVolElemShape (
   FEM_INT vol_id,   /* (IN)  The volume id                                  */
   FEM_BOOLEAN *hex_shape,   /* (OUT) TRUE if volume can have hexes. */
   FEM_BOOLEAN *wedge_shape, /* (OUT) TRUE if volume can have wedges. */
   FEM_BOOLEAN *pyr_shape,   /* (OUT) TRUE if volume can have pyramids. */
   FEM_BOOLEAN *tet_shape,   /* (OUT) TRUE if volume can have tets. */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_SUCCESS or EXIT_FAILURE)    */




                     /* ==================================================== */
                     /* === FEMe_VolumeElementShape: Return information about*/
                     /* === the shape of the elements meshed in a volume     */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (FEM_INT) return the element shape of    */
                     /* ===               the elements in a volume.  Return  */
                     /* ===               value is one of the following:     */
                     /* ===                                                  */
                     /* ===   if volume is meshed with tets, 5 is returned.  */
                     /* ===   if volume is meshed with hexs which can be     */
                     /* ===       degenerated into tets, 6 is returned.      */
                     /* ===   if volume is meshed with hexs which cannot be  */
                     /* ===       degenerated into tets, 7 is returned.      */
                     /* ===   if the volume is not meshed in the native CAD  */
                     /* ===       database, 0 is returned.                   */
                     /* ==================================================== */
FEM_CPP_EXTERN FEM_INT FEMe_VolumeElementShape (
   FEM_INT vol_id,   /* (IN)  The volume id                                  */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_SUCCESS or EXIT_FAILURE)    */





                     /* ==================================================== */
                     /* === FEMe_VolumeNumNodes                              */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return:  (FEM_INT) the number of nodes inside of */
                     /* ===                a volume mesh.  Nodes on the      */
                     /* ===                areas, lines and keypoints        */
                     /* ===                defining the volume are not       */
                     /* ===                counted.  If the volume is not    */
                     /* ===                meshed, 0 is returned.            */
                     /* ==================================================== */
FEM_CPP_EXTERN FEM_INT FEMe_VolumeNumNodes (
   FEM_INT vol_id,   /* (IN)  The volume id                                  */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_SUCCESS or EXIT_FAILURE)    */




                     /* ==================================================== */
                     /* === FEMe_VolumeNumElems                              */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (FEM_INT) the number of elems in a       */
                     /* ===         volume. If the volume is not meshed,  0  */
                     /* ===         is returned.                             */
                     /* ==================================================== */
FEM_CPP_EXTERN FEM_INT FEMe_VolumeNumElems (
   FEM_INT vol_id,   /* (IN)  The volume id                                  */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_SUCCESS or EXIT_FAILURE)    */




                     /* ==================================================== */
                     /* === FEMe_TetJacobianErrorLimit: Return the maximum   */
                     /* === allowable Jacobian allowable for Tetrahedral     */
                     /* === elements.                                        */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (FEM_DOUBLE) jacobian limit.             */
                     /* ==================================================== */
FEM_CPP_EXTERN FEM_DOUBLE FEMe_TetJacobianErrorLimit (
   FEM_INT vnum,
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_SUCCESS or EXIT_FAILURE)    */




                     /* ==================================================== */
                     /* === FEMe_GetElemsInVolume: Get a list of all         */
                     /* === elements on a volume.  Elements returned must    */
                     /* === already be stored in the native CAD database.    */
                     /* === Return: (FEM_INT) The number of elements in the  */
                     /* ===               volume.  If the volume is not      */
                     /* ===               meshed in the native CAD database, */
                     /* ===               then 0 is returned.                */
                     /* ==================================================== */
FEM_CPP_EXTERN FEM_INT FEMe_GetElemsInVolume (
   FEM_INT vol_id,   /* (IN)  The volume to get elems out of.                */
   FEM_INT *a_elems, /* (OUT) Array of ids of elements on vol_id             */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_SUCCESS or EXIT_FAILURE)    */




                     /* ==================================================== */
                     /* === FEMe_VolsAttachedToArea: Get a list of the       */
                     /* === volume ids of volumes attached to an area.       */
                     /* === Return the number of volumes attached to the     */
                     /* === area.                                            */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (FEM_INT) number of volumes attached to  */
                     /* ===               the area                           */
                     /* ==================================================== */
FEM_CPP_EXTERN FEM_INT FEMe_VolsAttachedToArea (
   FEM_INT area_num, /* (IN)  The area id                                    */
   FEM_INT *a_adjvols,/*(OUT) Array of volume ids attached to area.  This    */
                     /*       array is allocated by the calling function to  */
                     /*       be the size returned by                        */
                     /*       FEMe_NumVolsAttachedToArea                     */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_SUCCESS or EXIT_FAILURE)    */




                     /* ==================================================== */
                     /* === FEMe_NumVolsAttachedToArea: Return the number of */
                     /* === volumes attached to an area.  Same as            */
                     /* === FEMe_VolsAttachedToArea except that the vol ids  */
                     /* === of attached vols are not returned.               */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (FEM_INT) number of volumes attached to  */
                     /* ===               the area                           */
                     /* ==================================================== */
FEM_CPP_EXTERN FEM_INT FEMe_NumVolsAttachedToArea (
   FEM_INT area_num, /* (IN)  The area id                                    */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_SUCCESS or EXIT_FAILURE)    */




                     /* ==================================================== */
                     /* === FEMe_NumVolAreas: Returns the number of areas    */
                     /* === on a volume.  The total number of areas defining */
                     /* === the volume is returned including all areas on all*/
                     /* === shells.                                          */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (FEM_INT) the number of areas on the     */
                     /* ===         volume                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN FEM_INT FEMe_NumVolAreas (
   FEM_INT vol_id,   /* (IN)  The volume id                                  */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */




                     /* ==================================================== */
                     /* === FEMe_VolAreas: Returns the ids of all areas      */
                     /* === defining a volume.  The ids of all areas         */
                     /* === defining the volume area returned, including all */
                     /* === areas on all shells.                             */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (FEM_INT) the number of areas on the     */
                     /* ===         volume                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN FEM_INT FEMe_VolAreas (
   FEM_INT vol_id,   /* (IN)  The volume id                                  */
   FEM_INT *a_areas, /* (OUT) Array of area ids defining the volume.  The    */
                     /*       calling routine is responsible for allocating  */
                     /*       this array to be the size returned from        */
                     /*       FEMe_NumVolAreas.                              */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */




                     /* ==================================================== */
                     /* === FEMe_VolVolume: Returns the volume of a volume.  */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (FEM_DOUBLE) The volume of the volume    */
                     /* ==================================================== */
FEM_CPP_EXTERN FEM_DOUBLE FEMe_VolVolume (
   FEM_INT vol_id,   /* (IN)  The volume id                                  */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */




/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++   Area Attribute Inquires ++++++++++++++++++++++++++++++++*/
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

                     /* ==================================================== */
                     /* === FEMe_MaxNumAreas                                 */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (FEM_INT) return the number of areas in  */
                     /* ===               the model.                         */
                     /* ==================================================== */
FEM_CPP_EXTERN FEM_INT FEMe_MaxNumAreas (
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */



                     /* ==================================================== */
                     /* === FEMe_IsAreaClosed: Determine if an area is       */
                     /* === closed in either the u or v parametric direction */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_IsAreaClosed (
   FEM_INT area_num, /* (IN)  The area id                                    */
   FEM_BOOLEAN *in_u,/* (OUT) TRUE if closed in u, otherwise FALSE.          */
                     /*       An area is closed in u if both (umin,v) and    */
                     /*       (umax,v) evaluate to the same location in xyz  */
                     /*       space.                                         */
   FEM_BOOLEAN *in_v,/* (OUT) TRUE if closed in v, otherwise FALSE.          */
                     /*       An area is closed in v if both (u,vmin) and    */
                     /*       (u,vmax) evaluate to the same location in xyz  */
                     /*       space.                                         */
   FEM_INT *error ); /* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */



                     /* ==================================================== */
                     /* === FEMe_AreaParamRange: Return the parametric max   */
                     /* === and min of an area.                              */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_AreaParamRange(
   FEM_INT area_num, /* (IN)  The area id                                    */
   FEM_DOUBLE *minu, /* (OUT) min in u direction.                            */
   FEM_DOUBLE *minv, /* (OUT) max in u direction.                            */
   FEM_DOUBLE *maxu, /* (OUT) min in v direction.                            */
   FEM_DOUBLE *maxv, /* (OUT) max in v direction.                            */
   FEM_INT *error ); /* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */


                     /* ==================================================== */
                     /* === FEMe_AreaBoundingBox: Return the bounding box of and area    */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_AreaBoundingBox(
   FEM_INT area_num, /* (IN)  The area id                                    */
   FEM_DOUBLE a_min[3], /* (OUT) min                           */
   FEM_DOUBLE a_max[3], /* (OUT) max                            */
   FEM_INT *error ); /* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */


                     /* ==================================================== */
                     /* === FEMe_SurfaceOrientationWRTArea: Return the orientaiton of the surface wrt the area    */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
FEM_CPP_EXTERN void FEMe_SurfaceOrientationWRTArea(
   FEM_INT area_num, /* (IN)  The area id                                    */
   FEM_INT *orientation,  /*(OUT) 0 - opposite face, 1- with face */
   FEM_INT *error );


                     /* ==================================================== */
                     /* === FEMe_AreaHasLoneSeamKps: Return the ids of any   */
                     /* === keypoints on this area that are at the ends of   */
                     /* === a seamline (i.e. at the tip of a cone, or the    */
                     /* === pole of a sphere).  If the keypoint is attached  */
                     /* === to any line defining the area, then it is not    */
                     /* === "lone" and therefore should not be returned.     */
                     /* === There should not ever be more than 2 of them.  If*/
                     /* === there is then return error == EXIT_FAILURE,      */
                     /* === because its a weird surface that we are not able */
                     /* === to support.  By definition, if this area is not  */
                     /* === closed, then there are not any "lone" keypoints. */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
void FEMe_AreaHasLoneSeamKps(
   FEM_INT area_num, /* (IN)  The area id                                    */
   FEM_INT a_kps[2], /* (OUT) The ids of at most 2 keypoints alone at ends of*/
                     /*       the seamline.                                  */
   FEM_INT *num_kps, /* (OUT) either 0, 1, or 2, depending upon how many     */
                     /*       there are.                                     */
   FEM_INT *error ); /* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */


/*==========================================================================
 * === Function: FEMex_NumLinesInLoops
 * === Description: Get a the number of edges in each loops of the area.
 * ===              use sign to specify inner loops and outter loops
 * === Return (reserved for future use, 0 at this time )
 *========================================================================== */
FEM_CPP_EXTERN FEM_INT FEMe_NumLinesInLoops(
   FEM_INT area_num,   /* (IN)  area number of inquire  */
   FEM_INT *a_numEdges,  /* (out) number of edges of each loops, positive for outter loops negative for inner loops */
   FEM_INT *error ) ;

                     /*===================================================== */
                     /* === FEMe_NumAreaLoops: Get the number of loops       */
                     /* === on an area.                                      */
                     /* ===                                                  */
                     /* === Return (FEM_INT) the number of loops on the area */
                     /* ==================================================== */
FEM_CPP_EXTERN FEM_INT FEMe_NumAreaLoops (
   FEM_INT area_num, /* (IN)  The area id                                    */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */

                     /*===================================================== */
                     /* === FEMe_NumAreaLoopsII: Get the number of loops      */
                     /* === on an area.                                      */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return (FEM_INT) the number of loops on the area */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_NumAreaLoopsII (
   FEM_INT area_num, /* (IN)  The area id                                    */
   INT *num_internal_loops,/* (OUT) number of internal loops                 */
   INT *num_external_loops,/* (OUT) number of external loops                 */
   INT *error );    /* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)     */



                     /* ==================================================== */
                     /* === FEMe_NumAreaLoopLines:  Get a the number of lines*/
                     /* === that define an area loop.                        */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return (FEM_INT) the number of lines.  If        */
                     /* ===              the_loop == 0, return the maximum   */
                     /* ===              number of loops on any loop on the  */
                     /* ===              area.                               */
                     /* ==================================================== */
FEM_CPP_EXTERN FEM_INT FEMe_NumAreaLoopLines (
   FEM_INT area_num, /* (IN)  The area id                                    */
   FEM_INT the_loop, /* (IN)  The loop number on area_num.                   */
                     /*       possible values for "the_loop" are between 0   */
                     /*       and the return value from FEMe_NumAreaLoops.   */
                     /*       "the_loop" == 1 always refers to the first     */
                     /*       outermost loop.                                */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */



FEM_CPP_EXTERN void FEMe_AreaLoopType (
   INT iAreaId,   /* (IN)  area number of inquire */
   INT iLoopId,   /* (IN) */
   INT *iType,    /* -1: undefine, 0: ext, 1: inter */
   INT *iError );


                     /* ==================================================== */
                     /* === FEMe_AreaLoopLines: Get the ids of the lines     */
                     /* === that define an area loop.                        */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_AreaLoopLines (
   FEM_INT area_num, /* (IN)  The area id                                    */
   FEM_INT the_loop, /* (IN)  The loop number on area_num.                   */
                     /*       possible values for "the_loop" are between 1   */
                     /*       and the return value from FEMe_NumAreaLoops.   */
                     /*       "the_loop" == 1 always refers to the first     */
                     /*       outermost loop.                                */
   FEM_INT *a_lines, /* (OUT) Lines on this loop.  Outer loop lines are in   */
                     /*       counterclockwise order.  Inner loop lines are  */
                     /*       in clockwise order. Line ids are positive if   */
                     /*       line is in direction of the loop.  Line ids    */
                     /*       are negative if line is in opposite direction  */
                     /*       of the loop.  Calling function is responsible  */
                     /*       for allocating the memory for the array.       */
                     /*       (array dimension = the size returned by        */
                     /*        FEMe_NumAreaLoopLines)                        */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */




                     /* ==================================================== */
                     /* === FEMe_AreaLines:  Get a list of line ids of all   */
                     /* === lines that define an area.  All lines defining   */
                     /* === the area are included in the list regardless of  */
                     /* === the number of line loops on the area.            */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_AreaLines (
   FEM_INT area_num, /* (IN)  The area id                                    */
   FEM_INT *a_lines, /* (OUT) Array of line ids.                             */
   FEM_INT *a_dir,   /* (IN)  If NULL, then do not return directions.        */
                     /* (OUT) Array parallel to a_lines that specifies the   */
                     /*       direction of each line with respect to the     */
                     /*       area.  Only returned if a_dir != NULL.         */
                     /*              a_dir[i] == 1 if the area is on the     */
                     /*                          left of the line.           */
                     /*              a_dir[i] == -1 if the area is on the    */
                     /*                          right of the line.          */
                     /*              a_dir[i] == 0 if the area is closed or  */
                     /*                          non-manifold and this lines */
                     /*                          direction is indeterminate. */
   FEM_INT *num_line,/* (OUT) Number of output lines (dimension of a_lines)  */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */




                     /* ==================================================== */
                     /* === FEMe_IsAreaKpSide: Given an area number and a    */
                     /* === kp number on that area, indicate whether that kp */
                     /* === has been specified to be a side angle for map    */
                     /* === meshing.                                         */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
void FEMe_IsAreaKpSide(
   FEM_INT area_id,  /* (IN)  the area of inquire                            */
   FEM_INT kp_id,    /* (IN)  the kp of inquire                              */
   FEM_INT *side,    /* (OUT) 1 if kp is a side, otherwise 0                 */
   FEM_INT *error ); /* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */





                     /* ==================================================== */
                     /* === FEMe_GetElemsOnArea: Get a list of all elements  */
                     /* === on an area.  Elements returned must already be   */
                     /* === stored in the native CAD database.               */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (FEM_INT) number of elements on the area.*/
                     /* ===               If the area is not meshed in the   */
                     /* ===               native CAD database, then 0 is     */
                     /* ===               returned.                          */
                     /* ==================================================== */
FEM_CPP_EXTERN FEM_INT FEMe_GetElemsOnArea (
   FEM_INT area_id,  /* (IN)  The area to get elems off of.                  */
   FEM_INT *a_elems, /* (OUT) Array of ids of elements on "area_id"          */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */




                     /* ==================================================== */
                     /* === FEMe_GetFacetsOnArea: Get a list of all facets   */
                     /* === on an area (recovered from the the volume        */
                     /* === elements adjacent to this area).  Facets are     */
                     /* === recovered from volume elements in adjacent       */
                     /* === volumes that are already stored in the native    */
                     /* === CAD database.  If the area is already meshed     */
                     /* === with area elements, they are ignored and the     */
                     /* === facets from the volume elements are recovered.   */
                     /* === If no adjacent volume is meshed with volume      */
                     /* === elements, no facets are returned, even if the    */
                     /* === area is meshed with area elements.               */
                     /* === FEMe_GetFacetsOnArea is only called after        */
                     /* === FEMe_GetElemsOnArea has been called and returned */
                     /* === 0 for number of area elements on the area.       */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_GetFacetsOnArea (
   FEM_INT area_id,  /* (IN)  The area to get facets off of.                 */
   FEM_DOUBLE **a_xyz,/*(OUT) Array of nodal locations (3*num_nodes long)    */
                     /*       FEMe_GetFacetsOnArea is responsible for        */
                     /*       allocating memory for "a_xyz".  After the      */
                     /*       ANSYS meshing database is finished with the    */
                     /*       memory, it will be freed by calling            */
                     /*       FEMe_Free().                                   */
   FEM_INT **a_nodes,/* (OUT) Array of node ids (num_nodes long).  This array*/
                     /*       is parallel to "a_xyz" and stores the ids of   */
                     /*       the nodes as stored in the native CAD database.*/
                     /*       FEMe_GetFacetsOnArea is responsible for        */
                     /*       allocating memory for "a_node_ids".  After the */
                     /*       ANSYS meshing database is finished with the    */
                     /*       memory, it will be freed by calling            */
                     /*       FEMe_Free().                                   */
   FEM_INT *nnodes,  /* (OUT) Number of nodes on the area.  If no adjacent   */
                     /*       volume is meshed, then "num_facets" is         */
                     /*       returned as 0.                                 */
   FEM_INT **a_iel,  /* (OUT) Connectivity of nodes to form facets.          */
                     /*       (array dimension = 8*num_facets long)          */
                     /*       example:                                       */
                     /*                                                      */
                     /*         corner nodes of 1st facet   a_iel[0] = 34    */
                     /*                                     a_iel[1] = 25    */
                     /*                                     a_iel[2] = 101   */
                     /*                                     a_iel[3] = 3     */
                     /*                                                      */
                     /*         midnodes of 1st facet       a_iel[4] = 27    */
                     /*                                     a_iel[5] = 220   */
                     /*                                     a_iel[6] = 221   */
                     /*                                     a_iel[7] = 119   */
                     /*                                                      */
                     /*         corner nodes of 2nd facet   a_iel[8] = 11    */
                     /*                                     a_iel[9] = 17    */
                     /*                                     a_iel[10] = 444  */
                     /*                                     a_iel[11] = 8    */
                     /*                                                      */
                     /*         midnodes of 2nd facet       a_iel[12] = 13   */
                     /*                                     a_iel[13] = 117  */
                     /*                                     a_iel[14] = 118  */
                     /*                                     a_iel[15] = 121  */
                     /*                                                      */
                     /*       If no midnodes, store 0 in midnode locations.  */
                     /*       If triangle, store 3rd node id in both 3rd node*/
                     /*       and 4th node locations.  FEMe_GetFacetsOnArea  */
                     /*       is responsible for allocating memory for       */
                     /*       a_iel.  After the ANSYS meshing database is    */
                     /*       finished with the memory, it will be freed by  */
                     /*       calling FEMe_Free().  Order of facet nodes     */
                     /*       must be consistent from one facet to the next. */
   FEM_INT *nfacets, /* (OUT) Number of facets in a_iel.  If no adjacent     */
                     /*       volume is meshed, then "num_facets" is         */
                     /*       returned as 0.                                 */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */




                     /* ==================================================== */
                     /* === FEMe_AreaElementShape: Return information about  */
                     /* === the shape of the elements meshed on an area      */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (FEM_INT) the element shape of the elems */
                     /* ===               in an area.  Return value is one   */
                     /* ===               of the following:                  */
                     /* ===                                                  */
                     /* ===   if area is meshed with tris, 2 is returned.    */
                     /* ===   if area is meshed with quads which can be      */
                     /* ===       degenerated into tris, 3 is returned.      */
                     /* ===   if area is meshed with quads which cannot be   */
                     /* ===       degenerated into tris, 4 is returned.      */
                     /* ===   if the area is not meshed in the native CAD    */
                     /* ===       database, 0 is returned.                   */
                     /* ==================================================== */
FEM_CPP_EXTERN FEM_INT FEMe_AreaElementShape (
   FEM_INT area_id,  /* (IN)  The area id                                    */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_SUCCESS or EXIT_FAILURE)    */




                     /* ==================================================== */
                     /* === FEMe_AreaNumNodes                                */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return:  (FEM_INT) return the number of nodes    */
                     /* ===                inside of an area mesh.  Nodes on */
                     /* ===                the lines and keypoints defining  */
                     /* ===                the area are not counted.  If the */
                     /* ===                area is not meshed in the native  */
                     /* ===                CAD database, 0 is returned.      */
                     /* ==================================================== */
FEM_CPP_EXTERN FEM_INT FEMe_AreaNumNodes (
   FEM_INT area_id,  /* (IN)  The area id                                    */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_SUCCESS or EXIT_FAILURE)    */




                     /* ==================================================== */
                     /* === FEMe_AreaNumElems                                */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return:  (FEM_INT) return the number of elems in */
                     /* ===                an area mesh.  If the area is not */
                     /* ===                meshed in the native CAD          */
                     /* ===                database, 0 is returned.          */
                     /* ==================================================== */
FEM_CPP_EXTERN FEM_INT FEMe_AreaNumElems (
   FEM_INT area_id,  /* (IN)  The area id                                    */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_SUCCESS or EXIT_FAILURE)    */




                     /* ==================================================== */
                     /* === FEMe_MaxAreaId: return the greatest id of all    */
                     /* === areas in the model.                              */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* ==================================================== */
FEM_CPP_EXTERN FEM_INT FEMe_MaxAreaId (
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_SUCCESS or EXIT_FAILURE)    */




                     /* ==================================================== */
                     /* === FEMe_NumAreaHardPoints: Return the number of     */
                     /* === hardpoints on a given area.                      */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (FEM_INT) # hard points.                 */
                     /* ==================================================== */
FEM_CPP_EXTERN FEM_INT FEMe_NumAreaHardPoints (
   FEM_INT area_num, /* (IN)  The area id                                    */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_SUCCESS or EXIT_FAILURE)    */




                     /* ==================================================== */
                     /* === FEMe_AreaHardPoints: Get a list of the ids of    */
                     /* === the hardpoints on a given area.                  */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (FEM_INT) # hard points in the list      */
                     /* ===                   returned                       */
                     /* ==================================================== */
FEM_CPP_EXTERN FEM_INT FEMe_AreaHardPoints (
   FEM_INT area_num, /* (IN)  The area id                                    */
   FEM_INT *a_hpt_list,/*(IN) List of hard points on area_num                */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_SUCCESS or EXIT_FAILURE)    */





                     /* ==================================================== */
                     /* === FEMe_AreaHardPointUV: Get the location of a      */
                     /* === hardpoint on an area.                            */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: void                                     */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_AreaHardPointUV (
   FEM_INT kp_id,    /* (IN)  the kp id of this hardpoint                    */
   FEM_DOUBLE *u,    /* (OUT) parametric location of this hardpoint.         */
   FEM_DOUBLE *v,    /* (OUT) parametric location of this hardpoint.         */
   FEM_DOUBLE a_xyz[3],/* (OUT) global location of this hardpoint.           */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_SUCCESS or EXIT_FAILURE)    */


                     /* ==================================================== */
                     /* === FEMe_AreaArea: Returns the area of a area.       */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (FEM_DOUBLE) The area of the area        */
                     /* ==================================================== */
FEM_CPP_EXTERN FEM_DOUBLE FEMe_AreaArea (
   FEM_INT area_id,  /* (IN)  The area id                                    */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */





/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++   Line Attribute Inquires ++++++++++++++++++++++++++++++++*/
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

                     /* ==================================================== */
                     /* === FEMe_LineKps: Retrieve the keypoints defining a  */
                     /* === line.                                            */
                     /* ===                                                  */
                     /* === NOTE: If line_num refers to a line that loops on */
                     /* ===       itself and has only 1 keypoint, then       */
                     /* ===       return *kp1 == *kp2.  If line_num refers   */
                     /* ===       to a line that loops on itself and has no  */
                     /* ===       keypoints, then return *kp1 == *kp2 == 0.  */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_LineKps (
   FEM_INT line_num, /* (IN)  The line id                                    */
   FEM_INT *kp1,     /* (OUT) Kp id where t = 0.0                            */
   FEM_INT *kp2,     /* (OUT) Kp id where t = 1.0                            */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */




                     /* ==================================================== */
                     /* === FEMe_MaxNumLines                                 */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (FEM_INT) the number of lines in the model.  */
                     /* ==================================================== */
FEM_CPP_EXTERN FEM_INT FEMe_MaxNumLines (
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */


                     /* ==================================================== */
                     /* === FEMe_LineEsize: Returns Esize of both keypoints  */
                     /* ===                 in a line.                       */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_LineEsize (
   FEM_INT lnum,      /* (IN)  Line Number                                   */
   FEM_DOUBLE *esize1, /* (OUT) First Keypoint Esize                         */
   FEM_DOUBLE *esize2, /* (OUT) Second Keypoint Esize                        */
   FEM_INT *error);    /* (OUT) Error Flag.                                  */
      
              
                     /* ==================================================== */
                     /* === FEMe_LineLength: Retrieve the length of a line.  */
                     /* ===                                                  */
                     /* === Return: (FEM_DOUBLE) the length.                 */
                     /* ==================================================== */
FEM_CPP_EXTERN FEM_DOUBLE FEMe_LineLength (
   FEM_INT line_num, /* (IN)  The line id                                    */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_SUCCESS or EXIT_FAILURE)    */

   
                     /* ==================================================== */
                     /* === FEMe_LineSlope Returns slope of a line           */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_LineSlope (
   FEM_INT lnum,        /* (IN)  Line Number                                 */
   FEM_DOUBLE s,        /* (IN) Parameter Value                              */
   FEM_DOUBLE *a_slope, /* (OUT) computed slope at s (vector array)          */  
   FEM_INT *error);     /* (OUT) Error Flag.                                 */


                     /* ==================================================== */
                     /* === FEMe_LineSlopeCurv Returns both slope and max    */
                     /* ===     curvature of a line at a point               */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_LineSlopeCurv (
   FEM_INT lnum,        /* (IN)  Line Number                                 */
   FEM_DOUBLE s,        /* (IN) Parameter Value                              */
   FEM_DOUBLE *a_slope, /* (OUT) computed slope at s (vector array[3])       */
   FEM_DOUBLE *curv,    /* (OUT) computed curvature                          */
   FEM_INT *error);     /* (OUT) Error Flag.                                 */


                     /* ==================================================== */
                     /* === FEMe_LineNumDiv: Returns number of divisions     */
                     /* ===                  on each line.                   */
                     /* === Return: (INT   )                                 */
                     /* ==================================================== */
FEM_CPP_EXTERN FEM_INT FEMe_LineNumDiv (
   FEM_INT lnum,      /* (IN)  Line Number                                   */
   FEM_INT *error);    /* (OUT) Error Flag.                                  */
                   

                     /* ==================================================== */
                     /* === FEMe_LineRatio: Returns sizing ration            */
                     /* ===                 of each line.                    */
                     /* === Return: (DOUBLE)                                 */
                     /* ==================================================== */
FEM_CPP_EXTERN FEM_DOUBLE FEMe_LineRatio (
   FEM_INT lnum,      /* (IN)  Line Number                                   */
   FEM_INT *error);    /* (OUT) Error Flag.                                  */
 

                     /* ==================================================== */
                     /* === FEMe_LineDivsFixed: Returns if divs on line are  */
                     /* ===                     fixed                        */
                     /* === Return: (INT) 1=fixed 0=not fixed                */
                     /* ==================================================== */
FEM_CPP_EXTERN FEM_INT FEMe_LineDivsFixed (
   FEM_INT lnum,      /* (IN)  Line Number                                   */
   FEM_INT *error);    /* (OUT) Error Flag.                                  */
 

                     /* ==================================================== */
                     /* === FEMe_AreasAttachedToLine: Get a list of area     */
                     /* === ids of areas attached to a line.  Return the     */
                     /* === number of areas attached to the line.            */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (FEM_INT) number of areas attached to    */
                     /* ===               the line                           */
                     /* ==================================================== */
FEM_CPP_EXTERN FEM_INT FEMe_AreasAttachedToLine (
   FEM_INT line_num, /* (IN)  The line id                                    */
   FEM_INT *a_adjareas,/*(OUT)Array of area ids attached to line             */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */


                     /* ==================================================== */
                     /* === FEMe_GetLineLayerInfo: Get parameters specifying */
                     /* === the layer mesh desired given a line number.      */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_GetLineLayerInfo (
   FEM_INT line_id,  /* (IN)  The line id                                    */
   FEM_DOUBLE *layer1,/*(OUT) Parameter specifying how far away from the line*/
                     /*       a constant element size is desired.            */
                     /*       if ( *layer1 == 0 ) no layer meshing is to be  */
                     /*                           done.                      */
                     /*       if ( *layer1 > 0 ) *layer1 is absolute         */
                     /*                          distance away from line.    */
                     /*       if ( *layer1 < 0 ) *layer1 is number of        */
                     /*                          elements away from line.    */
   FEM_DOUBLE *layer2,/*(OUT) Parameter specifying size of transitioning     */
                     /*       layer from layer elements to larger elems.     */
                     /*       if ( *layer1 == 0 ) no layer meshing is to be  */
                     /*                           done.                      */
                     /*       if ( *layer1 > 0 ) *layer1 is absolute         */
                     /*                          distance to do transitioning*/
                     /*       if ( *layer1 < 0 ) *layer1 is maximum growth   */
                     /*                          ratio possible.             */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_SUCCESS or EXIT_FAILURE)    */




                     /* ==================================================== */
                     /* === FEMe_NumLineHardPoints: Return the number of     */
                     /* === hardpoints on a given line.                      */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: FEM_INT # hard points.                   */
                     /* ==================================================== */
FEM_CPP_EXTERN FEM_INT FEMe_NumLineHardPoints (
   FEM_INT line_num, /* (IN) line number of inquire                          */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_SUCCESS or EXIT_FAILURE)    */




                     /* ==================================================== */
                     /* === FEMe_LineHardPoints: Get a list of the ids of    */
                     /* === the hardpoints on a given line.                  */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: FEM_INT # hard points in the list        */
                     /* ===         returned.                                */
                     /* ==================================================== */
FEM_CPP_EXTERN FEM_INT FEMe_LineHardPoints (
   FEM_INT line_num, /* (IN) line number of inquire                          */
   FEM_INT *a_hpt_list,/*(IN)list of hard points on line_num                 */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_SUCCESS or EXIT_FAILURE)    */





/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++   Keypoint Attribute Inquires ++++++++++++++++++++++++++++*/
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

                     /* ==================================================== */
                     /* === FEMe_LinesAttachedToKp: Get a list of line ids   */
                     /* === of lines attached to a kp.                       */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (FEM_INT) the number of lines attached to*/
                     /* ===               the keypoint.                      */
                     /* ==================================================== */
FEM_CPP_EXTERN FEM_INT FEMe_LinesAttachedToKp (
   FEM_INT kp_num,   /* (IN)  The keypoint id                                */
   FEM_INT *a_adjlines,/*(OUT)Array of line ids attached to kp               */
   FEM_INT *error ); /* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */




                     /* ==================================================== */
                     /* === FEMe_KpNodeId: Determine the id of the node at a */
                     /* === given keypoint.                                  */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (FEM_INT) Id of the node if meshed.  If  */
                     /* ===               not meshed 0 is returned.          */
                     /* ==================================================== */
FEM_CPP_EXTERN FEM_INT FEMe_KpNodeId (
   FEM_INT kp_num,   /* (IN)  The keypoint id                                */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */




                     /* ==================================================== */
                     /* === FEMe_MaxNumKps                                   */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (FEM_INT) the number of keypoints in the */
                     /* ===               model                              */
                     /* ==================================================== */
FEM_CPP_EXTERN FEM_INT FEMe_MaxNumKps ( 
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */




                     /* ==================================================== */
                     /* === FEMe_KpXYZ: return the coordinates of a keypoint */
                     /* ===                                                  */
                     /* === RETURN: 1 if keypoint is defined.                */
                     /* ===         0 if keypoint is undefined.              */
                     /* ===        -1 if keypoint is defined but unselected. */
                     /* ==================================================== */
FEM_CPP_EXTERN FEM_INT FEMe_KpXYZ (
   FEM_INT kp_num,   /* (IN)  The keypoint id                                */
   FEM_DOUBLE xyz[3],/* (OUT) Kp location (xyz)                              */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */


                     /* ==================================================== */
                     /* === FEMe_KpEsize: Return Esize of Keypoint           */
                     /* === Return: (FEM_DOUBLE) Return Esize value and error*/
                     /* ===               value of function */
                     /* ==================================================== */
FEM_CPP_EXTERN FEM_DOUBLE FEMe_KpEsize (
   FEM_INT kp_num,   /* (IN)  The keypoint id                                */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_SUCCESS or EXIT_FAILURE)    */






                     /* ==================================================== */
                     /* === FEMe_KpIsAreaHardPoint: Determine if a keypoint  */
                     /* === is a hard point on an area.                      */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (FEM_INT) If it is, then return the id of*/
                     /* ===               the area it is on.  If it is not a */
                     /* ===               hard point on an area, return 0.   */
                     /* ==================================================== */
FEM_CPP_EXTERN FEM_INT FEMe_KpIsAreaHardPoint (
   FEM_INT kp_num,   /* (IN)  The keypoint id                                */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_SUCCESS or EXIT_FAILURE)    */




                     /* ==================================================== */
                     /* === FEMe_KpIsLineHardPoint: Determine if a keypoint  */
                     /* === is a hard point on a line.                       */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (FEM_INT) If it is, then return the id of*/
                     /* ===               the line it is on.  If it is not a */
                     /* ===               hard point on a line, return 0.    */
                     /* ==================================================== */
FEM_CPP_EXTERN FEM_INT FEMe_KpIsLineHardPoint (
   FEM_INT kp_num,   /* (IN)  The keypoint id                                */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_SUCCESS or EXIT_FAILURE)    */



/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++   Element Shape Inquires +++++++++++++++++++++++++++++++++*/
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

                     /* ==================================================== */
                     /* === FEMe_TetJacobian: Calculate the jacobian ratio   */
                     /* === for a 10 noded tetrahedra.                       */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_TetJacobian (
   FEM_DOUBLE xyz[30],/*(IN)  Location of 10 nodes on tet                    */
   FEM_DOUBLE *jrat, /* (OUT) Jacobian Ratio of the tet                      */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_SUCCESS or EXIT_FAILURE)    */




                     /* ==================================================== */
                     /* === FEMe_HexWedgePyrJacobian: Calculate the jacobian */
                     /* === ratio for a pyraid, wedge or hex.                */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_HexWedgePyrJacobian (
   FEM_INT nodes[20],/* (IN)  Connectivity of nodes in xyz.  For wedges, and */
                     /*       pyramids, nodes must be in degenerate hex form */
                     /*       (i.e. nodes[2] must equal nodes[3], etc.       */
   FEM_DOUBLE *xyz,  /* (IN)  Nodes array                                    */
   FEM_DOUBLE *jrat, /* (OUT) Jacobian Ratio of the tet                      */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_SUCCESS or EXIT_FAILURE)    */


                     /* ==================================================== */
                     /* === FEMe_CheckForSplit: Given a quad check           */
                     /* === to see if this quad needs to be split into 2     */
                     /* === triangles because of poor shape.                 */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (FEM_INT) 0, if no splitting is required,*/
                     /* ===                   1, if splitting is required    */
                     /* ===                      for anything other than     */
                     /* ===                      warp,                       */
                     /* ===                  -1, if splitting is required    */
                     /* ===                      for warp.                   */
                     /* ==================================================== */
FEM_CPP_EXTERN FEM_INT FEMe_CheckForSplit (
   FEM_DOUBLE a_xyz[24],
                     /* (IN) xyz coordinates of nodes defining the quad      */
                     /*      corners and midnodes.  They must follow the     */
                     /*      order of the nodes in the below diagram.        */
                     /* ===                                                  */
                     /* ===                  6                               */
                     /* ===         3  *-----*-----* 2                       */
                     /* ===            |           |                         */
                     /* ===            |           |                         */
                     /* ===          7 *           * 5                       */
                     /* ===            |           |                         */
                     /* ===            |           |                         */
                     /* ===            *-----*-----*                         */
                     /* ===          0       4      1                        */
                     /* ===                                                  */
                     /*      The coordinates should be in the array as       */
                     /*      follows:                                        */
                     /*       a_xyz[0] = x of node 0.                        */
                     /*       a_xyz[1] = y of node 0.                        */
                     /*       a_xyz[2] = z of node 0.                        */
                     /*       a_xyz[3] = x of node 1.                        */
                     /*       a_xyz[4] = y of node 1.                        */
                     /*       a_xyz[5] = z of node 1.                        */
                     /*       etc...                                         */
   FEM_INT anum,     /* (IN) area number that the quad is on. If this quad   */
                     /*      will not be a quad shell element, but rather    */
                     /*      will be on the boundary of a volume meshed with */
                     /*      hexes, then this will be passed in as the       */
                     /*      negative of areanumber.                         */
   FEM_DOUBLE uguess,/* (IN) u guess.  This can be used as a guess for       */
                     /*      projections.  To determine which diagonal to    */
                     /*      split for warp, it is suggested that you        */
                     /*      project the midpoint of both diagonals to the   */
                     /*      area and choose the diagonal that is closest to */
                     /*      the surface.                                    */
   FEM_DOUBLE vguess,/* (IN) v guess.  See comment for uguess.               */
   FEM_INT *splitnode,
                     /* (OUT) either 0 or 1.                                 */
                     /*       If 0, then the quad should be along diagonal   */
                     /*       between nodes 0 and 2.                         */
                     /*       If 1, then the quad should be along diagonal   */
                     /*       between nodes 1 and 3.                         */
                     /*       This only needs to be returned if the face     */
                     /*       needs to be split because of warp              */
                     /*       (i.e. return value == -1).                     */
                     /*       If the return value == 1, obj_splitnode is     */
                     /*       not used so do not waste time computing it.    */
                     /*       If the quad is not being split because of warp */
                     /*       The component will determine which diaganoal   */
                     /*       the quad should be split on by maximizing the  */
                     /*       minimum angle of the quad                      */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_SUCCESS or EXIT_FAILURE)    */


                     /* ==================================================== */
                     /* === FEMe_CheckForSplit: Given a quad check           */
                     /* === to see if this quad needs to be split into 2     */
                     /* === triangles because of poor shape.                 */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (FEM_INT) 0, if no splitting is required,*/
                     /* ===                   1, if splitting is required    */
                     /* ===                      for anything other than     */
                     /* ===                      warp,                       */
                     /* ===                  -1, if splitting is required    */
                     /* ===                      for warp.                   */
                     /* ==================================================== */
FEM_CPP_EXTERN FEM_INT FEMe_CheckForSplit0 (
   FEM_DOUBLE a_xyz[24],
                     /* (IN) xyz coordinates of nodes defining the quad      */
                     /*      corners and midnodes.  They must follow the     */
                     /*      order of the nodes in the below diagram.        */
                     /* ===                                                  */
                     /* ===                  6                               */
                     /* ===         3  *-----*-----* 2                       */
                     /* ===            |           |                         */
                     /* ===            |           |                         */
                     /* ===          7 *           * 5                       */
                     /* ===            |           |                         */
                     /* ===            |           |                         */
                     /* ===            *-----*-----*                         */
                     /* ===          0       4      1                        */
                     /* ===                                                  */
                     /*      The coordinates should be in the array as       */
                     /*      follows:                                        */
                     /*       a_xyz[0] = x of node 0.                        */
                     /*       a_xyz[1] = y of node 0.                        */
                     /*       a_xyz[2] = z of node 0.                        */
                     /*       a_xyz[3] = x of node 1.                        */
                     /*       a_xyz[4] = y of node 1.                        */
                     /*       a_xyz[5] = z of node 1.                        */
                     /*       etc...                                         */
   FEM_INT anum,     /* (IN) area number that the quad is on. If this quad   */
                     /*      will not be a quad shell element, but rather    */
                     /*      will be on the boundary of a volume meshed with */
                     /*      hexes, then this will be passed in as the       */
                     /*      negative of areanumber.                         */
   FEM_DOUBLE a_sin[4],/* (IN) u guess.  This can be used as a guess for       */
                     /*      projections.  To determine which diagonal to    */
                     /*      split for warp, it is suggested that you        */
                     /*      project the midpoint of both diagonals to the   */
                     /*      area and choose the diagonal that is closest to */
                     /*      the surface.                                    */
   FEM_DOUBLE a_tin[4],/* (IN) v guess.  See comment for uguess.               */
   FEM_INT *splitnode,
                     /* (OUT) either 0 or 1.                                 */
                     /*       If 0, then the quad should be along diagonal   */
                     /*       between nodes 0 and 2.                         */
                     /*       If 1, then the quad should be along diagonal   */
                     /*       between nodes 1 and 3.                         */
                     /*       This only needs to be returned if the face     */
                     /*       needs to be split because of warp              */
                     /*       (i.e. return value == -1).                     */
                     /*       If the return value == 1, obj_splitnode is     */
                     /*       not used so do not waste time computing it.    */
                     /*       If the quad is not being split because of warp */
                     /*       The component will determine which diaganoal   */
                     /*       the quad should be split on by maximizing the  */
                     /*       minimum angle of the quad                      */
   FEM_INT *error  );/* (OUT) Error flag.  (EXIT_SUCCESS or EXIT_FAILURE)    */



/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++   Debugging routines     +++++++++++++++++++++++++++++++++*/
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

                     /* ==================================================== */
                     /* === FEMe_DrawFace: Draw a 2D element or the face of  */
                     /* === a 3D elements.                                   */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_DrawFace (
   FEM_INT face_id,  /* (IN)  Id for labeling                                */
   FEM_INT ncorners, /* (IN)  Number of corners on the face (3 or 4)         */
   FEM_DOUBLE *xyz,  /* (IN)  Location of nodes (length = 3*num_corners)     */
   FEM_INT *iel,     /* (IN)  Connectivity of nodes in xyz array             */
   FEM_INT color  ); /* (IN)  Color to draw face in                          */




                     /* ==================================================== */
                     /* === FEMe_TrackBegin: Called whenever a major         */
                     /* === routine is invoked for debugging purposes.       */
                     /* === "str" points to a unique string for each major   */
                     /* === routine that could be called.                    */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_TrackBegin(
   FEM_CHAR *str );  /* (IN) Name of Track being entered.                    */




                     /* ==================================================== */
                     /* === FEMe_TrackPoint: Called whenever a minor         */
                     /* === routine is invoked for debugging purposes.       */
                     /* === "str" points to a unique string for each minor   */
                     /* === routine that could be called.                    */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_TrackPoint (
   FEM_CHAR *str  ); /* (IN) Name of Track being entered.                    */




                     /* ==================================================== */
                     /* === FEMe_TrackEnd: Called whenever a major           */
                     /* === routine is left for debugging purposes.          */
                     /* === "str" points to a unique string for each major   */
                     /* === routine that could be called.  "str" is the same */
                     /* === string that was sent to FEMe_TrackBegin when the */
                     /* === major function was entered.                      */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_TrackEnd (
   FEM_CHAR *str  ); /* (IN) Name of Track being exited.                     */



/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++   Output routines     ++++++++++++++++++++++++++++++++++++*/
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

                     /* ==================================================== */
                     /* === FEMe_Error: Called whenever an                   */
                     /* === error/warning/note is encountered.  See          */
                     /* === FEM_errors.h for descriptions of possible        */
                     /* === values for "subprocessid" and "errorid" and      */
                     /* === their meaning.                                   */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_Error (
   FEM_INT subprocessid,
                     /* (IN)  Id of subprocess where error was encountered   */
   FEM_INT errorid,  /* (IN)  Id of error in subprocess that was encountered */
   FEM_INT severity, /* (IN)  Severify of Error:                             */
                     /*           4 : FATAL, program aborted.                */
                     /*           3 : ERROR, subprocess is aborted.          */
                     /*           2 : WARNING, subprocess is not aborted.    */
                     /*           1 : NOTE, information only.                */
   FEM_DOUBLE *a_params,
                     /* (IN)  Parameters relating to error message (i.e. line*/
                     /*       or area numbers where error ocurred, etc.)     */
   FEM_CHAR *file,   /* (IN)  Filename where error occured for debugging     */
                     /*       purposes only.                                 */
   FEM_INT line  );  /* (IN)  Line in file where error occured for debugging */
                     /*       purposes only.                                 */




                     /* ==================================================== */
                     /* === FEMe_String: Called with a message/error/note in */
                     /* === the form of a char string.                       */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_String (
   FEM_CHAR string[256],/*(IN)The message as a char string                   */
   FEM_INT severity);/* (IN)  Severify of Error:                             */
                     /*           4 : FATAL, program aborted.                */
                     /*           3 : ERROR, subprocess is aborted.          */
                     /*           2 : WARNING, subprocess is not aborted.    */
                     /*           1 : NOTE, information only.                */




                     /* ==================================================== */
                     /* === FEMe_PrintToOutputUnit: Print a character string */
                     /* === to standard output unit. This would usually be   */
                     /* === used to write a string from C to Fortran unit so */
                     /* === C and Fortran output go to same buffer. In C,    */
                     /* === printf would be replaced by sprintf to a string  */
                     /* === before calling this routine.                     */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_PrintToOutputUnit (
   FEM_CHAR *str  ); /* (IN)  String to be printed out                       */




                     /* ==================================================== */
                     /* === FEMe_VerifyCommand: Verify a command, e.g. by    */
                     /* === bringing up a dialog box.                        */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_VerifyCommand (
   FEM_CHAR *str,    /* (IN)  String to be printed out                       */
   FEM_INT *go   );  /* (IN)  0 or +n: write message that command aborted    */
                     /*       -n: do not write message that command aborted  */
                     /* (OUT) 1: response was yes or ok                      */
                     /*       0: response was a no                           */





                     /* ==================================================== */
                     /* === FEMe_VerifyAllCommand: Verify a command, e.g. by */
                     /* === bringing up a dialog box.                        */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_VerifyAllCommand (
   FEM_CHAR *str,    /* (IN)  String to be printed out                       */
   FEM_INT *go   );  /* (IN)  0 or +n: write message that command aborted    */
                     /*       -n: do not write message that command aborted  */
                     /* (OUT) 1: response was yes                            */
                     /*       0: response was no                             */
                     /*       2: response was ok to all                      */





                     /* ==================================================== */
                     /* === FEMe_Interactive: See if we are running          */
                     /* === interactively or in batch mode.  This is called  */
                     /* === before calls to FEMe_VerifyCommand.  If we are   */
                     /* === running in batch mode then there will not be a   */
                     /* === user to answer the question asked by             */
                     /* === FEMe_VerifyCommand.  If FEMe_Interactive returns */
                     /* === !0, then FEMe_VerifyCommand gets called.  If     */
                     /* === FEMe_Interactive return 0, then FEMe_Error or    */
                     /* === FEMe_String gets called instead and we assume a  */
                     /* === positive response.                               */
                     /* === Return: FEM_INT: 0 if running in batch mode,     */
                     /* ===             !0 if running interactively          */
                     /* ==================================================== */
FEM_CPP_EXTERN FEM_INT FEMe_Interactive( void );




/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*+++++++++++++++   Memory Management +++++++++++++++++++++++++++++++++++++++*/
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

                     /* ==================================================== */
                     /* === FEMe_Malloc: allocate and return a chunk of      */
                     /* === memory the size of "size" in bytes.              */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (FEM_CHAR *) pointer to the memory or    */
                     /* ===                  0x0 if no memory is available.  */
                     /* ==================================================== */
FEM_CPP_EXTERN FEM_CHAR *FEMe_Malloc (
   FEM_INT size,     /* (IN)  The size in bytes of memory needed.            */
   FEM_CHAR *thefile,/* (IN)  The file where memory is requested - for       */
                     /*       debugging purposes only                        */
   FEM_INT theline); /* (IN)  The line number in thefile where memory is     */
                     /*       requested - for debugging purposes only.       */
                     /*                                                      */
                     /*       NOTE:  "thefile" and "theline" are used to     */
                     /*              debug memory leaks.  The memory manager */
                     /*              can keep track of the file and line of  */
                     /*              each memory allocation.  After          */
                     /*              execution, the memory manager can       */
                     /*              report which memory allocations were    */
                     /*              never freed.                            */
                     /* ==================================================== */




                     /* ==================================================== */
                     /* === FEMe_Free: Free up a chunk of memory that was    */
                     /* === allocated with FEMe_Malloc.                      */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_Free (
   FEM_CHAR *ptr,    /* (IN)  Pointer to the memory to be freed              */
   FEM_CHAR *thefile,/* (IN)  The file where memory is freed - for           */
                     /*       debugging purposes only                        */
   FEM_INT theline); /* (IN)  The line number in thefile where memory is     */
                     /*       freed - for debugging purposes only.           */
                     /* ==================================================== */


/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++   BCs and Constraints   ++++++++++++++++++++++++++++++++++*/
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

                     /* ==================================================== */
                     /* === determine if the list of nodes can be refined    */
                     /* === (nodes with loads and constraints applied        */
                     /* === directly at the node cannot be refined.  Loads   */
                     /* === and constraints applied at the solid model can)  */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_RefChkNode (
   FEM_INT numNodes,  /* (IN)  number of nodes to check                      */
   FEM_INT *nodeList, /* (IN)  list of nodes to check					     */
   FEM_INT noGeo,     /* (IN)  1 = geometry not associated with any node in  */
	                  /*          list (nodes/elems are detached)            */
	                  /*       0 = associated with geometry                  */
   FEM_INT erLevel,   /* (IN)  3 = display error message                     */
                      /*       2 = display warning message                   */
                      /*       1 = display note                              */
					  /*          (curently only used for morph/remesh)      */
   FEM_INT *ok);      /* (OUT) 0 = did not pass (at least 1 constraint or	 */
                      /*           force is applied to a node)				 */
                      /*       1 = passed test - ok to refine				 */

                     /* ==================================================== */
                     /* === determine if the list of nodes can be refined    */
                     /* === (nodes with body forces applied					 */
                     /* === directly at the node cannot be refined.  Body    */
                     /* === forces applied at the solid model can)			 */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_RefChkBfNode (
   FEM_INT numNodes,  /* (IN)  number of nodes to check                      */
   FEM_INT *nodeList, /* (IN)  list of nodes to check					     */
   FEM_INT noGeo,     /* (IN)  1 = geometry not associated with any node in  */
	                  /*          list (nodes/elems are detached)            */
	                  /*       0 = associated with geometry                  */
   FEM_INT erLevel,   /* (IN)  3 = display error message                     */
                      /*       2 = display warning message                   */
                      /*       1 = display note                              */
					  /*          (curently only used for morph/remesh)      */
   FEM_INT *ok);      /* (OUT) 0 = did not pass (at least 1 constraint or	 */
                      /*           force is applied to a node)				 */
                      /*       1 = passed test - ok to refine				 */


                     /* ==================================================== */
                     /* === determine if the list of elems can be refined	 */
                     /* === (elems with surface loads applied				 */
                     /* === directly at the elem cannot be refined.  Loads   */
                     /* === at the solid model can)							 */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_RefChkElem (
   FEM_INT numElems,  /* (IN)  number of elems to check                      */
   FEM_INT *elemList, /* (IN)  list of elems to check					     */
   FEM_INT noGeo,     /* (IN)  1 = geometry not associated with any elem in  */
	                  /*          list (nodes/elems are detached)            */
	                  /*       0 = associated with geometry                  */
 
   FEM_INT *ok);      /* (OUT) 0 = did not pass (at least 1 constraint or	 */
                      /*           force is applied to an elem)				 */
                      /*       1 = passed test - ok to refine				 */

                     /* ==================================================== */
                     /* === determine if the list of elems can be refined    */
                     /* === (elems with body forces applied					 */
                     /* === directly at the elem cannot be refined.  Body    */
                     /* === forces applied at the solid model can)			 */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_RefChkBfElem (
   FEM_INT numElems,  /* (IN)  number of elems to check                      */
   FEM_INT *elemList, /* (IN)  list of elems to check					     */
   FEM_INT noGeo,     /* (IN)  1 = geometry not associated with any elem in  */
	                  /*          list (nodes/elems are detached)            */
	                  /*       0 = associated with geometry                  */
   FEM_INT *ok);      /* (OUT) 0 = did not pass (at least 1 constraint or	 */
                      /*           force is applied to an elem)				 */
                      /*       1 = passed test - ok to refine				 */


/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++   Misc. Inquires +++++++++++++++++++++++++++++++++++++++++*/
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

                     /* ==================================================== */
                     /* === FEMe_SetParameters: Set the various user         */
                     /* === specified parameters used during meshing,        */
                     /* === smoothing, etc.  This routine gets called        */
                     /* === from 3 different places:                         */
                     /* ===                                                  */
                     /* === 1.  From FEM_Init() in the creation of the Ansys */
                     /* ===     Meshing Database.  geo_type == 0, and only   */
                     /* ===     general stuff like debugging, quadsplitting, */
                     /* ===     etc. make sense to set.                      */
                     /* === 2.  From FEM_MeshAreas() directly before the     */
                     /* ===     Ansys Meshing Toolkit meshes an area.        */
                     /* ===     geo_type == 3, and area meshing parameters   */
                     /* ===     specific to the area "geo_id" can be set.    */
                     /* ===     FEMe_SetParameters() will be called at least */
                     /* ===     once for each area being meshed with a call  */
                     /* ===     to FEM_MeshAreas().  In some cases,          */
                     /* ===     FEMe_SetParameters may get called more than  */
                     /* ===     once for each area by different submodules   */
                     /* ===     within the mesher to ensure that the         */
                     /* ===     parameters are up to date.                   */
                     /* === 3.  From FEM_TetMesh() direclty before the Ansys */
                     /* ===     Meshing Toolkit meshes a volume.             */
                     /* ===     geo_type == 4, and the tet meshing           */
                     /* ===     parameters specific to volume "geo_id" can   */
                     /* ===     be set.  FEMe_SetParameters will be called   */
                     /* ===     at least once for each volume being meshed   */
                     /* ===     with a call to FEM_TetMesh().                */
                     /* ===                                                  */
                     /* === Any of the parameters specified in FEM_globals.h */
                     /* === can be set.  This routine can be left empty.  If */
                     /* === so, a set of default values for all parameters   */
                     /* === will be used.                                    */
                     /* ===                                                  */
                     /* === Return: (void)                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN void FEMe_SetParameters(
   FEM_GEOTYPE geo_type, /* (IN)  The type of entity that is about to be meshed. */
                     /*       If geo_type == FEM_NO_GEO, nothing is about to */
                     /*       be meshed.  The Ansys Meshing Toolkit is being */
                     /*       set up generally and no mesher has been        */
                     /*       specically called yet.                         */
   FEM_INT geo_id ); /* (IN)  The id of the entity that is about to be       */
                     /*       meshed.  Ignored if geo_type == 0.             */





                     /* ==================================================== */
                     /* === FEMe_AreaElemNodes:  Given the id of an area     */
                     /* === element return the ids of the nodes on it.       */
                     /* ===                                                  */
                     /* === Node ids returned in a_nodes are counterclockwise*/
                     /* === around element.  3 possible element are:         */
                     /* ===                                                  */
                     /* ==================================================== */
                     /* ===                                                  */
                     /* ===  Triangles (non-degenerate quad)                 */
                     /* ===            (return value num_corners == 3)       */
                     /* ===                                                  */
                     /* ===                   * a_nodes[0]                   */
                     /* ===                  / \                             */
                     /* ===                 /   \                            */
                     /* ===     a_nodes[3] *     * a_nodes[5]                */
                     /* ===               /       \                          */
                     /* ===              /         \                         */
                     /* ===  a_nodes[1] *-----*-----* a_nodes[2]             */
                     /* ===               a_nodes[4]                         */
                     /* ===                                                  */
                     /* ==================================================== */
                     /* ===                                                  */
                     /* ===  Triangles (degenerate quad)                     */
                     /* ===            (return value num_corners == 4)       */
                     /* ===                                                  */
                     /* ===                  * a_nodes[0]                    */
                     /* ===                 / \                              */
                     /* ===                /   \                             */
                     /* ===    a_nodes[4] *     * a_nodes[7]                 */
                     /* ===              /       \                           */
                     /* ===             /         \                          */
                     /* === a_nodes[1] *-----*-----* a_nodes[2, 3, and 6]    */
                     /* ===              a_nodes[5]                          */
                     /* ===                                                  */
                     /* ==================================================== */
                     /* ===                                                  */
                     /* ===  Quadrilaterals (return value num_corners == 4)  */
                     /* ===                                                  */
                     /* ===              a_nodes[7]                          */
                     /* === a_nodes[0] *-----*-----* a_nodes[3]              */
                     /* ===            |           |                         */
                     /* ===            |           |                         */
                     /* === a_nodes[4] *           * a_nodes[6]              */
                     /* ===            |           |                         */
                     /* ===            |           |                         */
                     /* === a_nodes[1] *-----*-----* a_nodes[2]              */
                     /* ===              a_nodes[5]                          */
                     /* ===                                                  */
                     /* ==================================================== */
                     /* ===                                                  */
                     /* === Return: (FEM_INT) num_corners (the number of     */
                     /* ===               corners on the element, see above  */
                     /* ===               for possible element shapes and    */
                     /* ===               cooresponding return values.)      */
                     /* ==================================================== */
FEM_CPP_EXTERN FEM_INT FEMe_AreaElemNodes (
   FEM_INT elem_id,  /* (IN)  The id of element we want nodes for            */
   FEM_INT nodes[8], /* (OUT) Array of ids of nodes on elem_number,          */
                     /*       empty midnode locations must be filled with 0  */
   FEM_INT *nenodes, /* (OUT) Number of nodes on the element. This is either */
                     /*       3, 4, 6, or 8.  Dropped midnodes are counted.  */
   FEM_INT *selected,/* (OUT) TRUE if the element is selected.               */
   FEM_INT *error ); /* (OUT) Error flag.  (EXIT_FAILURE or EXIT_SUCCESS)    */





                     /* ==================================================== */
                     /* === FEMe_VolumeElemNodes:  Given the id of a volume  */
                     /* === element return the id of the node on it.         */
                     /* ===                                                  */
                     /* === 4 possible elements are:                         */
                     /* ===                                                  */
                     /* ==================================================== */
                     /* ===                                                  */
                     /* === Tetrahedra: (return value of 4 or 10)            */
                     /* ===                                                  */
                     /* ===             a_nodes[3]                           */
                     /* ===                  *                               */
                     /* ===                 /|\                              */
                     /* ===                / | \                             */
                     /* ===    a_nodes[7] *  |  * a_nodes[9]                 */
                     /* ===              /   |   \                           */
                     /* ===             /    *8   \                          */
                     /* === a_nodes[0] *- - *|- - -* a_nodes[2]              */
                     /* ===             \   6|    /                          */
                     /* ===              \   |   /                           */
                     /* ===    a_nodes[4] *  |  * a_nodes[5]                 */
                     /* ===                \ | /                             */
                     /* ===                 \|/                              */
                     /* ===                  *                               */
                     /* ===              a_nodes[1]                          */
                     /* ===                                                  */
                     /* ==================================================== */
                     /* ===                                                  */
                     /* === Wedges: (return value of 6 or 15)                */
                     /* ===                                                  */
                     /* ===               a_nodes[11]                        */
                     /* === a_nodes[3]  *-----*-----* a_nodes[5]             */
                     /* ===             |\         /|                        */
                     /* ===             | \       / |                        */
                     /* ===             |  *9  10*  |                        */
                     /* === a_nodes[12] *   \   /   * a_nodes[14]            */
                     /* ===             |    \ /    |                        */
                     /* ===             |     *4    |                        */
                     /* ===             |     |     |                        */
                     /* === a_nodes[0]  *- - -|*8- -* a_nodes[2]             */
                     /* ===              \    |    /                         */
                     /* ===               \ 13*   /                          */
                     /* ===     a_nodes[6] *  |  * a_nodes[7]                */
                     /* ===                 \ | /                            */
                     /* ===                  \|/                             */
                     /* ===                   *                              */
                     /* ===                    a_nodes[1]                    */
                     /* ===                                                  */
                     /* ==================================================== */
                     /* ===                                                  */
                     /* === Pyramids: (return value of 5 or 13)              */
                     /* ===                                                  */
                     /* ===               a_nodes[4]                         */
                     /* ===                   *                              */
                     /* ===                  /|\                             */
                     /* ===                 // \\                            */
                     /* ===                / | | \                           */
                     /* ===   a_nodes[12] * /   \ * a_nodes[11]              */
                     /* ===              /  |   |  \                         */
                     /* ===             /  /  7  \  \                        */
                     /* === a_nodes[3] *- -|- * -|- -* a_nodes[2]            */
                     /* ===            |  *9    10*  |                       */
                     /* ===            |  |       |  |                       */
                     /* === a_nodes[8] * /         \ * a_nodes[6]            */
                     /* ===            | |         | |                       */
                     /* ===            |/           \|                       */
                     /* === a_nodes[0] *------*------* a_nodes[1]            */
                     /* ===               a_nodes[5]                         */
                     /* ===                                                  */
                     /* ==================================================== */
                     /* ===                                                  */
                     /* === Hexahedra: (return value of 8 or 20)             */
                     /* ===                                                  */
                     /* ===                    a_nodes[14]                   */
                     /* ===        a_nodes[7] *-----*-----* a_nodes[6]       */
                     /* ===                  /|          /|                  */
                     /* ===                 /           / |                  */
                     /* ===    a_nodes[15] *  |      13*  |                  */
                     /* ===               /   *19     /   * a_nodes[18]      */
                     /* ===              /  12|      /    |                  */
                     /* ===  a_nodes[4] *-----*-----*5    |                  */
                     /* ===             |     |     |     |                  */
                     /* ===             |    3*- - *|- - -* a_nodes[2]       */
                     /* ===             |    /    10|    /                   */
                     /* === a_nodes[16] *           *17 /                    */
                     /* ===             |  *11      |  * a_nodes[9]          */
                     /* ===             |           | /                      */
                     /* ===             |/          |/                       */
                     /* === a_nodes[0]  *-----*-----* a_nodes[1]             */
                     /* ===              a_nodes[8]                          */
                     /* ===                                                  */
                     /* ==================================================== */
                     /* ===                                                  */
                     /* ===                                                  */
                     /* === Return: (FEM_INT) num_nodes (the number of nodes */
                     /* ===               on the element including midnodes. */
                     /* ===               Even if some midnodes are dropped, */
                     /* ===               they are still counted, just put 0 */
                     /* ===               in a_nodes array.)                 */
                     /* ==================================================== */
FEM_CPP_EXTERN FEM_INT FEMe_VolumeElemNodes (
   FEM_INT elem_id,  /* (IN)  The id of element we want nodes for            */
   FEM_INT nodes[20],/* (OUT) Array of ids of nodes on elem_number,          */
                     /*       empty midnode locations must be filled with 0  */
   FEM_INT *selected,/* (OUT) TRUE if the element is selected.               */
   FEM_INT *error ); /* (OUT) Error flag.  (EXIT_SUCCESS or EXIT_FAILURE)    */




                     /* ==================================================== */
                     /* ===  FEMe_RecoverAreaMesh                            */
                     /* ===                                                  */
                     /* === Return:recover mesh from foreign database        */
                     /* === if you dont have the CMDB source then return EXIT_FAILURE*/
                     /* ==================================================== */

FEM_CPP_EXTERN void FEMe_RecoverAreaMesh( 
    FEM_INT area , /* return EXIT_SUCCES or EXIT_FAILURE */
    FEM_INT *error );

                     /* ==================================================== */
                     /* ===  FEMe_faceShapeMetric                            */
                     /* ===                                                  */
                     /* ===  returns a severity level of the face's shape    */
                     /* ===  0 = ok                                          */
                     /* ===  1 = warning                                    */
                     /* ===  2 = error                                      */
                     /* ===  3 = inverted                                   */
                     /* ==================================================== */
FEM_CPP_EXTERN FEM_INT FEMe_faceShapeMetric(
   FEM_INT numNode,
   FEM_DOUBLE a_xyz[24],
   FEM_INT *error ) ;

                     /* ==================================================== */
                     /* ===  FEMe_GeometryType                            */
                     /* ===                                                  */
                     /* ===  returns a geometry type based on the following */
                     /* ===  0 based enumeration
                            enum ANS_GeomTypes
                            {
                                kUnTyped,
                                kCalCurve,
                                kStraightLine,
                                kCircle,
                                kArc,
                                kCalSurface,
                                kPlane,
                                kCylinder,
                                kCone,
                                kSphere,
                                kTorus,
	                            kEliCylinder,
                                kNurbsSurface,
                                kNurbsCurve,
                                kEllipse,
                                kEliCone,
                                kFacetedSurface,
                                kFacetedCurve
                            }
                       ==================================================== */
FEM_CPP_EXTERN FEM_INT FEMe_GeometryType( 
    FEM_INT id, 
    FEM_INT dim, 
    FEM_INT *error );


FEM_CPP_EXTERN FEM_INT FEMe_getInfluenceSpheres (
    FEM_INT     iAreaId,                                               
    void        *psSpheres,
    FEM_BOOLEAN *pbExist);

FEM_CPP_EXTERN FEM_INT FEMe_getNumOfInfluenceSpheres (
    FEM_INT iAreaId,
    FEM_INT *piNumOfSpheres );

#ifndef STANDALONE_DELAUNAY

FEM_CPP_EXTERN FEM_INT FEMe_NumberOfRadialDivisionsOnArea (
    FEM_INT iAreaId,
    FEM_INT *piNumberOfRadialDivisionsOnArea );

FEM_CPP_EXTERN void FEMe_hasAreaMapMeshControl( 
   FEM_INT area_id,
	FEM_INT *piHasMapMeshControl,     /* 0 = no control, 1= AllQuad, 2=TriBestSplit,3=TriSplitAtINode,4=TriSplitAtJNode*/
   FEM_INT *error );

FEM_CPP_EXTERN void FEMe_GetProjectBackToUnderlyingGeometry( 
   FEM_INT area_id,
   FEM_BOOLEAN *pbProjectBack,    
   FEM_INT *error );

FEM_CPP_EXTERN void FEMe_SetProjectBackToUnderlyingGeometry( 
   FEM_INT area_id,
   FEM_BOOLEAN bProjectBack,  
   FEM_INT *error );


FEM_CPP_EXTERN void FEMe_calLengthOfIsolineBetweenTwoParms( 
   FEM_INT area_id,
   FEM_INT direction,
   FEM_DOUBLE parm1,
   FEM_DOUBLE parm2,
   FEM_DOUBLE parmconst,
   FEM_DOUBLE *length,   
   FEM_INT *error );

FEM_CPP_EXTERN void FEMe_getExternalSweepingParametersForVol( 
   FEM_INT vol_id,
   FEM_INT *iNdiv,
   FEM_DOUBLE *dEsize,
   FEM_DOUBLE *dBias,
   FEM_INT    *iSrcId,
   FEM_INT    *iTrgId,
   FEM_INT *error );

FEM_CPP_EXTERN void FEMe_isPointOnAreatDegen(
	FEM_INT			area_id,		/* (IN) id of area */
	FEM_DOUBLE		s,				/* (IN) s parametric location */
	FEM_DOUBLE		t,				/* (IN) t parametric location */
								/* Note: s and t not used if surface is
								analytical - use xyzin instead */
	FEM_DOUBLE		xyz[3],			/* (IN) world coord on surface */
								/* Note: used only if surface is analytical, 
								s and t ignored */
	FEM_BOOLEAN *atDegeneracy,	/* (OUT) at degen point */	
    FEM_INT      *error );

FEM_CPP_EXTERN void FEMe_areaHasDegeneracies(
	FEM_INT			area_id,		/* (IN) id of area */
	FEM_BOOLEAN     *hasDegeneracy, /* (OUT) at degen point */	
    FEM_INT         *error);

FEM_CPP_EXTERN void FEMe_getShapeCheckGroup( FEM_INT *iGroup, INT *error );

FEM_CPP_EXTERN void FEMe_setSuperAccurate(
    FEM_INT     iAreaId,  /* (IN) area id */ 
    FEM_BOOLEAN bValue ); /* (IN)  TRUE for supper accuracy  */
FEM_CPP_EXTERN INT FEMe_sphCrtNodOnSurf( DOUBLE *pt1, DOUBLE *pt2, INT num_nodes, INT anum, DOUBLE *pts );


FEM_CPP_EXTERN DOUBLE FEMe_CalculateClosedFacetedSurfacePseudoSeamLength( INT anum, INT *error );
#endif

#endif

