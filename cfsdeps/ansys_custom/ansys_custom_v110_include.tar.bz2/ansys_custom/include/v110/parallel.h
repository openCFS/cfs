/* sid 60.1 copy of parallel.h last changed by jtm on 2006/05/15 19:44:37 */
/*HFILE parallel.h                                      fjb,system
------------------------------------------------------------------------
------- Notice - This file contains ANSYS Confidential information --------
------------------------------------------------------------------------
*/
/* 
 * *** copyright(c) 2006 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */


/*------------------------------ Description ---------------------------
\Author:        F. Bogden
\Title:         Parallel Primitives Library header
\Desc:          This file is the header file for all of the cc interface 
		routines to create and manage threads.  
\History:       94/11/30 - fjb: Initial creation

\Function(s)
 -Primary:      parallel primitives header
 -Secondary:    none
 -External:     none
 -Internal:     none
 -Static:       none
----------------------------------------------------------------------*/
#ifndef PARALLEL_H
#  define PARALLEL_H

/*------------------ Header files and declarations -------------------*/
/* BELOW DEFINE ADDED TO FORCE STRICT ANSI C COMPILES */
# define ansANSI
#include "computer.h"
#include "globals.h"
#include "syssys.h"

#include <thread.h>

/*------------------------------ Dependencies ------------------------*/

/*----------------------- Static Macro Definitions -------------------*/

/*
   ppDebug = 0, no debug, create threads.
   ppDebug = 1, yes debug, create threads.
   ppDebug = 2, yes debug, direct calls -no- threads.

   OPTION : compile with -DDEBUG to get debugging messages -or-
            compile with -DNO_DEBUG to get -no- debugging messages ever.
*/
# define debug 0
#ifdef DEBUG
# define debug 1
#endif
#ifdef NO_DEBUG
# define debug 0
#endif

/***********************************************************************
                  * * *  N O T I C E  * * *
The definition of MAX_LOCKS MUST be the same size as the PPNUMLOCK 
parameter statement in FORTRAN common PPCOM.  Also, the definition of 
MAXARGS is the maximum number of FORTRAN arguments permitted by this 
version.  This MUST be consistent with the FORTRAN ppfrkx calls.
                  * * *  N O T I C E  * * *
***********************************************************************/
#define MAX_LOCKS 128
#define MAXARGS 15
#define MAXARGS1 (MAXARGS + 1)

/* define the MAX_CPUS permitted for this version */
#define MAX_CPUS 32

/*--------------------- Static TypeDefs/Structures -------------------*/

/*
** Barrier data type
*/
typedef struct {
	mutex_t	lk;
	cond_t	wait_cv;	/* cv for waiters at barrier	*/
	cond_t	leave_cv;	/* cv for wake-up thread	*/
	cond_t	next_cv;	/* cv for next iteration	*/
	int	runners;	/* number of running threads	*/
	int	waiters;	/* number of waiting threads	*/
	int	maxcnt;		/* maximum number of runners	*/
	int	next;		/* 1 - OK for next iteration	*/
} barrier_t;

/* App may want to dynamically allocate as many of these as it needs, for
   now we just have one the app.
   These barriers once initialized are labeled, e.g., cannot be  reinitialized.
   If more than one is needed, need to allocate more.
*/

/*----------------------- Variable Definitions -----------------------*/
/* global variables */
INT ppDebug;
INT ppDebug_lock;



/*------------------------- Internal Functions -----------------------*/

VOID cwfrk( VOID *[] );
VOID (*subr1) ();
VOID (*subr2) (VOID *);
VOID (*subr3) (VOID *,VOID *);
VOID (*subr4) (VOID *,VOID *,VOID *);
VOID (*subr5) (VOID *,VOID *,VOID *,VOID *);
VOID (*subr6) (VOID *,VOID *,VOID *,VOID *,VOID *);
VOID (*subr7) (VOID *,VOID *,VOID *,VOID *,VOID *,VOID *);
VOID (*subr8) (VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *);
VOID (*subr9) (VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *);
VOID (*subr10) (VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,
                VOID *);
VOID (*subr11) (VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,
		VOID *,VOID *);
VOID (*subr12) (VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,
		VOID *,VOID *,VOID *);
VOID (*subr13) (VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,
		VOID *,VOID *,VOID *,VOID *);
VOID (*subr14) (VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,
		VOID *,VOID *,VOID *,VOID *,VOID *);
VOID (*subr15) (VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,
		VOID *,VOID *,VOID *,VOID *,VOID *,VOID *);
VOID (*subr16) (VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,
		VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *);
VOID thr_init( VOID * );
VOID thread_create( VOID *[],int *tid );

VOID 	ppbarrier (barrier_t *);
int	barrier_init( barrier_t *bp, int count, int type, void *arg );
int	barrier_wait( barrier_t *bp );
int	barrier_destroy( barrier_t *bp );
void    start_threads();
void    wait_for_start();
extern INT  get_proc_id_( VOID );

/*------------------------- Exported Functions -----------------------*/
/* used either from fortran and/or cc */
extern VOID ppfrk_ ( VOID *(*)() );
extern VOID ppfrk1_( VOID *(*)(VOID *), VOID *[] );
extern VOID ppfrk2_( VOID *(*)(VOID *,VOID *), VOID *[], VOID *[] );
extern VOID ppfrk3_( VOID *(*)(VOID *,VOID *,VOID *), VOID *[], VOID *[], 
		     VOID *[] );
extern VOID ppfrk4_( VOID *(*)(VOID *,VOID *,VOID *,VOID *), VOID *[], 
                     VOID *[], VOID *[], VOID *[] );
extern VOID ppfrk5_( VOID *(*)(VOID *,VOID *,VOID *,VOID *,VOID *), VOID *[], 
		     VOID *[], VOID *[], VOID *[], VOID *[] );
extern VOID ppfrk6_( VOID *(*)(VOID *,VOID *,VOID *,VOID *,VOID *,VOID *), 
		     VOID *[], VOID *[], VOID *[], VOID *[], VOID *[], 
                     VOID *[] );
extern VOID ppfrk7_( VOID *(*)(VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,
                     VOID *), VOID *[], VOID *[], VOID *[], VOID *[], VOID *[], 
                     VOID *[], VOID *[] );
extern VOID ppfrk8_( VOID *(*)(VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,
		     VOID *), VOID *[], VOID *[], VOID *[], VOID *[], VOID *[], 
                     VOID *[], VOID *[], VOID *[] );
extern VOID ppfrk9_( VOID *(*)(VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,
                     VOID *,VOID *), VOID *[], VOID *[], VOID *[], VOID *[], 
                     VOID *[], VOID *[], VOID *[], VOID *[], VOID *[] );
extern VOID ppfrk10_( VOID *(*)(VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,
                      VOID *,VOID *, VOID *), VOID *[], VOID *[], VOID *[], 
                      VOID *[], VOID *[], VOID *[], VOID *[], VOID *[], VOID *[], 
                      VOID *[] );
extern VOID ppfrk11_( VOID *(*)(VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,
                      VOID *,VOID *, VOID *, VOID *), VOID *[], VOID *[], 
                      VOID *[], VOID *[], VOID *[], VOID *[], VOID *[], VOID *[], 
                      VOID *[], VOID *[], VOID *[] );
extern VOID ppfrk12_( VOID *(*)(VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,
                      VOID *,VOID *, VOID *, VOID *,VOID *), VOID *[], VOID *[], 
                      VOID *[], VOID *[], VOID *[], VOID *[], VOID *[], VOID *[], 
                      VOID *[], VOID *[], VOID *[], VOID *[] );
extern VOID ppfrk13_( VOID *(*)(VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,
                      VOID *,VOID *, VOID *, VOID *,VOID *,VOID *), VOID *[], 
                      VOID *[], VOID *[], VOID *[], VOID *[], VOID *[], VOID *[], 
                      VOID *[], VOID *[], VOID *[], VOID *[], VOID *[], VOID *[] );
extern VOID ppfrk14_( VOID *(*)(VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,
                      VOID *,VOID *, VOID *, VOID *,VOID *,VOID *,VOID *), VOID *[], 
                      VOID *[], VOID *[], VOID *[], VOID *[], VOID *[], VOID *[], 
                      VOID *[], VOID *[], VOID *[], VOID *[], VOID *[], VOID *[], 
                      VOID *[] );
extern VOID ppfrk15_( VOID *(*)(VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,VOID *,
                      VOID *,VOID *, VOID *, VOID *,VOID *,VOID *,VOID *,VOID *), 
                      VOID *[], VOID *[], VOID *[], VOID *[], VOID *[], VOID *[], 
                      VOID *[], VOID *[], VOID *[], VOID *[], VOID *[], VOID *[], 
                      VOID *[], VOID *[], VOID *[] );

extern VOID ppinit_( CHAR [], INT *,INT * );
extern VOID ppinit2_ ( VOID );
extern VOID ppfini_( VOID );
extern VOID ppresu_( VOID );
extern VOID pppark_( VOID );
extern VOID pprset_( VOID );
extern VOID ppsynci_( VOID );
extern VOID ppsync_( VOID );
extern VOID pplock_( INT * );
extern VOID lockst_( INT * );
extern VOID ppunlock_( INT * );
extern VOID lockcl_( INT * );
extern VOID ppinfo_( INT*, INT * );
extern INT ppinqr_( INT * );
extern INT ppnext_( VOID );
extern INT ppproc_( VOID );

extern VOID pplockprt_( VOID );
extern VOID ppunlockprt_( VOID );
extern VOID printf_lck(const char *format, ...);

#endif		/* PARALLEL_H */
/*---------------------------- End Of Module -------------------------*/
