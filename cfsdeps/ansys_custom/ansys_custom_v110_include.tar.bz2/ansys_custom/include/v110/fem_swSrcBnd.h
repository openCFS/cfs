/* sid 60.1 copy of fem_swSrcBnd.h last changed by upd111 on 2005/07/21 19:43:01 */

/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 1999 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_swSrcBnd.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_swSrcBnd.h
 *  header file for FEM_swSrcBnd.c
 *
 */
#ifndef FEM_SWSRCBND_INCLUDE
#define FEM_SWSRCBND_INCLUDE
#include "FEM_aeMeshData.h"
#include "fem_swPriv.h"

/*----------------- Globally accessible variables ---------------------------*/

/*----------------- Globally accessible function prototypes -----------------*/

/* ============================================================================  */
/* === FEM_swGetBnd: Create an  ordered list of nodes on the boundary of an area.*/
/* === Return: EXIT_SUCCESS or EXIT_FAILURE                                      */
/* ============================================================================= */
INT FEM_swGetBnd(
	AREAMSHDAT_PTYP p_mshArea) ;


#endif

