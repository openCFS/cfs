/* sid 60.1 copy of AnsMemPcDebug.h last changed by jtm on 2006/05/15 19:43:07 */

/* *** copyright(c) 2006 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */

/*
 * define some debugging flags for PC development  
 * -- any other case, they are NULL 
 */
#if defined (DEVELOPMENT)
# if defined (PCWINNT_SYS)
#  if defined (DEBUG_MALLOC)
#   if !defined (_DEBUG)
#    define _DEBUG
#   endif
#   include <CRTDBG.H>
#   if !defined (_CRTDBG_MAP_ALLOC)
#    define _CRTDBG_MAP_ALLOC
#   endif
#   define  DEBUGGING_MALLOC_SETUP \
      _CrtSetDbgFlag(_CRTDBG_CHECK_ALWAYS_DF | _CrtSetDbgFlag(_CRTDBG_REPORT_FLAG)); \
      _CrtSetReportMode( _CRT_WARN, _CRTDBG_MODE_FILE ); \
      _CrtSetReportFile( _CRT_WARN, _CRTDBG_FILE_STDOUT ); \
      _CrtSetReportMode( _CRT_ERROR, _CRTDBG_MODE_FILE ); \
      _CrtSetReportFile( _CRT_ERROR, _CRTDBG_FILE_STDOUT ); \
      _CrtSetReportMode( _CRT_ASSERT, _CRTDBG_MODE_FILE ); \
      _CrtSetReportFile( _CRT_ASSERT, _CRTDBG_FILE_STDOUT )
#  else
#   define  DEBUGGING_MALLOC_SETUP ((void) 0) 
#  endif
# else
#  define  DEBUGGING_MALLOC_SETUP ((void) 0) 
# endif
#else
# define  DEBUGGING_MALLOC_SETUP ((void) 0) 
#endif

