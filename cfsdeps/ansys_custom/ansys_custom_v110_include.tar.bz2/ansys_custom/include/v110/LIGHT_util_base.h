/* sid 60.3 copy of LIGHT_util_base.h last changed by jtm on 2006/05/16 13:52:36 */
/*******************************************************************************
 *
 *  MSH_util.h - Utilitaire de gestion des mesh
 *               
 * 
 * |Module: ADOMESH
 *
 * |Description: 
 *
 * |Includes:	
 *        
 * |Auteur: Gilles Venet
 *
 * |Creation: Mai 2001
 *
 * |Version: 
 *
 * |Copyright:	copyright(c) 2006 SAS IP, Inc.  All rights reserved.
 *
 *
 ******************************************************************************/
#ifndef __lightutilbaseh__
#define __lightutilbaseh__ 1

#include "LIGHT_struct_base.h"

/*#ifdef __cplusplus
extern "C" {
#endif*/

  extern void		MSH_liberer_memoire_Lnoeud ( T_Lnoeud **Lnoeud );
  extern void		MSH_liberer_memoire_Lelement ( T_Lelement **Lelement );

  extern T_statut	DAM_lire_maillage_LIGHT ( T_cbf *cbf, T_Mesh *mesh, T_Lnoeud **Lnoeud, T_Lelement ** );
  extern T_Lnoeud   *LIGHT_lire_noeud_dans_cbf ( T_cbf *cbf, int numero, T_statut *ier );
  extern T_Lelement * LIGHT_lire_element_dans_cbf ( T_cbf  *cbf, int numero, T_statut *ier  ); //lecture des elements
  extern T_Lelement * LIGHT_lire_element_data_dans_cbf ( T_cbf  *cbf, int numero, T_statut *ier  );//lecture que des type d'element et du nbre de noeud
  extern T_Lnoeud	*MSH_allouer_memoire_Lnoeud ( T_statut *ier );
  extern T_Lelement	*MSH_allouer_memoire_Lelement ( T_statut *ier );

  extern T_statut	LIGHT_set_nbnoeud ( T_Lnoeud *noeud, unsigned int nbn );
  extern T_statut	LIGHT_set_nbnoeud_si ( T_Lnoeud *noeud, unsigned int nbn );
  extern T_statut 	LIGHT_set_nbelement ( T_Lelement *element, unsigned int nbn ); // complet
  extern T_statut 	LIGHT_set_nbelement_si ( T_Lelement *element, unsigned int nbn ); // sans connectivite inverse
  extern T_statut   LIGHT_set_nbelement_data ( T_Lelement *element, unsigned int nbn );// uniquement le type et le nbr de noeud par element
  extern T_Lnoeud *LIGHT_copier_Lnoeud ( T_Lnoeud *Lnorg, T_statut *ier );
  extern T_Lnoeud *LIGHT_copier_Tnoeud ( T_Noeud **norg, int nb_nbnoeud, T_statut *ier );
  extern T_Lelement *LIGHT_copier_Telement ( T_Element **eleorg, int nb_element, T_statut *ier  );
  extern T_Noeud **LIGHT_copier_noeud_IVEC ( T_Lnoeud *Lnoeud, IVEC *IndexNode, T_Noeud ** n0, T_statut *ier );


  extern T_statut	LIGHT_noeud_num2ind ( T_Lnoeud *noeud );

  extern T_statut 	LIGHT_add_noeud ( T_Lnoeud *, int numero, double *xyz );
  extern T_statut 	LIGHT_add_noeud_si ( T_Lnoeud *, int indice, int numero, double *xyz );
  extern T_statut 	LIGHT_add_element ( T_Lelement *Lelement, int numero, E_ele_type_geo type_geometrique, int nb_noeud, int *noeud );
  extern T_statut 	LIGHT_add_element2 ( T_Lelement *Lelement, int numero, E_ele_type_geo type_geometrique, int nb_noeud, vector<int> &noeud );
  extern T_statut 	LIGHT_add_element_si ( T_Lelement *Lelement, int indice, int numero, E_ele_type_geo type_geometrique, int nb_noeud, int *noeud );

  extern void LIGHT_set_boite_of_nodes ( T_Lnoeud *Lnoeud );

  extern unsigned int 	LIGHT_get_nbnoeud ( T_Lnoeud *noeud );
  extern unsigned int 	LIGHT_get_nbnoeud_max ( T_Lnoeud *noeud );

  extern T_booleen	LIGHT_noeud_existe ( T_Lnoeud *Lnoeud, int numero , int *);
  extern double		*LIGHT_get_noeud ( T_Lnoeud *, int numero );
  extern double		*LIGHT_get_noeud_indice ( T_Lnoeud *, int numero, int *ind );
  extern int      LIGHT_get_Nindice ( T_Lnoeud *Lnoeud, int numero );
  extern double *LIGHT_get_noeud_by_indice ( T_Lnoeud *Lnoeud, int  indice , int * );

  extern int    *LIGHT_get_element ( T_Lelement *Lelement, int numero, E_ele_type_geo *type, int *nb_noeud );
  unsigned int  LIGHT_get_nbelement( T_Lelement * Lele);
  unsigned int  LIGHT_get_nbelement_max ( T_Lelement * Lele);
  extern int	*LIGHT_get_element_avec_indice (T_Lelement * Lelement,int *indEle, int numero, E_ele_type_geo *type, int *nb_noeud );
  extern int*LIGHT_get_element_by_indice( T_Lelement * Lelement,int indEle, int *numero, E_ele_type_geo *type, int *nb_noeud );
  extern E_ele_type_geo LIGHT_get_element_type ( T_Lelement *Lelement, int numero, int **ele, int *nb_noeud );
  double LIGHT_eval_taille_mesh ( T_Lnoeud *Lnode );

/*#ifdef __cplusplus
}
#endif*/

#endif
