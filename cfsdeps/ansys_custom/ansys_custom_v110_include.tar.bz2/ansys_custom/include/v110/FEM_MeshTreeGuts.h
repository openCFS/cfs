/* sid 60.1 copy of FEM_MeshTreeGuts.h last changed by upd111 on 2005/07/21 19:38:55 */
/* ********************************** */
/* *** ansys(r) copyright(c) 2000 *** */
/* *** ansys, inc.                *** */
/* ********************************** */

/*  FEM_MeshTreeGuts.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/* 
 *  FEM_MeshTreeGuts.h
 *  Mesh table xref mesh to fea entity
 *
 */
 #ifndef FEM_MESHTreeGUTS
 #define FEM_MESHTreeGUTS

#include "FEM_meshTree.h"

class CBBox;
class Tree_Node;

class QuadAndOctTree
{
public:
    QuadAndOctTree ( _eTreeType eType  );
    ~QuadAndOctTree ();

   Tree_Node    *m_pcQuadtree;
   Tree_Node    *m_pcOctTree;
};
#endif
