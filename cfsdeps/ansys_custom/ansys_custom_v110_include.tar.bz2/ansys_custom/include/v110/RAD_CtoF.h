/* sid 60.1 copy of RAD_CtoF.h last changed by jtm on 2006/05/15 19:43:28 */

/* ---------------------------------------------------------------------- */
/* *** copyright(c) 2006 SAS IP, Inc.  All rights reserved. */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */

/* First some memory allocation macros */
#define VFNEWC(size,name) VfAlloc_C((size),(name),__FILE__,__LINE__) 
#define VFNEWF(size,name) VfAlloc_F((size),(name),__FILE__,__LINE__) 
#define VFNEWD(size,name) VfAlloc_D((size),(name),__FILE__,__LINE__) 
#define VFNEWI(size,name) VfAlloc_I((size),(name),__FILE__,__LINE__) 
#define VFRENEWC(ptr,size,name) VfReAlloc_C((ptr),(size),(name),__FILE__,__LINE__)
#define VFRENEWF(ptr,size,name) VfReAlloc_F((ptr),(size),(name),__FILE__,__LINE__)
#define VFRENEWD(ptr,size,name) VfReAlloc_D((ptr),(size),(name),__FILE__,__LINE__)
#define VFRENEWI(ptr,size,name) VfReAlloc_I((ptr),(size),(name),__FILE__,__LINE__)
#define VFFREE(ptr) VfFree((ptr),__FILE__,__LINE__)

CHAR *VfAlloc_C(INT,CHAR*,CHAR*,INT);
INT *VfAlloc_I(INT,CHAR*,CHAR*,INT);
REAL *VfAlloc_F(INT,CHAR*,CHAR*,INT);
DOUBLE *VfAlloc_D(INT,CHAR*,CHAR*,INT);
CHAR *VfReAlloc_C(INT,CHAR*,CHAR*,INT);
INT *VfReAlloc_I(INT,CHAR*,CHAR*,INT);
REAL *VfReAlloc_F(INT,CHAR*,CHAR*,INT);
DOUBLE *VfReAlloc_D(INT,CHAR*,CHAR*,INT);
void VfFree(INT*,CHAR*,INT);


/*  RAD_CtoF.h */
/* *** Notice - This file contains ANSYS Confidential information  *** */
/*                                                       mik (From SJO)
 *  RAD_CtoF.h
 *  Prototypes and #defines for handling calls from
 *  C to FORTRAN and FORTRAN to C for the FEM module
 *
 *  To call FORTRAN from C:
 *  1.  A total of 5 entries into this file should be made under the
 *      headings "FORTRAN subroutines called from C".  Search for these
 *      headings and follow the pattern.
 *  2.  To call FORTRAN from C use an underscore at the end of the name
 *      All lower case is required!
 *      ie.           ffunc_(args);
 *  3.  Do not use the underscore in the FORTRAN definition of the function
 *      ie.           subroutine ffunc(arg1,arg2)
 *  4.  Pass the addresses of data to the FORTRAN subroutine i.e.
 *                    INT arg1;
 *                    DOUBLE arg2;
 *                    ffunc_(&arg1, &arg2);
 *  5.  Include this file in the C file that calls the FORTRAN. i.e.
 *                #include "FEMa_CtoF.h"
 *
 *  To call C from FORTRAN:
 *  1.  A C function callable from FORTRAN should be named with an
 *      underscore after the last letter.  All lower case is required!
 *       .ie cfunc_
 *  2.  The function definition should have the type and the #define
 *      CALLTYP preceding the function name. i.e.
 *               INT CALLTYP cfunc_ (args)
 *      CALLTYP is defined in computers.h - so do a #include "computers.h"
 *  3.  Argument lists should use K&R standard rather than including
 *      types in the argument list (ANSI standard).  i.e.
 *               INT CALLTYP cfunc_ (arg1, arg2)
 *                   INT *arg1;
 *                   DOUBLE *arg2;
 *  4.  Arguments to the C function should be received as addresses and
 *      then dereferenced before being used.  i.e.
 *               INT CALLTYP cfunc_ (arg1, arg2)
 *                   INT *arg1;
 *                   DOUBLE *arg2;
 *               {
 *                   *arg1 = 1;  *arg2 = 1.0;
 *               }
 *  4.  A total of 5 entries into this file should be made under the
 *      headings "C functions called from FORTRAN".  Search for these
 *      headings and follow the pattern.
 *  5.  This file should be included in the C file where the function
 *      is located.  i.e.
 *               #include "FEMa_CtoF.h"
 *  6.  To call C from FORTRAN do not use the underscore i.e.
 *               call cfunc(arg1,arg2)
 *  7.  An extern definition should be included in the calling FORTRAN
 *      subroutine as well as the return type (if any).  i.e.
 *               extern cfunc
 *               integer cfunc
 *
 */

/* (1)-------------------------------------------------------------*/
#if defined(RS6000_SYS) || defined(HP32_SYS)

/* === C functions called from FORTRAN */

#define init_vfdb_     init_vfdb
#define destroy_vfdb_  destroy_vfdb
#define get_vfrow_     get_vfrow
#define vufactor_      vufactor 
#define radsol_gauss_  radsol_gauss 
#define rd_vfdb_       rd_vfdb
#define wr_vfdb_       wr_vfdb
#define get_vfrowsum0_ get_vfrowsum0
#define get_vfrowsum1_ get_vfrowsum1
#define put_vfrow_     put_vfrow
#define init_vfencl_   init_vfencl
#define get_vfsingle_  get_vfsingle

/* === FORTRAN subroutines called from C */

#endif

/* (2)-------------------------------------------------------------*/

#if defined(WATCOMC_SYS) || \
    defined(PCWINNT_SYS)

/* === C functions called from FORTRAN */
#define init_vfdb_     INIT_VFDB
#define destroy_vfdb_  DESTROY_VFDB
#define get_vfrow_     GET_VFROW
#define vufactor_      VUFACTOR 
#define radsol_gauss_  RADSOL_GAUSS 
#define rd_vfdb_       RD_VFDB
#define wr_vfdb_       WR_VFDB
#define get_vfrowsum0_ GET_VFROWSUM0
#define get_vfrowsum1_ GET_VFROWSUM1
#define put_vfrow_     PUT_VFROW
#define init_vfencl_   INIT_VFENCL
#define get_vfsingle_  GET_VFSINGLE

/* === FORTRAN subroutines called from C */
#endif

/* (3)-------------------------------------------------------------*/
#if defined(WATCOMC_SYS)

/* === C functions called from FORTRAN */
#pragma aux INIT_VFDB "^";
#pragma aux DESTROY_VFDB "^";
#pragma aux GET_VFROW "^";
#pragma aux VUFACTOR "^";
#pragma aux RADSOL_GAUSS "^";
#pragma aux RD_VFDB "^";
#pragma aux WR_VFDB "^";
#pragma aux GET_VFROWSUM0 "^";
#pragma aux GET_VFROWSUM1 "^";
#pragma aux PUT_VFROW "^";
#pragma aux INIT_VFENCL "^";
#pragma aux GET_VFSINGLE "^";

/* === FORTRAN subroutines called from C */

#endif

/* (4)-------------------------------------------------------------*/
/*
 * *** FUNCTION RETURN TYPE DECLARATION
 */

#if !defined(PCWINNT_SYS)

/* === C functions called from FORTRAN */
  void  init_vfdb_();
  void  destroy_vfdb_();
  void  get_vfrow_();
  void  vufactor_();
  void  radsol_gauss_();
  void  rd_vfdb_();
  void  wr_vfdb_();
  void  get_vfrowsum0_();
  void  get_vfrowsum1_();
  void  put_vfrow_();
  void  init_vfencl_();
  void  get_vfsingle_();

/* === FORTRAN subroutines called from C */

/* (5)-------------------------------------------------------------*/
#else

/* === C functions called from FORTRAN */
  void CALLTYP init_vfdb_(INT *, INT *, INT *);
  void CALLTYP init_vfencl_(INT *, INT *, INT *);
  void CALLTYP destroy_vfdb_();
  void CALLTYP get_vfrow_();
  void CALLTYP put_vfrow_();
  void CALLTYP get_vfsingle_();
  void CALLTYP vufactor_(INT *, INT *,REAL *,REAL *,REAL *, INT *,INT *,
                         REAL *);
  void CALLTYP radsol_gauss_(INT *,REAL *,REAL *,REAL *, REAL *, REAL *,
                             INT *,INT *, REAL *,INT *);
#if !defined (PCWINNT_SYS)
  void CALLTYP  rd_vfdb_(CHAR *);
  void CALLTYP  wr_vfdb_(CHAR *,INT *);
#endif
  void CALLTYP  get_vfrowsum0_(INT *,INT *, REAL *);
  void CALLTYP  get_vfrowsum1_(INT *,INT *, REAL *);

/* === FORTRAN subroutines called from C */

#endif







