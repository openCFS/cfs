/* sid 60.1 copy of FEM_vlPublic.h last changed by upd111 on 2005/07/21 19:41:55 */
#ifndef FEM_VLPUBLIC
#define FEM_VLPUBLIC

#include "FEM_cdbtypes.h"
#include "FEM_Public.h"
#include "FEM_cell.h"

class VOL_TYP : public CELL_TYP {
   
   private:
                       /* =================================================== */
                       /* === mp_areas:  The head of a linked list of all     */
                       /* === areas defining this volume.                     */
                       /* =================================================== */
      CELLUSE_PTYP mp_areas;

                       /* =================================================== */
                       /* === m_num_areas: The number of areas defining this  */
                       /* === volume.  Also the length of mp_areas.           */
                       /* =================================================== */
      INT m_num_areas;

   public:
      VOL_TYP() { };
      ~VOL_TYP() { };
      void Delete() { DeleteCell(); };

                       /* =================================================== */
                       /* === GetNext: Get the next volume in this model.     */
                       /* === return: VOL_PTYP of the next volume.            */
                       /* =================================================== */
      VOL_PTYP GetNext( ) { return (VOL_PTYP)CELL_TYP::GetNext(); };

                       /* =================================================== */
                       /* === InitVol: Initialize this object.  Must be       */
                       /* === called in addition to the default constructor.  */
                       /* =================================================== */
      void InitVol( ) { InitCellVolume();
                        mp_areas = NULL;
                        m_num_areas = 0; };

                       /* =================================================== */
                       /* === SetArea: Store an areas as one of the areas     */
                       /* === defining the boundary of this volume.           */
                       /* === return: EXIT_SUCCESS or EXIT_FAILURE            */
                       /* =================================================== */
      INT SetArea(
         const AREA_PTYP obj_area,/* (IN)  An area that defines the boundary  */
                                  /*       of this volume.                    */
         const INT orientation    /* (IN)  The orientation of this area with  */
                                  /*       respect to this volume:            */
                                  /*         1: area normal faces out.        */
                                  /*        -1: area normal faces in.         */
         );

                       /* =================================================== */
                       /* === NumAreas: Return the number of areas on this    */
                       /* === volume.                                         */
                       /* === return: number of areas on this volume.         */
                       /* =================================================== */
      INT NumAreas() const { return m_num_areas; };

                       /* =================================================== */
                       /* === AreaList: Return a pointer to Iterator that     */
                       /* === Iterates through the adjacent areas.            */
                       /* === return: CELLUSE_PTYP to adjacent areas.         */
                       /* =================================================== */
      CELLUSE_PTYP AreaList( ) const { return mp_areas; };

                       /* =================================================== */
                       /* === AreaList: Create an array that holds pointers   */
                       /* === to all of the areas on the boundary of this     */
                       /* === volume.                                         */
                       /* === return: EXIT_SUCCESS or EXIT_FAILURE            */
                       /* =================================================== */
      INT AreaList(
         AREA_PTYP **aobj_areas,/*(OUT)array of area pointers.  Must be       */
                              /*       deallocated by the calling routine.    */
         INT &numareas        /* (OUT) number of areas in aobj_areas.         */
         ) const;

                       /* =================================================== */
                       /* === AreaList: Create an array that holds ids        */
                       /* === of all of the areas on the boundary of this     */
                       /* === volume.                                         */
                       /* === return: EXIT_SUCCESS or EXIT_FAILURE            */
                       /* =================================================== */
      INT AreaList(
         INT **a_areas,       /*(OUT)  array of area ids.  Must be            */
                              /*       deallocated by the calling routine.    */
         INT &numareas        /* (OUT) number of areas in a_areas.            */
         ) const;

                       /* =================================================== */
                       /* === LineList: Create an array that holds ids        */
                       /* === of all of the lines on the boundary of this     */
                       /* === volume.                                         */
                       /* === return: EXIT_SUCCESS or EXIT_FAILURE            */
                       /* =================================================== */
      INT LineList(
         INT **a_lines,       /*(OUT)  array of line ids.  Must be            */
                              /*       deallocated by the calling routine.    */
         INT &numlines        /* (OUT) number of lines in a_lines.            */
         ) const;

                       /* =================================================== */
                       /* === LineList: Create an array that holds pointers   */
                       /* === to all of the lines on the boundary of this     */
                       /* === volume.                                         */
                       /* === return: EXIT_SUCCESS or EXIT_FAILURE            */
                       /* =================================================== */
      INT LineList(
         LINE_PTYP **aobj_lines,/*(OUT)array of line pointers.  Must be       */
                              /*       deallocated by the calling routine.    */
         INT &numlines        /* (OUT) number of lines in aobj_lines.         */
         ) const;

                       /* =================================================== */
                       /* === KpList: Create an array that holds pointers to  */
                       /* === all of the keypoints on the boundary of this    */
                       /* === volume.                                         */
                       /* === return: EXIT_SUCCESS or EXIT_FAILURE            */
                       /* =================================================== */
      INT KpList(
         KP_PTYP **aobj_kps,  /* (OUT) array of kp pointers.  Must be         */
                              /*       deallocated by calling routine.        */
         INT &numkps          /* (OUT) number of kp pointers in aobj_kps      */
         ) const;

                       /* =================================================== */
                       /* === KpList: Create an array that holds ids of       */
                       /* === all of the keypoints on the boundary of this    */
                       /* === volume.                                         */
                       /* === return: EXIT_SUCCESS or EXIT_FAILURE            */
                       /* =================================================== */
      INT KpList(
         INT **a_kps,         /* (OUT) array of kp ids.  Must be              */
                              /*       deallocated by calling routine.        */
         INT &numkps          /* (OUT) number of kp pointers in aobj_kps      */
         ) const;

                       /* =================================================== */
                       /* === IsAdjArea: Determine whether a given area id is */
                       /* === is of an area that is adjacent to this volume.  */
                       /* === return: BOOELAN TRUE or FALSE.                  */
                       /* =================================================== */
      FEM_BOOLEAN IsAdjArea(
         const INT area_id    /* (IN)  The id of the area to check.           */
         ) const
      {
         NEXTCELL_PTYP p_area = mp_areas;
         CELL_PTYP obj_cell;

         while ( p_area ) {
            obj_cell = p_area->GetCell();
            if ( obj_cell->IsArea() &&
                 obj_cell->GetId() == area_id ) {
               return TRUE;
            }
            p_area = p_area->GetNext();
         }
         return FALSE;
      }

                       /* =================================================== */
                       /* === IsAdjLine: Determine whether a given line id is */
                       /* === is of a line that is adjacent to this volume.   */
                       /* === return: BOOELAN TRUE or FALSE.                  */
                       /* =================================================== */
      FEM_BOOLEAN IsAdjLine(
         const INT line_id    /* (IN)  The id of the line to check.           */
         ) const;

                       /* =================================================== */
                       /* === IsAdjArea: Determine whether a given area id is */
                       /* === is of an area that is adjacent to this volume.  */
                       /* === return: BOOELAN TRUE or FALSE.                  */
                       /* =================================================== */
      FEM_BOOLEAN IsAdjArea(
         const AREA_PTYP pobj_area /* (IN)  The area to check.           */
         ) const
      {
         NEXTCELL_PTYP p_area = mp_areas;
         CELL_PTYP obj_cell;

         while ( p_area ) {
            obj_cell = p_area->GetCell();
            if ( obj_cell->IsArea() &&
                 obj_cell == pobj_area ) {
               return TRUE;
            }
            p_area = p_area->GetNext();
         }
         return FALSE;
      }

                       /* =================================================== */
                       /* === OtherAdjAreaOnVol: Given a line and a area      */
                       /* === bounding this volume, determine the other area  */
                       /* === that bounds this volume that is adjacent to the */
                       /* === line.                                           */
                       /* === return: AREA_PTYP the other area.               */
                       /* =================================================== */
      AREA_PTYP OtherAdjAreaOnVol(
         const LINE_PTYP pobj_line,   /* (IN)  a line on this volume.         */
         const AREA_PTYP pobj_area    /* (IN)  an area on this volume adjacent*/
                                      /*       to this line.                  */
         ) const
      {
         AREA_PTYP obj_adjarea = pobj_line->GetAdjArea();
         while ( obj_adjarea ) {
            if ( obj_adjarea != pobj_area &&
                 IsAdjArea( obj_adjarea ) ) {
               return obj_adjarea;
            }
            obj_adjarea = pobj_line->GetNextAdjArea( obj_adjarea );
         }
         return NULL;
      };
}; 

#endif
