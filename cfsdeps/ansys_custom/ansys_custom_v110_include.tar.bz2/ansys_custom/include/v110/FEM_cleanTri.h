/* sid 60.2 copy of FEM_cleanTri.h last changed by upd111 on 2006/02/06 15:00:37 */
/*  FEM_cleanTri.h */
/*
 * *** ansys(r) copyright(c) 1999
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_cleanTri.h
 *  header file for FEM_cleanTri.c
 *
 */
#ifndef FEM_CLEAN_TRI_INCLUDE
#define FEM_CLEAN_TRI_INCLUDE

#define EXIT_CANT_SWAP -999
#define CANT_SPLIT_EDGE (EDGE_OBJ)0x1
#define CANT_SPLIT_FACE 2


#define NO_CHECK_FOR_SPLITING_FACE			0L<<0 
#define CHECK_POINT_INSIDE_SPLITING_FACE	1L<<0 
#define CHECK_NEWLY_CREATED_TRI_FACE		1L<<1 

#ifdef __cplusplus
extern "C" {
#endif

/*----------------- Globally accessible function prototypes -----------------*/

                              /* =========================================== */
                              /* === FEM_clTriCleanUp: Do cleanup, delaunay  */
                              /* === swaps and surface curvature refinement  */
                              /* === for all-tri mesh                        */
INT FEM_clTriCleanUp (

   /* *** General arguments *** */

   INT    anum,               /* current area number                         */
   INT    midnodes,           /* whether areas have midnodes                 */
   INT    num_bound,          /* number of boundary nodes                    */
   INT    num_internal,       /* number of internal nodes                    */
   INT    shape,              /* 3 = tri, 4 = tri/quad                       */

   /* *** Smoothing arguments *** */

   INT    smooth,             /* smoothing on or off                         */
   DOUBLE smthtol,            /* smoothing tolerance                         */
   INT    smooth_iter,        /* number of smoothing iterations              */
   INT    line_smooth,        /* line smoothing on or off                    */

   /* *** Curvature Refinement aruments *** */

   INT    curvref,            /* curvature refinement toggle status          */
   DOUBLE maxang,             /* the maximum spanning angle (radians) for    */
                              /*  any single edge                            */
   INT    shc,                /* small hole coarsening flag                  */
   DOUBLE shc_maxang,         /* max angle for small hole coarsening         */
   DOUBLE shc_minratio,       /* small hole coarsening: min ratio between    */
                              /* largest to smallest edge at which shc will  */
                              /* take effect                                 */
   DOUBLE shc_maxratio,       /* small hole coarsening: max ratio between    */
                              /* largest to smallest edge that sizes will    */
                              /* no longer be coarsened (use shc_maxang)     */
   DOUBLE maxEsize,           /* maximum element size                        */
   DOUBLE minEsize,           /* minimum element size                        */
   DOUBLE quadfactor,         /* size factor for quad meshing                */
   INT    stretch,            /* 1 = refine only in direction of curvature   */
                              /* 0 = refine uniformly in all directions      */
                              /*     based on max curvature                  */
   INT    high_curv,          /* flag = area has high curvature              */
   INT    cswap,              /* flag = curvature swapping                   */

   /* *** Topology and Delaunay arguments *** */

   INT    delaunay,           /* Delaunay improvement toggle status          */
   INT    topoclean,          /* topological cleanup toggle status           */
   INT    topo_iter  );       /* max number of topo clean iterations         */


                              /* =========================================== */
                              /* === FEM_clSwapDelaunay: perform delauney    */
                              /* === on all tri meshes.  Called from         */
                              /* === FEM_clean.c                             */
INT FEM_clSwapDelaunay (
   NODELIST_OBJ obj_nlist,    /* the node list                               */
   EDGELIST_OBJ obj_edlist,   /* the edge list                               */
   FACELIST_OBJ obj_flist,    /* the face list                               */
   INT area,                  /* area number to clean up                     */
   INT midnodes,              /* model contains midnodes                     */
   INT smooth,                /* do smoothing                                */
   INT line_smooth,           /* do line smoothing                           */
   DOUBLE smooth_tol,         /* tolerance for smoothing                     */
   INT *tri_swapped  );       /* returns as 1 if something was swapped       */

                              /* =========================================== */
                              /* === FEM_clDoSwap : Swap the diagonal        */
                              /* === between two adjacent triangle faces     */
                              /* === EXIT_CANT_SWAP returned if topologically*/
                              /* === impossible                              */
INT FEM_clDoSwap (
   EDGELIST_OBJ obj_edlist,   /* the edge list object                        */
   FACELIST_OBJ obj_flist,    /* the face list object                        */
   EDGE_OBJ *pobj_edge,       /* edge between two faces                      */
   FACE_OBJ *pobj_face1,      /* face adjacent to edge                       */
   FACE_OBJ *pobj_face2  );   /* other face adjacent to edge                 */

                              /* =========================================== */
                              /* === FEM_clSplitAtEdge: split an edge between*/
                              /* === two tris to create four tris            */ 
                              /* === CANT_SPLIT_EDGE will be returned if the */
                              /* === quality of resulting tris is below      */
                              /* === SMALL_METRIC                            */
EDGE_OBJ FEM_clSplitAtEdge ( 
   EDGE_OBJ obj_edge2,        /* the edge between the two tris               */
   NODE_OBJ obj_node1,        /* node at one end of edge                     */
   DOUBLE ratio,              /* ratio at which to split edge (0->1)         */
   NODE_OBJ obj_node,         /* optional node at which to split edge at     */
                              /*   NULL: node created in function            */
   INT check  );              /* check the resulting element quality before  */
                              /* performing split - return CANT_SPLIT_EDGE   */
                              /* if any metric is below SMALL_METRIC         */

                              /*===============================================*/
                              /* === FEM_clCurveSwap:                          */
                              /* === perform edge swaps based on surface curvature.*/
                              /* === Swap edges that do not follow the direction of*/
                              /* ===  curvature(Only called for non-flat surfaces) */
INT FEM_clCurveSwap (
   FACELIST_OBJ obj_flist,
   EDGELIST_OBJ obj_edlist,
   NODELIST_OBJ obj_nlist,
   DOUBLE maxang,
   INT anum );


                              /*==============================================*/
                              /* === FEM_clQualitySwap: Swap edges in order to*/
                              /* === improve the quality of the elements.     */
                              /* === Swapping is done to closer approximate a */
                              /* === curved surface or to maximize the        */
                              /* === minimum shape metrics if there are       */
                              /* === hardpoints on the surface.               */
INT FEM_clQualitySwap ( 
   FACELIST_OBJ obj_flist,    /* (IN)  the facelist                           */
   EDGELIST_OBJ obj_edlist,   /* (IN)  the facelist                           */
   NODELIST_OBJ obj_nlist,    /* (IN)  the facelist                           */
   DOUBLE maxang,             /* (IN)  max span angle for approximating       */
                              /*       curved surfaces.  Not used unless      */
                              /*       check_curv == TRUE.                    */
   INT anum,                  /* (IN)  The area number                        */
   FEM_BOOLEAN check_curv,    /* (IN)  TRUE if edge surface approximation     */
                              /*       should be checked to see if swap should*/
                              /*       be done.                               */
   FEM_BOOLEAN areahpts );    /* (IN)  TRUE if there are area hardpoints on   */
                              /*       this area.                             */


INT FEM_clSplitAtLoc ( 
   FACE_OBJ obj_face,			/* the face to be splited               */
   DOUBLE	xyz[3],				/* location								*/
   INT check,  					/* check the location					*/
   NODE_OBJ *pobj_newNode );

#ifdef __cplusplus
}
#endif

#endif

