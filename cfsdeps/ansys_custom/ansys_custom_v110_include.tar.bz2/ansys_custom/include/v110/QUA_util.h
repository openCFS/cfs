/* sid 60.2 copy of QUA_util.h last changed by gdvenet on 2006/02/10 09:42:45 */
/* QUA_util.h CADOE  */
/*
 * QUA_util.h
 *   
 * HISTORY
 *   
 *   09/25/00 11:19 <       Brian Jantzen> Rel:ms8m1    SCCA:79107  Delta:81.2
 *   
 *   01/13/00 11:20 <        Marc Gadbois> Rel:ms8      SCCA:65669  Delta:8.3
 *   
 *   09/30/99 17:38 <         James Silva> Rel:ms8      SCCA:56512  Delta:8.2
 */

/* $Id$ */

#ifndef __quah__
#define __quah__ 1

#ifdef __cplusplus
extern "C" {
#endif

extern T_statut QUA_quamat( VEC *, VEC * );
extern VEC *QUA_matqua( VEC *, T_statut * );
extern T_statut QUA_quamat_d( VEC *, VEC *, int *);
extern void eulmat( double *eul, double *rot );
extern void eulqua( double *eul, double *rot );
extern void mateul( double rot[9], double eul[9] );
extern void mateulr( double *rot, double *eul );
extern void eulmatr( double *eul, double *rot );

#ifdef __cplusplus
  }
#endif

#endif
