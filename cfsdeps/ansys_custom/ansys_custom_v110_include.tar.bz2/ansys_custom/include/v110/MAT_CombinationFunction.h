/* sid 60.1 copy of MAT_CombinationFunction.h last changed by upd111 on 2006/10/09 19:57:31 */
////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         Copyright (C) 2001 ANSYS Inc.  All Rights Reserved             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MAT_CombinationFunction.h $
// $Revision$ 7.0
// $Date$ May 8 2002
// $Author$ rjayasee
//
// Decription :
//
//	This class is the base class for all constitutive functions that are
//  combination function
//////////////////////////////////////////////////////////////////////////////

#if !defined( MAT_CombinationFunction_H )
#define MAT_CombinationFunction_H


#include "MAT_ConstitutiveFunction.h"

// #include "MAT_ConstitutiveFunction.h"

class MAT_CombinationFunction : public MAT_ConstitutiveFunction
{

public:

    MAT_CombinationFunction();
    //Constructor

    virtual bool SetActiveComponentFunction( ANS_String oActiveFunction ) ;
    //R true or false
    //R true if valid param. Check with derived class for details
    //I oActiveFunction
    //I-One of the component constitutive functions in the comb model
    //- Set the "Active Component Constitutive Function"
    
    virtual bool GetActiveComponentFunction( ANS_String& oActiveFunction ) ;
    //R true or false
    //R true if valid param. Check with derived class for details
    //I oActiveFunction
    //I-One of the component constitutive functions in the comb model
    //- Gets the "Active Component Constitutive Function"

    virtual MAT_ConstitutiveFunction const* GetComponent(ANS_String oCompName) = 0 ;
    //R Pointer to Component
    //I oCompName
    //I-Name of component
    //- Returns a Components

    virtual void Print() ;
    //F-Print

  	virtual ~MAT_CombinationFunction();
    //F-Destructor

    ANS_String m_oActiveComponentFunction ;
    //Active Function on which fitting operations are to done

    //--????????------
    //Possible data structure to implement all combination functions here
};

#endif // !defined(MAT_PronyViscoHypoElastic_H)
