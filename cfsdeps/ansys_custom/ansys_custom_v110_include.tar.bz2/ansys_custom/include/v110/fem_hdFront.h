/* sid 60.1 copy of fem_hdFront.h last changed by upd111 on 2005/07/21 19:42:11 */
/*  fem_hdFront.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  fem_hdFront.h
 *  Prototypes and macros for hexdom front data type
 *
 */

#ifndef HDFRONT_H
#define HDFRONT_H

/*------------------------ Constants -------------------------------------------*/
#define EDGE_0 (1L<<0)
#define EDGE_1 (1L<<1)
#define EDGE_2 (1L<<2)
#define EDGE_3 (1L<<3)
#define NODE_LEFT  (1L<<0)
#define NODE_RIGHT (1L<<1)
#define TWOPI 6.2831853071796
#define NUMSTATES 6
#define CANT_RECOVER -999
#define EXIT_ON_FRONT -998
#define EXIT_CANT_RECOVER -998
#define MAX_UPDATE_FRONT 100
#define MAX_HEX_TRIES 6
#define EXIT_CANT_FAIL -937
#define EXIT_DEGENERATE_PROTOHEX -1001
#define EXIT_CANT_RETESSELATE -926
#define EXIT_CANT_COLLAPSE -923
#define EXIT_CANT_SEAM -922
#define DUMMY_FRONT (HDFRONT_PTYP)0xdeadbeef
#define TWO_ROOT_THREE  3.46410161514
   

         /* === Characterstic Angles === */
                /* adjacent fronts with angle < THRESHOLD_ANGLE are           */
                /* defined as adjacent faces of a proto-hex                   */
#define THRESHOLD_ANGLE 2.3561944901924    /* 135 degrees */
                /* edge is selected in fem_hdGetSide if angle between front   */
                /* normal and edge is less than CLOSEDGE_ANGLE                */
#define CLOSEDGE_ANGLE 0.5235987755983     /* 30 degrees */
#define CLOSEDGE_DOT   0.8660254037844
#define CLOSEDGEONFRONT_DOT 0.5
#define MINBETA_INTERIOR -0.5
#define MINBETA_BOUND 0.25
static const DOUBLE ZERO_TOL = DBL_EPSILON * 1.0e3;

/*------------------------ Data Structures -------------------------------------*/
typedef struct HDFRONT_TYP *HDFRONT_PTYP;
typedef struct HDFRONT_TYP {
   INT state;            /* first 4 bits used */
   INT level;            /* from the boundary */
   INT inode0;           /* initial node/edge on front face (obj_face) */
   INT orientation;      /* direction of nodes/edges with repsect to obj_face */
   INT numtries;         /* number of tries to form hex at this front 
                            999 = impossible to make hex at this front */
   INT flag[4];          /* one for each edge */
   DOUBLE angle[4];      /* angle at the edges */
   INT visit;            /* visited flag */
   DOUBLE area;          /* approx area of the front */
   VECTOR3D s_norm;      /* normal of the front */
   FACE_OBJ obj_tri0;    /* triangles immediately adjacent obj_face */
   FACE_OBJ obj_tri1;    
   FACE_OBJ obj_face;    /* the front face */
   HDFRONT_PTYP ps_previous;  /* for double linked list */
   HDFRONT_PTYP ps_next;
} HDFRONT_TYP;

typedef enum { ELEMENT_ENTITY, 
               FACE_ENTITY, 
               EDGE_ENTITY, 
               FEMNODE_ENTITY,
               NO_ENTITY } ENTITY_ENUM;

/*------------------------ Globals - used in only FEM_hd files -----------------*/
extern NODELIST_OBJ g_obj_nlist;          /* global node list                  */
extern EDGELIST_OBJ g_obj_edlist;         /* global edge list                  */
extern FACELIST_OBJ g_obj_flist;          /* global face list                  */
extern ELEMENTLIST_OBJ g_obj_elist;       /* global element list               */

extern INT g_hdebug;                      /* 1 = draw, basic error messages    */
                                          /* 2 = verify data structures        */
extern INT g_flag;                        /* keep track of current process     */
extern INT g_vol;                         /* the volume number we are meshing  */
extern DOUBLE g_voltol;                   /* volume tolerance                  */
extern DOUBLE g_areatol;                  /* area tolerance                    */
extern DOUBLE g_lintol;                   /* linear tolerance                  */
extern DEQUE_OBJ g_obj_tetdeque;          /* used for deleting tets            */
extern INT g_seamflag;

/*----------------------- Macros ----------------------------------------------*/
/*==============================================================================
 * === macro: fem_hdFaceOnFront_C
 * === Author: sjo
 * === Description: return whether face has a front associated with it
 * === Return: FEM_BOOLEAN  TRUE/FALSE
 *============================================================================*/
#define fem_hdFaceOnFront_C( obj_face ) \
   ((FEM_BOOLEAN)((FEM_faGenericPointer_MAC( obj_face )) ? TRUE : FALSE))

/*==============================================================================
 * === macro: fem_hdFront_C
 * === Author: sjo
 * === Description: return the front at a face
 * === Return: HDFRONT_PTYP  ps_front
 *============================================================================*/
#define fem_hdFront_C( obj_face ) \
   ((HDFRONT_PTYP)(FEM_faGenericPointer_MAC( obj_face )))

/*==============================================================================
 * === macro: fem_hdSetBit_MAC
 * === Author: sjo
 * === Description: Set a bit in a bit field
 * === Return: modified bitfield
 *============================================================================*/
#define fem_hdSetBit_MAC( bitfield, bit ) \
    ((bitfield) | (1L << (bit)))

/*==============================================================================
 * === macro: fem_hdUnsetBit_MAC
 * === Author: sjo
 * === Description: Unset a bit in a bit field
 * === Return: modified bitfield
 *============================================================================*/
#define fem_hdUnsetBit_MAC( bitfield, bit ) \
    ((bitfield) ^ (1L << (bit)))

/*==============================================================================
 * === macro: fem_hdIsFrontAtEdge_C
 * === Author: sjo
 * === Description: return whether there is another front at the indicated edge
 * ===              of the front - does not check for edges created for the
 * ===              current proto-hex
 * === Return: HDFRONT_PTYP  ps_front
 *============================================================================*/
#define fem_hdIsFrontAtEdge_C( ps_front, iedge ) \
   ((FEM_BOOLEAN)((ps_front->state & (1L << iedge)) ? TRUE : FALSE))

/*==============================================================================
 * === macro: fem_hdIsFrontAtAnyEdge_C
 * === Author: sjo
 * === Description: return whether there is another front at the indicated edge
 * ===              of the front - also checks for edges created for the
 * ===              current proto-hex
 * === Return: HDFRONT_PTYP  ps_front
 *============================================================================*/
#define fem_hdIsFrontAtAnyEdge_C( ps_front, iedge ) \
   ((FEM_BOOLEAN)((ps_front->state & (1L << iedge) || \
               ps_front->state & (1L << (iedge+4))) ? TRUE : FALSE))

/*==============================================================================
 * === macro: fem_hdSetFrontAtEdge_C
 * === Author: sjo
 * === Description: Set the state bit for an edge on a front
 * ===              state bits are 0-3.  Only set after the completion of hex
 * === Return: HDFRONT_PTYP  ps_front
 *============================================================================*/
#define fem_hdSetFrontAtEdge_C( ps_front, iedge ) \
   ps_front->state = fem_hdSetBit_MAC( ps_front->state, iedge )

/*==============================================================================
 * === macro: fem_hdUnsetFrontAtEdge_C
 * === Author: sjo
 * === Description: UnSet the state bit for an edge on a front
 * ===              state bits are 0-3.  Only set after the completion of hex
 * === Return: HDFRONT_PTYP  ps_front
 *============================================================================*/
#define fem_hdUnsetFrontAtEdge_C( ps_front, iedge ) \
   ps_front->state = fem_hdUnsetBit_MAC( ps_front->state, iedge )

/*==============================================================================
 * === macro: fem_hdSetTempFrontAtEdge_C
 * === Author: sjo
 * === Description: Set the temp state bit for an edge on a front
 * ===              temp state bits are 4-7 and indicate the state of fronts
 * ===              that were built as part of the current proto-hex
 * === Return: HDFRONT_PTYP  ps_front
 *============================================================================*/
#define fem_hdSetTempFrontAtEdge_C( ps_front, iedge ) \
   ps_front->state = fem_hdSetBit_MAC( ps_front->state, iedge+4 )

/*==============================================================================
 * === macro: fem_hdUnsetTempFrontAtEdge_C
 * === Author: sjo
 * === Description: UNSet the temp state bit for an edge on a front
 * ===              temp state bits are 4-7 and indicate the state of fronts
 * ===              that were built as part of the current proto-hex
 * === Return: HDFRONT_PTYP  ps_front
 *============================================================================*/
#define fem_hdUnsetTempFrontAtEdge_C( ps_front, iedge ) \
   ps_front->state = fem_hdUnsetBit_MAC( ps_front->state, iedge+4 )

/*==============================================================================
 * === macro: fem_hdZeroFrontsAtEdge_C
 * === Author: sjo
 * === Description: Zero the number of fronts adjacent to an edge
 * === Return: void
 *============================================================================*/
#define fem_hdZeroFrontsAtEdge_C( obj_edge ) \
   FEM_edSetGenericPointer_C( obj_edge, 0 )

/*==============================================================================
 * === macro: fem_hdIncrFrontsAtEdge_C
 * === Author: sjo
 * === Description: Increment the number of fronts adjacent to an edge
 * === Return: void
 *============================================================================*/
#define fem_hdIncrFrontsAtEdge_C( obj_edge ) \
   FEM_edSetGenericPointer_C( obj_edge, \
     ((INT)FEM_edGenericPointer_MAC( obj_edge )+1))

/*==============================================================================
 * === macro: fem_hdDecrFrontsAtEdge_C
 * === Author: sjo
 * === Description: Decrement the number of fronts adjacent to an edge
 * === Return: void
 *============================================================================*/
#define fem_hdDecrFrontsAtEdge_C( obj_edge ) \
   FEM_edSetGenericPointer_C( obj_edge, \
     ((INT)FEM_edGenericPointer_MAC( obj_edge )-1))

/*==============================================================================
 * === macro: fem_hdNumFrontsAtEdge_C
 * === Author: sjo
 * === Description: return the number of fronts adjacent to an edge
 * === Return: number
 *============================================================================*/
#define fem_hdNumFrontsAtEdge_C( obj_edge ) \
   (INT)FEM_edGenericPointer_MAC( obj_edge )


/*------------------------ Prototypes ------------------------------------------*/

INT           fem_hdFrontCheck               ( void );
INT           fem_hdCheckOneFront            ( HDFRONT_PTYP ps_front );
INT           fem_hdInitFronts               ( INT numfac,
                                               INT *p_numtris );
INT           fem_hdTotFronts                ( void );
INT           fem_hdInitStates               ( void );
INT           fem_hdInitOrientFronts         ( void );
INT           fem_hdInitOrientOneFront       ( HDFRONT_PTYP ps_front );
INT           fem_hdStateIndex               ( HDFRONT_PTYP ps_front );
DOUBLE        fem_hdAngleBetweenFronts       ( HDFRONT_PTYP ps_front0, 
                                               HDFRONT_PTYP ps_front1 );
HDFRONT_PTYP    fem_hdAdjacentFront            ( HDFRONT_PTYP ps_front, 
                                               INT index );
EDGE_OBJ      fem_hdAdjacentEdge             ( HDFRONT_PTYP ps_front,
                                               INT iedge,
                                               INT side );
INT           fem_hdDiscardFront             ( HDFRONT_PTYP ps_front );
HDFRONT_PTYP    fem_hdNewFront                 ( FACE_OBJ obj_face, 
                                               FACE_OBJ obj_tri0,
                                               FACE_OBJ obj_tri1,
                                               INT level );
INT           fem_hdOrientFront              ( HDFRONT_PTYP ps_front,
                                               NODE_OBJ obj_node0,
                                               NODE_OBJ obj_node1 );
INT           fem_hdAddFrontToMainList       ( HDFRONT_PTYP ps_front );
INT           fem_hdAddToStateList           ( HDFRONT_PTYP ps_front,
                                               INT level );
INT           fem_hdAddToUpdateFrontArray    ( HDFRONT_PTYP ps_front,
                                               HDFRONT_PTYP *a_update_front,
                                               INT num_update_front );
INT           fem_hdRemoveFromStateList      ( HDFRONT_PTYP ps_front );
INT           fem_hdFailFront                ( HDFRONT_PTYP ps_front,
                                               INT level );
INT           fem_hdInsertState              ( HDFRONT_PTYP ps_insertfront,
                                               INT curlevel );
INT           fem_hdRemoveFrontFromMainList  ( HDFRONT_PTYP ps_front );
HDFRONT_PTYP    fem_hdNextFront                ( INT *p_level );
HDFRONT_PTYP    fem_hdBetterFront              ( HDFRONT_PTYP ps_front );
INT           fem_hdDeleteAllFrontMemory     ( void );
INT           fem_hdDrawFronts               ( void );
INT           fem_hdTrisAtQuad               ( FACE_OBJ obj_quad,
                                               FACE_OBJ *pobj_tri1,
                                               FACE_OBJ *pobj_tri2,
                                               EDGE_OBJ *pobj_edge );
INT           fem_hdEdgeOnThisFront          ( HDFRONT_PTYP ps_front,
                                               EDGE_OBJ obj_edge );
INT           fem_hdEdgeOnFront              ( EDGE_OBJ obj_edge );
INT           fem_hdEdgeOnOrBehindFront      ( EDGE_OBJ obj_edge );
INT           fem_hdNodeOnFront              ( NODE_OBJ obj_node );
INT           fem_hdNodeOnRealFront          ( NODE_OBJ obj_node );
NODE_OBJ      fem_hdFrontNode                ( HDFRONT_PTYP ps_front,
                                               INT idx );
INT           fem_hdFrontNodes               ( HDFRONT_PTYP ps_front,
                                               NODE_OBJ *aobj_nodes );
EDGE_OBJ      fem_hdFrontEdge                ( HDFRONT_PTYP ps_front,
                                               INT idx );
INT           fem_hdFrontEdges               ( HDFRONT_PTYP ps_front,
                                               EDGE_OBJ *aobj_edge );
INT           fem_hdFrontEdgeIndex           ( HDFRONT_PTYP ps_front,
                                               EDGE_OBJ obj_edge );
INT           fem_hdFrontEdgeNodes           ( HDFRONT_PTYP ps_front,
                                               EDGE_OBJ obj_edge,
                                               NODE_OBJ *p_obj_node0,
                                               NODE_OBJ *p_obj_node1 );
INT           fem_hdUpdateFront              ( ELEMENT_OBJ obj_elem,
                                               INT level,
                                               HDFRONT_PTYP *a_update_front,
                                               INT num_update_front );
INT           fem_hdAvgFrontVector           ( NODE_OBJ obj_node,
                                               HDFRONT_PTYP ps_front,
                                               VECTOR3D *ps_vec );
INT           fem_hdFGPUpdate                ( void );
INT           fem_hdFixTetsAtFront           ( HDFRONT_PTYP ps_front );
INT           fem_hdFrontCount               ( void );
INT           fem_hdFrontsAtNode             ( NODE_OBJ obj_node,
                                               INT *numfronts,
                                               HDFRONT_PTYP *aps_fronts );
INT           fem_hdNumAdjElems              ( EDGE_OBJ obj_edge,
                                               INT *p_numhex,
                                               INT *p_numtet );
INT           fem_hdInitCloseNodeOK          ( NODE_OBJ obj_node );
INT           fem_hdCloseNodeOK              ( NODE_OBJ obj_oppnode ); 
INT           fem_hdRetesselate              ( void );
INT           fem_hdDeleteTetsInHex          ( HDFRONT_PTYP ps_front ); 
INT           fem_hdDeleteTetsInDeque        ( DEQUE_OBJ obj_tetdeque );
INT           fem_hdMakeTetDeque             ( DEQUE_OBJ obj_tetdeque,
                                               HDFRONT_PTYP ps_front );   
INT           hdCheck();
INT           fem_hdDump                     ( void );
INT           fem_hdResume                   ( void );
INT           fem_hdResetFront               ( HDFRONT_PTYP ps_front ); 
HDFRONT_PTYP    fem_hdNextFrontAtEdge          ( EDGE_OBJ obj_edge,
                                               NODE_OBJ obj_node0,
                                               VECTOR3D *ps_norm,
                                               DOUBLE *p_angle );  
INT           fem_hdPyramidsAtFront          ( void );
FEM_BOOLEAN   fem_hdIsEdgeBehindFront        ( EDGE_OBJ obj_edge );
void          fem_hdStats();
INT           fem_hdKiteAtFront              ( HDFRONT_PTYP );

#endif

