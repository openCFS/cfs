/* sid 60.1 copy of CommonShape.h last changed by jtm on 2006/05/15 19:43:12 */
/*
 * *** copyright(c) 2006 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */
#if defined(XOX_DEBUG)
#define CALLTYP
typedef int INT;
typedef  void VOID;
#include "ansproto.h"
#endif

#if !defined(include_xoxbolh)
#define include_xoxbolh
#include "xoxbol.h"
#endif
#include "shapesmt.h"
