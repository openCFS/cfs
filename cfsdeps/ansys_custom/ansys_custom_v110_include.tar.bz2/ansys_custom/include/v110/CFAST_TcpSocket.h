/* sid 60.1 copy of CFAST_TcpSocket.h last changed by upd111 on 2006/10/09 19:58:09 */
/* CFILE CFAST_TcpSocket.h CADOE */
#ifndef _CFAST_TcpSocket
#define _CFAST_TcpSocket

#include "cadoe.h"
#include "m_matrix.h"
#include "erreur.h"
#include "CFAST_Socket.h"

#ifdef WINNT
#define MSG_WAITALL 4
#endif

class CFAST_TcpSocket : public CFAST_Socket
{
public:
	// Constructor.  Used to create a new TCP socket given a port
	CFAST_TcpSocket(int _iPort) : CFAST_Socket("tcp", (int)_iPort) { };

	// Constructor.  Called when a client connects and a new file descriptor has
	// be created as a result.	
	CFAST_TcpSocket(short int _iSocketFd) : CFAST_Socket(_iSocketFd) { };

	// Sends a message to a connected host. The number of bytes sent is returned
	unsigned int iSendMessage(void *_vMessage, unsigned int _iMessageSize);

	// Receives a TCP message 
	unsigned int iReceiveMessage(void *_vMessage, unsigned int _iMessageSize, int _iOption = 0);

	// Binds the socket to an address and port number
	void vBindSocket();

	// Accepts a connecting client.  The address of the connected client is stored in the
	// parameter
	CFAST_TcpSocket *Accept(char *_sHost = NULL);

	// Listens to connecting clients
	void vListen(int _iNumPorts = 5);

	// Connects to a client specified by a supplied host name
	virtual void vConnect(CFAST_GetHostInfo *);

	unsigned int iSendSize(unsigned int size /* nb bytes*/);
	unsigned int iSendArray(const void * ptr, unsigned int size);
	
	unsigned int iReceiveSize(unsigned int * size /* nb bytes*/, int _iOption);
	unsigned int iReceiveArray(void *iArray, unsigned int size, int _iOption);
	
};

#endif
