/* sid 60.2 copy of cAnsGraphicsInterface.h last changed by jtm on 2006/05/16 13:52:44 */
/* cAnsPick.h	                                        
------------------------------------------------------------------------
------- Notice - This file contains ANSYS Confidential information 
------------------------------------------------------------------------
*/

/* ---------------------------------------------------------------------
 * copyright(c) 2006 SAS IP, Inc.  All rights reserved. 
 * ---------------------------------------------------------------------*/

/*------------------------------ Description ---------------------------
 * Description:   The include file to be used for the ANSYS Picking
 *                API routines.
 *----------------------------------------------------------------------*/

/*--------------------- Static TypeDefs/Structures ---------------------*/

/*----------------------- Variable Definitions -------------------------*/

/*------------------------- API Functions ------------------------------*/

extern void cAnsGraphics_ActiveWin(INT winNum);
extern void cAnsGraphics_Dynamic(INT on_off);
extern void cAnsGraphics_ModelLight(char* button);
extern void cAnsGraphics_Rate(INT rateVal);
extern void cAnsGraphics_Zoom(char* zoomType);

/*------------------------------ API Description -----------------------
cAnsGraphics_ActiveWin


  void cAnsGraphics_ActiveWin(activeWin)
      INT  activeWin;

Header file: cAnsGraphicsInterface.h

Purpose:
     To set the active window for graphics window operations (e.g zoom)

Parameters:
     Input
     -----------------------------
       activeWin
         The window number to be made active.  This parameter can 
         have a value from 1 to 5.

     Output
     -----------------------------
       NONE

Return Value:
     NONE

Notes:

----------------------------- End API Description --------------------*/

/*------------------------------ API Description -----------------------
cAnsGraphics_Dynamic


  void cAnsGraphics_Dynamic (on_off)
      INT  on_off;

Header file: cAnsGraphicsInterface.h

Purpose:
     To invoke zoom mode in the graphics window

Parameters:
     Input
     -----------------------------
       on_off
         Key to turn dynamic mode on or off it can have a value of 0 or 1.

     Output
     -----------------------------
       NONE

Return Value:
     NONE

Notes:

----------------------------- End API Description --------------------*/

/*------------------------------ API Description -----------------------
cAnsGraphics_ModelLight


  void cAnsGraphics_ModelLight (button)
      char  *button;

Header file: cAnsGraphicsInterface.h

Purpose:
     To change the dynamic mode object from model to light in 3D mode.

Parameters:
     Input
     -----------------------------
       button
         The type of object for the dynamic mode to operate on.  This 
         parameter can have a value of model or light.  The default
         is model.

     Output
     -----------------------------
       NONE

Return Value:
     NONE

Notes:

----------------------------- End API Description --------------------*/

/*------------------------------ API Description -----------------------
cAnsGraphics_Rate

   void cAnsGraphics_Rate (rateVal)
      INT     rateVal;

Header file: cAnsGraphicsInterface.h

Purpose:
     To set the rate value for graphics window operations 
     (e.g dynamic rotation)

Parameters:
     Input
     -----------------------------
       rateVal
         The rate value for graphics operations.  This parameter can 
         have a value from 1 to 100.

     Output
     -----------------------------
       NONE

Return Value:
     NONE

Notes:

----------------------------- End API Description --------------------*/

/*------------------------------ API Description -----------------------
cAnsGraphics_Zoom


  void cAnsGraphics_CenterZoom (zoomType)
      char  *zoomType;

Header file: cAnsGraphicsInterface.h

Purpose:
     To invoke zoom mode in the graphics window

Parameters:
     Input
     -----------------------------
       zoomType
         The type of zoom operation to be performed.  This parameter can 
         have a value of box, center, or window.

     Output
     -----------------------------
       NONE

Return Value:
     NONE

Notes:

----------------------------- End API Description --------------------*/

/*---------------------------- End Of Module ---------------------------*/
