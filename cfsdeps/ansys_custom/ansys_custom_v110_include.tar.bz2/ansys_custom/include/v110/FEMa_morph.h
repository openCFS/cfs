/* sid 60.1 copy of FEMa_morph.h last changed by upd111 on 2006/10/09 19:55:34 */
/*  FEMa_morph.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */

/* *** ansys(r) copyright(c) 2000
 * *** ansys, inc.
 */

/*
 *  FEMa_morph.h
 *  Heaer file for FEMa_morph.c (Morphing and Remeshing)
 *
 */

#ifndef FEMA_MORPH_H
#define FEMA_MORPH_H

/*------------------------ Prototypes ------------------------------------------*/

                         /*=====================================================*/
                         /* === FEMa_moMorph2D: 2D morphing and remeshing       */
                         /*=====================================================*/
INT FEMa_moMorph2D(
   INT *a_areas,         /* list of areas to perform morphing (if detached, then
                            this is the array of elements) */
   INT num_areas,        /* number of areas (or numelems if detached) */
   INT *a_snodes,        /* list of structural nodes */
   INT num_snodes,       /* number of structural nodes */
   DOUBLE *a_disp,       /* displacement of structural nodes */
   INT *a_ns_nodes,      /* list of non-structural nodes on boundary
                            that can move */
   INT num_nsnodes,      /* number of non-structural nodes */
   INT rmshky,           /* remesh flag option (0=1st try morph then remesh if morph
                            fails. 1=Remesh only. 2=Morph only) */
   DOUBLE lratio,        /* for rmshky=0: if any specified displacement at a
                            node is greater than lratio*min length of any edge
                            attached, then goto remesh without attempting morph */
   DOUBLE minmetric,     /* for rmshky=0: if during morphing the quality of any
                            element drops below minmetric then goto remesh */
   INT debug,            /* debug flag */
   INT detached,         /* model is detached from solid (elements only)
                            if TRUE then send in array of element ids in a_areas */
   INT *p_abort );       /* user abort flag */

                         /*=====================================================*/
                         /* === FEMa_moMorph3D: 3D morphing and remeshing       */
                         /*=====================================================*/
INT  FEMa_moMorph3D(
   INT *a_vols,          /* list of volumes to perform morphing (if detached, then
                            this is the array of elements) */
   INT num_vols,         /* number of volumes (or numelems if detached) */
   INT *a_snodes,        /* list of structural nodes */
   INT num_snodes,       /* number of structural nodes */
   DOUBLE *a_disp,       /* displacement of structural nodes */
   INT *a_ns_nodes,      /* list of non-structural nodes on boundary
                            that can move */
   INT num_nsnodes,      /* number of non-structural nodes */
   INT rmskky,           /* remesh flag option (0=1st try morph then remesh if morph
                            fails. 1=Remesh only. 2=Morph only) */
   DOUBLE lratio,        /* for rmskky=0: if any specified displacement at a
                            node is greater than lratio*min length of any edge
                            attached, then goto remesh without attempting morph */
   DOUBLE minmetric,     /* for rmshky=0: if during morphing the quality of any
                            element drops below minmetric then goto remesh */
   INT debug,            /* debug flag */
   INT detached,         /* model is detached from solid (elements only)
                            if TRUE then send in array of element ids in a_vols */
   INT *p_abort );       /* uaer abort flag */



                         /*=====================================================*/
                         /* === FEMa_ALE_Morph2D: 2D morphing only              */
                         /*=====================================================*/
INT FEMa_ALE_Morph2D(
   INT    num_nodes,     /* (IN) number of nodes */
   DOUBLE *a_coord,      /* (IN/OUT) current node coodinates (3*num_nodes) */
   INT    num_disp_nodes,/* (IN) number of displaced nodes */
   INT    *a_disp_nodes, /* (IN) list of displaced nodes  (num_disp_nodes) */
   DOUBLE *a_disp,       /* (IN/OUT) displacement for each node (3*num_nodes) */
   INT    debug,
   INT    *error );      /* (OUT) error flag */


                         /*=====================================================*/
                         /* === FEMa_ALE_Morph2D_Setup: setup for 2D morphing   */
                         /*=====================================================*/
INT FEMa_ALE_Morph2D_Setup(
   INT    num_nodes,     /* (IN) number of nodes */
   DOUBLE *a_coord,      /* (IN) current node coodinates (3*num_nodes) */
   INT    *a_geo_assoc,  /* (IN) geometry associativity  (num_nodes) */
   INT    *a_geo_types,  /* (IN) geometry type 1=key point, 2=line, 3=area (num_nodes) */
   INT    num_elements,  /* (IN) number of elements */
   INT    node_per_elem, /* (IN) number nodes per element */
   INT    *a_elements,   /* (IN) element list (node_per_elem, num_elements) */
   INT    *a_elem_shape, /* (IN) element shape (num_elements) */
   INT    num_disp_nodes,/* (IN) number of displaced nodes */
   INT    *error );      /* (OUT) error flag */

                         /*=====================================================*/
                         /* === FEMa_ALE_Morph_Done: terminate morphing process */
                         /*=====================================================*/
INT FEMa_ALE_Morph_Done();

                         /*=====================================================*/
                         /* === FEMa_ALE_Morph3D_Setup: setup for 3D morphing   */
                         /*=====================================================*/
INT FEMa_ALE_Morph3D_Setup(
   INT    num_nodes,     /* (IN) number of nodes */
   DOUBLE *a_coord,      /* (IN) current node coodinates (3*num_nodes) */
   INT    *a_geo_assoc,  /* (IN) geometry associativity  (num_nodes) */
   INT    *a_geo_types,  /* (IN) geometry type 1=key point, 2=line, 3=area (num_nodes) */
   INT    num_elements,  /* (IN) number of elements */
   INT    node_per_elem, /* (IN) number nodes per element */
   INT    *a_elements,   /* (IN) element list (node_per_elem, num_elements) */
   INT    *a_elem_shape, /* (IN) element shape (num_elements) */
   INT    num_disp_nodes,/* (IN) number of displaced nodes */
   INT    *error );      /* (OUT) error flag */


                         /*=====================================================*/
                         /* === FEMa_ALE_Morph3D: 3D morphing only              */
                         /*=====================================================*/
INT FEMa_ALE_Morph3D(
   INT    num_nodes,     /* (IN) number of nodes */
   DOUBLE *a_coord,      /* (IN/OUT) current node coodinates (3*num_nodes) */
   INT    num_disp_nodes,/* (IN) number of displaced nodes */
   INT    *a_disp_nodes, /* (IN) list of displaced nodes  (num_disp_nodes) */
   DOUBLE *a_disp,       /* (IN/OUT) displacement for each node (3*num_nodes) */
   INT    debug,
   INT    *error );      /* (OUT) error flag */


#endif

