/* sid 60.4 copy of CPrivEvalProcess.h last changed by smarguer on 2006/07/20 08:12:28 */
/*******************************************************************************
 *
 *   CPrivEvalProcess.h -- 
 *              
 * |Module: SolutionXplorer
 *
 * |Description: 
 *        
 * |Auteur: Stephane MARGUERIN
 *
 * |Creation: Avril 2002
 *
 *
 * |Copyright:	copyright(c) 2006 SAS IP, Inc.  All rights reserved.
 *
 *   
 ******************************************************************************/
#ifndef __CPrivEvalProcess_h__ 
#define __CPrivEvalProcess_h__ 1 


#include "cadoe.h"
#include "liste_chainee.h"
#include "adoc.h"
#include "sx_CADOE_solver.h"
#include "sx_postTraitement.h"
#include "ADOC_FctApp.h"
#include "C_AdocDriver.h"
#include "CEvalProcess.h"

#include "CCadoePortable.h"

#include "CPrivSolutionXplorer.h"
#include "CParameterMgr.h"
#include "TessaletedEvaluation.h"




class CPrivEvalProcess : public CEvalProcess
{
 public:
  
  typedef map <string,CDirection*> DirectionMap;
  typedef list <CDirection*> DirectionList;
  
  CPrivEvalProcess( const CEvalProcess::PostType postType, CPrivSolutionXplorer *psxp );
  ~CPrivEvalProcess();

  int getId(void) const { return _id; }

  CSolutionXplorer* getParentSolutionXplorer(void) const { return static_cast<CSolutionXplorer*>(_psxp); }

  // criteres
  const CCritInfo::CritInfoList& getCritInfoList( void ) const;
  int getCritInfoVector( CCritInfo::CritInfoVector& vec ) const;
  bool getCriterionIfAvailable( CCriterion::Code code, CCriterion &crit ) const;
  int selectCriterion( CCriterion &crit );
  void deselectCriterion( int critId );
  void deselectCriterion( CCriterion &crit );

	
  // Directions
  int selectDirection( CDirection*,  CEvalProcess::Axis axis=CEvalProcess::AXIS_X );
  void deselectDirection( CDirection *drt );
  CDirection* getDirection( const string &name ) const;
 
  /* deselect all criteria and directions */
  void deselectAll( void );

  int setDesignSet( string dirName, double *paramValues );
  int setDesignSet( int dirId, double *paramValues );


  void normalizeParamX(  bool norm=true )   { _normParamX=norm; }
  void normalizeParamY(  bool norm=true )   { _normParamY=norm; }
  void normalizeResults(  bool norm=true )  { _normCrit=norm; }
  void setEvaluateAccuracy(  bool eval=false ) { _evalAccuracy=eval; }

  void setNumberOfSteps( int nbXSteps=0, int nbYSteps=0 );
  void setTessaletionError( double Error=0.01 ) { _tessaletion_error=Error; }
  void setTessaletionFlag( bool tesal=true ) { _tessaletion_flag = tesal;}
  double getTessaletionError( void ) { return _tessaletion_error;}
  void setGoal(OptGoal goal);
  void setGlobalAccuracy(double acc) { _precision = acc; }
  void setMethOpt(OptMethod meth_opt);
  void setNbEval(int nb) { _nb_eval = nb; }
  void setPenalty(double ip,double mp,double pc) {_init_penalty=ip;_max_penalty=mp;_penalty_coef=pc;}
  void setLineSearchStep(double lss) {_line_search_step = lss;}
  
  int evaluate( CEvalResults &res );
  int initEvaluate(void);
  int endEvaluate(const string &fctname="");
  int evalDesignSet( CDesignSet &set );
  int evalDesignSetList( list<CDesignSet> &setList );
  int evalCurve( CEvalResults &res );
  
  int evalSurface( list<CDesignSet*> &setList, double accuracy, double dxMin, double dyMin) {return 0;}
  
  int evalContour( CEvalResultsField &res );
  int evalContour( CDesignSet &set, CEvalResultsField &res );
  int evalContour( list<CDesignSet> &setList, CEvalResultsField &res );
  
  int evalSampleMatrix(int numPoints, int numInputs, int numOutputs, double** ppdInputMatrix, double** ppdOutputMatrix);
  int dumpSeriesExpansion( string SeriesExpansionFilename, string DescriptionFilename, bool verbose );
  int writeMorphedMesh( FILE *fp, CEvalResultsField &res, int iRes, int criterionId, int Node );

  virtual bool canNormalizeResults() { return _normCritOk; }
	
  // evaluates all the criteria for the current parameter values
  // output vector dim = nbCrit
  // rq: current values defaults to initialValue and can be set with setParamValue()
  // int evalPerturb( int step, double *xyz )  { return 0; } // 3*nb_nodes
  
  
  void printDirections(void) const;
  void printCriteria( const FILE *fic=stdout, const bool withLimit=false ) const;
  
  void setAdocOption( const char *optionName, int value );
  void setAdocOption( const char *optionName, double value );
  void setAdocOption( const char *optionName, const char *optionValue ) {_adocOptions[optionName] = optionValue;}

  int getNumberOfSelectedCriteria(void);

 private:
  CPrivEvalProcess( const CPrivEvalProcess &proc );
  CPrivEvalProcess& operator =( const CPrivEvalProcess &proc);
  
  
  int buildCriteriaList(void);
  
  bool criterionIsAvailable( T_tableau_resultat *res ) const;
  void deleteSolutionVector(void) { if (_solution) V_FREE(_solution); }
  void zeroVecParam(void);
  
  int readPolynomial(void);
  int designSet2VecParam( CDesignSet& set );
  int calculerVecParam( void );
  int calculerDesignSet( CDesignSet &set );
  int calculerDesignSetEtMappe( CDesignSet &set, CEvalResultsField &res, int *cpt, int iRes );
  int calculerRefSets( bool *normalize );
  
  
  int evalCurrentPoint( CEvalResults &res );
  int evalHistogram( CEvalResults &res );
  int evalOptimization( CEvalResults &res );
  int evalTolerance( CEvalResults &res );
  int evalHandBook( CEvalResults &res );
  
  static	int	_idGenerator;
  int			_id;
  
  CEvalProcess::PostType	_postType; // curve, histo, contour...
  C_AdocDriver                  *_adocDriver;
  T_modele*			_modele;		// modele 
  PAR*				_par;				// objet par adoc en representation interne
  PAR*				_parUser;	// objet par adoc en representation interne
  map<string,int>	        _parIndName; // correspondance nom de parametre - indice dans le par
  int				_nbDirectX;
  int				_nbDirectY;
  int				_nbXSteps;
  int				_nbYSteps;
  bool				_normParamX;
  bool				_normParamY;
  bool				_normCrit;
  bool				_evalAccuracy;
  int				_numBlocks; // results size as a number of results blocks
  CCritInfo::CritInfoList	_avCritList; // current list of the available criteria
  T_ltete*			_lcrit;	// list of criteria to evaluate
  VEC*				_vec_param;
  T_res_cas_charge*		_res_cas;
  CPrivSolutionXplorer*		_psxp; // parent SolutionXplorer
  CParameterMgr*		_pmgr;
  DirectionMap			_directions;
  DirectionList                 _directlist;
  
  VEC*				_solution;
  BVEC*				_tabi; 
  IVEC*                         _a_evaluer;  // list the modes/frequencies to be evaluated
  VSTRUCT*                      _lesmodes;
  VEC*                          _freq;
  double			_precision; // returned precision for a given evaluation
  E_goal			_goal;
  E_meth_opt			_meth_opt;
  int				_nb_eval;
  double			_init_penalty;
  double			_max_penalty;
  double			_penalty_coef;
  double			_line_search_step;
  bool				_normCritOk;
  double                        _tessaletion_error;
  bool                          _tessaletion_flag;
  C_Tess*			_tess;

  map<string,string> 		_adocOptions;

  bool				_bUseCache;
  CParameterMgr::ParamVector		_vPar;
};	

#endif
