/* sid 60.1 copy of FEM_interp.h last changed by upd111 on 2005/07/21 19:40:17 */
/*  FEM_interp.h */
/*
 * *** ansys(r) copyright(c) 1999
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_interp.h
 *  header file for FEM_interp.c
 *
 */
#ifndef FEM_INTERP_INCLUDE
#define FEM_INTERP_INCLUDE

#include "FEM_delaunay.h"


typedef enum {INTERP_LINEAR,
              INTERP_NATNEIGH} INTERP_METHOD_ENUM;

/* === Structure for interpolation (for each node) */

typedef struct INTERP_NODE_TYP *INTERP_NODE_PTYP;
typedef struct INTERP_NODE_TYP{
   INT flag;              /* visted flag */
   DOUBLE weight;         /* weight at node */
   DOUBLE fx,fy;          /* function gradient at node */
   DOUBLE a11,a12,a22;    /* anisotropic tensor coefficients (a21 = a12)*/
} INTERP_NODE_TYP;

/*----------------- Globally accessible function prototypes -----------------*/

#ifdef __cplusplus
extern "C" {
#endif

                             /* === FEM_inSetInterpMethod: set the current   */
                             /* === interpolation method                     */
void FEM_inSetInterpMethod (
   INTERP_METHOD_ENUM method  );

                             /* === FEM_inInterpMethod: get the current      */
                             /* === interpolation method                     */
INTERP_METHOD_ENUM FEM_inInterpMethod ( void  );

                             /* === FEM_inNaturalNeighbor: interpolate using */
                             /* === natural neighbor interpolation           */
DOUBLE FEM_inNaturalNeighbor (
   DOUBLE x, DOUBLE y  );              /* point to interpolate               */

                             /* === FEM_inNaturalNeighbor2: same as          */
                             /* === FEM_inNaturalNeighbor except returns     */
                             /* === interpolated gradient vector             */
DOUBLE FEM_inNaturalNeighbor2 (
   DOUBLE x, DOUBLE y,                 /* point to interpolate               */
   DOUBLE *p_dfdx, DOUBLE *p_dfdy  );  /* interpolated gradient vector       */

                             /* === FEM_inNaturalNeighbor3: same as          */
                             /* === FEM_inNaturalNeighbor except returns     */
                             /* === interpolated anisotropy coefficients     */

DOUBLE FEM_inNaturalNeighbor3 (
   DOUBLE x, DOUBLE y,                 /* point to interpolate               */
   DOUBLE *p_a11, DOUBLE *p_a12,       /* interpolated gradient vector       */
   DOUBLE *p_a22  );

                             /* === FEM_inInterpNaturalNeighbor: interpolate */
                             /* === using natural neighbor interpolation     */
                             /* === same as FEM_inNaturalNeighbor, but must  */
                             /* === pass in list of tris whose ccirc contain */
                             /* === the point                                */
DOUBLE FEM_inInterpNaturalNeighbor (
   DOUBLE x, DOUBLE y,                 /* point to interpolate               */
   FACE_OBJ *aobj_neightri,            /* array of neighbor tris             */
   INT num_neightri,                   /* number of natural neighbor tris in */
                                       /* aobj_neightri                      */
   MESH_ENTITY_ENUM entity_type,       /* type of entity where node located  */
   ADDRESS_TYP obj_entity  );          /* node, edge or face where node is   */
                                       /* located                            */

                             /* === FEM_inInterpNaturalNeighbor2: same as    */
                             /* === FEM_inInterpNaturalNeighbor except       */
                             /* === interpolated gradient                    */
DOUBLE FEM_inInterpNaturalNeighbor2 (
   DOUBLE x, DOUBLE y,                 /* point to interpolate               */
   FACE_OBJ *aobj_neightri,            /* array of neighbor tris             */
   INT num_neightri,                   /* number of natural neighbor tris in */
                                       /* aobj_neightri                      */
   MESH_ENTITY_ENUM entity_type,       /* type of entity where node located  */
   ADDRESS_TYP obj_entity,             /* node, edge or face where node is   */
                                       /* located                            */
   DOUBLE *p_dfdx,                     /* interpolated gradient vector       */
   DOUBLE *p_dfdy  );                

                             /* === FEM_inInterpNaturalNeighbor3: same as    */
                             /* === FEM_inInterpNaturalNeighbor except       */
                             /* === interpolated anisotropy coefficients     */
DOUBLE FEM_inInterpNaturalNeighbor3 (
   DOUBLE x, DOUBLE y,                 /* point to interpolate               */
   FACE_OBJ *aobj_neightri,            /* array of neighbor tris             */
   INT num_neightri,                   /* number of natural neighbor tris in */
                                       /* aobj_neightri                      */
   MESH_ENTITY_ENUM entity_type,       /* type of entity where node located  */
   ADDRESS_TYP obj_entity,             /* node, edge or face where node is   */
                                       /* located                            */
   DOUBLE *p_a11,                      /* interpolated anisotropy coefficient*/
   DOUBLE *p_a12,
   DOUBLE *p_a22  );


INT FEM_inTest ( CHAR *fname  );
INT FEM_inTestR ( CHAR *fname  );

                             /* === FEM_inGradient: interpolate the gradient */
                             /* === at a node. (Uses least squares and IDW   */
                             /* === interpolation for weights)               */
INT FEM_inGradient (
   NODE_OBJ obj_node,                  /* the node                           */
   FACE_OBJ *aobj_neightri,            /* array of neighbor tris             */
   INT num_neightri,                   /* number of natural neighbor tris in */
                                       /* aobj_neightri                      */
   DOUBLE *p_fx, 
   DOUBLE *p_fy  );                    /* return gradient at the node        */

                             /* === FEM_inIDWatNode: do an inverse distance  */
                             /* === weighted interpolation using gradient    */
                             /* === planes at a node (ignore node scalar     */
                             /* === value). Don't allow a gradient in x or y */
                             /* === greater than maxgrad. Gradients at       */
                             /* === neighbor nodes will be truncated.        */
DOUBLE FEM_inIDWatNode (
   NODE_OBJ obj_node,                  /* the node                           */
   DOUBLE maxgrad,                     /* don't allow any gradient to exceed */
   FACE_OBJ *aobj_neightri,            /* array of neighbor tris             */
   INT num_neightri  );                /* number of natural neighbor tris in */
                                       /* aobj_neightri                      */

                             /* === FEM_inNewInterpNode: return pointer to   */
                             /* === interp-node structure.  handle all       */
                             /* === allocation, reallocation                 */
INTERP_NODE_PTYP FEM_inNewInterpNode ( void  );

                             /* === FEM_inDeleteInterpNode: free a interpnode*/
                             /* === by placing it back on the available      */
                             /* === interpnode stack                         */
void FEM_inDeleteInterpNode (
   INTERP_NODE_PTYP p_interpnode  );   /* address of interpnode to be freed  */

                             /* === FEM_inDeleteAllInterNode: get rid of any */
                             /* === interpnode structures that remain        */
INT FEM_inDeleteAllInterpNode ( void  );

                             /* === FEM_inInterp: interpolate a scalar       */
                             /* === function value from a set of scalars     */
                             /* === stored at the nodes of a Delaunay 2D     */
                             /* === mesh.  (Must have been initialized with  */
                             /* === function FEM_delaunay).                  */
                             /* === Return: DOUBLE interpolated value.       */
DOUBLE FEM_inInterp (
   DOUBLE x,                /* location of point to be interpolated */
   DOUBLE y  );

                             /* === FEM_inInterp2: same as FEM_inInterp but  */
                             /* === also returns an interpolated gradient    */
                             /* === vector at the node                       */
                             /* === Return: DOUBLE interpolated value.       */
DOUBLE FEM_inInterp2 (
   DOUBLE x,                          /* location of point to be interpolated*/
   DOUBLE y,
   DOUBLE *p_dfdx,                    /* return interpolated gradient vector */
   DOUBLE *p_dfdy  );

                             /* === FEM_inInterp2: same as FEM_inInterp but  */
                             /* === also returns the interpolated anisoropy  */
                             /* === coefficents at the node                  */
                             /* === Return: DOUBLE interpolated value.       */
DOUBLE FEM_inInterp3 (
   DOUBLE x,                          /* location of point to be interpolated*/
   DOUBLE y,
   DOUBLE *p_a11,                     /* return interpolated aniso coeffic.  */
   DOUBLE *p_a12,       
   DOUBLE *p_a22  );   


                             /* === Set the mesh object that will be used    */
                             /* === for all interpolation operations         */
void FEM_inSetInterpMesh (
   MESH_OBJ obj_interpmesh  );

                             /* === FEM_inLinear: interpolate                */
                             /* === using linear interpolation               */
DOUBLE FEM_inLinear ( DOUBLE x,
                               DOUBLE y  );
                             /* === FEM_inLinear3: interpolate               */
                             /* === using linear interpolation               */
                             /* === also interpolate anistropy metric        */
DOUBLE FEM_inLinear3 ( DOUBLE x,
                                DOUBLE y,
                                DOUBLE *p_a11,
                                DOUBLE *p_a12,
                                DOUBLE *p_a22  );

MESH_OBJ FEM_inGetInterpMesh ( );
#ifdef __cplusplus
}
#endif




#endif
