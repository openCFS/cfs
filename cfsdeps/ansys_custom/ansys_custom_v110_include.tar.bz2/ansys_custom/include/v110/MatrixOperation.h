/* sid 60.1 copy of MatrixOperation.h last changed by upd111 on 2006/10/09 19:56:39 */
////////////////////////////////////////////////////////////////////////////
//                                                                        //
//          Copyright (C) 2001 ANSYS Inc.  All Rights Reserved            //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MatrixOperation.h $
// $Revision$
// $Date$
// $Author$
//
// Decription:
//
// Header file for matrix operations.
////////////////////////////////////////////////////////////////////////////


#ifndef __MatrixOperation_H__
#define __MatrixOperation_H__

//======================================================================================//
//                                      MatrixOperation                                        //
//======================================================================================//
// DESCRIPTION:                                                                          
//                                                                                      
// Basic matrix operations. Contains addition, multiplication, scaling, transpose,                
// L2 norm and row and column switch methods. Protected methods are provided for 
// sanity checks on the matrix bounds for addition and multiplication.
//                                                                                 
// PARENTS:                                                                             
//
// CONTENTS:                                                                             
//======================================================================================//

typedef class MatrixOperation
{
    public:

        // Lifecycle
        // ---------

        // constructor
        MatrixOperation( );

        // destructor
        virtual ~MatrixOperation( );

        // Operations
        // ----------

        // addition methods
        // ================

        int Add( const Matrix &, const Matrix &, Matrix & );

        int Add( const SqrMatrix &, const SqrMatrix &, SqrMatrix & );
        int Add( const SqrMatrix &, const SymMatrix &, SqrMatrix & );
        int Add( const SqrMatrix &, const LowerMatrix &, SqrMatrix & );
        int Add( const SqrMatrix &, const UpperMatrix &, SqrMatrix & );
        int Add( const SqrMatrix &, const DiaMatrix &, SqrMatrix & );
        
        int Add( const SymMatrix &, const SymMatrix &, SymMatrix & );
        int Add( const SymMatrix &, const SqrMatrix &, SqrMatrix & );
        int Add( const SymMatrix &, const LowerMatrix &, SqrMatrix & );
        int Add( const SymMatrix &, const UpperMatrix &, SqrMatrix & );
        int Add( const SymMatrix &, const DiaMatrix &, SymMatrix & );
        
        int Add( const LowerMatrix &, const LowerMatrix &, LowerMatrix & );
        int Add( const LowerMatrix &, const SqrMatrix &, SqrMatrix & );
        int Add( const LowerMatrix &, const SymMatrix &, SqrMatrix & );
        int Add( const LowerMatrix &, const UpperMatrix &, SqrMatrix & );
        int Add( const LowerMatrix &, const DiaMatrix &, LowerMatrix & );

        int Add( const UpperMatrix &, const UpperMatrix &, UpperMatrix & );
        int Add( const UpperMatrix &, const SqrMatrix &, SqrMatrix & );
        int Add( const UpperMatrix &, const SymMatrix &, SqrMatrix & );
        int Add( const UpperMatrix &, const DiaMatrix &, UpperMatrix & );
        
        int Add( const DiaMatrix &, const DiaMatrix &, DiaMatrix & );
        int Add( const DiaMatrix &, const SqrMatrix &, SqrMatrix & );
        int Add( const DiaMatrix &, const SymMatrix &, SymMatrix & );
        int Add( const DiaMatrix &, const LowerMatrix &, LowerMatrix & );
        int Add( const DiaMatrix &, const UpperMatrix &, UpperMatrix & );
        
        int Add( const RowVector &, const RowVector &, RowVector & );
        
        int Add( const ColVector &, const ColVector &, ColVector & );

        // multiplication methods
        // ======================

        int Mult( const Matrix &, const Matrix &, Matrix & );
        int Mult( const Matrix &, const SqrMatrix &, Matrix & );
        int Mult( const Matrix &, const SymMatrix &, Matrix & );
        int Mult( const Matrix &, const LowerMatrix &, Matrix & );
        int Mult( const Matrix &, const UpperMatrix &, Matrix & );
        int Mult( const Matrix &, const DiaMatrix &, Matrix & );
        int Mult( const Matrix &, const ColVector &, ColVector & );

        int Mult( const SqrMatrix &, const SqrMatrix &, SqrMatrix & );
        int Mult( const SqrMatrix &, const Matrix &, Matrix & );
        int Mult( const SqrMatrix &, const SymMatrix &, SqrMatrix & );
        int Mult( const SqrMatrix &, const LowerMatrix &, SqrMatrix & );
        int Mult( const SqrMatrix &, const UpperMatrix &, SqrMatrix & );
        int Mult( const SqrMatrix &, const DiaMatrix &, SqrMatrix & );
        int Mult( const SqrMatrix &, const ColVector &, ColVector & );

        int Mult( const SymMatrix &, const SymMatrix &, SymMatrix & );
        int Mult( const SymMatrix &, const Matrix &, Matrix & );
        int Mult( const SymMatrix &, const SqrMatrix &, SqrMatrix & );
        int Mult( const SymMatrix &, const LowerMatrix &, SqrMatrix & );
        int Mult( const SymMatrix &, const UpperMatrix &, SqrMatrix & );
        int Mult( const SymMatrix &, const DiaMatrix &, SqrMatrix & );
        int Mult( const SymMatrix &, const ColVector &, ColVector & );

        int Mult( const LowerMatrix &, const LowerMatrix &, LowerMatrix & );
        int Mult( const LowerMatrix &, const Matrix &, Matrix & );
        int Mult( const LowerMatrix &, const SqrMatrix &, SqrMatrix & );
        int Mult( const LowerMatrix &, const SymMatrix &, SqrMatrix & );
        int Mult( const LowerMatrix &, const UpperMatrix &, SqrMatrix & );
        int Mult( const LowerMatrix &, const DiaMatrix &, LowerMatrix & );
        int Mult( const LowerMatrix &, const ColVector &, ColVector & );

        int Mult( const UpperMatrix &, const UpperMatrix &, UpperMatrix & );
        int Mult( const UpperMatrix &, const Matrix &, Matrix & );
        int Mult( const UpperMatrix &, const SqrMatrix &, SqrMatrix & );
        int Mult( const UpperMatrix &, const SymMatrix &, SqrMatrix & );
        int Mult( const UpperMatrix &, const LowerMatrix &, SqrMatrix & );
        int Mult( const UpperMatrix &, const DiaMatrix &, UpperMatrix & );
        int Mult( const UpperMatrix &, const ColVector &, ColVector & );
         
 
        int Mult( const DiaMatrix &, const DiaMatrix &, DiaMatrix & );
        int Mult( const DiaMatrix &, const Matrix &, Matrix & );
        int Mult( const DiaMatrix &, const SqrMatrix &, SqrMatrix & );
        int Mult( const DiaMatrix &, const SymMatrix &, SqrMatrix & );
        int Mult( const DiaMatrix &, const LowerMatrix &, LowerMatrix & );
        int Mult( const DiaMatrix &, const UpperMatrix &, UpperMatrix & );
        int Mult( const DiaMatrix &, const ColVector &, ColVector & );

        int Mult( const RowVector &, const Matrix &, RowVector & );
        int Mult( const RowVector &, const SqrMatrix &, RowVector & );
        int Mult( const RowVector &, const SymMatrix &, RowVector & );
        int Mult( const RowVector &, const LowerMatrix &, RowVector & );
        int Mult( const RowVector &, const UpperMatrix &, RowVector & );
        int Mult( const RowVector &, const DiaMatrix &, RowVector & );
        int Mult( const RowVector &, const ColVector &, double & );

        int Mult( const ColVector &, const RowVector &, Matrix & ); 

        // transpose methods 
        // =================

        int Transp( const Matrix &, Matrix & );

        int Transp( const SqrMatrix &, SqrMatrix & );

        int Transp( const LowerMatrix &, UpperMatrix & );

        int Transp( const UpperMatrix &, LowerMatrix & );

        int Transp( const RowVector &, ColVector & );

        int Transp( const ColVector &, RowVector & );

        // transpose multiplication methods
        // ================================

        int TranspMult( const Matrix & , SymMatrix & );

        int TranspMult( const SqrMatrix & , SymMatrix & );

        int TranspMult( const SymMatrix &, SymMatrix & );

        int TranspMult( const LowerMatrix &, SymMatrix & );

        int TranspMult( const UpperMatrix &, SymMatrix & );

        int TranspMult( const DiaMatrix &, DiaMatrix & );

        int TranspMult( const RowVector & , SymMatrix &);

        int TranspMult( const ColVector &, double & );
        
        // row switch (writes new matrix) methods
        // ======================================

        int RowSwitch( const Matrix &, const int &, const int &, Matrix & );
        int RowSwitch( const int &, const int &, Matrix & );

        int RowSwitch( const SqrMatrix &, const int &, const int &, SqrMatrix & );
        int RowSwitch( const int &, const int &, SqrMatrix & );

        int RowSwitch( const ColVector &, const int &, const int &, ColVector & );
        int RowSwitch( const int &, const int &, ColVector & );

        // column switch (writes new matrix) methods
        // =========================================

        int ColSwitch( const Matrix &, const int &, const int &, Matrix & );
        int ColSwitch( const int &, const int &, Matrix & );

        int ColSwitch( const SqrMatrix &, const int &, const int &, SqrMatrix & );
        int ColSwitch( const int &, const int &, SqrMatrix & );

        int ColSwitch( const RowVector &, const int &, const int &, RowVector & );
        int ColSwitch( const int &, const int &, RowVector & );

        // scaling methods
        // ===============

		int Scale( const Matrix &, const double &, Matrix & );
		int Scale( const double &, Matrix & );

		int Scale( const SqrMatrix &, const double &, SqrMatrix & );
        int Scale( const double &, SqrMatrix & );

		int Scale( const SymMatrix &, const double &, SymMatrix & );
        int Scale( const double &, SymMatrix & );

        int Scale( const LowerMatrix &, const double &, LowerMatrix & );
        int Scale( const double &, LowerMatrix & );

        int Scale( const UpperMatrix &, const double &, UpperMatrix & );
        int Scale( const double &, UpperMatrix & );

		int Scale( const DiaMatrix &, const double &, DiaMatrix & );
        int Scale( const double &, DiaMatrix & );

		int Scale( const RowVector &, const double &, RowVector & );
        int Scale( const double &, RowVector & );

		int Scale( const ColVector &, const double &, ColVector & );
        int Scale( const double &, ColVector & );

        // inversion and matrix solution methods
        // =====================================

        // perform Choleski Decomposition of a symmetry matrix
        int CholeskiDecomp( const SymMatrix &, LowerMatrix & );

        // solve linear equations using forward and backward substitutions, with Choleski
        // ------------------------------------------------------------------------------
        // Decomposition matrix
        // --------------------

        // for only one right hand side vector
        int CholeskiFwdBwdSubst( const LowerMatrix &, const ColVector &, ColVector & );

        // multiple right hand side vector, as a matrix
        int CholeskiFwdBwdSubst( const LowerMatrix &, const Matrix &, Matrix & );

        // solve linear equations using Choleski Decomposition
        // ---------------------------------------------------
        
        // for only one right hand side vector
        int CholeskiSolve( const SymMatrix &, const ColVector &, ColVector & );

        // multiple right hand side vector, as a matrix
        int CholeskiSolve( const SymMatrix &, const Matrix &, Matrix & );

    protected:

        // protected member functions
        // --------------------------

		// sanity check on bounds of matrices for addition
        int CheckAdd( const Matrix *, const Matrix *, const Matrix * );

        // sanity check on bounds of matrices for multiplication
        int CheckMult( const Matrix *, const Matrix *, const Matrix * );

		// sanity check on bounds of matrices for transpose
        int CheckTransp( const Matrix *, const Matrix * );

        // sanity check on bounds of matrices for transpose multiplication
        int CheckTranspMult( const Matrix *, const Matrix * );

        // sanity check on bounds of matrices for switch row operation
        int CheckRowSwitch( const Matrix *, const int &, const int &, const Matrix * );
        int CheckRowSwitch( const int &, const int &, const Matrix * );

		// sanity check on bounds of matrices for switch column operation
        int CheckColSwitch( const Matrix *, const int &, const int &, const Matrix * );
        int CheckColSwitch( const int &, const int &, const Matrix * );

		// sanity check on bounds of matrices for scale operation
        int CheckScale( const Matrix *, const Matrix * );
        int CheckScale( const Matrix * );
    
    private:

        // no private data member
        // ----------------------

}MatrixOperation;

# endif
