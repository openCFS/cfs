/* sid 60.1 copy of FEM_surfCurv.h last changed by upd111 on 2005/07/21 19:41:37 */
/*  FEM_surfCurv.h */
/*
 * *** ansys(r) copyright(c) 1999
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_surfCurv.h
 *  header file for FEM_bgmesh.c
 *
 */
#ifndef FEM_SURFCURV_INCLUDE
#define FEM_SURFCURV_INCLUDE

                              /* === FEM_surfCurv: refine elements based on    */
                              /* === the curvature of the geometry             */
INT FEM_surfCurv (
   INT anum,                           /* the area number                      */
   DOUBLE maxang,                      /* the maximum spanning angle (radians) */
                                       /* for any single edge                  */
   INT shc,                            /* small hole coarsening flag           */
   DOUBLE shc_maxang,                  /* max angle for small hole coarsening  */
   DOUBLE shc_minratio,                /* small hole coarsening: min ratio     */
                                       /* between largest to smallest edge at  */
                                       /* which shc will take effect           */
   DOUBLE shc_maxratio,                /* small hole coarsening: max ratio     */
                                       /* between largest to smallest edge     */
                                       /* that sizes will no longer be         */
                                       /* coarsened (use shc_maxang)           */
   DOUBLE maxEsize,                    /* maximum element size                 */
   DOUBLE minEsize,                    /* minimum element size                 */
   INT quadmesh,                       /* flag - currently quad meshing        */
   DOUBLE quadfactor,                  /* factor to increase elems by if       */
                                       /* quad meshing                         */
   INT stretch,                        /* 1 = refine only in direction of curv */
                                       /* 0 = refine uniformly in all          */
                                       /* directions based on max curvature    */
   INT *p_edge_split  );               /* return whether any changes made      */

#endif
