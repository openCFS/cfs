/* sid 60.1 copy of ansETypetypes.h last changed by upd111 on 2006/10/09 19:57:12 */

#include "ansysdef.h"

/****************************************************************
 global-level structure for ANSYS element type characteristics
 ****************************************************************/
struct ansEType_str {               /* Name of the structure                                         */
  INT         tag;                  /* Tag for this instance of the element type structure           */
  INT         numDef;               /* Number of defined element types in this structure             */
  INT         maxDef;               /* Maximum number of defined element types in this structure     */
  INT         maxSize;              /* Maximum number of characteristics stored for any element type */
  INT        *Internal_to_External; /* Mapping vector for global internal to global external         */
  INT        *External_to_Internal; /* Mapping vector for global external to global internal         */ 
  etypeData  *dataVec;              /* Array of element type characteristics                         */
};

#define ansETypeTag(typ)                (typ->tag)
#define ansETypeNumDef(typ)             (typ->numDef)
#define ansETypeMaxDef(typ)             (typ->maxDef)
#define ansETypeMaxSize(typ)            (typ->maxSize)

#define ansETypeInt2ExtPtr(typ)         (typ->Internal_to_External)
#define ansETypeInt2ExtVec(typ,i)       (typ->Internal_to_External[i])
#define ansETypeExt2IntPtr(typ)         (typ->External_to_Internal)
#define ansETypeExt2IntVec(typ,i)       (typ->External_to_Internal[i])

#define ansETypeDataPtr(typ)            (typ->dataVec)
#define ansETypeDataVec(typ,i)          (typ->dataVec+i)



/******************************************************************
 data-level structure for ANSYS element type characteristics
 ******************************************************************/
struct etypeData_str {  /* Name of the structure                                           */
  char     modified;    /* Flag indicating whether this element type has been modified     */
  char     internal;    /* Flag indicating whether this element type is internal to object */
  INT      size;        /* Number of characteristics stored for this element type          */
  INT     *ielc;        /* Array of element type characteristics for this element type     */
};

#define etypeDataModified(tData)         (tData->modified)
#define etypeDataInternal(tData)         (tData->internal)
#define etypeDataSize(tData)             (tData->size)

#define etypeDataIelcPtr(tData)          (tData->ielc)
#define etypeDataIelcVec(tData,i)        (tData->ielc[i])

