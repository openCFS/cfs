/* sid 60.1 copy of fem_cleanPriv.h last changed by upd111 on 2005/07/21 19:42:04 */
/*  FEM_clean.h */
/* 
 * *** ansys(r) copyright(c) 1999
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  fem_cleanPriv.h
 *  header file for FEM_clean.c
 *
 */
#ifndef FEM_CLEANPRIV_INCLUDE
#define FEM_CLEANPRIV_INCLUDE

/* --- Define structures used only by clean up routines.  --- */

typedef struct {  /* used to store info in generic pointer of angle */
                  /* at boundary nodes                              */
   INT node_angle;  /* angle at node in degrees */
} NODE_CLEANUP_INFO;

/* --- Constants used only by cleanup routines. --- */
#define TRI_CLEANUP     3
#define QUADTRI_CLEANUP 4
#define QUAD_CLEANUP    5

/* === constants for error handling */

#define CLN_ALREADY_INITIALIZED 1

/*----------------- Globally accessible function prototypes -----------------*/

                               /* ========================================== */
                               /* === FEM_clInitCleanUp: Set up stuff in     */
                               /* === preparation for doing either tri or    */
                               /* === quad/tri clean up.                     */
INT FEM_clInitCleanUp (
   INT area,                   /* the area that will be cleaned up           */
   INT shape  );               /* shape that cleanup should be initialized to*/
                               /* cleanup.  3 for tri cleanup, 4 for quad/tri*/
                               /* cleanup.                                   */

                               /* ========================================== */
                               /* === FEM_clFinishCleanUp: Clean up stuff    */
                               /* === after doing clean up.                  */
INT FEM_clFinishCleanUp (  );

                               /* ========================================== */
                               /* === FEM_clAdjustMidnodes: After cleanup the*/
                               /* === midnodes will not be positioned        */
                               /* === correctly - go back and fix their      */
                               /* === locations based on the corner node     */
                               /* === locations                              */
INT FEM_clAdjustMidnodes (
   INT anum );

                               /* ========================================== */
                               /* === FEM_clSwapDiagonal: given an edge      */
                               /* === between two quad faces, swap the edge  */
                               /* === between the two faces.                 */
INT FEM_clSwapDiagonal (
   EDGE_OBJ obj_edge,          /* the edge to swap                           */
   EDGELIST_OBJ obj_edlist,    /* the edge list                              */
   FACELIST_OBJ obj_flist,     /* the face list                              */
   FACE_OBJ obj_adj_face1,     /* one face adjacent to obj_edge              */
   FACE_OBJ obj_adj_face2,     /* one face adjacent to obj_edge              */
   NODE_OBJ obj_nodes[6],      /* the ordered nodes around the 2 faces       */
   INT new_diag,               /* which diagonal is the new diagonal         */
   DEQUE_OBJ obj_face_deque,   /* deque storing faces                        */
   DEQUE_OBJ obj_edge_deque,   /* deque storing edges                        */
   INT *change  );             /* returned as TRUE if the swap is done       */

                               /* ========================================== */
                               /* === FEM_clEdgeIntersectTest: Tests to see  */
                               /* === if a line between nodes obj_node1 and  */
                               /* === obj_node2 intersects a line between    */
                               /* === nodes obj_chknode1 and obj_chknode2.   */
INT FEM_clEdgeIntersectTest (
   NODE_OBJ obj_node1,         /* node 1 of first edge                       */
   NODE_OBJ obj_node2,         /* node 2 of first edge                       */
   NODE_OBJ obj_chknode1,      /* node 1 of second edge                      */
   NODE_OBJ obj_chknode2,      /* node 2 of second edge                      */
   INT area_number,            /* the area the nodes are in                  */
   INT *intersect  );          /* returned as True if the Edges intersect    */

                               /* ========================================== */
                               /* === FEM_clQuadInvertedTest:  Tests to see  */
                               /* === if elems will be inverted.  This       */
                               /* === routine tests to make sure that        */
                               /* === neither elem is inverted at obj_node1. */
                               /* === The test should be run again for       */
                               /* === obj_node3.                             */
INT FEM_clInvertedTest (
   NODE_OBJ obj_node1,         /* see fem_cleanPriv.c for details            */
   NODE_OBJ obj_node2,
   NODE_OBJ obj_node3,
   NODE_OBJ obj_node4,
   NODE_OBJ obj_face,          /* optional face for obj_node2, Can be NULL   */
   INT *inverted  );           /* returned as TRUE if elements are inverted. */

                               /* ========================================== */
                               /* === FEM_clNumOptimalEdges: determine the   */
                               /* === number of edges that should be         */
                               /* === connected to a node to have good       */
                               /* === topology                               */
INT FEM_clNumOptimalEdges (
   NODE_OBJ obj_node,          /* the node                                   */
   INT area  );                /* area number considering                    */

                               /* ========================================== */
                               /* === FEM_clDeleteFace: delete a face from   */
                               /* === obj_flist and save the id if requested.*/
INT FEM_clDeleteFace (
   FACE_OBJ del_face,          /* the face to be deleted                     */
   FACELIST_OBJ obj_flist,     /* the face list containing the face          */
   INT save_id  );             /* set another element to have this same id   */

                               /* ========================================== */
                               /* === FEM_clDeleteNode: delete a node from   */
                               /* === obj_nlist and save the id if requested.*/
INT FEM_clDeleteNode (
   NODE_OBJ del_node,          /* the node to be deleted                     */
   NODELIST_OBJ obj_nlist,     /* the node list containing the face          */
   INT save_id  );             /* set another node to have this same id      */

                               /* ========================================== */ 
                               /* === FEM_clWillSwapInvert: determine if     */
                               /* === swapping a diagonal between 2 quads    */
                               /* === would result in inverted elements.     */
                               /* ===                                        */
                               /* ===                   2 *------* 1         */
                               /* ===                    /        \          */
                               /* ===                   /          \         */
                               /* ===                  /  existing  \        */
                               /* ===               3 *--------------* 0     */
                               /* ===                  \  diagonal  /        */
                               /* ===                   \          /         */
                               /* ===                    \        /          */
                               /* ===                   4 *------* 5         */
                               /* ===                                        */
INT FEM_clWillSwapInvert (
   NODE_OBJ aobj_nodes[6],     /* (IN)  nodes around the quads to be tested  */
                               /*       (see figure below)                   */
   INT which_diag,             /* (IN)  which diagonal is to be tested.  If  */
                               /*       which_diag == 1, the diagonal        */
                               /*       between aobj_nodes[1] and            */
                               /*       aobj_nodes[4] is tested,  if         */
                               /*       which_diag == 1, the diagonal        */
                               /*       between aobj_nodes[2] and            */
                               /*       aobj_nodes[5] is tested.             */
   INT area,                   /* (IN)  area mesh is on                      */
   INT *inverted  );           /* (OUT) returned as TRUE if inverted         */
                               /*       elements would result.               */

                               /* ========================================== */ 
                               /* === FEM_clInsert2EdgeNode: given a quad,   */
                               /* === divide the quad into two quads by      */
                               /* === inserting a two edge node.             */
                               /* === Return: EXIT_SUCCESS or EXIT_FAILURE   */
INT FEM_clInsert2EdgeNode(
   FACE_OBJ obj_face,          /* (IN)  the face to divide                   */
   NODE_OBJ obj_node,          /* (IN)  the node at which to divide          */
   FACELIST_OBJ obj_flist,     /* (IN)  face list to insert into             */
   NODELIST_OBJ obj_nlist,     /* (IN)  node list                            */
   EDGELIST_OBJ obj_edlist,    /* (IN)  edge list                            */
   DEQUE_OBJ obj_face_deque,   /* (IN)  deque holding faces                  */
   NODE_OBJ *obj_newnode,      /* (IN)  the newly inserted 2-edge node is    */
                               /*       returned                             */
   INT *change,                /* (OUT) returned as TRUE if able to insert   */
                               /*       the node                             */
   INT debug,
   FILE *debug_fp );

INT FEM_clAdjustAreaMidnodes(  
   INT anum);
/*==============================================================================
 * === MACRO: FEM_clBoundaryAngle_C
 * === Author: mls
 * === Description:  Given a boundary node, return the angle the area currently
 * ===               being processed.
 * === Arguments:
 *        NODE_OBJ  obj_node  the node where the angle is desired.
 * === Return: INT the angle stored at the node in degrees.
 *============================================================================*/
#define FEM_clBoundaryAngle_C( obj_node )\
   ((g_meshtype == STANDARD_MESH) ?\
    ((NODE_CLEANUP_INFO *)(FEM_noGenericPointer_MAC(obj_node)))->node_angle :\
    0.0);


#endif

