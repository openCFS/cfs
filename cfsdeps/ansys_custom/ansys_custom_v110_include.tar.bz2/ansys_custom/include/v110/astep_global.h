/* sid 60.1 copy of astep_global.h last changed by upd111 on 2006/10/09 19:54:31 */
/* NOTE: This file is DEAD and NO LONGER USED! */
