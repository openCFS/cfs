/* sid 60.1 copy of CFAST_Socket.h last changed by upd111 on 2006/10/09 19:58:08 */
/* CFILE CFAST_Socket.h CADOE */
#ifndef _CFAST_Socket
#define _CFAST_Socket

#include "CFAST_GetProtocol.h"
#include "CFAST_GetHostInfo.h"
#include <stdio.h>
#include <string.h>
#include "cadoe_iostream.h"
#include "cadoe_cstdio.h"

#ifndef WINNT
    #include <sys/socket.h>
    #include <unistd.h>
    #include <fcntl.h>
    #include <errno.h>
    #include <sys/types.h>
    #include <stropts.h>
#if defined(__hpux) || defined(LINUX) || defined(__sgi)
    #include <sys/ioctl.h>  // for HP
#elif __sun
   #include <sys/filio.h>  // for Sun */
#endif
#else
    #include <winsock2.h>
#endif

class CFAST_Socket
{
protected:
    int iPort;        // Socket port number    
    int iSocket;        // Socket file descriptor
    int iBlocking;        // Blocking flag
    char cBind;        // Binding flag
    struct sockaddr_in clientAddress;    // Address of the client that sent data
public:
    // Constructor.  Creates a socket given a protocol (UDP / TCP) and a port number
    CFAST_Socket(char *_sProtocol, int _iPort);

    // Constructor.  Stores a socket file descriptor
    CFAST_Socket(int _iSocket) : iSocket(_iSocket) { };

    // Destructor.  Closes the socket
    virtual ~CFAST_Socket()
    {
        vCloseSocket();
    }

    // Closes the socket
    void vCloseSocket() 
    { 
        #ifdef    WINNT
            closesocket(iSocket);
        #else
            close(iSocket);
        #endif
    }

    // The following member functions sets socket options on and off
    void vSetDebug(int _iToggle);
    void vSetBroadcast(int _iToggle);
    void vSetReuseAddr(int _iToggle);
    void vSetKeepAlive(int _iToggle);
    void vSetLinger(struct linger _lingerOption);
    void vSetSocketBlocking(int _iToggle);

    // Sets the size of the send and receive buffer
    void vSetSendBuf(unsigned int _iSendBufSize);
    void vSetReceiveBuf(unsigned int _iReceiveBufSize);

    // The following member functions retrieve socket option settings
    int iGetDebug();
    int  iGetBroadcast();
    int  iGetReuseAddr();
    int  iGetKeepAlive();
    void vGetLinger(struct linger &_lingerOption);
    int  iGetSendBuf();
    int  iGetReceiveBuf();
    int  iGetSocketBlocking() { return iBlocking; }

    // Returns the socket file descriptor
    int  iGetSocketFd() { return iSocket; }

    // Gets the system error
    char *sGetError()
    {
        #ifndef WINNT
            return strerror(errno);
        #else
	    static char buf[10];
            sprintf(buf, "%d", WSAGetLastError());    
            return buf;
        #endif
    }
};

#endif
        
