/* sid 60.5 copy of FEM_faPublic.h last changed by upd111 on 2007/01/02 21:02:37 */
/*  FEM_faPublic.h */
/*
 * *** ansys(r) copyright(c) 1998
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_faPublic.h
 *  Prototypes and macros for FEM face data type
 *
 */

#ifndef FEM_FAPUBLIC
#define FEM_FAPUBLIC

#include "FEM_cdbtypes.h"
#include "FEM_external.h"

/* === property masks used with the property field in the face */

#ifndef NO_PROPERTY
#define NO_PROPERTY        0L
#endif
#define FACE_ON_AREA         (1L<<0)
#define FACE_IN_VOLUME       (1L<<1)
#define FACE_SPLIT           (1L<<2)
#define FACE_VISITED         (1L<<3)
#define FACE_ID_DUPLICATED   (1L<<4)
#define FACE_MARKED          (1L<<5)
#define FACE_PROCESS         (1L<<6)
#define FACE_HAS_MIDNODES    (1L<<7)
#define FACE_DEGENERATE_QUAD (1L<<8)
#define FACE_SELECTED        (1L<<9)
#define FACE_MID_PROJECT     (1L<<10)
#define FACE_SWAPPED         (1L<<11)
#define FACE_PAVED           (1L<<12)
#define FACE_ELEM            (1L<<13)
#define FACE_CONSTRAINED     (1L<<14)
#define FACE_NOFACES_FLAG    (1L<<15)  /* === Do not use anywhere except
                                          === FEM_noFaces */
#define FACE_PSUEDO_ELEM     (1L<<16)
#define FACE_HASH2_FLAG      (1L<<17)  /* === Do not use anywhere except
                                          === FEM_faHashFace2 */
#define FACE_AT_FRONT        (1L<<18)
#define FACE_INVERTED        (1L<<19)
#define FACE_MAPPED          (1L<<20)
#define FACE_ON_BND          (1L<<21)
#define EMPTY                (1L<<22)
#define FACE_PRE_EXIST_FACE  (1L<<23)
#define FACE_NEAR_HIGH_CURV  (1L<<24)
#define FACE_DEGENERACY      (1L<<25)
/* etc... */

/* === manipulating and inquiring on the linked list object */

#ifdef __cplusplus
extern "C" {
#endif

                             /* === FEM_faNewList: create a new face list     */
                             /* === and initialize (FACELIST_OBJ              */
                             /* === constructor)                              */
FACELIST_OBJ FEM_faNewList ( void  );

                             /* === FEM_faDeleteList: delete the face list    */
                             /* === (FACELIST_OBJ destructor)                 */
void FEM_faDeleteList (
   FACELIST_OBJ obj_flist );        /* The face list object                   */

                             /* === FEM_faNew: create a new face and add      */
                             /* === it to the face list                       */
                             /* === (FACE_OBJ constructor)                    */
FACE_OBJ FEM_faNew (
   FACELIST_OBJ obj_flist );           /* The element list object             */

                             /* === FEM_faDelete: delete a face and           */
                             /* === remove from list                          */
                             /* === (FACE_OBJ destructor)                     */
void FEM_faDelete (
   FACELIST_OBJ obj_flist,             /* The face list object                */
   FACE_OBJ obj_face );                /* face object to be deleted           */

                             /* === FEM_faNewTri: create a new tri element    */
                             /* === for surface meshing                       */
FACE_OBJ FEM_faNewTri (
   NODE_OBJ aobj_node[6]  );           /* array of nodes ordered according to */
                                       /* TRI_EDGE_NODE.  Can include midside */
                                       /* If not then 3-5 should be NULL      */
                             /* === FEM_faNewQuad: create a new quad element  */
                             /* === for surface meshing                       */
FACE_OBJ FEM_faNewQuad (
   NODE_OBJ aobj_node[8]  );           /* array of nodes ordered according to */
                                       /* QUAD_EDGE_NODE.  Can include midside*/
                                       /* If not then 4-7 should be NULL      */

                             /* === FEM_faHashFace: Hash face into the face   */
                             /* === list.  If it does not exist in the list,  */
                             /* === then create one. return the face object   */
FACE_OBJ FEM_faHashFace (
   FACELIST_OBJ obj_flist,         /* the face list object                    */
   EDGE_OBJ obj_edge0,             /* vertex 0 of the face                    */
   EDGE_OBJ obj_edge1,             /* vertex 1 of the face                    */
   EDGE_OBJ obj_edge2,             /* vertex 2 of the face                    */
   EDGE_OBJ obj_edge3,             /* vertex 3 of the face (NULL for tri face)*/
   FEM_BOOLEAN *edge_orientation,  /* RETURN: direction face is oriented with */
                                   /* respect to how the face is stored       */
                                   /* (1 or -1) (used for face_use)           */
   INT *initial_edge,              /* RETURN: initial edge index with respect */
                                   /* to how face is stored                   */
   FEM_BOOLEAN *newface  );        /* RETURN: TRUE if a new face was created  */

                             /* === FEM_faHashFace2: Find all faces that use  */
                             /* === a set of edges.  If no faces use the      */
                             /* === edges, num_faces is returned as 0.        */
                             /* === This is done by looking at the adjacent   */
                             /* === faces to the edges for a face with the    */
                             /* === same vertices.                            */
                             /* === Return: EXIT_SUCCESS or EXIT_FAILURE.     */
INT FEM_faHashFace2 (
   FACELIST_OBJ obj_flist,         /* (IN)  the face list object              */
   EDGE_OBJ *aobj_edges,           /* (IN)  list of edges on the face.  Some  */
                                   /*       of the edges can be null.  If so  */
                                   /*       all faces matching the edge       */
                                   /*       pattern will be returned in       */
                                   /*       aobj_faces                        */
   INT num_edges,                  /* (IN)  length of aobj_edges              */
   FACE_OBJ *aobj_faces,           /* (OUT) faces found with all edges in     */
                                   /*       aobj_edges                        */
   FEM_BOOLEAN *a_edge_orientations,/* (OUT) direction face is oriented with  */
                                   /*       respect to how the face is stored */
                                   /*       (1 or -1) (used for face_use)     */
                                   /*       if only one edge is passed in     */
                                   /*       orientation is returned as 0 since*/
                                   /*       it cannot be determined           */
   INT *num_faces,                 /* (OUT) length of aobj_faces and          */
                                   /*       a_edge_orientations               */
   INT max_face  );                /* (IN)  maximum number of faces that can  */
                                   /*       be stored in aobj_faces without   */
                                   /*       memory overflow.                  */

                             /* === FEM_faMaxId: return max face id in list   */
INT FEM_faMaxId (
   FACELIST_OBJ obj_flist  );      /* the face list object                    */



/* === face utility functions */


                             /* === FEM_faNodes: get the all nodes of a face  */
                             /* === (use FEM_faElementNodes for ordered nodes)*/
INT FEM_faNodes (
   FACE_OBJ obj_face,                  /* face object                         */
   NODE_OBJ *aobj_nodes );             /* array of node objects returned      */

                             /* === FEM_faNode: get a single (corner) node    */
                             /* === on the face, based on the node's index -  */
                             /* === same index as aobj_nodes from FEM_faNodes */
                             /* === Return the node or NULL                   */
NODE_OBJ FEM_faNode (
   FACE_OBJ obj_face,                  /* face object                         */
   INT index  );                       /* index of node on face               */

FEM_BOOLEAN FEM_faNodeOnFace (
   FACE_OBJ obj_face,
   NODE_OBJ obj_node );
            
                             /* === FEM_faNodes: get corner nodes of a tri    */
INT FEM_faTriCornerNodes (
   FACE_OBJ obj_face,                  /* face object                         */
   NODE_OBJ *aobj_nodes );             /* array of node objects returned      */

							 /* === FEM_faCornerNodes: gets corner nodes 
							        of a face*/
INT FEM_faCornerNodes (		 
	FACE_OBJ obj_face,
	NODE_OBJ *aobj_nodes);

                             /* === FEM_faEdgeNodes: return the ordered nodes */
                             /* === on an edge of the face                    */
INT FEM_faEdgeNodes (
   FACE_OBJ obj_face,                  /* face object                         */
   EDGE_OBJ obj_edge,                  /* edge object                         */
   NODE_OBJ *p_obj_node0,              /* first node on edge                  */
   NODE_OBJ *p_obj_node1  );           /* next ccw node on face               */

                             /* === FEM_faNextCCWNode: given a node on the    */
                             /* === face, return the next counter clockwise   */
                             /* === ordered node on the face.  Used for 2D    */
                             /* === applications only                         */
NODE_OBJ FEM_faNextCCWNode (
   FACE_OBJ obj_face,                  /* the face object                     */
   NODE_OBJ obj_node  );               /* the node object                     */

#ifndef STANDALONE_DELAUNAY
                             /* === FEM_faElementNodes: get the nodes of face */
                             /* === of an element. Nodes are ordered right    */
                             /* === hand rule with normal pointing out of     */
                             /* === element.                                  */
INT FEM_faElementNodes (
   FACE_OBJ obj_face,                  /* face object                         */
   ELEMENT_OBJ obj_element,            /* element object (face is on element) */
   NODE_OBJ *aobj_nodes );             /* return array of ordered nodes on fac*/
#endif

                             /* === FEM_faSetEdgeOrientation: set orientation */
                             /* === of nodes on and edge with repect to the   */
                             /* === face (should be CCW ordering of edges)    */
void FEM_faSetEdgeOrientation (
   FACE_OBJ obj_face,                 /* the face object                      */
   INT iedge,                         /* edge index on face                   */
   INT nd_orient  );                  /* node orientation on edge (-1 or 1)   */

                             /* === FEM_faEdgeIndex: return index of edge     */
                             /* === on face                                   */
INT FEM_faEdgeIndex (
   FACE_OBJ obj_face,                 /* the face object                      */
   EDGE_OBJ obj_edge  );              /* an edge on the face                  */

                             /* === FEM_faNodeIndex: given a face and one of  */
                             /* === its nodes, return its index on the face   */
                             /* === (only corner nodes)                       */
INT FEM_faNodeIndex (
   FACE_OBJ obj_face,                 /* the face object                      */
   NODE_OBJ obj_node  );              /* a node on the face                   */

                             /* === FEM_faAdjElement: get an adjacent         */
                             /* === element to the fac                        */
ELEMENT_OBJ FEM_faAdjElement (
   FACE_OBJ obj_face  );               /* face object                         */

                             /* === FEM_faNumAdjElems: return number of       */
                             /* === adjacent elems                            */
INT FEM_faNumAdjElems(
   FACE_OBJ obj_face );

                             /* === FEM_faOtherAdjElem: given one adjacent    */
                             /* === element to the face, return the other     */
                             /* === (assumes only two adjacent elements       */
                             /* === to face)                                  */
ELEMENT_OBJ FEM_faOtherAdjElem (
   FACE_OBJ obj_face,                  /* the face object                     */
   ELEMENT_OBJ obj_element );          /* one of adjacent elements to face    */


                             /* === FEM_faNextAdjElement: get next adjacent   */
                             /* === element to the face                       */
ELEMENT_OBJ FEM_faNextAdjElement (
   FACE_OBJ obj_face,                  /* face object                         */
   ELEMENT_OBJ obj_element  );         /* one of the elements adjacent to face*/

                            /* === FEM_faAdjUpdate: update face adjacencies   */
INT FEM_faAdjUpdate (
   FACE_OBJ obj_face );                /* face object                         */

                            /* === FEM_faAdjRemove: delete any adjacency      */
                            /* === info for the element                       */
INT FEM_faAdjRemove (
   FACE_OBJ obj_face );                /* face object                         */


                            /* === FEM_faDeleteFaceEdge: delete a face and    */
                            /* === any edges associated with it that are      */
                            /* === unused as a result of deletion (updates    */
                            /* === adjacencies)                               */
INT FEM_faDeleteFaceEdge (
   FACE_OBJ obj_face  );               /* the face object to delete           */

                            /* === FEM_faDeleteFaceEdgeII: delete a face and  */
                            /* === any edges associated with it that are      */
                            /* === unused as a result of deletion (updates    */
                            /* === adjacencies)                               */
                            /* === THIS WONT DELETE EDGES ON LINES !!!!!!!    */
INT FEM_faDeleteFaceEdgeII (
   FACE_OBJ obj_face  );               /* the face object to delete           */

                            /* === FEM_faArea: compute area of the face       */
DOUBLE FEM_faArea (
   FACE_OBJ obj_face  );               /* face object                         */

                            /* === FEM_faCentroid: compute the centroid       */
INT FEM_faCentroid (
   FACE_OBJ obj_face,                  /* the face object                     */
   DOUBLE *xc, DOUBLE *yc, DOUBLE *zc );/* return the centroid location       */


INT FEM_faCentroidUV (
   FACE_OBJ obj_face,                  /* the face object                     */
   DOUBLE *Uc, DOUBLE *Vc );           /* return the centroid location        */

INT FEM_faCentroidA(
   NODE_OBJ *aobj_nodes,          
   INT iNumNodes,
   DOUBLE adCntXyz[3] );

INT FEM_faIntersectionBtwTwoTris (
   FACE_OBJ obj_faceA,
   FACE_OBJ obj_faceB,
   INT      *piNumInterstions,
   VECTOR3D aLocations[3] );


INT FEM_faCentroidUVA(
   NODE_OBJ *aobj_nodes,          
   INT iNumNodes,
   DOUBLE adCntXyz[3] );

                            /* === FEM_faCircumCircle: compute the            */
                            /* === circumcircle radius and center             */
void FEM_faCircumCircle (
   FACE_OBJ obj_face,                  /* the face object                     */
   DOUBLE *p_radius, VECTOR3D *p_center );/* return NULL                      */

                            /* === FEM_faElementNormal: compute face normal   */
                            /* === with respect to outward pointing direction */
                            /* === from element                               */
INT FEM_faElementNormal (
   FACE_OBJ obj_face,                  /* face on element                     */
   ELEMENT_OBJ obj_element,            /* current element                     */
   DOUBLE *p_xn,                       /* return normal                       */
   DOUBLE *p_yn,
   DOUBLE *p_zn  );

                            /* === FEM_faNormal: compute the normal of face   */
INT FEM_faNormal (
   FACE_OBJ obj_face,                  /* the face                            */
   DOUBLE *xn, DOUBLE *yn, DOUBLE *zn );/* return the normal (unnormalized)   */

                            /* === FEM_faEdgeBetween: return the edge between */
                            /* === two adjacent faces                         */
EDGE_OBJ FEM_faEdgeBetween (
   FACE_OBJ obj_face,                  /* a face object                       */
   FACE_OBJ obj_adjface );             /* an adjacent face                    */

                            /* === FEM_faEdgesBetween: return the edge between */
                            /* === two adjacent faces                         */
INT FEM_faEdgesBetween(
   FACE_OBJ obj_face,       /* a face object */
   FACE_OBJ obj_adjface,    /* an adjacent face */
   EDGE_OBJ *aobj_edges,    /* this arrray need be allocated outside [4] */
   INT *numEdges);

                            /* === FEM_faFaceAngleAtNode: calculate the angle */
                            /* === on a face at a particular node             */
DOUBLE FEM_faFaceAngleAtNode (
   NODE_OBJ obj_node,                  /* the node object                     */
   FACE_OBJ obj_face  );               /* the face object                     */

                            /* === FEM_faFaceAngleAtNode_2: calculate the angle */
                            /* === on a face at a particular node             */
DOUBLE FEM_faFaceAngleAtNode_2 (
   NODE_OBJ obj_node,                  /* the node object                     */
   FACE_OBJ obj_face  );               /* the face object                     */


                            /* === FEM_faOppositeTriFace: Given a node on a   */
                            /* === triangular face, return the face that is   */
                            /* === opposite the edge opposite the node.       */
DOUBLE FEM_faNodeAngleWithNormal (
   NODE_OBJ obj_node,                  /* the node object                     */
   FACE_OBJ obj_face,                  /* the face object                     */
   INT iDim );
                            /* === FEM_faOppositeTriFace: Given a node on a   */
                            /* === triangular face, return the face that is   */
                            /* === opposite the edge opposite the node.       */
FACE_OBJ FEM_faOppositeTriFace (
   FACE_OBJ obj_face,                  /* the face                            */
   INT node_index  );                  /* index of node on obj_face
                                          (0, 1, or 2 )                       */

                            /* === FEM_faOppositeTriEdge: Given a node on a   */
                            /* === triangular face, return the edge that is   */
                            /* === opposite the node.                         */
EDGE_OBJ FEM_faOppositeTriEdge (
   FACE_OBJ obj_face,                  /* the face                            */
   NODE_OBJ obj_node  );               /* edge on obj_face                    */


                            /* === FEM_faOppositeTriNode: Given an edge on a  */
                            /* === triangular face, return the node that is   */
                            /* === opposite the edge.                         */
NODE_OBJ FEM_faOppositeTriNode (
   FACE_OBJ obj_face,                  /* the face                            */
   EDGE_OBJ obj_edge  );               /* edge on obj_face                    */

                            /* === FEM_faOppositeQuadNode: Given a node on a  */
                            /* === quad face, return the node that is         */
                            /* === opposite the node.                         */
NODE_OBJ FEM_faOppositeQuadNode (
   FACE_OBJ obj_face,
   NODE_OBJ obj_node );

                            /* === FEM_faDetermineFaceGeoEntity: Determine    */
                            /* === the Ansys geometric entity associated with */
                            /* === a face                                     */
INT FEM_faDetermineFaceGeoEntity (
   FACE_OBJ obj_face  );               /* the face                            */

                            /* === FEM_faPlaceAtFront: Given a PROPERTY and a */
                            /* === geo_entity, place all faces in the face    */
                            /* === list with this property and geo_entity (if */
                            /* === necessary ) at the front of the list.      */
INT FEM_faPlaceAtFront (
   FACELIST_OBJ obj_flist,             /* face list to rearrange              */
   LONG property,                      /* property to rearrange on            */
   INT geo_entity  );                  /* geo_entity to rearrange on          */

                            /* === FEM_noPlaceAtFront2: Given a face, place   */
                            /* === it at the front of a face list.            */
INT FEM_faPlaceAtFront2 (
   FACE_OBJ obj_face,                 /* face to put at front                 */
   FACELIST_OBJ obj_flist  );         /* face list to rearrange               */

                            /* === FEM_faPlaceAtRear: Given a property (or    */
                            /* === properties), place all faces in the face   */
                            /* === list with this property at the rear of the */
                            /* === list; this is equivalent to placing faces  */
                            /* === without this property at the front of list */
void FEM_faPlaceAtRear (
   FACELIST_OBJ obj_flist,             /* face list to rearrange              */
   LONG property  );                   /* property to rearrange on            */

                            /* === FEM_faClearGenericPointers: Set all generic*/
                            /* === pointers in obj_flist to NULL              */
void FEM_faClearGenericPointers (
   FACELIST_OBJ obj_flist  );


                            /* === FEM_faReplaceOneNode: face replace a node */
                            /* === Return: INT EXIT_SUCCESS or EXIT_FAILURE   */
INT FEM_faReplaceOneNode( 
   FACE_OBJ *face, 
   NODE_OBJ newNode, 
   NODE_OBJ oldNode, 
   DEQUE_OBJ *tcDeques);

                            /* === FEM_faFlipDirection: Reverse the direction */
                            /* === of the face.                               */
                            /* === Return: INT EXIT_SUCCESS or EXIT_FAILURE   */
INT FEM_faFlipDirection (
   FACE_OBJ obj_face );                /* face object                         */

                            /* === FEM_faSetConstraints:  All faces that       */
                            /* === are constrained have previously been       */
                            /* === marked as such (FACE_CONSTRAINED).  Set    */
                            /* === all edge and node CONSTRAINED flags to     */
                            /* === correspond to faces.  Place all            */
                            /* === non-constrained entities at the top of     */
                            /* === their respective lists.                    */
                             /* ************************************************
                                       CAUTION VERY TIME CONSUMING
                            ***************************************************/

INT FEM_faFlipMesh (
   INT     anum ); 

INT FEM_faSetConstraints(  
   FACELIST_OBJ obj_flist,
   EDGELIST_OBJ obj_edlist,
   NODELIST_OBJ obj_nlist );

                            /* === FEM_faSetConstraintsII:  Constrain all faces and edges                     */
                            /* ===  except the faces and edges on the specified area that                     */
                            /* === do not have the specified property set. All faces that      */
                            /* === are constrained have previously been       */
                            /* === marked as such (FACE_CONSTRAINED).  Set    */
                            /* === all edge and node CONSTRAINED flags to     */
                            /* === correspond to faces.  Place all            */
                            /* === non-constrained entities at the top of     */
                            /* === their respective lists.                    */
INT FEM_faSetConstraintsII(  
   INT anum,                            /* === area not to mark as constrained */
   LONG property );                  /* === mark all faces on this are that do not have this property */

                            /* === FEM_faGet: Retreive the face object given  */
                            /* === its id (linear search)                     */ 
FACE_OBJ FEM_faGet(
   INT id );

                            /* === FEM_faGetEdgeOrientation: Get the orientation of an edge wrt the face  */
                            /* === Return: FEM_BOOLEAN (1=[0],[1], -1=[1],[0]  ) */
FEM_BOOLEAN FEM_faGetEdgeOrientation( 
   FACE_OBJ obj_face, 
   EDGE_OBJ obj_edge );

                            /* === FEM_faQuadraticQuadJR: Quadratic Quad Jac Rat and area  */
DOUBLE FEM_faQuadraticQuadJR(  
               FACE_OBJ obj_face,
				  DOUBLE *jacobRatio, 
				  FEM_BOOLEAN *error);

void FEM_faGetUseInteriorMidsForQuadraticQuadJR( FEM_BOOLEAN *pbUseInteriorMids );
void FEM_faSetUseInteriorMidsForQuadraticQuadJR( FEM_BOOLEAN bUseInteriorMids );

INT FEM_faTriHeight2(     /* fail or not */
   FACE_OBJ obj_face,     /* the triangle */
   EDGE_OBJ obj_edge,     /* the edge of the height about */
   DOUBLE   *pd_height2,
   INT *piOut );


INT FEM_faIsFaceNarrow( FACE_OBJ obj_face );

#ifdef __cplusplus
}
#endif

/*
 * === Face Macros
 */
#include "fem_Struct.h"

/*============================================================================*/
/* === Macro: FEM_faNext_C
 * === Author: sjo
 * === Description: return the next face in the linked list of faces
 * === Arguments:
 *     FACE_OBJ obj_face          current face in list
 * === Return: FACE_OBJ              next face in list
 *             NULL if macro not defined for g_meshtype
 */
#define FEM_faNext_C( obj_face )\
   ((g_meshtype == STANDARD_MESH) ?\
      (FACE_OBJ)(((FACE_PTYP)(obj_face))->ps_next) :\
   NULL)

/*============================================================================*/
/* === Macro:  FEM_faPrevious_C
 * === Author: sjo
 * === Description: get the previous face in the linked list object
 * === Arguments:
 *     FACE_OBJ obj_element          current face in list
 * === Return: FACE_OBJ              previous face in list
 *             NULL if macro not defined for g_meshtype
 */
#define FEM_faPrevious_C( obj_face )\
   ((g_meshtype == STANDARD_MESH) ?\
      (FACE_OBJ)(((FACE_PTYP)(obj_face))->ps_previous) :\
   NULL)

/*============================================================================*/
/* === Macro: FEM_faTotal_C
 * === Author: sjo
 * === Description: get the total number of faces in list
 * === Arguments:
 *     FACELIST_OBJ obj_flist   The face list
 * === Return: INT              total number of faces in list
 *             -1 if macro not defined for g_meshtype
 */
#define FEM_faTotal_C( obj_flist )\
   ((g_meshtype == STANDARD_MESH) ?\
      (INT)(((FACELIST_PTYP)(obj_flist))->total) :\
   -1)

/*============================================================================*/
/* === Macro: FEM_faList_C
 * === Author: sjo
 * === Description: return the head of the face linked list
 * === Arguments:
 *     FACELIST_OBJ obj_flist      face list
 * === Return: FACE_OBJ            head of face list
 *             NULL if macro not defined for g_meshtype
 */
#define FEM_faList_C( obj_flist )\
   ((g_meshtype == STANDARD_MESH) ?\
      (FACE_OBJ)(((FACELIST_PTYP)(obj_flist))->ps_list) :\
   NULL)

/*============================================================================*/
/* === Macro: FEM_faId_C
 * === Author: sjo
 * === Description: return the face id
 * === Arguments:
 *     FACE_OBJ obj_face        face object
 * === Return: INT              face id
 *             -1 if macro not defined for g_meshtype
 */
#define FEM_faId_C( obj_face )\
   ((g_meshtype == STANDARD_MESH) ?\
      (INT)(((FACE_PTYP)(obj_face))->id) :\
   -1)

/*============================================================================*/
/* === Macro: FEM_faSetId_C
 * === Author: sjo
 * === Description: set the face id
 * === Arguments:
 *     FACE_OBJ obj_face      face object
 *     INT face_id            the new face id
 * === Return: nothing
 */
#define FEM_faSetId_C( obj_face, face_id )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((FACE_PTYP)(obj_face))->id = (INT)face_id;\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }

/*============================================================================*/
/* === Macro: FEM_faParent_C
 * === Author: mls
 * === Description: return the parent
 * === Arguments:
 *     FACE_OBJ obj_face        face object
 * === Return: INT              parent
 *             -1 if macro not defined for g_meshtype
 */
#define FEM_faParent_C( obj_face )\
   ((g_meshtype == STANDARD_MESH) ?\
      (INT)(((FACE_PTYP)(obj_face))->parent) :\
   -1)

/*============================================================================*/
/* === Macro: FEM_faSetParent_C
 * === Author: mls
 * === Description: set the parent
 * === Arguments:
 *     FACE_OBJ obj_face      face object
 *     INT parent             the new parent
 * === Return: nothing
 */
#define FEM_faSetParent_C( obj_face, new_parent )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((FACE_PTYP)(obj_face))->parent = (INT)new_parent;\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }

/*============================================================================*/
/* === Macro: FEM_faNumEdges_C
 * === Author: sjo
 * === Description: get the number of edges on the face
 * === Arguments:
 *     FACE_OBJ obj_face          face object
 * === Return: INT                number of edges on the face
 *             -1 if macro not defined for g_meshtype
 */
#define FEM_faNumEdges_C( obj_face )\
   ((g_meshtype == STANDARD_MESH) ?\
      (INT)(((FACE_PTYP)(obj_face))->numedges) :\
   -1)


/*============================================================================*/
/* === Macro: FEM_faSetNumEdges_C
 * === Author: sjo
 * === Description: set the number of edges on the face
 * === Arguments:
 *     FACE_OBJ obj_face         face object
 *     INT num_edge              number of edges on face
 * === Return: nothing
 */
#define FEM_faSetNumEdges_C( obj_face, num_edges )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((FACE_PTYP)(obj_face))->numedges = (INT)num_edges;\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }

/*============================================================================*/
/* === Macro: FEM_faEdge_C
 * === Author: sjo
 * === Description: get the iedge edge object from the face
 * === Arguments:
 *     FACE_OBJ obj_face   face object
 *     INT iedge           number of edge to return (0, 1, 2, or 3)
 * === Return: EDGE_OBJ          edge object corresponding to iedge
 *             NULL if macro not defined for g_meshtype
 */
#define FEM_faEdge_C( obj_face, iedge )\
   ((g_meshtype == STANDARD_MESH) ?\
      (EDGE_OBJ)(((FACE_PTYP)(obj_face))->aps_edge_use[iedge]->ps_edge) :\
   NULL)

/*============================================================================*/
/* === Macro: FEM_faSetEdge_C
 * === Author: sjo
 * === Description: set the iedge edge object to the element
 * === Arguments:
 *     FACE_OBJ obj_face     face object
 *     INT iedge             number of edge to set
 *     EDGE_OBJ obj_edge     new edge object for the face
 * === Return: nothing
 */
#define FEM_faSetEdge_C( obj_face, iedge, obj_edge )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((FACE_PTYP)(obj_face))->aps_edge_use[iedge]->ps_edge =\
               (EDGE_PTYP)obj_edge;\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }

/*============================================================================*/
/* === Macro: FEM_faProperty_C
 * === Author: sjo
 * === Description: return the status of a property for the face
 * === Arguments:
 *     FACE_OBJ obj_face     face object
 *     LONG property_mask    one of the face properties specified above
 * === Return: LONG 0 or !=0      0 = not set, !=0 = set
 */
#define FEM_faProperty_C( obj_face, property_mask )\
   ((g_meshtype == STANDARD_MESH) ?\
      (LONG)(((FACE_PTYP)(obj_face))->property & (LONG)(property_mask)) :\
   0L)

/*============================================================================*/
/* === Macro: FEM_faGetAllProperties_C
 * === Author: mls
 * === Description: return the variable bit field for all properties
 * === Arguments:
 *     FACE_OBJ obj_face     face object
 * === Return: LONG the property
 */
#define FEM_faGetAllProperties_C( obj_face )\
   ((g_meshtype == STANDARD_MESH) ?\
      (LONG)(((FACE_PTYP)(obj_face))->property) : 0L)

/*============================================================================*/
/* === Macro: FEM_faSetProperty_C
 * === Author: sjo
 * === Description: Set the status of a property for the face
 * === Arguments:
 *     FACE_OBJ obj_face     face object
 *     LONG property_mask    one of the face properties specified above
 *     FEM_BOOLEAN status;   0 or 1, TRUE or FALSE, ON or OFF
 * === Return: 0 or !=0      0 = not set, !=0 = set
 */
#define FEM_faSetProperty_C( obj_face, property_mask, status )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         if (status) {\
            ((FACE_PTYP)(obj_face))->property = \
               ((FACE_PTYP)(obj_face))->property | (LONG)(property_mask);\
         }\
         else {\
            if(((FACE_PTYP)(obj_face))->property & (LONG)(property_mask)) {\
               ((FACE_PTYP)(obj_face))->property =\
                  ((FACE_PTYP)(obj_face))->property ^ (LONG)(property_mask);\
            }\
         }\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }

/*============================================================================*/
/* === Macro: FEM_faSetAllProperties_C
 * === Author: mls
 * === Description: Set the entire property bit field
 * === Arguments:
 *     FACE_OBJ obj_face     face object
 *     LONG property         the bit field
 * === Return: none
 */
#define FEM_faSetAllProperties_C( obj_face, new_property )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((FACE_PTYP)(obj_face))->property = new_property;\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }

/*============================================================================*/
/* === Macro: FEM_faInitProperties_C
 * === Author: sjo
 * === Description: Initialize all properties for the face to OFF
 * === Arguments:
 *     FACE_OBJ obj_face     face object
 * === Return: nothing
 */
#define FEM_faInitProperties_C( obj_face )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((FACE_PTYP)(obj_face))->property = NO_PROPERTY;\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }

/*============================================================================*/
/* === Macro: FEM_faShapeMetric_C
 * === Author: sjo
 * === Description: get the element shape metric
 * === Arguments:
 *     FACE_OBJ obj_face     face object
 * === Return: DOUBLE shape_metric
 */
#define FEM_faShapeMetric_C( obj_face )\
   ((g_meshtype == STANDARD_MESH) ?\
      (DOUBLE)(((FACE_PTYP)(obj_face))->shape_metric) :\
   -999.)

/*============================================================================*/
/* === Macro: FEM_faSetShapeMetric_C
 * === Author: sjo
 * === Description: set the element shape metric
 * === Arguments:
 *     FACE_OBJ obj_face     face object
 *     DOUBLE the_metric     the element shape metric
 * === Return: nothing
 */
#define FEM_faSetShapeMetric_C( obj_face, the_metric )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((FACE_PTYP)(obj_face))->shape_metric = (DOUBLE)(the_metric);\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }

/*============================================================================*/
/* === Macro: FEM_faGenericPointer_MAC
 * === Author: sjo
 * === Description: retreive the generic pointer from the face object
 * === Arguments:
 *     FACE_OBJ obj_face     face object
 * === Return: (void *) a generic pointer  (must be caste to corect type)
 */
#define FEM_faGenericPointer_MAC( obj_face )\
   ((g_meshtype == STANDARD_MESH) ?\
      (((FACE_PTYP)(obj_face))->p_info) :\
   NULL)

/*============================================================================*/
/* === Macro: FEM_faSetGenericPointer_C
 * === Author: sjo
 * === Description: set a generic pointer into the face object
 * === Arguments:
 *     FACE_OBJ obj_face       face object
 *     ADRESS_TYP obj_entity   any object entity or generic void pointer
 * === Return: void
 */
#define FEM_faSetGenericPointer_C( obj_face, obj_entity )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((FACE_PTYP)(obj_face))->p_info = (ADDRESS_TYP)obj_entity;\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }

/*============================================================================*/
/* === Macro: FEM_faGeoEntity_C
 * === Author: sjo
 * === Description: get the face underlying geometric entity id
 * === Arguments:
 *     FACE_OBJ obj_face     face object
 * === Return: INT geo_entity
 */
#define FEM_faGeoEntity_C( obj_face )\
   ((g_meshtype == STANDARD_MESH) ?\
      (INT)((FACE_PTYP)(obj_face))->geo_entity : -1)

/*============================================================================*/
/* === Macro: FEM_faSetGeoEntity_C
 * === Author: sjo
 * === Description: set the edge underlying geometric entity id
 * === Arguments:
 *     FACE_OBJ obj_face     face object
 *     INT the_entity        number of the entity (user defined)
 * === Return: void
 */
#define FEM_faSetGeoEntity_C( obj_face, the_entity )\
   switch (g_meshtype) {\
      case STANDARD_MESH:\
         ((FACE_PTYP)(obj_face))->geo_entity = (INT)the_entity;\
         break;\
      default:\
         FEMe_Error( GENERIC, GEN_BAD_MESH_TYPE, FEM_ERROR, NULL,\
                     __FILE__,__LINE__ );\
         break;\
   }



#endif
