/* sid 60.1 copy of AnsysMetisUtils.h last changed by jrb on 2006/02/10 21:49:21 */
/*HFILE AnsysMetisUtils.h                  ANSI_C                    jrb
------------------------------------------------------------------------
------- Notice - This file contains ANSYS Confidential information
------------------------------------------------------------------------
*/

/*------------------------------ Description ---------------------------

\Author:    Jeff Beisheim

\Title:     Standard METIS domain decomposition utility header

\Desc:      Header for METIS domain decomposition utility routines

            Currently contains the following utility functions:

                   computeVertexWeight

\History:   Created 3/30/06 (jrb)

\Function(s)
 -Primary:      Standard METIS domain decomposition utility header
 -Secondary:    Prototypes for AnsysMetisUtils.c
 -External:     none
 -Internal:     none
 -Static:       none

----------------------------------------------------------------------*/

/*------------------------------ Prototypes --------------------------*/

extern INT computeVertexWeight(INT*);

