/* sid 60.1 copy of FEM_coNodeArray.h last changed by upd111 on 2005/07/21 19:39:36 */

/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 1999 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_coNodeArray.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_coNodeArray.h
 *  header file for FEM_coNodeArray.c
 *
 */
#ifndef FEMA_CREATENODEARRAY_INCLUDE
#define FEMA_CREATENODEARRAY_INCLUDE

                            /* ============================================= */
                            /* === FEMa_coCreateNodeArray: creates an   */
                            /* === array of nodes in ansys element node form.*/
                            /* === This form duplicates degenerate nodes.    */
                            /* === Can be used for both volume and surface   */
                            /* === elements.  To use for surface elements,   */
                            /* === send element in obj_face and set          */
                            /* === obj_elem == NULL.  To use for volume      */
                            /* === elems, set obj_face == NULL, and send     */
                            /* === volume element in obj_elem.               */
                            /* ============================================= */
INT FEM_coCreateNodeArray (
   FACE_OBJ obj_face,             /* (IN)  the face to get nodes from        */
   ELEMENT_OBJ obj_elem,          /* (IN)  the element to get nodes from     */
   NODE_OBJ aobj_nodes[20],        /* (OUT) the nodes on the face             */
   INT *num_nodes );             /* (OUT) length of aobj_nodes              */

#endif
