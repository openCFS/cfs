/* sid 60.2 copy of MAT_TBMetaDataApi.h last changed by jtm on 2006/05/16 13:52:41 */

/*
////////////////////////////////////////////////////////////////////////////
//                                                                        //
//         copyright(c) 2006 SAS IP, Inc.  All rights reserved.             //
//                                                                        //
// This file contains proprietary software licensed from ANSYS Inc.       //
// This header must remain in any source code despite modifications or    //
// enhancements by any party.                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
//
// $Workfile: MAT_TBMetaDataApi.h $
// $Revision$ 7.0
// $Date$ Feb 9 2005
// $Author$ rjayasee
//
// Decription :
//
//	C Entry point from Ansys to the Curve Fitting Code. This has all the
//  Command Parsing code
//////////////////////////////////////////////////////////////////////////////
*/

/*  tbfit.h */
#if !defined(MAT_TBMetaDataApi__1)
#define MAT_TBMetaDataApi__1
#define MAT_TBMetaDataApi_Get__1

#include "ansys.h"

/* (1)----------------------------------------------------------------*/
#if defined(LOWERCASENOUNDER_SYS)

/*
 *   The pattern for these platforms is the lowercased version of the name
 */

#define MAT_GetTBOptName          mat_gettboptname
#define MAT_IsSupportedClass      mat_issupportedclass
#endif


/* (2)----------------------------------------------------------------*/
#if defined(UPPERCASENOUNDER_SYS)

/*
 *   The pattern for these platforms is the uppercased version of the name
 */

#define MAT_GetTBOptName          MAT_GETTBOPTNAME
#define MAT_IsSupportedClass      MAT_ISSUPPORTEDCLASS

#endif


/* (3)----------------------------------------------------------------*/
#if defined(LOWERCASEUNDER_SYS)

/*
 *   The pattern for these platforms is the lowercased version of the name 
 *   followed by an underscore
 */

#define MAT_GetTBOptName          mat_gettboptname_
#define MAT_IsSupportedClass      mat_issupportedclass_


#endif


/* (4)----------------------------------------------------------------*/

/*
 *   This section is for definition of prototypes.  Each prototype 
 *   should be ANSI compliant and specify the types of each parameter 
 *   as well as the return type.
 */
#ifdef __cplusplus
extern "C"
{
#endif

INT FUNCTION MAT_GetTBOptName( FCHAR(oName), INT* iTbOpt, FCHAR(pTbOptName) FCHARL(oName_len) FCHARL(oTbOptName_len)) ;
INT FUNCTION MAT_IsSupportedClass( FCHAR(oName) FCHARL(oName_len) ) ;

void ToLowerCaseString( char* pString, INT size) ;

#ifdef __cplusplus
}

#endif


#endif
