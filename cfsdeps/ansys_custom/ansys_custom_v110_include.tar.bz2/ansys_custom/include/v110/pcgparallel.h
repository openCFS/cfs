/* sid 60.2 copy of pcgparallel.h last changed by jrb on 2005/10/25 13:02:58 */

/* Define MPI communication tag */
#include "mpitag.h"


/* Define the size related parameters */

#define  MAX_DOMAIN          128    /* max number of machines/processors */


/* Global variables */

extern INT             GlbnNodes;
extern INT             GlbnElems;
extern INT             GlbnumDof;
extern INT             GlbnDomain;

extern INT             GlbadjustCE;  /* Number of CEs in cpce data structure summed */
                                     /* between all machines into one value for all */
extern INT             GlbfinalCE;   /* Number of CEs in Glbcpce data structure     */
                                     /* (this value is shared out on all machines)  */


extern NodeList        GlbfeNodeList;
extern ElemArr         GlbelemArr;

extern sparseFactor    GlbA_adjArr;
extern sparseFactor    GlbM_adjArr;
extern sparseFactor    GlbD_adjArr;
extern sparseFactor    GlbA11;
extern sparseFactor    GlbA12T;
extern sparseFactor    GlbA21T;
extern sparseFactor    GlbM11;
extern sparseFactor    GlbM12T;
extern sparseFactor    GlbM21T;
extern sparseFactor    GlbD11;
extern sparseFactor    GlbD12T;
extern sparseFactor    GlbD21T;
extern DOUBLE*         Glbrhs;
extern DOUBLE*         GlbrhsMass;

extern DomainConnection SubToElem, ElemToNode, SubToNode, NodeToSub, SharedNodes;

extern INT*            GlbToLocalNode;
extern INT*            LocalToGlbNode;
extern INT*            GlbToLocalElem;
extern INT*            LocalToGlbElem;
extern DOUBLE          *GlbSendBufferPCGDof;
extern DOUBLE          *GlbRecvBufferPCGDof;
extern DOUBLE          *GlbSendBufferANSDof;
extern DOUBLE          *GlbRecvBufferANSDof;


extern INT*             NodeTouched;

extern INT*             GlblDofPerNode;

extern  CpCe            Glbcpce;
extern  sparseFactor    GlbG;

extern  DOUBLE*         DofnSub;      /* nVars, nSub on this DOF */

extern  INT*            IntfaceLen;
extern  INT*            IntfacePos;
extern  INT*            IntfaceLenUniform;
extern  INT*            IntfacePosUniform;
extern  INT             TotalIntfLen;
extern  INT             TotalIntfLenUniform;

extern  LONGINTC        totalDiagLenL;
extern  INT             maxMaster;

extern  INT             *GlbForward;
extern  INT             *GlbBack;
extern  INT             *GlbExtToGlbIntElem;
extern  INT             *GlbIntToGlbExtElem;

extern	INT		maxSetVars;
