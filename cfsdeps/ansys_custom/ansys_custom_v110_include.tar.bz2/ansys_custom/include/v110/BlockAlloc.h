/* sid 60.1 copy of BlockAlloc.h last changed by upd111 on 2006/10/09 19:55:36 */
#ifndef _BLOCK_ALLOC_H_
#define _BLOCK_ALLOC_H_

#include <sys/types.h>
#include "DomainDec.h"
#include "ResizeArray.h"

class BlockAlloc {
    char *block;
    INT index;
    INT blLen;
    ResizeArray<char *> allBlocks;
    INT nblock;
  public:
    BlockAlloc(INT l = 4096) :
        allBlocks(0) { blLen = l; block = 0; nblock = 0;}
    ~BlockAlloc();
    void *getMem(size_t nb);
};

void * operator new(size_t nbyte, BlockAlloc &block);
#if !defined(PCWINNT_SYS)
void * operator new[](size_t nbyte, BlockAlloc &block);
#endif

#endif
