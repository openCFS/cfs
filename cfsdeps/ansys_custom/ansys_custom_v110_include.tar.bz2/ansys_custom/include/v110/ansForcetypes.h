/* sid 60.1 copy of ansForcetypes.h last changed by upd111 on 2006/10/09 19:57:19 */

#include "ansysdef.h"


extern  INT  cCreateAnsForce(void);
extern  INT  cDeleteAnsForce(void);
extern  INT  cInquireAnsForce(INT,INT,INT);
extern  INT  cPutAnsForce(INT,INT,DOUBLE*);
extern  INT  cGetAnsForce(INT,INT,INT*,DOUBLE*);
extern  INT  cGetAnsForcePtr(INT,INT,INT*,DOUBLE**);
extern  INT  cActivateAnsForce(INT,INT,INT);
extern  INT  cDumpAnsForce(INT);


/****************************************************************
 global-level structure for ANSYS nodal forces
 ****************************************************************/
struct ansForce_str {        /* Name of the structure                           */
  INT       tag;             /* Tag for this instance of the force structure    */
  INT       numForceNodes;   /* Number of nodes with forces                     */
  INT       maxForceNode;    /* Maximum external node number having forces      */
  INT       numForce;        /* Total number of forces                          */
};

#define ansForceTag(forc)                (forc->tag)
#define ansForceNumForceNodes(forc)      (forc->numForceNodes)
#define ansForceMaxForceNode(forc)       (forc->maxForceNode)
#define ansForceNumForce(forc)           (forc->numForce)



/******************************************************************
 data-level structure for ANSYS nodal forces
 ******************************************************************/
struct forceData_str {   /* Name of the structure                                    */
  char       modified;   /* Flag indicating whether this force has been modified     */
  char       internal;   /* Flag indicating whether this force is internal to object */
  INT        dof;        /* External DOF value                                       */
  char       active;     /* Flag indicating if force is active or inactive           */
  DOUBLE    *values;     /* Vector containing force values (we store 4 values)       */
                         /*        (1:2) current real,imag values                    */
                         /*        (3:4) previous real,imag values                   */ 
  forceData *nextForce;  /* Pointer to the next force data structure for this node   */
                         /* If this pointer is NULL, then this is the last stored    */
                         /* force for this node                                      */
};

#define forceDataModified(fData)         (fData->modified)
#define forceDataInternal(fData)         (fData->internal)
#define forceDataDof(fData)              (fData->dof)
#define forceDataForceActive(fData)      (fData->active)

#define forceDataValuesPtr(fData)        (fData->values)
#define forceDataValuesVec(fData,i)      (fData->values[i])

#define forceDataNextForcePtr(fData)     (fData->nextForce)

