/* sid 60.24 copy of C_AnsysModele.h last changed by eedelor on 2006/08/21 13:10:39 */
/*******************************************************************************
 *
 *   C_AnsysModele.h - 
 *               
 * 
 * |Module:  API with Ansys Modele
 *
 * |Description: 
 *
 * |Includes:	
 *        
 * |Auteur: Emmanuel DELOR
 *
 * |Creation: July 2005
 *
 * |Version:
 *
 * |Historique:
 *
 * |Copyright:	copyright(c) 2006 SAS IP, Inc.  All rights reserved.
 *
 *
 ******************************************************************************/


#ifndef __C_ANSYSMODELE_ 
#define __C_ANSYSMODELE_ 1

#include "cadoe.h"
#include "cadoesys.h"
#include "bf.h"
#include "C_MessageTool.h" 
#include "ansysdef.h"
#include "elempr.h"
#include "Fx_Info.h"
#include "extmodl.h"   // for elmget
#include "C_VecPi.h"
#include "CadoeAnsys.h"

#if defined(LOWERCASENOUNDER_SYS)
#define SortComp		sortcomp
#define dofc                    dofc
#define dofiqr			dofiqr
#define dnodgt			dnodgt
#define sxnl_isResult		sxnl_isresult
#endif

#if defined(UPPERCASENOUNDER_SYS)
#define Sortcomp		SORTCOMP
#define dofc                    DOFC
#define dofiqr			DOFIQR
#define dnodgt			DNODGT
#define sxnl_isResult		SXNL_ISRESULT
#endif

#if defined(LOWERCASEUNDER_SYS)
#define SortComp                sortcomp_
#define dofc                    dofc_
#define dofiqr			dofiqr_
#define dnodgt			dnodgt_
#define sxnl_isResult		sxnl_isresult_
#endif

extern "C" {
  SUBROUTINE SortComp (int*, int*);
  INT  cGetAnsElmExt2IntListPtr(INT**);
  INT FUNCTION dofc(int*, int*, double*, double*);
  SUBROUTINE dofiqr(int*, int*, int*);
  INT FUNCTION dnodgt(int*, int*, double*);
  INT FUNCTION sxnl_isResult(int *result);
}

class C_ConstraintEquation
{
 public:
  C_ConstraintEquation(int id);
  virtual ~C_ConstraintEquation() {IV_FREE(_dofList);};
  
  typedef enum {
    E_TYPE_CP = 0,
    E_TYPE_CE
  } E_TYPE;
  
  virtual int Resize(int size);
  virtual int Read(FILE *fp);
  virtual int Write(FILE *fp);
  int getType() {return _type;}
  int getSize() {return _size;};
  
 public:
  int	_id;	// identifiant 1 <= _id <= nbCE
  E_TYPE _type;
  int	_size;
  IVEC *_dofList;
};

class C_CP : public C_ConstraintEquation
{
 public:
  C_CP(int id) : C_ConstraintEquation(id) {_type = E_TYPE_CP;};
  ~C_CP() {};
  
  static IVEC *S_dofBuffer;
  
  void FillSummary(string &message);
  int ReadFullFile();
};

class C_CE : public C_ConstraintEquation
{
 public: 
  C_CE(int id) : C_ConstraintEquation(id) {_type = E_TYPE_CE; _coefsList=NULL;_cnst=0.;};
  ~C_CE() {V_FREE(_coefsList);};
  
  virtual int Resize(int size);
  
  void saveCnst() {_cnst = _coefsList->ve[_size];};
  void setCnstZero() {_coefsList->ve[_size] = 0.;};
  void restoreCnst() {_coefsList->ve[_size] = _cnst;};

  int ReadFullFile();
  int WriteFullFile();
  
  int Read(FILE *fp);
  int Write(FILE *fp);

  void FillSummary(string &message);
  
  static IVEC *S_dofBuffer;
  static VEC *S_coefsBuffer;

 protected:
  VEC  *_coefsList; 
  double _cnst;
};

class C_EntitieCriterion
{
public: 
  C_EntitieCriterion() {};
  virtual ~C_EntitieCriterion() {};
  
  virtual bool isActive(int indice) = 0;
  virtual int findElemNeighBour(int elem, C_VecPi<int> &neighBourList) = 0;
};

class C_AnsysModele
{
public:
  // constructor 
  C_AnsysModele()  
  { 
    _id = -1;
    _nbElements = -1;
    _nbNodes = -1;
    _nbDofPerNode = -1;
    _structural = false;
    _contact = -1;
    _isContactElements = -1;
    _nrkey = -1;
    _nbcs = -1;
    _nbddl = -1;
    
    _maxSizeCP = 0;
    _maxSizeCE = 0;
    _elmListOut = NULL;
    _Forward = NULL;
    _Back = NULL;
    _Order = NULL;
    _curdof = NULL;
    _ContactDOFMarker = NULL;
  };
  
  // destructor
  virtual ~C_AnsysModele() 
  {
    set <C_CP* >::iterator itcp;
    for (itcp = _listCP.begin(); itcp != _listCP.end(); itcp++)
      delete (*itcp);
    set <C_CE* >::iterator itce;
    for (itce = _listCE.begin(); itce != _listCE.end(); itce++)
      delete (*itce);
    IV_FREE(C_CP::S_dofBuffer);
    IV_FREE(C_CE::S_dofBuffer);
    V_FREE(C_CE::S_coefsBuffer);
  };
  
  // get the version of the object 
  const char	*Version() const { return (char *)"6";}
  
  int getNbElements() {return _nbElements;}
  int getNbNodes() {return _nbNodes;}
  int getNbDofPerNode() {return _nbDofPerNode;}
  int getStructural() {return _structural;}
  int getContact() {return _contact;}
  int isContactElement() {return _isContactElements;}
  int getNbddl() {return _nbddl;};
  int getNbcs() {return _nbcs;}
  int getNrkey() {return _nrkey;}
  int* getContactDOFMarker() {return _ContactDOFMarker;}
  
  C_VecPi<int> &getFullToBcs() {return _FullToBcs;}
  C_VecPi<int> &getBcsToAns() {return _BcsToAns;}
  C_VecPi<int> &getAnsToBcs() {return _AnsToBcs;}
  
  C_VecPi<int> &getListPres() {return _listPres;}
  C_VecPi<double> &getValPres() {return _valPres;}
  C_VecPi<double> &getHugeUinci() {return _hugeUinci;};
  
  // apply prescribed on UDisp
  int applyPres(C_VecPi<double> &UDisp);
  
  // read CPCE in FULL file
  virtual int readCpCeFromFullFile();
  
  // build connectivity between nodes and elements
  virtual int buildConnectivity();
  
  // initialize object 
  virtual int initialize();

  // Copy Fortran Adress
  virtual void copyFortranAdress(C_AnsysModele *model);
  
  // initialize mapping tables (BCS <-> ANS <-> FULL)
  virtual int InitMapping(void);
  
  /// set pointers to fortran memory
  virtual void InitFortran(int *Order, int *Back, int *Forward,
			   int *First, int *Last, int *DofBits,
			   int *curdof, int *ContactDOFMarker)
  {
    _Order = Order;
    _Back = Back;
    _Forward = Forward;
    _First = First;
    _Last = Last;
    _DofBits = DofBits; 
    _curdof = curdof;
    _ContactDOFMarker = ContactDOFMarker;
  }
  
  // same bounadry conditions between two models ?
  bool isSameBC(C_AnsysModele *model);
  
  // is there internal nodes ?
  bool internalNodes();
  
  // get and set fortran variables
  static void fxSetInfoInt(E_info_fx eInfoFx, int ival) {double ddum; fx_setinfo(&eInfoFx,&ival,&ddum);}; 
  static void fxSetInfoDbl(E_info_fx eInfoFx, double dval) {int idum; fx_setinfo(&eInfoFx,&idum,&dval);}; 
  static void fxGetInfoInt(E_info_fx eInfoFx, int &ival) {double ddum; fx_getinfo(&eInfoFx,&ival,&ddum);}; 
  static void fxGetInfoDbl(E_info_fx eInfoFx, double &dval) {int idum; fx_getinfo(&eInfoFx,&idum,&dval);}; 
  
  // BCS space <-> Nodal space
  int IndToNod(C_VecPi<double> &VInd, C_VecPi <double> &VNod);
  int IndToNodExp(C_VecPi<double> &VInd, C_VecPi<double> &VNod, bool ApplyAllBC);
  int NodToInd(C_VecPi<double> &VNod, C_VecPi<double> &VInd);
  
  // manage HUGE values
  int fillHuge(C_VecPi<double> &UDisp);
  int restoreHuge(C_VecPi<double> &UDisp);
  int zeroHuge(C_VecPi<double> &UDisp);
  
  // apply contribution of slaves DOFs to master DOFs
  void DerivativeCpGtU(C_VecPi<double> &Uprev);
  void DerivativeGtU(C_VecPi<double> &Uprev);
  
  // assembly elements
  void Sfform(C_VecPi<double> &Uprev);
  
  // get number of contact DOFs
  int getNbDofContact();
  
  // internal <-> external representation 
  inline int getNodeIndice (int numero) {return _Forward[numero-1]-1;}
  inline int getNodeNumero (int indice) {return _Back[indice];};
  inline int getElementIndice (int numero) {return _elmListOut[numero]-1;}
  inline int getElementNumero (int indice) {return _Order[indice];}
  inline int getPremInc (int numero) {return getNodeIndice(numero) * _nbDofPerNode;};
  
  // get nodes (labels) of an element (label)
  int elementToNodes(int numElem, int numNodes[NNMAX+1]) 
  {
    int nbNodes = elmget(&numElem,_elmdat,numNodes); 
    /* SortComp(&nbNodes,numNodes);*/
    return nbNodes;
  };
  
  // get elements (indices) of nodes (indice) 
  int nodeToElements(int indNode, int *&indElems) {indElems = &(_connecInv[_pConInv[indNode]]); return(_pConInv[indNode+1]-_pConInv[indNode]);}
  
  // get the list of BCS dofs associated to nodes o list of element 
  int elementToBcsDof(C_VecPi<int> &elems, C_VecPi<int> &dofBcs);
  
  // get the list of element associated to a list of nodes
  int NodeToElem(BVEC *nodes, BVEC *elems);  
  
  // build region with a critere
  int buildRegion(int nbEntities, C_EntitieCriterion &critere, set <C_VecPi<int> *> &regions);
  
  // computes the elements to assembly to get correct forces on DOF in bDofInd
  int ElemToAssembly(BVEC *bDofInd, BVEC *bDofNod, IVEC *listElem, BVEC *bNodes, int indiceNodeToAdd = -1);
  
  // get type of an element (label)
  int getTypeGeometrique(int numElem){
    int etype;
    elmget(&numElem,_elmdat,_nodes);
    etype = _elmdat[1];		// EL_TYPE=2
    etyget(&etype,_ielc);
    return _ielc[1];		// JETYP=2 in echprm.inc
  }
  
  // get ith keyoptof an element (label)
  int getKeyopt(int numElem, int keyopt){
    int etype;
    elmget(&numElem,_elmdat,_nodes);
    etype = _elmdat[1];		// EL_TYPE=2
    etyget(&etype,_ielc);
    return _ielc[1+keyopt];	
  }
  
  // management of CP, CE and prescribed
  int getPrescribed();
  int zeroG0();
  int restoreG0();
  
  // IO
  virtual int Write (FILE *fp);
  virtual int Read (FILE *fp);
  
  double MemSize();

  int printCPCE();
  int FillSummary(string &message);
  
protected:
  int _ielc[IELCSZ+1];
  int _elmdat[EL_DIM+1];
  int _nodes[NNMAX+1];
  C_VecPi<int> _pConInv;
  C_VecPi<int> _connecInv;
  
protected:
  int _id;
  int _nbElements;	// nombre d'elements
  int _nbNodes;		// nombre de noeuds 
  int _nbDofPerNode;
  bool _structural;
  int _contact;
  int _isContactElements;
  int _nrkey;
  int _nbcs;
  int _nbddl;

  C_VecPi<int> _FullToBcs;
  C_VecPi<int> _BcsToAns;
  C_VecPi<int> _AnsToBcs;

public:
  int *_Forward;	// external to internal node representation
  int *_Back;		// internal to external node representation
  int *_Order;		// internal to external element representation
  
  int *_First;
  int *_Last;
  int *_DofBits;
  
  int *_curdof;
  int *_ContactDOFMarker;
  
  int *_elmListOut;	// external to internal element representation
  
protected:
  int _maxSizeCP;
  set <C_CP* > _listCP;
  int _maxSizeCE;
  set <C_CE* > _listCE;
  
  C_VecPi<int> _listPres;
  C_VecPi<double> _valPres;
  C_VecPi<double> _hugeUinci;
  
  typedef enum
    {
      E_PTRST = 1,
      E_PTRTH = 2,
      E_PTREL = 3,
      E_PTRMAG = 4,
      E_PTRFL = 5
    } E_TYPE_RESULT;
  
};

C_AnsysModele * GLOB_GetAnsysModele();
C_AnsysModele *GLOB_GetCopyModel();

#endif 
