/* sid 60.1 copy of FEM_refineTet.h last changed by upd111 on 2005/07/21 19:41:24 */
/*  FEM_refineTet.h */
/*
 * *** ansys(r) copyright(c) 1999
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_refineTet.h
 *  Prototypes and macros for refining tetrahedral meshes.
 *
 */

#ifndef FEM_REFINETET
#define FEM_REFINETET

#include "FEM_cdbtypes.h"

#ifdef __cplusplus
extern "C" {
#endif

                                 /* ========================================= */
                                 /* === FEM_reProcessTet_2Ref: process a      */
                                 /* === tetrahedral element for splitting     */
                                 /* === using 2-Refinement.                   */
INT FEM_reProcessTet_2Ref (
   FACELIST_OBJ obj_ellist,      /* the element list                          */
   NODELIST_OBJ obj_nlist,       /* the node list                             */
   FACE_OBJ obj_elem,            /* tetrahedron to be split                   */
   FEM_BOOLEAN detached,         /* TRUE if not associated with solid model   */
   FEM_BOOLEAN no_lines,         /* TRUE if no new nodes can be created on
                                    lines                                     */
   DEQUE_OBJ obj_pyr_deque,      /* deque containing wedges in trans region   */
   DEQUE_OBJ obj_wedge_deque  ); /* deque containing wedges in trans region   */

                                 /* ========================================= */
                                 /* === FEM_reProcessTet_3Ref: process a      */
                                 /* === tetrahedral element for splitting     */
                                 /* === using 3-Refinement.                   */
INT FEM_reProcessTet_3Ref (
   FACELIST_OBJ obj_ellist,      /* the element list                          */
   NODELIST_OBJ obj_nlist,       /* the node list                             */
   FACE_OBJ obj_elem,            /* tetrahedron to be split                   */
   FEM_BOOLEAN detached,         /* TRUE if not associated with solid model   */
   FEM_BOOLEAN no_lines,         /* TRUE if no new nodes can be created on
                                    lines                                     */
   DEQUE_OBJ obj_pyr_deque,      /* deque containing wedges in trans region   */
   DEQUE_OBJ obj_wedge_deque  ); /* deque containing wedges in trans region   */

                                 /* ========================================= */
                                 /* === FEM_reProcessTet_tohex: process a     */
                                 /* === tetrahedral element for splitting     */
                                 /* === into 4 hexes                          */
                                 /* === Return: EXIT_SUCCESS or EXIT_FAILURE  */
INT FEM_reProcessTet_tohex (
   ELEMENTLIST_OBJ obj_ellist,   /* the element list */
   NODELIST_OBJ obj_nlist,       /* the node list */
   FACE_OBJ obj_elem,            /* tetrahedron to be split */
   FEM_BOOLEAN detached,         /* TRUE if not associated with solid model */
   FEM_BOOLEAN no_lines  );      /* TRUE if no new nodes can be created on
                                    lines                                     */

                                 /* ========================================= */
                                 /* === FEM_reEliminateWedgesInTetMesh:       */
                                 /* === eliminate wedges from transition      */
                                 /* === region of tet meshes.  These wedges   */
                                 /* === were created in the 3d tet templates. */
INT FEM_reEliminateWedgesInTetMesh (
   ELEMENTLIST_OBJ obj_ellist,   /* element list                              */
   NODELIST_OBJ obj_nlist,       /* element list                              */
   DEQUE_OBJ obj_deque,          /* deque of wedges to eliminate              */
   FEM_BOOLEAN detached  );          /* TRUE if mesh is detached from solid model */

                                 /* ========================================= */
                                 /* === FEM_reEliminatePyramidsInTetMesh:     */
                                 /* === eliminate pyramidss from transition   */
                                 /* === region of tet meshes.  These pyramids */
                                 /* === were created in the 3d tet templates. */
INT FEM_reEliminatePyramidsInTetMesh (
   ELEMENTLIST_OBJ obj_ellist,   /* element list                              */
   DEQUE_OBJ obj_deque,          /* deque of pyramids to eliminate            */
   FEM_BOOLEAN detached  );      /* TRUE if mesh is detached from solid model */

                                 /* ========================================= */
                                 /* === FEM_reDoTetQuadRetain:  Any tets that */
                                 /* === have an edge that has its             */
                                 /* === EDGE_QUAD_RETAIN flag set needs to be */
                                 /* === split into 2 edges so quads can be    */
                                 /* === maintained in an adjacent area.       */
INT FEM_reDoTetQuadRetain (
   ELEMENTLIST_OBJ obj_ellist,   /* element list                              */
   FEM_BOOLEAN detached  );      /* TRUE if detached from solid model         */

                                 /* ========================================= */
                                 /* === FEM_reChooseTetDiagonal: given 6 nodes*/
                                 /* === enclosing 4 tetrahedra, determine     */
                                 /* === which diagonal is best to define the  */
                                 /* === 4 tetrahedra.  This routine           */
                                 /* === determines which diagonal to use in   */
                                 /* === one of 2 ways:                        */
                                 /* ===                                       */
                                 /* ===    1.  By maximizing the minimum      */
                                 /* ===        sphere ratio, or               */
                                 /* ===    2.  by optimizing the valence of   */
                                 /* ===        nodes involved.                */
                                 /* ===                                       */
                                 /* === Method 1. is used if any of the nodes */
                                 /* === are boundary nodes. Method 2. is used */
                                 /* === if none of the nodes are boundary     */
                                 /* === nodes. The routine calling this       */
                                 /* === function must decide which method to  */
                                 /* === use and send in either 1 or 2 for     */
                                 /* === method parameter.  The routine that   */
                                 /* === calls this function must determine    */
                                 /* === this because this function can not    */
                                 /* === call FEM_noIsBoundaryNode because     */
                                 /* === edge and face geo entities may not be */
                                 /* === set up for the edges attached to the  */
                                 /* === nodes                                 */
                                 /* === Return: EXIT_SUCCESS or EXIT_FAILURE  */
                                 /* ========================================= */
INT FEM_reChooseTetDiagonal(
   NODE_OBJ obj_node0,/* new nodes on the tet. */
   NODE_OBJ obj_node1,
   NODE_OBJ obj_node2,
   NODE_OBJ obj_node3,
   NODE_OBJ obj_node4,
   NODE_OBJ obj_node5,
   INT method,        /* see comment in Function description above  */
   INT parent,        /* (IN) id of element being refined           */
   INT *which_diag ); /* (OUT) which_diag == 1, then use diag 0 - 5 */
                      /*                     2, then use diag 1 - 3 */
                      /*                     3, then use diag 2 - 4 */


INT FEM_reBendElemEdges(
    ELEMENT_OBJ obj_elem,
    INT contToNbr ) ;


#ifdef __cplusplus
}
#endif

#endif
