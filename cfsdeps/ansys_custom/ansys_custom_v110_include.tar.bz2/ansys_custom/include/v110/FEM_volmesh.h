/* sid 60.1 copy of FEM_volmesh.h last changed by upd111 on 2005/07/21 19:41:56 */

/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 1999 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_volmesh.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_volmesh.h
 *  Prototypes and macros for FEM_volmesh
 *
 */

#ifndef FEM_VOLMESH_H
#define FEM_VOLMESH_H

/*------------------------ Constants -------------------------------------------*/

/*------------------------ Data Structures -------------------------------------*/

/*------------------------ Globals - used in only FEM_hd files -----------------*/

/*------------------------ Prototypes ------------------------------------------*/

#ifdef __cplusplus
extern "C" {
#endif


                           /* ================================================= */
                           /* === FEM_volmesh: mesh a volume given the mesh     */
                           /* === object containing a closed shell of tris      */
                           /* === and/or quads                                  */
                           /* === Return: INT EXIT_SUCCESS or EXIT_FAILURE      */
                           /* ================================================= */
INT FEM_volmesh(
   INT vnum,               /* the volume number                                 */
   MESH_OBJ obj_mesh,      /* (IN/OUT) the current mesh object containing quad  */
                           /*  and/or tri facets                                */
   INT num_nodes,          /* (IN) number of nodes on the volume boundary.      */
                           /*      These nodes are at the front of the          */
                           /*      nodelist in obj_mesh.                        */
   INT num_facets,         /* (IN) number of facets on the volume boundary.     */
                           /*      These facets are at the front of the         */
                           /*      facelist in obj_mesh.                        */
   INT mesher,             /* (IN) 1 = PLG tet mesher                           */
                           /*      2 = SJO hex dominant                         */
   INT midnodes,           /* (IN) 1 = midnodes on edges                        */
   INT project,            /* (IN) 0 = project midnodes, 1 = striaght           */
   INT debug,             /* (IN) debug flag                                   */
   INT fromBrutForceRef);
                           /* ================================================= */

                           /* ================================================= */
                           /* === FEM_voTetPLG: C interface to PLG mesher       */
                           /* === Return: INT EXIT_SUCCESS or EXIT_FAILURE      */
                           /* ================================================= */
INT FEM_voTetPLG ( 
   INT vnum,               /* (IN)     The volume number                        */
   MESH_OBJ obj_mesh,      /* (IN/OUT) the current mesh object containing quad  */
                           /*          and/or tri facets                        */
   INT num_nodes,          /* (IN)     number of nodes on volume boundary.      */
                           /*          Nodes are placed at front of node list   */
                           /*          in obj_mesh.                             */
   INT num_facets,         /* (IN)     number of facets on volume boundary.     */
                           /*          Facets are placed at front of face list  */
                           /*          in obj_mesh.                             */
   INT fromBrutForceRef);


#ifdef __cplusplus
}
#endif

#endif

