/* sid 60.2 copy of ggi_header_f.h last changed by gawang on 2005/09/22 19:58:47 */
*comdeck,ggi_header_f     user                                        gawang
C /* C style Comments cannot be include for FORTRAN files. */
      IMPLICIT NONE
C
C---- Set the option for real or double precision.
C
#if defined (ggireal) || defined (GGIREAL)
#  define REAL_GGI     real
#else
#  define REAL_GGI     double precision
#endif
C
C---- Set FUNCTION/SUBROUTINE/CALLTYP if NOSTDCALL is not defined
C     on MS Windows for Ansys platforms (taken from computer.h).
C
#if defined (PCWINNT_SYS)                        /* ALL NTs */
#  if !defined (NOSTDCALL)
#    undef FUNCTION
#    define FUNCTION __stdcall
#    undef SUBROUTINE
#    define SUBROUTINE void __stdcall
#    undef CALLTYP
#    define CALLTYP __stdcall
#  endif
#endif
C
C---- Useful integer constants 
C
      INTEGER INT_ZERO, INT_ONE, INT_TWO, INT_BIG
      PARAMETER (INT_ZERO=0,INT_ONE=1,INT_TWO=2, INT_BIG =2**30-1)
      INTEGER GGI_FALSE, GGI_TRUE
      PARAMETER (GGI_FALSE=0,GGI_TRUE=1)
      INTEGER GGI_DEB
      PARAMETER (GGI_DEB=0)
C
C---- Useful real constants 
C
      REAL_GGI ZERO,ONE,TWO,THREE,FOUR,FIVE,SIX,EIGHT,TEN,
     &         TWELVE,HUNDRED
      PARAMETER(ZERO=0.0D0,ONE=1.0D0,TWO=2.0D0,THREE=3.0D0,
     &          FOUR=4.0D0,FIVE=5.0D0,SIX=6.0D0,EIGHT=8.0D0,
     &          TEN=10.0D0,TWELVE=12.0D0,HUNDRED=1.0D2)
C
C---- Useful real fractions
C
      REAL_GGI ONETHIRD, HALF, TWOTHIRDS, QUARTER
      REAL_GGI THREEQUARTERS, THREEHALVES
      PARAMETER (ONETHIRD = ONE/THREE, HALF = ONE/TWO)
      PARAMETER (TWOTHIRDS = TWO/THREE, QUARTER = 0.25D0)
      PARAMETER (THREEHALVES = 1.5D0, THREEQUARTERS = 0.75D0)
C
C---- Useful truncated irrationals
C
      REAL_GGI PI
      PARAMETER (PI = 3.141592654)
C
C---- Useful big/small numbers
C
      REAL_GGI BN, SN
      PARAMETER(BN=1.0D+30,SN=1.0D-30)

