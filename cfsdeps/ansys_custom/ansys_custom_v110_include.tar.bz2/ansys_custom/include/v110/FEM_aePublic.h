/* sid 60.3 copy of FEM_aePublic.h last changed by upd111 on 2006/08/16 16:00:58 */
#ifndef FEM_AEPUBLIC
#define FEM_AEPUBLIC

#include "FEM_cdbtypes.h"
#include "FEM_Public.h"
#include "FEM_cell.h"
#include <vector>

typedef enum {UDIR, 
              VDIR } SEAMDIR;

class AREA_TYP : public CELL_TYP {

   private:
      CELLUSE_PTYP mp_lines;
      INT m_num_lines;
      unsigned m_closed_inu:1;
      unsigned m_closed_inv:1;
      unsigned m_nonmanifold:1;
      DOUBLE m_seamLengthU;
      DOUBLE m_seamLengthV;
      INT m_num_hardpoints;
      INT m_num_loops;
      NEXTCELL_PTYP m_p_hpts; 

      INT seamLineLength( SEAMDIR seamDir, DOUBLE &length );
      INT getSeamLineEndPointsUvs(   SEAMDIR uv_dir,
          DOUBLE uv0[2],  /* uv of bottom point, I/O */ 
          DOUBLE uv1[2]);  /* uv of top point,    I/O */ 
      INT findTheClosePointOnLine( 
          INT line_id, 
          SEAMDIR uv_dir, // close dir
          DOUBLE *uv0,  // uv value of one point
          DOUBLE range,  // the param range of the surface in the direction of uv_dir                                  
          DOUBLE *tt,  // the param value of the new point on the line
          DOUBLE *a_xyzout,  // the new point to find
          DOUBLE *uv ); // the uv to find
      void findLineThatCrossesSeamOrWhoseEndPointIsOnSeam( const std::vector<INT> &cLines, INT &iLineId, INT &iEndPointOnSeam, INT &iDir );


   public:
      AREA_TYP() { mp_lines = NULL; 
                   m_num_lines = 0; 
                   m_nonmanifold = 0;
                   m_closed_inu = 0; 
                   m_closed_inv = 0; 
                   m_num_loops = 0; 
                   m_seamLengthU = -HUGE_VAL;
                   m_seamLengthV = -HUGE_VAL;};
      ~AREA_TYP() { };
      void Delete() { DeleteCell(); };

      AREA_PTYP GetNext( ) { return (AREA_PTYP)CELL_TYP::GetNext(); };

      void InitArea( ) { InitCellArea();
                         mp_lines = NULL;
                         m_num_lines = 0;
                         m_nonmanifold = 0;
                         m_closed_inu = m_closed_inv = 0;
                         m_num_hardpoints = 0;
                         m_num_loops = 0;
                         m_p_hpts = NULL;                   
                         m_seamLengthU = -HUGE_VAL;
                         m_seamLengthV = -HUGE_VAL; };

      INT SetLine( const LINE_PTYP obj_line, const INT orientation );
      INT NumLines() const { return m_num_lines; };
      CELLUSE_PTYP LineList( ) const { return mp_lines; };
      INT LineList( LINE_PTYP **a_lines, INT &num_lines ) const;
      INT KpList( KP_PTYP **a_kps, INT &numkps ) const;
      INT NumKps( INT &numkps ) const;
      FEM_BOOLEAN IsBndKp( INT kp_id ) const;
      FEM_BOOLEAN IsBndHdpt( INT kp_id ) const;
      FEM_BOOLEAN IsBndLine( INT line_id ) const;

      void SetClosedInU( const FEM_BOOLEAN closed = TRUE )
      {
         if ( closed ) m_closed_inu = 1;
         else m_closed_inu = 0;
      }
      void SetClosedInV( const FEM_BOOLEAN closed = TRUE )
      {
         if ( closed ) m_closed_inv = 1;
         else m_closed_inv = 0;
      }

      FEM_BOOLEAN IsClosedInU() const
      {
         if ( m_closed_inu == 1 ) return TRUE;
         else return FALSE;
      }

      FEM_BOOLEAN IsClosedInV() const
      {
         if ( m_closed_inv ) return TRUE;
         else return FALSE;
      }

      FEM_BOOLEAN IsClosed() const
      {
         if ( m_closed_inu == 1 || m_closed_inv ) return TRUE;
         else return FALSE;
      }

      void SetIsNonManifold( const FEM_BOOLEAN stat = TRUE )
      {
         if ( stat ) m_nonmanifold = 1;
         else m_nonmanifold = 0;
      }

      FEM_BOOLEAN IsNonManifold() const
      {
         if ( m_nonmanifold == 1 ) return TRUE;
         else return FALSE;
      }
      FEM_BOOLEAN IsLineOnSeam( LINE_PTYP obj_line ) const
      {
         if ( !IsClosed() ) return FALSE;
         CELLUSE_PTYP pobj_line = mp_lines;
         while ( pobj_line ) {
            if ( pobj_line->GetCell() == obj_line ) {
               if ( pobj_line->Orientation() == 0 ) {
                  return TRUE;
               }
               else {
                  return FALSE;
               }
            }
            pobj_line = pobj_line->GetNext();
         }
         return FALSE;
      }

      INT NextLineOnArea( LINE_PTYP obj_line, KP_PTYP &obj_kp,
                          LINE_PTYP *obj_nextline, INT *direction );

      INT NumHardPoints() const { return m_num_hardpoints; };
      INT SetHardPoint( const KP_PTYP obj_kp );
      FEM_BOOLEAN IsHpt( INT kp_id ) const
      {
         NEXTCELL_PTYP p_hpt = m_p_hpts;
         while ( p_hpt ) {
            if ( ((KP_PTYP)(p_hpt->GetCell()))->GetId() == kp_id ) {
               return TRUE;
            }
            p_hpt = p_hpt->GetNext();
         }
         return FALSE;
      };

      INT NumAdjVols() const { return NumAdjCells(); };
      VOL_PTYP GetAdjVol() const { return (VOL_PTYP)GetAdjCell(); };

      VOL_PTYP GetNextAdjVol( VOL_PTYP obj_vol ) const
      {
         return (VOL_PTYP)GetNextAdjCell( (CELL_PTYP)obj_vol );
      };

      void GetAdjLines( INT kp_id, LINE_PTYP &obj_line1,
                        LINE_PTYP &obj_line2 ) const;
      INT NumLoops();
      INT GetLoop( INT loopnum, LINE_PTYP **aobj_looplines );
      INT SeamLength( SEAMDIR seamDir, DOUBLE &length ) ;
      LINE_PTYP commonLine( AREA_PTYP pcArea );
      void CommonLinesAndVertices( AREA_PTYP pcArea, std::vector<LINE_PTYP> &cLines, std::vector<KP_PTYP> &cVertices );
      DOUBLE Length();
      INT GetOppositeLineOnArea( LINE_PTYP obj_line, LINE_PTYP &obj_oppLine );

};
 
#endif
