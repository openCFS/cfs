/* sid 60.1 copy of OutputWin.h last changed by jtm on 2006/05/15 19:43:28 */
/*
 * *** copyright(c) 2006 SAS IP, Inc.  All rights reserved.
 * *** ansys, inc.
 */
extern int  fBatch;

void FortranToOutputWin ( const void *buffer, unsigned bytes );
void CToOutputWin( char * inputBuf, int numChars );

