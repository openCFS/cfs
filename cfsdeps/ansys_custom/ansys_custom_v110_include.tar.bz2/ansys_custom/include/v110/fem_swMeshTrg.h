/* sid 60.1 copy of fem_swMeshTrg.h last changed by upd111 on 2005/07/21 19:42:56 */

/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 1999 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_swMeshTrg.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_swMeshTrg.h
 *  header file for FEM_swMeshTrg.c
 *
 */
#ifndef FEM_SWMESHTRG_INCLUDE
#define FEM_SWMESHTRG_INCLUDE

/*----------------- Globally accessible data types --------------------------*/

/*----------------- Globally accessible variables ---------------------------*/

/*----------------- Globally accessible macros ------------------------------*/

/*----------------- Globally accessible function prototypes -----------------*/

                               /* ========================================== */
                               /* === FEM_swMeshTrg: During volume           */
                               /* === sweeping, project the source area mesh */
                               /* === onto the target area.  Before calling  */
                               /* === this routine, make sure all lines on   */
                               /* === the target area area already meshed.   */
                               /* === Return: EXIT_SUCCESS or EXIT_FAILURE   */
                               /* ========================================== */
INT FEM_swMeshTrg(
   INT vnum,                     /* (IN)  volume being swept.                 */
   INT num_bnd_nodes,            /* (IN)  len of aobj_src_bnd_nodes.          */
   INT num_bnd_edges,            /* (IN)  len of a_iel and aobj_src_bnd_edges */
   NODE_OBJ *aobj_src_bnd_nodes, /* (IN)  boundary nodes on source area.      */
   EDGE_OBJ *aobj_src_bnd_edges, /* (IN)  boundary edges on source area.      */
   INT *a_iel,                   /* (IN)  connectivity of edges in            */
                                 /*       aobj_src_bnd_nodes to form boundary.*/
   INT num_trg_kps,              /* (IN)  length of a_trg_kps.                */
   INT *a_trg_kps,               /* (IN)  array of trg kp ids.                */
   INT num_trg_lines,            /* (IN)  length of a_trg_lines               */
   INT *a_trg_lines,             /* (IN)  array of trg line ids.              */
   INT num_vollines,             /* (IN)  length of a_vollines.               */
   INT *a_vollines,              /* (IN)  array of line ids on vnum           */
   INT source_area,              /* (IN)  source area for sweeping.           */
   INT target_area,              /* (IN)  target area for sweeping.           */
   FEM_BOOLEAN src_pos,          /* (IN)  TRUE if the source area is          */
                                 /*       positively oriented with respect to */
                                 /*       vnum.                               */
   FEM_BOOLEAN trg_pos,          /* (IN)  TRUE if the target area is          */
                                 /*       positively oriented with respect to */
                                 /*       vnum.                               */
   FEM_BOOLEAN lsmooth,          /* (IN)  TRUE if line smoothing should be    */
                                 /*       done on trg area.                   */
   FEM_BOOLEAN do_progress,
   INT debug );

#endif

