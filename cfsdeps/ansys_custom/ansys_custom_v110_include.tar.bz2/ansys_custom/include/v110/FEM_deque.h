/* sid 60.1 copy of FEM_deque.h last changed by upd111 on 2005/07/21 19:39:50 */
/*  FEM_deque.h */
/*
 * *** ansys(r) copyright(c) 1999
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_dePublic.h
 *  Contains the structures and prototypes for deque manipulation in the
 *  C meshin data base.  This file must be included in order for a deque can
 *  be used in any general file using the C meshing data base.  This file
 *  must be included after FEM_public.h

 *   INSTRUCTIONS for use:
 *        to use this module follow the following steps:
 *          1. declare a local variable to be a DEQUE_OBJ.
 *          2. Initialize the deque by calling FEM_deInitDeque();
 *          3. Push, Pop, Remove, Insert as Desired.
 *          4. When you are done with the deque, you must call
 *             FEM_deKillDeque() to free up memory used by the deque.
 *
 *       EXAMPLE:
 **********************************************************************
 *              DEQUE_OBJ obj_deque;
 *              INT data1, data2, data3, data4, data5;
 *              INT *data;
 *
 *              data1 = ...;
 *              data2 = ...;
 *              data3 = ...;
 *              data4 = ...;
 *              data5 = ...;
 *
 *              obj_deque = FEM_deInitDeque();
 *              loc_data1 = FEM_deTopPush( obj_deque, &data1 );
 *              loc_data2 = FEM_deTopPush( obj_deque, &data2 );
 *              loc_data3 = FEM_deTopPush( obj_deque, &data4 );
 *              loc_data4 = FEM_deTopPush( obj_deque, &data4 );
 *              loc_data5 = FEM_deInsert( obj_deque, loc_data2, &data5 );
 *              FEM_deRemove( obj_deque, loc_data3 );
 *
 *              data = FEM_deBottomPop( obj_deque );
 *              while ( !FEM_deIsEmpty( obj_deque ) ) {
 *                 data = FEM_deBottomPop( obj_deque );
 *              }
 *
 *              FEM_deKillDeque( obj_deque );
 *
 **********************************************************************
 */
#ifndef FEM_DEPUBLIC
#define FEM_DEPUBLIC

#ifdef __cplusplus
extern "C" {
#endif

                 /* ======================================================== */
                 /* === FEM_deInitDeque: Initializes and returns a deque     */
                 /* ======================================================== */
DEQUE_OBJ FEM_deInitDeque (  );

                 /* ======================================================== */
                 /* === FEM_deInitDeque: Initializes and returns a deque set */
                 /* === up to store doubles.                                 */
                 /* ======================================================== */
DEQUE_OBJ FEM_deInitDblDeque (  );

                 /* ======================================================== */
                 /* === FEM_deKillDeque: Frees up memory used in the deque   */
                 /* === After calling FEM_deKillDeque, nothing may be put    */
                 /* === back in the deque until FEM_deInitDeque is called    */
                 /* === again.                                               */
                 /* ======================================================== */
void FEM_deKillDeque (
   DEQUE_OBJ obj_deque  );  /* the deque to be killed.                       */

                 /* ======================================================== */
                 /* === FEM_deEmpty: Deletes all contents of the deque.      */
                 /* ======================================================== */
void FEM_deEmpty( 
   DEQUE_OBJ obj_deque );       /* the deque to be emptied.                */

                 /* ======================================================== */
                 /* === FEM_deTopPush: Push data onto the top of the         */
                 /* === deque.                                               */
                 /* ======================================================== */
ADDRESS_TYP FEM_deTopPush (
   DEQUE_OBJ obj_deque,      /* the deque to push data onto                  */
   ADDRESS_TYP p_data  );  /* the data to push onto the deque                */

                 /* ======================================================== */
                 /* === FEM_deTopPushDbl: Push data onto the top of the      */
                 /* === deque.                                               */
                 /* ======================================================== */
ADDRESS_TYP FEM_deTopPushDbl (
   DEQUE_OBJ obj_deque,      /* the deque to push data onto                  */
   DOUBLE dbl  );          /* the data to push onto the deque                */

                 /* ======================================================== */
                 /* === FEM_deBottomPush: Push data onto the bottom of       */
                 /* === the deque.                                           */
                 /* ======================================================== */
ADDRESS_TYP FEM_deBottomPush (  
   DEQUE_OBJ obj_deque,      /* the deque to push data onto                  */
   ADDRESS_TYP p_data  );  /* the data to push onto the deque                */

                 /* ======================================================== */
                 /* === FEM_deBottomPushDbl: Push data onto the bottom of    */
                 /* === the deque.                                           */
                 /* ======================================================== */
ADDRESS_TYP FEM_deBottomPushDbl (  
   DEQUE_OBJ obj_deque,      /* the deque to push data onto                  */
   DOUBLE dbl  );          /* the data to push onto the deque                */

                 /* ======================================================== */
                 /* === FEM_deInsertAbove: Insert data into the middle of    */
                 /* === the deque above p_loc. p_loc is the return value of  */
                 /* === either FEM_deTopPush, FEM_deBottomPush,              */
                 /* === FEM_deInsertAbove, or FEM_deInsert.                  */
                 /* === If p_loc == NULL, the data will be pushed onto the   */
                 /* === bottom of the deque by default.                      */
                 /* ======================================================== */
ADDRESS_TYP FEM_deInsertAbove (  
   DEQUE_OBJ obj_deque,         /* the deque to push data onto               */
   ADDRESS_TYP p_loc,           /* location in deque above which to insert   */
   ADDRESS_TYP p_data  );       /* the data to push onto the deque           */

                 /* ======================================================== */
                 /* === FEM_deInsertAboveDbl: Insert data into the middle of */
                 /* === the deque above p_loc. p_loc is the return value of  */
                 /* === either FEM_deTopPush, FEM_deBottomPush,              */
                 /* === FEM_deInsertAbove, or FEM_deInsert.                  */
                 /* === If p_loc == NULL, the data will be pushed onto the   */
                 /* === bottom of the deque by default.                      */
                 /* ======================================================== */
ADDRESS_TYP FEM_deInsertAboveDbl (  
   DEQUE_OBJ obj_deque,         /* the deque to push data onto               */
   ADDRESS_TYP p_loc,           /* location in deque above which to insert   */
   DOUBLE dbl );                /* the data to push onto the deque           */

                 /* ======================================================== */
                 /* === FEM_deInsertBelow: Insert data into the middle of    */
                 /* === the deque below p_loc. p_loc is the return value of  */
                 /* === either FEM_deTopPush, FEM_deBottomPush,              */
                 /* === FEM_deInsertAbove, or FEM_deInsert.                  */
                 /* === If p_loc == NULL, the data will be pushed onto the   */
                 /* === top of the deque by default.                         */
                 /* ======================================================== */
ADDRESS_TYP FEM_deInsertBelow (  
   DEQUE_OBJ obj_deque,         /* the deque to push data onto               */
   ADDRESS_TYP p_loc,           /* location in deque below which to insert   */
   ADDRESS_TYP p_data  );       /* the data to push onto the deque           */

                 /* ======================================================== */
                 /* === FEM_deInsertBelowDbl: Insert data into the middle of */
                 /* === the deque below p_loc. p_loc is the return value of  */
                 /* === either FEM_deTopPush, FEM_deBottomPush,              */
                 /* === FEM_deInsertAbove, or FEM_deInsert.                  */
                 /* === If p_loc == NULL, the data will be pushed onto the   */
                 /* === top of the deque by default.                         */
                 /* ======================================================== */
ADDRESS_TYP FEM_deInsertBelowDbl (  
   DEQUE_OBJ obj_deque,         /* the deque to push data onto               */
   ADDRESS_TYP p_loc,           /* location in deque below which to insert   */
   DOUBLE dbl );                /* the data to push onto the deque           */

                 /* ======================================================== */
                 /* === FEM_deTopPop: pop the data off of the top of the     */
                 /* === deque.  The data is removed from the deque.          */
                 /* ======================================================== */
ADDRESS_TYP FEM_deTopPop (
   DEQUE_OBJ obj_deque  );      /* the deque to pop data off of              */

                 /* ======================================================== */
                 /* === FEM_deTopPopDbl: pop the data off of the top of the  */
                 /* === deque.  The data is removed from the deque.          */
                 /* ======================================================== */
DOUBLE FEM_deTopPopDbl (
   DEQUE_OBJ obj_deque  );      /* the deque to pop data off of              */

                 /* ======================================================== */
                 /* === FEM_deBottomPop: pop the data off of the bottom      */
                 /* === of the deque.  The data is removed from the deque.   */
                 /* ======================================================== */
ADDRESS_TYP FEM_deBottomPop (
   DEQUE_OBJ obj_deque  );      /* the deque to pop data off of              */

                 /* ======================================================== */
                 /* === FEM_deBottomPopDbl: pop the data off of the bottom   */
                 /* === of the deque.  The data is removed from the deque.   */
                 /* ======================================================== */
DOUBLE FEM_deBottomPopDbl (
   DEQUE_OBJ obj_deque  );      /* the deque to pop data off of              */

                 /* ======================================================== */
                 /* === FEM_deTopLook: Look at the data on the top of the    */
                 /* === deque.  The data remains on the deque.               */
                 /* ======================================================== */
ADDRESS_TYP FEM_deTopLook (
   DEQUE_OBJ obj_deque  );      /* the deque to look at                      */

                 /* ======================================================== */
                 /* === FEM_deTopLookDBL: Look at the data on the top of the */
                 /* === deque.  The data remains on the deque.               */
                 /* ======================================================== */
DOUBLE FEM_deTopLookDbl (
   DEQUE_OBJ obj_deque  );      /* the deque to look at                      */

                 /* ======================================================== */
                 /* === FEM_deBottomLook: look at the data on the bottom     */
                 /* === of the deque.  The data remains on the deque.        */
                 /* ======================================================== */
ADDRESS_TYP FEM_deBottomLook (
   DEQUE_OBJ obj_deque  );      /* the deque to look at                      */

                 /* ======================================================== */
                 /* === FEM_deBottomLookDbl: look at the data on the bottom  */
                 /* === of the deque.  The data remains on the deque.        */
                 /* ======================================================== */
DOUBLE FEM_deBottomLookDbl (
   DEQUE_OBJ obj_deque  );      /* the deque to look at                      */

                 /* ======================================================== */
                 /* === FEM_deFindData: Attempt to find data in the deck     */
                 /* === that matches a given pointer (the data remains on    */
                 /* === the deque)                                           */
                 /* === Return: The (first) location in the deque where the  */
                 /* === data is stored.  NULL if it is not found             */
                 /* ======================================================== */
ADDRESS_TYP FEM_deFindData(
   DEQUE_OBJ obj_deque,         /* the deque object                          */
   ADDRESS_TYP p_data );        /* the data we are looking for               */

                 /* ======================================================== */
                 /* === FEM_deLinearRemove: Remove specific data from the    */
                 /* === deque.  A linear search through the deque is         */
                 /* === used to remove the data which may be slow.  If you   */
                 /* === know where in the deque the data is stored, call     */
                 /* === FEM_deRemove() instead.  All occurances of p_data are*/
                 /* === removed from the deque.                              */
                 /* ======================================================== */
INT FEM_deLinearRemove (
   DEQUE_OBJ obj_deque,       /* the deque to take data out of               */
   ADDRESS_TYP p_data  );     /* the data to take out of the deque           */

                 /* ======================================================== */
                 /* === FEM_deLinearRemoveDbl: Remove specific data from the */
                 /* === deque.  A linear search through the deque is         */
                 /* === used to remove the data which may be slow.  If you   */
                 /* === know where in the deque the data is stored, call     */
                 /* === FEM_deRemove() instead.  All occurances of p_data are*/
                 /* === removed from the deque.                              */
                 /* ======================================================== */
INT FEM_deLinearRemoveDbl (
   DEQUE_OBJ obj_deque,       /* the deque to take data out of               */
   DOUBLE dbl  );             /* the data to take out of the deque           */

                 /* ======================================================== */
                 /* === FEM_deRemove: Remove specific data from the deque.   */
                 /* ======================================================== */
void FEM_deRemove (
   DEQUE_OBJ obj_deque,       /* the deque to take data out of               */
   ADDRESS_TYP p_location  ); /* the location of the data to take out of the */
                              /* deque.  p_location is the pointer returned  */
                              /* from FEM_deTopPush or FEM_deBottomPush and  */
                              /* is a void pointer to the location of the    */
                              /* data to be removed from the deque.          */
                              /* If you did not save the return value from   */
                              /* the push or pop operation, you can call     */
                              /* FEM_deLinearRemove() which removes the data */
                              /* by doing a linear search through the deque  */
                              /* Only the ocurrance pointed to by p_location */
                              /* will be removed from the deque.             */

/* macros */

/*============================================================================*/
/* === Macro: FEM_deIsEmpty_C
 * === Author: mls
 * === Description: determine if a deque is empty.
 * === Arguments:
 *     DEQUE_OBJ obj_deque   the deque to look at
 * === Return: TRUE if there is nothing stored in the deque.
 * ===         FALSE if there is something stored in the deque.
 */
#define FEM_deIsEmpty_C( obj_deque )\
         !(((DEQUE_PTYP)obj_deque)->ps_top) ? TRUE : FALSE

/*============================================================================*/
/* === Macro: FEM_deLength_C
 * === Author: mls
 * === Description: return the number of things stored in the deque
 * === Arguments:
 *     DEQUE_OBJ obj_deque   the deque to look at
 */
#define FEM_deLength_C( obj_deque ) (((DEQUE_PTYP)obj_deque)->length)

#ifdef __cplusplus
}
#endif

#endif

