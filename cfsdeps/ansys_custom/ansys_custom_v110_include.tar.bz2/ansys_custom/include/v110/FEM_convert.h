/* sid 60.1 copy of FEM_convert.h last changed by upd111 on 2005/07/21 19:39:37 */
/*  FEM_convert.h */
/*
 * *** ansys(r) copyright(c) 1999
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_convert.h
 *  header file for FEM_convert.c
 *
 */
#ifndef FEM_CONVERT_INCLUDE
#define FEM_CONVERT_INCLUDE
/* === Bits used to set options to FEM_convert.c */

#define SETUP_AREA_EVAL            (1L<<0) /* Area evaluations on anum will
                                              be possible */
#define SETUP_LINE_EVAL            (1L<<1) /* Line evaluations will be
                                              possible  */
#define SETUP_NODE_SMOOTHABLE      (1L<<2) /* NODE_SMOOTHABLE flag in each
                                              node will be set */
#define SETUP_FACE_MIDNODE_PROJECT (1L<<3) /* flag in each face will be set */
#define SETUP_EDGE_GEO             (1L<<4) /* the geo entity of each edge will
                                              be determined and set */
#define SETUP_UV                   (1L<<5) /* the UV coordinates of all nodes
                                              will be calculated. */
#define SETUP_RETURN_MIDNODES      (1L<<6) /* the faces will be sotred with
                                              midnodes */
#define SETUP_ALL_LINES            (1L<<7) /* set up ALL lines for evaluations
                                              (not just the modifiable lines)
                                              SETUP_LINE_EVAL must also be set*/
#define SETUP_FRONT_SEGS           (1L<<8) /* set up an array of boundary
                                              segments defined in the paver
                                              for use with layer meshing. */
#define SETUP_FACE_GEO             (1L<<9) /* the geo entity of each face in
                                              volumes will be determined and
                                              set */
/* etc... */

#define SETUP_SMOOTHING  ( SETUP_AREA_EVAL | SETUP_LINE_EVAL |\
                           SETUP_NODE_SMOOTHABLE )
#define SETUP_CLEANUP    ( SETUP_EDGE_GEO )
#define SETUP_REFINEMENT ( SETUP_EDGE_GEO | SETUP_LINE_EVAL |\
                           SETUP_AREA_EVAL | SETUP_FACE_MIDNODE_PROJECT |\
                           SETUP_FACE_GEO )
#define SETUP_PAVING     ( SETUP_AREA_EVAL | SETUP_LINE_EVAL |\
                           SETUP_NODE_SMOOTHABLE | SETUP_FACE_MIDNODE_PROJECT |\
                           SETUP_EDGE_GEO )

/*----------------- Globally accessible function prototypes -----------------*/

                            /* ============================================= */
                            /* === FEM_convert: Set up the C meshing data    */
                            /* === base from arrays describing a mesh.  This */
                            /* === This is used to set up the c meshing data */
                            /* === base with an existing mesh to perform     */
                            /* === post processing on it or refinement       */
                            /* === rather than for meshing from scratch      */
                            /* === Return: INT  EXIT_SUCCESS or EXIT_FAILURE */
                            /* ============================================= */
INT FEM_convert (
   INT    anum,             /* (IN) current area number                      */
   INT    midelm,           /* (IN) whether areas have midnodes              */
   INT    nummx,            /* (IN) max number of nodes per element          */
   INT    num_bound,        /* (IN) number of boundary nodes                 */
   INT    num_internal,     /* (IN) number of internal nodes                 */
   INT    nelem,            /* (IN) number of elements                       */
   INT    *a_iel,           /* (IN) element array (nummx, *)                 */
   DOUBLE *a_coor2d,        /* (IN) parametric value of nodes                */
   DOUBLE *a_coor3db,       /* (IN) 3D locations of boundary nodes           */
   DOUBLE *a_coor3d,        /* (IN) 3D node locations                        */
   INT    *a_ibound,        /* (IN) Complete list of nodes on the boundary   */
                            /*      (including midside nodes                 */
   INT    nbound,           /* (IN) size of ibound                           */
   INT    options  );       /* (IN) options for C meshing data base - bits   */
                            /*      are set using options above (i.e.        */
                            /*      SETUP_XXX)                               */

                            /* ============================================= */
                            /* === FEM_coGetNodesArray: Allow access to the */
                            /* === file global fg_aobj_node in FEM_convert.c*/
                            /* === fg_aobj_node is a list of the nodes sent  */
                            /* === to the C meshing data base from the       */
                            /* === FORTRAN arrays.                           */
                            /* ============================================= */
NODE_OBJ *FEM_coGetNodesArray (  );

                            /* ============================================= */
                            /* === FEM_coFreeNodesArray: Free up the memory */
                            /* === used to store fg_aobj_node.  This is      */
                            /* === called from fem_convertbck_ after the C   */
                            /* === meshing data base is destroyed            */
                            /* ============================================= */
void FEM_coFreeNodesArray (  );


                            /* ============================================= */
                            /* === Function: FEM_coSetFaceMidnodeProjectFlag*/
                            /* === used to set midnode projetion flag on a   */
                            /* === face                                      */
                            /* ============================================= */
INT FEM_coSetFaceMidnodeProjectFlag (  );


                            /* ============================================= */
                            /* === Function: FEM_coSetElemMidnodeProjectFlag*/
                            /* === used to set midnode projetion flag on a   */
                            /* === element.                                  */
                            /* ============================================= */
INT FEM_coSetElemMidnodeProjectFlag (  );

#endif

