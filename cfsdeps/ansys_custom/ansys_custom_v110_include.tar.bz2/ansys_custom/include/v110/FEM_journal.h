/* sid 60.1 copy of FEM_journal.h last changed by upd111 on 2005/07/21 19:40:18 */
/*  FEM_journal.h */
/*
 * *** ansys(r) copyright(c) 1999
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_journal.h
 *  header file for FEM_journal.c
 *
 */
#ifndef FEM_JOURNAL_H
#define FEM_JOURNAL_H

extern JOURNAL_WRITE_TYPE g_journal;


                             /* ============================================= */
                             /* === FEM_jrWriteFuncHeader: Write out a header */
                             /* === in the journal file for a routine that    */
                             /* === just called.                              */
                             /* === RETURN: INT, EXIT_SUCCESS or EXIT_FAILURE */
                             /* ============================================= */
INT FEM_jrWriteFuncHeader(
   char *routine,            /* (IN)  name of routine called.                 */
   INT num_args );           /* (IN)  num arguments on routine.               */

                             /* ============================================= */
                             /* === FEM_jrWriteFuncTrailer: Write a trailer   */
                             /* === in the journal file for a routine that was*/
                             /* === just called.  This is used for void       */
                             /* === functions. If the routine returns a value */
                             /* === call one of the other WriteFuncTrailerX   */
                             /* === routines.                                 */
                             /* === RETURN: INT, EXIT_SUCCESS or EXIT_FAILURE */
                             /* ============================================= */
INT FEM_jrWriteFuncTrailer(
   char *routine );          /* (IN)  name of routine called.                 */

                             /* ============================================= */
                             /* === FEM_jrWriteFuncTrailerInt:  Write a       */
                             /* === trailer in the journal file for a routine */
                             /* === that was just called and also returns an  */
                             /* === integer.                                  */
                             /* === RETURN: INT, EXIT_SUCCESS or EXIT_FAILURE */
                             /* ============================================= */
INT FEM_jrWriteFuncTrailerInt(
   char *routine,            /* (IN)  name of routine called.                 */
   INT the_int );            /* (IN)  The value returned from routine.        */

                             /* ============================================= */
                             /* === FEM_jrWriteFuncTrailerDbl:  Write a       */
                             /* === trailer in the journal file for a routine */
                             /* === that was just called and also returns an  */
                             /* === double.                                   */
                             /* === RETURN: INT, EXIT_SUCCESS or EXIT_FAILURE */
                             /* ============================================= */
INT FEM_jrWriteFuncTrailerDbl(
   char *routine,            /* (IN)  name of routine called.                 */
   DOUBLE the_dbl );         /* (IN)  The value returned from routine.        */

                             /* ============================================= */
                             /* === FEM_jrWriteFuncTrailerBool:  Write a      */
                             /* === trailer in the journal file for a routine */
                             /* === that was just called and also returns an  */
                             /* === boolean.                                  */
                             /* === RETURN: INT, EXIT_SUCCESS or EXIT_FAILURE */
                             /* ============================================= */
INT FEM_jrWriteFuncTrailerBool(
   char *routine,            /* (IN)  name of routine called.                 */
   FEM_BOOLEAN the_bool );   /* (IN)  The value returned from routine.        */

                             /* ============================================= */
                             /* === FEM_jrWriteGeoType: Write out a routine   */
                             /* === argument of type GEOTYPE.                 */
                             /* === RETURN: INT, EXIT_SUCCESS or EXIT_FAILURE */
                             /* ============================================= */
INT FEM_jrWriteGeoType(
   FEM_GEOTYPE the_gtype );  /* (IN)  Value of the GEOTYPE argument.          */

                             /* ============================================= */
                             /* === FEM_jrWriteInt: Write out a routine       */
                             /* === argument of type INT.                     */
                             /* === RETURN: INT, EXIT_SUCCESS or EXIT_FAILURE */
                             /* ============================================= */
INT FEM_jrWriteInt(
   INT the_int );            /* (IN)  Value of the INT argument.              */

                             /* ============================================= */
                             /* === FEM_jrWriteDbl: Write out a routine       */
                             /* === argument of type DOUBLE.                  */
                             /* === RETURN: INT, EXIT_SUCCESS or EXIT_FAILURE */
                             /* ============================================= */
INT FEM_jrWriteDbl(
   DOUBLE the_dbl );         /* (IN)  Value of the DOUBLE argument.           */

                             /* ============================================= */
                             /* === FEM_jrWriteString: Write out a routine    */
                             /* === argument of type CHAR *.                  */
                             /* === RETURN: INT, EXIT_SUCCESS or EXIT_FAILURE */
                             /* ============================================= */
INT FEM_jrWriteString(
   char *str );              /* (IN)  Value of the CHAR * argument.           */

                             /* ============================================= */
                             /* === FEM_jrWriteBool: Write out a routine      */
                             /* === argument of type FEM_BOOLEAN.             */
                             /* === RETURN: INT, EXIT_SUCCESS or EXIT_FAILURE */
                             /* ============================================= */
INT FEM_jrWriteBool(
   FEM_BOOLEAN the_bool );   /* (IN)  Value of the FEM_BOOLEAN argument.      */

                             /* ============================================= */
                             /* === FEM_jrWriteAEShape: Write out a routine   */
                             /* === argument of type AREAELEM_SHAPE.          */
                             /* === RETURN: INT, EXIT_SUCCESS or EXIT_FAILURE */
                             /* ============================================= */
INT FEM_jrWriteAEShape(
   AREAELEM_SHAPE the_shape);/* (IN)  Value of the AREAELEM_SHAPE argument.   */

                             /* ============================================= */
                             /* === FEM_jrWriteDblArray:  Write out a routine */
                             /* === argument that is an array of DOUBLEs.     */
                             /* === RETURN: INT, EXIT_SUCCESS or EXIT_FAILURE */
                             /* ============================================= */
INT FEM_jrWriteDblArray(
   DOUBLE *a_array,          /* (IN)  argument array.                         */
   INT length );             /* (IN)  length of a_array.                      */

                             /* ============================================= */
                             /* === FEM_jrWriteIntArray:  Write out a routine */
                             /* === argument that is an array of INTs.        */
                             /* === RETURN: INT, EXIT_SUCCESS or EXIT_FAILURE */
                             /* ============================================= */
INT FEM_jrWriteIntArray(
   INT *a_array,             /* (IN)  argument array.                         */
   INT length );             /* (IN)  length of a_array.                      */

                             /* ============================================= */
                             /* === FEM_jrReadFuncHeader: Read in a routine   */
                             /* === header.                                   */
                             /* === RETURN: INT, EXIT_SUCCESS or EXIT_FAILURE */
                             /* ============================================= */
INT FEM_jrReadFuncHeader(
   char *routine,            /* (IN)  name of routine called. Not used if     */
                             /*       match == FALSE.                         */
                             /* (OUT) name of routine in journal file.        */
   INT *num_args,            /* (IN)  number of args on routine.  Not used if */
                             /*       match == FALSE.                         */
                             /* (OUT) number of args in journal file.         */
   FEM_BOOLEAN match );      /* (IN)  TRUE if input arguments must match what */
                             /*       is in the journal file.                 */

                             /* ============================================= */
                             /* === FEM_jrReadFuncTrailer: Read in a void     */
                             /* === routine trailer.                          */
                             /* === RETURN: INT, EXIT_SUCCESS or EXIT_FAILURE */
                             /* ============================================= */
INT FEM_jrReadFuncTrailer(
   char *routine );          /* (IN) name of routine called.  This is compared*/
                             /*      with name in journal file to detect      */
                             /*      corruption.                              */

                             /* ============================================= */
                             /* === FEM_jrReadFuncTrailerInt: Read in an      */
                             /* === INT routine trailer.                      */
                             /* === RETURN: INT, EXIT_SUCCESS or EXIT_FAILURE */
                             /* ============================================= */
INT FEM_jrReadFuncTrailerInt(
   char *routine,            /* (IN)  name of routine called.  This is        */
                             /*       compared with name in journal file to   */
                             /*       detect corruption.                      */
   INT *the_int );           /* (OUT) return value from routine.              */

                             /* ============================================= */
                             /* === FEM_jrReadFuncTrailerDbl: Read in a       */
                             /* === DOUBLE routine trailer.                   */
                             /* === RETURN: INT, EXIT_SUCCESS or EXIT_FAILURE */
                             /* ============================================= */
INT FEM_jrReadFuncTrailerDbl(
   char *routine,            /* (IN)  name of routine called.  This is        */
                             /*       compared with name in journal file to   */
                             /*       detect corruption.                      */
   DOUBLE *the_dbl );        /* (OUT) return value from routine.              */

                             /* ============================================= */
                             /* === FEM_jrReadFuncTrailerBool: Read in        */
                             /* === FEM_BOOLEAN routine trailer.              */
                             /* === RETURN: INT, EXIT_SUCCESS or EXIT_FAILURE */
                             /* ============================================= */
INT FEM_jrReadFuncTrailerBool(
   char *routine,            /* (IN)  name of routine called.  This is        */
                             /*       compared with name in journal file to   */
                             /*       detect corruption.                      */
   FEM_BOOLEAN *the_bool );  /* (OUT) return value from routine.              */

                             /* ============================================= */
                             /* === FEM_jrReadString:  Read in a String       */
                             /* === routine argument.                         */
                             /* === RETURN: INT, EXIT_SUCCESS or EXIT_FAILURE */
                             /* ============================================= */
INT FEM_jrReadString(
   char *str,                /* (IN)  string that should be in journal file.  */
                             /*       Not used if match == FALSE.             */
                             /* (OUT) string in journal file.                 */
   FEM_BOOLEAN match );      /* (IN)  TRUE if input arguments must match what */
                             /*       is in the journal file.                 */

                             /* ============================================= */
                             /* === FEM_jrReadInt:  Read in a integer         */
                             /* === routine argument.                         */
                             /* === RETURN: INT, EXIT_SUCCESS or EXIT_FAILURE */
                             /* ============================================= */
INT FEM_jrReadInt(
   INT *the_int,             /* (IN)  integer that should be in journal file. */
                             /*       Not used if match == FALSE.             */
                             /* (OUT) INT in journal file.                    */
   FEM_BOOLEAN match );      /* (IN)  TRUE if input arguments must match what */
                             /*       is in the journal file.                 */

                             /* ============================================= */
                             /* === FEM_jrReadDbl:  Read in a double          */
                             /* === routine argument.                         */
                             /* === RETURN: INT, EXIT_SUCCESS or EXIT_FAILURE */
                             /* ============================================= */
INT FEM_jrReadDbl(
   DOUBLE *the_dbl,          /* (IN)  DOUBLE that should be in the journal    */
                             /*       file.  Not used if match == FALSE.      */
                             /* (OUT) double in journal file.                 */
   FEM_BOOLEAN match );      /* (IN)  TRUE if input arguments must match what */
                             /*       is in the journal file.                 */

                             /* ============================================= */
                             /* === FEM_jrReadBool:  Read in a boolean        */
                             /* === routine argument.                         */
                             /* === RETURN: INT, EXIT_SUCCESS or EXIT_FAILURE */
                             /* ============================================= */
INT FEM_jrReadBool(
   FEM_BOOLEAN *the_bool,    /*(IN) FEM_BOOLEAN that should be in the journal */
                             /*       file.  Not used if match == FALSE.      */
                             /* (OUT) FEM_BOOLEAN in journal file.            */
   FEM_BOOLEAN match );      /* (IN)  TRUE if input arguments must match what */
                             /*       is in the journal file.                 */

                             /* ============================================= */
                             /* === FEM_jrReadGeoType:  Read in a GEOTYPE     */
                             /* === routine argument.                         */
                             /* === RETURN: INT, EXIT_SUCCESS or EXIT_FAILURE */
                             /* ============================================= */
INT FEM_jrReadGeoType(
   FEM_GEOTYPE *the_gtype,   /* (IN)  GEOTYPE that should be in the journal   */
                             /*       file.  Not used if match == FALSE.      */
                             /* (OUT) GEOTYPE in journal file.                */
   FEM_BOOLEAN match );      /* (IN)  TRUE if input arguments must match what */
                             /*       is in the journal file.                 */

                             /* ============================================= */
                             /* === FEM_jrReadAEShape:  Read in a             */
                             /* === AREAELEM_SHAPE routine argument.          */
                             /* === RETURN: INT, EXIT_SUCCESS or EXIT_FAILURE */
                             /* ============================================= */
INT FEM_jrReadAEShape(
   AREAELEM_SHAPE *the_shape,/* (IN)  AREAELEM_SHAPE that should be in the    */
                             /*       journal file.  Not used if match ==     */
                             /*       FALSE.                                  */
                             /* (OUT) AREAELEM_SHAPE in journal file.         */
   FEM_BOOLEAN match );      /* (IN)  TRUE if input arguments must match what */
                             /*       is in the journal file.                 */

                             /* ============================================= */
                             /* === FEM_jrReadDblArray:  Read in a routine    */
                             /* === argument of type DOUBLE array.            */
                             /* === RETURN: INT, EXIT_SUCCESS or EXIT_FAILURE */
                             /* ============================================= */
INT FEM_jrReadDblArray(
   DOUBLE *a_array,          /* (IN)  values of array that should be in       */
                             /*       journal file.  Not used if match ==     */
                             /*       FALSE.                                  */
                             /* (OUT) Actual double array in journal file.    */
   INT *length,              /* (IN)  length that the array in journal file   */
                             /*       should be.                              */
                             /* (OUT) Actual length of array in journal file. */
   FEM_BOOLEAN match );      /* (IN)  TRUE if input arguments must match what */
                             /*       is in the journal file.                 */

                             /* ============================================= */
                             /* === FEM_jrReadDblArray:  Read in a routine    */
                             /* === argument of type DOUBLE array and         */
                             /* === allocate memory to hold what is read in.  */
                             /* === RETURN: INT, EXIT_SUCCESS or EXIT_FAILURE */
                             /* ============================================= */
INT FEM_jrReadDblArray2(
   DOUBLE **a_array,         /* (OUT) array read from file. (Allocated by     */
                             /*       FEM_jrReadDblArray2).                   */
   INT *length );            /* (OUT) lengthof a_array.                       */

                             /* ============================================= */
                             /* === FEM_jrReadIntArray:  Read in a routine    */
                             /* === argument of type INT array.               */
                             /* === RETURN: INT, EXIT_SUCCESS or EXIT_FAILURE */
                             /* ============================================= */
INT FEM_jrReadIntArray(
   INT *a_array,             /* (IN)  values of array that should be in       */
                             /*       journal file.  Not used if match ==     */
                             /*       FALSE.                                  */
                             /* (OUT) Actual int array in journal file.       */
   INT *length,              /* (IN)  length that the array in journal file   */
                             /*       should be.                              */
                             /* (OUT) Actual length of array in journal file. */
   FEM_BOOLEAN match );      /* (IN)  TRUE if input arguments must match what */
                             /*       is in the journal file.                 */

                             /* ============================================= */
                             /* === FEM_jrReadIntArray:  Read in a routine    */
                             /* === argument of type INT array and            */
                             /* === allocate memory to hold what is read in.  */
                             /* === RETURN: INT, EXIT_SUCCESS or EXIT_FAILURE */
                             /* ============================================= */
INT FEM_jrReadIntArray2(
   INT **a_array,            /* (OUT) array read from file. (Allocated by     */
                             /*       FEM_jrReadDblArray2).                   */
   INT *length );            /* (OUT) lengthof a_array.                       */

#endif

