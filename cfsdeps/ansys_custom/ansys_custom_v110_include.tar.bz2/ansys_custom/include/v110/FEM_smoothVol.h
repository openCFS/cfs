/* sid 60.1 copy of FEM_smoothVol.h last changed by upd111 on 2005/07/21 19:41:34 */

/* ---------------------------------------------------------------------- */
/* *** ansys(r) copyright(c) 1998 */
/* *** ansys, inc.                */
/* ---------------------------------------------------------------------- */


/*  FEM_smoothVol.h */
/* *** Notice - This file contains ANSYS Confidential information  ***      */
/*
 *  FEM_smoothVol.h
 *  header file for FEM_smoothVol.c
 *
 */
#ifndef FEM_SMOOTHVOL_INCLUDE
#define FEM_SMOOTHVOL_INCLUDE

#ifdef __cplusplus
extern "C" {
#endif

/*----------------- Globally accessible function prototypes -----------------*/

                              /* =========================================== */
                              /* === FEM_smVolumeSmooth: apply constrained   */
                              /* === Laplacian smoothing to movable          */
                              /* === (interior) vertices of a given tet mesh */
                              /* === (in a global data structure, possibly   */
                              /* === containing non-tet elements); all tets  */
                              /* === must be put in NEGATIVE volume vertex   */
                              /* === order (positive TetMetric vertex order);*/
                              /* === optimization-based moves may be         */
                              /* === attempted for some vertices depending   */
                              /* === on shape measures                       */
                              /* === Return: EXIT_SUCCESS or EXIT_FAILURE    */
                              /* =========================================== */
INT FEM_smVolumeSmooth (
   INT npass,                 /* (IN)  maximum number of smoothing passes    */
                              /*       actual number of passes may be        */
                              /*       fewer if no vertices moved in a       */
                              /*       pass                                  */
   INT mtype,                 /* (IN)  measure type (1 to 4)                 */
   DOUBLE mtmov,              /* (IN)  vertex is moved if min(measures       */
                              /*       of new tets incident on vertex) >     */
                              /*       min(measures of old tets, mtmov)      */
                              /*       + movtol; so if mtmov >= 1.0,         */
                              /*       movement occurs only if worst tet     */
                              /*       is improved                           */
   DOUBLE movtol,             /* (IN)  tolerance that measures must          */
                              /*       improve by in order to move           */
                              /*       vertex (see above)                    */
   DOUBLE mtopt,              /* (IN)  max tet measure for which optimization*/
                              /*       based smoothing is applied to move    */
                              /*       vertex; if mtopt > 1.0                */
                              /*       (and pass# <= nexpass), then          */
                              /*       optimization move is always           */
                              /*       attempted; if mtopt <= 0.0, then      */
                              /*       no optimization move is attempted     */
                              /*       (assuming no inverted tets)           */
   INT nexpass,               /* (IN)  number of expensive passes for        */
                              /*       opt-based smoothing may be applied    */
   FEM_BOOLEAN *abort  );     /* (OUT) return TRUE (with EXIT_SUCCESS)       */
                              /*       if user abort occurred                */
                              /* =========================================== */

/* ************ Further comments on usage of FEM_smVolumeSmooth ************

   a) Positive TetMetric vertex order is same as negative volume vertex order.
      Sign of tet volume is given by sign of 4 by 4 determinant formed from
      ordered tet vertices, with each column (or row) being homogeneous
      coordinates of a vertex).
   b) If the triangulation/mesh is output by FEM_improveTet then the shape
      metric field of tets is already set (assuming same mtype), else call
      function FEM_imInitElemMetric to initialize this field. The shape
      metric field of tets are updated on exit. FEM_imInitElemMetric and
      FEM_smVolumeSmooth also set or update shape metric field for pyramids,
      but not wedges and hexahedra (since no metric exist yet).
   c) Midnodes do not have to be present on all edges. Any missing midnode is
      taken to be the midpoint of edge for quadratic tet measure evaluation.
   d) Non-tet elements (e.g. pyramids, wedges, hexes) may be present in mesh.
      In addition to unconstrained tets, unconstrained pyramids may also be
      modified.
   e) Nodes that can be moved are interior corner nodes (not on an interior
      area or line, i.e. NODE_IN_VOLUME property is TRUE), incident on
      unconstrained tets or pyramids, that have the NODE_SMOOTHABLE property
      set to TRUE. Function FEM_smSetVolumeNodesSmoothable can be called to
      initialize NODE_SMOOTHABLE property flag (any midnode will have
      NODE_SMOOTHABLE property set to FALSE).
   f) Midnodes are ignored for the linear tet measures (mtype = 1, 2, or 3).
      For quadratic tets, they will need to be recalculated as midpoint of
      edge for those edges incident on a moved node (indicated by NODE_MOVED
      property set to TRUE), on exit from FEM_smVolumeSmooth. (So NODE_MOVED
      property flag must be set to FALSE before entering routine.)
   g) See file FEMa_swapnsmo.c for example of required initialization.

   ************ End of comments on usage of FEM_smVolumeSmooth ************* */


                              /* =========================================== */
                              /* === FEM_smSetVolumeNodesSmoothable: In      */
                              /* === preparation to call FEM_smVolumeSmooth, */
                              /* === set the NODE_SMOOTHABLE flag in all     */
                              /* === nodes.  The flag will be set to be TRUE */
                              /* === for all nodes with the NODE_IN_VOLUME   */
                              /* === property set but are not adjacent to    */
                              /* === any hexes or wedges.  The hex and wedge */
                              /* === limitation is only temporary since the  */
                              /* === smoother does not yet have a metric for */
                              /* === these element shapes.                   */
                              /* === Return: EXIT_SUCCESS or EXIT_FAILURE    */
                              /* =========================================== */
INT FEM_smSetVolumeNodesSmoothable (
   NODELIST_OBJ obj_nlist,    /* (IN)  node list                             */
   ELEMENTLIST_OBJ obj_ellist  );/* (IN) element list                        */
                              /* =========================================== */

                              /* =========================================== */
                              /* === FEM_smElementMetric: compute element    */
                              /* === metric (not implemented for hexes and   */
                              /* === wedges)                                 */
                              /* === Return: DOUBLE the metric               */
                              /* =========================================== */
DOUBLE FEM_smElementMetric (
   ELEMENT_OBJ obj_element,   /* (IN)  an element                            */
   INT mtype  );              /* (IN)  measure type (1-6)                    */
                              /* =========================================== */

                              /* =========================================== */
                              /* === FEM_smVolumeOptMove: try to move        */
                              /* === interior node to a near-optimal         */
                              /* === position wrt its incident tetrahedra    */
                              /* =========================================== */
INT FEM_smVolumeOptMove ( 
   NODE_OBJ obj_node,         /* (IN) interior node                          */
   INT mtype,                 /* (IN) measure type (1 to 6)                  */
   DOUBLE movtol,             /* (IN) tolerance that measures must improve by*/
                              /* in order to move node                       */
   DOUBLE delta,              /* (IN) positive perturbation for estimating   */
                              /* gradients                                   */
   INT nelem,                 /* (IN) number of elements incident on node    */
   ELEMENT_OBJ aobj_elem[],   /* (IN) array of nelem tetrahedral objects     */
   VECTOR3D as_midnsav[],     /* (IN) work array for saving previous         */
                              /* midnodes; must be of size >= number of      */
                              /* edges incident on node                      */
   FEM_BOOLEAN *move_node );  /* (OUT) return TRUE if node is moved          */
#ifdef __cplusplus
}
#endif


#endif
