/* sid 60.1 copy of fem_Private.h last changed by upd111 on 2005/07/21 19:42:02 */
/* fem_Private.h */
/* 
 * *** ansys(r) copyright(c) 1999
 * *** ansys, inc.
 */
/* *** Notice - This file contains ANSYS Confidential information  *** */
/*                                                          
 * === fem_Private.h
 * === Finite element mesh module private header
 * === (Only FEM_* or fem_* functions should include this header file)
 */
#ifndef FEM_PRIVATE
#define FEM_PRIVATE

#include "FEM_cdbtypes.h"

#include "FEM_Public.h"

/*
 * === Include structure definitions for various data representations
 */

#include "fem_Struct.h"

/*
 * === Private prototypes
 */

/*
 * === Include prototypes and macros that can be accessed only within
 * === the FEM module (one for each object type)
 */

#ifndef STANDALONE_DELAUNAY
#include "fem_elPriv.h"
#endif
#include "fem_faPriv.h"
#include "fem_edPriv.h"
#include "fem_noPriv.h"

/*
 * === Include info for mesh memory mangement
 */

#include "fem_Memory.h"

#endif

