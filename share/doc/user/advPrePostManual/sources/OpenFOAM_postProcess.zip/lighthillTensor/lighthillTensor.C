/*---------------------------------------------------------------------------* \
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     |
    \\  /    A nd           | Copyright (C) 2011 OpenFOAM Foundation
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM.  If not, see <http://www.gnu.org/licenses/>.

Application
    divLambVector

Description
    Calculates and writes the divergence of the Lamb vector (modified from 
    sources of Lambda2)

    The -noWrite option has no meaning.

\*---------------------------------------------------------------------------*/

#include "calc.H"
#include "fvc.H"

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

void Foam::calc(const argList& args, const Time& runTime, const fvMesh& mesh)
{
    IOobject Uheader
    (
        "U",
        runTime.timeName(),
        mesh,
        IOobject::MUST_READ
    );

    if (Uheader.headerOk())
    {
        Info<< "    Reading U" << endl;
        volVectorField U(Uheader, mesh);

/* const volTensorField gradU(fvc::grad(U));

        volTensorField SSplusWW
        (
            (symm(gradU) & symm(gradU)) + (skew(gradU) & skew(gradU))
        ); */

        Info<< "    Calculating tensor U*U" << endl;
        volTensorField tensUU
        (
            IOobject
            (
                "tensUU",
                runTime.timeName(),
                mesh,
                IOobject::NO_READ
            ),
            U*U
//           -eigenValues(SSplusWW)().component(vector::Y)
        );

        Info<< "    Calculating div(U*U)" << endl;
        volVectorField divUU
        (
            IOobject
            (
                "divUU",
                runTime.timeName(),
                mesh,
                IOobject::NO_READ
            ),
            fvc::div(tensUU)
//           -eigenValues(SSplusWW)().component(vector::Y)
        );

        Info<< "    Calculating div(div(U*U))" << endl;
        volScalarField derivLighthillT
        (
            IOobject
            (
                "derivLighthillT",
                runTime.timeName(),
                mesh,
                IOobject::NO_READ,
                IOobject::NO_WRITE
            ),
            fvc::div(divUU)
//           -eigenValues(SSplusWW)().component(vector::Y)
        );

        Info<< "    Writing derivLighthillT" << endl;
        derivLighthillT.write();
    }
    else
    {
        Info<< "    No U" << endl;
    }

    Info<< "\nEnd\n" << endl;
}


// ************************************************************************* //
